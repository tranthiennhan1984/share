﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Configuration;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace PFClient {
    internal class Program {
        static int Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            if (debug == "Y") System.Diagnostics.Debugger.Launch();


            var args = Host.Arguments;
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());


            string input_file = string.Empty;
            string input_folder = string.Empty;
            string output_folder = string.Empty;
            string soap_url = string.Empty;
            string soap_action = string.Empty;
            string soap_template = string.Empty;

            var retval = ReadArgs(args, ref input_file, ref input_folder, ref output_folder, ref soap_url, ref soap_action, ref soap_template);

            Console.WriteLine("input_file: {0}", input_file);
            Console.WriteLine("input_folder: {0}", input_folder);
            Console.WriteLine("output_folder: {0}", output_folder);
            Console.WriteLine("soap_url: {0}", soap_url);
            Console.WriteLine("soap_action: {0}", soap_action);
            if (retval < 0) return retval;

            return Task.Factory.StartNew(async () => {
                return await Process(new HttpClient(), input_file, input_folder, output_folder, new Uri(soap_url, UriKind.RelativeOrAbsolute), soap_action, soap_template);
            }).Unwrap().GetAwaiter().GetResult();

        }
        private static async Task<int> Process(HttpClient client, string input_file, string input_folder, string output_folder, Uri soap_url, string soap_action, string soap_template) {
            if (!string.IsNullOrWhiteSpace(input_file)) {
                return await ProcessFile(client, input_file, output_folder, soap_url, soap_action, soap_template);
            }
            return await ProcessFolder(client, input_folder, output_folder, soap_url, soap_action, soap_template);
        }

        private static async Task<int> ProcessFolder(HttpClient client, string input_folder, string output_folder, Uri soap_url, string soap_action, string soap_template) {
            foreach (var file in Directory.GetFiles(input_folder, "*.xml")) {
                var retVal = await ProcessFile(client, Path.Combine(input_folder, file), output_folder, soap_url, soap_action, soap_template);
                if (retVal < 0) return retVal;
            }
            return 0;
        }
        private static async Task<int> ProcessFile(HttpClient client, string input_file, string output_folder, Uri soap_url, string soap_action, string soap_template) {
            var fName = Path.Combine(output_folder, Path.GetFileName(input_file));
            var req = ReadXml(soap_template, input_file);
            var resp = await Soap(client, soap_url, soap_action, req);
            File.WriteAllText(fName, resp);
            return 0;
        }
        public static async Task<string> Soap(HttpClient client, Uri url, string action, string request) {
            try {
                using (var req = new HttpRequestMessage(HttpMethod.Post, url)) {
                    req.Headers.Add("SOAPAction", action);
                    req.Content = new StringContent(request, Encoding.UTF8, "text/xml");

                    string content;
                    using (var response = await client.SendAsync(req)) {
                        content = await response.Content.ReadAsStringAsync();
                    }
                    //HtmlDecode(p))
                    var index = content.IndexOf(":callTXLifeResponse ");
                    if (index < 0) return content;
                    var start = content.IndexOf(">", index) + 1;
                    var end = content.IndexOf("<", start);
                    return HtmlDecode(content.Substring(start, end - start));
                }
            } catch (Exception ex) {
                return ex.ToString();
            }
        }
        private static string ReadXml(string soap_template, string filePath) {
            var sb = new StringBuilder();

            Action<string> step;
            var step2 = new Action<string>(l => sb.AppendLine(l));
            var step1 = new Action<string>(l => {
                if (l.IndexOf("<?") > -1) return;
                sb.AppendLine(l);
                step = step2;
            });
            step = step1;
            string line;
            using (var reader = File.OpenText(filePath)) {
                while ((line = reader.ReadLine()) != null) {
                    step(line);
                }
            }
            return string.Format(soap_template, sb.ToString());
        }
        private static int ReadArgs(Arguments args, ref string input_file, ref string input_folder, ref string output_folder, ref string soap_url, ref string soap_action, ref string soap_template) {
            var configPath = Path.Combine(Arguments.CorrectFolderPath(null), "PFClient.config");
            using (var reader = File.OpenText(configPath)) {
                ReadConfig(reader,
                    ref input_file,
                    ref input_folder,
                    ref output_folder,
                    ref soap_url,
                    ref soap_action,
                    ref soap_template);
            }
            if (args.TryGetNotEmpty("f", out string f)) {
                input_file = f;
            }
            if (args.TryGetNotEmpty("i", out string i)) {
                input_folder = i;
            }
            if (args.TryGetNotEmpty("o", out string o)) {
                output_folder = o;
            }

            if (string.IsNullOrWhiteSpace(soap_url)) {
                Console.Out.WriteLine($"Missing soap_url");
                return -1;
            }

            if (File.Exists(soap_template)) soap_template = File.ReadAllText(soap_template);
            else if (string.IsNullOrWhiteSpace(soap_template)) {
                using (var stream = new StreamReader(typeof(Program).Assembly.GetManifestResourceStream("PFClient.soapTemplate.xml"))) {
                    soap_template = stream.ReadToEnd();
                }
            }
            if (string.IsNullOrWhiteSpace(soap_template)) {
                Console.Out.WriteLine($"Missing soap_template");
                return -1;
            }

            if (string.IsNullOrWhiteSpace(output_folder)) {
                Console.Out.WriteLine($"Missing output_folder");
                return -1;
            } else Arguments.CorrectFolderPath(output_folder);

            if (!Directory.Exists(output_folder)) Directory.CreateDirectory(output_folder);

            if (string.IsNullOrWhiteSpace(input_file)) {
                if (string.IsNullOrWhiteSpace(input_folder)) {
                    Console.Out.WriteLine($"Missing input_file");
                    return -1;
                }
                Arguments.CorrectFolderPath(input_folder);
                if (!Directory.Exists(input_folder)) {
                    Console.Out.WriteLine($"Input folder doesn't exist {input_folder}");
                    return -1;
                }
            } else if (!File.Exists(input_file)) {
                Console.Out.WriteLine($"Input file doesn't exist {input_file}");
                return -1;
            }
            return 0;
        }

        private static void ReadConfig(TextReader reader, ref string input_file, ref string input_folder, ref string output_folder, ref string soap_url, ref string soap_action, ref string soap_template) {
            string line;
            while ((line = reader.ReadLine()) != null) {
                if (string.IsNullOrWhiteSpace(line)) continue;
                var index = line.IndexOf(':');
                if (index <= 0) continue;
                var name = line.Substring(0, index);
                var value = line.Substring(index + 1);
                switch (name) {
                    case "input_file": input_file = value; break;
                    case "input_folder": input_folder = value; break;
                    case "output_folder": output_folder = value; break;
                    case "soap_url": soap_url = value; break;
                    case "soap_action": soap_action = value; break;
                    case "soap_template": soap_template = value; break;
                }
            }
        }
        private static void RegisterArgs(Arguments args) {
            args.RegisterOptions("f", "Input file in xml format")
                .RegisterOptions("i", "Input folder constain list of input file")
                .RegisterOptions("o", "Output folder")
            ;
        }


        public static string HtmlDecode(string value) {
            if (String.IsNullOrEmpty(value)) {
                return value;
            }

            // Don't create string writer if we don't have nothing to encode
            if (!StringRequiresHtmlDecoding(value)) {
                return value;
            }

            StringWriter writer = new StringWriter(CultureInfo.InvariantCulture);
            HtmlDecode(value, writer);
            return writer.ToString();
        }

        public static void HtmlDecode(string value, TextWriter output) {
            if (value == null) {
                return;
            }
            if (output == null) {
                throw new ArgumentNullException("output");
            }

            if (!StringRequiresHtmlDecoding(value)) {
                output.Write(value);        // good as is
                return;
            }

            //UnicodeDecodingConformance decodeConformance = HtmlDecodeConformance;
            int l = value.Length;
            for (int i = 0; i < l; i++) {
                char ch = value[i];

                if (ch == '&') {
                    // We found a '&'. Now look for the next ';' or '&'. The idea is that
                    // if we find another '&' before finding a ';', then this is not an entity,
                    // and the next '&' might start a real entity (VSWhidbey 275184)
                    int index = value.IndexOfAny(_htmlEntityEndingChars, i + 1);
                    if (index > 0 && value[index] == ';') {
                        string entity = value.Substring(i + 1, index - i - 1);

                        if (entity.Length > 1 && entity[0] == '#') {
                            // The # syntax can be in decimal or hex, e.g.
                            //      &#229;  --> decimal
                            //      &#xE5;  --> same char in hex
                            // See http://www.w3.org/TR/REC-html40/charset.html#entities

                            bool parsedSuccessfully;
                            uint parsedValue;
                            if (entity[1] == 'x' || entity[1] == 'X') {
                                parsedSuccessfully = UInt32.TryParse(entity.Substring(2), NumberStyles.AllowHexSpecifier, NumberFormatInfo.InvariantInfo, out parsedValue);
                            } else {
                                parsedSuccessfully = UInt32.TryParse(entity.Substring(1), NumberStyles.Integer, NumberFormatInfo.InvariantInfo, out parsedValue);
                            }

                            if (parsedSuccessfully) {
                                parsedSuccessfully = ((parsedValue < HIGH_SURROGATE_START) || (LOW_SURROGATE_END < parsedValue && parsedValue <= UNICODE_PLANE16_END));
                                //switch (decodeConformance) {
                                //    case UnicodeDecodingConformance.Strict:
                                //        // decoded character must be U+0000 .. U+10FFFF, excluding surrogates
                                //        parsedSuccessfully = ((parsedValue < HIGH_SURROGATE_START) || (LOW_SURROGATE_END < parsedValue && parsedValue <= UNICODE_PLANE16_END));
                                //        break;

                                //    case UnicodeDecodingConformance.Compat:
                                //        // decoded character must be U+0001 .. U+FFFF
                                //        // null chars disallowed for compat with 4.0
                                //        parsedSuccessfully = (0 < parsedValue && parsedValue <= UNICODE_PLANE00_END);
                                //        break;

                                //    case UnicodeDecodingConformance.Loose:
                                //        // decoded character must be U+0000 .. U+10FFFF
                                //        parsedSuccessfully = (parsedValue <= UNICODE_PLANE16_END);
                                //        break;

                                //    default:
                                //        Debug.Assert(false, "Should never get here!");
                                //        parsedSuccessfully = false;
                                //        break;
                                //}
                            }

                            if (parsedSuccessfully) {
                                if (parsedValue <= UNICODE_PLANE00_END) {
                                    // single character
                                    output.Write((char)parsedValue);
                                } else {
                                    // multi-character
                                    char leadingSurrogate, trailingSurrogate;
                                    ConvertSmpToUtf16(parsedValue, out leadingSurrogate, out trailingSurrogate);
                                    output.Write(leadingSurrogate);
                                    output.Write(trailingSurrogate);
                                }

                                i = index; // already looked at everything until semicolon
                                continue;
                            }
                        } else {
                            i = index; // already looked at everything until semicolon

                            char entityChar = HtmlEntities.Lookup(entity);
                            if (entityChar != (char)0) {
                                ch = entityChar;
                            } else {
                                output.Write('&');
                                output.Write(entity);
                                output.Write(';');
                                continue;
                            }
                        }

                    }
                }

                output.Write(ch);
            }
        }

        private const char HIGH_SURROGATE_START = '\uD800';
        private const char LOW_SURROGATE_START = '\uDC00';
        private const char LOW_SURROGATE_END = '\uDFFF';
        private const int UNICODE_PLANE00_END = 0x00FFFF;
        private const int UNICODE_PLANE01_START = 0x10000;
        private const int UNICODE_PLANE16_END = 0x10FFFF;

        private const int UnicodeReplacementChar = '\uFFFD';

        private static readonly char[] _htmlEntityEndingChars = new char[] { ';', '&' };
        // similar to Char.ConvertFromUtf32, but doesn't check arguments or generate strings
        // input is assumed to be an SMP character
        private static void ConvertSmpToUtf16(uint smpChar, out char leadingSurrogate, out char trailingSurrogate) {
            Debug.Assert(UNICODE_PLANE01_START <= smpChar && smpChar <= UNICODE_PLANE16_END);

            int utf32 = (int)(smpChar - UNICODE_PLANE01_START);
            leadingSurrogate = (char)((utf32 / 0x400) + HIGH_SURROGATE_START);
            trailingSurrogate = (char)((utf32 % 0x400) + LOW_SURROGATE_START);
        }
        private static bool StringRequiresHtmlDecoding(string s) {
            //if (HtmlDecodeConformance == UnicodeDecodingConformance.Compat) {
            //    // this string requires html decoding only if it contains '&'
            //    return (s.IndexOf('&') >= 0);
            //} else {
            // this string requires html decoding if it contains '&' or a surrogate character
            for (int i = 0; i < s.Length; i++) {
                char c = s[i];
                if (c == '&' || Char.IsSurrogate(c)) {
                    return true;
                }
            }
            return false;
            //}
        }

        // helper class for lookup of HTML encoding entities
        private static class HtmlEntities {

            // The list is from http://www.w3.org/TR/REC-html40/sgml/entities.html, except for &apos;, which
            // is defined in http://www.w3.org/TR/2008/REC-xml-20081126/#sec-predefined-ent.

            private static String[] _entitiesList = new String[] {
                "\x0022-quot",
                "\x0026-amp",
                "\x0027-apos",
                "\x003c-lt",
                "\x003e-gt",
                "\x00a0-nbsp",
                "\x00a1-iexcl",
                "\x00a2-cent",
                "\x00a3-pound",
                "\x00a4-curren",
                "\x00a5-yen",
                "\x00a6-brvbar",
                "\x00a7-sect",
                "\x00a8-uml",
                "\x00a9-copy",
                "\x00aa-ordf",
                "\x00ab-laquo",
                "\x00ac-not",
                "\x00ad-shy",
                "\x00ae-reg",
                "\x00af-macr",
                "\x00b0-deg",
                "\x00b1-plusmn",
                "\x00b2-sup2",
                "\x00b3-sup3",
                "\x00b4-acute",
                "\x00b5-micro",
                "\x00b6-para",
                "\x00b7-middot",
                "\x00b8-cedil",
                "\x00b9-sup1",
                "\x00ba-ordm",
                "\x00bb-raquo",
                "\x00bc-frac14",
                "\x00bd-frac12",
                "\x00be-frac34",
                "\x00bf-iquest",
                "\x00c0-Agrave",
                "\x00c1-Aacute",
                "\x00c2-Acirc",
                "\x00c3-Atilde",
                "\x00c4-Auml",
                "\x00c5-Aring",
                "\x00c6-AElig",
                "\x00c7-Ccedil",
                "\x00c8-Egrave",
                "\x00c9-Eacute",
                "\x00ca-Ecirc",
                "\x00cb-Euml",
                "\x00cc-Igrave",
                "\x00cd-Iacute",
                "\x00ce-Icirc",
                "\x00cf-Iuml",
                "\x00d0-ETH",
                "\x00d1-Ntilde",
                "\x00d2-Ograve",
                "\x00d3-Oacute",
                "\x00d4-Ocirc",
                "\x00d5-Otilde",
                "\x00d6-Ouml",
                "\x00d7-times",
                "\x00d8-Oslash",
                "\x00d9-Ugrave",
                "\x00da-Uacute",
                "\x00db-Ucirc",
                "\x00dc-Uuml",
                "\x00dd-Yacute",
                "\x00de-THORN",
                "\x00df-szlig",
                "\x00e0-agrave",
                "\x00e1-aacute",
                "\x00e2-acirc",
                "\x00e3-atilde",
                "\x00e4-auml",
                "\x00e5-aring",
                "\x00e6-aelig",
                "\x00e7-ccedil",
                "\x00e8-egrave",
                "\x00e9-eacute",
                "\x00ea-ecirc",
                "\x00eb-euml",
                "\x00ec-igrave",
                "\x00ed-iacute",
                "\x00ee-icirc",
                "\x00ef-iuml",
                "\x00f0-eth",
                "\x00f1-ntilde",
                "\x00f2-ograve",
                "\x00f3-oacute",
                "\x00f4-ocirc",
                "\x00f5-otilde",
                "\x00f6-ouml",
                "\x00f7-divide",
                "\x00f8-oslash",
                "\x00f9-ugrave",
                "\x00fa-uacute",
                "\x00fb-ucirc",
                "\x00fc-uuml",
                "\x00fd-yacute",
                "\x00fe-thorn",
                "\x00ff-yuml",
                "\x0152-OElig",
                "\x0153-oelig",
                "\x0160-Scaron",
                "\x0161-scaron",
                "\x0178-Yuml",
                "\x0192-fnof",
                "\x02c6-circ",
                "\x02dc-tilde",
                "\x0391-Alpha",
                "\x0392-Beta",
                "\x0393-Gamma",
                "\x0394-Delta",
                "\x0395-Epsilon",
                "\x0396-Zeta",
                "\x0397-Eta",
                "\x0398-Theta",
                "\x0399-Iota",
                "\x039a-Kappa",
                "\x039b-Lambda",
                "\x039c-Mu",
                "\x039d-Nu",
                "\x039e-Xi",
                "\x039f-Omicron",
                "\x03a0-Pi",
                "\x03a1-Rho",
                "\x03a3-Sigma",
                "\x03a4-Tau",
                "\x03a5-Upsilon",
                "\x03a6-Phi",
                "\x03a7-Chi",
                "\x03a8-Psi",
                "\x03a9-Omega",
                "\x03b1-alpha",
                "\x03b2-beta",
                "\x03b3-gamma",
                "\x03b4-delta",
                "\x03b5-epsilon",
                "\x03b6-zeta",
                "\x03b7-eta",
                "\x03b8-theta",
                "\x03b9-iota",
                "\x03ba-kappa",
                "\x03bb-lambda",
                "\x03bc-mu",
                "\x03bd-nu",
                "\x03be-xi",
                "\x03bf-omicron",
                "\x03c0-pi",
                "\x03c1-rho",
                "\x03c2-sigmaf",
                "\x03c3-sigma",
                "\x03c4-tau",
                "\x03c5-upsilon",
                "\x03c6-phi",
                "\x03c7-chi",
                "\x03c8-psi",
                "\x03c9-omega",
                "\x03d1-thetasym",
                "\x03d2-upsih",
                "\x03d6-piv",
                "\x2002-ensp",
                "\x2003-emsp",
                "\x2009-thinsp",
                "\x200c-zwnj",
                "\x200d-zwj",
                "\x200e-lrm",
                "\x200f-rlm",
                "\x2013-ndash",
                "\x2014-mdash",
                "\x2018-lsquo",
                "\x2019-rsquo",
                "\x201a-sbquo",
                "\x201c-ldquo",
                "\x201d-rdquo",
                "\x201e-bdquo",
                "\x2020-dagger",
                "\x2021-Dagger",
                "\x2022-bull",
                "\x2026-hellip",
                "\x2030-permil",
                "\x2032-prime",
                "\x2033-Prime",
                "\x2039-lsaquo",
                "\x203a-rsaquo",
                "\x203e-oline",
                "\x2044-frasl",
                "\x20ac-euro",
                "\x2111-image",
                "\x2118-weierp",
                "\x211c-real",
                "\x2122-trade",
                "\x2135-alefsym",
                "\x2190-larr",
                "\x2191-uarr",
                "\x2192-rarr",
                "\x2193-darr",
                "\x2194-harr",
                "\x21b5-crarr",
                "\x21d0-lArr",
                "\x21d1-uArr",
                "\x21d2-rArr",
                "\x21d3-dArr",
                "\x21d4-hArr",
                "\x2200-forall",
                "\x2202-part",
                "\x2203-exist",
                "\x2205-empty",
                "\x2207-nabla",
                "\x2208-isin",
                "\x2209-notin",
                "\x220b-ni",
                "\x220f-prod",
                "\x2211-sum",
                "\x2212-minus",
                "\x2217-lowast",
                "\x221a-radic",
                "\x221d-prop",
                "\x221e-infin",
                "\x2220-ang",
                "\x2227-and",
                "\x2228-or",
                "\x2229-cap",
                "\x222a-cup",
                "\x222b-int",
                "\x2234-there4",
                "\x223c-sim",
                "\x2245-cong",
                "\x2248-asymp",
                "\x2260-ne",
                "\x2261-equiv",
                "\x2264-le",
                "\x2265-ge",
                "\x2282-sub",
                "\x2283-sup",
                "\x2284-nsub",
                "\x2286-sube",
                "\x2287-supe",
                "\x2295-oplus",
                "\x2297-otimes",
                "\x22a5-perp",
                "\x22c5-sdot",
                "\x2308-lceil",
                "\x2309-rceil",
                "\x230a-lfloor",
                "\x230b-rfloor",
                "\x2329-lang",
                "\x232a-rang",
                "\x25ca-loz",
                "\x2660-spades",
                "\x2663-clubs",
                "\x2665-hearts",
                "\x2666-diams",
            };

            private static Dictionary<string, char> _lookupTable = GenerateLookupTable();

            private static Dictionary<string, char> GenerateLookupTable() {
                // e[0] is unicode char, e[1] is '-', e[2+] is entity string

                Dictionary<string, char> lookupTable = new Dictionary<string, char>(StringComparer.Ordinal);
                foreach (string e in _entitiesList) {
                    lookupTable.Add(e.Substring(2), e[0]);
                }

                return lookupTable;
            }

            public static char Lookup(string entity) {
                char theChar;
                _lookupTable.TryGetValue(entity, out theChar);
                return theChar;
            }
        }

    }
}
