﻿using System.IO;
using System.Net.Http;
using System;
using System.Threading.Tasks;
using System.Text;
using Microsoft.SqlServer.Server;
using static System.Collections.Specialized.BitVector32;
using System.Net;

namespace PFClient {
    static class Extension {
        public static async Task<string> ProcessAsync(this HttpClient client, Uri url, string action, string content) {
            try {
                using (var req = new HttpRequestMessage(HttpMethod.Post, url)) {
                    req.Headers.Add("SOAPAction", action);
                    //req.Headers.Add("SOAPAction", "http://localhost:9081/TXLifeService");
                    req.Content = new StringContent(content, Encoding.UTF8, "text/xml");

                    using (var response = await client.SendAsync(req)) {
                        return await response.Content.ReadAsStringAsync();
                    }
                }
            } catch (Exception ex) {
                return ex.ToString();
            }
        }
    }
}
