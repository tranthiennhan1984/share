﻿namespace Binean.Foundation.Helpers {
    file static class Messages {
        public const string BFND030101E = "Cannot convert '{0}' to statement";
    }
    file static class Properties {
        public const string Service = nameof(Service);
        public const string Path = nameof(Path);
    }
    public class StatementsSetter : ISetter, IValidator {
        private static readonly MessageStorage _msgStorage = MessageStorage.Load(typeof(Messages));

        private readonly Processor _processor;
        private readonly List<IStatement> _stms = new();

        public StatementsSetter(Processor storage) {
            _processor = storage;
        }
        public StatementsSetter(Processor storage, IService service) : this(storage) {
            Setter = (p, i) => i.MSet(Properties.Service, service, guarantee: false);
        }

        public Action<string, ISetter>? Setter { get; set; }
        public Action<Processor>? Validator { get; set; }

        public bool WriteGuarantee { get; set; } = true;
        public bool TrySetValue(string name, object? value) {
            if (value is not IStatement stm) throw _msgStorage.CreateException(nameof(Messages.BFND030101E), value);
            _stms.Add(stm);
            _processor.Register(name, stm);
            if (stm.ToSetter() is ISetter st) {
                st.TrySetValue(Properties.Path, name);
                Setter?.Invoke(name, st);
            }
            return true;
        }
        public void Validate() {
            Validator?.Invoke(_processor);
            foreach (var stm in _stms) {
                if (stm is IValidator stmv) stmv.Validate();
            }
        }
    }
}

