﻿
using Binean.Private;
using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Data {
    [BMessage]
    file static class Messages {
        public const string BFND020101E = "Cannot set property: '{0}' to {1}.";
        public const string BFND020102E = "Cannot remove property: '{0}' from {1}.";
        public const string BFND020103E = "Cannot convert '{0}' to path.";
    }
    public static partial class Extension {

        #region :: PropPath Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEmpty([NotNullWhen(false)] this Propath path) => path.Count == 0;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty([NotNullWhen(false)] this Propath? path)
            => path == null || path.Count == 0;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Propath? ToPropath(this object obj, bool assert = true)
            => obj is Propath path ? path
                : obj is not string str ? null
                : Propath.TryParse(str, out Propath? p2) ? p2
                : assert ? throw MessageStorage.CreateException(nameof(Messages.BFND020103E), str)
                : null;

        public static T? GetParent<T>(this T? getter, Propath? path, out string? name) where T : IGetter {
            if (getter.IsNullOrEmpty() || path == null) {
                name = null;
                return default;
            }
            if (path.Count == 0) {
                name = null;
                return getter;
            }
            if (path.Count == 1) {
                name = path[0];
                return getter;
            }
            var ent = getter;
            path.Scan(n => {
                if (ent.Get(n).ToPEntity() is not T v) {
                    ent = default;
                    return false;
                }
                ent = v;
                return true;
            }, 0, path.Count - 2);
            name = ent == null ? null : path[^1];
            return ent;
        }
        public static bool TryRead(this IGetter? getter, Propath? path, out object? value, bool caseInsensitive = false) {
            using (Prior.CaseScope(caseInsensitive)) {
                var p = getter.GetParent(path, out string? name);
                if (p == null) {
                    value = null;
                    return false;
                }
                if (string.IsNullOrEmpty(name)) {
                    value = p;
                    return true;
                }
                return p.TryGetValue(name, out value);
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Read(this IGetter? getter, Propath? path, bool caseInsensitive = false)
            => TryRead(getter, path, out object? value, caseInsensitive) ? value : null;

        #endregion

    }
}
