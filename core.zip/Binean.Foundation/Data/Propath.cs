﻿using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Binean.Foundation.Data {
    public sealed class Propath {
        private readonly List<string> _props = new();
        private Propath() { }
        public Propath(string name) {
            AddItem(name);
        }
        public string this[int index] => _props[index];
        public int Count => _props.Count;
        public Propath Add(Propath prop) {
            if (prop.IsEmpty()) return this;
            var length = prop.Count;
            for (int i = 0; i < length; i++) {
                _props.Add(prop[i]);
            }
            return this;
        }
        public Propath AddItem(string name) {
            if (string.IsNullOrWhiteSpace(name)) return this;
            _props.Add(name);
            return this;
        }
        public override string ToString() {
            var sb = new StringBuilder();
            var length = _props.Count;
            for (int i = 0; i < length; i++) {
                sb.Append(PathSeparators.Member).Append(_props[i]);
            }
            if (sb.Length > 0) sb.Remove(0, 1);
            return sb.ToString();
        }

        public string? Peek() => _props.Count == 0 ? null : _props[0];
        public string? Pop() {
            if (_props.Count == 0) return null;
            var retVal = _props[0];
            _props.RemoveAt(0);
            return retVal;
        }
        public Propath Clone(int index = 0) {
            var length = _props.Count;
            var retval = new Propath();
            var props = retval._props;
            for (int i = index; i < length; i++) {
                props.Add(_props[i]);
            }
            return retval;
        }
        public Propath? GetParentPath(out string? name) {
            if (Count == 0) {
                name = null;
                return null;
            }
            if (Count == 1) {
                name = _props[0];
                return null;
            }

            var length = Count - 1;
            name = _props[length];
            var retval = new Propath();
            for (int i = 0; i < length; i++) {
                retval.Add(new(_props[i]));
            }
            return retval;
        }
        public void Scan(Func<string, bool> action, int from = 0, int to = -1) {
            if (to < 0 || to >= _props.Count) to = _props.Count - 1;
            for (var i = from; i <= to; i++) {
                if (!action(_props[i])) break;
            }
        }

        public static Propath CreateEmpty() => new();
        public static bool TryParse(string? text, [NotNullWhen(true)] out Propath? path) {
            if (string.IsNullOrWhiteSpace(text = text?.Trim())) return (path = null) != null;
            path = new Propath();

            var ends = $"{PathSeparators.Member}\0";
            using (var reader = text.CreateTextReader()) {
                while (true) {
                    var chr = reader.Current;
                    if (chr == PathSeparators.Member) {
                        reader.MoveNext();
                        continue;
                    }
                    if (chr == BetextReader.EofCharacter) break;
                    var name = reader.ReadUntil(endCond: ends.Contains, errCond: "\r\n".Contains, expected: PathSeparators.Member);
                    if (string.IsNullOrWhiteSpace(name)) return (path = null) != null;
                    path.Add(new Propath(name));
                }
            }
            return path.Count > 0;
        }
    }

    public class PathSeparators {
        public const char Member = '/';
        public const char Method = '#';
    }
}

