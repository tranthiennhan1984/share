﻿using Binean.Private;

namespace Binean.Foundation {
    public static partial class Comparers {
        public static readonly StringComparer IgnoreCase = new IgnoreCaseComparer();
    }
}

