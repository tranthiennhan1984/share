﻿using System.Linq.Expressions;
using System.Runtime.CompilerServices;

namespace Binean.Foundation {
    public static class Bexpression {
        private static readonly Func<string, string> _constCreator = BuildConstantCreator();
        private static Func<string, string> BuildConstantCreator() {
            ParameterExpression param = Expression.Parameter(typeof(string), "para");
            return Expression.Lambda<Func<string, string>>(param, param).Compile();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string CreateConstant(this string value)
            => _constCreator.Invoke(value);
    }
}

