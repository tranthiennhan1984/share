﻿using Binean.Foundation.Internal;

using Binean.Private;
using System.Collections.Concurrent;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace Binean.Foundation {
    [BLog]
    file static class Logs {
        public const string BFND1011E = "Cannot create instance of type '{0}'.";
    }
    public static class Generator {
        private static readonly EGetter _env = new();
        private static readonly EGetter _sys = new();
        private static readonly IEntity _global = new DEntity(_sys.GetSource());

        private static readonly Dictionary<Type, BindingDecriptor> _descriptors = [];
        private static readonly ConcurrentDictionary<Type, BindingDecriptor> _scope = new();
        private static readonly object _lock = new();

        public static IGetter Env => _env;
        public static IGetter Sys => _sys;
        public static IEntity Global => _global;

        static Generator() {
            //Bid.A();
            InitalizeContructor();
            using (var reader = Men.Serialize(Environment.GetEnvironmentVariables()).Assert()) {
                using (var writer = Men.Deserialize(_env.GetSource())) {
                    writer.Write(reader);
                }
            }
        }

        private static void Bind(BindingDecriptor descriptor) {
            lock (_lock) {
                var dict = descriptor.Lifetime == BindingLifetime.Scope ? _scope : (IDictionary<Type, BindingDecriptor>)_descriptors;
                dict[descriptor.BindingType] = descriptor;
            }
        }

        public static void Unbind(Type type) {
            lock (_lock) {
                _scope.TryRemove(type, out _);
                _descriptors.Remove(type);
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Unbind<T>()
            => Unbind(typeof(T));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Singleton(Type bindingType, Type implementationType)
            => Bind(new BindingDecriptor(bindingType, implementationType, BindingLifetime.Singleton));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Singleton(Type bindingType, Func<object>? implementationFactory)
            => Bind(new BindingDecriptor(bindingType, implementationFactory, BindingLifetime.Singleton));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Singleton(Type bindingType, object instance)
            => Bind(new BindingDecriptor(bindingType, instance));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Singleton<T>()
           => Bind(new BindingDecriptor(typeof(T), typeof(T), BindingLifetime.Singleton));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Singleton<TBind, TImpl>()
           => Bind(new BindingDecriptor(typeof(TBind), typeof(TImpl), BindingLifetime.Singleton));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Singleton<T>(Type implementationType)
            => Bind(new BindingDecriptor(typeof(T), implementationType, BindingLifetime.Singleton));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Singleton<T>(object instance)
           => Bind(new BindingDecriptor(typeof(T), instance));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Singleton<T>(Func<object>? implementationFactory)
            => Bind(new BindingDecriptor(typeof(T), implementationFactory, BindingLifetime.Singleton));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Transient(Type bindingType, Type implementationType)
            => Bind(new BindingDecriptor(bindingType, implementationType, BindingLifetime.Transient));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Transient(Type bindingType, Func<object>? implementationFactory)
            => Bind(new BindingDecriptor(bindingType, implementationFactory, BindingLifetime.Transient));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Transient<T>()
           => Bind(new BindingDecriptor(typeof(T), typeof(T), BindingLifetime.Transient));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Transient<T>(Type implementationType)
            => Bind(new BindingDecriptor(typeof(T), implementationType, BindingLifetime.Transient));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Transient<TBind, TImpl>()
           => Bind(new BindingDecriptor(typeof(TBind), typeof(TImpl), BindingLifetime.Transient));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Transient<T>(Func<object>? implementationFactory)
            => Bind(new BindingDecriptor(typeof(T), implementationFactory, BindingLifetime.Transient));

        //public static void Scope<T>(IDisposed instance) {
        //    instance.Disposed += new EventHandler((e, a) => {
        //        Unbind<T>();
        //    });
        //    Bind(new BindingDecriptor(typeof(T), instance) { Lifetime = BindingLifetime.Scope });
        //}
        public static IDisposable NewScope<T>(object instance) {
            IDisposable retVal;
            if (instance is IDisposed disposed) {
                retVal = disposed;
                disposed.Disposed += new EventHandler((e, a) => {
                    Unbind<T>();
                });
            } else retVal = CreateDisposable(Unbind<T>);
            Bind(new BindingDecriptor(typeof(T), instance) { Lifetime = BindingLifetime.Scope });
            return retVal;
        }

        public static bool TryCreateInstance(Type type, [NotNullWhen(true)] out object? value) {
            BindingDecriptor? descptor;
            lock (_lock) {
                if (!_scope.TryGetValue(type, out descptor) && !_descriptors.TryGetValue(type, out descptor)) descptor = null;
            }
            value = descptor?.GetInstance();
            return value != null;
        }

        public static bool TryCreate<T>([NotNullWhen(true)] out T? value) {
            if (!TryCreateInstance(typeof(T), out object? v)) return (value = default) != null;
            if (v.Convert<T>() is T t) return (value = t) != null;
            return (value = default) != null;
        }
        public static bool IsPrimitiveType(Type type)
        => type.IsPrimitive || type == typeof(string) || type == typeof(byte[]);
        public static bool IsObjectType(Type type)
            => !IsPrimitiveType(type) && !type.IsAbstract && !type.IsInterface;
        public static object? CreateInstance(this Type type) {
            if (TryCreateInstance(type, out object? retVal)) return retVal;
            if (!IsObjectType(type) || type == typeof(object)) return null;
            return Activator.CreateInstance(type);
        }
        public static T? CreateInstance<T>()
            => (T?)CreateInstance(typeof(T));

        [return: NotNull]
        public static T Create<T>() {
            var type = typeof(T);
            var retVal = CreateInstance(type);
            return retVal != null ? (T)retVal : throw MessageStorage.CreateException(nameof(Logs.BFND1011E), type.GetTypeName());
        }

        public static bool TryCreate(Type type, [NotNullWhen(true)] out object? value) => (value = CreateInstance(type)) != null;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IDisposable CreateDisposable(Action? disposedAction)
            => new Disposable(disposedAction);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? DefaultValue(this Type type)
            => Nullable.GetUnderlyingType(type) is null && type.IsValueType
            ? CreateInstance(type) : null;

        //public static IDisposable? CaseScope(bool insensitive = false) {
        //    var oldValue = _caseInsensitive;
        //    if (oldValue == insensitive) return null;

        //    _caseInsensitive = insensitive;
        //    return new Disposable(() => _caseInsensitive = oldValue);
        //}

        private static void InitalizeContructor() {
            var asms = AppDomain.CurrentDomain.GetAssemblies();
            if (asms != null) {
                foreach (var asm in asms) {
                    RunClassConstructor(asm);
                }
            }
            AppDomain.CurrentDomain.AssemblyLoad += OnAssemblyLoaded;
        }
        private static void OnAssemblyLoaded(object? sender, AssemblyLoadEventArgs args) {
            RunClassConstructor(args.LoadedAssembly);
        }
        private static void RunClassConstructor(Assembly asm) {
            if (asm.GetCustomAttribute<BAssemblyAttribute>() is null) return;
            foreach (var type in asm.GetTypes()) {
                if (type.GetCustomAttribute<BLogAttribute>() is not null) {
                    MessageStorage.Load(type);
                }
                //else if (type.GetCustomAttribute<BeconstructorAttribute>() is not null) {
                //    RuntimeHelpers.RunClassConstructor(type.TypeHandle);
                //}
            }
        }
        //#region :: Request Helpers ::
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static async ValueTask<T?> ProcessAsync<T>(this Request request, string address, Func<T?>? failback = null)
        //    => (await ProcessAsync(request, address)).CastAs(failback);
        //public static async ValueTask<object?> ProcessAsync(this Request request, string link) {
        //    request.SetAddress(link);
        //    var resp = await request.ProcessAsync();
        //    if (!request.Validate(ref resp)) return null;
        //    return resp.Get(Properties.Body);
        //}
        ////[MethodImpl(MethodImplOptions.AggressiveInlining)]
        ////public static async ValueTask<T?> ProcessTemplateAsync<T>(this Request request, string address, Func<T?>? failback = null)
        ////    => (await ProcessAsync(request, address.ToTemplate().Read()!)).CastAs(failback);
        ////public static async ValueTask<object?> ProcessTemplateAsync(this Request request, string address)
        ////    => await ProcessAsync(request, address.ToTemplate().Read()!);

        //#endregion
    }
    public enum BindingLifetime {
        Singleton,
        Transient,
        Scope
    }
    public interface IDisposed : IDisposable {
        event EventHandler? Disposed;
    }
}
