﻿

namespace Binean.Foundation {
    file static class Properties {
        public static readonly Bsid Message = nameof(Message);
    }
    public class Bexception(IGetter content, Exception? innerException = null) : Exception(content.QGet<string>(Properties.Message), innerException) {
        public IGetter Content { get; } = content;
    }
}
