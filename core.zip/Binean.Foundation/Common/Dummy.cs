﻿//using Binean.Foundation.Flow;

using Binean.Private;
using System.Collections;

namespace Binean.Foundation {
    public partial class Dummy {
        public static readonly IDisposable Disposable = new Disposable(null);
        public static readonly IEntity Entity = new DummyEntity();
        public static readonly IEnumerable List = Array.Empty<object?>();

        public static readonly IScript Script = new DummyScript();

        public static readonly ICell Cell = new DummyCell();
        public static readonly ILogger ErrLog = new ExceptionLogger();
        public static readonly ILogger Logger = new NullLogger();

        public static readonly Proc ErrorProc = r => r.InternalServerError();
        public static readonly Proc ReturnProc = r => r.NoContent();
        public static readonly Proc KillProc = r => r.Kill();


        public static ILogger CreateLogger() => new DummyLogger();
        public static IEntity CreateEntity() => new DummyEntity();

        private sealed class DummyEntity : IEntity, IWriteLock {
            bool IGetter.IsEmpty => true;
            public IEnumerator<IUnit> GetEnumerator() { yield break; }
            IEnumerator IEnumerable.GetEnumerator() { yield break; }

            bool IGettable.TryGetValue(Bsid bid, out object? obj)
                => (obj = null) != null;
            bool ISettable.TrySetValue(Bsid bid, object? value) => false;
            bool ISetter.Clear() => true;
            bool ISetter.TryRemoveValue(Bsid bid) => false;
            void ISetter.ChangeDisplayBid(Bsid bid) { }
            public bool Readonly(bool? readOnly = null) => true;
        }

        private sealed class DummyCell : ICell {
            public bool Process(IMessage message) {
                message.LogInfo();
                return message.NotFound();
            }
        }
        private sealed class ExceptionLogger : ILogger {
            public LogLevel MinimumLevel {
                get => LogLevel.Error;
                set { }
            }

            public IGetter? ErrorMessage { get; private set; }
            public LogLevel MaxLogLevel => LogLevel.Verbose;

            public void Log(IGetter message) {
                if (message.QGet(Properties.LogLevel, LogLevel.Information) < LogLevel.Error) return;
                ErrorMessage = message;
                throw message.CreateException();
            }
        }
        private sealed class DummyLogger : ILogger {
            public LogLevel MinimumLevel { get; set; } = LogLevel.Verbose;
            public IGetter? ErrorMessage { get; private set; }
            public LogLevel MaxLogLevel { get; private set; }
            public void Log(IGetter message) {
                var level = message.QGet(Properties.LogLevel, LogLevel.Verbose);
                if (level > MinimumLevel) MinimumLevel = level;
                if (level < MaxLogLevel) MaxLogLevel = level;
                if (level >= LogLevel.Error) ErrorMessage = message;
            }
        }
        private sealed class NullLogger : ILogger {
            public LogLevel MinimumLevel { get; set; } = LogLevel.Verbose;
            public IGetter? ErrorMessage { get; private set; }
            public LogLevel MaxLogLevel { get; private set; } = LogLevel.Verbose;
            public void Log(IGetter message) {}
        }

        private sealed class DummyScript : IScript {
            public Bsid Name => Name;
            public IEntity Functions => Entity;
        }
    }
    file static class Properties {
        public static readonly Bsid LogLevel = nameof(LogLevel);
    }
}
