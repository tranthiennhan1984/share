﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class Biq : INameList<CodeId> {
        private readonly Finder _finder;
        private readonly List<CodeId> _bics = [];
        private int _valueType;
        private Action<int, CodeId> _insertHandler = default!;
        public Biq(ListType listType) {
            ListType = listType;
            _finder = ListType.HasFlag(ListType.Ordered) ? InBinaryFinder : InFinder;
            _valueType = ListType.HasFlag(ListType.Constant) ? 1 : 2;
            InUpdateInsertHandler();
        }
        public CodeId this[int index] => _bics[index];

        public ListType ListType { get; }

        public int Count => _bics.Count;

        public int Add(CodeId bic) {
            if (bic.IsNothing) return -1;
            if (_finder(bic, out int index)) return index;
            index = ~index;
            _insertHandler(index, bic);
            return index;
        }
        public bool Find(CodeId bic, out int index)
            => bic.IsNothing ? (index = -1) > 0 : _finder(bic, out index);
        public void RemoveAt(int index) => _bics.RemoveAt(index);
        public void Clear() => _bics.Clear();

        private void InUpdateInsertHandler() {
            if (_valueType > 1) _insertHandler = InInsert;
            else _insertHandler = InInsertError;
        }
        private void InInsert(int index, CodeId bic) => _bics.Insert(index, bic);
        private void InInsertError(int index, CodeId bic) => throw new InvalidOperationException();

        private delegate bool Finder(CodeId bic, out int index);
        private bool InBinaryFinder(CodeId bic, out int index) {
            var length = _bics.Count;
            if (length == 0) return (index = ~length) > -1;
            return _bics.BinarySearch(length, (set, index) => set[index], n => n.CompareTo(bic), out index);
        }
        private bool InFinder(CodeId bic, out int index) {
            var length = _bics.Count;
            if (length == 0) return (index = ~length) > -1;
            for (int i = 0; i < length; i++) {
                if (_bics[i].CompareTo(bic) == 0) return (index = i) > -1;
            }
            return (index = ~length) > -1;
        }

        public bool Readonly(bool? readOnly = null) {
            if (readOnly is null
                || (readOnly.Value && _valueType < 0)
                || (!readOnly.Value && _valueType > 0)) {
                return _valueType < 0;
            }
            _valueType = -_valueType;
            InUpdateInsertHandler();
            return _valueType < 0;
        }
        public bool Readonly(CodeId name, bool? readOnly = null) {
            if (readOnly is null) return _valueType < 0;
            if (!Find(name, out int index) || _bics[index] is not CodeId bic) return false;
            if (readOnly != null) bic.IsReadonly = readOnly.Value;
            return bic.IsReadonly;
        }

        public IEnumerator<CodeId> GetEnumerator() => _bics.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_bics).GetEnumerator();
    }
}