﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class Bib : INameList {
        private readonly Finder _finder;
        private readonly List<Bsid> _bids = [];
        private int _valueType;
        private Action<int, Bsid> _insertHandler = default!;

        public Bib(ListType listType) {
            ListType = listType;
            _finder = ListType.HasFlag(ListType.Ordered) ? InBinaryFinder : InFinder;
            _valueType = ListType.HasFlag(ListType.Constant) ? 1 : 2;
            InUpdateInsertHandler();
        }

        public int Count => _bids.Count;
        public Bsid this[int index] => _bids[index];
        public ListType ListType { get; }

        public int Add(Bsid bid) {
            if (bid.IsNothing) return -1;
            if (_finder(bid, out int index)) return index;
            index = ~index;
            _insertHandler(index, bid);
            return index;
        }
        public bool Find(Bsid bid, out int index)
            => bid.IsNothing ? (index = -1) > 0 : _finder(bid, out index);
        public void RemoveAt(int index) => _bids.RemoveAt(index);
        public void Clear() => _bids.Clear();

        public bool Readonly(bool? readOnly = null) {
            if (readOnly is null
                || (readOnly.Value && _valueType < 0)
                || (!readOnly.Value && _valueType > 0)) {
                return _valueType < 0;
            }
            _valueType = -_valueType;
            InUpdateInsertHandler();
            return _valueType < 0;
        }
        public bool Readonly(Bsid name, bool? readOnly = null) {
            if (readOnly is null) return _valueType < 0;
            if (!Find(name, out int index) || _bids[index] is not Bsid bid) return false;
            if (readOnly != null) bid.IsReadonly = readOnly.Value;
            return bid.IsReadonly;
        }

        private void InUpdateInsertHandler() {
            if (_valueType == 1) _insertHandler = InInsertSingleton;
            else if (_valueType == 2) _insertHandler = InInsert;
            else _insertHandler = InInsertError;
        }
        private void InInsert(int index, Bsid bid) => _bids.Insert(index, bid);
        private void InInsertError(int index, Bsid bid) => throw new InvalidOperationException();
        private void InInsertSingleton(int index, Bsid bid) => _bids.Insert(index, bid.Constant());

        public IEnumerator<Bsid> GetEnumerator() => _bids.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_bids).GetEnumerator();

        private delegate bool Finder(Bsid bid, out int index);
        private bool InBinaryFinder(Bsid bid, out int index) {
            var length = _bids.Count;
            if (length == 0) return (index = ~length) > -1;
            return _bids.BinarySearch(length, (set, index) => set[index], n => n.CompareTo(bid), out index);
        }
        private bool InFinder(Bsid bid, out int index) {
            var length = _bids.Count;
            if (length == 0) return (index = ~length) > -1;
            for (int i = 0; i < length; i++) {
                if (_bids[i].CompareTo(bid) == 0) return (index = i) > -1;
            }
            return (index = ~length) > -1;
        }

    }
}
