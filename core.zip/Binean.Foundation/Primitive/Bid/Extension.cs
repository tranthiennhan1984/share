﻿using Binean.Foundation.Storage;
using System;
using System.Buffers.Text;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Unicode;

namespace Binean.Foundation.Primitive {
    public static partial class Extension {

        #region :: Bidten Helpers ::
        internal static byte[] _codeIdEncodingMap = "_0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-"u8.ToArray();
        internal static sbyte[] _codeIdDencodingMap = _codeIdEncodingMap.BuildBidDencodingMap();
        public static sbyte[] BuildBidDencodingMap(this byte[] encodingMap) {
            var retVal = new sbyte[sbyte.MaxValue];
            var length = retVal.Length;
            for (int i = 0; i < length; i++) {
                retVal[i] = -1;
            }
            length = encodingMap.Length;
            int code;
            for (sbyte i = 0; i < length; i++) {
                code = encodingMap[i];
                retVal[code] = i;
            }
            return retVal;
        }

        public static string ToString(this CodeId bidten, bool writeAll = false) {
            var content = bidten._content[0];
            var buffer = new char[writeAll ? 12 : 10];
            var bufIndex = -1;
            if (writeAll && content < 0) buffer[++bufIndex] = ':';
            for (int bitOff = 57; bitOff > 0; bitOff -= 6) {
                buffer[++bufIndex] = CodeId.ToChar((byte)((content >> bitOff) & 63));
            }
            if (writeAll) buffer[++bufIndex] = CodeId.ToChar((byte)(content & 7));
            return new string(buffer, 0, bufIndex + 1);
        }
        public static CodeId ToBidten(this string txt, bool readAll) {
            var startIndex = 0;
            if (txt[0] == ':') startIndex = 1;

            var content = ToBidten(txt, startIndex);
            if (startIndex > 0) content = -content;

            if (!readAll) return new CodeId(content);

            startIndex += 10;
            if (txt.Length > startIndex) {
                long code = _codeIdDencodingMap[txt[startIndex]];
                content |= (code > 7 ? 7 : code);
            }

            return new CodeId(content);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static CodeId ToBidten(this string txt) => new(ToBidten(txt, 0));
        public static long ToBidten(string txt, int startIndex) {
            var dencodingMap = _codeIdDencodingMap;
            var content = 0L;
            var sLen = txt.Length;
            var bitOffset = 57;
            for (; startIndex < sLen && bitOffset > 0; startIndex++, bitOffset -= 6) {
                long chr = dencodingMap[txt[startIndex]];
                content |= chr << bitOffset;
            }
            return new CodeId(content);
        }

        ////public unsafe static string ToString1(this CodeId bidten, bool writeAll = false) {
        ////    var retVal = new sbyte[12];
        ////    var index = -1;

        ////    fixed (byte* srcBytes = &MemoryMarshal.GetReference(bidten.AsBytes())) {
        ////        fixed (sbyte* destBytes = &retVal[0]) {
        ////            srcMax -= 2;
        ////            while (src < srcMax) {
        ////                result = Encode(src, ref encodingMap);
        ////                Unsafe.WriteUnaligned(dest, result);
        ////                src += 3;
        ////                dest += 4;
        ////            }
        ////            return new string(destBytes, 0, index + 1);
        ////        }
        ////    }

        ////}
        //public unsafe static string ToString1(this CodeId bidten) {
        //    var retVal = new sbyte[12];
        //    fixed (byte* srcBytes = &MemoryMarshal.GetReference(bidten.AsBytes())) {
        //        fixed (sbyte* destBytes = &retVal[0]) {
        //            ref byte encodingMap = ref MemoryMarshal.GetReference(CodeId._encodingMap);
        //            CodeIdEncoding(srcBytes, destBytes, ref encodingMap);
        //            return new string(destBytes, 0, 10);
        //        }
        //    }

        //}
        //private unsafe static void CodeIdEncoding(byte* srcBytes, sbyte* destBytes, ref byte encodingMap) {
        //    static uint Encode(int* src, ref byte encodingMap) {
        //        uint i0 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 28) & 0x3F));
        //        uint i1 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 20) & 0x3F));
        //        uint i2 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 14) & 0x3F));
        //        uint i3 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 8) & 0x3F));

        //        if (BitConverter.IsLittleEndian) {
        //            return i0 | (i1 << 8) | (i2 << 16) | (i3 << 24);
        //        } else {
        //            return (i0 << 24) | (i1 << 16) | (i2 << 8) | i3;
        //        }
        //    }

        //    static uint LastEncode(int* src, ref byte encodingMap) {
        //        uint i0 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 10) & 0x3F));
        //        uint i1 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 4) & 0x3F));

        //        if (BitConverter.IsLittleEndian) {
        //            return i0 | (i1 << 8);
        //        } else {
        //            return (i0 << 24) | (i1 << 16);
        //        }
        //    }

        //    byte* src = srcBytes;
        //    sbyte* dest = destBytes;
        //    for (int i = 0; i < 8; i += 3) {
        //        Unsafe.WriteUnaligned(dest, Encode((int*)src, ref encodingMap));
        //        src += 3;
        //        dest += 4;
        //    }
        //    Unsafe.WriteUnaligned(dest, LastEncode((int*)(src - 2), ref encodingMap));
        //}
        //private unsafe static void CodeIdDecoding(sbyte* srcBytes, byte* destBytes, ref byte encodingMap) {
        //    static uint Encode(int* src, ref byte encodingMap) {
        //        uint i0 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 28) & 0x3F));
        //        uint i1 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 20) & 0x3F));
        //        uint i2 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 14) & 0x3F));
        //        uint i3 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 8) & 0x3F));

        //        if (BitConverter.IsLittleEndian) {
        //            return i0 | (i1 << 8) | (i2 << 16) | (i3 << 24);
        //        } else {
        //            return (i0 << 24) | (i1 << 16) | (i2 << 8) | i3;
        //        }
        //    }

        //    static uint LastEncode(int* src, ref byte encodingMap) {
        //        uint i0 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 10) & 0x3F));
        //        uint i1 = Unsafe.Add(ref encodingMap, (IntPtr)((*src >> 4) & 0x3F));

        //        if (BitConverter.IsLittleEndian) {
        //            return i0 | (i1 << 8);
        //        } else {
        //            return (i0 << 24) | (i1 << 16);
        //        }
        //    }

        //    byte* src = srcBytes;
        //    sbyte* dest = destBytes;
        //    for (int i = 0; i < 8; i += 3) {
        //        Unsafe.WriteUnaligned(dest, Encode((int*)src, ref encodingMap));
        //        src += 3;
        //        dest += 4;
        //    }
        //    Unsafe.WriteUnaligned(dest, LastEncode((int*)(src - 2), ref encodingMap));
        //}
        #endregion


        #region :: Buid Helpers ::
        public static string ToString(this Bsid buid, bool writeAll = false) {
            var contents = buid._content;
            var conLen = contents.Length;

            var buffer = new char[conLen * Bsid.CharPerUnit + 1];
            var bufIndex = -1;
            if (writeAll && contents[0] < 0) buffer[++bufIndex] = ':';

            for (var conIndex = 0; conIndex < conLen; conIndex++) {
                var content = contents[conIndex];
                if (content == 0) break;
                var capital = (int)(content & Bsid.CaseMark);
                for (int bitOfft = 57, capOff = 8; bitOfft > Bsid.CharPerUnit; bitOfft -= 6, capOff--) {
                    var c = (byte)((content >> bitOfft) & 63);
                    if (c == Bid.EndCode) {
                        conIndex = conLen;
                        break;
                    }
                    var isUpper = ((capital >> capOff) & 1) == 1;
                    buffer[++bufIndex] = Bsid.ToChar(c, isUpper);
                }
            }
            return new string(buffer, 0, bufIndex + 1);
        }
        //public static Bsid ToBuid(this string txt, bool readAll = false) {
        //    var content = 0L;

        //    var sLen = txt.Length;
        //    var sOff = 0;
        //    var isLocked = false;
        //    if (txt[sOff] == ':') {
        //        isLocked = true;
        //        ++sOff;
        //    }

        //    var bitOffset = 57;
        //    for (; sOff < sLen && bitOffset > 0; sOff++, bitOffset -= 6) {
        //        content |= bidten.ToCode(txt[sOff]) << bitOffset;
        //    }

        //    if (readAll && sOff < sLen) content |= Math.Min(7, bidten.ToCode(txt[sOff]));

        //    if (isLocked) content = -content;
        //    return new bidten(content);
        //}
        #endregion



        public static string ReadAll(this IInput<char> reader, int capacity = 16) {
            var sb = new StringBuilder(capacity);
            char chr;
            while ((chr = reader.Current) != Bid.EOF) {
                sb.Append(chr);
                reader.MoveNext();
            }
            return sb.ToString();
        }
        public static T WriteAll<T>(this T writer, string? text) where T : IOutput<char> {
            if (string.IsNullOrEmpty(text)) return writer;
            var length = text.Length;
            for (int i = 0; i < length; i++) {
                if (!writer.Write(text[i])) throw MessageStorage.CreateException(nameof(Logs.BFND20203E));
            }
            return writer;
        }
        public static T WriteAll<T>(this T writer, IInput<char> reader) where T : IOutput<char> {
            char chr;
            while ((chr = reader.Current) != Bid.EOF) {
                if (!writer.Write(chr)) throw MessageStorage.CreateException(nameof(Logs.BFND20203E));
                reader.MoveNext();
            }
            return writer;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrDummy([NotNullWhen(false)] this Bsid? bid) => bid is null || bid.IsNothing;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static List<string> GetWords(this Bsid bid, bool ignorePunctuator = false)
            => bid.CreateReader().GetWords(ignorePunctuator);
        public static List<string> GetWords(this IInput<char> reader, bool ignorePunctuator = true) {
            var retVal = new List<string>();
            var builder = new StringBuilder();

            static void ReadWord(IInput<char> reader, List<string> list, StringBuilder builder) {
                static bool func(char c) => char.IsLetterOrDigit(c) && !char.IsUpper(c);
                char chr;
                while (((chr = reader.Current) != Bid.EOF) && func(chr)) {
                    builder.Append(reader.Current);
                    reader.MoveNext();
                }
                if (builder.Length > 0) {
                    list.Add(builder.ToString());
                    builder.Clear();
                }
            }
            static void ReadUpper(IInput<char> reader, List<string> list, StringBuilder builder) {
                static bool func(char c) => char.IsDigit(c) || char.IsUpper(c);
                char chr;
                while (((chr = reader.Current) != Bid.EOF) && func(chr)) {
                    _ = builder.Append(char.ToLower(reader.Current));
                    reader.MoveNext();
                }
                if (builder.Length <= 0) return;

                var len = func(reader.Current) ? builder.Length - 1 : builder.Length;
                if (len == 0) return;
                list.Add(builder.ToString(0, len));
                builder.Remove(0, len);
            }
            static void ReadPunctualtor(IInput<char> reader, List<string> list, StringBuilder builder, bool ignorePunctuator) {
                static bool func(char c) => !char.IsLetterOrDigit(c);

                System.Diagnostics.Debug.Assert(builder.Length == 0);
                char chr;
                while (((chr = reader.Current) != Bid.EOF) && func(chr)) {
                    builder.Append(reader.Current);
                    reader.MoveNext();
                }
                if (builder.Length > 0) {
                    if (!ignorePunctuator) list.Add(builder.ToString());
                    builder.Clear();
                }
            }

            char chr;
            while ((chr = reader.Current) != Bid.EOF) {
                if (!char.IsLetterOrDigit(chr)) ReadPunctualtor(reader, retVal, builder, ignorePunctuator);
                else if (char.IsUpper(chr)) ReadUpper(reader, retVal, builder);
                else ReadWord(reader, retVal, builder);
            }
            return retVal;
        }
        public static string ToName(this List<string> words, NameCase nameCase = NameCase.PascalCase) {
            if (words.Count == 0) return string.Empty;

            if (nameCase == NameCase.NotSet) nameCase = NameCase.PascalCase;

            var first = nameCase switch {
                NameCase.PascalCase or NameCase.SNAKE_CASE or NameCase.KEBAB_CASE => new Func<char, string>(chr => char.ToString(char.ToUpper(chr))),
                _ => new Func<char, string>(chr => chr.ToString())
            };

            var body = nameCase switch {
                NameCase.KEBAB_CASE or NameCase.SNAKE_CASE => new Func<string, string>(s => s.ToUpper()),
                _ => new Func<string, string>(s => s),
            };

            var builder = new StringBuilder();
            var length = words.Count;
            var name = words[0];
            builder.Append(first(name[0])).Append(body(name[1..]));
            if (length == 1) return builder.ToString();

            first = nameCase switch {
                NameCase.PascalCase => new Func<char, string>(chr => char.ToString(char.ToUpper(chr))),
                NameCase.SNAKE_CASE => new Func<char, string>(chr => $"_{char.ToUpper(chr)}"),
                NameCase.KEBAB_CASE => new Func<char, string>(chr => $"-{char.ToUpper(chr)}"),
                NameCase.camelCase => new Func<char, string>(chr => char.ToString(char.ToLower(chr))),
                NameCase.snake_case => new Func<char, string>(chr => $"_{char.ToLower(chr)}"),
                NameCase.kebab_case => new Func<char, string>(chr => $"-{char.ToLower(chr)}"),
                _ => throw new InvalidOperationException(),
            };

            for (int i = 1; i < length; i++) {
                name = words[i];
                builder.Append(first(name[0])).Append(body(name[1..]));
            }

            return builder.ToString();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bsid ToCase(this Bsid bid, NameCase to) => (Bsid)bid.GetWords().ToName(to);
    }
}