﻿using Binean.Foundation.Storage;
using System.Diagnostics;

namespace Binean.Foundation.Primitive {
    /// <summary>
    /// Binean string identifier
    /// </summary>
    public sealed class Bsid(long[] content) : Bid(content) {
        public new static readonly Bsid Nothing = new([0L]);

        public const int CharPerUnit = 9;
        public const long CaseMark = 511;
        public const long IgnoreCaseMark = 9223372036854775296;
        private const string Punctuator = "-_.@ ,:=&$#^~*+!()[]<>%'/?";//"{}\\|`;"

        public Bsid(Bid bid) : this(bid._content) { }
        public override string ToString() => (string)this;

        //public int TryCompareTo(Bid? other) {
        //    if (other is null) return 1;
        //    if (ReferenceEquals(this, other)) return 0;

        //    var comp = new Comparison<long>((a, b) => (a & IgnoreCaseMark).CompareTo(b & IgnoreCaseMark));

        //    var ocontent = other._content;

        //    var r = comp(_content[0], ocontent[0]);
        //    if (r != 0) return r;

        //    var rLen = _content.Length.CompareTo(ocontent.Length);
        //    var len = rLen < 0 ? _content.Length : ocontent.Length;

        //    for (var i = 1; i < len; i++) {
        //        if ((r = _content[i].CompareTo(ocontent[i])) != 0) return r;
        //    }

        //    return rLen;
        //}



        //public int CompareTo(Bid? other) {
        //    if (other is null) return 1;
        //    if (ReferenceEquals(this, other)) return 0;
        //    return InCompare(other, false);
        //}
        //public bool Equals(Bid? other) {
        //    if (other is null) return false;
        //    if (ReferenceEquals(this, other)) return true;
        //    return InCompare(other, false) == 0;
        //}
        //public override bool Equals(object? obj) {
        //    if (obj is null) return false;
        //    if (ReferenceEquals(this, obj)) return true;
        //    var bid = obj.ToBid(() => throw this.CreateException(nameof(Logs.BFND2033E), obj));
        //    return InCompare(bid, false) == 0;
        //}
        //public override int GetHashCode() => _content[0].GetHashCode();

        //public int TryCompareTo(Bid? other) {
        //    if (other is null) return 1;
        //    if (ReferenceEquals(this, other)) return 0;
        //    return InCompare(other, true);
        //}

        //private int InCompare(Bid other, bool ignoreCase = false) {
        //    var obics = other._content;
        //    var len = Math.Min(_content.Length, obics.Length);
        //    for (var i = 0; i < len; i++) {
        //        var r = _content[i].BicCompare(obics[i], ignoreCase);
        //        if (r != 0) return r;
        //    }
        //    return _content.Length.CompareTo(obics.Length);
        //}
        public IInput<char> CreateReader() => new BidReader(_content);

        public Bsid Clone() {
            var len = _content.Length;
            var bics = new long[len];
            Array.Copy(_content, bics, len);
            return new Bsid(bics);
        }

        //public void SetReadonly(bool readOnly) {
        //    var bic = _content[0];
        //    if (bic == 0) return;
        //    if (readOnly) {
        //        if (bic > 0) _content[0] = -bic;
        //    } else if (bic < 0) _content[0] = -bic;
        //}
        //public int GetTextLength() {
        //    if (IsNothing) return 0;
        //    return (_content.Length - 1) * BicHelper.CharPerCode + _content[^1].GetLastIndex() + 1;
        //}
        //public string ToString(int startIndex = 0, int length = -1)
        //    => _content.ToString(startIndex < 0 ? 0 : startIndex, length);
        //public bool StarWith(string name, bool ignoreCase = false) {
        //    if (name.Length == 0) return true;
        //    if (name.Length > GetTextLength()) return false;
        //    return string.Compare(name, _content.ToString(0, name.Length), ignoreCase) == 0;
        //}
        //public bool EndWith(string name, bool ignoreCase = false) {
        //    if (name.Length == 0) return true;
        //    var len = GetTextLength();
        //    var nLen = name.Length;
        //    if (nLen > len) return false;
        //    return string.Compare(name, _content.ToString(len - nLen, nLen), ignoreCase) == 0;
        //}

        //public static bool operator ==(Bid? left, Bid? right) => left is null ? right is null : left.Equals(right);
        //public static bool operator !=(Bid? left, Bid? right) => !(left == right);
        //public static bool operator <(Bid? left, Bid? right) => left != null ? left.CompareTo(right) < 0 : right is null;
        //public static bool operator <=(Bid? left, Bid? right) => left is null || left.CompareTo(right) <= 0;
        //public static bool operator >(Bid? left, Bid? right) => left != null && left.CompareTo(right) > 0;
        //public static bool operator >=(Bid? left, Bid? right) => left is null ? right is null : left.CompareTo(right) >= 0;

        //public static explicit operator Bid(long value) => new([value]);
        //public static explicit operator long(Bid bid) => bid._content[0];

        //public static implicit operator Bid(string? name) => name.TryParse(out Bid bid, true) ? bid : Nothing;
        //public static implicit operator string(Bid bid) => bid._content.ToString(0, -1);

        public static implicit operator Bsid(string? name) => string.IsNullOrEmpty(name) ? new Bsid([0L]) : new BidWriter((name.Length / CharPerUnit) + 1).WriteAll(name).ToBid();
        public static implicit operator string(Bsid bsid) => new BidReader(bsid._content).ReadAll(bsid._content.Length * CharPerUnit);

        /// <summary>
        ///     0: EOF
        ///  1-10: '0' - '9'
        /// 11-37: 'A' - 'Z' isLower: 'a' - 'z'
        /// 38-63: -_.@ ,:=&$#^~*+!()[]<>%'/?
        /// </summary>
        public static char ToChar(byte code, bool isLower) {
            if (code == 0) return EOF;
            if (code < 11) return (char)(code + 47);
            if (code < 38) return (char)(isLower ? code + 86 : code + 54);
            var index = code - 38;
            return Punctuator[index];
        }
        public static long ToCode(char chr, out bool isLower) {
            if (chr >= 97 && chr < 123) {
                isLower = true;
                return chr - 86L;
            }
            isLower = false;
            if (chr >= 48 && chr < 58) return chr - 47L;
            if (chr >= 65 && chr < 91) return chr - 54L;
            if (chr == EOF) return EndCode;

            var index = Punctuator.IndexOf(chr);
            if (index >= 0) return index + 38;

            throw MessageStorage.CreateException(nameof(Logs.BFND20301E), nameof(Bsid), chr);
        }
    }

    file class BidReader : IInput<char> {
        private readonly long[] _content;
        private int _contentIndex = -1;

        private long _code;
        private int _codeOff = Bsid.CharPerUnit;

        private int _capital;
        private int _captialOff;

        private int _position = -1;
        public BidReader(long[] content) {
            _content = content;
            if (_content[0] == 0) {
                _contentIndex = _content.Length;
                Current = Bid.EOF;
                IsEnd = true;
            } else MoveNext();
        }

        object IInput<char>.Position => _position;

        public char Current { get; private set; } = Bid.EOF;
        public bool IsEnd { get; private set; }

        public void MoveNext() {
            if (IsEnd) return;
            if (InMoveNext()) ++_position;
            else IsEnd = true;
        }
        private bool InMoveNext() {
            if (_codeOff <= Bsid.CharPerUnit) {
                if (++_contentIndex >= _content.Length) {
                    Current = Bid.EOF;
                    IsEnd = true;
                    return false;
                }
                _code = _content[_contentIndex];
                _capital = (int)(_code & Bsid.CaseMark);
                _codeOff = 57;
                _captialOff = 8;
            } else {
                _codeOff -= 6;
                _captialOff--;
            }

            var c = (byte)((_code >> _codeOff) & 63);
            if (c == Bid.EndCode) {
                _contentIndex = _content.Length;
                Current = Bid.EOF;
                IsEnd = true;
                return false;
            }
            var isUpper = ((_capital >> _captialOff) & 1) == 1;
            Current = Bsid.ToChar(c, isUpper);
            return true;
        }
    }

    file sealed class BidWriter : IOutput<char> {
        private readonly long[] _content;
        private int _contentIndex = -1;

        private int _codeOff = Bsid.CharPerUnit;
        private int _captialOff;

        private int _position = -1;

        public BidWriter(int capacity) {
            _content = new long[capacity];
        }
        object IOutput<char>.Position => _position;
        public bool IsEnd { get; private set; }
        public bool Write(char chr) {
            if (IsEnd) return false;
            if (InWrite(chr)) {
                ++_position;
                return true;
            }
            IsEnd = true;
            return false;
        }
        private unsafe bool InWrite(char chr) {
            if (_codeOff <= Bsid.CharPerUnit) {
                if (++_contentIndex >= _content.Length) {
                    IsEnd = true;
                    return false;
                }
                fixed (long* _code = &_content[_contentIndex]) {
                    *_code = 0L;
                }
                _codeOff = 57;
                _captialOff = 8;
            } else {
                _codeOff -= 6;
                _captialOff--;
            }

            var c = Bsid.ToCode(chr, out bool isLower);
            if (c == Bid.EndCode) {
                _contentIndex = _content.Length;
                IsEnd = true;
                return false;
            }

            fixed (long* _code = &_content[_contentIndex]) {
                *_code |= c << _codeOff;
                if (isLower) *_code |= 1L << _captialOff;
            }

            return true;
        }

        public Bsid ToBid() {
            var len = _content.Length;
            for (; len > 1; len--) {
                if (_content[len - 1] != 0) break;
            }
            return new Bsid(_content[..len]);
        }
    }

    //file static partial class BicHelper {
    //    public const long DefaultMark = 9223372036854775807;
    //    public const long IgnoreCaseMark = 9223372036854775296;
    //    public const long CaseMark = 511;

    //    public const int CharPerUnit = 9;
    //    private const string Punctuator = "-_.@ ,:=&$#^~*+!()[]<>%'/";//"{}\\|`?;"

    //    //public static int BicCompare(this long a, long b, bool ignoreCase = false) {
    //    //    if (a == b) return 0;
    //    //    if (a == 0) return -1;
    //    //    if (b == 0) return 1;
    //    //    var mark = ignoreCase ? IgnoreCaseMark : DefaultMark;
    //    //    a &= mark;
    //    //    b &= mark;
    //    //    return a < b ? -1 : 1;
    //    //}
    //    //public static char ToChar(this byte code, bool isUpper) {
    //    //    if (code == 0) return Bid.EOF;
    //    //    if (code == Bid.InvalidCode) return Bid.InvalidCharacter;
    //    //    if (code < 11) return (char)(code + 47);
    //    //    if (code < 38) return (char)(isUpper ? code + 54 : code + 86);
    //    //    var index = code - 38;
    //    //    return Punctuator[index];
    //    //}
    //    //private static bool TryGetCode(this char chr, out long code, out bool isUpper, bool allowInvalid) {
    //    //    var validCode = allowInvalid ? Bid.InvalidCode : (long)0;
    //    //    if (chr >= 65 && chr < 91) {
    //    //        isUpper = true;
    //    //        return (code = chr - 54L) > -1;
    //    //    }
    //    //    isUpper = false;
    //    //    if (chr < 32 || chr > 126) return (code = Bid.InvalidCode) == validCode;
    //    //    if (chr >= 48 && chr < 58) return (code = chr - 47L) > -1;
    //    //    if (chr >= 97 && chr < 123) return (code = chr - 86L) > -1;

    //    //    var index = Punctuator.IndexOf(chr);
    //    //    if (index >= 0) return (code = index + 38) > -1;

    //    //    Debug.WriteLine($"Invalid Bid character: {chr}");
    //    //    if (chr == Bid.EOF) return (code = 0L) > -1;

    //    //    return (code = Bid.InvalidCode) == validCode;
    //    //}
    //    //public static int GetLastIndex(this long bic) {
    //    //    for (int i = CharPerUnit - 1, offset = CharPerUnit; i > 0; i--, offset += 6) {
    //    //        if ((byte)((bic >> offset) & 63) != 0) return i + 1;
    //    //    }
    //    //    return 0;
    //    //}

    //    //public static bool ToBic(this ReadOnlySpan<char> name, ref int index, out long bic, bool? allowInvalid = false) {
    //    //    bic = 0L;
    //    //    var aInvalid = allowInvalid != null && allowInvalid.Value;
    //    //    var end = name.Length;
    //    //    for (int i = CharPerUnit - 1, offset = 57; i >= 0 && index < end; i--, offset -= 6, index++) {
    //    //        var chr = name[index];
    //    //        if (chr == Bid.EOF) return true;
    //    //        if (!TryGetCode(chr, out long code, out bool isUpper, aInvalid)) {
    //    //            if (allowInvalid is null) return false;
    //    //            if (allowInvalid.Value) throw MessageStorage.CreateException(nameof(Logs.BFND20301E), chr);
    //    //        }
    //    //        bic |= code << offset;
    //    //        if (isUpper) bic |= 1L << i;
    //    //    }
    //    //    return true;
    //    //}
    //    //public static bool TryParse(this string? name, out Bid bid, bool? allowInvalid = null) {
    //    //    if (TryParseBics(name, out long[] bics, allowInvalid)) {
    //    //        bid = new Bid(bics);
    //    //        return true;
    //    //    }
    //    //    bid = Bid.Nothing;
    //    //    return false;
    //    //}
    //    //public static bool TryParseBics(this string? name, out long[] bics, bool? allowInvalid = null) {
    //    //    if (string.IsNullOrWhiteSpace(name)) {
    //    //        bics = [0L];
    //    //        return allowInvalid.GetValueOrDefault();
    //    //    }

    //    //    var length = name.Length;
    //    //    var len = length / CharPerUnit;
    //    //    if (len * CharPerUnit < length) len++;

    //    //    var span = name.AsSpan();
    //    //    var buff = new long[len];
    //    //    var boff = -1;
    //    //    var index = 0;
    //    //    while (index < length) {
    //    //        if (name[index] == Bid.EOF) break;
    //    //        if (!ToBic(span, ref index, out long bic, allowInvalid)) {
    //    //            bics = [0L];
    //    //            return false;
    //    //        }
    //    //        buff[++boff] = bic;
    //    //    }
    //    //    bics = buff.ToArray(0, boff + 1);
    //    //    return true;
    //    //}

    //    //public static unsafe string ToString(this long[] _bics, int startIndex, int length) {
    //    //    if (length == 0) return string.Empty;
    //    //    if (length < 0) length = CharPerUnit * _bics.Length - startIndex;
    //    //    if (length <= 0) return string.Empty;
    //    //    var span = stackalloc char[length];
    //    //    var index = 0;
    //    //    var reader = new BidReader(_bics, true);
    //    //    if (startIndex > 1 && !reader.Skip(startIndex - 1)) return string.Empty;
    //    //    while (reader.MoveNext()) {
    //    //        span[index] = reader.Current;
    //    //        if (++index >= length) break;
    //    //    }
    //    //    return new string(span, 0, index);
    //    //}

    //    //public static long GetCode(this long bic, int index) {
    //    //    if (index < 0 || index >= CharPerUnit) return 0;
    //    //    var offset = 6 * (CharPerUnit - 1 - index) + CharPerUnit;
    //    //    return (byte)(bic >> offset) & 63;
    //    //}
    //    //public static long SetCode(this long bic, int index, long code) {
    //    //    if (index < 0 || index >= CharPerUnit) return bic;
    //    //    var offset = 6 * (CharPerUnit - 1 - index) + CharPerUnit;
    //    //    var clr = ~(63L << offset);
    //    //    bic &= clr;
    //    //    return bic |= code << offset;
    //    //}
    //}

}