﻿using Binean.Foundation.Storage;
using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Binean.Foundation.Primitive {
    ///<summary>
    /// Binean identifier
    /// </summary>
    public class Bid : IComparable<Bid>, IEquatable<Bid> {
        public const char EOF = '\0';
        public const byte EndCode = 0;

        public static readonly Bid Nothing = new();

        internal protected long[] _content;

        protected Bid() {
            _content = [0L];
        }
        public Bid(long[] content) {
            if (content.Length == 0) _content = [0L];
            else _content = content;
        }
        public Bid(ReadOnlySpan<byte> data) : this(OnBidContent(data)) { }

        public int Length => _content.Length;
        public bool IsNothing => _content[0] == 0;
        public virtual bool IsReadonly {
            get => false;
            set { }
        }

        public override int GetHashCode() => _content[0].GetHashCode();
        public override bool Equals(object? obj) {
            if (ReferenceEquals(this, obj)) return true;
            if (obj is null) return false;

            if (obj is not Bid other) throw this.CreateException(nameof(Logs.BFND20311E), obj);
            return OnCompare(other._content) == 0;
        }
        public int CompareTo(Bid? other) {
            if (ReferenceEquals(this, other)) return 0;
            if (other is null) return 1;
            return OnCompare(other._content);
        }
        public bool Equals(Bid? other) {
            if (ReferenceEquals(this, other)) return true;
            if (other is null) return false;
            return OnCompare(other._content) == 0;
        }
        protected virtual int OnCompare(long[] ocontent) {
            var rLen = _content.Length.CompareTo(ocontent.Length);
            var len = rLen < 0 ? _content.Length : ocontent.Length;

            for (int r, i = 0; i < len; i++) {
                if ((r = _content[i].CompareTo(ocontent[i])) != 0) return r;
            }

            return rLen;
        }

        internal protected Span<byte> AsBytes() => MemoryMarshal.Cast<long, byte>(_content);

        public static bool operator ==(Bid? left, Bid? right)
            => left is null ? right is null : left.CompareTo(right) == 0;
        public static bool operator !=(Bid? left, Bid? right) => !(left == right);
        public static bool operator <(Bid? left, Bid? right)
            => left is null ? right is not null : left.CompareTo(right) < 0;
        public static bool operator <=(Bid? left, Bid? right)
            => left is null || left.CompareTo(right) <= 0;
        public static bool operator >(Bid? left, Bid? right)
            => left is not null && left.CompareTo(right) > 0;
        public static bool operator >=(Bid left, Bid right)
            => left is null ? right is null : left.CompareTo(right) >= 0;

        public static implicit operator Bid(Guid guid) => new(guid.ToByteArray());

        protected static long[] OnBidContent(ReadOnlySpan<byte> data) {
            var len = data.Length / 8;
            if (len * 8 != data.Length) len++;
            var contents = new long[len];
            data.CopyTo(MemoryMarshal.Cast<long, byte>(contents));
            return contents;
        }
    }
}