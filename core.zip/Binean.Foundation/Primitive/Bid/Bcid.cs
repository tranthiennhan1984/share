﻿using Binean.Private;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Primitive {
    /// <summary>
    /// Binean unique identifier
    /// </summary>
    public sealed class Biid(long content) : Bid([content]) {
        public const int MaxLength = 10;
        private const string Punctuator = "-_.@ ,:=&$#^~*+!()[]<>%'/?";//"{}\\|`;"

        public new static readonly Biid Nothing = new(0L);

        public Biid(Bid bid) : this(bid._content[0]) {
        }

        public override string ToString() => (string)this;

        public override bool IsReadonly {
            get => _content[0] < 0;
            set {
                if (IsNothing) return;
                if (value ^ _content[0] > 0) _content[0] = -_content[0];
            }
        }

        protected override int OnCompare(long[] ocontent) {
            var r = AbsCompare(_content[0], ocontent[0]);
            return r != 0 ? r : ocontent.Length == 1 ? 0 : -1;
        }

        public IInput<char> CreateReader(bool skipFirst = false) => new BcidReader(_content[0], skipFirst);
        public unsafe void Add(int offset) {
            fixed (long* code = &_content[0]) {
                *code += offset;
            }
        }

        public static implicit operator Biid(long value) => new(value);
        public static implicit operator long(Biid bic) => bic._content[0];

        public static implicit operator Biid(string? name) => string.IsNullOrEmpty(name) ? new Biid(0L) : new Biid(new BcidWriter().WriteAll(name).Content);
        public static implicit operator string(Biid bic) => new BcidReader(bic._content[0]).ReadAll(MaxLength);

        /// <summary>
        ///     0: EOF
        ///  1-10: '0' - '9'
        /// 11-37: 'A' - 'Z' isLower: 'a' - 'z'
        /// 38-63: -_.@ ,:=&$#^~*+!()[]<>%'/?
        /// </summary>
        public static char ToChar(byte code, bool isLower = false) {
            if (code == 0) return EOF;
            if (code < 11) return (char)(code + 47);
            if (code < 38) return (char)(isLower ? code + 86 : code + 54);
            var index = code - 38;
            return Punctuator[index];
        }
        public static long ToCode(char chr, out bool isLower) {
            if (chr >= 97 && chr < 123) {
                isLower = true;
                return chr - 86L;
            }
            isLower = false;
            if (chr >= 48 && chr < 58) return chr - 47L;
            if (chr >= 65 && chr < 91) return chr - 54L;
            if (chr == EOF) return EndCode;

            var index = Punctuator.IndexOf(chr);
            if (index >= 0) return index + 38;

            throw MessageStorage.CreateException(nameof(Logs.BFND20301E), nameof(Bsid), chr);
        }
    }

    file sealed class BcidReader : IInput<char> {
        private readonly long _content;
        private int _position = -1;
        private int _shiftOffset;

        private Func<bool> _next;

        public BcidReader(long content, bool skipFirst = false) {
            _content = content;
            _next = _content == 0 ? InReadEnd : skipFirst ? InReadNext : InReadFirst;
            _shiftOffset = 63;
            MoveNext();
        }

        object IInput<char>.Position => _position;

        public char Current { get; private set; } = Bid.EOF;
        public bool IsEnd { get; private set; }

        public void MoveNext() {
            if (IsEnd) return;
            if (_next()) ++_position;
            else IsEnd = true;
        }

        private bool InReadFirst() {
            _next = InReadNext;
            if (_content > 0) return InReadNext();
            _position--;
            Current = ':';
            return true;
        }
        private bool InReadNext() {
            if (_shiftOffset < 6) return InReadLast();

            var c = Biid.ToChar((byte)((_content >> (_shiftOffset -= 6)) & 63));
            if (c == Bid.EOF) return InReadEnd();

            Current = c;
            return true;
        }
        private bool InReadLast() {
            _next = InReadEnd;

            var c = Biid.ToChar((byte)(_content & 7));

            Current = c;
            return true;
        }
        private bool InReadEnd() {
            _next = InReadEnd;
            Current = Bid.EOF;
            _shiftOffset = 0;
            return false;
        }
    }
    sealed class BcidWriter : IOutput<char> {
        private long _content;
        private int _position = -1;
        private int _shiftOffset = 63;

        private Func<char, bool> _write;

        public BcidWriter() {
            _content = 0;
            _write = InWriteFirst;
        }

        public long Content => _content;

        object IOutput<char>.Position => _position;
        public bool IsEnd { get; private set; }
        public bool Write(char chr) {
            if (IsEnd) return false;
            if (_write(chr)) {
                ++_position;
                return true;
            }
            IsEnd = true;
            return false;
        }

        private bool InWriteFirst(char chr) {
            _write = InWriteNext;
            if (chr != ':') return InWriteNext(chr);
            _position--;
            return true;
        }
        private bool InWriteNext(char chr) {
            if (chr == Bid.EOF) return InWriteEnd(chr);
            if (_shiftOffset < 6) return InWriteLast(chr);

            _content |= Biid.ToCode(chr, out _) << (_shiftOffset -= 6);

            return true;
        }
        private bool InWriteLast(char chr) {
            _write = InWriteEnd;

            _content |= Math.Min(7, Biid.ToCode(chr));

            return true;
        }
        private bool InWriteEnd(char chr) {
            _write = InWriteEnd;
            _shiftOffset = 0;
            return false;
        }
    }
}