﻿using Binean.Foundation.Storage;
using Binean.Private;
using System.Runtime.CompilerServices;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace Binean.Foundation.Primitive {
    /// <summary>
    /// Binean unique identifier
    /// </summary>
    public sealed class Buid(long[] content) : Bid(content) {
        public new static readonly Buid Nothing = new();

        private Buid() : this([0L]) { }
        //public override string ToString() => this.ToString(true);

        public override bool IsReadonly {
            get => _content[0] < 0;
            set {
                if (IsNothing) return;
                if (value ^ _content[0] > 0) _content[0] = -_content[0];
            }
        }
        protected override int OnCompare(long[] ocontent) {
            var r = AbsCompare(_content[0], ocontent[0]);
            if (r != 0) return r;

            var rLen = _content.Length.CompareTo(ocontent.Length);
            var len = rLen < 0 ? _content.Length : ocontent.Length;

            for (var i = 1; i < len; i++) {
                if ((r = _content[i].CompareTo(ocontent[i])) != 0) return r;
            }

            return rLen;
        }

        //public static implicit operator Buid(string? name) => string.IsNullOrEmpty(name) ? Nothing : name.ToBuid(false);
        //public static implicit operator string(Buid bidten) => bidten.IsNothing ? string.Empty : bidten.ToString(false);
    }
}