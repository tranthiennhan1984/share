﻿using Binean.Foundation.Storage;
using Binean.Private;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace Binean.Foundation.Primitive {
    /// <summary>
    /// Ten character Binean identifier
    /// </summary>
    public sealed class CodeId(long content) : Bid([content]) {
        public new static readonly CodeId Nothing = new();

        private CodeId() : this(0L) { }
        public override string ToString() => this.ToString(true);

        public override bool IsReadonly {
            get => _content[0] < 0;
            set {
                if (value ^ _content[0] < 0) _content[0] = -_content[0];
            }
        }
        public unsafe void Increase() {
            fixed (long* code = &_content[0]) {
                *code += 8;
            }
        }

        public static implicit operator CodeId(long value) => new(value);
        public static implicit operator long(CodeId bidten) => bidten._content[0];

        public static implicit operator CodeId(string? name) => string.IsNullOrEmpty(name) ? Nothing : name.ToBidten();
        public static implicit operator string(CodeId bidten) => bidten.IsNothing ? string.Empty : bidten.ToString(false);

        public static char ToChar(byte code) {
            if (code < 52) return (char)((code & 1L) == 1L ? (code >> 1) + 97L : (code >> 1) + 65L);
            if (code == 62) return '_';
            if (code == 63) return '-';
            if (code < 62) return (char)(code - 4);
            throw MessageStorage.CreateException(nameof(Logs.BFND20302E), nameof(CodeId), code);
        }

    }
}