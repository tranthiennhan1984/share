﻿namespace Binean.Foundation.Primitive {
    [BLog]
    internal static class Logs {
        public const string BFND2011E = "Cannot convert '{0}' to Batity '{1}'.";
        public const string BFND2012E = "Invalid name type '{0}'.";

        public const string BFND202AE = "Cannot convert '{0}' to path.";
        public const string BFND202BE = "Invalid token '{0}'.";
        public const string BFND202CE = "Token's name is expected.";
        public const string BFND202DE = "Token's name is unexpected.";
        public const string BFND202EE = "Token's tag is too long: '{0}'.";
        public const string BFND202IE = "Cannot set property: '{0}' to {1}.";
        public const string BFND202JE = "Cannot remove property: '{0}' from {1}.";
        public const string BFND20203E = "Writer is ended.";

        public const string BFND20301E = "Invalid {0} character '{1}'.";
        public const string BFND20302E = "Invalid {0} code: '{1}'.";
        public const string BFND20311E = "Argument must be a Biu '{0}'.";
        public const string BFND20321E = "Argument must be a Bic '{0}'.";
        public const string BFND2033E = "Argument must be a Bid '{0}'.";

        public const string BFND2041E = "Cannot set property: '{0}' to {1}.";

        public const string BFND2051E = "Token '{0}' is expected.";
        public const string BFND2052E = "Read fault; reader is closed.";
        public const string BFND2053E = "Initialize fault; reader is already initialized.";

        public const string BFND2061E = "Invalid token.";
        public const string BFND2062E = "Initialize fault; writer is already initialized.";
    }
}