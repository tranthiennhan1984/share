﻿using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace Binean.Foundation.Primitive {
    public static partial class Extension {

        #region :: Bic Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bsid? TryBid(this object? obj, Func<Bsid?>? failHandler = null)
            => InToBid(obj, failHandler ?? new Func<Bsid?>(() => null));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bsid ToBid(this object? obj, Func<Bsid>? failHandler = null)
            => InToBid(obj, failHandler ?? new Func<Bsid>(() => Bsid.Nothing)) ?? Bsid.Nothing;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static Bsid? InToBid(object? obj, Func<Bsid?> failHandler) {
            if (obj is null) return failHandler();
            if (obj is Bsid bid) return bid;
            if (obj is Bid biu) return new Bsid(biu);
            if (obj is long lv) return new Bsid([lv]);
            if (obj is string txt) return (Bsid)txt;
            return failHandler();
        }

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static tenid? TryBic(this object? obj, Func<tenid?>? failHandler = null)
        //    => InToBic(obj, failHandler ?? new Func<tenid?>(() => null));
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static tenid ToBic(this object? obj, Func<tenid>? failHandler = null)
        //    => InToBic(obj, failHandler ?? new Func<tenid>(() => tenid.Nothing)) ?? tenid.Nothing;
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //private static tenid? InToBic(object? obj, Func<tenid?> failHandler) {
        //    if (obj is null) return failHandler();
        //    if (obj is tenid bic) return bic;
        //    if (obj is Bid biu) return new tenid(biu);
        //    if (obj is long lv) return (tenid)lv;
        //    if (obj is string txt) return (tenid)txt;
        //    return failHandler();
        //}

        #endregion

        #region :: INameSet Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEnumerable<T> GetNames<T>(this IEnumerable enm)
            => enm is INames<T> no ? no.Names : InGetNames<T>(enm);
        private static IEnumerable<T> InGetNames<T>(IEnumerable enm) {
            foreach (var item in enm) {
                var obj = item is INamed ni ? ni.Name : item;
                if (obj.TryConvertName(out T? name)) yield return name;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Contains<T>(this INameSet<T> list, T name)
            => list != null && list.Find(name, out int _);
        public static bool Contains<T>(this INameSet<T> list, [NotNullWhen(true)] ref T name) {
            if (!list.Find(name, out int index)) return false;
            return (name = list[index]) is not null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty<T>([NotNullWhen(false)] this INameSet<T>? list)
            => list is null || list.Count == 0;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEmpty<T>(this INameSet<T> list) => list.Count == 0;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameSet<T> GetNameSet<T>(this IEnumerable enm)
            => enm is INames<T> no ? no.Names : Prior.CreateNames<T>().AddRange(InGetNames<T>(enm));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameList<T> Clone<T>(this INameSet<T> set)
            => Prior.CreateNames<T>().AddRange(set);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddRange<T, TName>(this T list, IEnumerable<TName> names) where T : INameList<TName> {
            foreach (var name in names) {
                list.Add(name);
            }
            return list;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddRange<T>(this T list, IEnumerable<Bsid> names) where T : INameList<Bsid> {
            foreach (var name in names) {
                list.Add(name);
            }
            return list;
        }
        public static bool Remove<T>(this INameList<T> list, T name) {
            if (!list.Find(name, out int index)) return false;
            list.RemoveAt(index);
            return true;
        }
        public static T RemoveRange<T, TName>(this T list, IEnumerable names) where T : INameList<TName> {
            foreach (var name in names) {
                if (name.TryConvertName(out TName? t)) list.Remove(t);
            }
            return list;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T RemoveRange<T, TName>(this T list, IEnumerable<TName> names) where T : INameList<TName> {
            foreach (var name in names) {
                if (name.TryConvertName(out TName? t)) list.Remove(t);
            }
            return list;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddName<T, TName>(this T list, TName item) where T : INameList<TName> {
            list.Add(item);
            return list;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddName<T>(this T list, Bsid item) where T : INameList<Bsid> {
            list.Add(item);
            return list;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T RemoveRange<T>(this T list, IEnumerable<Bsid> names) where T : INameList<Bsid> {
            foreach (var name in names) {
                if (name.TryConvertName(out Bsid? t)) list.Remove(t);
            }
            return list;
        }
        //public static void AddNames<TName,Titem>(this INameList<TName> list) {
        //    if (list is null) return;
        //    var type = typeof(Titem);
        //    if (type.IsEnum) list.AddRange(Enum.GetNames(type));
        //    else InAddFields(list, type);
        //}
        public static void AddNames<T>(this INameList<T> list, Type namesType) {
            if (list is null) return;
            if (namesType.IsEnum) list.AddRange(Enum.GetNames(namesType).GetNames<T>());
            else InAddFields(list, namesType);
        }
        private static void InAddFields<T>(INameList<T> list, Type propType) {
            var st = typeof(string);
            foreach (var field in propType.GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)) {
                if (!field.IsLiteral || field.IsInitOnly || field.FieldType != st) continue;
                if (field.GetRawConstantValue() is not string value || value is null) continue;
                if (value.TryConvertName(out T? t)) list.Add(t);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameList<T> AddName<T>(this INameList<T> list, bool condition, Func<T> nameFunc)
            => !condition ? list : list.AddName(nameFunc());

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameList<T> AddFirstName<T>(this INameList<T> list, params T[] values) {
            foreach (var value in values) {
                if (list.Add(value) >= 0) break;
            }
            return list;
        }

        private static string ReadText(this TextReader reader) {
            StringBuilder builder = new();
            char chr;
            while ((chr = reader.ReadChar()) != BetextReader.EofCharacter) {
                if (chr == ' ') {
                    if (builder.Length > 0) return builder.ToString();
                    continue;
                }
                builder.Append(chr);
            }
            return builder.ToString();
        }
        private static char ReadChar(this TextReader reader) {
            var retVal = reader.Read();
            return retVal < 0 ? BetextReader.EofCharacter : (char)retVal;
        }

        public static string BuildClass<T>(this INameList<T> list) {
            var builder = new StringBuilder();
            var length = list.Count;
            for (int i = 0; i < length; i++) {
                var name = list[i];
                if (builder.Length > 0) builder.Append(' ');
                builder.Append(name);
            }
            return builder.ToString();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameList<T> AddClasses<T>(this INameList<T> list, string? cls) {
            if (string.IsNullOrWhiteSpace(cls)) return list;
            using (var txtReader = new StringReader(cls)) {
                string txt;
                while ((txt = txtReader.ReadText()).Length > 0) {
                    if (txt.TryConvertName(out T? t)) list.Add(t);
                }
            }
            return list;
        }

        #endregion

        //#region :: StringList Helpers ::

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static StringList AddName(this StringList list, string name) {
        //    if (string.IsNullOrWhiteSpace(name)) return list;
        //    list.Add(name);
        //    return list;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static StringList AddRange(this StringList list, IEnumerable<string> items) {
        //    foreach (var name in items) {
        //        list.Add(name);
        //    }
        //    return list;
        //}
        //public static StringList AddRange(this StringList list, IEnumerable items) {
        //    foreach (var item in items) {
        //        if (item is not string name) {
        //            if (item is string txt) name = txt;
        //            else continue;
        //        }
        //        list.Add(name);
        //    }
        //    return list;
        //}
        //public static bool Remove(this StringList list, string name) {
        //    if (!list.Find(name, out int index)) return false;
        //    list.RemoveAt(index);
        //    return true;
        //}
        //public static StringList RemoveRange(this StringList list, IEnumerable items) {
        //    foreach (var item in items) {
        //        if (item is not string name) {
        //            if (item is string txt) name = txt;
        //            else continue;
        //        }
        //        list.Remove(name);
        //    }
        //    return list;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static StringList RemoveRange(this StringList list, IEnumerable<string> items) {
        //    foreach (var name in items) {
        //        list.Remove(name);
        //    }
        //    return list;
        //}
        //#endregion
    }
}