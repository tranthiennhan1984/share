﻿using System.Collections;
using System.Xml.Linq;
namespace Binean.Foundation.Primitive {
    public sealed class StringList : INameList<string> {
        private readonly Finder _finder;
        private readonly Func<int, string, int> _adder;
        private readonly List<string> _strings = [];
        private int _valueType;
        private Action<int, string> _insertHandler = default!;

        public StringList(ListType listType, bool isUnique = true) {
            ListType = listType;
            _finder = ListType.HasFlag(ListType.Ordered) ? InBinaryFinder : InFinder;
            _valueType = ListType.HasFlag(ListType.Constant) ? 1 : 2;
            _adder = isUnique ? UniqueAdd : NormalAdd;
            InUpdateInsertHandler();
        }

        public int Count => _strings.Count;
        public string this[int index] => _strings[index];
        public ListType ListType { get; }

        public bool IsLocked => _valueType < 0;

        public int Add(string name) {
            _finder(this, name, out int index);
            return _adder(index, name);
        }
        public bool Find(string name, out int index)
            => _finder(this, name, out index);
        public void RemoveAt(int index) => _strings.RemoveAt(index);
        public void Clear() => _strings.Clear();

        public bool Readonly(bool? readOnly = null) {
            if (readOnly is null
                || (readOnly.Value && _valueType < 0)
                || (!readOnly.Value && _valueType > 0)) return _valueType < 0;
            _valueType = -_valueType;
            InUpdateInsertHandler();
            return _valueType < 0;
        }

        private void InUpdateInsertHandler() {
            if (_valueType == 1) _insertHandler = InInsertSingleton;
            else if (_valueType == 2) _insertHandler = InInsert;
            else _insertHandler = InInsertError;
        }
        private void InInsert(int index, string name) => _strings.Insert(index, name);
        private void InInsertError(int index, string name) => throw new InvalidOperationException();
        private void InInsertSingleton(int index, string name) => _strings.Insert(index, name.ToConstant());


        private int NormalAdd(int index, string name) {
            if (index < 0) index = ~index;
            _insertHandler(index, name);
            return index;
        }
        private int UniqueAdd(int index, string name) {
            if (index >= 0) return index;
            index = ~index;
            _insertHandler(index, name);
            return index;
        }


        private delegate bool Finder(StringList list, string name, out int index);
        private static bool InBinaryFinder(StringList list, string name, out int index) {
            var length = list.Count;
            if (length == 0) return (index = ~length) > -1;
            return list.BinarySearch(length, (set, index) => set[index], n => n.CompareTo(name), out index);
        }
        private static bool InFinder(StringList list, string name, out int index) {
            var length = list.Count;
            if (length == 0) return (index = ~length) > -1;
            for (int i = 0; i < length; i++) {
                if (list[i].CompareTo(name) == 0) return (index = i) > -1;
            }
            return (index = ~length) > -1;
        }


        public IEnumerator<string> GetEnumerator() => _strings.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_strings).GetEnumerator();

    }
}
