﻿using System.Runtime.Versioning;

namespace Binean.Foundation.Primitive {
    public interface INameSet<T> : IEnumerable<T> {
        ListType ListType { get; }
        int Count { get; }
        T this[int index] { get; }
        bool Find(T name, out int index);
    }
    public interface INameList<T> : INameSet<T>, IWriteLock {
        int Add(T item);
        void RemoveAt(int index);
        void Clear();
    }
    [Flags]
    public enum ListType {
        Default = 0,
        Ordered = 1,
        Constant = 2,
        Quick = 3
    }
    public interface INameSet : INameSet<Bsid> {
    }
    public interface INameList: INameList<Bsid> { }
}
