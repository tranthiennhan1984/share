﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public interface IGetter : IEnumerable<IUnit>, IGettable {
        bool IsEmpty { get; }
    }
    public interface ISetter : ISettable {
        bool TryRemoveValue(Bsid bid);
        bool Clear();
        void ChangeDisplayBid(Bsid bid);
    }
    public interface IClassed {
        BClass? Class { get; set; }
    }
    public interface IValues {
        IEnumerable Values { get; }
    }
    public interface INames<T> {
        INameSet<T> Names { get; }
    }
    public interface INamed {
        Bsid Name { get; }
    }
    public interface IWriteLock {
        bool Readonly(bool? readOnly = null);
    }
    public interface INameLock : IWriteLock {
        bool Readonly(Bsid name, bool? readOnly = null);
    }
    public interface ILockable {
        IWriteLock? Lock { get; }
    }

    public interface IGettable {
        bool TryGetValue(Bsid bid, out object? value);
    }
    public interface ISettable {
        bool TrySetValue(Bsid bid, object? value);
    }

}