﻿namespace Binean.Foundation.Primitive {
    public interface IUnit : INamed {
        object? Value { get; }
    }

    public sealed class Unit(Bsid bid, object? value) : IUnit, IClassed, IBoxabl {
        public static readonly Unit Empty = new(Bsid.Nothing, DBNull.Value);
        public Unit() : this(Bsid.Nothing, null) { }

        public BClass? Class { get; set; }
        public Bsid Name { get; private set; } = bid;
        public object? Value { get; private set; } = value;

        public IEntity Box() => Prior.CreateQEntity().SetBClass(Class).SetName(Name).SetValue(Value);
        public void Unbox(IEntity data) {
            if (data is IClassed clsed) Class = clsed.Class;
            Name = data.GetName();
            Value = data.GetValue();
        }
    }
}
