﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    [CEntity]
    public class BClass : IProspective {
        public BClass() { }
        public BClass(IGetter? context) {
            Context = context;
        }
        public IGetter? Context { get; set; }

        [CProp(WriteOver = true)]
        public Bib Names { get; } = Prior.CreateCNames();
        public IEntity Potential { get; } = Prior.CreateQEntity();

        public IGetter Compute() {
            if (Context.IsNullOrEmpty()) return Dummy.Entity;
            var retVal = Context.Compute(Names);
            if (!Potential.IsNullOrEmpty()) retVal.Assign(Potential);
            return retVal;
        }

        public static BClass CreateClass(Bsid cls) {
            var retVal = new BClass();
            retVal.Names.Add(cls);
            if (cls.ToType() is Type type) retVal.Potential.SetValueType(type);
            return retVal;
        }
    }
}