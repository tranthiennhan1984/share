﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class EGetter(IEntity source) : IGetter, IClassed, INames<Bsid>, IValues {
        internal readonly IEntity _source = source;
        public EGetter() : this(Prior.CreateEntity()) { }

        public bool IsEmpty => _source.IsEmpty;

        public BClass? Class {
            get => _source is IClassed clsed ? clsed.Class : _class;
            set {
                if (_source is IClassed clsed) clsed.Class = value;
                else _class = value;
            }
        }
        private BClass? _class;

        public INameSet<Bsid> Names => _source.GetNameSet<Bsid>();
        public IEnumerable Values => _source.GetValues();

        public bool TryGetValue(Bsid bid, out object? value) {
            var retVal = _source.TryGetValue(bid, out value);
            if (retVal && value is IEntity ent && value is not EGetter && value is not BEntity) {
                value = new EGetter(ent);
            }
            return retVal;
        }
        public IEnumerator<IUnit> GetEnumerator() => _source.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_source).GetEnumerator();
    }
    public sealed class AGetter : IGetter {
        internal readonly List<IGetter> _getters = [];
        public AGetter(params IGetter[] getters) {
            AddRange(getters);
        }
        public AGetter(IEnumerable<IGetter> getters) {
            AddRange(getters);
        }
        public bool IsEmpty => _getters.Count == 0;
        public bool TryGetValue(Bsid bid, out object? value) {
            var length = _getters.Count;
            for (int i = 0; i < length; i++) {
                var getter = _getters[i];
                if (getter.TryGetValue(bid, out value)) return true;
            }
            return (value = null) != null;
        }

        public void AddRange(IEnumerable<IGetter> getters) {
            foreach (var getter in getters) {
                AddLast(getter);
            }
        }
        public void AddFirst(IGetter getter) {
            if (_getters.Contains(getter)) _getters.Remove(getter);
            _getters.Insert(0, getter);
        }
        public void AddLast(IGetter getter) {
            if (_getters.Contains(getter)) _getters.Remove(getter);
            _getters.Add(getter);
        }

        private IEnumerable<IUnit> GetUnits() {
            var visited = Prior.CreateQNames();
            var length = _getters.Count;
            for (int i = 0; i < length; i++) {
                var getter = _getters[i];
                foreach (var unit in getter) {
                    if (visited.Contains(unit.Name)) continue;
                    visited.Add(unit.Name);
                    yield return unit;
                }
            }
        }
        public IEnumerator<IUnit> GetEnumerator() => GetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetUnits().GetEnumerator();
    }
}