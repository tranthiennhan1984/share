﻿using Microsoft.VisualBasic;
using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using static System.Net.Mime.MediaTypeNames;

namespace Binean.Foundation.Primitive {
    public static partial class Extension {
        //#region :: Getable Helpers ::

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool Contains(this Gettable getable, Bid name)
        //    => getable.TryGetValue(name, out _);
        //public static object? Get(this Gettable getable, Bid name)
        //    => getable.TryGetValue(name, out object? obj) ? obj : null;
        //public static T? Get<T>(this Gettable getable, Bid name, T? faultValue = default)
        //    => getable.TryGetValue(name, out object? obj) ? obj.Convert(() => faultValue) : faultValue;
        //public static bool TryGet<T>(this Gettable getable, Bid name, out T? value) {
        //    if (getable(name, out object? obj)) {
        //        if (obj.TryConvert(typeof(T), out object? v)) {
        //            value = (T?)v;
        //            return true;
        //        }
        //    }
        //    value = default;
        //    return false;
        //}

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool TryGetNotNull<T>(this Gettable getable, Bid name, [NotNullWhen(true)] out T? value)
        //    => TryGet(getable, name, out value) && value != null;

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static Settable Set(this Settable setable, Bid name, object? value, bool guarantee = true) {
        //    if (!setable(name, value) && guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND20201E), name, setable);
        //    return setable;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static Settable Add(this Settable setter, INamed item) => setter.Set(item.Name, item);

        //#endregion

        #region :: Setter Gettter features::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEnumerable<T> GetValues<T>(this IEnumerable<IUnit> enm) {
            foreach (var item in enm.GetValues()) {
                if (item is T t) yield return t;
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEnumerable GetValues(this IEnumerable<IUnit> enm)
            => enm is IValues co ? co.Values : InGetValues(enm);
        private static IEnumerable InGetValues(IEnumerable<IUnit> enm) {
            foreach (var item in enm) {
                yield return item.Value;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Contains(this IGettable getter, Bsid name) {
            if (getter is INames<Bsid> named) return named.Names.Contains(name);
            return getter.TryGetValue(name, out _);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty([NotNullWhen(false)] this IGetter? getter)
            => getter is null || getter.IsEmpty;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Get(this IGettable? getter, Bsid name)
            => getter != null && getter.TryGetValue(name, out object? obj) ? obj : null;

        [return: NotNullIfNotNull(nameof(faultValue))]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Get<T>(this IGettable? getter, Bsid name, T? faultValue = default)
            => getter != null && getter.TryGetValue(name, out object? obj) ? obj.Convert(() => faultValue) : faultValue;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? QGet(this IGettable getter, Bsid name)
            => getter.TryGetValue(name, out object? obj) ? obj : null;

        [return: NotNullIfNotNull(nameof(faultValue))]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? QGet<T>(this IGettable getter, Bsid name, T? faultValue = default)
            => getter.TryGetValue(name, out object? obj) ? obj.Convert(() => faultValue) : faultValue;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T QSet<T>(this T setter, Bsid name, object? value, bool guarantee = true) where T : ISetter {
            if (!setter.TrySetValue(name, value) && guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND202IE), name, setter);
            return setter;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Remove<T>(this T setter, Bsid name) where T : ISetter {
            setter.TryRemoveValue(name);
            return setter;
        }

        public static bool TrySet(this ISetter setter, Bsid name, Func<object?> valueGetter, bool guarantee = true, bool? mset = false) {
            if (mset.GetValueOrDefault(true) && setter.TryGetValue(name, out object? oldValue) && oldValue != null) {
                if (mset is null && guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND202IE), name, setter);
                return false;
            }
            var retVal = setter.TrySetValue(name, valueGetter());
            if (!retVal && guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND202IE), name, setter);
            return retVal;
        }
        public static bool TrySet(this ISetter setter, Bsid name, object? value, bool guarantee = true, bool? mset = false) {
            if (mset.GetValueOrDefault(true) && setter.TryGetValue(name, out object? oldValue) && oldValue != null) {
                if (mset is null && guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND202IE), name, setter);
                return false;
            }
            var retVal = setter.TrySetValue(name, value);
            if (!retVal && guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND202IE), name, setter);
            return retVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T ISet<T>(this T setter, Bsid name, object? value, bool guarantee = true) where T : ISetter {
            setter.TrySet(name, value, guarantee, null);
            return setter;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T ISet<T>(this T setter, Bsid name, Func<object?> valueGetter, bool guarantee = true) where T : ISetter {
            setter.TrySet(name, valueGetter, guarantee, null);
            return setter;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T MSet<T>(this T setter, Bsid name, object? value, bool guarantee = true) where T : ISetter {
            setter.TrySet(name, value, guarantee, true);
            return setter;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T MSet<T>(this T setter, Bsid name, Func<object?> valueGetter, bool guarantee = true) where T : ISetter {
            setter.TrySet(name, valueGetter, guarantee, true);
            return setter;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Set<T>(this T setter, Bsid name, object? value, bool guarantee = true) where T : ISetter {
            setter.TrySet(name, value, guarantee, false);
            return setter;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Set<T>(this T setter, Bsid name, Func<object?> valueGetter, bool guarantee = true) where T : ISetter {
            setter.TrySet(name, valueGetter, guarantee, false);
            return setter;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Remove<T>(this T setter, Bsid name, bool guarantee = false) where T : ISetter {
            if (!setter.TryRemoveValue(name) && guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND202JE), name, setter);
            return setter;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Clear<T>(this T setter) where T : ISetter {
            setter.Clear();
            return setter;
        }

        public static bool TryGetNotNull<T>(this IGettable? getter, Bsid name, [NotNullWhen(true)] out T? value) {
            if (getter != null && getter.TryGetValue(name, out object? obj)) {
                if (obj.TryConvert(typeof(T), out object? v)) {
                    value = (T?)v;
                    return v != null;
                }
            }
            value = default;
            return false;
        }
        public static bool TryUnbox<T>(this IGettable? getter, Bsid name, [NotNullWhen(true)] out T? value, bool validate = true) {
            if (getter.TryGetNotNull(name, out object? obj) && obj.TryUnbox(out value, validate)) return true;
            value = default;
            return false;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryGetText(this IGettable? getter, Bsid name, [NotNullWhen(true)] out string? value)
            => TryGetNotNull(getter, name, out value) && !string.IsNullOrWhiteSpace(value);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T TryConfigure<T>(this T obj, IGettable? value) {
            if (value is null) return obj;
            obj.TryConfigure(value, false);
            return obj;
        }
        public static T TryConfigure<T>(this T setter, IGettable? value, bool guarantee = false) {
            if (value is null) return setter;
            using (var reader = Men.Serialize(value)!) {
                using (var writer = Men.Deserialize(setter)) {
                    writer.WriteGuarantee = guarantee;
                    writer.Write(reader);
                }
            }
            return setter;
        }
        public static T Assign<T>(this T setter, IGetter? getter, bool guarantee = false, bool validate = false) where T : ISetter {
            if (getter.IsNullOrEmpty()) return setter;

            if (setter is not IEquatable<IGetter> equ || !equ.Equals(getter)) {
                foreach (var unit in getter) {
                    setter.Set(unit.Name, unit.Value, guarantee);
                }
            }

            if (validate) (setter as IValidator)?.TryValidate();

            return setter;
        }
        public static T MAssign<T>(this T setter, IGetter? getter, bool guarantee = false, bool validate = false) where T : ISetter {
            if (getter.IsNullOrEmpty()) return setter;

            foreach (var unit in getter) {
                setter.MSet(unit.Name, unit.Value, guarantee);
            }

            if (validate) (setter as IValidator)?.TryValidate();

            return setter;
        }

        #endregion

        #region :: Class Helpers ::
        public static int IndexOfClass(this string txt, string? cls) {
            if (string.IsNullOrEmpty(txt)) return -1;
            if (string.IsNullOrWhiteSpace(cls = cls?.Trim())) return -1;

            var index = txt.IndexOf(cls);
            if (index < 0) return -1;
            var last = index + cls.Length;
            if (last == txt.Length || txt[last] == ' ') return index;
            return -1;
        }
        [return: NotNullIfNotNull(nameof(txt))]
        public static string? AddClass(this string? txt, string? cls) {
            if (string.IsNullOrWhiteSpace(cls = cls?.Trim())) return txt;
            if (string.IsNullOrEmpty(txt)) return cls;
            if (txt.IndexOfClass(cls) > -1) return txt;
            return $"{txt} {cls}";
        }
        [return: NotNullIfNotNull(nameof(txt))]
        public static string? RemoveClass(this string? txt, string? cls) {
            if (string.IsNullOrWhiteSpace(cls = cls?.Trim())) return txt;
            if (string.IsNullOrEmpty(txt)) return txt;
            var index = txt.IndexOfClass(cls);
            if (index < 0) return txt;
            var first = index < 1 ? "" : txt[0..(index - 1)];
            index += cls.Length;
            var end = index == txt.Length ? "" : txt[(index + 1)..];
            return $"{first} {end}";
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BClass AssertClass(this IClassed classed, IGetter? context = null) {
            if (classed.Class is not BClass retVal) classed.Class = retVal = new BClass(context);
            return retVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetClass<T>(this T obj, Bsid cls) where T : IClassed {
            if (!cls.IsNothing) obj.AssertClass().Names.Add(cls);
            return obj;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddClass<T>(this T obj, Bsid cls) where T : IClassed {
            if (!cls.IsNothing) obj.AssertClass().Names.Add(cls);
            return obj;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T RemoveClass<T>(this T obj, Bsid cls) where T : IClassed {
            if (obj.Class is BClass bcls) bcls.Names.Remove(cls);
            return obj;
        }
        public static T AddNames<T>(this T obj, IEnumerable<Bsid>? names) where T : IClassed {
            if (names != null) obj.AssertClass().Names.AddRange(names);
            return obj;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetBClass<T>(this T obj, BClass? bcls) where T : IClassed {
            if (bcls is null) return obj;
            obj.Class = bcls;
            return obj;
        }
        public static T AddBClass<T>(this T obj, BClass? bcls) where T : IClassed {
            if (bcls is null) return obj;
            var cls = obj.AssertClass();
            if (!bcls.Potential.IsNullOrEmpty()) cls.Potential.MAssign(bcls.Potential);
            if (bcls.Names is IEnumerable names) cls.Names.AddRange(names.GetNames<Bsid>());
            cls.Context ??= bcls.Context;
            return obj;
        }

        public static IEntity Compute(this IGetter context, IEnumerable names) {
            var retVal = Prior.CreateQEntity();
            foreach (var name in names) {
                if (name.TryBid() is not Bsid bid) continue;
                if (context.QGet(bid)?.Box() is not IGetter gt) continue;
                retVal.Assign(gt, false);
            }
            return retVal;
        }

        #endregion

        #region :: Name Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Add<T>(this T setter, INamed item) where T : ISetter
            => setter.Set(item.Name, item);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T MAdd<T>(this T setter, INamed item) where T : ISetter
            => setter.MSet(item.Name, item);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryAdd(this ISetter setter, INamed item)
            => setter.TrySet(item.Name, item, true);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryMAdd(this ISetter setter, INamed item)
            => setter.TrySet(item.Name, item, true, true);
        #endregion

        #region :: Validator ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        [return: NotNullIfNotNull(nameof(obj))]
        public static T? AValidate<T>(this T? obj) => Validate(obj, true);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        [return: NotNullIfNotNull(nameof(obj))]
        public static T? Validate<T>(this T? obj, bool assert) {
            (obj as IValidator)?.Validate(assert ? Dummy.ErrLog : Dummy.CreateLogger());
            return obj;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryValidate(this IValidator validator) {
            var logger = Dummy.CreateLogger();
            return validator.Validate(logger) && logger.MinimumLevel < LogLevel.Error;
        }

        #endregion
    }
}
