﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class Entity(ListType listType) : IEntity, IClassed, INames<Bsid>, IValues, ILockable {

        private readonly Bib _names = new(listType);
        private readonly IList _values = Prior.CreateList();

        private Bsid _displayBid = Properties.Name;

        public override string? ToString()
            => this.QGet(DisplayBid) is string txt ? txt : base.ToString();

        public int Count => _values.Count;
        public bool IsEmpty => _values.Count == 0;

        public BClass? Class { get; set; }

        public INameSet<Bsid> Names => _names;
        public IEnumerable Values => _values;
        IWriteLock? ILockable.Lock => _names.GetLock();

        public Bsid DisplayBid { get => _displayBid; set => _displayBid = value; }

        public bool TryGetValue(Bsid bid, out object? value)
            => (!bid.IsNothing && _names.Count > 0
                && _names.Find(bid, out int index)
                && (value = _values[index]) is not DBNull) || (value = null) != null;
        public bool TrySetValue(Bsid bid, object? value) {
            if (_names.Readonly() || bid.IsNothing) return false;

            if (_names.Find(bid, out int index)) {
                if (_names[index].IsReadonly) return false;
                if (value is DBNull) {
                    _names.RemoveAt(index);
                    _values.RemoveAt(index);
                } else {
                    _values[index] = value;
                }
                return true;
            }

            if (value is DBNull) return true;

            _values.Insert(_names.Add(bid), value);
            return true;
        }
        public bool Clear() {
            if (_names.Readonly()) return false;
            _names.Clear();
            _values.Clear();
            return true;
        }
        public bool TryRemoveValue(Bsid bid) {
            if (_names.Readonly()) return false;

            if (!_names.Find(bid, out int index) || _names[index].IsReadonly) return false;

            _names.RemoveAt(index);
            _values.RemoveAt(index);
            return true;
        }

        public void ChangeDisplayBid(Bsid bid) => DisplayBid = bid;
        private IEnumerable<IUnit> GetUnits() {
            var length = _values.Count;
            for (int i = 0; i < length; i++) {
                yield return new Unit(_names[i], _values[i]);
            }
        }
        public IEnumerator<IUnit> GetEnumerator() => GetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => _values.GetEnumerator();
    }

    public sealed class Litity : List<object?>, IClassed, IValues {
        internal Litity() { }
        public BClass? Class { get; set; }
        public IEnumerable Values => this;
    }

    public sealed class DEntity(IGetter? source, IEntity entity) : IEntity, IClassed, INames<Bsid>, ILockable, IValidator {
        private readonly Bib _deleted = Prior.CreateQNames();

        public DEntity(IGetter? source) : this(source, Prior.CreateEntity((source as INames<Bsid>)?.Names.ListType ?? ListType.Default)) { }

        public override string? ToString()
            => Entity.ToString();

        public bool IsEmpty => Entity.IsEmpty && Source.IsEmpty;

        public BClass? Class {
            get => Entity is IClassed clsed ? clsed.Class : _class;
            set {
                if (Entity is IClassed clsed) clsed.Class = value;
                else _class = value;
            }
        }
        private BClass? _class;
        public INameSet<Bsid> Names => InGetNames();
        IWriteLock? ILockable.Lock => Entity.GetLock();

        public IEntity Entity { get; private set; } = entity;
        public IGetter Source { get; private set; } = source ?? Dummy.Entity;

        public void ChangeSource(IGetter source) {
            Source = source;
        }

        public bool TryGetValue(Bsid bid, out object? value) {
            if (_deleted.Contains(bid) || bid.IsNothing) {
                value = null;
                return false;
            }
            if (Entity.TryGetValue(bid, out value)) return true;
            return Source.TryGetValue(bid, out value);
        }
        public bool TrySetValue(Bsid bid, object? value) {
            if (bid.IsNothing) return false;
            if (value is DBNull) {
                Entity.TryRemoveValue(bid);
                _deleted.Add(bid);
                return true;
            }

            _deleted.Remove(bid);
            Entity.TrySetValue(bid, value);
            return true;
        }
        public bool Clear() {
            if (!Entity.Clear()) return false;
            _deleted.Clear();
            return true;
        }
        public bool TryRemoveValue(Bsid bid) {
            Entity.TryRemoveValue(bid);
            _deleted.Add(bid);
            return true;
        }
        public void ChangeDisplayBid(Bsid bid) => Entity.ChangeDisplayBid(bid);
        private INameSet<Bsid> InGetNames() {
            var retval = Prior.CreateCNames();
            if (Source != Dummy.Entity) retval.AddRange(Source.GetNames<Bsid>());
            retval.AddRange(Entity.GetNames<Bsid>());
            retval.RemoveRange(_deleted);
            return retval;
        }
        private IEnumerable<IUnit> InGetUnits() {
            var visited = Prior.CreateQNames().AddRange(_deleted);

            foreach (var unit in Source) {
                var name = unit.Name;
                if (_deleted.Contains(name)) continue;
                visited.Add(name);
                if (Entity.TryGetValue(name, out object? value)) yield return new Unit(name, value);
                else yield return unit;
            }

            foreach (var unit in Entity) {
                var name = unit.Name;
                if (visited.Contains(name)) continue;
                yield return unit;
            }
        }

        public IEnumerator<IUnit> GetEnumerator() => InGetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => InGetUnits().GetEnumerator();

        public bool Validate(ILogger logger) => (Entity as IValidator)?.Validate(logger) ?? false;

    }
    file static class Properties {
        public static readonly Bsid Name = nameof(Name);
    }
}