﻿namespace Binean.Foundation.Primitive {
    public interface IEntity : IGetter, ISetter {
    }
    public interface IProspective {
        IEntity Potential { get; }
    }
}