﻿namespace Binean.Foundation.Primitive {
    public abstract class BEntity : IClassed, IProspective, ILockable {
        protected IEntity _latent;

        protected BEntity() : this(Prior.GetBEntityData()) { }
        protected BEntity(IEntity entity) { _latent = entity; }

        public IEntity Potential => _latent;

        public BClass? Class {
            get {
                if (_latent is IClassed cls) return cls.Class;
                return _class;
            }
            set => OnClassChanged(value);
        }
        private BClass? _class;

        IWriteLock? ILockable.Lock => (_latent as ILockable)?.Lock;
        public bool IsDummy => Potential == Dummy.Entity;
        protected virtual void OnClassChanged(BClass? value) {
            if (_latent is IClassed te) te.Class = value;
            else _class = value;
        }
    }
}