﻿namespace Binean.Foundation.Primitive {
    public interface IBoxabl {
        IEntity Box();
        void Unbox(IEntity data);
    }
    public interface IValidator {
        bool Validate(ILogger logger);
    }
    public interface ISerializable {
        Node Write(ref Deserialize deserialize, Node block, string name);
        Token Read(ref Serialize serialize, Token block, string name);
    }
}