﻿using Binean.Private;
using System.Diagnostics;

namespace Binean.Foundation.Primitive {
    [CEntity]
    public abstract class Writer : IDisposable {
        private readonly List<Node> _stack = [];
        private readonly NodeResolve _resolve;

        private Action? _disposedAction;
        protected Node? _rootNode;
        private Deserialize _deserialize;
        private Node? _blockNode;

        internal protected object? _content;
        private IEntity _context = Dummy.Entity;

        protected Writer() {
            _resolve = OnNodeResolve;
            _deserialize = WriteException;
            ListType = ListType.Default;
        }

        ~Writer() {
            Dispose(false);
        }
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing) {
            if (disposing) {
                if (_disposedAction != null) {
                    _disposedAction.Invoke();
                    _disposedAction = null;
                }
            }
        }

        public bool CanContinue { get; protected set; }

        [CProp]
        public ListType ListType { get; set; }

        public bool Write(Token token) {
            if (token.Type.IsControl()) {
                WriteControl(_context, token);
                return true;
            }

            if (!CanContinue) {
                _deserialize = WriteException;
                return false;
            }

            if (_blockNode is null || token is null || token.IsDummy) return Clear();

            var node = OnDeserialize(_resolve, ref _deserialize, _blockNode, token);
            var nodeType = node.Type;
            if (nodeType.IsBlock()) {
                Debug.Assert(_blockNode != null);
                _stack.Add(_blockNode);
                _blockNode = node.Lock();
                return true;
            }
            if (nodeType.IsEndBlock()) {
                Debug.Assert(_blockNode != null);
                if (_blockNode.Level == -1) return Clear();
                var index = _stack.Count - 1;
                var cNode = _stack[index];
                _stack.RemoveAt(index);
                _blockNode = cNode.Lock();
                return true;
            }
            if (node.IsDummy) return Clear();
            return true;
        }

        private bool Clear() {
            _stack.Clear();
            _blockNode = null;
            _deserialize = WriteException;
            CanContinue = false;
            return true;
        }

        protected void Initialize(Node rootNode, Deserialize deserialize, Action? disposedAction) {
            if (_rootNode != null || _disposedAction != null) {
                throw MessageStorage.CreateException(nameof(Logs.BFND2062E));
            }
            _disposedAction = disposedAction;
            _deserialize = deserialize;

            _stack.Clear();
            _rootNode = rootNode;
            _blockNode = _rootNode.Lock();
            CanContinue = _blockNode != null;
        }

        public virtual void Write(Reader reader) {
            if (reader.IsNullOrEmpty() || !CanContinue) return;
            try {
                var context = _context = BuildContext();

                WriteControl(context, Token.CreateControlToken(Properties.ListType, reader.ListType));
                //if (reader.NameCase != NameCase.NotSet) WriteControl(context, Token.CreateControlToken(Properties.FromCase, reader.NameCase));

                var token = reader.Read();
                if (token.IsDummy) return;

                token.AssertLevel(0);
                if (!Write(Extension.ChangeContext(token, context))) return;

                while (reader.CanRead && CanContinue) {
                    token = reader.Read();
                    if (!Write(Extension.ChangeContext(token, context)) || token.IsDummy) break;
                }
            } finally {
                _context = Dummy.Entity;
            }
        }

        protected virtual IEntity BuildContext() {
            var context = Prior.CreateQEntity();
            context.QSet(Properties.ListType, ListType);
            return context;
        }
        protected virtual void WriteControl(IEntity context, Token token) {
            var name = token.Name;
            if (!token.Potential.TryGetValue(name, out var value)) return;
            context.Set(name, value, false);
            if (name == Properties.ListType && value is ListType listType) {
                if (ListType == listType) return;
                OnWriteListType(ListType = listType);
            }
        }

        protected virtual void OnWriteListType(ListType listType) { }

        protected virtual void Close() { }
        protected Node OnDeserialize(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            OnCookToken(block, token);
            var node = token.Type == NodeType.Define ? OnDefine(resolve, ref deserialize, block, token)
                : token.Type == NodeType.Redefine ? OnRedefine(resolve, ref deserialize, block, token)
                : deserialize(resolve, ref deserialize, block, token);
            return node;
        }

        protected virtual Node OnDefine(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            var ent = Prior.CreateQEntity();
            _context.QSet(token.Name, ent);
            return block.AddItem(new DefineNode(ent, ref deserialize, token));
        }
        protected virtual Node OnRedefine(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (!_context.TryGetNotNull(token.Name, out IEntity? ent)) {
                ent = Prior.CreateQEntity();
                _context.QSet(token.Name, ent);
            }
            return block.AddItem(new DefineNode(ent, ref deserialize, token));
        }
        protected virtual void OnCookToken(Node block, Token token) { }
        protected virtual Node OnNodeResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token node) => Node.DummyNode;

        public object? GetContent() {
            Close();
            return _content;
        }
        public Node WriteEof(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(resolve != null);
            Debug.Assert(block != null);
            Debug.Assert(token != null);
            deserialize = WriteException;
            return Node.DummyNode;
        }
        public Node WriteException(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            deserialize = WriteException;
            throw this.CreateException(nameof(Logs.BFND2061E));
        }
        public static Writer CreateDummy(Action? disposedAction = null)
            => new DummWriter(disposedAction);
    }
    file static class Properties {
        public static readonly Bsid ListType = nameof(ListType);
    }
}
