﻿using System.Diagnostics;

namespace Binean.Foundation.Primitive {
    public class Token : Node {
        public static readonly Token Eof = new(Dummy.Entity);
        private IGetter? _context;

        public Token(NodeType type, object? value = null, Bsid? name = null) : base(type, value, name) { }
        public Token(IEntity ent) : base(ent) { }

        protected override void OnClassChanged(BClass? value) {
            if (this.IsReadonly()) return;
            base.OnClassChanged(value);
        }

        public void ChangeType(NodeType type) => Potential.SetNodeType(type);
        public void ChangeName(Bsid name) => Potential.SetName(name);
        public void ChangeValue(object? value) => Potential.SetValue(value);

        public void ChangeContext(IGetter context) {
            if (this.IsReadonly() || IsDummy || IsEnd) return;
            if (_context != null) {
                if (Class is BClass bcls && bcls.Context == _context) bcls.Context = null;
            }
            _context = context;
            if (Class is BClass bcls1) bcls1.Context = _context;
            if (_latent is not DEntity dent) _latent = new DEntity(_context, _latent);
            else dent.ChangeSource(_context);
        }

        public void RemoveSource() {
            if (this.IsReadonly() || IsDummy || IsEnd) return;
            if (_latent is DEntity dent) _latent = dent.Entity;
        }
        public Token NewToken(NodeType tokenType, object? value = null, Bsid? name = null)
            => AddItem(new Token(tokenType, value, name));
        public Token EndToken() => AddItem(new Token(_endEntity));

        public static Token CreateControlToken(Bsid name, object? value = null) {
            var retVal = new Token(NodeType.Control, name: name);
            retVal.Potential.QSet(name, value);
            return retVal;
        }

        public Token UpdateLevelIndex(int level, int index) {
            if (!this.IsReadonly()) {
                Level = level;
                Index = index;
            }
            return this;
        }
    }
    public abstract class Sertoken : Token {
        private readonly Serialize _serialize;
        public Sertoken(Serialize serialize, NodeType type, object? value = null, Bsid? name = null)
            : base(type, value, name) {
            _serialize = serialize;
        }
        public Sertoken(Serialize serialize, IEntity ent) : base(ent) {
            _serialize = serialize;
        }

        public virtual Token ReadEndBlock(TokenResolve resolve, ref Serialize serialize, Token block) {
            Debug.Assert(block == this);
            serialize = _serialize;
            return block.EndToken();
        }
        public virtual Token ReadEof(TokenResolve resolve, ref Serialize serialize, Token block) {
            Debug.Assert(block == this);
            serialize = _serialize;
            return Eof;
        }

        protected void MoveBack(ref Serialize serialize) => serialize = _serialize;
        protected Token ReadBack(TokenResolve resolve, ref Serialize serialize, Token block)
            => _serialize(resolve, ref serialize, block);
    }
}
