﻿using System.Diagnostics;

namespace Binean.Foundation.Primitive {
    public class Node : BEntity {
        public static readonly Node DummyNode = new(Dummy.Entity);
        protected static readonly IEntity _endEntity = Dummy.CreateEntity();

        public Node() : base() { }
        public Node(NodeType type, object? value = null, Bsid? name = null) : base(Prior.CreateQEntity().SetNodeType(type).SetName(name ?? Bsid.Nothing).SetValue(value)) { }
        public Node(IEntity? entity) : base(entity ?? Prior.CreateQEntity()) { }

        public int Level { get; protected set; } = -1;
        public int Index { get; protected set; } = -1;
        public int ItemIndex { get; private set; } = -1;

        public Node? Parent { get; private set; }
        public virtual string Path {
            get {
                if (_path != null) return _path;
                var parentPath = Parent?.Path;
                return _path = Level < 1 ? string.Empty
                    : Name.IsNothing ? string.IsNullOrWhiteSpace(parentPath) ? $"[{Index}]" : $"{parentPath}[{Index}]"
                    : string.IsNullOrWhiteSpace(parentPath) ? (string)Name : $"{parentPath}{PathSeparators.Member}{Name}";
            }
        }
        private string? _path;

        public bool IsEnd => Potential == _endEntity;
        public NodeType Type => IsEnd ? NodeType.End : Potential.GetNodeType();
        public Bsid Name => Potential.GetName();
        public object? Value => Potential.GetValue();

        public virtual T AddItem<T>(T node) where T : Node {
            if (node.IsDummy) throw new InvalidOperationException();
            node.Parent = this;
            node.Level = Level + 1;
            if (node.Type.IsDefineOrControl()) node.Index = ItemIndex;
            else node.Index = ++ItemIndex;
            return node;
        }
        public Node EndNode() => AddItem(new Node(_endEntity));
    }

    public abstract class DesNode : Node {
        private readonly Deserialize _deserialize;
        protected DesNode(Deserialize deserialize, NodeType kind, object? value = null, Bsid? name = null)
            : base(kind, value, name) {
            _deserialize = deserialize;
        }
        public virtual Node WriteEndBlock(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(resolve != null);
            Debug.Assert(token.Type.IsEndBlock());
            Debug.Assert(this == block);
            deserialize = _deserialize;
            return block.EndNode();
        }
    }
    public sealed class DefineNode : DesNode {
        private readonly IEntity _ent;
        public DefineNode(IEntity entity, ref Deserialize deserialize, Token token)
            : base(deserialize, token.Type, entity, token.Name) {
            _ent = entity;

            deserialize = WriteItem;
        }
        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _ent.AValidate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var node = resolve(resolve, ref deserialize, block, token);
            if (node.IsDummy) return block.AddItem(token.Skip(ref deserialize));

            _ent.Set(node.Name, node.Value, true);
            return block.AddItem(node);
        }
    }
    public enum NodeType {
        None = 0,
        Define,
        Redefine,
        Object,
        Array,
        Value,
        End,
        Control,
    }
}
