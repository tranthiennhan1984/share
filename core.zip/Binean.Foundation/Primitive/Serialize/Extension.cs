﻿using Binean.Private;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Primitive {
    static partial class Extension {

        #region :: NodeType Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsBlock(this NodeType nodeType) => nodeType == NodeType.Object || nodeType == NodeType.Array || nodeType == NodeType.Define || nodeType == NodeType.Redefine;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsDefineOrControl(this NodeType nodeType) => nodeType == NodeType.Define || nodeType == NodeType.Redefine || nodeType == NodeType.Control;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEndBlock(this NodeType nodeType) => nodeType == NodeType.End;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsArray(this NodeType nodeType) => nodeType == NodeType.Array;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsObject(this NodeType nodeType) => nodeType == NodeType.Object;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsValue(this NodeType nodeType) => nodeType == NodeType.Value;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsData(this NodeType nodeType) => nodeType == NodeType.Value || nodeType == NodeType.Object || nodeType == NodeType.Array;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsControl(this NodeType nodeType) => nodeType == NodeType.Control;
        #endregion

        #region :: Token Helper ::

        [DebuggerStepThrough]
        [Conditional("DEBUG")]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void AssertLevel(this Token token, int expected)
            => Debug.Assert(token.Level == expected);

        [DebuggerStepThrough]
        [Conditional("DEBUG")]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void AssertTokenType(this Token token, NodeType expected)
            => Debug.Assert(token.Type == expected);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bsid AssertTokenName(this Node block, Bsid name) {
            var tokenType = block.Type;
            if (tokenType.IsObject() && name.IsNothing) throw MessageStorage.CreateException(nameof(Logs.BFND202CE));
            if (tokenType.IsArray() && !name.IsNothing) throw MessageStorage.CreateException(nameof(Logs.BFND202DE));
            return name;
        }

        //public static T SetClass<T>(this T token, string? cls) {
        //    if (cls is null) return token;
        //    if (cls is string txt) {
        //        if (txt is { Length: > 255 }) throw MessageStorage.CreateException(nameof(Logs.BFND20213E), cls);
        //        if (string.IsNullOrWhiteSpace(txt)) return token;
        //    }
        //    if (token is Token t) t.ChangeClass(cls);
        //    else if (token is IClassed tg) tg.Class = cls;
        //    return token;
        //}

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Node Skip(this Token token, ref Deserialize deserialize) {
            var tokenType = token.Type;
            if (tokenType.IsValue()) return new Node(token.Box());
            if (tokenType.IsBlock()) return new DummyNode(ref deserialize, token.Type, token.Name);
            throw MessageStorage.CreateException(nameof(Logs.BFND202BE), token);
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Token AddVirtualToken(this Token block, ref Serialize serialize, NodeType tokenType, Bsid? name = null, Serialize? next = null)
            => block.AddItem(new VirtualToken(ref serialize, tokenType, name ?? Bsid.Nothing, next));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T ChangeContext<T>(this T token, IGetter context) where T : Token {
            token.ChangeContext(context);
            return token;
        }
        #endregion

        #region :: Properties Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static NodeType GetNodeType(this IEntity entity) => entity.QGet(Properties.Type, NodeType.None);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetNodeType<T>(this T entity, NodeType type) where T : IEntity => entity.QSet(Properties.Type, type);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bsid GetName(this IEntity entity) => entity.QGet(Properties.Name, Bsid.Nothing);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetName<T>(this T entity, Bsid name) where T : IEntity => entity.QSet(Properties.Name, name);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? GetValue(this IEntity entity) => entity.QGet(Properties.Value);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetValue<T>(this T entity, object? value) where T : IEntity => entity.QSet(Properties.Value, value);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? GetNext<T>(this IEntity entity) => entity.QGet<T>(Properties.Next);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetNext<T>(this T entity, object? value) where T : IEntity => entity.QSet(Properties.Next, value);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? GetValueType<T>(this IEntity entity) => entity.QGet<T>(Properties.ValueType);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? GetValueType(this IEntity entity) => entity.QGet(Properties.ValueType);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetValueType<T>(this T entity, object? value) where T : IEntity => entity.QSet(Properties.ValueType, value);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T MSetValueType<T>(this T entity, object? value) where T : IEntity => entity.MSet(Properties.ValueType, value);
        #endregion
    }
    file static class Properties {
        public static readonly Bsid Type = nameof(Type);
        public static readonly Bsid Name = nameof(Name);
        public static readonly Bsid Value = nameof(Value);

        public static readonly Bsid Next = nameof(Next);

        public static readonly Bsid ValueType = nameof(ValueType);
    }
}
