﻿using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Binean.Foundation.Primitive {
    public sealed class Bip {
        private readonly List<Bsid> _bids = [];
        private Bip() { }
        public Bip(Bsid bid) {
            AddItem(bid);
        }
        public Bsid this[int index] => _bids[index];
        public int Count => _bids.Count;
        public Bip Add(Bip prop) {
            if (prop.IsEmpty()) return this;
            var length = prop.Count;
            for (int i = 0; i < length; i++) {
                _bids.Add(prop[i]);
            }
            return this;
        }
        public Bip AddItem(Bsid bid) {
            if (bid.IsNothing) return this;
            _bids.Add(bid);
            return this;
        }
        public Bip Remove(int index) {
            _bids.RemoveAt(index);
            return this;
        }

        public override string ToString() => ToString(PathSeparators.Member);
        public Bsid Peek() => _bids.Count == 0 ? Bsid.Nothing : _bids[0];
        public Bsid Pop() {
            if (_bids.Count == 0) return Bsid.Nothing;
            var retVal = _bids[0];
            _bids.RemoveAt(0);
            return retVal;
        }
        public Bip Clone(int index = 0, int length = -1) {
            if (length > 0) length = index + length;
            if (length < 0 || length > _bids.Count) length = _bids.Count;
            var retval = new Bip();
            var props = retval._bids;
            for (int i = index; i < length; i++) {
                props.Add(_bids[i]);
            }
            return retval;
        }
        public Bip? GetParentPath(out Bsid name) {
            if (Count == 0) {
                name = Bsid.Nothing;
                return null;
            }
            if (Count == 1) {
                name = _bids[0];
                return null;
            }

            var length = Count - 1;
            name = _bids[length];
            var retval = new Bip();
            for (int i = 0; i < length; i++) {
                retval.Add(new(_bids[i]));
            }
            return retval;
        }
        public void Scan(Func<Bsid, bool> action, int from = 0, int to = -1) {
            if (to < 0 || to >= _bids.Count) to = _bids.Count - 1;
            for (var i = from; i <= to; i++) {
                if (!action(_bids[i])) break;
            }
        }

        public static Bip CreateEmpty() => new();
        public static bool TryParse(string? text, [NotNullWhen(true)] out Bip? path, char? memberSeparator = null) {
            if (string.IsNullOrWhiteSpace(text = text?.Trim())) return (path = null) != null;
            path = new Bip();

            memberSeparator ??= PathSeparators.Member;

            var ends = $"{memberSeparator}\0";
            using (var reader = text.CreateTextReader()) {
                while (true) {
                    var chr = reader.Current;
                    if (chr == memberSeparator) {
                        reader.MoveNext();
                        continue;
                    }
                    if (chr == BetextReader.EofCharacter) break;
                    var name = reader.ReadUntil(endCond: ends.Contains, errCond: "\r\n".Contains, expected: memberSeparator);
                    if (string.IsNullOrWhiteSpace(name)) return (path = null) != null;
                    path.Add(new Bip((Bsid)name));
                }
            }
            return path.Count > 0;
        }
        public string ToString(char? memberSeparator) {
            var sb = new StringBuilder();
            var length = _bids.Count;
            for (int i = 0; i < length; i++) {
                sb.Append(memberSeparator).Append(_bids[i]);
            }
            if (sb.Length > 0) sb.Remove(0, 1);
            return sb.ToString();
        }
    }

    public class PathSeparators {
        public const char Member = '/';
        public const char Method = '#';
    }
}

