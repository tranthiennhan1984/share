﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Binean.Foundation.Primitive;

namespace Binean.Foundation.Data {
    public static partial class Extension {
        #region :: PropPath Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEmpty([NotNullWhen(false)] this Bip path) => path.Count == 0;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty([NotNullWhen(false)] this Bip? path)
            => path is null || path.Count == 0;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bip? ToPropath(this object obj, bool assert = true)
            => obj is Bip path ? path
                : obj is not string str ? null
                : Bip.TryParse(str, out Bip? p2) ? p2
                : assert ? throw MessageStorage.CreateException(nameof(Primitive.Logs.BFND202AE), str)
                : null;

        public static T? GetParent<T>(this T? getter, Bip? path, out Bsid bid) where T : IGettable {
            if (getter is null || path is null) {
                bid = Bsid.Nothing;
                return default;
            }
            if (path.Count == 0) {
                bid = Bsid.Nothing;
                return getter;
            }
            if (path.Count == 1) {
                bid = path[0];
                return getter;
            }
            var ent = getter;
            path.Scan(n => {
                if (ent.QGet(n).ToGettable() is not T v) {
                    ent = default;
                    return false;
                }
                ent = v;
                return true;
            }, 0, path.Count - 2);
            bid = ent is null ? Bsid.Nothing : path[^1];
            return ent;
        }
        public static bool TryRead(this IGettable? getter, Bip? path, out object? value) {
            var p = getter.GetParent(path, out Bsid bid);
            if (p is null || bid.IsNothing) return (value = null) != null;
            return p.TryGetValue(bid, out value);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Read(this IGettable? getter, Bip? path)
            => TryRead(getter, path, out object? value) ? value : null;

        #endregion
    }
}
