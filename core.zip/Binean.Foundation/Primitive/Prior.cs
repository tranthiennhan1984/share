﻿using Binean.Foundation.Private;
using Binean.Private;
using System.Collections;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq.Expressions;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Primitive {
    public static class Prior {
        #region :: Constant Helpers ::
        private static readonly Bib _names = new(ListType.Ordered);
        private static object _nameLock = new();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bsid Constant(this string name)
            => string.IsNullOrWhiteSpace(name) ? Bsid.Nothing : InConstant((Bsid)name, true);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bsid Constant(this Bsid bid, bool reused = true) => bid.Length == 0 ? bid : InConstant(bid, reused);
        private static Bsid InConstant(this Bsid bid, bool reused = false) {
            if (_names.Find(bid, out int index)) return _names[index];
            lock (_nameLock) {
                if (!reused) bid = bid.Clone();
                _names.Add(bid);
                return bid;
            }
        }

        private static readonly Func<string, string> _constCreator = BuildConstantCreator();
        private static Func<string, string> BuildConstantCreator() {
            ParameterExpression param = Expression.Parameter(typeof(string), "para");
            return Expression.Lambda<Func<string, string>>(param, param).Compile();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ToConstant(this string name)
            => _constCreator.Invoke(name);

        #endregion

        //#region :: Configs Helpers ::
        //[ThreadStatic]
        //private static Pconfig? _configs;
        //public static Pconfig Configs => _configs ??= new Pconfig();

        //public static bool CaseInsensitive => Configs.CaseInsensitive;
        //public static IDisposable? ConfigsScope(Pconfig configs) {
        //    if (_configs != null && _configs.Equals(configs)) return null;
        //    var old = _configs;
        //    _configs = configs;
        //    return new Disposable(() => _configs = old);
        //}
        //public static IDisposable CaseScope(bool caseInsensitive) {
        //    if (Configs.CaseInsensitive == caseInsensitive) return Dummy.Disposable;
        //    var old = _configs!.CaseInsensitive;
        //    _configs.CaseInsensitive = caseInsensitive;
        //    return new Disposable(() => {
        //        if (_configs != null) _configs.CaseInsensitive = old;
        //    });
        //}

        //#endregion

        #region :: NameList Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bib CreateNames(this ListType listType) => new(listType);
        /// <summary>
        /// Default Name List
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bib CreateNames() => new(ListType.Default);
        /// <summary>
        /// Orderred Name list
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bib CreateONames() => new(ListType.Ordered);
        /// <summary>
        /// Constant Name List
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bib CreateCNames() => new(ListType.Constant);
        /// <summary>
        /// (Normal) Orderred Singleton Name List
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bib CreateQNames() => new(ListType.Quick);


        public static bool TryConvertName<T>(this object? obj, [NotNullWhen(true)] out T? name) {
            if (obj is null) {
                name = default;
                return false;
            }

            var typeT = typeof(T);
            if (typeT == typeof(Bsid)) {
                var bid = obj.ToBid();
                obj = bid.IsNothing ? null : bid;
            }
            //if (typeT == typeof(tenid)) {
            //    var bic = obj.ToBic();
            //    obj = bic.IsNothing ? null : bic;
            //}
            if (typeT == typeof(string)) {
                var txt = obj?.ToString() ?? string.Empty;
                obj = string.IsNullOrEmpty(txt) ? null : txt;
            }

            name = obj is null ? default : (T)obj;
            return name != null;
        }
        public static INameList<T> CreateNames<T>(ListType listType) {
            var typeT = typeof(T);
            if (typeT == typeof(Bsid)) return (INameList<T>)(object)new Bib(listType);
            if (typeT == typeof(CodeId)) return (INameList<T>)(object)new Biq(listType);
            if (typeT == typeof(string)) return (INameList<T>)(object)new StringList(listType);
            throw MessageStorage.CreateException(nameof(Logs.BFND2012E), typeT);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameList<T> CreateNames<T>() => CreateNames<T>(ListType.Default);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameList<T> CreateONames<T>() => CreateNames<T>(ListType.Ordered);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameList<T> CreateCNames<T>() => CreateNames<T>(ListType.Constant);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static INameList<T> CreateQNames<T>() => CreateNames<T>(ListType.Quick);
        #endregion

        #region :: StringList Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StringList CreateStrings(this ListType listType, bool isUnique = true) => new(listType, isUnique);
        /// <summary>
        /// Default Name List
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StringList CreateStrings(bool isUnique = true) => new(ListType.Default, isUnique);
        /// <summary>
        /// Orderred Name list
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StringList CreateONames(bool isUnique = true) => new(ListType.Ordered, isUnique);
        /// <summary>
        /// Constant Name List
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StringList CreateCNames(bool isUnique = true) => new(ListType.Constant, isUnique);
        /// <summary>
        /// (Normal) Orderred Singleton Name List
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static StringList CreateQNames(bool isUnique = true) => new(ListType.Quick, isUnique);

        #endregion

        #region :: Lockable Helpers ::
        public static IWriteLock? GetLock(this object? obj) {
            if (obj is IWriteLock lck) return lck;
            if (obj is ILockable lcka) return lcka.Lock;
            return null;
        }
        public static INameLock? GetNameLock(this object? obj, string name) {
            if (obj is INameLock lck) return lck;
            if (obj is ILockable lcka) return lcka.Lock as INameLock;
            return null;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsReadonly(this object obj)
            => (obj.GetLock() is IWriteLock lck) && lck.Readonly();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Lock<T>(this T obj) {
            if (obj.GetLock() is IWriteLock lck) lck.Readonly(true);
            return obj;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Unlock<T>(this T obj) {
            if (obj.GetLock() is IWriteLock lck) lck.Readonly(false);
            return obj;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsReadonly(this object obj, string name)
            => (obj.GetNameLock(name) is INameLock lck) && lck.Readonly(name);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T NameLock<T>(this T obj, string name) {
            if (obj.GetNameLock(name) is INameLock lck) lck.Readonly(name, true);
            return obj;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T NameUnlock<T>(this T obj, string name) {
            if (obj.GetNameLock(name) is INameLock lck) lck.Readonly(name, false);
            return obj;
        }
        public static IDisposable? LockScope(this object obj) {
            if (obj.GetLock() is not IWriteLock lck) return null;
            if (lck.Readonly()) return Dummy.Disposable;
            lck.Readonly(true);
            return Generator.CreateDisposable(() => lck.Readonly(false));
        }
        public static IDisposable? NameLockScope(this object obj, string name) {
            if (obj.GetNameLock(name) is not INameLock lck) return null;
            if (lck.Readonly(name)) return Dummy.Disposable;
            lck.Readonly(name, true);
            return Generator.CreateDisposable(() => lck.Readonly(name, false));
        }
        #endregion

        #region :: Entity Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity Assert(this IEntity? entity) => entity ?? Dummy.Entity;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EGetter ToReadonly(this IEntity entity) => new(entity);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Entity CreateEntity() => new(ListType.Default);
        /// <summary>
        /// Sorted Constant Property Name Entity
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Entity CreateQEntity() => new(ListType.Quick);
        /// <summary>
        /// Constant Property Name Entity
        /// </summary>
        /// <param name="keepOrder"></param>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Entity CreateCEntity() => new(ListType.Constant);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Entity CreateEntity(this ListType listType) => new(listType);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Litity CreateLitity() => new();
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IList CreateList() => new List<object?>();


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IGetter? ToGetter(this object? obj) {
            if (obj is IGetter getter) return getter;
            return Box(obj);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ISetter? ToSetter(this object? obj) {
            if (obj is ISetter setter) return setter;
            return Box(obj);
        }

        public static T Assert<T>(this IEntity entity, Bsid name, Func<T> generator) {
            if (entity.TryGetValue(name, out object? obj) && obj is T retVal) return retVal;
            entity.Set(name, retVal = generator());
            return retVal;
        }


        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static IList AssertList(this IEntity entity, Bid name)
        //    => entity.Assert(name, CreateLitity);

        //public static IEntity AssertEntity(this object? obj, Bid contentProp) {
        //    if (obj.Box() is IEntity ent) return ent;
        //    contentProp ??= Properties.Content;
        //    ent = CreateEntity();
        //    if (obj != null && !contentProp.IsDummy) ent.Set(contentProp, obj);
        //    return ent;
        //}
        //public static IList AssertList(this object? obj, string name) {
        //    if (obj is IList retVal) return retVal;

        //    retVal = CreateLitity();
        //    if (obj != null) retVal.Add(obj);
        //    return retVal;
        //}

        ////public static IConnector Swap(this IEntity entity, string name, ISetter value) {
        ////    value ??= Dummy.Entity;

        ////    if (!entity.TryGet(name, out object? source)) source = DBNull.Value;
        ////    entity.Set(name, value);
        ////    return new Connector(value, (source as IGetter) ?? Dummy.Entity, e => {
        ////        entity.Set(name, source);
        ////    });
        ////}
        public static IDisposable Swap(this IEntity entity, Bsid bid, object? value, bool condition = true) {
            if (!condition) return Dummy.Disposable;
            if (!entity.TryGetValue(bid, out object? source)) source = DBNull.Value;
            entity.Set(bid, value);
            return new Disposable(() => {
                if (source == DBNull.Value) entity.Remove(bid);
                else entity.Set(bid, source);
            });
        }

        public static IEntity? AssertParent(this IEntity? ent, Bip? path, out Bsid bid) {
            if (ent is null || path is null) {
                bid = Bsid.Nothing;
                return default;
            }
            if (path.Count == 0) {
                bid = Bsid.Nothing;
                return ent;
            }
            if (path.Count == 1) {
                bid = path[0];
                return ent;
            }
            var c = ent;
            path.Scan(n => {
                if (c.QGet(n).ToPEntity() is not IEntity v) {
                    v = CreateEntity();
                    c.Set(n, v);
                }
                c = v;
                return true;
            }, 0, path.Count - 2);
            bid = c is null ? Bsid.Nothing : path[^1];
            return c;
        }
        public static bool Update(this IEntity? entity, Bip? path, object? value, bool guarantee = true, bool assert = true) {
            var p = assert ? entity.AssertParent(path, out Bsid bid) : entity.GetParent(path, out bid);
            if (p is null || bid.IsNothing) return false;
            p.Set(bid, value, guarantee);
            return true;
        }
        public static bool Delete(this IEntity? entity, Bip? path, bool guarantee = true) {
            var p = entity.GetParent(path, out Bsid bid);
            if (p is null) return false;
            if (bid.IsNothing) p.Clear();
            p.Remove(bid, guarantee);
            return true;
        }

        #endregion

        #region :: BEntity Helpers ::

        [ThreadStatic]
        private static IEntity? _bentity;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity GetBEntityData() => _bentity ?? new Entity(ListType.Default);

        private static IDisposable BEntityScope(IEntity? entity) {
            if (_bentity == entity) return Dummy.Disposable;
            var old = _bentity;
            _bentity = entity;
            return new Disposable(() => _bentity = old);
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity? Box(this object? obj)
            => obj.TryBox(out IEntity? ent) ? ent : null;

        public static IEntity? ToPEntity(this object? obj)
            => obj.TryBox(out IEntity? ent) ? ent
            : obj is IList list ? new Listity(list)
            : null;
        public static bool TryBox(this object? obj, [NotNullWhen(true)] out IEntity? ent) {
            if (obj is null) return (ent = null) != null;

            if (obj is IEntity entity) return (ent = entity) != null;
            if (obj is IBoxabl boxabl) return (ent = boxabl.Box()) != null;

            if (CEntity.TryBox(obj, out ent)) return true;
            return (ent = null) != null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Unbox<T>(this object value, bool validate = true)
            => TryUnbox(value, out T? ent, validate) ? ent : default;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Unbox<T>(this IEntity entity, bool validate = true)
            => TryUnbox(entity, out T? bEntity, validate) ? bEntity : throw MessageStorage.CreateException(nameof(Logs.BFND2011E), entity, typeof(T));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryUnbox<T>(this object? value, [NotNullWhen(true)] out T? obj, bool validate = true) {
            if (value is null) return (obj = default) != null;
            if (value is T t) return (obj = t) != null;
            if (value.Box() is not IEntity entity) return (obj = default) != null;
            var type = typeof(T);
            if (entity is IClassed clsed && clsed.Class?.ToType() is Type ct && type.IsAssignableFrom(ct)) type = ct;
            if (!InTryUnbox(entity, type, out object? o, validate)) return (obj = default) != null;
            if (o is T ot) return validate ? (obj = ot) != null : (obj = ot).AValidate() != null;
            return (obj = default) != null;
        }
        public static bool TryUnbox<T>(this IEntity? entity, [NotNullWhen(true)] out T? obj, bool validate = true) {
            if (entity is null) return (obj = default) != null;
            if (entity is T retVal) return validate ? (obj = retVal) != null : (obj = retVal).AValidate() != null;
            var type = typeof(T);
            if (entity is IClassed clsed && clsed.Class?.ToType() is Type t && type.IsAssignableFrom(t)) type = t;
            if (!InTryUnbox(entity, type, out object? o, validate)) return (obj = default) != null;
            if (o is T ot) return validate ? (obj = ot) != null : (obj = ot).AValidate() != null;
            return (obj = default) != null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Unbox(this object? value, Type type, bool validate = true)
            => TryUnbox(value, type, out object? obj, validate) ? obj : null;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Unbox(this IEntity? entity, Type type, bool validate = true)
            => TryUnbox(entity, type, out object? obj, validate) ? obj : null;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryUnbox(this object? value, Type type, [NotNullWhen(true)] out object? obj, bool validate = true) {
            if (value is null) return (obj = null) != null;
            if (type.IsAssignableFrom(value.GetType())) return validate ? (obj = value) != null : (obj = value).AValidate() != null;
            if (value.Box() is not IEntity entity) return (obj = null) != null;
            if (entity is IClassed clsed && clsed.Class?.ToType() is Type t && type.IsAssignableFrom(t)) type = t;
            return InTryUnbox(entity, type, out obj, validate);
        }
        public static bool TryUnbox(this IEntity? entity, Type type, [NotNullWhen(true)] out object? obj, bool validate = true) {
            if (entity is null) return (obj = null) != null;
            if (type.IsAssignableFrom(entity.GetType())) return validate ? (obj = entity) != null : (obj = entity).AValidate() != null;
            if (entity is IClassed clsed && clsed.Class?.ToType() is Type t && type.IsAssignableFrom(t)) type = t;
            return InTryUnbox(entity, type, out obj, validate);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Unbox(this IEntity? entity, bool validate = true)
            => TryUnbox(entity, out object? obj, validate) ? obj : null;
        public static bool TryUnbox(this IEntity? entity, [NotNullWhen(true)] out object? obj, bool validate = true) {
            if (entity is not IClassed clsed || clsed.Class?.ToType() is not Type type) return (obj = entity) != null;
            return InTryUnbox(entity, type, out obj, validate);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Unbox(this object? entity, bool validate = true)
            => TryUnbox(entity, out object? obj, validate) ? obj : null;
        public static bool TryUnbox(this object? value, [NotNullWhen(true)] out object? obj, bool validate = true) {
            if (value is null) return (obj = null) != null;
            if (value.Box() is not IEntity entity) return (obj = value) != null;
            if (entity is not IClassed clsed || clsed.Class?.ToType() is not Type type) return (obj = value) != null;
            return InTryUnbox(entity, type, out obj, validate);
        }
        private static bool InTryUnbox(this IEntity entity, Type type, [NotNullWhen(true)] out object? obj, bool validate = true) {
            try {
                using (BEntityScope(entity)) {
                    if ((obj = Generator.CreateInstance(type)) is null) return false;
                }
                if (obj is IBoxabl boxabl) boxabl.Unbox(entity);
                else if (obj.ToSetter() is ISetter setter) setter.Assign(entity, validate: validate);
                return true;
            } catch (Exception ex) {
                Debug.WriteLine(ex.Correct().ToString());
                throw;
            }
        }
        #endregion

        #region :: Organ Helpers ::
        public static IPlugin ToPlugin(this ICell cell) => new CellPlugin(cell);
        #endregion

        #region :: Flow Helpers ::
        public static bool TryGetValue(this object? obj, Bsid bid, out object? value) {
            if (bid.IsNothing) return (value = null) != null;
            if (obj is IGettable gt) return gt.TryGetValue(bid, out value);
            if (obj is IACell aCell) return aCell.Cells.TryGetValue(bid, out value);
            if (obj.ToGetter() is IGettable gt2) return gt2.TryGetValue(bid, out value);
            return (value = null) != null;
        }
        public static IGettable ToGettable(this object? obj) => new Gettable(obj.TryGetValue);
        #endregion
    }

    //public class Pconfig : IEquatable<Pconfig> {
    //    public NameType EType { get; set; } = NameType.Default;
    //    public bool CaseInsensitive { get; set; } = false;
    //    public bool Equals(Pconfig? other) {
    //        if (other is null) return false;
    //        return EType == other.EType && CaseInsensitive == other.CaseInsensitive;
    //    }
    //    public override bool Equals(object? obj) {
    //        if (obj is null) return false;
    //        if (ReferenceEquals(this, obj)) return true;
    //        return Equals(obj as Pconfig);
    //    }
    //    public override int GetHashCode() => (EType, CaseInsensitive).GetHashCode();
    //}
    file static class Properties {
        public static Bsid Content = nameof(Content);
    }
}
