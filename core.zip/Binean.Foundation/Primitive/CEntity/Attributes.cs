﻿namespace Binean.Foundation.Primitive {
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public class CEntityAttribute : Attribute {
        public string Class { get; set; } = string.Empty;
        public Type? CType { get; set; }
        public bool IsList { get; set; }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class CPropAttribute : Attribute {
        public object DefaultValue { get; set; } = DBNull.Value;
        public bool ReadHidden { get; set; }
        public bool ReadSkip { get; set; }
        public bool WriteOver { get; set; }
        public bool WriteHidden { get; set; }
        public bool WriteSkip { get; set; }
        public string? Description { get; set; }
    }

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public class CMemberAttribute : CPropAttribute {
        public string MemberName { get; set; } = default!;
    }

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public class EPropsAttribute : Attribute {
        public EPropsAttribute() { }
        public EPropsAttribute(string name) { PropertName = name; }
        public string? PropertName { get; set; }
    }
}
