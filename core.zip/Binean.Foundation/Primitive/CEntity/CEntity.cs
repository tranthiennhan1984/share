﻿using Binean.Private;
using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;

namespace Binean.Foundation.Primitive {
    public sealed class CEntity(CEntityType entityType, object instance) : IEntity, IValidator, IClassed, INames<Bsid>, IWriteLock {
        private readonly CEntityType _entityType = entityType;
        private readonly object _instance = instance;
        private bool _isLocked;

        public bool IsEmpty => false;

        public BClass? Class {
            get => _instance is IClassed clsed ? clsed.Class : _class ?? _entityType.Class;
            set {
                if (_instance is IClassed clsed) clsed.Class = value;
                else _class = value;
            }
        }
        private BClass? _class;

        public INameSet<Bsid> Names => GetNames();

        public bool TryGetValue(Bsid bid, out object? value) => _entityType.TryGetValue(_instance, bid, out value);
        public bool TrySetValue(Bsid bid, object? value) {
            if (_isLocked || bid.IsNothing) return false;
            if (value is DBNull) return _entityType.TryRemoveValue(_instance, bid);
            return _entityType.TrySetValue(_instance, bid, value);
        }
        public bool Clear() => !_isLocked && _entityType.TryClear(_instance);
        public bool TryRemoveValue(Bsid bid) => !_isLocked && _entityType.TryRemoveValue(_instance, bid);
        public void ChangeDisplayBid(Bsid bid) { }

        private INameSet<Bsid> GetNames() => _entityType.GetterNames;
        private IEnumerable<IUnit> GetUnits() {
            var names = _entityType.GetterNames;
            foreach (var name in names) {
                if (!TryGetValue(name, out var value)) continue;
                yield return new Unit(name, value);
            }
        }

        public IEnumerator<IUnit> GetEnumerator() => GetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetUnits().GetEnumerator();
        public bool Validate(ILogger logger) => (_instance as IValidator)?.Validate(logger) ?? true;

        private static IEntity? Box(object obj) {
            if (obj is IProspective evolvable) return new CoverEntity(obj, evolvable.Potential);
            return obj is IDictionary dict ? new Dictity(dict) : null;
        }
        public static bool TryBox(object obj, [NotNullWhen(true)] out IEntity? ent) {
            var otype = obj.GetType();
            if (otype.GetCustomAttribute<CEntityAttribute>() is null) return (ent = Box(obj)) != null;
            if (!CEntityType.TryCreate(otype, out CEntityType? ctype)) return (ent = Box(obj)) != null;

            ent = new CEntity(ctype, obj);
            if (obj is IProspective evol) {
                var skips = ctype.ReadSkips;
                ent = new LatentEntity(ent, evol.Potential, skips.IsNullOrEmpty() ? null : skips.Contains);
            }
            return true;
        }

        public bool Readonly(bool? readOnly = null) {
            if (readOnly != null) _isLocked = readOnly.Value;
            return _isLocked;
        }

    }

    public sealed class CEntityType {
        private const int TypeCapacity = 300;
        private static readonly List<CEntityType> _types = new(TypeCapacity);
        private static readonly object _lock = new();

        private readonly CEntityAttribute _cea;
        private readonly Entity _getters = Prior.CreateQEntity();
        private readonly Entity _setters = Prior.CreateQEntity();
        private readonly IEntity _members = Prior.CreateQEntity();
        private readonly IEntity _propTypes = Prior.CreateQEntity();
        private readonly Entity _writeOvers = Prior.CreateQEntity();
        private readonly Bib _readSkips = Prior.CreateQNames();
        private readonly Bib _writeHiddens = Prior.CreateQNames();

        public CEntityType(Type declareType) {
            DeclareType = declareType;
            _cea = LoadMembers(declareType, _members, _getters, _setters, _propTypes, _readSkips, _writeHiddens, _writeOvers);
            if (!string.IsNullOrWhiteSpace(_cea.Class)) Class = BClass.CreateClass((Bsid)_cea.Class);
        }

        public Type DeclareType { get; }

        public BClass? Class { get; private set; }
        public INameSet<Bsid> GetterNames => _getters.Names;
        public INameSet<Bsid> SetterNames => _setters.Names;
        public INameSet<Bsid> ReadSkips => _readSkips;
        public INameSet<Bsid> WriteHiddens => _writeHiddens;

        public bool TryGetValue(object instance, Bsid name, out object? value) {
            if (_getters.QGet(name) is not GetterDelegate getter) return (value = null) != null;
            return getter(instance, out value);
        }
        public bool TrySetValue(object instance, Bsid name, object? value) {
            if (_writeOvers.QGet(name) is GetterDelegate getter) {
                if (!getter(instance, out object? v)) return false;
                if (v == value) return true;

                if (v is ISetter s && value is IGetter g) {
                    s.Assign(g, false, true);
                    return true;
                }
                return false;
            }
            if (_setters.QGet(name) is SetterDelegate setter) {
                return setter(instance, value);
            }
            return false;
        }
        public bool TryRemoveValue(object instance, Bsid name) {
            if (_writeOvers.QGet(name) is GetterDelegate getter) {
                if (!getter(instance, out object? v)) return false;
                if (v is ISetter s) return s.Clear();
                return false;
            }
            if (_setters.QGet(name) is SetterDelegate setter) {
                return setter(instance, GetDefault(name));
            }
            return false;
        }
        public bool TryClear(object instance) {
            foreach (var name in _setters.Names) {
                TryRemoveValue(instance, name);
            }
            return true;
        }
        private object? GetDefault(Bsid name) {
            object? retVal;
            if (_members.TryGetNotNull(name, out CPropAttribute? att) && att.DefaultValue is not DBNull) retVal = att.DefaultValue;
            else if (_propTypes.TryGetNotNull(name, out Type? type)) retVal = type.DefaultValue();
            else retVal = null;
            return retVal;
        }

        public static bool TryCreate(Type type, [NotNullWhen(true)] out CEntityType? centityType) {
            lock (_lock) {
                var length = _types.Count;
                for (int i = 0; i < length; i++) {
                    var t = _types[i];
                    if (t.DeclareType == type) {
                        centityType = t;
                        _types.RemoveAt(i);
                        _types.Insert(0, t);
                        return true;
                    }
                }
            }
            if (type.GetCustomAttribute<CEntityAttribute>() is null) return (centityType = null) != null;
            centityType = new CEntityType(type);
            lock (_lock) {
                while (_types.Count + 1 >= TypeCapacity) _types.RemoveAt(_types.Count - 1);
                _types.Insert(0, centityType);
            }
            return true;
        }

        public static CEntityAttribute LoadMembers(Type type, IEntity members, IEntity getters, IEntity setters, IEntity props, Bib readSkips, Bib writeHiddens, IEntity writeOvers) {
            if (type.GetCustomAttribute<CEntityAttribute>() is not CEntityAttribute cea) throw new InvalidOperationException();

            var ceas = Prior.CreateEntity();
            foreach (var mt in type.GetCustomAttributes<CMemberAttribute>()) {
                ceas.Set(mt.MemberName.Constant(), mt);
            }

            var readFaulted = new GetterDelegate(ReadFaulted);
            var writeFaulted = new SetterDelegate(WriteFaulted);
            var writeSuccess = new SetterDelegate(WriteSuccess);

            foreach (var prop in type.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                var propName = prop.Name.Constant();
                if (prop.GetCustomAttribute<CPropAttribute>() is not CPropAttribute att) {
                    if (!ceas.TryGetNotNull(propName, out CMemberAttribute? mt)) continue;
                    att = mt;
                }
                members.Set(propName, att);
                if (att.ReadSkip) readSkips.Add(propName);
                if (att.WriteHidden) writeHiddens.Add(propName);

                var getter = att.ReadHidden || att.ReadSkip || !prop.CanRead ? readFaulted : prop.BuildGetAccessor();
                getters.Set(propName, getter);
                if (att.WriteOver) writeOvers.Set(propName, getter == readFaulted && prop.CanRead ? prop.BuildGetAccessor() : getter);

                var setter = att.WriteOver || att.WriteSkip ? writeSuccess
                    : att.WriteHidden || !prop.CanWrite ? writeFaulted
                    : prop.BuildSetAccessor() ?? writeFaulted;

                setters.Set(propName, setter);
                if (setter != writeFaulted) props.Set(propName, prop.PropertyType);
            }

            return cea;
        }
        private static bool ReadFaulted(object instance, out object? value) => (value = null) != null;
        private static bool WriteSuccess(object instance, object? value) => true;
        private static bool WriteFaulted(object instance, object? value) => false;

        public Node NodeResolve(object instance, NodeResolve resolve, ref Deserialize deserialize, Node block, Token token, bool guarantee) {
            if (!token.Type.IsValue() || token.Value is null) token.ChangeValue(GetValue(instance, token));

            var retVal = resolve(resolve, ref deserialize, block, token);
            if (retVal.IsDummy) return retVal;

            var name = retVal.Name;
            try {
                if (TrySetValue(instance, name, retVal.Value) && guarantee) return retVal;
                if (guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND2041E), name, instance);
                return Node.DummyNode;
            } catch {
                if (guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND2041E), name, instance);
                return Node.DummyNode;
            }
        }
        private object? GetValue(object instance, Token token) {
            var name = token.Name;
            if (_writeOvers.TryGetNotNull(name, out GetterDelegate? ogetter)) return ogetter(instance, out object? v) ? v : null;
            token.Potential.MSetValueType(() => _propTypes.QGet<Type>(name));
            return null;
        }
    }

    public delegate bool SetterDelegate(object instance, object? value);
    public delegate bool GetterDelegate(object instance, out object? value);
}