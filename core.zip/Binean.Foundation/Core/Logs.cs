﻿namespace Binean.Foundation.Core {
    [BLog]
    internal static class Logs {
        public const string BFND1011E = "Missing request path.";
        public const string BFND1012E = "Missing request method.";
        public const string BFND1013E = "Cannot convert request information to '{0}'.";
        public const string BFND1014E = "Missing context.";
        public const string BFND1015E = "Forbidden - you don't have permission to access/on this server.";
        public const string BFND1016E = "Not found.";
        public const string BFND1017E = "The request has been completed.";

        public const string BFND101AI = "Move to address '{0}'.";

        public const string BFND1021E = "In the {0} function, status code '{1}' is not allowed.";
    }
}