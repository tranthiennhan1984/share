﻿namespace Binean.Foundation.Core {
    public interface ICell {
        bool Process(IMessage message);
    }
    /// <summary>
    /// Task Cell
    /// </summary>
    public interface ITCell : ICell {
        ValueTask<bool> ProcessAsyn(IMessage message);
    }
    /// <summary>
    /// Attachable Cell
    /// </summary>
    public interface IACell : ICell {
        IGetter Cells { get; }
        void AttachCell(Bsid name, ICell cell, bool guarantee = true);
    }
    /// <summary>
    /// Procedure Cell
    /// </summary>
    public interface IPCell : ICell {
        void AttachProc(Bsid name, Proc proc, bool guarantee = true);
    }
    public interface IPlugin : ICell {
        void AttachTo(BDomain app, Bsid name);
    }

    public delegate bool Proc(IMessage message);
    public delegate ValueTask<bool> AProc(IMessage message);
}
