﻿namespace Binean.Foundation.Core {
    public sealed class Address : BEntity {
        public Address() {
        }
        public Address(Bip? path, Bsid method) {
            Path = path;
            Method = method;
        }
        public Address(IEntity enity) : base(enity) { }

        public override string ToString() {
            var path = Path?.ToString() ?? string.Empty;
            var method = Method.IsNothing ? string.Empty : $"{PathSeparators.Method}{Method}";
            return $"{path}{method}";
        }

        public Bip? Path {
            get {
                if (!Potential.TryGetValue(Properties.Path, out object? value)) return null;
                if (value is Bip propath) return propath;
                var retVal = value?.ToPropath();
                Potential.TrySetValue(Properties.Path, retVal);
                return retVal;
            }
            set => Potential.TrySetValue(Properties.Path, value);
        }
        public Bsid Method {
            get => Potential.Get<Bsid>(Properties.Method) ?? Bsid.Nothing;
            set => Potential.QSet(Properties.Method, value);
        }

        public void SetAddress(Bip? path = null, Bsid? method = null) {
            if (path != null) Path = path;
            if (!method.IsNullOrDummy()) Method = method;
        }
        public void SetAddress(string link) {
            Parse(link, out Bip? path, out Bsid method);
            SetAddress(path, method);
        }
        public static void Parse(string? link, out Bip? path, out Bsid method) {
            if (string.IsNullOrWhiteSpace(link)) {
                path = null;
                method = Bsid.Nothing;
                return;
            }

            var index = link.LastIndexOf(PathSeparators.Method);
            if (index >= 0) {
                method =  (Bsid) link[(index + 1)..];
                link = link[..index];
            } else method = Bsid.Nothing;

            path = link.ToPropath();
        }
    }
    file static class Properties {
        public static readonly Bsid Path = nameof(Path);
        public static readonly Bsid Method = nameof(Method);
    }
}
