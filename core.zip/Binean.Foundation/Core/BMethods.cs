﻿namespace Binean.Foundation.Core {
    /// <summary>
    /// Base methods
    /// </summary>
    public static class BMethods {
        public static readonly Bsid list = nameof(list);
        public static readonly Bsid read = nameof(read);
        public static readonly Bsid create = nameof(create);
        public static readonly Bsid replace = nameof(replace);
        public static readonly Bsid update = nameof(update);
        public static readonly Bsid delete = nameof(delete);
        public static readonly Bsid head = nameof(head);
        public static readonly Bsid option = nameof(option);
        public static readonly Bsid trace = nameof(trace);
        public static readonly Bsid connect = nameof(connect);
        public static readonly Bsid mount = nameof(mount);
        public static readonly Bsid run = nameof(run);
    }
}

