﻿

namespace Binean.Foundation.Core {
    public interface ILink {
        Type? Type { get; }
        IGetter? Parameters { get; }
    }
    public sealed class BLink : BEntity, ILink {
        public Type? Type {
            get => GetType(Potential, Properties.Type);
            set => Potential.QSet(Properties.Type, value);
        }
        public IGetter? Parameters { get; set; }

        private static Type? GetType(IEntity ent, Bsid prop) {
            if (!ent.TryGetNotNull(prop, out object? obj)) return null;
            if (obj is Type type) return type;
            if (obj.ToType() is Type t) {
                ent.Set(prop, t);
                return t;
            }
            return null;
        }
    }

    [CEntity]
    public class CLink : ILink {
        [CProp]
        public Type? Type { get; set; }

        [CProp]
        public IGetter? Parameters { get; set; }
    }

    file static class Properties {
        public static readonly Bsid Type = nameof(Type);
        public static readonly Bsid Parameters = nameof(Parameters);
    }
}
