﻿using Binean.Foundation.Logging;
using System.Collections;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.CompilerServices;


namespace Binean.Foundation.Core {
    public static partial class Extension {
        #region :: Message Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsSuccess(this BStatusCode code)
            => code > 0 && code <= BStatusCode.NotModified;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsSuccess(this IMessage message)
            => message.StatusCode.IsSuccess();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsCompleted(this BStatus status)
            => status == BStatus.Success || status == BStatus.Faulted || status == BStatus.Terminated;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsCompleted(this IMessage message)
            => message.BStatus.IsCompleted();


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IMessage CreateRequest(this IMessage message, bool useParentLogger = true)
            => new BMessage(message, useParentLogger ? message.Logger : null);


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? ToDBNull(this object? _) => DBNull.Value;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void LogInfo(this IMessage message) {
            var add = message.TryGetAddress(out Address? address) ? address.ToString() : string.Empty;
            if (string.IsNullOrWhiteSpace(add)) {
                var caller = new StackTrace().GetFrame(1)!.GetMethod()!;
                add = $"{caller.DeclaringType!.FullName}.{caller.Name}";
            } else if (add.StartsWith(PathSeparators.Method)) {
                var caller = new StackTrace().GetFrame(1)!.GetMethod()!;
                add = $"{caller.DeclaringType!.FullName}.{caller.Name}{add}";
            }
            message.Logger.Log(nameof(Logs.BFND101AI), add);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Faulted(this IMessage message, Exception ex) {
            System.Diagnostics.Debug.WriteLine(ex);
            return message.Error(BStatusCode.InternalServerError, ex.ToMessage());
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Response<T>(this IMessage message, Func<T>? failback = null, bool assert = false)
            => message.IsSuccess() ? message.Response.Convert(failback) : assert ? throw message.AssertErrorMessage().CreateException() : failback is null ? default : failback();
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Success(this IMessage message, Func<bool>? failback = null, bool assert = false)
            => message.IsSuccess() || (assert ? throw message.AssertErrorMessage().CreateException() : failback != null && failback());

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool NoContent(this IMessage message)
            => message.Return(DBNull.Value, BStatusCode.NoContent);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Faulted(this IMessage message, BStatusCode code, Bsid messageId, params object?[] args)
            => message.Error(code, MessageStorage.GenerateMessage(messageId, args));

        /// <summary>
        /// Faulted because of an invalid input is provided. For example, validation error, missing data.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool BadRequest(this IMessage message, Bsid messageId, params object?[] args)
            => message.Faulted(BStatusCode.BadRequest, messageId, args);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool BadRequest(this IMessage message)
            => message.Error(BStatusCode.BadRequest, Dummy.Entity);
        /// <summary>
        /// Faulted because of conflict situation while executing the method. For example, adding duplicate entry
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Conflict(this IMessage message, Bsid messageId, params object?[] args)
            => message.Faulted(BStatusCode.Conflict, messageId, args);

        /// <summary>
        /// Faulted because the user is not having access to the method being used. For example, Delete access without admin rights.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Forbidden(this IMessage message)
            => message.Faulted(BStatusCode.Forbidden, nameof(Logs.BFND1015E));

        /// <summary>
        /// Faulted because the method is not available.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool NotFound(this IMessage message)
            => message.Faulted(BStatusCode.NotFound, nameof(Logs.BFND1016E));
        /// <summary>
        /// Faulted because the method is not available.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ValueTask<bool> NotFoundAsync(this IMessage message)
            => ValueTask.FromResult(message.Faulted(BStatusCode.NotFound, nameof(Logs.BFND1016E)));

        /// <summary>
        /// Faulted because the server has thrown some exception while executing the method.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool InternalServerError(this IMessage message)
            => message.Error(BStatusCode.InternalServerError, null);

        public static IEntity ToMessage(this Exception ex) {
            IEntity msg;
            if (ex is Bexception bex) msg = (Men.Clone(bex.Content) as IEntity) ?? Prior.CreateEntity();
            else {
                msg = MessageStorage.SomethingWrongMessage().QSet(Properties.LogTime, DateTime.Now);
                var txt = ex.Message;
                if (!string.IsNullOrWhiteSpace(txt)) msg.QSet(Properties.Message, $"{msg.Get(Properties.Message)} {txt}");
                msg.Trace();
            }
            return msg.QSet(Properties.Exception, ex);
        }

        public static bool AssertError(this IMessage message) => message.IsCompleted() ? message.IsSuccess() : message.InternalServerError();
        public static IGetter AssertErrorMessage(this IGetter? msg) => msg ?? MessageStorage.SomethingWrongMessage();
        public static IGetter AssertErrorMessage(this IMessage message) => message.Logger.ErrorMessage.AssertErrorMessage();

        public static bool Complete(this IMessage message, IMessage value) {
            if (value == message) return message.StatusCode.IsSuccess();
            message.AssertNotCompleted();
            switch (value.BStatus) {
                case BStatus.Success:
                    message.Return(value.Response, value.StatusCode);
                    break;
                case BStatus.Faulted:
                    message.Error(value.StatusCode, value.Logger == message.Logger ? Dummy.Entity : value.AssertErrorMessage());
                    break;
                case BStatus.Terminated:
                    message.Kill();
                    break;
            }
            return message.StatusCode.IsSuccess();
        }
        public static void AssertNotCompleted(this IMessage message) {
            if (message.IsCompleted()) throw MessageStorage.CreateException(nameof(Logs.BFND1017E));
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryGetAddress(this IMessage message, [NotNullWhen(true)] out Address? address) {
            if (!message.Potential.TryGetNotNull(Properties.Address, out object? obj)) return (address = null) != null;
            if (obj is Address add) return (address = add) != null;
            if (obj is string txt) {
                address = new Address();
                address.SetAddress(txt);
                message.Potential.QSet(Properties.Address, address);
                return true;
            }
            if (obj.ToPEntity() is IEntity ent) {
                address = new Address(ent);
                message.Potential.QSet(Properties.Address, address);
                return true;
            }
            return (address = null) != null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Address AssertAddress(this IMessage message) {
            if (!message.TryGetAddress(out Address? address)) {
                address = new(Prior.CreateQEntity());
                message.Potential.QSet(Properties.Address, address);
            }
            return address;
        }

        public static bool TryGetMethod(this IMessage message, [NotNullWhen(true)] out Bsid method, bool preventLog = false) {
            if (message.TryGetAddress(out Address? address)) method = address.Method;
            else method = Bsid.Nothing;
            if (!method.IsNothing) return true;
            if (!preventLog) message.Logger.Log(nameof(Logs.BFND1012E));
            method = Bsid.Nothing;
            return false;
        }
        public static bool TryGetPath(this IMessage message, [NotNullWhen(true)] out Bip? path, bool preventLog = false) {
            if (message.TryGetAddress(out Address? address) && address.Path is Bip p && !p.IsEmpty()) return (path = p) != null;
            if (!preventLog) message.Logger.Log(nameof(Logs.BFND1011E));
            return (path = null) != null;
        }

        public static bool TryGetRequest<T>(this IMessage message, [NotNullWhen(true)] out T? args, bool allowLog = true) {
            if (message.Potential.TryGetNotNull(Properties.Request, out args) && args != null) return true;
            if (allowLog) message.Logger.Log(nameof(Logs.BFND1013E), typeof(T));
            args = default;
            return false;
        }
        public static bool TryUnboxRequest<T>(this IMessage message, [NotNullWhen(true)] out T? args, bool allowLog = true) {
            if (message.Potential.TryGetValue(Properties.Request, out object? obj) && obj.TryUnbox(out args)) return true;
            if (allowLog) message.Logger.Log(nameof(Logs.BFND1013E), typeof(T));
            args = default;
            return false;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? GetRequest(this IMessage message) => message.Potential.QGet(Properties.Request);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IMessage Request(this IMessage message, object? request = null) {
            if (request != null) message.Potential.QSet(Properties.Request, request);
            return message;
        }
        //public static bool TryGetContext(this BRequest req, [NotNullWhen(true)] out IContext? context, bool allowLog = true) {
        //    context = req.Latent.Get<IContext>(Properties.Context);
        //    if (context != null) return true;
        //    if (allowLog) req.Log(nameof(Logs.BFND10104E));
        //    return false;
        //}
        //public static BRequest SetContext(this BRequest req, IContext? context, bool guarantee = true) {
        //    req.Latent.QSet(Properties.Context, context, guarantee);
        //    return req;
        //}


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Attach<T>(this T mCell, Bsid name, ICell cell, bool guarantee = true) where T : IACell {
            mCell.AttachCell(name, cell, guarantee);
            return mCell;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Attach<T>(this T mCell, Bsid name, Proc proc, bool guarantee = true) where T : IPCell {
            mCell.AttachProc(name, proc, guarantee);
            return mCell;
        }
        public static async ValueTask<bool> ProcessAsync(this ICell cell, IMessage message) {
            if (cell is ITCell tCell) return await tCell.ProcessAsync(message);
            return cell.Process(message);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IMessage Address(this IMessage message, Bip? path = null, Bsid? method = null) {
            if (path is null && method.IsNullOrDummy()) return message;
            message.AssertAddress().SetAddress(path, method);
            return message;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IMessage Address(this IMessage message, string? link) {
            if (string.IsNullOrWhiteSpace(link)) return message;
            message.AssertAddress().SetAddress(link);
            return message;
        }

        public static IMessage RProcess(this ICell cell, Bsid method, object? args = null, IMessage? message = null, Bip? path = null) {
            var msg = message is null ? new BMessage() : message.CreateRequest();
            cell.Process(msg.Address(path, method).Request(args));
            return msg;
        }
        public static async ValueTask<IMessage> RProcessAsync(this ICell cell, Bsid method, object? args = null, IMessage? message = null, Bip? path = null) {
            var msg = message is null ? new BMessage() : message.CreateRequest();
            await cell.ProcessAsync(msg.Address(path, method).Request(args));
            return msg;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Process<T>(this ICell cell, IMessage message, Func<T?>? failback = null) {
            cell.Process(message);
            if (!message.IsSuccess()) return failback is null ? default : failback();
            return message.Response.Convert(failback);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Process<T>(this ICell cell, Bip? path = null, Bsid? method = null, object? request = null, Func<T?>? failback = null) {
            failback ??= () => default;
            if (path is null && method.IsNullOrDummy() && request is null) return failback();
            var msg = new BMessage().Address(path, method).Request(request);
            return cell.Process<T>(msg);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Process<T>(this ICell cell, Bsid method, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
           => RProcess(cell, method, args, message, path).Response(failback, assert);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> ProcessAsync<T>(this ICell cell, Bsid method, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, method, args, message, path)).Response(failback, assert);




        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICell? Connect(this ICell cell, object? args = null, IMessage? message = null, Func<ICell>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.connect, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<ICell?> ConnectAsync(this ICell cell, object? args = null, IMessage? message = null, Func<ICell>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.connect, args, message, path)).Response(failback, assert);


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Exists(this ICell cell, object? args = null, IMessage? message = null, Func<bool>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.head, args, message, path).Success(failback, assert);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<bool> ExistsAsync(this ICell cell, object? args = null, IMessage? message = null, Func<bool>? failback = null, bool assert = false, Bip? path = null)
            => (message = await RProcessAsync(cell, BMethods.head, args, message, path)).IsSuccess() || (assert ? throw message.AssertErrorMessage().CreateException() : failback != null && failback());
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Head<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.head, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> HeadAsync<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.head, args, message, path)).Response(failback, assert);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Mount<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
           => RProcess(cell, BMethods.head, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> MountAsync<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.head, args, message, path)).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Mount(this ICell cell, object? args = null, IMessage? message = null, Func<bool>? failback = null, bool assert = false, Bip? path = null)
           => RProcess(cell, BMethods.head, args, message, path).Success(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<bool> MountAsync(this ICell cell, object? args = null, IMessage? message = null, Func<bool>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.head, args, message, path)).Success(failback, assert);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Read<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.read, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> ReadAsync<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.read, args, message, path)).Response(failback, assert);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Create<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.create, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> CreateAsync<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.create, args, message, path)).Response(failback, assert);


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Update<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.update, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> UpdateAsync<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.update, args, message, path)).Response(failback, assert);


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Replace<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.replace, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> ReplaceAsync<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.replace, args, message, path)).Response(failback, assert);


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Delete<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.delete, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> DeleteAsync<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.delete, args, message, path)).Response(failback, assert);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IList? List(this ICell cell, object? args = null, IMessage? message = null, Func<IList>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.list, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<IList?> ListAsync(this ICell cell, object? args = null, IMessage? message = null, Func<IList>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.list, args, message, path)).Response(failback, assert);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IGetter? Option(this ICell cell, object? args = null, IMessage? message = null, Func<IGetter>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.option, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<IGetter?> OptionAsync(this ICell cell, object? args = null, IMessage? message = null, Func<IGetter>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.option, args, message, path)).Response(failback, assert);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Run<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.run, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<T?> RunAsync<T>(this ICell cell, object? args = null, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.run, args, message, path)).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Run(this ICell cell, object? args = null, IMessage? message = null, Func<bool>? failback = null, bool assert = false, Bip? path = null)
            => RProcess(cell, BMethods.run, args, message, path).Response(failback, assert);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<bool> RunAsync(this ICell cell, object? args = null, IMessage? message = null, Func<bool>? failback = null, bool assert = false, Bip? path = null)
            => (await RProcessAsync(cell, BMethods.run, args, message, path)).Response(failback, assert);

        #endregion
    }
    file static class Properties {
        public static readonly Bsid Address = nameof(Address);
        public static readonly Bsid Path = nameof(Path);
        public static readonly Bsid Method = nameof(Method);

        public static readonly Bsid Request = nameof(Request);
        public static readonly Bsid Context = nameof(Context);

        public static readonly Bsid LogTime = nameof(LogTime);
        public static readonly Bsid Message = nameof(Message);
        public static readonly Bsid Exception = nameof(Exception);
    }
}
