﻿namespace Binean.Foundation.Core {
    public class BDomain : BEntity, IACell, ITCell {
        protected readonly ACell _cells = new();

        public Action? FatalErrorAction { get; set; }

        public IGetter Cells => _cells.Cells;

        //public bool TryGetValue(Bid bid, out object? value) => _cells.TryGetValue(bid, out value);

        public void AttachCell(Bsid name, ICell cell, bool guarantee = true) {
            _cells.AttachCell(name, cell, guarantee);
            (cell as IPlugin)?.AttachTo(this, name);
        }
        public bool Process(IMessage message) => _cells.Process(message);
        public ValueTask<bool> ProcessAsyn(IMessage message) => _cells.ProcessAsyn(message);

    }
}
