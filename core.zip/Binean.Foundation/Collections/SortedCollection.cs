﻿namespace Binean.Foundation.Collections {
    public class SortedCollection<T> : System.Collections.ObjectModel.Collection<T> {
        private readonly Comparison<T> _comparer;
        public SortedCollection(IComparer<T> comparer) {
            _comparer = comparer.Compare;
        }
        public SortedCollection(Comparison<T> comparer) {
            _comparer = comparer;
        }

        public bool SoleItem { get; set; } = true;

        public bool TrySetMember(T item, bool overrideIfExists = true) {
            if (Items.BinarySearch(i => _comparer(i, item), out int index)) {
                if (!overrideIfExists) return false;
                Items[index] = item;
            } else Items.Insert(~index, item);
            return true;
        }

        public bool BinarySearch(T item, out int index, int startIndex = 0, int length = -1)
            => Items.BinarySearch(i => _comparer(i, item), out index, startIndex, length);
        public bool BinarySearch(Func<T, int> comparison, out int index, int startIndex = 0, int length = -1)
            => Items.BinarySearch(comparison, out index, startIndex, length);
        public bool Contains(T item, int startIndex = 0, int length = -1)
            => Items.BinarySearch(i => _comparer(i, item), out int _, startIndex, length);

        public int AddItem(T item) {
            if (Items.BinarySearch(t1 => _comparer(t1, item), out int index)) {
                if (SoleItem) {
                    Items[index] = item;
                    return index;
                }
                index++;
            } else index = ~index;
            Items.Insert(index, item);
            return index;
        }
        public int SetItem(T item, int index) {
            if (Items.BinarySearch(t1 => _comparer(t1, item), out int i)) {
                if (SoleItem) index = i;
                index = i + 1;
            } else index = ~i;
            Items[index] = item;
            return index;
        }
        protected override void InsertItem(int index, T item) {
            AddItem(item);
        }
        protected override void SetItem(int index, T item) {
            SetItem(item, index);
        }
    }
}
