﻿using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Foundation.Collections {
    public static partial class Extension {
        public static T[] ToArray<T>(this IList<T> list) {
            T[] retVal = new T[list.Count];
            list.CopyTo(retVal, 0);
            return retVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T[] ToArray<T>(this T[] source, int offset, int count) {
            if (offset == 0 && count == source.Length) return source;
            var retVal = new T[count];
            Array.Copy(source, offset, retVal, 0, count);
            return retVal;
        }

        public static bool BinarySearch<T, V>(this T set, int lenght, Func<T, int, V> getter, Func<V, int> comparison, out int index) {
            var low = 0;
            var hi = lenght - 1;

            var comp = hi < 0 ? 1 : comparison(getter(set, hi));
            if (comp == 0) return (index = hi) > -1;
            else if (comp < 0) return (index = ~(hi + 1)) > -1;
            hi--;

            comp = comparison(getter(set, low));
            if (comp == 0) return (index = low) > -1;
            else if (comp > 0) return (index = ~low) > -1;
            low++;

            while (low <= hi) {
                var mid = low + ((hi - low) >> 1);
                comp = comparison(getter(set, mid));
                if (comp == 0) return (index = mid) > -1;

                if (comp > 0) hi = mid - 1;
                else low = mid + 1;
            }
            index = ~low;
            return false;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static TC Diff<TC, TI>(this TC dlist, IEnumerable<TI>? source, IEnumerable<TI>? target, IComparer<TI> comparer, Differ<TC, TI> differ)
            => Diff(dlist, source, target, comparer.Compare, differ);
        public static TC Diff<TC, TI>(this TC dlist, IEnumerable<TI>? source, IEnumerable<TI>? target, Comparison<TI> comparer, Differ<TC, TI> differ) {
            var slist = new List<TI>();
            var tlist = new List<TI>();

            if (source != null) slist.AddRange(source);
            slist.Sort(comparer);

            if (target != null) tlist.AddRange(target);
            tlist.Sort(comparer);

            var slen = slist.Count;
            var tlen = tlist.Count;
            int sind = 0;
            int tind = 0;
            while (true) {
                var sitm = sind < slen ? slist[sind] : default;
                var titm = tind < tlen ? tlist[tind] : default;

                if (sitm is null && titm is null) break;

                int comp = sitm is null && titm is null ? 0
                    : sitm is null ? 1
                    : titm is null ? -1
                    : comparer(sitm, titm);

                differ(dlist, comp, sitm, titm);

                sind += comp <= 0 ? 1 : 0;
                tind += comp >= 0 ? 1 : 0;
                continue;
            }
            return dlist;
        }
    }

    public delegate void Differ<TC, TI>(TC container, int comp, TI? source, TI? target);
}
