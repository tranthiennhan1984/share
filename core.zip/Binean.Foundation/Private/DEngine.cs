﻿using System.Diagnostics.CodeAnalysis;


namespace Binean.Foundation.Private {
    sealed class DEngine : IEngine {
        private readonly IEngine _engine;
        private readonly DCell _cell;

        public DEngine(IEngine engine, ICell cell) {
            _cell = new DCell(cell);
            _engine = engine;
        }

        public IGetter Cells => _cell.Cells;
        public void AttachCell(string name, ICell cell, bool guarantee = true) => _cell.AttachCell(name, cell, guarantee);
        public bool Process(BRequest request) => _cell.Process(request);

        public bool Call(IContext context, IFunc func, BRequest request, bool createNewContext = true)
            => _engine.Call(context, func, request, createNewContext);
        public bool TryLoadModule(string path, [NotNullWhen(true)] out IModule? module)
            => _engine.TryLoadModule(path, out module);
    }
}

