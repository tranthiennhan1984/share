﻿namespace Binean.Foundation.Private {
    sealed class CellPlugin(ICell cell) : IPlugin {
        private readonly ICell _cell = cell;

        void IPlugin.AttachTo(BDomain owner, Bsid name) { }
        bool ICell.Process(IMessage message) => _cell.Process(message);
    }
}
