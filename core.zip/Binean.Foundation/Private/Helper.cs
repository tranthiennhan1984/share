﻿using Binean.Foundation.Protect;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Private {
    internal static class Helper {
        #region :: Data Converters ::
        internal static bool ConvertToEnum(object value, Type targetType, out object? target) {
            if (value is string text) {
                try {
                    target = Enum.Parse(targetType, text, true);
                    return true;
                } catch (Exception ex) {
                    var _ = ex; target = null; return false;
                }
            }

            try {
                target = Enum.ToObject(targetType, value); return true;
            } catch (Exception ex) {
                var _ = ex; target = null; return false;
            }
        }
        #endregion

        #region :: Message Helpers ::
        internal static void LoadMessages(IEntity msgs, Type type) {
            var fields = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);

            var length = fields.Length;
            for (int i = 0; i < length; i++) {
                if (fields[i] is not FieldInfo field) continue;
                if (field.GetValue(null) is not string msg) continue;
                var mid = (Bsid) field.Name;
                if (msgs.TryGetValue(mid, out _)) return;
                msgs.Set(mid, GenerateMessage(mid, msg));
            }
        }
        internal static IEntity GenerateMessage(Bsid mid, string message) {
            InParseMessageId((string)mid, out LogLevel logLevel);
            return Prior.CreateEntity()
               .QSet(Properties.Id, mid)
               .QSet(Properties.LogLevel, logLevel)
               .QSet(Properties.Message, message);

        }
        private static void InParseMessageId(string msgId, out LogLevel logLevel) {
            var length = msgId.Length;

            var chr = msgId[length - 1];
            var lv = "VDIWEF".IndexOf(char.ToUpper(chr));
            if (lv > -1) {
                logLevel = (LogLevel)lv;
            } else logLevel = LogLevel.Verbose;
        }

        internal static IEntity GenerateMessage(IEntity msgs, Bsid id, params object?[] args) {
            var getter = msgs.Get(id).ToGetter();
            var msg = getter.Get<string>(Properties.Message);
            var retVal = Prior.CreateEntity().QSet(Properties.Message, InBuildMessage(msg, id, args));
            if (!getter.IsNullOrEmpty()) retVal.MAssign(getter, false);
            return retVal;
        }
        private static string InBuildMessage(string? msg, Bsid id, params object?[] args) {
            if (string.IsNullOrWhiteSpace(msg)) {
                var sb = new StringBuilder((string)id);
                var length = args.Length;
                for (int i = 0; i < length; i++) {
                    sb.Append($" {{{i}}}");
                }
                msg = sb.ToString();
            }

            string retVal = (args.Length > 0 ? string.Format(CultureInfo.CurrentCulture, msg, args) : msg) ?? string.Empty;

            char first;
            return retVal.Length > 0 && char.IsLower(first = retVal[0]) ? $"{char.ToUpper(first)}{retVal[1..]}" : retVal;
        }
        #endregion

        #region :: IO Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static char ToChar(this int value) => value <= 0 ? BetextReader.EofCharacter : (char)value;

        #endregion

        #region :: Reflection Helpers ::
        internal static GetterDelegate BuildGetAccessor(this PropertyInfo propertyInfo) {
            var ownerType = propertyInfo.DeclaringType!;
            var propType = propertyInfo.PropertyType;

            DynamicMethod dynamicMethod = new("GetProperty", typeof(object), new Type[] { typeof(object) }, ownerType);

            ILGenerator ilGenerator = dynamicMethod.GetILGenerator();

            ilGenerator.Emit(OpCodes.Ldarg_0);
            ilGenerator.Emit(OpCodes.Castclass, ownerType);
            ilGenerator.EmitCall(OpCodes.Callvirt, propertyInfo.GetGetMethod()!, null);
            if (propType.IsValueType) ilGenerator.Emit(OpCodes.Box, propType);

            ilGenerator.Emit(OpCodes.Ret);

            var func = (Func<object, object?>)dynamicMethod.CreateDelegate(typeof(Func<object, object?>));
            return delegate (object instance, out object? value) {
                value = func(instance);
                return true;
            };
        }
        internal static SetterDelegate? BuildSetAccessor(this PropertyInfo propertyInfo) {
            if (propertyInfo.GetSetMethod() is not MethodInfo methodInfo) return null;

            var ownerType = propertyInfo.DeclaringType!;
            var propType = propertyInfo.PropertyType;

            var dynamicMethod = new DynamicMethod("SetProperty", null, new Type[] { typeof(object), typeof(object) }, ownerType);

            var ilGenerator = dynamicMethod.GetILGenerator();

            ilGenerator.Emit(OpCodes.Ldarg_0);
            ilGenerator.Emit(OpCodes.Castclass, ownerType);
            ilGenerator.Emit(OpCodes.Ldarg_1);
            if (propType.IsValueType) ilGenerator.Emit(OpCodes.Unbox_Any, propType);
            ilGenerator.EmitCall(OpCodes.Callvirt, methodInfo, null);
            ilGenerator.Emit(OpCodes.Ret);

            var action = (Action<object, object?>)dynamicMethod.CreateDelegate(typeof(Action<object, object?>));

            return new SetterDelegate((i, o) => {
                if (!o.TryConvert(propType, out object? value)) return false;
                action(i, value);
                return true;
            });
        }

        //public static void Main() {
        //    Example example = new Example();

        //    // Get the PropertyInfo for the property
        //    PropertyInfo propertyInfo = typeof(Example).GetProperty("Property");

        //    // Create a dynamic method
        //    DynamicMethod dynamicMethod = new DynamicMethod("SetProperty", null, new Type[] { typeof(object), typeof(object) }, typeof(Example));
        //    ILGenerator ilGenerator = dynamicMethod.GetILGenerator();

        //    // Load the instance onto the evaluation stack
        //    ilGenerator.Emit(OpCodes.Ldarg_0);

        //    // Cast it to the correct type
        //    ilGenerator.Emit(OpCodes.Castclass, typeof(Example));

        //    // Load the value onto the evaluation stack
        //    ilGenerator.Emit(OpCodes.Ldarg_1);


        //    // Load the target type onto the evaluation stack
        //    ilGenerator.Emit(OpCodes.Ldtoken, propertyInfo.PropertyType);
        //    ilGenerator.EmitCall(OpCodes.Call, typeof(Type).GetMethod("GetTypeFromHandle"), null);

        //    // Declare a local variable to hold the conversion result
        //    LocalBuilder resultLocal = ilGenerator.DeclareLocal(typeof(object));

        //    // Call the ConvertTo method
        //    MethodInfo convertMethod = typeof(Example).GetMethod("ConvertTo");
        //    ilGenerator.EmitCall(OpCodes.Call, convertMethod, null);

        //    // Store the conversion result in the local variable
        //    ilGenerator.Emit(OpCodes.Stloc, resultLocal);

        //    // Load the conversion result onto the evaluation stack
        //    ilGenerator.Emit(OpCodes.Ldloc, resultLocal);

        //    // Unbox the return value (if the property type is a value type)
        //    if (propertyInfo.PropertyType.IsValueType) {
        //        ilGenerator.Emit(OpCodes.Unbox_Any, propertyInfo.PropertyType);
        //    }

        //    // Call the setter of the property
        //    ilGenerator.EmitCall(OpCodes.Callvirt, propertyInfo.GetSetMethod(), null);

        //    // Return from the method
        //    ilGenerator.Emit(OpCodes.Ret);

        //    // Create a delegate from the dynamic method
        //    Action<object, object> setProperty = (Action<object, object>)dynamicMethod.CreateDelegate(typeof(Action<object, object>));

        //    // Use the delegate to set the property value
        //    setProperty(example, "Hello, World!");

        //    Console.WriteLine(example.Property);  // Outputs: Hello, World!
        //}

        #endregion
    }
}
namespace Binean.Foundation.Protect {
    file static class Properties {
        public static readonly Bsid Id = nameof(Id);
        public static readonly Bsid LogLevel = nameof(LogLevel);
        public static readonly Bsid Message = nameof(Message);
    }
}