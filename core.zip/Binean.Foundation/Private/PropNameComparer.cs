﻿
namespace Binean.Private {
    internal sealed class PropNameComparer : StringComparer {
        public bool CaseInsensitive { get; set; }
        public override int Compare(string? x, string? y) {
            if (x == null && y == null) return 0;
            if (x == null) return -1;
            if (y == null) return 1;

            return x.NameComparison(y, CaseInsensitive);
        }
        public override bool Equals(string? x, string? y)
            => Compare(x, y) == 0;
        public override int GetHashCode(string obj) => obj.ToLower().GetHashCode();
    }
}

