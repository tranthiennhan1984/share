﻿using Binean.Foundation.Protect;
using System.Diagnostics;
using BenReader = Binean.Foundation.Storage.BenReader;

namespace Binean.Private {
    internal sealed class BenStoken : Sertoken {
        private readonly BenReader _reader;
        private readonly BenDataTypes _itemType;

        public BenStoken(BenReader reader, ref Serialize serialize, BenDataTypes itemType, Bsid name)
            : base(serialize, NodeType.Array, null, name) {
            _reader = reader;
            _itemType = itemType;
            Debug.Assert(_itemType != BenDataTypes.None);
            serialize = ReadItem;
        }
        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            Debug.Assert(this == block);

            switch (_reader.PeekPunctuator()) {
                case BenPunctuator.EndObject: throw _reader.CreateException(nameof(Logs.BFND4011E));
                case BenPunctuator.EndArray:
                    _reader.MoveNext();
                    return ReadEndBlock(resolve, ref serialize, block);
            }
            return block.NewToken(NodeType.Value, _reader.ReadValue(_itemType));
        }
    }
}
namespace Binean.Foundation.Protect {

    [BLog]
    file static class Logs {
        public const string BFND4011E = "'EndArray punctuator' expected.";
    }
}
