﻿using System.Collections;

namespace Binean.Foundation.Private {
    delegate bool NameFinder(INameSet set, Bid bid, out int index);
    sealed class NameList : INameList, ILock {
        private readonly NameFinder _finder;
        private readonly List<Bid> _bids = [];
        private int _valueType;
        private Action<int, Bid> _insertHandler = default!;

        public NameList(bool sorted = false, bool isConstant = false) {
            if (sorted) {
                NameType = ListType.Ordered;
                _finder = Primitive.Extension.NameBinaryFinder;
            } else {
                NameType = ListType.Default;
                _finder = Primitive.Extension.NameFinder;
            }
            _valueType = isConstant ? 1 : 2;
            UpdateInsertHandler();
        }

        public int Count => _bids.Count;
        public Bid this[int index] => _bids[index];
        public ListType NameType { get; }

        bool ILock.IsLocked => _valueType < 0;

        public int Add(Bid bid) {
            if (!bid.IsString()) return -1;
            if (_finder(this, bid, out int index)) return index;
            index = ~index;
            _insertHandler(index, bid);
            return index;
        }
        public bool Find(Bid bid, out int index)
            => _finder(this, bid, out index);
        public void RemoveAt(int index) => _bids.RemoveAt(index);
        public void Clear() => _bids.Clear();

        public void Lock() {
            if (_valueType < 0) return;
            _valueType = -_valueType;
            UpdateInsertHandler();
        }
        public void Unlock() {
            if (_valueType > 0) return;
            _valueType = -_valueType;
            UpdateInsertHandler();
        }

        private void UpdateInsertHandler() {
            if (_valueType == 1) _insertHandler = InInsertSingleton;
            else if (_valueType == 2) _insertHandler = InInsert;
            else _insertHandler = InInsertError;
        }
        private void InInsert(int index, Bid bid) => _bids.Insert(index, bid);
        private void InInsertSingleton(int index, Bid bid) => _bids.Insert(index, bid.Constant());
        private void InInsertError(int index, Bid bid) => throw new InvalidOperationException();

        public IEnumerator<Bid> GetEnumerator() => _bids.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_bids).GetEnumerator();
    }
}
