﻿
using System.Runtime.CompilerServices;

namespace Binean.Private {
    sealed class BuidReader : IInput<char> {
        private readonly long _content;
        private int _position = -1;
        private int _shiftOffset;

        private readonly IBuidEncoding _encoding;
        private Func<bool> _next;

        public BuidReader(long content, IBuidEncoding encoding) {
            _content = content;
            _encoding = encoding;
            _next = _content == 0 ? InReadEnd : InReadNext;
            _shiftOffset = 64 - (encoding.HasLockBit ? 1 : 0);
            MoveNext();
        }

        object IInput<char>.Position => _position;

        public char Current { get; private set; } = Bid.EOF;
        public bool IsEnd { get; private set; }

        public void MoveNext() {
            if (IsEnd) return;
            if (_next()) ++_position;
            else IsEnd = true;
        }

        private bool InReadNext() {
            if (_shiftOffset < 6) return InReadLast();

            var c = _encoding.Char((byte)((_content >> (_shiftOffset -= 6)) & 63));
            if (c == Bid.EOF) return InReadEnd();

            Current = c;
            return true;
        }
        private bool InReadLast() {
            _next = _encoding.Padding == Bid.EOF ? InReadEnd : InReadPadding;

            var offset = _encoding.HasLockBit ? 3 : 2;
            var c = _encoding.LastChar((byte)(((byte)((_content << offset) & 63)) >> offset));
            if (c == Bid.EOF) return InReadEnd();

            Current = c;
            return true;
        }
        private bool InReadPadding() {
            _next = InReadEnd;
            Current = _encoding.Padding;
            return true;
        }
        private bool InReadEnd() {
            _next = InReadEnd;
            Current = Bid.EOF;
            _shiftOffset = 0;
            return false;
        }
    }
    sealed class Buid64Writer : IOutput<char> {
        private long _content;
        private int _position = -1;
        private int _shiftOffset = 63;

        private readonly Func<char, long> _toCode;
        private Func<char, bool> _write;

        public Buid64Writer(Func<char, long> toCode, bool isBase64 = false) {
            Padding = isBase64 ? '=' : Bid.EOF;
            _toCode = toCode;
            _content = 0;
            _write = InWrite;
        }
        public char Padding { get; }
        public long Content => _content;


        object IOutput<char>.Position => _position;
        public bool IsEnd { get; private set; }
        public bool Write(char chr) {
            if (IsEnd) return false;
            if (_write(chr)) {
                ++_position;
                return true;
            }
            IsEnd = true;
            return false;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool IsBase64() => Padding == '=';
        private bool InWrite(char chr) {
            if (chr == Padding) return InWriteEnd(chr);
            if (_shiftOffset < 6) return IsBase64() ? InWriteLastBase64(chr) : InWriteEnd(chr);

            _content |= _toCode(chr) << (_shiftOffset -= 6);

            return true;
        }
        private bool InWriteLastBase64(char chr) {
            _write = InWritePadding;
            _content |= _toCode(chr) >> 2;
            return true;
        }
        private bool InWritePadding(char chr) {
            _write = InWriteEnd;
            return chr == '=';
        }
        private bool InWriteEnd(char chr) {
            _write = InWriteEnd;
            _shiftOffset = 0;
            return false;
        }
    }
}