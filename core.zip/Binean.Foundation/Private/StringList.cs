﻿using System.Collections;

namespace Binean.Foundation.Private {
    delegate bool StringFinder(IStringSet set, string name, out int index);
    sealed class StringList : IStringList, ILock {
        private readonly StringFinder _finder;
        private readonly List<string> _names = new();
        private int _insertType;
        private Action<int, string> _insertHandler = default!;

        public StringList(bool sorted = false, bool singleton = false) {
            if (sorted) {
                NameType = NameType.Ordered;
                _finder = Primitive.Extension.StringBinaryFinder;
            } else {
                NameType = NameType.Default;
                _finder = Primitive.Extension.StringFinder;
            }
            _insertType = singleton ? 1 : 2;
            UpdateInsertHandler();
        }

        public int Count => _names.Count;
        public string this[int index] => _names[index];
        public NameType NameType { get; }

        bool ILock.IsLocked => _insertType < 0;

        public int Add(string name) {
            if (name == string.Empty) return -1;
            if (_finder(this, name, out int index)) return index;
            index = ~index;
            _insertHandler(index, name);
            return index;
        }
        public bool Find(string name, out int index)
            => _finder(this, name, out index);
        public void RemoveAt(int index) => _names.RemoveAt(index);
        public void Clear() => _names.Clear();

        public void Lock() {
            if (_insertType < 0) return;
            _insertType = -_insertType;
            UpdateInsertHandler();
        }
        public void Unlock() {
            if (_insertType > 0) return;
            _insertType = -_insertType;
            UpdateInsertHandler();
        }

        private void UpdateInsertHandler() {
            if (_insertType == 1) _insertHandler = InInsertSingleton;
            else if (_insertType == 2) _insertHandler = InInsert;
            else _insertHandler = InInsertError;
        }
        private void InInsert(int index, string name) => _names.Insert(index, name);
        private void InInsertSingleton(int index, string name) => _names.Insert(index, name.ToConstant());
        private void InInsertError(int index, string name) => throw new InvalidOperationException();

        public IEnumerator<string> GetEnumerator() => _names.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_names).GetEnumerator();
    }
}
