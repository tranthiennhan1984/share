﻿using Binean.Foundation.Primitive;
using System.Collections;


namespace Binean.Private {
    internal sealed class Listity(IList list) : IEntity, IClassed {
        private readonly IList _list = list;
        private Bsid _displayBid = Properties.Name;

        public override string? ToString()
            => this.Get(_displayBid) is string txt ? txt : base.ToString();
        bool IGetter.IsEmpty => _list.Count == 0;
        public BClass? Class { get; set; }

        public bool TryGetValue(Bsid bid, out object? value) {
            if (!int.TryParse((string)bid, out int index)) return (value = null) != null;
            if (index < 0 || index >= _list.Count) return (value = null) != null;
            return (value = _list[index]) is not DBNull || (value = null) != null;
        }
        public bool TrySetValue(Bsid bid, object? value) {
            if (!int.TryParse((string)bid, out int index)) return false;
            if (index < 0 || index > _list.Count) return false;
            if (index < _list.Count) {
                if (value is DBNull) {
                    _list.RemoveAt(index);
                    return true;
                }
            } else if (value is DBNull) return true;

            _list[index] = value;
            return true;
        }
        public bool Clear() {
            _list.Clear();
            return true;
        }
        public bool TryRemoveValue(Bsid bid) {
            if (!int.TryParse((string)bid, out int index)) return false;
            if (index < 0 || index > _list.Count) return false;
            _list.RemoveAt(index);
            return true;
        }
        public void ChangeDisplayBid(Bsid bid) => _displayBid = bid;
        private IEnumerable<IUnit> GetNodes() {
            var length = _list.Count;
            for (int i = 0; i < length; i++) {
                yield return new Unit(Bsid.Nothing, _list[i]);
            }
        }
        IEnumerator<IUnit> IEnumerable<IUnit>.GetEnumerator() => GetNodes().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => _list.GetEnumerator();

    }
    internal sealed class Dictity(IDictionary dict) : IEntity, IClassed {
        private readonly IDictionary _dict = dict;
        private Bsid _displayBid = Properties.Name;

        public override string? ToString()
            => this.Get(_displayBid) is string txt ? txt : base.ToString();

        public BClass? Class { get; set; }

        public bool IsEmpty => _dict.Count == 0;

        public bool TryGetValue(Bsid bid, out object? value) {
            if (!bid.IsNothing && _dict.Count > 0 && _dict.Contains(bid)) {
                value = _dict[bid];
                if (value is not DBNull) return true;
            }
            value = null;
            return false;
        }
        public bool TrySetValue(Bsid bid, object? value) {
            if (bid.IsNothing) return false;

            if (_dict.Contains(bid)) {
                if (value is DBNull) {
                    _dict.Remove(bid);
                    return false;
                }
                _dict[bid] = value;
                return true;
            }

            if (value is DBNull) return true;

            _dict[bid] = value;
            return true;
        }
        public bool Clear() {
            _dict.Clear();
            return true;
        }
        public bool TryRemoveValue(Bsid bid) {
            if (!_dict.Contains(bid)) return false;
            _dict.Remove(bid);
            return true;
        }
        public void ChangeDisplayBid(Bsid bid) => _displayBid = bid;
        private IEnumerable<IUnit> GetUnits() {
            foreach (var name in _dict.Keys) {
                if (name.TryBid() is not Bsid bid) continue;
                yield return new Unit(bid, _dict[name]);
            }
        }
        IEnumerator<IUnit> IEnumerable<IUnit>.GetEnumerator() => GetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetUnits().GetEnumerator();

    }

    internal sealed class CoverEntity : IEntity, IClassed, INames<Bsid>, IValues, ILockable, IValidator, IEquatable<IGetter> {
        private readonly object _instance;
        private readonly IEntity _entity;
        private readonly IClassed? _clsed;

        public CoverEntity(object instance, IEntity entity) {
            _instance = instance;
            _entity = entity;
            _clsed = _instance as IClassed ?? _entity as IClassed;
        }

        public bool IsEmpty => _entity.IsEmpty;

        public BClass? Class {
            get => _clsed is null ? _class : _clsed.Class;
            set {
                if (_clsed != null) _clsed.Class = value;
                else _class = value;
            }
        }
        private BClass? _class;
        public INameSet<Bsid> Names => _entity.GetNameSet<Bsid>();
        public IEnumerable Values => _entity.GetValues();
        public IWriteLock? Lock => _entity.GetLock();

        public bool TryGetValue(Bsid bid, out object? value) => _entity.TryGetValue(bid, out value);
        public bool TrySetValue(Bsid bid, object? value) => _entity.TrySetValue(bid, value);
        public bool TryRemoveValue(Bsid bid) => _entity.TryRemoveValue(bid);
        public bool Clear() => _entity.Clear();
        public void ChangeDisplayBid(Bsid bid) => _entity.ChangeDisplayBid(bid);
        public IEnumerator<IUnit> GetEnumerator() => _entity.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_entity).GetEnumerator();
        public bool Validate(ILogger logger) {
            if (_instance is IValidator val) return val.Validate(logger);
            if (_entity is IValidator eval) return eval.Validate(logger);
            return true;
        }
        public bool Equals(IGetter? other) => ReferenceEquals(_entity, other);

    }

    internal sealed class LatentEntity(IEntity source, IEntity latent, Func<Bsid, bool>? skipRead = null) : IEntity, IClassed, INames<Bsid>, IWriteLock, IValidator {
        private readonly Bib _deleted = Prior.CreateQNames();
        private readonly Func<Bsid, bool>? _skipRead = skipRead;
        private bool _isLocked;

        public override string? ToString()
            => Source.ToString();

        public bool IsEmpty => Source.IsEmpty && Latent.IsEmpty;

        public BClass? Class {
            get => Source is IClassed clsed ? clsed.Class : _class;
            set {
                if (Source is IClassed clsed) clsed.Class = value;
                else _class = value;
            }
        }
        private BClass? _class;

        public INameSet<Bsid> Names => InGetNames();

        public IEntity Source { get; private set; } = source;
        public IEntity Latent { get; private set; } = latent;

        public bool TryGetValue(Bsid bid, out object? value) {
            if (_deleted.Contains(bid) || bid.IsNothing) return (value = null) != null;

            if (Source.TryGetValue(bid, out value)) return true;

            if (_skipRead != null && _skipRead(bid)) return (value = null) != null;

            return Latent.TryGetValue(bid, out value);
        }
        public bool TrySetValue(Bsid bid, object? value) {
            if (_isLocked || bid.IsNothing) return false;
            if (value is DBNull) _deleted.Add(bid);
            else _deleted.Remove(bid);

            if (Source.TrySetValue(bid, value)) return true;
            return Latent.TrySetValue(bid, value);
        }
        public bool Clear() {
            if (_isLocked) return false;
            Source.Clear();
            Latent.Clear();
            _deleted.Clear();
            return true;
        }
        public bool TryRemoveValue(Bsid name) {
            if (_isLocked || name.IsNothing) return false;
            _deleted.Add(name);
            if (Source.TryRemoveValue(name)) return true;
            return Latent.TryRemoveValue(name);
        }

        public void ChangeDisplayBid(Bsid name) => Source.ChangeDisplayBid(name);
        public bool Readonly(bool? readOnly = null) {
            if (readOnly != null) _isLocked = readOnly.Value;
            return _isLocked;
        }

        private INameSet<Bsid> InGetNames() {
            var retval = Prior.CreateCNames();
            retval.AddRange(Source.GetNames<Bsid>());
            if (!Latent.IsEmpty) retval.AddRange(Latent.GetNames<Bsid>());
            retval.RemoveRange(_deleted);
            return retval;
        }
        private IEnumerable<IUnit> InGetUnits() {
            var visited = Prior.CreateQNames().AddRange(_deleted);

            foreach (var unit in Source) {
                var name = unit.Name;
                if (_deleted.Contains(name)) continue;
                visited.Add(name);
                yield return unit;
            }

            foreach (var unit in Source) {
                var name = unit.Name;
                if (visited.Contains(name)) continue;
                yield return unit;
            }
        }

        public bool Validate(ILogger logger) => (Source as IValidator)?.Validate(logger) ?? false;
        public IEnumerator<IUnit> GetEnumerator() => InGetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => InGetUnits().GetEnumerator();

    }
    file static class Properties {
        public static readonly Bsid Name = nameof(Name);
    }
}