﻿namespace Binean.Private {
    internal sealed class Gettable(Gettable.Getter gettable) : IGettable {
        public delegate bool Getter(Bsid bid, out object? value);
        private readonly Getter _gettable = gettable;

        public bool TryGetValue(Bsid bid, out object? value)
            => _gettable(bid, out value);
    }
}