﻿namespace Binean.Foundation.Cells {
    /// <summary>
    /// REST async cell
    /// </summary>
    public class RTCell : BEntity, ITCell {
        public bool Process(IMessage message) {
            var retVal = Task.Factory.StartNew(async () => await ProcessAsyn(message)).Unwrap().GetAwaiter().GetResult();
            return retVal;
        }
        public async ValueTask<bool> ProcessAsyn(IMessage message) {
            message.LogInfo();
            if (!message.TryGetMethod(out Bsid method)) return message.BadRequest();

            try {
                if (method == BMethods.list) return await OnList(message);
                if (method == BMethods.read) return await OnRead(message);
                if (method == BMethods.create) return await OnCreate(message);
                if (method == BMethods.replace) return await OnReplace(message);
                if (method == BMethods.update) return await OnUpdate(message);
                if (method == BMethods.delete) return await OnDelete(message);
                if (method == BMethods.head) return await OnHead(message);
                if (method == BMethods.option) return await OnOption(message);
                if (method == BMethods.trace) return await OnTrace(message);
                if (method == BMethods.connect) return await OnConnect(message);
                return await OnOther(method, message);
            } catch (Exception ex) {
                return message.Faulted(ex.Correct());
            }
        }
        /// <summary>
        /// To fetch a group of resources
        /// </summary>
        public virtual ValueTask<bool> OnList(IMessage message) => ValueTask.FromResult(message.NotFound());

        /// <summary>
        /// To fetch a single resource
        /// </summary>
        public virtual ValueTask<bool> OnRead(IMessage message) => ValueTask.FromResult(message.NotFound());

        /// <summary>
        /// To fetch a single resource or group of resources
        /// </summary>
        public virtual ValueTask<bool> OnCreate(IMessage message) => ValueTask.FromResult(message.NotFound());

        /// <summary>
        /// To update an entire resource in one go
        /// </summary>
        public virtual ValueTask<bool> OnReplace(IMessage message) => ValueTask.FromResult(message.NotFound());
        /// <summary>
        /// To partially update a resource
        /// </summary>
        public virtual ValueTask<bool> OnUpdate(IMessage message) => ValueTask.FromResult(message.NotFound());

        /// <summary>
        /// To delete a resource
        /// </summary>
        public virtual ValueTask<bool> OnDelete(IMessage message) => ValueTask.FromResult(message.NotFound());

        /// <summary>
        /// To get metadata of the endpoint
        /// </summary>
        public virtual ValueTask<bool> OnHead(IMessage message) => ValueTask.FromResult(message.NotFound());
        /// <summary>
        /// To get information on permitted operations
        /// </summary>
        public virtual ValueTask<bool> OnOption(IMessage message) => ValueTask.FromResult(message.Return(
            Prior.CreateQEntity().QSet(Properties.Date, DateTime.Now)));

        /// <summary>
        /// For diagnosing purposes
        /// </summary>
        public virtual ValueTask<bool> OnTrace(IMessage message) => ValueTask.FromResult(message.NotFound());

        /// <summary>
        /// To make the two-way connection between the client and the resource.
        /// </summary>
        public virtual ValueTask<bool> OnConnect(IMessage message) => ValueTask.FromResult(message.NotFound());

        /// <summary>
        /// Other
        /// </summary>
        public virtual ValueTask<bool> OnOther(Bsid method, IMessage message) => ValueTask.FromResult(message.NotFound());
    }
    file static class Properties {
        public static readonly Bsid Date = nameof(Date);
    }
}

