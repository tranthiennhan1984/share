﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Xml.Linq;

namespace Binean.Foundation.Cells {

    [CEntity]
    public sealed class FileCell(string? location) : RCell, IGettable {
        public FileCell() : this(null) { }

        [CProp]
        public string Location {
            get => _location;
            set => _location = value.AssertFolderPath();
        }
        private string _location = (location ?? string.Empty).AssertFolderPath();

        [CProp]
        public bool IsReadonly { get; set; }

        [CProp]
        public Bsid Format { get; set; } = Eformat.cen;

        [CProp]
        public bool Mountable { get; set; }

        public bool TryGetValue(Bsid bid, [NotNullWhen(true)] out object? value) {
            if (bid.IsNothing) return (value = null) != null;
            var location = CorrectPath((string)bid);

            if (!Directory.Exists(location)) {
                if (IsReadonly) return (value = null) != null;
                Directory.CreateDirectory(location);
            }
            value = new FileCell {
                Location = location,
                IsReadonly = IsReadonly,
                Format = Format,
            };
            return true;
        }

        public override bool OnMount(IMessage message) {
            if (!Mountable) return message.Forbidden();

            if (!message.TryUnboxRequest(out FileCnArgs? args)) {
                return message.Return(CloneInfo());
            }

            if (args.Folder is not string location || string.IsNullOrWhiteSpace(location)) {
                if (args.Path is not string path || string.IsNullOrWhiteSpace(path))
                    return message.BadRequest(nameof(Logs.BFND7011E));
                if (Path.GetDirectoryName(CorrectPath(path)) is not string fd || string.IsNullOrWhiteSpace(fd))
                    return message.BadRequest(nameof(Logs.BFND7011E));
                location = fd;
            } else location = CorrectPath(location);

            if (!Directory.Exists(location)) {
                Directory.CreateDirectory(location);
            }

            Location = location;
            return message.Return(CloneInfo());
        }
        public override bool OnConnect(IMessage message) {
            if (!message.TryUnboxRequest(out FileCnArgs? args)) return message.BadRequest();

            if (args.Folder is not string location || string.IsNullOrWhiteSpace(location)) {
                if (args.Path is not string path || string.IsNullOrWhiteSpace(path))
                    return message.BadRequest(nameof(Logs.BFND7011E));
                if (Path.GetDirectoryName(CorrectPath(path)) is not string fd || string.IsNullOrWhiteSpace(fd))
                    return message.BadRequest(nameof(Logs.BFND7011E));
                location = fd;
            } else location = CorrectPath(location);

            if (!Directory.Exists(location)) {
                if (IsReadonly || !args.CreateIfNotExist) return message.NoContent();
                Directory.CreateDirectory(location);
            }
            return message.Return(new FileCell {
                Location = location,
                IsReadonly = IsReadonly,
                Format = Format,
            });
        }
        public override bool OnOption(IMessage message) {
            return base.OnOption(message);
        }
        public override bool OnHead(IMessage message) {
            if (!message.TryUnboxRequest(out FileHdArgs? args)) return message.BadRequest();
            if (args.Path is not string filePath || string.IsNullOrWhiteSpace(filePath))
                return message.BadRequest(nameof(Logs.BFND7011E));

            var ext = Path.GetExtension(filePath);
            if (string.IsNullOrWhiteSpace(ext)) {
                ext = (string)Format;
                filePath = Path.ChangeExtension(filePath, $".{ext}");
            }
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists) return message.NotFound();

            return args.NameOnly ? message.Return(fileInfo.FullName)
                : message.Return(ToFileInfo(fileInfo));
        }

        public override bool OnList(IMessage message) {
            if (!message.TryUnboxRequest(out FileLsArgs? args, false)) args = new FileLsArgs();
            if (args.Path is not string path) path = Location;
            else path = CorrectPath(path);

            if (File.Exists(path)) path = CorrectPath(Path.GetDirectoryName(path));
            if (!Directory.Exists(path)) return message.NoContent();

            var nameOnly = args.NameOnly;
            var retVal = Prior.CreateList();
            if (args.ListType == FileListType.Folder) {
                var list = Directory.GetDirectories(path, args.Filter ?? "*.*", args.FindAll ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
                foreach (var item in list) {
                    var dirInfo = new DirectoryInfo(item);
                    if (!dirInfo.Exists) continue;
                    if (nameOnly) retVal.Add(Path.GetFileNameWithoutExtension(item));
                    else retVal.Add(ToDirInfo(dirInfo));
                }
            } else {
                var list = Directory.GetFiles(path, args.Filter ?? "*.*", args.FindAll ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
                foreach (var item in list) {
                    var fileInfo = new FileInfo(item);
                    if (!fileInfo.Exists) continue;
                    if (nameOnly) retVal.Add(Path.GetFileNameWithoutExtension(item));
                    else retVal.Add(ToFileInfo(fileInfo));
                }
            }
            return message.Return(retVal);
        }
        public override bool OnRead(IMessage message) {
            if (!message.TryUnboxRequest(out FileRdArgs? args)) return message.BadRequest();
            if (args.Path is not string filePath || string.IsNullOrWhiteSpace(filePath))
                return message.BadRequest(nameof(Logs.BFND7011E));

            filePath = CorrectPath(filePath);

            var fmt = args.Format;
            var ext = Path.GetExtension(filePath).TrimStart('.');
            if (fmt.IsNothing) fmt = string.IsNullOrWhiteSpace(ext) ? Format : (Bsid)ext;
            if (string.IsNullOrWhiteSpace(ext)) filePath = Path.ChangeExtension(filePath, $".{fmt}");

            if (!File.Exists(filePath)) return message.Conflict(nameof(Logs.BFND7013E), filePath);

            var contentType = args.Type;
            if (contentType == ContentType.Text || string.Compare(fmt, "txt", true) == 0) {
                return message.Return(File.ReadAllText(filePath));
            }
            if (contentType == ContentType.Blob) {
                return message.Return(File.ReadAllBytes(filePath));
            }
            if (contentType == ContentType.Stream) {
                return message.Return(File.OpenRead(filePath));
            }

            if (Eformat.Get(fmt) is not IEformat format) return message.BadRequest(nameof(Logs.BFND7012E), fmt);

            if (contentType == ContentType.Reader) {
                return message.Return(format.Serialize(File.OpenRead(filePath).CreateTextReader(), args.Configs).Assert());
            }

            using (var stream = File.OpenRead(filePath)) {
                using (var reader = format.Serialize(stream, args.Configs).Assert()) {
                    reader.ToSetter()?.QSet(Properties.Location, filePath);
                    if (args.TmplArgs is IGetter tmplArgs) reader.TemplateArgs = tmplArgs;
                    return message.Return(Men.ToObject(reader));
                }
            }
        }
        public override bool OnCreate(IMessage message)
            => InUpdate(message, create: true);
        public override bool OnUpdate(IMessage message)
            => InUpdate(message);
        public override bool OnReplace(IMessage message)
            => InUpdate(message, replace: true);
        private bool InUpdate(IMessage message, bool replace = false, bool create = false) {
            if (IsReadonly) return message.NotFound();
            if (!Directory.Exists(Location)) Directory.CreateDirectory(Location);

            if (!message.TryUnboxRequest(out FileUdArgs? args)) return message.BadRequest();
            if (args.Path is not string filePath || string.IsNullOrWhiteSpace(filePath))
                return message.BadRequest(nameof(Logs.BFND7011E));

            filePath = CorrectPath(filePath);

            if (create && Directory.Exists(filePath)) return message.NotFound();

            var fmt = args.Format;
            var ext = Path.GetExtension(filePath).TrimStart('.');
            if (fmt.IsNothing) fmt = string.IsNullOrWhiteSpace(ext) ? Format : (Bsid)ext;
            if (string.IsNullOrWhiteSpace(ext)) filePath = Path.ChangeExtension(filePath, $".{ext = (string)fmt}");

            if (create && File.Exists(filePath)) return message.NotFound();
            if (create) replace = true;
            if (!replace && !File.Exists(filePath)) return message.Conflict(nameof(Logs.BFND7013E), filePath);

            var contentType = args.Type;
            if (contentType == ContentType.Text || string.Compare(fmt, "txt", true) == 0) {
                File.WriteAllText(filePath, args.Content.Convert(() => string.Empty));
                return message.Return(filePath);
            }
            if (contentType == ContentType.Blob) {
                if (args.Content is byte[] content) File.WriteAllBytes(filePath, content);
                else File.WriteAllText(filePath, string.Empty);
                return message.Return(filePath);
            }
            if (contentType == ContentType.Stream) {
                if (args.Content is Stream stream) {
                    stream.Seek(0, SeekOrigin.Begin);
                    using (var ws = File.Create(filePath)) {
                        stream.CopyTo(ws);
                    }
                } else File.WriteAllText(filePath, string.Empty);
                return message.Return(filePath);
            }

            if (Eformat.Get(fmt) is not IEformat format) return message.BadRequest(nameof(Logs.BFND7012E), fmt);

            Reader? reader = null;
            if (contentType == ContentType.Reader) reader = args.Content.Convert<Reader>();
            reader ??= Men.Serialize(args.Content).Assert();

            var configs = args.Configs;
            using (var stream = File.Create(filePath)) {
                using (var writer = format.Deserialize(stream, configs).Assert()) {
                    writer.ToSetter()?.QSet(Properties.Location, filePath);
                    if (reader is MenReader dr) dr.TagMode = configs.Get(Properties.TagMode, TagMode.Tag);
                    writer.Write(reader);
                }
            }
            return message.Return(filePath);
        }

        public override bool OnDelete(IMessage message) {
            if (!message.TryUnboxRequest(out FileArgs? args)) return message.BadRequest();
            if (args.Path is not string filePath || string.IsNullOrWhiteSpace(filePath))
                return message.BadRequest(nameof(Logs.BFND7011E));

            filePath = CorrectPath(filePath);

            var ext = Path.GetExtension(filePath);
            if (string.IsNullOrWhiteSpace(ext)) filePath = Path.ChangeExtension(filePath, $".{Format}");

            if (!File.Exists(filePath)) return message.Conflict(nameof(Logs.BFND7013E), filePath);

            File.Delete(filePath);
            return message.Return(filePath);
        }
        private string CorrectPath(string? path) => string.IsNullOrWhiteSpace(path) ? _location : Path.IsPathRooted(path) ? path : Path.Combine(_location, path);

        private Entity CloneInfo() {
            var retVal = Prior.CreateQEntity();
            using (var writer = Men.Deserialize(retVal)) {
                using (var reader = Men.Serialize(this).Assert()) {
                    writer.Write(reader);
                }
            }
            return retVal;
        }
        private static Entity ToFileInfo(FileInfo fileInfo)
            => Prior.CreateQEntity()
                .QSet(nameof(fileInfo.Name), fileInfo.Name)
                .QSet(nameof(fileInfo.FullName), fileInfo.FullName)
                .QSet(nameof(fileInfo.Length), fileInfo.Length)
                .QSet(nameof(fileInfo.IsReadOnly), fileInfo.IsReadOnly)
                .QSet(nameof(fileInfo.CreationTime), fileInfo.CreationTime)
                .QSet(nameof(fileInfo.LastWriteTime), fileInfo.LastWriteTime)
                .QSet(nameof(fileInfo.LastAccessTime), fileInfo.LastAccessTime);
        private static Entity ToDirInfo(DirectoryInfo dirInfo)
            => Prior.CreateQEntity()
                .QSet(nameof(dirInfo.Name), dirInfo.Name)
                .QSet(nameof(dirInfo.FullName), dirInfo.FullName)
                .QSet(nameof(dirInfo.CreationTime), dirInfo.CreationTime)
                .QSet(nameof(dirInfo.LastWriteTime), dirInfo.LastWriteTime)
                .QSet(nameof(dirInfo.LastAccessTime), dirInfo.LastAccessTime);

    }

    file static class Properties {
        public static readonly Bsid Location = nameof(Location);

        public static readonly Bsid NameOnly = nameof(NameOnly);

        public static readonly Bsid Path = nameof(Path);
        public static readonly Bsid Folder = nameof(Folder);

        public static readonly Bsid Format = nameof(Format);
        public static readonly Bsid Content = nameof(Content);

        public static readonly Bsid Configs = nameof(Configs);

        public static readonly Bsid TagMode = nameof(TagMode);

        public static readonly Bsid Type = nameof(Type);
        public static readonly Bsid TmplArgs = nameof(TmplArgs);

        public static readonly Bsid ListType = nameof(ListType);
        public static readonly Bsid Filter = nameof(Filter);
        public static readonly Bsid FindAll = nameof(FindAll);
        public static readonly Bsid CreateIfNotExist = nameof(CreateIfNotExist);
    }
    public enum ContentType {
        Object,
        Text,
        Blob,
        Stream,
        Reader,
    }

    [CEntity]
    public class FileArgs : BEntity {
        [CProp]
        public string? Path { get; set; }
    }
    [CEntity]
    public sealed class FileCnArgs : FileArgs {
        [CProp]
        public string? Folder {
            get => Potential.QGet<string>(Properties.Folder);
            set => Potential.QSet(Properties.Folder, value);
        }
        [CProp]
        public bool CreateIfNotExist {
            get => Potential.QGet<bool>(Properties.CreateIfNotExist);
            set => Potential.QSet(Properties.CreateIfNotExist, value);
        }
    }
    [CEntity]
    public abstract class FileCmArgs : FileArgs {
        [CProp]
        public Bsid Format { get; set; } = Bsid.Nothing;
        [CProp]
        public ContentType? Type { get; set; }
        [CProp]
        public IGetter? Configs { get; set; }
    }
    [CEntity]
    public sealed class FileRdArgs : FileCmArgs {
        [CProp]
        public IGetter? TmplArgs { get; set; }
    }
    [CEntity]
    public sealed class FileUdArgs : FileCmArgs {
        [CProp]
        public object? Content { get; set; }
    }
    [CEntity]
    public class FileHdArgs : FileArgs {
        [CProp]
        public bool NameOnly { get; set; } = true;
    }
    [CEntity]
    public sealed class FileLsArgs : FileHdArgs {
        [CProp]
        public FileListType? ListType { get; set; }
        [CProp]
        public string? Filter { get; set; }
        [CProp]
        public bool FindAll { get; set; }
    }
    public enum FileListType {
        File,
        Folder
    }
}

namespace Binean.Foundation {
    public static class BFile {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICell? Connect(this ICell cell, string file, IMessage? message = null, bool assert = false, Bip? path = null)
            => cell.Connect(new FileArgs { Path = file }, message, null, assert, path);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Exists(this ICell cell, string file, IMessage? message = null, bool assert = false, Bip? path = null)
            => cell.Exists(new FileArgs { Path = file }, message, null, assert, path);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IGetter? Head(this ICell cell, string file, IMessage? message = null, bool assert = false, Bip? path = null)
            => cell.Head<IGetter>(new FileArgs { Path = file }, message, null, assert, path);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Read<T>(this ICell cell, FileRdArgs args, IMessage? message = null, Func<T>? failback = null, bool assert = false, Bip? path = null)
            => Core.Extension.Read(cell, args, message, failback, assert, path);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? Create(this ICell cell, FileUdArgs args, IMessage? message = null, bool assert = false, Bip? path = null)
            => cell.Create<string>(args, message, null, assert, path);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? Update(this ICell cell, FileUdArgs args, IMessage? message = null, bool assert = false, Bip? path = null)
            => cell.Update<string>(args, message, null, assert, path);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? Replace(this ICell cell, FileUdArgs args, IMessage? message = null, bool assert = false, Bip? path = null)
            => cell.Replace<string>(args, message, null, assert, path);


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? Delete(this ICell cell, string file, IMessage? message = null, bool assert = false, Bip? path = null)
            => cell.Delete<string>(new FileArgs { Path = file }, message, null, assert, path);
    }
}
