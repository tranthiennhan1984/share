﻿using System.Diagnostics.CodeAnalysis;

namespace Binean.Foundation.Cells {
    [BMessage]
    file static class Messages {
        public const string BFND070401E = "Missing name.";
        public const string BFND070402E = "Invalid request Path '{0}'; only name allowed.";
        public const string BFND070403E = "The item named '{0}' already exists.";
    }
    /// <summary>
    /// Entity Cell
    /// </summary>
    [CEntity]
    public class ECell : RCell {
        public ECell() : base(null) { }
        public ECell(IEntity? entity) : base(entity) { }
        public override bool OnConnect(BRequest request) {
            if (!TryGetName(request, out string? name)) return request.BadRequest();
            if (!_entity.TryGetValue(name, out object? value)) return request.NotFound();
            return request.Success(value);
        }
        public override bool OnList(BRequest request) {
            var list = new List<string>();
            _entity.Each(i => list.Add(i.Name));
            return request.Success(list.ToArray());
        }
        public override bool OnRead(BRequest request) {
            if (!TryGetName(request, out string? name)) return request.BadRequest();
            if (!_entity.TryGetValue(name, out object? value)) return request.NotFound();
            return request.Success(Men.Clone(value));
        }
        public override bool OnCreate(BRequest request) {
            if (!TryGetName(request, out string? name)) return request.BadRequest();

            if (_entity.Contains(name)) return request.Conflict(nameof(Messages.BFND070402E), name);

            _entity.Set(name, request.Request);
            return request.Success(name);
        }
        public override bool OnReplace(BRequest request) {
            if (!TryGetName(request, out string? name)) return request.BadRequest();
            _entity.Set(name, request.Request);
            return request.Success(name);
        }
        public override bool OnDelete(BRequest request) {
            if (!TryGetName(request, out string? name)) return request.BadRequest();
            if (!_entity.Contains(name)) return request.NotFound();
            _entity.Remove(name);
            return request.NoContent();
        }

        public override bool OnHead(BRequest request) {
            if (!TryGetName(request, out string? name)) return request.BadRequest();
            if (!_entity.Contains(name)) return request.NotFound();
            return request.Success(name);
        }

        protected static bool TryGetName(BRequest request, [NotNullWhen(true)] out string? name) {
            if (!request.TryGetPath(out Propath? path)) return (name = null) != null;
            if (path.Count > 1) {
                request.Log(nameof(Messages.BFND070402E), path);
                return (name = null) != null;
            }
            if (path.Count == 0) {
                request.Log(nameof(Messages.BFND070401E));
                return (name = null) != null;
            }
            name = path[0];
            if (string.IsNullOrWhiteSpace(name)) {
                request.Log(nameof(Messages.BFND070401E));
                return false;
            }
            return true;
        }
    }
}