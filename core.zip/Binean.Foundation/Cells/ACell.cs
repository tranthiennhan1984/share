﻿using System.Diagnostics.CodeAnalysis;


namespace Binean.Foundation.Cells {

    /// <summary>
    /// Attachable cell
    /// </summary>
    public class ACell : IACell, ITCell, IGettable {
        public delegate bool InitializeHandler(IMessage message, out Bsid name, out IEntity? tag);
        public delegate void FinalizeHandler(IMessage message, IEntity? tag);

        protected readonly Entity _cells = Prior.CreateQEntity();
        protected InitializeHandler _initialize = PathInitialize;
        protected FinalizeHandler _finalize = PathFinalize;

        public virtual IGetter Cells => _cells;

        public bool Process(IMessage message) {
            message.LogInfo();

            if (!_initialize(message, out Bsid bid, out IEntity? tag) || bid.IsNothing)
                return OnMissingName(message);

            if (!OnGetCell(bid, out ICell? cell)) {
                _finalize(message, tag);
                return OnMissingCell(message, bid);
            }

            try {
                return cell.Process(message);
            } catch (Exception ex) {
                return message.Faulted(ex.Correct());
            } finally {
                _finalize(message, tag);
            }
        }
        public async ValueTask<bool> ProcessAsyn(IMessage message) {
            message.LogInfo();
            if (!_initialize(message, out Bsid name, out IEntity? tag) || name.IsNothing)
                return await OnMissingNameAsync(message);

            if (!OnGetCell(name, out ICell? cell)) {
                _finalize(message, tag);
                return await OnMissingCellAsync(message, name);
            }

            try {
                return await cell.ProcessAsync(message);
            } catch (Exception ex) {
                return message.Faulted(ex.Correct());
            } finally {
                _finalize(message, tag);
            }
        }

        public virtual void AttachCell(Bsid name, ICell cell, bool guarantee = true)
            => OnAttachCell(_cells, name, cell, guarantee);

        protected virtual bool OnMissingName(IMessage message) => message.NotFound();
        protected virtual bool OnMissingCell(IMessage message, Bsid name) => message.NotFound();
        protected virtual ValueTask<bool> OnMissingNameAsync(IMessage message) => ValueTask.FromResult(message.NotFound());
        protected virtual ValueTask<bool> OnMissingCellAsync(IMessage message, Bsid name) => ValueTask.FromResult(message.NotFound());

        protected virtual bool OnGetCell(Bsid name, [NotNullWhen(true)] out ICell? cell)
            => _cells.TryGetNotNull(name, out cell);
        protected virtual void OnAttachCell(IEntity cells, Bsid name, ICell cell, bool guarantee) {
            if (name.IsNothing) {
                if (guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND7032E));
                return;
            }
            if (cells.TryGetValue(name, out _)) {
                if (guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND7031E), name);
                return;
            }
            cells.Set(name, cell, guarantee);
        }

        public static bool PathInitialize(IMessage message, out Bsid name, out IEntity? tag) {
            if (!message.TryGetPath(out Bip? path)) {
                name = Bsid.Nothing;
                tag = null;
                return false;
            }
            name = path.Peek();
            message.AssertAddress().Path = path.Clone(1);
            tag = Prior.CreateQEntity().QSet(Properties.Path, path);
            return true;
        }
        public static void PathFinalize(IMessage message, IEntity? tag) {
            if (tag?.QGet(Properties.Path) is Bip path) message.AssertAddress().Path = path;
        }

        public bool TryGetValue(Bsid bid, out object? value) => Cells.TryGetValue(bid, out value);
    }

    /// <summary>
    /// Cachable cell
    /// </summary>
    public sealed class CCell : ACell {
        private readonly Entity _ccells = Prior.CreateEntity();
        public void ClearCache() {
            _ccells.Clear();
        }
        public override void AttachCell(Bsid name, ICell cell, bool guarantee = true)
            => OnAttachCell(_ccells, name, cell, guarantee);
        protected override bool OnGetCell(Bsid name, [NotNullWhen(true)] out ICell? cell) {
            if (_ccells.TryGetNotNull(name, out cell)) return true;
            return base.OnGetCell(name, out cell);
        }
        /// <summary>
        /// Statable attach
        /// </summary>
        public void SAttachCell(Bsid name, ICell cell, bool guarantee = true)
            => OnAttachCell(_cells, name, cell, guarantee);
    }

    /// <summary>
    /// Virtual cell
    /// </summary>
    [CEntity]
    public sealed class VCell(ICell cell, Bip? path = null) : ICell, ITCell {
        private readonly ICell _cell = cell;

        [CProp]
        public Bip? Path { get; set; } = path;
        public bool Process(IMessage message) {
            message.LogInfo();
            using (message.AssertAddress().Potential.Swap(nameof(Path), Path, !Path.IsNullOrEmpty())) {
                return _cell.Process(message);
            }
        }
        public async ValueTask<bool> ProcessAsyn(IMessage message) {
            message.LogInfo();
            using (message.AssertAddress().Potential.Swap(nameof(Path), Path, !Path.IsNullOrEmpty())) {
                return await _cell.ProcessAsync(message);
            }
        }
    }

    /// <summary>
    /// Method cell
    /// </summary>
    [CEntity]
    public sealed class MCell : ACell {
        public MCell() {
            PathAllowed = false;
        }

        [CProp]
        public bool PathAllowed {
            get => _pathAllowed;
            set {
                _pathAllowed = value;
                _initialize = value ? InPathInitialize : InInitialize;
                _finalize = value ? InPathFinalize : InFinalize;
            }
        }
        private bool _pathAllowed;

        private bool InInitialize(IMessage message, out Bsid name, out IEntity? tag) {
            if (message.TryGetMethod(out name)) {
                message.AssertAddress().Potential.TryRemoveValue(Properties.Method);
                tag = Prior.CreateQEntity().QSet(Properties.Method, name);
                return true;
            }

            name = Bsid.Nothing;
            tag = null;
            return false;
        }
        private void InFinalize(IMessage message, IEntity? tag) {
            if (tag?.QGet(Properties.Method) is Bsid method) message.AssertAddress().Method = method;
        }
        private bool InPathInitialize(IMessage message, out Bsid name, out IEntity? tag) {
            if (PathInitialize(message, out name, out tag)) return true;
            return InInitialize(message, out name, out tag);
        }
        private void InPathFinalize(IMessage message, IEntity? tag) {
            var address = message.AssertAddress();
            if (tag?.QGet(Properties.Path) is Bip path) address.Path = path;
            if (tag?.QGet(Properties.Method) is Bsid method) address.Method = method;
        }
    }

    /// <summary>
    /// Procedure cell
    /// </summary>
    public class PCell : ICell {
        protected readonly Entity _fucs = Prior.CreateQEntity();
        public virtual bool Process(IMessage message) {
            message.LogInfo();
            if (!message.TryGetMethod(out Bsid method)) return message.BadRequest();
            if (!OnGetProc(method, out Proc? proc)) return message.NotFound();
            return proc(message);
        }

        public virtual void AttachProc(Bsid name, Proc proc, bool guarantee = true)
            => OnAttachProc(_fucs, name, proc, guarantee);

        protected virtual bool OnGetProc(Bsid name, [NotNullWhen(true)] out Proc? proc)
            => _fucs.TryGetNotNull(name, out proc);
        protected virtual void OnAttachProc(IEntity cells, Bsid name, Proc proc, bool guarantee) {
            if (name.IsNothing) {
                if (guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND7032E));
                return;
            }
            if (cells.TryGetValue(name, out _)) {
                if (guarantee) throw MessageStorage.CreateException(nameof(Logs.BFND7031E), name);
                return;
            }
            cells.QSet(name, proc, guarantee);
        }
    }
    file static class Properties {
        public static readonly Bsid Path = nameof(Path);
        public static readonly Bsid Method = nameof(Method);
    }
}

