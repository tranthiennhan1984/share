﻿namespace Binean.Foundation.Cells {
    /// <summary>
    /// REST cell
    /// </summary>
    public class RCell : BEntity, ICell {
        public bool Process(IMessage message) {
            message.LogInfo();
            if (!message.TryGetMethod(out Bsid method)) return message.BadRequest();

            try {
                if (method == BMethods.list) return OnList(message);
                if (method == BMethods.read) return OnRead(message);
                if (method == BMethods.create) return OnCreate(message);
                if (method == BMethods.replace) return OnReplace(message);
                if (method == BMethods.update) return OnUpdate(message);
                if (method == BMethods.delete) return OnDelete(message);
                if (method == BMethods.head) return OnHead(message);
                if (method == BMethods.option) return OnOption(message);
                if (method == BMethods.trace) return OnTrace(message);
                if (method == BMethods.connect) return OnConnect(message);
                if (method == BMethods.mount) return OnMount(message);
                return OnOther(method, message);
            } catch (Exception ex) {
                return message.Faulted(ex.Correct());
            }
        }

        /// <summary>
        /// To fetch a group of resources
        /// </summary>
        public virtual bool OnList(IMessage message) => message.NotFound();

        /// <summary>
        /// To fetch a single resource
        /// </summary>
        public virtual bool OnRead(IMessage message) => message.NotFound();

        /// <summary>
        /// To fetch a single resource or group of resources
        /// </summary>
        public virtual bool OnCreate(IMessage message) => message.NotFound();

        /// <summary>
        /// To update an entire resource in one go
        /// </summary>
        public virtual bool OnReplace(IMessage message) => message.NotFound();
        /// <summary>
        /// To partially update a resource
        /// </summary>
        public virtual bool OnUpdate(IMessage message) => message.NotFound();

        /// <summary>
        /// To delete a resource
        /// </summary>
        public virtual bool OnDelete(IMessage message) => message.NotFound();

        /// <summary>
        /// To get metadata of the endpoint
        /// </summary>
        public virtual bool OnHead(IMessage message) => message.NotFound();
        /// <summary>
        /// To get information on permitted operations
        /// </summary>
        public virtual bool OnOption(IMessage message) => message.Return(
            Prior.CreateQEntity().QSet(Properties.Date, DateTime.Now));

        /// <summary>
        /// For diagnosing purposes
        /// </summary>
        public virtual bool OnTrace(IMessage message) => message.NotFound();

        /// <summary>
        /// To make the two-way connection between the client and the resource.
        /// </summary>
        public virtual bool OnConnect(IMessage message) => message.NotFound();

        /// <summary>
        /// Mount new resource, change location or add new resource
        /// </summary>
        public virtual bool OnMount(IMessage message) => message.NotFound();

        /// <summary>
        /// Other
        /// </summary>
        public virtual bool OnOther(Bsid method, IMessage message) => message.NotFound();
    }
    file static class Properties {
        public static readonly Bsid Date = nameof(Date);
    }
}

