﻿using Binean.Foundation.Core;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Cells {
    [BMessage]
    file static class Messages {
        public const string BFND070201E = "Missing folder path.";
        public const string BFND070202E = "Folder '{0}' does not exist.";
    }
    file static class Properties {
        public const string Location = nameof(Location);
        public const string Path = nameof(Path);
        public const string Content = nameof(Content);
    }

    [CEntity]
    public sealed class FolderCell : RCell {
        public FolderCell(string? location = null) {
            _location = (location ?? string.Empty).AssertFolderPath();
        }

        [CProp]
        public string Location {
            get => _location;
            set => _location = value.AssertFolderPath();
        }
        private string _location = string.Empty;

        [CProp]
        public bool IsReadonly { get; set; }

        [CProp]
        public bool Mountable { get; set; }

        public override bool OnConnect(BRequest request) {
            var folderPath = GetPath(request);
            if (string.IsNullOrWhiteSpace(folderPath)) return request.NoContent();
            return request.Success(new FolderCell {
                Location = folderPath,
                IsReadonly = IsReadonly
            });
        }

        public override bool OnHead(BRequest request) {
            var folderPath = GetPath(request);
            if (string.IsNullOrWhiteSpace(folderPath)) return request.BadRequest(nameof(Messages.BFND070201E));

            var dirInfo = new DirectoryInfo(folderPath);
            if (!dirInfo.Exists) return request.NotFound();
            var resp = Prior.CreateSXEntity()
                .Set(nameof(dirInfo.FullName), dirInfo.FullName)
                .Set(nameof(dirInfo.CreationTime), dirInfo.CreationTime)
                .Set(nameof(dirInfo.LastWriteTime), dirInfo.LastWriteTime)
                .Set(nameof(dirInfo.LastAccessTime), dirInfo.LastAccessTime);

            return request.Success(resp);
        }

        public override bool OnCreate(BRequest request) {
            var folderPath = GetPath(request);
            if (IsReadonly) return request.NotFound();

            if (string.IsNullOrWhiteSpace(folderPath)) return request.BadRequest(nameof(Messages.BFND070201E));

            if (Directory.Exists(folderPath) || File.Exists(folderPath))
                return request.Success(folderPath);

            var ext = Path.GetExtension(folderPath);
            if (!string.IsNullOrWhiteSpace(ext)) return request.NotFound();

            Directory.CreateDirectory(folderPath);
            return request.Success(folderPath);
        }
        public override bool OnDelete(BRequest request) {
            var folderPath = GetPath(request);
            if (string.IsNullOrWhiteSpace(folderPath)) return request.BadRequest(nameof(Messages.BFND070201E));

            if (!Directory.Exists(folderPath)) return request.Conflict(nameof(Messages.BFND070202E), folderPath);
            Directory.Delete(folderPath, true);
            return request.Success(folderPath);
        }

        private string? GetPath(BRequest request) {
            if (!request.TryBEntity(out FolderCArgs? args) || args.Path is not string path) return null;
            return CorrectPath(path);
        }
        private string CorrectPath(string path) => Path.IsPathRooted(path) ? path : Path.Combine(_location, path);
    }

    public sealed class FolderCArgs : BEntity {
        public string? Path {
            get => Entity.Get<string>(Properties.Path);
            set => Entity.Set(Properties.Path, value);
        }
    }
}

namespace Binean.Foundation {
    public static class BFolder {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Exists(this ICell cell, string folder, BRequest? request = null, bool assert = false, Propath? path = null)
            => cell.Exists(new FolderCArgs { Path = folder }, request, null, assert, path);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? Make(this ICell cell, string folder, BRequest? request = null, bool assert = false, Propath? path = null)
            => cell.Create<string>(new FolderCArgs { Path = folder }, request, null, assert, path);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? Remove(this ICell cell, string folder, BRequest? request = null, bool assert = false, Propath? path = null)
            => cell.Delete<string>(new FolderCArgs { Path = folder }, request, null, assert, path);
    }
}
