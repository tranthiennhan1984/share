﻿namespace Binean.Foundation.Cells {
    [BLog]
    internal static class Logs {
        public const string BFND7011E = "Missing file path.";
        public const string BFND7012E = "Format '{0}' does not exist in current context.";
        public const string BFND7013E = "File '{0}' does not exist.";

        public const string BFND7031E = "The cell named '{0}' already exists.";
        public const string BFND7032E = "The cell name must be not empty text.";

        public const string BFND7051E = "Missing name.";
        public const string BFND7052E = "Missing cell.";
    }
}

