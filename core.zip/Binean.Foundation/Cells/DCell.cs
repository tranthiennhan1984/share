﻿using System.Xml.Linq;

namespace Binean.Foundation.Cells {

    /// <summary>
    /// Dependency Cell
    /// </summary>
    public sealed class DCell(ICell cell) : ACell {
        private readonly ICell _cell = cell;

        protected override bool OnMissingCell(IMessage message, Bsid name) => _cell.Process(message);
        protected override async ValueTask<bool> OnMissingCellAsync(IMessage message, Bsid name) => await _cell.ProcessAsync(message);

        protected override bool OnMissingName(IMessage message) => OnSelfProcess(message);
        protected override async ValueTask<bool> OnMissingNameAsync(IMessage message) => await OnSelfProcessAsync(message);
        private bool OnSelfProcess(IMessage message) {
            if (!message.TryGetMethod(out Bsid method, true)) return message.BadRequest();
            if (method == Methods.mount) return OnMount(message);
            return message.NotFound();
        }
        private async ValueTask<bool> OnSelfProcessAsync(IMessage message) {
            if (!message.TryGetMethod(out Bsid method, true)) return message.BadRequest();
            if (method == Methods.mount) return OnMount(message);
            return await message.NotFoundAsync();
        }

        private bool OnMount(IMessage message) {
            if (!message.TryUnboxRequest(out DCellArgs? arg)) return message.BadRequest();
            if (arg.Name.IsNothing) return message.BadRequest(nameof(Logs.BFND7051E));
            if (arg.Cell is not ICell cell) return message.BadRequest(nameof(Logs.BFND7052E));
            AttachCell(arg.Name, cell);
            return message.Return(cell);
        }
    }

    file static class Methods {
        public static readonly Bsid mount = nameof(mount);
    }
    file static class Properties {
        public static readonly Bsid Name = nameof(Name);
        public static readonly Bsid Cell = nameof(Cell);
    }

    [CEntity]
    public sealed class DCellArgs : BEntity {
        [CProp]
        public Bsid Name {
            get => Potential.QGet(Properties.Name, Bsid.Nothing);
            set => Potential.QSet(Properties.Name, value);
        }
        [CProp]
        public ICell? Cell {
            get => Potential.QGet<ICell>(Properties.Cell);
            set => Potential.QSet(Properties.Cell, value);
        }
    }
}

