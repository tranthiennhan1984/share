﻿
using Binean.Private;
using System.Text;

namespace Binean.Foundation.Storage {
    public interface ITEntry {
        bool TryGetValue(IGetter args, out object? value);
    }
    public sealed class Template(string text, bool asString = false) {
        private static readonly EscapeContext _textEscape = new() {
            StartChar = '\\',
            EndChars = "\"\\bfnrt{",
            ReplaceChars = "\"\\\b\f\n\r\t{",
            EscapeUnicode = true
        };

        private readonly string _text = text;
        private ITEntry? _prop;

        public string Text { get => _text; }
        public bool AsString { get; set; } = asString;

        public object? Read(IGetter args) {
            var prop = _prop ??= OnParse(_text, AsString);
            return prop.TryGetValue(args, out var value) ? value : null;
        }
        private static ITEntry OnParse(string text, bool asString) {
            using (var reader = text.CreateTextReader()) {
                var entries = InParseString(reader);
                return asString || entries.Count != 1 ? new StringEntry(entries) : entries[0];
            }
        }
        private static IList<ITEntry> InParseString(ICharInput reader) {
            var entries = new List<ITEntry>();
            char chr;
            while ((chr = reader.Current) != BetextReader.EofCharacter) {
                switch (chr) {
                    case '{': {
                            reader.MoveNext();
                            entries.Add(ParseProp(reader.ReadUntil(expected: '}')));
                        }
                        break;
                    default:
                        using (var er = new EscapeReader(reader, _textEscape)) {
                            entries.Add(new TextEntry(er.ReadUntil(endCond: "{\0".Contains)));
                        }
                        break;
                }
            }
            if (entries.Count == 0) entries.Add(new TextEntry(string.Empty));
            return entries;
        }
        private static ITEntry ParseProp(string text) {
            var path = text.ToPropath()!;
            string name = (string)path.Pop()!;
            if (path.Count == 0) path = null;
            return name.StartsWith('$') ? new PropEntry((Bsid)name[1..], path, true)
                : new PropEntry((Bsid)name, path, false);
        }
    }
}

namespace Binean.Private {
    internal sealed class TextEntry(string text) : ITEntry {
        private readonly string _text = text;

        public bool TryGetValue(IGetter args, out object? value)
             => (value = _text) != null;
    }
    internal sealed class PropEntry(Bsid name, Bip? path, bool fromEnv) : ITEntry {
        private readonly bool _fromEnv = fromEnv;
        private readonly Bip? _path = path;
        private readonly Bsid _name = name;

        public bool TryGetValue(IGetter args, out object? value) {
            if (_name.IsNothing) return (value = null) != null;
            if (_fromEnv) args = Generator.Env;
            value = args.TryGetValue(_name, out object? v) ? v : null;
            if (_path is null) return true;

            if (value.ToGetter() is not IGetter getter) return (value = null) != null;
            value = getter.Read(_path);
            return true;
        }
    }
    internal sealed class StringEntry(IList<ITEntry> entries) : ITEntry {
        private readonly IList<ITEntry> _entries = entries;

        public bool TryGetValue(IGetter args, out object? value) {
            if (_entries.Count == 0) return (value = null) != null;

            var sb = new StringBuilder();
            var length = _entries.Count;
            for (int i = 0; i < length; i++) {
                var entry = _entries[i];
                if (!entry.TryGetValue(args, out object? v)) continue;
                sb.Append(v.Convert<string>());
            }
            value = sb.ToString();
            return true;
        }
    }
}