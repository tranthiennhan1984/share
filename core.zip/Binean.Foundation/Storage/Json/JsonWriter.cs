﻿namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class JsonWriter : Writer {
        private readonly BetextWriter _writer;
        private Action<JsonWriter>? _close;

        public JsonWriter(BetextWriter writer, Action? disposedAction = null, Action<JsonWriter>? close = null) {
            _content = writer;
            _close = close;
            var rootNode = new Node(NodeType.Array);
            _writer = writer;
            var deserialize = new Deserialize(WriteItem);
            if (_close != null) {
                if (disposedAction is null) disposedAction = Close;
                else {
                    var cur = disposedAction;
                    disposedAction = () => {
                        Close();
                        cur();
                    };
                }
            }

            Initialize(rootNode, deserialize, disposedAction);
        }

        [CProp]
        public string? Location {
            get => _writer.Location;
            set => _writer.Location = value;
        }

        [CProp]
        public bool Decorate {
            get => _writer.Decorate;
            set => _writer.Decorate = value;
        }

        [CProp]
        public int IndentOffset {
            get => _writer.IndentOffset;
            set => _writer.IndentOffset = value;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (block.Level < 0 && token.Type.IsEndBlock()) {
                deserialize = WriteException;
                return block.EndNode();
            }
            return WriteItem(_writer, block, token, token.Name);
        }


        public static void WriteObject(BetextWriter writer, int idenLevel, Bsid name, bool isObject) {
            writer.AssertNewLine(idenLevel, true);
            if (!name.IsNothing) {
                writer.WriteString((string)name).Write(":");
                if (writer.Decorate) writer.Write(" ");
            }
            writer.Write(isObject ? "{" : "[").EndLine();
        }
        public static void WriteEndObject(BetextWriter writer, int idenLevel, bool blockIsObject) {
            writer.AssertNewLine(idenLevel, true).Write(blockIsObject ? "}" : "]");
        }
        public static void WriteEndLine(BetextWriter writer, int itemIndex) {
            if (itemIndex >= 0) writer.EndLine(null, ',');
        }
        public static void WriteValue(BetextWriter writer, int idenLevel, Bsid name, object? value) {
            writer.AssertNewLine(idenLevel);
            if (!name.IsNothing) {
                writer.WriteString((string)name).Write(":");
                if (writer.Decorate) writer.Write(" ");
            }
            if (value is byte[] blob) writer.WriteBlob(blob, "\"", "\"");
            else writer.WriteValue(value);
        }
        public static Node WriteItem(BetextWriter writer, Node block, Token token, Bsid name, int indenOffset = 0) {
            var blockType = block.Type;
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                WriteEndObject(writer, block.Level + indenOffset, blockType.IsObject());
                return block.EndNode();
            }
            if (block.ItemIndex >= 0) writer.EndLine(null, ',');
            var idenLevel = block.Level + indenOffset + 1;

            if (tokenType.IsValue()) {
                WriteValue(writer, idenLevel, blockType.IsObject() ? name : Bsid.Nothing, token.Value);
                return block.AddItem(new Node(token.Potential));
            }

            WriteObject(writer, idenLevel, blockType.IsObject() ? name : Bsid.Nothing, tokenType.IsObject());
            return block.AddItem(new Node(token.Potential));
        }
        protected override void Close() {
            if (_close is null) return;
            _close(this);
            CanContinue = false;
            _close = null;
        }
    }
}
