﻿namespace Binean.Foundation.Storage {
    [CEntity]
    sealed class JsonLexer : IInput<Symbol> {
        private readonly ICharInput _reader;
        public JsonLexer(ICharInput reader) {
            _reader = reader;
            _reader.IsWhitespace = Json.IsWhitespace;
        }

        [CProp]
        public string? Location {
            get { return _reader.Location; }
            set { _reader.Location = value; }
        }

        [CProp]
        public object Position => _reader.Position;
        public Symbol Current { get; private set; } = Symbol.None;
        public bool IsEnd => Current == Symbol.Eof;
        public void MoveNext() {
            if (Current == Symbol.Eof) return;
            Current = Read();
        }

        public Symbol Read() {
            while (true) {
                var chr = _reader.SkipWhitespaces();

                switch (chr) {
                    case '{':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.LBRACE, chr.ToString());
                    case '}':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.RBRACE, chr.ToString());
                    case '[':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.LSQBRACKET, chr.ToString());
                    case ']':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.RSQBRACKET, chr.ToString());
                    case ':':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.COLON, chr.ToString());
                    case ',':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.COMMA, chr.ToString());
                    case '"':
                        return _reader.ReadStringSymbol();
                    case '-':
                        return _reader.ReadNumberSymbol();

                    case BetextReader.EofCharacter: return Symbol.Eof;
                }
                if (char.IsDigit(chr)) return _reader.ReadNumberSymbol();
                if (char.IsLetter(chr)) return _reader.ReadIdentifierSymbol(true);

                throw _reader.InvalidCharacter(chr);
            }
        }
    }
    static class JsonSymbol {
        public static readonly Bsid COMMA = nameof(COMMA);
        public static readonly Bsid LSQBRACKET = nameof(LSQBRACKET);
        public static readonly Bsid RSQBRACKET = nameof(RSQBRACKET);
        public static readonly Bsid LBRACE = nameof(LBRACE);
        public static readonly Bsid RBRACE = nameof(RBRACE);
        public static readonly Bsid COLON = nameof(COLON);

        public static readonly Bsid String = nameof(String);
        public static readonly Bsid Number = nameof(Number);
        public static readonly Bsid Boolean = nameof(String);
        public static readonly Bsid Null = nameof(Null);
    }
}
