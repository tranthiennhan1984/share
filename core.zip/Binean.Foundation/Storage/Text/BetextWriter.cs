﻿using System.Globalization;
using System.Text;

namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class BetextWriter(TextWriter writer, Action? disposedAction = null, EscapeContext? stringEscape = null, int tabSize = 2) : IDisposable {
        private readonly EscapeContext _stringEscape = stringEscape ?? EscapeContext.StringEscape;
        private readonly string _indentedText = tabSize < 0 ? new string('\t', -tabSize) : tabSize > 0 ? new string(' ', tabSize) : string.Empty;
        private Action? _disposedAction = disposedAction;
        private readonly string _newLine = "\n";
        private bool _isNewLine = true;
        internal TextWriter _textWriter = writer;

        public BetextWriter(TextWriter writer, bool leaveOpen = false, EscapeContext? stringEscape = null, int tabSize = 2)
            : this(writer, leaveOpen ? null : writer.Dispose, stringEscape, tabSize) { }

        public void Dispose() {
            if (_disposedAction != null) {
                _disposedAction();
                _disposedAction = null;
            }
        }

        [CProp]
        public string? Location { get; set; }

        [CProp]
        public bool Decorate { get; set; } = true;

        [CProp]
        public int IndentOffset { get; set; }

        public BetextWriter Write(string text) {
            _textWriter.Write(text);
            _isNewLine = false;
            return this;
        }

        public BetextWriter AssertNewLine(bool force = false) {
            if (_isNewLine || !force) return this;
            if (Decorate) _textWriter.Write(_newLine);
            _isNewLine = true;
            return this;
        }
        public BetextWriter AssertNewLine(int indent, bool force = false) {
            if (!_isNewLine && !force) return this;
            if (!_isNewLine) EndLine();
            if (Decorate) {
                _textWriter.Write(_indentedText.Repeat(indent + IndentOffset));
                _isNewLine = false;
            }
            return this;
        }
        public BetextWriter EndLine(char? undecoratedText = null, char? alwayText = null) {
            if (alwayText != null) _textWriter.Write(alwayText);
            if (Decorate) _textWriter.Write(_newLine);
            else if (undecoratedText != null) _textWriter.Write(undecoratedText);
            _isNewLine = true;
            return this;
        }
        public BetextWriter WriteBlob(byte[] blob, string start = "@{", string end = "}") {
            _isNewLine = false;
            if (blob is null) {
                _textWriter.Write("null");
                return this;
            }
            if (!string.IsNullOrWhiteSpace(start)) _textWriter.Write(start);
            _textWriter.Write(blob.ToBase64());
            if (!string.IsNullOrWhiteSpace(end)) _textWriter.Write(end);
            return this;
        }
        public BetextWriter WriteValue(object? value) {
            if (value is null) return Write("null");
            if (value is string strValue) return WriteString(strValue);
            if (value is Type tValue) return WriteString(tValue.GetTypeName());
            if (value is decimal dec) return Write(dec.ToString());
            if (value is double dValue) return Write(dValue.ToString());
            if (value is float fvalue) return Write(fvalue.ToString());
            if (value is int ivalue) return Write(ivalue.ToString());
            if (value is long lvalue) return Write(lvalue.ToString());
            if (value is short svalue) return Write(svalue.ToString());
            if (value is byte bvalue) return Write(bvalue.ToString());
            if (value is bool blvalue) return Write(blvalue ? "true" : "false");
            return WriteString(value.ToString());
        }
        public BetextWriter WriteString(string? text, bool inQuote = true, EscapeContext? escapeContext = null) {
            if (text is null) {
                _textWriter.Write("null");
                return this;
            }
            if (inQuote) _textWriter.Write("\"");

            var escapse = escapeContext ?? _stringEscape;

            var len = text.Length;
            for (var i = 0; i < len; i++) {
                var chr = text[i];
                if ((escapse.ReplaceChars.IndexOf(chr) is int index) && index > -1) {
                    _textWriter.Write("\\");
                    _textWriter.Write(escapse.EndChars[index]);
                } else {
                    int value = chr;
                    if ((value >= 32 && value < 127) || chr == '_')
                        _textWriter.Write(chr);
                    else if ((value >= 0x80 && value <= 0xFF)
                             || (value >= 0x0080 && value <= 0x00FF)
                             || (value >= 0x0100 && value <= 0x024F)
                             || (value >= 0x0300 && value <= 0x036F)
                             || (value >= 0x1E00 && value <= 0x1EFF))
                        _textWriter.Write(chr);
                    else {
                        _textWriter.Write("\\u");
                        _textWriter.Write(value.ToString("X", CultureInfo.CurrentCulture).PadLeft(4, '0'));
                    }
                }
            }
            if (inQuote) _textWriter.Write("\"");
            _isNewLine = false;
            return this;
        }


        public bool EscapeString(string? text, out string str, EscapeContext? escapeContext = null) {
            if (text is null) return (str = "null") != null;

            var sb = new StringBuilder();
            var escapse = escapeContext ?? _stringEscape;

            bool hasEscapse = false;
            var len = text.Length;
            for (var i = 0; i < len; i++) {
                var chr = text[i];
                if ((escapse.ReplaceChars.IndexOf(chr) is int index) && index > -1) {
                    hasEscapse = true;
                    sb.Append('\\');
                    sb.Append(escapse.EndChars[index]);
                } else {
                    int value = chr;
                    if ((value >= 32 && value < 127) || chr == '_')
                        sb.Append(chr);
                    else if ((value >= 0x80 && value <= 0xFF)
                             || (value >= 0x0080 && value <= 0x00FF)
                             || (value >= 0x0100 && value <= 0x024F)
                             || (value >= 0x0300 && value <= 0x036F)
                             || (value >= 0x1E00 && value <= 0x1EFF))
                        sb.Append(chr);
                    else {
                        hasEscapse = true;
                        sb.Append("\\u");
                        sb.Append(value.ToString("X", CultureInfo.CurrentCulture).PadLeft(4, '0'));
                    }
                }
            }
            str = sb.ToString();
            return hasEscapse;
        }

        public BetextWriter WriterName(string name) {
            //if (EscapeString(name, out string text)) {

            //}
            if (IsSimpleName(name)) return Write(name);
            return WriteString(name);
        }
        static bool IsSimpleName(string name) {
            if (string.IsNullOrEmpty(name)) return false;
            var length = name.Length;
            for (int i = 0; i < length; i++) {
                var chr = name[i];
                if (BetextReader.IsIdentifierCharacter(chr)) continue;
                return false;
            }
            return true;
        }
    }
}
