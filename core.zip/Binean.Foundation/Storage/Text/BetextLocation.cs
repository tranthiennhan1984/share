﻿
namespace Binean.Foundation.Storage {
    public struct BetextLocation(int row, int column) : IEquatable<BetextLocation> {
        public static readonly BetextLocation Empty = new(0, 0);

        public override readonly string ToString()
            => $"[{Row + 1},{Column + 1}]";

        public int Row { get; set; } = row;
        public int Column { get; set; } = column;

        public bool IsEmpty {
            readonly get { return Row == 0 && Column == 0; }
            set {
                if (!value) return;
                Row = 0;
                Column = 0;
            }
        }

        public override readonly int GetHashCode() {
            return Row ^ Column;
        }

        public override readonly bool Equals(object? obj) {
            if (obj is not BetextLocation other) return false;
            return Equals(other);
        }

        public readonly bool Equals(BetextLocation other) {
            if (Row != other.Row) return false;
            return Column == other.Column;
        }

        public static bool operator ==(BetextLocation left, BetextLocation right) {
            return left.Equals(right);
        }

        public static bool operator !=(BetextLocation left, BetextLocation right) {
            return !(left == right);
        }

    }
}
