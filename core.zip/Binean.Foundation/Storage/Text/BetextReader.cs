﻿using Binean.Private;
using SystemTextReader = System.IO.TextReader;

namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class BetextReader(SystemTextReader reader, Action? disposedAction = null) : ICharInput {
        public const char EofCharacter = '\0';

        public static readonly Func<char, bool> IsIdentifierCharacter = new(c => char.IsLetterOrDigit(c) || "_-".Contains(c));
        public static readonly Func<char, bool> IsSIdentifierCharacter = new(c => char.IsLetterOrDigit(c) || c == '_');

        private Action? _disposedAction = disposedAction;
        private BetextLocation _currentLocation;
        private readonly SystemTextReader _textReader = reader;

        ~BetextReader() {
            Dispose(false);
        }
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        private void Dispose(bool disposing) {
            if (disposing) {
                if (_disposedAction != null) {
                    _disposedAction.Invoke();
                    _disposedAction = null;
                }
            }
        }

        [CProp(WriteSkip = true)]
        public string? Location { get; set; }
        public bool HasEscape => false;
        [CProp]
        public bool OverEof { get; set; }

        object IInput<char>.Position => _currentLocation;
        public Func<char, bool> IsWhitespace { get; set; } = char.IsWhiteSpace;
        public char PeekChar { get; set; } = EofCharacter;
        public char Current {
            get {
                if (!OverEof && IsEnd) return EofCharacter;
                if (PeekChar != EofCharacter) return PeekChar;
                var chr = _textReader.Peek();
                if (chr <= 0) {
                    IsEnd = true;
                    return EofCharacter;
                }
                return Helper.ToChar(chr);
            }
        }
        public bool IsEnd { get; private set; }
        public void MoveNext() {
            if (!OverEof && IsEnd) return;
            var _prevChar = Current;
            if (PeekChar != EofCharacter) {
                PeekChar = EofCharacter;
            } else _textReader.Read();

            var chr = Current;
            IsEnd = false;
            if (chr == EofCharacter) {
                IsEnd = true;
            } else if (chr == '\r') {
                _currentLocation.Row++;
                _currentLocation.Column = 0;
            } else if (chr == '\n' && _prevChar != '\r') {
                _currentLocation.Row++;
                _currentLocation.Column = 0;
            } else {
                _currentLocation.Column++;
            }
        }
    }
}
