﻿using System.Runtime.CompilerServices;


namespace Binean.Foundation.Storage {
    public sealed class Ten(Bsid name) : ICformat, ISformat {
        public Bsid Name { get; private set; } = name;

        Reader? IEformat.Serialize(object? data, IGetter? config)
            => Serialize(data).TryConfigure(config);
        Writer? IEformat.Deserialize(object? data, IGetter? config)
            => throw new NotSupportedException();

        Reader? ICformat.Serialize(ICharInput input, IGetter? config)
            => Serialize(input, true).TryConfigure(config);
        Writer? ICformat.Deserialize(BetextWriter output, IGetter? config)
            => throw new NotSupportedException();

        Reader? ISformat.Serialize(Stream stream, IGetter? config)
            => Serialize(stream.CreateTextReader(true)).TryConfigure(config);
        Writer? ISformat.Deserialize(Stream stream, IGetter? config)
            => throw new NotSupportedException();

        public static TenReader? Serialize(object? data) {
            if (data is ICharInput input) return Serialize(input, true);
            if (data is null || data.CreateTextReader() is not ICharInput ci) return null;
            return Serialize(ci);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static TenReader Serialize(ICharInput reader, bool leaveOpen = false)
            => new(reader, leaveOpen ? null : reader.Dispose);
    }
}