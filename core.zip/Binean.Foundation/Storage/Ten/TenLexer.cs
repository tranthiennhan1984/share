﻿namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class TenLexer : IInput<Symbol> {

        private readonly ICharInput _reader;
        public TenLexer(ICharInput reader) {
            _reader = reader;
            _reader.IsWhitespace = Json.IsWhitespace;
        }

        [CProp]
        public string? Location {
            get { return _reader.Location; }
            set { _reader.Location = value; }
        }

        [CProp]
        public object Position => _reader.Position;

        [CProp]
        public ListType EType { get; set; }

        public Symbol Current { get; private set; } = Symbol.None;
        public bool IsEnd => Current == Symbol.Eof;
        public void MoveNext() {
            if (Current == Symbol.Eof) return;
            Current = Read();
        }
        public Symbol Read() {
            while (true) {
                var chr = _reader.SkipWhitespaces();

                switch (chr) {
                    case '{':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.LBRACE, chr.ToString());
                    case '}':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.RBRACE, chr.ToString());
                    case '[':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.LSQBRACKET, chr.ToString());
                    case ']':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.RSQBRACKET, chr.ToString());
                    case ':':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.COLON, chr.ToString());
                    case ',':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.COMMA, chr.ToString());

                    case '\'':
                    case '"':
                        return _reader.ReadStringSymbol();

                    case '-':
                        return _reader.ReadNumberSymbol();

                    case '@':
                        _reader.MoveNext();
                        return _reader.ReadBlobSymbol();

                    case '$':
                        _reader.MoveNext();
                        return _reader.ReadTempalateSymbol();

                    case '#':
                        _reader.MoveNext();
                        if (_reader.Current == '!') return _reader.ReadListTypeSymbol(EType);
                        return _reader.ReadDefineSymbol();

                    case BetextReader.EofCharacter: return Symbol.Eof;
                }

                if (char.IsDigit(chr)) return _reader.ReadNumberSymbol();
                if (char.IsLetter(chr) || chr == '_') return _reader.ReadIdentifierSymbol();
                throw _reader.InvalidCharacter(chr);
            }
        }
    }
    public static class TenSymbol {
        public static readonly Bsid COMMA = nameof(COMMA);
        public static readonly Bsid LSQBRACKET = nameof(LSQBRACKET);
        public static readonly Bsid RSQBRACKET = nameof(RSQBRACKET);
        public static readonly Bsid LBRACE = nameof(LBRACE);
        public static readonly Bsid RBRACE = nameof(RBRACE);
        public static readonly Bsid COLON = nameof(COLON);

        public static readonly Bsid Identifier = nameof(Identifier);
        public static readonly Bsid String = nameof(String);
        public static readonly Bsid Number = nameof(Number);
        public static readonly Bsid Boolean = nameof(Boolean);
        public static readonly Bsid Null = nameof(Null);
        public static readonly Bsid Blob = nameof(Blob);

        public static readonly Bsid Comment = nameof(Comment);
        public static readonly Bsid Class = nameof(Class);
        public static readonly Bsid SDefine = nameof(SDefine);
        public static readonly Bsid Define = nameof(Define);
        public static readonly Bsid Redefine = nameof(Redefine);

        public static readonly Bsid Template = nameof(Template);
        public static readonly Bsid ListType = nameof(ListType);
    }
}
