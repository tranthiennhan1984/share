﻿namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class TenReader : Reader {
        public readonly TenLexer _lexer;

        public TenReader(ICharInput reader, Action? disposedAction = null) {
            var rootToken = new Token(NodeType.Array);
            _lexer = new TenLexer(reader);
            ListType = ListType.Ordered | ListType.Constant;
            _lexer.MoveNext();
            Initialize(rootToken, _lexer.IsEnd ? ReadEof : ReadItem, disposedAction);
        }
        [CProp]
        public string? Location {
            get { return _lexer.Location; }
            set { _lexer.Location = value; }
        }

        [CProp]
        public object Position => _lexer.Position;

        [CProp]
        public override ListType ListType {
            get => base.ListType;
            set => _lexer.EType = base.ListType = value;
        }

        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            var blockType = block.Type;
            Bsid propName = Bsid.Nothing;
            var cls = Bsid.Nothing;
            while (true) {
                var symbol = _lexer.Current;
                var type = symbol.Type;

                if (type == TenSymbol.String || type == TenSymbol.Identifier) {
                    var text = symbol.Text;
                    _lexer.MoveNext();
                    if ((type = _lexer.Current.Type) == TenSymbol.COLON) {
                        _lexer.MoveNext();
                        propName = (Bsid)text;
                        continue;
                    }
                    if (type == TenSymbol.LBRACE || type == TenSymbol.LSQBRACKET) {
                        propName = (Bsid)text;
                        continue;
                    }
                    if (propName.IsNothing && blockType.IsObject()) return block.NewToken(NodeType.Value, null, (Bsid)text);
                    return block.NewToken(NodeType.Value, text, propName).AddClass(cls);
                }

                if (type == TenSymbol.LBRACE) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Object, null, propName).AddClass(cls);
                }

                if (type == TenSymbol.RBRACE) {
                    if (blockType.IsArray()) throw _lexer.ExpectedCharacter(']');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (type == TenSymbol.LSQBRACKET) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Array, null, propName).AddClass(cls);
                }

                if (type == TenSymbol.RSQBRACKET) {
                    if (blockType.IsObject()) throw _lexer.ExpectedCharacter('}');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (type == TenSymbol.COMMA) {
                    _lexer.MoveNext();
                    if (propName.IsNothing) continue;
                    return block.NewToken(NodeType.Value, null, propName).AddClass(cls);
                }

                if (type == TenSymbol.Number
                    || type == TenSymbol.Null
                    || type == TenSymbol.Boolean
                    || type == TenSymbol.Blob
                    ) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Value, symbol.Tag, propName);
                }

                if (type == TenSymbol.Class) {
                    _lexer.MoveNext();
                    cls = (Bsid)symbol.Text;
                    continue;
                }

                if (type == TenSymbol.SDefine) {
                    _lexer.MoveNext();
                    return block.AddItem(Token.CreateControlToken((Bsid)symbol.Text, Prior.CreateQEntity().SetValueType(symbol.Tag)));
                }
                if (type == TenSymbol.Define) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Define, null, (Bsid)symbol.Text);
                }
                if (type == TenSymbol.Redefine) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Redefine, null, (Bsid)symbol.Text);
                }

                if (type == TenSymbol.Template) {
                    _lexer.MoveNext();
                    return block.AddItem(CreateTemplateToken(ref serialize, (symbol.Tag as Template)!, propName)).AddClass(cls);
                }

                if (type == TenSymbol.Comment) {
                    _lexer.MoveNext();
                    continue;
                }

                if (type == TenSymbol.ListType) {
                    _lexer.MoveNext();
                    if (symbol.Tag is ListType listType) {
                        return block.AddItem(Token.CreateControlToken(Properties.ListType, listType));
                    }
                    continue;
                }

                if (symbol == Symbol.Eof) return ReadEof(resolve, ref serialize, block);

                throw _lexer.InvalidSymbol(_lexer.Current);
            }
        }
        private Token CreateTemplateToken(ref Serialize serialize, Template template, Bsid name) {
            var value = template.Read(TemplateArgs);
            if (value is null) return new Token(NodeType.Value, value, name);
            if (Men.Serialize(value, true) is not Reader reader) return new Token(NodeType.Value, value, name);
            return new ReaderToken(ref serialize, reader, name, false);
        }
    }
    file static class Properties {
        public static readonly Bsid ListType = nameof(ListType);
    }
}
