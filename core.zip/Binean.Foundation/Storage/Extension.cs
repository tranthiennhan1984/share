﻿using Binean.Foundation.Internal;
using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Foundation.Storage {
    public static partial class Extension {

        #region :: Stream Helper ::
        //public static Stream ToBlockReader(this Stream stream, bool asyncRead = false, bool leaveOpen = false, int capacity = 1024)
        //    => new BlockReader(stream, asyncRead, leaveOpen, capacity);
        public static byte[] ReadExactly(this Stream stream, int count) {
            if (count <= 0) return [];
            byte[] blob = new byte[count];
            stream.ReadExactly(blob, 0, count);
            return blob;
        }
        public static void WriteASCII(this Stream stream, string txt) {
            var blob = Encoding.ASCII.GetBytes(txt);
            stream.Write(new byte[] { (byte)blob.Length });
            stream.Write(blob);
        }
        public static string ReadASCII(this Stream stream)
            => Encoding.ASCII.GetString(stream.ReadExactly(stream.ReadByte()));

        //public static void Write(this Stream stream, Reader reader, ISformat format, IEntity? config = null) {
        //    stream.WriteASCII(format.Name);
        //    using (var writer = format.Deserialize(stream).TryConfigure(config).Assert())
        //        writer.Write(reader);
        //}
        //public static Reader? Serialize(this Stream stream, out ISformat format, IEntity? config = null) {
        //    var name = Encoding.ASCII.GetString(stream.ReadExactly(stream.ReadByte()));
        //    format = Eformat.Get(name).NotNull<ISformat>();
        //    return format.Serialize(stream).TryConfigure(config);
        //}

        #endregion


        #region :: Exception Helpers ::

        public static Bexception CreateException(this object sender, Bsid messageId, params object?[] args) {
            var retVal = MessageStorage.CreateException(messageId, args);
            if (sender.ToGetter() is IEntity source && retVal.Content.GetSource() is ISetter setter) {
                setter.QSet(Properties.Location, source.Get(Properties.Location), false)
                    .QSet(Properties.Position, source.Get(Properties.Position), false);
            }
            return retVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bexception ExpectedCharacter(this object reader, char chr)
            => reader.CreateException(nameof(Logs.BFND5041E), chr);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bexception InvalidCharacter(this object reader, char chr)
            => reader.CreateException(nameof(Logs.BFND5042E), chr);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bexception InvalidToken(this object reader, Token token)
            => reader.CreateException(nameof(Logs.BFND5043E), token);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bexception InvalidSymbol(this object reader, Symbol symbol)
            => reader.CreateException(nameof(Logs.BFND5044E), symbol);

        #endregion

        #region :: Text Reader Writer Helper ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetContent<T>(this T writer, object? content) where T : Writer {
            writer._content = content;
            return writer;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICharInput CreateTextReader(this string text)
            => CreateTextReader(new StringReader(text));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICharInput CreateTextReader(this Stream stream, bool leaveOpen = false)
            => CreateTextReader(stream, leaveOpen, Encoding.UTF8);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICharInput CreateTextReader(this Stream stream, bool leaveOpen, Encoding encoding) {
            var str = new StreamReader(stream, encoding, true, 1024, leaveOpen);
            return new BetextReader(str, str.Dispose);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICharInput CreateTextReader(this TextReader textReader, bool leaveOpen = false)
            => new BetextReader(textReader, leaveOpen ? null : textReader.Dispose);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BetextWriter CreateTextWriter(this Stream stream, bool leaveOpen = false)
            => CreateTextWriter(stream, leaveOpen, Encoding.UTF8);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BetextWriter CreateTextWriter(this Stream stream, bool leaveOpen, Encoding encoding) {
            var stw = new StreamWriter(stream, encoding, 1024, leaveOpen);
            return new BetextWriter(stw, stw.Dispose);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BetextWriter CreateTextWriter(this TextWriter textWriter, bool leaveOpen = false)
            => new(textWriter, leaveOpen);

        public static string ReadAll(this ICharInput reader) {
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                sb.Append(reader.Current);
                reader.MoveNext();
            }
            return sb.ToString();
        }
        public static byte[] ReadBlob(this ICharInput reader, char begin = '[', char end = ']') {
            if (reader.IsEnd) return [];

            var chr = reader.Current;
            if (begin != BetextReader.EofCharacter) {
                if (chr != begin) throw reader.InvalidCharacter(chr);
                else reader.MoveNext();
            }//else skip begin

            int value = 0;
            var step = 0;
            using (var stream = new MemoryStream()) {
                while (!reader.IsEnd) {
                    chr = reader.Current;
                    if (chr == end) {
                        reader.MoveNext();
                        stream.Flush();
                        return stream.ToArray();
                    }

                    int i = 0;

                    if (char.IsDigit(chr)) i = chr - 48;
                    else if ((chr = char.ToUpper(chr)) >= 'A' && chr <= 'F') i = chr - 55;
                    else throw reader.InvalidCharacter(chr);

                    if (++step == 1) {
                        value = (byte)(i * 16);
                    } else {
                        value += i;
                        stream.WriteByte((byte)value);
                        step = 0;
                    }
                    reader.MoveNext();
                }
            }
            if (step == 1) throw reader.InvalidCharacter(chr);
            throw reader.ExpectedCharacter(end);
        }
        public static string ReadUntil(this ICharInput reader, Func<char, bool>? endCond = null, Func<char, bool>? skipCond = null, Func<char, bool>? errCond = null, char? expected = null) {
            if (endCond is null && skipCond is null && errCond is null && expected is null) throw reader.CreateException(nameof(Logs.BFND504AE));
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                var chr = reader.Current;
                if (!reader.HasEscape) {
                    if (endCond != null && endCond(chr)) return sb.ToString();
                    if (expected != null && expected == chr) {
                        reader.MoveNext();
                        return sb.ToString();
                    }

                    if (skipCond != null && skipCond(chr)) {
                        reader.MoveNext();
                        return sb.ToString();
                    }
                    if (errCond != null && errCond(chr)) {
                        if (expected != null) throw reader.ExpectedCharacter(expected.Value);
                        else throw reader.InvalidCharacter(chr);
                    }
                }
                sb.Append(chr);
                reader.MoveNext();
            }
            if (endCond != null && endCond(BetextReader.EofCharacter)) return sb.ToString();
            if (expected != null) throw reader.ExpectedCharacter(expected.Value);
            else throw reader.InvalidCharacter(BetextReader.EofCharacter);
        }
        public static string ReadWhile(this ICharInput reader, Func<char, bool> condition) {
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                char chr = reader.Current;
                if (!reader.HasEscape && !condition(chr)) break;
                sb.Append(chr);
                reader.MoveNext();
            }
            return sb.ToString();
        }
        public static string ReadWhile(this ICharInput reader, Func<char, bool>? lastCond = null, Func<char, bool>? endCond = null, Func<char, bool>? errCond = null) {
            if (lastCond is null && endCond is null && errCond is null) throw reader.CreateException(nameof(Logs.BFND5049E));
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                char chr = reader.Current;
                if (!reader.HasEscape) {
                    if (lastCond != null && lastCond(chr)) { _ = sb.Append(chr); break; }
                    if (endCond != null && endCond(chr)) break;
                    if (errCond != null && errCond(chr)) throw reader.InvalidCharacter(chr);
                }
                sb.Append(chr);
                reader.MoveNext();
            }
            return sb.ToString();
        }
        public static char SkipWhitespaces(this ICharInput reader) {
            var isWhitespace = reader.IsWhitespace;
            char chr;
            while (isWhitespace(chr = reader.Current)) {
                if (reader.HasEscape) break;
                reader.MoveNext();
            }
            return chr;
        }
        public static char SkipNewLine(this ICharInput reader) {
            char chr;
            while ("\r\n".Contains(chr = reader.Current)) {
                if (reader.HasEscape) break;
                reader.MoveNext();
            }
            return chr;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ReadName(this ICharInput reader)
            => ReadName(reader, BetextReader.IsIdentifierCharacter);
        public static string ReadName(this ICharInput reader, Func<char, bool> condition) {
            var chr = reader.Current;
            if ("'\"".Contains(chr)) {
                reader.MoveNext();
                using (var er = new EscapeReader(reader, EscapeContext.StringEscape))
                    return er.ReadUntil(expected: chr, errCond: "\r\n".Contains);
            }
            return reader.ReadWhile(condition);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? ReadString(this ICharInput reader) {
            var chr = reader.Current;
            if (!"\"'".Contains(chr)) return null;
            reader.MoveNext();
            using (var er = new EscapeReader(reader, EscapeContext.StringEscape))
                return er.ReadUntil(expected: chr, errCond: "\r\n".Contains);
        }
        public static Symbol ReadStringSymbol(this ICharInput reader) {
            var chr = reader.Current;
            return new Symbol(JsonSymbol.String, reader.ReadString()!) { Tag = chr };
        }

        public static Symbol ReadNumberSymbol(this ICharInput reader) {
            var sb = new StringBuilder();
            if (reader.Current == '-') {
                sb.Append('-');
                reader.MoveNext();
            }
            sb.Append(reader.ReadWhile(char.IsDigit));
            if (reader.Current == '.') {
                sb.Append('.');
                reader.MoveNext();
                sb.Append(reader.ReadWhile(char.IsDigit));
                var text = sb.ToString();
                if (text.EndsWith('.')) throw reader.InvalidCharacter(reader.Current);
                return new Symbol(Bebol.Number, text) { Tag = double.Parse(text) };
            } else {
                var text = sb.ToString();
                return new Symbol(Bebol.Number, text) { Tag = int.Parse(text) };
            }
        }
        public static Symbol ReadBlobSymbol(this ICharInput reader) {
            var chr = reader.Current;
            if (chr == '[') return new Symbol(Bebol.Blob) { Tag = reader.ReadBlob() };
            if (chr == '{') {
                reader.MoveNext();
                var text = reader.ReadUntil(expected: '}', errCond: "\r\n".Contains);
                return new Symbol(Bebol.Blob) { Tag = text.Base64ToBlob() };
            }
            throw reader.InvalidCharacter(chr);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ReadIdentifier(this ICharInput reader, Func<char, bool>? isIdentifierCharacter = null)
            => reader.ReadWhile(isIdentifierCharacter ?? BetextReader.IsIdentifierCharacter);
        public static Symbol ReadIdentifierSymbol(this ICharInput reader, bool keywordOnly = false, Func<char, bool>? isIdentifierCharacter = null) {
            var text = reader.ReadIdentifier(isIdentifierCharacter);
            if (string.Compare(text, "true", true) == 0) return new Symbol(Bebol.Boolean, text) { Tag = true };
            if (string.Compare(text, "false", true) == 0) return new Symbol(Bebol.Boolean, text) { Tag = false };
            if (string.Compare(text, "null", true) == 0) return new Symbol(Bebol.Null, text) { Tag = null };

            if (keywordOnly) throw reader.CreateException(nameof(Logs.BFND5045E), text);
            return new Symbol(Bebol.Identifier, text);
        }
        public static Symbol ReadClassSymbol(this ICharInput reader) {
            if (reader.Current != '@') return new Symbol(Bebol.Comment, reader.ReadUntil(endCond: "\r\n\0".Contains));
            reader.MoveNext();
            return new Symbol(Bebol.Class, reader.ReadUntil(endCond: "\r\n\0".Contains));
        }
        public static Symbol ReadDefineSymbol(this ICharInput reader) {
            if (reader.Current != '@') return new Symbol(Bebol.Comment, reader.ReadUntil(endCond: "\r\n\0".Contains));
            reader.MoveNext();
            var tKey = reader.ReadUntil(endCond: ":|{\r\n\0".Contains);
            if (reader.Current == ':') {
                reader.MoveNext();
                return new Symbol(Bebol.SDefine, tKey.TrimEnd()) { Tag = reader.ReadUntil(endCond: "\r\n\0".Contains) };
            }
            bool isDefine = true;
            if (reader.Current == '|') {
                reader.MoveNext();
                isDefine = false;
                if (reader.Current == '{') throw reader.InvalidCharacter(reader.Current);
            }
            if (reader.Current == '{') {
                reader.MoveNext();
                return new Symbol(isDefine ? Bebol.Define : Bebol.Redefine, tKey.TrimEnd());
            }
            return new Symbol(Bebol.Class, tKey);
        }
        public static Symbol ReadTempalateSymbol(this ICharInput _reader) {
            var chr = _reader.Current;
            if ("'\"".Contains(chr)) {
                var text = _reader.ReadString()!;
                return new Symbol(Bebol.Template, text) { Tag = new Template(text) };
            }
            if (chr == '{') {
                var text = _reader.ReadWhile(lastCond: c => c == '}')!;
                return new Symbol(Bebol.Template, text) { Tag = new Template(text) };
            }
            throw _reader.InvalidCharacter(chr);
        }
        public static Symbol ReadListTypeSymbol(this ICharInput reader, ListType source) {
            if (reader.Current != '!') throw reader.InvalidCharacter(reader.Current);
            reader.MoveNext();
            var ntype = reader.ReadListType(source, out string text, new Func<char, ListType>(chr => throw reader.InvalidCharacter(chr)));
            return new Symbol(Bebol.ListType, text) { Tag = ntype };
        }
        //public static EType ReadEType(this ICharInput reader, EType source, EType failback)
        //    => ReadEType(reader, source, out _, chr => failback);
        //public static EType ReadEType(this ICharInput reader, EType source, out string text)
        //    => ReadEType(reader, source, out text, new Func<char, EType>(chr => throw reader.InvalidCharacter(chr)));
        public static ListType ReadListType(this ICharInput reader, ListType source, out string text, Func<char, ListType> failback) {
            var chr = reader.Current;
            if (!"+-os".Contains(chr)) {
                text = string.Empty;
                return failback(chr);
            }

            var sb = new StringBuilder();
            var etype = source;
            var isOn = false;
            while (true) {
                if (chr == '-') isOn = true;
                else if (chr == '+') isOn = false;
                else if (chr == 'o') {
                    if (isOn) etype |= ListType.Ordered;
                    else etype &= ~ListType.Ordered;
                } else if (chr == 's') {
                    if (isOn) etype |= ListType.Constant;
                    else etype &= ~ListType.Constant;
                } else break;
                sb.Append(chr);
                reader.MoveNext();
                chr = reader.Current;
            }
            text = sb.ToString();
            return etype;
        }

        #endregion

        #region :: Reader Writer Helper ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty(this Reader reader)
            => reader is null || reader.IsEmpty || !reader.CanRead;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Reader Assert(this Reader? reader)
            => reader ?? Reader.CreateDummy();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Writer Assert(this Writer? writer)
            => writer ?? Writer.CreateDummy();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ToCen(this IGetter? getter, IGetter? config = null) {
            if (getter.IsNullOrEmpty()) return string.Empty;
            using (var reader = Men.Serialize(getter)!) {
                return Cen.ToString(reader, config);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ToJson(this object? obj, IGetter? config = null) {
            if (obj is null) return string.Empty;
            using (var reader = Men.Serialize(obj).Assert()) {
                return Json.ToString(reader, config);
            }
        }

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static string DenToCen(this IGetter? getter, IGetter? config = null) {
        //    if (getter.IsNullOrEmpty()) return string.Empty;
        //    using (var reader = new ProReader(getter)) {
        //        return Cen.ToString(reader, config);
        //    }
        //}

        //public static int ReadAll(this Reader reader) {
        //    if (reader.IsNullOrEmpty()) return 0;

        //    var token = reader.Read();
        //    if (token.IsEof) return 0;
        //    token.AssertLevel(0);
        //    var isArray = token.Type.IsArray();
        //    var retVal = isArray ? 0 : 1;
        //    while (reader.CanRead) {
        //        token = reader.Read();
        //        if (token.IsEof) break;
        //        if (token.Type.IsEndBlock() && token.Level == 1) break;
        //        if (isArray && token.IsData() && token.Level == 1) retVal++;
        //    }
        //    return retVal;
        //}

        public static Stream? CreateStream(this object data) {
            var buffer = data.Convert<byte[]>();
            if (buffer != null && buffer.Length > 0) {
                return new MemoryStream(buffer);
            }
            return null;
        }
        public static ICharInput? CreateTextReader(this object data) {
            if (data is ICharInput) throw new NotSupportedException();
            if (data is string text && !string.IsNullOrWhiteSpace(text)) return text.CreateTextReader();
            if (data is TextReader txtReader) return txtReader.CreateTextReader(true);
            if (data is Stream stream) return stream.CreateTextReader(true);
            if (data is byte[] buffer) return Encoding.UTF8.GetString(buffer, 0, buffer.Length).CreateTextReader();
            return null;
        }
        public static BetextWriter? CreateTextWriter(this object data) {
            if (data is BetextWriter) throw new NotSupportedException();
            if (data is TextWriter sw) return sw.CreateTextWriter(true);
            if (data is StringBuilder sb) return new StringWriter(sb).CreateTextWriter();
            if (data is Stream stream) return stream.CreateTextWriter(true);
            if (data is byte[] buffer) return new MemoryStream(buffer).CreateTextWriter();
            return null;
        }
        //public static TextWriter? CreateTextWriter(this object data) {
        //    if (data is TextWriter) throw new NotSupportedException();
        //    if (data is StringBuilder sb) return new StringWriter(sb);
        //    if (data is Stream stream) return new StreamWriter(stream, Encoding.UTF8, 1024, true);
        //    if (data is byte[] buffer) return new StreamWriter(new MemoryStream(buffer));
        //    return null;
        //}
        //public static T? GetConfigValue<T>(this object? config, string? propName)
        //    => GetConfigValue(config, propName, default(T));
        //public static T? GetConfigValue<T>(this object? config, string? propName, T defaultValue) {
        //    if (config is null || propName is null || propName.IsDummyProp()) return defaultValue;

        //    if (config is IEntity ent) return ent.Get(propName, defaultValue);
        //    return config.CastAs(() => defaultValue);
        //}

        //public static void SkipBlock(this Reader reader, Token block) {
        //    var level = 0;
        //    Token token;
        //    while ((token = reader.Read()).Type != TokenType.Eof) {
        //        if (token.IsBlock) {
        //            token.SkipBlock();
        //            level++;
        //        }
        //        if (token.Type.IsEndBlock() && --level < 0) {
        //            return;
        //        }
        //    }
        //    throw reader.CreateException(block, Messages.FNDN_00001_0008);
        //}
        #endregion

        #region :: Data format ::
        //public static byte[] Serialize(this IStreamSerializer reader, Reader reader) {
        //    using (var stream = new MemoryStream()) {
        //        reader.Serialize(reader, stream);
        //        stream.Flush();
        //        return stream.ToArray();
        //    }
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool TryCreateReader(this string? txt, [NotNullWhen(true)] out Reader? reader) {
        //    if (!string.IsNullOrWhiteSpace(txt) && txt.Length > 6 && txt[0] == '_' && txt[4] == '_'
        //        && txt.Substring(1, 3).Get() is IEntityNotation format) {
        //        reader = format.CreateReader(txt[5..]);
        //        return true;
        //    }
        //    reader = null;
        //    return false;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static string? GetFormatName(this IEntity entity, string? faultValue = null) {
        //    if (!entity.TryGet(Properties.Format, out object? obj)) return faultValue;
        //    if (obj is string type) return type;
        //    if (obj is IEntityNotation format) return format.Name;
        //    return faultValue;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static IEntityNotation? GetDataFormat(this IEntity entity, IEntityNotation? faultValue = null, bool keep = false) {
        //    if (!entity.TryGet(Properties.Format, out object? obj)) return faultValue;
        //    if (obj is IEntityNotation format) return format;
        //    if (obj is not string type) return faultValue;

        //    if (type?.Get() is not IEntityNotation fm) return faultValue;
        //    format = fm;
        //    if (keep) entity.Set(Properties.Format, format);
        //    return format;
        //}
        #endregion

        #region :: Symbol Helpers ::

        public static bool IsType(this Symbol symbol, Bsid type)
            => symbol.Type == type;

        public static bool IsType(this Symbol symbol, Bsid type, string text)
            => symbol.Type == type && string.Compare(symbol.Text, text) == 0;

        #endregion

        //#region :: Storage ::

        //public static async ValueTask<Response> ReadAsync(this IStorage storage, Request request, PropPath path, bool caseInsensitive = false) {
        //    try {
        //        using (var reader = (await storage.ReadAsync(path, caseInsensitive)).Assert()) {
        //            var retVal = Den.ToObject(reader);
        //            return retVal is null ? Response.NoContent : new Response(retVal);
        //        }
        //    } catch (Exception ex) {
        //        return request.ReturnSomethingWrong(ex.Correct());
        //    }
        //}
        //public static async ValueTask<Response> WriteAsync(this IStorage storage, Request request, PropPath path, Reader? reader) {
        //    try {
        //        if (reader is null) return Response.NoContent;
        //        return await storage.WriteAsync(path, reader) ? Response.NoContent : Response.Conflict;
        //    } catch (Exception ex) {
        //        return request.ReturnSomethingWrong(ex.Correct());
        //    }
        //}

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static IStorage CreateSubStorage(this IStorage storage, PropPath path)
        //    => new DependencyStorage(storage, path);

        //#endregion
    }

    file static class Properties {
        public static readonly Bsid Location = nameof(Location);
        public static readonly Bsid Position = nameof(Position);

        public static readonly Bsid Logs = nameof(Logs);
        public static readonly Bsid Body = nameof(Body);
        public static readonly Bsid Template = nameof(Template);

        public static readonly Bsid EType = nameof(ListType);
    }
    file static class Bebol {
        public static readonly Bsid Identifier = nameof(Identifier);
        public static readonly Bsid Number = nameof(Number);
        public static readonly Bsid Boolean = nameof(Boolean);
        public static readonly Bsid Null = nameof(Null);

        public static readonly Bsid String = nameof(String);

        public static readonly Bsid Blob = nameof(Blob);
        public static readonly Bsid Comment = nameof(Comment);
        public static readonly Bsid Class = nameof(Class);
        public static readonly Bsid SDefine = nameof(SDefine);
        public static readonly Bsid Define = nameof(Define);
        public static readonly Bsid Redefine = nameof(Redefine);

        public static readonly Bsid Template = nameof(Template);
        public static readonly Bsid ListType = nameof(ListType);
    }
}
