﻿using System.Collections;


namespace Binean.Foundation.Storage {
    [CEntity]
    public class MenReader : Reader {
        private Token? _nextToken;

        public MenReader(object obj, Action? disposedAction = null) {
            Content = obj;
            Serialize serialize = Content is null ? ReadEof : ReadContainer;
            var rootToken = new Token(NodeType.Array);
            Initialize(rootToken, serialize, disposedAction);
        }

        public event TokenResolve? TokenResolve;

        [CProp]
        public TagMode TagMode { get; set; }

        public object? Content { get; }

        private Token ReadContainer(TokenResolve resolve, ref Serialize serialize, Token block) {
            serialize = ReadEof;

            var token = resolve(resolve, ref serialize, block, new Token(NodeType.None, Content));
            if (token.IsDummy) {
                serialize = ReadException;
                return ReadEof(resolve, ref serialize, block);
            }
            return block.AddItem(token);
        }

        protected override Token OnSerialize(TokenResolve resolve, ref Serialize serialize, Token block) {
            Token token = _nextToken != null ? block.AddItem(_nextToken) : serialize(resolve, ref serialize, block);
            _nextToken = token.Potential.GetNext<Token>();
            return token;
        }

        protected override Token OnTokenResolve(TokenResolve resolve, ref Serialize serialize, Token block, Token token) {
            var value = token.Value;
            if (value is null) {
                token.ChangeType(NodeType.Value);
                return token;
            }

            var valueType = value.GetType();
            if (Generator.IsPrimitiveType(valueType)) {
                token.ChangeType(NodeType.Value);
                return token;
            }

            if (value.ToGetter() is IGetter getter) return ListTypeToken(new MenToken(ref serialize, getter.GetEnumerator(), token, NodeType.Object).SetBClass((getter as IClassed)?.Class), getter as INames<Bsid>);

            if (value is IList list) return new MenToken(ref serialize, list.GetEnumerator(), token, NodeType.Array).SetBClass((list as IClassed)?.Class);
            if (value is IEnumerable enm) return new MenToken(ref serialize, enm.GetEnumerator(), token, NodeType.Array).SetBClass((enm as IClassed)?.Class);

            var retVal = TokenResolve?.Invoke(resolve, ref serialize, block, token) ?? Token.Eof;
            if (!retVal.IsDummy) return retVal;

            token.ChangeType(NodeType.Value);
            return token;
        }

        protected Token ListTypeToken(Token token, INames<Bsid>? namedObject) {
            if (namedObject is null || namedObject.Names.ListType == ListType) return token;
            var retVal = Token.CreateControlToken(Properties.ListType, namedObject.Names.ListType);
            retVal.Potential.SetNext(token);
            return retVal;
        }
    }
    file static class Properties {
        public static readonly Bsid ListType = nameof(ListType);
    }
}
