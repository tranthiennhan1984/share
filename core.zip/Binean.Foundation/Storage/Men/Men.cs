﻿using System.Collections;

namespace Binean.Foundation.Storage {
    public sealed class Men(Bsid name) : IEformat {
        public Bsid Name { get; private set; } = name;

        Reader? IEformat.Serialize(object? data, IGetter? config)
            => Serialize(data).TryConfigure(config);
        Writer? IEformat.Deserialize(object? data, IGetter? config)
            => Deserialize(data).TryConfigure(config);

        public static MenReader? Serialize(object? obj, bool requireBlock = false) {
            if (obj is null || obj is DBNull) return null;
            if (!requireBlock) return new MenReader(obj);
            if (ToGettableObject(obj) is object block) return new MenReader(block);
            return null;
        }
        public static MenWriter Deserialize(object? obj)
            => new(obj);
        public static object? ToObject(Reader? reader, IGetter? proConfig = null) {
            if (reader is null) return null;
            using (var writer = new MenWriter().TryConfigure(proConfig)) {
                writer.Write(reader);
                return writer.GetContent();
            }
        }
        public static object? Clone(object? obj, IGetter? proConfig = null) {
            if (obj is null) return null;
            if (obj is byte[] blob) {
                var retVal = new byte[blob.Length];
                blob.CopyTo(retVal, 0);
                return retVal;
            }
            if (ToGettableObject(obj) is not object block) return obj;
            using (var reader = new MenReader(block))
                return ToObject(reader, proConfig);
        }

        private static object? ToGettableObject(object? obj) {
            if (obj is null) return null;
            if (obj.ToGetter() is IGetter ent) return ent;
            return obj as IList;
        }
    }
}