﻿using System.Collections;


namespace Binean.Foundation.Storage {
    public class MenToken : Sertoken {
        private readonly IEnumerator _enumerator;

        public MenToken(ref Serialize serialize, IEnumerator enumerator, Node node, NodeType kind)
            : base(serialize, node.Box() ?? Prior.CreateQEntity()) {
            _enumerator = enumerator;
            ChangeType(kind);
            serialize = ReadItem;
        }
        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            if (!_enumerator.MoveNext() || _enumerator.Current == Unit.Empty) {
                return ReadEndBlock(resolve, ref serialize, block);
            }            
            var retval = resolve(resolve, ref serialize, block, CorrectNode(_enumerator.Current));
            return retval == Eof ? ReadEndBlock(resolve, ref serialize, block)
                : block.AddItem(retval);
        }
        private static Token CorrectNode(object? value) {
            if (value is Token token) return token;
            if (value is Unit unit) return new Token(unit.Box());
            return new Token(NodeType.None, value);
        }
    }
}
