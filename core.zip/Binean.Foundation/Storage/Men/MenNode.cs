﻿using System.Collections;
using System.Diagnostics;

namespace Binean.Foundation.Storage {
    public sealed class MenNode : DesNode {
        private readonly IEntity _ent;
        private readonly bool _guarantee;

        public MenNode(IEntity entity, ref Deserialize deserialize, Token token, bool guarantee)
            : base(deserialize, token.Type, entity, token.Name) {
            _ent = entity;

            if (_ent is IClassed clsed) clsed.AddBClass(token.Class);

            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _ent.AValidate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var node = resolve(resolve, ref deserialize, block, token);
            if (node.IsDummy) return block.AddItem(token.Skip(ref deserialize));

            _ent.Set(node.Name, node.Value, _guarantee);
            return block.AddItem(node);
        }
    }
    public sealed class BNode : DesNode {
        private readonly IBoxabl _boxabl;
        private readonly IEntity _ent;
        private readonly bool _guarantee;

        public BNode(IBoxabl boxabl, IEntity ent, ref Deserialize deserialize, NodeType kind, Bsid name, bool guarantee)
            : base(deserialize, kind, boxabl, name) {
            _boxabl = boxabl;
            _ent = ent;
            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _boxabl.Unbox(_ent);
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var node = resolve(resolve, ref deserialize, block, token);
            if (node.IsDummy) return block.AddItem(token.Skip(ref deserialize));

            _ent.Set(node.Name, node.Value, _guarantee);
            return block.AddItem(node);
        }
    }
    public sealed class CNode : DesNode {
        private readonly CEntityType _cType;
        private readonly object _instance;
        private readonly bool _guarantee;

        public CNode(object instance, CEntityType cType, ref Deserialize deserialize, Token token, bool guarantee)
            : base(deserialize, token.Type, instance, token.Name) {
            _cType = cType;
            _instance = instance;
            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);

            var tokenType = token.Type;
            if (tokenType.IsEndBlock()) {
                _instance.AValidate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var node = _cType.NodeResolve(_instance, resolve, ref deserialize, block, token, _guarantee);
            if (node == DummyNode || node.Value is DBNull) return block.AddItem(token.Skip(ref deserialize));
            return block.AddItem(node);
        }
    }
    public sealed class ENode : DesNode {
        private readonly CEntityType _cType;
        private readonly INameSet<Bsid> _setterNames;
        private readonly INameSet<Bsid> _writeHiddens;
        private readonly object _instance;
        private readonly IEntity _ent;
        private readonly bool _guarantee;

        public ENode(object instance, IEntity ent, CEntityType cType, ref Deserialize deserialize, Node token, bool guarantee)
            : base(deserialize, token.Type, instance, token.Name) {
            _cType = cType;
            _setterNames = _cType.SetterNames;
            _writeHiddens = _cType.WriteHiddens;
            _instance = instance;
            _ent = ent;

            if (_ent is IClassed clsed) clsed.AddBClass(token.Class);

            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _instance.AValidate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var name = token.Name;
            if (_writeHiddens.Contains(name) || !_setterNames.Contains(name)) {
                var node = resolve(resolve, ref deserialize, block, token);
                if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));
                _ent.Set(node.Name, node.Value, _guarantee);
                return block.AddItem(node);
            } else {
                var node = _cType.NodeResolve(_instance, resolve, ref deserialize, block, token, _guarantee);
                if (node == DummyNode || node.Value is DBNull) return block.AddItem(token.Skip(ref deserialize));
                return block.AddItem(node);
            }
        }
    }

    public sealed class ListNode : DesNode {
        private readonly IList _list;
        private readonly Type? _itemType;

        public ListNode(IList list, ref Deserialize deserialize, Node node)
            : base(deserialize, node.Type, list, node.Name) {
            _list = list;
            var args = _list.GetType().GetGenericArguments();
            if (args.Length > 0) _itemType = args[0];
            deserialize = WriteItem;
        }
        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _list.AValidate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }

            if (!tokenType.IsValue()) token.ChangeValue(null);
            var node = InResolve(resolve, ref deserialize, block, token);
            if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));
            _list.Add(node.Value);
            return block.AddItem(node);
        }
        private Node InResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.Value is null && _itemType != null) token.ChangeValue(Generator.CreateInstance(_itemType));
            return resolve(resolve, ref deserialize, block, token);
        }
    }
    public sealed class NameListNode : DesNode {
        private readonly Bib _list;

        public NameListNode(Bib list, ref Deserialize deserialize, Node node)
            : base(deserialize, node.Type, list, node.Name) {
            _list = list;
            deserialize = WriteItem;
        }
        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _list.AValidate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }

            if (!tokenType.IsValue()) token.ChangeValue(null);
            var node = resolve(resolve, ref deserialize, block, token);
            if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));
            if (node.Value.TryConvert(out string? txt) && !string.IsNullOrWhiteSpace(txt)) _list.Add((Bsid)txt);
            return block.AddItem(node);
        }
    }
    public sealed class DictNode : DesNode {
        private readonly IDictionary _dict;
        private readonly Type? _itemType;

        public DictNode(IDictionary dict, ref Deserialize deserialize, Node snode)
            : base(deserialize, snode.Type, dict, snode.Name) {
            _dict = dict;
            var args = _dict.GetType().GetGenericArguments();
            if (args.Length > 1) _itemType = args[1];
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _dict.AValidate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }

            var name = token.Name;
            Debug.Assert(!name.IsNothing);

            if (!tokenType.IsValue()) token.ChangeValue(null);
            var node = InResolve(resolve, ref deserialize, block, token);
            if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));

            _dict[name] = node.Value;
            return block.AddItem(node);
        }
        private Node InResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.Value is null && _itemType != null) token.ChangeValue(Generator.CreateInstance(_itemType));
            return resolve(resolve, ref deserialize, block, token);
        }
    }
    public sealed class SetNode : DesNode {
        private readonly ISetter _setter;
        private readonly bool _guarantee;

        public SetNode(ISetter setter, ref Deserialize deserialize, NodeType kind, Bsid name, bool guarantee)
            : base(deserialize, kind, setter, name) {
            _setter = setter;
            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _setter.AValidate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }

            if (!tokenType.IsValue()) token.ChangeValue(null);
            var node = resolve(resolve, ref deserialize, block, token);
            if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));

            _setter.Set(token.Name, token.Value, _guarantee);
            return block.AddItem(node);
        }
    }
}
