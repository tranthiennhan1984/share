﻿using System.Collections;
using System.Diagnostics;
namespace Binean.Foundation.Storage {
    [CEntity]
    public class MenWriter : Writer {
        public MenWriter(object? content = null, Action? disposedAction = null) {
            _content = content;
            Initialize(new Node(NodeType.Array), WriteContainer, disposedAction);
            //_agetter = new AStyleGetter(new StyleGetter(Styles));
        }

        [CProp]
        public bool WriteGuarantee { get; set; } = true;

        private Node WriteContainer(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.IsDummy) return WriteEof(resolve, ref deserialize, block, token);
            deserialize = WriteEof;

            var tokenType = token.Type;
            if (!tokenType.IsValue()) token.ChangeValue(null);
            var valueType = token.Potential.GetValueType()?.ToType();

            if (_content != null) {
                if (valueType != null && !_content.GetType().IsAssignableFrom(valueType)) throw this.InvalidToken(token);
                token.ChangeValue(_content);
            }

            var node = resolve(resolve, ref deserialize, block, token);
            if (node.IsDummy) return block.AddItem(token.Skip(ref deserialize));

            _content = node.Value;
            return block.AddItem(node);
        }
        protected override void OnCookToken(Node block, Token token) {
            base.OnCookToken(block, token);
            if (token.Class is not BClass bcls || bcls.Compute() is not IGetter gt || gt.IsNullOrEmpty()) return;
            var latent = token.Potential;
            latent.Assign(gt);
        }

        //private static void ApplyClass(Token token, string cls) {
        //    if (cls.StartsWith('@')) {

        //    }
        //    if (cls.ToType() is Type t) {
        //        //token.MSet(Properties.ValueType, t);
        //    }
        //    var latent = token.Latent;
        //    if (latent.Get(cls).ToGetter() is IGetter getter) {
        //        latent.Assign(getter);
        //    }
        //}
        protected override Node OnNodeResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            var value = token.Value;

            var vType = token.Potential.GetValueType();

            if (value is null && vType?.ToType() is Type valueType) {
                if (!valueType.IsEnum && Generator.IsObjectType(valueType) && valueType != typeof(object)) {
                    token.ChangeValue(value = valueType.CreateInstance());
                }
            }

            var tokenType = token.Type;
            if (tokenType.IsValue()) return new Node(token.Box());

            if (tokenType.IsObject()) {
                if (value is null) {
                    var vent = Prior.CreateEntity(token.Potential.QGet<ListType>(Properties.ListType));
                    if (vType is string vts) vent.AssertClass().Potential.SetValueType(vts);
                    return new MenNode(vent, ref deserialize, token, WriteGuarantee);
                }
                if (value is IBoxabl boxal) return new BNode(boxal, Prior.CreateEntity(token.Potential.QGet<ListType>(Properties.ListType)).SetBClass(token.Class), ref deserialize, NodeType.Object, token.Name, WriteGuarantee);

                if (CEntityType.TryCreate(value.GetType(), out var entityType)) {
                    if (value is IProspective evolvable) return new ENode(value, evolvable.Potential, entityType, ref deserialize, token, WriteGuarantee);
                    return new CNode(value, entityType, ref deserialize, token, WriteGuarantee);
                }
                if (value is IDictionary dict) return new DictNode(dict, ref deserialize, token);
                if (value is BEntity bent) {
                    if (token.Class != null && bent is IClassed te) te.Class = token.Class;
                    return new MenNode(bent.Potential, ref deserialize, token, WriteGuarantee);
                }
                if (value.Box() is IEntity ent) return new MenNode(ent, ref deserialize, token, WriteGuarantee);
                if (value is ISetter setter) return new SetNode(setter, ref deserialize, token.Type, token.Name, WriteGuarantee);
                return token.Skip(ref deserialize);
            }

            Debug.Assert(tokenType.IsArray());
            {
                if (value is null) {
                    var vent = Prior.CreateLitity();
                    if (vType is string vts) vent.AssertClass().Potential.SetValueType(vts);
                    return new ListNode(vent, ref deserialize, token);
                }

                if (CEntityType.TryCreate(value.GetType(), out var entityType)) {
                    if (value is IProspective evolvable) return new ENode(value, evolvable.Potential, entityType, ref deserialize, token, WriteGuarantee);
                    return new CNode(value, entityType, ref deserialize, token, WriteGuarantee);
                }

                if (value is IList list) return new ListNode(list, ref deserialize, token);
                if (value is Bib namelist) return new NameListNode(namelist, ref deserialize, token);
                if (value.Box() is IEntity ent) return new MenNode(ent, ref deserialize, token, WriteGuarantee);
                return token.Skip(ref deserialize);
            }
        }
    }

    file static class Properties {
        public static readonly Bsid ListType = nameof(ListType);
    }
}
