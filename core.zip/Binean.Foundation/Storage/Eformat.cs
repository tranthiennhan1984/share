﻿namespace Binean.Foundation.Storage {
    file static class Properties {
        public static readonly Bsid Name = nameof(Name);
    }
    public static class Eformat {
        public static readonly Bsid ben = nameof(ben);
        public static readonly Bsid cen = nameof(cen);
        public static readonly Bsid json = nameof(json);
        public static readonly Bsid ten = nameof(ten);
        public static readonly Bsid men = nameof(men);
        public static readonly Bsid csv = nameof(csv);

        public static readonly Ben Ben = new(ben);
        public static readonly Cen Cen = new(cen);
        public static readonly Json Json = new(json);
        public static readonly Ten Ten = new(ten);
        public static readonly Men Men = new(men);
        public static readonly Csv Csv = new(csv);

        private static readonly IEntity _formats = Prior.CreateQEntity()
            .QSet(ben, Ben)
            .QSet(cen, Cen)
            .QSet(json, Json)
            .QSet(ten, Ten)
            .QSet(men, Men)
            .QSet(csv, Csv);

        private static readonly object _lock = new();
        public static bool IsRegistered(Bsid name) {
            lock (_lock) {
                return _formats.TryGetValue(name, out _);
            }
        }

        public static IEformat? Get(Bsid name) {
            lock (_lock) {
                return _formats.QGet<IEformat>(name);
            }
        }

        public static bool Register(this IEformat format, Bsid name) {
            lock (_lock) {
                //if (_formats.TryGetValue(name, out IEntityFormat _)return false;
                format.ToSetter()?.QSet(Properties.Name, name);
                _formats.QSet(name, format);
            }
            return true;
        }

        public static void Unregister(Bsid name) {
            lock (_lock) {
                _formats.Remove(name);
            }
        }
    }
}