﻿namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class CenLexer : IInput<Symbol> {

        private readonly ICharInput _reader;
        public CenLexer(ICharInput reader) {
            _reader = reader;
            _reader.IsWhitespace = Json.IsWhitespace;
        }

        [CProp]
        public string? Location {
            get { return _reader.Location; }
            set { _reader.Location = value; }
        }

        [CProp]
        public object Position => _reader.Position;

        [CProp]
        public ListType ListType { get; set; }

        public Symbol Current { get; private set; } = Symbol.None;
        public bool IsEnd => Current == Symbol.Eof;
        public void MoveNext() {
            if (Current == Symbol.Eof) return;
            Current = Read();
        }
        public Symbol Read() {
            while (true) {
                var chr = _reader.SkipWhitespaces();

                switch (chr) {
                    case '{':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.LBRACE, chr.ToString());
                    case '}':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.RBRACE, chr.ToString());
                    case '[':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.LSQBRACKET, chr.ToString());
                    case ']':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.RSQBRACKET, chr.ToString());
                    case ':':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.COLON, chr.ToString());
                    case ',':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.COMMA, chr.ToString());

                    case '\'':
                    case '"':
                        return _reader.ReadStringSymbol();

                    case '-':
                        return _reader.ReadNumberSymbol();

                    case '@':
                        _reader.MoveNext();
                        return _reader.ReadBlobSymbol();

                    case '#':
                        _reader.MoveNext();
                        if (_reader.Current == '!') return _reader.ReadListTypeSymbol(ListType);
                        return _reader.ReadClassSymbol();

                    case BetextReader.EofCharacter: return Symbol.Eof;
                }

                if (char.IsDigit(chr)) return _reader.ReadNumberSymbol();
                if (char.IsLetter(chr) || chr == '_') return _reader.ReadIdentifierSymbol();
                throw _reader.InvalidCharacter(chr);
            }
        }
    }
    internal static class CenSymbol {
        public static readonly Bsid COMMA = nameof(COMMA);
        public static readonly Bsid LSQBRACKET = nameof(LSQBRACKET);
        public static readonly Bsid RSQBRACKET = nameof(RSQBRACKET);
        public static readonly Bsid LBRACE = nameof(LBRACE);
        public static readonly Bsid RBRACE = nameof(RBRACE);
        public static readonly Bsid COLON = nameof(COLON);

        public static readonly Bsid Identifier = nameof(Identifier);
        public static readonly Bsid String = nameof(String);
        public static readonly Bsid Number = nameof(Number);
        public static readonly Bsid Boolean = nameof(Boolean);
        public static readonly Bsid Null = nameof(Null);

        public static readonly Bsid Blob = nameof(Blob);
        public static readonly Bsid Comment = nameof(Comment);
        public static readonly Bsid Class = nameof(Class);

        public static readonly Bsid ListType = nameof(ListType);
    }
}
