﻿namespace Binean.Foundation.Storage {
    [CEntity]
    public class CenReader : Reader {
        public readonly CenLexer _lexer;

        public CenReader(ICharInput reader, Action? disposedAction = null, NodeType beginType = NodeType.Array) {
            var rootToken = new Token(beginType);
            _lexer = new CenLexer(reader);
            ListType = ListType.Ordered;
            _lexer.MoveNext();
            Initialize(rootToken, _lexer.IsEnd ? ReadEof : ReadItem, disposedAction);
        }

        [CProp]
        public string? Location {
            get { return _lexer.Location; }
            set { _lexer.Location = value; }
        }

        [CProp]
        public object Position => _lexer.Position;

        [CProp]
        public override ListType ListType {
            get => base.ListType;
            set => _lexer.ListType = base.ListType = value;
        }

        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            var blockType = block.Type;
            Bsid propName = Bsid.Nothing;
            Bsid cls = Bsid.Nothing;
            while (true) {
                var symbol = _lexer.Current;
                var type = symbol.Type;

                if (type == CenSymbol.String || type == CenSymbol.Identifier) {
                    var text = symbol.Text;
                    _lexer.MoveNext();
                    if ((type = _lexer.Current.Type) == CenSymbol.COLON) {
                        _lexer.MoveNext();
                        propName = (Bsid)text;
                        continue;
                    }
                    if (type == CenSymbol.LBRACE || type == CenSymbol.LSQBRACKET) {
                        propName = (Bsid)text;
                        continue;
                    }
                    if (propName.IsNothing && blockType.IsObject()) return block.NewToken(NodeType.Value, null, (Bsid)text);
                    return block.NewToken(NodeType.Value, text, propName).AddClass(cls);
                }

                if (type == CenSymbol.LBRACE) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Object, null, propName).AddClass(cls);
                }

                if (type == CenSymbol.RBRACE) {
                    if (blockType.IsArray()) throw _lexer.ExpectedCharacter(']');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (type == CenSymbol.LSQBRACKET) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Array, null, propName).AddClass(cls);
                }

                if (type == CenSymbol.RSQBRACKET) {
                    if (blockType.IsObject()) throw _lexer.ExpectedCharacter('}');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (type == CenSymbol.COMMA) {
                    _lexer.MoveNext();
                    if (propName.IsNothing) continue;
                    return block.NewToken(NodeType.Value, null, propName);
                }

                if (type == CenSymbol.Number
                    || type == CenSymbol.Null
                    || type == CenSymbol.Boolean
                    || type == CenSymbol.Blob) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Value, symbol.Tag, propName);
                }

                if (type == CenSymbol.Class) {
                    _lexer.MoveNext();
                    cls = (Bsid)symbol.Text;
                    continue;
                }

                if (type == CenSymbol.Comment) {
                    _lexer.MoveNext();
                    continue;
                }

                if (type == CenSymbol.ListType) {
                    _lexer.MoveNext();
                    if (symbol.Tag is ListType etype) {
                        ListType = etype;
                        return block.NewToken(NodeType.Control, ListType, Properties.ListType);
                    }
                    continue;
                }

                if (symbol == Symbol.Eof) return ReadEof(resolve, ref serialize, block);

                throw _lexer.InvalidSymbol(_lexer.Current);
            }
        }
    }
    file static class Properties {
        public static readonly Bsid ListType = nameof(ListType);
    }
}
