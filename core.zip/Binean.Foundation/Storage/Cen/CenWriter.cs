﻿namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class CenWriter : Writer {
        private readonly BetextWriter _writer;
        private Action<CenWriter>? _close;

        public CenWriter(BetextWriter writer, Action? disposedAction = null, Action<CenWriter>? close = null) {
            _content = writer;
            _close = close;
            var rootNode = new Node(NodeType.Array);
            _writer = writer;
            var deserialize = new Deserialize(WriteItem);
            if (_close != null) {
                if (disposedAction is null) disposedAction = Close;
                else {
                    var cur = disposedAction;
                    disposedAction = () => {
                        Close();
                        cur();
                    };
                }
            }
            Initialize(rootNode, deserialize, disposedAction);
        }

        [CProp]
        public string? Location {
            get => _writer.Location;
            set => _writer.Location = value;
        }

        [CProp]
        public bool Decorate {
            get => _writer.Decorate;
            set => _writer.Decorate = value;
        }

        [CProp]
        public int IndentOffset {
            get => _writer.IndentOffset;
            set => _writer.IndentOffset = value;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (block.Level < 0 && token.Type.IsEndBlock()) {
                deserialize = WriteException;
                return block.EndNode();
            }
            return WriteItem(_writer, block, token, token.Name);
        }
        public static Node WriteItem(BetextWriter _writer, Node block, Token token, Bsid name, int indenOffset = 0) {
            var blockType = block.Type;
            if (token.Type.IsEndBlock()) {
                _writer.AssertNewLine(block.Level + indenOffset, true).Write(blockType.IsArray() ? "]" : "}").EndLine();
                return block.EndNode();
            }

            var idenLevel = block.Level + indenOffset + 1;
            if (token.Class?.Names is Bib names) {
                _writer.AssertNewLine(idenLevel);
                _writer.Write("#@").Write(names.BuildClass()).EndLine();
            }
            var tokenType = token.Type;
            if (tokenType.IsValue()) {
                _writer.AssertNewLine(idenLevel);
                if (blockType.IsObject()) {
                    _writer.WriterName((string)name).Write(":");
                    if (_writer.Decorate) _writer.Write(" ");
                }

                var value = token.Value;
                if (value is byte[] blob) _writer.WriteBlob(blob).EndLine(',');
                //else if (value is StringTemplate stmpl) _writer.Write("$").WriteString(stmpl.Text).EndLine(',');
                //else if (value is Template tmpl) _writer.Write("$").Write(tmpl.Text).EndLine(',');
                else _writer.WriteValue(value).EndLine(',');
                return block.AddItem(new Node(tokenType, value, token.Name));
            }

            _writer.AssertNewLine(idenLevel, true);
            if (blockType.IsObject()) {
                _writer.WriterName((string)name);
                if (_writer.Decorate) _writer.Write(" ");
            }
            _writer.Write(token.Type.IsObject() ? "{" : "[").EndLine();
            return block.AddItem(new Node(tokenType, DBNull.Value, token.Name));
        }
        protected override void Close() {
            if (_close is null) return;
            _close(this);
            CanContinue = false;
            _close = null;
        }
    }
}
