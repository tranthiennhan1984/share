﻿

namespace Binean.Foundation.Storage {
    /// <summary>
    /// Entity format
    /// </summary>
    public interface IEformat {
        Bsid Name { get; }
        Reader? Serialize(object? data, IGetter? config = null);
        Writer? Deserialize(object? data = null, IGetter? config = null);
    }
    /// <summary>
    /// Stream format
    /// </summary>
    public interface ISformat : IEformat {
        Reader? Serialize(Stream stream, IGetter? config = null);
        Writer? Deserialize(Stream stream, IGetter? config = null);
    }
    /// <summary>
    /// Character format
    /// </summary>
    public interface ICformat : IEformat {
        Reader? Serialize(ICharInput input, IGetter? config = null);
        Writer? Deserialize(BetextWriter output, IGetter? config = null);
    }
}