﻿using Binean.Private;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class BenReader : Reader {

        private readonly Stream _reader;
        private int _current = -1;
        private readonly Dictionary<int, Bsid> _properties = [];

        public BenReader(Stream reader, Action? disposedAction = null) {
            var rootToken = new Token(NodeType.Array);
            _reader = reader;
            Initialize(rootToken, !_reader.CanRead ? ReadEof : ReadContainer, disposedAction);
        }

        [CProp]
        public string? Location { get; set; }

        [CProp]
        public int Position { get; private set; }
        public bool IsEnd { get; private set; }

        internal int MoveNext() {
            if (IsEnd) return -1;
            Position++;
            _current = -1;
            return Peek();
        }
        private int Peek() {
            if (_current != -1) return _current;
            if (IsEnd) return _current = -1;

            _current = _reader.ReadByte();
            IsEnd = _current == -1;
            return _current;
        }

        private byte[] Read(int length) {
            var retVal = new byte[length];
            var offset = _current == -1 ? 0 : 1;
            var count = length - offset;
            if (count > 0 && _reader.Read(retVal, offset, count) != count) {
                throw this.CreateException(nameof(Logs.BFND5011E));
            }
            if (_current != -1) {
                retVal[0] = (byte)_current;
                _current = -1;
            }
            Position += length;
            return retVal;
        }

        internal object? ReadValue(BenDataTypes dataType) {
            return dataType switch {
                BenDataTypes.Text => Encoding.UTF8.GetString(Read(Read(1)[0])),
                BenDataTypes.String => Encoding.UTF8.GetString(Read(BitConverter.ToInt16(Read(2), 0))),
                BenDataTypes.Utf8 => Encoding.UTF8.GetString(Read(BitConverter.ToInt32(Read(4), 0))),
                BenDataTypes.Int32 => BitConverter.ToInt32(Read(4), 0),
                BenDataTypes.Float64 => BitConverter.ToDouble(Read(8), 0),
                BenDataTypes.Float32 => BitConverter.ToSingle(Read(4), 0),
                BenDataTypes.Int64 => BitConverter.ToInt64(Read(8), 0),
                BenDataTypes.True => true,
                BenDataTypes.False => false,
                BenDataTypes.Null => null,
                BenDataTypes.ASCII => BitConverter.ToChar(Read(1), 0),
                BenDataTypes.Int8 => ToSByte(Read(1)[0]),
                BenDataTypes.Uint8 => Convert.ToByte(Read(1)[0]),
                BenDataTypes.Int16 => BitConverter.ToInt16(Read(2), 0),
                BenDataTypes.Blob => Read(ReadInteger()),
                _ => throw this.CreateException(nameof(Logs.BFND5014E), dataType),
            };
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static sbyte ToSByte(byte value)
            => (sbyte)(value - sbyte.MinValue);

        private object? ReadValue() {
            var dataType = PeekDataType();
            MoveNext();
            return ReadValue(dataType);
        }

        private int ReadInteger() {
            var dataType = PeekDataType();
            MoveNext();
            return ReadInteger(dataType);
        }
        private int ReadInteger(BenDataTypes dataType) {
            return dataType switch {
                BenDataTypes.Int8 => ToSByte(Read(1)[0]),
                BenDataTypes.Uint8 => Convert.ToByte(Read(1)[0]),
                BenDataTypes.Int16 => BitConverter.ToInt16(Read(2), 0),
                BenDataTypes.Int32 => BitConverter.ToInt32(Read(4), 0),
                _ => throw this.CreateException(nameof(Logs.BFND5012E))
            };
        }

        private string ReadString() {
            var dataType = PeekDataType();
            MoveNext();
            return dataType switch {
                BenDataTypes.ASCII => BitConverter.ToChar(Read(1), 0).ToString(CultureInfo.CurrentCulture),
                BenDataTypes.Text => Encoding.UTF8.GetString(Read(Read(1)[0])),
                BenDataTypes.String => Encoding.UTF8.GetString(Read(BitConverter.ToInt16(Read(2), 0))),
                BenDataTypes.Utf8 => Encoding.UTF8.GetString(Read(BitConverter.ToInt16(Read(4), 0))),
                _ => throw this.CreateException(nameof(Logs.BFND5013E)),
            };
        }

        private BenDataTypes PeekDataType() => Peek().TryConvertEnum(out BenDataTypes v) ? v : BenDataTypes.None;
        internal BenPunctuator PeekPunctuator() => Peek().TryConvertEnum(out BenPunctuator p) ? p : BenPunctuator.None;

        private Token ReadContainer(TokenResolve resolve, ref Serialize serialize, Token block) {
            var punctuator = PeekPunctuator();
            if (punctuator == BenPunctuator.EOF) {
                MoveNext();
                return ReadEof(resolve, ref serialize, block);
            }
            serialize = ReadEof;
            return ReadItem(resolve, ref serialize, block);
        }
        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            Debug.Assert(resolve != null);
            return InReadItem(ref serialize, block);
        }
        private Token InReadItem(ref Serialize serialize, Token block) {
            Bsid cls = Bsid.Nothing;
            Bsid propName = Bsid.Nothing;
            int propertyId;
            //string? text;
            BenDataTypes itemType = BenDataTypes.None;
            while (true) {
                var punctuator = PeekPunctuator();
                switch (punctuator) {
                    case BenPunctuator.BeginObject:
                        MoveNext();
                        return block.AddItem(new BenToken(this, ref serialize, true, propName)).AddClass<Token>(cls);

                    case BenPunctuator.BeginArray:
                        MoveNext();
                        punctuator = PeekPunctuator();
                        if (punctuator == BenPunctuator.ItemType) {
                            MoveNext();
                            itemType = PeekDataType();
                            MoveNext();
                            return block.AddItem(new BenStoken(this, ref serialize, itemType, propName));
                        }
                        return block.AddItem(new BenToken(this, ref serialize, false, propName)).AddClass<Token>(cls);

                    case BenPunctuator.Class:
                        MoveNext();
                        cls = (Bsid)ReadString();
                        continue;

                    case BenPunctuator.PropertyName:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int8);
                        propName = (Bsid)ReadString();
                        _properties[propertyId] = propName;
                        continue;
                    case BenPunctuator.PropertyName_16:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int16);
                        propName = (Bsid)ReadString();
                        _properties[propertyId] = propName;
                        continue;
                    case BenPunctuator.PropertyName_32:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int32);
                        propName = (Bsid)ReadString();
                        _properties[propertyId] = propName;
                        continue;

                    case BenPunctuator.PropertyId:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int8);
                        propName = _properties[propertyId];
                        continue;
                    case BenPunctuator.PropertyId_16:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int16);
                        propName = _properties[propertyId];
                        continue;
                    case BenPunctuator.PropertyId_32:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int32);
                        propName = _properties[propertyId];
                        continue;
                    case BenPunctuator.ListType:
                        MoveNext();
                        ListType = (ListType)ReadInteger(BenDataTypes.Int8);
                        continue;

                    case BenPunctuator.EOF:
                    case BenPunctuator.EndObject:
                    case BenPunctuator.EndArray:
                    case BenPunctuator.ItemType:
                        throw this.CreateException(nameof(Logs.BFND5015E), punctuator);
                }

                return block.NewToken(NodeType.Value, ReadValue(), propName).AddClass(cls);
            }
        }
        protected override Token OnTokenResolve(TokenResolve resolve, ref Serialize serialize, Token block, Token unit)
            => InReadItem(ref serialize, block);
    }
}
