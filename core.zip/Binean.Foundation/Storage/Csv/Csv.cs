﻿using System.Runtime.CompilerServices;


namespace Binean.Foundation.Storage {
    public sealed class Csv(Bsid name) : ICformat, ISformat {
        public Bsid Name { get; private set; } = name;

        Reader? IEformat.Serialize(object? data, IGetter? config)
            => Serialize(data).TryConfigure(config);
        Writer? IEformat.Deserialize(object? data, IGetter? config)
            => CreateWriter(data).TryConfigure(config) ?? Writer.CreateDummy();

        Reader? ICformat.Serialize(ICharInput input, IGetter? config)
            => Serialize(input, true).TryConfigure(config);
        Writer? ICformat.Deserialize(BetextWriter output, IGetter? config)
            => CreateWriter(output, true).TryConfigure(config);

        Reader? ISformat.Serialize(Stream stream, IGetter? config)
            => Serialize(stream.CreateTextReader(true)).TryConfigure(config);
        Writer? ISformat.Deserialize(Stream stream, IGetter? config)
            => CreateWriter(stream.CreateTextWriter(true)).TryConfigure(config);


        public static CsvReader? Serialize(object? data) {
            if (data is ICharInput input) return Serialize(input, true);
            if (data is null || data.CreateTextReader() is not ICharInput ci) return null;
            return Serialize(ci);
        }
        public static CsvWriter? CreateWriter(object? data = null) {
            if (data is null) {
                var st = new StringWriter();
                return new CsvWriter(st.CreateTextWriter(true), st.Dispose, w => {
                    st.Flush();
                    w.SetContent(st.GetStringBuilder().ToString());
                    st.Dispose();
                });
            }

            if (data is BetextWriter w) return CreateWriter(w, true);
            if (data.CreateTextWriter() is not BetextWriter tw) return null;
            return CreateWriter(tw).SetContent(data);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static CsvReader Serialize(ICharInput reader, bool leaveOpen = false)
            => new(reader, leaveOpen ? null : reader.Dispose);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static CsvWriter CreateWriter(BetextWriter writer, bool leaveOpen = false)
            => new(writer, leaveOpen ? null : writer.Dispose);

        public static string ToString(Reader serializer, IGetter? config = null) {
            using (var writer = CreateWriter().TryConfigure(config).Assert()) {
                writer.Write(serializer);
                return writer.GetContent().NotNull<string>();
            }
        }
        public static string ToString(object? obj, IGetter? config = null) {
            if (obj is null) return string.Empty;
            using (var reader = Men.Serialize(obj).Assert())
                return ToString(reader, config);
        }
    }
}