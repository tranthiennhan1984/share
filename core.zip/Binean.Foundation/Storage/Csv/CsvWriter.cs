﻿using System.Collections;
using System.Text;

namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class CsvWriter : Writer {
        private readonly BetextWriter _writer;

        private Bsid[] _headers = default!;
        private Action<CsvWriter>? _close;
        private readonly Entity _row = Prior.CreateEntity();
        private readonly List<Bsid> _columns = [];

        public CsvWriter(BetextWriter writer, Action? disposedAction = null, Action<CsvWriter>? close = null) {
            _content = writer;
            _close = close;
            _writer = writer;
            if (_close != null) {
                if (disposedAction is null) disposedAction = Close;
                else {
                    var cur = disposedAction;
                    disposedAction = () => {
                        Close();
                        cur();
                    };
                }
            }
            Initialize(new Node(NodeType.Array), WriteContainer, disposedAction);
        }

        [CProp]
        public string? Location {
            get => _writer.Location;
            set => _writer.Location = value;
        }

        [CProp(WriteOver = true)]
        public IList Columns => _columns;

        [CProp(WriteOver = true)]
        public Bib PropMap { get; } = Prior.CreateNames();

        [CProp]
        public bool WriteGuarantee { get; set; } = true;

        [CProp]
        public bool WriteHeaders { get; set; } = true;

        protected override void Close() {
            if (_close is null) return;
            _close(this);
            CanContinue = false;
            _close = null;
        }

        private Node WriteContainer(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.IsDummy) return WriteEof(resolve, ref deserialize, block, token);
            var tokenType = token.Type;
            if (tokenType.IsBlock()) {
                if (_columns.Count <= 0) deserialize = WriteFirstRow;
                else {
                    ApplyHeaders(_columns);
                    deserialize = WriteRow;
                }
                return block.AddItem(new Node(token.Potential));
            }

            return tokenType.IsValue() ? block.AddItem(new Node(NodeType.Value, _content))
                : block.AddItem(token.Skip(ref deserialize));
        }
        private Node WriteFirstRow(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.Type.IsEndBlock()) {
                deserialize = WriteEof;
                return block.AddItem(new Node(token.Potential));
            }
            if (!token.Type.IsObject()) return block.AddItem(token.Skip(ref deserialize));
            deserialize = WriteFirstRowCell;
            return block.AddItem(new Node(token.Potential));
        }
        private Node WriteFirstRowCell(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.Type.IsEndBlock()) {
                FirstRowValidator(_row);
                _row.Clear();
                deserialize = WriteRow;
                return block.AddItem(new Node(token.Potential));
            }
            _row.Set(token.Name, token.Value, WriteGuarantee);
            return block.AddItem(token.Skip(ref deserialize));
        }
        private Node WriteRow(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.Type.IsEndBlock()) {
                deserialize = WriteEof;
                return block.AddItem(new Node(token.Potential));
            }
            if (!token.Type.IsObject()) return block.AddItem(token.Skip(ref deserialize));
            deserialize = WriteCell;
            return block.AddItem(new Node(token.Potential));
        }
        private Node WriteCell(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.Type.IsEndBlock()) {
                RowValidator(_row);
                _row.Clear();
                deserialize = WriteRow;
                return block.AddItem(new Node(token.Potential));
            }
            _row.Set(token.Name, token.Value, WriteGuarantee);
            return block.AddItem(token.Skip(ref deserialize));
        }
        private void ApplyHeaders(IEnumerable<Bsid> headers) {
            PropMap.AddRange(headers);
            _headers = PropMap.ToArray();
            if (WriteHeaders) InWriteHeaders(_writer);
        }
        private void RowValidator(Entity row) {
            InWriteCells(_writer, row);
        }
        private void FirstRowValidator(Entity row) {
            ApplyHeaders(row.GetNames<Bsid>());
            InWriteCells(_writer, row);
        }
        private void InWriteHeaders(BetextWriter writer) {
            var length = _headers.Length;
            for (int i = 0; i < length; i++) {
                if (i > 0) writer.Write(",");
                _writer.Write(CsvEscape((string) _headers[i]));
            }
            _writer.EndLine();
        }
        private void InWriteCells(BetextWriter writer, Entity row) {
            var length = _headers.Length;
            for (int i = 0; i < length; i++) {
                if (i > 0) writer.Write(",");
                _writer.Write(CsvEscape(row.QGet(_headers[i], string.Empty)));
            }
            _writer.EndLine();
        }
        private static string CsvEscape(string value) {
            if (string.IsNullOrWhiteSpace(value)) return value;
            var sb = new StringBuilder();
            var length = value.Length;
            var needEsc = false;
            for (int i = 0; i < length; i++) {
                var chr = value[i];
                if (chr == '"') {
                    needEsc = true;
                    sb.Append(chr).Append(chr);
                    continue;
                }
                if (",\r\n\t()".IndexOf(chr) > -1) needEsc = true;
                sb.Append(chr);
            }
            if (needEsc) sb.Append('"').Insert(0, '"');
            return sb.ToString();
        }
    }
}
