﻿using System.Text;

namespace Binean.Foundation.Storage {
    [CEntity]
    public sealed class CsvLexer(ICharInput reader) : IInput<Symbol> {
        public static readonly Symbol CommaSymbol = new(CsvSymbol.Comma);
        public static readonly Symbol NewLineSymbol = new(CsvSymbol.NewLine);

        private readonly ICharInput _reader = reader;

        public Bib Properties { get; } = Prior.CreateQNames();

        [CProp]
        public string? Location {
            get { return _reader.Location; }
            set { _reader.Location = value; }
        }

        [CProp]
        public object Position => _reader.Position;
        public Symbol Current { get; private set; } = Symbol.None;
        public bool IsEnd => Current == Symbol.Eof;
        public void MoveNext() {
            if (Current == Symbol.Eof) return;
            Current = Read();
        }
        public Symbol Read() {
            while (true) {
                var chr = SkipSpace(_reader);
                switch (chr) {
                    case ',':
                        _reader.MoveNext();
                        return CommaSymbol;
                    case '\r':
                    case '\n':
                        _reader.MoveNext();
                        if ("\r\n".Contains(_reader.Current)) _reader.MoveNext();
                        return NewLineSymbol;
                    case '"':
                        return new Symbol(CsvSymbol.Text, ReadString(_reader));

                    case BetextReader.EofCharacter: return Symbol.Eof;
                    default:
                        return new Symbol(CsvSymbol.Value, ReadText(_reader));
                }
            }
        }
        private static char SkipSpace(ICharInput reader) {
            while (reader.Current == ' ') reader.MoveNext();
            return reader.Current;
        }
        private static string ReadString(ICharInput reader) {
            if (reader.Current != '"') return string.Empty;
            reader.MoveNext();
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                char chr = reader.Current;
                reader.MoveNext();
                if (chr == '"') {
                    if (reader.Current == '"') {
                        reader.MoveNext();
                        sb.Append(reader.Current);
                        continue;
                    }
                    SkipSpace(reader);
                    if (!"\0\r\n,".Contains(reader.Current)) throw reader.InvalidCharacter(reader.Current);
                    return sb.ToString();
                }
                sb.Append(chr);
            }
            throw reader.ExpectedCharacter('"');
        }
        private string ReadText(ICharInput reader) {
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                char chr = reader.Current;
                if (chr == '"') throw reader.InvalidCharacter(chr);
                if (",\r\n".IndexOf(chr) > -1) return sb.ToString();
                _reader.MoveNext();
                sb.Append(chr);
                continue;
            }
            return sb.ToString();
        }
    }
    public static class CsvSymbol {
        public static readonly Bsid NewLine = nameof(NewLine);
        public static readonly Bsid Comma = nameof(Comma);
        public static readonly Bsid Text = nameof(Text);
        public static readonly Bsid Value = nameof(Value);
    }
}
