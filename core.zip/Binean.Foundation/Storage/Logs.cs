﻿namespace Binean.Foundation.Storage {
    [BLog]
    internal static class Logs {
        public const string BFND5011E = "Buffer has less data then expected.";
        public const string BFND5012E = "'Integer data type' expected.";
        public const string BFND5013E = "'String data type' expected.";
        public const string BFND5014E = "Invalid data type '{0}'.";
        public const string BFND5015E = "Invalid punctuator '{0}'.";

        public const string BFND5041E = "'{0}' is expected.";
        public const string BFND5042E = "Invalid character '{0}'.";
        public const string BFND5043E = "Invalid token '{0}'.";
        public const string BFND5044E = "Invalid symbol '{0}'.";
        public const string BFND5045E = "Invalid keyword '{0}'.";
        public const string BFND5046E = "Token's name is expected.";
        public const string BFND5047E = "Token's name is unexpected.";
        public const string BFND5048E = "Token's tag is too long: '{0}'.";
        public const string BFND5049E = "At least one condition is expected'.";
        public const string BFND504AE = "At least one configure is expected'.";
    }
}
