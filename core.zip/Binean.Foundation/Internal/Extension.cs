﻿using System.Runtime.CompilerServices;


namespace Binean.Foundation.Internal {
    public static partial class Extension {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity GetSource(this IGetter getter) {
            if (getter is EGetter re) return re._source;
            if (getter is IEntity ent) return ent;
            return Dummy.Entity;
        }
        //=> (getter is REntity pg) ? pg._source : getter as IEntity ?? Dummy.Entity;
    }
}