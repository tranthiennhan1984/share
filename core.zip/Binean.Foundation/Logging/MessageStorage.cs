﻿
using Binean.Private;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Logging {
    public static class MessageStorage {
        private static readonly Entity _messages = Prior.CreateEntity();
        public static void Load(Type type)
            => Helper.LoadMessages(_messages, type);
        public static void AddMessage(Bsid mid, string message)
            => _messages.ISet(mid, Helper.GenerateMessage(mid, message));

        //public static void Load(IEntity msgs) => _messages.Connect(msgs).BindAll().Dispose();

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static Bexception SomethingWrong()
        //    => CreateException(nameof(Logs.BFND90201E));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity SomethingWrongMessage()
            => Helper.GenerateMessage(_messages, nameof(Logs.BFND9021E));
        public static IEntity GenerateMessage(Bsid messageId, params object?[] args)
            => Helper.GenerateMessage(_messages, messageId, args);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bexception CreateException(Bsid messageId, params object?[] args)
            => CreateException(null, messageId, args);

        public static Bexception CreateException(Exception? innerException, Bsid messageId, params object?[] args) {
            var msg = GenerateMessage(messageId, args);
            if (innerException != null) msg.QSet(Properties.Exception, innerException);
            return new(msg.ToReadonly(), innerException);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Bexception CreateException(this IGetter message, Exception? innerException = null)
            => new(message, innerException);

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static Bexception CreateException(this Request request) {
        //    IProtein? msg = nullz
        //    using (var reader = request.LogSerialize()) {
        //        var logs = reader.ToProtein().AssertList();
        //        var length = logs.Count;
        //        for (int i = length - 1; i >= 0; i--) {
        //            if (logs[i] is not IProtein log) continue;
        //            if (log.Get(Properties.LogLevel, LogLevel.Information) >= LogLevel.Error) {
        //                msg = log;
        //                log.Set(Properties.Trace, logs);
        //            }
        //        }
        //    }
        //    msg ??= Prior.CreateEntity().Set(Properties.Message, Messages.BFND060101E);
        //    return new(msg.ToReadonly());
        //}
        //public static void WriteLog(this Request request, TextWriter writer, LogLevel minimumLevel = LogLevel.Verbose, Action<TextWriter, IProtein>? logWriter = null) {
        //    IList logs;
        //    using (var reader = request.LogSerialize()) {
        //        logs = Pro.ToList(reader);
        //    }
        //    logWriter ??= SimpleLogWriter;
        //    var length = logs.Count;
        //    for (int i = 0; i < length; i++) {
        //        if (logs[i] is not IProtein log) continue;
        //        if (log.Get(Properties.LogLevel, LogLevel.Verbose) < minimumLevel) continue;
        //        logWriter(writer, log);
        //    }
        //}
    }
    file static class Properties {
        public static readonly Bsid Exception = nameof(Exception);
    }
}
