﻿namespace Binean.Foundation.Logging {
    public static class LogManager {
        public static ILogger? Instance { get; set; } = new DebugLogger { SimpleLog = true };
        public static LogLevel MaxLevel { get; internal set; }
        public static void ClearMaxLevle() => MaxLevel = LogLevel.Verbose;
    }
}
