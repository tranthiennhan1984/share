﻿using System.Diagnostics;
using System.Text;


namespace Binean.Foundation.Logging {
    [CEntity]
    public abstract class TextLogger : IInfoLogger {
        protected TextLogger() { }

        [CProp]
        public LogLevel MinimumLevel { get; set; } = LogLevel.Verbose;

        [CProp]
        public bool SkipSuccess { get; set; }

        [CProp]
        public bool SimpleLog { get; set; }

        public IGetter? ErrorMessage { get; private set; }

        public LogLevel MaxLogLevel { get; private set; }

        public virtual void Log(IGetter message) {
            var logLevel = message.Get(Properties.LogLevel, LogLevel.Verbose);
            if (logLevel < MinimumLevel) return;
            if (logLevel > MaxLogLevel) MaxLogLevel = logLevel;
            if (logLevel >= LogLevel.Error) ErrorMessage = message;
            var bd = new StringBuilder();
            WriteLog(bd, message);
            Log(bd.ToString());
        }

        public virtual void Log(IMessage message) {

        }
        //public virtual void Log(Request request, Response response) {
        //    if (request is null) return;
        //    if (SkipSuccess && response.Status.IsSuccess()) return;
        //    var message = BuildMessage(request, response, MinimumLevel, SimpleLog && response.IsSuccess(), WriteLog);
        //    if (!string.IsNullOrWhiteSpace(message)) Log(message);
        //}
        protected abstract void Log(string text);
        protected virtual void WriteLog(StringBuilder bd, IGetter log)
            => LogWriter(bd, log);
        protected static void LogWriter(StringBuilder bd, IGetter log) {
            if (log.IsNullOrEmpty()) return;
            if (log.Get<string>(Properties.Id) is string id) bd.Append($"- {id}: ");
            bd.AppendLine(log.QGet<string>(Properties.Message));

            if (log.TryGetText(Properties.Location, out string? loc))
                bd.Append($"  {Properties.Location}: ").AppendLine(loc);
            if (log.TryGetText(Properties.Position, out string? pos))
                bd.Append($"  {Properties.Position}: ").AppendLine(pos);

            if (log.TryGetNotNull(Properties.Exception, out Exception? exp)) {
                using (var reader = new StringReader(exp.ToString())) {
                    string? line;
                    while ((line = reader.ReadLine()) != null) {
                        bd.Append("  ").AppendLine(line);
                    }
                }
            }
        }

        //protected static void LogWriter(StringBuilder bd, IGetter log) {
        //    const string Address = nameof(Address);
        //    const string Message = nameof(Message);
        //    const string Exception = nameof(Exception);

        //    if (log.IsNullOrEmpty()) return;
        //    if (log.Get<string>(Properties.Id) is string id) bd.Append($"- {id}: ");
        //    bd.AppendLine(log.Get<string>(Message));

        //    if (log.TryGetText(Address, out string? add))
        //        bd.Append($"  {Address}: ").AppendLine(add);

        //    if (log.TryGetText(Properties.Location, out string? loc))
        //        bd.Append($"  {Properties.Location}: ").AppendLine(loc);
        //    if (log.TryGetText(Properties.Position, out string? pos))
        //        bd.Append($"  {Properties.Position}: ").AppendLine(pos);

        //    if (log.TryGetNotNull(Exception, out Exception? exp)) {
        //        using (var reader = new StringReader(exp.ToString())) {
        //            string? line;
        //            while ((line = reader.ReadLine()) != null) {
        //                bd.Append("  ").AppendLine(line);
        //            }
        //        }
        //    }
        //}
        //public static string BuildMessage(Request request, Response response, LogLevel minimumLevel, bool isSimpleLog = true, Action<StringBuilder, IProtein>? logWriter = null) {
        //    if (request is null) return string.Empty;

        //    var content = Prior.CreateEntity();
        //    IList logs;
        //    using (var reader = request.LogSerialize()) {
        //        logs = Men.ToList(reader);
        //    }

        //    var bd = new StringBuilder();
        //    if (minimumLevel <= LogLevel.Debug) WriteInfo(request, response, bd, isSimpleLog);

        //    logWriter ??= LogWriter;
        //    var length = logs.Count;
        //    for (int i = 0; i < length; i++) {
        //        if (logs[i] is not IProtein log) continue;
        //        if (log.Get(Properties.LogLevel, LogLevel.Verbose) < minimumLevel) continue;
        //        logWriter(bd, log);
        //    }
        //    return bd.ToString();
        //}
        //private static void WriteInfo(Request request, Response response, StringBuilder bd, bool isSimpleLog) {
        //    var add = request.GetAddress();
        //    if (isSimpleLog) {
        //        bd.Append(add).Append(": ")
        //            .AppendLine(response.Get<string>(Properties.Status));
        //        return;
        //    }
        //    var req = Prior.CreateEntity();
        //    req.Connect(request).Bind(Properties.Body);
        //    bd.Append(add).Append(' ')
        //    .Append(req.ToCen());

        //    var status = response.Get(Properties.Status);
        //    bd.Append(Properties.Status).Append(": ").Append(status).AppendLine();

        //    //var resp = new DependencyEntity(response);
        //    //resp.Remove(Properties.Status).Remove(Properties.ErrorCode);
        //    //bd.Append(resp.DenToCen());
        //}
    }

    [CEntity]
    public class DebugLogger : TextLogger {
        protected override void Log(string text) {
            Debug.Write(text);
        }
    }

    [CEntity]
    public class ConsoleLogger : TextLogger {
        protected override void Log(string text) {
            try {
                Console.Write(text);
            } catch (Exception ex) { var _ = ex; }
        }
    }
    file static class Properties {
        public static readonly Bsid Id = nameof(Id);

        public static readonly Bsid ServerName = nameof(ServerName);
        public static readonly Bsid Path = nameof(Path);
        public static readonly Bsid Method = nameof(Method);

        public static readonly Bsid Status = nameof(Status);
        public static readonly Bsid ErrorCode = nameof(ErrorCode);

        public static readonly Bsid LogLevel = nameof(LogLevel);

        public static readonly Bsid Location = nameof(Location);
        public static readonly Bsid Position = nameof(Position);

        public static readonly Bsid Body = nameof(Body);

        public static readonly Bsid Message = nameof(Message);
        public static readonly Bsid Exception = nameof(Exception);
    }
}
