﻿namespace Binean.Foundation.Logging {
    [BLog]
    internal static class Logs {
        public const string BFND9011E = "This field is required.";
        public const string BFND9021E = "Oops, Somthing went wrong.";
    }
}
