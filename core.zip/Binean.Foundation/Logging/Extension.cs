﻿using System.Collections;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Logging {
    public static partial class Extension {
        #region :: Logger ::
        public static Bexception CreateException(this ILogger logger, Bsid messageId, params object?[] args) {
            var msg = InGenerateMessage(logger, out LogLevel level, messageId, args);
            if (msg != null) {
                logger.Log(msg.Trace());
                if (level > LogManager.MaxLevel) LogManager.MaxLevel = level;
            }
            return MessageStorage.CreateException(messageId, args);
        }
        public static void Log(this ILogger logger, IList? messages) {
            if (messages is null || messages.Count == 0) return;
            var length = messages.Count;
            for (int i = 0; i < length; i++) {
                if (messages[i] is IEntity msg) logger.Log(msg);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? AssertSupport<T>(this T? logger, LogLevel level) where T : ILogger {
            return logger != null && logger.MinimumLevel <= level ? logger : default;
        }

        private static IEntity? InGenerateMessage<T>(T? logger, out LogLevel logLevel, Bsid messageId, params object?[] args) where T : ILogger {
            var retVal = MessageStorage.GenerateMessage(messageId, args);
            logLevel = retVal.Get(Properties.LogLevel, LogLevel.Verbose);
            if (logger.AssertSupport(logLevel) is null) return null;
            return retVal.QSet(Properties.LogTime, DateTime.Now);
        }

        public static bool Log(this ILogger logger, Bsid messageId, params object?[] args) {
            var msg = InGenerateMessage(logger, out LogLevel level, messageId, args) ?? throw new InvalidOperationException();
            logger.Log(msg.Trace());
            return level < LogLevel.Error;
        }
        public static T Trace<T>(this T entity, int index = 2) where T : IEntity {
            if (new StackTrace(1).GetFrame(index) is StackFrame stackFrame)
                entity.Set(Properties.Trace, stackFrame);
            return entity;
        }

        public static void WriteLogs(this ISerlogger logger, ILogger newLogger) {
            using (var reader = logger.Serialize()) {
                if (Men.ToObject(reader) is IList logs) {
                    foreach (var item in logs) {
                        if (item is not IGetter log) continue;
                        newLogger.Log(log);
                    }
                }
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void WriteDebug(this ISerlogger logger)
            => logger.WriteLogs(new DebugLogger());

        //private static void SimpleLogWriter(TextWriter writer, IGetter log) {
        //    if (log.IsNullOrEmpty()) return;
        //    if (log.Get<string>(Properties.Id) is string id) writer.Write($"- {id}: ");

        //    if (log.TryGetText(Properties.Location, out string? loc)) {
        //        writer.Write($"  {Properties.Location}: ");
        //        writer.WriteLine(loc);
        //    }
        //    if (log.TryGetText(Properties.Position, out string? pos)) {
        //        writer.Write($"  {Properties.Position}: ");
        //        writer.WriteLine(pos);
        //    }

        //    writer.WriteLine(log.Get<string>(Properties.Message));
        //    if (log.TryGetNotNull(Properties.Exception, out Exception? exp)) {
        //        using (var reader = new StringReader(exp.ToString())) {
        //            string? line;
        //            while ((line = reader.ReadLine()) != null) {
        //                writer.Write("  ");
        //                writer.WriteLine(line);
        //            }
        //        }
        //    }
        //}
        #endregion

        #region :: Messages ::
        //public static Bexception CreateException(this ILogger logger, string? scope, Bid messageId, params object?[] args) {
        //    var msg = InGenerateMessage(logger, out LogLevel level, messageId, args);
        //    if (msg != null) {
        //        if (!string.IsNullOrWhiteSpace(scope)) msg.QSet(Properties.Scope, scope);
        //        logger.Log(msg.Trace());
        //        if (level > LogManager.MaxLevel) LogManager.MaxLevel = level;
        //    }
        //    return MessageStorage.CreateException(messageId, args);
        //}
        //public static T Log<T>(this T logger, string? scope, Bid messageId, params object?[] args) where T : ILogger {
        //    var msg = InGenerateMessage(logger, out LogLevel level, messageId, args);
        //    if (msg is null) return logger;
        //    if (!string.IsNullOrWhiteSpace(scope)) msg.QSet(Properties.Scope, scope);
        //    logger.Log(msg.Trace());
        //    if (level > LogManager.MaxLevel) LogManager.MaxLevel = level;
        //    return logger;
        //}
        //public static bool Val(this ILogger logger, string? scope, string messageId, params object?[] args) {
        //    var msg = InGenerateMessage(logger, out LogLevel level, messageId, args);
        //    if (msg is null) return level < LogLevel.Error;
        //    if (!string.IsNullOrWhiteSpace(scope)) msg.QSet(Properties.Scope, scope);
        //    logger.Log(msg.Trace());
        //    if (level > LogManager.MaxLevel) LogManager.MaxLevel = level;
        //    return level < LogLevel.Error;
        //}
        //public static bool IsValScope(this string? scope, string exp) {
        //    if (scope is null) return false;
        //    if (string.IsNullOrEmpty(scope)) return true;
        //    return scope.IsName(exp);
        //}

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool RequiredMessage(this ILogger logger, string? scope) {
        //    logger.Log(scope, nameof(Logs.BFND090101E));
        //    return false;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool ValRequired(this ILogger logger, object? value, string? scope = null) {
        //    if (value != null) return true;
        //    logger.Log(scope, nameof(Logs.BFND090101E));
        //    return false;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool ValRequired(this ILogger logger, string? value, string? scope = null) {
        //    if (!string.IsNullOrEmpty(value)) return true;
        //    logger.Log(scope, nameof(Logs.BFND090101E));
        //    return false;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool ValText(this ILogger logger, string? value, string? scope = null) {
        //    if (!string.IsNullOrWhiteSpace(value)) return true;
        //    logger.Log(scope, nameof(Logs.BFND090101E));
        //    return false;
        //}

        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool TryValRequired(this ILogger logger, object? value, out Bexception? ex, Bid? scope = null) {
        //    if (value != null) return (ex = null) is null;
        //    ex = logger.CreateException(scope, nameof(Logs.BFND090101E));
        //    return false;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool TryValRequired(this ILogger logger, string? value, out Bexception? ex, Bid? scope = null) {
        //    if (!string.IsNullOrEmpty(value)) return (ex = null) is null;
        //    ex = logger.CreateException(scope, nameof(Logs.BFND090101E));
        //    return false;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool TryValText(this ILogger logger, string? value, out Bexception? ex, Bid? scope = null) {
        //    if (!string.IsNullOrWhiteSpace(value)) return (ex = null) is null;
        //    ex = logger.CreateException(scope, nameof(Logs.BFND090101E));
        //    return false;
        //}

        #endregion
    }
    file static class Properties {
        public static readonly Bsid LogLevel = nameof(LogLevel);
        public static readonly Bsid LogTime = nameof(LogTime);

        public static readonly Bsid Exception = nameof(Exception);
        public static readonly Bsid Id = nameof(Id);
        public static readonly Bsid Message = nameof(Message);

        public static readonly Bsid Trace = nameof(Trace);

        public static readonly Bsid Location = nameof(Location);
        public static readonly Bsid Position = nameof(Position);

        public static readonly Bsid Scope = nameof(Scope);
    }
}
