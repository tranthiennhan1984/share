﻿
using Binean.Foundation.Logging;
using System.Collections;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Flow {
    [BLog]
    file static class Logs {
        public const string BFND30201E = "Scope already completed.";
        public const string BFND30202E = "In the {0} function, status code '{1}' is not allowed.";
    }
    public class Scope : BEntity, IScope {
        public Scope(Batch batch, IScript script, IList actions, IScope? parent = null, ILogger? logger = null) {
            Batch = batch;
            Script = script;
            Parent = parent;
            Actions = actions;
            Logger = logger ?? new MemoryLogger();
        }
        public Batch Batch { get; }
        public IScript Script { get; }
        public IScope? Parent { get; }
        public IList Actions { get; }

        public BStatus BStatus { get; protected set; }
        public ILogger Logger { get; }
        public object? Response => Latent.Get(Properties.Response);
        public BStatusCode StatusCode => Latent.Get<BStatusCode>(Properties.StatusCode);

        public void ChangeStatus(BStatus status) {
            switch (status) {
                case BStatus.Waiting:
                case BStatus.Sending:
                case BStatus.Processing:
                    BStatus = status;
                    break;
                default:
                    throw new InvalidOperationException();
            }
        }
        public bool Success(object? response, BStatusCode code = BStatusCode.Ok) {
            this.AssertNotCompleted();
            if (!code.IsSuccess()) throw MessageStorage.CreateException((Bid)nameof(Logs.BFND30202E), nameof(Success), code);
            Latent.QSet(Properties.Response, response);
            Latent.QSet(Properties.StatusCode, code);
            BStatus = BStatus.Success;
            return true;
        }
        public bool Faulted(BStatusCode code, IGetter? message) {
            message = message.AssertErrorMessage();
            if (code.IsSuccess()) throw MessageStorage.CreateException((Bid)nameof(Logs.BFND30202E), nameof(Faulted), code);
            if (this.IsCompleted()) {
                if (!message.IsNullOrEmpty()) Logger.Log(message);
                Latent.MSet(Properties.StatusCode, code);
                return false;
            }
            Latent.QSet(Properties.StatusCode, code);
            if (!message.IsNullOrEmpty()) Logger.Log(message);
            BStatus = BStatus.Faulted;
            return false;
        }
        public bool Terminated() {
            if (this.IsCompleted()) return false;
            Latent.QSet(Properties.StatusCode, BStatusCode.InternalServerError);
            BStatus = BStatus.Terminated;
            return false;
        }
    }
    file static class Properties {
        public static readonly Bid Response = new(nameof(Response));
        public static readonly Bid StatusCode = new(nameof(StatusCode));
    }
}
