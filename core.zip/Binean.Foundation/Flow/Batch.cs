﻿using Binean.Foundation.Core;
using Binean.Private;
using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices.JavaScript;
using System.Security.AccessControl;

namespace Binean.Foundation.Flow {

    [CEntity]
    public class Batch : BEntity, IACell {
        public const string ScriptExtension = ".bs";
        public static Batch Current => _current ??= Generator.Create<Batch>();
        private static Batch? _current;

        protected readonly FileCell _fileCell;
        private readonly ACell _cells = new();

        public Batch() {
            _fileCell = new FileCell {
                Location = nameof(Batch)
            };
            AttachCell(Resources.file, _fileCell);
            OnConfiguration();
        }

        public static void Test() {
            //var domain = Generator.Create<BDomain>();
            //if (domain.ToGettable().QGet((Bsid)"batch") is Batch batch) {
            //    if (batch.List() is IList scripts) {
            //        batch.Run(new BatchRunArgs {
            //            Path = scripts[0].Convert<string>()
            //        });
            //    }
            //}
        }

        [CProp]
        public string Location {
            get => _fileCell.Location;
            set => _fileCell.Location = value;
        }
        public IGetter Cells => _cells.Cells;

        public void AttachCell(Bsid name, ICell cell, bool guarantee = true) => _cells.AttachCell(name, cell, guarantee);
        public virtual bool Validate(ILogger logger) {
            if (Potential.TryGetNotNull(Properties.Cells, out IGetter? getter)) {
                foreach (var unit in getter) {
                    if (unit.Value is not ICell cell) continue;
                    _cells.AttachCell(unit.Name!, cell);
                }
            }
            return true;
        }

        public bool Process(IMessage message) {
            message.LogInfo();
            if (!message.TryGetPath(out Bip? path, true) || path.IsNullOrEmpty()) return OnSelfProcess(message);
            return _cells.Process(message);
        }
        protected virtual bool OnSelfProcess(IMessage message) {
            if (!message.TryGetMethod(out Bsid method)) return message.BadRequest();
            try {
                if (method == Methods.run) return OnRun(message);
                if (method == BMethods.list) return OnList(message);
                return message.NotFound();
            } catch (Exception ex) {
                return message.Faulted(ex.Correct());
            } finally {
                if (!message.IsSuccess() && message.Logger is ISerlogger serlogger) {
                    serlogger.WriteDebug();
                }
            }
        }
        protected virtual bool OnList(IMessage message) {
            var msg = _fileCell.RProcess(BMethods.list, null, message, null);
            return message.Complete(msg);
        }
        protected virtual bool OnRun(IMessage message) {
            if (!message.TryUnboxRequest(out BatchRunArgs? args)) return message.BadRequest();

            var script = args.Script;
            if (script is null && !string.IsNullOrWhiteSpace(args.Path) && !OnLoadScript(args.Path, out script))
                return message.BadRequest(nameof(Logs.BFND3012E), args.Path);
            if (script is null) return message.BadRequest();

            if (!script.Functions.TryGetNotNull(Properties.main, out IFunc? func)) return message.BadRequest(nameof(Logs.BFND3011E));

            var context = CreateContext(func, null, message.Logger);
            if (func.Parameters is IGetter pars && !pars.IsEmpty && message.GetRequest().ToGetter() is IGetter fArgs) ApplyArguments(context, pars, fArgs);

            try {
                OnLoadContext(context);
                Execute(func.Body, context);
                return message.Complete(context);
            } catch (Exception ex) {
                return message.Faulted(ex.Correct());
            } finally {
                OnSaveContext(context);
            }
        }
        protected virtual void OnConfiguration() { }
        protected virtual void OnSaveContext(IContext context) { }
        protected virtual void OnLoadContext(IContext context) { }

        protected virtual bool OnLoadScript(string path, [NotNullWhen(true)] out IScript? script) {
            var a = _fileCell.Read<object>(new FileRdArgs {
                Format = Formats.bs,
                Type = ContentType.Object,
                Path = path,
            });

            _fileCell.Replace(new FileUdArgs {
                Path = "d:\\aaa.cen",
                Format = Eformat.cen,
                Content = a
            });

            return (script = a as IScript) != null;
        }
        public virtual IContext CreateContext(IContext? parent = null, ILogger? logger = null) {
            return new Context(this, parent?.Script ?? Dummy.Script, parent, logger);
        }
        public virtual IContext CreateContext(IFunc func, Context? parent = null, ILogger? logger = null) {
            var retVal = new Context(this, func.Script, parent, logger);
            retVal.Potential.QSet(Properties.Function, func);
            return retVal;
        }

        public virtual void ApplyArguments(IContext context, IGetter pars, IGetter args)
            => context.ApplyArguments(pars, args);

        public virtual void Execute(IList actions, IContext context) {
            context.ChangeStatus(BStatus.Processing);
            var length = actions.Count;
            if (length == 0) return;
            for (int i = 0; i < length; i++) {
                if (context.IsCompleted()) return;
                if (actions[i] is not IAction act) {
                    context.BadRequest(nameof(Logs.BFND3013E), actions[i]);
                    return;
                }
                act.Process(context);
                //if (context.IsSuccess() ) {
                //    context.BadRequest(nameof(Logs.BFND30104E), actions[i]);
                //    return;
                //}
            }
            if (!context.IsCompleted()) context.NoContent();
        }

        public virtual object? ReadExpression(IContext context, object expression)
            => context.ReadExpression(expression);

        public virtual Reader Serialize(object expresion, IContext context)
            => new FlowReader(expresion, context, context.Variables);
    }

    [CEntity]
    public class BatchRunArgs : BEntity {
        [CProp]
        public string? Path { get; set; }
        [CProp]
        public IScript? Script { get; set; }
        [CProp]
        public object? Arguments { get; set; }
    }
    file static class Resources {
        public static readonly Bsid file = nameof(file);
    }
    file static class Properties {
        public static readonly Bsid Cells = nameof(Cells);

        public static readonly Bsid Response = nameof(Response);
        public static readonly Bsid StatusCode = nameof(StatusCode);

        public static readonly Bsid Function = nameof(Function);

        public static readonly Bsid main = nameof(main);
    }
    file static class Methods {
        public static readonly Bsid run = nameof(run);
    }
    file static class Formats {
        public static readonly Bsid bs = nameof(bs);
    }
}
