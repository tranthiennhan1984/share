﻿using Binean.Foundation.Core;
using Binean.Foundation.Logging;
using System.Collections;
using static System.Formats.Asn1.AsnWriter;

namespace Binean.Foundation.Flow {
    public class Context : BMessage, IContext {
        internal readonly IEntity _variables = Prior.CreateEntity();

        public Context(Batch batch, IScript script, IMessage? parent = null, ILogger? logger = null) : base(parent, logger) {
            Batch = batch;
            Script = script;
            Variables = new VarEnt(this);
        }
        public Bib ReadonlyVariables { get; } = Prior.CreateQNames();
        public IEntity Variables { get; }

        public Batch Batch { get; }
        public IScript Script { get; }

        protected bool OnTryGetVariable(Bsid name, out object? value)
            => _variables.TryGetValue(name, out value);
        protected bool OnTrySetVariable(Bsid name, object? value) {
            if (ReadonlyVariables.Contains(name)) return false;
            if (_variables.TrySetValue(name, value)) return true;
            if (Parent is IContext pContext) return pContext.Variables.TrySetValue(name, value);
            return false;
        }
        sealed class VarEnt : IEntity {
            private readonly Context _context;
            private readonly IEntity _variable;

            public VarEnt(Context context) {
                _context = context;
                _variable = _context._variables;
            }

            public bool IsEmpty => _variable.IsEmpty;

            public void ChangeDisplayBid(Bsid bid) => _variable.ChangeDisplayBid(bid);
            public bool TryGetValue(Bsid bid, out object? value)
                => _context.OnTryGetVariable(bid, out value);
            public bool TrySetValue(Bsid bid, object? value)
                => _context.OnTrySetVariable(bid, value);
            public bool TryRemoveValue(Bsid bid) => _variable.TryRemoveValue(bid);
            public bool Clear() => _variable.Clear();


            IEnumerator<IUnit> IEnumerable<IUnit>.GetEnumerator() => _variable.GetEnumerator();
            IEnumerator IEnumerable.GetEnumerator() => _variable.GetEnumerator();
        }
    }
}
