﻿namespace Binean.Foundation.Flow {
    [BLog]
    internal static class Logs {
        public const string BFND3011E = "Missing main function.";
        public const string BFND3012E = "Cannot load module from '{0}'.";
        public const string BFND3013E = "Cannot convert '{0}' to IAction.";
        public const string BFND3014E = "Context is completed at action '{0}'.";
    }
}
