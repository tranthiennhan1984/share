﻿namespace Binean.Foundation.Flow {
    file static class Properties {
        public const string StopWhenError = nameof(StopWhenError);
    }
    public class Func : IFunc, IAction {
        protected readonly List<IAction> _actions = new();

        public Func(IEntity args, List<IAction> actions) {
            Arguments = args;
            _actions = actions;
        }

        public BRequest Request { get; set; } = default!;
        public IContext? Context { get; private set; }
        public IEntity Arguments { get; protected set; }

        IReadOnlyList<IAction> IFunc.Actions => _actions;

        public bool Process(BRequest request, IContext context) {
            Request = request;
            Context = context;
            return context.Engine.Call(context, this, request);
        }
    }
}
