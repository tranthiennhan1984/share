﻿namespace Binean.Foundation.Services {
    [CEntity]
    public class CellService : BEntity {
        public CellService(ICell cell) {
            Cell = cell;
        }

        [CProp]
        public ICell Cell { get; set; }

        protected IMessage Process(Bid method, object? args = null, IMessage? message = null, Propath? path = null)
            => Cell.RProcess(method, args, message, path);
        protected async ValueTask<IMessage> ProcessAsync(Bid method, object? args = null, IMessage? message = null, Propath? path = null)
            => await Cell.RProcessAsync(method, args, message, path);
    }
}
