﻿namespace Binean.Foundation.Services {
    public interface IAppService {
        bool IsReady { get; }
        object? ContentComponent { get; }

        void Open(ILink? link);

        void OpenDialog(ILink link);
        Task<dynamic?> OpenDialogAsync(ILink link);
        void CloseDialog(dynamic? result);
    }
}

