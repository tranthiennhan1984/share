﻿using BenchmarkDotNet.Running;
using Binean.Foundation.Primitive;
using System.Buffers.Text;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Benchmark {
    public class Program {
        public static void Main(string[] args) {
            //CodeId.FromString("RP00000001");
            var summary = BenchmarkRunner.Run(typeof(Program).Assembly);
        }
    }
}