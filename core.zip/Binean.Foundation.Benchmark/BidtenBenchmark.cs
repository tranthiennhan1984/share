using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using Binean.Foundation.Primitive;
using Microsoft.Diagnostics.Tracing.Parsers.MicrosoftWindowsTCPIP;
using System.Buffers.Text;
using System.Diagnostics;
using System.Text;

namespace Binean.Foundation.Benchmark {
    public class BidtenBenchmark {
        // private TestClass _tc = new TestClass();

        [Benchmark]
        public CodeId CastString() => (CodeId)"RP00000001";

        [Benchmark]
        public CodeId CallMethod() => "RP00000001".ToBidten();

    }
    class TestClass {
        public string Name { get; set; } = "Nhan";
    }
}