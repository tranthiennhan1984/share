#!/bin/ksh
# Stop INGENIUM Queue Worker 
export MQSERVER=INGQMGR.CHANNEL/TCP/'159.249.172.194(2399)'
#export MQSERVER=INGQMGR.CHANNEL/TCP/'159.249.172.129(2399)'
echo "MQSERVER=" $MQSERVER

export XSBCF=I00QWRK
export XSOCF=out/XSBUQEND.out
export LIBPATH=/usr/mqm/lib:$LIBPATH
#export DEVANIM=+A
#export DISPLAY=159.249.170.237:0

$DEVSRCE/binbatch/XSBUQEND 

echo "INGENIUM shutdown completed"