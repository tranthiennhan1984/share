Setup WebSphere MQ for INGENIUM queue deployment
------------------------------------------------

This document describes the setup requirement for running INGENIUM backend
without CICS (TXSeries).  The queue manager name is selected as INGQMGR and 
each region needs 3 queues for operation. By function, they are the dispatch
queue (IxxQ710), input queue (IxxI710) and output queue (IxxO710) where xx is
PR, ST, UT which stands for different regions.  In production setup, only the
PR queues are required.  It is assumed that the WebSphere MQ software is 
installed and functional.  The user running the steps must be a member of the
group mqm (Unix) and an administrator in Windows.  The queue manager is 
created with security off for non production environment. 

Step 1
------
Create queue manager

On Unix

Open a shell and enter the following
     export MQSNOAUT=yes
     crtmqm -lc -lp 30 -ls 100 -lf 1000 INGQMGR
     strmqm INGQMGR

On Windows

Sign on as administrator and open a command window and enter the following
     set MQSNOAUT=yes
     crtmqm -lc -lp 30 -ls 100 -lf 1000 INGQMGR
     strmqm INGQMGR

Step 2
------
Create queues by MQSC

runmqsc INGQMGR < INGMQDef.txt > INGMQDef.log


Step 3
------
Create server connection channel

runmqsc INGQMGR < createChannel.txt > createChannel.log

Step 4
------
Create a listener for client connection, port selected is 2399 which can be
changed.

runmqsc INGQMGR < createListener.txt > createListener.log
