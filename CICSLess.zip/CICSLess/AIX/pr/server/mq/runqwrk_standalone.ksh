#!/bin/ksh
# Run one instance of queue worker
rm -f out/*.out
./runqwrk.ksh
