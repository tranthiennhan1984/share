#!/usr/bin/perl -w
use v5.6.0;   # or better
use strict;
use threads;
use Thread::Semaphore;

# Install our own signal handler
$SIG{'HUP'}  = \&sig_hup;
$SIG{'INT'}  = \&sig_hup;
$SIG{'QUIT'} = \&sig_hup;

# Create a semaphore to maintain synchronized access to
# our thread count
my $semaphore = new Thread::Semaphore;
my $threadCount : shared = 0;

# Max Processes spawned, can be overriden on Command Line
my $maxthreads : shared = shift(@ARGV) || 3;

# The sleep time between when the program checks for dead
# processes
my $SLEEPTIME = 5;

# The Command to run in each process
my $commandToRun = "runqwrk.ksh";

my ($currentThread,$id);


# Start the main thread loop, startup the threads
print localtime() . " - Starting Threads (process id - $$)\n";
for ($currentThread=0;$currentThread<$maxthreads;$currentThread++)
{
	# start the thread
	$id = new threads \&cobolProcess;

	# detach the thread as we are not interested in returning
	# anything
	$id->detach;
}

print localtime() . " - waiting for all threads to initialize ...";

# wait for all the threads to initialize
while(1)
{
	if ($threadCount == $maxthreads)
	{
		print " done" ."\n";
		print localtime() . " - Total Thread Count - $threadCount\n";
		last;
	}
}

# Check the thread count every $SLEEPTIME seconds and create a
# new thread if we need to.
while(1)
{
	if ($maxthreads == 0)
	{
		if ($threadCount == 0)
		{
			print localtime() . " - Region Shutdown\n";
	 		last;
		}	
	} elsif ($threadCount < $maxthreads)
	{
		print localtime() . " - creating new thread\n";
		$id = new threads \&cobolProcess;
		$id->detach;
	}

	sleep($SLEEPTIME);
}



# The COBOL process that we start up
sub cobolProcess
{
	# increment the thread count
	$semaphore->up;
	$threadCount+=1;

	# execute the Process
	`$commandToRun`;

	# Check for exit signal from COBOL
	# 256 is equivalent to 1 from shell script 
	if ($? == '256')
	{
		print localtime() . " - Thread stopped\n";
		$maxthreads=0;
	} else {
		print localtime() . " - Thread died\n";
	}


	# Decrement the thread count
	$threadCount-=1;
	$semaphore->down;
}

# Our customized signal handler.
sub sig_hup
{
   print localtime() . " - Kill received, cleaning up..\n";
   exit;
}

