#!/bin/ksh
# Start INGENIUM Queue Worker 
export MQSERVER=INGQMGR.CHANNEL/TCP/'159.249.172.194(2399)'
#export MQSERVER=INGQMGR.CHANNEL/TCP/'159.249.172.129(2399)'
echo 'MQSERVER=' $MQSERVER
retrn='0'
export XSBCF=I00QWRK
export XSOCF=out/XSBUQWRK_$$.out
export LIBPATH=/usr/mqm/lib:$LIBPATH
#export DEVANIM=+A
#export DISPLAY=159.249.170.237:0
while [ 1 ]
do
	$DEVSRCE/binbatch/XSBUQWRK $DEVDB $DEVUSER $DEVPASS $$ 
	retrn=$?
        if [[ $DEVANIM = "+A" ]]; then break; fi
	if [[ $retrn = '1' ]]; then break; fi
done
exit $retrn
