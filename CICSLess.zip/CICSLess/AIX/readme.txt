This directory contains changes specific to AIX environment, other changes under srce and copy 
directories are the same.