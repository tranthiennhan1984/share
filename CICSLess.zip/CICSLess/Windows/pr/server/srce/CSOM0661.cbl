      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0661.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0661                                         **
      **  REMARKS:  SERV TRANSACTION                                 **
      **  DOMAIN :   PR                                              **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
550567**  5.5       SYSTEM MSG FOR RPU IF EFF-DT NOT= PD-TO-DT       **
553989**  5.5       SYSTEM MSG FOR ETI IF EFF-DT NOT= PD-TO-DT       **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557665**  5.5       SCHEDULING ENHANCEMENTS                          **
557690**  5.5       TAXATION OF US IMMEDIATE ANNUITIES               **
557697**  5.5       SPECIAL FREQUENCY BILLINGS                       **
557708**  5.5       NEW ABEND HANDLING ROUTINE                       **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       MODIFICATIONS REQUIRED FOR LEAP YEAR             **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012137**  5.6V      CHANGES TO SUPPORT A NEW SUPPRESS                **
012137**            CONFIRMATION SCREEN FIELD                        **
012624**  6.0       SECURITY                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014035**  6.0       CODE STANDARDIZATION                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       GLOBAL MESSAGING                                 **
014221**  6.2       LOGICAL LOCKING                                  **
015768**  6.2       CVG NUM/ EFFECTIVE DATE DEFAULT                  **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016548**  6.2       CHANGE COMP TO BINARY                            **
016686**  6.2       INGENIUM PROCESSING DATE CHANGES FOR CONCURRENCY **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020572**  6.3       LAPSING PAID-UP POLICIES IN SHORTAGE             **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020463**  6.4       INVESTOR PROFILES                                **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
025981**  6.7       MISLEADING MESSAGE ON ETI QUOTE                  **
028760**  6.7       MISLEADING MESSAGE ON RPU QUOTE                  **
029590**  6.7       POLICY NOT FOUND CONDITION HANDLING              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
026740**  7.1       ETI PROCESSING WITH PURE ENDOWMENT AMOUNT        **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0661'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *
       COPY SQLCA.
018764*COPY XCWLPTR.

       COPY XCWL8090.
014590*COPY XCWL0030.

007766 COPY XCWWCVGM.

       01  WS-PGM-WORK-AREA.
           05  TRANSACTION-NAME             PIC X(4) VALUE 'SERV'.
025970         88 TRANSACTION-NAME-DEFAULT       VALUE 'SERV'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1360' '1361' '1362'
                                                  '1364' '1365' '1366'
                                                  '1367' '1368' '1369'
                                                  '1370' '1371' '1372'
                                                  '1373' '1374' '1375'
023436*                                    '1376' '1377' '1378' '1379'.
023436                                     '1376' '1377' '1378' '1379'
                                           '1380'.
               88  WS-BUS-FCN-ANNIVERSARY        VALUE '1360'.
               88  WS-BUS-FCN-APL                VALUE '1361'.
               88  WS-BUS-FCN-APL-REVERSAL       VALUE '1362'.
               88  WS-BUS-FCN-PUT-ON-WAIVER      VALUE '1364'.
               88  WS-BUS-FCN-TAKE-OFF-WAIVER    VALUE '1365'.
               88  WS-BUS-FCN-MAKE-PAID-UP       VALUE '1366'.
               88  WS-BUS-FCN-RPU-QUOTE          VALUE '1367'.
               88  WS-BUS-FCN-REDUCED-PAID-UP    VALUE '1368'.
               88  WS-BUS-FCN-RPU-REVERSAL       VALUE '1369'.
               88  WS-BUS-FCN-ETI-QUOTE          VALUE '1370'.
               88  WS-BUS-FCN-EXTENDED-TERM      VALUE '1371'.
               88  WS-BUS-FCN-ETI-REVERSAL       VALUE '1372'.
               88  WS-BUS-FCN-DEEMED-DISPOS      VALUE '1373'.
               88  WS-BUS-FCN-AUTO-PREM-PYMT     VALUE '1374'.
               88  WS-BUS-FCN-IMMED-ANN-PYMT     VALUE '1375'.
               88  WS-BUS-FCN-IAP-REVERSAL       VALUE '1376'.
               88  WS-BUS-FCN-RRIF-PYMT          VALUE '1377'.
               88  WS-BUS-FCN-RRIF-PYMT-REVERSAL VALUE '1378'.
               88  WS-BUS-FCN-RESET              VALUE '1379'.
023436         88  WS-BUS-FCN-ANNIVERSARY-REVRS  VALUE '1380'.
               88  WS-BUS-FCN-REV-TRANS          VALUE '1364' '1368'
                                                       '1365' '1366'
023436                                          '1371' '1362' '1380'.
023436*                                                '1371' '1362'.
016503         88  WS-BUS-FCN-REDO-BYPASS        VALUE '1362' '1367'
016503                                                 '1369' '1370'
016503                                                 '1372' '1376'
016503                                                 '1378'.
       01  INDICES-FOR-661.
016548*    05  W0661-SUB             PIC S9(04)  COMP.
016548     05  W0661-SUB             PIC S9(04)  BINARY.
016548*    05  I                     PIC S9(04)  COMP.
016548     05  I                     PIC S9(04)  BINARY.
016440     05  WS-CVG                PIC S9(04)  BINARY.
       01  SWITCHES-FOR-661.
           05  WS-LEVEL-SW               PIC X.
               88  PROCESSING-POLICY     VALUE 'P'.
               88  PROCESSING-COVERAGE   VALUE 'C'.
016503     05  WS-REDO-SW            PIC X(01).
016503         88  WS-REDO-OK            VALUE 'Y'.
016503         88  WS-REDO-NOT-OK        VALUE 'N'.
      *
008455*01  EDIT-FIELDS-FOR-661.
008455*    05  EDIT-9V2              PIC 9(9).99.
008455*    05  WS-IN-S9V2            PIC 9(9).99.
008455*    05  WS-IN-S9V2-X   REDEFINES WS-IN-S9V2.
008455*        10  WS-IN-S9V2-XNO     PIC X(9).
008455*        10  WS-IN-S9V2-XPT     PIC X.
008455*        10  WS-IN-S9V2-XDC     PIC X(2).
       01  DISPLAY-FIELDS-FOR-661.
           05  DISPLAY-CVG           PIC 99.

023436 01  WS-WORK-AREA.
023436     05  WS-PHST-ACTV-TYP-CD          PIC 9(4).
023436         88  WS-PHST-ACTV-APL         VALUE 7023.
023436         88  WS-PHST-ACTV-ANNV        VALUE 7040.

018633*01  WS-TWRK-KEY                      PIC X(04) VALUE '1360'.
018633*01  WS-WORK-AREA.
018633*    05  WS-INTERNAL-DT               PIC X(10).
018633*    05  FILLER                       PIC X(290).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '1360'.
018633     15  LCOMM-TWRK-AREA.
018633         20  LCOMM-INTERNAL-DT   PIC X(10).

      *
      ****************************************************************
      * COMMON COPYBOOKS
      ****************************************************************
       COPY CCWE0661.
557756*COPY CCWTYSNO.
557756 COPY XCWL2510.
014221 COPY CCWWLOCK.
       COPY XCWWWKDT.
030054 COPY XCWWCNST.
      *
      ****************************************************************
      * I/O COPYBOOKS
      ****************************************************************
       COPY CCFHPOL.
       COPY CCFWPOL.
      *
       COPY CCFRCVG.
       COPY CCFWCVG.

023436 COPY CCFRPHST.
023436 COPY CCFWPHST.
      *
      ****************************************************************
      * CALLED MODULE PARAMETER INFORMATION
      ****************************************************************
020478 COPY CCWL2626.
016503 COPY CCWL0201.
016503 COPY CCWL0289.
       COPY CCWL0361.
013578 COPY CCWL0620.
016108 COPY CCWL0985.
557665*COPY CCWL1060.
       COPY CCWL1070.
       COPY CCWL1080.
       COPY CCWL1210.
      *
       COPY CCWL1220.
       COPY CCWL1230.
       COPY CCWL1240.
       COPY CCWL1350.
      *
       COPY CCWL1360.
       COPY CCWL1400.
       COPY CCWL2210.
       COPY CCWL2220.
      *
       COPY CCWL2430.
020463 COPY CCWL2735.
       COPY CCWL4750.
016503 COPY CCWL4780.
       COPY CCWL5400.
       COPY CCWL7000.
      *
       COPY XCWLDTLK.
       COPY XCWL0280.
008455 COPY XCWL0290.
       COPY XCWL1640.
023436 COPY XCWL1660.
       COPY XCWL1670.
       COPY XCWL1680.
      *
      ****************************************************************
      * INPUT PARAMETER INFORMATION
      ****************************************************************
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.

       COPY CCFRPOL.

       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0661.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *---------------
       0000-MAINLINE.
      *---------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.


           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *
      *---------------
       2000-PROCESS-REQUEST.
      *---------------
      **********************************************************
      * CHECK SECURITY PERMISSION AND EDIT KEY FIELDS
      * DISTRIBUTE CONTROL TO APPROPRIATE PROCESSING ROUTINE
      **********************************************************

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
018633*    MOVE SPACES                TO WS-WORK-AREA.


013578     IF NOT (WS-BUS-FCN-REDUCED-PAID-UP
013578        OR   WS-BUS-FCN-EXTENDED-TERM)
020874*       COMPUTE L0290-INPUT-NUMBER =  ZERO
020874        MOVE ZERO                     TO L0290-INPUT-V02
013578        MOVE 2                        TO L0290-PRECISION
013578        MOVE LENGTH OF MIR-CVG-FACE-AMT  TO L0290-MAX-OUT-LEN
020874*       PERFORM 0290-1000-NUMERIC-FORMAT
020874*          THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
013578        MOVE L0290-OUTPUT-DATA        TO MIR-CVG-FACE-AMT
013578     END-IF.


           PERFORM  2100-VALIDATE-KEY-FIELDS
               THRU 2100-VALIDATE-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
014221     OR  MIR-RETRN-TS-MISMATCH
               GO TO 2000-PROCESS-REQUEST-X
           ELSE
               PERFORM  2200-KEY-FIELD-XEDIT
                   THRU 2200-KEY-FIELD-XEDIT-X
               IF  WGLOB-MSG-ERROR-SW > ZERO
                   GO TO 2000-PROCESS-REQUEST-X
               END-IF
           END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           MOVE E0661-COV-NO          TO W0661-SUB.

           IF  E0661-COV-NO = ZERO
               SET PROCESSING-POLICY   TO TRUE
           ELSE
               SET PROCESSING-COVERAGE TO TRUE
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-ANNIVERSARY
                   PERFORM  3210-ANNIVERSARY
                       THRU 3210-ANNIVERSARY-X

               WHEN WS-BUS-FCN-APL
                   PERFORM  3220-PAY-PREM-BY-APL
                       THRU 3220-PAY-PREM-BY-APL-X

               WHEN WS-BUS-FCN-APL-REVERSAL
                   PERFORM  3225-REVERSE-APL
                       THRU 3225-REVERSE-APL-X

557665*        WHEN E0661-AUTO-PREM
557665*            PERFORM  3230-PAY-PREM-BY-AUTO
557665*                THRU 3230-PAY-PREM-BY-AUTO-X

               WHEN WS-BUS-FCN-PUT-ON-WAIVER
                   PERFORM  3240-PUT-ON-WAIVER
                       THRU 3240-PUT-ON-WAIVER-X

               WHEN WS-BUS-FCN-TAKE-OFF-WAIVER
                   PERFORM  3250-TAKE-OFF-WAIVER
                       THRU 3250-TAKE-OFF-WAIVER-X

               WHEN WS-BUS-FCN-MAKE-PAID-UP
                   PERFORM  3260-MAKE-PAID-UP
                       THRU 3260-MAKE-PAID-UP-X

               WHEN WS-BUS-FCN-RPU-QUOTE
                   PERFORM  3270-RPU-QUOTE
                       THRU 3270-RPU-QUOTE-X

               WHEN WS-BUS-FCN-REDUCED-PAID-UP
                   PERFORM  3280-REDUCED-PAID-UP
                       THRU 3280-REDUCED-PAID-UP-X

               WHEN WS-BUS-FCN-RPU-REVERSAL
                   PERFORM  3290-REVERSE-RPU
                       THRU 3290-REVERSE-RPU-X

               WHEN WS-BUS-FCN-ETI-QUOTE
                   PERFORM  3300-ETI-QUOTE
                       THRU 3300-ETI-QUOTE-X

               WHEN WS-BUS-FCN-EXTENDED-TERM
                   PERFORM  3310-EXTENDED-TERM
                       THRU 3310-EXTENDED-TERM-X

               WHEN WS-BUS-FCN-ETI-REVERSAL
                   PERFORM  3320-REVERSE-ETI
                       THRU 3320-REVERSE-ETI-X

               WHEN WS-BUS-FCN-DEEMED-DISPOS
                   PERFORM  3330-DEEMED-DISP
                       THRU 3330-DEEMED-DISP-X

               WHEN WS-BUS-FCN-AUTO-PREM-PYMT
                   PERFORM  3340-AUTO-PREM-PYMT
                       THRU 3340-AUTO-PREM-PYMT-X

               WHEN WS-BUS-FCN-IMMED-ANN-PYMT
                   PERFORM  3350-IMM-ANN-PYMT
                       THRU 3350-IMM-ANN-PYMT-X

               WHEN WS-BUS-FCN-IAP-REVERSAL
                   PERFORM  3360-REVERSE-IA-PYMT
                       THRU 3360-REVERSE-IA-PYMT-X

               WHEN WS-BUS-FCN-RRIF-PYMT
                   PERFORM  3370-RRIF-PAYMENT
                       THRU 3370-RRIF-PAYMENT-X

               WHEN WS-BUS-FCN-RRIF-PYMT-REVERSAL
                   PERFORM  3380-REV-RRIF-PYMT
                       THRU 3380-REV-RRIF-PYMT-X

               WHEN WS-BUS-FCN-RESET
                   PERFORM  3390-YEAR-END-RESET
                       THRU 3390-YEAR-END-RESET-X

023436         WHEN WS-BUS-FCN-ANNIVERSARY-REVRS
023436             PERFORM  3400-ANNIVERSARY-REVRS
023436                 THRU 3400-ANNIVERSARY-REVRS-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0661'
                                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *---------------
       2100-VALIDATE-KEY-FIELDS.
      *---------------


           PERFORM  7000-READ-POLICY
               THRU 7000-READ-POLICY-X.

014221     IF  MIR-RETRN-TS-MISMATCH
029590     OR  WGLOB-MSG-ERROR-SW > ZERO
014221         GO TO 2100-VALIDATE-KEY-FIELDS-X
014221     END-IF.

           PERFORM  7100-VALIDATE-CVG
               THRU 7100-VALIDATE-CVG-X.

           PERFORM  7200-EDIT-NAME
               THRU 7200-EDIT-NAME-X.

           PERFORM  7300-VALIDATE-SUBCODE
               THRU 7300-VALIDATE-SUBCODE-X.

           PERFORM  7400-VALIDATE-DATE
               THRU 7400-VALIDATE-DATE-X.

           PERFORM  7500-VALIDATE-AMOUNT
               THRU 7500-VALIDATE-AMOUNT-X.

           PERFORM  7600-VALIDATE-EFF-DT
               THRU 7600-VALIDATE-EFF-DT-X.

012137     PERFORM  7700-VALIDATE-SUPCNF
012137         THRU 7700-VALIDATE-SUPCNF-X.

016108     PERFORM  7800-VAL-DATE-OF-DTH
016108         THRU 7800-VAL-DATE-OF-DTH-X.

       2100-VALIDATE-KEY-FIELDS-X.
           EXIT.
      *
      *---------------
       2200-KEY-FIELD-XEDIT.
      *---------------

           IF  RPOL-POL-CVG-REC-CTR-N < E0661-COV-NO
      * MSG: COVERAGE NUMBER MUST EXIST. RE-ENTER
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
013578*
013578*  NAME ENTERED MUST MATCH POLICY OWNERS NAME
013578*
013578*    MOVE E0661-COV-NO          TO I.
013578*    PERFORM  2430-1000-BUILD-PARM-INFO
013578*        THRU 2430-1000-BUILD-PARM-INFO-X
013578*    MOVE E0661-OWNER-NAME      TO L2430-OWNER-NAME-1-4.
013578*    PERFORM  2430-5000-VALIDATE-OWNER-NM
013578*        THRU 2430-5000-VALIDATE-OWNER-NM-X.
013578*    IF  L2430-RETRN-OWNER-NM-MISMATCH
013578*MSG: NAME ENTERED DOES NOT MATCH OWNER LAST NAME
013578*        MOVE 'CS06610008'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    ELSE
013578*        MOVE MIR-DV-CLI-NM     TO E0661-OWNER-NAME
013578*    END-IF.

           IF  E0661-EFF-DATE < RPOL-POL-ISS-EFF-DT
      *MSG: TRANS EFF DT CANNOT BE PRIOR TO ISSUE DT
               MOVE 'CS06610012'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

026740     IF  WS-BUS-FCN-ETI-QUOTE
026740         PERFORM  2210-CHECK-XPRY-ETI
026740             THRU 2210-CHECK-XPRY-ETI-X
026740     END-IF.

       2200-KEY-FIELD-XEDIT-X.
           EXIT.
026740/
026740*-----------------------
026740 2210-CHECK-XPRY-ETI.
026740*-----------------------
026740
026740     IF  E0661-COV-X = '00'
026740         PERFORM
026740           VARYING WS-CVG FROM +1 BY +1
026740           UNTIL WS-CVG > RPOL-POL-CVG-REC-CTR-N
026740               IF  WCVGS-CVG-MAT-XPRY-DT (WS-CVG)
026740                                      <= E0661-EFF-DATE
026740* MSG: THE EFFECTIVE DATE IS GREATER THAN THE COVERAGE (@1)
026740*      MATURITY EXPIRY DATE
026740                   MOVE 'CS06614216'      TO WGLOB-MSG-REF-INFO
026740                   MOVE WCVGS-CVG-SEQ-NUM (WS-CVG)
026740                                          TO WGLOB-MSG-PARM (1)
026740                   PERFORM  0260-1000-GENERATE-MESSAGE
026740                       THRU 0260-1000-GENERATE-MESSAGE-X
026740                   SET WGLOB-RETURN-ERROR TO TRUE
026740               END-IF
026740         END-PERFORM
026740     ELSE
026740         IF  WCVGS-CVG-MAT-XPRY-DT (E0661-COV-NO)
026740                                      <= E0661-EFF-DATE
026740* MSG: THE EFFECTIVE DATE IS GREATER THAN THE COVERAGE (@1)
026740*      MATURITY EXPIRY DATE
026740             MOVE 'CS06614216'      TO WGLOB-MSG-REF-INFO
026740             MOVE WCVGS-CVG-SEQ-NUM (E0661-COV-NO)
026740                                    TO WGLOB-MSG-PARM (1)
026740             PERFORM  0260-1000-GENERATE-MESSAGE
026740                 THRU 0260-1000-GENERATE-MESSAGE-X
026740             SET WGLOB-RETURN-ERROR TO TRUE
026740         END-IF
026740     END-IF.
026740
026740 2210-CHECK-XPRY-ETI-X.
026740     EXIT.
026740/
      *
      *---------------
       3210-ANNIVERSARY.
      *---------------
      *
      * ANNIVERSARY PROCESSING AT THE COVERAGE LEVEL
      * NOT SUPPORTED
      *
           IF  PROCESSING-COVERAGE
               MOVE 'CS06613211'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3210-ANNIVERSARY-X
           END-IF.

           PERFORM  1400-1000-BUILD-PARM-INFO
               THRU 1400-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ISS-EFF-DT   TO L1680-INTERNAL-1.
           MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
           MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
           COMPUTE L1680-NUMBER-OF-YEARS =
                   RPOL-POL-PREV-ANNV-DUR-N + 1.
           PERFORM 1680-3000-ADD-Y-M-D-TO-DATE
              THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
           MOVE L1680-INTERNAL-2      TO L1400-EFF-DT.
           MOVE L1680-INTERNAL-2      TO E0661-EFF-DATE.


018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

018633*    MOVE L1680-INTERNAL-2      TO WS-INTERNAL-DT.
018633     MOVE L1680-INTERNAL-2      TO LCOMM-INTERNAL-DT.
018633*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM 9800-WRITE-TWRK
018633*       THRU 9800-WRITE-TWRK-X.
018633     PERFORM COMM-2000-WRITE-TWRK
018633        THRU COMM-2000-WRITE-TWRK-X.

013578*    MOVE E0661-OWNER-NAME      TO L1400-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3212-ANNIV-2
                       THRU 3212-ANNIV-2-X

               WHEN OTHER
                   PERFORM  3211-ANNIV-1
                       THRU 3211-ANNIV-1-X


           END-EVALUATE.

       3210-ANNIVERSARY-X.
           EXIT.

      *---------------
       3211-ANNIV-1.
      *---------------

           SET L1400-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1400-REDO-WARNING        TO TRUE.

           PERFORM  1400-1000-ANNIVERSARY-PRCES
               THRU 1400-1000-ANNIVERSARY-PRCES-X.

           IF  NOT L1400-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3211-ANNIV-1-X
           END-IF.

      *MSG: 'YOU ARE PUTTING THIS POLICY THRU ANNIVERSARY PROCESSING
           MOVE 'CS06612202'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3211-ANNIV-1-X.
           EXIT.

      *---------------
       3212-ANNIV-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
              GO TO 3212-ANNIV-2-X
           END-IF.

           SET L1400-PRCES-TYP-ALL TO TRUE.
016503     SET L1400-REDO-WARNING        TO TRUE.
           PERFORM  1400-1000-ANNIVERSARY-PRCES
               THRU 1400-1000-ANNIVERSARY-PRCES-X.

           IF  NOT L1400-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3212-ANNIV-2-X.
           EXIT.

      *---------------
       3220-PAY-PREM-BY-APL.
      *---------------

557697     IF RPOL-POL-SFB-CD NOT = SPACE
557697*MSG: POLICY MUST BE CHANGED FROM SPECIAL FREQ. BEFORE APL
557697        MOVE 'CS06610013'       TO WGLOB-MSG-REF-INFO
557697        PERFORM 0260-1000-GENERATE-MESSAGE
557697           THRU 0260-1000-GENERATE-MESSAGE-X
557697           GO TO 3220-PAY-PREM-BY-APL-X
557697     END-IF.

           PERFORM  1070-1000-BUILD-PARM-INFO
               THRU 1070-1000-BUILD-PARM-INFO-X.


           MOVE E0661-EFF-DATE        TO L1070-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1070-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3222-APL-2
                       THRU 3222-APL-2-X

               WHEN OTHER
                   PERFORM  3221-APL-1
                       THRU 3221-APL-1-X


           END-EVALUATE.

       3220-PAY-PREM-BY-APL-X.
           EXIT.

      *---------------
       3221-APL-1.
      *---------------

           SET L1070-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1070-REDO-WARNING        TO TRUE.

           PERFORM  1070-1000-APL-PROCESSING
               THRU 1070-1000-APL-PROCESSING-X.

           IF  NOT L1070-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3221-APL-1-X
           END-IF.

      *MSG: YOU ARE TAKING OUT AN APL ON THIS POLICY @1
           MOVE 'CS06612203'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.


018633*    MOVE L1070-EDIT-EFF-DT     TO WS-INTERNAL-DT.
018633     MOVE L1070-EDIT-EFF-DT     TO LCOMM-INTERNAL-DT.
018633*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM 9800-WRITE-TWRK
018633*       THRU 9800-WRITE-TWRK-X.
018633     PERFORM COMM-2000-WRITE-TWRK
018633        THRU COMM-2000-WRITE-TWRK-X.


       3221-APL-1-X.
           EXIT.

      *---------------
       3222-APL-2.
      *---------------


018633*    PERFORM 9700-RETRIEVE-TWRK
018633*       THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM COMM-1000-RETRIEVE-TWRK
018633        THRU COMM-1000-RETRIEVE-TWRK-X.
018633
018633*    IF L8090-RETRN-OK
018633*       MOVE L8090-AREA-INFO-TEXT TO WS-WORK-AREA
018633*    END-IF.
018633*
018633*    IF WS-INTERNAL-DT NOT = E0661-EFF-DATE
018633*        MOVE WS-INTERNAL-DT TO E0661-EFF-DATE
018633     IF LCOMM-INTERNAL-DT NOT = E0661-EFF-DATE
018633         MOVE LCOMM-INTERNAL-DT TO E0661-EFF-DATE
           END-IF.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3222-APL-2-X
           END-IF.

           SET L1070-PRCES-TYP-ALL TO TRUE.
016503     SET L1070-REDO-WARNING  TO TRUE.

           PERFORM  1070-1000-APL-PROCESSING
               THRU 1070-1000-APL-PROCESSING-X.

           IF  NOT L1070-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3222-APL-2-X.
           EXIT.

      *---------------
       3225-REVERSE-APL.
      *---------------

           PERFORM  1070-1000-BUILD-PARM-INFO
               THRU 1070-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L1070-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1070-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3227-REV-APL-2
                       THRU 3227-REV-APL-2-X

               WHEN OTHER
                   PERFORM  3226-REV-APL-1
                       THRU 3226-REV-APL-1-X


           END-EVALUATE.

       3225-REVERSE-APL-X.
           EXIT.

      *---------------
       3226-REV-APL-1.
      *---------------

           SET L1070-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1070-REDO-WARNING        TO TRUE.

           PERFORM  1070-2000-APL-REVERSAL
               THRU 1070-2000-APL-REVERSAL-X.

           IF  NOT L1070-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3226-REV-APL-1-X
           END-IF.

      *MSG: YOU ARE REVERSING AN APL PAYMENT ON THIS POLICY @1
           MOVE 'CS06610019'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3226-REV-APL-1-X.
           EXIT.

      *---------------
       3227-REV-APL-2.
      *---------------

023436     SET WS-PHST-ACTV-APL       TO TRUE.
023436     PERFORM  4600-LOCATE-PHST
023436         THRU 4600-LOCATE-PHST-X.
023436
023436     IF  WGLOB-RETURN-ERROR
023436         GO TO 3227-REV-APL-2-X
023436     END-IF.
023436
023436     PERFORM  4700-UNDO-ON-REVERSAL
023436         THRU 4700-UNDO-ON-REVERSAL-X.
023436
023436     IF  WGLOB-RETURN-ERROR
023436         GO TO 3227-REV-APL-2-X
023436     END-IF.

023436*    PERFORM  4000-START-PROCESS
023436*        THRU 4000-START-PROCESS-X.
023436*
023436*    IF  NOT WGLOB-GOOD-RETURN
023436*    OR  WS-REDO-NOT-OK
023436*        GO TO 3227-REV-APL-2-X
023436*    END-IF.
023436*
023436*    SET L1070-PRCES-TYP-ALL TO TRUE.
023436*    SET L1070-REDO-WARNING  TO TRUE.
023436*    PERFORM  1070-2000-APL-REVERSAL
023436*        THRU 1070-2000-APL-REVERSAL-X.
023436*
023436*    IF  NOT L1070-RETRN-OK
023436*        SET WGLOB-RETURN-ERROR TO TRUE
023436*    END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3227-REV-APL-2-X.
           EXIT.

557665*---------------
557665*3230-PAY-PREM-BY-AUTO.
557665*---------------
557665*
557665*    PERFORM  1060-1000-BUILD-PARM-INFO
557665*        THRU 1060-1000-BUILD-PARM-INFO-X.
557665*
557665*    MOVE E0661-EFF-DATE      TO L1060-EFF-DT.
557665*
557665*    EVALUATE TRUE
557665*
557665*        WHEN MIR-FORCE = '1'
557665*            PERFORM  3231-APM-1
557665*                THRU 3231-APM-1-X
557665*
557665*        WHEN MIR-FORCE = '2'
557665*            PERFORM  3232-APM-2
557665*                THRU 3232-APM-2-X
557665*
557665*    END-EVALUATE.
557665*
557665*3230-PAY-PREM-BY-AUTO-X.
557665*    EXIT.

557665*---------------
557665*3231-APM-1.
557665*---------------
557665*
557665*    SET L1060-PRCES-TYP-EDIT-ONLY TO TRUE.
557665*
557665*    PERFORM  1060-1000-AUTO-MTHD-PMT
557665*        THRU 1060-1000-AUTO-MTHD-PMT-X.
557665*
557665*    IF  NOT L1060-RETRN-OK
557665*       SET WGLOB-RETURN-ERROR TO TRUE
557665*        GO TO 3231-APM-1-X
557665*    END-IF.
557665*
557665*MSG: 'YOU ARE FORCING A PREMIUM TO BE PAID BY WAIVER OR PDF'
557665*    MOVE 'CS06612204' TO WGLOB-MSG-REF-INFO.
557665*    PERFORM  3500-VERIFY-TRAN
557665*        THRU 3500-VERIFY-TRAN-X.
557665*
557665*    MOVE L1060-EDIT-EFF-DT      TO C0661-INTERNAL-DT.
557665*
557665*3231-APM-1-X.
557665*    EXIT.
557665*
557665*---------------
557665*3232-APM-2.
557665*---------------
557665*
557665*    MOVE C0661-INTERNAL-DT TO L1060-EFF-DT.
557665*    MOVE C0661-INTERNAL-DT TO E0661-EFF-DATE.
557665*
557665*    PERFORM  4000-START-PROCESS
557665*        THRU 4000-START-PROCESS-X.
557665*
557665*    IF  NOT WGLOB-GOOD-RETURN
557665*        GO TO 3232-APM-2-X
557665*    END-IF.
557665*
557665*    SET L1060-PRCES-TYP-ALL TO TRUE.
557665*
557665*    PERFORM  1060-1000-AUTO-MTHD-PMT
557665*        THRU 1060-1000-AUTO-MTHD-PMT-X.
557665*
557665*    IF  NOT L1060-RETRN-OK
557665*       SET WGLOB-RETURN-ERROR TO TRUE
557665*    END-IF.
557665*
557665*    PERFORM  4500-END-PROCESS
557665*        THRU 4500-END-PROCESS-X.
557665*
557665*3232-APM-2-X.
557665*    EXIT.

      *---------------
       3240-PUT-ON-WAIVER.
      *---------------

557697     IF RPOL-POL-SFB-CD NOT = SPACE
557697* MSG: POLICY MUST BE CHANGED FROM SPECIAL FREQUENCY BEFORE WAIVER
557697        MOVE 'CS06610014'       TO WGLOB-MSG-REF-INFO
557697        PERFORM 0260-1000-GENERATE-MESSAGE
557697           THRU 0260-1000-GENERATE-MESSAGE-X
557697        GO TO 3240-PUT-ON-WAIVER-X
557697     END-IF.

           PERFORM  1240-1000-BUILD-PARM-INFO
               THRU 1240-1000-BUILD-PARM-INFO-X.

           MOVE E0661-COV-NO          TO L1240-CVG-NUM.
           MOVE E0661-EFF-DATE        TO L1240-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1240-CLI-SUR-NM-1-4.
           MOVE E0661-SUB-CODE        TO L1240-SUB-CODE.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3242-WVR-2
                       THRU 3242-WVR-2-X

               WHEN OTHER
                   PERFORM  3241-WVR-1
                       THRU 3241-WVR-1-X


           END-EVALUATE.

       3240-PUT-ON-WAIVER-X.
           EXIT.

      *---------------
       3241-WVR-1.
      *---------------

           SET L1240-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1240-REDO-WARNING        TO TRUE.

           IF  PROCESSING-POLICY
               PERFORM  1240-1000-POW-POL
                   THRU 1240-1000-POW-POL-X
           ELSE
               IF  PROCESSING-COVERAGE
                   PERFORM  1240-2000-POW-CVG
                       THRU 1240-2000-POW-CVG-X
               END-IF
           END-IF.

           IF  NOT L1240-RETRN-OK
              SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3241-WVR-1-X
           END-IF.

           IF  PROCESSING-POLICY
      *MSG: YOU ARE PUTTING THIS POLCY ON WAIVER @1
               MOVE 'CS06612205'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG: YOU ARE PUTTING THIS COVERAGE ON WAIVER @1
               MOVE 'CS06612206'      TO WGLOB-MSG-REF-INFO
           END-IF.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3241-WVR-1-X.
           EXIT.


      *---------------
       3242-WVR-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3242-WVR-2-X
           END-IF.

           SET L1240-PRCES-TYP-ALL TO TRUE.
016503     SET L1240-REDO-WARNING  TO TRUE.

           EVALUATE TRUE

               WHEN PROCESSING-POLICY
                    PERFORM  1240-1000-POW-POL
                        THRU 1240-1000-POW-POL-X

               WHEN PROCESSING-COVERAGE
                    PERFORM  1240-2000-POW-CVG
                        THRU 1240-2000-POW-CVG-X

           END-EVALUATE.

           IF  NOT L1240-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3242-WVR-2-X.
           EXIT.

      *---------------
       3250-TAKE-OFF-WAIVER.
      *---------------

           PERFORM  1240-1000-BUILD-PARM-INFO
               THRU 1240-1000-BUILD-PARM-INFO-X.

           MOVE E0661-COV-NO          TO L1240-CVG-NUM.
           MOVE E0661-EFF-DATE        TO L1240-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1240-CLI-SUR-NM-1-4.
           MOVE E0661-SUB-CODE        TO L1240-SUB-CODE.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3252-OFF-WVR-2
                       THRU 3252-OFF-WVR-2-X

               WHEN OTHER
                   PERFORM  3251-OFF-WVR-1
                       THRU 3251-OFF-WVR-1-X


           END-EVALUATE.

       3250-TAKE-OFF-WAIVER-X.
           EXIT.

      *---------------
       3251-OFF-WVR-1.
      *---------------

           SET L1240-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1240-REDO-WARNING        TO TRUE.

           IF  PROCESSING-POLICY
               PERFORM  1240-3000-TOW-POL
                   THRU 1240-3000-TOW-POL-X
           ELSE
               IF  PROCESSING-COVERAGE
                   PERFORM  1240-4000-TOW-CVG
                      THRU  1240-4000-TOW-CVG-X
               END-IF
           END-IF.

           IF  NOT L1240-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3251-OFF-WVR-1-X
           END-IF.

           IF  PROCESSING-POLICY
      *MSG: 'YOU ARE TAKING THIS POLICY OFF WAIVER @1'
               MOVE 'CS06612207'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG: 'YOU ARE TAKING THIS COVERAGE OFF WAIVER'
               MOVE 'CS06612208'      TO WGLOB-MSG-REF-INFO
           END-IF.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.
           PERFORM  3600-STAT-CHG-MESSAGE
               THRU 3600-STAT-CHG-MESSAGE-X.

       3251-OFF-WVR-1-X.
           EXIT.

      *---------------
       3252-OFF-WVR-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3252-OFF-WVR-2-X
           END-IF.

           SET L1240-PRCES-TYP-ALL TO TRUE.
016503     SET L1240-REDO-WARNING  TO TRUE.

           EVALUATE TRUE

               WHEN PROCESSING-POLICY
                    PERFORM  1240-3000-TOW-POL
                        THRU 1240-3000-TOW-POL-X

               WHEN PROCESSING-COVERAGE
                    PERFORM  1240-4000-TOW-CVG
                        THRU 1240-4000-TOW-CVG-X

           END-EVALUATE.

           IF  NOT L1240-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3252-OFF-WVR-2-X.
           EXIT.

      *---------------
       3260-MAKE-PAID-UP.
      *---------------

557697     IF RPOL-POL-SFB-CD NOT = SPACE
557697* MSG: POLICY MUST BE CHANGED FROM SPECIAL FREQUENCY BEFORE MAKING
557697*      PAID UP
557697        MOVE 'CS06610015'       TO WGLOB-MSG-REF-INFO
557697        PERFORM 0260-1000-GENERATE-MESSAGE
557697           THRU 0260-1000-GENERATE-MESSAGE-X
557697        GO TO 3260-MAKE-PAID-UP-X
557697     END-IF.

           PERFORM  1230-1000-BUILD-PARM-INFO
               THRU 1230-1000-BUILD-PARM-INFO-X.

           MOVE E0661-COV-NO          TO L1230-CVG-NUM.
           MOVE E0661-EFF-DATE        TO L1230-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1230-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3262-PAID-UP-2
                       THRU 3262-PAID-UP-2-X

               WHEN OTHER
                   PERFORM  3261-PAID-UP-1
                       THRU 3261-PAID-UP-1-X


           END-EVALUATE.

       3260-MAKE-PAID-UP-X.
           EXIT.

      *---------------
       3261-PAID-UP-1.
      *---------------

           SET L1230-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1230-REDO-WARNING        TO TRUE.

           IF  PROCESSING-POLICY
               PERFORM  1230-1000-PAID-UP-POL
                   THRU 1230-1000-PAID-UP-POL-X
           ELSE
                IF  PROCESSING-COVERAGE
                    PERFORM  1230-2000-PAID-UP-CVG
                        THRU 1230-2000-PAID-UP-CVG-X
                END-IF
           END-IF.

           IF  NOT L1230-RETRN-OK
020572     OR  L1230-EDIT-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3261-PAID-UP-1-X
           END-IF.

           IF  PROCESSING-POLICY
      *MSG: 'YOU ARE MAKING THIS POLICY PAID UP @1'
               MOVE 'CS06612209'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG: 'YOU ARE MAKING THIS COVERAGE PAID UP @1'
               MOVE 'CS06612210'      TO WGLOB-MSG-REF-INFO
           END-IF.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3261-PAID-UP-1-X.
           EXIT.

      *---------------
       3262-PAID-UP-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3262-PAID-UP-2-X
           END-IF.

           SET L1230-PRCES-TYP-ALL TO TRUE.
016503     SET L1230-REDO-WARNING  TO TRUE.

           EVALUATE TRUE

               WHEN PROCESSING-POLICY
                    PERFORM  1230-1000-PAID-UP-POL
                        THRU 1230-1000-PAID-UP-POL-X

               WHEN PROCESSING-COVERAGE
                    PERFORM  1230-2000-PAID-UP-CVG
                        THRU 1230-2000-PAID-UP-CVG-X

           END-EVALUATE.

           IF  NOT L1230-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3262-PAID-UP-2-X.
           EXIT.

      *---------------
       3270-RPU-QUOTE.
      *---------------

005409     MOVE RPOL-POL-PD-TO-DT-NUM TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.

005409     IF E0661-EFF-DATE NOT = L1680-INTERNAL-2
005409*    IF E0661-EFF-DATE NOT = RPOL-POL-PD-TO-DT-NUM
550567* MSG: EFFECTIVE DATE NOT EQUAL TO PAID TO DATE
550567         MOVE 'CS06610026'      TO WGLOB-MSG-REF-INFO
550567         PERFORM  0260-1000-GENERATE-MESSAGE
550567             THRU 0260-1000-GENERATE-MESSAGE-X
550567         SET WGLOB-RETURN-ERROR TO TRUE
550567         GO TO 3270-RPU-QUOTE-X
550567     END-IF.

           PERFORM  2210-1000-BUILD-PARM-INFO
               THRU 2210-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L2210-EFF-DT.
           MOVE E0661-COV-NO          TO L2210-CVG-NUM.

           SET L1070-PRCES-TYP-ALL TO TRUE.
016503     SET L2210-REDO-WARNING  TO TRUE.

           IF  PROCESSING-COVERAGE
              SET L2210-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  2210-1000-RPU-QUOTE
               THRU 2210-1000-RPU-QUOTE-X.

           IF  NOT L2210-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
      *MSG: RPU QT PROCESSING NOT COMPLETED
               MOVE 'CS06614210'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3270-RPU-QUOTE-X
           END-IF.

008455*    MOVE L2210-RPU-FACE-AMT TO EDIT-9V2.
008455*    MOVE EDIT-9V2           TO MIR-CVG-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L2210-RPU-FACE-AMT * 100.
020874     MOVE  L2210-RPU-FACE-AMT TO L0290-INPUT-V02.
008455     PERFORM  9600-FORMAT-FACE
008455         THRU 9600-FORMAT-FACE-X.
      *MSG: 'RPU FACE AMOUNT CALCULATED SHOWN ABOVE'
           MOVE 'CS06614081'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
028760*MSG: 'CHANGE CODE TO RPU IF  YOU WISH TO MAKE POLICY RPU'
028760*    MOVE 'CS06614082'          TO WGLOB-MSG-REF-INFO.
028760*    PERFORM  0260-1000-GENERATE-MESSAGE
028760*        THRU 0260-1000-GENERATE-MESSAGE-X.

       3270-RPU-QUOTE-X.
           EXIT.

      *---------------------
       3280-REDUCED-PAID-UP.
      *---------------------

557697     IF RPOL-POL-SFB-CD NOT = SPACE
557697* MSG: POLICY MUST BE CHANGED FROM SPECIAL FREQUENCY BEFORE MAKING
557697*      RPU
557697        MOVE 'CS06610016'       TO WGLOB-MSG-REF-INFO
557697        PERFORM 0260-1000-GENERATE-MESSAGE
557697           THRU 0260-1000-GENERATE-MESSAGE-X
557697        GO TO 3280-REDUCED-PAID-UP-X
557697     END-IF.

005409     MOVE RPOL-POL-PD-TO-DT-NUM TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.

005409     IF E0661-EFF-DATE NOT = L1680-INTERNAL-2
005409*    IF E0661-EFF-DATE NOT = RPOL-POL-PD-TO-DT-NUM
550567* MSG: EFFECTIVE DATE NOT EQUAL TO PAID TO DATE
550567         MOVE 'CS06610026'      TO WGLOB-MSG-REF-INFO
550567         PERFORM  0260-1000-GENERATE-MESSAGE
550567             THRU 0260-1000-GENERATE-MESSAGE-X
550567         SET WGLOB-RETURN-ERROR TO TRUE
550567         GO TO 3280-REDUCED-PAID-UP-X
550567     END-IF.

           PERFORM  1210-1000-BUILD-PARM-INFO
               THRU 1210-1000-BUILD-PARM-INFO-X.

           MOVE E0661-FACE-AMT        TO L1210-RPU-FACE-AMT.
           MOVE E0661-EFF-DATE        TO L1210-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1210-CLI-SUR-NM-1-4.
           MOVE E0661-COV-NO          TO L1210-CVG-NUM.
           MOVE MIR-DV-CHQ-CREAT-IND  TO L1210-RPU-CHEQUE-IND.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3282-RPU-2
                       THRU 3282-RPU-2-X

               WHEN OTHER
                   PERFORM  3281-RPU-1
                       THRU 3281-RPU-1-X


           END-EVALUATE.

       3280-REDUCED-PAID-UP-X.
           EXIT.

      *---------------
       3281-RPU-1.
      *---------------

           SET L1210-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1210-REDO-WARNING        TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L1210-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  1210-1000-MAKE-RPU
               THRU 1210-1000-MAKE-RPU-X.

           IF  NOT L1210-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3281-RPU-1-X
           END-IF.

           IF  RPOL-POL-PREM-SUSP-AMT GREATER THAN ZERO
           OR RPOL-POL-MISC-SUSP-AMT GREATER THAN ZERO
013578*        MOVE 'CS06610025'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-2000-GET-MESSAGE
013578*            THRU 0260-2000-GET-MESSAGE-X
013578*        MOVE WGLOB-MSG-TXT     TO MIR-CHQMSG
557756*        MOVE TYSNO-YES-NO-SHORT (WGLOB-LANG-SUB, 2)
557756*                                         TO MIR-DV-CHQ-CREAT-IND
557756         PERFORM 2510-1000-BUILD-PARM-INFO
557756            THRU 2510-1000-BUILD-PARM-INFO-X
557756         SET L2510-VALUE-LENGTH-SHORT TO TRUE
557756         SET L2510-RESPONSE-NO        TO TRUE
557756         PERFORM 2510-2000-SINGLE-VALUE
557756            THRU 2510-2000-SINGLE-VALUE-X
557756         MOVE L2510-RESPONSE-TXT           TO MIR-DV-CHQ-CREAT-IND
           END-IF.

      *MSG: YOU ARE MAKING THIS POLICY RPU @1
           MOVE 'CS06612212'          TO WGLOB-MSG-REF-INFO.

           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3281-RPU-1-X.
           EXIT.

      *---------------
       3282-RPU-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3282-RPU-2-X
           END-IF.

           SET L1210-PRCES-TYP-ALL TO TRUE.
016503     SET L1210-REDO-WARNING  TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L1210-CVG-PASSED TO TRUE
           END-IF.

           IF MIR-DV-CHQ-CREAT-IND = 'Y'
               SET L1210-RPU-CHEQUE-YES TO TRUE
           END-IF.

           PERFORM  1210-1000-MAKE-RPU
               THRU 1210-1000-MAKE-RPU-X.

           IF  NOT L1210-RETRN-OK
                SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
              THRU  4500-END-PROCESS-X.

       3282-RPU-2-X.
           EXIT.

      *---------------
       3290-REVERSE-RPU.
      *---------------

           PERFORM  1210-1000-BUILD-PARM-INFO
               THRU 1210-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L1210-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1210-CLI-SUR-NM-1-4.
           MOVE E0661-COV-NO          TO L1210-CVG-NUM.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3292-REV-RPU-2
                       THRU 3292-REV-RPU-2-X

               WHEN OTHER
                   PERFORM  3291-REV-RPU-1
                       THRU 3291-REV-RPU-1-X


           END-EVALUATE.

       3290-REVERSE-RPU-X.
           EXIT.

      *---------------
       3291-REV-RPU-1.
      *---------------

           SET L1210-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1210-REDO-WARNING        TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L1210-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  1210-2000-REVRS-RPU
               THRU 1210-2000-REVRS-RPU-X.

           IF  NOT L1210-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3291-REV-RPU-1-X
           END-IF.

      *MSG: YOU ARE REINSTATING THIS POLICY FROM REDUCED PAID UP @1
           MOVE 'CS06612213'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

           PERFORM  3600-STAT-CHG-MESSAGE
               THRU 3600-STAT-CHG-MESSAGE-X.

       3291-REV-RPU-1-X.
           EXIT.

      *---------------
       3292-REV-RPU-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3292-REV-RPU-2-X
           END-IF.

           SET L1210-PRCES-TYP-ALL TO TRUE.
016503     SET L1210-REDO-WARNING  TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L1210-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  1210-2000-REVRS-RPU
               THRU 1210-2000-REVRS-RPU-X.

           IF  NOT L1210-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
      *MSG:    REVERSAL RPU PROCESSING NOT COMPLETED
               MOVE 'CS06614212'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG:    REINSTATED FROM REDUCED PAID UP'
               MOVE 'CS06614101'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3292-REV-RPU-2-X.
           EXIT.

      *---------------
       3300-ETI-QUOTE.
      *---------------

005409     MOVE RPOL-POL-PD-TO-DT-NUM TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.

005409     IF E0661-EFF-DATE NOT = L1680-INTERNAL-2
005409*    IF E0661-EFF-DATE NOT = RPOL-POL-PD-TO-DT-NUM
553989* MSG: EFFECTIVE DATE NOT EQUAL TO PAID TO DATE
553989         MOVE 'CS06610026'      TO WGLOB-MSG-REF-INFO
553989         PERFORM  0260-1000-GENERATE-MESSAGE
553989             THRU 0260-1000-GENERATE-MESSAGE-X
553989         SET WGLOB-RETURN-ERROR TO TRUE
553989         GO TO 3300-ETI-QUOTE-X
553989     END-IF.

           PERFORM  2220-1000-BUILD-PARM-INFO
               THRU 2220-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L2220-EFF-DT.
           MOVE E0661-COV-NO          TO L2220-CVG-NUM.

           SET L2220-PRCES-TYP-ALL TO TRUE.
016503     SET L2220-REDO-WARNING  TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L2220-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  2220-1000-ETI-QUOTE
               THRU 2220-1000-ETI-QUOTE-X.

           IF  NOT L2220-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
      *MSG: ETI QUOTE PROCESSING NOT COMPLETED
               MOVE 'CS06614213'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3300-ETI-QUOTE-X
           END-IF.

008455*    MOVE L2220-ETI-FACE-AMT TO EDIT-9V2.
008455*    MOVE EDIT-9V2           TO MIR-CVG-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L2220-ETI-FACE-AMT * 100.
020874     MOVE  L2220-ETI-FACE-AMT TO L0290-INPUT-V02.
008455     PERFORM  9600-FORMAT-FACE
008455         THRU 9600-FORMAT-FACE-X.
           IF  L2220-ETI-FACE-AMT NOT > ZERO
      *MSG: 'ETI FACE AMOUNT NOT GREATER THAN ZERO - ZERO ASSUMED'
               MOVE 'CS06614114'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG: 'ETI FACE AMOUNT CALCULATED SHOWN ABOVE'
               MOVE 'CS06614111'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE L2220-ETI-END-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CVG-MAT-XPRY-DT.
      *MSG: 'CACULATED ETI EXPIRY DATE SHOWN ABOVE'
           MOVE 'CS06614112'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

025981*MSG: 'CHANGE CODE TO ETI IF  YOU WISH TO MAKE POLICY ETI'
025981*    MOVE 'CS06614113'          TO WGLOB-MSG-REF-INFO.
025981*    PERFORM  0260-1000-GENERATE-MESSAGE
025981*        THRU 0260-1000-GENERATE-MESSAGE-X.
025981*
       3300-ETI-QUOTE-X.
           EXIT.

      *-------------------
       3310-EXTENDED-TERM.
      *-------------------

557697     IF RPOL-POL-SFB-CD NOT = SPACE
557697* MSG: POLICY MUST BE CHANGED FROM SPECIAL FREQUENCY BEFORE MAKING
557697*      ETI
557697        MOVE 'CS06610017'       TO WGLOB-MSG-REF-INFO
557697        PERFORM 0260-1000-GENERATE-MESSAGE
557697           THRU 0260-1000-GENERATE-MESSAGE-X
557697        GO TO 3310-EXTENDED-TERM-X
557697     END-IF.

005409     MOVE RPOL-POL-PD-TO-DT-NUM TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.

005409     IF E0661-EFF-DATE NOT = L1680-INTERNAL-2
005409*    IF E0661-EFF-DATE NOT = RPOL-POL-PD-TO-DT-NUM
553989* MSG: EFFECTIVE DATE NOT EQUAL TO PAID TO DATE
553989         MOVE 'CS06610026'      TO WGLOB-MSG-REF-INFO
553989         PERFORM  0260-1000-GENERATE-MESSAGE
553989             THRU 0260-1000-GENERATE-MESSAGE-X
553989         SET WGLOB-RETURN-ERROR TO TRUE
553989         GO TO 3310-EXTENDED-TERM-X
553989     END-IF.

           PERFORM  1220-1000-BUILD-PARM-INFO
               THRU 1220-1000-BUILD-PARM-INFO-X.

           MOVE E0661-FACE-AMT        TO L1220-ETI-FACE-AMT.
           MOVE E0661-EFF-DATE        TO L1220-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1220-CLI-SUR-NM-1-4.
           MOVE E0661-EXP-DATE        TO L1220-ETI-END-DT.
           MOVE E0661-COV-NO          TO L1220-CVG-NUM.
           MOVE MIR-DV-CHQ-CREAT-IND  TO L1220-ETI-CHEQUE-IND.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3312-ETI-2
                       THRU 3312-ETI-2-X

               WHEN OTHER
                   PERFORM  3311-ETI-1
                       THRU 3311-ETI-1-X


           END-EVALUATE.

       3310-EXTENDED-TERM-X.
           EXIT.

      *---------------
       3311-ETI-1.
      *---------------

           SET L1220-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1220-REDO-WARNING        TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L1220-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  1220-1000-MAKE-ETI
               THRU 1220-1000-MAKE-ETI-X.

           IF  NOT L1220-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3311-ETI-1-X
           END-IF.

           IF  RPOL-POL-PREM-SUSP-AMT GREATER THAN ZERO
           OR RPOL-POL-MISC-SUSP-AMT GREATER THAN ZERO
013578*        MOVE 'CS06610025'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-2000-GET-MESSAGE
013578*            THRU 0260-2000-GET-MESSAGE-X
013578*        MOVE WGLOB-MSG-TXT     TO MIR-CHQMSG
557756*        MOVE TYSNO-YES-NO-SHORT (WGLOB-LANG-SUB, 2)
557756*                                       TO MIR-DV-CHQ-CREAT-IND
557756         PERFORM 2510-1000-BUILD-PARM-INFO
557756            THRU 2510-1000-BUILD-PARM-INFO-X
557756         SET L2510-VALUE-LENGTH-SHORT TO TRUE
557756         SET L2510-RESPONSE-NO        TO TRUE
557756         PERFORM 2510-2000-SINGLE-VALUE
557756            THRU 2510-2000-SINGLE-VALUE-X
557756         MOVE L2510-RESPONSE-TXT           TO MIR-DV-CHQ-CREAT-IND
           END-IF.

      *MSG: 'YOU ARE CHANGING THIS POLICY TO ETI @1
           MOVE 'CS06612215'          TO WGLOB-MSG-REF-INFO.

           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3311-ETI-1-X.
           EXIT.

      *---------------
       3312-ETI-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3312-ETI-2-X
           END-IF.

           SET L1220-PRCES-TYP-ALL TO TRUE.
016503     SET L1220-REDO-WARNING  TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L1220-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  1220-1000-MAKE-ETI
               THRU 1220-1000-MAKE-ETI-X.

           IF  NOT L1220-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3312-ETI-2-X.
           EXIT.

      *---------------
       3320-REVERSE-ETI.
      *---------------

           PERFORM  1220-1000-BUILD-PARM-INFO
               THRU 1220-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L1220-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1220-CLI-SUR-NM-1-4.
           MOVE E0661-COV-NO          TO L1220-CVG-NUM.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3322-REV-ETI-2
                       THRU 3322-REV-ETI-2-X

               WHEN OTHER
                   PERFORM  3321-REV-ETI-1
                       THRU 3321-REV-ETI-1-X


           END-EVALUATE.

       3320-REVERSE-ETI-X.
           EXIT.

      *---------------
       3321-REV-ETI-1.
      *---------------

           SET L1220-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1220-REDO-WARNING        TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L1220-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  1220-2000-REVRS-ETI
               THRU 1220-2000-REVRS-ETI-X.

           IF  NOT L1220-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3321-REV-ETI-1-X
           END-IF.

      *MSG: 'YOU ARE REINSTATING THIS POLICY FROM ETI @1
           MOVE 'CS06612216'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

           PERFORM  3600-STAT-CHG-MESSAGE
               THRU 3600-STAT-CHG-MESSAGE-X.

       3321-REV-ETI-1-X.
           EXIT.

      *---------------
       3322-REV-ETI-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3322-REV-ETI-2-X
           END-IF.

           SET L1220-PRCES-TYP-ALL TO TRUE.
016503     SET L1220-REDO-WARNING  TO TRUE.

           IF  PROCESSING-COVERAGE
               SET L1220-CVG-PASSED TO TRUE
           END-IF.

           PERFORM  1220-2000-REVRS-ETI
               THRU 1220-2000-REVRS-ETI-X.

           IF  NOT L1220-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3322-REV-ETI-2-X.
           EXIT.

      *---------------
       3330-DEEMED-DISP.
      *---------------

           PERFORM  7000-1000-BUILD-PARM-INFO
               THRU 7000-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L7000-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L7000-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3332-DEEMED-DISP-2
                       THRU 3332-DEEMED-DISP-2-X

               WHEN OTHER
                   PERFORM  3331-DEEMED-DISP-1
                       THRU 3331-DEEMED-DISP-1-X


           END-EVALUATE.

       3330-DEEMED-DISP-X.
           EXIT.

      *---------------
       3331-DEEMED-DISP-1.
      *---------------

           SET L7000-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L7000-REDO-WARNING        TO TRUE.

           PERFORM  7000-1000-DEEMED-DISP
               THRU 7000-1000-DEEMED-DISP-X.

           IF  NOT L7000-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3331-DEEMED-DISP-1-X
           END-IF.

      *MSG:'YOU ARE REQUESTING A DEEMED DISPOSITION @1'
           MOVE 'CS06612217'          TO WGLOB-MSG-REF-INFO.

           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3331-DEEMED-DISP-1-X.
           EXIT.

      *---------------
       3332-DEEMED-DISP-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3332-DEEMED-DISP-2-X
           END-IF.

           SET L7000-PRCES-TYP-ALL TO TRUE.
016503     SET L7000-REDO-WARNING  TO TRUE.
           PERFORM  7000-1000-DEEMED-DISP
               THRU 7000-1000-DEEMED-DISP-X.

           IF  NOT L7000-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3332-DEEMED-DISP-2-X.
           EXIT.

      *---------------
       3340-AUTO-PREM-PYMT.
      *---------------

557697     IF RPOL-POL-SFB-CD NOT = SPACE
557697* MSG: POLICY MUST BE CHANGED FROM SPECIAL FREQUENCY BEFORE MAKING
557697*      APP
557697        MOVE 'CS06610018'       TO WGLOB-MSG-REF-INFO
557697        PERFORM 0260-1000-GENERATE-MESSAGE
557697           THRU 0260-1000-GENERATE-MESSAGE-X
557697        GO TO 3340-AUTO-PREM-PYMT-X
557697     END-IF.

           IF  PROCESSING-COVERAGE
      *MSG:'APP PROCESSING AT COVERAGE LEVEL NOT SUPPORTED
               MOVE 'CS06613340'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3340-AUTO-PREM-PYMT-X
           END-IF.

           PERFORM  1080-1000-BUILD-PARM-INFO
               THRU 1080-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L1080-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1080-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM  3342-APP-2
                        THRU 3342-APP-2-X

               WHEN OTHER
                   PERFORM  3341-APP-1
                       THRU 3341-APP-1-X


           END-EVALUATE.

       3340-AUTO-PREM-PYMT-X.
           EXIT.

      *---------------
       3341-APP-1.
      *---------------

           SET L1080-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1080-REDO-WARNING        TO TRUE.

           PERFORM  1080-1000-AUTO-PREM-PMT
               THRU 1080-1000-AUTO-PREM-PMT-X.

           IF  NOT L1080-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3341-APP-1-X
           END-IF.

      *MSG: YOU ARE FORCING AN AUTO PREM PAYMENT ON AN FPUL POLICY @1
           MOVE 'CS06612218'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

018633*    MOVE L1080-EDIT-EFF-DT     TO WS-INTERNAL-DT.
018633     MOVE L1080-EDIT-EFF-DT     TO LCOMM-INTERNAL-DT.
018633*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM 9800-WRITE-TWRK
018633*       THRU 9800-WRITE-TWRK-X.
018633     PERFORM COMM-2000-WRITE-TWRK
018633        THRU COMM-2000-WRITE-TWRK-X.


       3341-APP-1-X.
           EXIT.

      *---------------
       3342-APP-2.
      *---------------

018633*    PERFORM 9700-RETRIEVE-TWRK
018633*       THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM COMM-1000-RETRIEVE-TWRK
018633        THRU COMM-1000-RETRIEVE-TWRK-X.
018633
018633*    IF L8090-RETRN-OK
018633*       MOVE L8090-AREA-INFO-TEXT TO WS-WORK-AREA
018633*    END-IF.
018633*
018633*    MOVE WS-INTERNAL-DT TO E0661-EFF-DATE
018633     MOVE LCOMM-INTERNAL-DT TO E0661-EFF-DATE

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3342-APP-2-X
           END-IF.

           SET L1080-PRCES-TYP-ALL TO TRUE.
016503     SET L1080-REDO-WARNING  TO TRUE.
           PERFORM  1080-1000-AUTO-PREM-PMT
               THRU 1080-1000-AUTO-PREM-PMT-X.

           IF  NOT L1080-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3342-APP-2-X.
           EXIT.

      *---------------
       3350-IMM-ANN-PYMT.
      *---------------

           IF  PROCESSING-COVERAGE
      *MSG: 'IMM ANNUITY PROCESSING AT COVERAGE LEVEL NOT SUPPORTED
               MOVE 'CS06613350'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3350-IMM-ANN-PYMT-X
           END-IF.

014035     IF  NOT  RPOL-POL-INS-TYP-IMMED-ANTY
014035*MSG:    FOR  ENTER CODE 'IAP' POLICY TYPE SHOULD BE 'I'
014035         MOVE 'CS06614215'      TO WGLOB-MSG-REF-INFO
014035         PERFORM  0260-1000-GENERATE-MESSAGE
014035             THRU 0260-1000-GENERATE-MESSAGE-X
014035         GO TO 3350-IMM-ANN-PYMT-X
014035     END-IF.

           PERFORM  1350-1000-BUILD-PARM-INFO
               THRU 1350-1000-BUILD-PARM-INFO-X.

012137     IF MIR-SUPRES-CNFRM-IND    = 'Y'
012137         SET L1350-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0661-EFF-DATE        TO L1350-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1350-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM 3352-IA-PAY-2
                        THRU 3352-IA-PAY-2-X

               WHEN OTHER
                   PERFORM  3351-IA-PAY-1
                       THRU 3351-IA-PAY-1-X


           END-EVALUATE.

       3350-IMM-ANN-PYMT-X.
           EXIT.

      *---------------
       3351-IA-PAY-1.
      *---------------

           SET L1350-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1350-REDO-WARNING        TO TRUE.

557690     IF  RPOL-POL-CTRY-US
557690         IF  L2430-CLI-SIN-ID = SPACES
557690         OR  L2430-CLI-SIN-ID = '000000000'
557690         OR  L2430-CLI-SIN-ID = LOW-VALUES
557690*MSG: TAX ID NOT FOUND ON CLIENT (@1)
557690             MOVE 'CS06610027'  TO WGLOB-MSG-REF-INFO
557690             MOVE RPOL-POL-ID   TO WGLOB-MSG-PARM (1)
557690             PERFORM  0260-1000-GENERATE-MESSAGE
557690                 THRU 0260-1000-GENERATE-MESSAGE-X
557690         END-IF
557690     END-IF

           PERFORM  1350-1000-MAKE-IA-PMT
               THRU 1350-1000-MAKE-IA-PMT-X

           IF  NOT L1350-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3351-IA-PAY-1-X
           END-IF.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

018633*    MOVE L1350-EDIT-EFF-DT     TO WS-INTERNAL-DT.
018633     MOVE L1350-EDIT-EFF-DT     TO LCOMM-INTERNAL-DT.
018633*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM 9800-WRITE-TWRK
018633*       THRU 9800-WRITE-TWRK-X.
018633     PERFORM COMM-2000-WRITE-TWRK
018633        THRU COMM-2000-WRITE-TWRK-X.

      *MSG: YOU ARE FORCING AN IMMEDIATE ANNUITY PAYOUT @1
           MOVE 'CS06612219'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3351-IA-PAY-1-X.
           EXIT.

      *---------------
       3352-IA-PAY-2.
      *---------------


018633*    PERFORM 9700-RETRIEVE-TWRK
018633*      THRU  9700-RETRIEVE-TWRK-X.
018633     PERFORM COMM-1000-RETRIEVE-TWRK
018633       THRU  COMM-1000-RETRIEVE-TWRK-X.

018633*    IF L8090-RETRN-OK
018633*       MOVE L8090-AREA-INFO-TEXT TO WS-WORK-AREA
018633*    END-IF.
018633*
018633*    IF WS-INTERNAL-DT NOT =       E0661-EFF-DATE
018633*       MOVE WS-INTERNAL-DT     TO E0661-EFF-DATE
018633*       MOVE WS-INTERNAL-DT     TO L1350-EFF-DT
018633     IF LCOMM-INTERNAL-DT NOT =    E0661-EFF-DATE
018633        MOVE LCOMM-INTERNAL-DT  TO E0661-EFF-DATE
018633        MOVE LCOMM-INTERNAL-DT  TO L1350-EFF-DT
           END-IF.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3352-IA-PAY-2-X
           END-IF.

           SET L1350-PRCES-TYP-ALL TO TRUE.
016503     SET L1350-REDO-WARNING  TO TRUE.

           PERFORM  1350-1000-MAKE-IA-PMT
               THRU 1350-1000-MAKE-IA-PMT-X.

           IF  NOT L1350-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3352-IA-PAY-2-X.
           EXIT.

      *---------------
       3360-REVERSE-IA-PYMT.
      *---------------

           IF  PROCESSING-COVERAGE
      *MSG: 'IMM ANNUITY PROCESSING AT COVERAGE LEVEL NOT SUPPORTED'
               MOVE 'CS06613350'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3360-REVERSE-IA-PYMT-X
           END-IF.

014035     IF  NOT  RPOL-POL-INS-TYP-IMMED-ANTY
014035*MSG:    FOR  ENTER CODE 'IAP' POLICY TYPE SHOULD BE 'I'
014035         MOVE 'CS06614215'      TO WGLOB-MSG-REF-INFO
014035         PERFORM  0260-1000-GENERATE-MESSAGE
014035             THRU 0260-1000-GENERATE-MESSAGE-X
014035         GO TO 3360-REVERSE-IA-PYMT-X
014035     END-IF.

           PERFORM  1350-1000-BUILD-PARM-INFO
               THRU 1350-1000-BUILD-PARM-INFO-X.
           MOVE E0661-EFF-DATE        TO L1350-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1350-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM  3362-REV-IA-2
                        THRU 3362-REV-IA-2-X

               WHEN OTHER
                   PERFORM  3361-REV-IA-1
                       THRU 3361-REV-IA-1-X


           END-EVALUATE.

       3360-REVERSE-IA-PYMT-X.
           EXIT.

      *---------------
       3361-REV-IA-1.
      *---------------

           SET L1350-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1350-REDO-WARNING        TO TRUE.

           PERFORM  1350-2000-REVRS-IA-PMT
               THRU 1350-2000-REVRS-IA-PMT-X.

           IF  NOT L1350-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3361-REV-IA-1-X
           END-IF.

557690     IF  RPOL-POL-CTRY-US
557690*MSG: USTX RECORD MUST BE MANUALLY ERRORED OUT
557690         MOVE 'CS06610028'      TO WGLOB-MSG-REF-INFO
557690         PERFORM  0260-1000-GENERATE-MESSAGE
557690             THRU 0260-1000-GENERATE-MESSAGE-X
557690     END-IF

      *MSG: YOU ARE REVERSING AN IMMEDIATE ANNUITY PAYOUT @1
           MOVE 'CS06612220'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3361-REV-IA-1-X.
           EXIT.

      *---------------
       3362-REV-IA-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3362-REV-IA-2-X
           END-IF.

           SET L1350-PRCES-TYP-ALL TO TRUE.
016503     SET L1350-REDO-WARNING  TO TRUE.
           PERFORM  1350-2000-REVRS-IA-PMT
               THRU 1350-2000-REVRS-IA-PMT-X.

           IF  NOT L1350-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3362-REV-IA-2-X.
           EXIT.

      *---------------
       3370-RRIF-PAYMENT.
      *---------------

           IF  PROCESSING-COVERAGE
      *MSG: 'RRIF PAYMENT PROCESSING AT COVERAGE LEVEL NOT SUPPORTED'
               MOVE 'CS06613370'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3370-RRIF-PAYMENT-X
           END-IF.

           PERFORM  1360-1000-BUILD-PARM-INFO
               THRU 1360-1000-BUILD-PARM-INFO-X.


           MOVE E0661-EFF-DATE        TO L1360-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1360-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM  3372-RRIF-PAY-2
                        THRU 3372-RRIF-PAY-2-X

               WHEN OTHER
                   PERFORM  3371-RRIF-PAY-1
                       THRU 3371-RRIF-PAY-1-X


           END-EVALUATE.

       3370-RRIF-PAYMENT-X.
           EXIT.

      *---------------
       3371-RRIF-PAY-1.
      *---------------

           SET L1360-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1360-REDO-WARNING        TO TRUE.

           PERFORM  1360-1000-MAKE-RRIF-PMT
               THRU 1360-1000-MAKE-RRIF-PMT-X.

           IF  NOT L1360-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3371-RRIF-PAY-1-X
           END-IF.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

018633*    MOVE L1360-RRIF-EFF-DT     TO WS-INTERNAL-DT.
018633     MOVE L1360-RRIF-EFF-DT     TO LCOMM-INTERNAL-DT.
018633*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM 9800-WRITE-TWRK
018633*       THRU 9800-WRITE-TWRK-X.
018633     PERFORM COMM-2000-WRITE-TWRK
018633        THRU COMM-2000-WRITE-TWRK-X.

      *MSG: YOU ARE FORCING A RRIF PAYOUT @1
           MOVE 'CS06612221'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3371-RRIF-PAY-1-X.
           EXIT.

      *---------------
       3372-RRIF-PAY-2.
      *---------------

018633*    PERFORM 9700-RETRIEVE-TWRK
018633*       THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM COMM-1000-RETRIEVE-TWRK
018633        THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF L8090-RETRN-OK
018633*       MOVE L8090-AREA-INFO-TEXT TO WS-WORK-AREA
018633*    END-IF.
018633*
018633*    IF WS-INTERNAL-DT NOT = E0661-EFF-DATE
018633*        MOVE WS-INTERNAL-DT TO E0661-EFF-DATE
018633*        MOVE WS-INTERNAL-DT TO L1360-EFF-DT
018633     IF LCOMM-INTERNAL-DT NOT = E0661-EFF-DATE
018633         MOVE LCOMM-INTERNAL-DT TO E0661-EFF-DATE
018633         MOVE LCOMM-INTERNAL-DT TO L1360-EFF-DT
           END-IF.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.


           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3372-RRIF-PAY-2-X
           END-IF.

           SET L1360-PRCES-TYP-ALL TO TRUE.
016503     SET L1360-REDO-WARNING  TO TRUE.
           PERFORM  1360-1000-MAKE-RRIF-PMT
               THRU 1360-1000-MAKE-RRIF-PMT-X.

           IF  NOT L1360-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3372-RRIF-PAY-2-X.
           EXIT.

      *---------------
       3380-REV-RRIF-PYMT.
      *---------------
           IF  PROCESSING-COVERAGE
      *MSG: RRIF PAYMENT PROCESSING AT COVERAGE LEVEL NOT SUPPORTED
               MOVE 'CS06613370'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3380-REV-RRIF-PYMT-X
           END-IF.

           PERFORM  1360-1000-BUILD-PARM-INFO
               THRU 1360-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L1360-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L1360-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3382-REV-RRIF-2
                       THRU 3382-REV-RRIF-2-X

               WHEN OTHER
                   PERFORM  3381-REV-RRIF-1
                       THRU 3381-REV-RRIF-1-X


               END-EVALUATE.

       3380-REV-RRIF-PYMT-X.
           EXIT.

      *---------------
       3381-REV-RRIF-1.
      *---------------

           SET L1360-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1360-REDO-WARNING        TO TRUE.

           PERFORM  1360-2000-REVRS-RRIF-PMT
               THRU 1360-2000-REVRS-RRIF-PMT-X.

           IF  NOT L1360-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3381-REV-RRIF-1-X
            END-IF.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

018633*    MOVE L1360-RRIF-EFF-DT     TO WS-INTERNAL-DT.
018633     MOVE L1360-RRIF-EFF-DT     TO LCOMM-INTERNAL-DT.
018633*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM 9800-WRITE-TWRK
018633*       THRU 9800-WRITE-TWRK-X.
018633     PERFORM COMM-2000-WRITE-TWRK
018633        THRU COMM-2000-WRITE-TWRK-X.


      *MSG: YOU ARE REVERSING A RRIF PAYOUT @1
           MOVE 'CS06612222'          TO WGLOB-MSG-REF-INFO.
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3381-REV-RRIF-1-X.
           EXIT.

      *---------------
       3382-REV-RRIF-2.
      *---------------

018633*    PERFORM 9700-RETRIEVE-TWRK
018633*       THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM COMM-1000-RETRIEVE-TWRK
018633        THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF L8090-RETRN-OK
018633*       MOVE L8090-AREA-INFO-TEXT TO WS-WORK-AREA
018633*    END-IF.
018633*
018633*    IF WS-INTERNAL-DT NOT = E0661-EFF-DATE
018633*        MOVE WS-INTERNAL-DT TO E0661-EFF-DATE
018633*        MOVE WS-INTERNAL-DT TO L1360-EFF-DT
018633     IF LCOMM-INTERNAL-DT NOT = E0661-EFF-DATE
018633         MOVE LCOMM-INTERNAL-DT TO E0661-EFF-DATE
018633         MOVE LCOMM-INTERNAL-DT TO L1360-EFF-DT
           END-IF.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.


           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3382-REV-RRIF-2-X
           END-IF.

           SET L1360-PRCES-TYP-ALL TO TRUE.
016503     SET L1360-REDO-WARNING  TO TRUE.

           PERFORM  1360-2000-REVRS-RRIF-PMT
               THRU 1360-2000-REVRS-RRIF-PMT-X.

           IF  NOT L1360-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3382-REV-RRIF-2-X.
           EXIT.

      *---------------
       3390-YEAR-END-RESET.
      *---------------

           PERFORM  0361-1000-BUILD-PARM-INFO
               THRU 0361-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L0361-EFF-DT.
013578*    MOVE E0661-OWNER-NAME      TO L0361-CLI-SUR-NM-1-4.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM  3392-YE-RESET-2
                        THRU 3392-YE-RESET-2-X
               WHEN OTHER
                   PERFORM  3391-YE-RESET-1
                       THRU 3391-YE-RESET-1-X


           END-EVALUATE.

       3390-YEAR-END-RESET-X.
           EXIT.

      *---------------
       3391-YE-RESET-1.
      *---------------

           SET L0361-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L0361-REDO-WARNING        TO TRUE.

           PERFORM  0361-1000-YEAREND-RESETS
               THRU 0361-1000-YEAREND-RESETS-X.

           IF  NOT L0361-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3391-YE-RESET-1-X
           END-IF.

      *MSG: YOU ARE PUTTING POLICY THRU YEAREND RESET PROCESSING @1
           MOVE 'CS06612223'          TO WGLOB-MSG-REF-INFO.
           MOVE E0661-EFF-DATE        TO WGLOB-MSG-PARM (1).
           PERFORM  3500-VERIFY-TRAN
               THRU 3500-VERIFY-TRAN-X.

       3391-YE-RESET-1-X.
           EXIT.

      *---------------
       3392-YE-RESET-2.
      *---------------

           PERFORM  4000-START-PROCESS
               THRU 4000-START-PROCESS-X.

           IF  NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3392-YE-RESET-2-X
           END-IF.

           SET L0361-PRCES-TYP-ALL TO TRUE.
016503     SET L0361-REDO-WARNING  TO TRUE.

           PERFORM  0361-1000-YEAREND-RESETS
               THRU 0361-1000-YEAREND-RESETS-X.

           IF  NOT L0361-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3392-YE-RESET-2-X.
           EXIT.
023436/
023436*-----------------------
023436 3400-ANNIVERSARY-REVRS.
023436*-----------------------
023436*
023436* ANNIVERSARY-REVERS PROCESSING AT THE COVERAGE LEVEL
023436* NOT SUPPORTED
023436*
023436     IF  PROCESSING-COVERAGE
023436         MOVE 'CS06610030'      TO WGLOB-MSG-REF-INFO
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436         GO TO 3400-ANNIVERSARY-REVRS-X
023436     END-IF.
023436
023436     MOVE RPOL-POL-ISS-EFF-DT   TO L1680-INTERNAL-1.
023436     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
023436     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
023436     COMPUTE L1680-NUMBER-OF-YEARS =
023436             RPOL-POL-PREV-ANNV-DUR-N.
023436     PERFORM 1680-3000-ADD-Y-M-D-TO-DATE
023436        THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
023436     MOVE L1680-INTERNAL-2      TO E0661-EFF-DATE.
023436*
023436*  CHECK THAT ANNIVERSARY HAS BEEN DONE
023436*
023436     IF  WGLOB-PROCESS-DATE < E0661-EFF-DATE
023436     OR  RPOL-POL-PREV-ANNV-DUR-N = ZEROES
023436*MSG: ANNV PROCESS MUST BE DONE BEFORE REVERSAL PROCESS
023436         MOVE 'CS06610031'         TO WGLOB-MSG-REF-INFO
023436
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436
023436         SET WGLOB-RETURN-ERROR TO TRUE
023436         GO TO 3400-ANNIVERSARY-REVRS-X
023436     END-IF.
023436
023436     PERFORM COMM-3000-DELETE-TWRK
023436        THRU COMM-3000-DELETE-TWRK-X.
023436
023436     MOVE L1680-INTERNAL-2      TO LCOMM-INTERNAL-DT.
023436
023436     PERFORM COMM-2000-WRITE-TWRK
023436        THRU COMM-2000-WRITE-TWRK-X.
023436
023436     EVALUATE TRUE
023436
023436         WHEN MIR-DV-PRCES-STATE-CD = '3'
023436             PERFORM  3402-ANNIV-REVRS-2
023436                 THRU 3402-ANNIV-REVRS-2-X
023436
023436         WHEN OTHER
023436              PERFORM  3401-ANNIV-REVRS-1
023436                  THRU 3401-ANNIV-REVRS-1-X
023436
023436     END-EVALUATE.
023436
023436 3400-ANNIVERSARY-REVRS-X.
023436     EXIT.
023436/
023436*-------------------
023436 3401-ANNIV-REVRS-1.
023436*-------------------
023436
023436*MSG: 'YOU ARE PUTTING THIS POLICY THRU ANNIVERSARY
023436*      REVERSAL PROCESSING
023436     MOVE 'CS06612234'          TO WGLOB-MSG-REF-INFO.
023436     PERFORM  3500-VERIFY-TRAN
023436         THRU 3500-VERIFY-TRAN-X.
023436
023436 3401-ANNIV-REVRS-1-X.
023436     EXIT.
023436/
023436*-------------------
023436 3402-ANNIV-REVRS-2.
023436*-------------------
023436
023436     SET WS-PHST-ACTV-ANNV     TO TRUE.
023436     PERFORM  4600-LOCATE-PHST
023436         THRU 4600-LOCATE-PHST-X.
023436
023436     IF  WGLOB-RETURN-ERROR
023436         GO TO 3402-ANNIV-REVRS-2-X
023436     END-IF.
023436
023436     PERFORM  4700-UNDO-ON-REVERSAL
023436         THRU 4700-UNDO-ON-REVERSAL-X.
023436
023436     IF  WGLOB-RETURN-ERROR
023436         GO TO 3402-ANNIV-REVRS-2-X
023436     END-IF.
023436
023436     PERFORM  4500-END-PROCESS
023436         THRU 4500-END-PROCESS-X.
023436
023436 3402-ANNIV-REVRS-2-X.
023436     EXIT.
023436/
      *---------------
       3500-VERIFY-TRAN.
      *---------------
      *
      *GENERATE THE FUNCTION SPECIFIC MESSAGE THAT WAS ALREADY SET UP
      *
           IF  PROCESSING-COVERAGE
               COMPUTE DISPLAY-CVG = W0661-SUB
               MOVE DISPLAY-CVG       TO WGLOB-MSG-PARM (1)
           ELSE
               MOVE RPOL-KEY          TO WGLOB-MSG-PARM (1)
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
      *GENERATE THE VERIFY MESSAGE
      *
      *MSG: 'PLEASE ENTER YES TO CONFIRM OR NO TO CANCEL PROCESS'
           MOVE 'CS06610002'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       3500-VERIFY-TRAN-X.
           EXIT.

      *---------------
       3600-STAT-CHG-MESSAGE.
      *---------------

           IF  PROCESSING-POLICY
               MOVE 'CS06612233'      TO WGLOB-MSG-REF-INFO
               MOVE WCVGS-CVG-STAT-EFF-DT (RPOL-POL-BASE-CVG-NUM)
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
            END-IF.

           IF  PROCESSING-COVERAGE
               MOVE 'CS06612233'      TO WGLOB-MSG-REF-INFO
               MOVE WCVGS-CVG-STAT-EFF-DT  (E0661-COV-NO)
                                      TO   L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3600-STAT-CHG-MESSAGE-X.
           EXIT.

      *-------------------
       4000-START-PROCESS.
      *-------------------

016503*  INVOKE REDO PROCESSING

016503     SET WS-REDO-OK           TO  TRUE.
016503     IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503        CONTINUE
016503     ELSE
016503        PERFORM  4200-INVOKE-REDO
016503            THRU 4200-INVOKE-REDO-X
016503     END-IF.

016503     IF WS-REDO-NOT-OK
016503        GO TO 4000-START-PROCESS-X
016503     END-IF.

      *
      *  UNLOCK POLICY RECORD (THIS ALLOWS FOR POLICY UPDATES IN
      *  CSLS0065 WHICH CAN BE CALLED FROM CSLS4700).
      *
           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.
           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.

           MOVE E0661-EFF-DATE        TO L4750-EFF-DT.
           SET L4750-FCN-DRVR-SECONDARY TO TRUE.
           SET L4750-PRCES-EXCLUSIVE    TO TRUE.
           IF NOT WS-BUS-FCN-REV-TRANS
               SET L4750-TCNTRCT-PREM-REVRS-BPSS TO TRUE
           END-IF.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

      * LOCK POLICY AGAIN IN ORDER TO DO UPDATES
      * SAVE POLICY INFO TO RESTORE AFTER READ FOR UPDATE
      *
           MOVE  RPOL-REC-INFO        TO  HPOL-REC-INFO.
           MOVE  MIR-POL-ID-BASE           TO  WPOL-POL-ID-BASE.
           MOVE  MIR-POL-ID-SFX           TO  WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.

           IF  NOT WGLOB-GOOD-RETURN
016503         PERFORM  0289-1000-INIT-PARM-INFO
016503             THRU 0289-1000-INIT-PARM-INFO-X
016503         MOVE E0661-EFF-DATE    TO L0289-LO-PAC-DT
016503         MOVE E0661-EFF-DATE    TO L0289-LO-CRC-DT
016503         MOVE E0661-EFF-DATE    TO L0289-PROC-EFF-DT
020467         MOVE E0661-EFF-DATE    TO L0289-LO-DD2-DT
016503         PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503             THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503         IF  L0289-RETRN-OK
016503             MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503             MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503         ELSE
016503             MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503             MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503         END-IF
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
               PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                   THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
           END-IF.

       4000-START-PROCESS-X.
           EXIT.

016503*----------------
016503 4200-INVOKE-REDO.
016503*----------------

016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503     OR  WS-BUS-FCN-REDO-BYPASS
016503         GO TO 4200-INVOKE-REDO-X
016503     END-IF.

016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     MOVE E0661-EFF-DATE                TO L4780-EFF-DT.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
016503     SET L4780-PRCES-INCLUSIVE          TO TRUE.

016503     PERFORM  4780-1000-GET-NEXT-ACT-DT
016503         THRU 4780-1000-GET-NEXT-ACT-DT-X.

016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              SET WS-REDO-NOT-OK           TO TRUE
016503              PERFORM  POL-3000-UNLOCK
016503                  THRU POL-3000-UNLOCK-X
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503             PERFORM  POL-3000-UNLOCK
016503                 THRU POL-3000-UNLOCK-X
016503             MOVE E0661-EFF-DATE      TO L0201-EFF-DT
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X
016503             PERFORM  0289-1000-INIT-PARM-INFO
016503                 THRU 0289-1000-INIT-PARM-INFO-X
016503             MOVE E0661-EFF-DATE  TO L0289-LO-PAC-DT
016503             MOVE E0661-EFF-DATE  TO L0289-LO-CRC-DT
016503             MOVE E0661-EFF-DATE  TO L0289-PROC-EFF-DT
020467             MOVE E0661-EFF-DATE  TO L0289-LO-DD2-DT
016503             PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503                 THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503             IF  L0289-RETRN-OK
016503                 MOVE L0289-NXT-ACTV-TYP-CD
016503                      TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE L0289-NXT-ACTV-DT
016503                      TO RPOL-POL-NXT-ACTV-DT
016503             ELSE
016503                 MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE WGLOB-PROCESS-DATE
016503                           TO RPOL-POL-NXT-ACTV-DT
016503             END-IF
016503             MOVE RPOL-REC-INFO           TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503             MOVE HPOL-REC-INFO           TO RPOL-REC-INFO
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
016503                 PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016503                     THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221                 PERFORM  POL-1000-READ-TWRK-TS
014221                     THRU POL-1000-READ-TWRK-TS-X
016503             IF  L0201-RETRN-OK
016503                 PERFORM  POL-1000-READ-FOR-UPDATE
016503                     THRU POL-1000-READ-FOR-UPDATE-X
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503             END-IF
016503     END-EVALUATE.

016503 4200-INVOKE-REDO-X.
016503     EXIT.


      *---------------
       4500-END-PROCESS.
      *---------------
      *
      *  UPDATE THE POLICY NEXT ACTIVITY TYPE AND DATE
      *
016503*    IF  RPOL-POL-STAT-IN-FORCE
016503*        MOVE WWKDT-ZERO-DT     TO RPOL-POL-NXT-ACTV-DT
016503*        IF  RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*            MOVE 'RSH'         TO RPOL-NXT-ACTV-TYP-CD
016503*        END-IF
016503*    END-IF.

016503*    MOVE WWKDT-ZERO-DT         TO RPOL-POL-NXT-ACTV-DT.
           MOVE WGLOB-PROCESS-DATE    TO RPOL-PREV-FILE-MAINT-DT.

016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     MOVE E0661-EFF-DATE    TO L0289-LO-PAC-DT.
016503     MOVE E0661-EFF-DATE    TO L0289-LO-CRC-DT.
016503     MOVE E0661-EFF-DATE    TO L0289-PROC-EFF-DT.
020467     MOVE E0661-EFF-DATE    TO L0289-LO-DD2-DT.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503      ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503      END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.


       4500-END-PROCESS-X.
           EXIT.
023436
023436*------------------
023436 4600-LOCATE-PHST.
023436*------------------
023436
023436     INITIALIZE                 RPHST-REC-INFO.
023436     MOVE RPOL-POL-ID           TO WPHST-POL-ID.
023436     MOVE E0661-EFF-DATE        TO L1660-INTERNAL-DATE.
023436     PERFORM  1660-2000-CONVERT-INT-TO-INV
023436         THRU 1660-2000-CONVERT-INT-TO-INV-X.
023436     MOVE L1660-INVERTED-DATE   TO WPHST-PCHST-EFF-IDT-NUM.
023436     MOVE ZEROS                 TO WPHST-PCHST-SEQ-NUM.
023436
023436     MOVE WPHST-KEY             TO WPHST-ENDBR-KEY.
030054*    MOVE 999                   TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                                TO WPHST-ENDBR-PCHST-SEQ-NUM.
023436
023436     PERFORM  PHST-1000-BROWSE
023436         THRU PHST-1000-BROWSE-X.
023436
023436     PERFORM  PHST-2000-READ-NEXT
023436         THRU PHST-2000-READ-NEXT-X.
023436
023436     IF  NOT WPHST-IO-OK
023436         MOVE E0661-EFF-DATE         TO L1640-INTERNAL-DATE
023436         PERFORM  1640-2000-INTERNAL-TO-EXT
023436             THRU 1640-2000-INTERNAL-TO-EXT-X
023436         MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (1)
023436* MSG: NO POLICY CHANGE ACTIVITY FOUND TO UNDO FOR DATE @1
023436         MOVE 'CS06610032'           TO WGLOB-MSG-REF-INFO
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436         PERFORM  PHST-3000-END-BROWSE
023436             THRU PHST-3000-END-BROWSE-X
023436         SET WGLOB-RETURN-ERROR      TO TRUE
023436         GO  TO 4600-LOCATE-PHST-X
023436     END-IF.
023436*
023436*  FIND THE LATEST ACTIVE PHST RECORD
023436*
023436     PERFORM  PHST-2000-READ-NEXT
023436         THRU PHST-2000-READ-NEXT-X
023436         UNTIL WPHST-IO-EOF
023436           OR  (RPHST-POL-ACTV-TYP-ID = WS-PHST-ACTV-TYP-CD
023436           AND  RPHST-PCHST-STAT-ACTIVE)
023436*
023436*  IF PHST READ NOT FOUND, THERE IS A PROBLEM WITH THE PHST FILE
023436*  (LAP DATE IS INCORRECTLY SET)
023436*
023436     IF  WPHST-IO-EOF
023436         MOVE E0661-EFF-DATE         TO L1640-INTERNAL-DATE
023436         PERFORM  1640-2000-INTERNAL-TO-EXT
023436             THRU 1640-2000-INTERNAL-TO-EXT-X
023436         MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (1)
023436* MSG: NO POLICY CHANGE ACTIVITY FOUND TO UNDO FOR DATE @1
023436         MOVE 'CS06610032'           TO WGLOB-MSG-REF-INFO
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436         SET WGLOB-RETURN-ERROR      TO TRUE
023436     END-IF.
023436
023436     PERFORM  PHST-3000-END-BROWSE
023436         THRU PHST-3000-END-BROWSE-X.
023436
023436 4600-LOCATE-PHST-X.
023436     EXIT.
023436
023436*---------------------
023436 4700-UNDO-ON-REVERSAL.
023436*---------------------
023436
023436     PERFORM  POL-3000-UNLOCK
023436         THRU POL-3000-UNLOCK-X.
023436
023436     PERFORM  4750-1000-BUILD-PARM-INFO
023436         THRU 4750-1000-BUILD-PARM-INFO-X.
023436
023436     SET L4750-FCN-DRVR-SECONDARY          TO TRUE.
023436
023436     MOVE RPHST-PCHST-EFF-DT      TO L4750-EFF-DT
023436     MOVE RPHST-PCHST-SEQ-NUM     TO L4750-PCHST-SEQ-NUM
023436     SET L4750-PRCES-INCLUSIVE    TO TRUE.
023436     SET L4750-UNDO-PCHST-SEQ-YES TO TRUE.
023436
023436     IF  MIR-SUPRES-CNFRM-IND = 'Y'
023436          SET L4750-SUPPRESS-CONFIRM TO TRUE
023436     END-IF.
023436
023436     PERFORM  4750-1000-UNDO-PROCESSING
023436         THRU 4750-1000-UNDO-PROCESSING-X.
023436
023436     IF  NOT L4750-RETRN-OK
023436         SET WGLOB-RETURN-ERROR            TO TRUE
023436     END-IF.
023436
023436     MOVE  RPOL-REC-INFO            TO  HPOL-REC-INFO.
023436     MOVE  MIR-POL-ID-BASE          TO  WPOL-POL-ID-BASE.
023436     MOVE  MIR-POL-ID-SFX           TO  WPOL-POL-ID-SFX.
023436
023436     PERFORM  POL-1000-READ-FOR-UPDATE
023436         THRU POL-1000-READ-FOR-UPDATE-X.
023436
023436     MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.
023436
023436     IF  NOT WGLOB-GOOD-RETURN
023436         PERFORM  0289-1000-INIT-PARM-INFO
023436             THRU 0289-1000-INIT-PARM-INFO-X
023436         MOVE E0661-EFF-DATE    TO L0289-LO-PAC-DT
023436         MOVE E0661-EFF-DATE    TO L0289-LO-CRC-DT
023436         MOVE E0661-EFF-DATE    TO L0289-PROC-EFF-DT
023436         MOVE E0661-EFF-DATE    TO L0289-LO-DD2-DT
023436         PERFORM  0289-1000-OBTAIN-NXT-ACTV
023436             THRU 0289-1000-OBTAIN-NXT-ACTV-X
023436         IF  L0289-RETRN-OK
023436             MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
023436             MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
023436         ELSE
023436             MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
023436             MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
023436         END-IF
023436         PERFORM  POL-2000-REWRITE
023436             THRU POL-2000-REWRITE-X
023436         PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
023436             THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
023436     END-IF.
023436
023436 4700-UNDO-ON-REVERSAL-X.
023436     EXIT.


      *---------------
       7000-READ-POLICY.
      *---------------

           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO WPOL-POL-ID-SFX.

           IF  NOT MIR-DV-PRCES-STATE-CD = '3'
014221*        PERFORM  POL-1000-READ
014221*            THRU POL-1000-READ-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
           ELSE
014221*        PERFORM  POL-1000-READ-FOR-UPDATE
014221*            THRU POL-1000-READ-FOR-UPDATE-X
014221         PERFORM  POL-2000-UPDATE-TWRK-TS
014221             THRU POL-2000-UPDATE-TWRK-TS-X
014221        IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221            MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221            MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221            MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221            PERFORM  0260-1000-GENERATE-MESSAGE
014221                THRU 0260-1000-GENERATE-MESSAGE-X
014221            GO TO 7000-READ-POLICY-X
018763        END-IF
           END-IF.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-READ-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.
           SET L5400-CRCY-MSG-REQD TO TRUE.
016440     SET L5400-POL-XFER-UPDATE TO TRUE.

012624     IF RPOL-POL-SUSPENDED
012624*MSG:   POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
012624        MOVE 'XS00000240'      TO WGLOB-MSG-REF-INFO
012624        PERFORM 0260-1000-GENERATE-MESSAGE
012624         THRU   0260-1000-GENERATE-MESSAGE-X
012624         SET WGLOB-RETURN-ERROR TO TRUE
012624              GO TO 7000-READ-POLICY-X
012624     END-IF.
016440*    IF RPOL-POL-APPL-CTL-CD = 'NB'
016440     IF RPOL-POL-STAT-BEFORE-SETL
012624*MSG    PENDING POLICY - CANNOT MAINTAIN OR PROCESS
012624        MOVE 'XS00000238'       TO WGLOB-MSG-REF-INFO
012624        PERFORM 0260-1000-GENERATE-MESSAGE
012624           THRU 0260-1000-GENERATE-MESSAGE-X
012624         SET WGLOB-RETURN-ERROR TO TRUE
012624        GO TO 7000-READ-POLICY-X
012624     END-IF.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
012624*    OR  L5400-CTL-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 7000-READ-POLICY-X
           END-IF.

020463     IF  WS-BUS-FCN-RRIF-PYMT
020463         PERFORM  2735-1000-BUILD-PARM-INFO
020463             THRU 2735-1000-BUILD-PARM-INFO-X
020463         MOVE  RPOL-POL-ID   TO L2735-POL-ID
020463         PERFORM  2735-1000-GET-PRFL
020463             THRU 2735-1000-GET-PRFL-X
020463         IF L2735-RETRN-PRFL-FND
020463*MSG: THE RRIF PAYMENT ALLOC FOR POLICY (@1) MAY NOT MATCH THE
020463*     ALLOCATIONS DEFINED FOR THE PROFILE
020463            MOVE 'CS06610023'      TO WGLOB-MSG-REF-INFO
020463            PERFORM  0260-1000-GENERATE-MESSAGE
020463               THRU  0260-1000-GENERATE-MESSAGE-X
020463
020463             IF  WGLOB-MSG-SEVRTY-FATAL
020463                 SET WGLOB-RETURN-ERROR  TO TRUE
020463                 GO TO 7000-READ-POLICY-X
020463             END-IF
020463
020463         END-IF
020463     END-IF.
020463
           PERFORM  7110-READ-COVERAGES-IN
               THRU 7110-READ-COVERAGES-IN-X.

       7000-READ-POLICY-X.
           EXIT.

      *---------------
       7100-VALIDATE-CVG.
      *---------------

015768     IF  MIR-CVG-NUM = SPACES
015768         MOVE '00'              TO E0661-COV-X
015768     ELSE
015768         MOVE MIR-CVG-NUM       TO E0661-COV-X
015768     END-IF.

016686*    MOVE MIR-CVG-NUM           TO E0661-COV-X.
           IF  E0661-COV-NO NOT NUMERIC
007766*    OR E0661-COV-NO > 20
007766     OR E0661-COV-NO > WCVGM-MAX-WCVGS-NUM
007766*MSG: COVERAGE MUST BE 2 DIGITS FROM 00-20
007766*MSG: COVERAGE MUST BE 2 DIGITS FROM 00-@1
               MOVE 'CS06610020'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7100-VALIDATE-CVG-X
           END-IF.

016440     IF  WS-BUS-FCN-REDUCED-PAID-UP
016440     OR  WS-BUS-FCN-RPU-REVERSAL
016440     OR  WS-BUS-FCN-EXTENDED-TERM
016440     OR  WS-BUS-FCN-ETI-REVERSAL
016440         PERFORM  7102-CHECK-STAT-RPU-ETI
016440             THRU 7102-CHECK-STAT-RPU-ETI-X
016440         IF  WGLOB-MSG-SEVRTY-FATAL
016440             SET WGLOB-RETURN-ERROR    TO TRUE
016440             GO TO 7100-VALIDATE-CVG-X
016440         END-IF
016440     END-IF.
016440
020463     IF  WS-BUS-FCN-MAKE-PAID-UP
020463         PERFORM  2735-1000-BUILD-PARM-INFO
020463             THRU 2735-1000-BUILD-PARM-INFO-X
020463         MOVE  RPOL-POL-ID   TO L2735-POL-ID
020463         PERFORM  2735-1000-GET-PRFL
020463             THRU 2735-1000-GET-PRFL-X
020463         IF L2735-RETRN-PRFL-FND
020463         AND E0661-COV-X NOT = '00'
020463            MOVE '00'              TO MIR-CVG-NUM
020463*MSG: THIS POLICY CONTAINS A PROFILE, CANNOT CHANGE TYPE OF PLAN.
020463            MOVE 'CS06610021'      TO WGLOB-MSG-REF-INFO
020463            PERFORM  0260-1000-GENERATE-MESSAGE
020463               THRU  0260-1000-GENERATE-MESSAGE-X
020463            SET WGLOB-RETURN-ERROR    TO TRUE
020463            GO TO 7100-VALIDATE-CVG-X
020463         END-IF
020463     END-IF.
020463
       7100-VALIDATE-CVG-X.
           EXIT.

016440*-----------------------
016440 7102-CHECK-STAT-RPU-ETI.
016440*-----------------------

016440     IF  E0661-COV-X = '00'
016440         PERFORM
016440           VARYING WS-CVG FROM +1 BY +1
016440           UNTIL WS-CVG > RPOL-POL-CVG-REC-CTR-N
016440               IF  WCVGS-CVG-STAT-BEFORE-SETL (WS-CVG)
016440*MSG: PENDING COVERAGE - CANNOT BE MAINTAIN OR PROCESS
016440                   MOVE 'XS00000244'    TO WGLOB-MSG-REF-INFO
016440                   PERFORM  0260-1000-GENERATE-MESSAGE
016440                       THRU 0260-1000-GENERATE-MESSAGE-X
016440                   MOVE RPOL-POL-CVG-REC-CTR TO WS-CVG
016440               END-IF
016440         END-PERFORM
016440     ELSE
016440         IF  WCVGS-CVG-STAT-BEFORE-SETL (E0661-COV-NO)
016440*MSG: PENDING COVERAGE - CANNOT BE MAINTAIN OR PROCESS
016440             MOVE 'XS00000244'    TO WGLOB-MSG-REF-INFO
016440             PERFORM  0260-1000-GENERATE-MESSAGE
016440                 THRU 0260-1000-GENERATE-MESSAGE-X
016440         END-IF
016440     END-IF.

016440 7102-CHECK-STAT-RPU-ETI-X.
016440     EXIT.

      *---------------
       7110-READ-COVERAGES-IN.
      *---------------

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

       7110-READ-COVERAGES-IN-X.
           EXIT.

      *---------------
       7200-EDIT-NAME.
      *---------------
013578
013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE RPOL-POL-ID                   TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.

013578*    IF  MIR-DV-CLI-NM = SPACES
015768*    IF  MIR-DV-OWN-CLI-NM = SPACES
015768*MSG: OWNER'S LAST NAME MUST BE ENTERED
015768*        MOVE 'CS06610021'      TO WGLOB-MSG-REF-INFO
015768*        PERFORM  0260-1000-GENERATE-MESSAGE
015768*            THRU 0260-1000-GENERATE-MESSAGE-X
015768*        GO TO 7200-EDIT-NAME-X
015768*    END-IF.

013578*    MOVE MIR-DV-CLI-NM         TO E0661-OWNER-NAME.

       7200-EDIT-NAME-X.
           EXIT.

      *---------------
       7300-VALIDATE-SUBCODE.
      *---------------

           IF  MIR-DV-WP-TYP-CD = SPACES
           OR WS-BUS-FCN-PUT-ON-WAIVER
               MOVE MIR-DV-WP-TYP-CD  TO E0661-SUB-CODE
               GO TO 7300-VALIDATE-SUBCODE-X
           ELSE
               MOVE SPACES            TO MIR-DV-WP-TYP-CD
      *MSG: SUB CODE IGNORED - ONLY VALID FOR ENTER CODE 'POW'
               MOVE 'CS06610011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7300-VALIDATE-SUBCODE-X.
           EXIT.

      *---------------
       7400-VALIDATE-DATE.
      *---------------

016686*    IF  MIR-APPL-CTL-PRCES-DT NOT = SPACES
016686     IF  MIR-DV-EFF-DT         NOT = SPACES
016686*        MOVE MIR-APPL-CTL-PRCES-DT
               MOVE MIR-DV-EFF-DT     TO  L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
      *MSG: INVALID DATE
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
016686*            MOVE MIR-APPL-CTL-PRCES-DT
016686             MOVE MIR-DV-EFF-DT TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 7400-VALIDATE-DATE-X
               END-IF
           ELSE
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
016686*                               TO MIR-APPL-CTL-PRCES-DT
016686                                TO MIR-DV-EFF-DT
           END-IF.

           MOVE L1640-INTERNAL-DATE   TO E0661-EFF-DATE.

           IF  WS-BUS-FCN-IMMED-ANN-PYMT
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               IF  E0661-EFF-DATE > WGLOB-PROCESS-DATE
      *MSG: EFFECTIVE DATE CANNOT BE IN THE FUTURE
                   MOVE 'CS06610004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       7400-VALIDATE-DATE-X.
           EXIT.

      *---------------
       7500-VALIDATE-AMOUNT.
      *---------------

           MOVE ZEROS                 TO E0661-FACE-AMT.

008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 2                     TO L0280-PRECISION.
008455     MOVE MIR-CVG-FACE-AMT      TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-CVG-FACE-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.

           IF WS-BUS-FCN-REDUCED-PAID-UP
           OR WS-BUS-FCN-EXTENDED-TERM
               CONTINUE
           ELSE
008455*        IF  MIR-CVG-FACE-AMT NOT = '000000000.00'
008455         IF  NOT L0280-OK
008455         OR  L0280-OUTPUT-DOLLAR NOT = ZERO
008455*            MOVE '000000000.00'        TO MIR-CVG-FACE-AMT
020874*            MOVE ZERO          TO L0290-INPUT-NUMBER
020874             MOVE ZERO          TO L0290-INPUT-V02
008455             PERFORM 9600-FORMAT-FACE
008455                THRU 9600-FORMAT-FACE-X
      *MSG: FACE AMOUNT ONLY VALID FOR ENTER CODES RPU/ETI
                   MOVE 'CS06610001'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
               GO TO 7500-VALIDATE-AMOUNT-X
           END-IF.

008455*    MOVE 'N'                       TO L0280-SIGN-IND.
008455*    MOVE 2                         TO L0280-PRECISION.
008455*    MOVE 9                         TO L0280-LENGTH.
008455*    MOVE 12                        TO L0280-INPUT-SIZE.
008455*    MOVE MIR-CVG-FACE-AMT                  TO L0280-INPUT-DATA.

008455*    PERFORM  0280-1000-NUMERIC-EDIT
008455*        THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO E0661-FACE-AMT
008455*        MOVE E0661-FACE-AMT         TO WS-IN-S9V2
008455*        MOVE WS-IN-S9V2-X          TO MIR-CVG-FACE-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         PERFORM  9600-FORMAT-FACE
008455             THRU 9600-FORMAT-FACE-X
           ELSE
      *MSG: FACE AMOUNT MUST BE NUMERIC
               MOVE 'CS06610007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7500-VALIDATE-AMOUNT-X.
           EXIT.

      *---------------
       7600-VALIDATE-EFF-DT.
      *---------------

           IF  MIR-CVG-MAT-XPRY-DT = SPACES
               GO TO 7600-VALIDATE-EFF-DT-X
           END-IF.

           IF  WS-BUS-FCN-EXTENDED-TERM
               CONTINUE
           ELSE
               MOVE SPACES            TO MIR-CVG-MAT-XPRY-DT
      *MSG: EXPIRY DATE ONLY VALID FOR ENTER CODE 'ETI'
               MOVE 'CS06610022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7600-VALIDATE-EFF-DT-X
           END-IF.

           MOVE MIR-CVG-MAT-XPRY-DT   TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      *MSG: INVALID DATE
               MOVE 'XS00000036'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-MAT-XPRY-DT
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO E0661-EXP-DATE
           END-IF.

       7600-VALIDATE-EFF-DT-X.
           EXIT.

012137*--------------------
012137 7700-VALIDATE-SUPCNF.
012137*--------------------

012137     IF   MIR-SUPRES-CNFRM-IND NOT = SPACES
012137          IF   MIR-SUPRES-CNFRM-IND NOT = 'Y'
012137          AND  MIR-SUPRES-CNFRM-IND NOT = 'N'
012137*MSG: SUPPRESS CONFIRMATION STATEMENT INVALID. ENTER 'Y' OR 'N'
012137               MOVE 'CS06614214'             TO WGLOB-MSG-REF-INFO
012137               PERFORM  0260-1000-GENERATE-MESSAGE
012137                   THRU 0260-1000-GENERATE-MESSAGE-X
012137               MOVE  1          TO WGLOB-MSG-ERROR-SW
012137          END-IF
012137     ELSE
012137               MOVE 'N'         TO MIR-SUPRES-CNFRM-IND
012137     END-IF.

012137     IF  WS-BUS-FCN-ANNIVERSARY
012137         CONTINUE
012137     ELSE
012137         IF   MIR-SUPRES-CNFRM-IND NOT = SPACES
012137         AND  MIR-SUPRES-CNFRM-IND NOT = 'N'
012137*MSG: SUPPRESS CONFIRMATION STATEMENT INVALID. ENTER 'Y' OR 'N'
012137             MOVE 'CS06610029'  TO WGLOB-MSG-REF-INFO
012137             PERFORM  0260-1000-GENERATE-MESSAGE
012137                 THRU 0260-1000-GENERATE-MESSAGE-X
012137             MOVE 'N'           TO MIR-SUPRES-CNFRM-IND
012137         END-IF
012137     END-IF.

012137 7700-VALIDATE-SUPCNF-X.
012137     EXIT.
      *
016108*---------------------
016108 7800-VAL-DATE-OF-DTH.
016108*---------------------
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     IF  WS-BUS-FCN-RPU-QUOTE
016108     OR  WS-BUS-FCN-ETI-QUOTE
016108     OR  WS-BUS-FCN-AUTO-PREM-PYMT
016108         GO TO 7800-VAL-DATE-OF-DTH-X
016108     END-IF.
016108
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     IF  WS-BUS-FCN-APL
016108     OR  WS-BUS-FCN-IMMED-ANN-PYMT
016108         MOVE WGLOB-PROCESS-DATE TO L0985-EFF-DT
016108     ELSE
016108         MOVE E0661-EFF-DATE     TO L0985-EFF-DT
016108     END-IF.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE  1                 TO WGLOB-MSG-ERROR-SW
016108     END-IF.
016108
016108 7800-VAL-DATE-OF-DTH-X.
016108     EXIT.
016108
      *---------------
       9100-BLANK-DATA-FIELDS.
      *---------------

013578*    MOVE SPACES                TO MIR-DV-CLI-NM.
013578     MOVE SPACES                TO MIR-DV-OWN-CLI-NM.
           MOVE SPACES                TO MIR-BUS-FCN-ID.
           MOVE SPACES                TO MIR-DV-WP-TYP-CD.
           MOVE WGLOB-PROCESS-DATE    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
016686*    MOVE L1640-EXTERNAL-DATE   TO MIR-APPL-CTL-PRCES-DT.
016686     MOVE L1640-EXTERNAL-DATE   TO MIR-DV-EFF-DT.
           MOVE ZEROES                TO MIR-CVG-NUM.
008455*    MOVE '000000000.00'         TO MIR-CVG-FACE-AMT.
020874*    MOVE 0                     TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     PERFORM  9600-FORMAT-FACE
008455         THRU 9600-FORMAT-FACE-X.
           MOVE SPACES                TO MIR-CVG-MAT-XPRY-DT.


       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *---------------
       9300-SETUP-MSIN-REFERENCE.
      *---------------
      *
      * MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      * TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE            TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.
           MOVE MIR-CVG-NUM           TO WGLOB-REF-COVERAGE-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.


      *
018633***************************
018633*9500-BUILD-TWRK-KEY.
018633***************************
018633*
018633*    MOVE WS-TWRK-KEY           TO L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                 TO L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM      TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*
008455******************
008455 9600-FORMAT-FACE.
008455******************
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FACE-AMT.
008455 9600-FORMAT-FACE-X.
008455     EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0361-0000-INIT-PARM-INFO
025970         THRU 0361-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1070-0000-INIT-PARM-INFO
025970         THRU 1070-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1080-0000-INIT-PARM-INFO
025970         THRU 1080-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1210-0000-INIT-PARM-INFO
025970         THRU 1210-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1220-0000-INIT-PARM-INFO
025970         THRU 1220-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1230-0000-INIT-PARM-INFO
025970         THRU 1230-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1240-0000-INIT-PARM-INFO
025970         THRU 1240-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1350-0000-INIT-PARM-INFO
025970         THRU 1350-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1360-0000-INIT-PARM-INFO
025970         THRU 1360-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1400-0000-INIT-PARM-INFO
025970         THRU 1400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2210-0000-INIT-PARM-INFO
025970         THRU 2210-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2220-0000-INIT-PARM-INFO
025970         THRU 2220-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2510-0000-INIT-PARM-INFO
025970         THRU 2510-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7000-0000-INIT-PARM-INFO
025970         THRU 7000-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE INDICES-FOR-661.
025970     INITIALIZE SWITCHES-FOR-661.
025970     INITIALIZE DISPLAY-FIELDS-FOR-661.
025970     INITIALIZE WS-WORK-AREA.
025970     SET TRANSACTION-NAME-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
008455*

018633***************************
018633*9700-RETRIEVE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM 8090-2000-RETRIEVE-TWRK
018633*       THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*
018633***************************
018633*9800-WRITE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    MOVE 300           TO L8090-AREA-LEN.
018633*
018633*    PERFORM 8090-1000-WRITE-TWRK
018633*       THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*
018633***************************
018633*9900-DELETE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*
018633*    PERFORM 8090-3000-DELETE-TWRK
018633*       THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      ***************************
      *  PROCESSING COPYBOOKS
      ***************************
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
       COPY NCPPCVGS.
       COPY NCPPCVGR.
      *
025970 COPY XCPS1670.
       COPY CCPSPGA.
      *
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
014660*COPY XCPPMEXT.
      *
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
      *************************
      *  LINKAGE PROCESSING COPYBOOKS
      *************************
018764*COPY CCCL0201.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0201.
018764 COPY CCPL0201.

016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.

       COPY CCPS0361.
018764*COPY CCCL0361.
018764 COPY CCPL0361.

025970 COPY CCPS0620.
013578 COPY CCPL0620.

557665*COPY CCPS1060.
557665*COPY CCCL1060.

016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
      *
       COPY CCPS1070.
018764*COPY CCCL1070.
018764 COPY CCPL1070.

       COPY CCPS1080.
018764*COPY CCCL1080.
018764 COPY CCPL1080.
      *
       COPY CCPS1210.
018764*COPY CCCL1210.
018764 COPY CCPL1210.

       COPY CCPS1220.
018764*COPY CCCL1220.
018764 COPY CCPL1220.

       COPY CCPS1230.
018764*COPY CCCL1230.
018764 COPY CCPL1230.

       COPY CCPS1240.
018764*COPY CCCL1240.
018764 COPY CCPL1240.
      *
       COPY CCPS1350.
018764*COPY CCCL1350.
018764 COPY CCPL1350.
      *
       COPY CCPS1360.
018764*COPY CCCL1360.
018764 COPY CCPL1360.

       COPY CCPS1400.
018764*COPY CCCL1400.
018764 COPY CCPL1400.

       COPY CCPS2210.
018764*COPY CCCL2210.
018764 COPY CCPL2210.
      *
       COPY CCPS2220.
018764*COPY CCCL2220.
018764 COPY CCPL2220.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.

020463 COPY CCPL2735.
020463 COPY CCPS2735.

       COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.
      *
016503 COPY CCPS4780.
018764*COPY CCCL4780.
018764 COPY CCPL4780.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.


       COPY CCPS7000.
018764*COPY CCCL7000.
018764 COPY CCPL7000.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
023436 COPY XCPL1660.
025970 COPY XCPS1680.
       COPY XCPL1680.
      *
557756 COPY XCPS2510.
018764*COPY XCCL2510.
018764 COPY XCPL2510.
      *
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      *
      ********************************
      *  FILE I/O PROCESSING MODULES
      ********************************
       COPY CCPNCVG.
       COPY CCPUCVG.
      *
       COPY CCPNPOL.
       COPY CCPUPOL.

023436 COPY CCPBPHST.
      *
      ********************************
      *  ERROR HANDLING ROUTINES
      ********************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      *                  END OF PROGRAM CSOM0661                     **
      *****************************************************************
