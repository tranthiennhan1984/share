      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7712.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7712                                         **
      **  REMARKS:  THIS MODULE PERFORMS USRP RECORD UPDATE          **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021367**  6.4       CHANGE FIELD NAMES FROM OTH TO OTHR              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023434**  6.5       EXPAND ADDRESS LINE                              **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7712'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-UPDATE        VALUE '7712'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '7710'.
           05  WS-USRP-TAX-YR               PIC 9(4).
           05  WS-USRP-SEQ-NUM              PIC 9(4).
           05  WS-MIR-ZERO-AMT              PIC X(19).
           05  WS-MIR-ZERO-TAX-AMT          PIC X(13).
023434     05  WS-LENGTH                    PIC 9(04).
025970*    05  WS-MAX-LENGTH                PIC 9(04) VALUE 40.
023434     05  WS-ADDRESS-LINE.
023434         10  WS-ADDR-CHAR             PIC X(01) OCCURS 128.
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '7710'.
025970     05  WS-MAX-LENGTH                PIC 9(04).
025970         88  WS-MAX-LENGTH-DEFAULT    VALUE 40.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY CCWWLOCK.
       COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWCLI.
       COPY CCFRCLI.
      /
       COPY CCFWUSRP.
       COPY CCFRUSRP.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY CCWL0620.
       COPY CCWL2430.
       COPY CCWL2440.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
       COPY XCWL8960.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7712.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID    TO WGLOB-MSG-PARM (2)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-UPDATE.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  5100-LOCK-USRP-RECORD
               THRU 5100-LOCK-USRP-RECORD-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  8000-EDIT-DATA-FIELDS
               THRU 8000-EDIT-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  5300-GET-CLI-NM
                   THRU 5300-GET-CLI-NM-X
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  5200-UPDATE-USRP
               THRU 5200-UPDATE-USRP-X.

       2000-UPDATE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  4110-EDIT-POL-ID
               THRU 4110-EDIT-POL-ID-X.

           PERFORM  4120-EDIT-TAX-YR
               THRU 4120-EDIT-TAX-YR-X.

           PERFORM  4130-EDIT-SEQ-NO
               THRU 4130-EDIT-SEQ-NO-X.

       2100-VALIDATE-KEYS-X.
           EXIT.


      *-----------------
       4110-EDIT-POL-ID.
      *-----------------

           MOVE MIR-POL-ID           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
      *MSG:    POLICY DOES NOT EXIST
               MOVE 'CS77120001'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
           END-IF.

       4110-EDIT-POL-ID-X.
           EXIT.

      *-----------------
       4120-EDIT-TAX-YR.
      *-----------------

           MOVE MIR-USRP-TAX-YR             TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-TAX-YR   TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-USRP-TAX-YR
           ELSE
      *MSG: INVALID TAX YEAR
               MOVE 'CS77120020'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4120-EDIT-TAX-YR-X.
           EXIT.


      *-----------------
       4130-EDIT-SEQ-NO.
      *-----------------

           MOVE MIR-USRP-SEQ-NUM      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-SEQ-NUM
                                            TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-USRP-SEQ-NUM
           ELSE
      *MSG: INVALID RECEIPT SEQUENCE NUMBER
               MOVE 'CS77120002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       4130-EDIT-SEQ-NO-X.
           EXIT.


      *----------------------
       5100-LOCK-USRP-RECORD.
      *----------------------

           MOVE MIR-POL-ID                  TO WUSRP-POL-ID.
           MOVE WS-USRP-TAX-YR              TO WUSRP-USRP-TAX-YR.
           MOVE WS-USRP-SEQ-NUM             TO WUSRP-USRP-SEQ-NUM.

           PERFORM  USRP-2000-UPDATE-TWRK-TS
               THRU USRP-2000-UPDATE-TWRK-TS-X.

           IF  NOT WUSRP-IO-OK
      *MSG: USRP (@1) NOT FOUND
               MOVE 'CS77120003'            TO WGLOB-MSG-REF-INFO
               MOVE WUSRP-KEY               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 5100-LOCK-USRP-RECORD-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2
               MOVE 'XS00000303'            TO WGLOB-MSG-REF-INFO
               MOVE 'USRP'                  TO WGLOB-MSG-PARM (1)
               MOVE WUSRP-KEY               TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 5100-LOCK-USRP-RECORD-X
           END-IF.

           IF RUSRP-USRP-RPT-ACTV
      *MSG: INFORMATION HAS ALREADY BEEN REPORTED
               MOVE 'CS77120050'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1               TO WGLOB-MSG-ERROR-SW
               END-IF
           END-IF.

       5100-LOCK-USRP-RECORD-X.
           EXIT.


      *------------------
       5200-UPDATE-USRP.
      *------------------

           PERFORM  USRP-2000-REWRITE
               THRU USRP-2000-REWRITE-X.

           PERFORM  USRP-1000-READ-TWRK-TS
               THRU USRP-1000-READ-TWRK-TS-X.

       5200-UPDATE-USRP-X.
           EXIT.


      *----------------
       5300-GET-CLI-NM.
      *----------------

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           INITIALIZE L0620-INPUT-PARM-INFO.

           IF  L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
           END-IF.

           MOVE L2430-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME          TO MIR-DV-OWN-CLI-NM.

       5300-GET-CLI-NM-X.
           EXIT.


      *---------------
       7000-BUILD-KEYS.
      *---------------

           MOVE MIR-POL-ID            TO WUSRP-POL-ID.
           MOVE WS-USRP-TAX-YR        TO WUSRP-USRP-TAX-YR.
           MOVE WS-USRP-SEQ-NUM       TO WUSRP-USRP-SEQ-NUM.

       7000-BUILD-KEYS-X.
           EXIT.


      *----------------------------
       8000-EDIT-DATA-FIELDS.
      *----------------------------

           PERFORM  8110-EDIT-CLI-ID
               THRU 8110-EDIT-CLI-ID-X.

           PERFORM  8120-EDIT-USRP-PRT-STAT-CD
               THRU 8120-EDIT-USRP-PRT-STAT-CD-X.

           PERFORM  8130-EDIT-USRP-STAT-CD
               THRU 8130-EDIT-USRP-STAT-CD-X.

           PERFORM  8140-EDIT-USRP-RPT-CD
               THRU 8140-EDIT-USRP-RPT-CD-X.

           PERFORM  8150-EDIT-USRP-RETRN-TYP-CD
               THRU 8150-EDIT-USRP-RETRN-TYP-CD-X.

           PERFORM  8160-EDIT-USRP-PNSN-QUALF-CD
               THRU 8160-EDIT-USRP-PNSN-QUALF-CD-X.

           PERFORM  8170-EDIT-USRP-TAX-ID-TYP-CD
               THRU 8170-EDIT-USRP-TAX-ID-TYP-CD-X.

           PERFORM  8180-EDIT-USRP-FRGN-CTRY-IND
               THRU 8180-EDIT-USRP-FRGN-CTRY-IND-X.

           PERFORM  8190-EDIT-USRP-IRS-DSTRB-CD
               THRU 8190-EDIT-USRP-IRS-DSTRB-CD-X.

           PERFORM  8200-EDIT-USRP-TAX-DTRMN-IND
               THRU 8200-EDIT-USRP-TAX-DTRMN-IND-X.

           PERFORM  8210-EDIT-USRP-IRA-SEP-IND
               THRU 8210-EDIT-USRP-IRA-SEP-IND-X.

           PERFORM  8220-EDIT-USRP-TOT-DSTRB-IND
               THRU 8220-EDIT-USRP-TOT-DSTRB-IND-X.

           PERFORM  8230-EDIT-USRP-COMB-RPT-CD
               THRU 8230-EDIT-USRP-COMB-RPT-CD-X.

           PERFORM  8240-EDIT-USRP-TIN-NOTI-CD
               THRU 8240-EDIT-USRP-TIN-NOTI-CD-X.

           PERFORM  8250-EDIT-USRP-SRC-CD
               THRU 8250-EDIT-USRP-SRC-CD-X.

           PERFORM  8270-EDIT-USRP-DSTRB-PCT
               THRU 8270-EDIT-USRP-DSTRB-PCT-X.

           PERFORM  8280-EDIT-USRP-LTAXWH-AMT
               THRU 8280-EDIT-USRP-LTAXWH-AMT-X.

           PERFORM  8290-EDIT-USRP-OTH-TAXWH-AMT
               THRU 8290-EDIT-USRP-OTH-TAXWH-AMT-X.

           PERFORM  8300-EDIT-USRP-PRT-DT
               THRU 8300-EDIT-USRP-PRT-DT-X.

           PERFORM  8310-EDIT-USRP-CRNT-LOC-CD
               THRU 8310-EDIT-USRP-CRNT-LOC-CD-X.

           PERFORM  8400-EDIT-AMT-FIELDS
               THRU 8400-EDIT-AMT-FIELDS-X.

           MOVE MIR-USRP-CRNT-LOC-CD   TO RUSRP-USRP-CRNT-LOC-CD.
           MOVE MIR-USRP-CITY-NM-TXT   TO RUSRP-USRP-CITY-NM-TXT.
           MOVE MIR-USRP-PSTL-CD       TO RUSRP-USRP-PSTL-CD.
           MOVE MIR-USRP-CLI-TAX-ID    TO RUSRP-USRP-CLI-TAX-ID.
           MOVE MIR-USRP-NM-LN-1-TXT   TO RUSRP-USRP-NM-LN-1-TXT.
           MOVE MIR-USRP-NM-LN-2-TXT   TO RUSRP-USRP-NM-LN-2-TXT.
           MOVE MIR-USRP-ADDR-LN-TXT   TO RUSRP-USRP-ADDR-LN-TXT.
           MOVE MIR-USRP-FRGN-CTRY-TXT TO RUSRP-USRP-FRGN-CTRY-TXT.
           MOVE MIR-USRP-SPCL-DATA-TXT TO RUSRP-USRP-SPCL-DATA-TXT.
023437     MOVE MIR-USRP-STATE-LOC-CD  TO RUSRP-USRP-STATE-LOC-CD.


       8000-EDIT-DATA-FIELDS-X.
           EXIT.


      *-----------------
       8110-EDIT-CLI-ID.
      *-----------------

           IF  MIR-CLI-ID = RUSRP-CLI-ID
               GO TO 8110-EDIT-CLI-ID-X
           END-IF.

           IF  MIR-CLI-ID = SPACE
               MOVE SPACE                   TO RUSRP-CLI-ID
               GO TO 8110-EDIT-CLI-ID-X
           END-IF.

           MOVE MIR-CLI-ID                  TO WCLI-CLI-ID.

           PERFORM  CLI-1000-READ
               THRU CLI-1000-READ-X.

           IF  NOT WCLI-IO-OK
      *MSG: CLIENT (@1) NOT FOUND
               MOVE 'CS77120004'            TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID              TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8110-EDIT-CLI-ID-X
           END-IF.

           MOVE MIR-CLI-ID                  TO RUSRP-CLI-ID.

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.

           MOVE MIR-CLI-ID                  TO L2440-CLI-ID.
           MOVE 'PR'                        TO L2440-CLI-ADDR-TYP-CD.

           PERFORM  2440-1000-PRIMARY-ADDRESS
               THRU 2440-1000-PRIMARY-ADDRESS-X

           IF  NOT L2440-RETRN-OK
      *MSG: CLIENT (@1) ADDRESS NOT FOUND
               MOVE 'CS77120005'            TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID              TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8110-EDIT-CLI-ID-X
           END-IF.

           MOVE RCLI-CLI-TAX-ID             TO MIR-USRP-CLI-TAX-ID.
           MOVE RCLI-CLI-TAX-ID             TO RUSRP-USRP-CLI-TAX-ID.

023434     MOVE ZEROS                       TO WS-LENGTH.
023434     MOVE ZEROS                       TO J.

023434*    MOVE L2440-CLI-ADDR-LN-1-TXT     TO MIR-USRP-ADDR-LN-TXT.
023434*    MOVE L2440-CLI-ADDR-LN-1-TXT     TO RUSRP-USRP-ADDR-LN-TXT.
023434     MOVE L2440-CLI-ADDR-LN-1-TXT-TXT TO MIR-USRP-ADDR-LN-TXT.
023434     MOVE L2440-CLI-ADDR-LN-1-TXT-TXT TO RUSRP-USRP-ADDR-LN-TXT.
023434     MOVE L2440-CLI-ADDR-LN-1-TXT     TO WS-ADDRESS-LINE.
023434     PERFORM  8111-ADDR-LENGTH-CALC
023434         THRU 8111-ADDR-LENGTH-CALC-X.
023434
023434* IF THE LENGTH OF THE ADDRESS LINE IS GREATER THAN 40
023434* CHARACTERS SEND A WARNING MESSAGE TO THE USER
023434*
023434     IF  WS-LENGTH   >  WS-MAX-LENGTH
023434* MSG: CLIENT'S ADDRESS LONGER THAN ALLOWED BY IRS.
023434*      EXCESS HAS BEEN REMOVED.
023434         MOVE 'CS77120033'            TO WGLOB-MSG-REF-INFO
023434         PERFORM  0260-1000-GENERATE-MESSAGE
023434             THRU 0260-1000-GENERATE-MESSAGE-X
023434     END-IF.

           MOVE L2440-CLI-CRNT-LOC-CD       TO MIR-USRP-CRNT-LOC-CD.
           MOVE L2440-CLI-CRNT-LOC-CD       TO RUSRP-USRP-CRNT-LOC-CD.

           MOVE L2440-CLI-CITY-NM-TXT       TO MIR-USRP-CITY-NM-TXT.
           MOVE L2440-CLI-CITY-NM-TXT       TO RUSRP-USRP-CITY-NM-TXT.

           MOVE L2440-CLI-PSTL-CD           TO MIR-USRP-PSTL-CD.
           MOVE L2440-CLI-PSTL-CD           TO RUSRP-USRP-PSTL-CD.


       8110-EDIT-CLI-ID-X.
           EXIT.
      /
023434*----------------------
023434 8111-ADDR-LENGTH-CALC.
023434*----------------------
023434* CALCULATE THE LENGTH OF THE ADDRESS LINE
023434*
023434     PERFORM
023434         VARYING I FROM 128 BY -1
023434          UNTIL WS-ADDR-CHAR(I)  NOT = SPACE
023434          OR I < 1
023434
023434         IF  WS-ADDR-CHAR(I) = SPACE
023434             COMPUTE J = J + 1
023434         END-IF
023434
023434     END-PERFORM.
023434
023434     COMPUTE WS-LENGTH            = 128 - J.
023434
023434 8111-ADDR-LENGTH-CALC-X.
023434     EXIT.
023434/
      *---------------------------
       8120-EDIT-USRP-PRT-STAT-CD.
      *---------------------------

           IF  MIR-USRP-PRT-STAT-CD = RUSRP-USRP-PRT-STAT-CD
               GO TO 8120-EDIT-USRP-PRT-STAT-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-PRT-STAT-CD'        TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-PRT-STAT-CD      TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID PRINT STATUS
               MOVE 'CS77120006'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-PRT-STAT-CD      TO RUSRP-USRP-PRT-STAT-CD.

       8120-EDIT-USRP-PRT-STAT-CD-X.
           EXIT.


      *-----------------------
       8130-EDIT-USRP-STAT-CD.
      *-----------------------

           IF  MIR-USRP-STAT-CD = RUSRP-USRP-STAT-CD
               GO TO 8130-EDIT-USRP-STAT-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-STAT-CD'            TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-STAT-CD          TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID RECORD STATUS
               MOVE 'CS77120007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-STAT-CD          TO RUSRP-USRP-STAT-CD.

       8130-EDIT-USRP-STAT-CD-X.
           EXIT.


      *----------------------
       8140-EDIT-USRP-RPT-CD.
      *----------------------

           IF  MIR-USRP-RPT-CD = RUSRP-USRP-RPT-CD
               GO TO 8140-EDIT-USRP-RPT-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-RPT-CD'             TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-RPT-CD           TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID REPORT STATUS
               MOVE 'CS77120008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-RPT-CD           TO RUSRP-USRP-RPT-CD.

       8140-EDIT-USRP-RPT-CD-X.
           EXIT.


      *----------------------------
       8150-EDIT-USRP-RETRN-TYP-CD.
      *----------------------------

           IF  MIR-USRP-RETRN-TYP-CD = RUSRP-USRP-RETRN-TYP-CD
               GO TO 8150-EDIT-USRP-RETRN-TYP-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-RETRN-TYP-CD'       TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-RETRN-TYP-CD     TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID RETURN TYPE
               MOVE 'CS77120009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-RETRN-TYP-CD      TO RUSRP-USRP-RETRN-TYP-CD.

       8150-EDIT-USRP-RETRN-TYP-CD-X.
           EXIT.


      *----------------------------
       8160-EDIT-USRP-PNSN-QUALF-CD.
      *----------------------------

           IF  MIR-USRP-PNSN-QUALF-CD = RUSRP-USRP-PNSN-QUALF-CD
               GO TO 8160-EDIT-USRP-PNSN-QUALF-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-PNSN-QUALF-CD'      TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-PNSN-QUALF-CD    TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID TAX ACCOUNT TYPE
               MOVE 'CS77120010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-PNSN-QUALF-CD    TO RUSRP-USRP-PNSN-QUALF-CD.

       8160-EDIT-USRP-PNSN-QUALF-CD-X.
           EXIT.


      *----------------------------
       8170-EDIT-USRP-TAX-ID-TYP-CD.
      *----------------------------

           IF  MIR-USRP-TAX-ID-TYP-CD = RUSRP-USRP-TAX-ID-TYP-CD
               GO TO 8170-EDIT-USRP-TAX-ID-TYP-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-TAX-ID-TYP-CD'      TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-TAX-ID-TYP-CD    TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID TAX ID TYPE
               MOVE 'CS77120011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-TAX-ID-TYP-CD    TO RUSRP-USRP-TAX-ID-TYP-CD.

       8170-EDIT-USRP-TAX-ID-TYP-CD-X.
           EXIT.


      *----------------------------
       8180-EDIT-USRP-FRGN-CTRY-IND.
      *----------------------------

           IF  MIR-USRP-FRGN-CTRY-IND = RUSRP-USRP-FRGN-CTRY-IND
               GO TO 8180-EDIT-USRP-FRGN-CTRY-IND-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-FRGN-CTRY-IND'      TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-FRGN-CTRY-IND    TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID FORIEGN COUNTRY INDICATOR
               MOVE 'CS77120012'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-FRGN-CTRY-IND    TO RUSRP-USRP-FRGN-CTRY-IND.

       8180-EDIT-USRP-FRGN-CTRY-IND-X.
           EXIT.


      *----------------------------
       8190-EDIT-USRP-IRS-DSTRB-CD.
      *----------------------------

           IF  MIR-USRP-IRS-DSTRB-CD = RUSRP-USRP-IRS-DSTRB-CD
               GO TO 8190-EDIT-USRP-IRS-DSTRB-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USTX-IRS-DSTRB-CD'       TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-IRS-DSTRB-CD     TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID DISTRIBUTION CODE
               MOVE 'CS77120013'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-IRS-DSTRB-CD     TO RUSRP-USRP-IRS-DSTRB-CD.

       8190-EDIT-USRP-IRS-DSTRB-CD-X.
           EXIT.


      *----------------------------
       8200-EDIT-USRP-TAX-DTRMN-IND.
      *----------------------------

           IF  MIR-USRP-TAX-DTRMN-IND = RUSRP-USRP-TAX-DTRMN-IND
               GO TO 8200-EDIT-USRP-TAX-DTRMN-IND-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-TAX-DTRMN-IND'      TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-TAX-DTRMN-IND    TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID TAXABLE AMOUNT NOT DETERMINED INDICATOR
               MOVE 'CS77120014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-TAX-DTRMN-IND    TO RUSRP-USRP-TAX-DTRMN-IND.

       8200-EDIT-USRP-TAX-DTRMN-IND-X.
           EXIT.


      *--------------------------
       8210-EDIT-USRP-IRA-SEP-IND.
      *--------------------------

           IF  MIR-USRP-TAX-DTRMN-IND = RUSRP-USRP-TAX-DTRMN-IND
               GO TO 8210-EDIT-USRP-IRA-SEP-IND-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-IRA-SEP-IND'        TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-IRA-SEP-IND      TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID IRA/SEP/SIMPLE INDICATOR
               MOVE 'CS77120015'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-IRA-SEP-IND      TO RUSRP-USRP-IRA-SEP-IND.

       8210-EDIT-USRP-IRA-SEP-IND-X.
           EXIT.


      *----------------------------
       8220-EDIT-USRP-TOT-DSTRB-IND.
      *----------------------------

           IF  MIR-USRP-TOT-DSTRB-IND = RUSRP-USRP-TOT-DSTRB-IND
               GO TO 8220-EDIT-USRP-TOT-DSTRB-IND-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-TOT-DSTRB-IND'      TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-TOT-DSTRB-IND    TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID TOTAL DISTRIBUTION INDICATOR
               MOVE 'CS77120016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-TOT-DSTRB-IND     TO RUSRP-USRP-TOT-DSTRB-IND.

       8220-EDIT-USRP-TOT-DSTRB-IND-X.
           EXIT.

      *---------------------------
       8230-EDIT-USRP-COMB-RPT-CD.
      *---------------------------

           IF  MIR-USRP-COMB-RPT-CD = RUSRP-USRP-COMB-RPT-CD
               GO TO 8230-EDIT-USRP-COMB-RPT-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-COMB-RPT-CD'        TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-COMB-RPT-CD      TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID COMBINED FEDERAL/STATE CODE
               MOVE 'CS77120017'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-COMB-RPT-CD       TO RUSRP-USRP-COMB-RPT-CD.

       8230-EDIT-USRP-COMB-RPT-CD-X.
           EXIT.


      *---------------------------
       8240-EDIT-USRP-TIN-NOTI-CD.
      *---------------------------

           IF  MIR-USRP-TIN-NOTI-CD = RUSRP-USRP-TIN-NOTI-CD
               GO TO 8240-EDIT-USRP-TIN-NOTI-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-TIN-NOTI-CD'        TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-TIN-NOTI-CD      TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID SECOND TIN NOTICE
               MOVE 'CS77120018'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-TIN-NOTI-CD      TO RUSRP-USRP-TIN-NOTI-CD.

       8240-EDIT-USRP-TIN-NOTI-CD-X.
           EXIT.


      *----------------------
       8250-EDIT-USRP-SRC-CD.
      *----------------------

           IF  MIR-USRP-SRC-CD = RUSRP-USRP-SRC-CD
               GO TO 8250-EDIT-USRP-SRC-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-SRC-CD'            TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-SRC-CD          TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID REPORT GENERATION CODE
               MOVE 'CS77120019'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-SRC-CD          TO RUSRP-USRP-SRC-CD.

       8250-EDIT-USRP-SRC-CD-X.
           EXIT.


      *-------------------------
       8270-EDIT-USRP-DSTRB-PCT.
      *-------------------------

           IF MIR-USRP-DSTRB-PCT = SPACE
              GO TO 8270-EDIT-USRP-DSTRB-PCT-X
           END-IF.


           MOVE MIR-USRP-DSTRB-PCT          TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-DSTRB-PCT TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO RUSRP-USRP-DSTRB-PCT
           ELSE
      *MSG: INVALID PERCENTAGE OF TOTAL DISTRIBUTION
               MOVE 'CS77120046'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8270-EDIT-USRP-DSTRB-PCT-X.
           EXIT.


      *--------------------------
       8280-EDIT-USRP-LTAXWH-AMT.
      *--------------------------

           MOVE MIR-USRP-LTAXWH-AMT          TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-LTAXWH-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-LTAXWH-AMT
           ELSE
      *MSG: INVALID STATE INCOME TAX WITHHELD AMOUNT
               MOVE 'CS77120047'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8280-EDIT-USRP-LTAXWH-AMT-X.
           EXIT.



      *-----------------------------
       8290-EDIT-USRP-OTH-TAXWH-AMT.
      *-----------------------------

021367*    MOVE MIR-USRP-OTH-TAXWH-AMT       TO L0280-INPUT-DATA.
021367*    MOVE LENGTH OF MIR-USRP-OTH-TAXWH-AMT TO L0280-INPUT-SIZE.
021367     MOVE MIR-OTHR-TAXWH-AMT           TO L0280-INPUT-DATA.
021367     MOVE LENGTH OF MIR-OTHR-TAXWH-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
021367*        MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-OTH-TAXWH-AMT
021367         MOVE L0280-OUTPUT-V02        TO RUSRP-OTHR-TAXWH-AMT
           ELSE
      *MSG: INVALID LOCAL INCOME TAX WITHHELD AMOUNT
               MOVE 'CS77120048'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8290-EDIT-USRP-OTH-TAXWH-AMT-X.
           EXIT.


      *----------------------
       8300-EDIT-USRP-PRT-DT.
      *----------------------

           IF MIR-USRP-PRT-DT = SPACE
              MOVE WWKDT-ZERO-DT        TO RUSRP-USRP-PRT-DT
              GO TO 8300-EDIT-USRP-PRT-DT-X
           END-IF.

           MOVE MIR-USRP-PRT-DT         TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
      *MSG: INVALID PRINT DATE
               MOVE 'CS77120049'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                       TO RUSRP-USRP-PRT-DT
           END-IF.

       8300-EDIT-USRP-PRT-DT-X.
           EXIT.

      *---------------------------
       8310-EDIT-USRP-CRNT-LOC-CD.
      *---------------------------

           IF  MIR-USRP-CRNT-LOC-CD = RUSRP-USRP-CRNT-LOC-CD
               GO TO 8310-EDIT-USRP-CRNT-LOC-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'CLI-CRNT-LOC-CD'        TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-CRNT-LOC-CD     TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID CURRENT LOCATION CODE
               MOVE 'CS77120050'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-USRP-CRNT-LOC-CD     TO RUSRP-USRP-CRNT-LOC-CD.

       8310-EDIT-USRP-CRNT-LOC-CD-X.
           EXIT.


      *---------------------
       8400-EDIT-AMT-FIELDS.
      *---------------------

           PERFORM  8401-EDIT-AMT-1
               THRU 8401-EDIT-AMT-1-X.

           PERFORM  8402-EDIT-AMT-2
               THRU 8402-EDIT-AMT-2-X.

           PERFORM  8403-EDIT-AMT-3
               THRU 8403-EDIT-AMT-3-X.

           PERFORM  8404-EDIT-AMT-4
               THRU 8404-EDIT-AMT-4-X.

           PERFORM  8405-EDIT-AMT-5
               THRU 8405-EDIT-AMT-5-X.

           PERFORM  8406-EDIT-AMT-6
               THRU 8406-EDIT-AMT-6-X.

           PERFORM  8407-EDIT-AMT-7
               THRU 8407-EDIT-AMT-7-X.

           PERFORM  8408-EDIT-AMT-8
               THRU 8408-EDIT-AMT-8-X.

           PERFORM  8409-EDIT-AMT-9
               THRU 8409-EDIT-AMT-9-X.

           PERFORM  8410-EDIT-AMT-A
               THRU 8410-EDIT-AMT-A-X.

           PERFORM  8411-EDIT-AMT-B
               THRU 8411-EDIT-AMT-B-X.

           PERFORM  8412-EDIT-AMT-C
               THRU 8412-EDIT-AMT-C-X.


       8400-EDIT-AMT-FIELDS-X.
           EXIT.

      *----------------
       8401-EDIT-AMT-1.
      *----------------

           MOVE MIR-USRP-PMT-1-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-1-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-1-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 1
               MOVE 'CS77120021'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8401-EDIT-AMT-1-X.
           EXIT.


      *----------------
       8402-EDIT-AMT-2.
      *----------------

           MOVE MIR-USRP-PMT-2-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-2-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-2-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 2
               MOVE 'CS77120022'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8402-EDIT-AMT-2-X.
           EXIT.

      *----------------
       8403-EDIT-AMT-3.
      *----------------

           MOVE MIR-USRP-PMT-3-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-3-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-3-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 3
               MOVE 'CS77120023'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8403-EDIT-AMT-3-X.
           EXIT.

      *----------------
       8404-EDIT-AMT-4.
      *----------------

           MOVE MIR-USRP-PMT-4-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-4-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-4-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 4
               MOVE 'CS77120024'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8404-EDIT-AMT-4-X.
           EXIT.

      *----------------
       8405-EDIT-AMT-5.
      *----------------

           MOVE MIR-USRP-PMT-5-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-5-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-5-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 5
               MOVE 'CS77120025'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8405-EDIT-AMT-5-X.
           EXIT.

      *----------------
       8406-EDIT-AMT-6.
      *----------------

           MOVE MIR-USRP-PMT-6-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-6-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-6-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 6
               MOVE 'CS77120026'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8406-EDIT-AMT-6-X.
           EXIT.

      *----------------
       8407-EDIT-AMT-7.
      *----------------

           MOVE MIR-USRP-PMT-7-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-7-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-7-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 7
               MOVE 'CS77120027'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8407-EDIT-AMT-7-X.
           EXIT.

      *----------------
       8408-EDIT-AMT-8.
      *----------------

           MOVE MIR-USRP-PMT-8-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-8-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-8-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 8
               MOVE 'CS77120028'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8408-EDIT-AMT-8-X.
           EXIT.

      *----------------
       8409-EDIT-AMT-9.
      *----------------

           MOVE MIR-USRP-PMT-9-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-9-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-9-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT 9
               MOVE 'CS77120029'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8409-EDIT-AMT-9-X.
           EXIT.

      *----------------
       8410-EDIT-AMT-A.
      *----------------

           MOVE MIR-USRP-PMT-A-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-A-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-A-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT A
               MOVE 'CS77120030'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8410-EDIT-AMT-A-X.
           EXIT.

      *----------------
       8411-EDIT-AMT-B.
      *----------------

           MOVE MIR-USRP-PMT-B-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-B-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-B-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT B
               MOVE 'CS77120031'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8411-EDIT-AMT-B-X.
           EXIT.

      *----------------
       8412-EDIT-AMT-C.
      *----------------

           MOVE MIR-USRP-PMT-C-AMT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-PMT-C-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE +2                           TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED          TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RUSRP-USRP-PMT-C-AMT
           ELSE
      *MSG: INVALID PAYMENT AMOUNT C
               MOVE 'CS77120032'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8412-EDIT-AMT-C-X.
           EXIT.


      *----------------------------
       9200-MOVE-RECORD-TO-MIR.
      *----------------------------

           MOVE  RUSRP-USRP-RETRN-TYP-CD   TO MIR-USRP-RETRN-TYP-CD.
           MOVE  RUSRP-CLI-ID              TO MIR-CLI-ID.
           MOVE  RUSRP-USRP-CLI-TAX-ID     TO MIR-USRP-CLI-TAX-ID.
           MOVE  RUSRP-USRP-TAX-ID-TYP-CD  TO MIR-USRP-TAX-ID-TYP-CD.
           MOVE  RUSRP-USRP-PNSN-QUALF-CD  TO MIR-USRP-PNSN-QUALF-CD.
           MOVE  RUSRP-USRP-NM-LN-1-TXT    TO MIR-USRP-NM-LN-1-TXT.
           MOVE  RUSRP-USRP-NM-LN-2-TXT    TO MIR-USRP-NM-LN-2-TXT.
           MOVE  RUSRP-USRP-ADDR-LN-TXT    TO MIR-USRP-ADDR-LN-TXT.
           MOVE  RUSRP-USRP-CITY-NM-TXT    TO MIR-USRP-CITY-NM-TXT.
           MOVE  RUSRP-USRP-CRNT-LOC-CD    TO MIR-USRP-CRNT-LOC-CD.
           MOVE  RUSRP-USRP-PSTL-CD        TO MIR-USRP-PSTL-CD.
           MOVE  RUSRP-USRP-FRGN-CTRY-IND  TO MIR-USRP-FRGN-CTRY-IND.
           MOVE  RUSRP-USRP-FRGN-CTRY-TXT  TO MIR-USRP-FRGN-CTRY-TXT.
           MOVE  RUSRP-USRP-IRS-DSTRB-CD   TO MIR-USRP-IRS-DSTRB-CD.
           MOVE  RUSRP-USRP-TAX-DTRMN-IND  TO MIR-USRP-TAX-DTRMN-IND.
           MOVE  RUSRP-USRP-IRA-SEP-IND    TO MIR-USRP-IRA-SEP-IND.
           MOVE  RUSRP-USRP-TOT-DSTRB-IND  TO MIR-USRP-TOT-DSTRB-IND.
           MOVE  RUSRP-USRP-COMB-RPT-CD    TO MIR-USRP-COMB-RPT-CD.
           MOVE  RUSRP-USRP-TIN-NOTI-CD    TO MIR-USRP-TIN-NOTI-CD.
           MOVE  RUSRP-USRP-SPCL-DATA-TXT  TO MIR-USRP-SPCL-DATA-TXT.
           MOVE  RUSRP-USRP-SRC-CD         TO MIR-USRP-SRC-CD.
           MOVE  RUSRP-USRP-PRT-STAT-CD    TO MIR-USRP-PRT-STAT-CD.
           MOVE  RUSRP-USRP-RPT-CD         TO MIR-USRP-RPT-CD.
           MOVE  RUSRP-USRP-STAT-CD        TO MIR-USRP-STAT-CD.

           MOVE RUSRP-USRP-PRT-DT          TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE        TO MIR-USRP-PRT-DT.

020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-TAX-YR.
020874     MOVE RUSRP-USRP-TAX-YR        TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-TAX-YR
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-TAX-YR.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-DSTRB-PCT.
020874     MOVE RUSRP-USRP-DSTRB-PCT     TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-DSTRB-PCT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-DSTRB-PCT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-1-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-1-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-1-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-1-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-2-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-2-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-2-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-2-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-3-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-3-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-3-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-3-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-4-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-4-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-4-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-4-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-5-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-5-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-5-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-5-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-6-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-6-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-6-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-6-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-7-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-7-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-7-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-7-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-8-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-8-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-8-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-8-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-9-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-9-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-9-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-9-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-A-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-A-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-A-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-A-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-B-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-B-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-B-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-B-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-C-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-C-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-C-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-C-AMT.



020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-LTAXWH-AMT * 100.
020874     MOVE RUSRP-USRP-LTAXWH-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-LTAXWH-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-LTAXWH-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-OTH-TAXWH-AMT * 100.
021367*    MOVE RUSRP-USRP-OTH-TAXWH-AMT TO L0290-INPUT-V02.
021367     MOVE RUSRP-OTHR-TAXWH-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
021367*    MOVE LENGTH OF MIR-USRP-OTH-TAXWH-AMT
021367     MOVE LENGTH OF MIR-OTHR-TAXWH-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
021367*    MOVE L0290-OUTPUT-DATA        TO MIR-USRP-OTH-TAXWH-AMT.
021367     MOVE L0290-OUTPUT-DATA        TO MIR-OTHR-TAXWH-AMT.


       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.
025970     SET WS-MAX-LENGTH-DEFAULT TO TRUE.
025970
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  USRP
                                '$VAR2'   BY 'USRP'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS8090.
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
       COPY CCPS2430.
       COPY CCPL2430.
020478 COPY CCPS2440.
       COPY CCPL2440.
      /
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
021930*COPY XCPS8090.
       COPY XCPL8090.

       COPY XCPS8960.
       COPY XCPL8960.


      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPNCLI.

       COPY CCPNUSRP.
       COPY CCPUUSRP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7712
      *****************************************************************
