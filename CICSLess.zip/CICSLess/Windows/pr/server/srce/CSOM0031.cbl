      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0031.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0031                                         **
      **  REMARKS:  IRTS - MAINTAIN INTEREST RATES (IR) TABLE.       **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE           **
      **            FUNCTIONS FOR THE INTEREST RATES TABLE.          **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       REMOVE DUPL FLDS INT-RT-DY-DR/INT-RT-MO-DUR      **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557699**  5.5       ADD LOGIC FOR ACCESSING ADUIT MODULES            **
557708**  5.5       CICS ABEND HANDLING                              **
557756**  5.5       MULTI-LANGUAGE SUPPORT                           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       PUT WORK DATES THRU THE DATE ROUTINE TO GET      **
005409**            VALID DATE PRIOR TO MOVING TO DB2 TABLES         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014591**  6.0       COMBINE TWO PARTS FIELD                          **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************
      /
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0031'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
016548*    05  WS-SUB                        PIC S9(4) COMP.
016548     05  WS-SUB                        PIC S9(4) BINARY.
016548*    05  WS-MAX-NUM-LINES              PIC S9(4) COMP VALUE +12.
025970*    05  WS-MAX-NUM-LINES              PIC S9(4) BINARY VALUE +12.

           05  EDIT-7-4                      PIC 999.9999.
008455*    05  EDIT-9-0                      PIC 999999999.

           05  WS-MTH-VALUE-ALPHA            PIC X(03).
           05  WS-MTH-VALUE-NUMERIC
               REDEFINES WS-MTH-VALUE-ALPHA  PIC 9(03).

           05  WS-DAY-VALUE-ALPHA            PIC X(03).
           05  WS-DAY-VALUE-NUMERIC
               REDEFINES WS-DAY-VALUE-ALPHA  PIC 9(03).

008455*    05  WS-MAX-AMOUNT-ALPHA           PIC X(09).
008455*    05  WS-MAX-AMOUNT-NUMERIC
008455*        REDEFINES WS-MAX-AMOUNT-ALPHA PIC 9(09).
008455     05  WS-MAX-AMOUNT                 PIC 9(16).

           05  WS-FIELD-ALPHA.
               10  WS-FIELD-ALPHA1           PIC XXX.
               10  WS-FIELD-ALPHA2           PIC X.
               10  WS-FIELD-ALPHA3           PIC XXXX.
           05  WS-FIELD-NUMERIC
               REDEFINES WS-FIELD-ALPHA.
               10  WS-FIELD-NUMERIC1         PIC 999.
               10  WS-FIELD-NUMERIC2         PIC X.
               10  WS-FIELD-NUMERIC3         PIC V9999.

           05  WS-EFFEC-DATE-ALPHA           PIC X(10).
           05  WS-EFFEC-DATE-NUMERIC
               REDEFINES WS-EFFEC-DATE-ALPHA.
               10  WS-EFF-YEAR               PIC 9(04).
               10  FILLER                    PIC X(01).
               10  WS-EFF-MONTH              PIC 9(02).
               10  FILLER                    PIC X(01).
               10  WS-EFF-DAY                PIC 9(02).

005409     05  WS-DAYS-IN-YEAR               PIC S9(3) COMP-3 VALUE 0.

       01  WS-EDIT-CHECKS.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID          VALUE '1590' '1591'
                                                   '1592' '1593'
                                                   '1594'.
               88  WS-BUS-FCN-RETRIEVE       VALUE '1590'.
               88  WS-BUS-FCN-CREATE         VALUE '1591'.
               88  WS-BUS-FCN-UPDATE         VALUE '1592'.
               88  WS-BUS-FCN-DELETE         VALUE '1593'.
               88  WS-BUS-FCN-LIST           VALUE '1594'.
025970*    05  WS-TWRK-KEY                   PIC X(04)  VALUE '1590'.

           05  WS-ERROR-SW                   PIC X(01).
               88  ERROR-FOUND               VALUE 'Y'.
               88  NO-ERRORS-FOUND           VALUE 'N'.

           05  WS-CLEAR-SCREEN-SW            PIC X(01).
               88  CLEAR-DATA-FIELDS         VALUE 'Y'.
               88  DO-NOT-CLEAR-DATA         VALUE 'N'.

       01  WS-KEY-WORK-AREAS.

           05  WS-IRK-KEY.
               10  WS-IRK-DISPLAY-FIELDS.
                   15  WS-IRK-COMPANY        PIC X(2).
014591*            15  WS-IRK-PLAN           PIC X(5).
014591*            15  WS-IRK-RATE           PIC X.
014591             15  WS-IRK-PLAN-ID        PIC X(6).
                   15  WS-IRK-EFF-DATE       PIC 9(7).
                   15  WS-IRK-MONTHS         PIC 9(3).
                   15  WS-IRK-DAYS           PIC 9(3).
557756*        10  WS-IRK-MAX                PIC S9(9)V99  COMP-3.
557756         10  WS-IRK-MAX                PIC S9(13)V99 COMP-3.

           05  WS-LOW-IR-KEY.
               10  WS-LOW-IR-COMPANY         PIC X(2).
014591*        10  WS-LOW-IR-PLAN            PIC X(5).
014591*        10  WS-LOW-IR-RS              PIC X.
014591         10  WS-LOW-IR-PLAN-ID         PIC X(6).
               10  WS-LOW-IR-EFF-DATE        PIC X(7).
               10  WS-LOW-IR-MONTHS          PIC X(3).
               10  WS-LOW-IR-DAYS            PIC X(3).
557756*        10  WS-LOW-IR-MAX             PIC S9(9)V99  COMP-3.
557756         10  WS-LOW-IR-MAX             PIC S9(13)V99 COMP-3.

           05  WS-HIGH-IR-KEY.
               10  WS-HIGH-IR-COMPANY        PIC X(2).
014591*        10  WS-HIGH-IR-PLAN           PIC X(5).
014591*        10  WS-HIGH-IR-RS             PIC X.
014591         10  WS-HIGH-IR-PLAN-ID        PIC X(6).
               10  WS-HIGH-IR-EFF-DATE       PIC X(7).
               10  WS-HIGH-IR-MONTHS         PIC X(3).
               10  WS-HIGH-IR-DAYS           PIC X(3).
557756*        10  WS-HIGH-IR-MAX            PIC S9(9)V99  COMP-3.
557756         10  WS-HIGH-IR-MAX            PIC S9(13)V99  COMP-3.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-NUM-LINES              PIC S9(4) BINARY.
025970         88  WS-MAX-NUM-LINES-DEFAULT  VALUE +12.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1590'.
      /
025970 COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
       COPY CCFWIR.
       COPY CCFRIR.
      /
008455 COPY XCWL0280.
008455 COPY XCWL0290.
      /
013578*COPY XCWL2510.
      /
557756*COPY CCWTYSNO.
       COPY XCWLDTLK.
       COPY XCWL1660.
005409 COPY XCWL1670.
005409 COPY XCWL1680.
014221 COPY XCWL8090.
      /
       COPY XCWL1640.
      /

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0031.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      **********************
       2000-PROCESS-REQUEST.
      **********************

025970*    SET MIR-RETRN-OK     TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
008455
025970*    MOVE +12                   TO WS-MAX-NUM-LINES.
025970*    MOVE 'N'                   TO WS-CLEAR-SCREEN-SW.

           PERFORM  2100-INITIAL-SYSTEM-EDITS
               THRU 2100-INITIAL-SYSTEM-EDITS-X.
           IF ERROR-FOUND
               PERFORM  2300-CLEAR-SCREEN-VALUES
                   THRU 2300-CLEAR-SCREEN-VALUES-X
                   VARYING WS-SUB FROM 1 BY 1
                   UNTIL WS-SUB > WS-MAX-NUM-LINES
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           PERFORM  2200-SET-UP-AND-CALCLATE-KEY
               THRU 2200-SET-UP-AND-CALCLATE-KEY-X.
           MOVE WS-IRK-KEY            TO WIR-KEY.
           PERFORM  IR-1000-READ
               THRU IR-1000-READ-X.
           MOVE WIR-KEY               TO WS-IRK-KEY.

           IF WS-BUS-FCN-LIST
               PERFORM  2300-CLEAR-SCREEN-VALUES
                   THRU 2300-CLEAR-SCREEN-VALUES-X
                   VARYING WS-SUB FROM 1 BY 1
                   UNTIL WS-SUB > 12
557660     END-IF.

           EVALUATE TRUE
               WHEN WS-BUS-FCN-CREATE
                   PERFORM  3000-PROCESS-CREATE
                       THRU 3000-PROCESS-CREATE-X
               WHEN WS-BUS-FCN-DELETE
                   PERFORM  4000-PROCESS-DELETE
                       THRU 4000-PROCESS-DELETE-X
               WHEN WS-BUS-FCN-LIST
                   PERFORM  5000-PROCESS-LIST
                       THRU 5000-PROCESS-LIST-X
               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  6000-PROCESS-UPDATE
                       THRU 6000-PROCESS-UPDATE-X
               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  7000-PROCESS-RETRIEVE
                       THRU 7000-PROCESS-RETRIEVE-X
557660     END-EVALUATE.


           IF CLEAR-DATA-FIELDS
               PERFORM  2300-CLEAR-SCREEN-VALUES
                   THRU 2300-CLEAR-SCREEN-VALUES-X
                   VARYING WS-SUB FROM 1 BY 1
                   UNTIL WS-SUB > WS-MAX-NUM-LINES
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      ***************************
       2100-INITIAL-SYSTEM-EDITS.
      ***************************
      *
           MOVE 'N'                   TO WS-ERROR-SW.

           MOVE MIR-INT-RT-EFF-DT     TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
557756*    IF L1640-NOT-VALID
557756*        EVALUATE TRUE
557756*            WHEN WGLOB-USER-LANG-ENGLISH
557756*                MOVE 'DDMMMYYYY' TO MIR-INT-RT-EFF-DT
557756*            WHEN WGLOB-USER-LANG-FRENCH
557756*                MOVE 'JJMMMAAAA' TO MIR-INT-RT-EFF-DT
557756*            WHEN WGLOB-USER-LANG-SPANISH
557756*                MOVE 'DDMMMAAAA' TO MIR-INT-RT-EFF-DT
557756*            WHEN OTHER
557756*                MOVE 'DDMMMYYYY' TO MIR-INT-RT-EFF-DT
557756*        END-EVALUATE
557756*    ELSE
557756     IF L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-INT-RT-EFF-DT
557660     END-IF.
           MOVE L1640-INTERNAL-DATE   TO WS-EFFEC-DATE-ALPHA.

           IF MIR-INT-RT-EFF-DT = SPACES
           AND WS-BUS-FCN-LIST
               MOVE ZEROS             TO MIR-INT-RT-EFF-DT
005409         MOVE ZEROS             TO MIR-DPOS-TRM-MO-DUR
005409         MOVE ZEROS             TO MIR-DPOS-TRM-DY-DUR
           ELSE
               IF L1640-NOT-VALID
                   MOVE 'Y'           TO WS-ERROR-SW
                   MOVE 'CS00000036'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           MOVE MIR-DPOS-TRM-MO-DUR   TO WS-MTH-VALUE-ALPHA.
           IF WS-MTH-VALUE-ALPHA NUMERIC
               CONTINUE
           ELSE
               MOVE 'Y'               TO WS-ERROR-SW
               MOVE 'CS00000031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE MIR-DPOS-TRM-DY-DUR   TO WS-DAY-VALUE-ALPHA.
           IF WS-DAY-VALUE-ALPHA NUMERIC
034802*        IF WS-DAY-VALUE-NUMERIC = ZERO
034802*             NEXT SENTENCE
034802*        ELSE
034802         IF WS-DAY-VALUE-NUMERIC NOT = ZERO
005409              MOVE L1640-INTERNAL-DATE
                                      TO L1680-INTERNAL-1
005409              MOVE WS-MTH-VALUE-NUMERIC
                                      TO L1680-NUMBER-OF-MONTHS
005409              PERFORM  1680-5000-ADD-M-TO-DATE
005409                  THRU 1680-5000-ADD-M-TO-DATE-X
005409              MOVE L1680-INT-YYYY-2
                                      TO LDTLK-LEAP-YEAR
005409              MOVE L1680-INT-MM-2
                                      TO LDTLK-LEAP-MONTH
005409              PERFORM  LEAP-0100-EDIT-LEAP-YEAR
005409                  THRU LEAP-0100-EDIT-LEAP-YEAR-X
005409              COMPUTE WS-DAYS-IN-YEAR = LDTLK-DAYS-IN-YEAR - 1
034802*        END-IF
034802*        IF WS-DAY-VALUE-NUMERIC > WS-DAYS-IN-YEAR
034802              IF WS-DAY-VALUE-NUMERIC > WS-DAYS-IN-YEAR
005409*        IF WS-DAY-VALUE-NUMERIC > 365
                       MOVE 'Y'          TO WS-ERROR-SW
005409*MSG: DAYS MUST BE LESS THAN DAYS-IN-A-YEAR. RE-ENTER.
005409                 MOVE WS-DAYS-IN-YEAR
                                      TO WGLOB-MSG-PARM (1)
                       MOVE 'CS00310002' TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
034802              END-IF
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               MOVE 'Y'               TO WS-ERROR-SW
               MOVE 'CS00000031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

008455     MOVE MIR-INT-RT-MAX-AMT    TO L0280-INPUT-DATA.
008455     MOVE 0                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-INT-RT-MAX-AMT
                                      TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-INT-RT-MAX-AMT
                                      TO L0280-LENGTH.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455
008455*    IF MIR-INT-RT-MAX-AMT NUMERIC
008455     IF  L0280-OK
008455         MOVE L0280-OUTPUT      TO WS-MAX-AMOUNT
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         MOVE L0280-PRECISION   TO L0290-PRECISION
008455         MOVE L0280-INPUT-SIZE  TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-INT-RT-MAX-AMT
008455*        MOVE MIR-INT-RT-MAX-AMT       TO WS-MAX-AMOUNT-ALPHA
           ELSE
               MOVE 'Y'               TO WS-ERROR-SW
               MOVE 'CS00000031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2100-INITIAL-SYSTEM-EDITS-X.
           EXIT.

      /
      ******************************
       2200-SET-UP-AND-CALCLATE-KEY.
      ******************************

           MOVE WS-EFFEC-DATE-NUMERIC TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE   TO WS-IRK-EFF-DATE.
           MOVE WS-MTH-VALUE-NUMERIC  TO WS-IRK-MONTHS.
           MOVE WS-DAY-VALUE-NUMERIC  TO WS-IRK-DAYS.
014591     MOVE MIR-INT-RT-ID         TO WS-IRK-PLAN-ID.
014591*    MOVE MIR-RTSCL             TO WS-IRK-RATE.
           MOVE ZEROS                 TO WS-IRK-MAX.
008455*    MOVE WS-MAX-AMOUNT-NUMERIC TO WS-IRK-MAX.
008455     MOVE WS-MAX-AMOUNT         TO WS-IRK-MAX.

       2200-SET-UP-AND-CALCLATE-KEY-X.
           EXIT.


      /
      **************************
       2300-CLEAR-SCREEN-VALUES.
      **************************

           MOVE SPACES            TO MIR-INT-RT-ID-T (WS-SUB).
014591*    MOVE SPACES            TO MIR-TRATE-T (WS-SUB).
           MOVE SPACES            TO MIR-INT-RT-EFF-DT-T (WS-SUB).
           MOVE SPACES            TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB).
           MOVE SPACES            TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB).
           MOVE SPACES            TO MIR-INT-RT-MAX-AMT-T (WS-SUB).
           MOVE SPACES            TO MIR-INIT-DPOS-INT-PCT-T (WS-SUB).
           MOVE SPACES            TO MIR-ROLOVR-INT-PCT-T (WS-SUB).
           MOVE SPACES            TO MIR-MKTVAL-ADJ-INT-PCT-T (WS-SUB).

       2300-CLEAR-SCREEN-VALUES-X.
           EXIT.

      /
      *********************
       3000-PROCESS-CREATE.
      *********************
      *
      ****
      ***  IF THE READ WAS OKAY, IT MEANS THE RECORD ALREADY EXISTED
      ****
           IF WIR-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WS-IRK-DISPLAY-FIELDS
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-CREATE-X
557660     END-IF.

      ****
      ***  LOGIC TO INQUIRE INTO THE EDIT TABLE (ETAB)
      ***  FOR VALID IRTS PLAN AND RATE SCALE
      ****
      *
           IF MIR-INT-RT-ID = SPACES
               MOVE 'CS00310001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-CREATE-X
           END-IF.
      *

      ****
      ***  MOVE THE REST OF THE VALUES TO THE RIR-REC-INFO AND THEN
      ***  WRITE OUT THE NEW RECORD.  DISPLAY MESSAGE INDICATING NEW
      ***  RECORD HAS BEEN CREATED.
      ****
005409*    MOVE WS-EFFEC-DATE-NUMERIC TO RIR-INT-RT-EFF-DT.
005409     MOVE WS-EFFEC-DATE-NUMERIC TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO RIR-INT-RT-EFF-DT.
557659*    MOVE WS-MTH-VALUE-NUMERIC  TO RIR-INT-RT-MO-DUR-N.
557659     MOVE WS-MTH-VALUE-NUMERIC  TO RIR-DPOS-TRM-MO-DUR-N.
557659*    MOVE WS-DAY-VALUE-NUMERIC  TO RIR-INT-RT-DY-DUR-N.
557659     MOVE WS-DAY-VALUE-NUMERIC  TO RIR-DPOS-TRM-DY-DUR-N.
           MOVE ZEROES                TO RIR-INIT-DPOS-INT-PCT.
           MOVE ZEROES                TO RIR-ROLOVR-INT-PCT.
           MOVE ZEROES                TO RIR-MKTVAL-ADJ-INT-PCT.
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  IR-1000-WRITE
               THRU IR-1000-WRITE-X.
557699     IF WGLOB-AUDIT-REQUESTED
557699        PERFORM IR-1000-CALL-AUDIT
557699           THRU IR-1000-CALL-AUDIT-X
557699     END-IF.

014221     PERFORM  IR-1000-READ-TWRK-TS
014221         THRU IR-1000-READ-TWRK-TS-X.

           MOVE 1                     TO WS-SUB.
           PERFORM  8000-FORMAT-SCREEN
               THRU 8000-FORMAT-SCREEN-X.

       3000-PROCESS-CREATE-X.
           EXIT.

      /
      *********************
       4000-PROCESS-DELETE.
      *********************
      *
      *
014221*    PERFORM  IR-1000-READ-FOR-UPDATE
014221*        THRU IR-1000-READ-FOR-UPDATE-X.

014221     PERFORM  IR-2000-UPDATE-TWRK-TS
014221         THRU IR-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABEL @1, KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'IR'               TO WGLOB-MSG-PARM (01)
014221         MOVE WIR-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  NOT WIR-IO-OK
014221*MSG: 'RECORD LOST IN MAINTAIN (@1) - CONTACT SYSTEMS'
014221         MOVE WIR-KEY           TO WGLOB-MSG-PARM (1)
014221         MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4000-PROCESS-DELETE-X
014221     END-IF.

           IF  WIR-IO-OK
557699         IF WGLOB-AUDIT-REQUESTED
557699            PERFORM IR-1000-CALL-AUDIT
557699              THRU IR-1000-CALL-AUDIT-X
557699         END-IF
               PERFORM  IR-1000-DELETE
                   THRU IR-1000-DELETE-X
               IF WIR-IO-OK
                   MOVE 'XS00000011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557699             IF WGLOB-AUDIT-REQUESTED
557699                PERFORM IR-1000-CALL-AUDIT
557699                   THRU IR-1000-CALL-AUDIT-X
557699             END-IF
557660         END-IF
557660     END-IF.

           MOVE +1                    TO WS-MAX-NUM-LINES.

           MOVE 'Y'                   TO WS-CLEAR-SCREEN-SW.

       4000-PROCESS-DELETE-X.
           EXIT.

      /
      *******************
       5000-PROCESS-LIST.
      *******************
      *
           MOVE WS-IRK-KEY            TO WS-LOW-IR-KEY.
           MOVE WS-LOW-IR-KEY         TO WIR-KEY.
           MOVE WS-LOW-IR-KEY         TO WS-HIGH-IR-KEY.
           MOVE HIGH-VALUES           TO WS-HIGH-IR-EFF-DATE.
           MOVE HIGH-VALUES           TO WS-HIGH-IR-MONTHS.
           MOVE HIGH-VALUES           TO WS-HIGH-IR-DAYS.
557756*    MOVE 999999999.99      TO WS-HIGH-IR-MAX.
557756     MOVE 9999999999999.99      TO WS-HIGH-IR-MAX.
           MOVE WS-HIGH-IR-KEY        TO WIR-ENDBR-KEY.
           MOVE ZERO                  TO WS-SUB.
           PERFORM  IR-1000-BROWSE
               THRU IR-1000-BROWSE-X.

           IF  WIR-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-LIST-X
557660     END-IF.

           PERFORM  IR-2000-READ-NEXT
               THRU IR-2000-READ-NEXT-X.
           IF WIR-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-LIST-X
           END-IF.

           PERFORM  8000-FORMAT-SCREEN
               THRU 8000-FORMAT-SCREEN-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 12
               OR WIR-IO-EOF.

           IF WIR-IO-EOF
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
                  MOVE MIR-INT-RT-ID-T (1)
                                      TO MIR-INT-RT-ID
                  MOVE MIR-INT-RT-EFF-DT-T (1)
                                      TO MIR-INT-RT-EFF-DT
                  MOVE MIR-DPOS-TRM-MO-DUR-T (1)
                                      TO MIR-DPOS-TRM-MO-DUR
                  MOVE MIR-DPOS-TRM-DY-DUR-T (1)
                                      TO MIR-DPOS-TRM-DY-DUR
                  MOVE MIR-INT-RT-MAX-AMT-T (1)
                                      TO MIR-INT-RT-MAX-AMT
                  MOVE MIR-INT-RT-EFF-DT-T (1)
                                      TO L1640-EXTERNAL-DATE
020462*           PERFORM 1640-3000-EXTERNAL-TO-INT
020462*              THRU 1640-3000-EXTERNAL-TO-INT-X
020462            PERFORM 1640-7000-MIR-TO-INT
020462               THRU 1640-7000-MIR-TO-INT-X                     
                  MOVE L1640-INTERNAL-DATE   TO WS-EFFEC-DATE-ALPHA
                  MOVE MIR-DPOS-TRM-MO-DUR-T (1)
                                      TO WS-MTH-VALUE-ALPHA
                  MOVE MIR-DPOS-TRM-DY-DUR-T (1)
                                      TO WS-DAY-VALUE-ALPHA
                  PERFORM  2200-SET-UP-AND-CALCLATE-KEY
                      THRU 2200-SET-UP-AND-CALCLATE-KEY-X
           ELSE
               IF WS-SUB > 12
                  MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
                  SET WGLOB-MORE-DATA-EXISTS  TO TRUE
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                  MOVE RIR-INT-RT-ID       TO MIR-INT-RT-ID
                  MOVE RIR-INT-RT-EFF-DT   TO L1640-INTERNAL-DATE
020462*           PERFORM 1640-2000-INTERNAL-TO-EXT
020462*              THRU 1640-2000-INTERNAL-TO-EXT-X
020462            PERFORM 1640-8000-INTERNAL-TO-MIR
020462               THRU 1640-8000-INTERNAL-TO-MIR-X
                  MOVE L1640-EXTERNAL-DATE TO MIR-INT-RT-EFF-DT
                  MOVE RIR-DPOS-TRM-MO-DUR TO MIR-DPOS-TRM-MO-DUR
                  MOVE RIR-DPOS-TRM-DY-DUR TO MIR-DPOS-TRM-DY-DUR
020874*           COMPUTE L0290-INPUT-NUMBER = RIR-INT-RT-MAX-AMT
020874            MOVE RIR-INT-RT-MAX-AMT  TO L0290-INPUT-V00
                  MOVE 0                   TO L0290-PRECISION
                  MOVE LENGTH OF MIR-INT-RT-MAX-AMT
                                           TO L0290-MAX-OUT-LEN
020874*           PERFORM 0290-1000-NUMERIC-FORMAT
020874*              THRU 0290-1000-NUMERIC-FORMAT-X
020874            PERFORM 0290-2000-FORMAT-FOR-MIR
020874               THRU 0290-2000-FORMAT-FOR-MIR-X                     
                  MOVE L0290-OUTPUT-DATA   TO MIR-INT-RT-MAX-AMT
                  MOVE RIR-INT-RT-EFF-DT   TO WS-EFFEC-DATE-ALPHA
                  MOVE RIR-DPOS-TRM-MO-DUR TO WS-MTH-VALUE-ALPHA
                  MOVE RIR-DPOS-TRM-DY-DUR TO WS-DAY-VALUE-ALPHA
                  PERFORM  2200-SET-UP-AND-CALCLATE-KEY
                      THRU 2200-SET-UP-AND-CALCLATE-KEY-X
               END-IF
           END-IF.

           PERFORM  IR-3000-END-BROWSE
               THRU IR-3000-END-BROWSE-X.

       5000-PROCESS-LIST-X.
           EXIT.

      /
      *********************
       6000-PROCESS-UPDATE.
      *********************
      *
      *
014221*    PERFORM  IR-1000-READ-FOR-UPDATE
014221*        THRU IR-1000-READ-FOR-UPDATE-X.

014221     PERFORM  IR-2000-UPDATE-TWRK-TS
014221         THRU IR-2000-UPDATE-TWRK-TS-X.

014221*    IF  WIR-IO-OK
557699*        NEXT SENTENCE
014221     EVALUATE  TRUE
014221       WHEN  WIR-IO-OK
557699         IF WGLOB-AUDIT-REQUESTED
557699            PERFORM IR-1000-CALL-AUDIT
557699               THRU IR-1000-CALL-AUDIT-X
557699         END-IF
014221*    ELSE
014221       WHEN  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABEL @1, KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'IR'               TO WGLOB-MSG-PARM (01)
014221         MOVE WIR-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-UPDATE-X
014221       WHEN OTHER
      *MSG: 'RECORD LOST IN MAINTAIN (@1) - CONTACT SYSTEMS'
               MOVE WIR-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-UPDATE-X
014221*    END-IF.
014221     END-EVALUATE.

           MOVE 'N'                   TO WS-ERROR-SW.
           PERFORM  6300-IRTS-FLD-MNT
               THRU 6300-IRTS-FLD-MNT-X.

           IF NO-ERRORS-FOUND
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  IR-2000-REWRITE
                   THRU IR-2000-REWRITE-X
557699         IF WGLOB-AUDIT-REQUESTED
557699            PERFORM IR-1000-CALL-AUDIT
557699               THRU IR-1000-CALL-AUDIT-X
557699         END-IF
014221         PERFORM  IR-1000-READ-TWRK-TS
014221             THRU IR-1000-READ-TWRK-TS-X
               MOVE 1                 TO WS-SUB
               PERFORM  8000-FORMAT-SCREEN
                   THRU 8000-FORMAT-SCREEN-X
               MOVE +1                TO WS-MAX-NUM-LINES
           ELSE
               PERFORM  IR-3000-UNLOCK
                   THRU IR-3000-UNLOCK-X
557660     END-IF.

       6000-PROCESS-UPDATE-X.
           EXIT.

      /
      *******************
       6300-IRTS-FLD-MNT.
      *******************
      *
013578*    MOVE MIR-INIT-DPOS-INT-PCT-T (1)
013578     MOVE MIR-INIT-DPOS-INT-PCT
                                      TO WS-FIELD-ALPHA.
           IF WS-FIELD-ALPHA1 NOT NUMERIC
           OR WS-FIELD-ALPHA3 NOT NUMERIC
           OR WS-FIELD-ALPHA2 NOT = '.'
               MOVE 'Y'               TO WS-ERROR-SW
               MOVE 'CS00000031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               COMPUTE RIR-INIT-DPOS-INT-PCT = WS-FIELD-NUMERIC1
                                  + WS-FIELD-NUMERIC3
557660     END-IF.

013578*    MOVE MIR-ROLOVR-INT-PCT-T (1)
013578     MOVE MIR-ROLOVR-INT-PCT
                                      TO WS-FIELD-ALPHA.
           IF WS-FIELD-ALPHA1 NOT NUMERIC
           OR WS-FIELD-ALPHA3 NOT NUMERIC
           OR WS-FIELD-ALPHA2 NOT = '.'
               MOVE 'Y'               TO WS-ERROR-SW
               MOVE 'CS00000031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               COMPUTE RIR-ROLOVR-INT-PCT = WS-FIELD-NUMERIC1
                                   + WS-FIELD-NUMERIC3
557660     END-IF.

013578*    MOVE MIR-MKTVAL-ADJ-INT-PCT-T (1)
013578     MOVE MIR-MKTVAL-ADJ-INT-PCT
                                      TO WS-FIELD-ALPHA.
           IF WS-FIELD-ALPHA1 NOT NUMERIC
           OR WS-FIELD-ALPHA3 NOT NUMERIC
           OR WS-FIELD-ALPHA2 NOT = '.'
               MOVE 'Y'               TO WS-ERROR-SW
               MOVE 'CS00000031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               COMPUTE RIR-MKTVAL-ADJ-INT-PCT = WS-FIELD-NUMERIC1
                                 + WS-FIELD-NUMERIC3
557660     END-IF.

       6300-IRTS-FLD-MNT-X.
           EXIT.
      /
      ***********************
       7000-PROCESS-RETRIEVE.
      ***********************
      *
014221     PERFORM  IR-1000-READ-TWRK-TS
014221         THRU IR-1000-READ-TWRK-TS-X.

           IF WIR-IO-NOT-FOUND
               MOVE 'Y'                   TO WS-CLEAR-SCREEN-SW
               MOVE 'XS00000001'          TO WGLOB-MSG-REF-INFO
               MOVE WS-IRK-DISPLAY-FIELDS TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE +1 TO WS-MAX-NUM-LINES
               GO TO 7000-PROCESS-RETRIEVE-X
557660     END-IF.

           MOVE 1 TO WS-SUB.
           PERFORM  8000-FORMAT-SCREEN
               THRU 8000-FORMAT-SCREEN-X.


       7000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      ********************
       8000-FORMAT-SCREEN.
      ********************

014591*    MOVE RIR-INT-RT-ID-PLAN    TO MIR-INT-RT-ID-T (WS-SUB).
014591*    MOVE RIR-INT-RT-ID-RS      TO MIR-TRATE-T (WS-SUB).
014591     MOVE RIR-INT-RT-ID         TO MIR-INT-RT-ID-T (WS-SUB).

           MOVE RIR-INT-RT-EFF-DT     TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
              
           MOVE L1640-EXTERNAL-DATE   TO MIR-INT-RT-EFF-DT-T (WS-SUB).

557659*    MOVE RIR-INT-RT-MO-DUR-N   TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB).
557659     MOVE RIR-DPOS-TRM-MO-DUR-N TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB).
557659*    MOVE RIR-INT-RT-DY-DUR-N   TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB).
557659     MOVE RIR-DPOS-TRM-DY-DUR-N TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB).
008455*
008455*    MOVE RIR-INT-RT-MAX-AMT     TO EDIT-9-0.
008455*    MOVE EDIT-9-0               TO MIR-INT-RT-MAX-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER = RIR-INT-RT-MAX-AMT.
020874     MOVE RIR-INT-RT-MAX-AMT    TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-INT-RT-MAX-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-INT-RT-MAX-AMT-T (WS-SUB).
008455
020874*    MOVE RIR-INIT-DPOS-INT-PCT TO EDIT-7-4.
020874*    MOVE EDIT-7-4            TO MIR-INIT-DPOS-INT-PCT-T (WS-SUB).
020874*    MOVE EDIT-7-4            TO MIR-INIT-DPOS-INT-PCT.
020874     MOVE RIR-INIT-DPOS-INT-PCT      TO L0290-INPUT-V04.
020874     MOVE 4                          TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-INIT-DPOS-INT-PCT
020874                                     TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA  TO MIR-INIT-DPOS-INT-PCT-T (WS-SUB).
020874     MOVE L0290-OUTPUT-DATA  TO MIR-INIT-DPOS-INT-PCT.
020874*    MOVE RIR-ROLOVR-INT-PCT    TO EDIT-7-4.
020874*    MOVE EDIT-7-4              TO MIR-ROLOVR-INT-PCT-T (WS-SUB).
020874*    MOVE EDIT-7-4              TO MIR-ROLOVR-INT-PCT.
020874     MOVE RIR-ROLOVR-INT-PCT         TO L0290-INPUT-V04.
020874     MOVE 4                          TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-ROLOVR-INT-PCT
020874                                     TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA  TO MIR-ROLOVR-INT-PCT-T (WS-SUB).
020874     MOVE L0290-OUTPUT-DATA  TO MIR-ROLOVR-INT-PCT.
020874*    MOVE RIR-MKTVAL-ADJ-INT-PCT                      TO EDIT-7-4.
020874*    MOVE EDIT-7-4           TO MIR-MKTVAL-ADJ-INT-PCT-T (WS-SUB).
020874*    MOVE EDIT-7-4           TO MIR-MKTVAL-ADJ-INT-PCT.
020874     MOVE RIR-MKTVAL-ADJ-INT-PCT     TO L0290-INPUT-V04.
020874     MOVE 4                          TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MKTVAL-ADJ-INT-PCT
020874                                     TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA  TO MIR-MKTVAL-ADJ-INT-PCT-T (WS-SUB).
020874     MOVE L0290-OUTPUT-DATA  TO MIR-MKTVAL-ADJ-INT-PCT.
           IF WS-BUS-FCN-LIST
              PERFORM  IR-2000-READ-NEXT
                  THRU IR-2000-READ-NEXT-X
           END-IF.

       8000-FORMAT-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-CHECKS.
025970     INITIALIZE WS-KEY-WORK-AREAS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE SPACES                   TO WWKDT-WORK-FIELDS.
025970     MOVE WWKDT-ZERO-DT            TO WS-EFFEC-DATE-ALPHA.
025970     MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK              TO TRUE.
025970     SET WS-MAX-NUM-LINES-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT       TO TRUE.
025970     SET DO-NOT-CLEAR-DATA         TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
008455 COPY XCPL0280.
008455/
008455 COPY XCPS0290.
008455 COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.

025970 COPY XCPS1660.
       COPY XCPL1660.
      /
025970 COPY XCPS1680.
005409 COPY XCPL1680.
005409/
005409 COPY XCPPLEAP.
005409/

018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
013578*COPY XCCL2510.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
013578*COPY XCPS2510.
018764*COPY CCCLIR.
018764 COPY CCPLIR.
557699/
       COPY XCPPINIT.

       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY IR
014221                         '$VAR2' BY 'IR'.
      /
       COPY CCPAIR.
      /
       COPY CCPBIR.
      /
       COPY CCPNIR.
      /
       COPY CCPUIR.

       COPY CCPXIR.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0031                     **
      *****************************************************************
