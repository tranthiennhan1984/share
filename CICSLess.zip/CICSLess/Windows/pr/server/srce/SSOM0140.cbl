      *************************
       IDENTIFICATION DIVISION.
      *************************

       COPY XCWWCRHT.

       PROGRAM-ID. SSOM0140.

      *****************************************************************
      **  MEMBER :  SSOM0140                                         **
      **  REMARKS:  'FICA' FUND TAX FILE MAINTENANCE PROGRAM         **
      **            FUND TAX FILE MAINTENANCE PROGRAM (FICA)         **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       NEW CICS ABEND ROUTINE                           **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZING FOR INT'L SUPPORT            **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       MODIFICATIONS FOR LEAP YEAR                      **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEAN-UP                                    **
012624**  6.0       SECURITY                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       RENAME 0000-MAINLINE                             **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021239**  6.4       FUND UNIT VALUE                                  **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
       DATA DIVISION.
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0140'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

      /
013578*COPY XCWL2510.
016537*COPY XCWWWKDT.
021239 COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
       COPY XCWLDTLK.
       COPY XCWL1640.

       COPY XCWL1660.
      /
005409 COPY XCWL1670.
      /
005409 COPY XCWL1680.
      /
008455 COPY XCWL0280.
008455/
008455 COPY XCWL0290.
008455/
014221 COPY XCWL8090.
008455/
       COPY SCFWFH.
       COPY SCFRFH.
      /
       COPY SCFWFV.
       COPY SCFRFV.
      /
021239 COPY SCFWFUTP.
021239 COPY SCFRFUTP.
021239
       COPY SCFWFT.
       COPY SCFRFT.
      /
       01  HOLD-MAP.
           05  HOLD-FUND                      PIC X(05).
021239     05  HOLD-FNDVL-UNIT-TYP-CD         PIC X(02).
008453     05  HOLD-EFF-DATE                  PIC X(10).
           05  HOLD-JUL-EFF-DATE              PIC 9(07).
           05  HOLD-INT-EFF-DATE              PIC X(10).
           05  HOLD-INTR-ELIG.
               10  HOLD-INT-EL                PIC X(20).
008455         10  HOLD-INT-EL-OUT            PIC S9(8)V9(9) COMP-3.
           05  HOLD-INTR-NON-ELIG.
               10  HOLD-INT-NEL               PIC X(20).
008455         10  HOLD-INT-NEL-OUT           PIC S9(8)V9(9) COMP-3.
           05  HOLD-DIVI-ELIG.
               10  HOLD-DIV-EL                PIC X(20).
008455         10  HOLD-DIV-EL-OUT            PIC S9(8)V9(9) COMP-3.
           05  HOLD-DIVI-NON-ELIG.
               10  HOLD-DIV-NEL               PIC X(20).
008455         10  HOLD-DIV-NEL-OUT           PIC S9(8)V9(9) COMP-3.
           05  HOLD-OTHER-INCOME.
               10  HOLD-OTHER                 PIC X(20).
008455         10  HOLD-OTHER-OUT             PIC S9(8)V9(9) COMP-3.
           05  HOLD-RNCG-CANADA.
               10  HOLD-RNCG-CND              PIC X(20).
008455         10  HOLD-RNCG-CND-OUT          PIC S9(8)V9(9) COMP-3.
           05  HOLD-RNCG-FOREIGN.
               10  HOLD-RNCG-FOR              PIC X(20).
008455         10  HOLD-RNCG-FOR-OUT          PIC S9(8)V9(9) COMP-3.
           05  HOLD-TOTAL-AMOUNT.
               10  HOLD-TOTAL                 PIC X(20).
008455         10  HOLD-TOTAL-OUT             PIC S9(8)V9(9) COMP-3.
      /
       01  WS-MISC-AREA.
021239*    05  UPDATE-SW                      PIC 9.
021239*        88  NO-UPDATE                  VALUE 0.
021239*        88  UPDATE-REQUIRED            VALUE 1.
           05  WS-INTERNAL-VALUES.
557973         10  WS-IE-AMOUNT               PIC S9(8)V9(09)  COMP-3.
557973         10  WS-INE-AMOUNT              PIC S9(8)V9(09)  COMP-3.
557973         10  WS-DE-AMOUNT               PIC S9(8)V9(09)  COMP-3.
557973         10  WS-DNE-AMOUNT              PIC S9(8)V9(09)  COMP-3.
557973         10  WS-OI-AMOUNT               PIC S9(8)V9(09)  COMP-3.
557973         10  WS-CGC-AMOUNT              PIC S9(8)V9(09)  COMP-3.
557973         10  WS-CGF-AMOUNT              PIC S9(8)V9(09)  COMP-3.
557973         10  WS-T-AMOUNT                PIC S9(8)V9(09)  COMP-3.
557973         10  WS-RUN-T-AMOUNT            PIC S9(8)V9(09)  COMP-3.
           05  WS-BUS-FCN-ID          PIC X(04).
               88  WS-BUS-FCN-VALID       VALUE '1840' THRU '1843'.
               88  WS-BUS-FCN-RETRIEVE    VALUE '1840'.
               88  WS-BUS-FCN-CREATE      VALUE '1841'.
               88  WS-BUS-FCN-UPDATE      VALUE '1842'.
               88  WS-BUS-FCN-DELETE      VALUE '1843'.
025970*    05  WS-TWRK-KEY            PIC X(04) VALUE '1840'.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY            PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1840'.

021239*01  WS-FT-DATA-REC.
021239*    05  WS-FT-CODE.
021239*        10  WS-FT-CODE-COMPANY            PIC X(2).
021239*        10  WS-FT-CODE-REST.
021239*            15  WS-FT-FUND-CODE           PIC X(5).
021239*            15  WS-FT-JUL-EFF-DATE        PIC 9(7).
016548*    05  WS-FT-VERSION-NUMBER              PIC S9(8)      COMP.
021239*    05  WS-FT-VERSION-NUMBER              PIC S9(8)      BINARY.
021239*    05  WS-FT-DETAIL.
021239*        10  WS-FT-EFF-DATE                PIC X(10).
021239*        10  WS-FT-INT-ELIGIBLE            PIC S9(8)V9(9) COMP-3.
021239*        10  WS-FT-INT-NON-ELIGIBLE        PIC S9(8)V9(9) COMP-3.
021239*        10  WS-FT-DIV-ELIGIBLE            PIC S9(8)V9(9) COMP-3.
021239*        10  WS-FT-DIV-NON-ELIGIBLE        PIC S9(8)V9(9) COMP-3.
021239*        10  WS-FT-OTHER-INCOME            PIC S9(8)V9(9) COMP-3.
021239*        10  WS-FT-REALIZED-GAINS-CA       PIC S9(8)V9(9) COMP-3.
021239*        10  WS-FT-REALIZED-GAINS-FO       PIC S9(8)V9(9) COMP-3.
021239*        10  WS-FT-TOTAL                   PIC S9(8)V9(9) COMP-3.
021239*        10  FILLER                        PIC X(16).
      /
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0140.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *-------------------
015543 0000-MAINLINE.
      *-------------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.

           PERFORM  0500-PROCESS-REQUEST
               THRU 0500-PROCESS-REQUEST-X.

           PERFORM EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

015543 0000-MAINLINE-X.
           EXIT.
      /
      *-------------------
       0500-PROCESS-REQUEST.
      *-------------------

           PERFORM  0600-MAP-TO-HOLD
               THRU 0600-MAP-TO-HOLD-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.

           PERFORM  0530-CHECK-FUND-DATE
               THRU 0530-CHECK-FUND-DATE-X.

           IF  WGLOB-MSG-ERROR-SW = 1
014221     OR  MIR-RETRN-TS-MISMATCH
               GO TO 0500-PROCESS-REQUEST-X
557660     END-IF.

021239     PERFORM  0535-CHECK-FNDVL-UNIT-TYP-CD
021239         THRU 0535-CHECK-FNDVL-UNIT-TYP-CD-X.
021239
021239     IF  WGLOB-MSG-ERROR-SW = 1
021239         GO TO 0500-PROCESS-REQUEST-X
021239     END-IF.
021239
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  1000-PROCESS-RETRIEVE
                        THRU 1000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-PROCESS-DELETE
                        THRU 2000-PROCESS-DELETE-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  3000-PROCESS-CREATE
                        THRU 3000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  6000-PROCESS-UPDATE
                        THRU 6000-PROCESS-UPDATE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST
                                      TO TRUE

           END-EVALUATE.


       0500-PROCESS-REQUEST-X.
           EXIT.

      *---------------------
       0530-CHECK-FUND-DATE.
      *---------------------

           MOVE HOLD-FUND             TO WFH-FND-ID.
014221*    PERFORM  FH-1000-READ
014221*        THRU FH-1000-READ-X.

014221     EVALUATE TRUE

014221         WHEN WS-BUS-FCN-RETRIEVE
014221              PERFORM  FH-1000-READ-TWRK-TS
014221                  THRU FH-1000-READ-TWRK-TS-X

014221         WHEN WS-BUS-FCN-CREATE
014221         WHEN WS-BUS-FCN-UPDATE
014221            EVALUATE MIR-DV-PRCES-STATE-CD
014221                WHEN '1'
014221                WHEN '2'
014221                    PERFORM  FH-1000-READ-TWRK-TS
014221                        THRU FH-1000-READ-TWRK-TS-X
014221                WHEN '3'
014221                    PERFORM  FH-2000-UPDATE-TWRK-TS
014221                        THRU FH-2000-UPDATE-TWRK-TS-X
014221                    IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                       MOVE 'XS00000303'  TO WGLOB-MSG-REF-INFO
014221                       MOVE 'FH'          TO WGLOB-MSG-PARM (01)
014221                       MOVE WFH-KEY         TO WGLOB-MSG-PARM (02)
014221                       PERFORM  0260-1000-GENERATE-MESSAGE
014221                           THRU 0260-1000-GENERATE-MESSAGE-X
014221                       GO TO 0530-CHECK-FUND-DATE-X
014221                    ELSE
014221                        IF  WFH-IO-OK
014221                            PERFORM  FH-3000-UNLOCK
014221                                THRU FH-3000-UNLOCK-X
014221                        END-IF
014221                    END-IF
014221            END-EVALUATE
014221
014221         WHEN WS-BUS-FCN-DELETE
014221            PERFORM  FH-2000-UPDATE-TWRK-TS
014221                THRU FH-2000-UPDATE-TWRK-TS-X
014221            IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                MOVE 'XS00000303'  TO WGLOB-MSG-REF-INFO
014221                MOVE 'FH'          TO WGLOB-MSG-PARM (01)
014221                MOVE WFH-KEY         TO WGLOB-MSG-PARM (02)
014221                PERFORM  0260-1000-GENERATE-MESSAGE
014221                    THRU 0260-1000-GENERATE-MESSAGE-X
014221                 GO TO 0530-CHECK-FUND-DATE-X
014221             ELSE
014221                 IF  WFH-IO-OK
014221                     PERFORM  FH-3000-UNLOCK
014221                         THRU FH-3000-UNLOCK-X
014221                  END-IF
014221             END-IF
014221     END-EVALUATE.


           IF  NOT WFH-IO-OK
      *MSG: FUND IS NOT A VALID FUND - REENTER
               MOVE 'SS01400001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE HOLD-EFF-DATE         TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
      *MSG: EFFECTIVE DATE IS NOT A VALID DATE - REENTER
               MOVE 'SS01400002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO HOLD-INT-EFF-DATE
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE
                                      TO HOLD-JUL-EFF-DATE
557660     END-IF.

       0530-CHECK-FUND-DATE-X.
           EXIT.
      /
021239*----------------------------
021239 0535-CHECK-FNDVL-UNIT-TYP-CD.
021239*----------------------------
021239
021239     MOVE HOLD-FUND              TO WFUTP-FND-ID.
021239     MOVE HOLD-FNDVL-UNIT-TYP-CD TO WFUTP-FND-UNIT-TYP-CD.
021239
021239     PERFORM  FUTP-1000-READ
021239         THRU FUTP-1000-READ-X.
021239
021239     IF  NOT WFUTP-IO-OK
021239*MSG: INVALID FUND UNIT TYPE CODE
021239         MOVE 'SS01400003'      TO WGLOB-MSG-REF-INFO
021239         PERFORM  0260-1000-GENERATE-MESSAGE
021239             THRU 0260-1000-GENERATE-MESSAGE-X
021239         GO TO 0535-CHECK-FNDVL-UNIT-TYP-CD-X
021239     END-IF.
021239
021239     IF  RFUTP-FND-UNIT-END-DT NOT = WWKDT-ZERO-DT
021239     AND HOLD-INT-EFF-DATE > RFUTP-FND-UNIT-END-DT
021239*MSG: FUND UNIT TYPE EXPIRED
021239         MOVE 'SS01400004'      TO WGLOB-MSG-REF-INFO
021239         PERFORM  0260-1000-GENERATE-MESSAGE
021239             THRU 0260-1000-GENERATE-MESSAGE-X
021239     END-IF.
021239
021239 0535-CHECK-FNDVL-UNIT-TYP-CD-X.
021239     EXIT.
021239
      *-----------------
       0600-MAP-TO-HOLD.
      *-----------------

           MOVE MIR-FND-ID            TO HOLD-FUND.
021239     MOVE MIR-FNDVL-UNIT-TYP-CD TO HOLD-FNDVL-UNIT-TYP-CD.
           MOVE MIR-FNDTAX-EFF-DT     TO HOLD-EFF-DATE.

           MOVE MIR-UNIT-ELIG-INT-AMT TO HOLD-INT-EL.

           MOVE MIR-UNIT-INELG-INT-AMT
                                      TO HOLD-INT-NEL.

           MOVE MIR-UNIT-ELIG-DIV-AMT TO HOLD-DIV-EL.

           MOVE MIR-UNIT-INELG-DIV-AMT
                                      TO HOLD-DIV-NEL.

           MOVE MIR-UNIT-OTHR-INCM-AMT
                                      TO HOLD-OTHER.

           MOVE MIR-UNIT-CDN-GAIN-AMT TO HOLD-RNCG-CND.

           MOVE MIR-UNIT-FRGN-GAIN-AMT
                                      TO HOLD-RNCG-FOR.

           MOVE MIR-FNDTAX-TOT-AMT    TO HOLD-TOTAL.

           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE MIR-UNIT-ELIG-INT-AMT TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-ELIG-INT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT-V09  TO HOLD-INT-EL-OUT
008455     END-IF.
008455
           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE MIR-UNIT-INELG-INT-AMT
                                      TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-INELG-INT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT-V09  TO HOLD-INT-NEL-OUT
008455     END-IF.
008455
           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE MIR-UNIT-ELIG-DIV-AMT TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-ELIG-DIV-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT-V09  TO HOLD-DIV-EL-OUT
008455     END-IF.
008455
           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE MIR-UNIT-INELG-DIV-AMT
                                      TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-INELG-DIV-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT-V09  TO HOLD-DIV-NEL-OUT
008455     END-IF.
008455
           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE MIR-UNIT-OTHR-INCM-AMT
                                      TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-OTHR-INCM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT-V09  TO HOLD-OTHER-OUT
008455     END-IF.
008455
           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE MIR-UNIT-CDN-GAIN-AMT TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-CDN-GAIN-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT-V09  TO HOLD-RNCG-CND-OUT
008455     END-IF.
008455
           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE MIR-UNIT-FRGN-GAIN-AMT
                                      TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-FRGN-GAIN-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT-V09  TO HOLD-RNCG-FOR-OUT
008455     END-IF.
008455
           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE MIR-FNDTAX-TOT-AMT    TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-FNDTAX-TOT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT-V09  TO HOLD-TOTAL-OUT
008455     END-IF.
008455

       0600-MAP-TO-HOLD-X.
           EXIT.
      /
      *------------------
       1000-PROCESS-RETRIEVE.
      *------------------

           MOVE HOLD-FUND             TO WFT-FND-ID.
021239     MOVE HOLD-FNDVL-UNIT-TYP-CD TO WFT-FNDVL-UNIT-TYP-CD.
           MOVE HOLD-JUL-EFF-DATE     TO WFT-FNDVL-IDT-NUM-N.

           PERFORM  FT-1000-READ
               THRU FT-1000-READ-X.

           IF  WFT-IO-OK
               CONTINUE
           ELSE
               PERFORM  FT-1000-CREATE
                   THRU FT-1000-CREATE-X
      *MSG: A TAX RECORD DOES NOT EXIST FOR THIS KEY
               MOVE 'SS01400010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  8100-FT-TO-OUTPUT
               THRU 8100-FT-TO-OUTPUT-X.

       1000-PROCESS-RETRIEVE-X.
           EXIT.

      *------------------
       2000-PROCESS-DELETE.
      *------------------

           MOVE HOLD-FUND             TO WFT-FND-ID.
021239     MOVE HOLD-FNDVL-UNIT-TYP-CD TO WFT-FNDVL-UNIT-TYP-CD.
           MOVE HOLD-JUL-EFF-DATE     TO WFT-FNDVL-IDT-NUM-N.

           PERFORM  FT-1000-READ-FOR-UPDATE
               THRU FT-1000-READ-FOR-UPDATE-X.

           EVALUATE TRUE

               WHEN WFT-IO-OK
                    PERFORM  FT-1000-DELETE
                        THRU FT-1000-DELETE-X

014221* UPDATE TIMESTAMP OF THE MASTER FH
014221              PERFORM  FH-1000-READ-FOR-UPDATE
014221                  THRU FH-1000-READ-FOR-UPDATE-X
014221              PERFORM  FH-2000-REWRITE
014221                  THRU FH-2000-REWRITE-X
014221              PERFORM  FH-1000-READ-TWRK-TS
014221                  THRU FH-1000-READ-TWRK-TS-X
      *MSG: TAX RECORD SUCCESSFULLY DELETED
                    MOVE 'SS01400020' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN OTHER
      *MSG: A TAX RECORD DOES NOT EXIST FOR THIS KEY
                    MOVE 'SS01400010' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.


       2000-PROCESS-DELETE-X.
           EXIT.
      /
      *-------------------
       3000-PROCESS-CREATE.
      *-------------------

           IF  MIR-DV-PRCES-STATE-CD = '1'
           OR  MIR-DV-PRCES-STATE-CD = '2'
           OR  MIR-DV-PRCES-STATE-CD = '3'
               CONTINUE
           ELSE
               SET MIR-RETRN-INVALD-RQST
                                      TO TRUE
               GO TO 3000-PROCESS-CREATE-X
           END-IF.

           MOVE HOLD-FUND             TO WFT-FND-ID.
021239     MOVE HOLD-FNDVL-UNIT-TYP-CD TO WFT-FNDVL-UNIT-TYP-CD.
           MOVE HOLD-JUL-EFF-DATE     TO WFT-FNDVL-IDT-NUM-N.
           PERFORM  FT-1000-READ
               THRU FT-1000-READ-X.

           IF  WFT-IO-OK
      *MSG: A TAX RECORD ALREADY EXISTS FOR THIS KEY
              MOVE 'SS01400011'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3000-PROCESS-CREATE-X
           END-IF.

           PERFORM  3100-VERIFY-EFFD
               THRU 3100-VERIFY-EFFD-X.

           IF  WGLOB-MSG-ERROR-SW = 1
               GO TO 3000-PROCESS-CREATE-X
           END-IF.

           EVALUATE MIR-DV-PRCES-STATE-CD

               WHEN '1'
                    PERFORM  FT-1000-CREATE
                        THRU FT-1000-CREATE-X
      *MSG: PLEASE CREATE DETAILED TAX INFORMATION
                    MOVE 'SS01400019' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN '2'
                    PERFORM  6100-CHECK-MAINTAIN
                        THRU 6100-CHECK-MAINTAIN-X
      *MSG: PLEASE VERIFY THE TAX INFORMATION
                    MOVE 'SS01400022' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN '3'
                    PERFORM  6100-CHECK-MAINTAIN
                        THRU 6100-CHECK-MAINTAIN-X
                    PERFORM  FT-1000-WRITE
                        THRU FT-1000-WRITE-X
      *MSG: TAX RECORD SUCCESSFULLY CREATED
                    MOVE 'SS01400023' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
014221* UPDATE TIMESTAMP OF THE MASTER FH
014221              PERFORM  FH-1000-READ-FOR-UPDATE
014221                  THRU FH-1000-READ-FOR-UPDATE-X
014221              PERFORM  FH-2000-REWRITE
014221                  THRU FH-2000-REWRITE-X
014221              PERFORM  FH-1000-READ-TWRK-TS
014221                  THRU FH-1000-READ-TWRK-TS-X

           END-EVALUATE.

           IF  WGLOB-MSG-ERROR-SW = 0
               PERFORM  8100-FT-TO-OUTPUT
                   THRU 8100-FT-TO-OUTPUT-X
           END-IF.

       3000-PROCESS-CREATE-X.
           EXIT.

      *-------------------
       3100-VERIFY-EFFD.
      *-------------------

           MOVE HOLD-JUL-EFF-DATE     TO WFV-FNDVL-IDT-NUM-N.
           MOVE HOLD-FUND             TO WFV-FND-ID.
021239     MOVE HOLD-FNDVL-UNIT-TYP-CD TO WFV-FNDVL-UNIT-TYP-CD.
           PERFORM  FV-1000-READ
               THRU FV-1000-READ-X.

           IF  WFV-IO-NOT-FOUND
               PERFORM  FV-1000-CREATE
                   THRU FV-1000-CREATE-X
           END-IF.

           IF  NOT WFV-IO-OK
      *MSG: EFFECTIVE DATE IS NOT A FUND UNIT PRICE DATE
               MOVE 'SS01400005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       3100-VERIFY-EFFD-X.
           EXIT.

      *-------------------
       6000-PROCESS-UPDATE.
      *-------------------

           IF  MIR-DV-PRCES-STATE-CD = '2'
           OR  MIR-DV-PRCES-STATE-CD = '3'
               CONTINUE
           ELSE
               SET MIR-RETRN-INVALD-RQST
                                      TO TRUE
               GO TO 6000-PROCESS-UPDATE-X
           END-IF.

           MOVE HOLD-FUND             TO WFT-FND-ID.
           MOVE HOLD-JUL-EFF-DATE     TO WFT-FNDVL-IDT-NUM-N.
021239     MOVE HOLD-FNDVL-UNIT-TYP-CD TO WFT-FNDVL-UNIT-TYP-CD.
           PERFORM  FT-1000-READ-FOR-UPDATE
               THRU FT-1000-READ-FOR-UPDATE-X.

           IF  NOT WFT-IO-OK
      *MSG: A TAX RECORD DOES NOT EXIST FOR THIS KEY
               MOVE 'SS01400010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  6100-CHECK-MAINTAIN
               THRU 6100-CHECK-MAINTAIN-X.

           IF WGLOB-MSG-ERROR-SW = 1
               PERFORM  FT-3000-UNLOCK
                   THRU FT-3000-UNLOCK-X
               GO TO 6000-PROCESS-UPDATE-X
557660     END-IF.

           EVALUATE MIR-DV-PRCES-STATE-CD

               WHEN '2'
                    PERFORM  FT-3000-UNLOCK
                        THRU FT-3000-UNLOCK-X
      *MSG: PLEASE VERIFY THE TAX INFORMATION
                    MOVE 'SS01400022' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN '3'
                    PERFORM  FT-2000-REWRITE
                        THRU FT-2000-REWRITE-X
      *MSG: TAX RECORD SUCCESSFULLY MAINTAINED
                    MOVE 'SS01400024' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
014221* UPDATE TIMESTAMP OF THE MASTER FH
014221              PERFORM  FH-1000-READ-FOR-UPDATE
014221                  THRU FH-1000-READ-FOR-UPDATE-X
014221              PERFORM  FH-2000-REWRITE
014221                  THRU FH-2000-REWRITE-X
014221              PERFORM  FH-1000-READ-TWRK-TS
014221                  THRU FH-1000-READ-TWRK-TS-X

           END-EVALUATE.

       6000-PROCESS-UPDATE-X.
           EXIT.

      *--------------------
       6100-CHECK-MAINTAIN.
      *--------------------

           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE HOLD-INT-EL           TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-ELIG-INT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
               MOVE 'SS01400051'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
008455         MOVE L0280-OUTPUT-V09  TO HOLD-INT-EL-OUT
               MOVE HOLD-INT-EL-OUT   TO WS-IE-AMOUNT
557660     END-IF.

           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE HOLD-INT-NEL          TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-INELG-INT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
               MOVE 'SS01400052'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
008455         MOVE L0280-OUTPUT-V09  TO HOLD-INT-NEL-OUT
               MOVE HOLD-INT-NEL-OUT  TO WS-INE-AMOUNT
557660     END-IF.

           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE HOLD-DIV-EL           TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-ELIG-DIV-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
               MOVE 'SS01400053'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
008455         MOVE L0280-OUTPUT-V09  TO HOLD-DIV-EL-OUT
008455         MOVE HOLD-DIV-EL-OUT   TO WS-DE-AMOUNT
557660     END-IF.

           SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE HOLD-DIV-NEL          TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-INELG-DIV-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
               MOVE 'SS01400054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
008455         MOVE L0280-OUTPUT-V09  TO HOLD-DIV-NEL-OUT
008455         MOVE HOLD-DIV-NEL-OUT  TO WS-DNE-AMOUNT
557660     END-IF.

008455     SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE HOLD-OTHER            TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-OTHR-INCM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
               MOVE 'SS01400055'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
008455         MOVE L0280-OUTPUT-V09  TO HOLD-OTHER-OUT
008455         MOVE HOLD-OTHER-OUT    TO WS-OI-AMOUNT
557660     END-IF.

008455     SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE HOLD-RNCG-CND         TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-CDN-GAIN-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
               MOVE 'SS01400056'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
008455         MOVE L0280-OUTPUT-V09  TO HOLD-RNCG-CND-OUT
008455         MOVE HOLD-RNCG-CND-OUT TO WS-CGC-AMOUNT
557660     END-IF.

008455     SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE HOLD-RNCG-FOR         TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-UNIT-FRGN-GAIN-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
               MOVE 'SS01400057'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
008455         MOVE L0280-OUTPUT-V09  TO HOLD-RNCG-FOR-OUT
008455         MOVE HOLD-RNCG-FOR-OUT TO WS-CGF-AMOUNT
557660     END-IF.

008455     SET L0280-SIGN-PERMITTED   TO TRUE.
008455     MOVE 9                     TO L0280-PRECISION.
008455     MOVE HOLD-TOTAL            TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-FNDTAX-TOT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
               MOVE 'SS01400058'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
008455         MOVE L0280-OUTPUT-V09  TO HOLD-TOTAL-OUT
008455         MOVE HOLD-TOTAL-OUT    TO WS-T-AMOUNT
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               COMPUTE WS-RUN-T-AMOUNT = WS-IE-AMOUNT +
                                         WS-INE-AMOUNT +
                                         WS-DE-AMOUNT +
                                         WS-DNE-AMOUNT +
                                         WS-OI-AMOUNT +
                                         WS-CGC-AMOUNT +
                                         WS-CGF-AMOUNT
               IF WS-RUN-T-AMOUNT NOT = WS-T-AMOUNT
                   MOVE 'SS01400059'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  7000-HOLD-TO-FT
                   THRU 7000-HOLD-TO-FT-X
557660     END-IF.

       6100-CHECK-MAINTAIN-X.
           EXIT.
      /
      *----------------
       7000-HOLD-TO-FT.
      *----------------

005409     MOVE HOLD-INT-EFF-DATE     TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO RFT-FNDTAX-EFF-DT.

           MOVE WS-IE-AMOUNT          TO RFT-UNIT-ELIG-INT-AMT.
           MOVE WS-INE-AMOUNT         TO RFT-UNIT-INELG-INT-AMT.
           MOVE WS-DE-AMOUNT          TO RFT-UNIT-ELIG-DIV-AMT.
           MOVE WS-DNE-AMOUNT         TO RFT-UNIT-INELG-DIV-AMT.
           MOVE WS-OI-AMOUNT          TO RFT-UNIT-OTHR-INCM-AMT.
           MOVE WS-CGC-AMOUNT         TO RFT-UNIT-CDN-GAIN-AMT.
           MOVE WS-CGF-AMOUNT         TO RFT-UNIT-FRGN-GAIN-AMT.

           MOVE WS-T-AMOUNT           TO RFT-FNDTAX-TOT-AMT.


       7000-HOLD-TO-FT-X.
           EXIT.
      /
      *------------------
       8100-FT-TO-OUTPUT.
      *------------------

           MOVE HOLD-FUND             TO MIR-FND-ID.
021239     MOVE HOLD-FNDVL-UNIT-TYP-CD TO MIR-FNDVL-UNIT-TYP-CD.
           MOVE HOLD-EFF-DATE         TO MIR-FNDTAX-EFF-DT.

           MOVE RFT-UNIT-ELIG-INT-AMT TO HOLD-INT-EL-OUT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFT-UNIT-ELIG-INT-AMT
020874*                                 * 1000000000.
020874     MOVE RFT-UNIT-ELIG-INT-AMT TO L0290-INPUT-V09.
008455     MOVE 9                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UNIT-ELIG-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UNIT-ELIG-INT-AMT.
008455
           MOVE RFT-UNIT-INELG-INT-AMT
                                      TO HOLD-INT-NEL-OUT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFT-UNIT-INELG-INT-AMT
020874*                                 * 1000000000.
020874     MOVE RFT-UNIT-INELG-INT-AMT TO L0290-INPUT-V09.
008455     MOVE 9                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UNIT-INELG-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UNIT-INELG-INT-AMT.

           MOVE RFT-UNIT-ELIG-DIV-AMT TO HOLD-DIV-EL-OUT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFT-UNIT-ELIG-DIV-AMT
020874*                                 * 1000000000.
020874     MOVE RFT-UNIT-ELIG-DIV-AMT TO L0290-INPUT-V09.
008455     MOVE 9                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UNIT-ELIG-DIV-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UNIT-ELIG-DIV-AMT.
008455
           MOVE RFT-UNIT-INELG-DIV-AMT
                                      TO HOLD-DIV-NEL-OUT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFT-UNIT-INELG-DIV-AMT
020874*                                 * 1000000000.
020874     MOVE RFT-UNIT-INELG-DIV-AMT TO L0290-INPUT-V09.
008455     MOVE 9                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UNIT-INELG-DIV-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UNIT-INELG-DIV-AMT.

           MOVE RFT-UNIT-OTHR-INCM-AMT
                                      TO HOLD-OTHER-OUT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFT-UNIT-OTHR-INCM-AMT
020874*                                 * 1000000000.
020874     MOVE RFT-UNIT-OTHR-INCM-AMT TO L0290-INPUT-V09.
008455     MOVE 9                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UNIT-OTHR-INCM-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UNIT-OTHR-INCM-AMT.
008455
           MOVE RFT-UNIT-CDN-GAIN-AMT TO HOLD-RNCG-CND-OUT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFT-UNIT-CDN-GAIN-AMT
020874*                                 * 1000000000.
020874     MOVE RFT-UNIT-CDN-GAIN-AMT TO L0290-INPUT-V09.
008455     MOVE 9                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UNIT-CDN-GAIN-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UNIT-CDN-GAIN-AMT.

           MOVE RFT-UNIT-FRGN-GAIN-AMT
                                      TO HOLD-RNCG-FOR-OUT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFT-UNIT-FRGN-GAIN-AMT
020874*                                 * 1000000000.
020874     MOVE RFT-UNIT-FRGN-GAIN-AMT TO L0290-INPUT-V09.
008455     MOVE 9                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UNIT-FRGN-GAIN-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UNIT-FRGN-GAIN-AMT.

           MOVE RFT-FNDTAX-TOT-AMT    TO HOLD-TOTAL-OUT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFT-FNDTAX-TOT-AMT
020874*                                 * 1000000000.
020874     MOVE RFT-FNDTAX-TOT-AMT    TO L0290-INPUT-V09.
008455     MOVE 9                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-FNDTAX-TOT-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-FNDTAX-TOT-AMT.

       8100-FT-TO-OUTPUT-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE HOLD-MAP.
025970     INITIALIZE WS-MISC-AREA.

025970     SET WS-TWRK-KEY-DEFAULT    TO TRUE.

025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.

025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
025970 COPY XCPS1680.
005409 COPY XCPL1680.
      /
013578*COPY XCPS2510.
013578*COPY XCCL2510.
013578*
       COPY XCPPINIT.
       COPY XCPPEXIT.
012624*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY FH
014221                         '$VAR2' BY 'FH'.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
008455 COPY XCPL0280.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
       COPY SCPNFV.
       COPY SCPCFV.
      /
021239 COPY SCPNFUTP.
021239
       COPY SCPNFH.
016537*COPY SCPCFH.
014221 COPY SCPUFH.
      /
       COPY SCPAFT.
       COPY SCPNFT.
       COPY SCPUFT.
       COPY SCPXFT.
       COPY SCPCFT.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM SSOM0140                     **
      *****************************************************************
