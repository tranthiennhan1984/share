      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0691.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0691                                         **
      **  REMARKS:  TERM - PROCESS POLICY OR COVERAGE                **
      **                   TERMINATION OR REINSTATEMENT              **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       ABEND HANDLING                                   **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZING FOR INTERNATIONAL SUPPT      **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEANUP AND STANDARDIZATION                 **
012134**  5.6V      TAXATION OF VARIABLE PRODUCTS                    **
012136**  5.6V      FREE LOOK PROCESSING                             **
012137**  5.6V      SEC CONFIRMATIONS                                **
012696**  5.6V      ALLOCATIONS                                      **
014035**  5.6V      CODE CLEAN-UP & STANDARDIZATION                  **
014765**  5.6A      CODE CLEAN-UP & STANDARDIZATION                  **
012624**  6.0       POLICY ACCESS VERIFICATION                       **
013578**  6.0       ADD DV-NOT-TAKEN-CD & DV-TAX-SURR-CD             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
013693**  6.2       LOCATION INCOME TAX WITHHOLD                     **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016686**  6.2       INGENIUM PROCESSING DATE CHANGES FOR CONCURRENCY **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
016158**  6.3       DEFERRED TERMINATION PROCESSING (6.1.2J)         **
018731**  6.3       EFT ENHANCEMENTS                                 **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018844**  6.3       REPLACEMENT PROCESSING FOR U.S. POLICIES         **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
019360**  6.4       SPECIAL LTAXWH CALC CODE FOR SURRENDER           **
020463**  6.4       INVESTOR PROFILES                                **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
023393**  6.5       BYPASS LOCATION TAX WITHHELD                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
023444**  6.5       QUOTE INCOME ON WITHDRAWALS                      **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023438**  6.5       1035 EXCHANGE WITH LOAN                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
032896**  7.0       CODE CLEANUP AND STANDARDIZATION                 **
026947**  7.1       PAC/CRC/DD2 SCHEDULE AT REVERSAL                 **
032623**  7.1       PHST GROUPING                                    **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

       CONFIGURATION SECTION.
      /
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0691'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *
       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

007766 COPY XCWWCVGM.

016537*01  FILLER                PIC X(1000).

       01  WS-PGM-WORK-AREA.
016548*    05  WS-SUB            PIC S9(04) COMP.
016548     05  WS-SUB            PIC S9(04) BINARY.
016548*    05  I                 PIC S9(04) COMP.
016548     05  I                 PIC S9(04) BINARY.
012134*    05  WS-SEGF-SUB       PIC S9(04) COMP.
           05  WS-CVG-LIST.
016548*        10  WS-CVG-TO-PROCESS PIC S9(04) COMP
016548         10  WS-CVG-TO-PROCESS PIC S9(04) BINARY
007766                           OCCURS 20.
007766*                          OCCURS 99.
012134*    05  WS-SEGUNDS-IND          PIC X(01).
012134*        88  WS-NO-SEGFUNDS      VALUE 'N'.
012134*        88  WS-SEGFUNDS         VALUE 'Y'.
012134*    05  WS-SEGUND-ERR-IND       PIC X(01).
012134*        88  WS-SEGFUND-ERROR    VALUE 'N'.
012134*        88  WS-NO-SEGFUND-ERROR VALUE 'Y'.
012136     05  WS-FREE-LOOK-NTU-PRCES-CD      PIC X(01).
012136         88  WS-FREE-LOOK-NTU-PRCES-NO  VALUE 'N'.
012136         88  WS-FREE-LOOK-NTU-PRCES     VALUE 'Y'.
           05  WS-BUS-FCN-ID                  PIC X(04).
020478*        88  WS-BUS-FCN-VALID           VALUE '1450' THRU '1465'.
020478         88  WS-BUS-FCN-VALID           VALUE '1450' THRU '1459'
020478                                              '1462' THRU '1465'.
               88  WS-BUS-FCN-TNOTKN          VALUE '1450'.
               88  WS-BUS-FCN-RNOTKN          VALUE '1451'.
               88  WS-BUS-FCN-TLAPS           VALUE '1452'.
               88  WS-BUS-FCN-RLAPS           VALUE '1453'.
               88  WS-BUS-FCN-TLAPSWV         VALUE '1454'.
               88  WS-BUS-FCN-RLAPSWV         VALUE '1455'.
               88  WS-BUS-FCN-TCNVR           VALUE '1456'.
               88  WS-BUS-FCN-RCNVR           VALUE '1457'.
               88  WS-BUS-FCN-TDEATH          VALUE '1458'.
               88  WS-BUS-FCN-RDEATH          VALUE '1459'.
020478*        88  WS-BUS-FCN-TSURR           VALUE '1460'.
020478*        88  WS-BUS-FCN-RSURR           VALUE '1461'.
               88  WS-BUS-FCN-TNORMAL         VALUE '1462'.
               88  WS-BUS-FCN-RNORMAL         VALUE '1463'.
               88  WS-BUS-FCN-TREPL           VALUE '1464'.
               88  WS-BUS-FCN-RREPL           VALUE '1465'.
               88  WS-BUS-FCN-TERM            VALUE '1450'
                                                    '1452'
                                                    '1454'
                                                    '1456'
                                                    '1458'
020478*                                             '1460'
                                                    '1462'
                                                    '1464'.
               88  WS-BUS-FCN-REVERSAL        VALUE '1451'
                                                    '1453'
                                                    '1455'
                                                    '1457'
                                                    '1459'
020478*                                             '1461'
                                                    '1463'
                                                    '1465'.
023514*    05  WS-TWRK-KEY               PIC X(04)  VALUE '1450'.
           05  SWITCHES-FOR-691.
               10  WS-LEVEL-SW           PIC X.
                   88  PROCESSING-POLICY     VALUE 'P'.
                   88  PROCESSING-COVERAGE   VALUE 'C'.
               10  POLICY-LOCK-SW        PIC X.
                   88  POLICY-NOT-LOCKED     VALUE 'N'.
                   88  POLICY-LOCKED         VALUE 'Y'.
               10  UPDATE-SW             PIC X.
                   88  UPDATE-NOT-REQUIRED   VALUE 'N'.
                   88  UPDATE-REQUIRED       VALUE 'Y'.
013578         10  DEFERRED-TRANS-SW     PIC X.
013578             88  NOT-DEFERRED-TRANS    VALUE 'N'.
013578             88  DEFERRED-TRANS        VALUE 'Y'.
016503         10  WS-REDO-SW                PIC X(01).
016503             88  WS-REDO-OK            VALUE 'Y'.
016503             88  WS-REDO-NOT-OK        VALUE 'N'.
016158         10  WS-FREE-LOOK-CHECK-SW     PIC X(01).
016158             88  WS-FREE-LOOK-CHECK-NO VALUE 'N'.
016158             88  WS-FREE-LOOK-CHECK-YES VALUE 'Y'.
               10  HOLD-FIELDS-FOR-691.
008453*            15  HOLD-INPUT-DATE       PIC X(9).
                   15  HOLD-INPUT-DATE       PIC X(10).
                   15  POLICY-HOLD.
                      20  FILLER            PIC X.
                      20  FILLER            PIC 9(8).
                      20  POLICY-LAST       PIC X.
                   15 WORK-FIELDS-FOR-691.
557973*               20  WS-REFUND-AMT         PIC S9(7)V99   COMP-3.
557973*               20  WS-AMOUNT-EDITED      PIC -9(07).99.
                      20  DISPLAY-SUB           PIC 99.
557973*               20  WS-ED-PAYOUT-AMOUNT   PIC -(08)9.99.
008455*               20  WS-ED-PAYOUT-AMOUNT   PIC -(12)9.99.
023444     05  WS-TRMN-AMT             PIC S9(13)V9(02) COMP-3.
023444
031037     05  WS-LOOP-SW                   PIC X(01).
031037         88  WS-LOOP-NOT-END          VALUE 'N'.
031037         88  WS-LOOP-END              VALUE 'Y'.
026947     05  WS-SAVE-PMT-DRW-DT           PIC X(10).
029060     05  WS-REVRS-PCHST-SEQ-NUM       PIC S9(05) COMP-3.
023437
      ***********************************************************
      * COMMON COPYBOOKS
      ***********************************************************
       COPY XCWWWKDT.
      /
557756*COPY CCWTYSNO.
       COPY XCWLDTLK.
       COPY XCWL1640.
031037 COPY XCWL1660.
014221 COPY XCWL8090.
      /
008453*COPY XCWTDTTB.
014035*COPY CCWW1160.
014221 COPY CCWWLOCK.
      /
       COPY CCWE0691.
013693/
013693 COPY XCWEBLCH.
      /
023437 COPY XCWL0316.
023437 COPY CCWLTAXC.
032896*COPY CCWLTAXW.
023437
      **********************************************************
      * I/O COPYBOOKS
      **********************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
012136 COPY CCFWPH.
012136 COPY CCFRPH.
012136/
031037 COPY CCFWPHST.
031037 COPY CCFRPHST.
031037/
       COPY CCFHPOL.
       COPY CCFWPOL.
      /
      ***********************************************************
      * CALLED MODULE PARAMETER INFORMATION
      ***********************************************************
020478 COPY CCWL2626.
016158 COPY CCWL0182.
016503 COPY CCWL0201.
016503 COPY CCWL0289.
013578 COPY CCWL0620.
016108 COPY CCWL0985.
       COPY CCWL1110.
       COPY CCWL1120.
       COPY CCWL1130.
       COPY CCWL1140.
       COPY CCWL1150.
       COPY CCWL1160.
       COPY CCWL1170.
       COPY CCWL1180.
      /
032623 COPY CCWL2408.
       COPY CCWL2430.
020463/
020463 COPY CCWL2735.
      /
018731 COPY CCWL4382.
018731/
       COPY CCWL4750.
      /
016503 COPY CCWL4780.
      /
       COPY CCWL5400.
      /
016158 COPY FCWL8170.
012136 COPY FCWL8250.
012136/
012136 COPY FCWLFUND.
012136/
012134*COPY SCWL5435.
012134*
014035*COPY XCWL1670.
       COPY XCWL0280.
018844 COPY XCWL0290.
      /
      **********************************************************
      * INPUT PARAMETER INFORMATION
      **********************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      /
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0691.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018844     PERFORM  0290-1000-BUILD-PARM-INFO
018844         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  0200-PROCESS-TRANSACTIONS
               THRU 0200-PROCESS-TRANSACTIONS-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------------
       0200-PROCESS-TRANSACTIONS.
      *--------------------------
      *
023514*    INITIALIZE WS-PGM-WORK-AREA.
023514*
           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.

           PERFORM  1000-SAVE-INPUT
               THRU 1000-SAVE-INPUT-X.

           IF  MIR-DV-PRCES-STATE-CD = '1'
               PERFORM  1700-RESET-TO-HF-1
                   THRU 1700-RESET-TO-HF-1-X
           END-IF.

           PERFORM  1100-SET-UP-OUTPUT-MAP
               THRU 1100-SET-UP-OUTPUT-MAP-X.

           SET UPDATE-NOT-REQUIRED           TO TRUE.
013578     SET NOT-DEFERRED-TRANS            TO TRUE.

           PERFORM  2000-TERM-PROCESSING
               THRU 2000-TERM-PROCESSING-X.
032623     MOVE ZERO                         TO WGLOB-PCHST-REL-SEQ-NUM.

       0200-PROCESS-TRANSACTIONS-X.
           EXIT.
      /
      *----------------
       1000-SAVE-INPUT.
      *----------------
      *
      *  THIS ROUTINE SAVES THE INPUT FROM THE SCREEN
      *
           MOVE SPACES                TO E0691-EDIT-AREA.
           MOVE MIR-POL-ID-BASE       TO POLICY-HOLD.
           MOVE MIR-POL-ID-SFX        TO POLICY-LAST.
013578*    MOVE MIR-DV-CLI-NM         TO E0691-OWNER-NAME.
013578     MOVE MIR-DV-OWN-CLI-NM     TO E0691-OWNER-NAME.
           MOVE MIR-CVG-NUM           TO E0691-COV-X.
           MOVE MIR-BUS-FCN-ID        TO E0691-CODE.
013578*    MOVE MIR-DV-INSRD-DTH-CD   TO E0691-DEATH-CODE.
013578
013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-TNOTKN
013578              MOVE MIR-DV-NOT-TAKEN-CD
016158*                               TO E0691-DEATH-CODE
016158                                TO E0691-NTU-RFND-DEST-CD
013578
020478*        WHEN WS-BUS-FCN-TSURR
018844         WHEN WS-BUS-FCN-TREPL
018844*             MOVE MIR-DV-SURR-TAX-CD
018844              MOVE MIR-SURR-TAX-OVRID-CD
016158*                               TO E0691-DEATH-CODE
016158                                TO E0691-SURR-TAX-OVRID-CD
013578         WHEN OTHER
013578              MOVE MIR-DV-INSRD-DTH-CD
013578                                TO E0691-DEATH-CODE
013578
013578     END-EVALUATE.
013578
016537     IF E0691-DEATH-CODE = EBLCH-BLANK-FIELD-CHAR
016537        MOVE SPACES        TO E0691-DEATH-CODE
016537     END-IF.

023437*    MOVE MIR-DV-TAX-OVRID-IND  TO E0691-TAX-BYPASS-SW.
029060*    IF  MIR-LTAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
029060*       MOVE SPACES          TO MIR-LTAXWH-CALC-CD
029060*    END-IF.
029060*    MOVE MIR-LTAXWH-CALC-CD    TO E0691-LTAXWH-CALC-CD.
029060
029060     IF  MIR-LTAXWH-RQST-CD = EBLCH-BLANK-FIELD-CHAR
029060         MOVE SPACES            TO MIR-LTAXWH-RQST-CD
029060     END-IF.
029060
029060     MOVE MIR-LTAXWH-RQST-CD    TO E0691-LTAXWH-CALC-CD.
016686*    MOVE MIR-APPL-CTL-PRCES-DT TO HOLD-INPUT-DATE.
016686     MOVE MIR-DV-EFF-DT         TO HOLD-INPUT-DATE.
016686*    MOVE MIR-APPL-CTL-PRCES-DT TO L1640-EXTERNAL-DATE.
016686     MOVE MIR-DV-EFF-DT         TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO E0691-EFF-DATE.
018731*    MOVE MIR-DV-CHQ-CREAT-IND  TO E0691-CHEQUE-IND.
018731     MOVE MIR-DV-SELCT-PAYO-MTHD-CD
018731                                TO E0691-PAYO-MTHD-CD.
018731     MOVE MIR-CLI-ID            TO E0691-CLI-ID.
018731     MOVE MIR-CLI-BNK-ACCT-NUM  TO E0691-CLI-BNK-ACCT-NUM.
           MOVE POLICY-HOLD           TO WPOL-POL-ID.
026055
026055     IF  WS-BUS-FCN-TDEATH
026055         SET E0691-PAYO-MTHD-NOT-REQ TO TRUE
026055     END-IF.

       1000-SAVE-INPUT-X.
           EXIT.

      *-----------------------
       1100-SET-UP-OUTPUT-MAP.
      *-----------------------
      *
      **  THIS ROUTINE INITIALIZES THE OUTPUT MAP
      *
           MOVE ZERO                  TO WGLOB-RETURN-CODE.
           MOVE POLICY-HOLD           TO MIR-POL-ID-BASE.
           MOVE POLICY-LAST           TO MIR-POL-ID-SFX.
013578*    MOVE E0691-OWNER-NAME      TO MIR-DV-CLI-NM.
013578
013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE MIR-POL-ID                    TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.
010311***  MOVE E0691-COV-NO         TO MIR-CVG-NUM.
010311     MOVE E0691-COV-X           TO MIR-CVG-NUM.
013578*    MOVE E0691-DEATH-CODE      TO MIR-DV-INSRD-DTH-CD.
013578
013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-TNOTKN
016158*            MOVE E0691-DEATH-CODE
016158             MOVE E0691-NTU-RFND-DEST-CD
013578                                TO MIR-DV-NOT-TAKEN-CD
013578
020478*        WHEN WS-BUS-FCN-TSURR
018844         WHEN WS-BUS-FCN-TREPL
016158*             MOVE E0691-DEATH-CODE
016158              MOVE E0691-SURR-TAX-OVRID-CD
018844*                               TO MIR-DV-SURR-TAX-CD
018844                                TO MIR-SURR-TAX-OVRID-CD
013578
013578         WHEN OTHER
013578              MOVE E0691-DEATH-CODE
013578                                TO MIR-DV-INSRD-DTH-CD
013578
013578     END-EVALUATE.
013578
016686*    MOVE HOLD-INPUT-DATE       TO MIR-APPL-CTL-PRCES-DT.
016686     MOVE HOLD-INPUT-DATE       TO MIR-DV-EFF-DT.
018731*    MOVE E0691-CHEQUE-IND      TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO MIR-DV-SELCT-PAYO-MTHD-CD.
018731     MOVE E0691-CLI-ID          TO MIR-CLI-ID.
018731     MOVE E0691-CLI-BNK-ACCT-NUM
018731                                TO MIR-CLI-BNK-ACCT-NUM.
023437*    MOVE E0691-TAX-BYPASS-SW   TO MIR-DV-TAX-OVRID-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO MIR-LTAXWH-CALC-CD.
029060     MOVE E0691-LTAXWH-CALC-CD  TO MIR-LTAXWH-RQST-CD.
013693
023437     IF  RPOL-POL-CTRY-US
013693         IF  MIR-DV-PRCES-STATE-CD = '1'
013693         OR  MIR-DV-PRCES-STATE-CD = '2'
029060*            IF  (MIR-LTAXWH-CALC-CD  = 'B'
029060*            OR  MIR-LTAXWH-CALC-CD   = 'S')
029060             IF  (MIR-LTAXWH-RQST-CD  = 'B'
029060             OR  MIR-LTAXWH-RQST-CD   = 'S')
013693             AND (L2430-CLI-TXEMP-CD  = 'D'
013693             OR   L2430-CLI-TXEMP-CD  = 'M'
013693             OR   L2430-CLI-TXEMP-CD  = 'N'
013693             OR   L2430-CLI-TXEMP-CD  = 'S')
013693*MSG: (F) 'CLIENT HAS B-NOTICE CALCUATION ONLY ALLOWED'
013693                  MOVE 'CS06914303'        TO  WGLOB-MSG-REF-INFO
013693                  PERFORM  0260-1000-GENERATE-MESSAGE
013693                      THRU 0260-1000-GENERATE-MESSAGE-X
023437             END-IF
013693        END-IF
013693     END-IF.
013693

       1100-SET-UP-OUTPUT-MAP-X.
           EXIT.

      /
      *-------------------
       1700-RESET-TO-HF-1.
      *-------------------
      *
      **  THIS ROUTINE SETS THE SCREEN TO A STARTING/OPEN POSITION
      **
      **  1. SET INITIAL/DEFAULT VALUES FOR SCREEN FIELDS

013578*    MOVE SPACES                TO MIR-DV-CLI-NM.
013578     MOVE SPACES                TO MIR-DV-OWN-CLI-NM.
           MOVE SPACES                TO MIR-DV-INSRD-DTH-CD.
013578     MOVE SPACES                TO MIR-DV-NOT-TAKEN-CD.
018844*    MOVE SPACES                TO MIR-DV-SURR-TAX-CD.
018844     MOVE SPACES                TO MIR-SURR-TAX-OVRID-CD.
018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD
018731     MOVE SPACES                TO MIR-CLI-ID.
018731     MOVE SPACES                TO MIR-CLI-BNK-ACCT-NUM.
023437*    MOVE 'N'                   TO MIR-DV-TAX-OVRID-IND.
029060*    MOVE 'C'                   TO MIR-LTAXWH-CALC-CD.
029060     MOVE 'C'                   TO MIR-LTAXWH-RQST-CD.

       1700-RESET-TO-HF-1-X.
           EXIT.
      /
      *---------------------
       2000-TERM-PROCESSING.
      *---------------------

           PERFORM  3000-GENERAL-TRANS-EDITS
               THRU 3000-GENERAL-TRANS-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
014221     OR  MIR-RETRN-TS-MISMATCH
               GO TO 2000-TERM-PROCESSING-X
           END-IF.

           IF E0691-COV-NO = ZERO
               SET PROCESSING-POLICY          TO TRUE
           ELSE
               SET PROCESSING-COVERAGE        TO TRUE
           END-IF.

012134*    IF  MIR-DV-PRCES-STATE-CD = '2'
012134*        PERFORM  5435-1000-BUILD-PARM-INFO
012134*            THRU 5435-1000-BUILD-PARM-INFO-X
012134*    END-IF.
012134*

032623     IF  MIR-DV-PRCES-STATE-CD = '3'
032623         PERFORM  2408-0000-INIT-PARM-INFO
032623             THRU 2408-0000-INIT-PARM-INFO-X
032623         MOVE RPOL-POL-ID              TO L2408-POL-ID
032623         MOVE E0691-EFF-DATE           TO L2408-EFF-DT
032623         PERFORM  2408-2000-NXT-PHST-SEQ
032623             THRU 2408-2000-NXT-PHST-SEQ-X
032623         MOVE L2408-NXT-PCHST-SEQ-NUM  TO WGLOB-PCHST-REL-SEQ-NUM
032623     END-IF.
           EVALUATE TRUE

               WHEN WS-BUS-FCN-TNOTKN
                   PERFORM  3200-NTU
                       THRU 3200-NTU-X

               WHEN WS-BUS-FCN-TLAPS
                   PERFORM  3210-LAPSE
                       THRU 3210-LAPSE-X

               WHEN WS-BUS-FCN-TLAPSWV
                   PERFORM  3220-LAPSE-W-VALUE
                       THRU 3220-LAPSE-W-VALUE-X

               WHEN WS-BUS-FCN-TCNVR
                   PERFORM  3230-CONVERT
                       THRU 3230-CONVERT-X

               WHEN WS-BUS-FCN-TDEATH
                   PERFORM  3240-DEATH
                       THRU 3240-DEATH-X

020478*        WHEN WS-BUS-FCN-TSURR
020478*            PERFORM  3250-SURRENDER
020478*                THRU 3250-SURRENDER-X

               WHEN WS-BUS-FCN-TNORMAL
                   PERFORM  3260-MAT-EXP
                       THRU 3260-MAT-EXP-X

               WHEN WS-BUS-FCN-TREPL
                   PERFORM  3270-REPLACEMENT
                       THRU 3270-REPLACEMENT-X

               WHEN WS-BUS-FCN-RNOTKN
                   PERFORM  3300-REV-NTU
                       THRU 3300-REV-NTU-X

               WHEN WS-BUS-FCN-RLAPS
                   PERFORM  3310-REV-LAPSE
                       THRU 3310-REV-LAPSE-X

               WHEN WS-BUS-FCN-RLAPSWV
                   PERFORM  3320-REV-LAPSE-W-VAL
                       THRU 3320-REV-LAPSE-W-VAL-X

               WHEN WS-BUS-FCN-RCNVR
                   PERFORM  3330-REV-CONVERT
                       THRU 3330-REV-CONVERT-X

               WHEN WS-BUS-FCN-RDEATH
                   PERFORM  3340-REV-DEATH
                       THRU 3340-REV-DEATH-X

020478*       WHEN WS-BUS-FCN-RSURR
020478*           PERFORM  3350-REV-SURRENDER
020478*               THRU 3350-REV-SURRENDER-X

               WHEN WS-BUS-FCN-RNORMAL
                   PERFORM  3360-REV-MAT-EXP
                       THRU 3360-REV-MAT-EXP-X

              WHEN WS-BUS-FCN-RREPL
                  PERFORM  3370-REV-REPLACEMENT
                      THRU 3370-REV-REPLACEMENT-X

              WHEN OTHER
                  SET MIR-RETRN-INVALD-RQST
                                      TO TRUE

           END-EVALUATE.

           IF  POLICY-LOCKED
               SET POLICY-NOT-LOCKED              TO TRUE

               IF  UPDATE-REQUIRED
016503*            MOVE WWKDT-ZERO-DT TO RPOL-POL-NXT-ACTV-DT
016503             PERFORM  0289-1000-INIT-PARM-INFO
016503                 THRU 0289-1000-INIT-PARM-INFO-X
016503             MOVE E0691-EFF-DATE  TO L0289-LO-PAC-DT
016503             MOVE E0691-EFF-DATE  TO L0289-LO-CRC-DT
020467             MOVE E0691-EFF-DATE  TO L0289-LO-DD2-DT
016503             MOVE E0691-EFF-DATE  TO L0289-PROC-EFF-DT
026947
026947*            DO NOT SCHEDULE PAC/CRC/DD2 APPLY FOR REVERSAL
026947
026947             MOVE WWKDT-ZERO-DT   TO WS-SAVE-PMT-DRW-DT
026947             IF  WS-BUS-FCN-REVERSAL
026947             AND RPOL-POL-PMT-DRW-DT NOT = WWKDT-ZERO-DT
026947             AND RPOL-POL-PREM-SUSP-AMT <= ZERO
026947                 MOVE RPOL-POL-PMT-DRW-DT
026947                                  TO WS-SAVE-PMT-DRW-DT
026947                 MOVE WWKDT-ZERO-DT
026947                                  TO RPOL-POL-PMT-DRW-DT
026947             END-IF
016503             PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503                 THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503             IF  L0289-RETRN-OK
016503                 MOVE L0289-NXT-ACTV-TYP-CD
016503                      TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE L0289-NXT-ACTV-DT
016503                      TO RPOL-POL-NXT-ACTV-DT
016503             ELSE
016503                 MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE WGLOB-PROCESS-DATE
016503                           TO RPOL-POL-NXT-ACTV-DT
016503             END-IF
026947             IF  WS-SAVE-PMT-DRW-DT NOT =  WWKDT-ZERO-DT
026947                 MOVE WS-SAVE-PMT-DRW-DT
026947                                  TO RPOL-POL-PMT-DRW-DT
026947             END-IF
                   MOVE WGLOB-PROCESS-DATE
                                      TO RPOL-PREV-FILE-MAINT-DT
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
                   PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                       THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
               ELSE
                   PERFORM  POL-3000-UNLOCK
                       THRU POL-3000-UNLOCK-X
               END-IF
           END-IF.

       2000-TERM-PROCESSING-X.
           EXIT.

      *-----------------
       2200-VERIFY-TRAN.
      *-----------------

           IF PROCESSING-COVERAGE
               MOVE E0691-COV-X       TO DISPLAY-SUB
               MOVE DISPLAY-SUB       TO WGLOB-MSG-PARM (1)
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE 'CS06910029'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *
      * WARN IF ACTIVITIES WILL BE REVERSED
      *
           PERFORM  2510-BUILD-4750-INFO
               THRU 2510-BUILD-4750-INFO-X.

           PERFORM  4750-2000-DTRMN-UNDO-PRCES
               THRU 4750-2000-DTRMN-UNDO-PRCES-X.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       2200-VERIFY-TRAN-X.
           EXIT.

016503*-----------------
016503 2400-INVOKE-REDO.
016503*-----------------

016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503         GO TO 2400-INVOKE-REDO-X
016503     END-IF.

016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     MOVE E0691-EFF-DATE                TO L4780-EFF-DT.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
016503     SET L4780-PRCES-INCLUSIVE          TO TRUE.

016503     PERFORM  4780-1000-GET-NEXT-ACT-DT
016503         THRU 4780-1000-GET-NEXT-ACT-DT-X.

016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              SET WS-REDO-NOT-OK           TO TRUE
016503              PERFORM  POL-3000-UNLOCK
016503                  THRU POL-3000-UNLOCK-X
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503             PERFORM  POL-3000-UNLOCK
016503                 THRU POL-3000-UNLOCK-X
016503             MOVE E0691-EFF-DATE      TO L0201-EFF-DT
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X
016503             PERFORM  0289-1000-INIT-PARM-INFO
016503                 THRU 0289-1000-INIT-PARM-INFO-X
016503             MOVE E0691-EFF-DATE  TO L0289-LO-PAC-DT
016503             MOVE E0691-EFF-DATE  TO L0289-LO-CRC-DT
020467             MOVE E0691-EFF-DATE  TO L0289-LO-DD2-DT
016503             MOVE E0691-EFF-DATE  TO L0289-PROC-EFF-DT
016503             PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503                 THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503             IF  L0289-RETRN-OK
016503                 MOVE L0289-NXT-ACTV-TYP-CD
016503                      TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE L0289-NXT-ACTV-DT
016503                      TO RPOL-POL-NXT-ACTV-DT
016503             ELSE
016503                 MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE WGLOB-PROCESS-DATE
016503                           TO RPOL-POL-NXT-ACTV-DT
016503             END-IF
016503             MOVE RPOL-REC-INFO             TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503             SET POLICY-LOCKED              TO TRUE
016503             MOVE HPOL-REC-INFO             TO RPOL-REC-INFO
016158             MOVE WGLOB-PROCESS-DATE TO RPOL-PREV-FILE-MAINT-DT
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
016503             PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                       THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
016503             SET POLICY-NOT-LOCKED            TO TRUE
016503             IF  L0201-RETRN-OK
016503                 PERFORM  POL-1000-READ-FOR-UPDATE
016503                     THRU POL-1000-READ-FOR-UPDATE-X
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503             END-IF
016503     END-EVALUATE.

016503 2400-INVOKE-REDO-X.
016503     EXIT.
      /
      *------------------
       2500-UNDO-PROCESS.
      *------------------

      *  UNLOCK POLICY RECORD (THIS ALLOWS FOR POLICY UPDATES
      *  IN CSLS0065 WHICH CAN BE CALLED FROM CSLS4700).
      *
           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.
           SET POLICY-NOT-LOCKED             TO TRUE.

012136*    PERFORM  2510-BUILD-4750-INFO
012136*        THRU 2510-BUILD-4750-INFO-X.
012136*
012136     IF  WS-FREE-LOOK-NTU-PRCES
012136         PERFORM  2520-BUILD-FL-4750-INFO
012136             THRU 2520-BUILD-FL-4750-INFO-X
012136     ELSE
012136         PERFORM  2510-BUILD-4750-INFO
012136             THRU 2510-BUILD-4750-INFO-X
012136     END-IF.
012136
           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF  WGLOB-RETURN-ERROR
           AND L4750-POL-UPDATE-NOT-REQD
               GO TO 2500-UNDO-PROCESS-X
           END-IF.

      *    LOCK POLICY AGAIN IN ORDER TO DO UPDATES
      *    SAVE POLICY INFO TO RESTORE AFTER READ FOR UPDATE

           MOVE  RPOL-REC-INFO        TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY             TO  WPOL-KEY.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           SET POLICY-LOCKED              TO TRUE.

           MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.

           IF  L4750-POL-UPDATE-REQD
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
               PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                   THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
               SET POLICY-NOT-LOCKED          TO TRUE

               IF  NOT WGLOB-RETURN-ERROR
                   MOVE RPOL-KEY      TO WPOL-KEY
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
                   SET POLICY-LOCKED              TO TRUE
               END-IF
           END-IF.

       2500-UNDO-PROCESS-X.
           EXIT.

      *---------------------
       2510-BUILD-4750-INFO.
      *---------------------

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.

           SET L4750-FCN-DRVR-SECONDARY      TO TRUE.
012136*    MOVE E0691-EFF-DATE               TO L4750-EFF-DT.
012136     IF ( WS-BUS-FCN-TNOTKN
012136     OR  WS-BUS-FCN-RNOTKN )
018763     AND NOT DEFERRED-TRANS
012136         IF  PROCESSING-POLICY
012136             MOVE RPOL-POL-ISS-EFF-DT
                                      TO L4750-EFF-DT
012136         ELSE
012136             MOVE WCVGS-CVG-ISS-EFF-DT (E0691-COV-NO)
012136                                TO L4750-EFF-DT
012136         END-IF
012136     ELSE
012136         MOVE E0691-EFF-DATE    TO L4750-EFF-DT
012136     END-IF.
012136
018731*    MOVE E0691-CHEQUE-IND      TO L4750-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L4750-PAYO-MTHD-CD.

           IF  WS-BUS-FCN-TNOTKN
               SET L4750-PRCES-INCLUSIVE     TO TRUE
           ELSE
               SET L4750-PRCES-EXCLUSIVE     TO TRUE
           END-IF.

           IF  E0691-NORM-PREM-RFND
               SET L4750-TCNTRCT-PREM-REVRS-NORM TO TRUE
           ELSE
               SET L4750-TCNTRCT-PREM-REVRS-TRMN TO TRUE
           END-IF.

           IF  E0691-REINSTATING
               IF  PROCESSING-POLICY
               OR  L4750-TCNTRCT-PREM-REVRS-TRMN
                   SET L4750-TCNTRCT-PREM-REVRS-BPSS TO TRUE
               END-IF
           END-IF.

           IF  E0691-PREM-REVRS-NSF
               SET L4750-TCNTRCT-PREM-DEST-NSF      TO TRUE
           ELSE
               IF (WS-BUS-FCN-TDEATH OR
                   PROCESSING-POLICY)
018731*        AND NOT E0691-CHEQUE-REQ
018731         AND E0691-PAYO-MTHD-NOT-REQ
                   SET L4750-TCNTRCT-PREM-DEST-DISB TO TRUE
               END-IF
           END-IF.

012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L4750-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.
012137
       2510-BUILD-4750-INFO-X.
           EXIT.
      /
012136*------------------------
012136 2520-BUILD-FL-4750-INFO.
012136*------------------------
012136
012136     PERFORM  4750-1000-BUILD-PARM-INFO
012136         THRU 4750-1000-BUILD-PARM-INFO-X.
012136
012136     SET L4750-FCN-DRVR-SECONDARY      TO TRUE.
012136     MOVE E0691-EFF-DATE        TO L4750-EFF-DT.

018731*    MOVE E0691-CHEQUE-IND      TO L4750-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L4750-PAYO-MTHD-CD.
012136     SET L4750-PRCES-EXCLUSIVE         TO TRUE.
012136
012136     IF  E0691-NORM-PREM-RFND
012136         SET L4750-TCNTRCT-PREM-REVRS-NORM TO TRUE
012136     ELSE
012136         SET L4750-TCNTRCT-PREM-REVRS-TRMN TO TRUE
012136     END-IF.
012136
012136     IF  E0691-PREM-REVRS-NSF
012136         SET L4750-TCNTRCT-PREM-DEST-NSF      TO TRUE
012136     ELSE
012136         IF  PROCESSING-POLICY
018731*        AND NOT E0691-CHEQUE-REQ
018731         AND E0691-PAYO-MTHD-NOT-REQ
012136             SET L4750-TCNTRCT-PREM-DEST-DISB TO TRUE
012136         END-IF
012136     END-IF.
012136
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L4750-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.
012137
012136 2520-BUILD-FL-4750-INFO-X.
012136     EXIT.
012136/
      *-------------------------
       3000-GENERAL-TRANS-EDITS.
      *-------------------------
      *
008453*  MSG:  EFFECTIVE DATE MUST BE ENTERED IN VALID FORMAT..DDMMMYYYY
008453*  MSG:  EFFECTIVE DATE MUST BE ENTERED IN VALID FORMAT
      *
           IF E0691-EFF-DATE = WWKDT-ZERO-DT
               MOVE 'CS00000054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
018731         GO TO 3000-GENERAL-TRANS-EDITS-X
            END-IF.

018731*    IF  E0691-CHEQUE-IND = 'Y'
018731*    OR  E0691-CHEQUE-IND = 'N'
018731     IF  E0691-PAYO-MTHD-CHQ
018731     OR  E0691-PAYO-MTHD-EFT
018731     OR  E0691-PAYO-MTHD-NOT-REQ
013578     OR  WS-BUS-FCN-REVERSAL
               CONTINUE
           ELSE
               MOVE 'CS06910005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
018731         GO TO 3000-GENERAL-TRANS-EDITS-X
           END-IF.

      *
      *  ENSURE THAT THE COVERAGE NUMBER IS IN THE CORRECT FORMAT
      *
           MOVE E0691-COV-X           TO L0280-INPUT-DATA.
           MOVE +2                    TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 'Y'                   TO L0280-SPACE-PERMITTED-IND.
           MOVE 'N'                   TO L0280-SIGN-IND.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               CONTINUE
           ELSE
               MOVE 'XS00000079'      TO WGLOB-MSG-REF-INFO
               MOVE  E0691-COV-X      TO WGLOB-MSG-PARM (1)
007766         MOVE  WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (2)
               MOVE  E0691-COV-X      TO MIR-CVG-NUM
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-GENERAL-TRANS-EDITS-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD = '1'
013578     OR  MIR-DV-PRCES-STATE-CD = '2'
014221*        PERFORM  POL-1000-READ
014221*            THRU POL-1000-READ-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
           ELSE
014221*        PERFORM  POL-1000-READ-FOR-UPDATE
014221*            THRU POL-1000-READ-FOR-UPDATE-X
014221         PERFORM  POL-2000-UPDATE-TWRK-TS
014221             THRU POL-2000-UPDATE-TWRK-TS-X
               SET POLICY-LOCKED              TO TRUE
014221         IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221             MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221             MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221             MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221             PERFORM  0260-1000-GENERATE-MESSAGE
014221                 THRU 0260-1000-GENERATE-MESSAGE-X
014221            GO TO 3000-GENERAL-TRANS-EDITS-X
016537         END-IF
           END-IF.

           IF WPOL-IO-OK
               CONTINUE
           ELSE
               MOVE 'CS06910019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-GENERAL-TRANS-EDITS-X
           END-IF.
      *
      * VERIFY POLICY ACCESS.
      *
016686*    IF  RPOL-POL-APPL-CTL-NBS
016686     IF  RPOL-POL-STAT-BEFORE-SETL
012624         MOVE 'XS00000238'      TO WGLOB-MSG-REF-INFO
012624         PERFORM  0260-1000-GENERATE-MESSAGE
012624             THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-GENERAL-TRANS-EDITS-X
012624     END-IF.
012624
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.
           SET L5400-CRCY-MSG-REQD     TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD TO TRUE.
016440     SET L5400-POL-XFER-UPDATE   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
012624*    OR  L5400-CTL-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               GO TO 3000-GENERAL-TRANS-EDITS-X
           END-IF.

           IF WPOL-IO-OK
               IF E0691-COV-X > RPOL-POL-CVG-REC-CTR-N
                   MOVE 'CS06910021'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

013578*    PERFORM  2430-1000-BUILD-PARM-INFO
013578*        THRU 2430-1000-BUILD-PARM-INFO-X.
012624*    MOVE E0691-OWNER-NAME      TO L2430-OWNER-NAME-1-4.
013578*    PERFORM  2430-5000-VALIDATE-OWNER-NM
013578*        THRU 2430-5000-VALIDATE-OWNER-NM-X.
013578*    IF L2430-RETRN-OWNER-NM-MISMATCH
013578*        MOVE 'CS06910022'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    END-IF.

023437*    IF  WS-BUS-FCN-TSURR
023437*    AND NOT E0691-TAX-BYPASS-VALID
023437*** MSG: TAX BYPASS INDICATOR MUST BE 'Y' OR 'N'
023437*        MOVE 'CS06910024'      TO WGLOB-MSG-REF-INFO
023437*        PERFORM  0260-1000-GENERATE-MESSAGE
023437*            THRU 0260-1000-GENERATE-MESSAGE-X
023437*    END-IF.
023437*
023437*    IF  E0691-TAX-BYPASS
023437*        IF WS-BUS-FCN-TSURR
023437*            NEXT SENTENCE
023437*        ELSE
023437* MSG: TAX BYPASS ALLOWED ONLY ON SURRENDERS
023437*            MOVE 'CS06910025'  TO WGLOB-MSG-REF-INFO
023437*            PERFORM  0260-1000-GENERATE-MESSAGE
023437*                THRU 0260-1000-GENERATE-MESSAGE-X
023437*        END-IF
023437*    END-IF.
023437*
020478*    IF  WS-BUS-FCN-TSURR
020478*    AND NOT E0691-LTAXWH-CALC-VALID
023437*    AND NOT E0691-LTAXWH-CALC-TSURR
019360*MSG: LOCATION TAX BYPASS INDICATOR MUST BE 'B' OR 'C' ' '.
020478*        MOVE 'CS06910026'       TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*    END-IF.

023437*    IF  E0691-LTAXWH-CALC
023437*        IF  WS-BUS-FCN-TSURR
023437*            NEXT SENTENCE
023437*        ELSE
023437*MSG: LOCATION TAX CALCULATE ALLOWED ONLY ON SURRENDER
023437*            MOVE 'CS06910027'  TO WGLOB-MSG-REF-INFO
023437*            PERFORM  0260-1000-GENERATE-MESSAGE
023437*                THRU 0260-1000-GENERATE-MESSAGE-X
023437*        END-IF
023437*    END-IF.

012137*
012137* VALIDATE SUPPRESS CONFIRMATION
012137*
012137     IF  MIR-SUPRES-CNFRM-IND NOT = SPACES
012137         IF  MIR-SUPRES-CNFRM-IND NOT = 'Y'
012137         AND MIR-SUPRES-CNFRM-IND NOT = 'N'
012137*MSG: SUPPRESS CONFIRMATION NOT VALID. ENTER 'Y' OR 'N'.
012137             MOVE 'CS06914300'  TO WGLOB-MSG-REF-INFO
012137             PERFORM  0260-1000-GENERATE-MESSAGE
012137                 THRU 0260-1000-GENERATE-MESSAGE-X
012137         END-IF
012137     ELSE
012137         MOVE 'N'               TO MIR-SUPRES-CNFRM-IND
012137     END-IF.
012137
012137     IF WS-BUS-FCN-TNOTKN
012137     OR WS-BUS-FCN-TDEATH
012137     OR WS-BUS-FCN-RNOTKN
012137     OR WS-BUS-FCN-RDEATH
020478*    OR WS-BUS-FCN-TSURR
020478*    OR WS-BUS-FCN-RSURR
012137     OR WS-BUS-FCN-TNORMAL
012137     OR WS-BUS-FCN-RNORMAL
012137         CONTINUE
012137     ELSE
012137         IF  MIR-SUPRES-CNFRM-IND NOT = SPACES
012137         AND MIR-SUPRES-CNFRM-IND NOT = 'N'
012137*MSG: SUPPRESS CONFIRM IGNORED. VALID ENTER CODES
012137*     'NT,DT,RA,RD,SU,RS,NR,RN'
012137             MOVE 'CS06914301'  TO WGLOB-MSG-REF-INFO
012137             PERFORM  0260-1000-GENERATE-MESSAGE
012137                 THRU 0260-1000-GENERATE-MESSAGE-X
012137             MOVE 'N'           TO MIR-SUPRES-CNFRM-IND
012137         END-IF
012137     END-IF.
018731
018731     EVALUATE TRUE
018731         WHEN WS-BUS-FCN-TNOTKN
018731         WHEN WS-BUS-FCN-TLAPS
018731         WHEN WS-BUS-FCN-TLAPSWV
018731         WHEN WS-BUS-FCN-TCNVR
026055*        WHEN WS-BUS-FCN-TDEATH
020478*        WHEN WS-BUS-FCN-TSURR
018731         WHEN WS-BUS-FCN-TREPL
018731         WHEN WS-BUS-FCN-TNORMAL
018731             IF  MIR-DV-SELCT-PAYO-MTHD-CD = 'E'
018731                 PERFORM  3010-EDIT-EFT-CLIENT
018731                     THRU 3010-EDIT-EFT-CLIENT-X
018731                 PERFORM  4382-1000-BUILD-PARM-INFO
018731                     THRU 4382-1000-BUILD-PARM-INFO-X
018731                 MOVE E0691-CLI-ID     TO  L4382-CLI-ID
018731                 MOVE E0691-CLI-BNK-ACCT-NUM
018731                                       TO L4382-CLI-BNK-ACCT-NUM
018731                 PERFORM  4382-1000-EFT-EDITS
018731                     THRU 4382-1000-EFT-EDITS-X
018731                 IF  L4382-EDIT-ERROR
018731                 OR  NOT L4382-RETRN-OK
018731                     MOVE +1           TO WGLOB-MSG-ERROR-SW
018731                 END-IF
018731             END-IF
018731             IF  MIR-DV-SELCT-PAYO-MTHD-CD = 'C'
018731                 IF  E0691-CLI-ID NOT = SPACE
018731                 OR  E0691-CLI-BNK-ACCT-NUM NOT = SPACES
018731* MSG : WARNING - CHEQUE PAYOUT IS SELECTED; BANKING INFORMATION
018731*       IGNORED
018731                     MOVE 'CS06914304'  TO WGLOB-MSG-REF-INFO
018731                     PERFORM  0260-1000-GENERATE-MESSAGE
018731                         THRU 0260-1000-GENERATE-MESSAGE-X
018731                     MOVE SPACES        TO E0691-CLI-ID
018731                     MOVE SPACES        TO E0691-CLI-BNK-ACCT-NUM
018731                     MOVE SPACES        TO MIR-CLI-ID
018731                     MOVE SPACES        TO MIR-CLI-BNK-ACCT-NUM
018731                 END-IF
018731             END-IF
018731     END-EVALUATE.

023437*    IF WGLOB-MSG-ERROR-SW NOT > ZERO
023437*        PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
023437*            THRU CVGS-1000-LOAD-CVGS-ARRAY-X
023437*    END-IF.

023437     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
023437         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

020478*    IF  WS-BUS-FCN-TSURR
020478*    OR  WS-BUS-FCN-TNORMAL
020478     IF  WS-BUS-FCN-TNORMAL
023437     OR  WS-BUS-FCN-TDEATH
023437         PERFORM  3050-EDIT-LTAXWH-RQST
023437             THRU 3050-EDIT-LTAXWH-RQST-X
023437         PERFORM  3060-EDIT-TAXWH-RQST
023437             THRU 3060-EDIT-TAXWH-RQST-X
023437     END-IF.
023437
016108     IF  NOT WS-BUS-FCN-TDEATH
016108     AND NOT WS-BUS-FCN-RDEATH
016108*
016108*    VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108         PERFORM  0985-1000-BUILD-PARM-INFO
016108             THRU 0985-1000-BUILD-PARM-INFO-X
016108
016108         MOVE E0691-EFF-DATE    TO L0985-EFF-DT
016108
016108         PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108             THRU 0985-1000-VAL-POL-DT-OF-DTH-X
016108
016108         IF  NOT L0985-RETRN-OK
016108             MOVE +1            TO WGLOB-MSG-ERROR-SW
016108         END-IF
016108     END-IF.

020463     IF WS-BUS-FCN-TNOTKN
020463     OR WS-BUS-FCN-TREPL
020478*    OR WS-BUS-FCN-TSURR
020463     OR WS-BUS-FCN-TLAPS
020463     OR WS-BUS-FCN-TLAPSWV
020463     OR WS-BUS-FCN-TNORMAL
020463     OR WS-BUS-FCN-TDEATH
020463         PERFORM  2735-1000-BUILD-PARM-INFO
020463             THRU 2735-1000-BUILD-PARM-INFO-X
020463         MOVE  RPOL-POL-ID   TO L2735-POL-ID
020463         PERFORM  2735-1000-GET-PRFL
020463             THRU 2735-1000-GET-PRFL-X
020463         IF L2735-RETRN-PRFL-FND
020463         AND E0691-COV-X NOT = '00'
020463             MOVE '00'              TO MIR-CVG-NUM
020463*MSG: THIS POLICY CONTAINS AN INVESTOR PROFILE. THE TRANSACTION
020463*     MUST BE PERFORMED AT A POLICY LEVEL.
020463             MOVE 'CS06910006'      TO WGLOB-MSG-REF-INFO
020463             PERFORM  0260-1000-GENERATE-MESSAGE
020463                THRU  0260-1000-GENERATE-MESSAGE-X
020463             SET WGLOB-RETURN-ERROR    TO TRUE
020463             GO TO 3000-GENERAL-TRANS-EDITS-X
020463         END-IF
020463     END-IF.
020463
031037     IF  WS-BUS-FCN-REVERSAL
029060*    AND E0691-COV-X NOT = '00'
031037         PERFORM  3040-EDIT-REINSTATE-SEQ
031037             THRU 3040-EDIT-REINSTATE-SEQ-X
031037     END-IF.
031037
       3000-GENERAL-TRANS-EDITS-X.
           EXIT.
018731/
018731*---------------------
018731 3010-EDIT-EFT-CLIENT.
018731*---------------------
018731*
018731* EDIT TO MAKE SURE CLIENT ID IS NOT SPACES
018731*
018731     IF  MIR-CLI-ID = SPACES
018731*MSG : CLIENT ID MUST BE ENTERED FOR EFT PROCESSING
018731         MOVE 'CS06914305'      TO WGLOB-MSG-REF-INFO
018731         PERFORM  0260-1000-GENERATE-MESSAGE
018731             THRU 0260-1000-GENERATE-MESSAGE-X
018731         GO TO 3010-EDIT-EFT-CLIENT-X
018731     END-IF.
018731     PERFORM  2430-1000-BUILD-PARM-INFO
018731         THRU 2430-1000-BUILD-PARM-INFO-X.
018731     MOVE MIR-POL-ID            TO L2430-POL-ID.
018731     MOVE MIR-CLI-ID            TO L2430-CLI-ID.
018731
018731     PERFORM  2430-3300-GET-POL-CLI-REL
018731         THRU 2430-3300-GET-POL-CLI-REL-X.
018731
018731     IF  L2430-RETRN-CLI-NOT-FOUND
018731*MSG: EFT CLIENT DOES NOT BELONG TO THE POLICY
018731         MOVE 'CS06910030'  TO WGLOB-MSG-REF-INFO
018731         PERFORM  0260-1000-GENERATE-MESSAGE
018731             THRU 0260-1000-GENERATE-MESSAGE-X
018731         MOVE +1            TO WGLOB-MSG-ERROR-SW
018731     END-IF.
018731
018731 3010-EDIT-EFT-CLIENT-X.
018731     EXIT.
031037
031037*------------------------
031037 3040-EDIT-REINSTATE-SEQ.
031037*------------------------
031037
031037     MOVE RPOL-POL-ID            TO WPHST-POL-ID.
031037     MOVE E0691-EFF-DATE         TO L1660-INTERNAL-DATE.
031037     PERFORM  1660-2000-CONVERT-INT-TO-INV
031037         THRU 1660-2000-CONVERT-INT-TO-INV-X.
031037     MOVE L1660-INVERTED-DATE    TO WPHST-PCHST-EFF-IDT-NUM.
031037     MOVE ZERO                   TO WPHST-PCHST-SEQ-NUM.
031037     MOVE WPHST-KEY              TO WPHST-ENDBR-KEY.
031037     MOVE HIGH-VALUES            TO WPHST-ENDBR-PCHST-EFF-IDT-NUM.
031037
031037     PERFORM  PHST-1000-BROWSE
031037         THRU PHST-1000-BROWSE-X.
031037
031037     PERFORM  PHST-2000-READ-NEXT
031037         THRU PHST-2000-READ-NEXT-X.
031037
031037     SET WS-LOOP-NOT-END         TO TRUE
031037     PERFORM
031037         UNTIL NOT WPHST-IO-OK
031037         OR WS-LOOP-END
031037         IF  RPHST-POL-ACTV-TYP-ID = '3003'
031037         AND RPHST-PCHST-STAT-OVERRIDE
031037         AND RPHST-PCHST-PREV-STAT-CD = SPACE
031037             SET WS-LOOP-END     TO TRUE
031037         ELSE
031037             PERFORM  PHST-2000-READ-NEXT
031037                 THRU PHST-2000-READ-NEXT-X
031037         END-IF
031037     END-PERFORM.
031037
031037     PERFORM  PHST-3000-END-BROWSE
031037         THRU PHST-3000-END-BROWSE-X.
031037
031037     IF  WS-LOOP-END
031037     AND RPHST-CVG-NUM NOT = E0691-COV-X
029060     AND E0691-COV-X NOT = '00'
031037*MSG : CANNOT REINSTATE COVERAGE OUT OF SEQUENCE.  COVERAGE @1
031037*      SHOULD BE REINSTATED FIRST
031037         MOVE 'CS06910007'      TO WGLOB-MSG-REF-INFO
031037         MOVE RPHST-CVG-NUM     TO WGLOB-MSG-PARM (1)
031037         PERFORM  0260-1000-GENERATE-MESSAGE
031037             THRU 0260-1000-GENERATE-MESSAGE-X
031037         SET WGLOB-RETURN-ERROR TO TRUE
031037     END-IF.
031037
029060     MOVE RPHST-PCHST-REL-SEQ-NUM
029060                                TO WS-REVRS-PCHST-SEQ-NUM.
029060
031037 3040-EDIT-REINSTATE-SEQ-X.
031037     EXIT.

      /
023437*----------------------------
023437 3050-EDIT-LTAXWH-RQST.
023437*----------------------------
023437*
023437* LOCATION TAX WITHHOLDING DATA
023437*
029060*    IF  MIR-LTAXWH-CALC-CD = SPACES
029060*    OR  MIR-LTAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
029060*        MOVE 'C'               TO MIR-LTAXWH-CALC-CD
029060*    END-IF.
029060*
029060*    MOVE MIR-LTAXWH-CALC-CD    TO E0691-LTAXWH-CALC-CD.
029060
029060     IF  MIR-LTAXWH-RQST-CD = SPACES
029060     OR  MIR-LTAXWH-RQST-CD = EBLCH-BLANK-FIELD-CHAR
029060         MOVE 'C'               TO MIR-LTAXWH-RQST-CD
029060     END-IF.
029060 
029060     MOVE MIR-LTAXWH-RQST-CD    TO E0691-LTAXWH-CALC-CD.
023437
023437     IF  NOT E0691-LTAXWH-CALC-VALID
023437* MSG:  INVALID TAX WITHHOLD CALCULATION CODE
023437         MOVE 'CS06914310'       TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR  TO TRUE
023437         GO TO 3050-EDIT-LTAXWH-RQST-X
023437     END-IF.
023437
029060*    IF  MIR-LTAXWH-FLAT-AMT = SPACES
029060
029060     IF  MIR-LTAXWH-RQST-AMT = SPACES
029060         MOVE ZERO              TO E0691-LTAXWH-FLAT-AMT
023437     ELSE
029060*        MOVE MIR-LTAXWH-FLAT-AMT
029060*                               TO L0280-INPUT-DATA
029060         MOVE MIR-LTAXWH-RQST-AMT
029060                                TO L0280-INPUT-DATA
023437         SET L0280-SIGN-NOT-PERMITTED
023437                                TO TRUE
023437         MOVE 13                TO L0280-LENGTH
023437         MOVE 2                 TO L0280-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                               TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                TO L0280-INPUT-SIZE
023437         PERFORM  0280-1000-NUMERIC-EDIT
023437             THRU 0280-1000-NUMERIC-EDIT-X
023437
023437         IF  L0280-OK
023437             MOVE L0280-OUTPUT-V02
023437                                TO E0691-LTAXWH-FLAT-AMT
023437         ELSE
023437*MSG: INVALID LOCATION TAX REQUEST AMOUNT
023437             MOVE 'CS06914307'  TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437             SET WGLOB-RETURN-ERROR
023437                                TO TRUE
023437         END-IF
023437     END-IF.
023437
029060*    IF  MIR-LTAXWH-PCT = SPACES
029060*        MOVE ZERO               TO E0691-LTAXWH-PCT
029060
029060     IF  MIR-LTAXWH-RQST-PCT = SPACES
029060         MOVE ZERO               TO E0691-LTAXWH-PCT
023437     ELSE
029060*        MOVE MIR-LTAXWH-PCT     TO L0280-INPUT-DATA
029060         MOVE MIR-LTAXWH-RQST-PCT
029060                                 TO L0280-INPUT-DATA
023437         SET L0280-SIGN-NOT-PERMITTED
023437                                 TO TRUE
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                                TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                 TO L0280-INPUT-SIZE
023437         MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
023437         MOVE 2                  TO L0280-PRECISION
023437         PERFORM  0280-1000-NUMERIC-EDIT
023437             THRU 0280-1000-NUMERIC-EDIT-X
023437         IF  L0280-OK
023437             MOVE L0280-OUTPUT-V02
023437                                 TO E0691-LTAXWH-PCT
023437         ELSE
023437*MSG: INVALID FEDERAL TAX REQUEST PERCENT
023437             MOVE 'CS06914308'   TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437             SET WGLOB-RETURN-ERROR
023437                                 TO TRUE
023437         END-IF
023437     END-IF.
023437
023437     IF WGLOB-RETURN-ERROR
023437        GO TO 3050-EDIT-LTAXWH-RQST-X
023437     END-IF.
023437
023437     PERFORM  3052-CROSS-EDIT-LTAXWH
023437         THRU 3052-CROSS-EDIT-LTAXWH-X.
023437
023437 3050-EDIT-LTAXWH-RQST-X.
023437     EXIT.
023437
023437*----------------------------
023437 3052-CROSS-EDIT-LTAXWH.
023437*----------------------------
023437
023437     IF  E0691-LTAXWH-FLAT-AMT NOT = ZEROS
023437     AND E0691-LTAXWH-PCT      NOT = ZEROS
023437* LOCATION AMOUNT AND PERCENT CANNOT BE BOTH ENTERED
023437         MOVE 'CS06914311'      TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR TO TRUE
023437     END-IF.
023437
029060*    IF  MIR-LTAXWH-CALC-CD = 'S'
029060
029060     IF  MIR-LTAXWH-RQST-CD = 'S'
023437         IF E0691-LTAXWH-PCT    NOT = ZERO
023437         OR E0691-LTAXWH-FLAT-AMT NOT = ZERO
023437            CONTINUE
023437*MSG: LOCATION AMOUNT OR % NEED TO FILL IF OVERRIDE INDICATOR
023437         ELSE
023437             MOVE 'CS06914312'            TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437             SET WGLOB-RETURN-ERROR       TO TRUE
023437         END-IF
023437     END-IF.
023437
029060*    IF  MIR-LTAXWH-CALC-CD = 'C'
029060*    OR  MIR-LTAXWH-CALC-CD = SPACES
029060*    OR  MIR-LTAXWH-CALC-CD = 'B'
029060
029060     IF  MIR-LTAXWH-RQST-CD = 'C'
029060     OR  MIR-LTAXWH-RQST-CD = SPACES
029060     OR  MIR-LTAXWH-RQST-CD = 'B'
023437         IF  E0691-LTAXWH-FLAT-AMT NOT = ZEROS
023437         OR  E0691-LTAXWH-PCT    NOT = ZEROS
023437*MSG: LOCATION AMOUNT OR PERCENT CANNOT BE FILLED IF OVERRIDE
023437*     INDICATOR IS OFF
023437             MOVE 'CS06914313'            TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437             SET WGLOB-RETURN-ERROR       TO TRUE
023437        END-IF
023437     END-IF.
023437
023437 3052-CROSS-EDIT-LTAXWH-X.
023437     EXIT.
023437
023437*----------------------------
023437 3060-EDIT-TAXWH-RQST.
023437*----------------------------
023437*
023437* FEDERAL TAX REQUEST DATA
023437*
029060*    IF  MIR-FED-TAXWH-RQST-AMT = SPACES
029060
029060     IF  MIR-FTAXWH-RQST-AMT = SPACES
023437         MOVE ZERO               TO E0691-FED-TAXWH-RQST-AMT
023437     ELSE
029060*        MOVE MIR-FED-TAXWH-RQST-AMT
029060*                                TO L0280-INPUT-DATA
029060         MOVE MIR-FTAXWH-RQST-AMT
029060                                 TO L0280-INPUT-DATA
023437         SET L0280-SIGN-NOT-PERMITTED
023437                                 TO TRUE
023437         MOVE 13                 TO L0280-LENGTH
023437         MOVE 2                  TO L0280-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                 TO L0280-INPUT-SIZE
023437         PERFORM  0280-1000-NUMERIC-EDIT
023437             THRU 0280-1000-NUMERIC-EDIT-X
023437
023437         IF  L0280-OK
023437             MOVE L0280-OUTPUT-V02
023437                                 TO E0691-FED-TAXWH-RQST-AMT
023437         ELSE
023437*MSG: INVALID FEDERAL TAX REQUEST AMOUNT
023437             MOVE 'CS06914307'   TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437             SET WGLOB-RETURN-ERROR
023437                                 TO TRUE
023437         END-IF
023437     END-IF.
023437
029060*    IF  MIR-FED-TAXWH-RQST-PCT = SPACES
029060
029060     IF  MIR-FTAXWH-RQST-PCT = SPACES
023437         MOVE ZERO               TO E0691-FED-TAXWH-RQST-PCT
023437     ELSE
029060*        MOVE MIR-FED-TAXWH-RQST-PCT
029060*                                TO L0280-INPUT-DATA
029060         MOVE MIR-FTAXWH-RQST-PCT
029060                                 TO L0280-INPUT-DATA
023437         SET L0280-SIGN-NOT-PERMITTED
023437                                 TO TRUE
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                 TO L0280-INPUT-SIZE
023437         MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
023437         MOVE 2                  TO L0280-PRECISION
023437         PERFORM  0280-1000-NUMERIC-EDIT
023437             THRU 0280-1000-NUMERIC-EDIT-X
023437         IF  L0280-OK
023437             MOVE L0280-OUTPUT-V02
023437                                 TO E0691-FED-TAXWH-RQST-PCT
023437         ELSE
023437*MSG: INVALID FEDERAL TAX REQUEST PERCENT
023437             MOVE 'CS06914308'   TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437             SET WGLOB-RETURN-ERROR
023437                                 TO TRUE
023437         END-IF
023437     END-IF.
023437*
023437* CALL THE FEDERAL TAX EDIT REGIONAL EXIT FOR EDITS
023437*
023437     PERFORM  0316-1000-BUILD-PARM-INFO
023437         THRU 0316-1000-BUILD-PARM-INFO-X.
023437
023437     SET L0316-RGN-EXIT-TAXWH-CLI-EDITS
023437                                 TO TRUE.
023437
023437     MOVE RPOL-POL-CTRY-CD       TO L0316-CTRY-CD.
023437
023437     PERFORM  0316-1000-GET-RGN-EXIT-PGM
023437         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
023437
023437     IF  NOT L0316-RETRN-OK
023437     OR  L0316-RGN-EXIT-STAT-INACTV
023437*MSG: NO FEDERAL TAX REGIONAL EXIT FOUND FOR COUNTRY @1
023437         MOVE 'CS06914309'       TO WGLOB-MSG-REF-INFO
023437         MOVE L0316-CTRY-CD      TO WGLOB-MSG-PARM (1)
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         MOVE +1                 TO  WGLOB-MSG-ERROR-SW
023437         GO TO 3060-EDIT-TAXWH-RQST-X
023437     END-IF
023437
023437* AN ACTIVE REGION EXIT IS HELD. THIS MUST BE PERFORMED FIRST TO
023437* CARRY OUT EDITS FOR FEDERAL TAX WITHHOLDING DATA.
023437
023437     PERFORM  TAXC-1000-BUILD-PARM-INFO
023437         THRU TAXC-1000-BUILD-PARM-INFO-X.
023437
023437     SET LTAXC-RGN-EXIT-TAXWH-CLI-EDITS   TO TRUE.
023437
023437     MOVE MIR-POL-ID               TO LTAXC-POL-ID.
023437     MOVE E0691-EFF-DATE           TO LTAXC-EFF-DT.
029060*    MOVE MIR-FED-TAXWH-CALC-CD    TO LTAXC-FED-TAXWH-CALC-CD.
029060*    MOVE E0691-FED-TAXWH-RQST-AMT TO LTAXC-FED-TAXWH-RQST-AMT.
029060*    MOVE E0691-FED-TAXWH-RQST-PCT TO LTAXC-FED-TAXWH-RQST-PCT.
029060*
029060*    MOVE E0691-LTAXWH-CALC-CD     TO LTAXC-LTAXWH-CALC-CD.
029060*    MOVE E0691-LTAXWH-FLAT-AMT    TO LTAXC-LTAXWH-FLAT-AMT.
029060*    MOVE E0691-LTAXWH-PCT         TO LTAXC-LTAXWH-PCT.
029060     MOVE MIR-FTAXWH-RQST-CD       TO LTAXC-FTAXWH-RQST-CD.
029060     MOVE E0691-FED-TAXWH-RQST-AMT TO LTAXC-FTAXWH-RQST-AMT.
029060     MOVE E0691-FED-TAXWH-RQST-PCT TO LTAXC-FTAXWH-RQST-PCT.
029060     MOVE E0691-LTAXWH-CALC-CD     TO LTAXC-LTAXWH-RQST-CD.
029060     MOVE E0691-LTAXWH-FLAT-AMT    TO LTAXC-LTAXWH-RQST-AMT.
029060     MOVE E0691-LTAXWH-PCT         TO LTAXC-LTAXWH-RQST-PCT.
023437
023437     PERFORM  TAXC-1000-TAXWH-CLI-EDIT
023437         THRU TAXC-1000-TAXWH-CLI-EDIT-X.
023437
023437     IF  LTAXC-EDIT-ERROR
023437     OR  NOT LTAXC-RETRN-OK
023437         MOVE +1                 TO  WGLOB-MSG-ERROR-SW
023437     END-IF.
023437
023437 3060-EDIT-TAXWH-RQST-X.
023437     EXIT.
023437
      *---------
       3200-NTU.
      *---------

           PERFORM  1110-1000-BUILD-PARM-INFO
               THRU 1110-1000-BUILD-PARM-INFO-X.

           MOVE E0691-COV-NO          TO L1110-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1110-CHEQUE-IND.
012624*    MOVE E0691-OWNER-NAME      TO L1110-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1110-EFF-DT.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1110-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1110-LTAXWH-CALC-CD.
013693     SET  L1110-LTAXWH-DISB-NONP TO TRUE.
016158*    MOVE E0691-DEATH-CODE      TO L1110-SURR-FOR-TRANSFER-CD.
016158     MOVE E0691-NTU-RFND-DEST-CD TO L1110-SURR-FOR-TRANSFER-CD.
018731     MOVE E0691-PAYO-MTHD-CD     TO L1110-PAYO-MTHD-CD.
018731     MOVE E0691-CLI-ID           TO L1110-CLI-ID.
018731     MOVE E0691-CLI-BNK-ACCT-NUM TO L1110-CLI-BNK-ACCT-NUM.

           IF PROCESSING-POLICY
               SET L1110-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1110-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3202-NTU-1
                       THRU 3202-NTU-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3204-NTU-2
                       THRU 3204-NTU-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

018731     IF  L1110-RETRN-OK
018731     AND NOT WGLOB-RETURN-ERROR
018731         MOVE L1110-CLI-ID    TO MIR-CLI-ID
018731         MOVE L1110-CLI-BNK-ACCT-NUM
018731                              TO MIR-CLI-BNK-ACCT-NUM
018731     END-IF.

       3200-NTU-X.
           EXIT.

      *-----------
       3202-NTU-1.
      *-----------

           SET L1110-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1110-REDO-WARNING        TO TRUE.
           PERFORM  1110-1000-PROCESS-NTU
               THRU 1110-1000-PROCESS-NTU-X.
           IF L1110-RETRN-OK
016158*        CONTINUE
016158         IF L1110-DEFER-REQUIRE
016158             SET DEFERRED-TRANS TO TRUE
016158* MSG: FUND UNIT PRICES NOT AVAILABLE,
016158*      TERMINATION WILL BE DEFERRED
016158             MOVE 'CS06910001' TO WGLOB-MSG-REF-INFO
016158             PERFORM  0260-1000-GENERATE-MESSAGE
016158                 THRU 0260-1000-GENERATE-MESSAGE-X
016158         END-IF
           ELSE
              SET WGLOB-RETURN-ERROR TO TRUE
              GO TO 3202-NTU-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912201'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912202'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3202-NTU-1-X.
           EXIT.

      *-----------
       3204-NTU-2.
      *-----------

012134*    SET L5435-PRCES-TYP-TRMN  TO TRUE.
012134*    SET L5435-TRMN-TYP-NTU    TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X
           IF  NOT WGLOB-GOOD-RETURN
013578     OR  DEFERRED-TRANS
016503     OR  WS-REDO-NOT-OK
               GO TO 3204-NTU-2-X
           END-IF.

           SET L1110-PRCES-TYP-ALL  TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3209-PROCESS-NTU
012134*           THRU 3209-PROCESS-NTU-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*           OR      WS-SEGF-SUB > +20
012134*           OR      WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*    ELSE
012134*        PERFORM  3209-PROCESS-NTU
012134*            THRU 3209-PROCESS-NTU-X
012134*    END-IF.
012134     PERFORM  3209-PROCESS-NTU
012134         THRU 3209-PROCESS-NTU-X.

           IF NOT L1110-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3204-NTU-2-X.
           EXIT.
      /
      *-----------------
       3209-PROCESS-NTU.
      *-----------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1110-PRCES-LEVEL-CVG    TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                     TO L1110-CVG-NUM
012134*    END-IF.
012134*
           SET L1110-PRCES-TYP-ALL TO TRUE.
016503     SET L1110-REDO-WARNING  TO TRUE.
012136     SET L1110-FCN-DRVR-SECONDARY TO TRUE.
012136     MOVE L4750-EFF-DT          TO L1110-EFF-DT.
           PERFORM  1110-1000-PROCESS-NTU
               THRU 1110-1000-PROCESS-NTU-X.

       3209-PROCESS-NTU-X.
           EXIT.

      *-----------
       3210-LAPSE.
      *-----------

           PERFORM  1120-1000-BUILD-PARM-INFO
               THRU 1120-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1120-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1120-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1120-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1120-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1120-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1120-EFF-DT.
           MOVE WGLOB-USER-ID         TO L1120-INIT-HOLDER.
012134     MOVE E0691-DEATH-CODE      TO L1120-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1120-BYPASS-TAX-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1120-LTAXWH-CALC-CD.
013693     SET  L1120-LTAXWH-DISB-NONP TO TRUE.
018731     MOVE E0691-CLI-ID          TO L1120-CLI-ID.
018731     MOVE E0691-CLI-BNK-ACCT-NUM TO L1120-CLI-BNK-ACCT-NUM.

           IF PROCESSING-POLICY
               SET L1120-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1120-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3212-LAPSE-1
                       THRU 3212-LAPSE-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3214-LAPSE-2
                       THRU 3214-LAPSE-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.
018731     IF  L1120-RETRN-OK
018731     AND NOT WGLOB-RETURN-ERROR
018731         MOVE L1120-CLI-ID    TO MIR-CLI-ID
018731         MOVE L1120-CLI-BNK-ACCT-NUM
018731                              TO MIR-CLI-BNK-ACCT-NUM
018731     END-IF.


       3210-LAPSE-X.
           EXIT.

      *-------------
       3212-LAPSE-1.
      *-------------

           SET L1120-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1120-REDO-WARNING        TO TRUE.

           PERFORM  1120-1000-PROCESS-LAPSE
               THRU 1120-1000-PROCESS-LAPSE-X.
           IF L1120-RETRN-OK
016158*        CONTINUE
016158         IF L1120-DEFER-REQUIRE
016158             SET DEFERRED-TRANS TO TRUE
016158* MSG: FUND UNIT PRICES NOT AVAILABLE,
016158*      TERMINATION WILL BE DEFERRED
016158             MOVE 'CS06910001' TO WGLOB-MSG-REF-INFO
016158             PERFORM  0260-1000-GENERATE-MESSAGE
016158                 THRU 0260-1000-GENERATE-MESSAGE-X
016158         END-IF
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3212-LAPSE-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912203'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912204'      TO WGLOB-MSG-REF-INFO
           END-IF.
           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3212-LAPSE-1-X.
           EXIT.

      *-------------
       3214-LAPSE-2.
      *-------------

012134*    SET L5435-PRCES-TYP-TRMN  TO TRUE.
012134*    SET L5435-TRMN-TYP-LAPSE  TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
016158     OR DEFERRED-TRANS
               GO TO 3214-LAPSE-2-X
           END-IF.

           SET L1120-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3219-PROCESS-LAPSE
012134*           THRU 3219-PROCESS-LAPSE-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-SEGF-SUB > +20
012134*           UNTIL   WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*           OR      WS-CVG-TO-PROCESS(WS-SEGF-SUB) = ZERO
012134*    ELSE
012134*        PERFORM  3219-PROCESS-LAPSE
012134*            THRU 3219-PROCESS-LAPSE-X
012134*    END-IF.
012134     PERFORM  3219-PROCESS-LAPSE
012134         THRU 3219-PROCESS-LAPSE-X.

           IF NOT L1120-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3214-LAPSE-2-X.
           EXIT.

      *-------------------
       3219-PROCESS-LAPSE.
      *-------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1120-PRCES-LEVEL-CVG      TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                       TO L1120-CVG-NUM
012134*    END-IF.
012134*
           SET L1120-PRCES-TYP-ALL TO TRUE.
016503     SET L1120-REDO-WARNING  TO TRUE.
           PERFORM  1120-1000-PROCESS-LAPSE
               THRU 1120-1000-PROCESS-LAPSE-X.

       3219-PROCESS-LAPSE-X.
           EXIT.

      *-------------------
       3220-LAPSE-W-VALUE.
      *-------------------

           PERFORM  1170-1000-BUILD-PARM-INFO
               THRU 1170-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1170-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1170-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1170-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1170-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1170-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1170-EFF-DT.
           MOVE WGLOB-USER-ID         TO L1170-INIT-HOLDER.
012134     MOVE E0691-DEATH-CODE      TO L1170-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1170-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1170-LTAXWH-CALC-CD.
013693     SET  L1170-LTAXWH-DISB-NONP TO TRUE.
018731     MOVE E0691-CLI-ID           TO L1170-CLI-ID.
018731     MOVE E0691-CLI-BNK-ACCT-NUM TO L1170-CLI-BNK-ACCT-NUM.

           IF PROCESSING-POLICY
               SET L1170-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1170-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3222-LAPSE-W-VAL-1
                       THRU 3222-LAPSE-W-VAL-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3224-LAPSE-W-VAL-2
                       THRU 3224-LAPSE-W-VAL-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

018731     IF  L1170-RETRN-OK
018731     AND NOT WGLOB-RETURN-ERROR
018731         MOVE L1170-CLI-ID    TO MIR-CLI-ID
018731         MOVE L1170-CLI-BNK-ACCT-NUM
018731                              TO MIR-CLI-BNK-ACCT-NUM
018731     END-IF.

       3220-LAPSE-W-VALUE-X.
           EXIT.

      *-------------------
       3222-LAPSE-W-VAL-1.
      *-------------------

           SET L1170-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1170-REDO-WARNING        TO TRUE.

           PERFORM  1170-1000-PRCES-LAPSE-VAL
               THRU 1170-1000-PRCES-LAPSE-VAL-X.
           IF L1170-RETRN-OK
016158*        CONTINUE
016158         IF L1170-DEFER-REQUIRE
016158             SET DEFERRED-TRANS TO TRUE
016158* MSG: FUND UNIT PRICES NOT AVAILABLE,
016158*      TERMINATION WILL BE DEFERRED
016158             MOVE 'CS06910001' TO WGLOB-MSG-REF-INFO
016158             PERFORM  0260-1000-GENERATE-MESSAGE
016158                 THRU 0260-1000-GENERATE-MESSAGE-X
016158         END-IF
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3222-LAPSE-W-VAL-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912205'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912206'      TO WGLOB-MSG-REF-INFO
           END-IF.
           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3222-LAPSE-W-VAL-1-X.
           EXIT.

      *-------------------
       3224-LAPSE-W-VAL-2.
      *-------------------

012134*    SET L5435-PRCES-TYP-TRMN      TO TRUE.
012134*    SET L5435-TRMN-TYP-LAPSE-VAL  TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
016158     OR DEFERRED-TRANS
               GO TO 3224-LAPSE-W-VAL-2-X
           END-IF.

           SET L1120-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3229-PROCESS-LAPSE-W-VAL
012134*           THRU 3229-PROCESS-LAPSE-W-VAL-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-SEGF-SUB > +20
012134*           UNTIL   WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*           OR      WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*    ELSE
012134*        PERFORM  3229-PROCESS-LAPSE-W-VAL
012134*            THRU 3229-PROCESS-LAPSE-W-VAL-X
012134*    END-IF.
012134     PERFORM  3229-PROCESS-LAPSE-W-VAL
012134         THRU 3229-PROCESS-LAPSE-W-VAL-X.

           IF NOT L1170-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3224-LAPSE-W-VAL-2-X.
           EXIT.
      /
      *-------------------------
       3229-PROCESS-LAPSE-W-VAL.
      *-------------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1170-PRCES-LEVEL-CVG      TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                       TO L1170-CVG-NUM
012134*    END-IF.
012134*
           SET L1170-PRCES-TYP-ALL TO TRUE.
016503     SET L1170-REDO-WARNING  TO TRUE.

           PERFORM  1170-1000-PRCES-LAPSE-VAL
               THRU 1170-1000-PRCES-LAPSE-VAL-X.

       3229-PROCESS-LAPSE-W-VAL-X.
           EXIT.
      /
      *-------------
       3230-CONVERT.
      *-------------

           PERFORM  1150-1000-BUILD-PARM-INFO
               THRU 1150-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1150-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1150-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1150-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1150-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1150-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1150-EFF-DT.
012134     MOVE E0691-DEATH-CODE      TO L1150-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1150-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1150-LTAXWH-CALC-CD.
013693     SET  L1150-LTAXWH-DISB-NONP TO TRUE.
018731     MOVE E0691-CLI-ID           TO L1150-CLI-ID.
018731     MOVE E0691-CLI-BNK-ACCT-NUM TO L1150-CLI-BNK-ACCT-NUM.

           IF PROCESSING-POLICY
               SET L1150-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1150-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3232-CONVERT-1
                       THRU 3232-CONVERT-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3234-CONVERT-2
                       THRU 3234-CONVERT-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

018731     IF  L1150-RETRN-OK
018731     AND NOT WGLOB-RETURN-ERROR
018731         MOVE L1150-CLI-ID    TO MIR-CLI-ID
018731         MOVE L1150-CLI-BNK-ACCT-NUM
018731                              TO MIR-CLI-BNK-ACCT-NUM
018731     END-IF.

       3230-CONVERT-X.
           EXIT.
      /
      *---------------
       3232-CONVERT-1.
      *---------------

           SET L1150-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1150-REDO-WARNING        TO TRUE.

           PERFORM  1150-1000-PROCESS-CONVERT
               THRU 1150-1000-PROCESS-CONVERT-X.
           IF L1150-RETRN-OK
016158*        CONTINUE
016158         IF L1150-DEFER-REQUIRE
016158             SET DEFERRED-TRANS TO TRUE
016158* MSG: FUND UNIT PRICES NOT AVAILABLE,
016158*      TERMINATION WILL BE DEFERRED
016158             MOVE 'CS06910001' TO WGLOB-MSG-REF-INFO
016158             PERFORM  0260-1000-GENERATE-MESSAGE
016158                 THRU 0260-1000-GENERATE-MESSAGE-X
016158         END-IF
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3232-CONVERT-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912207'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912208'      TO WGLOB-MSG-REF-INFO
           END-IF.
           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3232-CONVERT-1-X.
           EXIT.
      /
      *---------------
       3234-CONVERT-2.
      *---------------

012134*    SET L5435-PRCES-TYP-TRMN   TO TRUE.
012134*    SET L5435-TRMN-TYP-CONVERT TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
016158     OR DEFERRED-TRANS
               GO TO 3234-CONVERT-2-X
           END-IF.

           SET L1150-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3239-PROCESS-CONVERT
012134*           THRU 3239-PROCESS-CONVERT-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-SEGF-SUB > +20
012134*           UNTIL   WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*           OR      WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*    ELSE
012134*        PERFORM  3239-PROCESS-CONVERT
012134*            THRU 3239-PROCESS-CONVERT-X
012134*
012134*    END-IF.
012134     PERFORM  3239-PROCESS-CONVERT
012134         THRU 3239-PROCESS-CONVERT-X.

           IF NOT L1150-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3234-CONVERT-2-X.
           EXIT.
      /
      *---------------------
       3239-PROCESS-CONVERT.
      *---------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1150-PRCES-LEVEL-CVG        TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                         TO L1150-CVG-NUM
012134*    END-IF.
012134*
           SET L1150-PRCES-TYP-ALL TO TRUE.
016503     SET L1150-REDO-WARNING  TO TRUE.

           PERFORM  1150-1000-PROCESS-CONVERT
               THRU 1150-1000-PROCESS-CONVERT-X.

       3239-PROCESS-CONVERT-X.
           EXIT.
      /
      *---------------
       3240-DEATH.
      *---------------

           PERFORM  1160-1000-BUILD-PARM-INFO
               THRU 1160-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1160-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1160-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1160-CHEQUE-SW.
026055*    MOVE E0691-PAYO-MTHD-CD    TO L1160-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1160-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1160-EFF-DT.
           MOVE WGLOB-USER-ID         TO L1160-INIT-HOLDER.
           MOVE E0691-DEATH-CODE      TO L1160-DEATH-REASON.
012134     MOVE E0691-DEATH-CODE      TO L1160-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1160-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1160-LTAXWH-CALC-CD.
013693     SET  L1160-LTAXWH-DISB-NONP TO TRUE.
026055*    MOVE E0691-CLI-ID           TO L1160-CLI-ID.
026055*    MOVE E0691-CLI-BNK-ACCT-NUM TO L1160-CLI-BNK-ACCT-NUM.

           IF PROCESSING-POLICY
               SET L1160-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1160-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3242-DEATH-1
                       THRU 3242-DEATH-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3244-DEATH-2
                       THRU 3244-DEATH-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

018731     IF  L1160-RETRN-OK
018731     AND NOT WGLOB-RETURN-ERROR
026055*        MOVE L1160-CLI-ID    TO MIR-CLI-ID
026055*        MOVE L1160-CLI-BNK-ACCT-NUM
026055*                             TO MIR-CLI-BNK-ACCT-NUM
023437
023437         PERFORM  3246-MOVE-DEATH-TAX-TO-MIR
023437             THRU 3246-MOVE-DEATH-TAX-TO-MIR-X
023444
023444         MOVE L1160-TAX-ACB-AMT TO L0290-INPUT-V02
023444         MOVE 2                 TO L0290-PRECISION
023444         MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
023444                                TO L0290-MAX-OUT-LEN
023444         PERFORM  0290-2000-FORMAT-FOR-MIR
023444             THRU 0290-2000-FORMAT-FOR-MIR-X
023444         MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-TAX-ACB-AMT
023444
023444         COMPUTE WS-TRMN-AMT = L1160-TAXBL-GRS-DSTRB-AMT
023444         MOVE WS-TRMN-AMT       TO L0290-INPUT-V02
023444         MOVE 2                 TO L0290-PRECISION
023444         MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
023444                                TO L0290-MAX-OUT-LEN
023444         PERFORM  0290-2000-FORMAT-FOR-MIR
023444             THRU 0290-2000-FORMAT-FOR-MIR-X
023444         MOVE L0290-OUTPUT-DATA TO MIR-DV-TAXBL-GRS-DSTRB-AMT
023444
023444         MOVE L1160-GRS-DSTRB-AMT
023444                                TO L0290-INPUT-V02
023444         MOVE 2                 TO L0290-PRECISION
023444         MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
023444                                TO L0290-MAX-OUT-LEN
023444         PERFORM  0290-2000-FORMAT-FOR-MIR
023444             THRU 0290-2000-FORMAT-FOR-MIR-X
023444         MOVE L0290-OUTPUT-DATA TO MIR-DV-GRS-DSTRB-AMT
026055
026055         MOVE L1160-POL-BNFY-XIST-IND
026055                                TO MIR-DV-POL-BNFY-XIST-IND
031036
031036         MOVE L1160-TOT-DTHCLM-AMT TO L0290-INPUT-V02
031036         MOVE 2                 TO L0290-PRECISION
031036         MOVE LENGTH OF MIR-DV-TOT-DTHCLM-AMT
031036                                TO L0290-MAX-OUT-LEN
031036         PERFORM  0290-2000-FORMAT-FOR-MIR
031036             THRU 0290-2000-FORMAT-FOR-MIR-X
031036         MOVE L0290-OUTPUT-DATA TO MIR-DV-TOT-DTHCLM-AMT
018731     END-IF.

031036     IF  L1160-TOT-DTHCLM-AMT > ZERO
031036*MSG: THE TOTAL DEATH CLAIM AMOUNT IS (@1)
031036         MOVE 'CS06914314'          TO WGLOB-MSG-REF-INFO
031036         COMPUTE L0290-INPUT-NUMBER = L1160-TOT-DTHCLM-AMT
031036                                    * L0290-CRCY-MULT-FCT
031036         MOVE WGLOB-CRCY-SCALE-QTY  TO L0290-PRECISION
031036         MOVE 40                    TO L0290-MAX-OUT-LEN
031036         SET L0290-MESSAGE-FORMAT   TO TRUE
031036         SET L0290-SIGN-DISPLAY     TO TRUE
031036         SET L0290-SIGN-FLOAT       TO TRUE
031036         PERFORM 0290-1000-NUMERIC-FORMAT
031036            THRU 0290-1000-NUMERIC-FORMAT-X
031036         MOVE L0290-OUTPUT-DATA     TO WGLOB-MSG-PARM (1)
031036         PERFORM  0260-1000-GENERATE-MESSAGE
031036             THRU 0260-1000-GENERATE-MESSAGE-X
031036     END-IF.

       3240-DEATH-X.
           EXIT.
      /
      *---------------
       3242-DEATH-1.
      *---------------

           SET L1160-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1160-REDO-WARNING        TO TRUE.

           PERFORM  1160-1000-PROCESS-DEATH
               THRU 1160-1000-PROCESS-DEATH-X.
           IF L1160-RETRN-OK
016158*        CONTINUE
016158         IF L1160-DEFER-REQUIRE
016158             SET DEFERRED-TRANS TO TRUE
016158* MSG: FUND UNIT PRICES NOT AVAILABLE,
016158*      TERMINATION WILL BE DEFERRED
016158             MOVE 'CS06910001' TO WGLOB-MSG-REF-INFO
016158             PERFORM  0260-1000-GENERATE-MESSAGE
016158                 THRU 0260-1000-GENERATE-MESSAGE-X
016158         END-IF
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3242-DEATH-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912209'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912210'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3242-DEATH-1-X.
           EXIT.
      /
      *-------------
       3244-DEATH-2.
      *-------------

012134*    SET L5435-PRCES-TYP-TRMN  TO TRUE.
012134*    SET L5435-TRMN-TYP-DEATH  TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.

           IF NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
016158     OR DEFERRED-TRANS
               GO TO 3244-DEATH-2-X
           END-IF.

012134*    IF  WS-PAYOUT-AMOUNT NOT = ZERO
012134*MSG: 'SEG FUND DEATH CLAIM AMOUNT @1'
012134*        MOVE 'CS06914242'             TO WGLOB-MSG-REF-INFO
012134*        MOVE WS-PAYOUT-AMOUNT         TO WS-ED-PAYOUT-AMOUNT
012134*        MOVE WS-ED-PAYOUT-AMOUNT      TO WGLOB-MSG-PARM (1)
012134*        COMPUTE L0290-INPUT-NUMBER = WS-PAYOUT-AMOUNT * 100
012134*        MOVE 2                        TO L0290-PRECISION
012134*        MOVE 40                       TO L0290-MAX-OUT-LEN
012134*        SET L0290-MESSAGE-FORMAT      TO TRUE
012134*        SET L0290-SIGN-DISPLAY        TO TRUE
012134*        SET L0290-SIGN-FLOAT          TO TRUE
012134*        PERFORM  0290-1000-NUMERIC-FORMAT
012134*            THRU 0290-1000-NUMERIC-FORMAT-X
012134*        MOVE L0290-OUTPUT-DATA        TO WGLOB-MSG-PARM (1)
012134*        PERFORM  0260-1000-GENERATE-MESSAGE
012134*            THRU 0260-1000-GENERATE-MESSAGE-X
012134*    END-IF.
012134*
           SET L1160-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3249-PROCESS-DEATH
012134*           THRU 3249-PROCESS-DEATH-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-SEGF-SUB > +20
012134*           UNTIL   WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*           OR      WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*    ELSE
012134*        PERFORM  3249-PROCESS-DEATH
012134*            THRU 3249-PROCESS-DEATH-X
012134*    END-IF.
012134     PERFORM  3249-PROCESS-DEATH
012134         THRU 3249-PROCESS-DEATH-X.

           IF NOT L1160-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3244-DEATH-2-X.
           EXIT.
      /
023437*----------------------------
023437 3246-MOVE-DEATH-TAX-TO-MIR.
023437*----------------------------
023437
029060*    MOVE L1160-CDA-FED-TAXWH-AMT  TO L0290-INPUT-V02.
029060     MOVE L1160-FTAXWH-AMT         TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-FTAXWH-AMT.
023437
029060*    MOVE L1160-LTAXWH-CALC-CD     TO MIR-LTAXWH-CALC-CD.
023437
029060*    MOVE L1160-CDA-LTAXWH-AMT     TO L0290-INPUT-V02.
029060     MOVE L1160-LTAXWH-AMT         TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                   TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-LTAXWH-FLAT-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-LTAXWH-AMT.
023437
029060*    IF  L1160-CDA-LTAXWH-AMT    > 0
029060*        MOVE ZEROS                TO L0290-INPUT-V02
029060*        MOVE 2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                                  TO L0290-MAX-OUT-LEN
029060*        PERFORM 0290-2000-FORMAT-FOR-MIR
029060*           THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE  L0290-OUTPUT-DATA   TO MIR-LTAXWH-PCT
029060*    END-IF.
023437
023437 3246-MOVE-DEATH-TAX-TO-MIR-X.
023437     EXIT.
      *-------------------
       3249-PROCESS-DEATH.
      *-------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1160-PRCES-LEVEL-CVG    TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                     TO L1160-CVG-NUM
012134*    END-IF.
012134*
           SET L1160-PRCES-TYP-ALL TO TRUE.
016503     SET L1160-REDO-WARNING  TO TRUE.

           PERFORM  1160-1000-PROCESS-DEATH
               THRU 1160-1000-PROCESS-DEATH-X.

       3249-PROCESS-DEATH-X.
           EXIT.
      /
      *---------------
020478*3250-SURRENDER.
      *---------------

020478*    PERFORM  1140-1000-BUILD-PARM-INFO
020478*        THRU 1140-1000-BUILD-PARM-INFO-X.
020478*    IF  MIR-SUPRES-CNFRM-IND = 'Y'
020478*        SET L1140-SUPPRESS-CONFIRM TO TRUE
020478*    END-IF.
020478*
020478*    MOVE E0691-COV-NO          TO L1140-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1140-CHEQUE-IND.
020478*    MOVE E0691-PAYO-MTHD-CD    TO L1140-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1140-CLI-SUR-NM-1-4.
020478*    MOVE E0691-EFF-DATE        TO L1140-EFF-DT.
020478*    MOVE WGLOB-USER-ID         TO L1140-INIT-HOLDER.
016158*    MOVE E0691-DEATH-CODE      TO L1140-SURR-FOR-TRANSFER-CD.
020478*    MOVE E0691-SURR-TAX-OVRID-CD TO L1140-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1140-TAX-BYPASS-IND.
020478*    MOVE MIR-FED-TAXWH-CALC-CD TO L1140-FED-TAXWH-CALC-CD.
020478*    MOVE E0691-LTAXWH-CALC-CD  TO L1140-LTAXWH-CALC-CD.
020478*    SET  L1140-LTAXWH-DISB-NONP TO TRUE.
020478*    MOVE E0691-CLI-ID           TO L1140-CLI-ID.
020478*    MOVE E0691-CLI-BNK-ACCT-NUM TO L1140-CLI-BNK-ACCT-NUM.
020478*
020478*    IF PROCESSING-POLICY
020478*        SET L1140-PRCES-LEVEL-POLICY  TO TRUE
020478*    ELSE
020478*        SET L1140-PRCES-LEVEL-CVG     TO TRUE
020478*    END-IF.
020478*
020478*    EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
020478*        WHEN MIR-DV-PRCES-STATE-CD = '2'
020478*            PERFORM  3252-SURR-1
020478*                THRU 3252-SURR-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
020478*        WHEN MIR-DV-PRCES-STATE-CD = '3'
020478*            PERFORM  3254-SURR-2
020478*                THRU 3254-SURR-2-X
020478*
020478*        WHEN OTHER
020478*            CONTINUE
020478*
020478*    END-EVALUATE.
020478*
020478*    IF  L1140-RETRN-OK
020478*    AND NOT WGLOB-RETURN-ERROR
020478*        MOVE L1140-CLI-ID    TO MIR-CLI-ID
020478*        MOVE L1140-CLI-BNK-ACCT-NUM
020478*                             TO MIR-CLI-BNK-ACCT-NUM
020478*        EVALUATE TRUE
020478*            WHEN L1140-PAYO-MTHD-CHQ
020478*            WHEN L1140-PAYO-MTHD-EFT
020874*                 COMPUTE L0290-INPUT-NUMBER =
020874*                             L1140-NET-DISB-AMT * 100
020478*                 MOVE  L1140-NET-DISB-AMT TO L0290-INPUT-V02
020478*            WHEN OTHER
020874*                 COMPUTE L0290-INPUT-NUMBER =
020874*                             RPOL-POL-OS-DISB-AMT * 100
020478*                 MOVE RPOL-POL-OS-DISB-AMT TO L0290-INPUT-V02
020478*        END-EVALUATE
020478*        MOVE 2               TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-DV-NET-DISB-AMT
020478*                             TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020478*        PERFORM  0290-2000-FORMAT-FOR-MIR
020478*            THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA TO MIR-DV-NET-DISB-AMT
020478*
020478*        MOVE L1140-TAX-ACB-AMT TO L0290-INPUT-V02
020478*        MOVE 2                 TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
020478*                               TO L0290-MAX-OUT-LEN
020478*        PERFORM  0290-2000-FORMAT-FOR-MIR
020478*            THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-TAX-ACB-AMT
020478*
020478*        COMPUTE WS-TRMN-AMT = L1140-TAXBL-GRS-DSTRB-AMT
020478*        MOVE WS-TRMN-AMT       TO L0290-INPUT-V02
020478*        MOVE 2                 TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
020478*                               TO L0290-MAX-OUT-LEN
020478*        PERFORM  0290-2000-FORMAT-FOR-MIR
020478*            THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA TO MIR-DV-TAXBL-GRS-DSTRB-AMT
020478*
020478*        MOVE L1140-GRS-DSTRB-AMT
020478*                               TO L0290-INPUT-V02
020478*        MOVE 2                 TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
020478*                               TO L0290-MAX-OUT-LEN
020478*        PERFORM  0290-2000-FORMAT-FOR-MIR
020478*            THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA TO MIR-DV-GRS-DSTRB-AMT
020478*
020478*        PERFORM  3256-MOVE-SURR-TAX-TO-MIR
020478*            THRU 3256-MOVE-SURR-TAX-TO-MIR-X
020478*    END-IF.
020478*
020478*3250-SURRENDER-X.
020478*    EXIT.
      /
      *------------
020478*3252-SURR-1.
      *------------

020478*    SET L1140-PRCES-TYP-EDIT-ONLY     TO TRUE
020478*    SET L1140-REDO-WARNING            TO TRUE
020478*
020478*    PERFORM  1140-1000-PROCESS-SURRENDER
020478*        THRU 1140-1000-PROCESS-SURRENDER-X.
020478*    IF L1140-RETRN-OK
016158*        CONTINUE
020478*        IF L1140-DEFER-REQUIRE
020478*            SET DEFERRED-TRANS TO TRUE
016158* MSG: FUND UNIT PRICES NOT AVAILABLE,
016158*      TERMINATION WILL BE DEFERRED
020478*            MOVE 'CS06910001' TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*        END-IF
020478*    ELSE
020478*        SET WGLOB-RETURN-ERROR        TO TRUE
020478*        GO TO 3252-SURR-1-X
020478*    END-IF.
020478*
020478*    IF PROCESSING-POLICY
020478*        MOVE 'CS06912211'      TO WGLOB-MSG-REF-INFO
020478*    ELSE
020478*        MOVE 'CS06912212'      TO WGLOB-MSG-REF-INFO
020478*    END-IF.
020478*
020478*    PERFORM  2200-VERIFY-TRAN
020478*        THRU 2200-VERIFY-TRAN-X.
020478*
020478*3252-SURR-1-X.
020478*    EXIT.
      /
      *------------
020478*3254-SURR-2.
      *------------

012134*    SET L5435-PRCES-TYP-TRMN     TO TRUE.
012134*    SET L5435-TRMN-TYP-SURRENDER TO TRUE.
012134*
020478*    PERFORM  4000-PROCESS-START
020478*        THRU 4000-PROCESS-START-X.
020478*    IF NOT WGLOB-GOOD-RETURN
020478*    OR  WS-REDO-NOT-OK
020478*    OR DEFERRED-TRANS
020478*        GO TO 3254-SURR-2-X
020478*    END-IF.
020478*
020478*    SET L1140-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3259-PROCESS-SURRENDER
012134*           THRU 3259-PROCESS-SURRENDER-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-SEGF-SUB > +20
012134*           UNTIL   WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*           OR      WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*    ELSE
012134*        PERFORM  3259-PROCESS-SURRENDER
012134*            THRU 3259-PROCESS-SURRENDER-X
012134*    END-IF.
020478*    PERFORM  3259-PROCESS-SURRENDER
020478*        THRU 3259-PROCESS-SURRENDER-X.

020478*    IF NOT L1140-RETRN-OK
020478*        SET WGLOB-RETURN-ERROR     TO TRUE
020478*    END-IF.
020478*
020478*    PERFORM  4500-END-PROCESS
020478*        THRU 4500-END-PROCESS-X.
020478*
020478*3254-SURR-2-X.
020478*    EXIT.
      /
023437*----------------------------
023437 3256-MOVE-SURR-TAX-TO-MIR.
023437*----------------------------
023437
029060*    MOVE L1140-CDA-FED-TAXWH-AMT  TO L0290-INPUT-V02.
029060     MOVE L1140-FTAXWH-AMT         TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT TO L0290-MAX-OUT-LEN.
023437     PERFORM  0290-2000-FORMAT-FOR-MIR
023437         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-FTAXWH-AMT.
023437
029060*    MOVE L1140-LTAXWH-CALC-CD     TO MIR-LTAXWH-CALC-CD.
023437
029060*    MOVE L1140-CDA-LTAXWH-AMT     TO L0290-INPUT-V02.
029060     MOVE L1140-LTAXWH-AMT         TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                   TO L0290-MAX-OUT-LEN.
023437     PERFORM  0290-2000-FORMAT-FOR-MIR
023437         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-FLAT-AMT.
029060     MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-RQST-AMT.
023437
029060*    IF  L1140-CDA-LTAXWH-AMT > 0
029060
029060     IF  L1140-LTAXWH-AMT > 0
023437         MOVE ZEROS                TO L0290-INPUT-V02
023437         MOVE 2                        TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                   TO L0290-MAX-OUT-LEN
023437         PERFORM 0290-2000-FORMAT-FOR-MIR
023437            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE  L0290-OUTPUT-DATA   TO MIR-LTAXWH-PCT
029060         MOVE  L0290-OUTPUT-DATA   TO MIR-LTAXWH-RQST-PCT
023437     END-IF.
023437
023437 3256-MOVE-SURR-TAX-TO-MIR-X.
023437     EXIT.
      *----------------------
020478*3259-PROCESS-SURRENDER.
      *----------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1140-PRCES-LEVEL-CVG          TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                           TO L1140-CVG-NUM
012134*    END-IF.
012134*
020478*    SET L1140-PRCES-TYP-ALL TO TRUE.
020478*    SET L1140-REDO-WARNING  TO TRUE.
020478*
020478*    PERFORM  1140-1000-PROCESS-SURRENDER
020478*        THRU 1140-1000-PROCESS-SURRENDER-X.
020478*
020478*3259-PROCESS-SURRENDER-X.
020478*    EXIT.
      /
      *-------------
       3260-MAT-EXP.
      *-------------

           PERFORM  1130-1000-BUILD-PARM-INFO
               THRU 1130-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1130-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1130-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1130-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1130-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1130-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1130-EFF-DT.
012134     MOVE E0691-DEATH-CODE      TO L1130-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1130-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1130-LTAXWH-CALC-CD.
013693     SET  L1130-LTAXWH-DISB-NONP TO TRUE.
018731     MOVE E0691-CLI-ID           TO L1130-CLI-ID.
018731     MOVE E0691-CLI-BNK-ACCT-NUM TO L1130-CLI-BNK-ACCT-NUM.

           IF PROCESSING-POLICY
               SET L1130-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1130-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3262-MAT-EXP-1
                       THRU 3262-MAT-EXP-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3264-MAT-EXP-2
                       THRU 3264-MAT-EXP-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

018731     IF  L1130-RETRN-OK
018731     AND NOT WGLOB-RETURN-ERROR
018731         MOVE L1130-CLI-ID    TO MIR-CLI-ID
018731         MOVE L1130-CLI-BNK-ACCT-NUM
018731                              TO MIR-CLI-BNK-ACCT-NUM
023437         PERFORM  3266-MOVE-MAT-EXP-TAX-TO-MIR
023437             THRU 3266-MOVE-MAT-EXP-TAX-TO-MIR-X
018731     END-IF.

       3260-MAT-EXP-X.
           EXIT.
      /
      *---------------
       3262-MAT-EXP-1.
      *---------------

           SET L1130-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1130-REDO-WARNING        TO TRUE.

           PERFORM  1130-1000-PROCESS-MAT-EXP
               THRU 1130-1000-PROCESS-MAT-EXP-X.
           IF L1130-RETRN-OK
016158*        CONTINUE
016158         IF L1130-DEFER-REQUIRE
016158             SET DEFERRED-TRANS TO TRUE
016158* MSG: FUND UNIT PRICES NOT AVAILABLE,
016158*      TERMINATION WILL BE DEFERRED
016158             MOVE 'CS06910001' TO WGLOB-MSG-REF-INFO
016158             PERFORM  0260-1000-GENERATE-MESSAGE
016158                 THRU 0260-1000-GENERATE-MESSAGE-X
016158         END-IF
023444         MOVE L1130-TAX-ACB-AMT TO L0290-INPUT-V02
023444         MOVE 2                 TO L0290-PRECISION
023444         MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
023444                                TO L0290-MAX-OUT-LEN
023444         PERFORM  0290-2000-FORMAT-FOR-MIR
023444             THRU 0290-2000-FORMAT-FOR-MIR-X
023444         MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-TAX-ACB-AMT
023444
023444         COMPUTE WS-TRMN-AMT = L1130-TAXBL-GRS-DSTRB-AMT
023444         MOVE WS-TRMN-AMT       TO L0290-INPUT-V02
023444         MOVE 2                 TO L0290-PRECISION
023444         MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
023444                                TO L0290-MAX-OUT-LEN
023444         PERFORM  0290-2000-FORMAT-FOR-MIR
023444             THRU 0290-2000-FORMAT-FOR-MIR-X
023444         MOVE L0290-OUTPUT-DATA TO MIR-DV-TAXBL-GRS-DSTRB-AMT
023444
023444         MOVE L1130-GRS-DSTRB-AMT
023444                                TO L0290-INPUT-V02
023444         MOVE 2                 TO L0290-PRECISION
023444         MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
023444                                TO L0290-MAX-OUT-LEN
023444         PERFORM  0290-2000-FORMAT-FOR-MIR
023444             THRU 0290-2000-FORMAT-FOR-MIR-X
023444         MOVE L0290-OUTPUT-DATA TO MIR-DV-GRS-DSTRB-AMT
           ELSE
014765         SET WGLOB-RETURN-ERROR        TO TRUE
               GO TO 3262-MAT-EXP-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912213'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912214'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3262-MAT-EXP-1-X.
           EXIT.
      /
      *---------------
       3264-MAT-EXP-2.
      *---------------

012134*    SET L5435-PRCES-TYP-TRMN          TO TRUE.
012134*    SET L5435-TRMN-TYP-MAT-EXP        TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
016158     OR DEFERRED-TRANS
               GO TO 3264-MAT-EXP-2-X
           END-IF.

           SET L1130-PRCES-TYP-ALL           TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3269-PRCES-MAT-EXP
012134*           THRU 3269-PRCES-MAT-EXP-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-SEGF-SUB > +20
012134*           UNTIL   WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*           OR      WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*    ELSE
012134*        PERFORM  3269-PRCES-MAT-EXP
012134*            THRU 3269-PRCES-MAT-EXP-X
012134*    END-IF.
012134     PERFORM  3269-PRCES-MAT-EXP
012134         THRU 3269-PRCES-MAT-EXP-X.

           IF NOT L1130-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3264-MAT-EXP-2-X.
           EXIT.
      /
023437*----------------------------
023437 3266-MOVE-MAT-EXP-TAX-TO-MIR.
023437*----------------------------
023437
029060*    MOVE L1130-CDA-FED-TAXWH-AMT  TO L0290-INPUT-V02.
029060     MOVE L1130-FTAXWH-AMT         TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-FTAXWH-AMT.
023437
029060*    MOVE L1130-LTAXWH-CALC-CD     TO MIR-LTAXWH-CALC-CD.
023437
029060*    MOVE L1130-CDA-LTAXWH-AMT     TO L0290-INPUT-V02.
029060     MOVE L1130-LTAXWH-AMT         TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                   TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-LTAXWH-FLAT-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-LTAXWH-RQST-AMT.
023437
029060*    IF  L1130-CDA-LTAXWH-AMT > 0
029060
029060     IF  L1130-LTAXWH-AMT > 0
023437         MOVE ZEROS                TO L0290-INPUT-V02
023437         MOVE 2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                   TO L0290-MAX-OUT-LEN
023437         PERFORM 0290-2000-FORMAT-FOR-MIR
023437            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE  L0290-OUTPUT-DATA   TO MIR-LTAXWH-PCT
029060         MOVE  L0290-OUTPUT-DATA   TO MIR-LTAXWH-RQST-PCT
023437     END-IF.
023437
023437 3266-MOVE-MAT-EXP-TAX-TO-MIR-X.
023437     EXIT.
023437
      *------------------
       3269-PRCES-MAT-EXP.
      *------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1130-PRCES-LEVEL-CVG    TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                     TO L1130-CVG-NUM
012134*    END-IF.
012134*
           SET L1130-PRCES-TYP-ALL TO TRUE.
016503     SET L1130-REDO-WARNING  TO TRUE.
           PERFORM  1130-1000-PROCESS-MAT-EXP
               THRU 1130-1000-PROCESS-MAT-EXP-X.

       3269-PRCES-MAT-EXP-X.
           EXIT.
      /
      *-----------------
       3270-REPLACEMENT.
      *-----------------

           PERFORM  1180-1000-BUILD-PARM-INFO
               THRU 1180-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1180-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1180-CVG-NUM.
           MOVE E0691-EFF-DATE        TO L1180-EFF-DT.
018731*    MOVE E0691-CHEQUE-IND      TO L1180-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1180-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1180-CLI-SUR-NM-1-4.
023438*    MOVE E0691-DEATH-CODE      TO L1180-SURR-FOR-TRANSFER-CD.
023438     MOVE E0691-SURR-TAX-OVRID-CD
023438                                TO L1180-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1180-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1180-LTAXWH-CALC-CD.
013693     SET  L1180-LTAXWH-DISB-NONP TO TRUE.
018731     MOVE E0691-CLI-ID           TO L1180-CLI-ID.
018731     MOVE E0691-CLI-BNK-ACCT-NUM TO L1180-CLI-BNK-ACCT-NUM.

           IF PROCESSING-COVERAGE
               SET L1180-PRCES-LEVEL-CVG     TO TRUE
           ELSE
               SET L1180-PRCES-LEVEL-POLICY  TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3272-REPLACEMENT-1
                       THRU 3272-REPLACEMENT-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3274-REPLACEMENT-2
                       THRU 3274-REPLACEMENT-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

018731     IF  L1180-RETRN-OK
018731     AND NOT WGLOB-RETURN-ERROR
018731         MOVE L1180-CLI-ID    TO MIR-CLI-ID
018731         MOVE L1180-CLI-BNK-ACCT-NUM
018731                              TO MIR-CLI-BNK-ACCT-NUM
018844         EVALUATE TRUE
018844             WHEN L1180-PAYO-MTHD-CHQ
018844             WHEN L1180-PAYO-MTHD-EFT
020874*                 COMPUTE L0290-INPUT-NUMBER =
020874*                             L1180-NET-DISB-AMT * 100
020874                  MOVE L1180-NET-DISB-AMT TO L0290-INPUT-V02
018844             WHEN OTHER
020874*                 COMPUTE L0290-INPUT-NUMBER =
020874*                             RPOL-POL-OS-DISB-AMT * 100
020874                  MOVE RPOL-POL-OS-DISB-AMT TO L0290-INPUT-V02
018844         END-EVALUATE
018844         MOVE 2               TO L0290-PRECISION
018844         MOVE LENGTH OF MIR-DV-NET-DISB-AMT
018844                              TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
018844         MOVE L0290-OUTPUT-DATA TO MIR-DV-NET-DISB-AMT
018731     END-IF.

       3270-REPLACEMENT-X.
           EXIT.
      /
      *-------------------
       3272-REPLACEMENT-1.
      *-------------------

           SET L1180-PRCES-TYP-EDIT-ONLY     TO TRUE.
016503     SET L1180-REDO-WARNING            TO TRUE.

           PERFORM 1180-1000-PRCES-REPL
              THRU 1180-1000-PRCES-REPL-X.
           IF L1180-RETRN-OK
016158*        CONTINUE
016158         IF L1180-DEFER-REQUIRE
016158             SET DEFERRED-TRANS TO TRUE
016158* MSG: FUND UNIT PRICES NOT AVAILABLE,
016158*      TERMINATION WILL BE DEFERRED
016158             MOVE 'CS06910001' TO WGLOB-MSG-REF-INFO
016158             PERFORM  0260-1000-GENERATE-MESSAGE
016158                 THRU 0260-1000-GENERATE-MESSAGE-X
016158         END-IF
           ELSE
               SET WGLOB-RETURN-ERROR        TO TRUE
               GO TO 3272-REPLACEMENT-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912232'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912233'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3272-REPLACEMENT-1-X.
           EXIT.
      /
      *-------------------
       3274-REPLACEMENT-2.
      *-------------------

012134*    SET L5435-PRCES-TYP-TRMN        TO TRUE.
012134*    SET L5435-TRMN-TYP-REPLACEMENT  TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
016158     OR DEFERRED-TRANS
               GO TO 3274-REPLACEMENT-2-X
           END-IF.

           SET L1180-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3279-PROCESS-REPLACEMENT
012134*           THRU 3279-PROCESS-REPLACEMENT-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-SEGF-SUB > +20
012134*           UNTIL   WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*           OR      WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*    ELSE
012134*        PERFORM  3279-PROCESS-REPLACEMENT
012134*            THRU 3279-PROCESS-REPLACEMENT-X
012134*    END-IF.
012134     PERFORM  3279-PROCESS-REPLACEMENT
012134         THRU 3279-PROCESS-REPLACEMENT-X.

           IF NOT L1180-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3274-REPLACEMENT-2-X.
           EXIT.
      /
      *-------------------------
       3279-PROCESS-REPLACEMENT.
      *-------------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1180-PRCES-LEVEL-CVG    TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                     TO L1180-CVG-NUM
012134*    END-IF.
012134*
           SET L1180-PRCES-TYP-ALL TO TRUE.
016503     SET L1180-REDO-WARNING  TO TRUE.
           PERFORM  1180-1000-PRCES-REPL
               THRU 1180-1000-PRCES-REPL-X.

       3279-PROCESS-REPLACEMENT-X.
           EXIT.
      /
      *-------------
       3300-REV-NTU.
      *-------------

           PERFORM  1110-1000-BUILD-PARM-INFO
               THRU 1110-1000-BUILD-PARM-INFO-X.

           MOVE E0691-COV-NO          TO L1110-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1110-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1110-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1110-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1110-EFF-DT.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1110-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1110-LTAXWH-CALC-CD.
013693     SET  L1110-LTAXWH-DISB-NONP TO TRUE.
012134     MOVE E0691-DEATH-CODE      TO L1110-SURR-FOR-TRANSFER-CD.

           IF PROCESSING-POLICY
               SET L1110-PRCES-LEVEL-POLICY TO TRUE
           ELSE
               SET L1110-PRCES-LEVEL-CVG    TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3302-REV-NTU-1
                       THRU 3302-REV-NTU-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3304-REV-NTU-2
                       THRU 3304-REV-NTU-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

       3300-REV-NTU-X.
           EXIT.
      /
      *---------------
       3302-REV-NTU-1.
      *---------------

           SET L1110-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1110-REDO-WARNING        TO TRUE.

           PERFORM  1110-2000-REINST-NTU
               THRU 1110-2000-REINST-NTU-X
           IF L1110-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3302-REV-NTU-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912215'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912216'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3302-REV-NTU-1-X.
           EXIT.
      /
      *---------------
       3304-REV-NTU-2.
      *---------------

012134*    SET L5435-PRCES-TYP-REINST TO TRUE.
012134*    SET L5435-TRMN-TYP-NTU     TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR  WS-REDO-NOT-OK
               GO TO 3304-REV-NTU-2-X
           END-IF.

           SET L1110-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3309-PRCES-REV-NTU
012134*           THRU 3309-PRCES-REV-NTU-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*           OR      WS-SEGF-SUB > +20
012134*           OR      WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*    ELSE
012134*        PERFORM  3309-PRCES-REV-NTU
012134*            THRU 3309-PRCES-REV-NTU-X
012134*    END-IF.
012134         PERFORM  3309-PRCES-REV-NTU
012134             THRU 3309-PRCES-REV-NTU-X.

           IF NOT L1110-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3304-REV-NTU-2-X.
           EXIT.
      /
      *-------------------
       3309-PRCES-REV-NTU.
      *-------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1110-PRCES-LEVEL-CVG          TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                           TO L1110-CVG-NUM
012134*    END-IF.
012134*
           SET L1110-PRCES-TYP-ALL TO TRUE.
012136     SET L1110-FCN-DRVR-SECONDARY TO TRUE.
016503     SET L1110-REDO-WARNING       TO TRUE.
012136     MOVE L4750-EFF-DT          TO L1110-EFF-DT.
           PERFORM  1110-2000-REINST-NTU
               THRU 1110-2000-REINST-NTU-X.

       3309-PRCES-REV-NTU-X.
           EXIT.
      /
      *---------------
       3310-REV-LAPSE.
      *---------------

           PERFORM  1120-1000-BUILD-PARM-INFO
               THRU 1120-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1120-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1120-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1120-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1120-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1120-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1120-EFF-DT.
012134     MOVE E0691-DEATH-CODE      TO L1120-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1120-BYPASS-TAX-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1120-LTAXWH-CALC-CD.
013693     SET  L1120-LTAXWH-DISB-NONP TO TRUE.


           SET L1120-RQST-REINSTATE    TO TRUE.

           IF PROCESSING-POLICY
               SET L1120-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1120-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3312-REV-LAPSE-1
                       THRU 3312-REV-LAPSE-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3314-REV-LAPSE-2
                       THRU 3314-REV-LAPSE-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

       3310-REV-LAPSE-X.
           EXIT.
      /
      *-----------------
       3312-REV-LAPSE-1.
      *-----------------

           SET L1120-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1120-REDO-WARNING        TO TRUE.

           PERFORM  1120-2000-REINST-LAPSE
               THRU 1120-2000-REINST-LAPSE-X
           IF L1120-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3312-REV-LAPSE-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912217'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912218'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3312-REV-LAPSE-1-X.
           EXIT.
      /
      *-----------------
       3314-REV-LAPSE-2.
      *-----------------

012134*    SET L5435-PRCES-TYP-REINST TO TRUE.
012134*    SET L5435-TRMN-TYP-LAPSE   TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR WS-REDO-NOT-OK
               GO TO 3314-REV-LAPSE-2-X
           END-IF.

           SET L1120-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3319-PRCES-REV-LAPSE
012134*           THRU 3319-PRCES-REV-LAPSE-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*           OR      WS-SEGF-SUB > +20
012134*           OR      WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*    ELSE
012134*        PERFORM  3319-PRCES-REV-LAPSE
012134*            THRU 3319-PRCES-REV-LAPSE-X
012134*    END-IF.
012134         PERFORM  3319-PRCES-REV-LAPSE
012134             THRU 3319-PRCES-REV-LAPSE-X.

           IF NOT L1120-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3314-REV-LAPSE-2-X.
           EXIT.
      /
      *---------------------
       3319-PRCES-REV-LAPSE.
      *---------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1120-PRCES-LEVEL-CVG      TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                       TO L1120-CVG-NUM
012134*    END-IF.
012134*
           SET L1120-PRCES-TYP-ALL TO TRUE.
016503     SET L1120-REDO-WARNING  TO TRUE.

           PERFORM  1120-2000-REINST-LAPSE
               THRU 1120-2000-REINST-LAPSE-X.

       3319-PRCES-REV-LAPSE-X.
           EXIT.
      /
      *--------------------
       3320-REV-LAPSE-W-VAL.
      *--------------------

           PERFORM  1170-1000-BUILD-PARM-INFO
               THRU 1170-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1170-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1170-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1170-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1170-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1170-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1170-EFF-DT.
012134     MOVE E0691-DEATH-CODE      TO L1170-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1170-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1170-LTAXWH-CALC-CD.
013693     SET  L1170-LTAXWH-DISB-NONP TO TRUE.

           IF PROCESSING-COVERAGE
               SET L1170-PRCES-LEVEL-CVG    TO TRUE
               MOVE 'V'               TO L1170-LPV-RSN-CD
           ELSE
               SET L1170-PRCES-LEVEL-POLICY TO TRUE
               MOVE RPOL-POL-CEAS-REASN-CD
                                      TO L1170-LPV-RSN-CD
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3322-REV-LPV-1
                       THRU 3322-REV-LPV-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3324-REV-LPV-2
                       THRU 3324-REV-LPV-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

       3320-REV-LAPSE-W-VAL-X.
           EXIT.
      /
      *---------------
       3322-REV-LPV-1.
      *---------------

           SET L1170-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1170-REDO-WARNING        TO TRUE.

           PERFORM  1170-2000-REINST-LAPSE-VAL
               THRU 1170-2000-REINST-LAPSE-VAL-X
           IF L1170-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3322-REV-LPV-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912219'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912220'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3322-REV-LPV-1-X.
           EXIT.
      /
      *---------------
       3324-REV-LPV-2.
      *---------------

012134*    SET L5435-PRCES-TYP-REINST     TO TRUE.
012134*    SET L5435-TRMN-TYP-LAPSE-VAL   TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR WS-REDO-NOT-OK
               GO TO 3324-REV-LPV-2-X
           END-IF.

           SET L1170-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*         PERFORM 3329-PRCES-REV-LPV
012134*           THRU 3329-PRCES-REV-LPV-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*           OR      WS-SEGF-SUB > +20
012134*           OR      WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*    ELSE
012134*        PERFORM  3329-PRCES-REV-LPV
012134*            THRU 3329-PRCES-REV-LPV-X
012134*    END-IF.
012134         PERFORM  3329-PRCES-REV-LPV
012134             THRU 3329-PRCES-REV-LPV-X.

           IF NOT L1170-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3324-REV-LPV-2-X.
           EXIT.
      /
      *-------------------
       3329-PRCES-REV-LPV.
      *-------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1170-PRCES-LEVEL-CVG           TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                            TO L1170-CVG-NUM
012134*    END-IF.
012134*
           SET L1170-PRCES-TYP-ALL TO TRUE.
016503     SET L1170-REDO-WARNING  TO TRUE.

           PERFORM  1170-2000-REINST-LAPSE-VAL
               THRU 1170-2000-REINST-LAPSE-VAL-X.

       3329-PRCES-REV-LPV-X.
           EXIT.
      /
      *-----------------
       3330-REV-CONVERT.
      *-----------------

           PERFORM  1150-1000-BUILD-PARM-INFO
               THRU 1150-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1150-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1150-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1150-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1150-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1150-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1150-EFF-DT.
012134     MOVE E0691-DEATH-CODE      TO L1150-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1150-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1150-LTAXWH-CALC-CD.
013693     SET  L1150-LTAXWH-DISB-NONP TO TRUE.

           IF PROCESSING-POLICY
               SET L1150-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1150-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3332-REV-CONVERT-1
                       THRU 3332-REV-CONVERT-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3334-REV-CONVERT-2
                       THRU 3334-REV-CONVERT-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

       3330-REV-CONVERT-X.
           EXIT.
      /
      *-------------------
       3332-REV-CONVERT-1.
      *-------------------

           SET L1150-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1150-REDO-WARNING        TO TRUE.

           PERFORM  1150-2000-REINST-CONVERT
               THRU 1150-2000-REINST-CONVERT-X
           IF L1150-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3332-REV-CONVERT-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912221'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912222'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3332-REV-CONVERT-1-X.
           EXIT.
      /
      *-------------------
       3334-REV-CONVERT-2.
      *-------------------

012134*    SET L5435-PRCES-TYP-REINST TO TRUE.
012134*    SET L5435-TRMN-TYP-CONVERT TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR WS-REDO-NOT-OK
               GO TO 3334-REV-CONVERT-2-X
           END-IF.

           SET L1150-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3339-PRCES-REV-CONVERT
012134*           THRU 3339-PRCES-REV-CONVERT-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*           OR      WS-SEGF-SUB > +20
012134*           OR      WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*    ELSE
012134*        PERFORM  3339-PRCES-REV-CONVERT
012134*            THRU 3339-PRCES-REV-CONVERT-X
012134*    END-IF.
012134        PERFORM  3339-PRCES-REV-CONVERT
012134             THRU 3339-PRCES-REV-CONVERT-X.

           IF NOT L1150-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3334-REV-CONVERT-2-X.
           EXIT.
      /
      *-----------------------
       3339-PRCES-REV-CONVERT.
      *-----------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1150-PRCES-LEVEL-CVG           TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                            TO L1150-CVG-NUM
012134*    END-IF.
012134*
           SET L1150-PRCES-TYP-ALL TO TRUE.
016503     SET L1150-REDO-WARNING  TO TRUE.
           PERFORM  1150-2000-REINST-CONVERT
               THRU 1150-2000-REINST-CONVERT-X.

       3339-PRCES-REV-CONVERT-X.
           EXIT.
      /
      *---------------
       3340-REV-DEATH.
      *---------------

           PERFORM  1160-1000-BUILD-PARM-INFO
               THRU 1160-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1160-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1160-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1160-CHEQUE-SW.
026055*    MOVE E0691-PAYO-MTHD-CD    TO L1160-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1160-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1160-EFF-DT.
012134     MOVE E0691-DEATH-CODE      TO L1160-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1160-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1160-LTAXWH-CALC-CD.
013693     SET  L1160-LTAXWH-DISB-NONP TO TRUE.

           IF PROCESSING-POLICY
               SET L1160-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1160-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3342-REV-DEATH-1
                       THRU 3342-REV-DEATH-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3344-REV-DEATH-2
                       THRU 3344-REV-DEATH-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

       3340-REV-DEATH-X.
           EXIT.
      /
      *-----------------
       3342-REV-DEATH-1.
      *-----------------

           SET L1160-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1160-REDO-WARNING        TO TRUE.

           PERFORM  1160-2000-REINST-DEATH
               THRU 1160-2000-REINST-DEATH-X
           IF L1160-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3342-REV-DEATH-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912223'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912224'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3342-REV-DEATH-1-X.
            EXIT.
      /
      *-----------------
       3344-REV-DEATH-2.
      *-----------------

012134*    SET L5435-PRCES-TYP-REINST TO TRUE.
012134*    SET L5435-TRMN-TYP-DEATH   TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR WS-REDO-NOT-OK
               GO TO 3344-REV-DEATH-2-X
           END-IF.

           SET L1160-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3349-PRCES-REV-DEATH
012134*           THRU 3349-PRCES-REV-DEATH-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*           OR      WS-SEGF-SUB > +20
012134*           OR      WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*    ELSE
012134*        PERFORM  3349-PRCES-REV-DEATH
012134*            THRU 3349-PRCES-REV-DEATH-X
012134*    END-IF.
012134         PERFORM  3349-PRCES-REV-DEATH
012134             THRU 3349-PRCES-REV-DEATH-X.

           IF NOT L1160-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3344-REV-DEATH-2-X.
            EXIT.
      /
      *---------------------
       3349-PRCES-REV-DEATH.
      *---------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1160-PRCES-LEVEL-CVG     TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                      TO L1160-CVG-NUM
012134*    END-IF.
012134*
           SET L1160-PRCES-TYP-ALL TO TRUE.
016503     SET L1160-REDO-WARNING  TO TRUE.
           PERFORM  1160-2000-REINST-DEATH
               THRU 1160-2000-REINST-DEATH-X.

       3349-PRCES-REV-DEATH-X.
           EXIT.
      /
      *-------------------
020478*3350-REV-SURRENDER.
      *-------------------

020478*    PERFORM  1140-1000-BUILD-PARM-INFO
020478*        THRU 1140-1000-BUILD-PARM-INFO-X.
020478*    IF  MIR-SUPRES-CNFRM-IND = 'Y'
020478*        SET L1140-SUPPRESS-CONFIRM TO TRUE
020478*    END-IF.
020478*
020478*    MOVE E0691-COV-NO          TO L1140-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1140-CHEQUE-IND.
020478*    MOVE E0691-PAYO-MTHD-CD    TO L1140-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1140-CLI-SUR-NM-1-4.
020478*    MOVE E0691-EFF-DATE        TO L1140-EFF-DT.
020478*
020478*    IF PROCESSING-POLICY
020478*        SET L1140-PRCES-LEVEL-POLICY  TO TRUE
020478*    ELSE
020478*        SET L1140-PRCES-LEVEL-CVG     TO TRUE
020478*    END-IF.
020478*
020478*    EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
020478*        WHEN MIR-DV-PRCES-STATE-CD = '2'
020478*            PERFORM  3352-REV-SURR-1
020478*                THRU 3352-REV-SURR-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
020478*        WHEN MIR-DV-PRCES-STATE-CD = '3'
020478*            PERFORM  3354-REV-SURR-2
020478*                THRU 3354-REV-SURR-2-X
020478*
020478*        WHEN OTHER
020478*            CONTINUE
020478*
020478*    END-EVALUATE.
020478*
020478*3350-REV-SURRENDER-X.
020478*    EXIT.
      /
      *----------------
020478*3352-REV-SURR-1.
      *----------------

020478*    SET L1140-PRCES-TYP-EDIT-ONLY TO TRUE.
020478*    SET L1140-REDO-WARNING        TO TRUE.
020478*
020478*    PERFORM  1140-2000-REINST-SURRENDER
020478*        THRU 1140-2000-REINST-SURRENDER-X
020478*    IF L1140-RETRN-OK
020478*        CONTINUE
020478*    ELSE
020478*        SET WGLOB-RETURN-ERROR TO TRUE
020478*        GO TO 3352-REV-SURR-1-X
020478*    END-IF.
020478*
020478*    IF PROCESSING-POLICY
020478*        MOVE 'CS06912225'      TO WGLOB-MSG-REF-INFO
020478*    ELSE
020478*        MOVE 'CS06912226'      TO WGLOB-MSG-REF-INFO
020478*    END-IF.
020478*
020478*    PERFORM  2200-VERIFY-TRAN
020478*        THRU 2200-VERIFY-TRAN-X.
020478*
020478*3352-REV-SURR-1-X.
020478*    EXIT.
      /
      *----------------
020478*3354-REV-SURR-2.
      *----------------

012134*    SET L5435-PRCES-TYP-REINST   TO TRUE.
012134*    SET L5435-TRMN-TYP-SURRENDER TO TRUE.
012134*
020478*    PERFORM  4000-PROCESS-START
020478*        THRU 4000-PROCESS-START-X.
020478*    IF NOT WGLOB-GOOD-RETURN
020478*    OR WS-REDO-NOT-OK
020478*        GO TO 3354-REV-SURR-2-X
020478*    END-IF.

020478*    SET L1140-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3359-PRCES-REV-SURR
012134*           THRU 3359-PRCES-REV-SURR-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*           OR      WS-SEGF-SUB > +20
012134*           OR      WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*    ELSE
012134*        PERFORM  3359-PRCES-REV-SURR
012134*            THRU 3359-PRCES-REV-SURR-X
012134*    END-IF.
020478*        PERFORM  3359-PRCES-REV-SURR
020478*            THRU 3359-PRCES-REV-SURR-X.
020478*
020478*    IF NOT L1140-RETRN-OK
020478*        SET WGLOB-RETURN-ERROR     TO TRUE
020478*    END-IF.
020478*
020478*    PERFORM  4500-END-PROCESS
020478*        THRU 4500-END-PROCESS-X.
020478*
020478*3354-REV-SURR-2-X.
020478*    EXIT.
      /
      *--------------------
020478*3359-PRCES-REV-SURR.
      *--------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1140-PRCES-LEVEL-CVG       TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                        TO L1140-CVG-NUM
012134*    END-IF.
012134*
020478*    SET L1140-PRCES-TYP-ALL TO TRUE.
020478*    SET L1140-REDO-WARNING  TO TRUE.
020478*    PERFORM  1140-2000-REINST-SURRENDER
020478*        THRU 1140-2000-REINST-SURRENDER-X.
020478*
020478*3359-PRCES-REV-SURR-X.
020478*    EXIT.
      /
      *-----------------
       3360-REV-MAT-EXP.
      *-----------------

           PERFORM  1130-1000-BUILD-PARM-INFO
               THRU 1130-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1130-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1130-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1130-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1130-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1130-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1130-EFF-DT.
012134     MOVE E0691-DEATH-CODE      TO L1130-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1130-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1130-LTAXWH-CALC-CD.
013693     SET  L1130-LTAXWH-DISB-NONP TO TRUE.


           IF PROCESSING-POLICY
               SET L1130-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1130-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3362-REV-MAT-EXP-1
                       THRU 3362-REV-MAT-EXP-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3364-REV-MAT-EXP-2
                       THRU 3364-REV-MAT-EXP-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

       3360-REV-MAT-EXP-X.
           EXIT.
      /
      *-------------------
       3362-REV-MAT-EXP-1.
      *-------------------

           SET L1130-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1130-REDO-WARNING        TO TRUE.

           PERFORM  1130-2000-REINST-MAT-EXP
               THRU 1130-2000-REINST-MAT-EXP-X
           IF L1130-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3362-REV-MAT-EXP-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912227'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912228'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3362-REV-MAT-EXP-1-X.
           EXIT.
      /
      *-------------------
       3364-REV-MAT-EXP-2.
      *-------------------

012134*    SET L5435-PRCES-TYP-REINST TO TRUE.
012134*    SET L5435-TRMN-TYP-MAT-EXP TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR WS-REDO-NOT-OK
               GO TO 3364-REV-MAT-EXP-2-X
           END-IF.

           SET L1130-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3369-PRCES-REV-MAT-EXP
012134*           THRU 3369-PRCES-REV-MAT-EXP-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*           OR      WS-SEGF-SUB > +20
012134*           OR      WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*    ELSE
012134*        PERFORM  3369-PRCES-REV-MAT-EXP
012134*            THRU 3369-PRCES-REV-MAT-EXP-X
012134*    END-IF.
012134         PERFORM  3369-PRCES-REV-MAT-EXP
012134             THRU 3369-PRCES-REV-MAT-EXP-X.
           IF NOT L1130-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3364-REV-MAT-EXP-2-X.
           EXIT.
      /
      *-----------------------
       3369-PRCES-REV-MAT-EXP.
      *-----------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1130-PRCES-LEVEL-CVG       TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                        TO L1130-CVG-NUM
012134*    END-IF.
012134*
           SET L1130-PRCES-TYP-ALL TO TRUE.
016503     SET L1130-REDO-WARNING  TO TRUE.
           PERFORM  1130-2000-REINST-MAT-EXP
               THRU 1130-2000-REINST-MAT-EXP-X.

       3369-PRCES-REV-MAT-EXP-X.
           EXIT.
      /
      *---------------------
       3370-REV-REPLACEMENT.
      *---------------------

           PERFORM  1180-1000-BUILD-PARM-INFO
               THRU 1180-1000-BUILD-PARM-INFO-X.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1180-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

           MOVE E0691-COV-NO          TO L1180-CVG-NUM.
018731*    MOVE E0691-CHEQUE-IND      TO L1180-CHEQUE-IND.
018731     MOVE E0691-PAYO-MTHD-CD    TO L1180-PAYO-MTHD-CD.
012624*    MOVE E0691-OWNER-NAME      TO L1180-CLI-SUR-NM-1-4.
           MOVE E0691-EFF-DATE        TO L1180-EFF-DT.
012134     MOVE E0691-DEATH-CODE      TO L1180-SURR-FOR-TRANSFER-CD.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L1180-TAX-BYPASS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L1180-LTAXWH-CALC-CD.
013693     SET  L1180-LTAXWH-DISB-NONP TO TRUE.

           IF PROCESSING-POLICY
               SET L1180-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1180-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3372-REV-REPLACE-1
                       THRU 3372-REV-REPLACE-1-X

013578*        WHEN MIR-DV-PRCES-STATE-CD = '2'
013578         WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3374-REV-REPLACE-2
                       THRU 3374-REV-REPLACE-2-X

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

       3370-REV-REPLACEMENT-X.
           EXIT.
      /
      *-------------------
       3372-REV-REPLACE-1.
      *-------------------

           SET L1180-PRCES-TYP-EDIT-ONLY TO TRUE.
016503     SET L1180-REDO-WARNING        TO TRUE.

           PERFORM  1180-2000-REINST-REPL
               THRU 1180-2000-REINST-REPL-X
           IF L1180-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3372-REV-REPLACE-1-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS06912234'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS06912235'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  2200-VERIFY-TRAN
               THRU 2200-VERIFY-TRAN-X.

       3372-REV-REPLACE-1-X.
           EXIT.
      /
      *-------------------
       3374-REV-REPLACE-2.
      *-------------------

012134*    SET L5435-PRCES-TYP-REINST     TO TRUE.
012134*    SET L5435-TRMN-TYP-REPLACEMENT TO TRUE.
012134*
           PERFORM  4000-PROCESS-START
               THRU 4000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
016503     OR WS-REDO-NOT-OK
               GO TO 3374-REV-REPLACE-2-X
           END-IF.

           SET L1180-PRCES-TYP-ALL TO TRUE.

012134*    IF WS-SEGFUND-ERROR
012134*        PERFORM 3379-PRCES-REV-REPLACE
012134*           THRU 3379-PRCES-REV-REPLACE-X
012134*           VARYING WS-SEGF-SUB FROM +1 BY +1
012134*           UNTIL   WS-SEGF-SUB > +20
012134*           UNTIL   WS-SEGF-SUB > WCVGM-MAX-WCVGS-NUM
012134*           OR      WS-CVG-TO-PROCESS (WS-SEGF-SUB) = ZERO
012134*    ELSE
012134*        PERFORM  3379-PRCES-REV-REPLACE
012134*            THRU 3379-PRCES-REV-REPLACE-X
012134*    END-IF.
012134         PERFORM  3379-PRCES-REV-REPLACE
012134             THRU 3379-PRCES-REV-REPLACE-X.

           IF NOT L1180-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  4500-END-PROCESS
               THRU 4500-END-PROCESS-X.

       3374-REV-REPLACE-2-X.
           EXIT.
      /
      *-----------------------
       3379-PRCES-REV-REPLACE.
      *-----------------------

012134*    IF WS-SEGFUND-ERROR
012134*        SET L1180-PRCES-LEVEL-CVG       TO TRUE
012134*        MOVE WS-CVG-TO-PROCESS (WS-SEGF-SUB)
012134*                                        TO L1180-CVG-NUM
012134*    END-IF.
012134*
           SET L1180-PRCES-TYP-ALL TO TRUE.
016503     SET L1180-REDO-WARNING  TO TRUE.
           PERFORM  1180-2000-REINST-REPL
               THRU 1180-2000-REINST-REPL-X.

       3379-PRCES-REV-REPLACE-X.
           EXIT.
      /
      *-------------------
       4000-PROCESS-START.
      *-------------------

016158     SET  WS-FREE-LOOK-CHECK-NO   TO TRUE.

012136     IF  (WS-BUS-FCN-TNOTKN
012136     OR   WS-BUS-FCN-RNOTKN)
012136     AND PROCESSING-POLICY
012136     AND NOT E0691-PREM-REVRS-NSF
012136         PERFORM  4020-CHECK-FREE-LOOK
012136             THRU 4020-CHECK-FREE-LOOK-X
012136         IF  WGLOB-RETURN-ERROR
016158*        OR  DEFERRED-TRANS
012136             GO TO 4000-PROCESS-START-X
012136         END-IF
012136     END-IF.
012136

016503*  INVOKE REDO PROCESSING

016503     SET WS-REDO-OK           TO  TRUE.

016503     IF  NOT WS-BUS-FCN-REVERSAL
016503        IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
016503        AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503           CONTINUE
016503        ELSE
016503           PERFORM  2400-INVOKE-REDO
016503               THRU 2400-INVOKE-REDO-X
016503        END-IF
016503     END-IF.

016503     IF WS-REDO-NOT-OK
016503        GO TO 4000-PROCESS-START-X
016503     END-IF.

016158     IF WS-BUS-FCN-TERM
016158     AND NOT-DEFERRED-TRANS
016158     AND WS-FREE-LOOK-CHECK-NO
016158         PERFORM  4100-CHECK-FOR-DEFER
016158             THRU 4100-CHECK-FOR-DEFER-X
016158     END-IF.
016158
016158     IF NOT WGLOB-GOOD-RETURN
016158        GO TO 4000-PROCESS-START-X
016158     END-IF.

016158     IF  DEFERRED-TRANS
016158     AND WS-BUS-FCN-TNOTKN
018763     AND WS-FREE-LOOK-CHECK-YES
016158         CONTINUE
016158     ELSE
               PERFORM  2500-UNDO-PROCESS
                   THRU 2500-UNDO-PROCESS-X
016158     END-IF.

           IF NOT WGLOB-GOOD-RETURN
               GO TO 4000-PROCESS-START-X
           END-IF.


016158     IF DEFERRED-TRANS
016158        SET UPDATE-REQUIRED     TO TRUE
016158        GO TO 4000-PROCESS-START-X
016158     END-IF.

012134*    MOVE E0691-EFF-DATE       TO L5435-EFF-DT.
012134*    MOVE E0691-CHEQUE-IND     TO L5435-CHEQUE-IND.
012134*    MOVE E0691-DEATH-CODE     TO L5435-SURR-FOR-TRANSFER-CD.
012134*    MOVE E0691-TAX-BYPASS-SW  TO L5435-BYPASS-TAX-IND.

           INITIALIZE WS-CVG-LIST.
012134*    SET  WS-NO-SEGFUND-ERROR  TO TRUE.

           IF  PROCESSING-COVERAGE
012134*    AND NOT WCVGS-CVG-INS-TYP-SEG-FUND (E0691-COV-NO)
               MOVE E0691-COV-NO      TO WS-CVG-TO-PROCESS (+1)
012134*        GO TO 4000-PROCESS-START-X
           END-IF.

029060     IF  WS-BUS-FCN-REVERSAL
029060         MOVE WS-REVRS-PCHST-SEQ-NUM
029060                                TO WGLOB-REVRS-PCHST-SEQ-NUM
029060     END-IF.
029060
012134*    IF  PROCESSING-POLICY
012134*        SET WS-NO-SEGFUNDS TO TRUE
012134*        PERFORM  4010-CHECK-FOR-SEGFUNDS
012134*            THRU 4010-CHECK-FOR-SEGFUNDS-X
012134*            VARYING WS-SEGF-SUB FROM +1 BY +1
012134*            UNTIL WS-SEGFUNDS
012134*            OR    WS-SEGF-SUB > RPOL-POL-CVG-REC-CTR-N
012134*        IF WS-NO-SEGFUNDS
012134*            GO TO 4000-PROCESS-START-X
012134*        END-IF
012134*    END-IF.
012134*
012134*    IF  PROCESSING-COVERAGE
012134*        MOVE E0691-COV-NO     TO L5435-CVG-NUM
012134*        PERFORM  5435-2000-SF-CVG-TRMN
012134*            THRU 5435-2000-SF-CVG-TRMN-X
012134*    ELSE
012134*        PERFORM  5435-1000-SF-POL-TRMN
012134*            THRU 5435-1000-SF-POL-TRMN-X
012134*    END-IF.
012134*
012134*    IF  L5435-RETRN-ERROR
012134*        SET WS-SEGFUND-ERROR TO TRUE
012134*    END-IF.
012134*
012134*    PERFORM
012134*        VARYING WS-SEGF-SUB FROM +1 BY +1
012134*        UNTIL   WS-SEGF-SUB > RPOL-POL-CVG-REC-CTR-N
012134*        OR   L5435-SUCCESSFUL-CVG-NUM (WS-SEGF-SUB) = ZEROES
012134*        MOVE L5435-SUCCESSFUL-CVG-NUM (WS-SEGF-SUB)
012134*                TO WS-CVG-TO-PROCESS  (WS-SEGF-SUB)
012134*    END-PERFORM.
012134*
012134*    MOVE L5435-PAYOUT-AMOUNT  TO WS-PAYOUT-AMOUNT.
012134*
       4000-PROCESS-START-X.
           EXIT.
      /
012134*-----------------
012134*4010-CHECK-FOR-SEGFUNDS.
012134*-----------------
012134*
012134*    IF  WCVGS-CVG-INS-TYP-SEG-FUND (WS-SEGF-SUB)
012134*        SET WS-SEGFUNDS TO TRUE
012134*        GO  TO 4010-CHECK-FOR-SEGFUNDS-X
012134*    END-IF.
012134*
012134*4010-CHECK-FOR-SEGFUNDS-X.
012134*    EXIT.
      /
012136*---------------------
012136 4020-CHECK-FREE-LOOK.
012136*---------------------
012136
012136     MOVE +0                    TO I.
012136     PERFORM  PLIN-1000-PLAN-HEADER-IN
012136         THRU PLIN-1000-PLAN-HEADER-IN-X.
012136     IF  WPH-IO-OK
012136         IF  RPH-FREE-LK-PRCES
012136             SET WS-FREE-LOOK-NTU-PRCES TO TRUE
012136             PERFORM  4021-PRCES-RFND-GUAR
012136                 THRU 4021-PRCES-RFND-GUAR-X
012136             SET WS-FREE-LOOK-NTU-PRCES-NO TO TRUE
012136         END-IF
012136     ELSE
012136             SET WGLOB-RETURN-ERROR TO TRUE
012136     END-IF.
012136
012136 4020-CHECK-FREE-LOOK-X.
012136     EXIT.
012136/
012136*---------------------
012136 4021-PRCES-RFND-GUAR.
012136*---------------------
012136
012136     IF  WS-BUS-FCN-TNOTKN
012136     AND E0691-EFF-DATE < WGLOB-PROCESS-DATE
012136         PERFORM  2500-UNDO-PROCESS
012136             THRU 2500-UNDO-PROCESS-X
012136         IF  NOT WGLOB-GOOD-RETURN
012136             GO TO 4021-PRCES-RFND-GUAR-X
012136         END-IF
012136     END-IF.
012136
012136     PERFORM  8250-1000-BUILD-PARM-INFO
012136         THRU 8250-1000-BUILD-PARM-INFO-X.
012136     SET L8250-PRCES-ONLINE         TO TRUE.
012136     MOVE E0691-EFF-DATE        TO L8250-EFF-DT.
018731*    IF  E0691-CHEQUE-REQ
018731*        SET L8250-CDI-PAYO-CHQ     TO TRUE
018731*    ELSE
018731*        SET L8250-CDI-PAYO-OS-DISB TO TRUE
018731*    END-IF.

018731     EVALUATE TRUE
018731         WHEN E0691-PAYO-MTHD-CHQ
018731            SET L8250-CDI-PAYO-CHQ     TO TRUE
018731         WHEN E0691-PAYO-MTHD-EFT
018731            SET L8250-CDI-PAYO-EFT     TO TRUE
018731         WHEN OTHER
018731            SET L8250-CDI-PAYO-OS-DISB TO TRUE
018731     END-EVALUATE.
018731     MOVE MIR-CLI-ID            TO L8250-CLI-ID.
018731     MOVE MIR-CLI-BNK-ACCT-NUM  TO L8250-CLI-BNK-ACCT-NUM.

012136     MOVE MIR-SUPRES-CNFRM-IND  TO L8250-SUPR-CONF-IND.
023437*    MOVE E0691-TAX-BYPASS-SW   TO L8250-TAX-BPSS-IND.
029060*    MOVE E0691-LTAXWH-CALC-CD  TO L8250-LTAXWH-CALC-CD.
012136
012136     IF  WS-BUS-FCN-TNOTKN
012136         PERFORM  8250-1000-PRCES-RFND-GUAR
012136             THRU 8250-1000-PRCES-RFND-GUAR-X
012136     ELSE
012136         PERFORM  8250-2000-REIN-RFND-GUAR
012136             THRU 8250-2000-REIN-RFND-GUAR-X
012136     END-IF.
012136
012136     IF  NOT L8250-RETRN-OK
012136         SET WGLOB-RETURN-ERROR TO TRUE
012136     END-IF.
012136
013578     IF  L8250-FNDVL-CALC-APROX
013578         SET DEFERRED-TRANS TO TRUE
013578     END-IF.
013578
016158     SET WS-FREE-LOOK-CHECK-YES  TO TRUE.
016158
012136 4021-PRCES-RFND-GUAR-X.
012136     EXIT.
012136/
016158*---------------------
016158 4100-CHECK-FOR-DEFER.
016158*---------------------
016158*
016158* CHECK FOR UNIT PRICES & DEFER IF NOT FOUND
016158*
016158     PERFORM  0182-1000-BUILD-PARM-INFO
016158         THRU 0182-1000-BUILD-PARM-INFO-X.
016158
016158     MOVE E0691-EFF-DATE               TO L0182-EFF-DT.
016158     SET L0182-CALC-RESERVE            TO TRUE.
016158
016158     IF WS-BUS-FCN-TNORMAL
020478*    OR WS-BUS-FCN-TSURR
016158     OR WS-BUS-FCN-TCNVR
016158     OR WS-BUS-FCN-TDEATH
016158     OR WS-BUS-FCN-TLAPSWV
016158     OR WS-BUS-FCN-TREPL
016158         MOVE 'N' TO L0182-TRMNL-DIV-CALC-IND
016158         IF PROCESSING-COVERAGE
016158         AND RPOL-POL-CVG-REC-CTR-N > +1
016158             SET L0182-TRMNL-BON-CALC-LVL-CVG TO TRUE
016158         END-IF
016158     END-IF.
016158
016158     IF WS-BUS-FCN-TNORMAL
016158     OR WS-BUS-FCN-TDEATH
016158         SET L0182-CALC-SUM-INS TO TRUE
016158     END-IF.
016158
020478*    IF WS-BUS-FCN-TSURR
020478*        SET L0182-CALC-IF-TERMINATED TO TRUE
020478*    END-IF.
016158
016158     IF WS-BUS-FCN-TDEATH
016158         SET L0182-INTRM-DTH-CALC TO TRUE
016158     END-IF.
016158
016158     PERFORM  0182-1000-CALC-CSV-POL
016158         THRU 0182-1000-CALC-CSV-POL-X.
016158
016158     IF      L0182-RETRN-OK
016158     AND NOT L0182-FNDVL-CALC-APROX
016158         CONTINUE
016158     ELSE
016158         IF  L0182-RETRN-OK
016158         AND L0182-FNDVL-CALC-APROX
016158             PERFORM  4110-GENERATE-DEFERRED-TERM
016158                 THRU 4110-GENERATE-DEFERRED-TERM-X
016158* MSG: TERMINATION HAS BEEN DEFERRED
016158             MOVE 'CS06910004' TO WGLOB-MSG-REF-INFO
016158             PERFORM  0260-1000-GENERATE-MESSAGE
016158                 THRU 0260-1000-GENERATE-MESSAGE-X
016158         END-IF
016158         SET DEFERRED-TRANS        TO TRUE
016158     END-IF.
016158
016158 4100-CHECK-FOR-DEFER-X.
016158     EXIT.
016158/
016158 4110-GENERATE-DEFERRED-TERM.
016158
016158     PERFORM  8170-1000-BUILD-PARM-INFO
016158         THRU 8170-1000-BUILD-PARM-INFO-X.
016158
016158     MOVE E0691-EFF-DATE           TO L8170-EFF-DT.
016158     MOVE MIR-SUPRES-CNFRM-IND     TO L8170-SUPR-CONF-IND.
016158     MOVE E0691-SURR-TAX-OVRID-CD  TO L8170-SURR-TAX-OVRID-CD
016158     MOVE E0691-COV-X              TO L8170-CVG-NUM
016158     MOVE E0691-DEATH-CODE         TO L8170-DTH-REASN-CD
016158     MOVE E0691-NTU-RFND-DEST-CD   TO L8170-NTU-RFND-DEST-CD
023437*    MOVE E0691-TAX-BYPASS-SW      TO L8170-TAX-BPSS-IND.
018731     MOVE E0691-CLI-ID             TO L8170-CLI-ID
018731     MOVE E0691-CLI-BNK-ACCT-NUM   TO L8170-CLI-BNK-ACCT-NUM
029060*    MOVE E0691-LTAXWH-CALC-CD     TO L8170-LTAXWH-CALC-CD.
023393
016158     EVALUATE TRUE
016158
016158         WHEN E0691-PAYO-MTHD-CHQ
016158             SET L8170-CDI-PAYO-CHQ TO TRUE
016158
016158         WHEN E0691-PAYO-MTHD-EFT
016158             SET L8170-CDI-PAYO-EFT TO TRUE
016158
016158         WHEN OTHER
016158             SET L8170-CDI-PAYO-OS-DISB TO TRUE
016158
016158     END-EVALUATE.
016158
016158     INITIALIZE LFUND-FND-INFO (1).
016158     MOVE +1                       TO LFUND-FND-CTR.
016158     MOVE -100.00                  TO LFUND-ALLOC-PCT (1).
016158     SET LFUND-ALLOC-PERCENT (1)  TO TRUE.
016158
016158     EVALUATE TRUE
016158
016158         WHEN WS-BUS-FCN-TNOTKN
016158             SET LFUND-ACTV-NOT-TAKEN-UP     TO TRUE
016158
016158         WHEN WS-BUS-FCN-TLAPS
016158             SET LFUND-ACTV-LAPSE-TERM       TO TRUE
016158
016158         WHEN WS-BUS-FCN-TNORMAL
016158             SET LFUND-ACTV-NORMAL-TERMINATION TO TRUE
016158
020478*        WHEN WS-BUS-FCN-TSURR
020478*            SET LFUND-ACTV-SURRENDER-TERM   TO TRUE
016158
016158         WHEN WS-BUS-FCN-TCNVR
016158             SET LFUND-ACTV-CONVERSION-TERM  TO TRUE
016158
016158         WHEN WS-BUS-FCN-TDEATH
016158             SET LFUND-ACTV-DEATH-TERM       TO TRUE
016158
016158         WHEN WS-BUS-FCN-TLAPSWV
016158             SET LFUND-ACTV-LAPSE-VALUE-TERM TO TRUE
016158
016158         WHEN WS-BUS-FCN-TREPL
016158             SET LFUND-ACTV-REPLACE-TERM     TO TRUE
016158
016158     END-EVALUATE.
016158
016158     PERFORM  8170-2000-DEFER-TRANSACTION
016158         THRU 8170-2000-DEFER-TRANSACTION-X.
016158
016158     IF NOT L8170-RETRN-OK
016158         SET WGLOB-RETURN-ERROR        TO TRUE
020478     ELSE
020478*MSG: TRANSACTION HAS BEEN DEFERRED
020478         MOVE 'CS00000260'             TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
016158     END-IF.
016158
016158 4110-GENERATE-DEFERRED-TERM-X.
016158     EXIT.
016158/
      *-----------------
       4500-END-PROCESS.
      *-----------------

           IF  WGLOB-GOOD-RETURN
           AND PROCESSING-COVERAGE

012696*MSG: POLICY ALLOCATIONS FOR THIS COVERAGE SHOULD BE CHECKED.
012696         MOVE 'CS06914302'      TO WGLOB-MSG-REF-INFO
012696         PERFORM 0260-1000-GENERATE-MESSAGE
012696            THRU 0260-1000-GENERATE-MESSAGE-X
012696*        IF  RPOL-POL-INS-TYP-FLEXIBLE
012696*        AND WCVGS-IN-ALLOC-AMT-PCT (E0691-COV-NO) > ZERO
012696*        AND WCVGS-CVG-IN-ALLOC-CD  (E0691-COV-NO) = 'P'
012696*MSG:        ADJUST PERCENTAGES TO TOTAL 100%
012696*            MOVE 'CS06914007'          TO WGLOB-MSG-REF-INFO
012696*            PERFORM  0260-1000-GENERATE-MESSAGE
012696*                THRU 0260-1000-GENERATE-MESSAGE-X
012696*        END-IF

           END-IF.
      *
012134*    IF WS-SEGFUND-ERROR
012134*
012134*        IF E0691-TERMINATING
012134*MSG: POLICY NOT TERMINATED..NOT ABLE TO TERM ALL SF COVERAGES
012134*            MOVE 'CS06914005' TO WGLOB-MSG-REF-INFO
012134*            PERFORM  0260-1000-GENERATE-MESSAGE
012134*                THRU 0260-1000-GENERATE-MESSAGE-X
012134*        ELSE
012134*MSG: POLICY NOT REINSTATED..NOT ABLE TO REINST ALL SF COVERAGES
012134*            MOVE 'CS06914006' TO WGLOB-MSG-REF-INFO
012134*            PERFORM  0260-1000-GENERATE-MESSAGE
012134*                THRU 0260-1000-GENERATE-MESSAGE-X
012134*        END-IF
012134*
012134*    END-IF.

           SET UPDATE-REQUIRED               TO TRUE.

       4500-END-PROCESS-X.
           EXIT.
      /
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.
            MOVE MIR-CVG-NUM          TO WGLOB-REF-COVERAGE-NUMBER.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970     PERFORM  0182-0000-INIT-PARM-INFO
025970         THRU 0182-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0316-0000-INIT-PARM-INFO
025970         THRU 0316-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1110-0000-INIT-PARM-INFO
025970         THRU 1110-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1120-0000-INIT-PARM-INFO
025970         THRU 1120-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1130-0000-INIT-PARM-INFO
025970         THRU 1130-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1140-0000-INIT-PARM-INFO
025970         THRU 1140-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1150-0000-INIT-PARM-INFO
025970         THRU 1150-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1160-0000-INIT-PARM-INFO
025970         THRU 1160-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1170-0000-INIT-PARM-INFO
025970         THRU 1170-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1180-0000-INIT-PARM-INFO
025970         THRU 1180-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
031037     PERFORM  1660-0000-INIT-PARM-INFO
031037         THRU 1660-0000-INIT-PARM-INFO-X.
031037
032623     PERFORM  2408-0000-INIT-PARM-INFO
032623         THRU 2408-0000-INIT-PARM-INFO-X.
032623
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4382-0000-INIT-PARM-INFO
025970         THRU 4382-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8170-0000-INIT-PARM-INFO
025970         THRU 8170-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8250-0000-INIT-PARM-INFO
025970         THRU 8250-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  TAXC-0000-INIT-PARM-INFO
025970         THRU TAXC-0000-INIT-PARM-INFO-X.
025970
032896**   PERFORM  TAXW-0000-INIT-PARM-INFO
032896**       THRU TAXW-0000-INIT-PARM-INFO-X.
025970
023514     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970     MOVE SPACES TO HOLD-FIELDS-FOR-691.
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK           TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *************************
      * PROCESSING COPYBOOKS
      *************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
012136 COPY CCPPPLIN.
       COPY NCPPCVGS.
       COPY NCPPCVGR.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      ************************
      * LINKAGE COPYBOOKS
      ************************
025970 COPY XCPS8090.
032896*COPY CCPSTAXW.
       COPY CCPSPGA.
      /
018764*COPY CCCL0182.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY CCPL0182.
016158 COPY CCPS0182.
      /
025970 COPY CCPS0620.
013578 COPY CCPL0620.

018764*COPY CCCL0201.
025970 COPY CCPS0201.
018764 COPY CCPL0201.

016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.

018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108 COPY CCPS0985.

018764*COPY CCCL1110.
018764 COPY CCPL1110.
       COPY CCPS1110.

018764*COPY CCCL1120.
018764 COPY CCPL1120.
       COPY CCPS1120.

018764*COPY CCCL1130.
018764 COPY CCPL1130.
       COPY CCPS1130.

018764*COPY CCCL1140.
018764 COPY CCPL1140.
       COPY CCPS1140.

018764*COPY CCCL1150.
018764 COPY CCPL1150.
       COPY CCPS1150.

018764*COPY CCCL1160.
018764 COPY CCPL1160.
       COPY CCPS1160.

018764*COPY CCCL1170.
018764 COPY CCPL1170.
       COPY CCPS1170.

018764*COPY CCCL1180.
018764 COPY CCPL1180.
       COPY CCPS1180.
      /
032623 COPY CCPL2408.
032623 COPY CCPS2408.
032623/
018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS2430.
020463/
020463 COPY CCPS2735.
020463 COPY CCPL2735.
      /
018764*COPY CCCL4382.
018764 COPY CCPL4382.
018731 COPY CCPS4382.
018731/
       COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.
      /
016503 COPY CCPS4780.
018764*COPY CCCL4780.
018764 COPY CCPL4780.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
016158 COPY FCPS8170.
018764*COPY FCCL8170.
018764 COPY FCPL8170.
      /
012136 COPY FCPS8250.
018764*COPY FCCL8250.
018764 COPY FCPL8250.
012136/
012134*COPY SCPS5435.
012134*COPY SCCL5435.
012134*
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
014035*COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
031037
031037 COPY XCPS1660.
031037 COPY XCPL1660.

018844 COPY XCPL0290.
018844 COPY XCPS0290.
      /
023437 COPY XCPS0316.
023437 COPY XCPL0316.
023437
023437 COPY CCPSTAXC.
023437 COPY CCPLTAXC.
023437
      ****************************
      * FILE I/O PROCESS MODULES
      ****************************
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
012136 COPY CCPNPH.
012136/
031037 COPY CCPBPHST.
031037/
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
012624*COPY XCPPMEXT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM0691                     **
      *****************************************************************
