      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3010.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3010                                         **
      **  REMARKS:  PROCESS DRIVER FOR LCGP TRANSACTION              **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010302**  5.6       INITIAL CREATION                                 **
012135**  5.6V      ADD AVT VALUES FOR STATE FUND APPROVAL           **
012136**  5.6V      ADD AVT VALUES FOR FREE LOOK PROCESSING          **
012139**  5.6V      SUPPORT REFUND OF EXCESS SALES LOAD (I.E         **
012139**            ADD 'FLDT ', 'PLDT ', 'SLDT ' VALUES             **
012139**            TO WS-PLAN-RATE-TYPE )                           **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
013585**  5.6A      CONTRACTUAL PAYOUTS                              **
013924**  5.6A      ANNUAL BONUS                                     **
013930**  5.6A      TERMINAL BONUS                                   **
013994**  5.6A      BONUS AND DIVIDEND VESTING                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
013693**  6.2       LOCATION TAX                                     **
014221**  6.2       LOGICAL RECORD LOCKING                           **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
015919**  6.2       TAMARA                                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
015951**  6.3       DISABILITY RIDERS ON TRAD POLICIES (6.1.1E)      **
016016**  6.3       FUND BONUS (6.1.1E)                              **
016109**  6.3       FREE FUND TRANSFERS (6.1.2J)                     **
016307**  6.3       ADMIN CHARGES AS A PERCENT OF FUND VALUE (6.1.1E)**
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018844**  6.3       REPLACEMENT PROCESSING FOR U.S. POLICIES         **
018905**  6.3       DURATION BASED MATURITY/EXPIRY AGE AND TERM      **
019142**  6.3       RECORD MATURITY OPTIONS (6.1.2J)                 **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020477**  6.4       MINIMUM DISTRIBUTION RULES                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      *
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3010'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       COPY XCWLDTLK.

       COPY XCWL1640.

       COPY XCWL1660.

016537*COPY CCWL0620.

      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *

       01  WS-WORKING-STORAGE.
           05  HOLD-LAST-LGAS-KEY           PIC X(22).
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 WS-SUB-DEFAULT              VALUE ZERO.
           05  WS-COUNT-KLON-RECS           PIC S9(4)  VALUE ZERO.
025970         88 WS-COUNT-KLON-RECS-DEFAULT           VALUE ZERO.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 I-DEFAULT                   VALUE ZERO.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
016548     05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
016548                                      BINARY.
025970         88 WS-MAX-BROWSE-LINES-DEFAULT          VALUE +12.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-VALID                    VALUES ARE
                   '0780', '0781', '0782', '0783', '0784' '0785'.
               88  WS-BUS-FCN-RETRIEVE                 VALUE '0780'.
               88  WS-BUS-FCN-CREATE                   VALUE '0781'.
               88  WS-BUS-FCN-UPDATE                   VALUE '0782'.
               88  WS-BUS-FCN-DELETE                   VALUE '0783'.
               88  WS-BUS-FCN-LIST                     VALUE '0784'.
               88  WS-BUS-FCN-CLONE                    VALUE '0785'.
014221     05  WS-TWRK-KEY                  PIC X(04)  VALUE '0780'.
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '0780'.
020477*    05  WS-GROUP-PROCESS-TYPE        PIC X(05).
020477*        88  WS-VALID-GROUP-PROCESS-TYPE         VALUES
020477*            'ADAGE'
020477*            'ADMEX'
020477*            'ADMFE'
020477*            'ADMWV'
020477*            'AGAMT'
020477*            'ANBDV'
020477*            'ANBNP'
020477*            'ANBNR'
020477*            'ANNIV'
020477*            'ANUNT'
020477*            'APFRM'
020477*            'ASMBY'
020477*            'BILNO'
020477*            'BTMOD'
020477*            'CLCHG'
020477*            'COINS'
020477*            'COLAR'
020477*            'COLAU'
020477*            'COMMT'
020477*            'CPAYO'
020477*            'CVAGE'
020477*            'CVANT'
020477*            'CVANP'
020477*            'CVYRS'
020477*            'DBCOR'
020477*            'DIPCT'
020477*            'DIVOP'
020477*            'DRCOM'
020477*            'EIPAR'
020477*            'ENHAN'
020477*            'EQAGE'
020477*            'EREPL'
020477*            'EXAGE'
020477*            'EXYRS'
020477*            'FARED'
020477*            'FCOMM'
020477*            'FDOPT'
020477*            'FLDT '
020477*            'FLREG'
020477*            'FLSTD'
020477*            'FPFMT'
020477*            'FPWOR'
020477*            'FREET'
020477*            'FREEW'
020477*            'GCOIN'
020477*            'GUARD'
020477*            'GUIDA'
020477*            'GUIDS'
020477*            'GVART'
020477*            'INCOM'
020477*            'INTBN'
020477*            'ISCHG'
020477*            'ISSRQ'
020477*            'LIFXP'
020477*            'LINTC'
020477*            'LTXEX'
020477*            'LTXWH'
020477*            'LTXWR'
020477*            'MCVIR'
020477*            'MCVLD'
020477*            'MIAGE'
020477*            'MIAMT'
020477*            'MNINT'
020477*            'MNPYT'
020477*            'MNRIF'
020477*            'MTAGE'
020477*            'MTYRS'
020477*            'MXADB'
020477*            'MXLIF'
020477*            'MXLIR'
020477*            'NFONT'
020477*            'NFOPT'
020477*            'PAKIT'
020477*            'PAYLD'
020477*            'PAYN '
020477*            'PLDT '
020477*            'PMTLD'
020477*            'PREMS'
020477*            'PREMU'
020477*            'PRMCH'
020477*            'PSURC'
020477*            'PSURT'
020477*            'PVARI'
020477*            'QPDEP'
020477*            'REMNO'
020477*            'REPLC'
020477*            'REPLE'
020477*            'REPLI'
020477*            'SCIIR'
020477*            'SECGP'
020477*            'SLDT '
020477*            'SURRC'
020477*            'SURRT'
020477*            'TAMRA'
020477*            'TAXWH'
020477*            'TBBDT'
020477*            'TBDDT'
020477*            'TBBMT'
020477*            'TBDMT'
020477*            'TBBSR'
020477*            'TBDSR'
020477*            'TXCOI'
020477*            'VARQU'
020477*            'VCOMT'
020477*            'VSTBN'
020477*            'VSTDV'
020477*            'DEP  '
020477*            'DRV  '
020477*            'ADM  '
020477*            'ARV  '
020477*            'BON  '
020477*            'BRV  '
020477*            'INP  '
020477*            'IRV  '
020477*            'SUR  '
020477*            'SRV  '
020477*            'LON  '
020477*            'LNV  '
020477*            'LIN  '
020477*            'LIV  '
020477*            'LNR  '
020477*            'LRV  '
020477*            'TRI  '
020477*            'TRV  '
020477*            'DT   '
020477*            'RD   '
020477*            'LPS  '
020477*            'RLP  '
020477*            'NTK  '
020477*            'RNT  '
020477*            'PO   '
020477*            'POV  '
020477*            'MON  '
020477*            'MNV  '
020477*            'MET  '
020477*            'MEV  '
020477*            'XFERE'.
014221 COPY CCWWLOCK.
      *
      ***************************************************************
      * LOCATION GROUP WORK AREA
      ***************************************************************
       COPY CCFRLGAS.
       COPY CCFWLGAS.
      *
016537*COPY CCWL2435.
      *
016537*COPY NCWL3340.
014221 COPY XCWL8090.
020477 COPY XCWL8960.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3010.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.

      **********************
       2000-PROCESS-REQUEST.
      **********************

           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN WS-BUS-FCN-CLONE
                    PERFORM 7000-PROCESS-KLON
                       THRU 7000-PROCESS-KLON-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3010'   TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *

      *****************************************************************
      *   CHECK LGAS:
      *   ENSURE THAT THE PLAN RATE ROW EXISTS.
      *****************************************************************
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************

           MOVE SPACES                TO MIR-LOC-GR-ID.

           IF  MIR-LOC-GR-COLCT-ID = SPACES
      *MSG:    GROUP LOCATION POINTER ID IS REQUIRED
               MOVE 'CS30100001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO  TO  3000-PROCESS-RETRIEVE-X
           END-IF.

           IF  MIR-LOC-GR-TYP-CD = SPACES
      *MSG:    LOCATION GROUP PROCESS TYPE IS REQUIRED
               MOVE 'CS30100002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO  TO  3000-PROCESS-RETRIEVE-X
           END-IF.

           IF  MIR-LOC-GR-LOC-CD = SPACES
      *MSG:    LOCATION IS REQUIRED
               MOVE 'CS30100003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM 8200-INVERT-EFFECTIVE-DATE
              THRU 8200-INVERT-EFFECTIVE-DATE-X

           IF  WGLOB-MSG-ERROR-SW     >  ZERO
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           MOVE MIR-LOC-GR-COLCT-ID   TO WLGAS-LOC-GR-COLCT-ID.
           MOVE MIR-LOC-GR-TYP-CD     TO WLGAS-LOC-GR-TYP-CD.
           MOVE MIR-LOC-GR-LOC-CD     TO WLGAS-LOC-GR-LOC-CD.

           PERFORM 8100-READ-LGAS-INFO
              THRU 8100-READ-LGAS-INFO-X.

           IF  WGLOB-MSG-ERROR-SW     >  ZERO
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *******************
       3500-PROCESS-LIST.
      *******************

           MOVE SPACES         TO MIR-LOC-GR-TYP-CD-G.
           MOVE SPACES         TO MIR-LOC-GR-LOC-CD-G.
           MOVE SPACES         TO MIR-LOC-GR-EFF-IDT-NUM-G.
           MOVE SPACES         TO MIR-LOC-GR-ID-G.

           PERFORM 8000-BUILD-LGAS-BROWSE-KEY
              THRU 8000-BUILD-LGAS-BROWSE-KEY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM LGAS-1000-BROWSE
              THRU LGAS-1000-BROWSE-X

           IF NOT WLGAS-IO-OK
           OR WLGAS-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
              MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM LGAS-2000-READ-NEXT
              THRU LGAS-2000-READ-NEXT-X.

           IF NOT WLGAS-IO-OK
           OR WLGAS-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM LGAS-3000-END-BROWSE
                  THRU LGAS-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WLGAS-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  LGAS-3000-END-BROWSE
               THRU LGAS-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      *
      *********************
       4000-PROCESS-CREATE.
      *********************


           MOVE MIR-LOC-GR-COLCT-ID   TO WLGAS-LOC-GR-COLCT-ID.
           MOVE MIR-LOC-GR-TYP-CD     TO WLGAS-LOC-GR-TYP-CD.
           MOVE MIR-LOC-GR-LOC-CD     TO WLGAS-LOC-GR-LOC-CD.

           PERFORM 8200-INVERT-EFFECTIVE-DATE
              THRU 8200-INVERT-EFFECTIVE-DATE-X

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM LGAS-1000-READ
              THRU LGAS-1000-READ-X.

           IF  WLGAS-IO-OK
               MOVE WLGAS-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  LOCATION GROUP KEY EDITS.
      *
           PERFORM 8500-EDIT-LGAS-KEY-FIELDS
              THRU 8500-EDIT-LGAS-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW = ZEROS
               CONTINUE
           ELSE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  CREATE RECORD
      *
           PERFORM LGAS-1000-CREATE
              THRU LGAS-1000-CREATE-X.

           MOVE MIR-LOC-GR-EFF-IDT-NUM TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO RLGAS-LOC-GR-EFF-DT.
           PERFORM LGAS-1000-WRITE
              THRU LGAS-1000-WRITE-X.
           IF  WGLOB-AUDIT-REQUESTED
               PERFORM LGAS-1000-CALL-AUDIT
                  THRU LGAS-1000-CALL-AUDIT-X
           END-IF.

014221     PERFORM LGAS-1000-READ-TWRK-TS
014221        THRU LGAS-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      *
      *********************
       5000-PROCESS-UPDATE.
      *********************

           PERFORM  8050-BUILD-LGAS-KEY
               THRU 8050-BUILD-LGAS-KEY-X.

014221*    PERFORM LGAS-1000-READ-FOR-UPDATE
014221*       THRU LGAS-1000-READ-FOR-UPDATE-X.
014221     PERFORM LGAS-2000-UPDATE-TWRK-TS
014221        THRU LGAS-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'LGAS'             TO WGLOB-MSG-PARM (01)
014221         MOVE WLGAS-KEY          TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF  WLGAS-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM LGAS-1000-CALL-AUDIT
                      THRU LGAS-1000-CALL-AUDIT-X
               END-IF
           ELSE
      *MSG:    "RECORD (@1 @2 @3 @4) NOT FOUND"
               MOVE MIR-LOC-GR-COLCT-ID
                                      TO WGLOB-MSG-PARM (1)
               MOVE MIR-LOC-GR-TYP-CD TO WGLOB-MSG-PARM (2)
               MOVE MIR-LOC-GR-LOC-CD TO WGLOB-MSG-PARM (3)
               MOVE MIR-LOC-GR-EFF-IDT-NUM
                                      TO WGLOB-MSG-PARM (4)
               MOVE 'CS30100013'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM 8510-EDIT-LGAS-DATA-FIELDS
              THRU 8510-EDIT-LGAS-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW = 0
               MOVE MIR-LOC-GR-ID
                                      TO  RLGAS-LOC-GR-ID
               PERFORM LGAS-2000-REWRITE
                  THRU LGAS-2000-REWRITE-X
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM LGAS-1000-CALL-AUDIT
                      THRU LGAS-1000-CALL-AUDIT-X
               END-IF
014221         PERFORM LGAS-1000-READ-TWRK-TS
014221            THRU LGAS-1000-READ-TWRK-TS-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
      *MSG:    MAINTENANCE COMPLETE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      *
      *********************
       6000-PROCESS-DELETE.
      *********************

           PERFORM  8050-BUILD-LGAS-KEY
               THRU 8050-BUILD-LGAS-KEY-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 6000-PROCESS-DELETE-X
           END-IF.

014221*    PERFORM LGAS-1000-READ-FOR-UPDATE
014221*       THRU LGAS-1000-READ-FOR-UPDATE-X
014221     PERFORM LGAS-2000-UPDATE-TWRK-TS
014221        THRU LGAS-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'LGAS'             TO WGLOB-MSG-PARM (01)
014221         MOVE WLGAS-KEY          TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WLGAS-IO-OK
               PERFORM 6100-PROCESS-LGAS-DELETE
                  THRU 6100-PROCESS-LGAS-DELETE-X
           ELSE
      *MSG:    "RECORD (@1 @2 @3 @4) NOT FOUND"
               MOVE MIR-LOC-GR-COLCT-ID
                                      TO WGLOB-MSG-PARM (1)
               MOVE MIR-LOC-GR-TYP-CD TO WGLOB-MSG-PARM (2)
               MOVE MIR-LOC-GR-LOC-CD TO WGLOB-MSG-PARM (3)
               MOVE MIR-LOC-GR-EFF-IDT-NUM
                                      TO WGLOB-MSG-PARM (4)
               MOVE 'CS30100013'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      *
      ***************************
       6100-PROCESS-LGAS-DELETE.
      ***************************

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM LGAS-1000-CALL-AUDIT
                  THRU LGAS-1000-CALL-AUDIT-X
           END-IF.

           PERFORM LGAS-1000-DELETE
              THRU LGAS-1000-DELETE-X.

           IF WLGAS-IO-OK
      *MSG:   DELETE COMPLETED MESSAGE
              MOVE 'XS00000011'       TO WGLOB-MSG-REF-INFO
              IF  WGLOB-AUDIT-REQUESTED
                  PERFORM LGAS-1000-CALL-AUDIT
                     THRU LGAS-1000-CALL-AUDIT-X
              END-IF
           ELSE
      *MSG:   RECORD (@1) LOST IN DELETE
              MOVE WLGAS-KEY          TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000010'       TO WGLOB-MSG-REF-INFO
           END-IF.

       6100-PROCESS-LGAS-DELETE-X.
           EXIT.
      *
      *******************
       7000-PROCESS-KLON.
      *******************

      *
      *---- EDIT THE 'FROM' KEY
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-KLON-1ST-EDIT
               THRU 7100-KLON-1ST-EDIT-X.

           IF WGLOB-MSG-ERROR-SW > ZEROS
              GO TO 7000-PROCESS-KLON-X
           END-IF.

           MOVE LOW-VALUES            TO  WLGAS-KEY.
           MOVE HIGH-VALUES           TO  WLGAS-ENDBR-KEY.

           IF MIR-LOC-GR-COLCT-ID NOT = SPACES
              MOVE MIR-LOC-GR-COLCT-ID
                                      TO  WLGAS-LOC-GR-COLCT-ID
              MOVE MIR-LOC-GR-COLCT-ID
                                      TO  WLGAS-ENDBR-LOC-GR-COLCT-ID
           END-IF.

           IF MIR-LOC-GR-TYP-CD NOT = SPACES
              MOVE MIR-LOC-GR-TYP-CD  TO  WLGAS-LOC-GR-TYP-CD
              MOVE MIR-LOC-GR-TYP-CD  TO  WLGAS-ENDBR-LOC-GR-TYP-CD
           END-IF.

           PERFORM  LGAS-1000-BROWSE
               THRU LGAS-1000-BROWSE-X.

           IF NOT WLGAS-IO-OK
           OR WLGAS-IO-EOF
      *MSG:  KLONE SOURCE INFORMATION DOES NOT EXIST
              MOVE 'CS30100015'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  LGAS-3000-END-BROWSE
                  THRU LGAS-3000-END-BROWSE-X
              GO TO 7000-PROCESS-KLON-X
           END-IF.

           PERFORM  LGAS-2000-READ-NEXT
               THRU LGAS-2000-READ-NEXT-X

           IF NOT WLGAS-IO-OK
           OR WLGAS-IO-EOF
      *MSG:  KLONE SOURCE INFORMATION DOES NOT EXIST
              MOVE 'CS30100015'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  LGAS-3000-END-BROWSE
                  THRU LGAS-3000-END-BROWSE-X
              GO TO 7000-PROCESS-KLON-X
           END-IF.

           PERFORM  LGAS-3000-END-BROWSE
               THRU LGAS-3000-END-BROWSE-X.

      *
      *    EDIT THE 'TO' KEY
      *

           PERFORM  7200-KLON-2ND-EDITS
               THRU 7200-KLON-2ND-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW > ZEROS
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      *MSG: RECORD NOT KLONED
               MOVE 'CS30100014'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-KLON-X
           END-IF.

      *
      *  START BROWSE AGAIN WITH ORIGINAL LPTR AND TYPE IF ENTERED
      *

           MOVE LOW-VALUES            TO WLGAS-KEY.
           MOVE HIGH-VALUES           TO WLGAS-ENDBR-KEY.

           MOVE MIR-LOC-GR-COLCT-ID   TO WLGAS-LOC-GR-COLCT-ID.
           MOVE MIR-LOC-GR-COLCT-ID   TO WLGAS-ENDBR-LOC-GR-COLCT-ID.

           IF  MIR-LOC-GR-TYP-CD = SPACES
               CONTINUE
           ELSE
               MOVE MIR-LOC-GR-TYP-CD TO WLGAS-LOC-GR-TYP-CD
               MOVE MIR-LOC-GR-TYP-CD TO WLGAS-ENDBR-LOC-GR-TYP-CD
           END-IF.

           MOVE ZERO                  TO WS-COUNT-KLON-RECS.

           PERFORM  LGAS-1000-BROWSE
               THRU LGAS-1000-BROWSE-X.

           IF WLGAS-IO-OK
              PERFORM  LGAS-2000-READ-NEXT
                  THRU LGAS-2000-READ-NEXT-X
              PERFORM  7300-CHECK-KLON-ONE-REC
                  THRU 7300-CHECK-KLON-ONE-REC-X
                  UNTIL WLGAS-IO-EOF
           ELSE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      *MSG: RECORD NOT KLONED
               MOVE 'CS30100021'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-KLON-X
           END-IF.

           PERFORM  LGAS-3000-END-BROWSE
               THRU LGAS-3000-END-BROWSE-X.

           IF WGLOB-MSG-ERROR-SW = ZEROS
      *MSG:  '@1 RECORD(S) IS/ARE CLONED
              MOVE WS-COUNT-KLON-RECS TO WGLOB-MSG-PARM (1)
              MOVE 'CS30100012'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       7000-PROCESS-KLON-X.
           EXIT.


      *******************
       7100-KLON-1ST-EDIT.
      *******************

           IF MIR-LOC-GR-COLCT-ID = SPACES
      * MSG:  'GROUP LOCATION POINTER ID IS REQUIRED'
              MOVE 'CS30100001'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
              MOVE MIR-LOC-GR-COLCT-ID
                                      TO  WEDIT-ETBL-VALU-ID
              PERFORM  LPTR-1000-EDIT-LPTR-LOCATION
                  THRU LPTR-1000-EDIT-LPTR-LOCATION-X
              IF NOT WEDIT-IO-OK
      * MSG:    'INVALID LOCATION POINTER'
                MOVE 'CS30100008'     TO  WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

           IF MIR-LOC-GR-TYP-CD = SPACES
              CONTINUE
           ELSE
020477*       MOVE MIR-LOC-GR-TYP-CD  TO  WS-GROUP-PROCESS-TYPE

020477        PERFORM  8960-1000-BUILD-PARM-INFO
020477            THRU 8960-1000-BUILD-PARM-INFO-X
020477
020477        MOVE 'LOC-GR-TYP-CD'    TO L8960-AV-TBL-CD
020477        MOVE MIR-LOC-GR-TYP-CD  TO L8960-AV-CD
020477
020477        PERFORM  8960-1000-VALIDATE-CODE
020477            THRU 8960-1000-VALIDATE-CODE-X
020477
020477        IF  NOT L8960-RETRN-OK
020477*       IF  NOT WS-VALID-GROUP-PROCESS-TYPE
      * MSG:    'INVALID LOCATION GROUP PROCESS TYPE'
                  MOVE 'CS30100005'   TO  WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO  7100-KLON-1ST-EDIT-X
           END-IF.

           IF MIR-LOC-GR-LOC-CD NOT = SPACES
              MOVE SPACES             TO  MIR-LOC-GR-LOC-CD
           END-IF.

           IF MIR-LOC-GR-EFF-IDT-NUM NOT = SPACES
              MOVE SPACES           TO  MIR-LOC-GR-EFF-IDT-NUM
           END-IF.

       7100-KLON-1ST-EDIT-X.
           EXIT.
      *
      *********************
       7200-KLON-2ND-EDITS.
      *********************
      *
      *---- CHECK CLONE DESTINATION
      *

015904*    IF MIR-LOC-GR-COLCT-ID-TO = SPACES
015904     IF MIR-DV-TO-LOC-GR-COLCT-ID = SPACES
      * MSG:  'GROUP LOCATION POINTER ID IS REQUIRED'
              MOVE 'CS30100001'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
015904*       MOVE MIR-LOC-GR-COLCT-ID-TO
015904        MOVE MIR-DV-TO-LOC-GR-COLCT-ID
                                      TO  WEDIT-ETBL-VALU-ID
              PERFORM  LPTR-1000-EDIT-LPTR-LOCATION
                  THRU LPTR-1000-EDIT-LPTR-LOCATION-X
              IF NOT WEDIT-IO-OK
      * MSG:    'INVALID GROUP LOCATION POINTER'
                MOVE 'CS30100008'     TO  WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

           IF MIR-LOC-GR-TYP-CD = SPACES
015904*       IF MIR-LOC-GR-TYP-CD-TO NOT = SPACES
015904        IF MIR-DV-TO-LOC-GR-TYP-CD NOT = SPACES
      * MSG: 'SOURCE GROUP PROCESS TYPE = SPACES'
                 MOVE 'CS30100010'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

           IF MIR-LOC-GR-TYP-CD NOT = SPACES
015904*       IF MIR-LOC-GR-TYP-CD-TO = SPACES
015904        IF MIR-DV-TO-LOC-GR-TYP-CD = SPACES
      * MSG: SOURCE GROUP PROCESS TYPE NOT = SPACES
                 MOVE 'CS30100011'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.
      *
015904*    IF MIR-LOC-GR-TYP-CD-TO = SPACES
015904     IF MIR-DV-TO-LOC-GR-TYP-CD = SPACES
              CONTINUE
           ELSE
015904*       MOVE MIR-LOC-GR-TYP-CD-TO TO WS-GROUP-PROCESS-TYPE
020477*       MOVE MIR-DV-TO-LOC-GR-TYP-CD TO WS-GROUP-PROCESS-TYPE

020477        PERFORM  8960-1000-BUILD-PARM-INFO
020477            THRU 8960-1000-BUILD-PARM-INFO-X
020477
020477        MOVE 'LOC-GR-TYP-CD'             TO L8960-AV-TBL-CD
020477        MOVE MIR-DV-TO-LOC-GR-TYP-CD     TO L8960-AV-CD
020477
020477        PERFORM  8960-1000-VALIDATE-CODE
020477            THRU 8960-1000-VALIDATE-CODE-X
020477
020477        IF  NOT L8960-RETRN-OK
020477*       IF  NOT WS-VALID-GROUP-PROCESS-TYPE
      * MSG:    'INVALID LOCATION GROUP PROCESS TYPE'
                  MOVE 'CS30100005'   TO  WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 7200-KLON-2ND-EDITS-X
           END-IF.

           MOVE LOW-VALUES            TO WLGAS-KEY.
           MOVE HIGH-VALUES           TO WLGAS-ENDBR-KEY.

015904*    IF MIR-LOC-GR-COLCT-ID-TO NOT = SPACES
015904     IF MIR-DV-TO-LOC-GR-COLCT-ID NOT = SPACES
015904*       MOVE MIR-LOC-GR-COLCT-ID-TO
015904        MOVE MIR-DV-TO-LOC-GR-COLCT-ID
                                      TO  WLGAS-LOC-GR-COLCT-ID
015904*       MOVE MIR-LOC-GR-COLCT-ID-TO
015904        MOVE MIR-DV-TO-LOC-GR-COLCT-ID
                                      TO  WLGAS-ENDBR-LOC-GR-COLCT-ID
           END-IF.

015904*    IF MIR-LOC-GR-TYP-CD-TO NOT = SPACES
015904     IF MIR-DV-TO-LOC-GR-TYP-CD NOT = SPACES
015904*       MOVE MIR-LOC-GR-TYP-CD-TO  TO  WLGAS-LOC-GR-TYP-CD
015904        MOVE MIR-DV-TO-LOC-GR-TYP-CD  TO  WLGAS-LOC-GR-TYP-CD
015904*       MOVE MIR-LOC-GR-TYP-CD-TO  TO  WLGAS-ENDBR-LOC-GR-TYP-CD
015904        MOVE MIR-DV-TO-LOC-GR-TYP-CD
015904                TO  WLGAS-ENDBR-LOC-GR-TYP-CD
           END-IF.

           PERFORM  LGAS-1000-BROWSE
               THRU LGAS-1000-BROWSE-X.

           PERFORM  LGAS-2000-READ-NEXT
               THRU LGAS-2000-READ-NEXT-X.

           IF WLGAS-IO-EOF
              CONTINUE
           ELSE
      *MSG:  KLONE DESTINATION ALREADY EXISTS
              MOVE 'CS30100016'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  LGAS-3000-END-BROWSE
               THRU LGAS-3000-END-BROWSE-X.

       7200-KLON-2ND-EDITS-X.
           EXIT.
      *
      *************************
       7300-CHECK-KLON-ONE-REC.
      *************************
      *
      *==== FOR DB2 SEPARATE CURSORS FOR BROWSE AND WRITE
      *
           MOVE WLGAS-KEY             TO HOLD-LAST-LGAS-KEY.
           MOVE RLGAS-KEY             TO WLGAS-KEY.
015904*    MOVE MIR-LOC-GR-COLCT-ID-TO TO WLGAS-LOC-GR-COLCT-ID.
015904     MOVE MIR-DV-TO-LOC-GR-COLCT-ID TO WLGAS-LOC-GR-COLCT-ID.
015904*    MOVE MIR-LOC-GR-COLCT-ID-TO TO RLGAS-LOC-GR-COLCT-ID.
015904     MOVE MIR-DV-TO-LOC-GR-COLCT-ID TO RLGAS-LOC-GR-COLCT-ID.

015904*    IF MIR-LOC-GR-TYP-CD-TO = SPACES
015904     IF MIR-DV-TO-LOC-GR-TYP-CD = SPACES
              CONTINUE
           ELSE
015904*       MOVE MIR-LOC-GR-TYP-CD-TO  TO WLGAS-LOC-GR-TYP-CD
015904        MOVE MIR-DV-TO-LOC-GR-TYP-CD  TO WLGAS-LOC-GR-TYP-CD
015904*       MOVE MIR-LOC-GR-TYP-CD-TO  TO RLGAS-LOC-GR-TYP-CD
015904        MOVE MIR-DV-TO-LOC-GR-TYP-CD  TO RLGAS-LOC-GR-TYP-CD
           END-IF.

           PERFORM  LGAS-1000-WRITE
               THRU LGAS-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM LGAS-1000-CALL-AUDIT
                  THRU LGAS-1000-CALL-AUDIT-X
           END-IF.

           ADD  1 TO WS-COUNT-KLON-RECS.

           MOVE HOLD-LAST-LGAS-KEY    TO  WLGAS-KEY.

           PERFORM  LGAS-2000-READ-NEXT
               THRU LGAS-2000-READ-NEXT-X.

       7300-CHECK-KLON-ONE-REC-X.
           EXIT.
      *
      ****************************
       8000-BUILD-LGAS-BROWSE-KEY.
      ****************************

           IF  MIR-LOC-GR-COLCT-ID = SPACES
      *MSG:    GROUP LOCATION POINTER ID IS REQUIRED
               MOVE 'CS30100001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO  TO  8000-BUILD-LGAS-BROWSE-KEY-X
           END-IF.

           MOVE LOW-VALUES            TO WLGAS-KEY.
           MOVE HIGH-VALUES           TO WLGAS-ENDBR-KEY.

           MOVE MIR-LOC-GR-COLCT-ID   TO WLGAS-LOC-GR-COLCT-ID.
           MOVE MIR-LOC-GR-COLCT-ID   TO WLGAS-ENDBR-LOC-GR-COLCT-ID.

           IF  MIR-LOC-GR-TYP-CD GREATER SPACES
               MOVE MIR-LOC-GR-TYP-CD TO WLGAS-LOC-GR-TYP-CD
           END-IF.

           IF  MIR-LOC-GR-LOC-CD  GREATER SPACES
               MOVE MIR-LOC-GR-LOC-CD TO WLGAS-LOC-GR-LOC-CD
           END-IF.

           IF  MIR-LOC-GR-EFF-IDT-NUM GREATER SPACES
               PERFORM 8200-INVERT-EFFECTIVE-DATE
                  THRU 8200-INVERT-EFFECTIVE-DATE-X
           END-IF.

       8000-BUILD-LGAS-BROWSE-KEY-X.
           EXIT.
      *
      *********************
       8050-BUILD-LGAS-KEY.
      *********************

           MOVE MIR-LOC-GR-COLCT-ID   TO WLGAS-LOC-GR-COLCT-ID.
           MOVE MIR-LOC-GR-TYP-CD     TO WLGAS-LOC-GR-TYP-CD.
           MOVE MIR-LOC-GR-LOC-CD     TO WLGAS-LOC-GR-LOC-CD.

           PERFORM 8200-INVERT-EFFECTIVE-DATE
              THRU 8200-INVERT-EFFECTIVE-DATE-X.

       8050-BUILD-LGAS-KEY-X.
           EXIT.
      *
      *********************
       8100-READ-LGAS-INFO.
      *********************

           IF  RLGAS-LOC-GR-COLCT-ID    = WLGAS-LOC-GR-COLCT-ID
           AND RLGAS-LOC-GR-TYP-CD      = WLGAS-LOC-GR-TYP-CD
           AND RLGAS-LOC-GR-LOC-CD      = WLGAS-LOC-GR-LOC-CD
           AND RLGAS-LOC-GR-EFF-IDT-NUM = WLGAS-LOC-GR-EFF-IDT-NUM
               GO TO 8100-READ-LGAS-INFO-X
           END-IF.

014221*    PERFORM LGAS-1000-READ
014221*       THRU LGAS-1000-READ-X.
014221     PERFORM LGAS-1000-READ-TWRK-TS
014221        THRU LGAS-1000-READ-TWRK-TS-X.

           IF WLGAS-IO-NOT-FOUND
      *MSG:    "RECORD (@1 @2 @3 @4) NOT FOUND"
               MOVE MIR-LOC-GR-COLCT-ID
                                      TO WGLOB-MSG-PARM (1)
               MOVE MIR-LOC-GR-TYP-CD TO WGLOB-MSG-PARM (2)
               MOVE MIR-LOC-GR-LOC-CD TO WGLOB-MSG-PARM (3)
               MOVE MIR-LOC-GR-EFF-IDT-NUM
                                      TO WGLOB-MSG-PARM (4)
               MOVE 'CS30100013'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8100-READ-LGAS-INFO-X.
           EXIT.

      *
      ****************************
       8200-INVERT-EFFECTIVE-DATE.
      ****************************

           IF  MIR-LOC-GR-EFF-IDT-NUM = SPACES
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                    TO  MIR-LOC-GR-EFF-IDT-NUM
           ELSE
               MOVE MIR-LOC-GR-EFF-IDT-NUM
                                      TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
      *MSG:    'EFFECTIVE DATE MUST BE A VALID DATE'
                   MOVE 'CS30100007'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 8200-INVERT-EFFECTIVE-DATE-X
               END-IF
           END-IF.

           MOVE L1640-INTERNAL-DATE   TO L1660-INTERNAL-DATE.

           PERFORM 1660-2000-CONVERT-INT-TO-INV
              THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE   TO WLGAS-LOC-GR-EFF-IDT-NUM.

       8200-INVERT-EFFECTIVE-DATE-X.
           EXIT.
      *
      ***************************
       8500-EDIT-LGAS-KEY-FIELDS.
      ***************************

           MOVE MIR-LOC-GR-COLCT-ID   TO WEDIT-ETBL-VALU-ID.

           PERFORM LPTR-1000-EDIT-LPTR-LOCATION
              THRU LPTR-1000-EDIT-LPTR-LOCATION-X.

           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *MSG:    'INVALID GROUP LOCATION POINTER'
               MOVE 'CS30100008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8500-EDIT-LGAS-KEY-FIELDS-X
           END-IF.

020477*    MOVE MIR-LOC-GR-TYP-CD    TO WS-GROUP-PROCESS-TYPE.

020477     PERFORM  8960-1000-BUILD-PARM-INFO
020477         THRU 8960-1000-BUILD-PARM-INFO-X.
020477
020477     MOVE 'LOC-GR-TYP-CD'             TO L8960-AV-TBL-CD.
020477     MOVE MIR-LOC-GR-TYP-CD           TO L8960-AV-CD.
020477
020477     PERFORM  8960-1000-VALIDATE-CODE
020477         THRU 8960-1000-VALIDATE-CODE-X.
020477
020477     IF  L8960-RETRN-OK
020477*    IF  WS-VALID-GROUP-PROCESS-TYPE
               CONTINUE
           ELSE

      *MSG:    'INVALID LOCATION GROUP PROCESS TYPE'
               MOVE 'CS30100005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8500-EDIT-LGAS-KEY-FIELDS-X
           END-IF.

           MOVE MIR-LOC-GR-LOC-CD     TO WEDIT-ETBL-VALU-ID.

           PERFORM LOCA-1000-EDIT-LOCATION
              THRU LOCA-1000-EDIT-LOCATION-X.

           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *MSG:    'INVALID LOCATION'
               MOVE 'CS30100004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8500-EDIT-LGAS-KEY-FIELDS-X.
           EXIT.

      ****************************
       8510-EDIT-LGAS-DATA-FIELDS.
      ****************************

           MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.

           PERFORM  LGAS-1000-EDIT-LGAS-LOCATION
               THRU LGAS-1000-EDIT-LGAS-LOCATION-X.

           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *MSG:    'INVALID LOCATION GROUP'
               MOVE 'CS30100006'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8510-EDIT-LGAS-DATA-FIELDS-X
           END-IF.

       8510-EDIT-LGAS-DATA-FIELDS-X.
           EXIT.

      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      ************************
       9100-BLANK-DATA-FIELDS.
      ************************

           MOVE SPACES        TO MIR-LOC-GR-TYP-CD-G.
           MOVE SPACES        TO MIR-LOC-GR-LOC-CD-G.
           MOVE SPACES        TO MIR-LOC-GR-EFF-IDT-NUM-G.
           MOVE SPACES        TO MIR-LOC-GR-ID-G.
           MOVE SPACES        TO MIR-LOC-GR-ID.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************

           IF WS-BUS-FCN-LIST
               PERFORM 9210-MOVE-LGAS-TO-SCRN-1
                  THRU 9210-MOVE-LGAS-TO-SCRN-1-X
                VARYING I FROM 1 BY 1
                  UNTIL I > WS-MAX-BROWSE-LINES
                     OR WLGAS-IO-EOF

               IF  NOT WLGAS-IO-EOF
                   MOVE RLGAS-LOC-GR-COLCT-ID
                                      TO MIR-LOC-GR-COLCT-ID
                   MOVE RLGAS-LOC-GR-TYP-CD
                                      TO MIR-LOC-GR-TYP-CD
                   MOVE RLGAS-LOC-GR-LOC-CD
                                      TO MIR-LOC-GR-LOC-CD
                   MOVE RLGAS-LOC-GR-EFF-DT
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM 1640-2000-INTERNAL-TO-EXT
020462*               THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM 1640-8000-INTERNAL-TO-MIR
020462                THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                     TO MIR-LOC-GR-EFF-IDT-NUM
               END-IF

               IF  WLGAS-IO-EOF
               AND MIR-LOC-GR-ID-T (1) NOT = SPACES
                   MOVE MIR-LOC-GR-ID-T (1)
                                      TO MIR-LOC-GR-ID
               END-IF
           ELSE
               MOVE RLGAS-LOC-GR-ID   TO MIR-LOC-GR-ID
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *
      **************************
       9210-MOVE-LGAS-TO-SCRN-1.
      **************************

           MOVE RLGAS-LOC-GR-TYP-CD   TO MIR-LOC-GR-TYP-CD-T (I).
           MOVE RLGAS-LOC-GR-LOC-CD   TO MIR-LOC-GR-LOC-CD-T (I).
           MOVE RLGAS-LOC-GR-EFF-DT   TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-LOC-GR-EFF-IDT-NUM-T (I).
           MOVE RLGAS-LOC-GR-ID       TO MIR-LOC-GR-ID-T (I).

           PERFORM LGAS-2000-READ-NEXT
              THRU LGAS-2000-READ-NEXT-X.

       9210-MOVE-LGAS-TO-SCRN-1-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-SUB-DEFAULT TO TRUE.
025970     SET I-DEFAULT TO TRUE.
025970     SET WS-COUNT-KLON-RECS-DEFAULT TO TRUE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY LGAS
014221                         '$VAR2' BY 'LGAS'.
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPELGAS.
       COPY CCPELPTR.
       COPY CCPELOCA.
       COPY CCPNEDIT.
      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
020477 COPY XCPS8960.
020477 COPY XCPL8960.
014035*COPY CCPL0620.

018764*COPY CCCLLGAS.
018764 COPY CCPLLGAS.
014035*COPY CCCL2435.
014035*COPY CCPS2435.

014035*COPY NCCL3340.
      *
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
      *
       COPY CCPALGAS.
       COPY CCPNLGAS.
       COPY CCPBLGAS.
       COPY CCPCLGAS.
       COPY CCPULGAS.
       COPY CCPXLGAS.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM CSOM3010                       *
      ******************************************************************
