      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2561.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2561                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE IPRD AND IPDF TABLES                     **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2561'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
025970*    05  WS-CONSTANTS.
025970*        10  WS-TWRK-KEY                  PIC X(04)
025970*                                         VALUE '2561'.

           05  WS-VARIABLES.
               10  WS-BUS-FCN-ID                PIC X(04).
                   88  WS-BUS-FCN-CREATE        VALUE '2561'.
               10  WS-BYPASS-CREATE-SW          PIC X(01).
                   88  WS-BYPASS-CREATE         VALUE 'Y'.
                   88  WS-BYPASS-CREATE-NO      VALUE 'N'.
               10  WS-SEQ-NUM-SW                PIC X(01).
                   88  WS-SEQ-NUM-NOTFND        VALUE 'N'.
                   88  WS-SEQ-NUM-FOUND         VALUE 'Y'.
               10  WS-PRFLD-EFF-DT              PIC X(10).
               10  WS-PRFLD-SEQ-NUM             PIC 9(03).
               
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '2561'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWIPRD.
       COPY CCFRIPRD.
      /
       COPY CCFWIPRO.
       COPY CCFRIPRO.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2561.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2561'    TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'  TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'  TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                       TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------
      *
      *  THE RECORD SHOULD NOT EXIST ON A CREATE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                                       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  7400-MOVE-DATA
               THRU 7400-MOVE-DATA-X.

           IF  WGLOB-RETURN-ERROR
           OR  WS-BYPASS-CREATE
               GO TO 2000-CREATE-X
           END-IF.
      *
      *  CREATE THE NEW RECORD AND AUDIT THE CHANGE
      *
           PERFORM  IPRD-1000-CREATE
               THRU IPRD-1000-CREATE-X.

           PERFORM  7500-INIT-RECORD
               THRU 7500-INIT-RECORD-X.

           PERFORM  IPRD-1000-WRITE
               THRU IPRD-1000-WRITE-X.

      *  UPDATE THE TIMESTAMP FOR LOGICAL LOCKING

           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.
           PERFORM  IPRO-1000-READ-TWRK-TS
               THRU IPRO-1000-READ-TWRK-TS-X.

       2000-CREATE-X.
           EXIT.
      /

      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           PERFORM  4110-EDIT-PRFL-ID
               THRU 4110-EDIT-PRFL-ID-X.

           PERFORM  4120-EDIT-PRFLD-EFF-DT
               THRU 4120-EDIT-PRFLD-EFF-DT-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /


      *------------------
       4110-EDIT-PRFL-ID.
      *------------------

           IF  MIR-PRFL-ID = SPACES
      *MSG: INVESTOR PROFILE ID (@1) NOT VALID
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'CS25610001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4110-EDIT-PRFL-ID-X
           END-IF.

           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.
           PERFORM IPRO-1000-READ
              THRU IPRO-1000-READ-X.

           IF  NOT WIPRO-IO-OK
      *MSG: INVESTOR PROFILE ID (@1) NOT VALID
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'CS25610001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4110-EDIT-PRFL-ID-X
           END-IF.

           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.

       4110-EDIT-PRFL-ID-X.
           EXIT.
      /

      *-----------------------
       4120-EDIT-PRFLD-EFF-DT.
      *-----------------------

           IF  MIR-PRFLD-EFF-DT = SPACES
      *MSG: INVALID EFFECTIVE DATE
               MOVE 'CS25610002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4120-EDIT-PRFLD-EFF-DT-X
           END-IF.

           MOVE MIR-PRFLD-EFF-DT       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                       TO WS-PRFLD-EFF-DT
           ELSE
      *MSG: INVALID EFFECTIVE DATE
               MOVE 'CS25610002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  RIPRO-PRFL-XPRY-DT NOT = WWKDT-ZERO-DT
               IF  WS-PRFLD-EFF-DT > RIPRO-PRFL-XPRY-DT
      *MSG: CREATE DISALLOWED, EFFECTIVE DATE LATER THAN EXPIRY DATE
                  MOVE 'CS25610005'       TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                  SET WGLOB-RETURN-ERROR  TO TRUE
                  GO TO 4120-EDIT-PRFLD-EFF-DT-X
               END-IF   
           END-IF.

       4120-EDIT-PRFLD-EFF-DT-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WIPRD-KEY.
           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      *---------------
       7400-MOVE-DATA.
      *---------------

           SET WS-BYPASS-CREATE-NO     TO TRUE.
           SET WS-SEQ-NUM-NOTFND       TO TRUE.
           MOVE +1                     TO WS-PRFLD-SEQ-NUM.

           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.
           MOVE WWKDT-HIGH-DT          TO WIPRD-PRFLD-EFF-DT.
           MOVE 999                    TO WIPRD-PRFLD-SEQ-NUM.
           MOVE WIPRD-KEY              TO WIPRD-ENDBR-KEY.
           MOVE WWKDT-LOW-DT           TO WIPRD-ENDBR-PRFLD-EFF-DT.
           MOVE ZERO                   TO WIPRD-ENDBR-PRFLD-SEQ-NUM.

           PERFORM  IPRD-1000-BROWSE-PREV
               THRU IPRD-1000-BROWSE-PREV-X.

           IF WIPRD-IO-OK
               PERFORM  IPRD-2000-READ-PREV
                   THRU IPRD-2000-READ-PREV-X
           END-IF.

           PERFORM 7450-GET-IPRD-INFO
              THRU 7450-GET-IPRD-INFO-X
              UNTIL NOT WIPRD-IO-OK
              OR    MIR-PRFL-ID NOT = RIPRD-PRFL-ID
              OR    WS-BYPASS-CREATE
              OR    WGLOB-RETURN-ERROR
              OR    WS-SEQ-NUM-FOUND.

           PERFORM  IPRD-3000-END-BROWSE-PREV
               THRU IPRD-3000-END-BROWSE-PREV-X.

           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPRD-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPRD-PRFLD-SEQ-NUM.

           MOVE WIPRD-PRFLD-SEQ-NUM    TO L0290-INPUT-V00.
           MOVE ZERO                   TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-PRFLD-SEQ-NUM.

       7400-MOVE-DATA-X.
           EXIT.
      /
      *-------------------
       7450-GET-IPRD-INFO.
      *-------------------

           IF  MIR-PRFL-ID NOT = RIPRD-PRFL-ID
               GO TO 7450-GET-IPRD-INFO-X
           END-IF.

           IF  RIPRD-PRFLD-STAT-ACTV
           AND WS-PRFLD-EFF-DT < RIPRD-PRFLD-EFF-DT
      *MSG: EFF DATE OF THE NEW PENDING RECORD SHOULD BE >= EFF DATE
      *     OF THE CURRENT ACTIVE RECORD
               MOVE 'CS25610003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-BYPASS-CREATE    TO TRUE
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 7450-GET-IPRD-INFO-X
           END-IF.

           IF  RIPRD-PRFLD-STAT-PEND
      *MSG: RECORD ALREADY EXISTS FOR THIS INVESTOR PROFILE (@1)
               MOVE 'CS25610004'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-BYPASS-CREATE    TO TRUE
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 7450-GET-IPRD-INFO-X
           END-IF.

           IF  RIPRD-PRFLD-EFF-DT = WS-PRFLD-EFF-DT
               MOVE RIPRD-PRFLD-SEQ-NUM TO WS-PRFLD-SEQ-NUM
               ADD 1                    TO WS-PRFLD-SEQ-NUM
               SET WS-SEQ-NUM-FOUND     TO TRUE
           END-IF.

           PERFORM  IPRD-2000-READ-PREV
               THRU IPRD-2000-READ-PREV-X.

       7450-GET-IPRD-INFO-X.
           EXIT.
      /
      *-----------------
       7500-INIT-RECORD.
      *-----------------

           SET RIPRD-PRFLD-STAT-PEND   TO TRUE.
           MOVE WWKDT-ZERO-DT          TO RIPRD-PRFLD-STAT-CHNG-DT.
           MOVE WWKDT-ZERO-DT          TO RIPRD-PRFLD-POL-CHNG-DT.

       7500-INIT-RECORD-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-VARIABLES.
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE SPACES TO   WWKDT-WORK-FIELDS.
025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.
025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK         TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  IPRO
                                '$VAR2'   BY 'IPRO'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
       COPY XCPL0290.
025970 COPY XCPS8090.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPAIPRD.
       COPY CCPVIPRD.
       COPY CCPCIPRD.
       COPY CCPNIPRO.
       COPY CCPUIPRO.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2561                     **
      *****************************************************************
