      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7660.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7660                                         **
      **  REMARKS:  THIS MODULE PERFORMS RETRIEVE FUNCTION           **
      **            FOR THE CATX TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016457**  6.2       NEW                                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7660'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       COPY CCWWINDX.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-RETRIEVE                 VALUE '7660'.
           05  WS-CATX-SEQ-NUM-X.
               10  WS-CATX-SEQ-NUM                     PIC 9(03).
           05  WS-CATX-PRCES-DT                        PIC X(10).
           05  WS-CATX-DT                              PIC X(10).

       COPY XCWLCOMM REPLACING '$VAR1' BY '7660'.
           15  LCOMM-CURR-KEY.
               20  LCOMM-POL-ID                 PIC X(10).
               20  LCOMM-CATX-PRCES-DT          PIC X(10).
               20  LCOMM-CATX-DT                PIC X(10).
               20  LCOMM-CATX-SEQ-NUM           PIC 9(03).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCATZ.
       COPY CCFRCATX.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
       COPY CCWL2430.
       COPY CCWL2440.
       COPY CCWL0620.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7660.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  COMM-1000-INITIALIZE
               THRU COMM-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-RETRIEVE
                        THRU 3000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7660'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *---------------
       3000-RETRIEVE.
      *---------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 3000-RETRIEVE-X
           END-IF.

           PERFORM  CATZ-1000-READ
               THRU CATZ-1000-READ-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           IF  WCATZ-IO-EOF
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE RCATX-POL-ID          TO LCOMM-POL-ID
               MOVE RCATX-CATX-PRCES-DT   TO LCOMM-CATX-PRCES-DT
               MOVE RCATX-CATX-DT         TO LCOMM-CATX-DT
               MOVE RCATX-CATX-SEQ-NUM    TO LCOMM-CATX-SEQ-NUM
           END-IF.

           PERFORM  COMM-3000-DELETE-TWRK
               THRU COMM-3000-DELETE-TWRK-X.
           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.

           MOVE RPOL-SBSDRY-CO-ID             TO MIR-POL-SBSDRY-CO-ID.

           PERFORM  3200-GET-OWNER-NAME
               THRU 3200-GET-OWNER-NAME-X.

       3000-RETRIEVE-X.
           EXIT.

      *--------------------
       3200-GET-OWNER-NAME.
      *--------------------

           MOVE ZERO                  TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE SPACE                 TO MIR-DV-OWN-CLI-NM
               GO TO 3200-GET-OWNER-NAME-X
           END-IF.

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF  L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
           END-IF.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.

           PERFORM  3210-CLIA-INFO
               THRU 3210-CLIA-INFO-X.

       3200-GET-OWNER-NAME-X.
           EXIT.

      *---------------
       3210-CLIA-INFO.
      *---------------

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.
           MOVE L2430-CLI-ADDR-TYP-CD TO L2440-CLI-ADDR-TYP-CD.
           MOVE L2430-CLI-ID          TO L2440-CLI-ID.

           IF  L2440-CLI-ADDR-TYP-CD =  'PR'
               PERFORM  2440-1000-PRIMARY-ADDRESS
                   THRU 2440-1000-PRIMARY-ADDRESS-X
           ELSE
               PERFORM  2440-2000-OTHER-ADDRESS
                   THRU 2440-2000-OTHER-ADDRESS-X
           END-IF.

           IF  L2440-RETRN-OK
               MOVE L2440-ADDR-STAT-CD      TO MIR-CLI-ADDR-STAT-CD
           END-IF.

       3210-CLIA-INFO-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           EVALUATE TRUE

               WHEN MIR-DV-BCKWRD-SCROLL
                    PERFORM  COMM-1000-RETRIEVE-TWRK
                        THRU COMM-1000-RETRIEVE-TWRK-X
                    IF  LCOMM-RETRN-OK
                        PERFORM  7100-GET-PREV-KEY
                            THRU 7100-GET-PREV-KEY-X
                    ELSE
      *MSG: TWRK ERROR - CALL SYSTEMS
                        MOVE 'XS00000243'      TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                    END-IF

               WHEN MIR-DV-FORWRD-SCROLL
                    PERFORM  COMM-1000-RETRIEVE-TWRK
                        THRU COMM-1000-RETRIEVE-TWRK-X
                    IF  LCOMM-RETRN-OK
                        PERFORM  7200-GET-NEXT-KEY
                            THRU 7200-GET-NEXT-KEY-X
                    ELSE
      *MSG: TWRK ERROR - CALL SYSTEMS
                        MOVE 'XS00000243'      TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                    END-IF

           END-EVALUATE.

           PERFORM  7300-EDIT-INPUT
               THRU 7300-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           MOVE MIR-POL-ID              TO WCATZ-POL-ID.
           MOVE WS-CATX-PRCES-DT        TO WCATZ-CATX-PRCES-DT.
           MOVE WS-CATX-DT              TO WCATZ-CATX-DT.
           MOVE WS-CATX-SEQ-NUM         TO WCATZ-CATX-SEQ-NUM.


       7000-BUILD-KEYS-X.
           EXIT.

      *-------------------
       7100-GET-PREV-KEY.
      *-------------------

           MOVE LCOMM-POL-ID          TO WCATZ-POL-ID.
           MOVE LCOMM-CATX-PRCES-DT TO WCATZ-CATX-PRCES-DT.
           MOVE LCOMM-CATX-DT         TO WCATZ-CATX-DT.
           MOVE LCOMM-CATX-SEQ-NUM    TO WCATZ-CATX-SEQ-NUM.

           MOVE WCATZ-KEY             TO WCATZ-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WCATZ-ENDBR-CATX-PRCES-DT.
           MOVE WWKDT-LOW-DT          TO WCATZ-ENDBR-CATX-DT.
           MOVE ZERO                  TO WCATZ-ENDBR-CATX-SEQ-NUM.

           PERFORM  CATZ-1000-BROWSE-PREV
               THRU CATZ-1000-BROWSE-PREV-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > 2
               OR NOT WCATZ-IO-OK

               PERFORM  CATZ-2000-READ-PREV
                   THRU CATZ-2000-READ-PREV-X

               IF  WCATZ-IO-OK
                   PERFORM  7110-SET-KEY
                       THRU 7110-SET-KEY-X
               END-IF

           END-PERFORM.

           IF  NOT WCATZ-IO-OK
      *MSG: 'END OF LIST'
               MOVE 'XS00000015'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  CATZ-3000-END-BROWSE-PREV
               THRU CATZ-3000-END-BROWSE-PREV-X.

       7100-GET-PREV-KEY-X.
           EXIT.
      /
      *--------------
       7110-SET-KEY.
      *--------------

           MOVE RCATX-POL-ID            TO MIR-POL-ID.
           MOVE RCATX-CATX-PRCES-DT     TO WS-CATX-PRCES-DT.

           MOVE RCATX-CATX-PRCES-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CATX-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CATX-PRCES-DT
           END-IF.

           MOVE RCATX-CATX-DT           TO WS-CATX-DT.

           MOVE RCATX-CATX-DT            TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CATX-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CATX-DT
           END-IF.

           MOVE RCATX-CATX-SEQ-NUM      TO WS-CATX-SEQ-NUM.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-SEQ-NUM.
020874     MOVE RCATX-CATX-SEQ-NUM       TO L0290-INPUT-V00.
           MOVE +0                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-SEQ-NUM
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-SEQ-NUM.

       7110-SET-KEY-X.
           EXIT.

      *-------------------
       7200-GET-NEXT-KEY.
      *-------------------

           MOVE LCOMM-POL-ID          TO WCATZ-POL-ID.
           MOVE LCOMM-CATX-PRCES-DT TO WCATZ-CATX-PRCES-DT.
           MOVE LCOMM-CATX-DT         TO WCATZ-CATX-DT.
           MOVE LCOMM-CATX-SEQ-NUM    TO WCATZ-CATX-SEQ-NUM.

           MOVE WCATZ-KEY             TO WCATZ-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT         TO WCATZ-ENDBR-CATX-PRCES-DT.
           MOVE WWKDT-HIGH-DT         TO WCATZ-ENDBR-CATX-DT.
           MOVE +999                  TO WCATZ-ENDBR-CATX-SEQ-NUM.

           PERFORM  CATZ-1000-BROWSE
               THRU CATZ-1000-BROWSE-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > 2
               OR NOT WCATZ-IO-OK

               PERFORM  CATZ-2000-READ-NEXT
                   THRU CATZ-2000-READ-NEXT-X
               IF  WCATZ-IO-OK
                   PERFORM  7110-SET-KEY
                       THRU 7110-SET-KEY-X
               END-IF

           END-PERFORM.

           IF  NOT WCATZ-IO-OK
      *MSG: 'END OF LIST'
               MOVE 'XS00000015'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  CATZ-3000-END-BROWSE
               THRU CATZ-3000-END-BROWSE-X.

       7200-GET-NEXT-KEY-X.
           EXIT.
      /
      *----------------
       7300-EDIT-INPUT.
      *----------------

           PERFORM  7310-EDIT-POL-ID
               THRU 7310-EDIT-POL-ID-X.

           PERFORM  7320-EDIT-CATX-PRCES-DT
               THRU 7320-EDIT-CATX-PRCES-DT-X.

           PERFORM  7330-EDIT-CATX-DT
               THRU 7330-EDIT-CATX-DT-X.

           PERFORM  7340-EDIT-CATX-SEQ-NUM
               THRU 7340-EDIT-CATX-SEQ-NUM-X.

       7300-EDIT-INPUT-X.
           EXIT.

      *------------------
       7310-EDIT-POL-ID.
      *------------------

           MOVE MIR-POL-ID               TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.
           IF  NOT WPOL-IO-OK
      *MSG:  POLICY NOT FOUND
               MOVE 'CS76600001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7310-EDIT-POL-ID-X.
           EXIT.

      *-------------------
       7320-EDIT-CATX-PRCES-DT.
      *-------------------

           MOVE MIR-CATX-PRCES-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      ****MSG: INVALID PROCESS DATE
               MOVE 'CS76600002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WWKDT-LOW-DT         TO WS-CATX-PRCES-DT
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-CATX-PRCES-DT
           END-IF.

       7320-EDIT-CATX-PRCES-DT-X.
           EXIT.

      *------------------
       7330-EDIT-CATX-DT.
      *------------------

           MOVE MIR-CATX-DT              TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      ****MSG: INVALID SYSTEM DATE
               MOVE 'CS76600003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WWKDT-LOW-DT         TO WS-CATX-DT
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-CATX-DT
           END-IF.

       7330-EDIT-CATX-DT-X.
           EXIT.

      *------------------
       7340-EDIT-CATX-SEQ-NUM.
      *------------------

           MOVE MIR-CATX-SEQ-NUM        TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CATX-SEQ-NUM
                                        TO L0280-INPUT-SIZE.
           MOVE 3                       TO L0280-LENGTH.
           MOVE ZERO                    TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           SET L0280-SPACES-PERMITTED   TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00     TO WS-CATX-SEQ-NUM
           ELSE
      ****MSG: INVALID SEQUENCE NUMBER
               MOVE 'CS76600004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE ZERO                 TO WS-CATX-SEQ-NUM
           END-IF.

       7340-EDIT-CATX-SEQ-NUM-X.
           EXIT.


      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RCATX-POL-ID             TO MIR-POL-ID.

           MOVE RCATX-CATX-PRCES-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CATX-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CATX-PRCES-DT
           END-IF.

           MOVE RCATX-CATX-DT            TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CATX-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CATX-DT
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-SEQ-NUM.
020874     MOVE RCATX-CATX-SEQ-NUM       TO L0290-INPUT-V00.
           MOVE +0                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-SEQ-NUM
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-SEQ-NUM.

           MOVE RCATX-CATX-CLI-TAX-ID    TO MIR-CATX-CLI-TAX-ID.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-DOD-CRNT-INT-AMT
020874*                               * 100.
020874     MOVE RCATX-DOD-CRNT-INT-AMT      TO L0290-INPUT-V02.
           MOVE +2                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DOD-CRNT-INT-AMT
                                            TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY           TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DOD-CRNT-INT-AMT.

020874*   COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-TAX-ACRU-AMT
020874*                               * 100.
020874     MOVE RCATX-CATX-TAX-ACRU-AMT      TO L0290-INPUT-V02.
           MOVE +2                           TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-TAX-ACRU-AMT
                                             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY            TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY      TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-TAX-ACRU-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CDN-OTHR-INCM-AMT
020874*                               * 100.
020874     MOVE RCATX-CDN-OTHR-INCM-AMT      TO L0290-INPUT-V02.
           MOVE +2                           TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CDN-OTHR-INCM-AMT
                                             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY            TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY      TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CDN-OTHR-INCM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-CDN-INT-AMT
020874*                               * 100.
020874     MOVE RCATX-CATX-CDN-INT-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-CDN-INT-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-CDN-INT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-T5-GAIN-AMT
020874*                               * 100.
020874     MOVE RCATX-CATX-T5-GAIN-AMT      TO L0290-INPUT-V02.
           MOVE +2                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-T5-GAIN-AMT
                                            TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY           TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-T5-GAIN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-T5-LOAN-AMT
020874*                               * 100.
020874     MOVE RCATX-CATX-T5-LOAN-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-T5-LOAN-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-T5-LOAN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-PREV-DISP-TAX-AMT
020874*                               * 100.
020874     MOVE RCATX-PREV-DISP-TAX-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PREV-DISP-TAX-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PREV-DISP-TAX-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-LOAN-DISP-TAX-AMT
020874*                               * 100.
020874     MOVE RCATX-LOAN-DISP-TAX-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LOAN-DISP-TAX-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-LOAN-DISP-TAX-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-LOAN-DISP-YTD-AMT
020874*                               * 100.
020874     MOVE RCATX-LOAN-DISP-YTD-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LOAN-DISP-YTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-LOAN-DISP-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-POL-PDF-INT-AMT
020874*                               * 100.
020874     MOVE RCATX-POL-PDF-INT-AMT    TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PDF-INT-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-POL-PDF-INT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-POL-ANPAYO-LTD-AMT
020874*                               * 100.
020874     MOVE RCATX-POL-ANPAYO-LTD-AMT TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-ANPAYO-LTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-POL-ANPAYO-LTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-PREV-LOAN-DISP-AMT
020874*                               * 100.
020874     MOVE RCATX-PREV-LOAN-DISP-AMT TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PREV-LOAN-DISP-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PREV-LOAN-DISP-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-ACQ-COST-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-ACQ-COST-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-ACQ-COST-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-ACQ-COST-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-T5-ACRU-AMT
020874*                               * 100.
020874     MOVE RCATX-CATX-T5-ACRU-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-T5-ACRU-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-T5-ACRU-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAXBL-GAIN-81-AMT
020874*                               * 100.
020874     MOVE RCATX-TAXBL-GAIN-81-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-GAIN-81-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-GAIN-81-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAXBL-PREM-PD-AMT
020874*                               * 100.
020874     MOVE RCATX-TAXBL-PREM-PD-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-PREM-PD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-PREM-PD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-DISP-YTD-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-DISP-YTD-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-DISP-YTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-DISP-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-TAX-GAIN-AMT
020874*                               * 100.
020874     MOVE RCATX-CATX-TAX-GAIN-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-TAX-GAIN-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-TAX-GAIN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-LOAN-DEDBL-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-LOAN-DEDBL-AMT TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-LOAN-DEDBL-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-LOAN-DEDBL-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-LOAN-DOD-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-LOAN-DOD-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-LOAN-DOD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-LOAN-DOD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-LOAN-INT-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-LOAN-INT-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-LOAN-INT-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-LOAN-INT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-MORT-GAIN-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-MORT-GAIN-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-MORT-GAIN-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-MORT-GAIN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-MORT-LOS-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-MORT-LOS-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-MORT-LOS-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-MORT-LOS-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-TAX-NCPI-AMT
020874*                               * 100.
020874     MOVE RCATX-CATX-TAX-NCPI-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-TAX-NCPI-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-TAX-NCPI-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-PREV-DISP-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-PREV-DISP-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-PREV-DISP-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-PREV-DISP-AMT.

020874*   COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-SUPP-PREM-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-SUPP-PREM-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-SUPP-PREM-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-SUPP-PREM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-TAX-TRNST-ELE-AMT
020874*                               * 100.
020874     MOVE RCATX-TAX-TRNST-ELE-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-TRNST-ELE-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-TRNST-ELE-AMT.

           MOVE RCATX-CATX-STAT-CD       TO MIR-CATX-STAT-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-SIDFND-INT-AMT
020874*                               * 100.
020874     MOVE RCATX-SIDFND-INT-AMT     TO L0290-INPUT-V02.
018846     MOVE +2                       TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-SIDFND-INT-AMT
018846                                   TO L0290-MAX-OUT-LEN.
018846     SET L0290-SIGN-DISPLAY        TO TRUE.
018846     SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA        TO MIR-SIDFND-INT-AMT.
018846
026055     MOVE RCATX-DTHCLM-INT-AMT     TO L0290-INPUT-V02.
026055     MOVE +2                       TO L0290-PRECISION.
026055     MOVE LENGTH OF MIR-DTHCLM-INT-AMT
026055                                   TO L0290-MAX-OUT-LEN.
026055     SET L0290-SIGN-DISPLAY        TO TRUE.
026055     SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
026055     PERFORM  0290-2000-FORMAT-FOR-MIR
026055         THRU 0290-2000-FORMAT-FOR-MIR-X.
026055     MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-INT-AMT.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID
025970       TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
       COPY XCPSCOMM.
       COPY XCPPCOMM.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.

025970 COPY CCPS0620.
       COPY CCPL0620.

025970 COPY XCPS1640.
       COPY XCPL1640.

025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      /
018764*COPY CCCL2440.
018764 COPY CCPL2440.
020478 COPY CCPS2440.
      /
       COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCATZ.
       COPY CCPBCATZ.
       COPY CCPVCATZ.
      /
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7660
      *****************************************************************
