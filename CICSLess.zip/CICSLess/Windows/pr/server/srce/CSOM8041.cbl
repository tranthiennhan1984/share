      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8041.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8041                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION FOR     **
      **            THE CVGC TABLE. FOR A GIVEN POLICY IT WILL       **
      **            RETURN CORRESPONDING INSUREDS,THEIR NAME AND     **
      **            BIRTHDATE, AND WHETHER THEY REQUIRE UNDERWRITING **
      **            BASED ON THE PLAN(S) THEY ARE ATTACHED TO.       **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       NEW FOR RELEASE 6.0                              **
015543**  6.0       CODE CLEANUP                                     **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8041'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '8041'.
016548*    05  WS-SUB                                  PIC S9(04) COMP.
016548     05  WS-SUB                                  PIC S9(04)
016548                                                 BINARY.
016548*    05  WS-SUB1                                 PIC S9(04) COMP.
016548     05  WS-SUB1                                 PIC S9(04)
016548                                                 BINARY.
016548*    05  WS-SUB2                                 PIC S9(04) COMP.
016548     05  WS-SUB2                                 PIC S9(04)
016548                                                 BINARY.
016548*    05  WS-MAX-LIST-LINES                       PIC S9(04) COMP
025970*    05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970*                                                VALUE 50.
           05  WS-INSRD-QTY-DISPLAY                    PIC 9(2).
           05  WS-INSRD-QTY-DISPLAY-R REDEFINES
               WS-INSRD-QTY-DISPLAY                    PIC X(2).
           05  WS-ERROR-CD                             PIC X(1).
               88  WS-ERROR                            VALUE 'Y'.
               88  WS-ERROR-NO                         VALUE 'N'.
025970 01  WS-CONSTANTS.
025970     05 WS-MAX-LIST-LINES                       PIC S9(04) BINARY.
025970        88 WS-MAX-LIST-LINES-DEFAULT            VALUE 50.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWCVGS.
      /
       COPY CCWWINDX.
      /
016537*COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWCVGC.
       COPY CCFRCVGC.
      /
       COPY CCFWPD.
       COPY CCFRPD.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL2435.
028298 COPY CCWL2626.
      /
       COPY CCWL0620.
      /
       COPY XCWL1640.
      /
016440 COPY CCWL5400.
      /
       COPY XCWLDTLK.
      /
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8041.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           SET MIR-RETRN-OK           TO TRUE.
025970*    MOVE ZERO                  TO WS-SUB1.
025970*    MOVE ZERO                  TO WS-SUB2.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8041'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEY-POL
               THRU 7000-BUILD-KEY-POL-X.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOL-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

016440*
016440*  POLICY TRANSFER CHECK
016440*
016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440        THRU  5400-1000-BUILD-PARM-INFO-X.
016440     PERFORM  5400-1000-POL-CHK
016440        THRU  5400-1000-POL-CHK-X.
016440
016440     IF  L5400-XFER-ACCS-RESTRICTED
016440     OR  NOT L5400-RETRN-OK
016440         GO TO 2000-LIST-X
016440     END-IF.


           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  7010-BUILD-KEY-CVGC
               THRU 7010-BUILD-KEY-CVGC-X.

           PERFORM  CVGC-1000-BROWSE
               THRU CVGC-1000-BROWSE-X.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

           IF  WCVGC-IO-EOF
               PERFORM  CVGC-3000-END-BROWSE
                   THRU CVGC-3000-END-BROWSE-X
      *MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           SET WS-ERROR-NO       TO TRUE.
           PERFORM  2010-BROWSE-TABLE-CVGC
               THRU 2010-BROWSE-TABLE-CVGC-X
              UNTIL WCVGC-IO-EOF
                 OR WS-ERROR.

           PERFORM  CVGC-3000-END-BROWSE
               THRU CVGC-3000-END-BROWSE-X.

           IF  WPD-IO-NOT-FOUND
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2020-PROCESS-INSURED-LIST
               THRU 2020-PROCESS-INSURED-LIST-X
            VARYING WS-SUB2 FROM 1 BY 1
              UNTIL WS-SUB2 > WS-SUB1
                 OR WS-ERROR.

      * WS-SUB1 CONTAINS THE NUMBER OF CLIENTS RETURNED
           MOVE WS-SUB1                 TO WS-INSRD-QTY-DISPLAY.
           MOVE WS-INSRD-QTY-DISPLAY-R  TO MIR-DV-POL-INSRD-QTY.

       2000-LIST-X.
           EXIT.
      /
      *-----------------------
       2010-BROWSE-TABLE-CVGC.
      *-----------------------

      * ADD CLIENT TO ARRAY:  THIS ROUTINE WILL ADD NEW CLIENTS TO
      * THE NEXT AVAILABLE POSITION IN THE CLIENT ARRAY. WHEN THE
      * CLIENT ALREADY EXISTS IN THE ARRAY IT WILL BE ADDED IN THE
      * SAME PLACE.

           PERFORM
            VARYING WS-SUB FROM 1 BY 1
              UNTIL WS-SUB  >  WS-SUB1
                 OR MIR-INSRD-CLI-ID-T (WS-SUB) =
                                     RCVGC-INSRD-CLI-ID
015543         CONTINUE
           END-PERFORM.

      *
           IF  WS-SUB > WS-MAX-LIST-LINES
               MOVE WS-MAX-LIST-LINES TO WS-SUB1
               SET WCVGC-IO-EOF       TO TRUE
      *        SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG: MORE DATA EXISTS
               MOVE 'XS00000014'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2010-BROWSE-TABLE-CVGC-X
           END-IF.


      *
      * NEW CLIENT, ADD TO ALREADY IN ARRAY
      *
           IF  WS-SUB  GREATER THAN WS-SUB1
               MOVE WS-SUB             TO WS-SUB1
               MOVE RCVGC-INSRD-CLI-ID TO MIR-INSRD-CLI-ID-T (WS-SUB1)
           END-IF.


           PERFORM  7020-BUILD-KEY-PD
               THRU 7020-BUILD-KEY-PD-X.

           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.

           IF  WPD-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPD-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WS-ERROR       TO TRUE
               GO TO 2010-BROWSE-TABLE-CVGC-X
           END-IF.

           IF  MIR-PLAN-UWG-IND-T(WS-SUB) = 'Y'
           OR  RPD-PLAN-UWG-REQIR
               MOVE 'Y' TO MIR-PLAN-UWG-IND-T (WS-SUB)
           ELSE
               MOVE 'N' TO MIR-PLAN-UWG-IND-T (WS-SUB)
           END-IF.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       2010-BROWSE-TABLE-CVGC-X.
           EXIT.
      /
      *--------------------------
       2020-PROCESS-INSURED-LIST.
      *--------------------------

           PERFORM  8000-GET-CLIENT-INFO
               THRU 8000-GET-CLIENT-INFO-X.

       2020-PROCESS-INSURED-LIST-X.
           EXIT.
      /
      *-------------------
       7000-BUILD-KEY-POL.
      *-------------------

           MOVE LOW-VALUES            TO WPOL-KEY.

           MOVE MIR-POL-ID            TO WPOL-POL-ID.

       7000-BUILD-KEY-POL-X.
           EXIT.
      /
      *--------------------
       7010-BUILD-KEY-CVGC.
      *--------------------

           MOVE LOW-VALUES             TO WCVGC-KEY.
           MOVE HIGH-VALUES            TO WCVGC-ENDBR-KEY.

           MOVE MIR-POL-ID             TO WCVGC-POL-ID.
           MOVE WCVGC-POL-ID           TO WCVGC-ENDBR-POL-ID.

       7010-BUILD-KEY-CVGC-X.
           EXIT.
      /
      *------------------
       7020-BUILD-KEY-PD.
      *------------------

           MOVE LOW-VALUES                      TO WPD-KEY.

           MOVE WCVGS-PLAN-ID (RCVGC-CVG-NUM-N) TO WPD-PLAN-ID.

       7020-BUILD-KEY-PD-X.
           EXIT.
      /
      *---------------------
       8000-GET-CLIENT-INFO.
      *---------------------

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-INSRD-CLI-ID-T (WS-SUB2)      TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  L2435-RETRN-OK
               INITIALIZE L0620-INPUT-PARM-INFO
               IF  L2435-CLI-SEX-CD = 'C'
                   MOVE L2435-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2435-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
                   MOVE L2435-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
                   MOVE L2435-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
                   MOVE L2435-CLI-SFX-NM       TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2435-CLI-SEX-CD  TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME TO MIR-DV-INSRD-CLI-NM-T(WS-SUB2)
           ELSE
               MOVE SPACES            TO MIR-DV-INSRD-CLI-NM-T(WS-SUB2)
      *MSG:   'CLIENT RECORD (@1) NOT FOUND'
               MOVE MIR-INSRD-CLI-ID-T (WS-SUB2)  TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000058'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WS-ERROR             TO TRUE
                   GO TO 8000-GET-CLIENT-INFO-X
               END-IF
           END-IF.

           IF  L2435-RETRN-OK
               PERFORM  8100-FORMAT-BTH-DT
                   THRU 8100-FORMAT-BTH-DT-X
           END-IF.

       8000-GET-CLIENT-INFO-X.
           EXIT.
      /
      *-------------------
       8100-FORMAT-BTH-DT.
      *-------------------

           MOVE L2435-CLI-BTH-DT TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE TO MIR-CLI-BTH-DT-T (WS-SUB2)
           ELSE
               MOVE SPACES              TO MIR-CLI-BTH-DT-T (WS-SUB2)
           END-IF.

       8100-FORMAT-BTH-DT-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-INSRD-CLI-ID-G.
           MOVE SPACES                TO MIR-DV-INSRD-CLI-NM-G.
           MOVE SPACES                TO MIR-CLI-BTH-DT-G.
           MOVE SPACES                TO MIR-PLAN-UWG-IND-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID
025970       TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
      /
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY CCCL2435.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL2435.
       COPY CCPS2435.
      /
025970 COPY CCPS0620.
       COPY CCPL0620.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440 COPY CCPS5400.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.
      /
       COPY CCPBCVGC.
016537*COPY CCPNCVGC.
      /
       COPY CCPNPD.
      /
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM8041                     **
      *****************************************************************
