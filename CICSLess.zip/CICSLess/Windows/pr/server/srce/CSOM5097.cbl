      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM5097.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5097                                         **
      **  REMARKS:  2-STAGE AUTOPAY PENDING DRAW HISTORY LIST.       **
      **            THIS PROCESS DRIVER ALLOWS THE USER TO LIST ALL  **
      **            PENDING DRAW HISTORY RECORDS (PDRW).             **
      **                                                             **
      **  DOMAIN :  BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5097'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
       
       COPY XCWEBLCH.
       
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT         VALUE +100.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '5097'.
           05  WS-SUB                                PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY
025970*                                              VALUE 100.
           05  WS-PIC-999                            PIC 999.
           05  WS-INVERTED-DRAW-DATE                 PIC 9(7).
       
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       
       COPY CCFWPDRS.
 
       COPY CCFWPDRW.
       COPY CCFRPDRW.
       
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1660.       
       COPY XCWL0290.      
       
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5097.
       
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5097'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
       
      *------------
       2000-LIST.
      *------------

           IF  MIR-SBSDRY-CO-ID =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-SBSDRY-CO-ID
           END-IF.

           IF  MIR-SBSDRY-CO-ID NOT = SPACES
               PERFORM  2100-BROWSE-WITH-SUBCO
                   THRU 2100-BROWSE-WITH-SUBCO-X
               GO TO 2000-LIST-X
           END-IF.
      
           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PDRW-1000-BROWSE
               THRU PDRW-1000-BROWSE-X.

           PERFORM  PDRW-2000-READ-NEXT
               THRU PDRW-2000-READ-NEXT-X
           
           IF  WPDRW-IO-EOF
      * MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X
               VARYING WS-SUB FROM +1 BY +1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
                    OR WPDRW-IO-EOF.

           IF  WPDRW-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RPDRW-PAC-DRW-IDT-NUM
                                      TO L1660-INVERTED-DATE
               PERFORM  9100-CONVERT-INV-EXT
                   THRU 9100-CONVERT-INV-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PAC-DRW-IDT-NUM
               COMPUTE L0290-INPUT-V00
                     = 1000
                     - RPDRW-PAC-DRW-SEQ-NUM 
               MOVE 0                     TO L0290-PRECISION 
               MOVE LENGTH OF MIR-PAC-DRW-SEQ-NUM
                                      TO L0290-MAX-OUT-LEN 
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRW-SEQ-NUM
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDRW-3000-END-BROWSE
               THRU PDRW-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.
       
      *-----------------------
       2100-BROWSE-WITH-SUBCO.
      *-----------------------
      
           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.
           
           PERFORM  7100-BUILD-KEYS
               THRU 7100-BUILD-KEYS-X.

           PERFORM  PDRS-1000-BROWSE
               THRU PDRS-1000-BROWSE-X.
      
           PERFORM  PDRS-2000-READ-NEXT
               THRU PDRS-2000-READ-NEXT-X
           
           IF  WPDRS-IO-EOF
               PERFORM  PDRS-3000-END-BROWSE
                   THRU PDRS-3000-END-BROWSE-X
               MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-BROWSE-WITH-SUBCO-X
           END-IF.
      
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X
               VARYING WS-SUB FROM +1 BY +1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES      
               OR WPDRS-IO-EOF.
      
           IF  WPDRS-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RPDRW-PAC-DRW-IDT-NUM
                                      TO L1660-INVERTED-DATE
               PERFORM  9100-CONVERT-INV-EXT
                   THRU 9100-CONVERT-INV-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PAC-DRW-IDT-NUM
               COMPUTE L0290-INPUT-V00
                     = 1000
                     - RPDRW-PAC-DRW-SEQ-NUM 
               MOVE 0                     TO L0290-PRECISION 
               MOVE LENGTH OF MIR-PAC-DRW-SEQ-NUM
                                      TO L0290-MAX-OUT-LEN 
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRW-SEQ-NUM
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      
           PERFORM  PDRS-3000-END-BROWSE
               THRU PDRS-3000-END-BROWSE-X.
      
       2100-BROWSE-WITH-SUBCO-X.
           EXIT.
       
      *----------------
       7000-BUILD-KEYS.
      *----------------
       
           MOVE LOW-VALUES            TO WPDRW-KEY.
           MOVE MIR-BNK-ID            TO WPDRW-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WPDRW-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID       TO WPDRW-BNK-ACCT-ID.

           IF  MIR-PAC-DRW-IDT-NUM                   = SPACES
               MOVE ZEROES            TO WPDRW-PAC-DRW-IDT-NUM
           ELSE
               MOVE WS-INVERTED-DRAW-DATE
                                      TO WPDRW-PAC-DRW-IDT-NUM
           END-IF.

           IF  MIR-PAC-DRW-SEQ-NUM IS NUMERIC
               MOVE MIR-PAC-DRW-SEQ-NUM
                                      TO WS-PIC-999
               COMPUTE WPDRW-PAC-DRW-SEQ-NUM
                     = 1000
                     - WS-PIC-999
           ELSE
               MOVE ZEROES            TO WPDRW-PAC-DRW-SEQ-NUM
           END-IF.

           MOVE WPDRW-KEY             TO WPDRW-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPDRW-ENDBR-PAC-DRW-IDT-NUM.
           MOVE 999                   TO WPDRW-ENDBR-PAC-DRW-SEQ-NUM.

       7000-BUILD-KEYS-X.
           EXIT.
       
      *----------------
       7100-BUILD-KEYS.
      *----------------
       
           MOVE LOW-VALUES            TO WPDRS-KEY.
           MOVE MIR-BNK-ID            TO WPDRS-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WPDRS-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID       TO WPDRS-BNK-ACCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WPDRS-SBSDRY-CO-ID.
      
           IF  MIR-PAC-DRW-SEQ-NUM IS NUMERIC
               MOVE MIR-PAC-DRW-SEQ-NUM
                                      TO WS-PIC-999
               COMPUTE WPDRS-PAC-DRW-SEQ-NUM
                     = 1000 - WS-PIC-999
           ELSE
               MOVE ZEROES            TO WPDRS-PAC-DRW-SEQ-NUM
           END-IF.
      
           IF  MIR-PAC-DRW-IDT-NUM                   = SPACES
               MOVE ZEROES            TO WPDRS-PAC-DRW-IDT-NUM
           ELSE
               MOVE WS-INVERTED-DRAW-DATE
                                      TO WPDRS-PAC-DRW-IDT-NUM
           END-IF.
      
           MOVE WPDRS-KEY             TO WPDRS-ENDBR-KEY.
           MOVE 999                   TO WPDRS-ENDBR-PAC-DRW-SEQ-NUM.
           MOVE HIGH-VALUE            TO WPDRS-ENDBR-PAC-DRW-IDT-NUM.
      
       7100-BUILD-KEYS-X.
           EXIT.
       
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES            TO MIR-PAC-DRW-IDT-NUM-G.
           MOVE SPACES            TO MIR-PAC-DRW-SEQ-NUM-G.
           MOVE SPACES            TO MIR-PAC-DRW-TOT-AMT-G.
           MOVE SPACES            TO MIR-PAC-DRW-STAT-CD-G.
           MOVE SPACES            TO MIR-SBSDRY-CO-ID-G.
       
       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      
      *---------------------
       9100-CONVERT-INV-EXT.
      *---------------------

           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.

           MOVE L1660-INTERNAL-DATE   TO L1640-INTERNAL-DATE.

           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.

       9100-CONVERT-INV-EXT-X.
           EXIT.
       
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF RPDRW-PAC-DRW-COLCT-DD2
              AND (RPDRW-PAC-DRW-STAT-TRIGGERED 
              OR RPDRW-PAC-DRW-STAT-WRITTEN)               
              CONTINUE
           ELSE
              IF  MIR-SBSDRY-CO-ID = SPACE
                  PERFORM  PDRW-2000-READ-NEXT
                      THRU PDRW-2000-READ-NEXT-X
              ELSE
                  PERFORM  PDRS-2000-READ-NEXT
                      THRU PDRS-2000-READ-NEXT-X
              END-IF
              SUBTRACT 1 FROM WS-SUB 
              GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.
              
           MOVE RPDRW-PAC-DRW-IDT-NUM TO L1660-INVERTED-DATE.

           PERFORM  9100-CONVERT-INV-EXT
               THRU 9100-CONVERT-INV-EXT-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-PAC-DRW-IDT-NUM-T (WS-SUB).

           COMPUTE L0290-INPUT-V00
                  = 1000
                  - RPDRW-PAC-DRW-SEQ-NUM. 
           MOVE 0                     TO L0290-PRECISION. 
           MOVE LENGTH OF MIR-PAC-DRW-SEQ-NUM-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN. 
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRW-SEQ-NUM-T (WS-SUB).
           
           IF  WS-SUB = 1
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PAC-DRW-IDT-NUM
               MOVE WS-PIC-999        TO MIR-PAC-DRW-SEQ-NUM
           END-IF.

           MOVE RPDRW-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T (WS-SUB).

           MOVE RPDRW-PAC-DRW-TOT-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRW-TOT-AMT-T (WS-SUB).

           MOVE RPDRW-PAC-DRW-STAT-CD TO MIR-PAC-DRW-STAT-CD-T (WS-SUB).

           IF  MIR-SBSDRY-CO-ID = SPACE
               PERFORM  PDRW-2000-READ-NEXT
                   THRU PDRW-2000-READ-NEXT-X
           ELSE
               PERFORM  PDRS-2000-READ-NEXT
                   THRU PDRS-2000-READ-NEXT-X
           END-IF.
       
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
       
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
       
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
           SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE ZERO                    TO WS-SUB.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970*    MOVE +100                    TO WS-MAX-LIST-LINES.
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       
       COPY XCPL0260.
       
       COPY XCPL0290.       
       COPY XCPS0290.       
       
025970 COPY XCPS1640.
       COPY XCPL1640.
       
025970 COPY XCPS1660.      
       COPY XCPL1660.      
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       
       COPY CCPBPDRW.
       COPY CCPBPDRS.
       
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM5097
      *****************************************************************

