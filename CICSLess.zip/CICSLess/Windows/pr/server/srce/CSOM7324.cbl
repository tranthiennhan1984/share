      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7324.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7324                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE PDBG TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
025970**  6.6       WORKING STORAGE INITIALISATION                   **     
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7324'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-CONSTANT-FIELDS.
025970*       10  WS-MAX-LIST-LINES           PIC 9(3) VALUE 50.
025970        10  WS-MAX-LIST-LINES             PIC 9(3).
025970            88  WS-MAX-LIST-LINES-DEFAULT VALUE 50.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID               PIC X(04).
                   88  WS-BUS-FCN-LIST         VALUE '7324'.
               10  WS-SUB                      PIC 9(3).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPDBG.
       COPY CCFRPDBG.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7324.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7324'        TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'      TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PDBG-1000-BROWSE
               THRU PDBG-1000-BROWSE-X.

           PERFORM  PDBG-2000-READ-NEXT
               THRU PDBG-2000-READ-NEXT-X.

           IF  WPDBG-IO-EOF
               PERFORM  PDBG-3000-END-BROWSE
                   THRU PDBG-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                       TO WS-SUB.
           PERFORM  2010-BROWSE-PDBG
               THRU 2010-BROWSE-PDBG-X
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WPDBG-IO-EOF.

           IF  WPDBG-IO-EOF
      *MSG: *** END OF LIST ***
               MOVE 'CS00000023'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
               MOVE RPDBG-PLAN-ID            TO MIR-PLAN-ID
               MOVE RPDBG-LOC-GR-ID          TO MIR-LOC-GR-ID
               MOVE RPDBG-PLAN-DBG-TYP-CD    TO MIR-PLAN-DBG-TYP-CD
           END-IF.

           PERFORM  PDBG-3000-END-BROWSE
               THRU PDBG-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-PDBG.
      *-----------------

           ADD 1                    TO WS-SUB.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PDBG-2000-READ-NEXT
               THRU PDBG-2000-READ-NEXT-X.

       2010-BROWSE-PDBG-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES            TO WPDBG-KEY.
           MOVE HIGH-VALUES           TO WPDBG-ENDBR-KEY.

           MOVE MIR-PLAN-ID           TO WPDBG-PLAN-ID.
           MOVE MIR-PLAN-ID           TO WPDBG-ENDBR-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPDBG-LOC-GR-ID.

           IF MIR-LOC-GR-ID NOT = SPACE
              MOVE MIR-PLAN-DBG-TYP-CD  TO WPDBG-PLAN-DBG-TYP-CD
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  WS-SUB > WS-MAX-LIST-LINES
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           MOVE RPDBG-PLAN-ID
             TO MIR-PLAN-ID-T (WS-SUB).

           MOVE RPDBG-LOC-GR-ID
             TO MIR-LOC-GR-ID-T (WS-SUB).

           MOVE RPDBG-PLAN-DBG-TYP-CD
             TO MIR-PLAN-DBG-TYP-CD-T (WS-SUB).

           MOVE RPDBG-PLAN-DBG-BASIC-CD
             TO MIR-PLAN-DBG-BASIC-CD-T (WS-SUB).

           MOVE RPDBG-PLAN-DBG-LOAN-IND
             TO MIR-PLAN-DBG-LOAN-IND-T (WS-SUB).

           MOVE RPDBG-PLAN-DBG-FCT-CD
             TO MIR-PLAN-DBG-FCT-CD-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *-------------------------
       9990-INIT-WORKING-STORAGE.
      *-------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-FIELDS.
025970           
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE. 
           
025970     MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBPDBG.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM7324
      *****************************************************************
