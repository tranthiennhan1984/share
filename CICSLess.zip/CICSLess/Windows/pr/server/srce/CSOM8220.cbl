      *------------------------
       IDENTIFICATION DIVISION.
      *------------------------
      *
       COPY XCWWCRHT.
      *
       PROGRAM-ID. CSOM8220.
      *
      *****************************************************************
      **  MEMBER :  CSOM8220                                         **
      **  REMARKS:  PTRX - PROCESS POLICY TRANSACTIONS               **
      **                                                             **
      **            THIS MODULE IS USED TO PROCESS SURRENDERS FOR    **
      **            CASH VALUE ANNUITIES AND SEGREGATED FUNDS AND    **
      **            TRANSFERS FOR SEGREGATED FUNDS.  THESE TRANSACT- **
      **            IONS ARE PROCESSED AT THE POLICY LEVEL.          **
      **                                                             **
      **            THERE ARE SEVEN METHODS OF ALLOCATING THE        **
      **            SURRENDER, INCLUDING SURRENDER OF A SPECIFIC     **
      **            NUMBER OF UNITS. SURRENDER LOADS CAN BE FORCED   **
      **            ON THE SCREEN, OR THEY CAN BE CALCULATED.        **
      **            TAX WITHHOLDING CAN BE BYPASSED IF DESIRED.      **
      **                                                             **
      **            THERE ARE THREE METHODS OF ALLOCATING THE        **
      **            TRANSFER FROM ONE FUND TO THE OTHER:             **
      **            AMOUNT TO AMOUNT; AMOUNT TO PERCENTAGE           **
      **            ALLOCATIONS; AND FUND PERCENTAGES TO PERCENTAGE  **
      **            ALLOCATIONS. LOADS CAN EITHER BE FORCED BY THE   **
      **            USER OR CALCULATED BY THE MODULE.                **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
012137**  5.6V      PROGRAM CREATED.                                 **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
013693**  6.2       SEND AN INDICATOR TO LOCATION TAX ROUTINE        **
014221**  6.2       LOGICAL LOCKING                                  **
015905**  6.2       REPLACE DV FIELD WITH ALLOWED VALUE SUBSETS      **
016392**  6.2       SETUP INDICATOR TO FORCE ZERO TRANSFER FEE       **
016440**  6.2       ADDITION OF POLICY TRANSFER EDITS                **
016503**  6.2       FILL IN REQUIRED PARAMETERS FOR SCHEDULER        **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016848**  6.2       POPULATE FROM/TO FIELDS                          **
018323**  6.2       SUPPRESS REDUNDANT MESSAGES                      **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
016107**  6.3       AUTO FACE REDUCTION (6.1.2J)                     **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
016109**  6.3       FREE FUND TRANSFERS (6.1.2J)                     **
016153**  6.3       SUPPRESS MESSAGE FOR DEFERRED TRANSACTION        **
017150**  6.3       CURRENCY SCALING (6.1.2J)                        **
018731**  6.3       EFT ENHANCEMENTS                                 **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018840**  6.3       POLICY FINANCIAL ACTIVITY FLOW                   **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
018558**  6.4       GET DEFAULT INSTRUCTION AT CONFIRM               **
019360**  6.4       SPECIAL LTAXWH CALC CODE FOR SURRENDER           **
019806**  6.4       BYPASS TAX FOR RRIF TRANSFER                     **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020463**  6.4       INVESTOR PROFILES                                **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021239**  6.4       FUND UNIT VALUE                                  **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
022210**  6.5       BYPASS TAX EDIT FOR QUALIFIED PLAN               **
022628**  6.5       TAX IS WITHHELD PER COVERAGE                     **
022917**  6.5       INTRA-POLICY TRANSFER PROCESSING                 **
023032**  6.5       BYPASS TAX FOR REGISTERED POLICY TRANSFERS       **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023444**  6.5       QUOTE INCOME ON WITHDRAWALS                      **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024550**  6.5       UNABLE TO OVERRIDE LOCATION TAX ON REG POLICY    **
025278**  6.5       INITIALIZATION OF LFUND-PARM-INFO                **
020478**  6.6       FUTURE DATED TRANSACTION                         **
024958**  6.6       RETAIN LTAXWH INSTRUCTIONS ON DEFERRAL           **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028065**  6.6       PGAL OUT OF SYNCH AFTER AUTOMATIC UNDO/REDO      **
028261**  6.6       LOCATION TAX REQUEST PERCENT BLANKED OUT         **
021056**  6.7       INCORRECT SIGN ON SEG FUND TRANSFER SCREEN       **
023629**  6.7       TRANSFER OUT PERCENTAGE TRUNCATED                **
028788**  6.7       EXTERNAL AGENCY INTEGRATION - POLICY EVENTS      **
031034**  7.0       TAX COMPONENTIZATION                             **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
031065**  7.0       FUND VALUE DISPLAY NO SIGN FOR NEGATIVE AMOUNT   **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       ENVIRONMENT DIVISION.
      *---------------------
       DATA DIVISION.
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8220'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *
       COPY SQLCA.
018764*COPY XCWLPTR.
      *
      *
014590*COPY XCWL0030.
019360 COPY XCWEBLCH.
      *
       01  WS-CONSTANTS.
016548*    05  WS-MAX-LINES-GUI              PIC S9(04) COMP VALUE 30.
025970*    05  WS-MAX-LINES-GUI              PIC S9(04) BINARY VALUE 30.
025970
016548*    05  WS-MAX-LINES-3270             PIC S9(04) COMP VALUE 15.
025970*    05  WS-MAX-LINES-3270             PIC S9(04) BINARY VALUE 15.
025970
016548*    05  WS-LINE-CNT                   PIC S9(04) COMP.
025970*    05  WS-LINE-CNT                   PIC S9(04) BINARY.
025970
025970     05  WS-TWRK-KEY                   PIC X(04).
020478*        88 WS-TWRK-KEY-DEFAULT        VALUE '1140'.
020478         88 WS-TWRK-KEY-DEFAULT        VALUE '1141'.
      *
       01  WS-WORK-FIELDS.
020469     05  WS-POL-CRCY-CD                PIC X(02)  VALUE SPACES.
016548*    05  K                             PIC S9(04) COMP.
016548     05  K                             PIC S9(04) BINARY.
016548*    05  J                             PIC S9(04) COMP.
016548     05  J                             PIC S9(04) BINARY.
016548*    05  I                             PIC S9(04) COMP.
016548     05  I                             PIC S9(04) BINARY.
016503     05  WS-SWITCHES.
016503         10  WS-REDO-SW                PIC X(01).
016503             88  WS-REDO-OK                  VALUE 'Y'.
016503             88  WS-REDO-NOT-OK              VALUE 'N'.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID             PIC X(04).
                   88  WS-BUS-FCN-ID-VALID         VALUE
020478*                '1140' '1141' '1142' '1143' '1144' '1145' '1146'
020478*                '1147' '1148' '1149'.
020478                 '1141' '1143' '1144' '1145' '1146' '1147' '1149'.
                   88  WS-BUS-FCN-SURRENDER        VALUE
020478*                '1140' '1141' '1142' '1143' '1144' '1145' '1146'.
020478                 '1141' '1143' '1144' '1145' '1146'.
020478*            88  WS-SURR-FND-CNTRCT-DFLT     VALUE '1140'.
                   88  WS-SURR-PRO-RATA            VALUE '1141'.
020478*            88  WS-SURR-BY-AMOUNT           VALUE '1142'.
                   88  WS-SURR-BY-PERCENT          VALUE '1143'.
                   88  WS-SURR-BY-PERCENT-TOT-VAL  VALUE '1144'.
                   88  WS-SURR-BY-PERCENT-FND-VAL  VALUE '1145'.
                   88  WS-SURR-BY-NO-OF-UNITS      VALUE '1146'.
                   88  WS-BUS-FCN-TRANSFER         VALUE
020478*                '1147' '1148' '1149'.
020478                 '1147' '1149'.
                   88  WS-TSFR-AMT-TO-AMT          VALUE '1147'.
020478*            88  WS-TSFR-AMT-TO-PCT          VALUE '1148'.
                   88  WS-TSFR-PCT-TO-PCT          VALUE '1149'.
020478*            88  WS-SURR-TWO-STEP            VALUE '1140' '1141'
020478             88  WS-SURR-TWO-STEP            VALUE '1141'
                                                         '1144'.
025970*        10  WS-TWRK-KEY                     PIC X(04)
025970*                                            VALUE '1140'.
               10  WS-ALLOC-CD                     PIC X(01).
               10  WS-DEST-CODE                    PIC X(01).
                   88  WS-VALID-DEST-CODE          VALUE
018731*                 'C' 'D' 'M' 'P'.
018731                 'C' 'D' 'E' 'M' 'P'.
                   88  WS-DEST-CHECK               VALUE 'C'.
                   88  WS-DEST-OS-DISB             VALUE 'D'.
018731             88  WS-DEST-EFT                 VALUE 'E'.
                   88  WS-DEST-MISC-SUSP           VALUE 'M'.
                   88  WS-DEST-PREM-SUSP           VALUE 'P'.
                   88  WS-DEST-NOT-APP             VALUE 'N'.
               10  WS-REASN-CODE                   PIC X(03).
                   88  WS-REASN-GRS                VALUE 'GRS'.
                   88  WS-REASN-NET                VALUE 'NET'.
013697             88  WS-REASN-CNT                VALUE 'CNT'.
                   88  WS-REASN-NOT-APP            VALUE 'N/A'.
                   88  WS-VALID-REASN-CODE         VALUE
013697*                'GRS' 'NET' 'N/A' SPACES.
013697                 'GRS' 'NET' 'CNT' 'N/A' SPACES.
               10  WS-SOURCE-CODE                  PIC X(01).
                   88  WS-VALID-SOURCE-CODE        VALUE
                        'C' SPACE.
                   88  WS-SOURCE-CHARGE       VALUE 'C'.
           05  WS-POL-ID.
               10  WS-POLNO                   PIC X(09).
               10  WS-SUFF                    PIC X(01).
           05  WS-EFF-DT                      PIC X(10).
021239*    05  WS-WORK-UNITS                  PIC S9(09)V9(09) COMP-3.
021239     05  WS-WORK-UNITS                  PIC S9(12)V9(06) COMP-3.
           05  WS-ZERO-AMT                    PIC X(16).
           05  WS-TRXN-AMT                    PIC S9(13)V99 COMP-3.
           05  WS-WORK-AMT                    PIC S9(13)V99 COMP-3.
           05  WS-TOTAL-AMT                   PIC S9(13)V99 COMP-3.
           05  WS-AMT-FROM                    PIC S9(13)V99 COMP-3.
           05  WS-AMT-TO                      PIC S9(13)V99 COMP-3.
           05  WS-WORK-PCT                    PIC S9(3)V9(4) COMP-3.
023629*    05  WS-PCT-FROM                    PIC S9(3)V9(4) COMP-3.
023629     05  WS-PCT-FROM                    PIC S9(5)V9(4) COMP-3.
           05  WS-PCT-TO                      PIC S9(3)V9(4) COMP-3.
           05  WS-ZERO-PCT                    PIC X(08).
           05  WS-POFVAL                      PIC S9(3)V9(4) COMP-3.
           05  WS-PERCENT-TOTAL               PIC S9(3)V9(4) COMP-3.
           05  WS-LOCPCT                     PIC S9(15)V9(03).
           05  WS-LOCAMT                     PIC S9(14)V9(04).
           05  WS-FEDAMT                     PIC S9(14)V9(04).
           05  WS-SCONF-CD                   PIC X(01).
               88  WS-SCONF-VALID            VALUE SPACE, 'Y', 'N'.
               88  WS-SCONF-YES              VALUE 'Y'.
               88  WS-SCONF-NO               VALUE 'N'.
016548*    05  WS-CVG-NUM                     PIC S9(04) COMP.
016548     05  WS-CVG-NUM                     PIC S9(04) BINARY.
016503     05  WS-MSG-SUPPRESS-SW             PIC X(01).
016503         88  WS-MSG-SUPPRESS            VALUE 'Y'.
023444     05  WS-POL-TAX-ACB-AMT             PIC S9(13)V99.
023444     05  WS-TOT-SURR-AMT                PIC S9(13)V99.
023437     05  WS-FED-TAXWH-RQST-AMT          PIC S9(11)V99.
023437     05  WS-FED-TAXWH-RQST-PCT          PIC S9(03)V9(02).
      *
       01  WS-TWRK-WORK-AREA.
           05  WS-TWRK-WORK-AREA-ID.
               10  WS-CTL-NAME-TERM-ID        PIC X(04).
025970*        10  WS-CTL-NAME-MNEMONIC       PIC X(03) VALUE 'FND'.
025970         10  WS-CTL-NAME-MNEMONIC            PIC X(03).
025970             88 WS-CTL-NAME-MNEMONIC-DEFAULT VALUE 'FND'.
               10  WS-TPI-QUEUE-SESSION-IND   PIC X(01).

           05  WS-TWRK-ITEM.
               10  WS-FUND-FND-INFO.
                   15  WS-FUND-CVG-NUM         PIC X(02).
                   15  WS-FUND-CVG-NUM-N       REDEFINES
                   WS-FUND-CVG-NUM             PIC 9(02).
                   15  WS-FUND-FND-ID          PIC X(05).
                   15  WS-FUND-FND-ACUM-AMT    PIC S9(13)V9(02) COMP-3.
                   15  WS-FUND-ALLOC-CD        PIC X(01).
                   88  WS-FUND-ALLOC-CD-VALID  VALUES SPACE
                        'A' 'P' 'U'.
                   88  WS-FUND-ALLOC-AMOUNT    VALUE 'A'.
                   88  WS-FUND-ALLOC-PERCENT   VALUE 'P'.
                   88  WS-FUND-ALLOC-UNITS     VALUE 'U'.
                   15  WS-FUND-ALLOC-AMT       PIC S9(13)V9(02) COMP-3.
                   15  WS-FUND-ALLOC-PCT       PIC S9(03)V9(04) COMP-3.
021239*            15  WS-FUND-ALLOC-UNIT-QTY  PIC S9(09)V9(09) COMP-3.
021239             15  WS-FUND-ALLOC-UNIT-QTY  PIC S9(12)V9(06) COMP-3.
              10  WS-8180-FNDVL-INFO.
                  15  WS-8180-CFN-CALC-CD      PIC X(01).
                  88  WS-8180-CFN-CALC-APROX    VALUE 'A'.
                  88  WS-8180-CFN-CALC-EXACT    VALUE 'E'.
                  15  WS-8180-CFN-CV-AMT       PIC S9(13)V99 COMP-3.
021239*           15  WS-8180-CFN-UNIT-QTY     PIC S9(09)V9(09) COMP-3.
021239            15  WS-8180-CFN-UNIT-QTY     PIC S9(12)V9(06) COMP-3.
      *
025970 01  WS-INDICATORS.
025970
025970* 01  WS-SIDE-FND-EXHAUSTED-IND           PIC X(01).
025970     05  WS-SIDE-FND-EXHAUSTED-IND        PIC X(01).
018846         88  WS-SIDE-FND-EXHAUSTED        VALUE 'Y'.
018846         88  WS-SIDE-FND-EXHAUSTED-NO     VALUE 'N'.
025970
025970*01  WS-REG-FND-WITHDRAWAL-IND            PIC X(01).
025970     05  WS-REG-FND-WITHDRAWAL-IND        PIC X(01).
018846         88  WS-REG-FND-WITHDRAWAL        VALUE 'Y'.
018846         88  WS-REG-FND-WITHDRAWAL-NO     VALUE 'N'.
025970
025970 01  WS-TYP-CDS.
025970
025970*01  WS-FROM-FND-TYP                      PIC X(01).
025970     05  WS-FROM-FND-TYP-CD               PIC X(01).
018846         88  WS-FROM-FND-TYP-SIDE         VALUE 'S'.
018846         88  WS-FROM-FND-TYP-REG          VALUE 'R'.
018846         88  WS-FROM-FND-TYP-BOTH         VALUE 'B'.
025970
025970*01  WS-TO-FND-TYP                        PIC X(01).
025970     05  WS-TO-FND-TYP-CD                 PIC X(01).
018846         88  WS-TO-FND-TYP-SIDE           VALUE 'S'.
018846         88  WS-TO-FND-TYP-REG            VALUE 'R'.
018846         88  WS-TO-FND-TYP-BOTH           VALUE 'B'.

       COPY CCFHPOL.
      *
016537*COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      *
       COPY XCWWWKDT.
020478 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL1640.
014221 COPY XCWL8090.
023437 COPY XCWL0316.
      *
013578 COPY CCWL0620.
      *
018846 COPY CCWL0182.
018846
016108 COPY CCWL0985.
016108*
       COPY CCWL2430.
016503 COPY CCWL0201.
016503 COPY CCWL0289.
016503 COPY CCWL4780.
020463 COPY CCWL2735.
      *
       COPY CCWL5400.
      *
031034*COPY CCWLPGAL.
015290
023437 COPY CCWLTAXC.
016537*COPY SCFWFR.
016537*COPY SCFRFR.
      *
016537*COPY SCFWFH.
016537*COPY SCFRFH.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
013578*
013578 COPY CCFWEDIT.
013578 COPY CCFREDIT.
      *
       COPY CCFWPOL.
      *
016537*COPY XCFWTWRK.
016537*COPY XCFRTWRK.
      *
017150 COPY XCWL0279.
017150*
       COPY XCWL0280.
      *
       COPY XCWL0290.
      *
020469 COPY XCWL8640.
020469
023437 COPY XCWL8960.
023437*
       COPY FCWL8200.
      *
       COPY FCWL8140.
      *
       COPY FCWL8150.
      *
       COPY FCWL8180.
      *
       COPY FCWLFUND.
      *
       COPY CCWL4750.
      *
018731 COPY CCWL4382.
018731*
      *01  WGLOB-GLOBAL-AREA.
      *
       COPY CCWLPGA.
      *
       COPY CCFRPOL.
      *
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8220.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM   ABND-1000-HANDLE-ABEND
026070*        THRU  ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
023118*    INITIALIZE WS-WORK-FIELDS.
      *
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
           PERFORM 2100-EDIT-KEY-FIELDS
              THRU 2100-EDIT-KEY-FIELDS-X.
      *
           IF WGLOB-MSG-ERROR-SW > ZERO
014221     OR MIR-RETRN-TS-MISMATCH
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.
      *
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034*
           PERFORM 2300-INITIALIZE-WORK-AREAS
              THRU 2300-INITIALIZE-WORK-AREAS-X.
      *
           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
           EVALUATE TRUE
               WHEN WS-BUS-FCN-SURRENDER
                   PERFORM 3000-PROCESS-SURRENDER
                      THRU 3000-PROCESS-SURRENDER-X
               WHEN WS-BUS-FCN-TRANSFER
                   PERFORM 4000-PROCESS-TRANSFER
                      THRU 4000-PROCESS-TRANSFER-X
               WHEN OTHER
                   SET MIR-RETRN-INVALD-RQST TO TRUE
                   MOVE 'CS82200002'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
           END-EVALUATE.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *---------------------
       2100-EDIT-KEY-FIELDS.
      *---------------------
      *
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
           MOVE MIR-POL-ID-BASE       TO WS-POLNO.
           MOVE MIR-POL-ID-SFX        TO WS-SUFF.
           MOVE WS-POL-ID             TO WPOL-POL-ID.
014221*    PERFORM POL-1000-READ
014221*       THRU POL-1000-READ-X.
      *
014221     IF  NOT MIR-DV-PRCES-STATE-CD = '3'
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
014221     ELSE
014221         PERFORM  POL-2000-UPDATE-TWRK-TS
014221             THRU POL-2000-UPDATE-TWRK-TS-X
014221         IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221             MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221             MOVE 'POL'             TO WGLOB-MSG-PARM (01)
014221             MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
014221             PERFORM  0260-1000-GENERATE-MESSAGE
014221                  THRU 0260-1000-GENERATE-MESSAGE-X
014221              GO TO 2100-EDIT-KEY-FIELDS-X
014221         ELSE
014221              IF  WPOL-IO-OK
014221                  PERFORM  POL-3000-UNLOCK
014221                      THRU POL-3000-UNLOCK-X
014221              END-IF
014221         END-IF
014221     END-IF.

      *
           IF NOT WPOL-IO-OK
      * MSG:  POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-EDIT-KEY-FIELDS-X
           END-IF.
      *
      *  DO POLICY ACCESS CHECKS
      *
           PERFORM 5400-1000-BUILD-PARM-INFO
              THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD   TO TRUE.

           PERFORM 5400-1000-POL-CHK
              THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-CRCY-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
           OR L5400-STAT-ACCS-RESTRICTED
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 2100-EDIT-KEY-FIELDS-X
           END-IF.
      *
           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
      *
           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 2100-EDIT-KEY-FIELDS-X
           END-IF.
      *
           IF  NOT RPOL-POL-STAT-IN-FORCE
               MOVE 'SS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE RPOL-POL-ID                   TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         SET MIR-RETRN-EDIT-ERROR       TO TRUE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.

           MOVE MIR-CIA-EFF-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-NOT-VALID
      * MESSAGE - INVALID EFFECTIVE DATE - REENTER
               MOVE 'CS82200004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WS-EFF-DT
           END-IF.
      *
      *
           IF WS-EFF-DT < RPOL-POL-ISS-EFF-DT
      * MESSAGE - EFFECTIVE DATE CANNOT PRECEDE POLICY ISSUE DATE
               MOVE 'CS82200005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WS-EFF-DT             TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE '1'               TO WGLOB-RETURN-CODE
016108         GO TO 2100-EDIT-KEY-FIELDS-X
016108     END-IF.
016108*
           IF MIR-DV-POL-SURR-AMT = SPACES
               MOVE ZERO              TO MIR-DV-POL-SURR-AMT
           END-IF.
      *
           MOVE MIR-DV-POL-SURR-AMT   TO L0280-INPUT-DATA
           SET L0280-SIGN-NOT-PERMITTED TO TRUE
           MOVE 2                     TO L0280-PRECISION
           MOVE LENGTH OF MIR-DV-POL-SURR-AMT
                                      TO L0280-INPUT-SIZE
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X
      *
           IF L0280-OK
               MOVE  L0280-OUTPUT     TO L0290-INPUT-NUMBER
               MOVE  2                TO L0290-PRECISION
               MOVE LENGTH OF MIR-DV-POL-SURR-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-SURR-AMT
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-TRXN-AMT
               EVALUATE TRUE
020478*          WHEN WS-SURR-FND-CNTRCT-DFLT
                 WHEN WS-SURR-PRO-RATA
020478*          WHEN WS-SURR-BY-AMOUNT
                 WHEN WS-SURR-BY-PERCENT
                   IF WS-TRXN-AMT = ZERO
                       MOVE WS-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
      * MESSAGE - AMOUNT MUST EXCEED ZERO FOR ENTER CODE (@1)
                       MOVE 'CS82200037'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   END-IF
                 WHEN WS-SURR-BY-PERCENT-TOT-VAL
                 WHEN WS-SURR-BY-PERCENT-FND-VAL
                 WHEN WS-SURR-BY-NO-OF-UNITS
                 WHEN WS-BUS-FCN-TRANSFER
                 WHEN WS-TSFR-AMT-TO-AMT
020478*          WHEN WS-TSFR-AMT-TO-PCT
                 WHEN WS-TSFR-PCT-TO-PCT
                   IF WS-TRXN-AMT > ZERO
                       MOVE WS-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
      * MESSAGE - AMOUNT MUST BE ZERO FOR ENTER CODE (@1)
                       MOVE 'CS82200038'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   END-IF
               END-EVALUATE
           ELSE
      * MESSAGE - INVALID AMOUNT - REENTER
               MOVE 'CS82200006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
           IF MIR-DV-OUT-ALLOC-PCT = SPACES
               MOVE ZERO              TO MIR-DV-OUT-ALLOC-PCT
           END-IF.
      *
           MOVE MIR-DV-OUT-ALLOC-PCT  TO L0280-INPUT-DATA
           SET L0280-SIGN-NOT-PERMITTED TO TRUE
           MOVE 3                     TO L0280-LENGTH
           MOVE 4                     TO L0280-PRECISION
           MOVE 8                     TO L0280-INPUT-SIZE
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-V04  TO WS-POFVAL
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
               MOVE  4                TO L0290-PRECISION
               MOVE LENGTH OF MIR-DV-OUT-ALLOC-PCT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-DV-OUT-ALLOC-PCT
               IF WS-SURR-BY-PERCENT-TOT-VAL
               AND WS-POFVAL = ZERO
      * MESSAGE - INVALID % OF VALUE - MUST BE > ZERO FOR ENTER CODE 'E'
                   MOVE 'CS82200034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
      * MESSAGE - INVALID % OF VALUE - REENTER
               MOVE 'CS82200007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
           IF MIR-CIA-LOAD-AMT = SPACES
               MOVE ZERO              TO MIR-CIA-LOAD-AMT
           END-IF.
      *
           MOVE MIR-CIA-LOAD-AMT      TO L0280-INPUT-DATA
           SET L0280-SIGN-NOT-PERMITTED TO TRUE
           MOVE 2                     TO L0280-PRECISION
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0280-INPUT-SIZE
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X
           IF L0280-OK
               MOVE  L0280-OUTPUT     TO L0290-INPUT-NUMBER
               MOVE  2                TO L0290-PRECISION
               MOVE  LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE  L0290-OUTPUT-DATA               TO MIR-CIA-LOAD-AMT
           ELSE
      * MESSAGE - INVALID CHARGE AMOUNT - REENTER
               MOVE 'CS82200008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
023437*    IF MIR-CIA-TAXWH-IND = SPACES
023437*        MOVE 'N'               TO MIR-CIA-TAXWH-IND
023437*    END-IF.
023437*    IF MIR-CIA-TAXWH-IND = 'Y'
023437*    OR MIR-CIA-TAXWH-IND = 'N'
023437*        CONTINUE
023437*    ELSE
023437* MESSAGE - TAX BYPASS MUST CONTAIN VALUES 'Y' OR 'N'
023437*        MOVE 'CS82200017'      TO WGLOB-MSG-REF-INFO
023437*        PERFORM  0260-1000-GENERATE-MESSAGE
023437*            THRU 0260-1000-GENERATE-MESSAGE-X
023437*    END-IF.
      *
016107     IF NOT MIR-DV-REDC-FACE-OVRID
016107         MOVE 'N'               TO MIR-DV-REDC-FACE-IND
016107     END-IF.
      *
029060*    IF MIR-FED-TAXWH-CALC-CD = SPACES
029060*    OR MIR-FED-TAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
029060*        MOVE 'C'               TO MIR-FED-TAXWH-CALC-CD
029060*    END-IF.
029060
029060     IF  MIR-FTAXWH-RQST-CD = SPACES
029060     OR  MIR-FTAXWH-RQST-CD = EBLCH-BLANK-FIELD-CHAR
029060         MOVE 'C'               TO MIR-FTAXWH-RQST-CD
029060     END-IF.
023437
029060*    IF MIR-LTAXWH-CALC-CD = SPACES
029060*    OR MIR-LTAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
029060*        MOVE 'C'               TO MIR-LTAXWH-CALC-CD
029060*    END-IF.
029060*    IF MIR-LTAXWH-CALC-CD = 'S'
029060*    OR MIR-LTAXWH-CALC-CD = 'C'
029060*    OR MIR-LTAXWH-CALC-CD = 'B'
029060
029060     IF  MIR-LTAXWH-RQST-CD = SPACES
029060     OR  MIR-LTAXWH-RQST-CD = EBLCH-BLANK-FIELD-CHAR
029060         MOVE 'C'               TO MIR-LTAXWH-RQST-CD
029060     END-IF.
029060
029060     IF  MIR-LTAXWH-RQST-CD = 'S'
029060     OR  MIR-LTAXWH-RQST-CD = 'C'
029060     OR  MIR-LTAXWH-RQST-CD = 'B'
013693         CONTINUE
013693     ELSE
013693* MESSAGE - LOCATION TAX OVERRIDE MUST CONTAIN VALUES 'C' OR 'S'
013693         MOVE 'CS82200039'      TO WGLOB-MSG-REF-INFO
013693         PERFORM  0260-1000-GENERATE-MESSAGE
013693             THRU 0260-1000-GENERATE-MESSAGE-X
013693     END-IF.
013693*
029060*    IF MIR-LTAXWH-PCT = SPACES
029060*        MOVE ZERO              TO MIR-LTAXWH-PCT
029060*    END-IF.
029060
029060     IF  MIR-LTAXWH-RQST-PCT = SPACES
029060         MOVE ZERO              TO MIR-LTAXWH-RQST-PCT
029060     END-IF.
013693 
029060*    MOVE MIR-LTAXWH-PCT     TO L0280-INPUT-DATA.
029060     MOVE MIR-LTAXWH-RQST-PCT       TO L0280-INPUT-DATA.
013693     SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
013693     MOVE 4                         TO L0280-LENGTH.
013693     MOVE 2                         TO L0280-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                    TO L0280-INPUT-SIZE.
013693     PERFORM  0280-1000-NUMERIC-EDIT
013693         THRU 0280-1000-NUMERIC-EDIT-X.
013693     IF L0280-OK
013693         MOVE L0280-OUTPUT-V02      TO WS-LOCPCT
013693         MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
013693         MOVE  2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                    TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-PCT
029060         MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-RQST-PCT
013693         IF WS-LOCPCT > 100
013693         OR WS-LOCPCT < ZERO
013693* MESSAGE - INVALID LOCATION TAX %
013693             MOVE 'CS82200041'        TO WGLOB-MSG-REF-INFO
013693             PERFORM  0260-1000-GENERATE-MESSAGE
013693                 THRU 0260-1000-GENERATE-MESSAGE-X
013693         END-IF
013693     ELSE
013693* MESSAGE - INVALID LOCATION TAX % - REENTER
013693         MOVE 'CS82200042'      TO WGLOB-MSG-REF-INFO
013693         PERFORM  0260-1000-GENERATE-MESSAGE
013693             THRU 0260-1000-GENERATE-MESSAGE-X
013693     END-IF.
013693*
029060*    IF MIR-LTAXWH-FLAT-AMT = SPACES
029060*        MOVE ZERO              TO MIR-LTAXWH-FLAT-AMT
029060*    END-IF.
029060
029060     IF  MIR-LTAXWH-RQST-AMT = SPACES
029060         MOVE ZERO              TO MIR-LTAXWH-RQST-AMT
029060     END-IF.
029060
029060*    MOVE MIR-LTAXWH-FLAT-AMT TO L0280-INPUT-DATA.
029060     MOVE MIR-LTAXWH-RQST-AMT     TO L0280-INPUT-DATA.
013693     SET L0280-SIGN-NOT-PERMITTED TO TRUE.
013693     MOVE 13                      TO L0280-LENGTH.
013693     MOVE 2                       TO L0280-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                               TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                TO L0280-INPUT-SIZE.
013693     PERFORM  0280-1000-NUMERIC-EDIT
013693         THRU 0280-1000-NUMERIC-EDIT-X.
013693*
013693     IF L0280-OK
013693         MOVE L0280-OUTPUT-V02  TO WS-LOCAMT
013693         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
013693         MOVE 2                 TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                               TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA TO MIR-LTAXWH-FLAT-AMT
029060         MOVE L0290-OUTPUT-DATA TO MIR-LTAXWH-RQST-AMT
013693     ELSE
013693* MESSAGE - INVALID LOCATION TAX WITHHELD AMOUNT
013693         MOVE 'CS82200043'      TO WGLOB-MSG-REF-INFO
013693         PERFORM  0260-1000-GENERATE-MESSAGE
013693             THRU 0260-1000-GENERATE-MESSAGE-X
013693     END-IF.
013693
023437*    IF MIR-FED-TAXWH-AMT = SPACES
029060*    IF MIR-CDA-FED-TAXWH-AMT = SPACES
029060
029060     IF  MIR-FTAXWH-AMT = SPACES
023437*        MOVE ZERO              TO MIR-FED-TAXWH-AMT
029060*        MOVE ZERO              TO MIR-CDA-FED-TAXWH-AMT
029060         MOVE ZERO              TO MIR-FTAXWH-AMT
013693     END-IF.
013693
023437*    MOVE MIR-FED-TAXWH-AMT  TO L0280-INPUT-DATA.
029060*    MOVE MIR-CDA-FED-TAXWH-AMT  TO L0280-INPUT-DATA.
029060     MOVE MIR-FTAXWH-AMT         TO L0280-INPUT-DATA.
013693     SET L0280-SIGN-NOT-PERMITTED TO TRUE.
013693     MOVE 13                    TO L0280-LENGTH.
013693     MOVE 2                     TO L0280-PRECISION.
023437*    MOVE LENGTH OF MIR-FED-TAXWH-AMT  TO L0280-INPUT-SIZE.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT  TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT         TO L0280-INPUT-SIZE.
013693     PERFORM  0280-1000-NUMERIC-EDIT
013693         THRU 0280-1000-NUMERIC-EDIT-X.
013693*
013693     IF L0280-OK
013693         MOVE L0280-OUTPUT-V02  TO WS-FEDAMT
013693         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
013693         MOVE  2                TO L0290-PRECISION
023437*        MOVE LENGTH OF MIR-FED-TAXWH-AMT
029060*        MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                               TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-FTAXWH-AMT
029060                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023437*        MOVE L0290-OUTPUT-DATA TO MIR-FED-TAXWH-AMT
029060*        MOVE L0290-OUTPUT-DATA TO MIR-CDA-FED-TAXWH-AMT
029060         MOVE L0290-OUTPUT-DATA TO MIR-FTAXWH-AMT
013693     ELSE
013693* MESSAGE - INVALID FEDERAL TAX WITHHELD AMOUNT
013693         MOVE 'CS82200044'      TO WGLOB-MSG-REF-INFO
013693         PERFORM  0260-1000-GENERATE-MESSAGE
013693             THRU 0260-1000-GENERATE-MESSAGE-X
013693     END-IF.
013693
029060*    IF NOT MIR-LTAXWH-CALC-CD = 'S'
029060*    AND (MIR-LTAXWH-FLAT-AMT > ZERO
029060*    OR   MIR-LTAXWH-PCT > ZERO)
029060* MESSAGE - IF % OR FLAT AMOUNT FILLED IN, LOCATION TAX
029060* MESSAGE - CODE MUST BE STORED
029060*        MOVE 'CS82200047'      TO WGLOB-MSG-REF-INFO
029060*        PERFORM  0260-1000-GENERATE-MESSAGE
029060*            THRU 0260-1000-GENERATE-MESSAGE-X
029060*    END-IF.
029060
029060     IF NOT  MIR-LTAXWH-RQST-CD = 'S'
029060         IF  MIR-LTAXWH-RQST-AMT > ZERO
029060         OR  MIR-LTAXWH-RQST-PCT > ZERO
029060* MESSAGE - IF % OR FLAT AMOUNT FILLED IN, LOCATION TAX
029060* MESSAGE - CODE MUST BE STORED
029060             MOVE 'CS82200047'  TO WGLOB-MSG-REF-INFO
029060             PERFORM  0260-1000-GENERATE-MESSAGE
029060                 THRU 0260-1000-GENERATE-MESSAGE-X
029060         END-IF
029060     END-IF.
013693
029060*    IF  (MIR-LTAXWH-FLAT-AMT > ZERO
029060*    AND  MIR-LTAXWH-PCT > ZERO)
029060     IF   MIR-LTAXWH-RQST-AMT > ZERO
029060     AND  MIR-LTAXWH-RQST-PCT > ZERO
013693* MESSAGE - LOCATION TAX FLAT AMOUNT AND PERCENT CANNOT BOTH
013693* MESSAGE - BE ENTERED
013693         MOVE 'CS82200049'      TO WGLOB-MSG-REF-INFO
013693         PERFORM  0260-1000-GENERATE-MESSAGE
013693             THRU 0260-1000-GENERATE-MESSAGE-X
013693     END-IF.
013693
029060*    IF   MIR-LTAXWH-CALC-CD = 'S'
029060*        IF (MIR-LTAXWH-FLAT-AMT > ZERO
029060*        OR  MIR-LTAXWH-PCT      > ZERO)
029060
029060     IF   MIR-LTAXWH-RQST-CD = 'S'
013693     AND  MIR-DV-PRCES-STATE-CD = '2'
029060         IF  MIR-LTAXWH-RQST-AMT > ZERO
029060         OR  MIR-LTAXWH-RQST-PCT > ZERO
                   CONTINUE
               ELSE
013693* MESSAGE - LOCATION TAX FLAT AMOUNT AND PERCENT CANNOT BOTH
013693* MESSAGE - BE ZERO WITH STORED OPTION
013693         MOVE 'CS82200050'      TO WGLOB-MSG-REF-INFO
013693         PERFORM  0260-1000-GENERATE-MESSAGE
013693             THRU 0260-1000-GENERATE-MESSAGE-X
013693         END-IF
013693     END-IF.
013693
024550     IF RPOL-POL-CTRY-US
024550     AND MIR-DV-PRCES-STATE-CD = '2'
023437*    IF MIR-DV-PRCES-STATE-CD = '2'
022210     AND MIR-SURR-TAX-OVRID-CD NOT = 'RP'
022210     AND MIR-SURR-TAX-OVRID-CD NOT = 'RQ'
022210     AND MIR-SURR-TAX-OVRID-CD NOT = 'RC'
022210     AND MIR-SURR-TAX-OVRID-CD NOT = 'TT'
022210     AND MIR-SURR-TAX-OVRID-CD NOT = 'DR'
022210     AND MIR-SURR-TAX-OVRID-CD NOT = 'DQ'
029060*       IF  (MIR-LTAXWH-CALC-CD  = 'B'
029060*       OR  MIR-LTAXWH-CALC-CD   = 'S')
029060        IF  (MIR-LTAXWH-RQST-CD  = 'B'
029060        OR  MIR-LTAXWH-RQST-CD   = 'S')
013693        AND (L2430-CLI-TXEMP-CD  = 'D'
013693        OR   L2430-CLI-TXEMP-CD  = 'M'
013693        OR   L2430-CLI-TXEMP-CD  = 'N'
013693        OR   L2430-CLI-TXEMP-CD  = 'S')
013693*MESSAGE - CLIENT IS SUBJECT TO MANDATORY TAX WITHHOLDING -
013693*MESSAGE - NO ADJUSTMENT OR BYPASS ALLOWED
013693           MOVE 'CS82200048'        TO  WGLOB-MSG-REF-INFO
013693           PERFORM  0260-1000-GENERATE-MESSAGE
013693               THRU 0260-1000-GENERATE-MESSAGE-X
013693        END-IF
013693     END-IF.
013693
023437*
023437     IF  WS-BUS-FCN-SURRENDER
023437         PERFORM 2110-EDIT-FED-TAXWH
023437            THRU 2110-EDIT-FED-TAXWH-X
023437     END-IF.
      *
           IF MIR-SUPRES-CNFRM-IND = SPACES
               MOVE 'N'               TO MIR-SUPRES-CNFRM-IND
           END-IF.
      *
           MOVE MIR-SUPRES-CNFRM-IND  TO WS-SCONF-CD.
           IF WS-SCONF-VALID
               CONTINUE
           ELSE
      * MESSAGE - INVALID SUPPRESS CONFIRM - MUST BE 'Y' OR 'N'
               MOVE 'CS82200029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
015905*    IF MIR-DV-CIA-REASN-CD = SPACES
015905*        MOVE 'N/A'             TO MIR-DV-CIA-REASN-CD
015905     IF MIR-CIA-REASN-CD = SPACES
015905         MOVE 'N/A'             TO MIR-CIA-REASN-CD
           END-IF.
      *
015905*    MOVE MIR-DV-CIA-REASN-CD      TO WS-REASN-CODE.
015905     MOVE MIR-CIA-REASN-CD      TO WS-REASN-CODE.
           IF WS-VALID-REASN-CODE
               CONTINUE
           ELSE
      * MESSAGE - INVALID REASON - MUST BE 'GRS' 'NET' OR 'NA'
               MOVE 'CS82200025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
           IF MIR-CIA-SRC-DEST-CD = SPACES
               MOVE 'D'               TO MIR-CIA-SRC-DEST-CD
           END-IF.
      *
           MOVE MIR-CIA-SRC-DEST-CD   TO WS-DEST-CODE.
018731*
018731     IF WS-VALID-DEST-CODE
               CONTINUE
018731     ELSE
018731        IF  WS-BUS-FCN-SURRENDER
018731* MESSAGE - INVALID DEST - MUST BE 'C' 'D' 'M' OR 'P'
018731* MESSAGE - INVALID DEST SELECTED
018731         MOVE 'CS82200027'      TO WGLOB-MSG-REF-INFO
018731         PERFORM  0260-1000-GENERATE-MESSAGE
018731             THRU 0260-1000-GENERATE-MESSAGE-X
018731        END-IF
           END-IF.

020478*    IF  NOT WS-SURR-FND-CNTRCT-DFLT
020463         PERFORM  2735-1000-BUILD-PARM-INFO
020463             THRU 2735-1000-BUILD-PARM-INFO-X
020463         MOVE  RPOL-POL-ID   TO L2735-POL-ID
020463         PERFORM  2735-1000-GET-PRFL
020463             THRU 2735-1000-GET-PRFL-X
020463         IF L2735-RETRN-PRFL-FND
020463*MSG: WARNING... POLICY CONTAINS AN INVESTOR PROFILE.
020463*     ALLOCATIONS ENTERED MAY NOT MATCH THOSE DEFINED
020463*     FOR THE PROFILE.
020463             MOVE 'CS82200001'   TO WGLOB-MSG-REF-INFO
020463             PERFORM  0260-1000-GENERATE-MESSAGE
020463                 THRU 0260-1000-GENERATE-MESSAGE-X
020463         END-IF
020478*    END-IF.
020463
           IF WS-BUS-FCN-SURRENDER
               PERFORM 2150-EDIT-SURR
                  THRU 2150-EDIT-SURR-X
           END-IF.
      *
           IF WS-BUS-FCN-TRANSFER
               PERFORM 2160-EDIT-XFER
                  THRU 2160-EDIT-XFER-X
           END-IF.
      *

       2100-EDIT-KEY-FIELDS-X.
           EXIT.
      *
      *
023437*-------------------
023437 2110-EDIT-FED-TAXWH.
023437*-------------------
023437*
023437*
029060*    IF  MIR-FED-TAXWH-RQST-AMT = SPACES
029060
029060     IF  MIR-FTAXWH-RQST-AMT = SPACES
023437         MOVE ZERO                    TO WS-FED-TAXWH-RQST-AMT
023437     ELSE
029060*        MOVE MIR-FED-TAXWH-RQST-AMT  TO L0280-INPUT-DATA
029060         MOVE MIR-FTAXWH-RQST-AMT     TO L0280-INPUT-DATA
023437         SET L0280-SIGN-NOT-PERMITTED TO TRUE
023437         MOVE 13                      TO L0280-LENGTH
023437         MOVE 2                       TO L0280-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                     TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                      TO L0280-INPUT-SIZE
023437         PERFORM  0280-1000-NUMERIC-EDIT
023437             THRU 0280-1000-NUMERIC-EDIT-X
023437         IF  L0280-OK
023437             MOVE L0280-OUTPUT-V02    TO WS-FED-TAXWH-RQST-AMT
023437         ELSE
023437* MESSAGE - INVALID FEDERAL TAX REQUEST AMOUNT
023437             MOVE 'CS82200058'        TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437         END-IF
023437     END-IF.
023437
029060*    IF MIR-FED-TAXWH-RQST-PCT = SPACES
029060
029060     IF MIR-FTAXWH-RQST-PCT = SPACES
023437         MOVE ZERO                    TO WS-FED-TAXWH-RQST-PCT
023437     ELSE
029060*        MOVE MIR-FED-TAXWH-RQST-PCT  TO L0280-INPUT-DATA
029060         MOVE MIR-FTAXWH-RQST-PCT     TO L0280-INPUT-DATA
023437         SET L0280-SIGN-NOT-PERMITTED TO TRUE
023437         MOVE 4                       TO L0280-LENGTH
023437         MOVE 2                       TO L0280-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                     TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                      TO L0280-INPUT-SIZE
023437         PERFORM  0280-1000-NUMERIC-EDIT
023437             THRU 0280-1000-NUMERIC-EDIT-X
023437         IF L0280-OK
023437             MOVE L0280-OUTPUT-V02    TO WS-FED-TAXWH-RQST-PCT
023437             IF WS-FED-TAXWH-RQST-PCT > 100
023437             OR WS-FED-TAXWH-RQST-PCT < ZERO
023437* MESSAGE - INVALID FEDERAL TAX %
023437                 MOVE 'CS82200059'    TO WGLOB-MSG-REF-INFO
023437                 PERFORM  0260-1000-GENERATE-MESSAGE
023437                     THRU 0260-1000-GENERATE-MESSAGE-X
023437             END-IF
023437         ELSE
023437* MESSAGE - INVALID FEDERAL TAX %
023437             MOVE 'CS82200059'        TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437         END-IF
023437     END-IF.
023437
023437* CALL THE REGIONAL EXIT ROUTINE TO EDIT THE FEDERAL TAX INPUT
023437
023437     PERFORM  0316-1000-BUILD-PARM-INFO
023437         THRU 0316-1000-BUILD-PARM-INFO-X.
023437
023437     SET L0316-RGN-EXIT-TAXWH-CLI-EDITS     TO TRUE.
023437     MOVE RPOL-POL-CTRY-CD                  TO L0316-CTRY-CD.
023437
023437     PERFORM  0316-1000-GET-RGN-EXIT-PGM
023437         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
023437
023437     IF  NOT L0316-RETRN-OK
023437     OR  L0316-RGN-EXIT-STAT-INACTV
023437*MSG: 'NO REGIONAL EXIT FOR FEDERAL TAX EDIT FOUND FOR
023437*      COUNTRY '@1''
023437         MOVE 'CS82200060'        TO WGLOB-MSG-REF-INFO
023437         MOVE L0316-CTRY-CD       TO WGLOB-MSG-PARM (01)
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         GO TO 2110-EDIT-FED-TAXWH-X
023437     END-IF.
023437
023437* IF ACTIVE REGIONAL EXIT DOES EXIST, FEDERAL TAX INPUT MUST
023437* BE EDIT FOR FEDERAL TAX WITHHOLD
023437
023437     PERFORM  TAXC-1000-BUILD-PARM-INFO
023437         THRU TAXC-1000-BUILD-PARM-INFO-X.
023437
023437     SET LTAXC-RGN-EXIT-TAXWH-CLI-EDITS      TO TRUE.
023437
023437     MOVE RPOL-POL-ID                 TO LTAXC-POL-ID.
023437     MOVE WS-EFF-DT                   TO LTAXC-EFF-DT.
029060*    MOVE MIR-FED-TAXWH-CALC-CD       TO LTAXC-FED-TAXWH-CALC-CD.
029060*    MOVE WS-FED-TAXWH-RQST-AMT       TO LTAXC-FED-TAXWH-RQST-AMT.
029060*    MOVE WS-FED-TAXWH-RQST-PCT       TO LTAXC-FED-TAXWH-RQST-PCT.
029060*    MOVE MIR-LTAXWH-CALC-CD          TO LTAXC-LTAXWH-CALC-CD.
029060*    MOVE WS-LOCAMT                   TO LTAXC-LTAXWH-FLAT-AMT.
029060*    MOVE WS-LOCPCT                   TO LTAXC-LTAXWH-PCT.
029060     MOVE MIR-FTAXWH-RQST-CD          TO LTAXC-FTAXWH-RQST-CD.
029060     MOVE WS-FED-TAXWH-RQST-AMT       TO LTAXC-FTAXWH-RQST-AMT.
029060     MOVE WS-FED-TAXWH-RQST-PCT       TO LTAXC-FTAXWH-RQST-PCT.
029060     MOVE MIR-LTAXWH-RQST-CD          TO LTAXC-LTAXWH-RQST-CD.
029060     MOVE WS-LOCAMT                   TO LTAXC-LTAXWH-RQST-AMT.
029060     MOVE WS-LOCPCT                   TO LTAXC-LTAXWH-RQST-PCT.
023437
023437     PERFORM  TAXC-1000-TAXWH-CLI-EDIT
023437         THRU TAXC-1000-TAXWH-CLI-EDIT-X.
023437
023437     IF  LTAXC-EDIT-ERROR
023437     OR  NOT LTAXC-RETRN-OK
023437         MOVE +1                TO  WGLOB-MSG-ERROR-SW
023437         GO TO 2110-EDIT-FED-TAXWH-X
023437     END-IF.
023437
023437 2110-EDIT-FED-TAXWH-X.
023437     EXIT.
      *
      *
      *--------------
       2150-EDIT-SURR.
      *--------------
      *
           IF NOT WS-REASN-GRS
           AND (WS-SURR-BY-PERCENT-TOT-VAL OR
                WS-SURR-BY-PERCENT-FND-VAL OR
                WS-SURR-BY-NO-OF-UNITS)
               SET WS-REASN-GRS        TO TRUE
015905*        MOVE WS-REASN-CODE      TO MIR-DV-CIA-REASN-CD
015905         MOVE WS-REASN-CODE      TO MIR-CIA-REASN-CD
      *MESSAGE: FOR ENTER: E, F, OR G, REASON MUST BE 'GRS', DEFAULTED
               MOVE 'CS82200030'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
013697*    IF (NOT WS-REASN-GRS
013697*    AND NOT WS-REASN-NET)
013697     IF  NOT WS-VALID-REASN-CODE
      *MESSAGE: REASON CODE OF 'GRS' OR 'NET' MUST BE ENTERED FOR SURR
               MOVE 'CS82200031'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

013697     EVALUATE TRUE
013697         WHEN NOT RPOL-POL-PNSN-QUALF-NONE
013697
022210*             MOVE MIR-SURR-TAX-OVRID-CD
022210*             TO L8140-SURR-TAX-OVRID-CD
022210              IF  MIR-SURR-TAX-OVRID-CD    = SPACES
022210                  SET L8140-SURR-TAX-OVRID-NORM TO TRUE
022210              ELSE
022210                  MOVE MIR-SURR-TAX-OVRID-CD
022210                                       TO L8140-SURR-TAX-OVRID-CD
022210              END-IF
013697
013697              IF  NOT WS-REASN-CNT
013697                  IF  (L8140-SURR-TAX-PREV-RCHAR
013697                  OR  L8140-SURR-TAX-CURR-RCHAR
013697                  OR  L8140-SURR-TAX-CURR-WTHDRW
013697                  OR  L8140-SURR-TAX-PREV-WTHDRW)
013697*MESSAGE: AMOUNT TYPE MUST BE CONTRIBUTION FOR WITHDRAW OR
013697*         RECHARACTERIZE CONTRIBUTION
013697                      MOVE 'CS82200055'  TO WGLOB-MSG-REF-INFO
013697                      PERFORM  0260-1000-GENERATE-MESSAGE
013697                          THRU 0260-1000-GENERATE-MESSAGE-X
013697                  END-IF
013697              END-IF
013697
013697              IF  WS-REASN-CNT
013697                  IF  NOT (L8140-SURR-TAX-PREV-RCHAR
013697                  OR  L8140-SURR-TAX-CURR-RCHAR
013697                  OR  L8140-SURR-TAX-CURR-WTHDRW
013697                  OR  L8140-SURR-TAX-PREV-WTHDRW)
013697*MESSAGE: REQUEST TYPE MUST BE WITHDRAW OR RECHARACTERIZE
013697*         CONTRIBUTION FOR AMOUNT TYPE CONTRIBUTION
013697                      MOVE 'CS82200056'  TO WGLOB-MSG-REF-INFO
013697                      PERFORM  0260-1000-GENERATE-MESSAGE
013697                          THRU 0260-1000-GENERATE-MESSAGE-X
013697                  END-IF
013697              END-IF
013697
013697     END-EVALUATE.
013697
018731     MOVE MIR-CIA-SRC-DEST-CD        TO WS-DEST-CODE.
018731
018731     IF  NOT WS-DEST-EFT
018731         IF  MIR-CLI-ID           NOT = SPACES
018731         OR  MIR-CLI-BNK-ACCT-NUM NOT = SPACES
018731*MSG: BANK DETAILS ARE ONLY VALID FOR EFT PAYOUT
018731             MOVE 'CS82200040'       TO  WGLOB-MSG-REF-INFO
018731             PERFORM  0260-1000-GENERATE-MESSAGE
018731                 THRU 0260-1000-GENERATE-MESSAGE-X
018731             MOVE SPACES             TO  MIR-CLI-ID
018731             MOVE SPACES             TO  MIR-CLI-BNK-ACCT-NUM
018731             SET WGLOB-RETURN-ERROR TO TRUE
018731         END-IF
018731     END-IF.
018731
018731     IF  WS-DEST-EFT
018731         PERFORM  2151-EDIT-EFT-CLIENT
018731             THRU 2151-EDIT-EFT-CLIENT-X
018731         PERFORM  2152-EDIT-EFT-BNK-INFO
018731             THRU 2152-EDIT-EFT-BNK-INFO-X
018731     END-IF.
      *
       2150-EDIT-SURR-X.
           EXIT.
      *
018731*--------------------
018731 2151-EDIT-EFT-CLIENT.
018731*--------------------
018731
018731*  EDIT TO MAKE SURE CLIENT ID IS NOT SPACES
018731     IF MIR-CLI-ID = SPACES
018731*MESSAGE CLIENT ID MUST BE ENTERED FOR EFT PROCESSING
018731           MOVE 'CS82200051'      TO WGLOB-MSG-REF-INFO
018731           PERFORM  0260-1000-GENERATE-MESSAGE
018731               THRU 0260-1000-GENERATE-MESSAGE-X
018731           GO TO 2151-EDIT-EFT-CLIENT-X
018731     END-IF.
018731
018731     PERFORM  2430-1000-BUILD-PARM-INFO
018731         THRU 2430-1000-BUILD-PARM-INFO-X.
018731
018731     MOVE MIR-POL-ID                    TO L2430-POL-ID.
018731     MOVE MIR-CLI-ID                    TO L2430-CLI-ID.
018731
018731     PERFORM  2430-3300-GET-POL-CLI-REL
018731         THRU 2430-3300-GET-POL-CLI-REL-X.
018731
018731     IF L2430-RETRN-CLI-NOT-FOUND
018731*MSG: EFT CLIENT DOES NOT BELONG TO THE POLICY
018731         MOVE 'CS82200054'  TO WGLOB-MSG-REF-INFO
018731         PERFORM  0260-1000-GENERATE-MESSAGE
018731             THRU 0260-1000-GENERATE-MESSAGE-X
018731         MOVE +1                     TO  WGLOB-MSG-ERROR-SW
018731     END-IF.
018731
018731 2151-EDIT-EFT-CLIENT-X.
018731     EXIT.
      *
018731*----------------------
018731 2152-EDIT-EFT-BNK-INFO.
018731*----------------------
018731     PERFORM  4382-1000-BUILD-PARM-INFO
018731         THRU 4382-1000-BUILD-PARM-INFO-X.
018731
018731     MOVE  MIR-CLI-ID              TO  L4382-CLI-ID.
018731     MOVE  MIR-CLI-BNK-ACCT-NUM    TO  L4382-CLI-BNK-ACCT-NUM.
018731
018731     PERFORM  4382-1000-EFT-EDITS
018731         THRU 4382-1000-EFT-EDITS-X.
018731
018731     IF  L4382-EDIT-ERROR
018731     OR  NOT L4382-RETRN-OK
018731         MOVE +1                     TO  WGLOB-MSG-ERROR-SW
018731     END-IF.
018731
018731 2152-EDIT-EFT-BNK-INFO-X.
018731     EXIT.
018731*
      *--------------
       2160-EDIT-XFER.
      *--------------
      *
      *  REASON MUST BE 'N/A' FOR TRANSFER REQUESTS
      *
           IF NOT WS-REASN-NOT-APP
      * MESSAGE: REASON MUST BE 'N/A' FOR TRANSFER REQUESTS
               MOVE 'CS82200036'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2160-EDIT-XFER-X.
           EXIT.
      *
      *---------------------------
       2300-INITIALIZE-WORK-AREAS.
      *---------------------------
      *
020469     MOVE RPOL-POL-CRCY-CD                TO WS-POL-CRCY-CD.
018846     SET WS-SIDE-FND-EXHAUSTED            TO TRUE.
018846     SET WS-REG-FND-WITHDRAWAL-NO         TO TRUE.
018846
           PERFORM 8200-1000-BUILD-PARM-INFO
              THRU 8200-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT             TO L8200-EFF-DT.
031036     SET L8200-CDI-TYP-PART-SUR TO TRUE.
      *
020478*    IF WS-SURR-FND-CNTRCT-DFLT
018558*    AND MIR-DV-PRCES-STATE-CD = '2'
020478*        SET L8200-CDI-TYP-PART-SUR TO TRUE
020478*        PERFORM 8200-2000-GET-DFLT-INSTR
020478*           THRU 8200-2000-GET-DFLT-INSTR-X
020478*        IF NOT L8200-RETRN-OK
020478* MESSAGE - NO DEFAULTS AVAILABLE FOR THIS POLICY
020478*            MOVE 'CS82200015'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM 0260-1000-GENERATE-MESSAGE
020478*               THRU 0260-1000-GENERATE-MESSAGE-X
020478*            SET MIR-RETRN-EDIT-ERROR TO TRUE
020478*        END-IF
020478*        IF L8200-RETRN-OK
020478*        AND L8200-RETRV-NO-REC
020478* MESSAGE - DEFAULT INSTRUCTIONS UNAVAILABLE - ASSUMMING PRORATA
020478*            MOVE 'CS82200032'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM 0260-1000-GENERATE-MESSAGE
020478*               THRU 0260-1000-GENERATE-MESSAGE-X
020478*        END-IF
020478*        IF WGLOB-MSG-SEVRTY-FATAL
020478*            GO TO 2300-INITIALIZE-WORK-AREAS-X
020478*        END-IF
020478*     ELSE
               PERFORM 8200-1000-INIT-INSTR
                  THRU 8200-1000-INIT-INSTR-X
020478*    END-IF.
      *
           PERFORM 8180-1000-BUILD-PARM-INFO
              THRU 8180-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT             TO L8180-EFF-DT.
           PERFORM  8180-1000-CALC-FUND-VAL
               THRU 8180-1000-CALC-FUND-VAL-X.
           EVALUATE TRUE
               WHEN WS-BUS-FCN-TRANSFER
                   SET LFUND-ACTV-TRANSFER           TO TRUE
               WHEN WS-BUS-FCN-SURRENDER
                   SET LFUND-ACTV-PARTIAL-SURRENDER  TO TRUE
           END-EVALUATE.
      *
       2300-INITIALIZE-WORK-AREAS-X.
           EXIT.
      *
      *-----------------------
       3000-PROCESS-SURRENDER.
      *-----------------------
      *
           EVALUATE TRUE
               WHEN MIR-DV-PRCES-STATE-CD = '1'
                   PERFORM 3100-PROCESS-SURRENDER-1
                      THRU 3100-PROCESS-SURRENDER-1-X
               WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM 3300-PROCESS-SURRENDER-2
                      THRU 3300-PROCESS-SURRENDER-2-X
               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM 3500-PROCESS-SURRENDER-3
                      THRU 3500-PROCESS-SURRENDER-3-X
           END-EVALUATE.
      *
       3000-PROCESS-SURRENDER-X.
           EXIT.
      *
      *-------------------------
       3100-PROCESS-SURRENDER-1.
      *-------------------------
      *
           EVALUATE TRUE
      * MIR-ENTER = 'C'
020478*        WHEN WS-SURR-BY-AMOUNT
020478*            PERFORM 3140-PRCES-SURR-BY-AMT
020478*               THRU 3140-PRCES-SURR-BY-AMT-X
      * MIR-ENTER = 'D'
               WHEN WS-SURR-BY-PERCENT
                   PERFORM 3150-PRCES-SURR-BY-PCT
                      THRU 3150-PRCES-SURR-BY-PCT-X
      * MIR-ENTER = 'F'
               WHEN WS-SURR-BY-PERCENT-FND-VAL
                   PERFORM 3160-PRCES-SURR-BY-PCT
                      THRU 3160-PRCES-SURR-BY-PCT-X
      * MIR-ENTER = 'G'
               WHEN WS-SURR-BY-NO-OF-UNITS
                   PERFORM 3170-PRCES-SURR-BY-UNITS
                      THRU 3170-PRCES-SURR-BY-UNITS-X
           END-EVALUATE.
      *
       3100-PROCESS-SURRENDER-1-X.
           EXIT.
      *
      *-----------------------
020478*3140-PRCES-SURR-BY-AMT.
      *-----------------------
      *
020478*    PERFORM 3141-DISPLAY-SURR-AMT
020478*       THRU 3141-DISPLAY-SURR-AMT-X
020478*       VARYING K FROM 1 BY 1
020478*         UNTIL K > LFUND-FND-CTR.
      *
020478*3140-PRCES-SURR-BY-AMT-X.
020478*    EXIT.
      *
      *----------------------
020478*3141-DISPLAY-SURR-AMT.
      *----------------------
      *
020478*    PERFORM 8000-DISPLAY-FUND-KEYS
020478*       THRU 8000-DISPLAY-FUND-KEYS-X.
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-AMT (K) * 100.
020478*    MOVE LFUND-ALLOC-AMT (K)   TO L0290-INPUT-V02.
020478*    MOVE 2                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (K).
      *
020478*    IF L8180-CFN-CV-AMT (K) = ZERO
020478*        MOVE ZERO              TO WS-WORK-PCT
020478*    ELSE
020478*        COMPUTE WS-WORK-AMT = LFUND-ALLOC-AMT (K) * -1
020478*        COMPUTE WS-WORK-PCT =
020469*              (WS-WORK-AMT / L8180-CFN-CV-AMT (K)) * 100
020478*              (WS-WORK-AMT / L8180-CFN-POL-CRCY-CV-AMT (K)) * 100
020478*    END-IF.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-WORK-PCT * 10000
020478*    MOVE WS-WORK-PCT           TO L0290-INPUT-V04.
020478*    MOVE 4                     TO L0290-PRECISION .
020478*    MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (K)
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (K).
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER
020478*    MOVE ZEROES                TO L0290-INPUT-V04
020478*    MOVE 4                     TO L0290-PRECISION
020478*    MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (K)
020478*                               TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-FIA-VALU-SURR-PCT-T (K).
020478*
020478*3141-DISPLAY-SURR-AMT-X.
020478*    EXIT.
      *
      *-----------------------
       3150-PRCES-SURR-BY-PCT.
      *-----------------------
      *
           PERFORM 3151-DISPLAY-SURR-PCT
              THRU 3151-DISPLAY-SURR-PCT-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
       3150-PRCES-SURR-BY-PCT-X.
           EXIT.
      *
      *----------------------
       3151-DISPLAY-SURR-PCT.
      *----------------------
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-PCT (K) * 10000.
020874     MOVE LFUND-ALLOC-PCT (K)   TO L0290-INPUT-V04.
           MOVE 4                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (K).
      *
           IF WS-TRXN-AMT = ZERO
               MOVE ZERO              TO WS-WORK-AMT
           ELSE
               COMPUTE WS-WORK-PCT = LFUND-ALLOC-PCT (K) * -1
017150*        COMPUTE WS-WORK-AMT =
017150         COMPUTE L0279-CRCY-AMT =
                     (WS-WORK-PCT * WS-TRXN-AMT)
017150         PERFORM  0279-2000-CRCY-TRUNC
017150             THRU 0279-2000-CRCY-TRUNC-X
017150         MOVE L0279-CRCY-AMT    TO WS-WORK-AMT
           END-IF.

020874* REVERTED BACK TO L0290-INPUT-NUMBER AS WE DO NOT NEED TO
020874* MULTIPLY WS-WORK-AMT BY 100

023437     COMPUTE L0290-INPUT-NUMBER ROUNDED = WS-WORK-AMT
023437*    MOVE WS-WORK-AMT           TO L0290-INPUT-NUMBER
020874*    MOVE WS-WORK-AMT           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (K).
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER
020874     MOVE ZEROES                TO L0290-INPUT-V04.
           MOVE 4                     TO L0290-PRECISION
           MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (K)
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-FIA-VALU-SURR-PCT-T (K).
      *
       3151-DISPLAY-SURR-PCT-X.
           EXIT.
      *
      *-----------------------
       3160-PRCES-SURR-BY-PCT.
      *-----------------------
      *
           PERFORM 3161-DISPLAY-SURR-PCT
              THRU 3161-DISPLAY-SURR-PCT-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
       3160-PRCES-SURR-BY-PCT-X.
           EXIT.
      *
      *----------------------
       3161-DISPLAY-SURR-PCT.
      *----------------------
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
           IF L8180-CFN-CV-AMT (K) = ZERO
               MOVE ZERO              TO WS-WORK-AMT
           ELSE
               COMPUTE WS-WORK-PCT = LFUND-ALLOC-PCT (K) * -1
017150*        COMPUTE WS-WORK-AMT =
017150         COMPUTE L0279-CRCY-AMT =
020469*              (WS-WORK-PCT * L8180-CFN-CV-AMT (K))
020469               (WS-WORK-PCT * L8180-CFN-POL-CRCY-CV-AMT (K))
020469         MOVE MIR-FIA-CRCY-CD-T (K)
020469                                TO L0279-CRCY-CD
017150         PERFORM  0279-2000-CRCY-TRUNC
017150             THRU 0279-2000-CRCY-TRUNC-X
017150         MOVE L0279-CRCY-AMT    TO WS-WORK-AMT
           END-IF.

020874* REVERTED BACK TO L0290-INPUT-NUMBER AS WE DO NOT NEED TO
020874* MULTIPLY WS-WORK-AMT BY 100
023437     COMPUTE L0290-INPUT-NUMBER ROUNDED = WS-WORK-AMT
023437*    MOVE WS-WORK-AMT           TO L0290-INPUT-NUMBER
020874*    MOVE WS-WORK-AMT           TO L0290-INPUT-V02
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (K).
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER
020874     MOVE ZEROES                TO L0290-INPUT-V04
           MOVE 4                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (K).
      *
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-PCT (K) * 10000.
020874     MOVE LFUND-ALLOC-PCT (K)   TO L0290-INPUT-V04.
           MOVE 4                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-FIA-VALU-SURR-PCT-T (K).
      *
       3161-DISPLAY-SURR-PCT-X.
           EXIT.
      *
      *-------------------------
       3170-PRCES-SURR-BY-UNITS.
      *-------------------------
      *
           MOVE SPACES                TO MIR-FIA-OUT-ALLOC-PCT-G.
      *
           PERFORM 3171-DISPLAY-SURR-UNITS
              THRU 3171-DISPLAY-SURR-UNITS-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
       3170-PRCES-SURR-BY-UNITS-X.
           EXIT.
      *
      *----------------------
       3171-DISPLAY-SURR-UNITS.
      *----------------------
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-UNIT-QTY (K)
020874*                               *  1000000000
021239*    MOVE LFUND-ALLOC-UNIT-QTY (K)  TO L0290-INPUT-V09
021239*    MOVE 9                     TO L0290-PRECISION.
021239     MOVE LFUND-ALLOC-UNIT-QTY (K)  TO L0290-INPUT-V06.
021239     MOVE 6                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-SURR-UNIT-QTY-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-FIA-SURR-UNIT-QTY-T (K).
      *
       3171-DISPLAY-SURR-UNITS-X.
           EXIT.
      *
      *-------------------------
       3300-PROCESS-SURRENDER-2.
      *-------------------------
      *
           EVALUATE TRUE
      * MIR-ENTER = 'A'
020478*        WHEN WS-SURR-FND-CNTRCT-DFLT
020478*            PERFORM 3310-PRCES-SURR-FIXED-DTLS
020478*               THRU 3310-PRCES-SURR-FIXED-DTLS-X
      * MIR-ENTER = 'B'
               WHEN WS-SURR-PRO-RATA
                   PERFORM 3320-PRCES-SURR-FIXED-DTLS
                      THRU 3320-PRCES-SURR-FIXED-DTLS-X
      * MIR-ENTER = 'E'
               WHEN WS-SURR-BY-PERCENT-TOT-VAL
                   PERFORM 3330-PRCES-SURR-FIXED-DTLS
                      THRU 3330-PRCES-SURR-FIXED-DTLS-X
      * MIR-ENTER = 'C'
020478*        WHEN WS-SURR-BY-AMOUNT
020478*            PERFORM 3340-PRCES-SURR-BY-AMT
020478*               THRU 3340-PRCES-SURR-BY-AMT-X
      * MIR-ENTER = 'D'
               WHEN WS-SURR-BY-PERCENT
                   PERFORM 3350-PRCES-SURR-BY-PCT
                      THRU 3350-PRCES-SURR-BY-PCT-X
      * MIR-ENTER = 'F'
               WHEN WS-SURR-BY-PERCENT-FND-VAL
                   PERFORM 3360-PRCES-SURR-BY-PCT
                      THRU 3360-PRCES-SURR-BY-PCT-X
      * MIR-ENTER = 'G'
               WHEN WS-SURR-BY-NO-OF-UNITS
                   PERFORM 3370-PRCES-SURR-BY-UNITS
                      THRU 3370-PRCES-SURR-BY-UNITS-X
           END-EVALUATE.
      *
       3300-PROCESS-SURRENDER-2-X.
           EXIT.
      *
      *---------------------------
020478*3310-PRCES-SURR-FIXED-DTLS.
      *---------------------------
      *
      * PROCESS WS-SURR-FND-CNTRCT-DFLT - 'A'
020478*    PERFORM  0182-1000-BUILD-PARM-INFO
020478*        THRU 0182-1000-BUILD-PARM-INFO-X.
020478*    MOVE WS-EFF-DT                   TO L0182-EFF-DT.
020478*    SET L0182-SURR-CHRG-TYP-PARTL    TO TRUE.
020478*    PERFORM  0182-1000-CALC-CSV-POL
020478*        THRU 0182-1000-CALC-CSV-POL-X.
020478*
020478*    IF  L0182-SIDFND-AFV-AMT > ZERO
020478*        PERFORM  8800-MSG-SIDE-FND-EXIST
020478*            THRU 8800-MSG-SIDE-FND-EXIST-X
020478*        IF  MIR-RETRN-EDIT-ERROR
020478*            GO TO 3310-PRCES-SURR-FIXED-DTLS-X
020478*        END-IF
020478*    END-IF.
020478*
020478*    PERFORM
020478*          VARYING J FROM 1 BY 1
020478*          UNTIL J > LFUND-FND-CTR
020478*        IF LFUND-ALLOC-PCT (J) > ZERO
020478*            SET LFUND-ALLOC-PERCENT (J) TO TRUE
020478*            COMPUTE LFUND-ALLOC-PCT (J) =
020478*                    LFUND-ALLOC-PCT (J) * -1
020478*        END-IF
020478*    END-PERFORM.
020478*
020478*    PERFORM 3550-BUILD-8140-LINKAGE
020478*       THRU 3550-BUILD-8140-LINKAGE-X.
020478*    SET L8140-REDO-WARNING      TO TRUE.
020478*    SET L8140-PRCES-TYP-EDIT-ONLY TO TRUE.
020478*    PERFORM 8140-1000-PRCES-SURR
020478*       THRU 8140-1000-PRCES-SURR-X.
      *
020478*    IF L8140-RETRN-OK
020874*        COMPUTE L0290-INPUT-NUMBER = L8140-TRXN-FEE-AMT * 100
020478*        MOVE L8140-TRXN-FEE-AMT  TO L0290-INPUT-V02
020478*        MOVE 2                 TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-CIA-LOAD-AMT
020478*                               TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020478*        PERFORM 0290-2000-FORMAT-FOR-MIR
020478*           THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE  L0290-OUTPUT-DATA            TO MIR-CIA-LOAD-AMT
023437*        PERFORM  3560-MOVE-TO-MIR-LTAXWH
023437*            THRU 3560-MOVE-TO-MIR-LTAXWH-X
020478*        PERFORM  3560-MOVE-TO-MIR-TAX-INFO
020478*            THRU 3560-MOVE-TO-MIR-TAX-INFO-X
020478*    ELSE
020478*        SET MIR-RETRN-EDIT-ERROR TO TRUE
020478*        GO TO 3310-PRCES-SURR-FIXED-DTLS-X
020478*    END-IF.
      *
020478*    MOVE ZERO                    TO WS-TOTAL-AMT.
020478*    PERFORM 3311-DISPLAY-FIXED-DTLS
020478*       THRU 3311-DISPLAY-FIXED-DTLS-X
020478*       VARYING K FROM 1 BY 1
020478*         UNTIL K > LFUND-FND-CTR.
      *
020478*    PERFORM
020478*        VARYING K FROM 1 BY 1
020478*        UNTIL K > LFUND-FND-CTR
020478*
020478*            COMPUTE WS-WORK-PCT ROUNDED
020478*                    = LFUND-ALLOC-AMT (K)
020478*                    / WS-TOTAL-AMT * -100
020478*
020874*            COMPUTE L0290-INPUT-NUMBER ROUNDED
020874*                       = WS-WORK-PCT
020874*                       * 10000
020478*            COMPUTE L0290-INPUT-V04 ROUNDED
020478*                       = WS-WORK-PCT
020478*            MOVE 4              TO L0290-PRECISION
020478*            MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
020478*                                TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020478*            PERFORM 0290-2000-FORMAT-FOR-MIR
020478*               THRU 0290-2000-FORMAT-FOR-MIR-X
020478*            MOVE L0290-OUTPUT-DATA
020478*            TO MIR-FIA-OUT-ALLOC-PCT-T (K)
020478*
020478*    END-PERFORM.
020478*
020478*3310-PRCES-SURR-FIXED-DTLS-X.
020478*    EXIT.
      *
      *------------------------
020478*3311-DISPLAY-FIXED-DTLS.
      *------------------------
      *
020478*    PERFORM 8000-DISPLAY-FUND-KEYS
020478*       THRU 8000-DISPLAY-FUND-KEYS-X.
      *
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-PCT (K) * 10000
020478*    MOVE LFUND-ALLOC-PCT (K)   TO L0290-INPUT-V04

020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-AMT (K)
020478*    MOVE LFUND-ALLOC-AMT (K)   TO L0290-INPUT-V04
020478*    MOVE 4                     TO L0290-PRECISION
020478*    MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (K)
020478*                               TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (K)
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER
020478*    MOVE ZEROES                TO L0290-INPUT-V04
020478*    MOVE 4                     TO L0290-PRECISION
020478*    MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (K)
020478*                               TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-FIA-VALU-SURR-PCT-T (K)
      *
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-AMT (K) * 100
020478*    MOVE LFUND-ALLOC-AMT (K)   TO L0290-INPUT-V02
020478*    MOVE 2                     TO L0290-PRECISION
020478*    MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (K)
020478*                               TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (K).
      *
020478*    ADD LFUND-ALLOC-AMT (K)    TO WS-TOTAL-AMT.
020478*
020478*3311-DISPLAY-FIXED-DTLS-X.
020478*    EXIT.
      *
      *---------------------------
       3320-PRCES-SURR-FIXED-DTLS.
      *---------------------------
      *
      * PROCESS WS-SURR-PRO-RATA - 'B'
      *
018846     PERFORM  0182-1000-BUILD-PARM-INFO
018846         THRU 0182-1000-BUILD-PARM-INFO-X.
018846     MOVE WS-EFF-DT                   TO L0182-EFF-DT.
018846     SET L0182-SURR-CHRG-TYP-PARTL    TO TRUE.
018846     PERFORM  0182-1000-CALC-CSV-POL
018846         THRU 0182-1000-CALC-CSV-POL-X.
018846
018846     IF  L0182-SIDFND-AFV-AMT > ZERO
018846         PERFORM  8800-MSG-SIDE-FND-EXIST
018846             THRU 8800-MSG-SIDE-FND-EXIST-X
018846         IF  MIR-RETRN-EDIT-ERROR
018846             GO TO 3320-PRCES-SURR-FIXED-DTLS-X
018846         END-IF
018846     END-IF.
018846

           PERFORM 3550-BUILD-8140-LINKAGE
              THRU 3550-BUILD-8140-LINKAGE-X.
016503     SET L8140-REDO-WARNING      TO TRUE.
           SET L8140-PRCES-TYP-EDIT-ONLY TO TRUE.
           PERFORM 8140-1000-PRCES-SURR
              THRU 8140-1000-PRCES-SURR-X.
      *
           IF L8140-RETRN-OK
020874*        COMPUTE L0290-INPUT-NUMBER = L8140-TRXN-FEE-AMT * 100
020874         MOVE L8140-TRXN-FEE-AMT TO L0290-INPUT-V02
               MOVE 2                 TO L0290-PRECISION
               MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE  L0290-OUTPUT-DATA            TO MIR-CIA-LOAD-AMT
023437*        PERFORM  3560-MOVE-TO-MIR-LTAXWH
023437*            THRU 3560-MOVE-TO-MIR-LTAXWH-X
023437         PERFORM  3560-MOVE-TO-MIR-TAX-INFO
023437             THRU 3560-MOVE-TO-MIR-TAX-INFO-X
           ELSE
013578         SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 3320-PRCES-SURR-FIXED-DTLS-X
           END-IF.
      *
           INITIALIZE WS-TOTAL-AMT.
           PERFORM
                 VARYING J FROM 1 BY 1
                 UNTIL J > LFUND-FND-CTR
               IF L8180-CFN-CV-AMT (J) > ZERO
                   COMPUTE WS-TOTAL-AMT =
020469*                    WS-TOTAL-AMT + L8180-CFN-CV-AMT (J)
020469                     WS-TOTAL-AMT + L8180-CFN-POL-CRCY-CV-AMT (J)
               END-IF
           END-PERFORM
      *
018846     MOVE +1                          TO J.
018846     MOVE +1                          TO K.
018846
           PERFORM 3321-DISPLAY-FIXED-DTLS
              THRU 3321-DISPLAY-FIXED-DTLS-X
018846*       VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
       3320-PRCES-SURR-FIXED-DTLS-X.
           EXIT.
      *
      *------------------------
       3321-DISPLAY-FIXED-DTLS.
      *------------------------
      *
018846     MOVE LFUND-CVG-NUM-N (K)         TO I.
018846
018846     IF  WCVGS-PLAN-FND-TYP-XTRNL (I)
018846     AND LFUND-ALLOC-AMT (K) = ZERO
018846         ADD +1                       TO K
018846         GO TO 3321-DISPLAY-FIXED-DTLS-X
018846     END-IF.

018846*    PERFORM 8000-DISPLAY-FUND-KEYS
018846*       THRU 8000-DISPLAY-FUND-KEYS-X.
018846*
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-AMT (K) * 100
020874     MOVE LFUND-ALLOC-AMT (K)   TO L0290-INPUT-V02
           MOVE 2                     TO L0290-PRECISION
018846*    MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (K)
018846     MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (K).
018846     MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (J).
      *
           IF WS-TRXN-AMT = ZERO
               MOVE ZERO              TO WS-WORK-PCT
           ELSE
018846*        COMPUTE WS-WORK-AMT = L8180-CFN-CV-AMT (K) * 100
018846*        COMPUTE WS-WORK-PCT = WS-WORK-AMT / WS-TOTAL-AMT
018846         COMPUTE WS-WORK-AMT = LFUND-ALLOC-AMT (K) * -100
018846         COMPUTE WS-WORK-PCT = WS-WORK-AMT / WS-TRXN-AMT
           END-IF.
      *
020874*    COMPUTE L0290-INPUT-NUMBER = WS-WORK-PCT * 10000
020874     MOVE WS-WORK-PCT           TO L0290-INPUT-V04
           MOVE 4                     TO L0290-PRECISION .
018846*    MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (K)
018846     MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (J)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846*    MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (K).
018846     MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (J).
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER
020874     MOVE ZEROES                TO L0290-INPUT-V04
           MOVE 4                     TO L0290-PRECISION
018846*    MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (K)
018846     MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846*    MOVE L0290-OUTPUT-DATA     TO MIR-FIA-VALU-SURR-PCT-T (K).
018846     MOVE L0290-OUTPUT-DATA     TO MIR-FIA-VALU-SURR-PCT-T (J).
      *
018846     MOVE LFUND-CVG-NUM (K)     TO MIR-CVG-NUM-T (J).
018846     MOVE LFUND-FND-ID (K)      TO MIR-FND-ID-T (J).
020874*    COMPUTE L0290-INPUT-NUMBER = L8180-CFN-CV-AMT (K) * 100.
020464*    MOVE L8180-CFN-CV-AMT (K)  TO L0290-INPUT-V02.
020464     COMPUTE L0290-INPUT-V02
020464            =  L8180-CFN-CV-AMT (K)
020464            + L8180-CFN-DEFR-IN-AMT (K)
020464            + L8180-CFN-DEFR-OUT-AMT (K).
018846     MOVE 2                     TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (J)
018846                                TO L0290-MAX-OUT-LEN.
018846     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CFN-APROX-AMT-T (J).
020469
020464*    COMPUTE L0290-INPUT-NUMBER =
020464*                         L8180-CFN-POL-CRCY-CV-AMT (K) * 100.
020464     COMPUTE  L0290-INPUT-NUMBER
020464           = (L8180-CFN-POL-CRCY-CV-AMT (K)
020464           +  L8180-CFN-POL-DEFR-IN-AMT     (K)
020464           +  L8180-CFN-POL-DEFR-OUT-AMT    (K))
020464           *  100.

020469     MOVE 2                     TO L0290-PRECISION.
020469     MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (J)
020469                                TO L0290-MAX-OUT-LEN.
020469     SET L0290-SIGN-POS-DISPLAY TO TRUE.
020469     PERFORM  0290-1000-NUMERIC-FORMAT
020469         THRU 0290-1000-NUMERIC-FORMAT-X.
020469     MOVE L0290-OUTPUT-DATA     TO MIR-DV-FIA-POL-CRCY-AMT-T (J).
020469
018846     MOVE LFUND-CVG-NUM-N (K)   TO I.
018846     MOVE WCVGS-PLAN-ID (I)     TO MIR-PLAN-ID-T (J).
018846
020874*    COMPUTE L0290-INPUT-NUMBER = L8180-CFN-UNIT-QTY (K)
020874*                               *  1000000000
021239*    MOVE L8180-CFN-UNIT-QTY (K) TO L0290-INPUT-V09
021239*    MOVE 9                     TO L0290-PRECISION.
021239*    MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (J)
021239     MOVE L8180-CFN-UNIT-QTY (K) TO L0290-INPUT-V06.
021239     MOVE 6                     TO L0290-PRECISION.
021239     MOVE LENGTH OF MIR-FIA-UNIT-CUM-QTY-T (J)
018846                                TO L0290-MAX-OUT-LEN.
018846     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
021239*    MOVE L0290-OUTPUT-DATA     TO MIR-CFN-INTG-AUNIT-QTY-T (J).
021239     MOVE L0290-OUTPUT-DATA     TO MIR-FIA-UNIT-CUM-QTY-T (J).
018846
018846     IF  MIR-CVG-NUM-T (J) = SPACE
018846     AND MIR-FND-ID-T (J) = SPACE
018846         ADD +1                 TO J
018846         ADD +1                 TO K
018846         GO TO 3321-DISPLAY-FIXED-DTLS-X
018846     END-IF.
018846
018846     IF  MIR-FND-ID-T (J) = SPACE
018846         MOVE MIR-PLAN-ID-T (J)   TO WEDIT-ETBL-VALU-ID
018846         PERFORM  PLAN-2000-DESC
018846             THRU PLAN-2000-DESC-X
018846         MOVE REDIT-ETBL-DESC-TXT TO MIR-DV-FND-DESC-TXT-T (J)
018846     ELSE
018846         MOVE MIR-FND-ID-T (J)    TO WEDIT-ETBL-VALU-ID
018846         PERFORM SGFD-2000-DESC
018846            THRU SGFD-2000-DESC-X
018846         MOVE REDIT-ETBL-DESC-TXT TO MIR-DV-FND-DESC-TXT-T (J)
018846     END-IF.
018846
020469*    RETRIEVE THE FUNDS CURRENCY CODE
020469     MOVE MIR-FND-ID-T (J)        TO L8640-FND-ID.
020469     PERFORM  8640-1000-GET-FND-CRCY-CD
020469         THRU 8640-1000-GET-FND-CRCY-CD-X.
020469     IF  L8640-RETRN-OK
020469         MOVE L8640-FND-CRCY-CD   TO MIR-FIA-CRCY-CD-T (J)
020469     ELSE
020469         MOVE SPACES              TO MIR-FIA-CRCY-CD-T (J)
020469* CASHFLOW TYPE PRODUCTS WILL BY DEFINITION HAVE LFUND-FND-ID (K)
020469* SET TO SPACES
020469         IF  MIR-FND-ID-T (J) = SPACES
020469             MOVE WS-POL-CRCY-CD  TO MIR-FIA-CRCY-CD-T (J)
020469         END-IF
020469     END-IF.
020469
020469*    FOR EACH OF THE FUNDS MOVE THE POLICY CURRENCY CODE TO MIR
020469     MOVE WS-POL-CRCY-CD        TO MIR-CIA-CRCY-CD-T (J).
020469
018846     ADD +1                     TO J.
018846     ADD +1                     TO K.
018846
       3321-DISPLAY-FIXED-DTLS-X.
           EXIT.
      *
      *---------------------------
       3330-PRCES-SURR-FIXED-DTLS.
      *---------------------------
      *
      * PROCESS WS-SURR-BY-PERCENT-TOT-VAL - 'E'
      *
018846     PERFORM  0182-1000-BUILD-PARM-INFO
018846         THRU 0182-1000-BUILD-PARM-INFO-X.
018846     MOVE WS-EFF-DT                   TO L0182-EFF-DT.
018846     SET L0182-SURR-CHRG-TYP-PARTL    TO TRUE.
018846     PERFORM  0182-1000-CALC-CSV-POL
018846         THRU 0182-1000-CALC-CSV-POL-X.
018846
018846     IF  L0182-SIDFND-AFV-AMT > ZERO
018846     AND WS-POFVAL NOT = 100
018846         PERFORM  8800-MSG-SIDE-FND-EXIST
018846             THRU 8800-MSG-SIDE-FND-EXIST-X
018846         IF  MIR-RETRN-EDIT-ERROR
018846             GO TO 3330-PRCES-SURR-FIXED-DTLS-X
018846         END-IF
018846     END-IF.
018846
           PERFORM
                 VARYING J FROM 1 BY 1
                 UNTIL J > LFUND-FND-CTR
               IF L8180-CFN-CV-AMT (J) > ZERO
                   SET LFUND-ALLOC-PERCENT (J) TO TRUE
                   COMPUTE LFUND-ALLOC-PCT (J) = -1 * WS-POFVAL
               END-IF
           END-PERFORM
      *
           IF WS-POFVAL = ZERO
               CONTINUE
           ELSE
               PERFORM 3550-BUILD-8140-LINKAGE
                  THRU 3550-BUILD-8140-LINKAGE-X
016503         SET L8140-REDO-WARNING      TO TRUE
               SET L8140-PRCES-TYP-EDIT-ONLY TO TRUE
               PERFORM 8140-1000-PRCES-SURR
                  THRU 8140-1000-PRCES-SURR-X
               IF L8140-RETRN-OK
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                                     L8140-TRXN-FEE-AMT * 100
020874             MOVE L8140-TRXN-FEE-AMT TO L0290-INPUT-V02
                   MOVE 2             TO L0290-PRECISION
                   MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE  L0290-OUTPUT-DATA
                                      TO MIR-CIA-LOAD-AMT
023437*            PERFORM  3560-MOVE-TO-MIR-LTAXWH
023437*                THRU 3560-MOVE-TO-MIR-LTAXWH-X
023437             PERFORM  3560-MOVE-TO-MIR-TAX-INFO
023437                 THRU 3560-MOVE-TO-MIR-TAX-INFO-X
               ELSE
013578             SET MIR-RETRN-EDIT-ERROR TO TRUE
                   GO TO 3330-PRCES-SURR-FIXED-DTLS-X
               END-IF
           END-IF.
      *
           PERFORM 3331-DISPLAY-FIXED-DTLS
              THRU 3331-DISPLAY-FIXED-DTLS-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
       3330-PRCES-SURR-FIXED-DTLS-X.
           EXIT.
      *
      *------------------------
       3331-DISPLAY-FIXED-DTLS.
      *------------------------
      *
      * EDIT WS-SURR-BY-PERCENT-TOT-VAL - 'E'
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER
020469*    MOVE ZEROES                TO L0290-INPUT-V04
020469*    MOVE 4                     TO L0290-PRECISION
020469*    MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (K)
020469*                               TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020469*    PERFORM 0290-2000-FORMAT-FOR-MIR
020469*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020469*    MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (K)
      *
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-PCT (K) * 10000
020874     MOVE LFUND-ALLOC-PCT (K)   TO L0290-INPUT-V04
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
           MOVE 4                     TO L0290-PRECISION
           MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (K)
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-FIA-VALU-SURR-PCT-T (K)
      *
020874*    COMPUTE L0290-INPUT-NUMBER = LFUND-ALLOC-AMT (K) * 100
020874     MOVE LFUND-ALLOC-AMT (K)   TO L0290-INPUT-V02
           MOVE 2                     TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (K)
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (K).
      *
       3331-DISPLAY-FIXED-DTLS-X.
           EXIT.
      *
      *-----------------------
020478*3340-PRCES-SURR-BY-AMT.
      *-----------------------
      *
020478*    PERFORM 3341-EDIT-SURR-AMT
020478*       THRU 3341-EDIT-SURR-AMT-X
020478*       VARYING K FROM 1 BY 1
020478*         UNTIL K > LFUND-FND-CTR.
      *
020478*    IF MIR-DV-PRCES-STATE-CD NOT = '1'
020478*        PERFORM 3345-EDIT-PRCES-REQUEST
020478*           THRU 3345-EDIT-PRCES-REQUEST-X
020478*        IF MIR-RETRN-OK
020478*            PERFORM 3141-DISPLAY-SURR-AMT
020478*               THRU 3141-DISPLAY-SURR-AMT-X
020478*               VARYING K FROM 1 BY 1
020478*                 UNTIL K > LFUND-FND-CTR
020478*        END-IF
020478*        GO TO 3340-PRCES-SURR-BY-AMT-X
020478*    END-IF.
      *
020478*    IF MIR-DV-PRCES-STATE-CD = '2'
020478*        PERFORM 3141-DISPLAY-SURR-AMT
020478*           THRU 3141-DISPLAY-SURR-AMT-X
020478*           VARYING K FROM 1 BY 1
020478*             UNTIL K > LFUND-FND-CTR
020478*    END-IF.
      *
020478*3340-PRCES-SURR-BY-AMT-X.
020478*    EXIT.
      *
      *-------------------
020478*3341-EDIT-SURR-AMT.
      *-------------------
      *
020478*    IF MIR-DV-FROM-FND-AMT-T (K) = SPACE
020478*        PERFORM 3141-DISPLAY-SURR-AMT
020478*           THRU 3141-DISPLAY-SURR-AMT-X
020478*        GO TO 3341-EDIT-SURR-AMT-X
020478*    END-IF.
      *
020478*    PERFORM 8000-DISPLAY-FUND-KEYS
020478*       THRU 8000-DISPLAY-FUND-KEYS-X.
020478*
020478*    MOVE ZERO                  TO WS-WORK-AMT.
020478*
020478*    MOVE MIR-DV-FROM-FND-AMT-T (K)
020478*                               TO L0280-INPUT-DATA.
020478*    SET L0280-SIGN-NOT-PERMITTED TO TRUE.
020478*    MOVE 2                     TO L0280-PRECISION.
020478*    MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (K)
020478*                               TO L0280-INPUT-SIZE.
020478*    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
020478*                           L0280-PRECISION - 1.
020478*    PERFORM  0280-1000-NUMERIC-EDIT
020478*        THRU 0280-1000-NUMERIC-EDIT-X.
020478*
020478*    IF L0280-OK
020478*        MOVE L0280-OUTPUT-DOLLAR
020478*                               TO WS-WORK-AMT
020478*    ELSE
020478*        MOVE ZERO              TO LFUND-ALLOC-AMT (K)
020478*        MOVE SPACE             TO LFUND-ALLOC-CD (K)
020478*        MOVE 'CS00000032'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        GO TO 3341-EDIT-SURR-AMT-X
020478*    END-IF.
020478*
020478*    IF WS-WORK-AMT = ZERO
020478*        MOVE ZERO              TO LFUND-ALLOC-AMT (K)
020478*        MOVE SPACE             TO LFUND-ALLOC-CD (K)
020478*        PERFORM 3141-DISPLAY-SURR-AMT
020478*           THRU 3141-DISPLAY-SURR-AMT-X
020478*        GO TO 3341-EDIT-SURR-AMT-X
020478*    ELSE
020478*        COMPUTE LFUND-ALLOC-AMT (K) = -1 * WS-WORK-AMT
020478*        SET LFUND-ALLOC-AMOUNT (K) TO TRUE
020478*        PERFORM 3141-DISPLAY-SURR-AMT
020478*           THRU 3141-DISPLAY-SURR-AMT-X
020478*    END-IF.
      *
020478*    MOVE LFUND-CVG-NUM-N (K)         TO WS-CVG-NUM.
020478*    EVALUATE TRUE
020478*
020478*        WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
020478*             SET WS-REG-FND-WITHDRAWAL      TO TRUE
020478*
020478*        WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
020478*         AND WS-WORK-AMT NOT = L8180-CFN-CV-AMT (K)
020478*             SET WS-SIDE-FND-EXHAUSTED-NO   TO TRUE
020478*
020478*    END-EVALUATE.
020478*
020478*3341-EDIT-SURR-AMT-X.
020478*    EXIT.
      *
      *------------------------
020478*3345-EDIT-PRCES-REQUEST.
      *------------------------
      *
020478*    IF  WS-SIDE-FND-EXHAUSTED-NO
020478*    AND WS-REG-FND-WITHDRAWAL
020478*        PERFORM  8800-MSG-SIDE-FND-EXIST
020478*            THRU 8800-MSG-SIDE-FND-EXIST-X
020478*        IF  MIR-RETRN-EDIT-ERROR
020478*            GO TO 3345-EDIT-PRCES-REQUEST-X
020478*        END-IF
020478*    END-IF.
020478*
020478*    MOVE ZERO                  TO WS-WORK-AMT.
020478*    PERFORM
020478*          VARYING K FROM 1 BY 1
020478*          UNTIL K > LFUND-FND-CTR
020478*        SUBTRACT LFUND-ALLOC-AMT (K) FROM WS-WORK-AMT
020478*    END-PERFORM.
      *
020478*    IF WS-WORK-AMT NOT = WS-TRXN-AMT
020478* MESSAGE - TOTAL SURR-AMOUNTS DO NOT EQUAL AMOUNT
020478*        MOVE 'CS82200028'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        SET MIR-RETRN-EDIT-ERROR TO TRUE
020478*        GO TO 3345-EDIT-PRCES-REQUEST-X
020478*    END-IF.
      *
020478*    PERFORM 3550-BUILD-8140-LINKAGE
020478*       THRU 3550-BUILD-8140-LINKAGE-X.
020478*    SET L8140-REDO-WARNING      TO TRUE.
020478*    SET L8140-PRCES-TYP-EDIT-ONLY TO TRUE.
020478*    PERFORM 8140-1000-PRCES-SURR
020478*       THRU 8140-1000-PRCES-SURR-X.
      *
020478*    IF NOT L8140-RETRN-OK
020478*        SET MIR-RETRN-EDIT-ERROR TO TRUE
020478*        GO TO 3345-EDIT-PRCES-REQUEST-X
020478*    END-IF.
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-TRXN-FEE-AMT * 100.
020478*    MOVE L8140-TRXN-FEE-AMT    TO L0290-INPUT-V02.
020478*    MOVE 2                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-CIA-LOAD-AMT
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
023437*    PERFORM  3560-MOVE-TO-MIR-LTAXWH
023437*        THRU 3560-MOVE-TO-MIR-LTAXWH-X.
020478*    PERFORM  3560-MOVE-TO-MIR-TAX-INFO
020478*        THRU 3560-MOVE-TO-MIR-TAX-INFO-X.

020874*    COMPUTE L0290-INPUT-NUMBER = L8140-NET-DISB-AMT * 100.
020478*    MOVE L8140-NET-DISB-AMT    TO L0290-INPUT-V02.
020478*    MOVE 2                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-DV-NET-DISB-AMT
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-NET-DISB-AMT.
020478*
020478*3345-EDIT-PRCES-REQUEST-X.
020478*    EXIT.
      *
      *-----------------------
       3350-PRCES-SURR-BY-PCT.
      *-----------------------
      *
           PERFORM 3351-EDIT-SURR-PCT
              THRU 3351-EDIT-SURR-PCT-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
           IF MIR-DV-PRCES-STATE-CD NOT = '1'
               PERFORM 3355-EDIT-PRCES-REQUEST
                  THRU 3355-EDIT-PRCES-REQUEST-X
               IF MIR-RETRN-OK
                   PERFORM 3151-DISPLAY-SURR-PCT
                      THRU 3151-DISPLAY-SURR-PCT-X
                      VARYING K FROM 1 BY 1
                        UNTIL K > LFUND-FND-CTR
               END-IF
               GO TO 3350-PRCES-SURR-BY-PCT-X
           END-IF.
      *
           IF MIR-DV-PRCES-STATE-CD = '2'
               PERFORM 3151-DISPLAY-SURR-PCT
                  THRU 3151-DISPLAY-SURR-PCT-X
                  VARYING K FROM 1 BY 1
                    UNTIL K > LFUND-FND-CTR
           END-IF.
      *
       3350-PRCES-SURR-BY-PCT-X.
           EXIT.
      *
      *-------------------
       3351-EDIT-SURR-PCT.
      *-------------------
      *
           IF MIR-FIA-OUT-ALLOC-PCT-T (K) = SPACE
               PERFORM 3151-DISPLAY-SURR-PCT
                  THRU 3151-DISPLAY-SURR-PCT-X
               GO TO 3351-EDIT-SURR-PCT-X
           END-IF.
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
           MOVE MIR-FIA-OUT-ALLOC-PCT-T (K)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 4                     TO L0280-PRECISION.
           MOVE 8                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           MOVE ZERO                  TO WS-WORK-PCT.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-V04  TO WS-WORK-PCT
           ELSE
               MOVE ZERO              TO LFUND-ALLOC-PCT (K)
               MOVE 'CS00000032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3351-EDIT-SURR-PCT-X
           END-IF.
      *
           IF WS-WORK-PCT = ZERO
               MOVE ZERO              TO LFUND-ALLOC-PCT (K)
               MOVE SPACE             TO LFUND-ALLOC-CD (K)
               PERFORM 3151-DISPLAY-SURR-PCT
                  THRU 3151-DISPLAY-SURR-PCT-X
               GO TO 3351-EDIT-SURR-PCT-X
           ELSE
               COMPUTE LFUND-ALLOC-PCT (K) = -1 * WS-WORK-PCT
               SET LFUND-ALLOC-PERCENT (K) TO TRUE
               PERFORM 3151-DISPLAY-SURR-PCT
                  THRU 3151-DISPLAY-SURR-PCT-X
               GO TO 3351-EDIT-SURR-PCT-X
           END-IF.
      *
018846     COMPUTE L0279-CRCY-AMT = WS-WORK-PCT
018846                            * WS-TRXN-AMT.
018846     PERFORM  0279-2000-CRCY-TRUNC
018846         THRU 0279-2000-CRCY-TRUNC-X
018846
018846     MOVE LFUND-CVG-NUM-N (K)         TO WS-CVG-NUM.
018846     EVALUATE TRUE
018846
018846         WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846              SET WS-REG-FND-WITHDRAWAL      TO TRUE
018846
018846         WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846          AND L8180-CFN-CV-AMT (K) NOT = L0279-CRCY-AMT
018846              SET WS-SIDE-FND-EXHAUSTED-NO   TO TRUE
018846
018846     END-EVALUATE.

       3351-EDIT-SURR-PCT-X.
           EXIT.
      *
      *------------------------
       3355-EDIT-PRCES-REQUEST.
      *------------------------
      *
018846     IF  WS-SIDE-FND-EXHAUSTED-NO
018846     AND WS-REG-FND-WITHDRAWAL
018846         PERFORM  8800-MSG-SIDE-FND-EXIST
018846             THRU 8800-MSG-SIDE-FND-EXIST-X
018846         IF  MIR-RETRN-EDIT-ERROR
018846             GO TO 3355-EDIT-PRCES-REQUEST-X
018846         END-IF
018846     END-IF.
018846
           MOVE ZERO                  TO WS-PERCENT-TOTAL.
           PERFORM
                 VARYING K FROM 1 BY 1
                 UNTIL K > LFUND-FND-CTR
               ADD LFUND-ALLOC-PCT (K)  TO WS-PERCENT-TOTAL
           END-PERFORM.

           IF WS-PERCENT-TOTAL NOT = -100.0000
      * MESSAGE - PERCENTAGES DO NOT ADD UP TO 100.0000
               MOVE 'CS82200019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 3355-EDIT-PRCES-REQUEST-X
           END-IF.
      *
           PERFORM 3550-BUILD-8140-LINKAGE
              THRU 3550-BUILD-8140-LINKAGE-X.
016503     SET L8140-REDO-WARNING      TO TRUE.
           SET L8140-PRCES-TYP-EDIT-ONLY TO TRUE.
           PERFORM 8140-1000-PRCES-SURR
              THRU 8140-1000-PRCES-SURR-X.
      *
           IF NOT L8140-RETRN-OK
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 3355-EDIT-PRCES-REQUEST-X
           END-IF.
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-TRXN-FEE-AMT * 100.
020874     MOVE L8140-TRXN-FEE-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
023437*    PERFORM  3560-MOVE-TO-MIR-LTAXWH
023437*        THRU 3560-MOVE-TO-MIR-LTAXWH-X.
023437     PERFORM  3560-MOVE-TO-MIR-TAX-INFO
023437         THRU 3560-MOVE-TO-MIR-TAX-INFO-X.
      *
       3355-EDIT-PRCES-REQUEST-X.
           EXIT.
      *
      *-----------------------
       3360-PRCES-SURR-BY-PCT.
      *-----------------------
      *
           PERFORM 3361-EDIT-SURR-PCT
              THRU 3361-EDIT-SURR-PCT-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
           IF MIR-DV-PRCES-STATE-CD NOT = '1'
               PERFORM 3365-EDIT-PRCES-REQUEST
                  THRU 3365-EDIT-PRCES-REQUEST-X
               IF MIR-RETRN-OK
                   PERFORM 3161-DISPLAY-SURR-PCT
                      THRU 3161-DISPLAY-SURR-PCT-X
                      VARYING K FROM 1 BY 1
                        UNTIL K > LFUND-FND-CTR
               END-IF
               GO TO 3360-PRCES-SURR-BY-PCT-X
           END-IF.
      *
           IF MIR-DV-PRCES-STATE-CD = '2'
               PERFORM 3161-DISPLAY-SURR-PCT
                  THRU 3161-DISPLAY-SURR-PCT-X
                  VARYING K FROM 1 BY 1
                    UNTIL K > LFUND-FND-CTR
           END-IF.
      *
       3360-PRCES-SURR-BY-PCT-X.
           EXIT.
      *
      *-------------------
       3361-EDIT-SURR-PCT.
      *-------------------
      *
           IF MIR-FIA-VALU-SURR-PCT-T (K) = SPACE
               PERFORM 3161-DISPLAY-SURR-PCT
                  THRU 3161-DISPLAY-SURR-PCT-X
               GO TO 3361-EDIT-SURR-PCT-X
           END-IF.
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
           MOVE MIR-FIA-VALU-SURR-PCT-T (K)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 4                     TO L0280-PRECISION.
           MOVE 8                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           MOVE ZERO                  TO WS-WORK-PCT.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-V04  TO WS-WORK-PCT
           ELSE
               MOVE ZERO              TO LFUND-ALLOC-PCT (K)
               MOVE 'CS00000032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3361-EDIT-SURR-PCT-X
           END-IF.
      *
           IF WS-WORK-PCT = ZERO
               MOVE ZERO              TO LFUND-ALLOC-PCT (K)
               MOVE SPACE             TO LFUND-ALLOC-CD (K)
               PERFORM 3161-DISPLAY-SURR-PCT
                  THRU 3161-DISPLAY-SURR-PCT-X
               GO TO 3361-EDIT-SURR-PCT-X
           ELSE
               COMPUTE LFUND-ALLOC-PCT (K) = -1 * WS-WORK-PCT
               SET LFUND-ALLOC-PERCENT (K) TO TRUE
               PERFORM 3161-DISPLAY-SURR-PCT
                  THRU 3161-DISPLAY-SURR-PCT-X
               GO TO 3361-EDIT-SURR-PCT-X
           END-IF.
018846     MOVE LFUND-CVG-NUM-N (K)         TO WS-CVG-NUM.
018846     EVALUATE TRUE
018846
018846         WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846              SET WS-REG-FND-WITHDRAWAL      TO TRUE
018846
018846         WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846          AND WS-WORK-PCT NOT = 100
018846          AND L8180-CFN-CV-AMT (K) > ZERO
018846              SET WS-SIDE-FND-EXHAUSTED-NO   TO TRUE
018846
018846     END-EVALUATE.
      *
       3361-EDIT-SURR-PCT-X.
           EXIT.
      *
      *------------------------
       3365-EDIT-PRCES-REQUEST.
      *------------------------
      *
018846     IF  WS-SIDE-FND-EXHAUSTED-NO
018846     AND WS-REG-FND-WITHDRAWAL
018846         PERFORM  8800-MSG-SIDE-FND-EXIST
018846             THRU 8800-MSG-SIDE-FND-EXIST-X
018846         IF  MIR-RETRN-EDIT-ERROR
018846             GO TO 3365-EDIT-PRCES-REQUEST-X
018846         END-IF
018846     END-IF.

           PERFORM 3550-BUILD-8140-LINKAGE
              THRU 3550-BUILD-8140-LINKAGE-X.
016503     SET L8140-REDO-WARNING      TO TRUE.
           SET L8140-PRCES-TYP-EDIT-ONLY TO TRUE.
           PERFORM 8140-1000-PRCES-SURR
              THRU 8140-1000-PRCES-SURR-X.
      *
           IF NOT L8140-RETRN-OK
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 3365-EDIT-PRCES-REQUEST-X
           END-IF.
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-TRXN-FEE-AMT * 100.
020874     MOVE L8140-TRXN-FEE-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
023437*    PERFORM  3560-MOVE-TO-MIR-LTAXWH
023437*        THRU 3560-MOVE-TO-MIR-LTAXWH-X.
023437     PERFORM  3560-MOVE-TO-MIR-TAX-INFO
023437         THRU 3560-MOVE-TO-MIR-TAX-INFO-X.
      *
       3365-EDIT-PRCES-REQUEST-X.
           EXIT.
      *
      *-------------------------
       3370-PRCES-SURR-BY-UNITS.
      *-------------------------
      *
      *EDIT UNITS
           PERFORM 3371-EDIT-SURR-UNITS
              THRU 3371-EDIT-SURR-UNITS-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
           IF MIR-DV-PRCES-STATE-CD NOT = '1'
               PERFORM 3375-EDIT-PRCES-REQUEST
                  THRU 3375-EDIT-PRCES-REQUEST-X
               IF MIR-RETRN-OK
                   PERFORM 3171-DISPLAY-SURR-UNITS
                      THRU 3171-DISPLAY-SURR-UNITS-X
                      VARYING K FROM 1 BY 1
                        UNTIL K > LFUND-FND-CTR
               END-IF
               GO TO 3370-PRCES-SURR-BY-UNITS-X
           END-IF.
      *
           IF MIR-DV-PRCES-STATE-CD = '2'
               PERFORM 3171-DISPLAY-SURR-UNITS
                  THRU 3171-DISPLAY-SURR-UNITS-X
                  VARYING K FROM 1 BY 1
                    UNTIL K > LFUND-FND-CTR
           END-IF.
      *
       3370-PRCES-SURR-BY-UNITS-X.
           EXIT.
      *
      *-------------------
       3371-EDIT-SURR-UNITS.
      *-------------------
      *
           IF MIR-FIA-SURR-UNIT-QTY-T (K) = SPACE
               PERFORM 3171-DISPLAY-SURR-UNITS
                  THRU 3171-DISPLAY-SURR-UNITS-X
               GO TO 3371-EDIT-SURR-UNITS-X
           END-IF.
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
           MOVE ZERO                  TO WS-WORK-UNITS.
      *
           MOVE MIR-FIA-SURR-UNIT-QTY-T (K)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
021239*    MOVE 9                     TO L0280-PRECISION
021239     MOVE 6                     TO L0280-PRECISION
           MOVE LENGTH OF MIR-FIA-SURR-UNIT-QTY-T (K)
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
021239*                           L0280-PRECISION - 1.
021239                            L0280-PRECISION - 2.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE ZERO              TO LFUND-ALLOC-UNIT-QTY (K)
               MOVE SPACE             TO LFUND-ALLOC-CD (K)
020464*        MOVE 'CS00000032'      TO WGLOB-MSG-REF-INFO
020464*MSG: INVALID SURRENDER UNITS
020464         MOVE 'CS82200003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3371-EDIT-SURR-UNITS-X
           END-IF.
      *
           IF  L8180-CFN-UNIT-QTY (K)  = 0
021239*    AND L0280-OUTPUT-V09        > 0
021239     AND L0280-OUTPUT-V06        > 0
               MOVE ZERO              TO LFUND-ALLOC-UNIT-QTY (K)
      * MESSAGE - SURRENDER INVALID FOR THIS FUND
               MOVE MIR-FND-ID-T (K)  TO WGLOB-MSG-PARM (1)
               MOVE 'CS82200016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3371-EDIT-SURR-UNITS-X
           END-IF.
      *
021239*    IF L0280-OUTPUT-V09  > L8180-CFN-UNIT-QTY (K)
021239     IF L0280-OUTPUT-V06  > L8180-CFN-UNIT-QTY (K)
               MOVE ZERO              TO LFUND-ALLOC-UNIT-QTY (K)
               MOVE SPACE             TO LFUND-ALLOC-CD (K)
      * MESSAGE - SURRENDER UNITS EXCEED FUND VALUE
               MOVE 'CS82200020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3371-EDIT-SURR-UNITS-X
           END-IF.
      *
021239*    MOVE L0280-OUTPUT-V09      TO WS-WORK-UNITS.
021239     MOVE L0280-OUTPUT-V06      TO WS-WORK-UNITS.
      *
           IF WS-WORK-UNITS = ZERO
               MOVE ZERO              TO LFUND-ALLOC-UNIT-QTY (K)
               MOVE SPACES            TO LFUND-ALLOC-CD (K)
               PERFORM 3171-DISPLAY-SURR-UNITS
                  THRU 3171-DISPLAY-SURR-UNITS-X
               GO TO 3371-EDIT-SURR-UNITS-X
           ELSE
               COMPUTE LFUND-ALLOC-UNIT-QTY (K) =
                                      -1 * WS-WORK-UNITS
               SET LFUND-ALLOC-UNITS (K) TO TRUE
               PERFORM 3171-DISPLAY-SURR-UNITS
                  THRU 3171-DISPLAY-SURR-UNITS-X
           END-IF.
      *
018846     MOVE LFUND-CVG-NUM-N (K)         TO WS-CVG-NUM.
018846     EVALUATE TRUE
018846
018846         WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846              SET WS-REG-FND-WITHDRAWAL      TO TRUE
018846
018846         WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846          AND WS-WORK-UNITS NOT = L8180-CFN-UNIT-QTY (K)
018846              SET WS-SIDE-FND-EXHAUSTED-NO   TO TRUE
018846
018846     END-EVALUATE.
018846
       3371-EDIT-SURR-UNITS-X.
           EXIT.
      *
      *------------------------
       3375-EDIT-PRCES-REQUEST.
      *------------------------
      *
018846     IF  WS-SIDE-FND-EXHAUSTED-NO
018846     AND WS-REG-FND-WITHDRAWAL
018846         PERFORM  8800-MSG-SIDE-FND-EXIST
018846             THRU 8800-MSG-SIDE-FND-EXIST-X
018846         IF  MIR-RETRN-EDIT-ERROR
018846             GO TO 3375-EDIT-PRCES-REQUEST-X
018846         END-IF
018846     END-IF.
018846
           PERFORM 3550-BUILD-8140-LINKAGE
              THRU 3550-BUILD-8140-LINKAGE-X.
016503     SET L8140-REDO-WARNING      TO TRUE.
           SET L8140-PRCES-TYP-EDIT-ONLY TO TRUE.
           PERFORM 8140-1000-PRCES-SURR
              THRU 8140-1000-PRCES-SURR-X.
      *
           IF NOT L8140-RETRN-OK
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 3375-EDIT-PRCES-REQUEST-X
           END-IF.
      *
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-TRXN-FEE-AMT * 100.
020874     MOVE L8140-TRXN-FEE-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
023437*    PERFORM  3560-MOVE-TO-MIR-LTAXWH
023437*        THRU 3560-MOVE-TO-MIR-LTAXWH-X.
023437     PERFORM  3560-MOVE-TO-MIR-TAX-INFO
023437         THRU 3560-MOVE-TO-MIR-TAX-INFO-X.
      *
       3375-EDIT-PRCES-REQUEST-X.
           EXIT.
      *
      *-------------------------
       3500-PROCESS-SURRENDER-3.
      *-------------------------
      *
016503     SET WS-MSG-SUPPRESS          TO TRUE.

           PERFORM 3300-PROCESS-SURRENDER-2
              THRU 3300-PROCESS-SURRENDER-2-X.
      *
           IF NOT MIR-RETRN-OK
               GO TO 3500-PROCESS-SURRENDER-3-X
           END-IF.
      *
           PERFORM POL-1000-READ-FOR-UPDATE
              THRU POL-1000-READ-FOR-UPDATE-X.
           IF NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-SURRENDER-3-X
           END-IF.
           MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
      *
016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.
016440     SET L5400-POL-XFER-UPDATE          TO TRUE
016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.
016440
016440*
016440* CHECK THE ACCESS RESTRICTION CODES
016440*
016440     IF L5400-XFER-ACCS-RESTRICTED
016440        GO TO 3500-PROCESS-SURRENDER-3-X
016440     END-IF.

016503*
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.

016503     MOVE WS-EFF-DT             TO L0289-PROC-EFF-DT.
016503     MOVE WS-EFF-DT             TO L0289-LO-PAC-DT.
016503     MOVE WS-EFF-DT             TO L0289-LO-CRC-DT.
020467     MOVE WS-EFF-DT             TO L0289-LO-DD2-DT.

016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD    TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT        TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                    TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE       TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

016503     SET WS-REDO-OK                     TO TRUE.
016503     IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503         CONTINUE
016503     ELSE
016503         PERFORM  8550-INVOKE-REDO
016503             THRU 8550-INVOKE-REDO-X
016503     END-IF.

016503     IF  WS-REDO-NOT-OK
016503         GO TO 3500-PROCESS-SURRENDER-3-X
016503     END-IF.

           PERFORM  8600-INVOKE-UNDO
               THRU 8600-INVOKE-UNDO-X.
      *
           IF  NOT WGLOB-GOOD-RETURN
               GO TO 3500-PROCESS-SURRENDER-3-X
           END-IF.
      *
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.

           PERFORM 3550-BUILD-8140-LINKAGE
              THRU 3550-BUILD-8140-LINKAGE-X.
016503     SET L8140-REDO-WARNING      TO TRUE.
           SET L8140-PRCES-TYP-ALL     TO TRUE.
           PERFORM 3510-ELIMINATE-UNUSED-FUNDS
              THRU 3510-ELIMINATE-UNUSED-FUNDS-X.
           PERFORM 8140-1000-PRCES-SURR
              THRU 8140-1000-PRCES-SURR-X.
      *
           IF L8140-RETRN-OK
           OR RPOL-REC-INFO NOT = HPOL-REC-INFO
               PERFORM 8500-UPDATE-POLICY-AND-CVGS
                  THRU 8500-UPDATE-POLICY-AND-CVGS-X
           END-IF.
      *
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-TRXN-FEE-AMT * 100.
020874     MOVE L8140-TRXN-FEE-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
023437*    PERFORM  3560-MOVE-TO-MIR-LTAXWH
023437*        THRU 3560-MOVE-TO-MIR-LTAXWH-X.
023437     PERFORM  3560-MOVE-TO-MIR-TAX-INFO
023437         THRU 3560-MOVE-TO-MIR-TAX-INFO-X.

020874*    COMPUTE L0290-INPUT-NUMBER = L8140-NET-DISB-AMT * 100.
020874     MOVE L8140-NET-DISB-AMT    TO L0290-INPUT-V02.
018840     MOVE 2                     TO L0290-PRECISION.
018840     MOVE LENGTH OF MIR-DV-NET-DISB-AMT
018840                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018840     MOVE L0290-OUTPUT-DATA     TO MIR-DV-NET-DISB-AMT.
      *
           PERFORM 8100-RESET-DEFAULTS
              THRU 8100-RESET-DEFAULTS-X.
      *
           IF L8140-RETRN-OK
      * MESSAGE - TRANSACTION PROCESSED SUCCESSFULLY
               MOVE 'CS82200033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       3500-PROCESS-SURRENDER-3-X.
           EXIT.
      *
      *----------------------------
       3510-ELIMINATE-UNUSED-FUNDS.
      *----------------------------
      *
           MOVE ZERO                  TO K.
           PERFORM
                 VARYING J FROM 1 BY 1
                 UNTIL J > LFUND-FND-CTR
               IF WS-SURR-PRO-RATA
018846             MOVE LFUND-CVG-NUM-N (J)  TO WS-CVG-NUM
                   IF L8180-CFN-CV-AMT (J) > ZERO
018846             AND WCVGS-PLAN-FND-TYP-NONE (WS-CVG-NUM)
                       ADD +1              TO K
                       MOVE LFUND-FND-INFO (J)
                                      TO
                            LFUND-FND-INFO (K)
                   END-IF
               ELSE
                   IF  LFUND-ALLOC-AMT (J) = ZERO
                   AND LFUND-ALLOC-PCT (J) = ZERO
                   AND LFUND-ALLOC-UNIT-QTY (J) = ZERO
                       CONTINUE
                   ELSE
                       ADD +1              TO K
                       MOVE LFUND-FND-INFO (J)
                                      TO
                            LFUND-FND-INFO (K)
                   END-IF
               END-IF
           END-PERFORM.
           MOVE K                     TO LFUND-FND-CTR.
      *
       3510-ELIMINATE-UNUSED-FUNDS-X.
           EXIT.
      *
      *------------------------
       3550-BUILD-8140-LINKAGE.
      *------------------------
      *
           PERFORM 8140-1000-BUILD-PARM-INFO
              THRU 8140-1000-BUILD-PARM-INFO-X.
      *
           EVALUATE TRUE
020478*         WHEN WS-SURR-FND-CNTRCT-DFLT
020478*             SET L8140-ALLOC-FND-CNTRCT-DFLT    TO TRUE
                WHEN WS-SURR-PRO-RATA
                    SET L8140-ALLOC-BY-FV-PREV-VAL-DT  TO TRUE
028788              SET L8140-AGT-COMM-RQST            TO TRUE
020478*         WHEN WS-SURR-BY-AMOUNT
020478*             SET L8140-ALLOC-BY-AMOUNT          TO TRUE
                WHEN WS-SURR-BY-PERCENT
                    SET L8140-ALLOC-BY-PERCENT         TO TRUE
028788              SET L8140-AGT-COMM-RQST            TO TRUE
                WHEN WS-SURR-BY-PERCENT-TOT-VAL
                    SET L8140-ALLOC-BY-PERCENT-TOT-VAL TO TRUE
028788              SET L8140-AGT-COMM-RQST            TO TRUE
                WHEN WS-SURR-BY-PERCENT-FND-VAL
                    SET L8140-ALLOC-BY-PERCENT-FND-VAL TO TRUE
028788              SET L8140-AGT-COMM-RQST            TO TRUE
                WHEN WS-SURR-BY-NO-OF-UNITS
                    SET L8140-ALLOC-BY-NO-OF-UNITS     TO TRUE
028788              SET L8140-AGT-COMM-RQST            TO TRUE
           END-EVALUATE.
      *
           MOVE WS-REASN-CODE         TO L8140-REASN-CD.
           MOVE WS-TRXN-AMT           TO L8140-SURR-AMOUNT.
           MOVE WS-EFF-DT             TO L8140-EFF-DT.
023437*    MOVE MIR-CIA-TAXWH-IND     TO L8140-TAX-BPSS-IND.
018731     MOVE MIR-CLI-ID            TO L8140-CLI-ID.
018731     MOVE MIR-CLI-BNK-ACCT-NUM  TO L8140-CLI-BNK-ACCT-NUM.
029060*    MOVE MIR-LTAXWH-CALC-CD TO L8140-LTAXWH-CALC-CD.
013693     SET  L8140-LTAXWH-DISB-NONP TO TRUE.
           MOVE MIR-SUPRES-CNFRM-IND  TO L8140-SUPR-CONF-IND.
016107     MOVE MIR-DV-REDC-FACE-IND  TO L8140-REDC-FACE-IND.
           MOVE MIR-CIA-SRC-DEST-CD   TO L8140-DEST-CD.
           SET L8140-DEFR-ALLOWED      TO TRUE.
029060*    MOVE WS-LOCPCT             TO L8140-LTAXWH-PCT.
022628*    MOVE WS-LOCAMT             TO L8140-LTAXWH-FLAT-AMT.
022628
022628     IF  MIR-DV-PRCES-STATE-CD = '3'
029060*    AND NOT L8140-LTAXWH-CALC
029060*       MOVE ZEROES             TO L8140-LTAXWH-FLAT-AMT
029060        MOVE ZEROES             TO L8140-LTAXWH-AMT
022628     ELSE
029060*       MOVE WS-LOCAMT          TO L8140-LTAXWH-FLAT-AMT
029060        MOVE WS-LOCAMT          TO L8140-LTAXWH-AMT
022628     END-IF.
022628
029060*    MOVE WS-FEDAMT             TO L8140-FED-TAXWH-AMT.
029060     MOVE WS-FEDAMT             TO L8140-FTAXWH-AMT.
      *
016153     IF  MIR-DV-PRCES-STATE-CD = '3'
016153         SET L8140-CONFIRM-STATE TO TRUE
016153     END-IF.
      *
016503     IF  WS-MSG-SUPPRESS
016503         SET L8140-MSG-SUPPRESS    TO TRUE
016503     END-IF.

013697     MOVE MIR-SURR-TAX-OVRID-CD TO L8140-SURR-TAX-OVRID-CD.
013697
013697     EVALUATE TRUE
013697         WHEN NOT RPOL-POL-PNSN-QUALF-NONE
013697
022210         IF  MIR-SURR-TAX-OVRID-CD    = SPACES
022210             SET L8140-SURR-TAX-OVRID-NORM TO TRUE
022210         END-IF
022210
013697         EVALUATE  TRUE
013697             WHEN  L8140-SURR-TAX-OVRID-IRA
013697             WHEN  L8140-SURR-TAX-ROLOVR-QUALF
013697             WHEN  L8140-SURR-TAX-OVRID-72T
013697             WHEN  L8140-SURR-TAX-ROTH-CNVR
013697             WHEN  L8140-SURR-TAX-OVRID-NORM
013697                   CONTINUE
013697
013697             WHEN  L8140-SURR-TAX-PREV-RCHAR
013697             WHEN  L8140-SURR-TAX-CURR-RCHAR
013697             WHEN  L8140-SURR-TAX-CURR-WTHDRW
013697             WHEN  L8140-SURR-TAX-PREV-WTHDRW
013697
013697                  IF  L8140-REASN-CNT
013697                      SET L8140-SURR-AMT-TYP-CNTR-AMT     TO TRUE
013697                      IF  L8140-SURR-TAX-PREV-RCHAR
013697                      OR  L8140-SURR-TAX-PREV-WTHDRW
013697                          SET L8140-PGAL-ALLOC-QUALF-PREV TO TRUE
013697                      ELSE
013697                          SET L8140-PGAL-ALLOC-QUALF-CRNT TO TRUE
013697                      END-IF
013697                  END-IF
013697
013697         END-EVALUATE
013697
013697     END-EVALUATE.
013697
013697     MOVE L8140-ALLOC-TYP-CD    TO MIR-PGAL-ALLOC-TYP-CD.
015290     SET L8140-TRXN-WTHDR       TO TRUE.
013697
       3550-BUILD-8140-LINKAGE-X.
           EXIT.
      *
023437*---------------------------
023437*3560-MOVE-TO-MIR-LTAXWH.
023437 3560-MOVE-TO-MIR-TAX-INFO.
023437*---------------------------
013693
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-SURR-GAIN-AMT * 100.
020874     MOVE L8140-SURR-GAIN-AMT   TO L0290-INPUT-V02.
013697     MOVE 2                     TO L0290-PRECISION.
023118*    MOVE LENGTH OF MIR-DV-GAIN-AMT
023118     MOVE LENGTH OF MIR-DV-SURR-GAIN-AMT
013697                                TO L0290-MAX-OUT-LEN.
013697     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
023118*    MOVE L0290-OUTPUT-DATA TO MIR-DV-GAIN-AMT.
023118     MOVE L0290-OUTPUT-DATA TO MIR-DV-SURR-GAIN-AMT.
013697
023437***  MOVE L8140-LTAXWH-CALC-CD TO MIR-LTAXWH-CALC-CD.
013693*RAG FOLLOWING IF STATEMENT
024958***  IF L8140-LTAXWH-CALC-CD = SPACES
024958***     CONTINUE
024958***  ELSE
024958***     MOVE L8140-LTAXWH-CALC-CD TO MIR-LTAXWH-CALC-CD
024958***  END-IF.
023437
028261*    IF  L8140-LTAXWH-FLAT-AMT > ZERO
028261*    AND L8140-LTAXWH-PCT      > ZERO
028261*       MOVE ZERO                 TO L8140-LTAXWH-PCT
028261*    END-IF.
013693
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-FED-TAXWH-AMT * 100.
029060*    MOVE L8140-FED-TAXWH-AMT  TO L0290-INPUT-V02.
029060     MOVE L8140-FTAXWH-AMT  TO L0290-INPUT-V02.
013693     MOVE 2                 TO L0290-PRECISION.
023437*    MOVE LENGTH OF MIR-FED-TAXWH-AMT
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                              TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT
029060                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
023437*    MOVE  L0290-OUTPUT-DATA            TO MIR-FED-TAXWH-AMT.
029060*    MOVE  L0290-OUTPUT-DATA            TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE  L0290-OUTPUT-DATA            TO MIR-FTAXWH-AMT.
013693
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-LTAXWH-FLAT-AMT * 100.
029060*    MOVE L8140-LTAXWH-FLAT-AMT  TO L0290-INPUT-V02.
029060     MOVE L8140-LTAXWH-AMT  TO L0290-INPUT-V02.
013693     MOVE 2                 TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                           TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
024958***  MOVE  L0290-OUTPUT-DATA            TO MIR-LTAXWH-FLAT-AMT.
029060*    MOVE  L0290-OUTPUT-DATA            TO MIR-CDA-LTAXWH-AMT.
029060     MOVE  L0290-OUTPUT-DATA            TO MIR-LTAXWH-AMT.    
013693
020874*    COMPUTE L0290-INPUT-NUMBER = L8140-LTAXWH-PCT * 100.
029060*    MOVE L8140-LTAXWH-PCT  TO L0290-INPUT-V02.
029060     MOVE WS-LOCPCT         TO L0290-INPUT-V02.
013693     MOVE 2                 TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                           TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA            TO MIR-LTAXWH-PCT.
029060     MOVE  L0290-OUTPUT-DATA            TO MIR-LTAXWH-RQST-PCT.

023437
029060*    MOVE L8140-FED-TAXWH-RQST-AMT  TO L0290-INPUT-V02.
029060     MOVE WS-FED-TAXWH-RQST-AMT     TO L0290-INPUT-V02.
023437     MOVE 2                         TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                   TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                    TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA        TO MIR-FED-TAXWH-RQST-AMT.
029060     MOVE  L0290-OUTPUT-DATA        TO MIR-FTAXWH-RQST-AMT.
023437
029060*    MOVE L8140-FED-TAXWH-RQST-PCT  TO L0290-INPUT-V02.
029060     MOVE WS-FED-TAXWH-RQST-PCT     TO L0290-INPUT-V02.
023437     MOVE 2                         TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                   TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                    TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA        TO MIR-FED-TAXWH-RQST-PCT.
029060     MOVE  L0290-OUTPUT-DATA        TO MIR-FTAXWH-RQST-PCT.
023437
023444     MOVE L8140-TAX-ACB-AMT TO L0290-INPUT-V02.
023444     MOVE 2                 TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
023444                            TO L0290-MAX-OUT-LEN.
023444     PERFORM  0290-2000-FORMAT-FOR-MIR
023444         THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-TAX-ACB-AMT.
023444
023444     MOVE L8140-TAXBL-PORTN-AMT   TO L0290-INPUT-V02.
023444     MOVE 2                 TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
023444                            TO L0290-MAX-OUT-LEN.
023444     PERFORM  0290-2000-FORMAT-FOR-MIR
023444         THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA TO MIR-DV-TAXBL-GRS-DSTRB-AMT.
023444
023444     IF  WS-REASN-GRS
023444         COMPUTE WS-TOT-SURR-AMT = L8140-SURR-AMOUNT
023444                                 - L8140-TRXN-FEE-AMT
023444     ELSE
023444         COMPUTE WS-TOT-SURR-AMT = L8140-SURR-AMOUNT
023444     END-IF.
023444     MOVE WS-TOT-SURR-AMT   TO L0290-INPUT-V02.
023444     MOVE 2                 TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
023444                            TO L0290-MAX-OUT-LEN.
023444     PERFORM  0290-2000-FORMAT-FOR-MIR
023444         THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA TO MIR-DV-GRS-DSTRB-AMT.
023444
023437*3560-MOVE-TO-MIR-LTAXWH-X.
023437 3560-MOVE-TO-MIR-TAX-INFO-X.
           EXIT.
      *
      *----------------------
       4000-PROCESS-TRANSFER.
      *----------------------
      *
      *
           EVALUATE TRUE
               WHEN MIR-DV-PRCES-STATE-CD = '1'
                   PERFORM 4100-PROCESS-TRANSFER-1
                      THRU 4100-PROCESS-TRANSFER-1-X
               WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM 4300-PROCESS-TRANSFER-2
                      THRU 4300-PROCESS-TRANSFER-2-X
               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM 4500-PROCESS-TRANSFER-3
                      THRU 4500-PROCESS-TRANSFER-3-X
           END-EVALUATE.
      *
       4000-PROCESS-TRANSFER-X.
           EXIT.
      *
      *------------------------
       4100-PROCESS-TRANSFER-1.
      *------------------------
      *
      * CLEAR THE BOTTOM OF THE SCREEN
           PERFORM 9100-CLEAR-DATA-FIELDS
              THRU 9100-CLEAR-DATA-FIELDS-X.
      *
           EVALUATE TRUE
               WHEN WS-TSFR-AMT-TO-AMT
                   PERFORM 4110-PRCES-XFER-AMT-TO-AMT
                      THRU 4110-PRCES-XFER-AMT-TO-AMT-X
020478*        WHEN WS-TSFR-AMT-TO-PCT
020478*            PERFORM 4130-PRCES-XFER-AMT-TO-PCT
020478*               THRU 4130-PRCES-XFER-AMT-TO-PCT-X
               WHEN WS-TSFR-PCT-TO-PCT
                   PERFORM 4150-PRCES-XFER-PCT-TO-PCT
                      THRU 4150-PRCES-XFER-PCT-TO-PCT-X
           END-EVALUATE.
      *
       4100-PROCESS-TRANSFER-1-X.
           EXIT.
      *
      *---------------------------
       4110-PRCES-XFER-AMT-TO-AMT.
      *---------------------------
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO WS-ZERO-AMT.

016848     MOVE ZERO                  TO WS-TOTAL-AMT.
           PERFORM 4111-DISPLAY-XFER-AMTS
              THRU 4111-DISPLAY-XFER-AMTS-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
016848     PERFORM  4112-DISPLAY-XFER-PCT
016848         THRU 4112-DISPLAY-XFER-PCT-X.


       4110-PRCES-XFER-AMT-TO-AMT-X.
           EXIT.
      *
      *-----------------------
       4111-DISPLAY-XFER-AMTS.
      *-----------------------
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
           EVALUATE TRUE
               WHEN LFUND-ALLOC-AMT (K) = ZERO
                   MOVE WS-ZERO-AMT   TO MIR-DV-FROM-FND-AMT-T (K)
                   MOVE WS-ZERO-AMT   TO MIR-DV-TO-FND-AMT-T (K)
               WHEN LFUND-ALLOC-AMT (K) < ZERO
                   MOVE WS-ZERO-AMT   TO MIR-DV-TO-FND-AMT-T (K)
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    LFUND-ALLOC-AMT (K) * -100
020874             COMPUTE L0290-INPUT-V02 =
020874                     LFUND-ALLOC-AMT (K) * -1
                   MOVE 2             TO L0290-PRECISION
                   MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-FROM-FND-AMT-T (K)
               WHEN LFUND-ALLOC-AMT (K) > ZERO
                   MOVE WS-ZERO-AMT   TO MIR-DV-FROM-FND-AMT-T (K)
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    LFUND-ALLOC-AMT (K) * 100
020874             MOVE LFUND-ALLOC-AMT (K) TO L0290-INPUT-V02
                   MOVE 2             TO L0290-PRECISION
                   MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-TO-FND-AMT-T (K)
016848             ADD LFUND-ALLOC-AMT (K)
016848                                TO WS-TOTAL-AMT
           END-EVALUATE.
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER.
020874     MOVE ZEROES                TO L0290-INPUT-V04.
           MOVE 4                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (K).
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER.
020874     MOVE ZEROES                TO L0290-INPUT-V04.
           MOVE 4                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-FIA-IN-ALLOC-PCT-T (K).
      *
       4111-DISPLAY-XFER-AMTS-X.
           EXIT.
016848
016848*---------------------------
016848 4112-DISPLAY-XFER-PCT.
016848*---------------------------
016848
016848     PERFORM
016848         VARYING K FROM 1 BY 1
016848         UNTIL K > LFUND-FND-CTR
016848
016848         EVALUATE TRUE
016848
016848             WHEN LFUND-ALLOC-AMT (K) < ZERO
016848                  COMPUTE WS-WORK-PCT ROUNDED
016848                             = LFUND-ALLOC-AMT (K)
016848                             / WS-TOTAL-AMT
016848                             * -100
020874*                 COMPUTE L0290-INPUT-NUMBER
020874*                            = WS-WORK-PCT
020874*                            * 10000
020874                  MOVE WS-WORK-PCT  TO L0290-INPUT-V04
016848                  MOVE 4            TO L0290-PRECISION
016848                  MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
016848                                    TO L0290-MAX-OUT-LEN
020874*                 PERFORM  0290-1000-NUMERIC-FORMAT
020874*                     THRU 0290-1000-NUMERIC-FORMAT-X
020874                  PERFORM 0290-2000-FORMAT-FOR-MIR
020874                     THRU 0290-2000-FORMAT-FOR-MIR-X
016848                  MOVE L0290-OUTPUT-DATA
016848                  TO MIR-FIA-OUT-ALLOC-PCT-T (K)
016848
016848             WHEN LFUND-ALLOC-AMT (K) > ZERO
016848                  COMPUTE WS-WORK-PCT ROUNDED
016848                             = LFUND-ALLOC-AMT (K)
016848                             / WS-TOTAL-AMT
016848                             * 100
020874*                 COMPUTE L0290-INPUT-NUMBER
020874*                            = WS-WORK-PCT
020874*                            * 10000
020874                  MOVE WS-WORK-PCT  TO L0290-INPUT-V04
016848                  MOVE 4            TO L0290-PRECISION
016848                  MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (1)
016848                                    TO L0290-MAX-OUT-LEN
020874*                 PERFORM  0290-1000-NUMERIC-FORMAT
020874*                     THRU 0290-1000-NUMERIC-FORMAT-X
020874                  PERFORM 0290-2000-FORMAT-FOR-MIR
020874                     THRU 0290-2000-FORMAT-FOR-MIR-X
016848                  MOVE L0290-OUTPUT-DATA
016848                  TO MIR-FIA-IN-ALLOC-PCT-T (K)
016848
016848         END-EVALUATE
016848
016848     END-PERFORM.
016848
016848
016848 4112-DISPLAY-XFER-PCT-X.
016848     EXIT.

      *---------------------------
020478*4130-PRCES-XFER-AMT-TO-PCT.
      *---------------------------
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020478*    MOVE ZERO                  TO L0290-INPUT-V02.
020478*    MOVE 2                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO WS-ZERO-AMT.
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020478*    MOVE ZERO                  TO L0290-INPUT-V04.
020478*    MOVE 4                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO WS-ZERO-PCT.
      *
020478*    MOVE ZERO                  TO WS-TOTAL-AMT.
020478*    PERFORM 4131-DISPLAY-XFER-AMT-PCT
020478*       THRU 4131-DISPLAY-XFER-AMT-PCT-X
020478*       VARYING K FROM 1 BY 1
020478*         UNTIL K > LFUND-FND-CTR.
020478*    PERFORM  4132-DISPLAY-XFER-PCT-AMT
020478*        THRU 4132-DISPLAY-XFER-PCT-AMT-X.
      *
020478*4130-PRCES-XFER-AMT-TO-PCT-X.
020478*    EXIT.
      *
      *
      *----------------------------
020478*4131-DISPLAY-XFER-AMT-PCT.
      *----------------------------
      *
020478*    PERFORM 8000-DISPLAY-FUND-KEYS
020478*       THRU 8000-DISPLAY-FUND-KEYS-X.
020478*
020478*    EVALUATE TRUE
020478*        WHEN LFUND-ALLOC-AMT (K) < ZERO
020478*            MOVE WS-ZERO-PCT   TO MIR-FIA-IN-ALLOC-PCT-T (K)
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    LFUND-ALLOC-AMT (K) * -100
020478*            COMPUTE L0290-INPUT-V02 =
020478*                    LFUND-ALLOC-AMT (K) * -1
020478*            MOVE 2             TO L0290-PRECISION
020478*            MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
020478*                               TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020478*            PERFORM 0290-2000-FORMAT-FOR-MIR
020478*               THRU 0290-2000-FORMAT-FOR-MIR-X
020478*            MOVE L0290-OUTPUT-DATA
020478*                               TO MIR-DV-FROM-FND-AMT-T (K)
020478*            ADD LFUND-ALLOC-AMT (K)
020478*                               TO WS-TOTAL-AMT
020478*        WHEN LFUND-ALLOC-AMT (K) > ZERO
020478*        WHEN LFUND-ALLOC-AMT (K) = ZERO
020478*            MOVE WS-ZERO-AMT   TO MIR-DV-TO-FND-AMT-T (K)
020478*    END-EVALUATE.
      *
020478*    EVALUATE TRUE
020478*        WHEN LFUND-ALLOC-PCT (K) > ZERO
020478*            MOVE WS-ZERO-AMT   TO MIR-DV-FROM-FND-AMT-T (K)
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    LFUND-ALLOC-PCT (K) * 10000
020478*            MOVE LFUND-ALLOC-PCT (K) TO L0290-INPUT-V04
020478*            MOVE 4             TO L0290-PRECISION
020478*            MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (1)
020478*                               TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020478*            PERFORM 0290-2000-FORMAT-FOR-MIR
020478*               THRU 0290-2000-FORMAT-FOR-MIR-X
020478*            MOVE L0290-OUTPUT-DATA
020478*                               TO MIR-FIA-IN-ALLOC-PCT-T (K)
020478*        WHEN LFUND-ALLOC-PCT (K) < ZERO
020478*        WHEN LFUND-ALLOC-PCT (K) = ZERO
020478*            MOVE WS-ZERO-PCT   TO MIR-FIA-IN-ALLOC-PCT-T (K)
020478*    END-EVALUATE.
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER.
020478*    MOVE ZEROES                TO L0290-INPUT-V04.
020478*    MOVE 4                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (K).
      *
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER.
020478*    MOVE ZEROES                TO L0290-INPUT-V02.
020478*    MOVE 2                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-TO-FND-AMT-T (K).
020478*
020478*4131-DISPLAY-XFER-AMT-PCT-X.
020478*    EXIT.
016848
016848*---------------------------
020478*4132-DISPLAY-XFER-PCT-AMT.
016848*---------------------------
016848
020478*    PERFORM
020478*        VARYING K FROM 1 BY 1
020478*        UNTIL K > LFUND-FND-CTR
020478*
020478*        EVALUATE TRUE
020478*
020478*            WHEN LFUND-ALLOC-AMT (K) < ZERO
020478*                 COMPUTE WS-WORK-PCT ROUNDED
020478*                            = LFUND-ALLOC-AMT (K)
020478*                            / WS-TOTAL-AMT
020478*                            * 100
020874*                 COMPUTE L0290-INPUT-NUMBER ROUNDED
020874*                            = WS-WORK-PCT
020874*                            * 10000
020478*                 COMPUTE L0290-INPUT-V04 ROUNDED
020478*                            = WS-WORK-PCT
020478*                 MOVE 4            TO L0290-PRECISION
020478*                 MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
020478*                                   TO L0290-MAX-OUT-LEN
020874*                 PERFORM  0290-1000-NUMERIC-FORMAT
020874*                     THRU 0290-1000-NUMERIC-FORMAT-X
020478*                 PERFORM 0290-2000-FORMAT-FOR-MIR
020478*                    THRU 0290-2000-FORMAT-FOR-MIR-X
020478*                 MOVE L0290-OUTPUT-DATA
020478*                 TO MIR-FIA-OUT-ALLOC-PCT-T (K)
020478*
020478*            WHEN LFUND-ALLOC-PCT (K) > ZERO
018763*                 COMPUTE WS-WORK-AMT ROUNDED
020478*                 COMPUTE L0279-CRCY-AMT
020478*                            = LFUND-ALLOC-PCT (K)
020478*                            * WS-TOTAL-AMT
020478*                            / -100
020478*                 PERFORM  0279-1000-CRCY-RND
020478*                     THRU 0279-1000-CRCY-RND-X
020478*                 MOVE L0279-CRCY-AMT TO WS-WORK-AMT
020874*                 COMPUTE L0290-INPUT-NUMBER ROUNDED
020874*                            = WS-WORK-AMT
020874*                            * 100
020478*                 COMPUTE L0290-INPUT-V02 ROUNDED
020478*                            = WS-WORK-AMT
020478*                 MOVE 2            TO L0290-PRECISION
020478*                 MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
020478*                                   TO L0290-MAX-OUT-LEN
020874*                 PERFORM  0290-1000-NUMERIC-FORMAT
020874*                     THRU 0290-1000-NUMERIC-FORMAT-X
020478*                 PERFORM 0290-2000-FORMAT-FOR-MIR
020478*                    THRU 0290-2000-FORMAT-FOR-MIR-X
020478*                 MOVE L0290-OUTPUT-DATA
020478*                 TO MIR-DV-TO-FND-AMT-T (K)
020478*
020478*        END-EVALUATE
020478*
020478*    END-PERFORM.
020478*
020478*
020478*4132-DISPLAY-XFER-PCT-AMT-X.
020478*    EXIT.
      *
      *---------------------------
       4150-PRCES-XFER-PCT-TO-PCT.
      *---------------------------
      *UNPROTECT FROM PCT, TO PCT
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V04.
           MOVE 4                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO WS-ZERO-PCT.
      *
016848     MOVE ZERO                  TO WS-TOTAL-AMT.
           PERFORM 4151-DISPLAY-XFER-PCTS
              THRU 4151-DISPLAY-XFER-PCTS-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
016848     PERFORM  4152-DISPLAY-XFER-AMTS
016848         THRU 4152-DISPLAY-XFER-AMTS-X.

       4150-PRCES-XFER-PCT-TO-PCT-X.
           EXIT.
      *----------------------------
       4151-DISPLAY-XFER-PCTS.
      *----------------------------
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
           EVALUATE TRUE
               WHEN LFUND-ALLOC-PCT (K) = ZERO
                   MOVE WS-ZERO-PCT   TO MIR-FIA-OUT-ALLOC-PCT-T (K)
                   MOVE WS-ZERO-PCT   TO MIR-FIA-IN-ALLOC-PCT-T (K)
               WHEN LFUND-ALLOC-PCT (K) < ZERO
                   MOVE WS-ZERO-PCT   TO MIR-FIA-IN-ALLOC-PCT-T (K)
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    LFUND-ALLOC-PCT (K) * -10000
020874             COMPUTE L0290-INPUT-V04 =
020874                     LFUND-ALLOC-PCT (K) * -1
                   MOVE 4             TO L0290-PRECISION
                   MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-FIA-OUT-ALLOC-PCT-T (K)
018763*            COMPUTE WS-WORK-AMT ROUNDED
018763             COMPUTE L0279-CRCY-AMT
016848                        = LFUND-ALLOC-PCT (K)
020469*                       * L8180-CFN-CV-AMT (K)
020469                        * L8180-CFN-POL-CRCY-CV-AMT (K)
016848                        / -100
018763             PERFORM  0279-1000-CRCY-RND
018763                 THRU 0279-1000-CRCY-RND-X
018763             MOVE L0279-CRCY-AMT TO WS-WORK-AMT
020874*            COMPUTE L0290-INPUT-NUMBER = WS-WORK-AMT * 100
020874             MOVE WS-WORK-AMT   TO L0290-INPUT-V02
016848             MOVE 2             TO L0290-PRECISION
016848             MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
016848                                TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
016848             MOVE L0290-OUTPUT-DATA
016848                                TO MIR-DV-FROM-FND-AMT-T (K)
016848
016848             ADD WS-WORK-AMT    TO WS-TOTAL-AMT
016848
               WHEN LFUND-ALLOC-PCT (K) > ZERO
                   MOVE WS-ZERO-PCT   TO MIR-FIA-OUT-ALLOC-PCT-T (K)
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    LFUND-ALLOC-PCT (K) * 10000
020874             MOVE LFUND-ALLOC-PCT (K) TO L0290-INPUT-V04
                   MOVE 4             TO L0290-PRECISION
                   MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-FIA-IN-ALLOC-PCT-T (K)

           END-EVALUATE.
      *
016848*    MOVE ZEROES                TO L0290-INPUT-NUMBER.
016848*    MOVE 2                     TO L0290-PRECISION.
016848*    MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
016848*                               TO L0290-MAX-OUT-LEN.
016848*    PERFORM 0290-1000-NUMERIC-FORMAT
016848*       THRU 0290-1000-NUMERIC-FORMAT-X.
016848*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (K).
016848*
020874*    MOVE ZEROES                TO L0290-INPUT-NUMBER.
020874     MOVE ZEROES                TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-TO-FND-AMT-T (K).

       4151-DISPLAY-XFER-PCTS-X.
           EXIT.
016848
016848*---------------------------
016848 4152-DISPLAY-XFER-AMTS.
016848*---------------------------
016848
016848     PERFORM
016848         VARYING K FROM 1 BY 1
016848         UNTIL K > LFUND-FND-CTR
016848
016848         IF  LFUND-ALLOC-PCT (K) > ZERO
018763*            COMPUTE WS-WORK-AMT ROUNDED
018763             COMPUTE L0279-CRCY-AMT
016848                        = LFUND-ALLOC-PCT (K)
016848                        * WS-TOTAL-AMT
016848                        / 100
018763             PERFORM  0279-1000-CRCY-RND
018763                 THRU 0279-1000-CRCY-RND-X
018763             MOVE L0279-CRCY-AMT TO WS-WORK-AMT
020874*            COMPUTE L0290-INPUT-NUMBER = WS-WORK-AMT * 100
020874             MOVE WS-WORK-AMT   TO L0290-INPUT-V02
016848             MOVE 2             TO L0290-PRECISION
016848             MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
016848                                TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
016848             MOVE L0290-OUTPUT-DATA
016848                                TO MIR-DV-TO-FND-AMT-T (K)
016848         END-IF
016848
016848     END-PERFORM.
016848
016848 4152-DISPLAY-XFER-AMTS-X.
016848     EXIT.
016848
      *------------------------
       4300-PROCESS-TRANSFER-2.
      *------------------------
      *
           EVALUATE TRUE
               WHEN WS-TSFR-AMT-TO-AMT
                   PERFORM 4310-PRCES-XFER-AMT-TO-AMT
                      THRU 4310-PRCES-XFER-AMT-TO-AMT-X
020478*        WHEN WS-TSFR-AMT-TO-PCT
020478*            PERFORM 4330-PRCES-XFER-AMT-TO-PCT
020478*               THRU 4330-PRCES-XFER-AMT-TO-PCT-X
               WHEN WS-TSFR-PCT-TO-PCT
                   PERFORM 4350-PRCES-XFER-PCT-TO-PCT
                      THRU 4350-PRCES-XFER-PCT-TO-PCT-X
           END-EVALUATE.
      *
       4300-PROCESS-TRANSFER-2-X.
           EXIT.
      *
      *---------------------------
       4310-PRCES-XFER-AMT-TO-AMT.
      *---------------------------
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO WS-ZERO-AMT.
      *
           MOVE SPACES                TO MIR-FIA-OUT-ALLOC-PCT-G.
           MOVE SPACES                TO MIR-FIA-IN-ALLOC-PCT-G.
      *
025970*    INITIALIZE WS-FROM-FND-TYP.
025970*    INITIALIZE WS-TO-FND-TYP.

025970     INITIALIZE WS-FROM-FND-TYP-CD.
025970     INITIALIZE WS-TO-FND-TYP-CD.
018846
           PERFORM 4311-EDIT-XFER-AMTS
              THRU 4311-EDIT-XFER-AMTS-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
016848     MOVE ZERO                   TO WS-TOTAL-AMT.

           IF MIR-DV-PRCES-STATE-CD NOT = '1'
               PERFORM 4315-EDIT-PROCES-REQUEST
                  THRU 4315-EDIT-PROCES-REQUEST-X
               IF MIR-RETRN-OK
016848             MOVE ZERO             TO WS-TOTAL-AMT
                   PERFORM 4111-DISPLAY-XFER-AMTS
                      THRU 4111-DISPLAY-XFER-AMTS-X
                      VARYING K FROM 1 BY 1
                        UNTIL K > LFUND-FND-CTR
016848             PERFORM  4112-DISPLAY-XFER-PCT
016848                 THRU 4112-DISPLAY-XFER-PCT-X
               END-IF
               GO TO 4310-PRCES-XFER-AMT-TO-AMT-X
           END-IF.
      *
           IF MIR-DV-PRCES-STATE-CD = '2'
016848         MOVE ZERO                  TO WS-TOTAL-AMT
               PERFORM 4111-DISPLAY-XFER-AMTS
                  THRU 4111-DISPLAY-XFER-AMTS-X
                  VARYING K FROM 1 BY 1
                    UNTIL K > LFUND-FND-CTR
016848         PERFORM  4112-DISPLAY-XFER-PCT
016848             THRU 4112-DISPLAY-XFER-PCT-X
           END-IF.
      *
       4310-PRCES-XFER-AMT-TO-AMT-X.
           EXIT.
      *
      *--------------------
       4311-EDIT-XFER-AMTS.
      *--------------------
      *
           IF MIR-DV-FROM-FND-AMT-T (K) = SPACE
           AND MIR-DV-TO-FND-AMT-T (K) = SPACE
               PERFORM 4111-DISPLAY-XFER-AMTS
                  THRU 4111-DISPLAY-XFER-AMTS-X
               GO TO 4311-EDIT-XFER-AMTS-X
           END-IF.
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
           MOVE ZERO                  TO WS-AMT-FROM.
           MOVE ZERO                  TO WS-AMT-TO.
      *
           IF MIR-DV-FROM-FND-AMT-T (K) > SPACE
               MOVE MIR-DV-FROM-FND-AMT-T (K)
                                      TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                      L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-AMT-FROM
               ELSE
                   MOVE ZERO          TO LFUND-ALLOC-AMT (K)
                   MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 4311-EDIT-XFER-AMTS-X
               END-IF
           END-IF.
      *
           IF MIR-DV-TO-FND-AMT-T (K) > SPACE
               MOVE MIR-DV-TO-FND-AMT-T (K)
                                      TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                      L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-AMT-TO
               ELSE
                   MOVE ZERO          TO LFUND-ALLOC-AMT (K)
                   MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 4311-EDIT-XFER-AMTS-X
               END-IF
           END-IF.
      *
           IF  WS-AMT-FROM = ZERO
           AND WS-AMT-TO   = ZERO
               MOVE WS-AMT-FROM       TO LFUND-ALLOC-AMT (K)
               MOVE SPACES            TO LFUND-ALLOC-CD (K)
               PERFORM 4111-DISPLAY-XFER-AMTS
                  THRU 4111-DISPLAY-XFER-AMTS-X
               GO TO 4311-EDIT-XFER-AMTS-X
           END-IF.
      *
           IF  WS-AMT-FROM > ZERO
           AND WS-AMT-TO > ZERO
               MOVE ZERO              TO LFUND-ALLOC-AMT (K)
      * MESSAGE - CANNOT TRANSFER FROM AND TO THE SAME FUND
               MOVE 'CS82200022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4311-EDIT-XFER-AMTS-X
           END-IF.
      *
           IF  WS-AMT-FROM > ZERO
018846         MOVE LFUND-CVG-NUM-N (K)     TO WS-CVG-NUM
018846         EVALUATE TRUE
018846
018846             WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846                  PERFORM  4420-SET-XFER-FROM-REGFND
018846                      THRU 4420-SET-XFER-FROM-REGFND-X
018846
018846             WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846                  PERFORM  4410-SET-XFER-FROM-SIDFND
018846                      THRU 4410-SET-XFER-FROM-SIDFND-X
018846
018846         END-EVALUATE
               COMPUTE LFUND-ALLOC-AMT (K) = -1
                                           * WS-AMT-FROM
               SET LFUND-ALLOC-AMOUNT (K) TO TRUE
               PERFORM 4111-DISPLAY-XFER-AMTS
                  THRU 4111-DISPLAY-XFER-AMTS-X
               GO TO 4311-EDIT-XFER-AMTS-X
           END-IF.
      *
           IF  WS-AMT-TO > ZERO
018846         MOVE LFUND-CVG-NUM-N (K)     TO WS-CVG-NUM
018846         EVALUATE TRUE
018846
018846             WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846                  PERFORM  4440-SET-XFER-TO-REGFND
018846                      THRU 4440-SET-XFER-TO-REGFND-X
018846
018846             WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846                  PERFORM  4430-SET-XFER-TO-SIDFND
018846                      THRU 4430-SET-XFER-TO-SIDFND-X
018846
018846         END-EVALUATE
               MOVE WS-AMT-TO         TO LFUND-ALLOC-AMT (K)
               SET LFUND-ALLOC-AMOUNT (K) TO TRUE
               PERFORM 4111-DISPLAY-XFER-AMTS
                  THRU 4111-DISPLAY-XFER-AMTS-X
           END-IF.
      *
       4311-EDIT-XFER-AMTS-X.
           EXIT.
      *
      *-------------------------
       4315-EDIT-PROCES-REQUEST.
      *-------------------------
      *
           MOVE ZERO                  TO WS-WORK-AMT.
           PERFORM
                 VARYING K FROM 1 BY 1
                 UNTIL K > LFUND-FND-CTR
               SUBTRACT LFUND-ALLOC-AMT (K) FROM WS-WORK-AMT
           END-PERFORM.
      *
           IF WS-WORK-AMT NOT = ZERO
      * MESSAGE - 'TO AMOUNT' DOES NOT MATCH 'FROM AMOUNT'
               MOVE 'CS82200024'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 4315-EDIT-PROCES-REQUEST-X
           END-IF.
      *
018846     PERFORM  4450-CROSS-EDIT-TRANSFER
018846         THRU 4450-CROSS-EDIT-TRANSFER-X.
018846     IF  MIR-RETRN-EDIT-ERROR
018846         GO TO 4315-EDIT-PROCES-REQUEST-X
018846     END-IF.
018846
016503     MOVE 'Y'                    TO L8150-REDO-WARNING-SW.
           PERFORM 4550-BUILD-8150-LINKAGE
              THRU 4550-BUILD-8150-LINKAGE-X.
           SET L8150-PRCES-TYP-EDIT-ONLY TO TRUE.
           PERFORM 8150-1000-PRCES-XFER
              THRU 8150-1000-PRCES-XFER-X.
      *
           IF NOT L8150-RETRN-OK
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
020874* REVERTED BACK TO L0290-INPUT-NUMBER AS WE DO NOT NEED TO
020874* MULTIPLY L8150-TRXN-FEE-AMT BY 100
           MOVE L8150-TRXN-FEE-AMT    TO L0290-INPUT-NUMBER.
020874*    MOVE L8150-TRXN-FEE-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
      *
       4315-EDIT-PROCES-REQUEST-X.
           EXIT.
      *
      *---------------------------
020478*4330-PRCES-XFER-AMT-TO-PCT.
      *---------------------------
      *EDIT FROM AMT, TO PCT
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020478*    MOVE ZERO                  TO L0290-INPUT-V02.
020478*    MOVE 2                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO WS-ZERO-AMT.
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020478*    MOVE ZERO                  TO L0290-INPUT-V04.
020478*    MOVE 4                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO WS-ZERO-PCT.
      *
020478*    MOVE SPACES                TO MIR-FIA-OUT-ALLOC-PCT-G.
020478*    MOVE SPACES                TO MIR-DV-TO-FND-AMT-G.
      *
025970*    INITIALIZE WS-FROM-FND-TYP.
025970*    INITIALIZE WS-TO-FND-TYP.

020478*    INITIALIZE WS-FROM-FND-TYP-CD.
020478*    INITIALIZE WS-TO-FND-TYP-CD.
020478*
020478*    PERFORM 4331-EDIT-XFER-AMT-TO-PCT
020478*       THRU 4331-EDIT-XFER-AMT-TO-PCT-X
020478*       VARYING K FROM 1 BY 1
020478*         UNTIL K > LFUND-FND-CTR.
      *
020478*    IF MIR-DV-PRCES-STATE-CD NOT = '1'
020478*        PERFORM 4335-EDIT-PROCES-REQUEST
020478*           THRU 4335-EDIT-PROCES-REQUEST-X
020478*        IF MIR-RETRN-OK
020478*            MOVE ZERO             TO WS-TOTAL-AMT
020478*            PERFORM 4131-DISPLAY-XFER-AMT-PCT
020478*               THRU 4131-DISPLAY-XFER-AMT-PCT-X
020478*               VARYING K FROM 1 BY 1
020478*                 UNTIL K > LFUND-FND-CTR
020478*            PERFORM  4132-DISPLAY-XFER-PCT-AMT
020478*                THRU 4132-DISPLAY-XFER-PCT-AMT-X
020478*        END-IF
020478*        GO TO 4330-PRCES-XFER-AMT-TO-PCT-X
020478*    END-IF.
      *
020478*    IF MIR-DV-PRCES-STATE-CD = '2'
020478*        MOVE ZERO              TO WS-TOTAL-AMT
020478*        PERFORM 4131-DISPLAY-XFER-AMT-PCT
020478*           THRU 4131-DISPLAY-XFER-AMT-PCT-X
020478*           VARYING K FROM 1 BY 1
020478*             UNTIL K > LFUND-FND-CTR
020478*        PERFORM  4132-DISPLAY-XFER-PCT-AMT
020478*            THRU 4132-DISPLAY-XFER-PCT-AMT-X
020478*    END-IF.
020478*
020478*4330-PRCES-XFER-AMT-TO-PCT-X.
020478*    EXIT.
      *
      *--------------------
020478*4331-EDIT-XFER-AMT-TO-PCT.
020478*--------------------
020478*
020478*    IF MIR-DV-FROM-FND-AMT-T (K) = SPACE
020478*    AND MIR-FIA-IN-ALLOC-PCT-T (K) = SPACE
020478*        PERFORM 4131-DISPLAY-XFER-AMT-PCT
020478*           THRU 4131-DISPLAY-XFER-AMT-PCT-X
020478*        GO TO 4331-EDIT-XFER-AMT-TO-PCT-X
020478*    END-IF.
020478*
020478*    MOVE ZERO                  TO WS-AMT-FROM.
020478*    MOVE ZERO                  TO WS-PCT-TO.
020478*
020478*    PERFORM 8000-DISPLAY-FUND-KEYS
020478*       THRU 8000-DISPLAY-FUND-KEYS-X.
020478*
020478*    IF MIR-DV-FROM-FND-AMT-T (K) > SPACE
020478*        MOVE MIR-DV-FROM-FND-AMT-T (K)
020478*                               TO L0280-INPUT-DATA
020478*        SET L0280-SIGN-NOT-PERMITTED TO TRUE
020478*        MOVE 2                 TO L0280-PRECISION
020478*        MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
020478*                               TO L0280-INPUT-SIZE
020478*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
020478*                               L0280-PRECISION - 1
020478*        PERFORM  0280-1000-NUMERIC-EDIT
020478*            THRU 0280-1000-NUMERIC-EDIT-X
020478*        IF L0280-OK
020478*            MOVE L0280-OUTPUT-DOLLAR
020478*                               TO WS-AMT-FROM
020478*        ELSE
020478*            MOVE ZERO          TO LFUND-ALLOC-AMT (K)
020478*            MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*            GO TO 4331-EDIT-XFER-AMT-TO-PCT-X
020478*        END-IF
020478*    END-IF.
020478*
020478*    IF MIR-FIA-IN-ALLOC-PCT-T (K) > SPACE
020478*        MOVE MIR-FIA-IN-ALLOC-PCT-T (K)
020478*                               TO L0280-INPUT-DATA
020478*        SET L0280-SIGN-NOT-PERMITTED TO TRUE
020478*        MOVE 4                 TO L0280-PRECISION
020478*        MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (1)
020478*                               TO L0280-INPUT-SIZE
020478*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
020478*                               L0280-PRECISION - 1
020478*        PERFORM  0280-1000-NUMERIC-EDIT
020478*            THRU 0280-1000-NUMERIC-EDIT-X
020478*        IF L0280-OK
020478*            MOVE L0280-OUTPUT-V04
020478*                               TO WS-PCT-TO
020478*        ELSE
020478*            MOVE ZERO          TO LFUND-ALLOC-PCT (K)
020478*            MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*            GO TO 4331-EDIT-XFER-AMT-TO-PCT-X
020478*        END-IF
020478*    END-IF.
020478*
020478*    IF  WS-AMT-FROM = ZERO
020478*    AND WS-PCT-TO   = ZERO
020478*        MOVE ZERO              TO LFUND-ALLOC-PCT (K)
020478*        MOVE SPACE             TO LFUND-ALLOC-CD (K)
020478*        PERFORM 4131-DISPLAY-XFER-AMT-PCT
020478*           THRU 4131-DISPLAY-XFER-AMT-PCT-X
020478*        GO TO 4331-EDIT-XFER-AMT-TO-PCT-X
020478*    END-IF.
020478*
020478*    IF  WS-AMT-FROM > ZERO
020478*    AND WS-PCT-TO   > ZERO
020478*        MOVE ZERO              TO LFUND-ALLOC-AMT (K)
020478*        MOVE ZERO              TO LFUND-ALLOC-PCT (K)
020478*        MOVE SPACE             TO LFUND-ALLOC-CD (K)
020478*        MOVE 'CS82200022'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        GO TO 4331-EDIT-XFER-AMT-TO-PCT-X
020478*    END-IF.
020478*
020478*    IF  WS-AMT-FROM > ZERO
020478*        MOVE LFUND-CVG-NUM-N (K)     TO WS-CVG-NUM
020478*        EVALUATE TRUE
020478*
020478*            WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
020478*                 PERFORM  4420-SET-XFER-FROM-REGFND
020478*                     THRU 4420-SET-XFER-FROM-REGFND-X
020478*
020478*            WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
020478*                 PERFORM  4410-SET-XFER-FROM-SIDFND
020478*                     THRU 4410-SET-XFER-FROM-SIDFND-X
020478*
020478*        END-EVALUATE
020478*
020478*        COMPUTE LFUND-ALLOC-AMT (K) = -1
020478*                                    * WS-AMT-FROM
020478*        SET LFUND-ALLOC-AMOUNT (K) TO TRUE
020478*        PERFORM 4131-DISPLAY-XFER-AMT-PCT
020478*           THRU 4131-DISPLAY-XFER-AMT-PCT-X
020478*        GO TO 4331-EDIT-XFER-AMT-TO-PCT-X
020478*    END-IF.
020478*
020478*    IF WS-PCT-TO > ZERO
020478*        MOVE LFUND-CVG-NUM-N (K)     TO WS-CVG-NUM
020478*        EVALUATE TRUE
020478*
020478*            WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
020478*                 PERFORM  4440-SET-XFER-TO-REGFND
020478*                     THRU 4440-SET-XFER-TO-REGFND-X
020478*
020478*            WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
020478*                 PERFORM  4430-SET-XFER-TO-SIDFND
020478*                     THRU 4430-SET-XFER-TO-SIDFND-X
020478*
020478*        END-EVALUATE
020478*
020478*        MOVE WS-PCT-TO         TO LFUND-ALLOC-PCT (K)
020478*        SET LFUND-ALLOC-PERCENT (K) TO TRUE
020478*        PERFORM 4131-DISPLAY-XFER-AMT-PCT
020478*           THRU 4131-DISPLAY-XFER-AMT-PCT-X
020478*    END-IF.
020478*
020478*4331-EDIT-XFER-AMT-TO-PCT-X.
020478*    EXIT.
      *
      *-------------------------
020478*4335-EDIT-PROCES-REQUEST.
      *-------------------------
      *
020478*    PERFORM  4450-CROSS-EDIT-TRANSFER
020478*        THRU 4450-CROSS-EDIT-TRANSFER-X.
020478*    IF  MIR-RETRN-EDIT-ERROR
020478*        GO TO 4335-EDIT-PROCES-REQUEST-X
020478*    END-IF.
020478*
020478*    MOVE ZERO                  TO WS-WORK-AMT.
020478*    MOVE ZERO                  TO WS-PCT-TO.
020478*    PERFORM
020478*         VARYING K FROM 1 BY 1
020478*         UNTIL K > LFUND-FND-CTR
020478*        IF LFUND-ALLOC-PCT (K) > ZERO
020478*            ADD      LFUND-ALLOC-PCT (K)   TO WS-PCT-TO
020478*        ELSE
020478*            SUBTRACT LFUND-ALLOC-AMT (K) FROM WS-WORK-AMT
020478*        END-IF
020478*    END-PERFORM.
      *
020478*    IF WS-WORK-AMT NOT > ZERO
020478* MESSAGE - AT LEAST ONE 'FROM AMOUNT' MUST BE ENTERED
020478*        MOVE 'CS82200035'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        SET MIR-RETRN-EDIT-ERROR TO TRUE
020478*        GO TO 4335-EDIT-PROCES-REQUEST-X
020478*    END-IF.
020478*
020478*    IF WS-PCT-TO NOT = 100.0000
020478* MESSAGE - PERCENTAGES DO NOT ADD UP TO 100.0000
020478*        MOVE 'CS82200019'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        SET MIR-RETRN-EDIT-ERROR TO TRUE
020478*        GO TO 4335-EDIT-PROCES-REQUEST-X
020478*    END-IF.
020478*
020478*    MOVE 'Y'                    TO L8150-REDO-WARNING-SW.
020478*    PERFORM 4550-BUILD-8150-LINKAGE
020478*       THRU 4550-BUILD-8150-LINKAGE-X.
020478*    SET L8150-PRCES-TYP-EDIT-ONLY TO TRUE.
020478*    PERFORM 8150-1000-PRCES-XFER
020478*       THRU 8150-1000-PRCES-XFER-X.
020478*
020478*    IF NOT L8150-RETRN-OK
020478*        SET MIR-RETRN-EDIT-ERROR TO TRUE
020478*    END-IF.
      *
020874* REVERTED BACK TO L0290-INPUT-NUMBER AS WE DO NOT NEED TO
020874* MULTIPLY L8150-TRXN-FEE-AMT BY 100
020478*    MOVE L8150-TRXN-FEE-AMT    TO L0290-INPUT-NUMBER.
020874*    MOVE L8150-TRXN-FEE-AMT    TO L0290-INPUT-V02.
020478*    MOVE 2                     TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-CIA-LOAD-AMT
020478*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
020478*
020478*4335-EDIT-PROCES-REQUEST-X.
020478*    EXIT.
      *
      *---------------------------
       4350-PRCES-XFER-PCT-TO-PCT.
      *---------------------------
      *EDIT FROM PCT, TO PCT
      *
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V04.
           MOVE 4                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO WS-ZERO-PCT.
      *
           MOVE SPACES                TO MIR-DV-FROM-FND-AMT-G.
           MOVE SPACES                TO MIR-DV-TO-FND-AMT-G.
      *
025970*    INITIALIZE WS-FROM-FND-TYP.
025970*    INITIALIZE WS-TO-FND-TYP.

025970     INITIALIZE WS-FROM-FND-TYP-CD.
025970     INITIALIZE WS-TO-FND-TYP-CD.
018846
           PERFORM 4351-EDIT-XFER-PCTS
              THRU 4351-EDIT-XFER-PCTS-X
              VARYING K FROM 1 BY 1
                UNTIL K > LFUND-FND-CTR.
      *
           IF MIR-DV-PRCES-STATE-CD NOT = '1'
               PERFORM 4355-EDIT-PROCES-REQUEST
                  THRU 4355-EDIT-PROCES-REQUEST-X
               IF MIR-RETRN-OK
016848             MOVE ZERO           TO WS-TOTAL-AMT
                   PERFORM 4151-DISPLAY-XFER-PCTS
                      THRU 4151-DISPLAY-XFER-PCTS-X
                      VARYING K FROM 1 BY 1
                        UNTIL K > LFUND-FND-CTR
016848             PERFORM  4152-DISPLAY-XFER-AMTS
016848                 THRU 4152-DISPLAY-XFER-AMTS-X
               END-IF
               GO TO 4350-PRCES-XFER-PCT-TO-PCT-X
           END-IF.
      *
           IF MIR-DV-PRCES-STATE-CD = '2'
016848         MOVE ZERO               TO WS-TOTAL-AMT
               PERFORM 4151-DISPLAY-XFER-PCTS
                  THRU 4151-DISPLAY-XFER-PCTS-X
                  VARYING K FROM 1 BY 1
                    UNTIL K > LFUND-FND-CTR
016848         PERFORM  4152-DISPLAY-XFER-AMTS
016848             THRU 4152-DISPLAY-XFER-AMTS-X
           END-IF.
      *
       4350-PRCES-XFER-PCT-TO-PCT-X.
           EXIT.
      *
      *--------------------
       4351-EDIT-XFER-PCTS.
      *--------------------
      *
           IF MIR-FIA-OUT-ALLOC-PCT-T (K) = SPACE
           AND MIR-FIA-IN-ALLOC-PCT-T (K) = SPACE
               PERFORM 4151-DISPLAY-XFER-PCTS
                  THRU 4151-DISPLAY-XFER-PCTS-X
               GO TO 4351-EDIT-XFER-PCTS-X
           END-IF.
      *
           MOVE ZERO                  TO WS-PCT-FROM.
           MOVE ZERO                  TO WS-PCT-TO.
      *
           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.
      *
           IF  MIR-FIA-OUT-ALLOC-PCT-T (K) > SPACE
               MOVE MIR-FIA-OUT-ALLOC-PCT-T (K)
                                      TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE 4                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                      L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-V04
                                      TO WS-PCT-FROM
               ELSE
                   MOVE ZERO          TO LFUND-ALLOC-PCT (K)
                   MOVE ZERO          TO WS-PCT-FROM
                   MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 4351-EDIT-XFER-PCTS-X
               END-IF
           END-IF.
      *
           IF MIR-FIA-IN-ALLOC-PCT-T (K) > SPACE
               MOVE MIR-FIA-IN-ALLOC-PCT-T (K)
                                      TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE 4                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (1)
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                      L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-V04
                                      TO WS-PCT-TO
               ELSE
                   MOVE ZERO          TO LFUND-ALLOC-PCT (K)
                   MOVE ZERO          TO WS-PCT-TO
                   MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF WS-PCT-FROM = ZERO
           AND  WS-PCT-TO = ZERO
               MOVE ZERO              TO LFUND-ALLOC-PCT (K)
               MOVE SPACE             TO LFUND-ALLOC-CD (K)
               PERFORM 4151-DISPLAY-XFER-PCTS
                  THRU 4151-DISPLAY-XFER-PCTS-X
               GO TO 4351-EDIT-XFER-PCTS-X
           END-IF.

           IF WS-PCT-FROM > ZERO
           AND  WS-PCT-TO > ZERO
               MOVE ZERO              TO LFUND-ALLOC-PCT (K)
               MOVE SPACE             TO LFUND-ALLOC-CD (K)
      * MESSAGE - CANNOT TRANSFER FROM AND TO THE SAME FUND
               MOVE 'CS82200022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4351-EDIT-XFER-PCTS-X
           END-IF.
      *
           IF WS-PCT-FROM > ZERO
018846         MOVE LFUND-CVG-NUM-N (K)     TO WS-CVG-NUM
018846         EVALUATE TRUE
018846
018846             WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846                  PERFORM  4420-SET-XFER-FROM-REGFND
018846                     THRU 4420-SET-XFER-FROM-REGFND-X
018846
018846             WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846                  PERFORM  4410-SET-XFER-FROM-SIDFND
018846                      THRU 4410-SET-XFER-FROM-SIDFND-X
018846
018846         END-EVALUATE
               COMPUTE LFUND-ALLOC-PCT (K) = -1
                                           * WS-PCT-FROM
               SET LFUND-ALLOC-PERCENT (K) TO TRUE
               PERFORM 4151-DISPLAY-XFER-PCTS
                  THRU 4151-DISPLAY-XFER-PCTS-X
               GO TO 4351-EDIT-XFER-PCTS-X
           END-IF.

           IF WS-PCT-TO > ZERO
018846         MOVE LFUND-CVG-NUM-N (K)     TO WS-CVG-NUM
018846         EVALUATE TRUE
018846
018846             WHEN NOT WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846                  PERFORM  4440-SET-XFER-TO-REGFND
018846                      THRU 4440-SET-XFER-TO-REGFND-X
018846
018846             WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846                  PERFORM  4430-SET-XFER-TO-SIDFND
018846                      THRU 4430-SET-XFER-TO-SIDFND-X
018846
018846         END-EVALUATE
               MOVE WS-PCT-TO         TO LFUND-ALLOC-PCT (K)
               SET LFUND-ALLOC-PERCENT (K) TO TRUE
               PERFORM 4151-DISPLAY-XFER-PCTS
                  THRU 4151-DISPLAY-XFER-PCTS-X
           END-IF.
      *
       4351-EDIT-XFER-PCTS-X.
           EXIT.
      *
      *-------------------------
       4355-EDIT-PROCES-REQUEST.
      *-------------------------
      *
           MOVE ZERO                  TO WS-PCT-FROM.
           MOVE ZERO                  TO WS-PCT-TO.
           PERFORM
              VARYING K FROM 1 BY 1
              UNTIL K > LFUND-FND-CTR
               IF LFUND-ALLOC-PCT (K) > ZERO
                   ADD LFUND-ALLOC-PCT (K) TO WS-PCT-TO
               ELSE
                   ADD LFUND-ALLOC-PCT (K) TO WS-PCT-FROM
               END-IF
           END-PERFORM.
      *
           IF WS-PCT-TO NOT = 100.0000
      * MESSAGE - PERCENTAGES DO NOT ADD UP TO 100.0000
               MOVE 'CS82200019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           IF  WS-PCT-FROM = ZERO
      * MESSAGE - TRANSFER FROM AMOUNT/PERCENT NOT SPECIFIED - REENTER
               MOVE 'CS82200021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           IF MIR-RETRN-EDIT-ERROR
               GO TO 4355-EDIT-PROCES-REQUEST-X
           END-IF.
      *
018846     PERFORM  4450-CROSS-EDIT-TRANSFER
018846         THRU 4450-CROSS-EDIT-TRANSFER-X.
018846     IF  MIR-RETRN-EDIT-ERROR
018846         GO TO 4355-EDIT-PROCES-REQUEST-X
018846     END-IF.
018846
016503     MOVE 'Y'                    TO L8150-REDO-WARNING-SW.
           PERFORM 4550-BUILD-8150-LINKAGE
              THRU 4550-BUILD-8150-LINKAGE-X.
           SET L8150-PRCES-TYP-EDIT-ONLY TO TRUE.
           PERFORM 8150-1000-PRCES-XFER
              THRU 8150-1000-PRCES-XFER-X.
      *
           IF NOT L8150-RETRN-OK
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
020874* REVERTED BACK TO L0290-INPUT-NUMBER AS WE DO NOT NEED TO
020874* MULTIPLY L8150-TRXN-FEE-AMT BY 100
           MOVE L8150-TRXN-FEE-AMT    TO L0290-INPUT-NUMBER.
020874*    MOVE L8150-TRXN-FEE-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
      *
       4355-EDIT-PROCES-REQUEST-X.
           EXIT.
      *
018846*---------------------------
018846 4410-SET-XFER-FROM-SIDFND.
018846*---------------------------
018846
018846     EVALUATE TRUE
018846
018846         WHEN WS-FROM-FND-TYP-SIDE
018846         WHEN WS-FROM-FND-TYP-BOTH
018846              CONTINUE
018846
018846         WHEN WS-FROM-FND-TYP-REG
018846              SET WS-FROM-FND-TYP-BOTH     TO TRUE
018846
018846         WHEN OTHER
018846              SET WS-FROM-FND-TYP-SIDE     TO TRUE
018846
018846     END-EVALUATE.
018846
018846 4410-SET-XFER-FROM-SIDFND-X.
018846     EXIT.
018846
018846*---------------------------
018846 4420-SET-XFER-FROM-REGFND.
018846*---------------------------
018846
018846     EVALUATE TRUE
018846
018846         WHEN WS-FROM-FND-TYP-REG
018846         WHEN WS-FROM-FND-TYP-BOTH
018846              CONTINUE
018846
018846         WHEN WS-FROM-FND-TYP-SIDE
018846              SET WS-FROM-FND-TYP-BOTH     TO TRUE
018846
018846         WHEN OTHER
018846              SET WS-FROM-FND-TYP-REG      TO TRUE
018846
018846     END-EVALUATE.
018846
018846 4420-SET-XFER-FROM-REGFND-X.
018846     EXIT.
018846
018846*---------------------------
018846 4430-SET-XFER-TO-SIDFND.
018846*---------------------------
018846
018846     EVALUATE TRUE
018846
018846         WHEN WS-TO-FND-TYP-SIDE
018846         WHEN WS-TO-FND-TYP-BOTH
018846              CONTINUE
018846
018846         WHEN WS-TO-FND-TYP-REG
018846              SET WS-TO-FND-TYP-BOTH       TO TRUE
018846
018846         WHEN OTHER
018846              SET WS-TO-FND-TYP-SIDE       TO TRUE
018846
018846     END-EVALUATE.
018846
018846 4430-SET-XFER-TO-SIDFND-X.
018846     EXIT.
018846
018846*---------------------------
018846 4440-SET-XFER-TO-REGFND.
018846*---------------------------
018846
018846     EVALUATE TRUE
018846
018846         WHEN WS-TO-FND-TYP-REG
018846         WHEN WS-TO-FND-TYP-BOTH
018846              CONTINUE
018846
018846         WHEN WS-TO-FND-TYP-SIDE
018846              SET WS-TO-FND-TYP-BOTH       TO TRUE
018846
018846         WHEN OTHER
018846              SET WS-TO-FND-TYP-REG        TO TRUE
018846
018846     END-EVALUATE.
018846
018846 4440-SET-XFER-TO-REGFND-X.
018846     EXIT.
018846
018846*---------------------------
018846 4450-CROSS-EDIT-TRANSFER.
018846*---------------------------
018846
018846     IF  (WS-FROM-FND-TYP-SIDE
018846        AND WS-TO-FND-TYP-SIDE)
018846     OR  (WS-FROM-FND-TYP-REG
018846        AND WS-TO-FND-TYP-REG)
018846         CONTINUE
018846     ELSE
018846*MSG: TRANSFER INVOLVES SIDE FUND. CHARGES AND LOADS WILL APPLY.
018846*     USE SURRENDER BUSINESS PROCESS.
018846         MOVE 'CS82200052'      TO WGLOB-MSG-REF-INFO
018846         PERFORM  0260-1000-GENERATE-MESSAGE
018846             THRU 0260-1000-GENERATE-MESSAGE-X
018846         IF  WGLOB-MSG-SEVRTY-FATAL
018846             SET MIR-RETRN-EDIT-ERROR TO TRUE
018846         END-IF
018846     END-IF.
018846
018846 4450-CROSS-EDIT-TRANSFER-X.
018846     EXIT.
018846
      *------------------------
       4500-PROCESS-TRANSFER-3.
      *------------------------
      *
           PERFORM 4300-PROCESS-TRANSFER-2
              THRU 4300-PROCESS-TRANSFER-2-X.
      *
           IF NOT MIR-RETRN-OK
               GO TO 4500-PROCESS-TRANSFER-3-X
           END-IF.
      *
           PERFORM POL-1000-READ-FOR-UPDATE
              THRU POL-1000-READ-FOR-UPDATE-X.
           IF NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4500-PROCESS-TRANSFER-3-X
           END-IF.
           MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.

016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.
016440     SET L5400-POL-XFER-UPDATE          TO TRUE
016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.
016440
016440*
016440* CHECK THE ACCESS RESTRICTION CODES
016440*
016440     IF L5400-XFER-ACCS-RESTRICTED
016440        GO TO 4500-PROCESS-TRANSFER-3-X
016440     END-IF.

016503     SET WS-REDO-OK                     TO TRUE.
016503     IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503         CONTINUE
016503     ELSE
016503         PERFORM  8550-INVOKE-REDO
016503             THRU 8550-INVOKE-REDO-X
016503     END-IF.

016503     IF  WS-REDO-NOT-OK
016503         GO TO 4500-PROCESS-TRANSFER-3-X
016503     END-IF.

           PERFORM  8600-INVOKE-UNDO
               THRU 8600-INVOKE-UNDO-X.

           IF NOT WGLOB-GOOD-RETURN
               GO TO 4500-PROCESS-TRANSFER-3-X
           END-IF.

016503     MOVE 'Y'                    TO L8150-REDO-WARNING-SW.
           PERFORM 4550-BUILD-8150-LINKAGE
              THRU 4550-BUILD-8150-LINKAGE-X.
           SET L8150-PRCES-TYP-ALL     TO TRUE.
           PERFORM 3510-ELIMINATE-UNUSED-FUNDS
              THRU 3510-ELIMINATE-UNUSED-FUNDS-X.
018323     SET L8150-MSG-SUPPRESS      TO TRUE.
           PERFORM 8150-1000-PRCES-XFER
              THRU 8150-1000-PRCES-XFER-X.
      *
           IF L8150-RETRN-OK
           OR RPOL-REC-INFO NOT = HPOL-REC-INFO
               PERFORM 8500-UPDATE-POLICY-AND-CVGS
                  THRU 8500-UPDATE-POLICY-AND-CVGS-X
           END-IF.
      *
020874* REVERTED BACK TO L0290-INPUT-NUMBER AS WE DO NOT NEED TO
020874* MULTIPLY L8150-TRXN-FEE-AMT BY 100
           MOVE L8150-TRXN-FEE-AMT    TO L0290-INPUT-NUMBER
020874*    MOVE L8150-TRXN-FEE-AMT    TO L0290-INPUT-V02
           MOVE 2                     TO L0290-PRECISION
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT
      *
           PERFORM 8100-RESET-DEFAULTS
              THRU 8100-RESET-DEFAULTS-X.
      *
           IF L8150-RETRN-OK
      * MESSAGE - TRANSACTION PROCESSED SUCCESSFULLY
               MOVE 'CS82200033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4500-PROCESS-TRANSFER-3-X.
           EXIT.
      *
      *------------------------
       4550-BUILD-8150-LINKAGE.
      *------------------------
      *
           PERFORM 8150-1000-BUILD-PARM-INFO
              THRU 8150-1000-BUILD-PARM-INFO-X.
      *
           EVALUATE TRUE
               WHEN WS-TSFR-AMT-TO-AMT
                   MOVE 'H'           TO L8150-ALLOC-CD
020478*        WHEN WS-TSFR-AMT-TO-PCT
020478*            MOVE 'I'           TO L8150-ALLOC-CD
               WHEN WS-TSFR-PCT-TO-PCT
                   MOVE 'J'           TO L8150-ALLOC-CD
           END-EVALUATE.
      *
019806*    MOVE WS-REASN-CODE         TO L8150-REASON-CD.
022917*019806     IF  RPOL-POL-INS-TYP-RRIF
022917*023032     OR  RPOL-POL-REG
022917*019806         SET  L8150-REASON-INTRNL-XFER
022917*019806                                TO TRUE
022917*019806     ELSE
022917*019806         MOVE WS-REASN-CODE     TO L8150-REASON-CD
022917*019806     END-IF.
022917*
022917     SET  L8150-REASON-INTRNL-XFER TO TRUE.
022917*
           MOVE WS-TRXN-AMT           TO L8150-XFER-AMT.
           MOVE WS-EFF-DT             TO L8150-EFF-DT.
           MOVE MIR-SUPRES-CNFRM-IND  TO L8150-SUPR-CONF-IND.
016392     MOVE ZERO                  TO L8150-TRXN-FEE-AMT.
016392     SET L8150-TRXN-FEE-OVRID   TO TRUE.
016503     SET L8150-REDO-WARNING     TO TRUE.
           SET L8150-DEFR-ALLOWED     TO TRUE.
016109     SET L8150-XFER-OVRID       TO TRUE.
      *
       4550-BUILD-8150-LINKAGE-X.
           EXIT.
      *
      *-----------------------
       8000-DISPLAY-FUND-KEYS.
      *-----------------------
      *
020469*    RETRIEVE THE FUNDS CURRENCY CODE
020469     MOVE LFUND-FND-ID (K)          TO L8640-FND-ID.
020469     PERFORM  8640-1000-GET-FND-CRCY-CD
020469         THRU 8640-1000-GET-FND-CRCY-CD-X.
020469     IF  L8640-RETRN-OK
020469         MOVE L8640-FND-CRCY-CD     TO MIR-FIA-CRCY-CD-T (K)
020469     ELSE
020469         MOVE SPACES                TO MIR-FIA-CRCY-CD-T (K)
020469* CASHFLOW TYPE PRODUCTS WILL BY DEFINITION HAVE LFUND-FND-ID (K)
020469* SET TO SPACES
020469         IF  LFUND-FND-ID (K) = SPACES
020469             MOVE WS-POL-CRCY-CD    TO MIR-FIA-CRCY-CD-T (K)
020469         END-IF
020469     END-IF.
020469
020469*    FOR EACH OF THE FUNDS MOVE THE POLICY CURRENCY CODE TO MIR
020469     MOVE WS-POL-CRCY-CD        TO MIR-CIA-CRCY-CD-T (K).
           MOVE LFUND-CVG-NUM (K)     TO MIR-CVG-NUM-T (K).
           MOVE LFUND-FND-ID (K)      TO MIR-FND-ID-T (K).
020874*    COMPUTE L0290-INPUT-NUMBER = L8180-CFN-CV-AMT (K) * 100.
020464*    MOVE L8180-CFN-CV-AMT (K)  TO L0290-INPUT-V02.
020464     COMPUTE L0290-INPUT-V02
020464            =  L8180-CFN-CV-AMT (K)
020464            + L8180-CFN-DEFR-IN-AMT (K)
020464            + L8180-CFN-DEFR-OUT-AMT (K).
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
031065*    IF  WS-TSFR-AMT-TO-AMT
031065*        SET L0290-SIGN-DISPLAY        TO TRUE
031065*    ELSE
031065*        SET L0290-SIGN-POS-DISPLAY    TO TRUE
031065*    END-IF.
031065     SET L0290-SIGN-DISPLAY        TO TRUE.
021056*    SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-CFN-APROX-AMT-T (K).

020464*    COMPUTE L0290-INPUT-NUMBER =
020464*                         L8180-CFN-POL-CRCY-CV-AMT (K) * 100.
020464     COMPUTE  L0290-INPUT-NUMBER
020464           = (L8180-CFN-POL-CRCY-CV-AMT (K)
020464           +  L8180-CFN-POL-DEFR-IN-AMT     (K)
020464           +  L8180-CFN-POL-DEFR-OUT-AMT    (K))
020464           *  100.
020469     MOVE 2                     TO L0290-PRECISION.
020469     MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (1)
020469                                TO L0290-MAX-OUT-LEN.
021056*    SET L0290-SIGN-POS-DISPLAY TO TRUE.
031065*    IF  WS-TSFR-AMT-TO-AMT
031065*        SET L0290-SIGN-DISPLAY        TO TRUE
031065*    ELSE
031065*        SET L0290-SIGN-POS-DISPLAY    TO TRUE
031065*    END-IF.
031065     SET L0290-SIGN-DISPLAY        TO TRUE.
020469     PERFORM  0290-1000-NUMERIC-FORMAT
020469         THRU 0290-1000-NUMERIC-FORMAT-X.
020469     MOVE L0290-OUTPUT-DATA     TO MIR-DV-FIA-POL-CRCY-AMT-T (K).
020469
           MOVE LFUND-CVG-NUM-N (K)   TO I.
           MOVE WCVGS-PLAN-ID (I)     TO MIR-PLAN-ID-T (K).
      *
           PERFORM 8010-DISPLAY-FUND-UNITS
              THRU 8010-DISPLAY-FUND-UNITS-X.
           PERFORM 8020-GET-FUND-DESCRIPTION
              THRU 8020-GET-FUND-DESCRIPTION-X.
      *
       8000-DISPLAY-FUND-KEYS-X.
           EXIT.
      *
      *--------------------------
       8010-DISPLAY-FUND-UNITS.
      *--------------------------
      *
020874*    COMPUTE L0290-INPUT-NUMBER = L8180-CFN-UNIT-QTY (K)
020874*                               *  1000000000
021239*    MOVE L8180-CFN-UNIT-QTY (K) TO L0290-INPUT-V09
021239*    MOVE 9                     TO L0290-PRECISION.
021239*    MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (1)
021239     MOVE L8180-CFN-UNIT-QTY (K) TO L0290-INPUT-V06.
021239     MOVE 6                     TO L0290-PRECISION.
021239     MOVE LENGTH OF MIR-FIA-UNIT-CUM-QTY-T (K)
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
021239*    MOVE L0290-OUTPUT-DATA     TO MIR-CFN-INTG-AUNIT-QTY-T (K).
021239     MOVE L0290-OUTPUT-DATA     TO MIR-FIA-UNIT-CUM-QTY-T (K).
      *
       8010-DISPLAY-FUND-UNITS-X.
           EXIT.
013578*
013578*--------------------------
013578 8020-GET-FUND-DESCRIPTION.
013578*--------------------------
013578*
013578     IF MIR-CVG-NUM-T (K) = SPACE
013578     AND MIR-FND-ID-T (K) = SPACE
013578         GO TO 8020-GET-FUND-DESCRIPTION-X
013578     END-IF.
013578*
013578     IF MIR-FND-ID-T (K) = SPACE
013578         MOVE MIR-PLAN-ID-T (K)   TO WEDIT-ETBL-VALU-ID
013578         PERFORM PLAN-2000-DESC
013578            THRU PLAN-2000-DESC-X
013578         MOVE REDIT-ETBL-DESC-TXT TO MIR-DV-FND-DESC-TXT-T (K)
013578     ELSE
013578         MOVE MIR-FND-ID-T (K)    TO WEDIT-ETBL-VALU-ID
013578         PERFORM SGFD-2000-DESC
013578            THRU SGFD-2000-DESC-X
013578         MOVE REDIT-ETBL-DESC-TXT TO MIR-DV-FND-DESC-TXT-T (K)
013578     END-IF.
013578*
013578 8020-GET-FUND-DESCRIPTION-X.
013578     EXIT.
      *

       8100-RESET-DEFAULTS.
      *==================.
           MOVE WGLOB-PROCESS-DATE    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CIA-EFF-DT.
      *
020874*    MOVE  0                    TO L0290-INPUT-NUMBER
020874     MOVE  ZERO                 TO L0290-INPUT-V02
           MOVE  2                    TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-SURR-AMT
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-SURR-AMT
      *
020874*     MOVE  0                    TO L0290-INPUT-NUMBER
020874      MOVE  ZERO                 TO L0290-INPUT-V02
           MOVE  2                    TO L0290-PRECISION
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT
      *
020874*    MOVE  0                    TO L0290-INPUT-NUMBER
020874     MOVE  ZERO                 TO L0290-INPUT-V04
           MOVE  4                    TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-OUT-ALLOC-PCT
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-OUT-ALLOC-PCT
      *
013578*    MOVE SPACES                TO MIR-DV-CLI-NM
013578     MOVE SPACES                TO MIR-DV-OWN-CLI-NM
015905*    MOVE 'N/A'                 TO MIR-DV-CIA-REASN-CD.
015905     MOVE 'N/A'                 TO MIR-CIA-REASN-CD.
023437*    MOVE 'N'                   TO MIR-CIA-TAXWH-IND.
016107     MOVE 'N'                   TO MIR-DV-REDC-FACE-IND.
029060*    MOVE 'C'                   TO MIR-LTAXWH-CALC-CD.
029060     MOVE 'C'                   TO MIR-LTAXWH-RQST-CD.
           MOVE 'N'                   TO MIR-SUPRES-CNFRM-IND.
           MOVE 'D'                   TO MIR-CIA-SRC-DEST-CD.
013693
020874*    MOVE 0                     TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                               TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                TO L0290-MAX-OUT-LEN.
013693     MOVE 2                     TO L0290-PRECISION.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA TO MIR-LTAXWH-PCT.
029060     MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-RQST-PCT.
013693
020874*    MOVE 0                     TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
013693     MOVE 2                     TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                               TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA TO MIR-LTAXWH-FLAT-AMT.
029060     MOVE L0290-OUTPUT-DATA TO MIR-LTAXWH-RQST-AMT.
013693
020874*    MOVE 0                     TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
013693     MOVE 2                     TO L0290-PRECISION.
023437*    MOVE LENGTH OF MIR-FED-TAXWH-AMT
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                               TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT
029060                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
023437*    MOVE L0290-OUTPUT-DATA TO MIR-FED-TAXWH-AMT.
029060*    MOVE L0290-OUTPUT-DATA TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE L0290-OUTPUT-DATA TO MIR-FTAXWH-AMT.
      *
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
013697     MOVE 2                     TO L0290-PRECISION.
023118*    MOVE LENGTH OF MIR-DV-GAIN-AMT
023118     MOVE LENGTH OF MIR-DV-SURR-GAIN-AMT
013697                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
023118*    MOVE L0290-OUTPUT-DATA TO MIR-DV-GAIN-AMT.
023118     MOVE L0290-OUTPUT-DATA TO MIR-DV-SURR-GAIN-AMT.
013697
       8100-RESET-DEFAULTS-X.
           EXIT.
      *
      *----------------------------
       8500-UPDATE-POLICY-AND-CVGS.
      *----------------------------
      *
016503*    IF RPOL-REC-INFO = HPOL-REC-INFO
016503*        PERFORM POL-3000-UNLOCK
016503*           THRU POL-3000-UNLOCK-X
016503*    ELSE
016503*        PERFORM POL-2000-REWRITE
016503*           THRU POL-2000-REWRITE-X
016503*    END-IF.

016503     PERFORM  8720-SET-POL-NXT-ACTV
016503         THRU 8720-SET-POL-NXT-ACTV-X.
016503     PERFORM  POL-2000-REWRITE
016503         THRU POL-2000-REWRITE-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

      *
           PERFORM
                VARYING I FROM 1 BY 1
                UNTIL I > RPOL-POL-CVG-REC-CTR-N
               MOVE I                 TO WCVG-CVG-NUM-N
               PERFORM CVG-1000-READ-FOR-UPDATE
                  THRU CVG-1000-READ-FOR-UPDATE-X
               IF RCVG-CVG-INFO = WCVGS-CVG-INFO (I)
                   PERFORM CVG-3000-UNLOCK
                      THRU CVG-3000-UNLOCK-X
               ELSE
                   MOVE WCVGS-CVG-INFO (I)
                                      TO RCVG-CVG-INFO
                   PERFORM CVG-2000-REWRITE
                      THRU CVG-2000-REWRITE-X
               END-IF
           END-PERFORM.
      *
       8500-UPDATE-POLICY-AND-CVGS-X.
           EXIT.

      *
      *****************
       8550-INVOKE-REDO.
      *****************

016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503         GO TO 8550-INVOKE-REDO-X
016503     END-IF.

016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     MOVE WS-EFF-DT                     TO L4780-EFF-DT.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
016503     SET L4780-PRCES-INCLUSIVE          TO TRUE.

016503     PERFORM  4780-1000-GET-NEXT-ACT-DT
016503         THRU 4780-1000-GET-NEXT-ACT-DT-X.

016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              SET WS-REDO-NOT-OK           TO TRUE
016503              PERFORM  POL-3000-UNLOCK
016503                  THRU POL-3000-UNLOCK-X
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503             PERFORM  POL-3000-UNLOCK
016503                 THRU POL-3000-UNLOCK-X
016503             MOVE WS-EFF-DT           TO L0201-EFF-DT
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X
016503             PERFORM  8720-SET-POL-NXT-ACTV
016503                 THRU 8720-SET-POL-NXT-ACTV-X
016503             MOVE RPOL-REC-INFO           TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503             MOVE HPOL-REC-INFO           TO RPOL-REC-INFO
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
016503                 PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016503                     THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221                 PERFORM  POL-1000-READ-TWRK-TS
014221                     THRU POL-1000-READ-TWRK-TS-X
016503             IF  L0201-RETRN-OK
016503                 PERFORM  POL-1000-READ-FOR-UPDATE
016503                     THRU POL-1000-READ-FOR-UPDATE-X
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503             END-IF
016503     END-EVALUATE.

016503 8550-INVOKE-REDO-X.
016503     EXIT.
      *
      ******************
       8600-INVOKE-UNDO.
      ******************
           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.
           SET L4750-FCN-DRVR-SECONDARY TO TRUE.
           MOVE WS-EFF-DT             TO L4750-EFF-DT.
012137     MOVE MIR-SUPRES-CNFRM-IND  TO L4750-SUPP-CONF-CD.
           SET  L4750-PRCES-EXCLUSIVE   TO TRUE
      *
      *  UNLOCK POLICY PRIOR TO UNDO
           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
013578         SET MIR-RETRN-EDIT-ERROR TO TRUE
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

           IF  WGLOB-RETURN-ERROR
           AND L4750-POL-UPDATE-NOT-REQD
               GO TO 8600-INVOKE-UNDO-X
           END-IF.

      *  LOCK POLICY AGAIN IN ORDER TO DO UPDATES
      *  SAVE POLICY INFO TO RESTORE AFTER READ FOR UPDATE

           MOVE  RPOL-REC-INFO        TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY             TO  WPOL-KEY.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.

           IF  L4750-POL-UPDATE-REQD

               PERFORM  8700-UPDATE-POL-CVG
                   THRU 8700-UPDATE-POL-CVG-X

               IF  WGLOB-GOOD-RETURN
                   MOVE  RPOL-KEY     TO  WPOL-KEY
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
               END-IF

           END-IF.

       8600-INVOKE-UNDO-X.
           EXIT.
      *
      *********************
       8700-UPDATE-POL-CVG.
      *********************

      *  UPDATE THE POLICY AND COVERAGES

016503     PERFORM  8720-SET-POL-NXT-ACTV
016503         THRU 8720-SET-POL-NXT-ACTV-X.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       8700-UPDATE-POL-CVG-X.
           EXIT.
      *
016503************************
016503 8720-SET-POL-NXT-ACTV.
016503***********************

016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X
016503     MOVE WS-EFF-DT       TO L0289-LO-PAC-DT
016503     MOVE WS-EFF-DT       TO L0289-LO-CRC-DT
020467     MOVE WS-EFF-DT       TO L0289-LO-DD2-DT.
016503     MOVE WS-EFF-DT       TO L0289-PROC-EFF-DT
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503     IF  L0289-RETRN-OK
016503          MOVE L0289-NXT-ACTV-TYP-CD
016503                   TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE L0289-NXT-ACTV-DT
016503                   TO RPOL-POL-NXT-ACTV-DT
016503      ELSE
016503          MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE WGLOB-PROCESS-DATE
016503                      TO RPOL-POL-NXT-ACTV-DT
016503      END-IF.

       8720-SET-POL-NXT-ACTV-X.
           EXIT.
      *
018846*---------------------------
018846 8800-MSG-SIDE-FND-EXIST.
018846*---------------------------
018846
018846*MSG: WITHDRAWAL FROM NON-SIDE FUND COVERAGE.
018846*     SIDE FUND VALUE > 0.00
018846     MOVE 'CS82200053'             TO WGLOB-MSG-REF-INFO.
018846     PERFORM  0260-1000-GENERATE-MESSAGE
018846         THRU 0260-1000-GENERATE-MESSAGE-X.
018846     IF  WGLOB-MSG-SEVRTY-FATAL
018846         SET MIR-RETRN-EDIT-ERROR TO TRUE
018846     END-IF.
018846
018846 8800-MSG-SIDE-FND-EXIST-X.
018846     EXIT.

      *---------------------------
       9100-CLEAR-DATA-FIELDS.
      *---------------------------
           MOVE SPACES                TO  MIR-CVG-NUM-G.
           MOVE SPACES                TO  MIR-PLAN-ID-G.
           MOVE SPACES                TO  MIR-FND-ID-G.
           MOVE SPACES                TO  MIR-DV-CFN-APROX-AMT-G.
           MOVE SPACES                TO MIR-DV-FROM-FND-AMT-G.
           MOVE SPACES                TO MIR-DV-TO-FND-AMT-G.
           MOVE SPACES                TO MIR-FIA-OUT-ALLOC-PCT-G.
           MOVE SPACES                TO MIR-FIA-IN-ALLOC-PCT-G.
           MOVE SPACES                TO MIR-FIA-SURR-UNIT-QTY-G.
           MOVE SPACES                TO MIR-FIA-OUT-ALLOC-PCT-G.
           MOVE SPACES                TO MIR-FIA-VALU-SURR-PCT-G.
020469     MOVE SPACES                TO MIR-FIA-CRCY-CD-G.
020469     MOVE SPACES                TO MIR-CIA-CRCY-CD-G.
020469     MOVE SPACES                TO MIR-DV-FIA-POL-CRCY-AMT-G.

       9100-CLEAR-DATA-FIELDS-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE            TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970     PERFORM  0182-0000-INIT-PARM-INFO
025970         THRU 0182-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0279-0000-INIT-PARM-INFO
025970         THRU 0279-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0316-0000-INIT-PARM-INFO
025970         THRU 0316-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4382-0000-INIT-PARM-INFO
025970         THRU 4382-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8140-0000-INIT-PARM-INFO
025970         THRU 8140-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8150-0000-INIT-PARM-INFO
025970         THRU 8150-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8180-0000-INIT-PARM-INFO
025970         THRU 8180-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8200-0000-INIT-PARM-INFO
025970         THRU 8200-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8640-0000-INIT-PARM-INFO
025970         THRU 8640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  TAXC-0000-INIT-PARM-INFO
025970         THRU TAXC-0000-INIT-PARM-INFO-X.
025970
023514     INITIALIZE WS-WORK-FIELDS.
025278     INITIALIZE LFUND-FND-CTR.
025278     INITIALIZE LFUND-ACTV-CD.
025970
025970     INITIALIZE WS-TWRK-WORK-AREA.
025970     INITIALIZE WS-INDICATORS.
025970     INITIALIZE WS-TYP-CDS.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025278     PERFORM
025278       VARYING I FROM +1 BY +1
025278       UNTIL I > LFUND-FND-MAX-CTR
025278         INITIALIZE LFUND-FND-INFO (I)
025278     END-PERFORM.
025970
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
025970     SET WS-CTL-NAME-MNEMONIC-DEFAULT TO TRUE.
025970
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      ****************************************************************
      *   PROCESSING COPYBOOKS
      ****************************************************************
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
       COPY NCPPCVGR.
       COPY NCPPCVGS.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
       COPY XCCP0030.
      *
025970 COPY XCPS8090.
025970 COPY XCPS8640.
       COPY CCPSPGA.
      *
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
013578 COPY CCPL0620.
013578*
018846 COPY CCPS0182.
018846 COPY CCPL0182.
018846
013578 COPY CCPEPLAN.
013578 COPY CCPESGFD.
      *
031034*COPY CCPSPGAL.
015290
023437 COPY CCPSTAXC.
023437 COPY CCPLTAXC.
023437
       COPY CCPS2430.
020463 COPY CCPS2735.
020463 COPY CCPL2735.
      *
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
       COPY CCPS5400.
      *
016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108*
       COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.
      *
025970 COPY XCPS0279.
017150 COPY XCPL0279.
017150*
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS4780.
018764*COPY CCCL4780.
018764 COPY CCPL4780.
018764*COPY CCCL0201.
025970 COPY CCPS0201.
018764 COPY CCPL0201.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
       COPY XCPL0290.
       COPY XCPS0290.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
018731 COPY CCPS4382.
018764*COPY CCCL4382.
018764 COPY CCPL4382.
018731*
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      ****************************************************************
      *   LINKAGE COPYBOOKS
      ****************************************************************
      *
       COPY FCPS8200.
018764*COPY FCCL8200.
018764 COPY FCPL8200.
      *
       COPY FCPS8140.
018764*COPY FCCL8140.
018764 COPY FCPL8140.
      *
       COPY FCPS8150.
018764*COPY FCCL8150.
018764 COPY FCPL8150.
      *
       COPY FCPS8180.
018764*COPY FCCL8180.
018764 COPY FCPL8180.
      *
023437 COPY XCPS0316.
023437 COPY XCPL0316.
021930*COPY XCPS8640.
020469 COPY XCPL8640.
020469*
023437 COPY XCPS8960.
023437 COPY XCPL8960.
      *
      *****************************************************************
      *   FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
      *
       COPY CCPNCVG.
      *
       COPY CCPUCVG.
013578*
013578 COPY CCPNEDIT.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM8220                     **
      *****************************************************************
