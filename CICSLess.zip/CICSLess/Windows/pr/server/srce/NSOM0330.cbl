      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0330.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0330                                         **
      **  REMARKS:  ATAB: MAINTAIN AGE / AMOUNT TABLE                **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE AGE AND AMOUNT TABLE.          **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
557973**  5.5       AMOUNT FIELD SIZING FOR INT'L SUPPORT            **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010645**  5.6       VARIATIONS BY LOCATION - UW AND NB               **
012074**  5.6       REINITIALIZE WS FIELDS FOR AS400 PROCESSING      **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
016475**  6.1       REMOVE DELETE-TWRK LOGIC                         **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0330'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
       COPY XCWL8090.


       01  WS-PGM-WORK-AREA.
016548*    05  WS-ATAB                      PIC S9(4)  COMP.
016548     05  WS-ATAB                      PIC S9(4)  BINARY.
016548*    05  WS-LSUB                      PIC S9(4)  COMP.
016548     05  WS-LSUB                      PIC S9(4)  BINARY.
016548*    05  WS-NEWSUB                    PIC S9(4)  COMP.
016548     05  WS-NEWSUB                    PIC S9(4)  BINARY.
016548*    05  WS-RSUB                      PIC S9(4)  COMP.
016548     05  WS-RSUB                      PIC S9(4)  BINARY.
016548*    05  WS-SUB                       PIC S9(4)  COMP.
016548     05  WS-SUB                       PIC S9(4)  BINARY.
025970*    05  WS-DATA-EDITS                PIC X(01)  VALUE '0'.
025970     05  WS-DATA-EDITS                PIC X(01).
025970         88  WS-DEFAULT-DATA-EDIT                VALUE '0'.
025970*    05  WS-CROSS-EDITS               PIC X(01)  VALUE '0'.
025970     05  WS-CROSS-EDITS               PIC X(01).
025970         88  WS-DEFAULT-EDITS                    VALUE '0'.
025970*    05  WS-FIRST                     PIC X(01)  VALUE '0'.
025970     05  WS-FIRST                     PIC X(01).
025970         88  WS-DEFAULT-FIRST                    VALUE '0'.
025970*    05  WS-NO-DISPLAY-LINES          PIC S9(3)  COMP-3
025970*                                                VALUE +12.
           05  WS-LINES                     PIC S9(3)  COMP-3.
           05  WS-LINES-REMAIN              PIC S9(3)  COMP-3.
           05  WS-N-99                      PIC 9(2).
           05  WS-PIC-Z9                    PIC Z9.
           05  WS-N-999                     PIC 9(3).
           05  WS-PIC-ZZ9                   PIC ZZ9.
008455*    05  WS-N-9S                      PIC 9(9).
008455*    05  WS-PIC-Z99                   PIC Z(8)9.
008455*    05  WS-CURR-RISK-9               PIC 9(9).
025970*    05  WS-HIGH-CURR-RISK            PIC S9(15) COMP-3
025970*                                     VALUE +999999999999999.
           05  WS-NUM-AGE                   PIC 9(3).
               88  AGE-IN-RANGE             VALUE 0 THRU 120.
           05  WS-CURRISK-INDICATOR         PIC X(01).
               88  WS-CURRISK-VALID         VALUE 'Y'.
           05  WS-AGEIN-INDICATOR           PIC X(01).
               88  WS-AGEIN-VALID           VALUE 'Y'.
           05  WS-VALIDATE-CONTROL          PIC X(01).
               88  WS-INVALID-CONTROL                  VALUE '1'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE
                   '0330' '0331' '0332' '0333' '0334'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0330'.
               88  WS-BUS-FCN-CREATE        VALUE '0331'.
               88  WS-BUS-FCN-UPDATE        VALUE '0332'.
               88  WS-BUS-FCN-DELETE        VALUE '0333'.
               88  WS-BUS-FCN-LIST          VALUE '0334'.
           05  WS-LOGICAL-EOF-SW            PIC X(01).
               88  WS-LOGICAL-EOF           VALUE 'Y'.
           05  WS-HOLD-ENDBR-KEY            PIC X(24) VALUE SPACES.
557973
557973     05  WS-WATAB-KEY.
557973         10  WS-WATAB-CO-ID               PIC X(02).
557973         10  WS-WATAB-DFLT-REQIR-ID       PIC X(06).
010645*        10  WS-WATAB-DFLT-REQIR-RGN-CD   PIC X(02).
010645         10  WS-WATAB-LOC-GR-CD           PIC X(03).
557973         10  WS-WATAB-OCCP-CLAS-CD        PIC X(02).
557973         10  WS-WATAB-DFLT-REQIR-AGE      PIC X(03).
557973         10  WS-WATAB-DFLT-REQIR-TCR-AMT  PIC X(09).

           05  WS-REUSE-TEMP-FIELDS             PIC X(17).
               88 WS-REUSE-TEMP-FIELDS-ON       VALUE
                  'REUSE_TEMP_FIELDS'.
      /
       01  WS-REQ-TABLE.
           05  WS-REQ-1        OCCURS 22    PIC X(05).
      *
       01  WS-RQCD-DETAILS.
           05  WS-RQCD.
               10  WS-RQCO1-T               PIC X(05).
               10  WS-RQCO2-T               PIC X(05).
               10  WS-RQCO3-T               PIC X(05).
               10  WS-RQCO4-T               PIC X(05).
               10  WS-RQCO5-T               PIC X(05).
               10  WS-RQCO6-T               PIC X(05).
               10  WS-RQCO7-T               PIC X(05).
               10  WS-RQCO8-T               PIC X(05).
               10  WS-RQCO9-T               PIC X(05).
               10  WS-RQCO10-T              PIC X(05).
               10  WS-RQCO11-T              PIC X(05).
               10  WS-RQCO12-T              PIC X(05).
               10  WS-RQCO13-T              PIC X(05).
               10  WS-RQCO14-T              PIC X(05).
               10  WS-RQCO15-T              PIC X(05).
               10  WS-RQCO16-T              PIC X(05).
               10  WS-RQCO17-T              PIC X(05).
               10  WS-RQCO18-T              PIC X(05).
               10  WS-RQCO19-T              PIC X(05).
               10  WS-RQCO20-T              PIC X(05).
               10  WS-RQCO21-T              PIC X(05).
               10  WS-RQCO22-T              PIC X(05).
           05  WS-RQCDT   REDEFINES WS-RQCD.
               10  WS-RQCD-01-T   OCCURS 22.
                   15  WS-RQCD-T            PIC X(05).

025970 01  WS-CONSTANTS.
025970     05  WS-NO-DISPLAY-LINES          PIC S9(3)  COMP-3.
025970         88  WS-DEFAULT-NO-DISPLAY-LINES         VALUE +12.
025970     05  WS-HIGH-CURR-RISK            PIC S9(15) COMP-3.
025970         88  WS-DEFAULT-HIGH-CURR-RISK
025970                                      VALUE +999999999999999.

018633*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0334'.
018633*    05  WS-TWRK-AREA.
018633*        10  WS-LAST-MIR.
018633*            15  WS-LAST-DFLT-REQIR-ID        PIC X(06).
018633*            15  WS-LAST-LOC-GR-ID            PIC X(03).
018633*            15  WS-LAST-OCCP-CLAS-CD         PIC X(02).
018633*            15  WS-LAST-DFLT-REQIR-AGE       PIC X(03).
018633*            15  WS-LAST-DFLT-REQIR-TCR-AMT   PIC S9(15) COMP-3.
018633*        10  WS-NEXT-KEY                      PIC X(24).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '0334'.
018633     15  LCOMM-LAST-MIR.
018633         20  LCOMM-LAST-DFLT-REQIR-ID     PIC X(06).
018633         20  LCOMM-LAST-LOC-GR-ID         PIC X(03).
018633         20  LCOMM-LAST-OCCP-CLAS-CD      PIC X(02).
018633         20  LCOMM-LAST-DFLT-REQIR-AGE    PIC X(03).
018633         20  LCOMM-LAST-DFLT-REQIR-TCR-AMT PIC S9(15) COMP-3.
018633     15  LCOMM-NEXT-KEY                   PIC X(24).
018633
016537*COPY XCWWWKDT.
      *
      /
       COPY XCWEBLCH.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY NCFRATAB.
       COPY NCFWATAB.
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
      /
       COPY XCWL0280.
      /
       COPY NCFRRTAB.
       COPY NCFWRTAB.
014221 COPY CCWWLOCK.
      /
008455 COPY XCWL0290.
      /

       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0330.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
012074     MOVE ZERO                  TO WS-DATA-EDITS.
012074     MOVE ZERO                  TO WS-FIRST.
012074     MOVE ZERO                  TO WS-CROSS-EDITS.
012074
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      ***************************************************************
      *   NORMAL PROCESSING: CHECK SECURITY PERMISSION & DISTRIBUTE
      *   CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      ***************************************************************
      **********************
       2000-PROCESS-REQUEST.
      **********************

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *
      *   FORMAT NUMERIC PORTIONS OF THE KEY
      *
           PERFORM  7200-FORMAT-KEYS
               THRU 7200-FORMAT-KEYS-X.

           IF WS-DATA-EDITS NOT = ZEROS
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
      *   CHECK BUSINESS FUNCTION ID FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X
      *
               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X
      *
               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X
      *
               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X
      *
               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X
      *
               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM0330'   TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

      *
      *   BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-ATAB-KEY
               THRU 7100-BUILD-ATAB-KEY-X.
      *
      *   CHECK IF RECORD EXISTS.
      *
014221*    PERFORM  ATAB-1000-READ
014221*        THRU ATAB-1000-READ-X.

014221     PERFORM  ATAB-1000-READ-TWRK-TS
014221         THRU ATAB-1000-READ-TWRK-TS-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF WATAB-IO-NOT-FOUND
               MOVE 'NS03300001'      TO WGLOB-MSG-REF-INFO
               MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
               MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE +1                TO WS-LINES
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      ***************************************************************
      *   INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE AND
      *   LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.
      ***************************************************************
      *******************
       3500-PROCESS-LIST.
      *******************

018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF  L8090-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT  TO WS-TWRK-AREA
018633     IF  LCOMM-RETRN-OK
018633         CONTINUE
           ELSE
018633*        MOVE SPACE                 TO WS-TWRK-AREA
018633         MOVE SPACE                 TO LCOMM-WORK-AREA
           END-IF.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.
      *
      *  SET UP BROWSE KEY LIMITS
      *
           IF  WS-REUSE-TEMP-FIELDS-ON
018633*        MOVE WS-LAST-DFLT-REQIR-TCR-AMT TO MIR-DFLT-REQIR-TCR-AMT
018633*        MOVE SPACES                     TO WS-NEXT-KEY
018633         MOVE LCOMM-LAST-DFLT-REQIR-TCR-AMT
018633           TO MIR-DFLT-REQIR-TCR-AMT
018633         MOVE SPACES                     TO LCOMM-NEXT-KEY
           END-IF.

           PERFORM  7100-BUILD-ATAB-KEY
               THRU 7100-BUILD-ATAB-KEY-X.
           MOVE HIGH-VALUES           TO WATAB-ENDBR-KEY.
557973     MOVE WS-HIGH-CURR-RISK     TO WATAB-ENDBR-DFLT-REQIR-TCR-AMT.
      *
      *  SCROLL THROUGH THE FILE WHEN THE KEY HAS NOT BEEN CHANGED
      *
018633*    IF  WS-LAST-MIR           NOT  =  SPACES
018633*    AND WS-LAST-DFLT-REQIR-ID      =  WATAB-DFLT-REQIR-ID
018633*    AND WS-LAST-LOC-GR-ID          =  WATAB-LOC-GR-ID
018633*    AND WS-LAST-OCCP-CLAS-CD       =  WATAB-OCCP-CLAS-CD
018633*    AND WS-LAST-DFLT-REQIR-AGE     =  WATAB-DFLT-REQIR-AGE
018633*    AND WS-LAST-DFLT-REQIR-TCR-AMT =  WATAB-DFLT-REQIR-TCR-AMT
018633*        IF WS-NEXT-KEY NOT = SPACE
018633*           MOVE  WS-NEXT-KEY  TO  WATAB-KEY
018633     IF  LCOMM-LAST-MIR        NOT  =  SPACES
018633     AND LCOMM-LAST-DFLT-REQIR-ID   =  WATAB-DFLT-REQIR-ID
018633     AND LCOMM-LAST-LOC-GR-ID       =  WATAB-LOC-GR-ID
018633     AND LCOMM-LAST-OCCP-CLAS-CD    =  WATAB-OCCP-CLAS-CD
018633     AND LCOMM-LAST-DFLT-REQIR-AGE  =  WATAB-DFLT-REQIR-AGE
018633     AND LCOMM-LAST-DFLT-REQIR-TCR-AMT = WATAB-DFLT-REQIR-TCR-AMT
018633         IF LCOMM-NEXT-KEY NOT = SPACE
018633            MOVE  LCOMM-NEXT-KEY TO WATAB-KEY
               END-IF
           END-IF.
      *
      *  POSITION AT AND READ FIRST RECORD
      *
           PERFORM  ATAB-1000-BROWSE
               THRU ATAB-1000-BROWSE-X.
      *
           IF WATAB-IO-OK
               PERFORM  ATAB-2000-READ-NEXT
                   THRU ATAB-2000-READ-NEXT-X
           ELSE
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973         MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
557973         MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           IF WATAB-IO-OK
               CONTINUE
           ELSE
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973         MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
557973         MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  ATAB-3000-END-BROWSE
                   THRU ATAB-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
            END-IF.
      *
      *   RESET BROUSE END KEY LIMITS SO THAT THE BROWSE ONLY
      *   VARIES BY THE AMOUNT
      *
           MOVE RATAB-KEY             TO  WATAB-ENDBR-KEY.
557973*****MOVE 999999999     TO  WATAB-ENDBR-DFLT-REQIR-TCR-AMT.
557973     MOVE WS-HIGH-CURR-RISK
                                     TO  WATAB-ENDBR-DFLT-REQIR-TCR-AMT.
           MOVE WATAB-ENDBR-KEY       TO WS-HOLD-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WATAB-ENDBR-KEY.
557973     MOVE WS-HIGH-CURR-RISK
557973                               TO  WATAB-ENDBR-DFLT-REQIR-TCR-AMT.
      *
      *   LOAD SCREEN DATA ARRAY.
      *
           MOVE 'N'                   TO WS-LOGICAL-EOF-SW.
           IF WATAB-IO-OK
                MOVE 1                TO WS-LINES
                MOVE SPACES           TO MIR-DFLT-REQIR-TCR-AMT-G
                MOVE SPACES           TO MIR-REQIR-1-ID-G
                MOVE SPACES           TO MIR-REQIR-2-ID-G
                MOVE SPACES           TO MIR-REQIR-3-ID-G
                MOVE SPACES           TO MIR-REQIR-4-ID-G
                MOVE SPACES           TO MIR-REQIR-5-ID-G
                MOVE SPACES           TO MIR-REQIR-6-ID-G
                MOVE SPACES           TO MIR-REQIR-7-ID-G
                MOVE SPACES           TO MIR-REQIR-8-ID-G
                MOVE SPACES           TO MIR-REQIR-9-ID-G
                MOVE SPACES           TO MIR-REQIR-10-ID-G
                MOVE SPACES           TO MIR-REQIR-11-ID-G
                MOVE SPACES           TO MIR-REQIR-12-ID-G
                MOVE SPACES           TO MIR-REQIR-13-ID-G
                MOVE SPACES           TO MIR-REQIR-14-ID-G
                MOVE SPACES           TO MIR-REQIR-15-ID-G
                MOVE SPACES           TO MIR-REQIR-16-ID-G
                MOVE SPACES           TO MIR-REQIR-17-ID-G
                MOVE SPACES           TO MIR-REQIR-18-ID-G
                MOVE SPACES           TO MIR-REQIR-19-ID-G
                MOVE SPACES           TO MIR-REQIR-20-ID-G
                MOVE SPACES           TO MIR-REQIR-21-ID-G
                MOVE SPACES           TO MIR-REQIR-22-ID-G
557660          PERFORM  3550-DISPLAY-RECORD
557660              THRU 3550-DISPLAY-RECORD-X
                        UNTIL (WS-LINES >  WS-NO-DISPLAY-LINES)
                        OR WS-LOGICAL-EOF
                        OR (WATAB-IO-EOF)
557660     END-IF.
      *
      *   COMPLETION MESSAGE
      *   (WHEN EOF, DETERMINE IF PHYSICAL OR LOGICAL EOF)
      *
           IF  WS-LOGICAL-EOF
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
018633*        MOVE WATAB-KEY         TO WS-NEXT-KEY
018633         MOVE WATAB-KEY         TO LCOMM-NEXT-KEY
               MOVE  WATAB-DFLT-REQIR-TCR-AMT
                                      TO
                     WATAB-ENDBR-DFLT-REQIR-TCR-AMT
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF WATAB-IO-EOF
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   SET WGLOB-MORE-DATA-EXISTS  TO TRUE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
557973*            MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973             MOVE WATAB-CO-ID   TO WS-WATAB-CO-ID
557973             MOVE WS-WATAB-KEY  TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557973*****        MOVE RATAB-DFLT-REQIR-TCR-AMT TO
557973*****                                       MIR-DFLT-REQIR-TCR-AMT
008455*            MOVE RATAB-DFLT-REQIR-TCR-AMT TO WS-CURR-RISK-9
008455*            MOVE WS-CURR-RISK-9         TO MIR-DFLT-REQIR-TCR-AMT
008455             MOVE RATAB-DFLT-REQIR-TCR-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455             MOVE 0             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DFLT-REQIR-TCR-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DFLT-REQIR-TCR-AMT
557660         END-IF
557660     END-IF.

           PERFORM  ATAB-3000-END-BROWSE
               THRU ATAB-3000-END-BROWSE-X.

018633*    MOVE WS-TWRK-AREA          TO L8090-AREA-INFO-TEXT.
018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.
      *
       3500-PROCESS-LIST-X.
           EXIT.
      /
      ***************************************************************
      *   INQUIRY DISPLAY PROCESSING:INPUT: WS-LINES
      *   DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE GIVEN
      *   BY WS-LINES AND RETRIEVE THE NEXT RECORD.
      ***************************************************************
      ***************************
557660 3550-DISPLAY-RECORD.
      ***************************
      *
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  ATAB-2000-READ-NEXT
               THRU ATAB-2000-READ-NEXT-X.
           IF WATAB-IO-OK
               IF RATAB-KEY > WS-HOLD-ENDBR-KEY
                   MOVE 'Y'           TO WS-LOGICAL-EOF-SW
557660         END-IF
557660     END-IF.
      *
557660 3550-DISPLAY-RECORD-X.
           EXIT.
      /
      ***************************************************************
      *   CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, INIT NEW
      *   RECORD AND ALLOW USER TO MODIFY.
      ***************************************************************
      *********************
       4000-PROCESS-CREATE.
      *********************

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.
      *
      *   EDIT CONTOL FIELDS.
      *
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
           PERFORM  7200-FORMAT-KEYS
               THRU 7200-FORMAT-KEYS-X.
           PERFORM  7000-EDIT-CONTROL-FIELDS
               THRU 7000-EDIT-CONTROL-FIELDS-X.
           IF WS-DATA-EDITS  = '1'
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      *   BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-ATAB-KEY
               THRU 7100-BUILD-ATAB-KEY-X.
      *
      *   CHECK IF RECORD EXISTS.
      *
           PERFORM  ATAB-1000-READ
               THRU ATAB-1000-READ-X.

014221     PERFORM  ATAB-1000-READ-TWRK-TS
014221         THRU ATAB-1000-READ-TWRK-TS-X.

           IF WATAB-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973         MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
557973         MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      *   CREATE NEW RECORD
      *
           PERFORM  ATAB-1000-CREATE
               THRU ATAB-1000-CREATE-X.
           PERFORM  ATAB-1000-WRITE
               THRU ATAB-1000-WRITE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO
557973*    MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973     MOVE WATAB-CO-ID           TO WS-WATAB-CO-ID
557973     MOVE WS-WATAB-KEY          TO WGLOB-MSG-PARM (1)
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X
           MOVE +1                    TO WS-LINES.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *
       4000-PROCESS-CREATE-X.
           EXIT.
      /
      ***************************************************************
      *   MAINTAIN PROCESSING: GET RECORD, EDIT DATA FIELDS, AND
      *   UPDATE IF EDIT ERRORS, ELSE UNLOCK.
      ***************************************************************
      *********************
       5000-PROCESS-UPDATE.
      *********************

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.
      *
      *   BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-ATAB-KEY
               THRU 7100-BUILD-ATAB-KEY-X.
      *
      *   READ RECORD FOR UPDATE.
      *
014221*    PERFORM  ATAB-1000-READ-FOR-UPDATE
014221*        THRU ATAB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  ATAB-2000-UPDATE-TWRK-TS
014221         THRU ATAB-2000-UPDATE-TWRK-TS-X.

           IF WATAB-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973         MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
557973         MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.
      *
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'ATAB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WATAB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.
      *
           PERFORM  8500-CROSS-EDIT
               THRU 8500-CROSS-EDIT-X.
      *
           PERFORM  ATAB-2000-REWRITE
               THRU ATAB-2000-REWRITE-X.

014221     PERFORM  ATAB-1000-READ-TWRK-TS
014221         THRU ATAB-1000-READ-TWRK-TS-X.
      *
           IF  WS-DATA-EDITS = '0'
           AND WS-CROSS-EDITS = '0'
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973         MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
557973         MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973         MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
557973         MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      ***************************************************************
      *   DELETE PROCESSING: DELETE THE RECORD
      ***************************************************************
      *********************
       6000-PROCESS-DELETE.
      *********************

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.
      *
      *   BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-ATAB-KEY
               THRU 7100-BUILD-ATAB-KEY-X.
      *
      *   READ RECORD FOR UPDATE.
      *
014221*    PERFORM  ATAB-1000-READ-FOR-UPDATE
014221*        THRU ATAB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  ATAB-2000-UPDATE-TWRK-TS
014221         THRU ATAB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'ATAB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WATAB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WATAB-IO-NOT-FOUND
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973         MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
557973         MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  ATAB-1000-DELETE
                   THRU ATAB-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WATAB-KEY      TO WGLOB-MSG-PARM (1)
557973         MOVE WATAB-CO-ID       TO WS-WATAB-CO-ID
557973         MOVE WS-WATAB-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: CHECK VALIDITY OF ALL KEY FIELDS TO
      *  ENSURE THAT ALL NEW RECORDS ARE CREATED WITH VALID KEYS.
      *****************************************************************
       7000-EDIT-CONTROL-FIELDS.
      *
           MOVE '0'                   TO WS-DATA-EDITS.
      *
           PERFORM  7010-EDIT-AGE-AMT-PTR
               THRU 7010-EDIT-AGE-AMT-PTR-X.
      *
010645*    PERFORM  7020-EDIT-COUNTRY-CODE
010645*        THRU 7020-EDIT-COUNTRY-CODE-X.
010645     PERFORM  7020-EDIT-LOC-GR-CODE
010645         THRU 7020-EDIT-LOC-GR-CODE-X.
      *
           PERFORM  7030-EDIT-AGE-INSURED
               THRU 7030-EDIT-AGE-INSURED-X.
      *
           PERFORM  7040-EDIT-CURR-RISK
               THRU 7040-EDIT-CURR-RISK-X.
      *
           PERFORM  7050-EDIT-OCC-CLASS
               THRU 7050-EDIT-OCC-CLASS-X.
      *
       7000-EDIT-CONTROL-FIELDS-X.
           EXIT.
      /
      **************************************************************
      *   EDIT AGE-AMOUNT POINTER
      *
      **************************************************************
       7010-EDIT-AGE-AMT-PTR.
      *
      *   EDIT AGE-AMT-PTR
      *
           IF MIR-DFLT-REQIR-ID          = SPACES
               MOVE 'NS03300002'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DFLT-REQIR-ID TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.
      *
       7010-EDIT-AGE-AMT-PTR-X.
           EXIT.
      *
010645**************************************************************
010645*   EDIT COUNTRY_CODE
010645*
010645**************************************************************
010645*7020-EDIT-COUNTRY-CODE.
010645*
010645*    MOVE MIR-CTRYC    TO WEDIT-ETBL-VALU-ID.
010645*    PERFORM  AARG-1000-EDIT-ATAB-REGION
010645*        THRU AARG-1000-EDIT-ATAB-REGION-X.
010645*
010645*    IF NOT WEDIT-IO-OK
010645*        MOVE 'NS03300003' TO WGLOB-MSG-REF-INFO
010645*        PERFORM 0260-1000-GENERATE-MESSAGE
010645*           THRU 0260-1000-GENERATE-MESSAGE-X
010645*        MOVE -1           TO MIR-CTRYC-L
010645*        MOVE '1'          TO WS-DATA-EDITS
010645*        MOVE TATRB-KEYS-ERROR
010645*                          TO MIR-CTRYC-A
010645*    END-IF.
010645*
010645*7020-EDIT-COUNTRY-CODE-X.
010645*    EXIT.
010645**************************************************************
010645*   EDIT LOCATION GROUP CODE
010645*
010645**************************************************************
010645 7020-EDIT-LOC-GR-CODE.
010645*
010645     MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.
010645     PERFORM LGAS-1000-EDIT-LGAS-LOCATION
010645         THRU LGAS-1000-EDIT-LGAS-LOCATION-X.
010645*
010645     IF NOT WEDIT-IO-OK
010645         MOVE 'NS03300003'      TO WGLOB-MSG-REF-INFO
010645         PERFORM 0260-1000-GENERATE-MESSAGE
010645            THRU 0260-1000-GENERATE-MESSAGE-X
010645         MOVE '1'               TO WS-DATA-EDITS
010645     END-IF.
010645*
010645 7020-EDIT-LOC-GR-CODE-X.
010645     EXIT.
      *
      **************************************************************
      *   EDIT AGE-OF-INSURED
      *
      **************************************************************
       7030-EDIT-AGE-INSURED.
      *
           IF NOT WS-AGEIN-VALID
               GO TO 7030-EDIT-AGE-INSURED-X
557660     END-IF.
      *
           MOVE MIR-DFLT-REQIR-AGE    TO WS-NUM-AGE.
           IF NOT AGE-IN-RANGE
               MOVE 'NS03300005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.
       7030-EDIT-AGE-INSURED-X.
           EXIT.
      *
      *
      **************************************************************
      *   EDIT TOTAL CURRENT RISK.
      *
      **************************************************************
       7040-EDIT-CURR-RISK.
      *
           IF NOT WS-CURRISK-VALID
               GO TO 7040-EDIT-CURR-RISK-X
557660     END-IF.

008455*    MOVE MIR-DFLT-REQIR-TCR-AMT         TO WS-N-9S.

008455*    IF WS-N-9S < 1 THEN
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 0                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-DFLT-REQIR-TCR-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH   =  L0280-INPUT-SIZE.
008455     MOVE MIR-DFLT-REQIR-TCR-AMT              TO L0280-INPUT-DATA.
008455     PERFORM  7800-NUMERIC-EDIT
008455         THRU 7800-NUMERIC-EDIT-X.
008455     IF L0280-OUTPUT < 1
               MOVE 'NS03300010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.
      *
       7040-EDIT-CURR-RISK-X.
           EXIT.
      *
      **************************************************************
      *   EDIT OCC CLASS - MUST BE IN EDIT, TYPE OCCCL
      **************************************************************
       7050-EDIT-OCC-CLASS.
      *
           IF MIR-OCCP-CLAS-CD = SPACES
               GO TO 7050-EDIT-OCC-CLASS-X
557660     END-IF.

           MOVE MIR-OCCP-CLAS-CD      TO WEDIT-ETBL-VALU-ID.

           PERFORM OCCL-1000-EDIT
               THRU OCCL-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
      *** MSG (S) OCC CLASS MUST BE BLANK, OR IN EDIT, TYPE OCCCL
               MOVE 'NS03300011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.
      *
       7050-EDIT-OCC-CLASS-X.
           EXIT.
      /
      *
      *****************************************************************
      *  BUILD ATAB KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************
       7100-BUILD-ATAB-KEY.
      *
           MOVE MIR-DFLT-REQIR-ID     TO WATAB-DFLT-REQIR-ID.
010645*    MOVE MIR-CTRYC        TO WATAB-DFLT-REQIR-RGN-CD.
010645     MOVE MIR-LOC-GR-ID         TO WATAB-LOC-GR-ID.
           MOVE MIR-OCCP-CLAS-CD      TO WATAB-OCCP-CLAS-CD.
           MOVE MIR-DFLT-REQIR-AGE    TO WATAB-DFLT-REQIR-AGE.
557973*****MOVE MIR-DFLT-REQIR-TCR-AMT TO WATAB-DFLT-REQIR-TCR-AMT.
008455*    MOVE MIR-DFLT-REQIR-TCR-AMT TO WS-CURR-RISK-9.
008455*    MOVE WS-CURR-RISK-9   TO WATAB-DFLT-REQIR-TCR-AMT.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 0                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-DFLT-REQIR-TCR-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH  =  L0280-INPUT-SIZE.
008455     MOVE MIR-DFLT-REQIR-TCR-AMT              TO L0280-INPUT-DATA.
008455     PERFORM  7800-NUMERIC-EDIT
008455         THRU 7800-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT      TO WATAB-DFLT-REQIR-TCR-AMT
008455     END-IF.
557973
557973*
557973*  BUILD DISPLAY WATAB-KEY FIELD FOR ERROR MESSAGE
557973*
557973     MOVE MIR-DFLT-REQIR-ID     TO WS-WATAB-DFLT-REQIR-ID.
010645*    MOVE MIR-CTRYC        TO WS-WATAB-DFLT-REQIR-RGN-CD.
010645     MOVE MIR-LOC-GR-ID         TO WS-WATAB-LOC-GR-CD.
557973     MOVE MIR-OCCP-CLAS-CD      TO WS-WATAB-OCCP-CLAS-CD.
557973     MOVE MIR-DFLT-REQIR-AGE    TO WS-WATAB-DFLT-REQIR-AGE.
008455*    MOVE MIR-DFLT-REQIR-TCR-AMT TO WS-WATAB-DFLT-REQIR-TCR-AMT.
008455     IF L0280-OK
008455         MOVE L0280-OUTPUT      TO WS-WATAB-DFLT-REQIR-TCR-AMT
008455     END-IF.
      *
       7100-BUILD-ATAB-KEY-X.
           EXIT.
      *
      *
      *****************************************************************
      *  FORMAT KEY FIELDS.
      *****************************************************************
       7200-FORMAT-KEYS.
      *
      * FORMAT AGE OF INSURED
      *
           MOVE 'N'                   TO WS-AGEIN-INDICATOR.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-DFLT-REQIR-AGE    TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE 'Y'               TO WS-AGEIN-INDICATOR
               MOVE L0280-OUTPUT      TO WS-N-999
               MOVE WS-N-999          TO MIR-DFLT-REQIR-AGE
           ELSE
               MOVE 'NS03300004'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DFLT-REQIR-AGE             TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.
      *
      *  FORMAT CURRENT RISK TOTAL
      *
           MOVE MIR-DFLT-REQIR-TCR-AMT TO WS-REUSE-TEMP-FIELDS.
           IF  WS-REUSE-TEMP-FIELDS-ON
           AND WS-BUS-FCN-LIST
               GO TO 7200-FORMAT-KEYS-X
           END-IF.

           MOVE 'N'                   TO WS-CURRISK-INDICATOR.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
008455*    MOVE 9                TO L0280-LENGTH.
008455*    MOVE 9                TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-DFLT-REQIR-TCR-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH  =  L0280-INPUT-SIZE.
           MOVE MIR-DFLT-REQIR-TCR-AMT              TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE 'Y'               TO WS-CURRISK-INDICATOR
008455*        MOVE L0280-OUTPUT  TO WS-N-9S
008455*        MOVE WS-N-9S       TO MIR-DFLT-REQIR-TCR-AMT
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DFLT-REQIR-TCR-AMT
008455                                TO L0290-MAX-OUT-LEN
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                                TO MIR-DFLT-REQIR-TCR-AMT
           ELSE
               MOVE 'NS03300006'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DFLT-REQIR-TCR-AMT
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.

       7200-FORMAT-KEYS-X.
           EXIT.
      /
      *
      *****************************************************************
      *  FIELD EDITS: CHECK VALIDITY OF ALL DATA FIELDS.
      *****************************************************************
       7500-EDIT-DATA-FIELDS.
      *
           MOVE '0'                   TO WS-DATA-EDITS.
           MOVE SPACES                TO WS-REQ-TABLE.
      *
           MOVE +1                    TO WS-LSUB.
           PERFORM  7510-EDIT-TABLE
               THRU 7510-EDIT-TABLE-X.
      *
           IF WS-DATA-EDITS = '0'
               MOVE SPACES            TO WS-RQCD
               MOVE SPACES            TO MIR-REQIR-1-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-2-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-3-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-4-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-5-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-6-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-7-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-8-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-9-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-10-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-11-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-12-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-13-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-14-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-15-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-16-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-17-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-18-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-19-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-20-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-21-ID-T (1)
               MOVE SPACES            TO MIR-REQIR-22-ID-T (1)
               MOVE +0                TO WS-NEWSUB
               MOVE '0'               TO WS-FIRST
               PERFORM  8000-SHUFFLE-ATAB
                   THRU 8000-SHUFFLE-ATAB-X
                   VARYING WS-ATAB FROM 1 BY 1
                   UNTIL WS-ATAB > 22
               MOVE WS-RQCO1-T        TO MIR-REQIR-1-ID-T (WS-LSUB)
               MOVE WS-RQCO2-T        TO MIR-REQIR-2-ID-T (WS-LSUB)
               MOVE WS-RQCO3-T        TO MIR-REQIR-3-ID-T (WS-LSUB)
               MOVE WS-RQCO4-T        TO MIR-REQIR-4-ID-T (WS-LSUB)
               MOVE WS-RQCO5-T        TO MIR-REQIR-5-ID-T (WS-LSUB)
               MOVE WS-RQCO6-T        TO MIR-REQIR-6-ID-T (WS-LSUB)
               MOVE WS-RQCO7-T        TO MIR-REQIR-7-ID-T (WS-LSUB)
               MOVE WS-RQCO8-T        TO MIR-REQIR-8-ID-T (WS-LSUB)
               MOVE WS-RQCO9-T        TO MIR-REQIR-9-ID-T (WS-LSUB)
               MOVE WS-RQCO10-T       TO MIR-REQIR-10-ID-T (WS-LSUB)
               MOVE WS-RQCO11-T       TO MIR-REQIR-11-ID-T (WS-LSUB)
               MOVE WS-RQCO12-T       TO MIR-REQIR-12-ID-T (WS-LSUB)
               MOVE WS-RQCO13-T       TO MIR-REQIR-13-ID-T (WS-LSUB)
               MOVE WS-RQCO14-T       TO MIR-REQIR-14-ID-T (WS-LSUB)
               MOVE WS-RQCO15-T       TO MIR-REQIR-15-ID-T (WS-LSUB)
               MOVE WS-RQCO16-T       TO MIR-REQIR-16-ID-T (WS-LSUB)
               MOVE WS-RQCO17-T       TO MIR-REQIR-17-ID-T (WS-LSUB)
               MOVE WS-RQCO18-T       TO MIR-REQIR-18-ID-T (WS-LSUB)
               MOVE WS-RQCO19-T       TO MIR-REQIR-19-ID-T (WS-LSUB)
               MOVE WS-RQCO20-T       TO MIR-REQIR-20-ID-T (WS-LSUB)
               MOVE WS-RQCO21-T       TO MIR-REQIR-21-ID-T (WS-LSUB)
               MOVE WS-RQCO22-T       TO MIR-REQIR-22-ID-T (WS-LSUB)
557660     END-IF.
      *
       7500-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  FIELD EDITS: PERFORM ROUTINE TO EDIT REQUIRE. CODES.
      *****************************************************************
       7510-EDIT-TABLE.
      *
           MOVE MIR-REQIR-1-ID-T   (WS-LSUB)
                                      TO WS-RQCO1-T.
           MOVE MIR-REQIR-2-ID-T   (WS-LSUB)
                                      TO WS-RQCO2-T.
           MOVE MIR-REQIR-3-ID-T   (WS-LSUB)
                                      TO WS-RQCO3-T.
           MOVE MIR-REQIR-4-ID-T   (WS-LSUB)
                                      TO WS-RQCO4-T.
           MOVE MIR-REQIR-5-ID-T   (WS-LSUB)
                                      TO WS-RQCO5-T.
           MOVE MIR-REQIR-6-ID-T   (WS-LSUB)
                                      TO WS-RQCO6-T.
           MOVE MIR-REQIR-7-ID-T   (WS-LSUB)
                                      TO WS-RQCO7-T.
           MOVE MIR-REQIR-8-ID-T   (WS-LSUB)
                                      TO WS-RQCO8-T.
           MOVE MIR-REQIR-9-ID-T   (WS-LSUB)
                                      TO WS-RQCO9-T.
           MOVE MIR-REQIR-10-ID-T   (WS-LSUB)
                                      TO WS-RQCO10-T.
           MOVE MIR-REQIR-11-ID-T   (WS-LSUB)
                                      TO WS-RQCO11-T.
           MOVE MIR-REQIR-12-ID-T   (WS-LSUB)
                                      TO WS-RQCO12-T.
           MOVE MIR-REQIR-13-ID-T   (WS-LSUB)
                                      TO WS-RQCO13-T.
           MOVE MIR-REQIR-14-ID-T   (WS-LSUB)
                                      TO WS-RQCO14-T.
           MOVE MIR-REQIR-15-ID-T   (WS-LSUB)
                                      TO WS-RQCO15-T.
           MOVE MIR-REQIR-16-ID-T   (WS-LSUB)
                                      TO WS-RQCO16-T.
           MOVE MIR-REQIR-17-ID-T   (WS-LSUB)
                                      TO WS-RQCO17-T.
           MOVE MIR-REQIR-18-ID-T   (WS-LSUB)
                                      TO WS-RQCO18-T.
           MOVE MIR-REQIR-19-ID-T   (WS-LSUB)
                                      TO WS-RQCO19-T.
           MOVE MIR-REQIR-20-ID-T   (WS-LSUB)
                                      TO WS-RQCO20-T.
           MOVE MIR-REQIR-21-ID-T   (WS-LSUB)
                                      TO WS-RQCO21-T.
           MOVE MIR-REQIR-22-ID-T   (WS-LSUB)
                                      TO WS-RQCO22-T.
      *
      *
           PERFORM  7520-EDIT-REQ-CODE
               THRU 7520-EDIT-REQ-CODE-X
               VARYING WS-RSUB FROM 1 BY 1
               UNTIL WS-RSUB > 22.
      *
               MOVE WS-RQCO1-T        TO MIR-REQIR-1-ID-T (WS-LSUB).
               MOVE WS-RQCO2-T        TO MIR-REQIR-2-ID-T (WS-LSUB).
               MOVE WS-RQCO3-T        TO MIR-REQIR-3-ID-T (WS-LSUB).
               MOVE WS-RQCO4-T        TO MIR-REQIR-4-ID-T (WS-LSUB).
               MOVE WS-RQCO5-T        TO MIR-REQIR-5-ID-T (WS-LSUB).
               MOVE WS-RQCO6-T        TO MIR-REQIR-6-ID-T (WS-LSUB).
               MOVE WS-RQCO7-T        TO MIR-REQIR-7-ID-T (WS-LSUB).
               MOVE WS-RQCO8-T        TO MIR-REQIR-8-ID-T (WS-LSUB).
               MOVE WS-RQCO9-T        TO MIR-REQIR-9-ID-T (WS-LSUB).
               MOVE WS-RQCO10-T       TO MIR-REQIR-10-ID-T (WS-LSUB).
               MOVE WS-RQCO11-T       TO MIR-REQIR-11-ID-T (WS-LSUB).
               MOVE WS-RQCO12-T       TO MIR-REQIR-12-ID-T (WS-LSUB).
               MOVE WS-RQCO13-T       TO MIR-REQIR-13-ID-T (WS-LSUB).
               MOVE WS-RQCO14-T       TO MIR-REQIR-14-ID-T (WS-LSUB).
               MOVE WS-RQCO15-T       TO MIR-REQIR-15-ID-T (WS-LSUB).
               MOVE WS-RQCO16-T       TO MIR-REQIR-16-ID-T (WS-LSUB).
               MOVE WS-RQCO17-T       TO MIR-REQIR-17-ID-T (WS-LSUB).
               MOVE WS-RQCO18-T       TO MIR-REQIR-18-ID-T (WS-LSUB).
               MOVE WS-RQCO19-T       TO MIR-REQIR-19-ID-T (WS-LSUB).
               MOVE WS-RQCO20-T       TO MIR-REQIR-20-ID-T (WS-LSUB).
               MOVE WS-RQCO21-T       TO MIR-REQIR-21-ID-T (WS-LSUB).
               MOVE WS-RQCO22-T       TO MIR-REQIR-22-ID-T (WS-LSUB).
      *

       7510-EDIT-TABLE-X.
           EXIT.
      /
      *
      *****************************************************************
      *  EDIT REQUIREMENT CODES.
      *  THE CODE MUST EXIST ON THE RTAB FILE.
      *
      *  NOTE1: THERE ARE UPTO 22 OCCURENCES OF THE REQUIREMENT CODE
      *         PER RECORD. THESE ARE DISPLAYED OVER 2 LINES. THUS
      *         IF IT IS THE 2ND LINE BEING EDITED, ADD 11 TO WS-ATAB
      *         SUBSCRIPT, TO OBTAIN THE CORRECT POSITION ON THE FILE.
      *  NOTE2: IF A REQUIREMENT CODE IS BLANKED OUT, MOVE THE
      *         FOLLOWING OCCURENCES UP 1, SO THERE ARE NO SPACES
      *         BETWEEN CODES ON THE FILE.
      *****************************************************************
      *
       7520-EDIT-REQ-CODE.
      *
           MOVE WS-RSUB               TO WS-ATAB.

           IF WS-RQCD-T (WS-RSUB)  = SPACES
               MOVE RATAB-REQIR-ID         (WS-ATAB)
                                      TO WS-RQCD-T (WS-RSUB)
               GO TO 7520-EDIT-REQ-CODE-X
557660     END-IF.
      *
           IF WS-RQCD-T (WS-RSUB)  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES           TO RATAB-REQIR-ID         (WS-ATAB)
                                      WS-RQCD-T (WS-RSUB)
               GO TO 7520-EDIT-REQ-CODE-X
557660     END-IF.
      *
           MOVE WS-RQCD-T (WS-RSUB)
                                      TO WRTAB-REQIR-ID.
      *
           PERFORM  RTAB-1000-READ
               THRU RTAB-1000-READ-X.
      *
           IF NOT WRTAB-IO-OK
               MOVE 'XS00000114'      TO WGLOB-MSG-REF-INFO
               MOVE WS-RQCD-T (WS-RSUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
               GO TO 7520-EDIT-REQ-CODE-X
557660     END-IF.
      *
      *
           MOVE WS-RQCD-T (WS-RSUB)   TO RATAB-REQIR-ID (WS-ATAB).
      *
       7520-EDIT-REQ-CODE-X.
           EXIT.
      /
      *****************************************************************
      *  NUMERIC EDIT
      *****************************************************************
       7800-NUMERIC-EDIT.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
       7800-NUMERIC-EDIT-X.
           EXIT.
      /
      *****************************************************************
      *  AFTER EDITING IS COMPLETE, SHUFFLE REQUIREMENT CODES
      *  SO THAT THERE ARE NO BLANK SPACES BETWEEN CODES ON THE ATAB.
      *****************************************************************
       8000-SHUFFLE-ATAB.
      *
           IF RATAB-REQIR-ID (WS-ATAB)  NOT = SPACES
               ADD +1                TO WS-NEWSUB
               MOVE RATAB-REQIR-ID (WS-ATAB)
                                     TO RATAB-REQIR-ID (WS-NEWSUB)
               IF WS-ATAB > WS-NEWSUB
                   MOVE SPACES       TO RATAB-REQIR-ID (WS-ATAB)
557660         END-IF
557660     END-IF.
      *
           MOVE +1                    TO WS-LSUB.
           MOVE WS-NEWSUB             TO WS-RSUB.

           IF  WS-NEWSUB = ZERO
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE RATAB-REQIR-ID (WS-NEWSUB)
                                      TO WS-RQCD-T (WS-RSUB)
557660     END-IF.

       8000-SHUFFLE-ATAB-X.
           EXIT.
      /
      ***************************************************************
      *  CROSS EDIT: ENSURE THAT DUPLICATES DON'T EXIST.
      ***************************************************************
      *
       8500-CROSS-EDIT.
      *
           MOVE '0'                   TO WS-CROSS-EDITS.
      *
           PERFORM  8520-SCAN-RATAB
               THRU 8520-SCAN-RATAB-X
               VARYING WS-ATAB FROM 1 BY 1
               UNTIL WS-ATAB > 22.
      *
       8500-CROSS-EDIT-X.
           EXIT.
      *
      ****************************************************************
      *  SCAN RATAB REQUIREMENT CODES, IF SPACE DO NOT CHECK IF
      *  DUPLICATES.
      ****************************************************************
      *
       8520-SCAN-RATAB.
      *
           IF RATAB-REQIR-ID (WS-ATAB) = SPACES
               GO TO 8520-SCAN-RATAB-X
557660     END-IF.
      *
           PERFORM
               VARYING WS-NEWSUB FROM 1 BY 1
               UNTIL WS-NEWSUB > 22 OR
               WS-REQ-1 (WS-NEWSUB) =
                        RATAB-REQIR-ID (WS-ATAB) OR
               WS-REQ-1 (WS-NEWSUB) = SPACES
015543         CONTINUE
           END-PERFORM.
      *
           IF WS-NEWSUB > 22
               MOVE '1'               TO WS-CROSS-EDITS
               MOVE 'NS03300008'      TO WGLOB-MSG-REF-INFO
               MOVE RATAB-REQIR-ID         (WS-ATAB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8520-SCAN-RATAB-X
557660     END-IF.
      *
           IF WS-REQ-1 (WS-NEWSUB) = RATAB-REQIR-ID (WS-ATAB)
               MOVE '1'               TO WS-CROSS-EDITS
               MOVE 'NS03300009'      TO WGLOB-MSG-REF-INFO
               MOVE RATAB-REQIR-ID         (WS-ATAB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8520-SCAN-RATAB-X
557660     END-IF.
      *
           MOVE RATAB-REQIR-ID (WS-ATAB)
                                      TO WS-REQ-1 (WS-NEWSUB).
      *
       8520-SCAN-RATAB-X.
           EXIT.
      *
      *
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.
      *
           PERFORM  9110-BLANK-DISPLAY-LINES
               THRU 9110-BLANK-DISPLAY-LINES-X
               VARYING WS-LINES FROM 1 BY 1
               UNTIL (WS-LINES > WS-NO-DISPLAY-LINES).
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH DISPLAY LINE TO BLANKS
      *****************************************************************
       9110-BLANK-DISPLAY-LINES.
      *
           MOVE SPACES            TO MIR-DFLT-REQIR-TCR-AMT-T (WS-LINES)
                          MIR-REQIR-1-ID-T (WS-LINES)
                          MIR-REQIR-2-ID-T (WS-LINES)
                          MIR-REQIR-3-ID-T (WS-LINES)
                          MIR-REQIR-4-ID-T (WS-LINES)
                          MIR-REQIR-5-ID-T (WS-LINES)
                          MIR-REQIR-6-ID-T (WS-LINES)
                          MIR-REQIR-7-ID-T (WS-LINES)
                          MIR-REQIR-8-ID-T (WS-LINES)
                          MIR-REQIR-9-ID-T (WS-LINES)
                          MIR-REQIR-10-ID-T (WS-LINES)
                          MIR-REQIR-11-ID-T (WS-LINES)
                          MIR-REQIR-12-ID-T (WS-LINES)
                          MIR-REQIR-13-ID-T (WS-LINES)
                          MIR-REQIR-14-ID-T (WS-LINES)
                          MIR-REQIR-15-ID-T (WS-LINES)
                          MIR-REQIR-16-ID-T (WS-LINES)
                          MIR-REQIR-17-ID-T (WS-LINES)
                          MIR-REQIR-18-ID-T (WS-LINES)
                          MIR-REQIR-19-ID-T (WS-LINES)
                          MIR-REQIR-20-ID-T (WS-LINES)
                          MIR-REQIR-21-ID-T (WS-LINES)
                          MIR-REQIR-22-ID-T (WS-LINES).
      *
       9110-BLANK-DISPLAY-LINES-X.
           EXIT.
      *
      *
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.
      *
      ***  IF THE FIRST DISPLAY LINE IS BEING FILLED MOVE CURRENT
      ***  RISK TO THE CONTROL LINE AS WELL BECAUSE LINE 1 IS MAINTAIN
      ***  LINE.
      *
           IF WS-LINES = 1
               MOVE RATAB-DFLT-REQIR-ID
                                      TO MIR-DFLT-REQIR-ID
010645*        MOVE RATAB-DFLT-REQIR-RGN-CD TO MIR-CTRYC
010645         MOVE RATAB-LOC-GR-ID   TO MIR-LOC-GR-ID
               MOVE RATAB-OCCP-CLAS-CD               TO MIR-OCCP-CLAS-CD
               MOVE RATAB-DFLT-REQIR-AGE
                                      TO MIR-DFLT-REQIR-AGE
557973*****    MOVE RATAB-DFLT-REQIR-TCR-AMT TO MIR-DFLT-REQIR-TCR-AMT
008455*        MOVE RATAB-DFLT-REQIR-TCR-AMT TO WS-CURR-RISK-9
008455*        MOVE WS-CURR-RISK-9           TO MIR-DFLT-REQIR-TCR-AMT
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DFLT-REQIR-TCR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         MOVE RATAB-DFLT-REQIR-TCR-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DFLT-REQIR-TCR-AMT
008455
018633*        MOVE RATAB-DFLT-REQIR-ID    TO WS-LAST-DFLT-REQIR-ID
018633*        MOVE RATAB-LOC-GR-ID        TO WS-LAST-LOC-GR-ID
018633*        MOVE RATAB-OCCP-CLAS-CD     TO WS-LAST-OCCP-CLAS-CD
018633*        MOVE RATAB-DFLT-REQIR-AGE   TO WS-LAST-DFLT-REQIR-AGE
018633         MOVE RATAB-DFLT-REQIR-ID    TO LCOMM-LAST-DFLT-REQIR-ID
018633         MOVE RATAB-LOC-GR-ID        TO LCOMM-LAST-LOC-GR-ID
018633         MOVE RATAB-OCCP-CLAS-CD     TO LCOMM-LAST-OCCP-CLAS-CD
018633         MOVE RATAB-DFLT-REQIR-AGE   TO LCOMM-LAST-DFLT-REQIR-AGE
               MOVE RATAB-DFLT-REQIR-TCR-AMT
018633*                                    TO WS-LAST-DFLT-REQIR-TCR-AMT
018633                                 TO LCOMM-LAST-DFLT-REQIR-TCR-AMT
557660     END-IF.
           MOVE +0                    TO WS-RSUB.
      *
           PERFORM  9220-MOVE-DETAILS
               THRU 9220-MOVE-DETAILS-X.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE DETAILS TO LINE.
      *****************************************************************
       9220-MOVE-DETAILS.
      *
           MOVE 0                 TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DFLT-REQIR-TCR-AMT-T (WS-LINES)
                                  TO L0290-MAX-OUT-LEN.
           MOVE RATAB-DFLT-REQIR-TCR-AMT
020874*                           TO L0290-INPUT-NUMBER.
020874                            TO L0290-INPUT-V00.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA TO
                                 MIR-DFLT-REQIR-TCR-AMT-T (WS-LINES).

           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-1-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-2-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-3-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-4-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-5-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-6-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-7-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-8-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-9-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-10-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-11-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-12-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-13-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-14-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-15-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-16-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-17-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-18-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-19-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-20-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-21-ID-T (WS-LINES).
           ADD +1                              TO WS-RSUB.
           MOVE RATAB-REQIR-ID         (WS-RSUB)
                                      TO MIR-REQIR-22-ID-T (WS-LINES).
           ADD +1   TO WS-LINES.
      *
       9220-MOVE-DETAILS-X.
           EXIT.
      *
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-REQ-TABLE.
025970     INITIALIZE                         WS-RQCD-DETAILS.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
023514
025970     SET WS-DEFAULT-NO-DISPLAY-LINES    TO TRUE.
025970     SET WS-DEFAULT-HIGH-CURR-RISK      TO TRUE.
025970     SET WS-DEFAULT-DATA-EDIT           TO TRUE.
025970     SET WS-DEFAULT-EDITS               TO TRUE.
025970     SET WS-DEFAULT-FIRST               TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
018633*--------------------
018633*9500-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*     MOVE WS-TWRK-KEY          TO L8090-BUS-FCN-ID.
018633*     MOVE ZEROS                TO L8090-TEMP-WRK-SEQ-NUM.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    SET L8090-USAGE-COMM       TO TRUE.
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*----------------
018633*9800-WRITE-TWRK.
018633*----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    SET L8090-USAGE-COMM        TO TRUE.
018633*    MOVE LENGTH OF WS-TWRK-AREA TO L8090-AREA-LEN.
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9900-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    SET L8090-USAGE-COMM       TO TRUE.
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY ATAB
014221                         '$VAR2' BY 'ATAB'.
010645*COPY NCPEAARG.
010645 COPY CCPELGAS.
      /
       COPY CCPEOCCL.
008455/
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY NCPAATAB.
      /
       COPY NCPBATAB.
      /
       COPY NCPNATAB.
      /
       COPY NCPCATAB.
      /
       COPY NCPUATAB.
      /
       COPY NCPXATAB.
      /
       COPY NCPNRTAB.
      /
      ****************************************************************
      * LINK TO  COPYBOOKS                                           *
      ****************************************************************
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.

      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY CCPNEDIT.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0330                     **
      *****************************************************************
