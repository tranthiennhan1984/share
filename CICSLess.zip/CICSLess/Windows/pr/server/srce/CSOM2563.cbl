      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2563.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2563                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE IPRD AND IPDF TABLES                     **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2563'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-CONSTANTS.
               10  WS-TWRK-KEY                  PIC X(04)
                                                VALUE '2563'.
025970             88  WS-TWRK-KEY-DEFAULT      VALUE '2563'.

           05  WS-VARIABLES.
               10  WS-BUS-FCN-ID                PIC X(04).
                   88  WS-BUS-FCN-DELETE        VALUE '2563'.
               10  WS-PRFLD-EFF-DT              PIC X(10).
               10  WS-PRFLD-SEQ-NUM             PIC 9(03).
               10  WS-FOUND-SW                  PIC X(01).
                   88  WS-FOUND                 VALUE 'Y'.
                   88  WS-NOTFND                VALUE 'N'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWIPRD.
       COPY CCFRIPRD.
       COPY CCFWIPRO.
       COPY CCFRIPRO.
       COPY CCFWIPRE.
       COPY CCFWIPDF.
       COPY CCFRIPDF.
       COPY CCFWPLIQ.
       COPY CCFRPLIP.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2563.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*                                TO WS-BUS-FCN-ID.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2563'
                                       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                                       TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                       TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-DELETE.
      *--------------
      *
      *  THE RECORD MUST EXIST, AND HAVE A CURRENT TIMESTAMP
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-DELETE-X
           END-IF.

           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.
           PERFORM  IPRO-2000-UPDATE-TWRK-TS
               THRU IPRO-2000-UPDATE-TWRK-TS-X.

           IF  WIPRO-IO-NOT-FOUND
      *MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
               MOVE WIPRO-KEY
                                       TO WGLOB-MSG-PARM (1)
               MOVE 'TIPRO'
                                       TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'
                                       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                                       TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           IF MIR-RETRN-TS-MISMATCH
      *MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2'
              MOVE 'XS00000303'
                                       TO WGLOB-MSG-REF-INFO
              MOVE 'IPRO'
                                       TO WGLOB-MSG-PARM (1)
              MOVE WIPRO-KEY
                                       TO WGLOB-MSG-PARM (2)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2000-DELETE-X
           END-IF.

      * EDIT THE DATA ENTERED FOR THE RECORD

           PERFORM  IPRD-1000-READ-FOR-UPDATE
               THRU IPRD-1000-READ-FOR-UPDATE-X.

           IF  WIPRD-IO-NOT-FOUND
      *MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
               MOVE WIPRD-KEY
                                       TO WGLOB-MSG-PARM (1)
               MOVE 'TIPRD'
                                       TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'
                                       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               SET MIR-RETRN-RQST-FAILED
                                       TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  7200-VALIDATE-KEY
               THRU 7200-VALIDATE-KEY-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  8000-EDIT-DATA
               THRU 8000-EDIT-DATA-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

      *  DELETE THE RECORD AND AUDIT THE CHANGE

           PERFORM  8500-DELETE-IPDF-RECORDS
               THRU 8500-DELETE-IPDF-RECORDS-X.

           PERFORM  IPRD-1000-DELETE
               THRU IPRD-1000-DELETE-X.

      *MSG: RECORD DELETED SUCCESSFULLY - CONTINUE

           IF  WIPRD-IO-OK
      *MSG:    DELETE COMPLETED MESSAGE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WIPRO-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               GO TO 2000-DELETE-X
           END-IF.

           IF NOT RIPRD-PRFLD-STAT-PEND
              PERFORM  8700-SWITCH-STATUS
                  THRU 8700-SWITCH-STATUS-X
           END-IF.

           PERFORM  IPRO-2000-REWRITE
               THRU IPRO-2000-REWRITE-X.

       2000-DELETE-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WIPRD-KEY.
           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.

           MOVE MIR-PRFLD-EFF-DT       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                       TO WS-PRFLD-EFF-DT
               MOVE WS-PRFLD-EFF-DT    TO WIPRD-PRFLD-EFF-DT

           ELSE
      *MSG: INVALID EFFECTIVE DATE
               MOVE 'CS25630001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           MOVE MIR-PRFLD-SEQ-NUM      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-INPUT-SIZE.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           SET L0280-SPACES-PERMITTED  TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT       TO WS-PRFLD-SEQ-NUM
               MOVE WS-PRFLD-SEQ-NUM   TO WIPRD-PRFLD-SEQ-NUM
           ELSE
      *MSG: SEQUENCE NUMBER MUST BE VALID NUMERIC
               MOVE 'CS25630002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *------------------
       7200-VALIDATE-KEY.
      *------------------

           MOVE LOW-VALUE              TO WPLIQ-KEY.
           MOVE MIR-PRFL-ID            TO WPLIQ-PRFL-ID.

           MOVE WPLIQ-KEY              TO WPLIQ-ENDBR-KEY.

           PERFORM  PLIQ-4000-BROWSE-INDEX
               THRU PLIQ-4000-BROWSE-INDEX-X.

           PERFORM  PLIQ-5000-READ-NEXT-INDEX
               THRU PLIQ-5000-READ-NEXT-INDEX-X.

           IF  WPLIQ-IO-OK
           AND RIPRD-PRFLD-STAT-ACTV
      *MSG: PLAN INVESTOR PROFILE RECORD (@1) EXISTS: CANNOT DELETE
      *     PROFILE
               MOVE 'CS25630003'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           PERFORM  PLIQ-6000-END-BROWSE-INDEX
               THRU PLIQ-6000-END-BROWSE-INDEX-X.

       7200-VALIDATE-KEY-X.
           EXIT.
      /
      *---------------
       8000-EDIT-DATA.
      *---------------

           IF  RIPRD-PRFLD-STAT-HIST
      *MSG: HISTORY INVESTOR PROFILES CANNOT BE DELETED
               MOVE 'CS25630004'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  RIPRD-PRFLD-STAT-ACTV
               MOVE MIR-PRFL-ID        TO WIPRE-PRFL-ID
               SET  WIPRE-PRFLD-STAT-PEND
                                       TO TRUE

               MOVE WIPRE-KEY          TO WIPRE-ENDBR-KEY

               PERFORM  IPRE-1000-BROWSE
                   THRU IPRE-1000-BROWSE-X

               PERFORM  IPRE-2000-READ-NEXT
                   THRU IPRE-2000-READ-NEXT-X

               IF  WIPRE-IO-OK
      *MSG: DELETE UNSUCCESSFUL.  THE PENDING INVESTOR PROFILE (@1) MUST
      *     BE DELETED FIRST
                   MOVE 'CS25630005'   TO WGLOB-MSG-REF-INFO
                   MOVE MIR-PRFL-ID    TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF

               PERFORM  IPRE-3000-END-BROWSE
                   THRU IPRE-3000-END-BROWSE-X

           END-IF.

       8000-EDIT-DATA-X.
           EXIT.
      /

      *-------------------------
       8500-DELETE-IPDF-RECORDS.
      *-------------------------

           MOVE LOW-VALUE              TO WIPDF-KEY.
           MOVE MIR-PRFL-ID            TO WIPDF-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPDF-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPDF-PRFLD-SEQ-NUM.
           MOVE ZERO                   TO WIPDF-PRFLDF-SEQ-NUM.

           MOVE WIPDF-KEY              TO WIPDF-ENDBR-KEY.
           MOVE 999                    TO WIPDF-ENDBR-PRFLDF-SEQ-NUM.

           PERFORM  IPDF-1000-BROWSE
               THRU IPDF-1000-BROWSE-X.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

           PERFORM  8525-DELETE-IPDF
               THRU 8525-DELETE-IPDF-X
               UNTIL NOT WIPDF-IO-OK.

           PERFORM  IPDF-3000-END-BROWSE
               THRU IPDF-3000-END-BROWSE-X.

       8500-DELETE-IPDF-RECORDS-X.
           EXIT.
      /
      *-----------------
       8525-DELETE-IPDF.
      *-----------------

           PERFORM  IPDF-1000-READ-FOR-UPDATE
               THRU IPDF-1000-READ-FOR-UPDATE-X.

           PERFORM  IPDF-1000-DELETE
               THRU IPDF-1000-DELETE-X.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

       8525-DELETE-IPDF-X.
           EXIT.
      /
      *-------------------
       8700-SWITCH-STATUS.
      *-------------------

           SET WS-NOTFND               TO TRUE.
           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.
           MOVE WWKDT-HIGH-DT          TO WIPRD-PRFLD-EFF-DT.
           MOVE 999                    TO WIPRD-PRFLD-SEQ-NUM.

           MOVE WIPRD-KEY              TO WIPRD-ENDBR-KEY.
           MOVE WWKDT-LOW-DT           TO WIPRD-ENDBR-PRFLD-EFF-DT.
           MOVE ZERO                   TO WIPRD-ENDBR-PRFLD-SEQ-NUM.

           PERFORM  IPRD-1000-BROWSE-PREV
               THRU IPRD-1000-BROWSE-PREV-X.

           IF WIPRD-IO-OK
               PERFORM  IPRD-2000-READ-PREV
                   THRU IPRD-2000-READ-PREV-X
           END-IF.

           PERFORM
               UNTIL NOT WIPRD-IO-OK
               OR    WS-FOUND
               IF  RIPRD-PRFLD-STAT-HIST
                   PERFORM  IPRD-1000-READ-FOR-UPDATE
                       THRU IPRD-1000-READ-FOR-UPDATE-X
                   SET RIPRD-PRFLD-STAT-ACTV
                                       TO TRUE
                   PERFORM  IPRD-2000-REWRITE
                       THRU IPRD-2000-REWRITE-X
                   SET WS-FOUND        TO TRUE
               END-IF
               PERFORM  IPRD-2000-READ-PREV
                   THRU IPRD-2000-READ-PREV-X
           END-PERFORM.

           PERFORM  IPRD-3000-END-BROWSE-PREV
               THRU IPRD-3000-END-BROWSE-PREV-X.

       8700-SWITCH-STATUS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-VARIABLES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET  MIR-RETRN-OK       TO  TRUE.
025970     MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  IPRO
                                '$VAR2'   BY 'IPRO'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPUIPRD.
       COPY CCPVIPRD.
       COPY CCPXIPRD.

       COPY CCPNIPRO.
       COPY CCPUIPRO.

       COPY CCPBIPRE.
       COPY CCPBIPDF.
       COPY CCPUIPDF.
       COPY CCPXIPDF.
       COPY CCPBPLIQ.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2563                     **
      *****************************************************************
