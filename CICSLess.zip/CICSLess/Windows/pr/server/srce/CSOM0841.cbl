      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0841.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0841                                         **
      **  REMARKS:  PROCESS DRIVER FOR LICENCE TABLE - LTAB          **
      **            THIS PROGRAM IS RESPONSIBLE FOR THE MAINTENANCE  **
      **            OF THE LI-FILE.  THE LTAB FILE IS ACCESSED USING **
      **            THE KEY OF 'TYPE: THE TYPE OF LICENCE' AND       **
      **            'LOCATION: WHICH IS A TWO CHARACTER IDENTIFIER   **
      **            OF THE LOCATION' AND 'CLASS: THE CLASS OF        **
      **            BUSINESS'.  A DATE IS KEPT DEFINING WHEN THE     **
      **            RECORD IS INFORCE.  THERE IS ALSO A DESCRIPTION  **
      **            FOR FOR DOC. OF THE RECORD.                      **
      **                                                             **
      **  DOMAIN :  AG                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
006002**  6.0       NEW COUNTRY LOCATION TABLE                       **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028786**  6.7       EXTERNAL AGENCY INTEGRATION - COMPENSATION CALC. **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0841'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *****************************************************************
      *  COMMON ON-LINE WS AND COPYBOOKS
      *****************************************************************

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       COPY XCWWWKDT.
       COPY XCWEBLCH.

       01  WS-PROGRAM-WORK-AREA.
013578*    05  WS-ENTER-CODE           PIC X(01).
013578*        88 WS-ENTER-CODE-VALID  VALUE 'B' 'M' 'C' 'D'.
013578     05  WS-BUS-FCN-ID           PIC X(04).
013578         88  WS-BUS-FCN-RETRIEVE VALUES '0700'.
013578         88  WS-BUS-FCN-CREATE   VALUES '0701'.
013578         88  WS-BUS-FCN-UPDATE   VALUES '0702'.
013578         88  WS-BUS-FCN-DELETE   VALUES '0703'.
013578         88  WS-BUS-FCN-LIST     VALUES '0704'.
025970*    05  WS-TWRK-KEY             PIC X(04)  VALUE '0700'.
013578*    05  WS-L-SUB                PIC 9(02)  VALUE 0.
013578     05  WS-L-SUB                PIC 9(03)  VALUE 0.
           05  WS-ERROR-SW             PIC X(01).
028786     05  WS-DV-LIC-TYP-CD        PIC X(01).
028786         88  WS-DV-LIC-TYP-AGENT            VALUE 'A'.
028786         88  WS-DV-LIC-TYP-PLAN             VALUE 'P'.

025970 01 WS-CONSTANTS.
025970     05  WS-TWRK-KEY             PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT VALUE '0700'.

      *
      *****************************************************************
      *  FILE AND OTHER RECORD LAYOUTS
      *****************************************************************

       COPY CCFWEDIT.
      *
       COPY CCFREDIT.
      *
028786*COPY CCFWAG.
028786*
028786*COPY CCFRAG.
      *
       COPY CCFWLI.

       COPY CCFRLI.
      *
       COPY CCFWPH.

       COPY CCFRPH.
006002*
021930*COPY XCFWCTLC.
021930*COPY XCFRCTLC.
      *
      *****************************************************************
      *  PARAMETER WORK AREA
      *****************************************************************

028786 COPY CCWL0083.
       COPY XCWLDTLK.
       COPY XCWL1640.
014221 COPY XCWL8090.

      *****************************************************************
      *  PROGRAM COMMON WORK AREA
      *****************************************************************

014221 COPY CCWWLOCK.

014588*COPY CCWCCOMM.

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.

      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0841.

      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           MOVE ZEROES                TO WS-ERROR-SW.

           IF  WS-BUS-FCN-UPDATE
               PERFORM 9300-BLANK-TO-BOTTOM
                  THRU 9300-BLANK-TO-BOTTOM-X
                  VARYING WS-L-SUB FROM 2 BY 1
                  UNTIL   WS-L-SUB >100
           ELSE
               PERFORM 9300-BLANK-TO-BOTTOM
                  THRU 9300-BLANK-TO-BOTTOM-X
                  VARYING WS-L-SUB FROM 1 BY 1
                  UNTIL   WS-L-SUB > 100
557660     END-IF.

      *
      *    SET UP KEY FIELDS FOR ACCESSING THE LI FILE
      *
           MOVE MIR-LIC-ID            TO WLI-LIC-ID.
           MOVE MIR-LIC-LOC-CD        TO WLI-LIC-LOC-CD.
           MOVE MIR-LIC-BUS-CLAS-CD   TO WLI-LIC-BUS-CLAS-CD.
      *
      *    PERFORM THE REQUIRED PROCESSING
      *
013578     IF  WS-BUS-FCN-RETRIEVE
013578         PERFORM  3000-PROCESS-RETRIEVE
013578             THRU 3000-PROCESS-RETRIEVE-X
013578     END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  3500-PROCESS-LIST
                   THRU 3500-PROCESS-LIST-X
557660     END-IF.

           IF  WS-BUS-FCN-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
557660     END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
557660     END-IF.

           IF  WS-BUS-FCN-DELETE
               PERFORM  6000-PROCESS-DELETE
                   THRU 6000-PROCESS-DELETE-X
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

014221*    PERFORM  LI-1000-READ
014221*        THRU LI-1000-READ-X.

014221     PERFORM  LI-1000-READ-TWRK-TS
014221         THRU LI-1000-READ-TWRK-TS-X.

      *
      *    LICENCE RECORD NOT FOUND FOR MAINTENANCE
      *
           IF  WLI-IO-NOT-FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE  WLI-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   GO TO 3000-PROCESS-RETRIEVE-X
557660         END-IF
557660     END-IF.

      *
      *    DISPLAY DESCRIPTION FROM THE CURRENT LICENCE RECORD
      *    PERFORM NECESSARY DATE CONVERSIONS ON THE STORED DATES
      *

           MOVE RLI-LIC-ID            TO MIR-LIC-ID-T (01).
           MOVE RLI-LIC-LOC-CD        TO MIR-LIC-LOC-CD-T (01).
           MOVE RLI-LIC-BUS-CLAS-CD   TO MIR-LIC-BUS-CLAS-CD-T (01).
           MOVE RLI-LIC-DESC-TXT      TO MIR-LIC-DESC-TXT-T (01).

           IF  RLI-LIC-EFF-DT NOT EQUAL TO WWKDT-ZERO-DT
               MOVE RLI-LIC-EFF-DT    TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LIC-EFF-DT-T (01)
           ELSE
               MOVE SPACES            TO MIR-LIC-EFF-DT-T (01)
557660     END-IF.

           IF  RLI-LIC-XPRY-DT NOT EQUAL TO WWKDT-ZERO-DT
               MOVE RLI-LIC-XPRY-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X

               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LIC-XPRY-DT-T (01)
           ELSE
               MOVE SPACES            TO MIR-LIC-XPRY-DT-T (01)
557660     END-IF.

           PERFORM  9300-BLANK-TO-BOTTOM
               THRU 9300-BLANK-TO-BOTTOM-X
               VARYING WS-L-SUB FROM 2 BY 1
               UNTIL   WS-L-SUB > 100.

           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.

      *-------------------
       3100-INQ-READ-NEXT.
      *-------------------

           ADD 1                    TO WS-L-SUB.
      *
      *    BUILD OUTPUT LINE FOR SCREEN TABLE DISPLAY
      *
           MOVE RLI-LIC-ID          TO MIR-LIC-ID-T (WS-L-SUB).
           MOVE RLI-LIC-LOC-CD      TO MIR-LIC-LOC-CD-T (WS-L-SUB).
           MOVE RLI-LIC-BUS-CLAS-CD TO
                                 MIR-LIC-BUS-CLAS-CD-T (WS-L-SUB).

           IF  RLI-LIC-EFF-DT NOT EQUAL TO WWKDT-ZERO-DT
               MOVE RLI-LIC-EFF-DT  TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X

               MOVE L1640-EXTERNAL-DATE
                                    TO MIR-LIC-EFF-DT-T (WS-L-SUB)
           ELSE
               MOVE SPACES          TO MIR-LIC-EFF-DT-T (WS-L-SUB)
557660     END-IF.

           IF  RLI-LIC-XPRY-DT NOT EQUAL TO WWKDT-ZERO-DT
               MOVE RLI-LIC-XPRY-DT TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X

               MOVE L1640-EXTERNAL-DATE
                                    TO MIR-LIC-XPRY-DT-T (WS-L-SUB)
           ELSE
               MOVE SPACES          TO MIR-LIC-XPRY-DT-T (WS-L-SUB)
557660     END-IF.

           MOVE RLI-LIC-DESC-TXT    TO MIR-LIC-DESC-TXT-T (WS-L-SUB).

           PERFORM  LI-2000-READ-NEXT
               THRU LI-2000-READ-NEXT-X.

       3100-INQ-READ-NEXT-X.
           EXIT.

      *--------------------
       3200-INQ-END-BROWSE.
      *--------------------
      *
      *    CHECK IF ALL RECORDS REQUESTED FOR INQUIRY
      *    HAVE BEEN DISPLAYED
      *
           IF  RLI-LIC-ID NOT = MIR-LIC-ID
               MOVE 8                 TO WLI-IO-STATUS
           END-IF.
      *
      *    CHECK IF THE TABLE DISPLAY AREA IS FULL
      *
           IF  WS-L-SUB = 100
               MOVE MIR-LIC-ID-T (100) TO MIR-LIC-ID
               MOVE MIR-LIC-LOC-CD-T (100)
                                      TO MIR-LIC-LOC-CD
               MOVE MIR-LIC-BUS-CLAS-CD-T (100)
                                      TO MIR-LIC-BUS-CLAS-CD
               PERFORM  LI-3000-END-BROWSE
                   THRU LI-3000-END-BROWSE-X
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
034802*        IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802*        ELSE
034802*            NEXT SENTENCE
034802*        END-IF
           ELSE
      *
      *    CHECK IF NO RECORDS ARE FOUND FOR THE INQUIRY
      *
               IF  WS-L-SUB = 0
                   MOVE 'XS00000034'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *
      *    ALL RECORDS HAVE BEEN FOUND FOR THE INQUIRY
      *
                   ADD   1             TO WS-L-SUB

                   PERFORM  LI-3000-END-BROWSE
                       THRU LI-3000-END-BROWSE-X
                   MOVE 'XS00000015'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       3200-INQ-END-BROWSE-X.
           EXIT.

      *------------------
       3500-PROCESS-LIST.
      *------------------

           MOVE 0                     TO WS-L-SUB.

           MOVE HIGH-VALUES           TO WLI-ENDBR-KEY.
           MOVE WLI-LIC-ID            TO WLI-ENDBR-LIC-ID.
      *
      *    BEGIN BROWSING OF THE LICENCE TABLE FOR THE KEY ENTERED
      *
           PERFORM  LI-1000-BROWSE
               THRU LI-1000-BROWSE-X.

           IF  WLI-IO-EOF
               PERFORM  3200-INQ-END-BROWSE
                   THRU 3200-INQ-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.
      *
      *    BUILD SCREEN TABLE DISPLAY FOR THE KEY ENTERED
      *
           PERFORM  LI-2000-READ-NEXT
               THRU LI-2000-READ-NEXT-X.
           PERFORM  3100-INQ-READ-NEXT
               THRU 3100-INQ-READ-NEXT-X
              UNTIL WLI-IO-EOF
                 OR (NOT WLI-IO-OK)
                 OR WS-L-SUB = 100.

           PERFORM  3200-INQ-END-BROWSE
               THRU 3200-INQ-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.

      *--------------------
       4000-PROCESS-CREATE.
      *--------------------

      *
      *  RESET ATTRIBUTES FOR KEY FIELDS
      *

           PERFORM  LI-1000-READ
               THRU LI-1000-READ-X.
      *
      *    CHECK IF RECORD ALREADY EXISTS FOR KEY ENTERED
      *
           IF  WLI-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE  WLI-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   GO TO 4000-PROCESS-CREATE-X
557660         END-IF
557660     END-IF.
      *
      *    VALIDATE LOCATION AND INITIALIZE LOCATION DESCRIPTION
      *
           PERFORM  4100-VALIDATE-LOC
               THRU 4100-VALIDATE-LOC-X.

      *
      *    VALIDATE CLASS AND INITIALIZE CLASS DESCRIPTION
      *
           PERFORM  4200-VALIDATE-CLASS
               THRU 4200-VALIDATE-CLASS-X.
           IF  NOT WEDIT-IO-OK
               MOVE  '1'              TO WS-ERROR-SW
557660     END-IF.

      *
      *    CHECK AGENT & PLAN HEADER FILE TO ENSURE 'TYPE'
      *    ENTERED IS VALID
      *
028786*    MOVE MIR-LIC-ID            TO WAG-AGT-ID.
028786*    PERFORM  AG-1000-READ
028786*        THRU AG-1000-READ-X.
028786*
028786*    IF  NOT WAG-IO-OK
028786*        MOVE MIR-LIC-ID         TO WPH-PLAN-ID
028786*        PERFORM  PH-1000-READ
028786*            THRU PH-1000-READ-X
028786*        IF  NOT WPH-IO-OK
028786*            MOVE 'CS08410005'   TO WGLOB-MSG-REF-INFO
028786*            PERFORM  0260-1000-GENERATE-MESSAGE
028786*                THRU 0260-1000-GENERATE-MESSAGE-X
028786*            IF  WGLOB-MSG-SEVRTY-WARNING
028786*                NEXT SENTENCE
028786*            ELSE
028786*                MOVE  '1'       TO WS-ERROR-SW
028786*            END-IF
028786*        END-IF
028786*    END-IF.
028786
028786     MOVE MIR-DV-LIC-TYP-CD      TO WS-DV-LIC-TYP-CD.
028786     EVALUATE TRUE
028786         WHEN WS-DV-LIC-TYP-PLAN
028786             MOVE MIR-LIC-ID     TO WPH-PLAN-ID
028786             PERFORM  PH-1000-READ
028786                 THRU PH-1000-READ-X
028786             IF  NOT WPH-IO-OK
028786                 MOVE 'CS08410005'
028786                                 TO WGLOB-MSG-REF-INFO
028786                 PERFORM  0260-1000-GENERATE-MESSAGE
028786                     THRU 0260-1000-GENERATE-MESSAGE-X
028786                 IF  WGLOB-MSG-SEVRTY-WARNING
028786                     CONTINUE
028786                 ELSE
028786                     MOVE  '1'   TO WS-ERROR-SW
028786                 END-IF
028786             END-IF
028786         WHEN WS-DV-LIC-TYP-AGENT
028786             PERFORM  0083-0000-INIT-PARM-INFO
028786                 THRU 0083-0000-INIT-PARM-INFO-X
028786             PERFORM  0083-2000-LOCATE-AGT-INFO
028786                 THRU 0083-2000-LOCATE-AGT-INFO-X
028786             IF  L0083-AGT-SYS-EXTERNAL-NO
028786                 MOVE MIR-LIC-ID TO L0083-AGT-ID (1)
028786                 PERFORM  0083-1000-RETRIEVE-AGT-INFO
028786                     THRU 0083-1000-RETRIEVE-AGT-INFO-X
028786                 IF  NOT L0083-AGT-FOUND (1)
028786* MSG: VALID AGENT ID MUST BE ENTERED
028786                     MOVE 'CS08410012'  TO WGLOB-MSG-REF-INFO
028786                     PERFORM  0260-1000-GENERATE-MESSAGE
028786                         THRU 0260-1000-GENERATE-MESSAGE-X
028786                     MOVE  '1'      TO WS-ERROR-SW
028786                 END-IF
028786             ELSE
028786* MSG: INVALID REQUEST
028786                 MOVE 'CS08410011'  TO WGLOB-MSG-REF-INFO
028786                 PERFORM  0260-1000-GENERATE-MESSAGE
028786                     THRU 0260-1000-GENERATE-MESSAGE-X
028786                 MOVE  '1'          TO WS-ERROR-SW
028786             END-IF
028786         WHEN OTHER
028786* MSG: INVALID REQUEST
028786             MOVE 'CS08410011'      TO WGLOB-MSG-REF-INFO
028786             PERFORM  0260-1000-GENERATE-MESSAGE
028786                 THRU 0260-1000-GENERATE-MESSAGE-X
028786             MOVE  '1'              TO WS-ERROR-SW
028786     END-EVALUATE.

           IF  WS-ERROR-SW = ZERO
               PERFORM  4500-CREATE-NEW-ENTRY
                   THRU 4500-CREATE-NEW-ENTRY-X
           ELSE
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.

      *------------------
       4100-VALIDATE-LOC.
      *------------------

      *
      *     CHECK EDIT TABLE TO ENSURE 'LOCATION' ENTERED IS VALID
      *

006002*    MOVE MIR-LIC-LOC-CD        TO WEDIT-ETBL-VALU-ID.
006002*    PERFORM  ILOC-1000-EDIT-ISSU-LOCATION
006002*        THRU ILOC-1000-EDIT-ISSU-LOCATION-X.
006002*    IF  NOT WEDIT-IO-OK
006002*        MOVE 'XS00000065'      TO WGLOB-MSG-REF-INFO
006002*        PERFORM  0260-1000-GENERATE-MESSAGE
006002*            THRU 0260-1000-GENERATE-MESSAGE-X
006002*        IF  WGLOB-MSG-SEVRTY-WARNING
006002*            NEXT SENTENCE
006002*        ELSE
006002*            GO TO 4100-VALIDATE-LOC-X
006002*        END-IF
006002*    END-IF.

006002     MOVE MIR-LIC-LOC-CD        TO WEDIT-ETBL-VALU-ID.
006002     PERFORM  ILOC-2000-DESC
006002         THRU ILOC-2000-DESC-X.

       4100-VALIDATE-LOC-X.
           EXIT.

      *--------------------
       4200-VALIDATE-CLASS.
      *--------------------

      *
      *    CHECK EDIT TABLE TO ENSURE 'CLASS' ENTERED IS VALID
      *

           MOVE MIR-LIC-BUS-CLAS-CD   TO WEDIT-ETBL-VALU-ID.
           PERFORM  CLAS-1000-EDIT-CLASS
               THRU CLAS-1000-EDIT-CLASS-X.
           IF  NOT WEDIT-IO-OK
               MOVE 'CS08410008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   GO TO 4200-VALIDATE-CLASS-X
557660         END-IF
557660     END-IF.

       4200-VALIDATE-CLASS-X.
           EXIT.

      *----------------------
       4500-CREATE-NEW-ENTRY.
      *----------------------

      *
      *    PREPARE TO CREATE NEW ENTRY IN LICENCE TABLE
      *
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  LI-1000-CREATE
               THRU LI-1000-CREATE-X.

           PERFORM  LI-1000-WRITE
               THRU LI-1000-WRITE-X.

014221     PERFORM  LI-1000-READ-TWRK-TS
014221         THRU LI-1000-READ-TWRK-TS-X.

           MOVE MIR-LIC-ID            TO MIR-LIC-ID-T (01).
           MOVE MIR-LIC-LOC-CD        TO MIR-LIC-LOC-CD-T (01).
           MOVE MIR-LIC-BUS-CLAS-CD   TO MIR-LIC-BUS-CLAS-CD-T (01).
           MOVE SPACES                TO MIR-LIC-EFF-DT-T (01).
           MOVE SPACES                TO MIR-LIC-XPRY-DT-T (01).
           MOVE SPACES                TO MIR-LIC-DESC-TXT-T (01).

       4500-CREATE-NEW-ENTRY-X.
           EXIT.

      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM  5200-PROCESS-UPDATE
               THRU 5200-PROCESS-UPDATE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.

      *--------------------
       5200-PROCESS-UPDATE.
      *--------------------

014221*    PERFORM  LI-1000-READ-FOR-UPDATE
014221*        THRU LI-1000-READ-FOR-UPDATE-X.

014221     PERFORM  LI-2000-UPDATE-TWRK-TS
014221         THRU LI-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'LI'              TO WGLOB-MSG-PARM (01)
014221         MOVE WLI-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5200-PROCESS-UPDATE-X
014221     END-IF.
      *
      *    LICENCE RECORD NOT FOUND FOR MAINTENANCE
      *
           IF  WLI-IO-NOT-FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE  WLI-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   GO TO 5200-PROCESS-UPDATE-X
557660         END-IF
557660     END-IF.

      *
      *    USING AN ASSUMPTION THAT AN EDIT MAY FAIL
      *

      *
      *    VALIDATE EFFECTIVE DATE
      *
            PERFORM  5210-EFFECTIVE-DATE-EDIT
                THRU 5210-EFFECTIVE-DATE-EDIT-X.

      *
      *    VALIDATE EXPIRY DATE
      *
            PERFORM  5220-EXPIRY-DATE-EDIT
                THRU 5220-EXPIRY-DATE-EDIT-X.

      *
      *    CROSS-CHECK EFFECTIVE AND EXPIRY DATES
      *    CHECK EXPIRY DATE TO BE GREATER THAN EFFECTIVE DATE
      *
            PERFORM  5230-DATE-CROSS-EDIT
                THRU 5230-DATE-CROSS-EDIT-X.

      *
      *    CHECK FOR EMPTY DATE(S)
      *    GIVE A WARNING IF EITHER DATE IS ZEROES
      *
            PERFORM  5240-UNKEYED-DATES-EDIT
                THRU 5240-UNKEYED-DATES-EDIT-X.

      *
      *    VALIDATE DESCRIPTION
      *
            PERFORM  5250-DESCRIPTION-EDIT
                THRU 5250-DESCRIPTION-EDIT-X.

      *
      *    RE-DISPLAY THE UN-ENTERED DATA
      *
           MOVE RLI-LIC-ID            TO MIR-LIC-ID-T (01).
           MOVE RLI-LIC-LOC-CD        TO MIR-LIC-LOC-CD-T (01).
           MOVE RLI-LIC-BUS-CLAS-CD   TO MIR-LIC-BUS-CLAS-CD-T (01).

           PERFORM  LI-2000-REWRITE
               THRU LI-2000-REWRITE-X.

014221     PERFORM  LI-1000-READ-TWRK-TS
014221         THRU LI-1000-READ-TWRK-TS-X.

           IF  WS-ERROR-SW  =  '1'
               GO TO 5200-PROCESS-UPDATE-X
557660     END-IF.

      *
      *    AUTO. POP OF THE PROCESS CONTROL LIST IS TURNED OFF
      *

           MOVE 'XS00000007'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5200-PROCESS-UPDATE-X.
           EXIT.

      *-------------------------
       5210-EFFECTIVE-DATE-EDIT.
      *-------------------------

           IF  MIR-LIC-EFF-DT-T (01) = SPACES
               IF  RLI-LIC-EFF-DT = WWKDT-ZERO-DT
                   MOVE SPACES        TO MIR-LIC-EFF-DT-T (01)
                   GO TO 5210-EFFECTIVE-DATE-EDIT-X
               ELSE
                   MOVE RLI-LIC-EFF-DT TO L1640-INTERNAL-DATE
020462*            PERFORM 1640-2000-INTERNAL-TO-EXT
020462*               THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM 1640-8000-INTERNAL-TO-MIR
020462                THRU 1640-8000-INTERNAL-TO-MIR-X

                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LIC-EFF-DT-T (01)
                   GO TO 5210-EFFECTIVE-DATE-EDIT-X
557660         END-IF
           ELSE
               IF  MIR-LIC-EFF-DT-T (01) = EBLCH-BLANK-FIELD-CHAR
                   MOVE WWKDT-ZERO-DT TO RLI-LIC-EFF-DT
                   MOVE SPACES        TO MIR-LIC-EFF-DT-T (01)
                   GO TO 5210-EFFECTIVE-DATE-EDIT-X
557660         END-IF
557660     END-IF.

           MOVE MIR-LIC-EFF-DT-T (01) TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               MOVE '1'               TO WS-ERROR-SW
               MOVE MIR-LIC-EFF-DT-T (01)
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'CS08410003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
034802*        IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802*        ELSE
034802*            NEXT SENTENCE
034802*        END-IF
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO RLI-LIC-EFF-DT
557660     END-IF.

       5210-EFFECTIVE-DATE-EDIT-X.
           EXIT.

      *----------------------
       5220-EXPIRY-DATE-EDIT.
      *----------------------

           IF  MIR-LIC-XPRY-DT-T (01) = SPACES
               IF  RLI-LIC-XPRY-DT = WWKDT-ZERO-DT
                   MOVE SPACES         TO MIR-LIC-XPRY-DT-T (01)
                   GO TO 5220-EXPIRY-DATE-EDIT-X
               ELSE
                   MOVE RLI-LIC-XPRY-DT
                                       TO L1640-INTERNAL-DATE
020462*            PERFORM 1640-2000-INTERNAL-TO-EXT
020462*               THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM 1640-8000-INTERNAL-TO-MIR
020462                THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                       TO MIR-LIC-XPRY-DT-T (01)
                   GO TO 5220-EXPIRY-DATE-EDIT-X
557660         END-IF
           ELSE
               IF  MIR-LIC-XPRY-DT-T (01) = EBLCH-BLANK-FIELD-CHAR
                   MOVE WWKDT-ZERO-DT  TO RLI-LIC-XPRY-DT
                   MOVE SPACES         TO MIR-LIC-XPRY-DT-T (01)
                   GO TO 5220-EXPIRY-DATE-EDIT-X
557660         END-IF
557660     END-IF.

           MOVE MIR-LIC-XPRY-DT-T (01) TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               MOVE '1'                TO WS-ERROR-SW
               MOVE MIR-LIC-XPRY-DT-T (01)
                                       TO WGLOB-MSG-PARM (1)
               MOVE 'CS08410003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
034802*        IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802*        ELSE
034802*            NEXT SENTENCE
034802*        END-IF
           ELSE
               MOVE L1640-INTERNAL-DATE
                                       TO RLI-LIC-XPRY-DT
557660     END-IF.

       5220-EXPIRY-DATE-EDIT-X.
            EXIT.

      *---------------------
       5230-DATE-CROSS-EDIT.
      *---------------------

           IF  RLI-LIC-XPRY-DT > WWKDT-ZERO-DT
           AND RLI-LIC-XPRY-DT < RLI-LIC-EFF-DT
               MOVE '1'          TO WS-ERROR-SW
               MOVE 'CS08410009' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5230-DATE-CROSS-EDIT-X.
           EXIT.

      *------------------------
       5240-UNKEYED-DATES-EDIT.
      *------------------------

           IF  RLI-LIC-EFF-DT  = WWKDT-ZERO-DT
           OR  RLI-LIC-XPRY-DT = WWKDT-ZERO-DT
               MOVE 'CS08410010' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
034802*        IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802*        ELSE
034802*            NEXT SENTENCE
034802*        END-IF
557660     END-IF.

       5240-UNKEYED-DATES-EDIT-X.
           EXIT.

      *----------------------
       5250-DESCRIPTION-EDIT.
      *----------------------

           IF  MIR-LIC-DESC-TXT-T (01) = SPACES
               MOVE RLI-LIC-DESC-TXT  TO MIR-LIC-DESC-TXT-T (01)
               GO TO 5250-DESCRIPTION-EDIT-X
           ELSE
               IF  MIR-LIC-DESC-TXT-T (01) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO RLI-LIC-DESC-TXT
                   MOVE SPACES        TO MIR-LIC-DESC-TXT-T (01)
                   GO TO 5250-DESCRIPTION-EDIT-X
               ELSE
                   MOVE MIR-LIC-DESC-TXT-T (01)
                                      TO RLI-LIC-DESC-TXT
557660         END-IF
557660     END-IF.

       5250-DESCRIPTION-EDIT-X.
           EXIT.

      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           PERFORM  6200-PROCESS-DELETE
               THRU 6200-PROCESS-DELETE-X.

       6000-PROCESS-DELETE-X.
           EXIT.

      *--------------------
       6200-PROCESS-DELETE.
      *--------------------

014221*    PERFORM  LI-1000-READ-FOR-UPDATE
014221*        THRU LI-1000-READ-FOR-UPDATE-X.

014221     PERFORM  LI-2000-UPDATE-TWRK-TS
014221         THRU LI-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'LI'              TO WGLOB-MSG-PARM (01)
014221         MOVE WLI-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6200-PROCESS-DELETE-X
014221     END-IF.
      *
      *    LICENCE RECORD FOUND FOR DELETION
      *
           IF  WLI-IO-OK
               PERFORM  LI-1000-DELETE
                   THRU LI-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

      *
      *  LICENCE RECORD NOT FOUND FOR DELETION
      *
           ELSE
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WLI-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       6200-PROCESS-DELETE-X.
           EXIT.

      *---------------------
       9300-BLANK-TO-BOTTOM.
      *---------------------

           MOVE SPACES         TO MIR-LIC-ID-T (WS-L-SUB).
           MOVE SPACES         TO MIR-LIC-LOC-CD-T (WS-L-SUB).
           MOVE SPACES         TO MIR-LIC-BUS-CLAS-CD-T (WS-L-SUB).
           MOVE SPACES         TO MIR-LIC-EFF-DT-T (WS-L-SUB).
           MOVE SPACES         TO MIR-LIC-XPRY-DT-T (WS-L-SUB).
           MOVE SPACES         TO MIR-LIC-DESC-TXT-T (WS-L-SUB).

       9300-BLANK-TO-BOTTOM-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
028786     PERFORM  0083-0000-INIT-PARM-INFO
028786         THRU 0083-0000-INIT-PARM-INFO-X.
028786
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PROGRAM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK          TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *
      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPEILOC.

       COPY CCPECLAS.
      *
028786 COPY CCPS0083.
028786 COPY CCPL0083.
028786*
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
      *
      *****************************************************************
      *  MESSAGE PROCESSING COPYBOOKS
      *****************************************************************
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      *****************************************************************
      *  HOUSEKEEPING PROCESS MODULES
      *****************************************************************
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY LI
014221                         '$VAR2' BY 'LI'.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  FILE I/O AND OTHER FILE RELATED PROCESS MODULES
      *****************************************************************
      *
       COPY CCPNEDIT.
      *
028786*COPY CCPNAG.

       COPY CCPCLI.
      *
       COPY CCPALI.

       COPY CCPBLI.
      *
       COPY CCPNLI.
      *
       COPY CCPULI.
      *
       COPY CCPXLI.
      *
       COPY CCPNPH.
016537*COPY XCPNCTLC.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0841                     **
      *****************************************************************
