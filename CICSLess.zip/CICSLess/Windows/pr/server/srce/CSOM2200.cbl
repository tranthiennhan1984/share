      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2200.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2200                                         **
      **  REMARKS:  FUNCTION PROCESS DRIVER FOR CLIENT SEARCH        **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013578**  6.0       ADD BLANK FIELD SUPPORT FOR MIR-CLI-SEX-CD       **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       NEW FOR RELEASE OF INGENIUM 6.0                  **
015620**  6.0       ADD SUPPORT FOR TAX ID SEARCH                    **
019143**  6.0       AMEND/DISPLAY CLIENT CONTACT INFORMATION (6.1.2J)**
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017336**  6.2       CHECK FOR BLANK CHARACTER ON LOCATION CODE       **
016103**  6.3       JAPANESE SEARCH ENHANCEMENTS (6.1.2J)            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019153**  6.3       ADD JP ADDRESS CODE                              **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015703**  6.4       REMOVE CCWLPGA                                   **
017134**  6.4       PROCEED TO NEXT PAGE FOR ACTION MORE             **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2200'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.

028298 COPY CCWL2626.
       COPY XCWLDTLK.

014590*COPY XCWL0030.

       COPY XCWL1640.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                        PIC X(04).
               88  WS-BUS-FCN-CLI-SRCH              VALUE '2200'.
016548*    05  WS-SUB                               PIC 9(04) COMP SYNC.
016548     05  WS-SUB                               PIC 9(04)
016548                                              BINARY SYNC.
016548*    05  WS-START-SUB                         PIC 9(04) COMP SYNC.
016548     05  WS-START-SUB                         PIC 9(04)
016548                                              BINARY SYNC.
016548*    05  WS-INFO-SEQ                          PIC 9(04) COMP SYNC.
016548     05  WS-INFO-SEQ                          PIC 9(04)
016548                                              BINARY SYNC.
           05  WS-TEMP-HOLD-AREA                    PIC X(25).
           05  WS-DISPLAY-PIC-99                    PIC 9(02).
025970*    05  WS-LAST                              PIC 9(03) VALUE 50.

025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-LAST                              PIC 9(03).  
025970         88  WS-LAST-DEFAULT                  VALUE 50. 

      *
       COPY NCWL5700.
      *
013578 COPY XCWEBLCH.
013578
       COPY CCFWPSYS.

       COPY CCFRPSYS.
      *
015703*COPY CCWLPGA.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2200.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      *
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------


           SET MIR-RETRN-OK             TO TRUE.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CLI-SRCH
                    PERFORM  3000-PROCESS-LIST
                        THRU 3000-PROCESS-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2200'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'      TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      *
      *------------------
       3000-PROCESS-LIST.
      *------------------

           SET WPSYS-SYS-CTL-INGENIUM    TO TRUE.

           PERFORM  PSYS-1000-READ
               THRU PSYS-1000-READ-X.

           IF WPSYS-IO-NOT-FOUND
               MOVE 'CS22000002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 3000-PROCESS-LIST-X
           END-IF.

           IF   MIR-DV-SUR-NM-SRCH-CD = SPACE
                MOVE 'E'                 TO MIR-DV-SUR-NM-SRCH-CD
           END-IF.

           IF   MIR-DV-GIV-NM-SRCH-CD = SPACE
                MOVE 'E'                 TO MIR-DV-GIV-NM-SRCH-CD
           END-IF.

013578     IF  MIR-CLI-SEX-CD = EBLCH-BLANK-FIELD-CHAR
013578         MOVE SPACE                TO MIR-CLI-SEX-CD
013578     END-IF.
013578
017336     IF  MIR-CLI-CRNT-LOC-CD = EBLCH-BLANK-FIELD-CHAR
017336         MOVE SPACE                TO MIR-CLI-CRNT-LOC-CD
017336     END-IF.
017336

016103     MOVE MIR-CLI-ID               TO L5700-CLI-ID.
           MOVE MIR-DV-CLI-NM-SRCH-IND   TO L5700-SUR-GIV-FLIP-SW.
           MOVE MIR-DV-SUR-NM-SRCH-CD    TO L5700-SURNM-PHON-EXACT-CD.
           MOVE MIR-DV-GIV-NM-SRCH-CD    TO L5700-GIVNM-PHON-EXACT-CD.
015904*    MOVE MIR-CLI-ENTR-CO-NM       TO L5700-CLI-ENTR-CO-NM.
015904     MOVE MIR-CLI-CO-ENTR-NM       TO L5700-CLI-ENTR-CO-NM.
015904*    MOVE MIR-CLI-ENTR-GIV-NM      TO L5700-CLI-GIV-NM.
015904     MOVE MIR-ENTR-GIV-NM      TO L5700-CLI-GIV-NM.
015904*    MOVE MIR-CLI-ENTR-SUR-NM      TO L5700-CLI-SUR-NM.
015904     MOVE MIR-ENTR-SUR-NM      TO L5700-CLI-SUR-NM.
           MOVE MIR-CLI-BTH-DT           TO L5700-CLI-BTH-DT.
           MOVE MIR-CLI-SEX-CD           TO L5700-CLI-SEX-CD.
015904*    MOVE MIR-CLI-MID-INIT-NM      TO L5700-CLI-MID-INIT-NM.
015904     MOVE MIR-CLI-INDV-MID-NM      TO L5700-CLI-MID-INIT-NM.
           MOVE MIR-CLI-PSTL-CD          TO L5700-CLI-PSTL-CD.
           MOVE MIR-CLI-CRNT-LOC-CD      TO L5700-CLI-CRNT-LOC-CD.
           MOVE MIR-CLI-TAX-ID           TO L5700-CLI-TAX-ID.
018763     MOVE MIR-CLI-ALT-ADDR-CD      TO L5700-CLI-ALT-ADDR-CD.
016103     MOVE MIR-CLI-CITY-NM-TXT      TO L5700-CLI-CITY-NM-TXT.

018732*    IF NOT WGLOB-COUNTRY-JAPAN
018732*        SET MIR-DV-SRCH-GR-ALPHA     TO TRUE
018732*    ELSE
018732*        IF  MIR-DV-SRCH-GR-ALPHA
018732*            SET MIR-DV-SRCH-GR-KANJI TO TRUE
018732*        END-IF
018732*    END-IF.
018732*    MOVE MIR-DV-SRCH-GR-CD        TO L5700-SRCH-GR-CD.
018732     MOVE MIR-CLI-INDV-GR-CD       TO L5700-SRCH-GR-CD.

           MOVE ZEROS                    TO L5700-LAST-REC-SEQ-NUM.

           PERFORM  4100-INIT-LIST-SCREEN
               THRU 4100-INIT-LIST-SCREEN-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > RPSYS-MAX-CLI-SRCH-QTY.

           MOVE RPSYS-MAX-CLI-SRCH-QTY   TO L5700-MAX-CLI-SRCH-QTY.

           PERFORM  5700-1000-PROCESS-SEARCH
               THRU 5700-1000-PROCESS-SEARCH-X.

           PERFORM  3100-EDIT-AREA-TO-MIR
               THRU 3100-EDIT-AREA-TO-MIR-X.

           MOVE 1                         TO  WS-START-SUB.

           IF  NOT L5700-RETRN-OK
           AND NOT L5700-RETRN-NONE-FOUND
               IF  L5700-RETRN-EDIT-ERROR
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
               ELSE
                   SET MIR-RETRN-RQST-FAILED TO TRUE
               END-IF
               GO TO 3000-PROCESS-LIST-X
           ELSE
               PERFORM  4000-LIST
                   THRU 4000-LIST-X
           END-IF.
      *
      *   SWITCH THE FIRST AND LAST NAMES AND
      *   SEARCH AGAIN
      *
           IF  MIR-DV-CLI-NM-SRCH-IND = 'Y'
015904*    AND MIR-CLI-ENTR-GIV-NM NOT = SPACES
015904     AND MIR-ENTR-GIV-NM NOT = SPACES
           AND L5700-SRCH-TYP-PERSON
           AND NOT L5700-LIST-FULL
015904*        MOVE MIR-CLI-ENTR-GIV-NM  TO WS-TEMP-HOLD-AREA
015904         MOVE MIR-ENTR-GIV-NM  TO WS-TEMP-HOLD-AREA
015904*        MOVE MIR-CLI-ENTR-SUR-NM  TO L5700-CLI-GIV-NM
015904         MOVE MIR-ENTR-SUR-NM  TO L5700-CLI-GIV-NM
               MOVE WS-TEMP-HOLD-AREA    TO L5700-CLI-SUR-NM
               COMPUTE L5700-MAX-CLI-SRCH-QTY =
                       RPSYS-MAX-CLI-SRCH-QTY - WS-START-SUB + 1
               PERFORM  5700-1000-PROCESS-SEARCH
                   THRU 5700-1000-PROCESS-SEARCH-X
               IF  L5700-RETRN-OK
                   PERFORM  4000-LIST
                       THRU 4000-LIST-X
               END-IF
           END-IF.

           SUBTRACT 1                  FROM  WS-START-SUB.
           MOVE WS-START-SUB             TO  WS-DISPLAY-PIC-99.
           MOVE WS-DISPLAY-PIC-99        TO  MIR-DV-CLI-SRCH-QTY.

           IF WS-START-SUB = ZERO
      *MSG:    NO POSSIBLE MATCHES FOUND
               MOVE 'CS22000003'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-LIST-X
           END-IF.

           IF  L5700-LIST-FULL
      *MSG:    THERE ARE MORE THAN @1 MATCHES, @1 ARE DISPLAYED
               MOVE RPSYS-MAX-CLI-SRCH-QTY TO WS-DISPLAY-PIC-99
               MOVE WS-DISPLAY-PIC-99    TO WGLOB-MSG-PARM (1)
               MOVE 'CS22000004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
017134         MOVE MIR-CLI-ID-T (WS-LAST)
017134                                   TO MIR-CLI-ID
017134         MOVE MIR-ENTR-SUR-NM-T (WS-LAST)
017134                                   TO MIR-ENTR-SUR-NM
017134         MOVE MIR-ENTR-GIV-NM-T (WS-LAST)
017134                                   TO MIR-ENTR-GIV-NM
017134         MOVE MIR-CLI-CO-ENTR-NM-T (WS-LAST)
017134                                   TO MIR-CLI-CO-ENTR-NM
           END-IF.

       3000-PROCESS-LIST-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE DATA RETURNED FROM EDIT TO MIR AREA
      *****************************************************************
      *----------------------
       3100-EDIT-AREA-TO-MIR.
      *----------------------

           IF  L5700-SUR-GIV-FLIP-SW NOT = HIGH-VALUES
               MOVE L5700-SUR-GIV-FLIP-SW    TO MIR-DV-CLI-NM-SRCH-IND
           END-IF.

           IF  L5700-SURNM-PHON-EXACT-CD NOT = HIGH-VALUES
               MOVE L5700-SURNM-PHON-EXACT-CD TO MIR-DV-SUR-NM-SRCH-CD
           END-IF.

           IF  L5700-GIVNM-PHON-EXACT-CD NOT = HIGH-VALUES
               MOVE L5700-GIVNM-PHON-EXACT-CD TO MIR-DV-GIV-NM-SRCH-CD
           END-IF.

           IF  L5700-CLI-ENTR-CO-NM NOT = HIGH-VALUES
015904*        MOVE L5700-CLI-ENTR-CO-NM     TO MIR-CLI-ENTR-CO-NM
015904         MOVE L5700-CLI-ENTR-CO-NM     TO MIR-CLI-CO-ENTR-NM
           END-IF.

           IF  L5700-CLI-GIV-NM NOT = HIGH-VALUES
015904*        MOVE L5700-CLI-GIV-NM         TO MIR-CLI-ENTR-GIV-NM
015904         MOVE L5700-CLI-GIV-NM         TO MIR-ENTR-GIV-NM
           END-IF.

           IF  L5700-CLI-SUR-NM NOT = HIGH-VALUES
015904*        MOVE L5700-CLI-SUR-NM         TO MIR-CLI-ENTR-SUR-NM
015904         MOVE L5700-CLI-SUR-NM         TO MIR-ENTR-SUR-NM
           END-IF.

           IF  L5700-CLI-TAX-ID NOT = HIGH-VALUES
               MOVE L5700-CLI-TAX-ID         TO MIR-CLI-TAX-ID
           END-IF.

           IF  L5700-CLI-BTH-DT NOT = HIGH-VALUES
               MOVE L5700-CLI-BTH-DT         TO MIR-CLI-BTH-DT
           END-IF.

           IF  L5700-CLI-SEX-CD NOT = HIGH-VALUES
               MOVE L5700-CLI-SEX-CD         TO MIR-CLI-SEX-CD
           END-IF.

           IF  L5700-CLI-MID-INIT-NM NOT = HIGH-VALUES
015904*        MOVE L5700-CLI-MID-INIT-NM    TO MIR-CLI-MID-INIT-NM
015904         MOVE L5700-CLI-MID-INIT-NM    TO MIR-CLI-INDV-MID-NM
           END-IF.

           IF  L5700-CLI-PSTL-CD NOT = HIGH-VALUES
               MOVE L5700-CLI-PSTL-CD        TO MIR-CLI-PSTL-CD
           END-IF.

           IF  L5700-CLI-CRNT-LOC-CD NOT = HIGH-VALUES
               MOVE L5700-CLI-CRNT-LOC-CD    TO MIR-CLI-CRNT-LOC-CD
           END-IF.


       3100-EDIT-AREA-TO-MIR-X.
           EXIT.
      *
      *----------
       4000-LIST.
      *----------

           IF  L5700-LAST-REC-SEQ-NUM = 0
               GO TO 4000-LIST-X
           END-IF.

           MOVE +1                    TO WS-INFO-SEQ.

016103     MOVE L5700-CLI-ID          TO MIR-CLI-ID.

           PERFORM  4200-LOAD-LIST-SCREEN
               THRU 4200-LOAD-LIST-SCREEN-X
               VARYING WS-SUB FROM WS-START-SUB BY 1
               UNTIL WS-SUB > RPSYS-MAX-CLI-SRCH-QTY
               OR  WS-INFO-SEQ > L5700-LAST-REC-SEQ-NUM.

           MOVE WS-SUB                  TO WS-START-SUB.

       4000-LIST-X.
           EXIT.
      *
      *----------------------
       4100-INIT-LIST-SCREEN.
      *----------------------

           MOVE SPACES        TO MIR-DV-SRCH-CLI-NM-T    (WS-SUB).
015904*    MOVE SPACES        TO MIR-CLI-ENTR-SUR-NM-T   (WS-SUB).
015904     MOVE SPACES        TO MIR-ENTR-SUR-NM-T   (WS-SUB).
015904*    MOVE SPACES        TO MIR-CLI-ENTR-GIV-NM-T   (WS-SUB).
015904     MOVE SPACES        TO MIR-ENTR-GIV-NM-T   (WS-SUB).
015904*    MOVE SPACES        TO MIR-CLI-ENTR-CO-NM-T    (WS-SUB).
015904     MOVE SPACES        TO MIR-CLI-CO-ENTR-NM-T    (WS-SUB).
015904*    MOVE SPACES        TO MIR-CLI-MID-INIT-NM-T   (WS-SUB).
015904     MOVE SPACES        TO MIR-CLI-INDV-MID-NM-T   (WS-SUB).
           MOVE SPACES        TO MIR-DV-CLI-PREV-NM-IND-T (WS-SUB).
           MOVE SPACES        TO MIR-CLI-BTH-DT-T        (WS-SUB).
           MOVE SPACES        TO MIR-CLI-SEX-CD-T        (WS-SUB).
           MOVE SPACES        TO MIR-CLI-ID-T            (WS-SUB).
           MOVE SPACES        TO MIR-CLI-ADDR-LN-1-TXT-T (WS-SUB).
           MOVE SPACES        TO MIR-CLI-PSTL-CD-T       (WS-SUB).
           MOVE SPACES        TO MIR-CLI-CRNT-LOC-CD-T   (WS-SUB).
018763     MOVE SPACES        TO MIR-CLI-ALT-ADDR-CD-T   (WS-SUB).
           MOVE SPACES        TO MIR-CLI-ADDR-STAT-CD-T  (WS-SUB).
           MOVE SPACES        TO MIR-CLI-TAX-ID-T        (WS-SUB).
016103     MOVE SPACES        TO MIR-CLI-CITY-NM-TXT-T   (WS-SUB).

       4100-INIT-LIST-SCREEN-X.
           EXIT.
      *
      *----------------------
       4200-LOAD-LIST-SCREEN.
      *----------------------

           MOVE L5700-CLI-SUR-NM-T (WS-INFO-SEQ)
015904*      TO MIR-CLI-ENTR-SUR-NM-T (WS-SUB).
015904       TO MIR-ENTR-SUR-NM-T (WS-SUB).

           MOVE L5700-CLI-GIV-NM-T (WS-INFO-SEQ)
015904*      TO MIR-CLI-ENTR-GIV-NM-T (WS-SUB).
015904       TO MIR-ENTR-GIV-NM-T (WS-SUB).

           MOVE L5700-CLI-CO-NM-T (WS-INFO-SEQ)
015904*      TO MIR-CLI-ENTR-CO-NM-T (WS-SUB).
015904       TO MIR-CLI-CO-ENTR-NM-T (WS-SUB).

           MOVE L5700-CLI-ENTR-NM-T (WS-INFO-SEQ)
             TO MIR-DV-SRCH-CLI-NM-T (WS-SUB).

           MOVE L5700-CLI-MID-INIT-T (WS-INFO-SEQ)
015904*      TO MIR-CLI-MID-INIT-NM-T (WS-SUB).
015904       TO MIR-CLI-INDV-MID-NM-T (WS-SUB).

           MOVE L5700-CLI-AKA-IND-T (WS-INFO-SEQ)
             TO MIR-DV-CLI-PREV-NM-IND-T (WS-SUB).

           MOVE L5700-CLI-BTH-DT-T (WS-INFO-SEQ) TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT                                    
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE        TO MIR-CLI-BTH-DT-T (WS-SUB).

           MOVE L5700-CLI-SEX-CD-T (WS-INFO-SEQ)
             TO MIR-CLI-SEX-CD-T (WS-SUB).

           MOVE L5700-CLI-ID-T (WS-INFO-SEQ)
             TO MIR-CLI-ID-T (WS-SUB).

           MOVE L5700-CLI-ADDRESS-TXT-T (WS-INFO-SEQ)
             TO MIR-CLI-ADDR-LN-1-TXT-T (WS-SUB).

           MOVE L5700-CLI-PSTL-CD-T (WS-INFO-SEQ)
             TO MIR-CLI-PSTL-CD-T (WS-SUB).

           MOVE L5700-CLI-CRNT-LOC-CD-T (WS-INFO-SEQ)
             TO MIR-CLI-CRNT-LOC-CD-T (WS-SUB).

018732*    IF WGLOB-COUNTRY-JAPAN
018732     IF MIR-CLI-INDV-GR-KANJI
018732     OR MIR-CLI-INDV-GR-KATAKANA
018763        MOVE L5700-CLI-ALT-ADDR-CD-T (WS-INFO-SEQ)
018763          TO MIR-CLI-ALT-ADDR-CD-T (WS-SUB)
019153     END-IF.

           MOVE L5700-CLI-ADDR-STAT-CD-T (WS-INFO-SEQ)
             TO MIR-CLI-ADDR-STAT-CD-T (WS-SUB).

           MOVE L5700-CLI-TAX-ID-T (WS-INFO-SEQ)
             TO MIR-CLI-TAX-ID-T (WS-SUB).

019143     MOVE L5700-CLI-ADDR-CNTCT-TXT-T (WS-INFO-SEQ)
019143       TO MIR-CLI-ADDR-CNTCT-TXT-T (WS-SUB).

016103     MOVE L5700-CLI-CITY-NM-TXT-T (WS-INFO-SEQ)
016103       TO MIR-CLI-CITY-NM-TXT-T (WS-SUB).

           ADD +1                     TO WS-INFO-SEQ.

       4200-LOAD-LIST-SCREEN-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5700-0000-INIT-PARM-INFO
025970         THRU 5700-0000-INIT-PARM-INFO-X.
025970
025970     SET  WS-LAST-DEFAULT              TO TRUE.
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
018764*COPY NCCL5700.
025970 COPY NCPS5700.
018764 COPY NCPL5700.
016537*COPY NCPS5700.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNPSYS.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM2200                     **
      *****************************************************************
