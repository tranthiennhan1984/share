      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4905.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4905                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE AVAILABLE FUND IDS/DESCRIPTIONS ON A     **
      **            POLICY.                                          **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       ORIGINAL - NEW FOR RELEASE 6.0                   **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4905'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
018764*COPY XCWLPTR.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '4905'.
016548*    05  WS-SUB                                  PIC S9(04) COMP.
016548     05  WS-SUB                                  PIC S9(04)
016548                                                 BINARY.
016548*    05  I                                       PIC S9(04) COMP.
016548     05  I                                       PIC S9(04)
016548                                                 BINARY.
           05  WS-CODE.
               10  WS-COVNO                            PIC X(02).
               10  WS-FUND-ID                          PIC X(07).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
021930*COPY CCFWCVGC.
021930*COPY CCFRCVGC.
021930*
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWLPGA.
      /
       COPY FCWLFUND.
       COPY FCWL8200.
      /
021930*COPY XCWLDTLK.
016537*COPY XCWL0280.
016537*COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4905.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4905'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE MIR-POL-ID                TO WPOL-POL-ID.

           PERFORM POL-1000-READ
              THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               PERFORM CVGS-1000-LOAD-CVGS-ARRAY
                  THRU CVGS-1000-LOAD-CVGS-ARRAY-X
               PERFORM 2100-RETRIEVE-FUNDS
                  THRU 2100-RETRIEVE-FUNDS-X
           ELSE
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
           END-IF.

       2000-LIST-X.
           EXIT.
      /
      *-------------------
       2100-RETRIEVE-FUNDS.
      *-------------------

           PERFORM  8200-1000-BUILD-PARM-INFO
               THRU 8200-1000-BUILD-PARM-INFO-X.

           PERFORM  8200-1000-INIT-INSTR
               THRU 8200-1000-INIT-INSTR-X.

           IF  L8200-RETRN-OK
               PERFORM 2200-PROCESS-FUNDS
                  THRU 2200-PROCESS-FUNDS-X
                  VARYING WS-SUB FROM +1 BY +1
                  UNTIL WS-SUB > LFUND-FND-CTR
           ELSE
      *MSG: 'POLICY FUNDS NOT FOUND'
               MOVE 'CS49050001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
           END-IF.

       2100-RETRIEVE-FUNDS-X.
           EXIT.
      /
      *-------------------
       2200-PROCESS-FUNDS.
      *-------------------

           MOVE LFUND-CVG-NUM (WS-SUB)    TO WS-COVNO.
           MOVE LFUND-FND-ID (WS-SUB)     TO WS-FUND-ID.
           MOVE WS-CODE                   TO MIR-DV-SBOX-CD-T (WS-SUB).

           IF  LFUND-FND-ID (WS-SUB) = SPACES
               MOVE WCVGS-PLAN-ID (WS-SUB)  TO WEDIT-ETBL-VALU-ID
               PERFORM PLAN-2000-DESC
                  THRU PLAN-2000-DESC-X
           ELSE
               MOVE LFUND-FND-ID (WS-SUB)   TO WEDIT-ETBL-VALU-ID
               PERFORM SGFD-2000-DESC
                  THRU SGFD-2000-DESC-X
           END-IF.

           MOVE REDIT-ETBL-DESC-TXT         TO MIR-DV-SBOX-DESC-TXT-T
                                               (WS-SUB).

       2200-PROCESS-FUNDS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES         TO MIR-DV-SBOX-CD-G.
           MOVE SPACES         TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.

           SET  WGLOB-REF-POLICY     TO TRUE.
           MOVE MIR-POL-ID           TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8200-0000-INIT-PARM-INFO
025970         THRU 8200-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970
025970     SET  MIR-RETRN-OK                TO TRUE.
025970
025970     MOVE SPACES                      TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
016537*COPY NCPPCVGR.
      /
       COPY CCPEPLAN.
       COPY CCPESGFD.
      /
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY FCCL8200.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY FCPL8200.
       COPY FCPS8200.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
016537*COPY XCPL0280.
016537*COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.

       COPY CCPNCVG.

016537*COPY CCPUCVG.

016537*COPY CCPBCVGC.
       COPY CCPNEDIT.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4905
      *****************************************************************
