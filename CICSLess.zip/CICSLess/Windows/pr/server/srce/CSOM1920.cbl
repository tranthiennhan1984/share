      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1920.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1920                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE CLNM TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015508**  6.0       NAME ENHANCEMENTS                                **
014221**  6.2       LOGICAL RECORD LOCKING                           **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016548**  6.2       CHANGE COMP TO BINARY                            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1920'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '1920'.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1920'.
016548*    05  WS-GR                         PIC 9(04) COMP SYNC.
016548     05  WS-GR                         PIC 9(04) BINARY SYNC.
016548*    05  WS-MAX-GR        VALUE 2      PIC 9(04) COMP SYNC.
018732*    05  WS-MAX-GR        VALUE 2      PIC 9(04) BINARY SYNC.
025970*    05  WS-MAX-GR        VALUE 3      PIC 9(04) BINARY SYNC.
           05  WS-PIC-999                    PIC 9(3).
               88  WS-PIC-001-003            VALUE 0 THRU 3.
018732     05  WS-CLNM-COUNT                 PIC 9(01).
020478     05  WS-EFF-DT                     PIC X(10).


025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1920'.
025970     05  WS-MAX-GR                     PIC 9(04) BINARY SYNC.
025970         88  WS-MAX-GR-DEFAULT         VALUE 3.


      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCLNM.
       COPY CCFRCLNM.
014221 COPY CCFWCLI.
014221 COPY CCFRCLI.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
020478 COPY CCWL2626.
       COPY XCWL0280.
020874 COPY XCWL0290.
020478 COPY XCWL1640.
014221 COPY XCWL8090.
020478 COPY XCWLDTLK.
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1920.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FCCK-1000-CHECK-CLIENT
020478         THRU FCCK-1000-CHECK-CLIENT-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1920'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

014221     MOVE MIR-CLI-ID       TO  WCLI-CLI-ID.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.
014221     IF NOT WCLI-IO-OK
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'CLI'              TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2000-RETRIEVE-X
014221      END-IF.

018732*    PERFORM  CLNM-1000-READ
018732*        THRU CLNM-1000-READ-X.
018732*
018732*    IF  WCLNM-IO-NOT-FOUND
018732*MSG: RECORD @1 NOT FOUND
018732*        MOVE WCLNM-KEY
018732*          TO WGLOB-MSG-PARM (1)
018732*        MOVE 'XS00000001'
018732*          TO WGLOB-MSG-REF-INFO
018732*        PERFORM  0260-1000-GENERATE-MESSAGE
018732*            THRU 0260-1000-GENERATE-MESSAGE-X
018732*        SET MIR-RETRN-RQST-FAILED
018732*          TO TRUE
018732*        GO TO 2000-RETRIEVE-X
018732*    END-IF.

      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
018732     MOVE ZERO          TO  WS-CLNM-COUNT.
           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X
            VARYING WS-GR FROM 1 BY 1
              UNTIL WS-GR > WS-MAX-GR.

018732     IF  WS-CLNM-COUNT = ZERO
018732*MSG: RECORD @1 NOT FOUND
018732         MOVE WCLNM-KEY
018732           TO WGLOB-MSG-PARM (1)
018732         MOVE 'XS00000001'
018732           TO WGLOB-MSG-REF-INFO
018732         PERFORM  0260-1000-GENERATE-MESSAGE
018732             THRU 0260-1000-GENERATE-MESSAGE-X
018732         SET MIR-RETRN-RQST-FAILED
018732           TO TRUE
018732     END-IF.

       2000-RETRIEVE-X.
           EXIT.

      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

020478*    IF MIR-CLI-INDV-SEQ-NUM = '000'
020478*    OR MIR-CLI-INDV-SEQ-NUM = SPACES
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*        MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*        MOVE 'CS19200001'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        GO TO 2100-VALIDATE-KEYS-X
020478*    END-IF.
020478*
020478*    IF MIR-CLI-INDV-SEQ-NUM NOT = SPACES
020478*        MOVE 'Y'               TO L0280-SPACE-PERMITTED-IND
020478*        MOVE 'N'               TO L0280-SIGN-IND
020478*        MOVE 0                 TO L0280-PRECISION
020478*        MOVE 3                 TO L0280-LENGTH
020478*        MOVE 3                 TO L0280-INPUT-SIZE
020478*        MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO L0280-INPUT-DATA
020478*        PERFORM  0280-1000-NUMERIC-EDIT
020478*            THRU 0280-1000-NUMERIC-EDIT-X
020478*
020478*        IF L0280-OK
020478*            CONTINUE
020478*        ELSE
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*            MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*            MOVE 'CS19200001'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*            GO TO 2100-VALIDATE-KEYS-X
020478*        END-IF
020478*
020478*        MOVE L0280-OUTPUT  TO WS-PIC-999
020478*        MOVE L0280-OUTPUT  TO L0290-INPUT-V00

020478*        IF  WS-PIC-001-003
020874*            MOVE WS-PIC-999    TO MIR-CLI-INDV-SEQ-NUM
020478*            MOVE ZERO          TO L0290-PRECISION
020478*            MOVE LENGTH OF MIR-CLI-INDV-SEQ-NUM
020478*                               TO L0290-MAX-OUT-LEN
020478*            PERFORM 0290-2000-FORMAT-FOR-MIR
020478*               THRU 0290-2000-FORMAT-FOR-MIR-X
020478*            MOVE L0290-OUTPUT-DATA TO MIR-CLI-INDV-SEQ-NUM
020478*        ELSE
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*            MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*            MOVE 'CS19200001'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*            GO TO 2100-VALIDATE-KEYS-X
020478*        END-IF
020478*
020478*    END-IF.

020478     IF  MIR-CLI-INDV-EFF-DT = SPACES
020478         MOVE WGLOB-PROCESS-DATE  TO WS-EFF-DT
020478     ELSE
020478         MOVE MIR-CLI-INDV-EFF-DT
020478                                  TO L1640-EXTERNAL-DATE
020478         PERFORM  1640-7000-MIR-TO-INT
020478             THRU 1640-7000-MIR-TO-INT-X
020478
020478         IF  L1640-NOT-VALID
020478*MSG : INVALID NAME EFFECTIVE DATE
020478             MOVE 'CS19200002'         TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478             GO TO 2100-VALIDATE-KEYS-X
020478         ELSE
020478             MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
020478         END-IF
020478     END-IF.
020478
020478     MOVE WS-EFF-DT          TO L1640-INTERNAL-DATE.
020478     PERFORM  1640-8000-INTERNAL-TO-MIR
020478         THRU 1640-8000-INTERNAL-TO-MIR-X.
020478     MOVE L1640-EXTERNAL-DATE TO MIR-CLI-INDV-EFF-DT.

       2100-VALIDATE-KEYS-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

020478*    MOVE LOW-VALUES                 TO WCLNM-KEY.
020478*    MOVE MIR-CLI-ID                 TO WCLNM-CLI-ID.

018732*    EVALUATE TRUE
018732*
018732*        WHEN WGLOB-COUNTRY-JAPAN
018732*             SET  WCLNM-CLI-INDV-GR-KATAKANA
018732*               TO TRUE
018732*
018732*        WHEN OTHER
018732*             SET  WCLNM-CLI-INDV-GR-ALPHA
018732*               TO TRUE
018732*
018732*    END-EVALUATE.

020478*    SET  WCLNM-CLI-INDV-GR-ALPHA    TO TRUE.
020478*    SET  WCLNM-CLI-INDV-NM-TYP-PREV TO TRUE.
020478*    MOVE MIR-CLI-INDV-SEQ-NUM       TO WCLNM-CLI-INDV-SEQ-NUM.
020478     MOVE MIR-CLI-ID                TO WCLNM-CLI-ID.
020478     MOVE WS-EFF-DT                 TO WCLNM-CLI-INDV-EFF-DT.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES
             TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

018732*    IF  WS-GR > 1
018732*
018732*        IF  WGLOB-COUNTRY-JAPAN
018732*            CONTINUE
018732*        ELSE
018732*            GO TO 9200-MOVE-RECORD-TO-MIR-X
018732*        END-IF
018732*
018732*        SET  WCLNM-CLI-INDV-GR-KANJI    TO TRUE
018732*        PERFORM  CLNM-1000-READ
018732*            THRU CLNM-1000-READ-X
018732*        IF  NOT WCLNM-IO-OK
018732*            GO TO 9200-MOVE-RECORD-TO-MIR-X
018732*        END-IF
018732*
018732*    END-IF.

018732     EVALUATE  WS-GR
018732         WHEN  1
018732             SET WCLNM-CLI-INDV-GR-ALPHA TO TRUE
018732         WHEN  2
018732             SET WCLNM-CLI-INDV-GR-KANJI TO TRUE
018732         WHEN  3
018732             SET WCLNM-CLI-INDV-GR-KATAKANA TO TRUE
018732     END-EVALUATE.
018732
018732     PERFORM  CLNM-1000-READ
018732         THRU CLNM-1000-READ-X.
018732     IF  NOT WCLNM-IO-OK
018732         GO TO 9200-MOVE-RECORD-TO-MIR-X
018732     END-IF.
018732
018732     ADD 1                  TO  WS-CLNM-COUNT
018732     MOVE RCLNM-CLI-INDV-GR-CD TO MIR-CLI-INDV-GR-CD.
018732
018732     EVALUATE TRUE
018732         WHEN RCLNM-CLI-INDV-GR-ALPHA
018732             MOVE 'A'       TO MIR-DV-LANG-GR-DISPLAY-CD
018732         WHEN RCLNM-CLI-INDV-GR-KANJI
018732         WHEN RCLNM-CLI-INDV-GR-KATAKANA
018732             MOVE 'J'       TO MIR-DV-LANG-GR-DISPLAY-CD
018732     END-EVALUATE.

           MOVE RCLNM-ENTR-GIV-NM
015904*      TO MIR-ENTR-GIV-NM-T (WS-GR).
015904       TO MIR-DV-ENTR-GIV-NM-T (WS-GR).

           MOVE RCLNM-CLI-INDV-GIV-NM
             TO MIR-CLI-INDV-GIV-NM-T (WS-GR).

           MOVE RCLNM-ENTR-SUR-NM
015904*      TO MIR-ENTR-SUR-NM-T (WS-GR).
015904       TO MIR-DV-ENTR-SUR-NM-T (WS-GR).

           MOVE RCLNM-CLI-INDV-SUR-NM
             TO MIR-CLI-INDV-SUR-NM-T (WS-GR).

           MOVE RCLNM-CLI-INDV-MID-NM
015904*      TO MIR-CLI-INDV-MID-NM-T (WS-GR).
015904       TO MIR-DV-CLI-INDV-MID-NM-T (WS-GR).

           MOVE RCLNM-CLI-INDV-SFX-NM
015904*      TO MIR-CLI-INDV-SFX-NM-T (WS-GR).
015904       TO MIR-DV-CLI-INDV-SFX-NM-T (WS-GR).

           MOVE RCLNM-CLI-INDV-TITL-TXT
015904*      TO MIR-CLI-INDV-TITL-TXT-T (WS-GR).
015904       TO MIR-DV-CLI-INDV-TITL-TXT-T (WS-GR).


       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT
             TO TRUE.
           MOVE MIR-CLI-ID
             TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
025970
025970     INITIALIZE  WLOCK-TWRK-OTHER-INFO.
025970     SET  WS-MAX-GR-DEFAULT             TO TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT           TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFCCK.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
025970 COPY XCPS8090.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
025970 COPY XCPS1640.
020478 COPY XCPL1640.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCLNM.
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM1920                        **
      *****************************************************************
