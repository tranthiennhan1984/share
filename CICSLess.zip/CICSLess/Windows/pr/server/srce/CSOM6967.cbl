      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM6967.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6967                                         **
      **  REMARKS:  POLI - POLICY INQUIRY SCREEN                     **
      **            THIS MODULE PERFORMS THE POLICY INQUIRY FUNCTION **
      **            FOR US TAX INFORMATION.                          **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       NEW PROCESS DRIVER WITH LOGIC TAKEN FROM         **
      **            CSBM6900 FOR US TAX INQUIRY ONLY                 **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016686**  6.2       PROCESSING DATE CHANGE FOR CONCURRENCY           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
017243**  6.4       REMOVE EXTRA FIELDS FROM POLICY INQUIRY          **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015705**  6.4       NAME FORMATTING                                  **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6967'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
016537*COPY XCWWCVGM.

       01  WS-PGM-WORK-AREA.
           05  WS-SUBD                            PIC 9(03).
           05  WS-FOUND-PRIMARY-SW                PIC X(01).
               88  WS-FOUND-PRIMARY               VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS           VALUE 'N'.

016548*    05  WS-SUB                             PIC S9(04)  COMP.
016548     05  WS-SUB                             PIC S9(04)  BINARY.

           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-BLANK         VALUE SPACES.
               88  WS-BUS-FCN-VALID         VALUE '6967'.
               88  WS-POLI-US-TAX           VALUE '6967'.

           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.

           05  WS-CLIENT-FOUND-SW           PIC X(01).
               88  WS-CLIENT-FOUND          VALUE 'Y'.
               88  WS-NO-CLIENT-FOUND       VALUE 'N'.

017243*    05  WS-SCREEN-DATE               PIC X(10).

           05  WS-CV-DATE                   PIC X(10).

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
      *
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
026057 COPY XCWWWKDT.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
       COPY CCFWPOLC.
       COPY CCFRPOLC.
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************
028298 COPY CCWL2626.
       COPY XCWL0290.

       COPY CCWL0620.
       COPY CCWL2430.
      *
016440 COPY CCWL5400.
       COPY CCWL6967.
      *
       COPY XCWLDTLK.
016537*COPY XCWL0225.
016537*COPY XCWL0280.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM6967.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           INITIALIZE L2430-OUTPUT-PARM-INFO.
           INITIALIZE RPOL-REC-INFO.

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *

      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           SET WS-NO-ERRORS-FOUND      TO TRUE.

           PERFORM  2200-INITIAL-EDITS
               THRU 2200-INITIAL-EDITS-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.

           PERFORM  3000-DISPLAY-SCREEN
               THRU 3000-DISPLAY-SCREEN-X.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *

      *------------------------
       2200-INITIAL-EDITS.
      *------------------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

016686*    MOVE MIR-APPL-CTL-PRCES-DT  TO WS-SCREEN-DATE.
017243*    MOVE MIR-DV-EFF-DT          TO WS-SCREEN-DATE.
016686*    MOVE MIR-APPL-CTL-PRCES-DT  TO WS-CV-DATE
016686     MOVE MIR-DV-EFF-DT          TO WS-CV-DATE

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    POLICY RECORD NOT FOUND (@1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

026057     MOVE MIR-DV-EFF-DT         TO L1640-EXTERNAL-DATE.
026057     PERFORM 1640-7000-MIR-TO-INT
026057        THRU 1640-7000-MIR-TO-INT-X.
026057     IF  L1640-NOT-VALID
026057         SET WS-ERROR-FOUND      TO TRUE
026057*MSG:    'DATE @1 INVALID'
026057         MOVE 'CS69670001'      TO WGLOB-MSG-REF-INFO
026057         MOVE MIR-DV-EFF-DT     TO WGLOB-MSG-PARM (1)
026057         PERFORM  0260-1000-GENERATE-MESSAGE
026057             THRU 0260-1000-GENERATE-MESSAGE-X
026057     ELSE
026057         MOVE L1640-INTERNAL-DATE  TO WS-CV-DATE
026057     END-IF.

016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.

016440     SET L5400-POL-XFER-INQ     TO TRUE.

016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.

016440     IF  L5400-XFER-ACCS-RESTRICTED
016440         SET WS-ERROR-FOUND     TO TRUE
016440     END-IF.

           IF  WS-ERROR-FOUND
               GO TO 2200-INITIAL-EDITS-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CV-DATE               TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WS-ERROR-FOUND      TO TRUE
026057        GO TO 2200-INITIAL-EDITS-X
026057     END-IF.

           PERFORM  2210-READ-ALL-CVG
               THRU 2210-READ-ALL-CVG-X
               VARYING WS-SUBD FROM 1 BY 1
               UNTIL   WS-SUBD > RPOL-POL-CVG-REC-CTR-N
               OR      WS-ERROR-FOUND.

           IF  WS-ERROR-FOUND
               GO TO 2200-INITIAL-EDITS-X
           END-IF.

       2200-INITIAL-EDITS-X.
           EXIT.
      *
      *------------------
       2210-READ-ALL-CVG.
      *------------------

           MOVE MIR-POL-ID-BASE       TO WCVG-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WCVG-POL-ID-SFX.
           MOVE WS-SUBD               TO WCVG-CVG-NUM-N.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  WCVG-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'POLICY & COVERAGE (@1) OUT OF SYNC ...'
               MOVE 'XS00000084'      TO WGLOB-MSG-REF-INFO
               MOVE WS-SUBD           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2210-READ-ALL-CVG-X
           END-IF.

           MOVE RCVG-CVG-INFO         TO WCVGS-CVG-INFO (WS-SUBD).
           MOVE WS-SUBD               TO WCVGS-CVG-SEQ-NUM-N (WS-SUBD).

       2210-READ-ALL-CVG-X.
           EXIT.
      *
      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------

           SET  WS-NO-CLIENT-FOUND TO TRUE.

      *
      * READ AND FORMAT OWNERS NAME
      *
           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
015705         MOVE L2430-CLI-MID-INIT-NM
015705                                TO L0620-CLI-MID-INIT-NM
015705         MOVE L2430-CLI-SFX-NM  TO L0620-CLI-SFX-NM
           END-IF.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
           MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

       2300-COMMON-LINE-SET-X.
           EXIT.
      *
      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  MIR-POL-ID-BASE = SPACES
                 GO TO 2320-GET-OWNER-X
           END-IF.

           IF  L2430-CLI-ID = SPACES
               PERFORM  2400-CHECK-FOR-OWNER-CLI
                   THRU 2400-CHECK-FOR-OWNER-CLI-X
           ELSE
               IF  L2430-CLI-NM-COMPRESSED = SPACES
      *MSG:        OWNER CLIENT NAME = SPACES
                   MOVE 'CS69670006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2320-GET-OWNER-X.
           EXIT.
      *
      *-------------------------
       2400-CHECK-FOR-OWNER-CLI.
      *-------------------------

      *
      * BUILD START/END BROWSE KEY
      *
           MOVE LOW-VALUES            TO  WPOLC-KEY.
           MOVE RPOL-POL-ID           TO  WPOLC-POL-ID.
           MOVE 'O'                   TO  WPOLC-POL-CLI-REL-TYP-CD.

           MOVE WPOLC-KEY             TO  WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO  WPOLC-ENDBR-CLI-ID.

      *
      *  POSITION AT THE FIRST RECORD FOR THE GIVEN RELATIONSHIP
      *
           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

           IF  WPOLC-IO-OK
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

           IF  WPOLC-IO-EOF
               MOVE 'CS69670007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           SET  WS-NO-PRIMARY-EXISTS TO TRUE.
           PERFORM  2500-DETERMINE-IF-PRIMARY
               THRU 2500-DETERMINE-IF-PRIMARY-X
               UNTIL WPOLC-IO-EOF
               OR    WS-FOUND-PRIMARY.

           IF  WS-NO-PRIMARY-EXISTS
               MOVE 'CS69670007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           PERFORM  2600-FIND-OWNERS-LOOP
               THRU 2600-FIND-OWNERS-LOOP-X
               UNTIL WPOLC-IO-EOF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.


       2400-CHECK-FOR-OWNER-CLI-X.
           EXIT.

      *--------------------------
       2500-DETERMINE-IF-PRIMARY.
      *--------------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD = 'P'
               SET WS-FOUND-PRIMARY TO TRUE
               GO TO 2500-DETERMINE-IF-PRIMARY-X
           END-IF.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2500-DETERMINE-IF-PRIMARY-X.
           EXIT.

      *----------------------
       2600-FIND-OWNERS-LOOP.
      *----------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD NOT = 'P'
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
               GO TO 2600-FIND-OWNERS-LOOP-X
           END-IF.

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

      *
      * WE HAVE FOUND THE REQUIRED RECORD, READ THE CLIENT FILE
      *
           MOVE  RPOLC-CLI-ID         TO  L2430-CLI-ID.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

       2600-FIND-OWNERS-LOOP-X.
           EXIT.
      *
      *--------------------
       3000-DISPLAY-SCREEN.
      *--------------------

           PERFORM  6967-1000-BUILD-PARM-INFO
               THRU 6967-1000-BUILD-PARM-INFO-X.

016686*    MOVE MIR-APPL-CTL-PRCES-DT
016686     MOVE MIR-DV-EFF-DT
                             TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

016686*    MOVE L1640-INTERNAL-DATE
016686*                      TO L6967-EFF-DT.

016686     IF  MIR-DV-EFF-DT = SPACE
016686         MOVE WGLOB-PROCESS-DATE TO L6967-EFF-DT
016686     ELSE
016686         MOVE L1640-INTERNAL-DATE
016686                                 TO L6967-EFF-DT
016686     END-IF.

           PERFORM  6967-1000-INQUIRE
               THRU 6967-1000-INQUIRE-X.

           PERFORM  6967-2000-RETRN-PARM-INFO
               THRU 6967-2000-RETRN-PARM-INFO-X.

       3000-DISPLAY-SCREEN-X.
           EXIT.
      *
      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6967-0000-INIT-PARM-INFO
025970         THRU 6967-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-PGM-WORK-AREA.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.


      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
      *
025970 COPY XCPS1670.
       COPY CCPSPGA.
      *
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      *
       COPY XCPS0290.
       COPY XCPL0290.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
016440 COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440*
       COPY CCPS6967.
018764*COPY CCCL6967.
018764 COPY CCPL6967.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
016537*COPY XCCL0225.
      *
016537*COPY XCPL0280.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNCVG.
      *
       COPY CCPNPOL.
      *
       COPY CCPBPOLC.
      *
      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6967                     **
      *****************************************************************
