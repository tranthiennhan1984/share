      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM3600.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM3600                                         **
      **  REMARKS:  THIS MODULE SUSPENDS A POLICY IN THE ADMIN       **
      **            SUB-SYSTEM AND ALLOWS FOR CHANGES TO BE MADE     **
      **            TO THE POLICY CONTRACT.  THE POLICY IS           **
      **            TRANSFERRED TO THE N.B. SUB-SYSTEM AND CHANGES   **
      **            ARE MADE AS IF THE POLICY IS IN A PENDING STATUS.**
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       CISC ABEND HANDLING                              **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       MULTI-COMPANY                                    **
010645**  5.6       ALLOW ACCESS TO AFTT BY LOCATION GROUP           **
012138**  5.6V      US SEC - GUIDELINE ANNUAL PREMIUMS               **
012148**  5.6V      TRAIL COMMISSION                                 **
012624**  6.0       POLICY ACCESS VERIFICATION                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
015742**  6.2       PCR - DON'T DEFAULT POLICY REDATE FIELD          **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
018455**  6.2       PCR - MISSING MESSAGES                           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024088**  6.5       PROBLEM WITH UNDO/REDO PROCESSING                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
026209**  6.7       CALCULATION OF MAT/EXP. DATE ON REISSUE/SUSPEND  **
025692**  6.7       REINSTATE ETI RPU OR EXPIRE WITH UNDERWRITING    **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM3600'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      /
       COPY SQLCA.
018764*COPY XCWLPTR.
      /
      /
014590*COPY XCWL0030.
      /
       01  W3600-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1570' THRU '1572'.
               88  WS-BUS-FCN-SUSPEND       VALUE '1570'.
               88  WS-BUS-FCN-CANCEL        VALUE '1571'.
016440*        88  WS-BUS-FCN-TRANSFER      VALUE '1572'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '1570'.
           05  W3600-EFF-DT                 PIC X(10).

           05  W3600-POL-UPDATE-SW          PIC X(01).
               88  W3600-POL-UPDATE-NOT-REQD VALUE 'N'.
               88  W3600-POL-UPDATE-REQD     VALUE 'Y'.

           05  W3600-MSG.
               10  W3600-MSG-REF-INFO        PIC X(10).
               10  W3600-MSG-SPACE           PIC X(01).
               10  W3600-MSG-TXT             PIC X(68).
016503     05  WS-REDO-SWITCH          PIC X(01).
016503         88  WS-REDO-OK          VALUE 'Y'.
016503         88  WS-REDO-NOT-OK      VALUE 'N'.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY      VALUE '1570'.
      /
      ****************************************************************
      * COMMON COPYBOOKS
      ****************************************************************
008453*COPY XCWTDTTB.
016503 COPY XCWWWKDT.
557756*COPY CCWTYSNO.
       COPY CCWWINDX.
      /
      ***************************************************************
      * I/O COPYBOOKS
      ***************************************************************
       COPY CCFHPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWPOL.
      /
      ***************************************************************
      * WORKING STORAGE PARAMETER AREA
      ***************************************************************

014221 COPY CCWWLOCK.
026057 COPY CCWWIHSD.

      ***************************************************************
      * CALLED MODULE PARAMETER INFORMATION
      ***************************************************************
      /
016503 COPY CCWL0201.
016503 COPY CCWL0289.
020478 COPY CCWL2626.
016503 COPY CCWL4780.
013578 COPY CCWL0620.
       COPY CCWL2430.
012148 COPY CCWL8240.
       COPY NCWL3610.
016440*COPY NCWL3620.
       COPY CCWL4750.
       COPY CCWL5400.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
557756 COPY XCWL2510.
014221 COPY XCWL8090.
       COPY XCWLDTLK.
      /
      ***************************************************************
      * INPUT PARAMETER INFORMATION
      ***************************************************************

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM3600.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

025970*    INITIALIZE W3600-WORK-AREA.
025970*    INITIALIZE FREQUENTLY-USED-INDICES.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      ***************************
       2000-PROCESS-REQUEST.
      ***************************

025970*    SET W3600-POL-UPDATE-NOT-REQD
025970*                               TO TRUE.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.

      *** VALIDATE KEY AND CONTROL FIELDS, EXIT IF  ERRORS FOUND

           PERFORM  3100-EDIT-KEY-FIELDS
               THRU 3100-EDIT-KEY-FIELDS-X
           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
      * PERFORM LOGIC BASED ON ENTER CODE
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-SUSPEND
                    PERFORM  3200-SUSPEND
                        THRU 3200-SUSPEND-X

016440*        WHEN WS-BUS-FCN-TRANSFER
016440*             PERFORM  3300-TRANSFER
016440*                 THRU 3300-TRANSFER-X

               WHEN WS-BUS-FCN-CANCEL
                    PERFORM  3400-CANCEL-SUSPEND
                        THRU 3400-CANCEL-SUSPEND-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST
                                      TO TRUE

           END-EVALUATE
      *
      * REWRITE POLICY AND COVERAGES
      *
           IF  W3600-POL-UPDATE-REQD
               PERFORM  8700-UPDATE-POL-AND-CVGS
                   THRU 8700-UPDATE-POL-AND-CVGS-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *---------------------------------------------------------------
      *    DO ALL VALIDITY CHECKS ON KEY AND CONTROL FIELDS THAT ARE N
      *    FUNCTION-SPECIFIC FOR INITIAL SCREEN (FORCE = 1)
      *---------------------------------------------------------------
      **********************
       3100-EDIT-KEY-FIELDS.
      **********************
      *
            PERFORM  8400-BUILD-POLICY-KEY
                THRU 8400-BUILD-POLICY-KEY-X.
      *
014221*     PERFORM  POL-1000-READ
014221*         THRU POL-1000-READ-X.

014221      EVALUATE TRUE
014221         WHEN MIR-DV-PRCES-STATE-CD = '3'

014221             PERFORM  POL-2000-UPDATE-TWRK-TS
014221                 THRU POL-2000-UPDATE-TWRK-TS-X

014221             IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                 MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221                 MOVE 'POL'            TO WGLOB-MSG-PARM (01)
014221                 MOVE WPOL-KEY         TO WGLOB-MSG-PARM (02)
014221                 PERFORM  0260-1000-GENERATE-MESSAGE
014221                     THRU 0260-1000-GENERATE-MESSAGE-X
014221                SET WGLOB-RETURN-ERROR     TO TRUE
014221                GO TO 3100-EDIT-KEY-FIELDS-X
014221             ELSE
014221                 IF  WPOL-IO-OK
014221                     PERFORM  POL-3000-UNLOCK
014221                         THRU POL-3000-UNLOCK-X
014221                 END-IF
014221             END-IF
014221         WHEN OTHER
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
014221      END-EVALUATE.

      *
           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET  WGLOB-RETURN-ERROR
                                      TO TRUE
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3100-EDIT-KEY-FIELDS-X
           END-IF.

012148     PERFORM  8240-1000-BUILD-PARM-INFO
012148         THRU 8240-1000-BUILD-PARM-INFO-X.
012148     MOVE WPOL-POL-ID           TO L8240-POL-ID.
012148     PERFORM  8240-1000-RETRIEVE-POLW
012148         THRU 8240-1000-RETRIEVE-POLW-X.
012148
      *
      * CALL CSLC5400 TO VERIFY AUTHORITY TO ACCESS POLICY
      *
016440*    IF  WS-BUS-FCN-CANCEL
016440*    AND RPOL-POL-APPL-CTL-ADMIN
016440*        MOVE 'XS00000239'      TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        SET WGLOB-RETURN-ERROR TO TRUE
016440*        GO TO 3100-EDIT-KEY-FIELDS-X
016440*    END-IF.
016440*
016440*    IF  (WS-BUS-FCN-SUSPEND
016440*    OR  WS-BUS-FCN-TRANSFER)
016440*    AND RPOL-POL-APPL-CTL-NBS
016440*        MOVE 'XS00000238'      TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        SET WGLOB-RETURN-ERROR TO TRUE
016440*        GO TO 3100-EDIT-KEY-FIELDS-X
016440*    END-IF.
016440*
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    EVALUATE TRUE
012624*
012624*        WHEN WS-BUS-FCN-CANCEL
012624*            SET L5400-SYS-APPL-CTL-NB
012624*                               TO TRUE
012624*
012624*        WHEN OTHER
012624*            SET L5400-SYS-APPL-CTL-ADMIN
012624*                               TO TRUE
012624*
012624*    END-EVALUATE.
012624*
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.
           IF  L5400-RETRN-OK
               IF  L5400-CNFD-ACCS-RESTRICTED
               OR L5400-BRCH-ACCS-RESTRICTED
012624*        OR L5400-CTL-ACCS-RESTRICTED
               OR L5400-STAT-ACCS-RESTRICTED
                   SET WGLOB-RETURN-ERROR
                                      TO TRUE
                   GO TO 3100-EDIT-KEY-FIELDS-X
               ELSE
                   CONTINUE
               END-IF
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3100-EDIT-KEY-FIELDS-X
           END-IF.
      **
      ** DEFAULT THE EFFECTIVE DATE IF  IT IS BLANK, OTHERWISE
      ** ENSURE THE DATE IS VALID
      **
           IF  MIR-SPND-POL-EFF-DT = SPACES
               MOVE WGLOB-PROCESS-DATE
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-SPND-POL-EFF-DT
               MOVE L1640-INTERNAL-DATE
                                      TO W3600-EFF-DT
           ELSE
               MOVE MIR-SPND-POL-EFF-DT
                                      TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-VALID
                   MOVE L1640-INTERNAL-DATE
                                      TO W3600-EFF-DT
               ELSE
                   MOVE 'NS36000003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                      TO TRUE
                   GO TO 3100-EDIT-KEY-FIELDS-X
               END-IF
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE W3600-EFF-DT             TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057         THRU IHSD-2000-CHK-IHSD-PROCESS-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WGLOB-RETURN-ERROR     TO TRUE
026057         GO TO 3100-EDIT-KEY-FIELDS-X
026057     END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           INITIALIZE I.

           PERFORM  3110-EDIT-OWNER-NAME
               THRU 3110-EDIT-OWNER-NAME-X.
      *
       3100-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      ***********************
       3110-EDIT-OWNER-NAME.
      ***********************

013578*    IF  MIR-DV-PRCES-STATE-CD > '1'
013578*        GO TO 3110-EDIT-OWNER-NAME-X
013578*    END-IF.
013578*
013578*    PERFORM  2430-1000-BUILD-PARM-INFO
013578*        THRU 2430-1000-BUILD-PARM-INFO-X
013578*    MOVE MIR-DV-CLI-NM         TO L2430-OWNER-NAME-1-4.
013578*
013578*    PERFORM  2430-5000-VALIDATE-OWNER-NM
013578*        THRU 2430-5000-VALIDATE-OWNER-NM-X
013578*    IF  L2430-RETRN-OK
013578*        CONTINUE
013578*    ELSE
013578*        MOVE 'NS36000002'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        SET WGLOB-RETURN-ERROR TO TRUE
013578*    END-IF.

013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE RPOL-POL-ID                   TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.

       3110-EDIT-OWNER-NAME-X.
           EXIT.
      /
      *************
       3200-SUSPEND.
      *************

      * CALL THE FUNCTION DRIVER NSLF3610 AND EVALUATE THE FORCE-CODE
           PERFORM  3610-1000-BUILD-PARM-INFO
               THRU 3610-1000-BUILD-PARM-INFO-X.

           MOVE W3600-EFF-DT          TO L3610-EFF-DT.
012138     MOVE L8240-AGT-ID (1)      TO L3610-POLW-AGT-ID (1).
012138     MOVE L8240-AGT-ID (2)      TO L3610-POLW-AGT-ID (2).
012138     MOVE L8240-AGT-ID (3)      TO L3610-POLW-AGT-ID (3).
012138
           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '1'
                    PERFORM  3210-SUSPEND-1
                        THRU 3210-SUSPEND-1-X

               WHEN MIR-DV-PRCES-STATE-CD = '2'
                    PERFORM  3220-SUSPEND-2
                        THRU 3220-SUSPEND-2-X

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM  3230-SUSPEND-3
                        THRU 3230-SUSPEND-3-X

               WHEN OTHER
013578             SET MIR-RETRN-INVALD-RQST
013578                                TO TRUE

           END-EVALUATE.

       3200-SUSPEND-X.
           EXIT.
      /
      ***************
       3210-SUSPEND-1.
      ***************

           SET L3610-PRCES-TYP-EDIT-ONLY
                                      TO TRUE.
016503     SET L3610-REDO-WARNING     TO TRUE.
           PERFORM  3610-1000-SUSPEND-POL
               THRU 3610-1000-SUSPEND-POL-X.
           IF  L3610-RETRN-OK
               MOVE 'Y'               TO MIR-SPND-POL-UWG-IND
015742*        MOVE 'Y'               TO MIR-SPND-POL-REDT-IND
               MOVE WGLOB-USER-ID     TO MIR-UW-USER-1-ID
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       3210-SUSPEND-1-X.
           EXIT.

      ***************
       3220-SUSPEND-2.
      ***************

           SET L3610-PRCES-TYP-EDIT-ONLY
                                      TO TRUE.
016503     SET L3610-REDO-WARNING     TO TRUE.
           MOVE MIR-SPND-POL-UWG-IND  TO L3610-POL-SPND-UWG-IND.
           MOVE MIR-SPND-POL-REDT-IND TO L3610-POL-SPND-DT-IND.
           MOVE MIR-SPND-POL-REASN-CD TO L3610-POL-SPND-REASN-CD
           MOVE MIR-UW-USER-1-ID      TO L3610-USER-ID.
           MOVE MIR-APP-FORM-TYP-ID   TO L3610-APP-FORM-TYP-ID.

           PERFORM  3610-1000-SUSPEND-POL
               THRU 3610-1000-SUSPEND-POL-X
           IF  L3610-RETRN-OK
               IF L3610-REDTE-WARN
                   PERFORM 2510-1000-BUILD-PARM-INFO
                       THRU 2510-1000-BUILD-PARM-INFO-X
                   SET L2510-VALUE-LENGTH-SHORT
                                      TO TRUE
                   SET L2510-RESPONSE-NO
                                      TO TRUE
                   PERFORM 2510-2000-SINGLE-VALUE
                       THRU 2510-2000-SINGLE-VALUE-X
557756*            MOVE TYSNO-YES-NO-SHORT(WGLOB-LANG-SUB, 2)
557756*                                      TO MIR-SPND-POL-REDT-IND
                   MOVE L2510-RESPONSE-TXT
                                      TO MIR-SPND-POL-REDT-IND
               END-IF
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               IF  L3610-REDTE-WARN
                   PERFORM 2510-1000-BUILD-PARM-INFO
                       THRU 2510-1000-BUILD-PARM-INFO-X
                   SET L2510-VALUE-LENGTH-SHORT
                                      TO TRUE
                   SET L2510-RESPONSE-NO
                                      TO TRUE
                   PERFORM 2510-2000-SINGLE-VALUE
                       THRU 2510-2000-SINGLE-VALUE-X
557756*            MOVE TYSNO-YES-NO-SHORT(WGLOB-LANG-SUB, 2)
557756*                                      TO MIR-SPND-POL-REDT-IND
                   MOVE L2510-RESPONSE-TXT
                                      TO MIR-SPND-POL-REDT-IND
                   GO TO 3220-SUSPEND-2-X
               END-IF

               IF  L3610-REDTE-ERR
                   PERFORM 2510-1000-BUILD-PARM-INFO
                       THRU 2510-1000-BUILD-PARM-INFO-X
                   SET L2510-VALUE-LENGTH-SHORT
                                      TO TRUE
                   SET L2510-RESPONSE-NO
                                      TO TRUE
                   PERFORM 2510-2000-SINGLE-VALUE
                       THRU 2510-2000-SINGLE-VALUE-X
557756*            MOVE TYSNO-YES-NO-SHORT(WGLOB-LANG-SUB, 2)
557756*                                      TO MIR-SPND-POL-REDT-IND
                   MOVE L2510-RESPONSE-TXT
                                      TO MIR-SPND-POL-REDT-IND
               END-IF
           END-IF.

       3220-SUSPEND-2-X.
           EXIT.
      /
      ***************
       3230-SUSPEND-3.
      ***************

016503*PERFORM "REDO" PROCESS IF NEXT ACTIVITY IS DUE TO BRING
016503*POLICY UP TO DATE


016503     SET WS-REDO-OK           TO  TRUE.
016503     IF (RPOL-POL-NXT-ACTV-DT NOT = WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503        CONTINUE
016503     ELSE
016503        PERFORM  8500-INVOKE-REDO
016503            THRU 8500-INVOKE-REDO-X
016503     END-IF.

016503     IF WS-REDO-NOT-OK
016503        GO TO 3230-SUSPEND-3-X
016503     END-IF.


      * PERFORM "UNDO" PROCESS
           PERFORM  8600-UNDO-PROCESS
               THRU 8600-UNDO-PROCESS-X.

           IF  WGLOB-RETURN-ERROR
               MOVE 'NS36000045'      TO WGLOB-MSG-REF-INFO
               GO TO 3230-SUSPEND-3-X
           END-IF.

      * ONCE WE HAVE REACHED HERE, WE MUST UPDATE POL AND CVGS
      * SINCE 3610 MAY DO SOME SUBSIDIARY FILE UPDATES

           SET W3600-POL-UPDATE-REQD  TO TRUE.

      * CALL NSLF3610 WITH A PRCES-TYP-ALL TO PERFORM SUSPEND
      * PROCESSING.

           MOVE MIR-SPND-POL-UWG-IND  TO L3610-POL-SPND-UWG-IND.
           MOVE MIR-SPND-POL-REDT-IND TO L3610-POL-SPND-DT-IND.
           MOVE MIR-SPND-POL-REASN-CD TO L3610-POL-SPND-REASN-CD
           MOVE MIR-UW-USER-1-ID      TO L3610-USER-ID.
           MOVE MIR-APP-FORM-TYP-ID   TO L3610-APP-FORM-TYP-ID.
           SET  L3610-REDO-WARNING    TO TRUE.
           PERFORM  3610-1000-SUSPEND-POL
               THRU 3610-1000-SUSPEND-POL-X.

           IF  L3610-RETRN-ERROR
      *MSG:    FATAL ERROR. RECORDS MAY BE OUT OF SYNC. CONTACT SYSTEMS
               MOVE 'NS36000047'      TO WGLOB-MSG-REF-INFO
               GO TO 3230-SUSPEND-3-X
           END-IF.

      * POLICY PROCESS.

      * MSG:  POLICY @1 SUSPENDED FROM ADMIN PROCESSING
           MOVE 'NS36000029'          TO WGLOB-MSG-REF-INFO.
018455     PERFORM  0260-1000-GENERATE-MESSAGE
018455         THRU 0260-1000-GENERATE-MESSAGE-X.

       3230-SUSPEND-3-X.
           EXIT.
      /
016440**************
016440*3300-TRANSFER.
016440**************
016440*
016440* THIS PARAGRAPH WILL SET UP THE PARMS TO CALL NSLF3620 AND
016440* EVALUATE THE FORCE-CODE.
016440*    PERFORM  3620-1000-BUILD-PARM-INFO
016440*        THRU 3620-1000-BUILD-PARM-INFO-X.
016440*
016440*    MOVE W3600-EFF-DT          TO L3620-EFF-DT
016440*
016440*    EVALUATE TRUE
016440*
013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
016440*        WHEN MIR-DV-PRCES-STATE-CD = '2'
016440*            PERFORM  3310-TRANSFER-1
016440*                THRU 3310-TRANSFER-1-X
016440*
016440*        WHEN MIR-DV-PRCES-STATE-CD = '3'
016440*            PERFORM  3330-TRANSFER-3
016440*                THRU 3330-TRANSFER-3-X
016440*
016440*        WHEN OTHER
016440*            SET MIR-RETRN-INVALD-RQST
016440*                               TO TRUE
016440*
016440*    END-EVALUATE.
016440*
016440*3300-TRANSFER-X.
016440*    EXIT.
016440*
016440****************
016440*3310-TRANSFER-1.
016440****************
016440*
016440* CALL FUNCTION-DRIVER FOR EDIT-ONLY PASS
016440*    SET L3620-PRCES-TYP-EDIT-ONLY
016440*                               TO TRUE
016440*
016440*    MOVE L8240-AGT-ID (1)      TO L3620-POLW-AGT-ID (1).
016440*    MOVE L8240-AGT-ID (2)      TO L3620-POLW-AGT-ID (2).
016440*    MOVE L8240-AGT-ID (3)      TO L3620-POLW-AGT-ID (3).
016440*
016440*    PERFORM  3620-1000-TRANSFER-POL
016440*        THRU 3620-1000-TRANSFER-POL-X.
016440*
016440*    IF  L3620-RETRN-OK
016440*        CONTINUE
016440*    ELSE
016440*        SET WGLOB-RETURN-ERROR TO TRUE
016440*    END-IF.
016440*
016440*3310-TRANSFER-1-X.
016440*    EXIT.
016440*
016440****************
016440*3330-TRANSFER-3.
016440****************
016440*
016440* PERFORM "UNDO" PROCESS
016440*    PERFORM  8600-UNDO-PROCESS
016440*        THRU 8600-UNDO-PROCESS-X.
016440*    IF  WGLOB-RETURN-ERROR
016440*        MOVE 'NS36000044'      TO WGLOB-MSG-REF-INFO
016440*        GO TO 3330-TRANSFER-3-X
016440*    END-IF.
016440*
016440* ONCE WE HAVE REACHED HERE, WE MUST UPDATE POL AND CVGS
016440* SINCE 3620 MAY DO SOME SUBSIDIARY FILE UPDATES
016440*
016440*    SET W3600-POL-UPDATE-REQD  TO TRUE.
016440*
016440* CALL NSLF3620 TO PERFORM TRANSFER PROCESSING
016440*    MOVE L8240-AGT-ID (1)      TO L3620-POLW-AGT-ID (1).
016440*    MOVE L8240-AGT-ID (2)      TO L3620-POLW-AGT-ID (2).
016440*    MOVE L8240-AGT-ID (3)      TO L3620-POLW-AGT-ID (3).
016440*
016440*    PERFORM  3620-1000-TRANSFER-POL
016440*        THRU 3620-1000-TRANSFER-POL-X.
016440*
016440*    IF  L3620-RETRN-ERROR
016440*MSG:    FATAL ERROR. RECORDS MAY BE OUT OF SYNC. CONTACT SYSTEMS
016440*        MOVE 'NS36000047'      TO WGLOB-MSG-REF-INFO
016440*        GO TO 3330-TRANSFER-3-X
016440*    END-IF.
016440*
016440* MSG:  POLICY @1 TRANSFERRED TO NEW BUSINESS SUBSYSTEM
016440*    MOVE 'NS36000017'          TO WGLOB-MSG-REF-INFO.
016440*
016440*3330-TRANSFER-3-X.
016440*    EXIT.
016440*
      ********************
       3400-CANCEL-SUSPEND.
      ********************

           PERFORM  3610-1000-BUILD-PARM-INFO
               THRU 3610-1000-BUILD-PARM-INFO-X.

           MOVE W3600-EFF-DT          TO L3610-EFF-DT.

           EVALUATE TRUE

013578*        WHEN MIR-DV-PRCES-STATE-CD = '1'
013578         WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  3410-CANCEL-SUSPEND-1
                       THRU 3410-CANCEL-SUSPEND-1-X

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  3430-CANCEL-SUSPEND-3
                       THRU 3430-CANCEL-SUSPEND-3-X

013578         WHEN OTHER
013578             SET MIR-RETRN-INVALD-RQST
013578                                TO TRUE

           END-EVALUATE.

       3400-CANCEL-SUSPEND-X.
           EXIT.
      /
      **********************
       3410-CANCEL-SUSPEND-1.
      **********************

           SET L3610-PRCES-TYP-EDIT-ONLY
                                      TO TRUE.

012148     MOVE L8240-AGT-ID (1)      TO L3610-POLW-AGT-ID (1).
012148     MOVE L8240-AGT-ID (2)      TO L3610-POLW-AGT-ID (2).
012148     MOVE L8240-AGT-ID (3)      TO L3610-POLW-AGT-ID (3).
012148
           PERFORM  3610-2000-CNCL-SPND-POL
               THRU 3610-2000-CNCL-SPND-POL-X.
012148
012148     MOVE L3610-POLW-AGT-ID (1) TO L8240-AGT-ID (1).
012148     MOVE L3610-POLW-AGT-ID (2) TO L8240-AGT-ID (2).
012148     MOVE L3610-POLW-AGT-ID (3) TO L8240-AGT-ID (3).

           IF  L3610-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       3410-CANCEL-SUSPEND-1-X.
           EXIT.
      /
      **********************
       3430-CANCEL-SUSPEND-3.
      **********************

           PERFORM  8600-UNDO-PROCESS
               THRU 8600-UNDO-PROCESS-X.
           IF  WGLOB-RETURN-ERROR
               MOVE 'NS36000046'      TO WGLOB-MSG-REF-INFO
               GO TO 3430-CANCEL-SUSPEND-3-X
           END-IF.

      * ONCE WE HAVE REACHED HERE, WE MUST UPDATE POL AND CVGS
      * SINCE 3610 MAY DO SOME SUBSIDIARY FILE UPDATES

           SET W3600-POL-UPDATE-REQD  TO TRUE.

      * CALL NSLF3610 TO DO "CANCEL SUSPEND" PROCESSING

012148     MOVE L8240-AGT-ID (1)      TO L3610-POLW-AGT-ID (1).
012148     MOVE L8240-AGT-ID (2)      TO L3610-POLW-AGT-ID (2).
012148     MOVE L8240-AGT-ID (3)      TO L3610-POLW-AGT-ID (3).
012148

016440     PERFORM  POL-1000-READ-FOR-UPDATE
016440         THRU POL-1000-READ-FOR-UPDATE-X.

           PERFORM  3610-2000-CNCL-SPND-POL
               THRU 3610-2000-CNCL-SPND-POL-X.
012148
012148     MOVE L3610-POLW-AGT-ID (1) TO L8240-AGT-ID (1).
012148     MOVE L3610-POLW-AGT-ID (2) TO L8240-AGT-ID (2).
012148     MOVE L3610-POLW-AGT-ID (3) TO L8240-AGT-ID (3).

016440     IF  NOT L3610-POL-UPDT
016440         PERFORM  POL-3000-UNLOCK
016440             THRU POL-3000-UNLOCK-X
016440     END-IF.

           IF  L3610-RETRN-ERROR
      *MSG:    FATAL ERROR. RECORDS MAY BE OUT OF SYNC. CONTACT SYSTEMS
               MOVE 'NS36000047'      TO WGLOB-MSG-REF-INFO
               GO TO 3430-CANCEL-SUSPEND-3-X
           END-IF.

      * MSG:  POLICY @1 SUSPENSION HAS BEEN CANCELLED
           MOVE 'NS36000041'          TO WGLOB-MSG-REF-INFO.
018455     PERFORM  0260-1000-GENERATE-MESSAGE
018455         THRU 0260-1000-GENERATE-MESSAGE-X.

       3430-CANCEL-SUSPEND-3-X.
           EXIT.
      /
      ***********************
       8400-BUILD-POLICY-KEY.
      ***********************
      *
           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.
      *
       8400-BUILD-POLICY-KEY-X.
           EXIT.
      /

016503*-----------------
016503 8500-INVOKE-REDO.
016503*-----------------

016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503         GO TO 8500-INVOKE-REDO-X
016503     END-IF.

016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     MOVE W3600-EFF-DT                  TO L4780-EFF-DT.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
024088*    SET L4780-PRCES-INCLUSIVE          TO TRUE.
025692*    SET L4780-PRCES-EXCLUSIVE          TO TRUE.
025692     SET L4780-PRCES-INCLUSIVE          TO TRUE.

016503     PERFORM  4780-1000-GET-NEXT-ACT-DT
016503         THRU 4780-1000-GET-NEXT-ACT-DT-X.

016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              SET WS-REDO-NOT-OK           TO TRUE
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503             MOVE W3600-EFF-DT        TO L0201-EFF-DT
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X
016503             PERFORM  0289-1000-INIT-PARM-INFO
016503                 THRU 0289-1000-INIT-PARM-INFO-X
016503             MOVE W3600-EFF-DT    TO L0289-LO-PAC-DT
020467             MOVE W3600-EFF-DT    TO L0289-LO-DD2-DT
016503             MOVE W3600-EFF-DT    TO L0289-LO-CRC-DT
016503             MOVE W3600-EFF-DT    TO L0289-PROC-EFF-DT
016503             PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503                 THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503             IF  L0289-RETRN-OK
016503                 MOVE L0289-NXT-ACTV-TYP-CD
016503                      TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE L0289-NXT-ACTV-DT
016503                      TO RPOL-POL-NXT-ACTV-DT
016503             ELSE
016503                 MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE WGLOB-PROCESS-DATE
016503                           TO RPOL-POL-NXT-ACTV-DT
016503             END-IF
016503             MOVE RPOL-REC-INFO             TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503            MOVE HPOL-REC-INFO              TO RPOL-REC-INFO
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
016503             PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016503                 THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
016503             IF  L0201-RETRN-OK
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503             END-IF
016503     END-EVALUATE.

016503 8500-INVOKE-REDO-X.
016503     EXIT.

      ******************
       8600-UNDO-PROCESS.
      ******************

026209     IF  NOT RPOL-POL-STAT-IN-FORCE
026209         GO TO 8600-UNDO-PROCESS-X
026209     END-IF.

      * CALL THE "UNDO" FUNCTION-DRIVER TO REVERSE TRANSACTIONS
024088* THAT ARE DATED LATER THAN OR ON THE EFFECTIVE DATE.
           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X

           SET L4750-FCN-DRVR-SECONDARY
                                      TO TRUE.
024088*    SET L4750-PRCES-EXCLUSIVE  TO TRUE.
025692*    SET L4750-PRCES-INCLUSIVE  TO TRUE.
029060*    SET L4750-PRCES-EXCLUSIVE  TO TRUE.
029060
029060     IF  W3600-EFF-DT = RPOL-POL-ISS-EFF-DT
029060         SET L4750-PRCES-INCLUSIVE
029060                                TO TRUE
029060     ELSE
029060         SET L4750-PRCES-EXCLUSIVE
029060                                TO TRUE
029060     END-IF.
029060
           MOVE W3600-EFF-DT          TO L4750-EFF-DT.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF

           IF  L4750-POL-UPDATE-REQD
               SET W3600-POL-UPDATE-REQD
                                      TO TRUE
           END-IF.

       8600-UNDO-PROCESS-X.
           EXIT.


      *-------------------------
       8700-UPDATE-POL-AND-CVGS.
      *-------------------------

           MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
           MOVE RPOL-KEY              TO HPOL-KEY.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE HPOL-REC-INFO         TO RPOL-REC-INFO.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM POL-1000-READ-TWRK-TS
014221        THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

012148     PERFORM  8240-2000-UPDATE-POLW
012148         THRU 8240-2000-UPDATE-POLW-X.

       8700-UPDATE-POL-AND-CVGS-X.
           EXIT.
      /
      *----------------------------------------------------------------
      *   SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS
      *   WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *----------------------------------------------------------------
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE            TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2510-0000-INIT-PARM-INFO
025970         THRU 2510-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  3610-0000-INIT-PARM-INFO
025970         THRU 3610-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8240-0000-INIT-PARM-INFO
025970         THRU 8240-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         W3600-WORK-AREA.
025970     INITIALIZE                         FREQUENTLY-USED-INDICES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET W3600-POL-UPDATE-NOT-REQD      TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970     MOVE SPACES                       TO WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
       COPY XCPPEXIT.
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
012624*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      ***************************************************************
      *  LINKAGE PROCESSING COPYBOOKS
      ***************************************************************
      *
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
013578 COPY CCPL0620.
      /
018764*COPY CCCL0201.
025970 COPY CCPS0201.
018764 COPY CCPL0201.
016503*
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503*
018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS2430.
      /
018764*COPY NCCL3610.
018764 COPY NCPL3610.
       COPY NCPS3610.
      /
016440*COPY NCCL3620.
016440*COPY NCPS3620.
      /
018764*COPY CCCL4750.
018764 COPY CCPL4750.
       COPY CCPS4750.
      /
016503 COPY CCPS4780.
018764*COPY CCCL4780.
018764 COPY CCPL4780.
016503*
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.
012148/
018764*COPY CCCL8240.
018764 COPY CCPL8240.
012148 COPY CCPS8240.
      /
018764*COPY XCCL2510.
018764 COPY XCPL2510.
557756 COPY XCPS2510.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
      /
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY NCPPCVGS.
       COPY NCPPCVGR.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      *****************************************************************
      * ERROR HANDLING ROUTINES
      *****************************************************************
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM3600                     **
      *****************************************************************

