      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM0040.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM0040                                         **
      **  REMARKS:  PROCESS DRIVER FOR FPRL                          **
      **            THIS TRANSACTION MAINTAINS RELATIONSHIPS BETWEEN **
      **            SEGREGATED FUNDS AND PLANS.                      **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE STANDARD                                    **
557708**  5.5       CICS ABEND HANDLING                              **
008445**  5.5.2     GENERATE MIR FROM TECH ARCH DATABASE             **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEAN-UP AND STANDARDIZATION                **
010314**  5.6       EQUITY INDEX PRODUCTS                            **
012135**  5.6V      ADD SUBSIDIARY CO. & LOCATION GROUP              **
012136**  5.6V      ADD FREE LOOK FUND DESIGNATION CODE              **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
015543**  6.0       CODE CLEANUP AND STANDARDIZATION                 **
014221**  6.2       LOGICAL RECORD LOCKING                           **
014591**  6.2       COMBINE PLAN-ID & RS                             **
015905**  6.2       REPLACED DV FIELD WITH ALLOWED VALUES SUBSETS    **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0040'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE '1740' '1741' '1742'
                                                  '1743' '1744' '1745'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1740'.
               88  WS-BUS-FCN-CREATE        VALUE '1741'.
               88  WS-BUS-FCN-UPDATE        VALUE '1742'.
               88  WS-BUS-FCN-DELETE        VALUE '1743'.
               88  WS-BUS-FCN-LIST          VALUE '1744'.
               88  WS-BUS-FCN-CLONE         VALUE '1745'.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.
               88  WS-DATA-EDITS-FAILED     VALUE 'N'.
           05  WS-CROSS-EDITS               PIC X(01).
               88  WS-CROSS-EDITS-OK        VALUE 'Y'.
               88  WS-CROSS-EDITS-FAILED    VALUE 'N'.
           05  WS-FDRQD                     PIC X(01).
               88  WS-FDRQD-VALID           VALUE 'O' 'R'.
010314         88  WS-FDRQD-FUND-REQD       VALUE 'R'.
           05  WS-MUTEX                     PIC X(01).
               88  WS-MUTEX-VALID           VALUE 'N' 'Y'.
           05  WS-PTLSR                     PIC X(01).
               88  WS-PTLSR-VALID           VALUE 'N' 'Y'.
025970*    05  WS-OK                        PIC X(01)  VALUE 'Y'.
025970*    05  WS-FAILED                    PIC X(01)  VALUE 'N'.
016548*    05  WS-DISPLAY-LINES             PIC S9(04)  COMP
025970*    05  WS-DISPLAY-LINES             PIC S9(04)  BINARY
013578*                                     VALUE +13.
025970*                                     VALUE +100.
016548*    05  WS-LINES                     PIC S9(04)  COMP.
016548     05  WS-LINES                     PIC S9(04)  BINARY.
010314     05  WS-PLAN-ID                   PIC X(06).
008455*    05  WS-PIC-7V99                  PIC 9(7).99.
           05  WS-SAVE-FR-END-KEY.
               10  WS-SAVE-PLAN-ID          PIC X(06).
012136     05  WS-FLFNDI                    PIC X(01).
012136         88  WS-FLFNDI-VALID          VALUE 'I' 'N'.
025970*01  WS-TWRK-KEY                      PIC X(04) VALUE '1740'.

025970 01  WS-CONSTANTS.
025970     05  WS-OK                        PIC X(01).
025970         88  WS-OK-DEFAULT            VALUE 'Y'.
025970     05  WS-FAILED                    PIC X(01).
025970         88  WS-FAILED-DEFAULT        VALUE 'N'.
025970     05  WS-DISPLAY-LINES             PIC S9(04) BINARY.
025970         88  WS-DISPLAY-LINES-DEFAULT VALUE +100.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1740'.

       01  WS-WORK-AREA.
           05  WS-WORK-PROGRAM-NUMBER       PIC X(04).
           05  WS-WORK-CLIENT-NUMBER        PIC X(10).
           05  WS-WORK-POL-ID.
               10  WS-WORK-POL-ID-BASE      PIC X(09).
               10  WS-WORK-POL-ID-SFX       PIC X(01).
           05  WS-WORK-QUOTE-NUMBER         PIC X(06).
           05  WS-WORK-CLAIM-NO             PIC X(06).
           05  WS-WORK-SPECIFIC-AREA.
               10  WS-WORK-FROM-CLONE-KEY.
014591*            15  WS-WORK-FROM-CLONE-PLAN-CODE    PIC X(06).
014591             15  WS-WORK-FROM-CLONE-PLAN-ID      PIC X(06).
                   15  WS-WORK-FROM-CLONE-SBSDR-CO-ID  PIC X(02).
                   15  WS-WORK-FROM-CLONE-LOC-GR-ID    PIC X(03).
                   15  WS-WORK-FROM-CLONE-FUND-CODE    PIC X(05).
               10  WS-WORK-TO-CLONE-KEY.
014591*            15  WS-WORK-TO-CLONE-PLAN-CODE      PIC X(06).
014591             15  WS-WORK-TO-CLONE-PLAN-ID        PIC X(06).
                   15  WS-WORK-TO-CLONE-SBSDRY-CO-ID   PIC X(02).
                   15  WS-WORK-TO-CLONE-LOC-GR-ID      PIC X(03).
                   15  WS-WORK-TO-CLONE-FUND-CODE      PIC X(05).
               10  FILLER                   PIC X(232).

       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      *
       COPY XCWL0280.
      *
008455 COPY XCWL0290.
008455*
014221 COPY XCWL8090.
014221*
020469 COPY CCFWPD.
020469 COPY CCFRPD.
020469*
       COPY SCFWFH.
       COPY SCFRFH.
      *
       COPY SCFWFR.
       COPY SCFRFR.
      *
       COPY SCFWFX.
       COPY SCFRFX.
      *
010314 COPY CCFWPH.
010314 COPY CCFRPH.
012135*
012135 COPY CCFWSCOM.
012135 COPY CCFRSCOM.
012135*
012135 COPY CCFWEDIT.
012135 COPY CCFREDIT.
012135*
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0040.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           IF WS-WORK-PROGRAM-NUMBER NOT = WGLOB-MAIN-PGM-NUMBER
               MOVE SPACES           TO WS-WORK-SPECIFIC-AREA
557660     END-IF.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------
      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *      PROCESS USER REQUEST
      *****************************************************************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *    MOVE BUSINESS FUNCTION ID TO A WORK FIELD.
      *
025970*    MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
      *
      *    CHECK FOR A DELETE CANCELLATION
      *
           IF MIR-DV-PRCES-STATE-CD = '9'
           AND NOT WS-BUS-FCN-DELETE
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
      *    CHECK FOR A CLONE CANCELLATION/COMPLETION
      *
           IF MIR-DV-PRCES-STATE-CD = '8'
           AND NOT WS-BUS-FCN-CLONE
               PERFORM  6800-PROCESS-CLONE-BACKOUT
                   THRU 6800-PROCESS-CLONE-BACKOUT-X
557660     END-IF.
      *
           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           IF WS-BUS-FCN-RETRIEVE
               PERFORM  3000-PROCESS-RETRIEVE
                   THRU 3000-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-LIST
               PERFORM  3500-PROCESS-LIST
                   THRU 3500-PROCESS-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-CREATE
               PERFORM  4000-CREATE
                   THRU 4000-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-DELETE
               PERFORM  6000-PROCESS-DELETE
                   THRU 6000-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-CLONE
               PERFORM  6500-PROCESS-CLONE
                   THRU 6500-PROCESS-CLONE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------
      *****************************************************************
      *  RETRIEVE PROCESSING: DISPLAY RECORD ON SCREEN.
      *****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

014221     MOVE MIR-FND-ID            TO WFH-FND-ID.
014221     PERFORM FH-1000-READ-TWRK-TS
014221        THRU FH-1000-READ-TWRK-TS-X
014221     IF  WFH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WFH-FND-ID         TO WGLOB-MSG-PARM (1)
014221        MOVE 'FH'               TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3000-PROCESS-RETRIEVE-X
014221     END-IF.

           PERFORM  7100-BUILD-FR-KEY
               THRU 7100-BUILD-FR-KEY-X.

           PERFORM  FR-1000-READ
               THRU FR-1000-READ-X.

           IF WFR-IO-NOT-FOUND
      *MSG:    FUND RELATIONSHIP (@1) RECORD NOT FOUND
               MOVE 'SS00400001'      TO WGLOB-MSG-REF-INFO
               MOVE WFR-KEY           TO WGLOB-MSG-PARM (1)
           ELSE
      *MSG:    RETRIEVE COMPLETED
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               MOVE +1                TO WS-LINES
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *-------------
       3500-PROCESS-LIST.
      *-------------
      *****************************************************************
      *  BROWSE PROCESSING: SET UP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      *    SETUP BROWSE KEY LIMITS
      *
           PERFORM  7100-BUILD-FR-KEY
               THRU 7100-BUILD-FR-KEY-X.
      *
      *    POSITION AT AND READ FIRST RECORD.
      *
           MOVE WFR-KEY               TO WFR-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WFR-ENDBR-FND-ID.
012135     MOVE HIGH-VALUES           TO WFR-ENDBR-SBSDRY-CO-ID.
012135     MOVE HIGH-VALUES           TO WFR-ENDBR-LOC-GR-ID.

           PERFORM  FR-1000-BROWSE
               THRU FR-1000-BROWSE-X.
           IF WFR-IO-OK
               PERFORM  FR-2000-READ-NEXT
                   THRU FR-2000-READ-NEXT-X
               IF WFR-IO-EOF
      *MSG:        NO RECORDS FOUND TO DISPLAY
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  FR-3000-END-BROWSE
                       THRU FR-3000-END-BROWSE-X
                   GO TO 3500-PROCESS-LIST-X
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
      *MSG:    NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.
      *
      *    LOAD SCREEN DATA ARRAY.
      *
           MOVE +1                    TO WS-LINES.
           PERFORM  3600-DISPLAY-RECORD
               THRU 3600-DISPLAY-RECORD-X
               UNTIL WS-LINES > WS-DISPLAY-LINES
               OR WFR-IO-EOF.
      *
      *  COMPLETION MESSAGE
      *  (WHEN EOF, DETERMINE IF PHYSICAL OR LOGICAL EOF)
      *
           IF WFR-IO-EOF
      *        END OF FILE REACHED
      *            BROWSE COMPLETED - CONTINUE
      *
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
012135         PERFORM  0260-1000-GENERATE-MESSAGE
012135             THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *            TO VIEW MORE DATA PRESS ENTER
      *
               MOVE WFR-FND-ID        TO MIR-FND-ID
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
012135         PERFORM  0260-1000-GENERATE-MESSAGE
012135             THRU 0260-1000-GENERATE-MESSAGE-X
012135         PERFORM  9220-UPDATE-SCREEN-KEYS
012135             THRU 9220-UPDATE-SCREEN-KEYS-X
557660     END-IF.
      *
      *    END THE BROWSE.
      *
           PERFORM  FR-3000-END-BROWSE
               THRU FR-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      *
      *--------------------
       3600-DISPLAY-RECORD.
      *--------------------
      *****************************************************************
      *  BROWSE DISPLAY PROCESSING: DISPLAY THE CURRENT RECORD ONTO
      *  THE SCREEN DATA LINE GIVEN BY WS-LINES AND RETRIEVE THE NEXT
      *  RECORD.
      *****************************************************************

           MOVE RFR-FND-ID            TO MIR-FND-ID-T (WS-LINES).
012135     MOVE RFR-SBSDRY-CO-ID      TO MIR-SBSDRY-CO-ID-T (WS-LINES).
012135     MOVE RFR-LOC-GR-ID         TO MIR-LOC-GR-ID-T (WS-LINES).
           ADD +1                  TO WS-LINES.

           PERFORM  FR-2000-READ-NEXT
               THRU FR-2000-READ-NEXT-X.

       3600-DISPLAY-RECORD-X.
           EXIT.
      *
      *------------
       4000-CREATE.
      *------------
      *****************************************************************
      *  CREATE PROCESSING: TWO PASSES REQUIRED
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      *      ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING
      *****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      *    VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
      *
           PERFORM  7500-EDIT-KEY-FIELDS
               THRU 7500-EDIT-KEY-FIELDS-X.
           IF WS-DATA-EDITS-FAILED
               GO TO 4000-CREATE-X
557660     END-IF.
      *
      *    BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-FR-KEY
               THRU 7100-BUILD-FR-KEY-X.
      *
      *    CHECK RECORD EXISTENCE
      *
           PERFORM  FR-1000-READ
               THRU FR-1000-READ-X.
           IF WFR-IO-OK
      *MSG:    FUND/PLAN RELATIONSHIP  (@1) ALREADY EXISTS
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WFR-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-CREATE-X
557660     END-IF.
      *
      *    CREATE NEW RECORD.
      *
           PERFORM  FR-1000-CREATE
               THRU FR-1000-CREATE-X.

010314     IF RFH-FND-TYP-INDEXED
010314         MOVE 'R'               TO RFR-PLAN-FND-REQIR-CD
010314     END-IF.

           PERFORM  FR-1000-WRITE
               THRU FR-1000-WRITE-X.

014221     MOVE MIR-FND-ID            TO WFH-FND-ID.
014221     PERFORM FH-1000-READ-TWRK-TS
014221        THRU FH-1000-READ-TWRK-TS-X.

      *MSG:    RECORD CREATED - CONTINUE
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE +1                    TO WS-LINES.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *MSG:    MAINTAIN DETAILS
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE 'M'                   TO MIR-BUS-FCN-ID.

       4000-CREATE-X.
           EXIT.
      *
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------
      *****************************************************************
      *  UPDATE PROCESSING:
      *        GET RECORD, EDIT DATA FIELDS AND UPDATE RECORD.
      *        FIELDS WITH ERRORS ARE NOT UPDATED.
      *****************************************************************
      *
014221     MOVE MIR-FND-ID            TO WFH-FND-ID.
014221     PERFORM FH-2000-UPDATE-TWRK-TS
014221        THRU FH-2000-UPDATE-TWRK-TS-X.

014221     IF  WFH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WFH-FND-ID         TO WGLOB-MSG-PARM (1)
014221         MOVE 'FH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'FH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WFH-FND-ID         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  7100-BUILD-FR-KEY
               THRU 7100-BUILD-FR-KEY-X.
           PERFORM  FR-1000-READ-FOR-UPDATE
               THRU FR-1000-READ-FOR-UPDATE-X.

      *MSG:    LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
           IF WFR-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WFR-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM FH-3000-UNLOCK
014221            THRU FH-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  7300-DATA-EDITS
               THRU 7300-DATA-EDITS-X.

           PERFORM  FR-2000-REWRITE
               THRU FR-2000-REWRITE-X.
      *
014221     PERFORM  FH-2000-REWRITE
014221         THRU FH-2000-REWRITE-X
014221     PERFORM  FH-1000-READ-TWRK-TS
014221         THRU FH-1000-READ-TWRK-TS-X

           IF WS-DATA-EDITS-OK
      *MSG:    MAINTENANCE COMPLETED - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               MOVE 'I'               TO MIR-BUS-FCN-ID
      *MSG:    RECORD UPDATED

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      *
      *------------
       6000-PROCESS-DELETE.
      *------------
      *****************************************************************
      *  DELETE PROCESSING:
      *      DELETE IS VERIFIED SO REMOVE RECORD
      *****************************************************************

014221     MOVE MIR-FND-ID            TO WFH-FND-ID.
014221     PERFORM FH-2000-UPDATE-TWRK-TS
014221        THRU FH-2000-UPDATE-TWRK-TS-X.

014221     IF  WFH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WFH-FND-ID         TO WGLOB-MSG-PARM (1)
014221         MOVE 'FH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'FH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WFH-FND-ID         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.


           PERFORM  7100-BUILD-FR-KEY
               THRU 7100-BUILD-FR-KEY-X.
           PERFORM  FR-1000-READ-FOR-UPDATE
               THRU FR-1000-READ-FOR-UPDATE-X.

           IF WFR-IO-NOT-FOUND
      *MSG:    RECORD (@1) LOST IN DELETE - CONTACT SYSTEMS
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WFR-KEY           TO WGLOB-MSG-PARM (1)
014221         PERFORM  FH-3000-UNLOCK
014221             THRU FH-3000-UNLOCK-X
           ELSE
      *MSG:    DELETE COMPLETED - CONTINUE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  FR-1000-DELETE
                   THRU FR-1000-DELETE-X
014221         PERFORM  FH-2000-REWRITE
014221             THRU FH-2000-REWRITE-X
014221         PERFORM  FH-1000-READ-TWRK-TS
014221             THRU FH-1000-READ-TWRK-TS-X

557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE 'I'                   TO MIR-BUS-FCN-ID.

       6000-PROCESS-DELETE-X.
           EXIT.

      *-------------------
       6500-PROCESS-CLONE.
      *-------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-FR-KEY
               THRU 7100-BUILD-FR-KEY-X.

           PERFORM  FR-1000-READ
               THRU FR-1000-READ-X.

           IF WFR-IO-NOT-FOUND
      *MSG:    FUND/PLAN RELATIONSHIP (@1) RECORD NOT FOUND
               MOVE 'SS00400001'      TO WGLOB-MSG-REF-INFO
               MOVE WFR-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
012135*DEL MSG: ENTER NEW PLAN CODE, RATE SCALE AND FUND CODE
012135*MOD MSG: ENTER NEW PLAN CODE, RATE SCALE, SUB CO, AND FUND CODE
               MOVE 'SS00400002'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE +1                    TO WS-LINES
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
014591*        MOVE MIR-PLAN-ID TO WS-WORK-FROM-CLONE-PLAN-CODE
014591         MOVE MIR-PLAN-ID TO WS-WORK-FROM-CLONE-PLAN-ID
               MOVE MIR-SBSDRY-CO-ID
                                      TO WS-WORK-FROM-CLONE-SBSDR-CO-ID
               MOVE MIR-LOC-GR-ID TO WS-WORK-FROM-CLONE-LOC-GR-ID
               MOVE MIR-FND-ID  TO WS-WORK-FROM-CLONE-FUND-CODE
           END-IF.

           MOVE MIR-PLAN-ID-2       TO WFR-PLAN-ID.
           MOVE MIR-FND-ID-2        TO WFR-FND-ID.
012135     MOVE MIR-SBSDRY-CO-ID-2  TO WFR-SBSDRY-CO-ID.
012135     MOVE MIR-LOC-GR-ID-2     TO WFR-LOC-GR-ID.

           PERFORM  FR-1000-READ
               THRU FR-1000-READ-X.

           IF WFR-IO-NOT-FOUND
      *
      *        VALID CONTROL FIELDS MUST HAVE BEEN ENTERED
      *
               PERFORM  7500-EDIT-KEY-FIELDS
                   THRU 7500-EDIT-KEY-FIELDS-X
               IF WS-DATA-EDITS-FAILED
                    GO TO 6500-PROCESS-CLONE-X
               ELSE
      *
      *            READ THE RECORD TO BE CLONED
      *
                   MOVE WS-WORK-FROM-CLONE-KEY
                                           TO WFR-PLAN-FND-REST-KEY-INFO
                   PERFORM  FR-1000-READ
                       THRU FR-1000-READ-X
015543             PERFORM  6510-FR-READ-CLONE-CHECK
015543                 THRU 6510-FR-READ-CLONE-CHECK-X
               END-IF
           ELSE
      *MSG:    FUND/PLAN RELATIONSHIP (@1) RECORD ALREADY EXISTS
               MOVE 'SS00400003'      TO WGLOB-MSG-REF-INFO
               MOVE WFR-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6500-PROCESS-CLONE-X
           END-IF.

           MOVE 'SS00400002'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6500-PROCESS-CLONE-X.
           EXIT.

015543 6510-FR-READ-CLONE-CHECK.
015543
015543     IF WFR-IO-NOT-FOUND
015543*MSG:   RECORD (@1) LOST IN CLONE - CONTACT SYSTEMS
015543         MOVE WFR-KEY            TO WGLOB-MSG-PARM (1)
015543         MOVE 'XS00000143'       TO WGLOB-MSG-REF-INFO
015543         PERFORM  0260-1000-GENERATE-MESSAGE
015543             THRU 0260-1000-GENERATE-MESSAGE-X
015543     ELSE
015543*
015543*      MOVE NEW KEY TO RECORD AREAS AND WRITE NEW RECORD
015543*
015543         MOVE MIR-PLAN-ID-2    TO WFR-PLAN-ID
015543         MOVE MIR-SBSDRY-CO-ID-2
015543                                  TO WFR-SBSDRY-CO-ID
015543         MOVE MIR-LOC-GR-ID-2  TO WFR-LOC-GR-ID
015543         MOVE MIR-FND-ID-2     TO WFR-FND-ID
015543         MOVE WFR-PLAN-FND-REST-KEY-INFO
015543                             TO RFR-PLAN-FND-REST-KEY-INFO
015543         PERFORM  FR-1000-WRITE
015543             THRU FR-1000-WRITE-X
015543         MOVE 'XS00000197'   TO WGLOB-MSG-REF-INFO
015543         PERFORM  0260-1000-GENERATE-MESSAGE
015543             THRU 0260-1000-GENERATE-MESSAGE-X
015543         PERFORM  9200-MOVE-RECORD-TO-SCREEN
015543             THRU 9200-MOVE-RECORD-TO-SCREEN-X
015543     END-IF.
015543
015543 6510-FR-READ-CLONE-CHECK-X.
015543     EXIT.
      *
      *-------------------
       6800-PROCESS-CLONE-BACKOUT.
      *-------------------
      *****************************************************************
      *  CLONE PROCESSING:
      *      CLONE WAS NOT VERIFIED, BACKOUT
      *****************************************************************

      *MSG:    CLONING COMPLETED
           MOVE 'XS00000203'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6800-PROCESS-CLONE-BACKOUT-X.
           EXIT.
      *
      *------------------
       7100-BUILD-FR-KEY.
      *------------------
      *****************************************************************
      *  BUILD FR KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************

               MOVE MIR-PLAN-ID       TO WFR-PLAN-ID.
               MOVE MIR-FND-ID        TO WFR-FND-ID.
012135         MOVE MIR-SBSDRY-CO-ID  TO WFR-SBSDRY-CO-ID.
012135         MOVE MIR-LOC-GR-ID     TO WFR-LOC-GR-ID.

      *
      *        SAVE KEY ENTERED TO USE TO DETERMINE END BROWSE
      *
           IF WS-BUS-FCN-LIST
               MOVE MIR-PLAN-ID       TO WS-SAVE-PLAN-ID
557660     END-IF.

       7100-BUILD-FR-KEY-X.
           EXIT.
      *
      *----------------
       7300-DATA-EDITS.
      *----------------
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************

010314     MOVE MIR-FND-ID            TO WFH-FND-ID.

010314     PERFORM  FH-1000-READ
010314         THRU FH-1000-READ-X.

           MOVE WS-OK                 TO WS-DATA-EDITS.

           PERFORM  7310-EDIT-FDRQD
               THRU 7310-EDIT-FDRQD-X.

           PERFORM  7320-EDIT-MUTEX
               THRU 7320-EDIT-MUTEX-X.

           PERFORM  7330-EDIT-PTLSR
               THRU 7330-EDIT-PTLSR-X.

012136     PERFORM  7360-EDIT-FLFNDI
012136         THRU 7360-EDIT-FLFNDI-X.

           PERFORM  7340-EDIT-MINOP
               THRU 7340-EDIT-MINOP-X.

           PERFORM  7350-EDIT-MNREM
               THRU 7350-EDIT-MNREM-X.

       7300-DATA-EDITS-X.
           EXIT.
      *
      *----------------
       7310-EDIT-FDRQD.
      *----------------
      *****************************************************************
      *  FDRQD: FUND REQUIRED INDICATOR MUST BE O OR R
      *****************************************************************
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-FND-REQIR-CD = SPACES
557659*        MOVE RFR-REQIR-FND-IND TO MIR-PLAN-FND-REQIR-CD
557659         MOVE RFR-PLAN-FND-REQIR-CD
                                      TO MIR-PLAN-FND-REQIR-CD
               GO TO 7310-EDIT-FDRQD-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-FND-REQIR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-FND-REQIR-CD
557660     END-IF.
      *
      *  EDIT FUND REQUIRED INDICATOR
      *
           MOVE MIR-PLAN-FND-REQIR-CD TO WS-FDRQD.

           IF WS-FDRQD-VALID
557659*        MOVE MIR-PLAN-FND-REQIR-CD        TO RFR-REQIR-FND-IND
557659         MOVE MIR-PLAN-FND-REQIR-CD
                                      TO RFR-PLAN-FND-REQIR-CD
           ELSE
               MOVE 'SS00400005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.

010314     IF RFH-FND-TYP-INDEXED
010314        IF NOT WS-FDRQD-FUND-REQD
010314* MSG: FUND REQUIRED IND MUST EQUAL 'R' FOR EIA PLAN
010314           MOVE 'SS00400012'    TO WGLOB-MSG-REF-INFO
010314           PERFORM  0260-1000-GENERATE-MESSAGE
010314               THRU 0260-1000-GENERATE-MESSAGE-X
010314           MOVE WS-FAILED       TO WS-DATA-EDITS
010314        END-IF
010314     END-IF.

       7310-EDIT-FDRQD-X.
           EXIT.
      *
      *----------------
       7320-EDIT-MUTEX.
      *----------------
      *****************************************************************
      *  MUTEX: MUTUAL-EXCL-IND MUST BE Y OR N
      *****************************************************************
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MUT-EXCL-IND = SPACES
               MOVE RFR-MUT-EXCL-IND  TO MIR-MUT-EXCL-IND
               GO TO 7320-EDIT-MUTEX-X
           END-IF.
010314*
010314*  BYPASS EDITS FOR EIA PLANS
010314*
010314     IF RFH-FND-TYP-INDEXED
010314         GO TO 7320-EDIT-MUTEX-X
010314     END-IF.

      *  RESET FIELD TO BLANK VALUE

           IF MIR-MUT-EXCL-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-MUT-EXCL-IND
           END-IF.

      *  EDIT MUTUALLY EXCLUSIVE FUND INDICATOR

           MOVE MIR-MUT-EXCL-IND      TO WS-MUTEX.

           IF WS-MUTEX-VALID
               MOVE MIR-MUT-EXCL-IND  TO RFR-MUT-EXCL-IND
           ELSE
               MOVE 'SS00400006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           END-IF.

       7320-EDIT-MUTEX-X.
           EXIT.
      *
      *----------------
       7330-EDIT-PTLSR.
      *----------------
      *****************************************************************
      *  PTLSR: FUND REQUIRED INDICATOR MUST BE Y OR N
      *****************************************************************
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PSUR-ALLOW-IND = SPACES
               MOVE RFR-PSUR-ALLOW-IND TO MIR-PSUR-ALLOW-IND
               GO TO 7330-EDIT-PTLSR-X
557660     END-IF.
010314*
010314*  BYPASS EDITS FOR EIA PLANS
010314*
010314     IF RFH-FND-TYP-INDEXED
010314         GO TO 7330-EDIT-PTLSR-X
010314     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PSUR-ALLOW-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PSUR-ALLOW-IND
557660     END-IF.
      *
      *  EDIT FUND PARTIAL SURRENDER INDICATOR
      *
           MOVE MIR-PSUR-ALLOW-IND    TO WS-PTLSR.

           IF WS-PTLSR-VALID
               MOVE MIR-PSUR-ALLOW-IND TO RFR-PSUR-ALLOW-IND
           ELSE
               MOVE 'SS00400006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.

       7330-EDIT-PTLSR-X.
           EXIT.
      *
      *----------------
       7340-EDIT-MINOP.
      *----------------
      *****************************************************************
      *  MINOP: FUND MINIMUM TO OPEN MUST BE A POSITIVE VALUE OR ZERO
      *****************************************************************
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MIN-OPN-AMT = SPACES
008455*        MOVE RFR-MIN-OPN-AMT      TO WS-PIC-7V99
008455*        MOVE WS-PIC-7V99          TO MIR-MIN-OPN-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFR-MIN-OPN-AMT * 100
020874         MOVE RFR-MIN-OPN-AMT      TO L0290-INPUT-V02
008455         PERFORM  9250-FORMAT-MINOP
008455             THRU 9250-FORMAT-MINOP-X
               GO TO 7340-EDIT-MINOP-X
557660     END-IF.
010314*
010314*  BYPASS EDITS FOR EIA PLANS
010314*
010314     IF RFH-FND-TYP-INDEXED
010314         GO TO 7340-EDIT-MINOP-X
010314     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-OPN-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZERO                 TO WS-PIC-7V99
008455*        MOVE WS-PIC-7V99          TO MIR-MIN-OPN-AMT
008455         MOVE ZEROS             TO MIR-MIN-OPN-AMT
557660     END-IF.
      *
      *  EDIT FUND PARTIAL SURRENDER INDICATOR
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
008455*    MOVE 7                        TO L0280-LENGTH.
           MOVE 2                     TO L0280-PRECISION.
           MOVE MIR-MIN-OPN-AMT       TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-MIN-OPN-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
557660         THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
008455*        MOVE L0280-OUTPUT-DOLLAR  TO WS-PIC-7V99
008455*        MOVE WS-PIC-7V99          TO MIR-MIN-OPN-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         PERFORM  9250-FORMAT-MINOP
008455             THRU 9250-FORMAT-MINOP-X
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RFR-MIN-OPN-AMT
           ELSE
               MOVE 'SS00400007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.

       7340-EDIT-MINOP-X.
           EXIT.
      *
      *----------------
       7350-EDIT-MNREM.
      *----------------
      *****************************************************************
      *  MNREM: FUND MINIMUM REMAINING MUST BE A POSITIVE VALUE OR ZERO
      *****************************************************************
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MIN-REMN-AMT = SPACES
008455*        MOVE RFR-MIN-REMN-AMT      TO WS-PIC-7V99
008455*        MOVE WS-PIC-7V99           TO MIR-MIN-REMN-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFR-MIN-REMN-AMT * 100
020874         MOVE RFR-MIN-REMN-AMT      TO L0290-INPUT-V02
008455         PERFORM  9252-FORMAT-MNREM
008455             THRU 9252-FORMAT-MNREM-X
               GO TO 7350-EDIT-MNREM-X
557660     END-IF.
010314*
010314*  BYPASS EDITS FOR EIA PLANS
010314*
010314     IF RFH-FND-TYP-INDEXED
010314         GO TO 7350-EDIT-MNREM-X
010314     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-REMN-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZERO                  TO WS-PIC-7V99
008455*        MOVE WS-PIC-7V99           TO MIR-MIN-REMN-AMT
008455         MOVE ZEROS             TO MIR-MIN-REMN-AMT
557660     END-IF.
      *
      *  EDIT FUND PARTIAL SURRENDER INDICATOR
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
008455*    MOVE 7                         TO L0280-LENGTH.
           MOVE 2                     TO L0280-PRECISION.
           MOVE MIR-MIN-REMN-AMT      TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-MIN-REMN-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
557660         THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
008455*        MOVE L0280-OUTPUT-DOLLAR   TO WS-PIC-7V99
008455*        MOVE WS-PIC-7V99           TO MIR-MIN-REMN-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         PERFORM  9252-FORMAT-MNREM
008455             THRU 9252-FORMAT-MNREM-X
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RFR-MIN-REMN-AMT
           ELSE
               MOVE 'SS00400007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.

       7350-EDIT-MNREM-X.
           EXIT.
      *
012136*-----------------
012136 7360-EDIT-FLFNDI.
012136*-----------------
012136*****************************************************************
012136*  FLFNDI: FREE LOOK FUND INDICATOR MUST BE I OR N
012136*****************************************************************
012136*
012136*  DATA NOT ENTERED, REFRESH MIR AND EXIT
012136*
015905*    IF MIR-DV-FREE-LK-FND-CD = SPACES
015905*        MOVE RFR-FREE-LK-FND-CD TO MIR-DV-FREE-LK-FND-CD
015905     IF MIR-FREE-LK-FND-CD = SPACES
015905         MOVE RFR-FREE-LK-FND-CD TO MIR-FREE-LK-FND-CD
012136         GO TO 7360-EDIT-FLFNDI-X
012136     END-IF.
012136*
012136*  RESET FIELD TO BLANK VALUE
012136*
015905*    IF MIR-DV-FREE-LK-FND-CD = EBLCH-BLANK-FIELD-CHAR
015905*        MOVE SPACES            TO MIR-DV-FREE-LK-FND-CD
015905     IF MIR-FREE-LK-FND-CD = EBLCH-BLANK-FIELD-CHAR
015905         MOVE SPACES            TO MIR-FREE-LK-FND-CD
012136     END-IF.
012136*
012136*  EDIT FREE LOOK FUND INDICATOR
012136*
015905*    MOVE MIR-DV-FREE-LK-FND-CD    TO WS-FLFNDI.
015905     MOVE MIR-FREE-LK-FND-CD       TO WS-FLFNDI.
012136
012136     IF WS-FLFNDI-VALID
015905*        MOVE MIR-DV-FREE-LK-FND-CD
015905         MOVE MIR-FREE-LK-FND-CD
                                      TO RFR-FREE-LK-FND-CD
012136     ELSE
012136*MSG:INVALID FREE LOOK FUND DESIGNATION CODE. VALID ONLY I OR N.
012136         MOVE 'SS00400013'      TO WGLOB-MSG-REF-INFO
012136         PERFORM  0260-1000-GENERATE-MESSAGE
012136             THRU 0260-1000-GENERATE-MESSAGE-X
012136         MOVE WS-FAILED         TO WS-DATA-EDITS
012136     END-IF.
012136
012136 7360-EDIT-FLFNDI-X.
012136     EXIT.
012136*
      *---------------------
       7500-EDIT-KEY-FIELDS.
      *---------------------
      *****************************************************************
      *  EDIT KEY FIELDS : ALL KEY FIELDS MUST BE EDITED FOR VALID
      *  VALUES BEFORE A CREATE WILL BE ALLOWED.
      *****************************************************************

           MOVE WS-OK                 TO WS-DATA-EDITS.

010314     MOVE MIR-PLAN-ID      TO WPH-PLAN-ID.

010314     PERFORM  PH-1000-READ
010314         THRU PH-1000-READ-X.

010314     IF NOT WPH-IO-OK
010314         MOVE 'SS00400009'      TO WGLOB-MSG-REF-INFO
010314* MSG: INVALID PLAN CODE.
010314         PERFORM  0260-1000-GENERATE-MESSAGE
010314             THRU 0260-1000-GENERATE-MESSAGE-X
010314         MOVE WS-FAILED         TO WS-DATA-EDITS
010314     END-IF.

010314*     PERFORM 7510-EDIT-PLAN-RS
010314*        THRU 7510-EDIT-PLAN-RS-X.

012135     PERFORM  7540-EDIT-KEY-SBSDRY-CO
012135         THRU 7540-EDIT-KEY-SBSDRY-CO-X

012135     PERFORM  7550-EDIT-KEY-LOC-GR-ID
012135         THRU 7550-EDIT-KEY-LOC-GR-ID-X

           PERFORM  7520-EDIT-KEY-FUND
               THRU 7520-EDIT-KEY-FUND-X

020469     PERFORM  7525-EDIT-CRCY-CD
020469         THRU 7525-EDIT-CRCY-CD-X.
020469
010314     IF RFH-FND-TYP-INDEXED
010314        PERFORM  7530-EDIT-INDEX-FUND
010314            THRU 7530-EDIT-INDEX-FUND-X
010314     ELSE
010314        PERFORM  7510-EDIT-PLAN-RS
010314            THRU 7510-EDIT-PLAN-RS-X
010314     END-IF.

       7500-EDIT-KEY-FIELDS-X.
           EXIT.
      *
      *------------------
       7510-EDIT-PLAN-RS.
      *------------------
      *****************************************************************
      *  PLAN CODE AND RATE SCALE MUST BE KEY TO AN FX RECORD
      *****************************************************************
      *
      *    READ FX FILE TO MAKE SURE RECORD EXISTS FOR PLAN CODE /
      *    RATE SCALE ENTERED.
      *
           PERFORM  8100-BUILD-FX-KEY
               THRU 8100-BUILD-FX-KEY-X.
           PERFORM  FX-1000-READ
               THRU FX-1000-READ-X.

           IF NOT WFX-IO-OK
               MOVE 'SS00400004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.

       7510-EDIT-PLAN-RS-X.
           EXIT.
      *
      *-------------------
       7520-EDIT-KEY-FUND.
      *-------------------
      *****************************************************************
      *  EDIT KEY: FUND CODE
      *****************************************************************

           MOVE MIR-FND-ID            TO WFH-FND-ID.
           PERFORM  FH-1000-READ
               THRU FH-1000-READ-X.

           IF NOT WFH-IO-OK
               MOVE 'SS00400008'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FND-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.

       7520-EDIT-KEY-FUND-X.
           EXIT.
      *
020469*------------------
020469 7525-EDIT-CRCY-CD.
020469*------------------
020469*****************************************************************
020469*  IF MULTI-CURRENCY RULES DO NOT APPLY TO THE PLAN THEN THE
020469*  CURRENCY CODE ON FUND HEADER MUST EQUAL THE CURRENCY CODE
020469*  ON THE PLAN HEADER.
020469*  IF MULTI-CURRENCY DOES APPLY THERE IS NO NEED FOR THE EDIT.
020469*****************************************************************
020469
020469* READ PLAN DEFAULTS TABLE TO ACCESS THE MULTI-CURRENCY INDICATOR
020469
020469     MOVE MIR-PLAN-ID           TO WPD-PLAN-ID.
020469
020469     PERFORM  PD-1000-READ
020469         THRU PD-1000-READ-X.
020469
020469     IF  NOT WPD-IO-OK
020469* MSG: PLAN (@1) NOT FOUND IN PLAN DEFAULT
020469         MOVE 'SS00400014'      TO WGLOB-MSG-REF-INFO
020469         MOVE MIR-PLAN-ID       TO WGLOB-MSG-PARM (1)
020469         PERFORM  0260-1000-GENERATE-MESSAGE
020469             THRU 0260-1000-GENERATE-MESSAGE-X
020469         MOVE WS-FAILED         TO WS-DATA-EDITS
020469     END-IF.
020469
020469* IF MULTI-CURRENCY RULES APPLY TO THE PLAN THEN DO
020469* NOT PERFORM THE EDIT
020469
020469     IF  RPD-PLAN-MULT-CRCY
020469         GO TO 7525-EDIT-CRCY-CD-X
020469     END-IF.
020469
020469* MULTI-CURRENCY RULES DO NOT APPLY - THEREFORE THE
020469* CURRENCY CODE ON FUND HEADER MUST EQUAL THE CURRENCY
020469* CODE ON PLAN HEADER.
020469
020469     IF  RFH-FND-CRCY-CD = RPH-PLAN-CRCY-CD
020469         CONTINUE
020469     ELSE
020469* MSG: CURRENCY ON FUND HEADER NOT EQUAL CURRENCY ON PLAN HEADER
020469         MOVE 'SS00400015'      TO WGLOB-MSG-REF-INFO
020469         PERFORM  0260-1000-GENERATE-MESSAGE
020469             THRU 0260-1000-GENERATE-MESSAGE-X
020469         MOVE WS-FAILED         TO WS-DATA-EDITS
020469         GO TO 7525-EDIT-CRCY-CD-X
020469     END-IF.
020469
020469 7525-EDIT-CRCY-CD-X.
020469     EXIT.
020469*
010314*--------------------
010314 7530-EDIT-INDEX-FUND.
010314*-------------------

010314*  EDIT TO MAKE SURE INDEX FUND ONLY ATTACTED TO EIA PLAN.

010314     IF NOT RPH-PLAN-CF-TYP-EIA
010314           MOVE 'SS00400010'    TO WGLOB-MSG-REF-INFO
010314* MSG: INDEXED FUNDS ONLY ALLOWED ON EQUITY INDEXED ANNUITY PLAN
010314           PERFORM  0260-1000-GENERATE-MESSAGE
010314               THRU 0260-1000-GENERATE-MESSAGE-X
010314           MOVE WS-FAILED       TO WS-DATA-EDITS
010314           GO TO 7530-EDIT-INDEX-FUND-X
010314     END-IF.

010314     PERFORM  7100-BUILD-FR-KEY
010314         THRU 7100-BUILD-FR-KEY-X.

012135     MOVE SPACES                TO WFR-SBSDRY-CO-ID.
012135     MOVE SPACES                TO WFR-LOC-GR-ID.
010314     MOVE SPACES                TO WFR-FND-ID.
010314*
010314*    POSITION AT AND READ FIRST RECORD.
010314*
010314     MOVE WFR-KEY               TO WFR-ENDBR-KEY.
010314     MOVE HIGH-VALUES           TO WFR-ENDBR-FND-ID.
012135     MOVE HIGH-VALUES           TO WFR-ENDBR-SBSDRY-CO-ID.
012135     MOVE HIGH-VALUES           TO WFR-ENDBR-LOC-GR-ID.

010314     PERFORM  FR-1000-BROWSE
010314         THRU FR-1000-BROWSE-X.

010314     IF NOT WFR-IO-OK
010314        GO TO 7530-EDIT-INDEX-FUND-X
010314     END-IF.

010314     PERFORM  FR-2000-READ-NEXT
010314         THRU FR-2000-READ-NEXT-X.
010314     IF WFR-IO-OK
010314        IF  MIR-PLAN-ID = RFR-PLAN-ID
010314*MSG: RELATIONSHIP FOR EIA PLAN (@1) ALREADY EXISTS
010314            MOVE 'SS00400011'   TO WGLOB-MSG-REF-INFO
010314            MOVE RFR-PLAN-ID    TO WS-PLAN-ID
010314            MOVE WS-PLAN-ID     TO WGLOB-MSG-PARM (1)
010314            PERFORM  0260-1000-GENERATE-MESSAGE
010314                THRU 0260-1000-GENERATE-MESSAGE-X
010314            MOVE WS-FAILED      TO WS-DATA-EDITS
010314        END-IF
010314     END-IF.

010314     PERFORM  FR-3000-END-BROWSE
010314         THRU FR-3000-END-BROWSE-X.

010314 7530-EDIT-INDEX-FUND-X.
010314     EXIT.
      *
012135*------------------------
012135 7540-EDIT-KEY-SBSDRY-CO.
012135*------------------------
012135
012135*    GET SUB-COMPANY PROFILE
012135
012135     MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.
012135
012135     PERFORM  SCOM-2000-READ-INDEX
012135         THRU SCOM-2000-READ-INDEX-X.
012135
012135     IF NOT WSCOM-IO-OK
012135         MOVE MIR-SBSDRY-CO-ID  TO WGLOB-MSG-PARM (1)
012135         MOVE WS-FAILED         TO WS-DATA-EDITS
012135         MOVE 'XS00000234'      TO WGLOB-MSG-REF-INFO
012135         PERFORM  0260-1000-GENERATE-MESSAGE
012135             THRU 0260-1000-GENERATE-MESSAGE-X
012135     END-IF.
012135
012135 7540-EDIT-KEY-SBSDRY-CO-X.
012135     EXIT.
012135*
012135*------------------------
012135 7550-EDIT-KEY-LOC-GR-ID.
012135*------------------------
012135
012135     MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.
012135
012135     PERFORM  LGAS-1000-EDIT-LGAS-LOCATION
012135         THRU LGAS-1000-EDIT-LGAS-LOCATION-X.
012135
012135     IF  WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
012135     ELSE
012135         MOVE MIR-LOC-GR-ID     TO WGLOB-MSG-PARM (1)
012135*MSG: LOC GROUP NOT VALID - CHECK EDIT TYPE 'LOCGP'
012135         MOVE 'XS00000235'      TO WGLOB-MSG-REF-INFO
012135         MOVE WS-FAILED         TO WS-DATA-EDITS
012135         PERFORM  0260-1000-GENERATE-MESSAGE
012135             THRU 0260-1000-GENERATE-MESSAGE-X
012135     END-IF.
012135
012135 7550-EDIT-KEY-LOC-GR-ID-X.
012135     EXIT.
012135*
      *------------------
       8100-BUILD-FX-KEY.
      *------------------
      *****************************************************************
      *  BUILD FX KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************

           MOVE MIR-PLAN-ID           TO WFX-PLAN-ID.

       8100-BUILD-FX-KEY-X.
           EXIT.
      *
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      *
      *    BLANK OUT DATA ON GIVEN SCREEN
      *
           PERFORM  9110-BLANK-DATA-FIELDS-1
               THRU 9110-BLANK-DATA-FIELDS-1-X
012135     VARYING WS-LINES FROM 1 BY 1
012135         UNTIL WS-LINES > WS-DISPLAY-LINES.

           PERFORM  9120-BLANK-DATA-FIELDS-2
               THRU 9120-BLANK-DATA-FIELDS-2-X.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *-------------------------
       9110-BLANK-DATA-FIELDS-1.
      *-------------------------
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 1
      *****************************************************************

012135     MOVE SPACES                TO MIR-FND-ID-T (WS-LINES).
012135     MOVE SPACES                TO MIR-LOC-GR-ID-T (WS-LINES).
012135     MOVE SPACES                TO MIR-SBSDRY-CO-ID-T (WS-LINES).

       9110-BLANK-DATA-FIELDS-1-X.
           EXIT.

      *-------------------------
       9120-BLANK-DATA-FIELDS-2.
      *-------------------------
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 2
      *****************************************************************

           MOVE SPACES                TO MIR-PLAN-FND-REQIR-CD.
           MOVE SPACES                TO MIR-MUT-EXCL-IND.
           MOVE SPACES                TO MIR-PSUR-ALLOW-IND.
015905*    MOVE SPACES                TO MIR-DV-FREE-LK-FND-CD.
015905     MOVE SPACES                TO MIR-FREE-LK-FND-CD.
           MOVE SPACES                TO MIR-MIN-OPN-AMT.
           MOVE SPACES                TO MIR-MIN-REMN-AMT.

       9120-BLANK-DATA-FIELDS-2-X.
           EXIT.
      *
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      *
      *    MOVE DATA FOR GIVEN SCREEN
      *
557659*    MOVE RFR-REQIR-FND-IND         TO MIR-PLAN-FND-REQIR-CD.
557659     MOVE RFR-PLAN-FND-REQIR-CD TO MIR-PLAN-FND-REQIR-CD.
           MOVE RFR-MUT-EXCL-IND      TO MIR-MUT-EXCL-IND.
           MOVE RFR-PSUR-ALLOW-IND    TO MIR-PSUR-ALLOW-IND.
015905*    MOVE RFR-FREE-LK-FND-CD    TO MIR-DV-FREE-LK-FND-CD.
015905     MOVE RFR-FREE-LK-FND-CD    TO MIR-FREE-LK-FND-CD.
008455*    MOVE RFR-MIN-OPN-AMT           TO WS-PIC-7V99.
008455*    MOVE WS-PIC-7V99               TO MIR-MIN-OPN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFR-MIN-OPN-AMT * 100.
020874     MOVE RFR-MIN-OPN-AMT       TO L0290-INPUT-V02.
008455     PERFORM  9250-FORMAT-MINOP
008455         THRU 9250-FORMAT-MINOP-X.
008455*    MOVE RFR-MIN-REMN-AMT          TO WS-PIC-7V99.
008455*    MOVE WS-PIC-7V99               TO MIR-MIN-REMN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFR-MIN-REMN-AMT * 100.
020874     MOVE RFR-MIN-REMN-AMT      TO L0290-INPUT-V02.
008455     PERFORM  9252-FORMAT-MNREM
008455         THRU 9252-FORMAT-MNREM-X.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *------------------------
012135 9220-UPDATE-SCREEN-KEYS.
      *------------------------

012135     MOVE RFR-FND-ID            TO MIR-FND-ID.
012135     MOVE RFR-SBSDRY-CO-ID      TO MIR-SBSDRY-CO-ID.
012135     MOVE RFR-LOC-GR-ID         TO MIR-LOC-GR-ID.

       9220-UPDATE-SCREEN-KEYS-X.
           EXIT.
      *
008455*------------------
008455 9250-FORMAT-MINOP.
008455*------------------
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-OPN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-OPN-AMT.
008455 9250-FORMAT-MINOP-X.
008455     EXIT.
008455*
008455*------------------
008455 9252-FORMAT-MNREM.
008455*------------------
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-REMN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-REMN-AMT.
008455 9252-FORMAT-MNREM-X.
008455     EXIT.
008455*
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     SET WS-OK-DEFAULT            TO TRUE.
025970     SET WS-FAILED-DEFAULT        TO TRUE.
025970     SET WS-DISPLAY-LINES-DEFAULT TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.

025970     MOVE SPACES                  TO WS-WORK-AREA.

025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY FH
014221                         '$VAR2' BY 'FH'.

       COPY XCPPEXIT.
      *
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
008455*
008455 COPY XCPL0290.
008455 COPY XCPS0290.
014221*
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
       COPY XCPPINIT.
      *
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
010314 COPY CCPNPH.
      *
020469 COPY CCPNPD.
020469*
       COPY SCPCFR.
      *
       COPY SCPAFR.
      *
       COPY SCPBFR.
      *
       COPY SCPNFR.
      *
       COPY SCPUFR.
      *
       COPY SCPXFR.
      *
       COPY SCPNFX.
      *
       COPY SCPNFH.
014221 COPY SCPUFH.
      *
012135 COPY CCPNSCOM.
012135 COPY CCPELGAS.
012135 COPY CCPNEDIT.
012135*
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM SSOM0040                     **
      *****************************************************************
