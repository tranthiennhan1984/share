      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM0730.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0730                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RETRIEVE FUNCTION       **
      **            FOR THE GUIDELINE PREMIUM ACTIVITY RECORDS.      **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0730'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-RETRIEVE           VALUE '0730'.
           05  WS-EFF-DT                         PIC X(10).
           05  WS-SEQ-NUM                        PIC S9(3) COMP-3.
           05  WS-CVG-NUM                        PIC 99.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
       COPY CCWWLOCK.
       COPY XCWWCNST.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0620.
       COPY CCWL2430.
       COPY CCWL5395.
       COPY CCWL5400.

       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1670.
       COPY XCWL1680.
       COPY XCWL8090.
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0730.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0730'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                         TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *--------------
       2000-RETRIEVE.
      *--------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  3000-GET-RECORD-INFO
               THRU 3000-GET-RECORD-INFO-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.

      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  2110-EDIT-POLICY
               THRU 2110-EDIT-POLICY-X.

           PERFORM  2120-EDIT-EFF-DT
               THRU 2120-EDIT-EFF-DT-X.

           PERFORM  2130-EDIT-CVG-NUM
               THRU 2130-EDIT-CVG-NUM-X.

           PERFORM  2140-EDIT-SEQ-NUM
               THRU 2140-EDIT-SEQ-NUM-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       2110-EDIT-POLICY.
      *-----------------

           MOVE MIR-POL-ID-BASE          TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX           TO WPOL-POL-ID-SFX.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  NOT WPOL-IO-OK
               SET WGLOB-RETURN-ERROR    TO TRUE
               MOVE 'CS00000019'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET L5400-CRCY-MSG-REQD       TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2110-EDIT-POLICY-X.
           EXIT.

      *-----------------
       2120-EDIT-EFF-DT.
      *-----------------

           MOVE MIR-GDLN-EFF-DT          TO L1640-EXTERNAL-DATE
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-INTERNAL-DATE = WWKDT-ZERO-DT
               MOVE 'CS00000054'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
           END-IF.

       2120-EDIT-EFF-DT-X.
           EXIT.

      *--------------------
       2130-EDIT-CVG-NUM.
      *--------------------

           IF  MIR-CVG-NUM = ZERO
           OR  MIR-CVG-NUM = SPACES
               MOVE ZERO                 TO WS-CVG-NUM
               GO TO 2130-EDIT-CVG-NUM-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE LENGTH OF MIR-CVG-NUM
                                         TO L0280-LENGTH.
           MOVE ZERO                     TO L0280-PRECISION.
           MOVE MIR-CVG-NUM              TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT         TO WS-CVG-NUM
               IF  WS-CVG-NUM > RPOL-POL-CVG-REC-CTR-N
      *MSG: THE COVERAGE MUST BE A NUMBER IN THE RANGE FROM 00 TO (@1)
                   MOVE 'CS00000055'     TO WGLOB-MSG-REF-INFO
                   MOVE RPOL-POL-CVG-REC-CTR
                                         TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
               END-IF
           ELSE
      *MSG:    'COVERAGE MUST BE NUMERIC'
               MOVE 'XS00000079'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2130-EDIT-CVG-NUM-X.
           EXIT.

      *-------------------
       2140-EDIT-SEQ-NUM.
      *-------------------

           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE LENGTH OF MIR-GDLN-SEQ-NUM
                                         TO L0280-LENGTH.
           MOVE ZERO                     TO L0280-PRECISION.
           MOVE MIR-GDLN-SEQ-NUM         TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT         TO WS-SEQ-NUM
               IF  WS-SEQ-NUM = ZERO
      *MSG:        INVALID SEQUENCE NUMBER
                   MOVE 'CS07300001'     TO WGLOB-MSG-REF-INFO
                   MOVE MIR-GDLN-SEQ-NUM TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
               END-IF
           ELSE
      *MSG:    INVALID SEQUENCE NUMBER
               MOVE 'CS07300001'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-GDLN-SEQ-NUM     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2140-EDIT-SEQ-NUM-X.
           EXIT.

      *----------------------
       3000-GET-RECORD-INFO.
      *----------------------

           PERFORM  5395-1000-BUILD-PARM-INFO
               THRU 5395-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID              TO L5395-POL-ID
           MOVE WS-EFF-DT                TO L5395-GDLN-EFF-DT
           MOVE WS-SEQ-NUM               TO L5395-GDLN-SEQ-NUM
           MOVE WS-CVG-NUM               TO L5395-CVG-NUM
           PERFORM  5395-1000-GDLN-RETRIEVE
               THRU 5395-1000-GDLN-RETRIEVE-X
           IF  NOT L5395-RETRN-OK
      *MSG: 'RECORD NOT FOUND'
               MOVE 'CS00000026'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR
                                         TO TRUE
           END-IF.

       3000-GET-RECORD-INFO-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                    TO MIR-SBSDRY-CO-ID.
           MOVE SPACE                    TO MIR-DV-OWN-CLI-NM.
           MOVE SPACE                    TO MIR-POL-GDLN-SPREM-AMT.
           MOVE SPACE                    TO MIR-POL-GDLN-APREM-AMT.
           MOVE SPACE                    TO MIR-ACUM-GDLN-PREM-AMT.
           MOVE SPACE                    TO MIR-DV-REMN-GDLN-AMT.
           MOVE SPACE                    TO MIR-PCHST-SEQ-NUM.
           MOVE SPACE                    TO MIR-GDLN-STAT-CD.
           MOVE SPACE                    TO MIR-GDLN-REASN-CD.
           MOVE SPACE                    TO MIR-CVG-GDLN-SPREM-AMT.
           MOVE SPACE                    TO MIR-CVG-GDLN-APREM-AMT.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           MOVE RPOL-SBSDRY-CO-ID        TO MIR-SBSDRY-CO-ID.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID              TO L2430-POL-ID.
           MOVE ZERO                     TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE                L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM
                                         TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                         TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                         TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                         TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD     TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME    TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES               TO MIR-DV-OWN-CLI-NM
           END-IF.

           MOVE L5395-POL-GDLN-SPREM-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-GDLN-SPREM-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-POL-GDLN-SPREM-AMT.

           MOVE L5395-POL-GDLN-APREM-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-GDLN-APREM-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-POL-GDLN-APREM-AMT.

           MOVE L5395-ACUM-GDLN-PREM-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-ACUM-GDLN-PREM-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-ACUM-GDLN-PREM-AMT.

           IF  L5395-POL-GDLN-SPREM-AMT  >  L5395-POL-GDLN-APREM-AMT
               COMPUTE L0290-INPUT-V02   =  L5395-POL-GDLN-SPREM-AMT
                                         -  L5395-ACUM-GDLN-PREM-AMT
           ELSE
               COMPUTE L0290-INPUT-V02   =  L5395-POL-GDLN-APREM-AMT
                                         -  L5395-ACUM-GDLN-PREM-AMT
           END-IF.

           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-REMN-GDLN-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-REMN-GDLN-AMT.

           IF  L5395-PCHST-SEQ-NUM = ZERO
               MOVE L5395-PCHST-SEQ-NUM  TO L0290-INPUT-V00
           ELSE
               COMPUTE L0290-INPUT-V00 = WCNST-MAX-PCHST-SEQ-NUM-N
                                       - L5395-PCHST-SEQ-NUM
           END-IF
           MOVE ZERO                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PCHST-SEQ-NUM
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PCHST-SEQ-NUM.

           MOVE L5395-GDLN-STAT-CD       TO MIR-GDLN-STAT-CD.
           MOVE L5395-GDLN-REASN-CD      TO MIR-GDLN-REASN-CD.

           IF  WS-CVG-NUM = ZERO
               GO TO 9200-MOVE-RECORD-TO-MIR-X
           END-IF.

           MOVE L5395-CVG-GDLN-APREM-AMT (WS-CVG-NUM)
                                         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CVG-GDLN-APREM-AMT.

           MOVE L5395-CVG-GDLN-SPREM-AMT (WS-CVG-NUM)
                                         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CVG-GDLN-SPREM-AMT.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  1670-0000-INIT-PARM-INFO
               THRU 1670-0000-INIT-PARM-INFO-X.

           PERFORM  1680-0000-INIT-PARM-INFO
               THRU 1680-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  5395-0000-INIT-PARM-INFO
               THRU 5395-0000-INIT-PARM-INFO-X.

           PERFORM  5400-0000-INIT-PARM-INFO
               THRU 5400-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-AREA.
           INITIALIZE FREQUENTLY-USED-INDICES.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY CCPS0620.
       COPY CCPL0620.
      /
       COPY CCPS2430.
       COPY CCPL2430.
      /
       COPY CCPS5395.
       COPY CCPL5395.
      /
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY XCPL0260.
      /
       COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPS1670.
       COPY XCPS1680.
       COPY XCPL1680.
      /
       COPY XCPL8090.
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **              END OF PROGRAM CSOM0730                        **
      *****************************************************************
