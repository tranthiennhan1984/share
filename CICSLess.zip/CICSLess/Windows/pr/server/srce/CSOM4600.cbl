      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4600.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4600                                         **
      **  REMARKS:  UNDO/REDO PROCESSING DRIVER (UNDR)               **
      **                                                             **
      **            PERFORMS AUTOMATIC UNDO/REDO OF CERTAIN POLICY   **
      **            ACTIVITIES. THESE ACTIVITIES INCLUDE             **
      **            MONTHIVERSARY PROCESSING AND PHST ACTIVITIES     **
      **            WHICH ARE DEFINED ON UTAB. UNDO PROCESSING ALSO  **
      **            INCLUDES THE REVERSAL OF TRADITIONAL PREMIUMS.   **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557708**  5.5       ABEND HANDLING                                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
014035**  5.6V      CODE CLEANUP AND STANDARDIZATION                 **
012624**  6.0       POLICY ACCESS VERIFICATION                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016440**  6.2       ADDITION OF POLICY TRANSFER EDITS                **
016503**  6.2       ADD CALL TO 0289 TO SET PARAMS FOR SCHEDULER     **
016548**  6.2       CHANGE COMP TO BINARY                            **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
026286**  6.7       ASSET RELALANCE PROCESS - UNDO ISSUE             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4600'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
      /
      /
025970 01  WS-CONSTANT-AREA.
025970     05  WS-TRANS-NAME                PIC X(04)  VALUE 'UNDR'.
025970         88  WS-TRANS-NAME-DEFAULT               VALUE 'UNDR'.
025970
       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'UNDR'.
025970*        88  WS-TRANS-NAME-DEFAULT               VALUE 'UNDR'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '0970' '0971'.
               88  WS-BUS-FCN-REDO          VALUE '0970'.
               88  WS-BUS-FCN-UNDO          VALUE '0971'.
           05  WS-INTERNAL-EFFDT.
               10  WS-INT-YYYY              PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-INT-MM                PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-INT-DD                PIC 9(02).
016548*    05  I                            PIC S9(4)  COMP.
016548     05  I                            PIC S9(4)  BINARY.
016503     05  WS-RETRN-CD                  PIC X(02).
016503         88  WS-RETRN-OK              VALUE '00'.
016503         88  WS-RETRN-ERROR           VALUE '01'.
      /
021930*COPY XCWWWKDT.
021930*
       COPY CCFWCVG.
       COPY CCFRCVG.

       COPY CCFHCVGS.
      /
       COPY CCFHPOL.
       COPY CCFWPOL.
      /
       COPY CCWL0201.
020478 COPY CCWL2626.
      /
013578 COPY CCWL0620.
      /
016108 COPY CCWL0985.
016108/
       COPY CCWL2430.
016440 COPY CCWL0289.
      /
       COPY CCWL4750.
      /
       COPY CCWL5400.
      /
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
014590*COPY XCWL0030.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY CCWLPGA.
      /
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM4600.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
      *   NORMAL PROCESSING: CHECK SECURITY PERMISSION & DISTRIBUTE
      *   CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      *
025970*    MOVE MIR-BUS-FCN-ID          TO  WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK            TO  TRUE.
025970*    SET  WS-RETRN-OK             TO  TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST    TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  2100-VALIDATE-KEY-FIELDS
               THRU 2100-VALIDATE-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
           OR  NOT WGLOB-GOOD-RETURN
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
      *   BUILD LPGA AREA
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.
      *
      *   READ IN COVERAGE RECORDS
      *
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           ELSE
014035*        MOVE WCVGS-WORK-AREA TO HCVGS-CVGS-INFO
014035         MOVE WCVGS-WORK-AREA   TO HCVGS-WORK-AREA
           END-IF.
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WS-INTERNAL-EFFDT     TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         SET WGLOB-RETURN-ERROR TO TRUE
016108         GO TO 2000-PROCESS-REQUEST-X
016108     END-IF.
020478     IF  MIR-DV-PRCES-STATE-CD NOT = '3'
020478         IF  WS-BUS-FCN-REDO
020478*MSG:  SCHEDULED ACTIVITIES WILL BE PROCESSED
020478             MOVE  'CS46000005'     TO WGLOB-MSG-REF-INFO
020478         ELSE
020478*MSG:  ACTIVITIES WILL BE REVERSED
020478             MOVE  'CS46000006'     TO WGLOB-MSG-REF-INFO
020478         END-IF
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478
020478         GO TO 2000-PROCESS-REQUEST-X
020478     END-IF.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           IF WS-BUS-FCN-UNDO
               PERFORM  3000-UNDO-PROCESS
                   THRU 3000-UNDO-PROCESS-X
           END-IF.

           IF WS-BUS-FCN-REDO
               PERFORM  4000-REDO-PROCESS
                   THRU 4000-REDO-PROCESS-X
           END-IF.

           PERFORM  2200-UPDATE-POLICY-CVG
               THRU 2200-UPDATE-POLICY-CVG-X.

016503     IF  WS-RETRN-ERROR
016503         SET WGLOB-RETURN-ERROR        TO TRUE
016503     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------------
       2100-VALIDATE-KEY-FIELDS.
      *-------------------------

      *
      * READ POLICY INFORMATION.
      *
           PERFORM  7000-READ-POLICY
               THRU 7000-READ-POLICY-X.

           IF  WGLOB-MSG-ERROR-SW > 0
           OR  NOT WGLOB-GOOD-RETURN
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

           PERFORM  7100-EDIT-NAME
               THRU 7100-EDIT-NAME-X.

           IF  WGLOB-MSG-ERROR-SW > 0
           OR  NOT WGLOB-GOOD-RETURN
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

           PERFORM  7200-VALIDATE-DATE
               THRU 7200-VALIDATE-DATE-X.

           IF  WGLOB-MSG-ERROR-SW > 0
           OR  NOT WGLOB-GOOD-RETURN
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

       2100-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      *-----------------------
       2200-UPDATE-POLICY-CVG.
      *-----------------------

016503*    IF  RPOL-REC-INFO NOT = HPOL-REC-INFO
016503*        PERFORM  7300-REWRITE-POLICY
016503*            THRU 7300-REWRITE-POLICY-X
016503*     END-IF.

016503      PERFORM  7300-REWRITE-POLICY
016503          THRU 7300-REWRITE-POLICY-X.

014035*    IF  WCVGS-WORK-AREA NOT = HCVGS-CVGS-INFO
026286*    IF  WCVGS-WORK-AREA NOT = HCVGS-WORK-AREA
026286*        PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
026286*            THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
026286*    END-IF.

026286     PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
026286         THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

       2200-UPDATE-POLICY-CVG-X.
           EXIT.
      /
      *------------------
       3000-UNDO-PROCESS.
      *------------------
      *
      * INVOKE MODULE TO UNDO PHST ACTIVITIES
      *
           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.

           MOVE  WS-INTERNAL-EFFDT    TO  L4750-EFF-DT.
           SET   L4750-PRCES-INCLUSIVE     TO  TRUE.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  L4750-RETRN-OK
      *MSG:  UNDO PROCESSING COMPLETED
               MOVE  'CS46000002'     TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
016503*        SET   WGLOB-RETURN-ERROR    TO  TRUE
016503         SET   WS-RETRN-ERROR        TO  TRUE
           END-IF.

       3000-UNDO-PROCESS-X.
           EXIT.
      /
      *------------------
       4000-REDO-PROCESS.
      *------------------
      *
      *  LINK TO 0201 TO SCHEDULE ALL EVENTS IN THE CORRECT ORDER
      *
           MOVE  WS-INTERNAL-EFFDT    TO  L0201-EFF-DT.

           PERFORM  0201-1000-AUTO-PROCESSING
               THRU 0201-1000-AUTO-PROCESSING-X.

           IF  L0201-RETRN-OK
      *MSG:  REDO PROCESSING COMPLETED
               MOVE  'CS46000003'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
016503*        SET   WGLOB-RETURN-ERROR    TO  TRUE
016503         SET   WS-RETRN-ERROR        TO  TRUE
           END-IF.

       4000-REDO-PROCESS-X.
           EXIT.
      /
      *-----------------
       7000-READ-POLICY.
      *-----------------

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF WPOL-IO-OK
               CONTINUE
           ELSE
      *MSG:  POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-READ-POLICY-X
           END-IF.

      *  ONLY PROCESS POLICIES IF STATUS IS INFORCE,
      *  AND STORE THE POLICY IN HOLD-POLICY AREA
      *
012624     IF  RPOL-POL-SUSPENDED
012624*MSGS: POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
012624         MOVE 'XS00000240'      TO WGLOB-MSG-REF-INFO
012624         PERFORM  0260-1000-GENERATE-MESSAGE
012624             THRU 0260-1000-GENERATE-MESSAGE-X
012624         IF  WGLOB-MSG-SEVRTY-FATAL
012624             SET WGLOB-RETURN-ERROR TO TRUE
012624             GO TO 7000-READ-POLICY-X
012624         END-IF
012624     END-IF.
012624
016440*     IF  RPOL-POL-APPL-CTL-NBS
016440     IF RPOL-POL-STAT-BEFORE-SETL
016440*MSGS: POLICY STATUS- CANNOT MAINTAIN OR PROCESS
012624         MOVE 'XS00000004'      TO WGLOB-MSG-REF-INFO
012624         PERFORM  0260-1000-GENERATE-MESSAGE
012624             THRU 0260-1000-GENERATE-MESSAGE-X
012624         IF  WGLOB-MSG-SEVRTY-FATAL
012624             SET WGLOB-RETURN-ERROR TO TRUE
012624             GO TO 7000-READ-POLICY-X
012624         END-IF
012624     END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    MOVE  WGLOB-APPL-ID        TO  L5400-SYS-APPL-CTL-CD.
           SET   L5400-CRCY-MSG-REQD   TO  TRUE.
016440     SET   L5400-POL-XFER-UPDATE TO  TRUE.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

012624*    IF  L5400-CTL-ACCS-RESTRICTED
012624*    OR  L5400-STAT-ACCS-RESTRICTED
012624     IF  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               SET  WGLOB-RETURN-ERROR TO  TRUE
           ELSE
               MOVE  RPOL-REC-INFO    TO  HPOL-REC-INFO
           END-IF.

       7000-READ-POLICY-X.
           EXIT.
      /
      *---------------
       7100-EDIT-NAME.
      *---------------

013578*    MOVE ZERO                  TO I.
013578*    PERFORM  2430-1000-BUILD-PARM-INFO
013578*        THRU 2430-1000-BUILD-PARM-INFO-X.
013578*
013578*    MOVE  MIR-DV-CLI-NM        TO  L2430-OWNER-NAME-1-4.
013578*
013578*    PERFORM  2430-5000-VALIDATE-OWNER-NM
013578*        THRU 2430-5000-VALIDATE-OWNER-NM-X.
013578*
013578*    IF  NOT L2430-RETRN-OK
013578*MSG: ENTER FIRST 4 LETTERS OF OWNER'S LAST NAME
013578*        MOVE 'CS46000004'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    END-IF.

013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE MIR-POL-ID                    TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.

       7100-EDIT-NAME-X.
           EXIT.
      /
      *-------------------
       7200-VALIDATE-DATE.
      *-------------------

           IF MIR-MTHV-EFF-DT-NUM = SPACES
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-MTHV-EFF-DT-NUM
           ELSE
               MOVE MIR-MTHV-EFF-DT-NUM
                                      TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF L1640-NOT-VALID
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-MTHV-EFF-DT-NUM
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
      *  DATE OK - MOVE TO WORKING STORAGE FIELD TO USE IN PROCESSING
      *
           MOVE L1640-INTERNAL-DATE   TO WS-INTERNAL-EFFDT.

       7200-VALIDATE-DATE-X.
           EXIT.
      /
      *--------------------
       7300-REWRITE-POLICY.
      *--------------------

016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.

016503     MOVE WS-INTERNAL-EFFDT     TO L0289-PROC-EFF-DT.
016503     MOVE WS-INTERNAL-EFFDT     TO L0289-LO-PAC-DT.
020467     MOVE WS-INTERNAL-EFFDT     TO L0289-LO-DD2-DT.
016503     MOVE WS-INTERNAL-EFFDT     TO L0289-LO-CRC-DT.

016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD    TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT        TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                    TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE       TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

016503     IF  RPOL-REC-INFO = HPOL-REC-INFO
016503         GO TO 7300-REWRITE-POLICY-X
016503     END-IF.

           MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           MOVE HPOL-REC-INFO         TO RPOL-REC-INFO.
      *
016503*  UPDATE THE POLICY ACTIVITY DATE AND TYPE TO ENSURE THAT THE
016503*  BATCH RESCHEDULES CORRECTLY
      *
016503*    MOVE WWKDT-ZERO-DT         TO RPOL-POL-NXT-ACTV-DT.
016503*    IF RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*        MOVE 'RSH'             TO RPOL-NXT-ACTV-TYP-CD
016503*    END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

       7300-REWRITE-POLICY-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

      *
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET  WS-TRANS-NAME-DEFAULT       TO TRUE.
025970     SET  WS-RETRN-OK             TO  TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
       COPY CCPSPGA.
      /
       COPY NCPPCVGR.
      /
       COPY NCPPCVGS.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
      ****************************************************************
      * LINK TO  COPYBOOKS                                           *
      ****************************************************************
      /
018764*COPY CCCL0201.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0201.
018764 COPY CCPL0201.

025970 COPY CCPS0620.
013578 COPY CCPL0620.

016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.

       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.

018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS0289.

       COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.

       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.

018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      ****************************************************************
      *  FILE I/O PROCESS MODULES                                    *
      ****************************************************************

       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
557708*COPY XCCPHNDL.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4600                     **
      *****************************************************************
