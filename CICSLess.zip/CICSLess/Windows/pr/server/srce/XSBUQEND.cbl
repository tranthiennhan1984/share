      $SET NOOUTDD
      *****************************************************************
      **  MEMBER :  XSBUQEND                                         **
      **  REMARKS:  INGENIUM QUEUE WORKER EXIT                       **
      **            THIS PROGRAM SENDS EXIT SIGNAL TO QUEUE WORKERS  **
      **            BY CLEARING DISPATCH QUEUE ENTRY AND WRITING     **
      **            EXIT COMMAND TO JOB INPUT QUEUE.                 **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       NEW PROGRAM                                      **
      *****************************************************************

      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSBUQEND.

       COPY XCWWCRHT.

      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

       CONFIGURATION SECTION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.

      /
      ***************
       DATA DIVISION.
      ***************

       FILE SECTION.

      *************************
       WORKING-STORAGE SECTION.
      *************************

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSBUQEND'.
       COPY CCWWINDX.
       COPY XCWTFCMD.
       COPY XCWWWKDT.
      /
      * WEBSPHERE MQ COPY BOOKS START
       01  MQM-OBJECT-DESCRIPTOR.
       COPY CMQODV.

       01  MQM-MESSAGE-DESCRIPTOR.
       COPY CMQMDV.

       01  MQM-GET-MESSAGE-OPTIONS.
       COPY CMQGMOV.

       01  MQM-PUT-MESSAGE-OPTIONS.
       COPY CMQPMOV.
      *
       01  MQM-CONSTANTS.
       COPY CMQV.
      * WEBSPHERE MQ COPY BOOKS END
              
       01 WS-POINTERS.
          05 WS-MQ-POINTER PROCEDURE-POINTER.
       
       01 WS-MQ-WORK-AREA.
      *---------------------------------------------------------------
      *    QUEUE MANAGER
      *---------------------------------------------------------------
          05 WS-QMGR-CON-HANDLE          PIC S9(09) BINARY.       
      *---------------------------------------------------------------
      *    DISPATCH QUEUE
      *---------------------------------------------------------------
          05 WS-DISPATCH-OPTIONS         PIC S9(09) BINARY.
          05 WS-DISPATCH-Q-HANDLE        PIC S9(09) BINARY.      
          05 WS-DISPATCH-ENTRY-LEN       PIC S9(09) BINARY.
          05 WS-DISPATCH-RETURN-LEN      PIC S9(09) BINARY.          
      *---------------------------------------------------------------
      *    INPUT QUEUE
      *---------------------------------------------------------------
          05 WS-OPI-OPTIONS              PIC S9(09) BINARY.
          05 WS-OPI-Q-HANDLE             PIC S9(09) BINARY.
          05 WS-OPI-RETURN-LEN           PIC S9(09) BINARY.

      *---------------------------------------------------------------
      *    INPUT QUEUE FOR OUTPUT
      *---------------------------------------------------------------
          05 WS-OPI2-OPTIONS             PIC S9(09) BINARY.
          05 WS-OPI2-Q-HANDLE            PIC S9(09) BINARY.
          05 WS-OPI2-RETURN-LEN          PIC S9(09) BINARY.

      *---------------------------------------------------------------
      *    OUTPUT QUEUE
      *---------------------------------------------------------------
          05 WS-OPO-OPTIONS              PIC S9(09) BINARY.
          05 WS-OPO-Q-HANDLE             PIC S9(09) BINARY.
          05 WS-OPO-RETURN-LEN           PIC S9(09) BINARY.          
      *---------------------------------------------------------------
      *    CLOSE OPTIONS
      *---------------------------------------------------------------
          05 WS-CLS-OPTIONS              PIC S9(09) BINARY.
      *---------------------------------------------------------------
      *    COMMON
      *---------------------------------------------------------------    
          05  WS-MSG-LEN                 PIC S9(09) BINARY.
          05  WS-COMP-CODE               PIC S9(09) BINARY.
          05  WS-REASON-CODE             PIC S9(09) BINARY.          

      *
      * TRACE MESSAGE
      *                 
       01 WS-TRACE-MSG.
          05  WS-TRACE-TIMESTAMP    PIC X(16).
          05  FILLER                PIC X(01) VALUE SPACE.          
      * MQ ACTION 
          05  FILLER                PIC X(03) VALUE 'OP='.
          05  WS-TRACE-OPERATION    PIC X(10).
              88  WS-TRACE-CONN     VALUE 'MQCONN'.
              88  WS-TRACE-OPEN     VALUE 'MQOPEN'.
              88  WS-TRACE-CLOSE    VALUE 'MQCLOSE'.
              88  WS-TRACE-PUT      VALUE 'MQPUT'.
              88  WS-TRACE-GET      VALUE 'MQGET'.
              88  WS-TRACE-DISC     VALUE 'MQDISC'.              
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(04) VALUE 'OBJ='.
          05  WS-TRACE-OBJ          PIC X(04).
              88  WS-TRACE-OBJ-NONE VALUE SPACE.
              88  WS-TRACE-OBJ-DISP VALUE 'DISP'.
              88  WS-TRACE-OBJ-IN   VALUE 'IN  '.
              88  WS-TRACE-OBJ-OUT  VALUE 'OUT '.
              88  WS-TRACE-OBJ-LOG  VALUE 'LOG '.
                            
          05  FILLER                PIC X(01) VALUE SPACE.                    
          05  FILLER                PIC X(06) VALUE 'MSGID='.          
          05  WS-TRACE-MSG-ID       PIC X(01).
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(05) VALUE 'COMP='.                    
          05  WS-TRACE-COMP-CODE    PIC 9(01).
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(03) VALUE 'RC='.                    
          05  WS-TRACE-REASON-CODE  PIC 9(04).               

       01  WS-BCF-PARM.
           05  WS-QUEUE-MGR                       PIC X(48).
           05  WS-DISPATCH-QUEUE-NAME             PIC X(48).
           05  WS-IN-QUEUE-NAME                   PIC X(48).
           05  WS-OUT-QUEUE-NAME                  PIC X(48).
           05  WS-MAX-TASK-X                      PIC X(08).
           05  WS-MAX-TASK-PER-QUEUE REDEFINES WS-MAX-TASK-X PIC 9(08).
           05  WS-DEBUG-FLAG                      PIC X(01).
               88  WS-DEBUG-FLAG-VALID            VALUE 'Y' 'N'.
               88  WS-DEBUG-YES                   VALUE 'Y'.
               88  WS-DEBUG-NO                    VALUE 'N'.
           05  WS-DISPLAY-PARM                    PIC X(20).
           05  WS-TRACE-FLAG                      PIC X(01).
               88  WS-TRACE-FLAG-VALID            VALUE 'Y' 'N'.
               88  WS-TRACE-YES                   VALUE 'Y'.
               88  WS-TRACE-NO                    VALUE 'N'.
           05  WS-VERBOSE-FLAG                    PIC X(01).
               88  WS-VERBOSE-FLAG-VALID          VALUE 'Y' 'N'.
               88  WS-VERBOSE-YES                 VALUE 'Y'.
               88  WS-VERBOSE-NO                  VALUE 'N'.               


       01  WS-WORK-AREA.
           05  WS-TASK-CNT                        PIC 9(08) BINARY
                                                   VALUE 0.
      * 5 SECONDS WAIT TIME
           05  WS-WAIT-TIME                       PIC S9(09) BINARY
                                                  VALUE 5000.
           05  WS-DEVANIM                         PIC X(03).                                                  
           05  WS-DISPATCH-QUEUE-FLAG             PIC X(01).
               88  WS-DISPATCH-EMPTY              VALUE 'Y'.
               88  WS-DISPATCH-NOT-EMPTY          VALUE 'N'.
           05  WS-INPUT-QUEUE-FLAG                PIC X(01).
               88  WS-INPUT-EMPTY                 VALUE 'Y'.
               88  WS-INPUT-NOT-EMPTY             VALUE 'N'.
           05  WS-OUTPUT-QUEUE-FLAG               PIC X(01).
               88  WS-OUTPUT-EMPTY                VALUE 'Y'.
               88  WS-OUTPUT-NOT-EMPTY            VALUE 'N'.
           05  WS-MAX-THREAD                      PIC 9(03) VALUE
                                                  100.

       01  WS-DISPATCH-ENTRY.
           05  WS-PROCESS-ID                      PIC 9(06).
           05  WS-PROCESS-ID-X REDEFINES WS-PROCESS-ID PIC X(06).                 
           05  FILLER                             PIC X(01) VALUE
                                                  SPACE.
           05  WS-DISP-DATE-TIME                  PIC X(16).
           
       01  WS-MSG-GR.
           05  WS-ERROR-MSG.
               10  FILLER                         PIC X(20) VALUE
                   'CONTROL CARD ERROR: '.
               10  WS-ERROR-TXT                   PIC X(112).
           05  WS-ERR-MSG                         PIC X(80).                          

       01  WS-DUMMY-MSG                           PIC X(01).
       01  WS-EXIT-MSG                            PIC X(04) VALUE
                                                  'EXIT'.
      *
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
      /
       COPY XCWWPARM.
      /
      *------------
      * FILE LAYOUT
      *------------

       COPY XCSRBCF.
       COPY XCSWSEQ  REPLACING ==:ID:==  BY BCF
                               ==':ID:'==  BY =='BCF'==.
      /
       COPY XCSROCF.
       COPY XCSWPRT  REPLACING ==:ID:==  BY OCF
                               ==':ID:'==  BY =='OCF'==.
      /
       LINKAGE SECTION.

       PROCEDURE DIVISION.
      *
      *--------------
       0000-MAINLINE.
      *--------------
           
           DISPLAY 'DEVANIM'  UPON ENVIRONMENT-NAME.
           ACCEPT  WS-DEVANIM FROM ENVIRONMENT-VALUE.

           IF  WS-DEVANIM = '+A'
               CALL 'CBL_DEBUGBREAK'
           END-IF.

           PERFORM  1000-INITIALIZE
               THRU 1000-INITIALIZE-X.

           PERFORM  3000-PROCESS-TRANSACTION
               THRU 3000-PROCESS-TRANSACTION-X.

           PERFORM  9000-FINALIZE
               THRU 9000-FINALIZE-X.

           STOP RUN.

       0000-MAINLINE-X.
           EXIT.
      /
      *----------------
       1000-INITIALIZE.
      *----------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  1100-OPEN-FILES
               THRU 1100-OPEN-FILES-X.

           PERFORM  1200-PRCES-CTL-CARDS
               THRU 1200-PRCES-CTL-CARDS-X.
               
           PERFORM  1300-HANDLE-DEBUG                                           
               THRU 1300-HANDLE-DEBUG-X.
               
      * CONNECT TO MQ QUEUE MANAGER AND OPEN QUEUES
           PERFORM  1400-CONNECT-MQ
               THRU 1400-CONNECT-MQ-X.                              

       1000-INITIALIZE-X.
           EXIT.

      *----------------
       1100-OPEN-FILES.
      *----------------

           PERFORM  OCF-3000-OPEN-OUTPUT
               THRU OCF-3000-OPEN-OUTPUT-X.

           PERFORM  BCF-1000-OPEN-INPUT
               THRU BCF-1000-OPEN-INPUT-X.

       1100-OPEN-FILES-X.
           EXIT.

      *---------------------
       1200-PRCES-CTL-CARDS.
      *---------------------

           PERFORM  BCF-1000-READ
               THRU BCF-1000-READ-X.

           PERFORM
               UNTIL NOT WBCF-SEQ-IO-OK

               MOVE RBCF-SEQ-REC-INFO   TO WPARM-CARD-AREA

               EVALUATE TRUE

                   WHEN WPARM-DESCRIPTION = 'QUEUE MANAGER'
                       IF WPARM-VALUE NOT = SPACE
                           MOVE WPARM-VALUE   TO WS-QUEUE-MGR
                       ELSE
                           PERFORM  1220-INVALID-CTL-CARD
                               THRU 1220-INVALID-CTL-CARD-X
                       END-IF

                   WHEN WPARM-DESCRIPTION = 'DISPATCH QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-DISPATCH-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'IN QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-IN-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF
                   
                   WHEN WPARM-DESCRIPTION = 'OUT QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-OUT-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'MAX TASK PER QUEUE'
                        CONTINUE

                   WHEN WPARM-DESCRIPTION = 'DEBUG'
                        MOVE WPARM-VALUE   TO WS-DEBUG-FLAG
                        IF  NOT WS-DEBUG-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'DEBUG DISPLAY'
                        CONTINUE

                   WHEN WPARM-DESCRIPTION = 'TRACE'
                        MOVE WPARM-VALUE   TO WS-TRACE-FLAG
                        IF  NOT WS-TRACE-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'VERBOSE'
                        MOVE WPARM-VALUE   TO WS-VERBOSE-FLAG
                        IF  NOT WS-VERBOSE-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN OTHER
                        PERFORM  1220-INVALID-CTL-CARD
                            THRU 1220-INVALID-CTL-CARD-X

               END-EVALUATE

               PERFORM  BCF-1000-READ
                   THRU BCF-1000-READ-X

           END-PERFORM.

       1200-PRCES-CTL-CARDS-X.
           EXIT.

      *----------------------
       1220-INVALID-CTL-CARD.
      *----------------------
      
           MOVE WPARM-CARD-AREA     TO WS-ERROR-TXT.
           DISPLAY WS-ERROR-MSG.
           STOP RUN.
           
       1220-INVALID-CTL-CARD-X.
           EXIT.

      *------------------
       1300-HANDLE-DEBUG.
      *------------------
      
      * IF CONTROL CARD INDICATES DEBUG AND DEVANIM IS NOT SET
           IF  WS-DEBUG-YES AND WS-DEVANIM NOT = '+A'
               CALL 'CBL_DEBUGBREAK'
           END-IF.       
       
       1300-HANDLE-DEBUG-X.
           EXIT.

      *----------------
       1400-CONNECT-MQ.
      *----------------
      
      *
      * CONNECT TO QUEUE MANAGER
      *
      
      * ON UNIX, THE PROGRAM IS COMPILED AND LINK TO libmqicb_r
      * ON Windows, MQICCB32.dll MUST BE IN THE PATH 
      
           SET WS-MQ-POINTER 
               TO ENTRY 'MQICCB32'.

UNIX  *    IF WS-MQ-POINTER = NULL
UNIX  *        SET WS-MQ-POINTER
UNIX  *            TO ENTRY 'MQMCB32'
UNIX  *    END-IF.

           IF WS-MQ-POINTER = NULL
               MOVE 'MQ SHARE OBJECT NOT FOUND' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.
           
           PERFORM  1410-CONNECT-QMGR
               THRU 1410-CONNECT-QMGR-X.           
      *
      * OPEN DISPATCH, INPUT AND OUTPUT QUEUE
      *
           PERFORM  1420-OPEN-DISPATCH-QUEUE
               THRU 1420-OPEN-DISPATCH-QUEUE-X.
      
           PERFORM  1430-OPEN-INPUT-QUEUE
               THRU 1430-OPEN-INPUT-QUEUE-X.
                   
           PERFORM  1440-OPEN-OUTPUT-QUEUE
               THRU 1440-OPEN-OUTPUT-QUEUE-X.

           PERFORM  1450-OPEN-INPUT-QUEUE-INPUT
               THRU 1450-OPEN-INPUT-QUEUE-INPUT-X.

       1400-CONNECT-MQ-X.
           EXIT.

      *------------------          
       1410-CONNECT-QMGR.
      *------------------
           
           CALL 'MQCONN' USING WS-QUEUE-MGR
                               WS-QMGR-CON-HANDLE
                               WS-COMP-CODE
                               WS-REASON-CODE.

      * OUTPUT TRACE IF REQUIRED                                                        
           SET WS-TRACE-CONN        TO TRUE.
           SET WS-TRACE-OBJ-NONE    TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.
                                   
           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ CONNECT ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
                                    
       1410-CONNECT-QMGR-X.
           EXIT.

      *-------------------------          
       1420-OPEN-DISPATCH-QUEUE.
      *-------------------------
      
           MOVE MQOT-Q                 TO MQOD-OBJECTTYPE.
           MOVE WS-DISPATCH-QUEUE-NAME TO MQOD-OBJECTNAME.
           
           COMPUTE WS-DISPATCH-OPTIONS = MQOO-INPUT-AS-Q-DEF +
                                         MQOO-FAIL-IF-QUIESCING.
      *
           CALL 'MQOPEN' USING WS-QMGR-CON-HANDLE
                               MQOD
                               WS-DISPATCH-OPTIONS
                               WS-DISPATCH-Q-HANDLE
                               WS-COMP-CODE
                               WS-REASON-CODE.
      *
           SET  WS-TRACE-OPEN       TO TRUE.
           SET  WS-TRACE-OBJ-DISP   TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ DISPATCH QUEUE OPEN ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
      
       1420-OPEN-DISPATCH-QUEUE-X.
           EXIT.

      *----------------------          
       1430-OPEN-INPUT-QUEUE.
      *----------------------
           
           MOVE MQOT-Q           TO MQOD-OBJECTTYPE.
           MOVE WS-IN-QUEUE-NAME TO MQOD-OBJECTNAME.
      *
           COMPUTE WS-OPI-OPTIONS = MQOO-OUTPUT +
                                    MQOO-FAIL-IF-QUIESCING.
      *
           CALL 'MQOPEN' USING WS-QMGR-CON-HANDLE
                               MQOD
                               WS-OPI-OPTIONS
                               WS-OPI-Q-HANDLE
                               WS-COMP-CODE
                               WS-REASON-CODE.
      *
           SET  WS-TRACE-OPEN       TO TRUE.
           SET  WS-TRACE-OBJ-IN     TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.
           
           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ INPUT QUEUE OPEN ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           

       1430-OPEN-INPUT-QUEUE-X.
           EXIT.
           
      *-----------------------          
       1440-OPEN-OUTPUT-QUEUE.
      *-----------------------
      
           MOVE MQOT-Q            TO MQOD-OBJECTTYPE.
           MOVE WS-OUT-QUEUE-NAME TO MQOD-OBJECTNAME.
           
           COMPUTE WS-OPO-OPTIONS = MQOO-INPUT-AS-Q-DEF +
                                    MQOO-FAIL-IF-QUIESCING.
      *
           CALL 'MQOPEN' USING WS-QMGR-CON-HANDLE
                               MQOD
                               WS-OPO-OPTIONS
                               WS-OPO-Q-HANDLE
                               WS-COMP-CODE
                               WS-REASON-CODE.
      *
           SET  WS-TRACE-OPEN       TO TRUE.
           SET  WS-TRACE-OBJ-OUT    TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ OUTPUT QUEUE OPEN ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
      
       1440-OPEN-OUTPUT-QUEUE-X.
           EXIT.

      *----------------------------          
       1450-OPEN-INPUT-QUEUE-INPUT.
      *----------------------------
      
           MOVE MQOT-Q            TO MQOD-OBJECTTYPE.
           MOVE WS-IN-QUEUE-NAME  TO MQOD-OBJECTNAME.
           
           COMPUTE WS-OPI2-OPTIONS = MQOO-INPUT-AS-Q-DEF +
                                    MQOO-FAIL-IF-QUIESCING.
      *
           CALL 'MQOPEN' USING WS-QMGR-CON-HANDLE
                               MQOD
                               WS-OPI2-OPTIONS
                               WS-OPI2-Q-HANDLE
                               WS-COMP-CODE
                               WS-REASON-CODE.
      *
           SET  WS-TRACE-OPEN       TO TRUE.
           SET  WS-TRACE-OBJ-IN     TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ INPUT QUEUE OPEN ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
      
       1450-OPEN-INPUT-QUEUE-INPUT-X.
           EXIT.

      *-------------------------
       3000-PROCESS-TRANSACTION.
      *-------------------------
      *
      * READ DISPATCH QUEUE FOR ACTIVE QUEUE WORKERS AND 
      * INSTRUCT COBOL QUEUE WORKERS TO STOP
      *
           MOVE 0 TO WS-COMP-CODE.

           PERFORM  8500-READ-DISPATCH-QUEUE
               THRU 8500-READ-DISPATCH-QUEUE-X.

           PERFORM  3100-CLEAR-DISP-INPUT-QUEUE
               THRU 3100-CLEAR-DISP-INPUT-QUEUE-X
               UNTIL WS-COMP-CODE > MQCC-WARNING.

      * FLUSH OUTPUT QUEUE FOR LEFT OVER RESULTS
           MOVE 0 TO WS-COMP-CODE.
           PERFORM  8700-READ-OUTPUT-QUEUE
               THRU 8700-READ-OUTPUT-QUEUE-X
               UNTIL WS-COMP-CODE > MQCC-WARNING.

      * FLUSH INPUT QUEUE JUST IN CASE
           MOVE 0 TO WS-COMP-CODE.
           PERFORM  8800-READ-INPUT-QUEUE
               THRU 8800-READ-INPUT-QUEUE-X
               UNTIL WS-COMP-CODE > MQCC-WARNING.
                                       
       3000-PROCESS-TRANSACTION-X.
           EXIT.


      *----------------------------
       3100-CLEAR-DISP-INPUT-QUEUE.
      *----------------------------

      * PUT 'EXIT' IN INPUT QUEUE                                 
           PERFORM  8600-WRITE-INPUT-QUEUE
               THRU 8600-WRITE-INPUT-QUEUE-X.

           MOVE 0 TO WS-COMP-CODE.

           PERFORM  8500-READ-DISPATCH-QUEUE
               THRU 8500-READ-DISPATCH-QUEUE-X.

       3100-CLEAR-DISP-INPUT-QUEUE-X.
           EXIT.


      *-------------------------
       8500-READ-DISPATCH-QUEUE.
      *-------------------------
      *
      * GET ALL ENTRIES FROM DISPATCH QUEUE
      *
           MOVE MQMI-NONE TO MQMD-MSGID.
      *
      * NO CORRELATION ID
      *
           MOVE MQCI-NONE TO MQMD-CORRELID.
      *
           COMPUTE MQGMO-OPTIONS = MQGMO-WAIT +
                                   MQGMO-ACCEPT-TRUNCATED-MSG +
                                   MQGMO-NO-SYNCPOINT +
                                   MQGMO-FAIL-IF-QUIESCING.

      * ENSURE NO NEW MESSAGE COMES OUT FROM ACTIVE THREADS
           MOVE WS-WAIT-TIME TO MQGMO-WAITINTERVAL.
      *
           CALL 'MQGET' USING WS-QMGR-CON-HANDLE
                              WS-DISPATCH-Q-HANDLE
                              MQMD
                              MQGMO                              
                              WS-DISPATCH-ENTRY-LEN
                              WS-DISPATCH-ENTRY
                              WS-DISPATCH-RETURN-LEN
                              WS-COMP-CODE
                              WS-REASON-CODE.                
      *
           SET  WS-TRACE-GET        TO TRUE.
           SET  WS-TRACE-OBJ-DISP   TO TRUE.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE = MQCC-OK
               ADD 1                TO WS-TASK-CNT    
           END-IF.           


       8500-READ-DISPATCH-QUEUE-X.
           EXIT.

      *----------------------
       8600-WRITE-INPUT-QUEUE.
      *----------------------

           MOVE MQMI-NONE  TO MQMD-MSGID.

           MOVE MQMI-NONE  TO MQMD-CORRELID.                           

           MOVE MQPER-NOT-PERSISTENT TO MQMD-PERSISTENCE.
           
           COMPUTE MQPMO-OPTIONS = MQPMO-NO-SYNCPOINT +
                                   MQPMO-FAIL-IF-QUIESCING.
           MOVE MQMT-DATAGRAM TO MQMD-MSGTYPE.                                        
           
           MOVE 4          TO WS-MSG-LEN.
      *                                    
           CALL 'MQPUT' USING WS-QMGR-CON-HANDLE
                              WS-OPI-Q-HANDLE
                              MQMD
                              MQPMO                              
                              WS-MSG-LEN
                              WS-EXIT-MSG
                              WS-COMP-CODE
                              WS-REASON-CODE.                
           
           SET  WS-TRACE-PUT        TO TRUE.
           SET  WS-TRACE-OBJ-IN     TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ INPUT QUEUE PUT ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           

       8600-WRITE-INPUT-QUEUE-X.
           EXIT.

      *-------------------------
       8700-READ-OUTPUT-QUEUE.
      *-------------------------
      *
      * GET ALL ENTRIES FROM OUTPUT QUEUE
      *
           MOVE MQMI-NONE TO MQMD-MSGID.
      *
      * NO CORRELATION ID
      *
           MOVE MQCI-NONE TO MQMD-CORRELID.
      *
           COMPUTE MQGMO-OPTIONS = MQGMO-WAIT +
                                   MQGMO-ACCEPT-TRUNCATED-MSG +
                                   MQGMO-NO-SYNCPOINT +
                                   MQGMO-FAIL-IF-QUIESCING.

      * ENSURE NO NEW MESSAGE COMES OUT FROM ACTIVE THREADS
           MOVE WS-WAIT-TIME TO MQGMO-WAITINTERVAL.

           MOVE 1          TO WS-MSG-LEN.

           CALL 'MQGET' USING WS-QMGR-CON-HANDLE
                              WS-OPO-Q-HANDLE
                              MQMD
                              MQGMO                              
                              WS-MSG-LEN
                              WS-DUMMY-MSG
                              WS-OPO-RETURN-LEN
                              WS-COMP-CODE
                              WS-REASON-CODE.                
      *
           SET  WS-TRACE-GET         TO TRUE.
           SET  WS-TRACE-OBJ-OUT     TO TRUE.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

       8700-READ-OUTPUT-QUEUE-X.
           EXIT.


      *----------------------
       8800-READ-INPUT-QUEUE.
      *----------------------
      *
      * GET ALL ENTRIES FROM INPUT QUEUE
      *
           MOVE MQMI-NONE TO MQMD-MSGID.
      *
      * NO CORRELATION ID
      *
           MOVE MQCI-NONE TO MQMD-CORRELID.
      *
           COMPUTE MQGMO-OPTIONS = MQGMO-WAIT +
                                   MQGMO-ACCEPT-TRUNCATED-MSG +
                                   MQGMO-NO-SYNCPOINT +
                                   MQGMO-FAIL-IF-QUIESCING.

      * ENSURE NO NEW MESSAGE COMES OUT FROM ACTIVE THREADS
           MOVE WS-WAIT-TIME TO MQGMO-WAITINTERVAL.

           MOVE 1          TO WS-MSG-LEN.

           CALL 'MQGET' USING WS-QMGR-CON-HANDLE
                              WS-OPI2-Q-HANDLE
                              MQMD
                              MQGMO                              
                              WS-MSG-LEN
                              WS-DUMMY-MSG
                              WS-OPI2-RETURN-LEN
                              WS-COMP-CODE
                              WS-REASON-CODE.                
      *
           SET  WS-TRACE-GET         TO TRUE.
           SET  WS-TRACE-OBJ-IN      TO TRUE.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

       8800-READ-INPUT-QUEUE-X.
           EXIT.

      *---------------
       9000-FINALIZE.
      *---------------

           PERFORM  9200-CLOSE-DISPATCH-QUEUE
               THRU 9200-CLOSE-DISPATCH-QUEUE-X.      
      
           PERFORM  9300-CLOSE-INPUT-QUEUE
               THRU 9300-CLOSE-INPUT-QUEUE-X.

           PERFORM  9400-CLOSE-OUTPUT-QUEUE
               THRU 9400-CLOSE-OUTPUT-QUEUE-X.

           PERFORM  9500-CLOSE-INPUT-QUEUE-INPUT
               THRU 9500-CLOSE-INPUT-QUEUE-INPUT-X.

           PERFORM  9700-CLOSE-QMGR-CONNECTION
               THRU 9700-CLOSE-QMGR-CONNECTION-X.

           PERFORM  9999-CLOSE-FILES
               THRU 9999-CLOSE-FILES-X.

       9000-FINALIZE-X.
           EXIT.

      *---------------
       9100-ABORT-ERR.
      *---------------

           DISPLAY WS-ERR-MSG.                         
           STOP RUN.
           
       9100-ABORT-ERR-X.
           EXIT.                                                                       

      *--------------------------       
       9200-CLOSE-DISPATCH-QUEUE.
      *--------------------------       
      
           MOVE MQCO-NONE  TO WS-CLS-OPTIONS.
      *
           CALL 'MQCLOSE' USING WS-QMGR-CON-HANDLE
                                WS-DISPATCH-Q-HANDLE
                                WS-CLS-OPTIONS
                                WS-COMP-CODE
                                WS-REASON-CODE.
                                
           SET  WS-TRACE-CLOSE      TO TRUE.
           SET  WS-TRACE-OBJ-DISP   TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ DISPATCH QUEUE CLOSE ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
       
       9200-CLOSE-DISPATCH-QUEUE-X.
           EXIT.

      *-----------------------       
       9300-CLOSE-INPUT-QUEUE.
      *-----------------------       
      
           MOVE MQCO-NONE  TO WS-CLS-OPTIONS.
      *
           CALL 'MQCLOSE' USING WS-QMGR-CON-HANDLE
                                WS-OPI-Q-HANDLE
                                WS-CLS-OPTIONS
                                WS-COMP-CODE
                                WS-REASON-CODE.
                                
           SET  WS-TRACE-CLOSE      TO TRUE.
           SET  WS-TRACE-OBJ-IN     TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ INPUT QUEUE CLOSE ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
       
       9300-CLOSE-INPUT-QUEUE-X.
           EXIT.
           
      *------------------------       
       9400-CLOSE-OUTPUT-QUEUE.
      *------------------------       

           MOVE MQCO-NONE  TO WS-CLS-OPTIONS.
      *
           CALL 'MQCLOSE' USING WS-QMGR-CON-HANDLE
                                WS-OPO-Q-HANDLE
                                WS-CLS-OPTIONS
                                WS-COMP-CODE
                                WS-REASON-CODE.
      *
           SET  WS-TRACE-CLOSE      TO TRUE.
           SET  WS-TRACE-OBJ-OUT    TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ OUTPUT QUEUE CLOSE ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
       
       9400-CLOSE-OUTPUT-QUEUE-X.
           EXIT.

      *-----------------------------       
       9500-CLOSE-INPUT-QUEUE-INPUT.
      *-----------------------------       

           MOVE MQCO-NONE  TO WS-CLS-OPTIONS.
      *
           CALL 'MQCLOSE' USING WS-QMGR-CON-HANDLE
                                WS-OPI2-Q-HANDLE
                                WS-CLS-OPTIONS
                                WS-COMP-CODE
                                WS-REASON-CODE.
      *
           SET  WS-TRACE-CLOSE      TO TRUE.
           SET  WS-TRACE-OBJ-IN     TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ INPUT QUEUE CLOSE ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
       
       9500-CLOSE-INPUT-QUEUE-INPUT-X.
           EXIT.
           
      *-------------------
       9600-GEN-TRACE-MSG.
      *-------------------
           
           IF  WS-TRACE-YES OR WS-VERBOSE-YES               
               MOVE FUNCTION CURRENT-DATE TO WS-TRACE-TIMESTAMP               
               MOVE WS-COMP-CODE        TO WS-TRACE-COMP-CODE
               MOVE WS-REASON-CODE      TO WS-TRACE-REASON-CODE
           END-IF.
 
           
           IF  WS-VERBOSE-YES
               DISPLAY WS-TRACE-MSG
           END-IF.
      
       9600-GEN-TRACE-MSG-X.
           EXIT.

      *---------------------------       
       9700-CLOSE-QMGR-CONNECTION.
      *---------------------------       
      *
      * DISCONNECT FROM QUEUE MANAGER
      *           
           CALL 'MQDISC' USING WS-QMGR-CON-HANDLE
                               WS-COMP-CODE
                               WS-REASON-CODE.
      *
           SET  WS-TRACE-DISC       TO TRUE.
           SET  WS-TRACE-OBJ-NONE   TO TRUE.
           MOVE SPACE               TO WS-TRACE-MSG-ID.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF WS-COMP-CODE NOT = MQCC-OK
               MOVE '*** MQ DISCONNECT ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.           
       
       9700-CLOSE-QMGR-CONNECTION-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           MOVE SPACES           TO WWKDT-WORK-FIELDS.
           MOVE LENGTH OF WS-DISPATCH-ENTRY 
               TO WS-DISPATCH-ENTRY-LEN.
           MOVE 0                TO WS-TASK-CNT.
           SET  WS-DISPATCH-NOT-EMPTY TO TRUE.
           SET  WS-INPUT-NOT-EMPTY    TO TRUE.
           SET  WS-OUTPUT-NOT-EMPTY   TO TRUE.           
           INITIALIZE            WS-BCF-PARM.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *-----------------
       9999-CLOSE-FILES.
      *-----------------

           PERFORM  BCF-4000-CLOSE
               THRU BCF-4000-CLOSE-X.

           PERFORM  OCF-4000-CLOSE
               THRU OCF-4000-CLOSE-X.

       9999-CLOSE-FILES-X.
           EXIT.

      /
      *
      * FILE COPYBOOKS
      *
       COPY XCSLFILE REPLACING ==:ID:==  BY OCF
                               ==':PGM:'== BY =='XSRQOCF'==.
       COPY XCSOFILE REPLACING ==:ID:==  BY OCF.
      /
       COPY XCSLFILE REPLACING ==:ID:==  BY BCF
                               ==':PGM:'== BY =='XSRQBCF'==.
       COPY XCSNSEQ  REPLACING ==:ID:==  BY BCF.
       COPY XCSOFILE REPLACING ==:ID:==  BY BCF.

      *
      * PROCESSING COPYBOOKS
      /      
      *
      *****************************************************************
      **                 END OF PROGRAM XSBUQEND                     **
      *****************************************************************
