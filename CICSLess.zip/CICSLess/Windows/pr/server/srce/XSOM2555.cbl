      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM2555.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM2555                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RAPID PRINT REQUEST     **
      **            FUNCTION OF A SPECIFIC PRTX RECORD               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM2555'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       COPY CCWWINDX.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-RAPID-PRT-RQST           VALUE '2555'.
036742     05  WS-TRNXT-PRCES-DT                       PIC X(10).
036742     05  WS-TRNXT-PRCES-TIME                     PIC X(08).
036742     05  WS-TRNXT-GEN-ID                         PIC 9(10).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
036742 COPY XCWWCNST.
       COPY XCWWWKDT.
       COPY XCWWTIME.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWLPGA.
       COPY XCWL0280.
       COPY XCWL2557.
       COPY XCWL8090.

       COPY XCWLDTLK.
       COPY XCWL1640.
      /

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM2555.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

025970*           PERFORM  9300-SETUP-MSIN-REFERENCE
025970*               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*           MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RAPID-PRT-RQST
                    PERFORM  2000-RAPID-PRT-RQST
                        THRU 2000-RAPID-PRT-RQST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2555'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *---------------------
       2000-RAPID-PRT-RQST.
      *--------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2557-1000-INIT-PARM-INFO
               THRU 2557-1000-INIT-PARM-INFO-X.

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 2000-RAPID-PRT-RQST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 2000-RAPID-PRT-RQST-X
           END-IF.

           PERFORM  2300-RAPID-PRT-RQST
               THRU 2300-RAPID-PRT-RQST-X.

       2000-RAPID-PRT-RQST-X.
           EXIT.

      *----------------
       2100-EDIT-INPUT.
      *----------------

           PERFORM  2110-EDIT-TRNXT-PART-NUM
               THRU 2110-EDIT-TRNXT-PART-NUM-X.

           PERFORM  2120-EDIT-USER-ID
               THRU 2120-EDIT-USER-ID-X.

036742*    PERFORM  2130-EDIT-TRNXT-INSTC-ID
036742*        THRU 2130-EDIT-TRNXT-INSTC-ID-X.
036742*
036742*    PERFORM  2140-EDIT-TRNXT-TS
036742*        THRU 2140-EDIT-TRNXT-TS-X.

036742     PERFORM  2130-EDIT-TRNXT-PRCES-DT
036742         THRU 2130-EDIT-TRNXT-PRCES-DT-X.
036742
036742     PERFORM  2140-EDIT-TRNXT-PRCES-TIME
036742         THRU 2140-EDIT-TRNXT-PRCES-TIME-X.
036742
036742     PERFORM  2150-EDIT-TRNXT-GEN-ID
036742         THRU 2150-EDIT-TRNXT-GEN-ID-X.

       2100-EDIT-INPUT-X.
           EXIT.

      *-------------------------
       2110-EDIT-TRNXT-PART-NUM.
      *-------------------------

           IF  MIR-TRNXT-PART-NUM = SPACE
      * MSG: INVALID TRANSACTION PART NUMBER
               MOVE 'XS25550001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-TRNXT-PART-NUM-X
           END-IF.

           SET L0280-SIGN-PERMITTED   TO TRUE.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 4                     TO L0280-LENGTH.
           MOVE 4                     TO L0280-INPUT-SIZE.
           MOVE MIR-TRNXT-PART-NUM    TO L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT          TO L2557-TRNXT-PART-NUM
           ELSE
      * MSG: INVALID TRANSACTION PART NUMBER
               MOVE 'XS25550001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-TRNXT-PART-NUM-X.
           EXIT.
      /
      *------------------
       2120-EDIT-USER-ID.
      *------------------

           IF  MIR-USER-ID = SPACE
               MOVE WGLOB-USER-ID           TO MIR-USER-ID
           END-IF.

       2120-EDIT-USER-ID-X.
           EXIT.
      /
036742*-------------------------
036742*2130-EDIT-TRNXT-INSTC-ID.
036742*-------------------------
036742*
036742*    IF  MIR-TRNXT-INSTC-ID = SPACE
036742* MSG: INVALID TRANSACTION INSTRUCTION NUMBER
036742*        MOVE 'XS25550002'      TO WGLOB-MSG-REF-INFO
036742*        PERFORM  0260-1000-GENERATE-MESSAGE
036742*            THRU 0260-1000-GENERATE-MESSAGE-X
036742*        GO TO 2130-EDIT-TRNXT-INSTC-ID-X
036742*    END-IF.
036742*
036742*    SET L0280-SIGN-PERMITTED   TO TRUE.
036742*    MOVE ZERO                  TO L0280-PRECISION.
036742*    MOVE 4                     TO L0280-LENGTH.
036742*    MOVE 4                     TO L0280-INPUT-SIZE.
036742*    MOVE MIR-TRNXT-INSTC-ID    TO L0280-INPUT-DATA.
036742*
036742*    PERFORM 0280-1000-NUMERIC-EDIT
036742*       THRU 0280-1000-NUMERIC-EDIT-X.
036742*
036742*    IF L0280-OK
036742*        MOVE L0280-OUTPUT          TO L2557-TRNXT-INSTC-ID
036742*    ELSE
036742* MSG: INVALID TRANSACTION INSTRUCTION NUMBER
036742*        MOVE 'XS25550002'      TO WGLOB-MSG-REF-INFO
036742*        PERFORM  0260-1000-GENERATE-MESSAGE
036742*            THRU 0260-1000-GENERATE-MESSAGE-X
036742*    END-IF.
036742*
036742*2130-EDIT-TRNXT-INSTC-ID-X.
036742*    EXIT.
      /
      *-------------------
036742*2140-EDIT-TRNXT-TS.
036742*-------------------
036742*
036742*    IF  MIR-TRNXT-TS = SPACES
036742****MSG: INVALID TIME STAMP
036742*        MOVE 'XS25550003'         TO WGLOB-MSG-REF-INFO
036742*        PERFORM  0260-1000-GENERATE-MESSAGE
036742*            THRU 0260-1000-GENERATE-MESSAGE-X
036742*        GO TO 2140-EDIT-TRNXT-TS-X
036742*    END-IF.
036742*
036742*2140-EDIT-TRNXT-TS-X.
036742*    EXIT.
036742
036742*-------------------------
036742 2130-EDIT-TRNXT-PRCES-DT.
036742*-------------------------
036742
036742     MOVE MIR-TRNXT-PRCES-DT
036742                                TO L1640-EXTERNAL-DATE
036742     PERFORM 1640-7000-MIR-TO-INT
036742        THRU 1640-7000-MIR-TO-INT-X
036742     IF  L1640-VALID
036742         IF  L1640-INTERNAL-DATE >  WGLOB-SYSTEM-DATE-INT
036742* MSG: INVALID DATE
036742             MOVE 'XS25550004'  TO WGLOB-MSG-REF-INFO
036742             PERFORM  0260-1000-GENERATE-MESSAGE
036742                 THRU 0260-1000-GENERATE-MESSAGE-X
036742             GO TO 2130-EDIT-TRNXT-PRCES-DT-X
036742         END-IF
036742     END-IF.
036742     MOVE L1640-INTERNAL-DATE   TO WS-TRNXT-PRCES-DT.
036742
036742 2130-EDIT-TRNXT-PRCES-DT-X.
036742     EXIT.
036742
036742*---------------------------
036742 2140-EDIT-TRNXT-PRCES-TIME.
036742*----------------------------
036742
036742     IF  MIR-TRNXT-PRCES-TIME = SPACE
036742         MOVE WGLOB-SYSTEM-TIME    TO WTIME-EDIT-TIME
036742         MOVE WTIME-EDIT-HHMMSS    TO MIR-TRNXT-PRCES-TIME
036742         GO TO 2140-EDIT-TRNXT-PRCES-TIME-X
036742     END-IF.
036742
036742     IF  MIR-TRNXT-PRCES-TIME (1:2) > '23'
036742     OR  MIR-TRNXT-PRCES-TIME (1:2) < '00'
036742     OR  MIR-TRNXT-PRCES-TIME (3:2) > '59'
036742     OR  MIR-TRNXT-PRCES-TIME (3:2) < '00'
036742     OR  MIR-TRNXT-PRCES-TIME (5:2) > '59'
036742     OR  MIR-TRNXT-PRCES-TIME (5:2) < '00'
036742****MSG: INVALID TIME
036742         MOVE 'XS25550005'         TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742     ELSE
036742         MOVE MIR-TRNXT-PRCES-TIME TO WTIME-EDIT-TIME
036742         MOVE WWKDT-ZERO-TS        TO WWKDT-INT-TS
036742         MOVE WTIME-EDIT-HH        TO WWKDT-INT-TS-HR
036742         MOVE WTIME-EDIT-MM        TO WWKDT-INT-TS-MI
036742         MOVE WTIME-EDIT-SS        TO WWKDT-INT-TS-SE
036742         MOVE WWKDT-INT-TS-HHMMSS  TO WS-TRNXT-PRCES-TIME
036742     END-IF.
036742
036742 2140-EDIT-TRNXT-PRCES-TIME-X.
036742     EXIT.
036742
036742*---------------------------
036742 2150-EDIT-TRNXT-GEN-ID.
036742*----------------------------
036742
036742     IF  MIR-TRNXT-GEN-ID = SPACE
036742* MSG: INVALID IDENTITY VALUE NUMBER
036742         MOVE 'XS25550006'      TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742         GO TO 2150-EDIT-TRNXT-GEN-ID-X
036742     END-IF.
036742
036742     SET L0280-SIGN-PERMITTED   TO TRUE.
036742     MOVE ZERO                  TO L0280-PRECISION.
036742     MOVE LENGTH OF MIR-TRNXT-GEN-ID
036742                                TO L0280-LENGTH.
036742     MOVE LENGTH OF MIR-TRNXT-GEN-ID
036742                                TO L0280-INPUT-SIZE.
036742     MOVE MIR-TRNXT-GEN-ID      TO L0280-INPUT-DATA.
036742
036742     PERFORM 0280-1000-NUMERIC-EDIT
036742        THRU 0280-1000-NUMERIC-EDIT-X.
036742
036742     IF  NOT L0280-OK
036742     OR  L0280-OUTPUT < ZERO
036742     OR  L0280-OUTPUT > WCNST-MAX-TRNXT-GEN-ID-N
036742* MSG: INVALID IDENTITY VALUE NUMBER
036742         MOVE 'XS25550006'      TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742     ELSE
036742         MOVE L0280-OUTPUT      TO WS-TRNXT-GEN-ID
036742     END-IF.
036742
036742 2150-EDIT-TRNXT-GEN-ID-X.
036742     EXIT.
036742
      *-------------------------
       2300-RAPID-PRT-RQST.
      *-------------------------
           MOVE 'Y' TO L2557-RAPD-PRT-RQST-IND.

           PERFORM 2557-1000-PROCESS-PRTX
             THRU  2557-1000-PROCESS-PRTX-X.
      *MSGS WILL BE DEALT WITH IN 2557.

       2300-RAPID-PRT-RQST-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-TRNXT-PART-NUM TO L2557-TRNXT-PART-NUM.
036742*    MOVE MIR-USER-ID        TO L2557-USER-ID.
036742*    MOVE MIR-TRNXT-INSTC-ID TO L2557-TRNXT-INSTC-ID.
036742*    MOVE MIR-TRNXT-TS       TO L2557-TRNXT-TS.
036742     MOVE WS-TRNXT-PRCES-DT  TO L2557-TRNXT-PRCES-DT.
036742     MOVE WS-TRNXT-PRCES-TIME TO L2557-TRNXT-PRCES-TIME.
036742     MOVE WS-TRNXT-GEN-ID    TO L2557-TRNXT-GEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2557-0000-INIT-PARM-INFO
025970         THRU 2557-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  9300-SETUP-MSIN-REFERENCE
025970        THRU 9300-SETUP-MSIN-REFERENCE-X.
           
           INITIALIZE WS-WORKING-STORAGE.
025970     MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.
           
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.

      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS2557.
       COPY XCPL2557.

       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.

025970 COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPS8090.
       COPY XCPL8090.

      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM XSOM2555
      ***************************************************************** 


