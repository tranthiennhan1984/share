      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM2574.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2574                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE PLIP TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2574'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '2574'.
           05  WS-SUB                                PIC S9(04) BINARY.
           05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPLIP.
       COPY CCFRPLIP.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWEBLCH.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2574.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2574'        TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'      TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PLIP-1000-BROWSE
               THRU PLIP-1000-BROWSE-X.

           PERFORM  PLIP-2000-READ-NEXT
               THRU PLIP-2000-READ-NEXT-X.

           IF  WPLIP-IO-EOF
               PERFORM  PLIP-3000-END-BROWSE
                   THRU PLIP-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-LIST-X
           END-IF.

      *  SET THE NUMBER OF LIST LINES USING MIR FIELD OCCURENCES

           COMPUTE WS-MAX-LIST-LINES
                 = LENGTH OF MIR-PRFL-ID-G
                 / LENGTH OF MIR-PRFL-ID-T (1).

           PERFORM  2010-BROWSE-PLIP
               THRU 2010-BROWSE-PLIP-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WPLIP-IO-EOF.

           IF  WPLIP-IO-EOF
               MOVE 'XS00000015'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE RPLIP-PLAN-ID         TO  MIR-PLAN-ID
               MOVE RPLIP-PRFL-ID         TO  MIR-PRFL-ID
               MOVE RPLIP-SBSDRY-CO-ID    TO  MIR-SBSDRY-CO-ID
               MOVE RPLIP-LOC-GR-ID       TO  MIR-LOC-GR-ID
           END-IF.

           PERFORM  PLIP-3000-END-BROWSE
               THRU PLIP-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-PLIP.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PLIP-2000-READ-NEXT
               THRU PLIP-2000-READ-NEXT-X.

       2010-BROWSE-PLIP-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES              TO WPLIP-KEY.
           MOVE MIR-PLAN-ID             TO WPLIP-PLAN-ID.

           IF  MIR-PRFL-ID       = SPACES
           OR  MIR-PRFL-ID       = EBLCH-BLANK-FIELD-CHAR
               CONTINUE
           ELSE
               MOVE MIR-PRFL-ID         TO WPLIP-PRFL-ID
           END-IF.

           IF  MIR-SBSDRY-CO-ID  = SPACES
           OR  MIR-SBSDRY-CO-ID  = EBLCH-BLANK-FIELD-CHAR
               CONTINUE
           ELSE
               MOVE MIR-SBSDRY-CO-ID    TO WPLIP-SBSDRY-CO-ID
           END-IF.

           IF  MIR-LOC-GR-ID     = SPACES
           OR  MIR-LOC-GR-ID     = EBLCH-BLANK-FIELD-CHAR
               CONTINUE
           ELSE
               MOVE MIR-LOC-GR-ID       TO WPLIP-LOC-GR-ID
           END-IF.

           MOVE HIGH-VALUES             TO WPLIP-ENDBR-KEY.
           MOVE WPLIP-PLAN-ID           TO WPLIP-ENDBR-PLAN-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                    TO  MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RPLIP-PRFL-ID         TO  MIR-PRFL-ID-T      (WS-SUB).
           MOVE RPLIP-SBSDRY-CO-ID    TO  MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE RPLIP-LOC-GR-ID       TO  MIR-LOC-GR-ID-T    (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBPLIP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2574
      *****************************************************************
