      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3184.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3184                                         **
      **  REMARKS:  PAAF - POLICY ACTIVITY AUDIT FIELD TABLE LIST    **
      **            THIS MODULE LISTS ENTRIES IN THE PAAF TABLE      **
      **            FOR A SPECIFIED POLICY                           **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3184'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-BR-CTR                PIC S9(04).
025970         88  WS-MAX-BR-CTR-DEFAULT    VALUE +50.
025970
       01  WS-PGM-WORK-AREA.
025970*    05  WS-SUB                       PIC S9(04)  COMP.
025970     05  WS-SUB                       PIC S9(04)  BINARY.
025970*    05  WS-MAX-BR-CTR                PIC S9(04).
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '3184'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWINDX.
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPAAG.
       COPY CCFRPAAF.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY CCWL2430.
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1646.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3184.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

023514*    PERFORM  9990-INIT-WORKING-STORAGE
023514*        THRU 9990-INIT-WORKING-STORAGE-X.
023514*
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3184'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  MIR-POL-ID  = SPACES
      *MSG:    POLICY ID IS REQUIRED
               MOVE 'CS31840001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR        TO TRUE
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           MOVE MIR-POL-ID               TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG:    POLICY ID DOES NOT EXIST
               MOVE 'XS00000070'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ID               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR        TO TRUE
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           IF  MIR-PAAFLD-GR-TS = SPACES
               MOVE WWKDT-HIGH-TS            TO MIR-PAAFLD-GR-TS
           ELSE
               PERFORM  1646-1000-BUILD-PARM-INFO
                   THRU 1646-1000-BUILD-PARM-INFO-X
               MOVE MIR-PAAFLD-GR-TS      TO L1646-TIMESTAMP
               PERFORM  1646-1000-EDIT-TIMESTAMP
                   THRU 1646-1000-EDIT-TIMESTAMP-X
               IF  L1646-EDIT-FAILED
                   SET WGLOB-RETURN-ERROR TO  TRUE
                   MOVE 'CS31840002'      TO  WGLOB-MSG-REF-INFO
      * MSG: INVALID TIMESTAMP
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
                   GO TO 3500-PROCESS-LIST-X
              END-IF
           END-IF.

           PERFORM  3510-BROWSE-NORMAL
               THRU 3510-BROWSE-NORMAL-X.

           PERFORM  9250-MOVE-OTHER-TO-SCREEN
               THRU 9250-MOVE-OTHER-TO-SCREEN-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------
       3510-BROWSE-NORMAL.
      *-------------------

           MOVE HIGH-VALUES             TO WPAAG-KEY.
           MOVE LOW-VALUES              TO WPAAG-ENDBR-KEY.

           MOVE MIR-POL-ID              TO WPAAG-POL-ID.
           MOVE MIR-PAAFLD-GR-TS        TO WPAAG-PAAFLD-GR-TS.

           MOVE 001                     TO WPAAG-PAAFLD-SEQ-NUM.
           MOVE WPAAG-KEY               TO WPAAG-ENDBR-KEY.
           MOVE WWKDT-LOW-TS            TO WPAAG-ENDBR-PAAFLD-GR-TS.

           PERFORM  PAAG-1000-BROWSE-PREV
               THRU PAAG-1000-BROWSE-PREV-X.

           PERFORM  PAAG-2000-READ-PREV
               THRU PAAG-2000-READ-PREV-X.

           PERFORM  3600-DISPLAY-RECORD
               THRU 3600-DISPLAY-RECORD-X
               VARYING WS-SUB FROM 1 BY 1
                 UNTIL WS-SUB > WS-MAX-BR-CTR
                 OR    NOT WPAAG-IO-OK.

           IF  NOT WPAAG-IO-EOF
      *MSG: TO VIEW MORE DATA SELECT MORE
               MOVE 'XS00000014'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPAAF-POL-ID        TO MIR-POL-ID
               MOVE RPAAF-PAAFLD-GR-TS
                                     TO MIR-PAAFLD-GR-TS
               SET WGLOB-MORE-DATA-EXISTS
                                        TO TRUE
           ELSE
               IF  MIR-PAAFLD-GR-TS-T (1) > SPACES
                   MOVE MIR-PAAFLD-GR-TS-T (1)
                                     TO MIR-PAAFLD-GR-TS
      *MSG: END OF FILE REACHED
                   MOVE 'XS00000025'    TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORD FOUND FOR DISPLAY
                   MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  PAAG-3000-END-BROWSE-PREV
               THRU PAAG-3000-END-BROWSE-PREV-X.

       3510-BROWSE-NORMAL-X.
           EXIT.
      /
      *--------------------
       3600-DISPLAY-RECORD.
      *--------------------

           MOVE RPAAF-PAAFLD-GR-TS
                           TO MIR-PAAFLD-GR-TS-T        (WS-SUB).
           MOVE RPAAF-PAAFLD-FLD-ID
                           TO MIR-PAAFLD-FLD-ID-T       (WS-SUB).
           MOVE RPAAF-PAAFLD-VALU-TXT-TXT
                           TO MIR-PAAFLD-VALU-TXT-T     (WS-SUB).
           MOVE RPAAF-PAAFLD-GR-TS
                           TO WWKDT-INT-TS.
           MOVE WWKDT-INT-TS-DT
                           TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                           TO MIR-DV-PAAFLD-GR-DT-T     (WS-SUB).

           PERFORM PAAG-2000-READ-PREV
              THRU PAAG-2000-READ-PREV-X.

       3600-DISPLAY-RECORD-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                   TO MIR-PAAFLD-GR-TS-G.
           MOVE SPACE                   TO MIR-PAAFLD-FLD-ID-G.
           MOVE SPACE                   TO MIR-PAAFLD-VALU-TXT-G.
           MOVE SPACE                   TO MIR-DV-PAAFLD-GR-DT-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9250-MOVE-OTHER-TO-SCREEN.
      *--------------------------

           MOVE RPOL-SBSDRY-CO-ID        TO MIR-SBSDRY-CO-ID.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           MOVE L2430-CLI-NM-COMPRESSED  TO MIR-DV-OWN-CLI-NM.

       9250-MOVE-OTHER-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  WS-MAX-BR-CTR-DEFAULT   TO TRUE.
           SET  MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970*    MOVE +50                     TO WS-MAX-BR-CTR.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPS2430.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2430.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPS1646.
       COPY XCPL1646.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPVPAAG.
      /
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3184                     *
      ****************************************************************
