      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4915.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4915                                         **
      **  REMARKS:  THIS MODULE PROVIDES A LIST OF FURTHER DIVISIONS **
      **            OR BLOCKS FOR A POSTAL CODE USING PSAD           **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016110**  6.3       POSTAL CODE DEFAULT SELECTION BOX (6.1.2J)       **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024152**  6.5       PREVENT LOOPING IN CODESERVER                    **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
019320**  6.7       SELECTION BOXES ADDED FOR JP PREFECTURE AND CITY **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4915'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUSINESS-FUNCTION              PIC X(04).
               88  WS-BUSINESS-FUNCTION-LIST     VALUE '4915'.
018763*    05  WS-SUB                            PIC S9(04) COMP SYNC.
018763     05  WS-SUB                            PIC S9(04) BINARY SYNC.
018763*    05  WS-DUP-SUB                        PIC S9(04) COMP SYNC.
018763     05  WS-DUP-SUB                        PIC S9(04) BINARY SYNC.
025970*    05  WS-MAX-LIST-LINES                 PIC 9(03) VALUE 100.
025970     05  WS-MAX-LIST-LINES                 PIC 9(03).
           05  WS-DUPLICATE-ADDR-LN-SW           PIC X(01).
               88  WS-ADDR-LN-FOUND              VALUE 'Y'.
               88  WS-ADDR-LN-NOT-FOUND          VALUE 'N'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
021930*COPY XCWEBLCH.
021930*COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPSAD.
       COPY CCFRPSAD.
      /
021930*COPY CCWLPGA.
021930*
       COPY XCWL0290.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4915.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUSINESS-FUNCTION.

           EVALUATE TRUE

               WHEN WS-BUSINESS-FUNCTION-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4915'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           IF  MIR-CLI-CTRY-CD NOT = 'JP'
018732*    OR  NOT WGLOB-COUNTRY-JAPAN
           OR  MIR-CLI-PSTL-CD = SPACES
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PSAD-1000-BROWSE
               THRU PSAD-1000-BROWSE-X.

018763*    IF  NOT WPSAD-IO-OK
018763*MSG: NO RECORDS FOUND TO DISPLAY
018763*        MOVE 'XS00000034'            TO WGLOB-MSG-REF-INFO
018763*        PERFORM  0260-1000-GENERATE-MESSAGE
018763*            THRU 0260-1000-GENERATE-MESSAGE-X
018763*        SET MIR-RETRN-RQST-FAILED TO TRUE
018763*        GO TO 2000-LIST-X
018763*    END-IF.
018763*
           PERFORM  PSAD-2000-READ-NEXT
               THRU PSAD-2000-READ-NEXT-X.

024152*    IF  WPSAD-IO-EOF
024152*        PERFORM  PSAD-3000-END-BROWSE
024152*            THRU PSAD-3000-END-BROWSE-X
018763*MSG: NO RECORDS FOUND TO DISPLAY
018763*        MOVE 'XS00000034'            TO WGLOB-MSG-REF-INFO
018763*        PERFORM  0260-1000-GENERATE-MESSAGE
018763*            THRU 0260-1000-GENERATE-MESSAGE-X
018763*        SET MIR-RETRN-RQST-FAILED TO TRUE
024152*        GO TO 2000-LIST-X
024152*    END-IF.
024152*
           MOVE 1                          TO WS-SUB.
           PERFORM  2010-BROWSE-PSAD
               THRU 2010-BROWSE-PSAD-X
              UNTIL WS-SUB > WS-MAX-LIST-LINES
                 OR WPSAD-IO-EOF.

           IF  WPSAD-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
024152         MOVE RPSAD-PCADDR-SEQ-NUM   TO MIR-PCADDR-SEQ-NUM
           END-IF.

           PERFORM  PSAD-3000-END-BROWSE
               THRU PSAD-3000-END-BROWSE-X.

           SET MIR-RETRN-OK                TO TRUE.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
       2010-BROWSE-PSAD.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PSAD-2000-READ-NEXT
               THRU PSAD-2000-READ-NEXT-X.

       2010-BROWSE-PSAD-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE LOW-VALUES          TO WPSAD-KEY.
018763*    MOVE MIR-CLI-PSTL-CD     TO WPSAD-PSTL-CD.
018763     MOVE MIR-CLI-PSTL-CD     TO WPSAD-PCADDR-PSTL-CD.
           MOVE MIR-PCADDR-GR-CD
018763*                             TO WPSAD-PSTL-ADDR-GR-CD.
018763*    MOVE 000                 TO WPSAD-PSTL-ADDR-SEQ-NUM.
018763                              TO WPSAD-PCADDR-GR-CD.
024152*    MOVE 000                 TO WPSAD-PCADDR-SEQ-NUM.
024152
024152     IF  MIR-PCADDR-SEQ-NUM NOT NUMERIC
024152         MOVE ZERO            TO WPSAD-PCADDR-SEQ-NUM
024152     ELSE
024152         MOVE MIR-PCADDR-SEQ-NUM
024152           TO WPSAD-PCADDR-SEQ-NUM
024152     END-IF.
024152
           MOVE WPSAD-KEY           TO WPSAD-ENDBR-KEY.
018763*    MOVE 999                 TO WPSAD-ENDBR-PSTL-ADDR-SEQ-NUM.
018763     MOVE 999                 TO WPSAD-ENDBR-PCADDR-SEQ-NUM.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES              TO MIR-DV-SBOX-CD-G.
           MOVE SPACES              TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

      *
      * CHECK WHETHER THE ADDRESS LINE IS ALREADY LISTED OR NOT
      *
           IF  WS-SUB > 1
               SET WS-ADDR-LN-NOT-FOUND  TO TRUE
               PERFORM  9210-CHECK-DUPLICATE-ADDR-LN
                   THRU 9210-CHECK-DUPLICATE-ADDR-LN-X
                VARYING WS-DUP-SUB FROM 1 BY 1
                  UNTIL WS-DUP-SUB = WS-SUB
                     OR WS-ADDR-LN-FOUND
               IF  WS-ADDR-LN-FOUND
                   GO TO 9200-MOVE-RECORD-TO-SCREEN-X
               END-IF
           END-IF.

018763*    MOVE RPSAD-PSTL-ADDR-SEQ-NUM  TO L0290-INPUT-NUMBER.
020874*    MOVE RPSAD-PCADDR-SEQ-NUM     TO L0290-INPUT-NUMBER.
020874     MOVE RPSAD-PCADDR-SEQ-NUM     TO L0290-INPUT-V00.
           MOVE ZERO                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-SBOX-CD-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.

020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-DV-SBOX-CD-T (WS-SUB).

           EVALUATE MIR-DV-PCADDR-LN-TXT

               WHEN '1'
018763*             MOVE RPSAD-PSTL-ADDR-LN-1-TXT
018763              MOVE RPSAD-PCADDR-LN-1-TXT
                      TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB)

               WHEN '2'
018763*             MOVE RPSAD-PSTL-ADDR-LN-2-TXT
018763              MOVE RPSAD-PCADDR-LN-2-TXT
                      TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB)

019320         WHEN '3'
019320              MOVE RPSAD-PCADDR-CITY-NM-TXT
019320                TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB)
019320
019320         WHEN '4'
019320              MOVE RPSAD-PCADDR-ALT-ADDR-CD
019320                TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB)

           END-EVALUATE.

           ADD 1                         TO WS-SUB.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *-----------------------------
       9210-CHECK-DUPLICATE-ADDR-LN.
      *-----------------------------

           EVALUATE MIR-DV-PCADDR-LN-TXT

               WHEN '1'
018763*             IF  RPSAD-PSTL-ADDR-LN-1-TXT =
018763              IF  RPSAD-PCADDR-LN-1-TXT =
                        MIR-DV-SBOX-DESC-TXT-T (WS-DUP-SUB)

                        SET WS-ADDR-LN-FOUND    TO TRUE
                    END-IF

               WHEN '2'
018763*             IF  RPSAD-PSTL-ADDR-LN-2-TXT =
018763              IF  RPSAD-PCADDR-LN-2-TXT =
                        MIR-DV-SBOX-DESC-TXT-T (WS-DUP-SUB)

                        SET WS-ADDR-LN-FOUND    TO TRUE
                    END-IF

019320         WHEN '3'
019320              IF  RPSAD-PCADDR-CITY-NM-TXT =
019320                  MIR-DV-SBOX-DESC-TXT-T (WS-DUP-SUB)
019320
019320                  SET WS-ADDR-LN-FOUND    TO TRUE
019320              END-IF
019320
019320         WHEN '4'
019320              IF  RPSAD-PCADDR-ALT-ADDR-CD =
019320                  MIR-DV-SBOX-DESC-TXT-T (WS-DUP-SUB)
019320
019320                  SET WS-ADDR-LN-FOUND    TO TRUE
019320              END-IF

           END-EVALUATE.

       9210-CHECK-DUPLICATE-ADDR-LN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
023514     INITIALIZE WS-WORKING-STORAGE.
023514
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUSINESS-FUNCTION.
023514     COMPUTE WS-MAX-LIST-LINES = LENGTH OF MIR-DV-SBOX-CD-G
023514                               / LENGTH OF MIR-DV-SBOX-CD-T (1).
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
       COPY CCPBPSAD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4915                     **
      *****************************************************************
