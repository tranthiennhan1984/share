      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM1882.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1882                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE UPDATE FUNCTION   **
      **            FOR A SINGLE FV RECORD                           **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
023309**  6.5       LOCK CONTENTION ON FH TABLE                      **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1882'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '1882'.
           05  WS-FNDVL-EFF-DT               PIC X(10).
           05  WS-FNDVL-IDT-NUM              PIC X(07).
           05  WS-PURCH-PRIC-AMT             PIC 9(08)V9(09) COMP-3.
           05  WS-SELL-PRIC-AMT              PIC 9(08)V9(09) COMP-3.
           05  WS-DELTA-PRICE                PIC 9(08)V9(09) COMP-3.
           05  WS-UP-ABS                     PIC 9(08)V9(09) COMP-3.

           05  WS-FND-UNIT-QTY               PIC 9(12)V9(06) COMP-3.
           05  WS-FNDVL-PURCH-AMT            PIC 9(08)V9(09) COMP-3.
           05  WS-FNDVL-SELL-AMT             PIC 9(08)V9(09) COMP-3.
           05  WS-TMP-AMT                    PIC 9(08)V9(09) COMP-3.

           05  WS-PREV-FNDVL-EFF-DT          PIC X(10).
           05  WS-PREV-PURCH-PRIC-AMT        PIC 9(08)V9(09) COMP-3.
           05  WS-PREV-SELL-PRIC-AMT         PIC 9(08)V9(09) COMP-3.

           05  WS-OVRID-SW                   PIC X(01).
               88  WS-OVRID                  VALUE 'Y'.
               88  WS-OVRID-NO               VALUE 'N'.
023309     05  WS-FND-PREV-VALN-DT           PIC X(10).

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1880'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1880'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWFH.
       COPY SCFRFH.

023309 COPY SCFWFDUP.
023309 COPY SCFRFDUT.
023309
       COPY SCFWFV.
       COPY SCFRFV.

       COPY CCWWLOCK.
023309 COPY XCWWWKDT.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWL1670.
       COPY XCWL1680.
       COPY XCWL7721.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1882.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-UPDATE.
      *-------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           SET WS-OVRID-NO             TO TRUE.

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           MOVE WS-OVRID-SW            TO MIR-DV-PRCES-OVRID-IND.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               IF  MIR-DV-PRCES-STATE-CD = '3'
               AND NOT MIR-RETRN-TS-MISMATCH
                   PERFORM  FH-3000-UNLOCK
                       THRU FH-3000-UNLOCK-X
               END-IF
               GO TO 2000-UPDATE-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  FV-1000-READ-FOR-UPDATE
               THRU FV-1000-READ-FOR-UPDATE-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           IF  WS-PURCH-PRIC-AMT = RFV-PURCH-PRIC-AMT
           AND WS-SELL-PRIC-AMT = RFV-SELL-PRIC-AMT
               PERFORM  FV-3000-UNLOCK
                   THRU FV-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

           MOVE WS-PURCH-PRIC-AMT           TO RFV-PURCH-PRIC-AMT.
           MOVE WS-SELL-PRIC-AMT            TO RFV-SELL-PRIC-AMT.

023309     PERFORM  2200-FND-PREV-VALN-DT
023309         THRU 2200-FND-PREV-VALN-DT-X.
023309
023309*    IF  RFV-FNDVL-EFF-DT <= RFH-FND-PREV-VALN-DT
023309     IF  RFV-FNDVL-EFF-DT <= WS-FND-PREV-VALN-DT
               SET RFV-FNDVL-CHNG           TO TRUE
           END-IF.

           PERFORM  FV-2000-REWRITE
               THRU FV-2000-REWRITE-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           PERFORM  FH-2000-REWRITE
               THRU FH-2000-REWRITE-X.

           PERFORM  FH-1000-READ-TWRK-TS
               THRU FH-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-FND-ID
               THRU 2110-EDIT-FND-ID-X.

           PERFORM  2120-EDIT-FNDVL-EFF-DT
               THRU 2120-EDIT-FNDVL-EFF-DT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2100-VALIDATE-DATA-X
           END-IF.

           PERFORM  2130-EDIT-FV-REC
               THRU 2130-EDIT-FV-REC-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2100-VALIDATE-DATA-X
           END-IF.

           PERFORM  2135-GET-PREV-PRICE
               THRU 2135-GET-PREV-PRICE-X.

           PERFORM  2140-EDIT-PURCH-PRICE
               THRU 2140-EDIT-PURCH-PRICE-X.

           PERFORM  2150-EDIT-SELL-PRICE
               THRU 2150-EDIT-SELL-PRICE-X.

           PERFORM  2160-EDIT-FND-UNIT-QTY
               THRU 2160-EDIT-FND-UNIT-QTY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2100-VALIDATE-DATA-X
           END-IF.

           PERFORM  2170-EDIT-FNDVL-PURCH-AMT
               THRU 2170-EDIT-FNDVL-PURCH-AMT-X.

           PERFORM  2180-EDIT-FNDVL-SELL-AMT
               THRU 2180-EDIT-FNDVL-SELL-AMT-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-FND-ID.
      *----------------------------

           MOVE MIR-FND-ID                  TO WFH-FND-ID.

           IF  MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  FH-2000-UPDATE-TWRK-TS
                   THRU FH-2000-UPDATE-TWRK-TS-X
           ELSE
               PERFORM  FH-1000-READ-TWRK-TS
                   THRU FH-1000-READ-TWRK-TS-X
           END-IF.

           IF  WFH-IO-NOT-FOUND
      *MSG: RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (1)
               MOVE 'FH'                    TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD = '3'
           AND MIR-RETRN-TS-MISMATCH
      *MSG: PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *     UPDATED - TABLE (@1), KEY @2
               MOVE 'XS00000303'            TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                    TO WGLOB-MSG-PARM (1)
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-FND-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-FNDVL-EFF-DT.
      *----------------------------

           MOVE MIR-FNDVL-EFF-DT       TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID FUND VALUATION DATE
               MOVE 'SS18820001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2120-EDIT-FNDVL-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE         TO WS-FNDVL-EFF-DT.

           MOVE WS-FNDVL-EFF-DT             TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE         TO WS-FNDVL-IDT-NUM.


           IF  WS-FNDVL-EFF-DT <= RFH-PREV-UNIT-ALLOC-DT
      *MSG: FV RECORD HAS BEEN USED TO ESTABLISH UNITS - CAN'T MAINTAIN
               MOVE 'SS18820002'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2120-EDIT-FNDVL-EFF-DT-X.
           EXIT.

      *----------------------------
       2130-EDIT-FV-REC.
      *----------------------------

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2130-EDIT-FV-REC-X
           END-IF.

           MOVE LOW-VALUES               TO WFV-KEY.

           MOVE MIR-FND-ID               TO WFV-FND-ID.
           MOVE MIR-FNDVL-UNIT-TYP-CD    TO WFV-FNDVL-UNIT-TYP-CD.
           MOVE ZERO                     TO WFV-FNDVL-IDT-NUM.

           MOVE WFV-KEY                  TO WFV-ENDBR-KEY.
           MOVE ALL '9'                  TO WFV-ENDBR-FNDVL-IDT-NUM.

           PERFORM  FV-1000-BROWSE
               THRU FV-1000-BROWSE-X.

           PERFORM  FV-2000-READ-NEXT
               THRU FV-2000-READ-NEXT-X.

           IF  NOT WFV-IO-OK
      *MSG: NO FV RECORDS EXIST FOR THIS FUND
               MOVE 'SS18820003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  FV-3000-END-BROWSE
                   THRU FV-3000-END-BROWSE-X
               GO TO 2130-EDIT-FV-REC-X
           END-IF

           IF  RFV-FNDVL-EFF-DT NOT = WS-FNDVL-EFF-DT
      *MSG: EFF. DATE MUST BE DATE OF MOST RECENT FV RECORD
               MOVE 'SS18820004'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-OVRID                 TO TRUE
           END-IF

           PERFORM  FV-3000-END-BROWSE
               THRU FV-3000-END-BROWSE-X.

       2130-EDIT-FV-REC-X.
           EXIT.

      *----------------------------
       2135-GET-PREV-PRICE.
      *----------------------------

           IF  WS-FNDVL-EFF-DT = RFH-FND-CREAT-DT
               GO TO 2135-GET-PREV-PRICE-X
           END-IF.

           MOVE LOW-VALUES                  TO WFV-KEY.

           MOVE MIR-FND-ID                  TO WFV-FND-ID.
           MOVE MIR-FNDVL-UNIT-TYP-CD       TO WFV-FNDVL-UNIT-TYP-CD.
           MOVE WS-FNDVL-IDT-NUM            TO WFV-FNDVL-IDT-NUM.

           MOVE WFV-KEY                     TO WFV-ENDBR-KEY.
           MOVE ALL '9'                     TO WFV-ENDBR-FNDVL-IDT-NUM.

           PERFORM  FV-1000-BROWSE
               THRU FV-1000-BROWSE-X.

           PERFORM  FV-2000-READ-NEXT
               THRU FV-2000-READ-NEXT-X.

           PERFORM  FV-2000-READ-NEXT
               THRU FV-2000-READ-NEXT-X.

           MOVE RFV-FNDVL-EFF-DT            TO WS-PREV-FNDVL-EFF-DT.
           MOVE RFV-PURCH-PRIC-AMT          TO WS-PREV-PURCH-PRIC-AMT.
           MOVE RFV-SELL-PRIC-AMT           TO WS-PREV-SELL-PRIC-AMT.

           PERFORM  FV-3000-END-BROWSE
               THRU FV-3000-END-BROWSE-X.

       2135-GET-PREV-PRICE-X.
           EXIT.

      *----------------------------
       2140-EDIT-PURCH-PRICE.
      *----------------------------

           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.
           MOVE +9                          TO L0280-PRECISION.
           MOVE LENGTH OF MIR-PURCH-PRIC-AMT
                                            TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 2.
           MOVE MIR-PURCH-PRIC-AMT          TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-V09        TO WS-PURCH-PRIC-AMT
           ELSE
      *MSG: INVALID BUY PRICE
               MOVE 'SS18820005'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2140-EDIT-PURCH-PRICE-X
           END-IF.

           IF  WS-PURCH-PRIC-AMT <= ZERO
      *MSG: BUY PRICE MUST BE GREATER THAN ZERO
               MOVE 'SS18820017'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2140-EDIT-PURCH-PRICE-X
           END-IF.

           PERFORM  7721-0000-INIT-PARM-INFO
               THRU 7721-0000-INIT-PARM-INFO-X.

           MOVE WS-PURCH-PRIC-AMT           TO L7721-ABS-IN-INTG.
           MOVE WS-PURCH-PRIC-AMT           TO L7721-ABS-IN-DCML.
           SET L7721-SIGN-POS               TO TRUE.
           MOVE RFH-FND-PRIC-ACCUR-QTY      TO L7721-ACCUR-QTY.
           SET L7721-RND-NEAR               TO TRUE.

           PERFORM  7721-1000-NUMERIC-ROUND
               THRU 7721-1000-NUMERIC-ROUND-X.

           IF  L7721-RETRN-OK
           AND L7721-ABS-IN-INTG = L7721-ABS-RND-INTG
           AND L7721-ABS-IN-DCML = L7721-ABS-RND-DCML
               CONTINUE
           ELSE
      *MSG: BUY PRICE DOES NOT MATCH PRICE ACCURACY
               MOVE 'SS18820006'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-OVRID                 TO TRUE
           END-IF.

           IF  WS-FNDVL-EFF-DT = RFH-FND-CREAT-DT
               GO TO 2140-EDIT-PURCH-PRICE-X
           END-IF.

           MOVE WS-FNDVL-EFF-DT             TO L1680-INTERNAL-2.
           MOVE WS-PREV-FNDVL-EFF-DT        TO L1680-INTERNAL-1.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
           COMPUTE WS-DELTA-PRICE ROUNDED
                = WS-PREV-PURCH-PRIC-AMT
                * RFH-FND-XPCT-GRWTH-AMT
                / 100
                * LDTLK-DAYS-FACTOR.

           COMPUTE WS-UP-ABS = WS-PURCH-PRIC-AMT
                             - WS-PREV-PURCH-PRIC-AMT.

           IF  WS-UP-ABS > WS-DELTA-PRICE
      *MSG: BUY PRICE DOES NOT FOLLOW EXPECTED GROWTH
               MOVE 'SS18820007'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-OVRID                 TO TRUE
           END-IF.

       2140-EDIT-PURCH-PRICE-X.
           EXIT.

      *----------------------------
       2150-EDIT-SELL-PRICE.
      *----------------------------

           IF  RFH-FND-PRIC-STRUCT-CD = 'S'
               IF  WGLOB-MSG-ERROR-SW = ZERO
                   MOVE MIR-PURCH-PRIC-AMT  TO MIR-SELL-PRIC-AMT
                   MOVE WS-PURCH-PRIC-AMT   TO WS-SELL-PRIC-AMT
               END-IF
               GO TO 2150-EDIT-SELL-PRICE-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.
           MOVE +9                          TO L0280-PRECISION.
           MOVE LENGTH OF MIR-SELL-PRIC-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 2.
           MOVE MIR-SELL-PRIC-AMT           TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-V09        TO WS-SELL-PRIC-AMT
           ELSE
      *MSG: INVALID SELL PRICE
               MOVE 'SS18820008'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2150-EDIT-SELL-PRICE-X
           END-IF

           IF  WS-SELL-PRIC-AMT <= ZERO
      *MSG: SELL PRICE MUST BE GREATER THAN ZERO
               MOVE 'SS18820018'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2150-EDIT-SELL-PRICE-X
           END-IF.

           PERFORM  7721-0000-INIT-PARM-INFO
               THRU 7721-0000-INIT-PARM-INFO-X.

           MOVE WS-SELL-PRIC-AMT            TO L7721-ABS-IN-INTG.
           MOVE WS-SELL-PRIC-AMT            TO L7721-ABS-IN-DCML.
           SET L7721-SIGN-POS               TO TRUE.
           MOVE RFH-FND-PRIC-ACCUR-QTY      TO L7721-ACCUR-QTY.
           SET L7721-RND-NEAR               TO TRUE.

           PERFORM  7721-1000-NUMERIC-ROUND
               THRU 7721-1000-NUMERIC-ROUND-X.

           IF  L7721-RETRN-OK
           AND L7721-ABS-IN-INTG = L7721-ABS-RND-INTG
           AND L7721-ABS-IN-DCML = L7721-ABS-RND-DCML
               CONTINUE
           ELSE
      *MSG: SELL PRICE DOES NOT MATCH PRICE ACCURACY
               MOVE 'SS18820009'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-OVRID                 TO TRUE
           END-IF.

           IF  WS-FNDVL-EFF-DT = RFH-FND-CREAT-DT
               GO TO 2150-EDIT-SELL-PRICE-X
           END-IF.

           MOVE WS-FNDVL-EFF-DT             TO L1680-INTERNAL-2.
           MOVE WS-PREV-FNDVL-EFF-DT        TO L1680-INTERNAL-1.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
           COMPUTE WS-DELTA-PRICE ROUNDED
                = WS-PREV-SELL-PRIC-AMT
                * RFH-FND-XPCT-GRWTH-AMT
                / 100
                * LDTLK-DAYS-FACTOR.

           COMPUTE WS-UP-ABS = WS-SELL-PRIC-AMT
                             - WS-PREV-SELL-PRIC-AMT.

           IF  WS-UP-ABS > WS-DELTA-PRICE
      *MSG: SELL PRICE DOES NOT FOLLOW EXPECTED GROWTH
               MOVE 'SS18820010'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-OVRID                 TO TRUE
           END-IF.

       2150-EDIT-SELL-PRICE-X.
           EXIT.

      *----------------------------
       2160-EDIT-FND-UNIT-QTY.
      *----------------------------

           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.
           MOVE +6                          TO L0280-PRECISION.
           MOVE LENGTH OF MIR-FND-UNIT-QTY  TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 2.
           MOVE MIR-FND-UNIT-QTY            TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-V06        TO WS-FND-UNIT-QTY
           ELSE
      *MSG: INVALID UNIT QUANTITY
               MOVE 'SS18820011'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2160-EDIT-FND-UNIT-QTY-X
           END-IF.

           IF  WS-FND-UNIT-QTY = ZERO
      *MSG: UNIT QUANTITY MUST BE GREATER THAN ZERO
               MOVE 'SS18820019'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2160-EDIT-FND-UNIT-QTY-X
           END-IF.

           PERFORM  7721-0000-INIT-PARM-INFO
               THRU 7721-0000-INIT-PARM-INFO-X.

           MOVE WS-FND-UNIT-QTY             TO L7721-ABS-IN-INTG.
           MOVE WS-FND-UNIT-QTY             TO L7721-ABS-IN-DCML.
           SET L7721-SIGN-POS               TO TRUE.
           MOVE RFH-FND-UNIT-ACCUR-QTY      TO L7721-ACCUR-QTY.
           SET L7721-RND-NEAR               TO TRUE.

           PERFORM  7721-1000-NUMERIC-ROUND
               THRU 7721-1000-NUMERIC-ROUND-X.

           IF  L7721-RETRN-OK
           AND L7721-ABS-IN-INTG = L7721-ABS-RND-INTG
           AND L7721-ABS-IN-DCML = L7721-ABS-RND-DCML
               CONTINUE
           ELSE
      *MSG: UNIT QUANTITY DOES NOT MATCH UNIT ACCURACY
               MOVE 'SS18820012'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-OVRID                 TO TRUE
           END-IF.

       2160-EDIT-FND-UNIT-QTY-X.
           EXIT.

      *----------------------------
       2170-EDIT-FNDVL-PURCH-AMT.
      *----------------------------

           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.
           MOVE +9                          TO L0280-PRECISION.
           MOVE LENGTH OF MIR-DV-FNDVL-PURCH-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 2.
           MOVE MIR-DV-FNDVL-PURCH-AMT      TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-V09        TO WS-FNDVL-PURCH-AMT
           ELSE
      *MSG: INVALID PURCHASE AMOUNT
               MOVE 'SS18820013'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2170-EDIT-FNDVL-PURCH-AMT-X
           END-IF.

           COMPUTE WS-TMP-AMT ROUNDED = WS-FND-UNIT-QTY
                                      * WS-PURCH-PRIC-AMT.

           IF  WS-FNDVL-PURCH-AMT NOT = WS-TMP-AMT
      *MSG: PURCHASE AMOUNT DOES NOT MATCH QTY X PRICE
               MOVE 'SS18820014'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-OVRID                 TO TRUE
           END-IF.

       2170-EDIT-FNDVL-PURCH-AMT-X.
           EXIT.

      *----------------------------
       2180-EDIT-FNDVL-SELL-AMT.
      *----------------------------

           IF  RFH-FND-PRIC-STRUCT-CD = 'S'
               GO TO 2180-EDIT-FNDVL-SELL-AMT-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.
           MOVE +9                          TO L0280-PRECISION.
           MOVE LENGTH OF MIR-DV-FNDVL-SELL-AMT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 2.
           MOVE MIR-DV-FNDVL-SELL-AMT       TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-V09        TO WS-FNDVL-SELL-AMT
           ELSE
      *MSG: INVALID SELL AMOUNT
               MOVE 'SS18820015'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2180-EDIT-FNDVL-SELL-AMT-X
           END-IF.

           COMPUTE WS-TMP-AMT ROUNDED = WS-FND-UNIT-QTY
                                      * WS-SELL-PRIC-AMT.

           IF  WS-FNDVL-SELL-AMT NOT = WS-TMP-AMT
      *MSG: SELL AMOUNT DOES NOT MATCH QTY * PRICE
               MOVE 'SS18820016'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2180-EDIT-FNDVL-SELL-AMT-X.
           EXIT.

023309*----------------------------
023309 2200-FND-PREV-VALN-DT.
023309*----------------------------
023309
023309     MOVE LOW-VALUES               TO WFDUP-KEY.
023309     MOVE RFV-FND-ID               TO WFDUP-FND-ID.
023309     MOVE WWKDT-LOW-DT             TO WFDUP-FIA-UNIT-PRIC-DT.
023309
023309     MOVE WFDUP-KEY            TO WFDUP-ENDBR-KEY.
023309     MOVE WWKDT-HIGH-DT        TO WFDUP-ENDBR-FIA-UNIT-PRIC-DT.
023309
023309     PERFORM  FDUP-2000-READ-MAX
023309         THRU FDUP-2000-READ-MAX-X.
023309
023309     IF  WFDUP-IO-OK
023309         MOVE WFDUP-MAX-FIA-UNIT-PRIC-DT TO WS-FND-PREV-VALN-DT
023309     ELSE
023309         MOVE WWKDT-ZERO-DT              TO WS-FND-PREV-VALN-DT
023309     END-IF.
023309
023309 2200-FND-PREV-VALN-DT-X.
023309     EXIT.
023309
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-FND-ID             TO WFV-FND-ID.
           MOVE MIR-FNDVL-UNIT-TYP-CD  TO WFV-FNDVL-UNIT-TYP-CD.
           MOVE WS-FNDVL-IDT-NUM       TO WFV-FNDVL-IDT-NUM.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           MOVE SPACE                       TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                     TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE         TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  FV-1000-CALL-AUDIT
                   THRU FV-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7721-0000-INIT-PARM-INFO
025970         THRU 7721-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE MIR-OUTPUT-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970     MOVE SPACES                 TO WWKDT-WORK-FIELDS.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  FH
                                '$VAR2'   BY 'FH'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.

025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.

025970 COPY XCPS1640.
       COPY XCPL1640.

025970 COPY XCPS1660.
       COPY XCPL1660.

025970 COPY XCPS1680.
       COPY XCPL1680.

       COPY XCPS7721.
       COPY XCPL7721.

       COPY XCPL8090.

       COPY SCPLFV.

023309 COPY SCPFFDUP.
023309
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNFH.
       COPY SCPUFH.

       COPY SCPUFV.
       COPY SCPBFV.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM SSOM1882                        **
      *****************************************************************
