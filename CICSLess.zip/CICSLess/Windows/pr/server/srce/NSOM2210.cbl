      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM2210.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM2210                                         **
      **  REMARKS:  IRTT: MAINTAIN INCOME RATION TEST TABLE.         **
      **                                                             **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE INCOME RATIO TEST TABLE.       **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP, MOVE BROWSE                        **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
557973**  5.5       AMOUNT FIELD SIZING FOR INT'L SUPPORT            **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016475**  6.1       REMOVE 9900-DELETE-TWRK LOGIC                    **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM2210'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
       COPY XCWL8090.

       01  WS-CONSTANTS.
016548*    05  WS-NO-OF-DISPLAY-LINE        PIC S9(08) COMP
025970*    05  WS-NO-OF-DISPLAY-LINE        PIC S9(08) BINARY
025970*                                     VALUE +10.
025970     05  WS-NO-OF-DISPLAY-LINE        PIC S9(08) BINARY.
025970         88  WS-DEFAULT-NO-OF-DISPLAY-LINE       VALUE +10.
025970     05  WS-NUM-9-13-HIGH             PIC S9(13).
025970         88  WS-DEFAULT-NUM-9-13-HIGH VALUE +9999999999999.

       01  WS-COUNTERS.
016548*    05  WS-LINE                      PIC S9(08) COMP.
016548     05  WS-LINE                      PIC S9(08) BINARY.

       01  WS-SWITCHES.
           05  WS-DATA-EDITS-SW             PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1600' '1601'
                                                  '1602' '1603'
                                                  '1604'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1600'.
               88  WS-BUS-FCN-CREATE        VALUE '1601'.
               88  WS-BUS-FCN-UPDATE        VALUE '1602'.
               88  WS-BUS-FCN-DELETE        VALUE '1603'.
               88  WS-BUS-FCN-LIST          VALUE '1604'.
           05  WS-NUM-9-3                   PIC 9(03).
008455*    05  WS-NUM-9-7                   PIC 9(07).
008455*    05  WS-NUM-9-5                   PIC 9(05).
025970*    05  WS-NUM-9-13-HIGH             PIC S9(13)
025970*                                     VALUE +9999999999999.

016475*    05  WS-TWRK-KEY                  PIC X(4) VALUE '1600'.
018633*    05  WS-TWRK-KEY                  PIC X(4) VALUE '1604'.
018633*    05  WS-TWRK-AREA.
018633*        10  WS-HOLD-KEY.
018633*            15  WS-HOLD-AGE          PIC X(03).
018633*            15  WS-HOLD-OCC-CLASS    PIC X(02).
018633*            15  WS-HOLD-INCOME       PIC X(13).
018633*        10  WS-NEXT-KEY.
018633*            15  WS-NEXT-AGE          PIC X(03).
018633*            15  WS-NEXT-OCC-CLASS    PIC X(02).
018633*            15  WS-NEXT-INCOME       PIC X(13).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '1604'.
018633         15  LCOMM-HOLD-KEY.
018633             20  LCOMM-HOLD-AGE       PIC X(03).
018633             20  LCOMM-HOLD-OCC-CLASS PIC X(02).
018633             20  LCOMM-HOLD-INCOME    PIC X(13).
018633         15  LCOMM-NEXT-KEY.
018633             20  LCOMM-NEXT-AGE       PIC X(03).
018633             20  LCOMM-NEXT-OCC-CLASS PIC X(02).
018633             20  LCOMM-NEXT-INCOME    PIC X(13).
018633
557973 01  WS-WIRTT-KEY.
557973     05  WS-WIRTT-CO-ID               PIC X(02).
557973     05  WS-WIRTT-CLI-INSRD-AGE       PIC X(03).
557973     05  WS-WIRTT-CLI-INSRD-AGE-N     REDEFINES
557973         WS-WIRTT-CLI-INSRD-AGE       PIC 9(03).
557973     05  WS-WIRTT-OCCP-CLAS-CD        PIC X(02).
557973     05  WS-WIRTT-CLI-ANN-INCM-AMT    PIC X(13).

       COPY XCWEBLCH.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY NCFWIRTT.
       COPY NCFRIRTT.
      /
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
008455/
016537*COPY XCWWWKDT.
      /
014221 COPY CCWWLOCK.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM2210.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *****************************************************************
      *      PROCESS USER REQUEST
      *****************************************************************
      **********************
       2000-PROCESS-REQUEST.
      **********************

025970*    MOVE MIR-BUS-FCN-ID     TO  WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK       TO  TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           IF  WS-BUS-FCN-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
      ***  NUMERIC KEY FIELDS MUST BE ENTERED CORRECTLY FOR THE
      ***  REMAINING FUNCTIONS.

           PERFORM  2100-VALIDATE-KEY-FIELDS
               THRU 2100-VALIDATE-KEY-FIELDS-X
           IF NOT WS-DATA-EDITS-OK
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
           IF  WS-BUS-FCN-RETRIEVE
               PERFORM  3000-PROCESS-RETRIEVE
                   THRU 3000-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  3500-PROCESS-LIST
                   THRU 3500-PROCESS-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-DELETE
               PERFORM 6000-PROCESS-DELETE
                  THRU 6000-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      **************************
       2100-VALIDATE-KEY-FIELDS.
      **************************

           MOVE 'Y'                   TO WS-DATA-EDITS-SW.

           IF MIR-CLI-INSRD-AGE = SPACES
               MOVE ZEROS             TO MIR-CLI-INSRD-AGE
           ELSE
               PERFORM  4110-EDIT-AGE
                   THRU 4110-EDIT-AGE-X
557660     END-IF.

           IF MIR-CLI-ANN-INCM-AMT = SPACES
008455*        MOVE ZEROS    TO MIR-CLI-ANN-INCM-AMT
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  9251-FORMAT-INCAM
008455             THRU 9251-FORMAT-INCAM-X
           ELSE
               PERFORM  4130-EDIT-INCOME
                   THRU 4130-EDIT-INCOME-X
557660     END-IF.

       2100-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           PERFORM  8000-BUILD-IRTT-KEY
               THRU 8000-BUILD-IRTT-KEY-X.
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
014221*    PERFORM  IRTT-1000-READ
014221*        THRU IRTT-1000-READ-X.
014221     PERFORM  IRTT-1000-READ-TWRK-TS
014221         THRU IRTT-1000-READ-TWRK-TS-X.

           IF WIRTT-IO-NOT-FOUND
      *** MSG (S) RECORD (@1) NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WIRTT-KEY    TO WGLOB-MSG-PARM (1)
557973         MOVE WIRTT-CO-ID       TO WS-WIRTT-CO-ID
557973         MOVE WS-WIRTT-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           ELSE
               MOVE +1                TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY DISPLAY PROCESSING: DISPLAY THE CURRENT RECORD ONTO
      *  THE SCREEN DATA LINE GIVEN BY WS-LINE AND RETRIEVE THE NEXT
      *  RECORD.
      *****************************************************************
       3100-DISPLAY-RECORD.
      *
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *
           PERFORM  IRTT-2000-READ-NEXT
               THRU IRTT-2000-READ-NEXT-X.
      *
       3100-DISPLAY-RECORD-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************
       3500-PROCESS-LIST.

018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF  L8090-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT  TO WS-TWRK-AREA
018633     IF  LCOMM-RETRN-OK
018633         CONTINUE
           ELSE
018633*        MOVE SPACE                 TO WS-TWRK-AREA
018633         MOVE SPACE                 TO LCOMM-WORK-AREA
           END-IF.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      *** IF KEY HAS NOT BEEN CHANGED, ADVANCE TO NEXT AGE/OCC CLASS
018633*    IF WS-HOLD-KEY NOT = SPACES
018633*        IF WS-HOLD-AGE = MIR-CLI-INSRD-AGE
018633*        AND WS-HOLD-OCC-CLASS = MIR-OCCP-CLAS-CD
018633*        AND WS-HOLD-INCOME = MIR-CLI-ANN-INCM-AMT
018633*            MOVE WS-NEXT-AGE   TO MIR-CLI-INSRD-AGE
018633*            MOVE WS-NEXT-OCC-CLASS
018633     IF LCOMM-HOLD-KEY NOT = SPACES
018633         IF LCOMM-HOLD-AGE = MIR-CLI-INSRD-AGE
018633         AND LCOMM-HOLD-OCC-CLASS = MIR-OCCP-CLAS-CD
018633         AND LCOMM-HOLD-INCOME = MIR-CLI-ANN-INCM-AMT
018633             MOVE LCOMM-NEXT-AGE TO MIR-CLI-INSRD-AGE
018633             MOVE LCOMM-NEXT-OCC-CLASS
                                      TO MIR-OCCP-CLAS-CD
018633*            MOVE WS-NEXT-INCOME
018633             MOVE LCOMM-NEXT-INCOME
                                      TO MIR-CLI-ANN-INCM-AMT
018633*            MOVE SPACES        TO WS-TWRK-AREA
018633             MOVE SPACES        TO LCOMM-WORK-AREA
               ELSE
018633*            MOVE SPACES        TO WS-TWRK-AREA
018633             MOVE SPACES        TO LCOMM-WORK-AREA
557660         END-IF
557660     END-IF.

      ***  SETUP BROWSE KEY LIMITS
           PERFORM  8000-BUILD-IRTT-KEY
               THRU 8000-BUILD-IRTT-KEY-X.
           MOVE HIGH-VALUES           TO WIRTT-ENDBR-KEY.
557973     MOVE WS-NUM-9-13-HIGH      TO WIRTT-ENDBR-CLI-ANN-INCM-AMT.

      ***  POSITION AT AND READ FIRST RECORD.
           PERFORM  IRTT-1000-BROWSE
               THRU IRTT-1000-BROWSE-X.
           IF NOT WIRTT-IO-OK
018633*        MOVE SPACES            TO WS-TWRK-AREA
018633         MOVE SPACES            TO LCOMM-WORK-AREA
      *** MSG (S) NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO  3500-PROCESS-LIST-X
557660     END-IF.

           PERFORM  IRTT-2000-READ-NEXT
               THRU IRTT-2000-READ-NEXT-X.
           IF NOT WIRTT-IO-OK
018633*        MOVE SPACES            TO WS-TWRK-AREA
018633         MOVE SPACES            TO LCOMM-WORK-AREA
      *** MSG (S) NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO  3500-PROCESS-LIST-X
557660     END-IF.

           MOVE RIRTT-CLI-INSRD-AGE   TO MIR-CLI-INSRD-AGE.
           MOVE RIRTT-OCCP-CLAS-CD    TO MIR-OCCP-CLAS-CD.
557973*    MOVE RIRTT-CLI-ANN-INCM-AMT TO MIR-CLI-ANN-INCM-AMT.
008455*    MOVE RIRTT-CLI-ANN-INCM-AMT TO WS-NUM-9-7.
008455*    MOVE WS-NUM-9-7             TO MIR-CLI-ANN-INCM-AMT.
020874*    MOVE RIRTT-CLI-ANN-INCM-AMT TO L0290-INPUT-NUMBER.
020874     MOVE RIRTT-CLI-ANN-INCM-AMT TO L0290-INPUT-V00.
008455     PERFORM  9251-FORMAT-INCAM
008455         THRU 9251-FORMAT-INCAM-X.

      ***  LOAD SCREEN DATA ARRAY.
      ***  "MANUALLY" CHECK FOR END BROWSE CONDITIONS SO CAN
      ***  RECOGNIZE PHYSICAL END OF FILE
           PERFORM  3100-DISPLAY-RECORD
              THRU 3100-DISPLAY-RECORD-X
              VARYING WS-LINE FROM 1 BY 1
              UNTIL RIRTT-CLI-INSRD-AGE NOT = MIR-CLI-INSRD-AGE
                 OR RIRTT-OCCP-CLAS-CD NOT = MIR-OCCP-CLAS-CD
                 OR WS-LINE > WS-NO-OF-DISPLAY-LINE
                 OR WIRTT-IO-EOF.

      *  COMPLETION MESSAGE
           IF WIRTT-IO-EOF
      *** MSG (I) NO MORE ENTRIES TO DISPLAY
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
018633*        MOVE SPACES            TO WS-TWRK-AREA
018633         MOVE SPACES            TO LCOMM-WORK-AREA
           ELSE
               MOVE RIRTT-CLI-INSRD-AGE
018633*                               TO WS-NEXT-AGE
018633*        MOVE RIRTT-OCCP-CLAS-CD   TO WS-NEXT-OCC-CLASS
018633                                TO LCOMM-NEXT-AGE
018633         MOVE RIRTT-OCCP-CLAS-CD   TO LCOMM-NEXT-OCC-CLASS
557973*        MOVE RIRTT-CLI-ANN-INCM-AMT TO WS-NEXT-INCOME
008455*        MOVE RIRTT-CLI-ANN-INCM-AMT TO WS-NUM-9-7
008455*        MOVE WS-NUM-9-7             TO C2210-NEXT-INCOME
008455         MOVE RIRTT-CLI-ANN-INCM-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         MOVE 0                 TO L0290-PRECISION
018633*        MOVE LENGTH OF WS-NEXT-INCOME
018633         MOVE LENGTH OF LCOMM-NEXT-INCOME
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018633*        MOVE L0290-OUTPUT-DATA TO WS-NEXT-INCOME
018633         MOVE L0290-OUTPUT-DATA TO LCOMM-NEXT-INCOME

018633*        MOVE MIR-CLI-INSRD-AGE TO WS-HOLD-AGE
018633*        MOVE MIR-OCCP-CLAS-CD  TO WS-HOLD-OCC-CLASS
018633         MOVE MIR-CLI-INSRD-AGE TO LCOMM-HOLD-AGE
018633         MOVE MIR-OCCP-CLAS-CD  TO LCOMM-HOLD-OCC-CLASS
               MOVE MIR-CLI-ANN-INCM-AMT
018633*                               TO WS-HOLD-INCOME
018633                                TO LCOMM-HOLD-INCOME
               IF RIRTT-CLI-INSRD-AGE = MIR-CLI-INSRD-AGE
               AND RIRTT-OCCP-CLAS-CD = MIR-OCCP-CLAS-CD
557973*            MOVE RIRTT-CLI-ANN-INCM-AMT TO MIR-CLI-ANN-INCM-AMT
008455*            MOVE RIRTT-CLI-ANN-INCM-AMT TO WS-NUM-9-7
008455*            MOVE WS-NUM-9-7             TO MIR-CLI-ANN-INCM-AMT
008455             MOVE RIRTT-CLI-ANN-INCM-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455             PERFORM  9251-FORMAT-INCAM
008455                 THRU 9251-FORMAT-INCAM-X
008455
      *** MSG (I) TO VIEW MORE DATA - PRESS ENTER
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
               ELSE
      *** MSG *** END OF LIST ***
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
557660         END-IF
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      ***  END THE BROWSE.
           PERFORM  IRTT-3000-END-BROWSE
               THRU IRTT-3000-END-BROWSE-X.

018633*    MOVE WS-TWRK-AREA          TO L8090-AREA-INFO-TEXT.
018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *****************************************************************
      *  CREATE PROCESSING.
      *****************************************************************
       4000-PROCESS-CREATE.

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.
           IF NOT WS-DATA-EDITS-OK
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      ***  BUILD CONTROL FIELDS.
           PERFORM  8000-BUILD-IRTT-KEY
               THRU 8000-BUILD-IRTT-KEY-X.

      ***  CHECK RECORD EXISTENCE.
           PERFORM  IRTT-1000-READ
               THRU IRTT-1000-READ-X.
           IF WIRTT-IO-OK
      *** MSG (S) RECORD (@1) ALREADY EXISTS
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WIRTT-KEY    TO WGLOB-MSG-PARM (1)
557973         MOVE WIRTT-CO-ID       TO WS-WIRTT-CO-ID
557973         MOVE WS-WIRTT-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE +1                TO WS-LINE
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      ***  CREATE NEW RECORD.
           PERFORM  IRTT-1000-CREATE
               THRU IRTT-1000-CREATE-X.
           PERFORM  IRTT-1000-WRITE
               THRU IRTT-1000-WRITE-X.
014221     PERFORM  IRTT-1000-READ-TWRK-TS
014221         THRU IRTT-1000-READ-TWRK-TS-X.

      ***MSG (I) RECORD CREATED
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE +1                    TO WS-LINE.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT KEY FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       4100-EDIT-KEY-FIELDS.

           MOVE 'Y'                   TO WS-DATA-EDITS-SW.

           PERFORM  4110-EDIT-AGE
               THRU 4110-EDIT-AGE-X.

           PERFORM  4120-EDIT-OCC-CLASS
               THRU 4120-EDIT-OCC-CLASS-X.

           PERFORM  4130-EDIT-INCOME
               THRU 4130-EDIT-INCOME-X.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: AGE
      *****************************************************************
       4110-EDIT-AGE.

      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-INSRD-AGE     TO L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-9-3
               MOVE WS-NUM-9-3        TO MIR-CLI-INSRD-AGE
           ELSE
      *** MSG (S) AGE MUST BE NUMERIC IN FORMAT 999
               MOVE 'NS22100001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
               GO TO 4110-EDIT-AGE-X
557660     END-IF.

           IF L0280-OUTPUT > +120
      *** MSG (F) AGE SHOULD BE LESS THAN OR EQUAL TO 120
               MOVE 'NS22100010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       4110-EDIT-AGE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: CLASS
      *****************************************************************
       4120-EDIT-OCC-CLASS.

           MOVE MIR-OCCP-CLAS-CD      TO WEDIT-ETBL-VALU-ID.
           PERFORM OCCL-1000-EDIT
              THRU OCCL-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
      *** MSG (S) OCC CLASS MUST BE IN EDIT, TYPE OCCCL
               MOVE 'NS22100002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       4120-EDIT-OCC-CLASS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: INCOME
      *****************************************************************
       4130-EDIT-INCOME.

           IF MIR-CLI-ANN-INCM-AMT = SPACES
008455*        MOVE ZEROS      TO MIR-CLI-ANN-INCM-AMT
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  9251-FORMAT-INCAM
008455             THRU 9251-FORMAT-INCAM-X
               GO TO 4130-EDIT-INCOME-X
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
008455*    MOVE 7              TO L0280-LENGTH.
008455*    MOVE 7              TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-ANN-INCM-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-CLI-ANN-INCM-AMT  TO L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-7
008455*        MOVE WS-NUM-9-7           TO MIR-CLI-ANN-INCM-AMT
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  9251-FORMAT-INCAM
008455             THRU 9251-FORMAT-INCAM-X
           ELSE
      *** MSG (S) INCOME MUST BE NUMERIC IN FORMAT 9999999
               MOVE 'NS22100003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       4130-EDIT-INCOME-X.
           EXIT.
      /
      *****************************************************************
      *  MAINTAIN PROCESSING.
      *****************************************************************
       5000-PROCESS-UPDATE.

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           PERFORM  8000-BUILD-IRTT-KEY
               THRU 8000-BUILD-IRTT-KEY-X.
014221*    PERFORM  IRTT-1000-READ-FOR-UPDATE
014221*        THRU IRTT-1000-READ-FOR-UPDATE-X.
014221     PERFORM  IRTT-2000-UPDATE-TWRK-TS
014221         THRU IRTT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'IRTT'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WIRTT-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF WIRTT-IO-NOT-FOUND
      *** MSG (S) RECORD (@1) NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WIRTT-KEY            TO WGLOB-MSG-PARM (1)
557973         MOVE WIRTT-CO-ID       TO WS-WIRTT-CO-ID
557973         MOVE WS-WIRTT-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           MOVE +1                    TO WS-LINE.
           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

557973*    MOVE RIRTT-CLI-ANN-INCM-AMT TO MIR-CLI-ANN-INCM-AMT-T
557973*                                   (WS-LINE).
008455*    MOVE RIRTT-CLI-ANN-INCM-AMT TO WS-NUM-9-7.
008455*    MOVE WS-NUM-9-7             TO MIR-CLI-ANN-INCM-AMT-T
008455*                                   (WS-LINE).
020874*    MOVE RIRTT-CLI-ANN-INCM-AMT            TO L0290-INPUT-NUMBER.
020874     MOVE RIRTT-CLI-ANN-INCM-AMT            TO L0290-INPUT-V00.
008455     PERFORM  9250-FORMAT-INCAM-T
008455         THRU 9250-FORMAT-INCAM-T-X.

           PERFORM  IRTT-2000-REWRITE
               THRU IRTT-2000-REWRITE-X.

014221     PERFORM  IRTT-1000-READ-TWRK-TS
014221         THRU IRTT-1000-READ-TWRK-TS-X.

           IF WS-DATA-EDITS-OK
      *** MSG (I) MAINTAIN COMPLETE - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
           ELSE
      *** MSG (I) RECORD UPDATED
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       5300-EDIT-DATA-FIELDS.

           MOVE 'Y'                   TO WS-DATA-EDITS-SW.

      *    SET UP PARMS FOR NUMERIC EDIT ROUTINE

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
008455*    MOVE 5               TO L0280-LENGTH.
008455*    MOVE 5               TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-NTAXBL-NUIC-AMT-T (WS-LINE)
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH  = L0280-INPUT-SIZE.

           PERFORM  5310-EDIT-NONTAX-NO-UIC
               THRU 5310-EDIT-NONTAX-NO-UIC-X.

           PERFORM  5320-EDIT-NONTAX-UIC-EP1
               THRU 5320-EDIT-NONTAX-UIC-EP1-X.

           PERFORM  5330-EDIT-NONTAX-UIC-EP2
               THRU 5330-EDIT-NONTAX-UIC-EP2-X.

           PERFORM  5340-EDIT-TAX-NO-UIC
               THRU 5340-EDIT-TAX-NO-UIC-X.

           PERFORM  5350-EDIT-TAX-UIC-EP1
               THRU 5350-EDIT-TAX-UIC-EP1-X.

           PERFORM  5360-EDIT-TAX-UIC-EP2
               THRU 5360-EDIT-TAX-UIC-EP2-X.

           PERFORM  5390-XEDIT-DATA-FIELDS
               THRU 5390-XEDIT-DATA-FIELDS-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MAXIMUM AMT FOR NON-TAXABLE, NON-UIC, ANY EP : MUST BE NUMERIC
      *****************************************************************
       5310-EDIT-NONTAX-NO-UIC.

           IF MIR-NTAXBL-NUIC-AMT-T (WS-LINE) = SPACES
008455*        MOVE RIRTT-NTAXBL-NUIC-AMT   TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5      TO MIR-NTAXBL-NUIC-AMT-T (WS-LINE)
008455         MOVE RIRTT-NTAXBL-NUIC-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  9252-FORMAT-NTNU-T
008455            THRU  9252-FORMAT-NTNU-T-X
               GO TO 5310-EDIT-NONTAX-NO-UIC-X
557660     END-IF.

           IF MIR-NTAXBL-NUIC-AMT-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROES           TO MIR-NTAXBL-NUIC-AMT-T (WS-LINE)
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  9252-FORMAT-NTNU-T
008455            THRU  9252-FORMAT-NTNU-T-X
               MOVE ZEROES            TO RIRTT-NTAXBL-NUIC-AMT
               GO TO 5310-EDIT-NONTAX-NO-UIC-X
557660     END-IF.

           MOVE MIR-NTAXBL-NUIC-AMT-T (WS-LINE)
                                      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RIRTT-NTAXBL-NUIC-AMT
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5    TO MIR-NTAXBL-NUIC-AMT-T (WS-LINE)
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  9252-FORMAT-NTNU-T
008455            THRU  9252-FORMAT-NTNU-T-X
           ELSE
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC - FORMAT 99999
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC
               MOVE 'NS22100004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5310-EDIT-NONTAX-NO-UIC-X.
           EXIT.
      /
      *****************************************************************
      *  MAX AMOUNT FOR NON-TAXABLE, WITH UIC EP < 120 : MUST BE NUMERIC
      *****************************************************************
       5320-EDIT-NONTAX-UIC-EP1.

           IF MIR-NTAXBL-UIC-EP1-AMT-T (WS-LINE) = SPACES
008455*        MOVE RIRTT-NTAXBL-UIC-EP1-AMT TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5     TO MIR-NTAXBL-UIC-EP1-AMT-T (WS-LINE)
008455         MOVE RIRTT-NTAXBL-UIC-EP1-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  9254-FORMAT-NTUE1-T
008455             THRU 9254-FORMAT-NTUE1-T-X
               GO TO 5320-EDIT-NONTAX-UIC-EP1-X
557660     END-IF.

           IF MIR-NTAXBL-UIC-EP1-AMT-T (WS-LINE) =
                                  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROES        TO MIR-NTAXBL-UIC-EP1-AMT-T (WS-LINE)
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  9254-FORMAT-NTUE1-T
008455             THRU 9254-FORMAT-NTUE1-T-X
               MOVE ZEROES            TO RIRTT-NTAXBL-UIC-EP1-AMT
               GO TO 5320-EDIT-NONTAX-UIC-EP1-X
557660     END-IF.

           MOVE MIR-NTAXBL-UIC-EP1-AMT-T (WS-LINE)
                                      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RIRTT-NTAXBL-UIC-EP1-AMT
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5   TO MIR-NTAXBL-UIC-EP1-AMT-T (WS-LINE)
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  9254-FORMAT-NTUE1-T
008455             THRU 9254-FORMAT-NTUE1-T-X
           ELSE
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC - FORMAT 99999
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC
               MOVE 'NS22100004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5320-EDIT-NONTAX-UIC-EP1-X.
           EXIT.
      /
      *****************************************************************
      *  MAX AMT FOR NON-TAXABLE, WITH UIC EP => 120 : MUST BE NUMERIC
      *****************************************************************
       5330-EDIT-NONTAX-UIC-EP2.

           IF MIR-NTAXBL-UIC-EP2-AMT-T (WS-LINE) = SPACES
008455*        MOVE RIRTT-NTAXBL-UIC-EP2-AMT TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5  TO MIR-NTAXBL-UIC-EP2-AMT-T (WS-LINE)
008455         MOVE RIRTT-NTAXBL-UIC-EP2-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  9256-FORMAT-NTUE2-T
008455             THRU 9256-FORMAT-NTUE2-T-X
               GO TO 5330-EDIT-NONTAX-UIC-EP2-X
557660     END-IF.

           IF MIR-NTAXBL-UIC-EP2-AMT-T (WS-LINE) =
                                         EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROES      TO MIR-NTAXBL-UIC-EP2-AMT-T (WS-LINE)
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  9256-FORMAT-NTUE2-T
008455             THRU 9256-FORMAT-NTUE2-T-X
               MOVE ZEROES            TO RIRTT-NTAXBL-UIC-EP2-AMT
               GO TO 5330-EDIT-NONTAX-UIC-EP2-X
557660     END-IF.

           MOVE MIR-NTAXBL-UIC-EP2-AMT-T (WS-LINE)
                                      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RIRTT-NTAXBL-UIC-EP2-AMT
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5   TO MIR-NTAXBL-UIC-EP2-AMT-T (WS-LINE)
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  9256-FORMAT-NTUE2-T
008455             THRU 9256-FORMAT-NTUE2-T-X
           ELSE
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC - FORMAT 99999
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC
               MOVE 'NS22100004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5330-EDIT-NONTAX-UIC-EP2-X.
           EXIT.
      /
      *****************************************************************
      *  MAX AMT FOR TAXABLE, NON-UIC, ANY EP:  MUST BE NUMERIC
      *****************************************************************
       5340-EDIT-TAX-NO-UIC.

           IF MIR-TAXBL-NUIC-AMT-T (WS-LINE) = SPACES
008455*        MOVE RIRTT-TAXBL-NUIC-AMT TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5       TO MIR-TAXBL-NUIC-AMT-T (WS-LINE)
008455         MOVE RIRTT-TAXBL-NUIC-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  9258-FORMAT-TNU-T
008455             THRU 9258-FORMAT-TNU-T-X
               GO TO 5340-EDIT-TAX-NO-UIC-X
557660     END-IF.

           IF MIR-TAXBL-NUIC-AMT-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROES           TO MIR-TAXBL-NUIC-AMT-T (WS-LINE)
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  9258-FORMAT-TNU-T
008455             THRU 9258-FORMAT-TNU-T-X
               MOVE ZEROES            TO RIRTT-TAXBL-NUIC-AMT
               GO TO 5340-EDIT-TAX-NO-UIC-X
557660     END-IF.

           MOVE MIR-TAXBL-NUIC-AMT-T (WS-LINE)
                                      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RIRTT-TAXBL-NUIC-AMT
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5    TO MIR-TAXBL-NUIC-AMT-T (WS-LINE)
008455         MOVE RIRTT-TAXBL-NUIC-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  9258-FORMAT-TNU-T
008455             THRU 9258-FORMAT-TNU-T-X
           ELSE
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC - FORMAT 99999
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC
               MOVE 'NS22100004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5340-EDIT-TAX-NO-UIC-X.
           EXIT.
      /
      *****************************************************************
      *  MAX AMT FOR TAXABLE, WITH UIC EP < 120 : MUST BE NUMERIC
      *****************************************************************
       5350-EDIT-TAX-UIC-EP1.

           IF MIR-TAXBL-UIC-EP1-AMT-T (WS-LINE) = SPACES
008455*        MOVE RIRTT-TAXBL-UIC-EP1-AMT TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5    TO MIR-TAXBL-UIC-EP1-AMT-T (WS-LINE)
008455         MOVE RIRTT-TAXBL-UIC-EP1-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  9260-FORMAT-TUE1-T
008455             THRU 9260-FORMAT-TUE1-T-X
               GO TO 5350-EDIT-TAX-UIC-EP1-X
557660     END-IF.

           IF MIR-TAXBL-UIC-EP1-AMT-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROES        TO MIR-TAXBL-UIC-EP1-AMT-T (WS-LINE)
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  9260-FORMAT-TUE1-T
008455             THRU 9260-FORMAT-TUE1-T-X
               MOVE ZEROES            TO RIRTT-TAXBL-UIC-EP1-AMT
               GO TO 5350-EDIT-TAX-UIC-EP1-X
557660     END-IF.

           MOVE MIR-TAXBL-UIC-EP1-AMT-T (WS-LINE)
                                      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RIRTT-TAXBL-UIC-EP1-AMT
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5    TO MIR-TAXBL-UIC-EP1-AMT-T (WS-LINE)
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  9260-FORMAT-TUE1-T
008455             THRU 9260-FORMAT-TUE1-T-X
           ELSE
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC - FORMAT 99999
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC
               MOVE 'NS22100004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5350-EDIT-TAX-UIC-EP1-X.
           EXIT.
      /
      *****************************************************************
      *  MAX AMT FOR TAXABLE, WITH UIC EP => 120 : MUST BE NUMERIC
      *****************************************************************
       5360-EDIT-TAX-UIC-EP2.

           IF MIR-TAXBL-UIC-EP2-AMT-T (WS-LINE) = SPACES
008455*        MOVE RIRTT-TAXBL-UIC-EP2-AMT TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5    TO MIR-TAXBL-UIC-EP2-AMT-T (WS-LINE)
008455         MOVE RIRTT-TAXBL-UIC-EP2-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  9262-FORMAT-TUE2-T
008455             THRU 9262-FORMAT-TUE2-T-X
               GO TO 5360-EDIT-TAX-UIC-EP2-X
557660     END-IF.

           IF MIR-TAXBL-UIC-EP2-AMT-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROES       TO MIR-TAXBL-UIC-EP2-AMT-T (WS-LINE)
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  9262-FORMAT-TUE2-T
008455             THRU 9262-FORMAT-TUE2-T-X
               MOVE ZEROES            TO RIRTT-TAXBL-UIC-EP2-AMT
               GO TO 5360-EDIT-TAX-UIC-EP2-X
557660     END-IF.

           MOVE MIR-TAXBL-UIC-EP2-AMT-T (WS-LINE)
                                      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RIRTT-TAXBL-UIC-EP2-AMT
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-5
008455*        MOVE WS-NUM-9-5    TO MIR-TAXBL-UIC-EP2-AMT-T (WS-LINE)
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  9262-FORMAT-TUE2-T
008455             THRU 9262-FORMAT-TUE2-T-X
           ELSE
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC - FORMAT 99999
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC
               MOVE 'NS22100004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5360-EDIT-TAX-UIC-EP2-X.
           EXIT.
      /
      ******************************************************************
      *  XEDIT DATA FIELDS:  NON-UIC, ANY EP SHOULD EQUAL UIC
      *  EP<120 + EP=120+
      ******************************************************************
       5390-XEDIT-DATA-FIELDS.

           IF (RIRTT-NTAXBL-UIC-EP1-AMT + RIRTT-NTAXBL-UIC-EP2-AMT)
               NOT = RIRTT-NTAXBL-NUIC-AMT
      *** MSG (F) SUM OF UIC AMOUNTS MUST EQUAL NON-UIC AMOUNT
               MOVE 'NS22100005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

           IF (RIRTT-TAXBL-UIC-EP1-AMT + RIRTT-TAXBL-UIC-EP2-AMT) NOT =
              RIRTT-TAXBL-NUIC-AMT
      *** MSG (F) SUM OF UIC AMOUNTS MUST EQUAL NON-UIC AMOUNT
               MOVE 'NS22100005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       5390-XEDIT-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  DELETE PROCESSING:
      *****************************************************************
       6000-PROCESS-DELETE.


016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           PERFORM  8000-BUILD-IRTT-KEY
               THRU 8000-BUILD-IRTT-KEY-X.
014221*    PERFORM  IRTT-1000-READ-FOR-UPDATE
014221*        THRU IRTT-1000-READ-FOR-UPDATE-X.
014221     PERFORM  IRTT-2000-UPDATE-TWRK-TS
014221         THRU IRTT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'IRTT'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WIRTT-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WIRTT-IO-NOT-FOUND
      *** MSG (S) RECORD (@1) NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WIRTT-KEY        TO WGLOB-MSG-PARM (1)
557973         MOVE WIRTT-CO-ID       TO WS-WIRTT-CO-ID
557973         MOVE WS-WIRTT-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
      *** MSG (I) RECORD DELETED - CONTINUE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  IRTT-1000-DELETE
                   THRU IRTT-1000-DELETE-X
557660     END-IF.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *****************************************************************
      *  BUILD IRTT KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       8000-BUILD-IRTT-KEY.

           MOVE MIR-CLI-INSRD-AGE     TO WIRTT-CLI-INSRD-AGE.
           MOVE MIR-OCCP-CLAS-CD      TO WIRTT-OCCP-CLAS-CD.
557973*    MOVE MIR-CLI-ANN-INCM-AMT  TO WIRTT-CLI-ANN-INCM-AMT.
008455*    MOVE MIR-CLI-ANN-INCM-AMT  TO WS-NUM-9-7.
008455*    MOVE WS-NUM-9-7       TO WIRTT-CLI-ANN-INCM-AMT.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE ZERO                  TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-ANN-INCM-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH   = L0280-INPUT-SIZE.
008455     MOVE MIR-CLI-ANN-INCM-AMT  TO L0280-INPUT-DATA.
008455
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455     MOVE L0280-OUTPUT          TO WIRTT-CLI-ANN-INCM-AMT.

557973*
557973*  BUILD DISPLAY WIRTT-KEY FIELD FOR ERROR MESSAGE
557973*
557973     MOVE MIR-CLI-INSRD-AGE     TO WS-WIRTT-CLI-INSRD-AGE.
557973     MOVE MIR-OCCP-CLAS-CD      TO WS-WIRTT-OCCP-CLAS-CD.
557973     MOVE MIR-CLI-ANN-INCM-AMT  TO WS-WIRTT-CLI-ANN-INCM-AMT.

       8000-BUILD-IRTT-KEY-X.
           EXIT.

      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.

           MOVE SPACES                TO MIR-CLI-ANN-INCM-AMT-G.
           MOVE SPACES                TO MIR-NTAXBL-NUIC-AMT-G.
           MOVE SPACES                TO MIR-NTAXBL-UIC-EP1-AMT-G.
           MOVE SPACES                TO MIR-NTAXBL-UIC-EP2-AMT-G.
           MOVE SPACES                TO MIR-TAXBL-NUIC-AMT-G.
           MOVE SPACES                TO MIR-TAXBL-UIC-EP1-AMT-G.
           MOVE SPACES                TO MIR-TAXBL-UIC-EP2-AMT-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.

557973*    MOVE RIRTT-CLI-ANN-INCM-AMT TO MIR-CLI-ANN-INCM-AMT-T
557973*                                   (WS-LINE).
008455*    MOVE RIRTT-CLI-ANN-INCM-AMT TO WS-NUM-9-7.
008455*    MOVE WS-NUM-9-7             TO MIR-CLI-ANN-INCM-AMT-T
008455*                                   (WS-LINE).
008455*    MOVE RIRTT-NTAXBL-NUIC-AMT  TO WS-NUM-9-5.
008455*    MOVE WS-NUM-9-5             TO MIR-NTAXBL-NUIC-AMT-T
008455*                                   (WS-LINE).
008455*    MOVE RIRTT-NTAXBL-UIC-EP1-AMT TO WS-NUM-9-5.
008455*    MOVE WS-NUM-9-5             TO MIR-NTAXBL-UIC-EP1-AMT-T
008455*                                   (WS-LINE).
008455*    MOVE RIRTT-NTAXBL-UIC-EP2-AMT TO WS-NUM-9-5.
008455*    MOVE WS-NUM-9-5             TO MIR-NTAXBL-UIC-EP2-AMT-T
008455*                                   (WS-LINE).
008455*    MOVE RIRTT-TAXBL-NUIC-AMT   TO WS-NUM-9-5.
008455*    MOVE WS-NUM-9-5             TO MIR-TAXBL-NUIC-AMT-T
008455*                                   (WS-LINE).
008455*    MOVE RIRTT-TAXBL-UIC-EP1-AMT TO WS-NUM-9-5.
008455*    MOVE WS-NUM-9-5             TO MIR-TAXBL-UIC-EP1-AMT-T
008455*                                   (WS-LINE).
008455*    MOVE RIRTT-TAXBL-UIC-EP2-AMT TO WS-NUM-9-5.
008455*    MOVE WS-NUM-9-5             TO MIR-TAXBL-UIC-EP2-AMT-T
008455*                                   (WS-LINE).
020874*    MOVE RIRTT-CLI-ANN-INCM-AMT  TO L0290-INPUT-NUMBER.
020874     MOVE RIRTT-CLI-ANN-INCM-AMT  TO L0290-INPUT-V00.
008455     PERFORM  9250-FORMAT-INCAM-T
008455         THRU 9250-FORMAT-INCAM-T-X.
020874*    MOVE RIRTT-NTAXBL-NUIC-AMT TO L0290-INPUT-NUMBER.
020874     MOVE RIRTT-NTAXBL-NUIC-AMT TO L0290-INPUT-V00.
008455     PERFORM  9252-FORMAT-NTNU-T
008455         THRU 9252-FORMAT-NTNU-T-X.
008455     MOVE RIRTT-NTAXBL-UIC-EP1-AMT
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     PERFORM  9254-FORMAT-NTUE1-T
008455         THRU 9254-FORMAT-NTUE1-T-X.
008455     MOVE RIRTT-NTAXBL-UIC-EP2-AMT
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     PERFORM  9256-FORMAT-NTUE2-T
008455         THRU 9256-FORMAT-NTUE2-T-X.
020874*    MOVE RIRTT-TAXBL-NUIC-AMT  TO L0290-INPUT-NUMBER.
020874     MOVE RIRTT-TAXBL-NUIC-AMT  TO L0290-INPUT-V00.
008455     PERFORM  9258-FORMAT-TNU-T
008455         THRU 9258-FORMAT-TNU-T-X.
008455     MOVE RIRTT-TAXBL-UIC-EP1-AMT
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     PERFORM  9260-FORMAT-TUE1-T
008455         THRU 9260-FORMAT-TUE1-T-X.
008455     MOVE RIRTT-TAXBL-UIC-EP2-AMT
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     PERFORM  9262-FORMAT-TUE2-T
008455         THRU 9262-FORMAT-TUE2-T-X.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
008455 9250-FORMAT-INCAM-T.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-ANN-INCM-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-CLI-ANN-INCM-AMT-T (WS-LINE).
008455 9250-FORMAT-INCAM-T-X.
008455     EXIT.
008455/
008455 9251-FORMAT-INCAM.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-ANN-INCM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CLI-ANN-INCM-AMT.
008455 9251-FORMAT-INCAM-X.
008455     EXIT.
008455/
008455 9252-FORMAT-NTNU-T.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-NTAXBL-NUIC-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-NTAXBL-NUIC-AMT-T (WS-LINE).
008455 9252-FORMAT-NTNU-T-X.
008455     EXIT.
008455/
008455 9254-FORMAT-NTUE1-T.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-NTAXBL-UIC-EP1-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-NTAXBL-UIC-EP1-AMT-T
008455                                (WS-LINE).
008455 9254-FORMAT-NTUE1-T-X.
008455     EXIT.
008455/
008455 9256-FORMAT-NTUE2-T.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-NTAXBL-UIC-EP2-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-NTAXBL-UIC-EP2-AMT-T (WS-LINE).
008455 9256-FORMAT-NTUE2-T-X.
008455     EXIT.
008455/
008455 9258-FORMAT-TNU-T.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TAXBL-NUIC-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-TAXBL-NUIC-AMT-T (WS-LINE).
008455 9258-FORMAT-TNU-T-X.
008455     EXIT.
008455/
008455 9260-FORMAT-TUE1-T.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TAXBL-UIC-EP1-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA  TO MIR-TAXBL-UIC-EP1-AMT-T (WS-LINE).
008455 9260-FORMAT-TUE1-T-X.
008455     EXIT.
008455/
008455 9262-FORMAT-TUE2-T.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TAXBL-UIC-EP2-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA  TO MIR-TAXBL-UIC-EP2-AMT-T (WS-LINE).
008455 9262-FORMAT-TUE2-T-X.
008455     EXIT.
008455/
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-COUNTERS.
025970     INITIALIZE                         WS-SWITCHES.
025970     INITIALIZE                         WS-WIRTT-KEY.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-NO-OF-DISPLAY-LINE  TO TRUE.
025970     SET WS-DEFAULT-NUM-9-13-HIGH       TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO  WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

018633*--------------------
018633*9500-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*     MOVE WS-TWRK-KEY          TO L8090-BUS-FCN-ID.
018633*     MOVE ZEROS                TO L8090-TEMP-WRK-SEQ-NUM.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    SET L8090-USAGE-COMM       TO TRUE.
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*----------------
018633*9800-WRITE-TWRK.
018633*----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    SET L8090-USAGE-COMM       TO TRUE.
018633*    MOVE LENGTH OF WS-TWRK-AREA TO L8090-AREA-LEN.
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9900-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    SET L8090-USAGE-COMM       TO TRUE.
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
018633*
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
      /
       COPY CCPEOCCL.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY IRTT
014221                         '$VAR2' BY 'IRTT'.
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455/
       COPY XCPPINIT.
      /
021930*COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
       COPY NCPAIRTT.
       COPY NCPBIRTT.
       COPY NCPNIRTT.
       COPY NCPUIRTT.
       COPY NCPXIRTT.
       COPY NCPCIRTT.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM2210                     **
      *****************************************************************
