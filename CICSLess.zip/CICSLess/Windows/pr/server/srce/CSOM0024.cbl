      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM0024.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0024                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE USER SESSION LIST       **
      **            FUNCTION BY SUBCOMPANY AND BATCH NUMBER,         **
      **            TO ALLOW THE USER TO PICK THE SESSION RECORDS FOR**
      **            WHICH THEY WANT TO VIEW DETAILS OR TOTALS        **
      **                                                             **
      **  DOMAIN :  BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016686**  6.2       PROCESS DATE CHANGE FOR CONCURRENCY              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028128**  6.6       MULTIPLE SIGN-ON ENHANCEMENTS                    **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0024'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-SUB                       PIC S9(4)  VALUE ZERO.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '0024'.
025970*    05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 10 BINARY.
           05  WS-SAVE-BTCH-NUM             PIC S9(07) COMP-3.
           05  WS-SAVE-CO-ID                PIC X(02).

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES            PIC S9(04).
025970         88  WS-MAX-LIST-LINES-DEFAULT  VALUE +10.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
021930*COPY XCWL1640.
021930*COPY XCWLDTLK.
       COPY XCWWWKDT.
036742 COPY XCWWCNST.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWUSET.
       COPY CCFRUSER.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0024.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0024'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------


           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  USET-1000-BROWSE
               THRU USET-1000-BROWSE-X.

           PERFORM  USET-2000-READ-NEXT
               THRU USET-2000-READ-NEXT-X.

           IF  WUSET-IO-EOF
               PERFORM  USET-3000-END-BROWSE
                   THRU USET-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2010-BROWSE-USER
               THRU 2010-BROWSE-USER-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WUSET-IO-EOF.

           IF  WUSET-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE
               MOVE RUSER-USER-ID
                 TO MIR-USER-ID
               MOVE RUSER-USER-SESN-BTCH-NUM
                 TO MIR-USER-SESN-BTCH-NUM
               MOVE RUSER-SBSDRY-CO-ID
                 TO MIR-SBSDRY-CO-ID
           END-IF.

           PERFORM  USET-3000-END-BROWSE
               THRU USET-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-USER.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE RUSER-USER-SESN-BTCH-NUM  TO WS-SAVE-BTCH-NUM.
           MOVE RUSER-SBSDRY-CO-ID        TO WS-SAVE-CO-ID.

           PERFORM  USET-2000-READ-NEXT
               THRU USET-2000-READ-NEXT-X
              UNTIL (RUSER-SBSDRY-CO-ID
                NOT = WS-SAVE-CO-ID
                OR RUSER-USER-SESN-BTCH-NUM
                NOT = WS-SAVE-BTCH-NUM)
                OR  WUSET-IO-EOF.

       2010-BROWSE-USER-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES          TO WUSET-KEY.
           MOVE WGLOB-USER-ID       TO WUSET-USER-ID.

           IF MIR-USER-SESN-BTCH-NUM = SPACES
              MOVE ZEROES                  TO WUSET-USER-SESN-BTCH-NUM
           ELSE
              MOVE MIR-USER-SESN-BTCH-NUM  TO WUSET-USER-SESN-BTCH-NUM
           END-IF.

           IF MIR-SBSDRY-CO-ID = SPACES
              MOVE LOW-VALUES          TO WUSET-SBSDRY-CO-ID
           ELSE
              MOVE MIR-SBSDRY-CO-ID    TO WUSET-SBSDRY-CO-ID
           END-IF.

036742*    MOVE WWKDT-LOW-TS        TO WUSET-USER-SESN-TS.
036742     MOVE ZEROS               TO WUSET-USER-SESN-GEN-ID.


           MOVE WUSET-KEY           TO WUSET-ENDBR-KEY.
           MOVE '9999999'           TO WUSET-ENDBR-USER-SESN-BTCH-NUM.
           MOVE HIGH-VALUES         TO WUSET-ENDBR-SBSDRY-CO-ID.
036742*    MOVE WWKDT-HIGH-TS       TO WUSET-ENDBR-USER-SESN-TS.
036742     MOVE WCNST-MAX-USER-SESN-GEN-ID-N
036742                           TO WUSET-ENDBR-USER-SESN-GEN-ID.
028128*
028128     IF  MIR-DV-DISPLAY-ALL-IND = 'N'
028128         MOVE WGLOB-USER-SESN-BTCH-NUM
028128                                 TO WUSET-USER-SESN-BTCH-NUM
028128         MOVE WGLOB-USER-SESN-BTCH-NUM
028128                                 TO WUSET-ENDBR-USER-SESN-BTCH-NUM
028128      END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-SBSDRY-CO-ID-G.
           MOVE SPACES                 TO MIR-USER-SESN-BTCH-NUM-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RUSER-SBSDRY-CO-ID
             TO MIR-SBSDRY-CO-ID-T (WS-SUB).

           MOVE RUSER-USER-SESN-BTCH-NUM
             TO MIR-USER-SESN-BTCH-NUM-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                     TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
021930*COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBUSET.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0024                      *
      *****************************************************************
