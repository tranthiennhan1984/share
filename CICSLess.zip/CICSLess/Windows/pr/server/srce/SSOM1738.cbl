      *****************************************************************
      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. SSOM1738.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1738                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE FS TABLE - CUMULATIVE                    **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016679**  6.2       DESCRIPTION                                      **
015944**  6.3       REDUCE FUNDS PER COVERAGE TO 25 (DEFAULT MAX)    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020618**  6.4       INITIALIZATION                                   **
021239**  6.4       FUND UNIT VALUE                                  **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023339**  6.5       WORKING STORAGE INITIALIZATION                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1738'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-GL                     VALUE '1738'.
           05  WS-SUB                                PIC S9(04) BINARY
                                                     VALUE 1.
025970*    05  WS-MAX-LIST-LINES                     PIC S9(03) BINARY
025970*                                              VALUE 25.
015944*                                              VALUE 129.
       01  WS-WORK-AREAS.
           05  EDIT-ZZ9-9999                         PIC ZZ9.9999.
           05  EDIT-SZZ9-999999                      PIC ---9.9(06).
           05  EDIT-999                              PIC 999.
           05  WS-POL-ID.
               10  WS-POL-ID-BASE                    PIC X(09).
               10  WS-POL-ID-SFX                     PIC X(01).

       01  KEY-WORK-AREAS.
           05  WK-SEQ                                PIC 9(4) BINARY.
           05  HOLD-SEQ                              PIC 9(3).
           05  HOLD-SEQ-X  REDEFINES  HOLD-SEQ       PIC X(3).
           05  EFFDT-I                   PIC X(10).
           05  WK-NEXT-FUND              PIC X(5).
           05  WK-FS-HIGH-KEY.
               10  FILLER                PIC X(14).
               10  WK-FS-HIGH-FUND       PIC X(05).
           05  WK-FA-HIGH-KEY.
               10  FILLER                PIC X(14).
               10  WK-FA-HIGH-EFF-DT     PIC 9(7).
               10  WK-FA-HIGH-SEQ-NUM    PIC S9(4)  BINARY.
           05  WK-FD-HIGH-KEY.
               10  FILLER                PIC X(14).
               10  WK-FD-HIGH-FUND       PIC X(5).
               10  WK-FD-HIGH-DATE       PIC 9(7).
               10  WK-FD-HIGH-SEQ        PIC 9(4)    BINARY.
           05  CARRY-OVER-SW             PIC 9.
               88  CARRY-OVER                        VALUE 1.
           05  WS-SIGN6-G.
               10  WS-SIGN6-T         OCCURS  139
                                      PIC X(01).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************

026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY SCFWFC.
       COPY SCFRFC.
       COPY SCFWFD.
       COPY SCFRFD.
       COPY SCFWFS.
       COPY SCFRFS.
       COPY SCFWFA.
       COPY SCFRFA.
       COPY CCFWPOL.
       COPY CCFRPOL.
021930*COPY CCFRPOLC.
021930*COPY CCFREDIT.
021930*COPY CCFWEDIT.
021930*COPY XCFRXTAB.
021930*COPY XCFWXTAB.
021930*COPY XCFRCRCY.
021930*COPY XCFWCRCY.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************

028298 COPY CCWL2626.
       COPY CCWL5400.
       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL0280.
021930*COPY CCWL2440.
021930*COPY CCWL0620.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
020469 COPY XCWL8640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1738.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

020618     MOVE HIGH-VALUES TO RFA-REC-INFO.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.


      *
      *  VALIDATE / CHECK POLICY ACCESS
      *
           PERFORM  1100-VALIDATE-POLICY
               THRU 1100-VALIDATE-POLICY-X.

           IF  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           MOVE MIR-CIA-EFF-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO EFFDT-I
           ELSE
               MOVE 'SS17380003'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE EFFDT-I               TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WGLOB-RETURN-ERROR     TO TRUE
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 1000-PROCESS-REQUEST-X
026057     END-IF.

           PERFORM  1200-NOW-GET-FUND
               THRU 1200-NOW-GET-FUND-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-GL
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM1738'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *---------------------
       1100-VALIDATE-POLICY.
      *---------------------

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 1100-VALIDATE-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET  L5400-STAT-MSG-NOT-REQD TO TRUE.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  NOT L5400-RETRN-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       1100-VALIDATE-POLICY-X.
           EXIT.
      /
      *------------------
       1200-NOW-GET-FUND.
      *------------------

           MOVE RPOL-POL-ID           TO WFC-POL-ID.
023339*    MOVE MIR-CVG-NUM           TO WFC-CVG-NUM.
023339*
023339     SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
023339     SET L0280-SPACES-PERMITTED     TO TRUE.
023339     MOVE ZERO                      TO L0280-PRECISION.
023339     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-LENGTH.
023339     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-INPUT-SIZE.
023339     MOVE MIR-CVG-NUM               TO L0280-INPUT-DATA.
023339
023339     PERFORM  0280-1000-NUMERIC-EDIT
023339         THRU 0280-1000-NUMERIC-EDIT-X.
023339
023339     IF  L0280-OK
023339         MOVE L0280-OUTPUT-V00      TO WFC-CVG-NUM-N
023339     ELSE
023339         MOVE ZERO                  TO WFC-CVG-NUM-N
023339     END-IF.
023339

           PERFORM  FC-1000-READ
               THRU FC-1000-READ-X.

           IF NOT WFC-IO-OK
               MOVE 'SS17380007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       1200-NOW-GET-FUND-X.
           EXIT.
      /
      *------------
       2000-LIST.
      *------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  2100-FIND-NEXT-FA-RECORD
               THRU 2100-FIND-NEXT-FA-RECORD-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
020618     OR WGLOB-RETURN-ERROR
               GO TO 2000-LIST-X
           END-IF.

      ***** SET UP FD/FS KEY AND HIGH KEY AS MUCH AS POSSIBLE *****
           MOVE RFA-POL-ID            TO WFD-POL-ID.
           MOVE RFA-POL-ID            TO WFS-POL-ID.
           MOVE RFA-CVG-NUM-N         TO WFD-CVG-NUM-N.
           MOVE RFA-CVG-NUM-N         TO WFS-CVG-NUM-N.

           IF WFD-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE TO WFD-CO-ID
           ELSE
               MOVE SPACES             TO WFD-CO-ID
           END-IF.

           IF WFS-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE TO WFS-CO-ID
           ELSE
               MOVE SPACES             TO WFS-CO-ID
           END-IF.

           MOVE WFD-KEY               TO WK-FD-HIGH-KEY.
           MOVE +9999999              TO WK-FD-HIGH-DATE.
           MOVE +999                  TO WK-FD-HIGH-SEQ.

           MOVE RFA-FRST-FIA-FND-ID   TO WK-NEXT-FUND.

           MOVE LOW-VALUES            TO WFS-FND-ID.

           MOVE WFS-KEY               TO WK-FS-HIGH-KEY.
           MOVE HIGH-VALUES           TO WK-FS-HIGH-FUND.
           MOVE WK-FS-HIGH-KEY        TO WFS-ENDBR-KEY.

           PERFORM  FS-1000-BROWSE
               THRU FS-1000-BROWSE-X.

           IF WFS-IO-EOF
               MOVE 'SS17380011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

020618     MOVE 1                     TO WS-SUB.
           PERFORM  2200-READ-NEXT-FS-RECORD
               THRU 2200-READ-NEXT-FS-RECORD-X
      *            VARYING WS-SUB FROM 1 BY 1
                   UNTIL   NOT WFS-IO-OK.

       2000-LIST-X.
           EXIT.
      /
      *-------------------------
       2100-FIND-NEXT-FA-RECORD.
      *-------------------------
      * VALIDATE NUMERIC FORMAT OF SEQUENCE NUMBER

           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CIA-SEQ-NUM       TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO HOLD-SEQ-X
020874*        MOVE HOLD-SEQ-X        TO MIR-CIA-SEQ-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CIA-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CIA-SEQ-NUM
               COMPUTE WK-SEQ = 1000 - L0280-OUTPUT
           ELSE
               SET WGLOB-RETURN-ERROR       TO TRUE
      * MSG: SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'SS17380010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-FIND-NEXT-FA-RECORD-X
           END-IF.

           IF EFFDT-I = WWKDT-ZERO-DT
               MOVE 'SS17380003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-FIND-NEXT-FA-RECORD-X
           END-IF.

           MOVE EFFDT-I                TO L1660-INTERNAL-DATE.
           PERFORM 1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WFA-CIA-IDT-NUM-N.

           MOVE RFC-POL-ID             TO WFA-POL-ID.
           MOVE RFC-CVG-NUM-N          TO WFA-CVG-NUM-N.
           MOVE RFC-INV-CVG-STAT-CD    TO MIR-CFN-STAT-CD.

           IF WFA-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE TO WFA-CO-ID
           ELSE
               MOVE SPACES             TO WFA-CO-ID
           END-IF.

           MOVE WK-SEQ                TO WFA-CIA-SEQ-NUM.
           MOVE WFA-KEY               TO WK-FA-HIGH-KEY.
           MOVE +999                  TO WK-FA-HIGH-SEQ-NUM.
           MOVE WK-FA-HIGH-KEY        TO WFA-ENDBR-KEY.

           IF MIR-CIA-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CIA-TYP-CD
           END-IF.

           PERFORM  FA-1000-BROWSE
               THRU FA-1000-BROWSE-X.

           IF WFA-IO-EOF
              MOVE 'SS17380004'  TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
020618        SET WGLOB-RETURN-ERROR  TO TRUE
              GO TO 2100-FIND-NEXT-FA-RECORD-X
           END-IF.

020618     MOVE HIGH-VALUE       TO RFA-CIA-TYP-CD.
           PERFORM  2110-FA-READ-RECORD-LOOP
               THRU 2110-FA-READ-RECORD-LOOP-X
                  UNTIL NOT WFA-IO-OK
                     OR MIR-CIA-TYP-CD = RFA-CIA-TYP-CD.

020874*    COMPUTE HOLD-SEQ = 1000 - RFA-CIA-SEQ-NUM.
020874*    MOVE HOLD-SEQ  TO MIR-CIA-SEQ-NUM.
020874     COMPUTE L0290-INPUT-V00  =  1000 - RFA-CIA-SEQ-NUM.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CIA-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-CIA-SEQ-NUM.
           PERFORM  FA-3000-END-BROWSE
               THRU FA-3000-END-BROWSE-X.

       2100-FIND-NEXT-FA-RECORD-X.
           EXIT.
      /
      *-------------------------
       2110-FA-READ-RECORD-LOOP.
      *-------------------------

           PERFORM  FA-2000-READ-NEXT
               THRU FA-2000-READ-NEXT-X.

           IF MIR-CIA-TYP-CD = SPACES
              MOVE RFA-CIA-TYP-CD      TO MIR-CIA-TYP-CD
           END-IF.

           IF NOT WFA-IO-OK
              MOVE 'SS17380004'  TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
020618        SET WGLOB-RETURN-ERROR  TO TRUE
              GO TO 2110-FA-READ-RECORD-LOOP-X
           END-IF.

       2110-FA-READ-RECORD-LOOP-X.
           EXIT.
      /
      *-------------------------
       2200-READ-NEXT-FS-RECORD.
      *-------------------------

           PERFORM  FS-2000-READ-NEXT
               THRU FS-2000-READ-NEXT-X.

           IF NOT WFS-IO-OK
               GO TO 2200-READ-NEXT-FS-RECORD-X
           END-IF.

           MOVE RFA-CIA-IDT-NUM-N     TO WFD-FIA-IDT-NUM-N.
           MOVE RFA-CIA-SEQ-NUM       TO WFD-FIA-SEQ-NUM.

           IF (RFS-FND-ID   < WK-NEXT-FUND)
             OR (WK-NEXT-FUND = SPACES)
               MOVE RFS-FND-ID        TO WFD-FND-ID
               MOVE RFS-FND-ID        TO WK-FD-HIGH-FUND
               MOVE WK-FD-HIGH-KEY    TO WFD-ENDBR-KEY
               PERFORM  2210-FIND-MOST-RECENT-FD
                   THRU 2210-FIND-MOST-RECENT-FD-X
               MOVE 1                 TO CARRY-OVER-SW
               SET RFD-FIA-UNIT-STAT-NOT-STRT TO TRUE
021239*        MOVE 0                 TO RFD-FIA-INTG-AUNIT-QTY
021239*        MOVE 0                 TO RFD-FIA-DCML-AUNIT-QTY
021239*        MOVE 0                 TO RFD-FIA-INTG-IUNIT-QTY
021239*        MOVE 0                 TO RFD-FIA-DCML-IUNIT-QTY
           ELSE
               MOVE WK-NEXT-FUND      TO WFD-FND-ID
               PERFORM  2220-FIND-EXACT-FD
                   THRU 2220-FIND-EXACT-FD-X
               MOVE ZERO              TO CARRY-OVER-SW
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2200-READ-NEXT-FS-RECORD-X
           END-IF.

           IF CARRY-OVER
              GO TO 2200-READ-NEXT-FS-RECORD-X
           ELSE
              MOVE RFD-FND-ID       TO MIR-FND-ID-T (WS-SUB)
020469
020469        PERFORM  8640-1000-BUILD-PARM-INFO
020469            THRU 8640-1000-BUILD-PARM-INFO-X
020469        MOVE RFD-FND-ID       TO L8640-FND-ID
020469        PERFORM  8640-1000-GET-FND-CRCY-CD
020469            THRU 8640-1000-GET-FND-CRCY-CD-X
020469        IF  NOT L8640-RETRN-OK
020469*MSG: CURRENCY CODE NOT FOUND FOR FUND @1
020469            MOVE 'SS17380001'   TO WGLOB-MSG-REF-INFO
020469            MOVE L8640-FND-ID   TO WGLOB-MSG-PARM (1)
020469            PERFORM  0260-1000-GENERATE-MESSAGE
020469                THRU 0260-1000-GENERATE-MESSAGE-X
020469        ELSE
020469            MOVE L8640-FND-CRCY-CD
020469                                TO MIR-FIA-CRCY-CD-T (WS-SUB)
020469        END-IF
020469
              MOVE RFD-FIA-GLA-CD   TO MIR-FIA-GLA-CD-T (WS-SUB)
020874*       COMPUTE L0290-INPUT-NUMBER = RFD-FIA-FND-GLA-AMT
020874*                                    * 100
020874        MOVE RFD-FIA-FND-GLA-AMT    TO L0290-INPUT-V02
              MOVE 2        TO L0290-PRECISION
              MOVE LENGTH OF MIR-FIA-FND-GLA-AMT-T (WS-SUB)
                            TO L0290-MAX-OUT-LEN
              SET L0290-SIGN-DISPLAY      TO TRUE
020874*       PERFORM  0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
              MOVE L0290-OUTPUT-DATA
                            TO MIR-FIA-FND-GLA-AMT-T (WS-SUB)

020874*       COMPUTE L0290-INPUT-NUMBER = RFD-FIA-GNRL-GLA-AMT
020874*                                    * 100
020874        MOVE RFD-FIA-GNRL-GLA-AMT   TO L0290-INPUT-V02
              MOVE 2        TO L0290-PRECISION
              MOVE LENGTH OF MIR-FIA-GNRL-GLA-AMT-T (WS-SUB)
                            TO L0290-MAX-OUT-LEN
              SET L0290-SIGN-DISPLAY      TO TRUE
020874*       PERFORM  0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
              MOVE L0290-OUTPUT-DATA
                            TO MIR-FIA-GNRL-GLA-AMT-T (WS-SUB)
              MOVE RFD-FIA-REVRS-GLA-CD
                           TO MIR-FIA-REVRS-GLA-CD-T (WS-SUB)
020874*       COMPUTE L0290-INPUT-NUMBER = RFD-REVRS-FND-GLA-AMT
020874*                                    * 100
020874        MOVE RFD-REVRS-FND-GLA-AMT  TO L0290-INPUT-V02
              MOVE 2        TO L0290-PRECISION
              MOVE LENGTH OF MIR-REVRS-FND-GLA-AMT-T (WS-SUB)
                            TO L0290-MAX-OUT-LEN
              SET L0290-SIGN-DISPLAY      TO TRUE
020874*       PERFORM  0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
              MOVE L0290-OUTPUT-DATA
                            TO MIR-REVRS-FND-GLA-AMT-T (WS-SUB)
020874*       COMPUTE L0290-INPUT-NUMBER = RFD-REVRS-GNRL-GLA-AMT
020874*                                    * 100
020874        MOVE RFD-REVRS-GNRL-GLA-AMT TO L0290-INPUT-V02
              MOVE 2        TO L0290-PRECISION
              MOVE LENGTH OF MIR-REVRS-GNRL-GLA-AMT-T (WS-SUB)
                            TO L0290-MAX-OUT-LEN
              SET L0290-SIGN-DISPLAY      TO TRUE
020874*       PERFORM  0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
              MOVE L0290-OUTPUT-DATA
                            TO MIR-REVRS-GNRL-GLA-AMT-T (WS-SUB)
              COMPUTE WS-SUB = WS-SUB + 1
            END-IF.

       2200-READ-NEXT-FS-RECORD-X.
           EXIT.
      /
      *-------------------------
       2210-FIND-MOST-RECENT-FD.
      *-------------------------

           PERFORM  FD-1000-BROWSE
               THRU FD-1000-BROWSE-X.

           IF WFD-IO-EOF
               PERFORM  2221-FIND-MOST-RCNT-FD-CONT
                   THRU 2221-FIND-MOST-RCNT-FD-CONT-X
               GO TO 2210-FIND-MOST-RECENT-FD-X
           END-IF.

           PERFORM  FD-2000-READ-NEXT
               THRU FD-2000-READ-NEXT-X.

           IF NOT WFD-IO-OK
               PERFORM  2221-FIND-MOST-RCNT-FD-CONT
                   THRU 2221-FIND-MOST-RCNT-FD-CONT-X
           END-IF.

           PERFORM  FD-3000-END-BROWSE
               THRU FD-3000-END-BROWSE-X.

       2210-FIND-MOST-RECENT-FD-X.
           EXIT.
      /
      *-------------------
       2220-FIND-EXACT-FD.
      *-------------------

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF NOT WFD-IO-OK
               MOVE 'SS17380005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2220-FIND-EXACT-FD-X
           END-IF.

           MOVE RFD-NXT-FIA-FND-ID    TO WK-NEXT-FUND
           IF NOT RFA-CIA-UNIT-STAT-NOT-STRT
               IF ((RFA-CIA-TYP-CD = 'SUR'
                                  OR 'ADM')
                     AND
                     RFA-CIA-REVRS-STAT-NOT-STRT)
                 OR (RFA-CIA-TYP-CD = 'DEP'
                     AND
                     NOT RFA-CIA-REVRS-STAT-NOT-STRT)
                 OR (RFA-CIA-TYP-CD = 'TRS'
                     AND
                     (RFD-FIA-FND-TRXN-AMT < 0
                        OR RFD-FIA-VALU-SURR-PCT NOT = 0)
                     AND
                     RFA-CIA-REVRS-STAT-NOT-STRT)
                 OR (RFA-CIA-TYP-CD = 'TRS'
                     AND
                     (RFD-FIA-FND-TRXN-AMT > 0
                        OR RFD-FIA-IN-ALLOC-PCT NOT = 0)
                     AND
                     NOT RFA-CIA-REVRS-STAT-NOT-STRT)
                   MOVE '-'           TO WS-SIGN6-T (WS-SUB)
               END-IF
           END-IF.

       2220-FIND-EXACT-FD-X.
           EXIT.
      /
      *----------------------------
       2221-FIND-MOST-RCNT-FD-CONT.
      *----------------------------

           MOVE RFS-FND-ID            TO RFD-FND-ID.
021239*    MOVE 0                     TO RFD-CFN-INTG-AUNIT-QTY.
021239*    MOVE 0                     TO RFD-CFN-DCML-AUNIT-QTY.
021239*    MOVE 0                     TO RFD-FIA-AUNIT-PRIC-AMT.
021239*    MOVE 0                     TO RFD-CFN-INTG-IUNIT-QTY.
021239*    MOVE 0                     TO RFD-CFN-DCML-IUNIT-QTY.
021239*    MOVE 0                     TO RFD-FIA-IUNIT-PRIC-AMT.
           MOVE 0                     TO RFD-CFN-TRXN-LTD-AMT.
           MOVE 0                     TO RFD-CFN-LOAD-LTD-AMT.
           MOVE 0                     TO RFD-CFN-INT-LTD-AMT.
           MOVE 0                     TO RFD-CFN-PEND-LTD-AMT.

       2221-FIND-MOST-RCNT-FD-CONT-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WFA-KEY.
           MOVE MIR-POL-ID-BASE        TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WS-POL-ID-SFX.
           MOVE WS-POL-ID              TO WFA-POL-ID.
023339*    MOVE MIR-CVG-NUM            TO WFA-CVG-NUM.
023339     MOVE WFC-CVG-NUM            TO WFA-CVG-NUM.
           MOVE WFA-KEY                TO WFA-ENDBR-KEY.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-CFN-STAT-CD.
           MOVE SPACES                 TO MIR-FIA-FND-GLA-AMT-G.
           MOVE SPACES                 TO MIR-FND-ID-G.
           MOVE SPACES                 TO MIR-FIA-GLA-CD-G.
           MOVE SPACES                 TO MIR-FIA-GNRL-GLA-AMT-G.
           MOVE SPACES                 TO MIR-FIA-REVRS-GLA-CD-G.
           MOVE SPACES                 TO MIR-REVRS-FND-GLA-AMT-G.
           MOVE SPACES                 TO MIR-REVRS-GNRL-GLA-AMT-G.
020469     MOVE SPACES                 TO MIR-FIA-CRCY-CD-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           SET  WGLOB-REF-POLICY       TO TRUE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                    TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE        TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX         TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8640-0000-INIT-PARM-INFO
025970         THRU 8640-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WS-WORK-AREAS.
025970     INITIALIZE KEY-WORK-AREAS.
025970     MOVE SPACE                       TO WWKDT-WORK-FIELDS.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************

025970 COPY XCPS1670.
       COPY CCPS5400.
018764*COPY CCCL5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL5400.
021930*COPY CCPL0620.
       COPY XCPL0290.
       COPY XCPS0290.
018764*COPY CCCL2440.
021930*COPY CCPL2440.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
020469 COPY XCPL8640.
020469 COPY XCPS8640.
020469
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************

021930*COPY CCPNEDIT.
       COPY CCPNPOL.
021930*COPY XCPNCRCY.
021930*COPY XCPNXTAB.
       COPY SCPNFC.
       COPY SCPBFD.
       COPY SCPNFD.
       COPY SCPBFS.
       COPY SCPBFA.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM SSOM1738
      *****************************************************************
