      *****************************************************************
      **  MEMBER :  XSOM0068                                         **
      **  REMARKS:  LIST THE SESSIONS FOR A USER ID.                 **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
028128**  6.6       MULTIPLE SIGN-ON ENHANCEMENTS                    **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM0068.

       COPY XCWWCRHT.

      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------
      *
      *--------------
       DATA DIVISION.
      *--------------
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM0068'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID          VALUE '0068'.
               88  WS-BUS-FCN-LIST           VALUE '0068'.

           05  SUB1                         PIC S9(4)  VALUE ZERO
                                            BINARY.
           05  MAX-USES-CTR                 PIC S9(4) VALUE ZERO
                                            BINARY.
      /
       COPY XCWL0290.
      *
       COPY XCWL1640.
      /
       COPY XCFWUSEU.
       COPY XCFRUSES.
      /
       COPY XCWLDTLK.
      /
       COPY XCWWWKDT.
      *
       COPY XCWWTIME.
      /
      *---------------
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *---------------

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM0068.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *-------------
       0000-MAINLINE.
      *-------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME         
               THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-PROCESS-LIST
                        THRU 2000-PROCESS-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM0068'            TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       2000-PROCESS-LIST.
      *------------------

           MOVE WGLOB-USER-ID                  TO MIR-USER-ID.
           COMPUTE MAX-USES-CTR = LENGTH OF MIR-CO-ID-G
                                / LENGTH OF MIR-CO-ID-T (1).
           MOVE WGLOB-USER-ID                  TO WUSEU-USER-ID.
           MOVE LOW-VALUE                      TO WUSEU-CO-ID.
           MOVE WUSEU-KEY                      TO WUSEU-ENDBR-KEY.
           MOVE HIGH-VALUE                     TO WUSEU-ENDBR-CO-ID.
           PERFORM USEU-1000-BROWSE
              THRU USEU-1000-BROWSE-X.
           PERFORM USEU-2000-READ-NEXT
              THRU USEU-2000-READ-NEXT-X.
           PERFORM
              UNTIL WUSEU-IO-EOF
               IF RUSES-USER-SESN-ID = WGLOB-USER-SESN-ID
                   PERFORM 2100-DISPLAY-THIS-SESN
                      THRU 2100-DISPLAY-THIS-SESN-X
               ELSE
                   PERFORM 2200-DISPLAY-ALTERNATE-SESN
                      THRU 2200-DISPLAY-ALTERNATE-SESN-X
               END-IF
               PERFORM USEU-2000-READ-NEXT
                  THRU USEU-2000-READ-NEXT-X
           END-PERFORM.
           PERFORM USEU-3000-END-BROWSE
              THRU USEU-3000-END-BROWSE-X.

       2000-PROCESS-LIST-X.
           EXIT.
      /
      *-----------------------
       2100-DISPLAY-THIS-SESN.
      *-----------------------

           MOVE RUSES-CO-ID                 TO MIR-CO-ID.
           MOVE RUSES-USER-SESN-CTRY-CD     TO MIR-USER-SESN-CTRY-CD.
           MOVE RUSES-USER-SESN-CRCY-CD     TO MIR-USER-SESN-CRCY-CD.
           PERFORM 2110-FORMAT-BTCH-NUM
              THRU 2110-FORMAT-BTCH-NUM-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-USER-SESN-BTCH-NUM.
           PERFORM 2120-FORMAT-DATE
              THRU 2120-FORMAT-DATE-X.
           MOVE L1640-EXTERNAL-DATE         TO MIR-USER-SESN-PRCES-DT.
           MOVE RUSES-USER-SESN-STAT-CD     TO MIR-USER-SESN-STAT-CD.

       2100-DISPLAY-THIS-SESN-X.
           EXIT.
      *
      *---------------------
       2110-FORMAT-BTCH-NUM.
      *---------------------
      *
           MOVE RUSES-USER-SESN-BTCH-NUM    TO L0290-INPUT-V00.
           MOVE 0                           TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USER-SESN-BTCH-NUM
                                            TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
      *
       2110-FORMAT-BTCH-NUM-X.
           EXIT.
      *
      *-----------------
       2120-FORMAT-DATE.
      *-----------------
      *
           MOVE RUSES-USER-SESN-PRCES-DT    TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
      *
       2120-FORMAT-DATE-X.
           EXIT.
      *
      *----------------------------
       2200-DISPLAY-ALTERNATE-SESN.
      *----------------------------
      *
           ADD 1                  TO SUB1.
      *
           IF SUB1 > MAX-USES-CTR
               GO TO 2200-DISPLAY-ALTERNATE-SESN-X
           END-IF.
      *
           MOVE RUSES-CO-ID       TO MIR-CO-ID-T (SUB1).
           MOVE RUSES-USER-SESN-CTRY-CD     
                                  TO MIR-USER-SESN-CTRY-CD-T (SUB1).
           MOVE RUSES-USER-SESN-CRCY-CD
                                  TO MIR-USER-SESN-CRCY-CD-T (SUB1).
           PERFORM 2110-FORMAT-BTCH-NUM
              THRU 2110-FORMAT-BTCH-NUM-X.
           MOVE L0290-OUTPUT-DATA TO MIR-USER-SESN-BTCH-NUM-T (SUB1).
           PERFORM 2120-FORMAT-DATE
              THRU 2120-FORMAT-DATE-X.
           MOVE L1640-EXTERNAL-DATE TO MIR-USER-SESN-PRCES-DT-T (SUB1).
           MOVE RUSES-USER-SESN-STAT-CD 
                                  TO MIR-USER-SESN-STAT-CD-T (SUB1).
      *
       2200-DISPLAY-ALTERNATE-SESN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                        TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE            TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
           PERFORM  TIMR-0000-INIT-PARM-INFO    
               THRU TIMR-0000-INIT-PARM-INFO-X.
      
           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.
      
           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.
      
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      
           INITIALIZE WS-WORKING-STORAGE.
           MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
           SET MIR-RETRN-OK                    TO TRUE.
      
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      *
       COPY XCPSTIMR.
       COPY XCCPTIMR.
 
       COPY XCPPTIME.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
       COPY XCCPERR.
      /
       COPY XCPL0260.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCCP0030.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY XCPBUSEU.
      *
      *****************************************************************
      **                 END OF PROGRAM XSOM0068                     **
      *****************************************************************
