      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2341.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2341                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE CREATE FUNCTION OF      **
      **            CLIENT LOG BY AN AUTHORIZED USER                 **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       ORIGINAL - NEW FOR RELEASE 6.0                   **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016387**  6.2       REMOVE FUSE SUPPORT                              **
016537**  6.2       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015703**  6.4       REMOVE CCWLPGA                                   **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2341'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
       COPY XCWWTIME.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-CLI-CREATE   VALUE '2341'.

       01  WS-FCN-WORK-AREA.
           05  WS-SWITCHES.
               10  WS-INPUT-FIELDS-OK-SW    PIC X(01).
                   88  WS-INPUT-FIELDS-OK       VALUE 'Y'.
                   88  WS-INPUT-FIELDS-NOT-OK   VALUE 'N'.
           05  WS-RDALG-KEY.
               10  WS-RDALG-ID              PIC X(06).
               10  WS-RDALG-NUM             PIC X(04).
           05  WS-POL-ID.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-SEQ-NUM                   PIC 9(03).
           05  WS-PIC-99                    PIC 9(02).
           05  WS-PIC-999                   PIC 9(03).
           05  WS-CLIENT-BROWSE-KEY         PIC X(50).
           05  WS-FORMAT-TIME.
               10  WS-FORMAT-HH             PIC X(02).
               10  WS-FORMAT-MM             PIC X(02).
               10  WS-FORMAT-SS             PIC X(02).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY CCWWFRMT.
016537*COPY XCWEBLCH.
016537*COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
021930*COPY CCFWPOL.
021930*COPY CCFRPOL.
021930*
021930*COPY CCFWCVG.
021930*COPY CCFRCVG.
021930*
       COPY NCFWDALG.
       COPY NCFRDALG.
      /
       COPY NCFWDALT.
       COPY NCFRDALT.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
016537*COPY CCWWCVGS.
      /
015703*COPY CCWLPGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
       COPY CCWL5600.
       COPY XCWL0280.
       COPY XCWL1640.
      /
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2341.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           SET MIR-RETRN-OK                  TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           IF  MIR-CPEVNT-TRXN-DT NOT > SPACES
               PERFORM  1200-DEFAULT-DATE
                   THRU 1200-DEFAULT-DATE-X
           END-IF.

           MOVE SPACES                  TO  WS-FORMAT-TIME.
           MOVE MIR-CPEVNT-TRXN-TIME    TO  WS-FORMAT-TIME.

           IF  WS-FORMAT-TIME NOT > SPACES
               PERFORM  1400-DEFAULT-TIME
                   THRU 1400-DEFAULT-TIME-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           MOVE MIR-BUS-FCN-ID    TO  WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CLI-CREATE
                    PERFORM  2000-PROCESS-CREATE
                        THRU 2000-PROCESS-CREATE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2341'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST     TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       1200-DEFAULT-DATE.
      *------------------

           MOVE WGLOB-SYSTEM-DATE-INT TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPEVNT-TRXN-DT.

       1200-DEFAULT-DATE-X.
           EXIT.
      *------------------
       1400-DEFAULT-TIME.
      *------------------

           MOVE WGLOB-SYSTEM-TIME     TO WTIME-EDIT-TIME.
           MOVE WTIME-EDIT-HH         TO WS-FORMAT-HH.
           MOVE WTIME-EDIT-MM         TO WS-FORMAT-MM.
           MOVE WTIME-EDIT-SS         TO WS-FORMAT-SS.
           MOVE WS-FORMAT-TIME        TO MIR-CPEVNT-TRXN-TIME.

       1400-DEFAULT-TIME-X.
           EXIT.
      /
      *-------------------
       2000-PROCESS-CREATE.
      *-------------------

           MOVE MIR-EVNT-ACTV-CD             TO  WDALT-EVNT-ACTV-CD.
           MOVE MIR-EVNT-ACT-CD              TO  WDALT-EVNT-ACT-CD.
           MOVE 'M'                          TO  WDALT-EVNT-SRC-CD.

           PERFORM  2200-EDIT-KEY-FIELDS
               THRU 2200-EDIT-KEY-FIELDS-X.

           IF  NOT WS-INPUT-FIELDS-OK
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-CREATE-X
           END-IF.

           PERFORM  DALT-1000-READ
               THRU DALT-1000-READ-X.

           IF NOT WDALT-IO-OK
               MOVE WDALT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'CS23410009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-CREATE-X
           END-IF.

           IF RDALT-EVNT-SECUR-CD    > WGLOB-SECUR-LVL-CD
               MOVE 'CS23410010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-CREATE-X
           END-IF.

           IF RDALT-EVNT-USE-IND  NOT = 'Y'
               MOVE 'CS23410011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                  PERFORM  9100-BLANK-DATA-FIELDS
                      THRU 9100-BLANK-DATA-FIELDS-X
                  GO TO 2000-PROCESS-CREATE-X
               END-IF
           END-IF.

           MOVE RDALT-EVNT-GR-CD           TO MIR-CPEVNT-GR-CD.

           PERFORM  7000-BUILD-DALG-KEY
               THRU 7000-BUILD-DALG-KEY-X.

           MOVE WS-CLIENT-BROWSE-KEY       TO  WDALG-KEY.

           PERFORM  DALG-1000-READ
               THRU DALG-1000-READ-X.

           IF WDALG-IO-OK
               MOVE WDALG-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-CREATE-X
           ELSE
               PERFORM  DALG-1000-CREATE
                   THRU DALG-1000-CREATE-X
               MOVE RDALT-EVNT-SECUR-CD TO RDALG-CPEVNT-SECUR-CD
               MOVE RDALT-MSG-REF-ID    TO RDALG-MSG-REF-ID
               MOVE RDALT-MSG-REF-NUM   TO RDALG-MSG-REF-NUM
               MOVE MIR-EVNT-ACT-CD     TO RDALG-EVNT-ACT-CD
               MOVE 'M'                 TO RDALG-CPEVNT-SRC-CD
               MOVE 'DALG'              TO RDALG-BUS-FCN-ID
               MOVE MIR-CVG-NUM         TO RDALG-CVG-NUM
               PERFORM  DALG-1000-WRITE
                   THRU DALG-1000-WRITE-X
               PERFORM  2400-MOVE-TO-CREATE-SCREEN
                   THRU 2400-MOVE-TO-CREATE-SCREEN-X
           END-IF.

      *MSG: RECORD CREATED - CONTINUE
           MOVE 'XS00000004'         TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2000-PROCESS-CREATE-X.
           EXIT.
      /
      *--------------------
       2200-EDIT-KEY-FIELDS.
      *--------------------

           SET WS-INPUT-FIELDS-OK           TO  TRUE.

           PERFORM  3000-EDIT-CLIENT-NUM
               THRU 3000-EDIT-CLIENT-NUM-X.

           PERFORM  3100-EDIT-FORMAT-DATE
               THRU 3100-EDIT-FORMAT-DATE-X.

           PERFORM  3200-EDIT-FORMAT-TIME
               THRU 3200-EDIT-FORMAT-TIME-X.

           PERFORM  3300-EDIT-SEQUENCE-NUM
               THRU 3300-EDIT-SEQUENCE-NUM-X.

           PERFORM  3400-EDIT-ACTIVITY
               THRU 3400-EDIT-ACTIVITY-X.

           PERFORM  3500-EDIT-ACTION
               THRU 3500-EDIT-ACTION-X.

           PERFORM  3600-EDIT-COVERAGE-NUM
               THRU 3600-EDIT-COVERAGE-NUM-X.

       2200-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *---------------------------
       2400-MOVE-TO-CREATE-SCREEN.
      *---------------------------

           MOVE RDALG-CVG-NUM         TO MIR-CVG-NUM.

           MOVE RDALG-MSG-REF-ID      TO  WS-RDALG-ID.
           MOVE RDALG-MSG-REF-NUM     TO  WS-RDALG-NUM.
           MOVE WS-RDALG-KEY          TO  WGLOB-MSG-REF-INFO.
           MOVE RDALG-CPEVNT-PARM-1-TXT
                                      TO  WGLOB-MSG-PARM (1).
           MOVE RDALG-CPEVNT-PARM-2-TXT
                                      TO  WGLOB-MSG-PARM (2).
           MOVE RDALG-CPEVNT-PARM-3-TXT
                                      TO  WGLOB-MSG-PARM (3).
           MOVE RDALG-CPEVNT-PARM-4-TXT
                                      TO  WGLOB-MSG-PARM (4).
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
015904*    MOVE WGLOB-MSG-TXT         TO MIR-DV-MSG-TXT.
015904     MOVE WGLOB-MSG-TXT         TO MIR-MSG-TXT.
           MOVE RDALG-EVNT-ACT-CD     TO MIR-EVNT-ACT-CD.

       2400-MOVE-TO-CREATE-SCREEN-X.
           EXIT.

      /
      *---------------------
       3000-EDIT-CLIENT-NUM.
      *---------------------

           IF  (MIR-CPEVNT-POL-CLI-ID = SPACES)
               MOVE 'CS23410001'               TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-EDIT-CLIENT-NUM-X
           END-IF.

      * ALL THE CLIENT ACCESS VERIFICATION MDOULE

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

016387*    SET L5600-GEN-CNSLDT-MSG-WARN   TO TRUE.
           MOVE MIR-CPEVNT-POL-CLI-ID      TO L5600-CLI-ID.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

      *  CHECK THE RETURN CODE

           IF  L5600-RETRN-OK
               CONTINUE
           ELSE
               SET WS-INPUT-FIELDS-NOT-OK   TO   TRUE
               GO TO 3000-EDIT-CLIENT-NUM-X
           END-IF.

           IF  L5600-CNFD-ACCS-RESTRICTED
               SET WS-INPUT-FIELDS-NOT-OK   TO  TRUE
           END-IF.

       3000-EDIT-CLIENT-NUM-X.
           EXIT.
      /
      *----------------------
       3100-EDIT-FORMAT-DATE.
      *----------------------

           MOVE MIR-CPEVNT-TRXN-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
               MOVE MIR-CPEVNT-TRXN-DT             TO WGLOB-MSG-PARM (1)
               MOVE 'CS23410002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-INPUT-FIELDS-NOT-OK TO TRUE
               GO TO 3100-EDIT-FORMAT-DATE-X
           END-IF.

           IF L1640-INTERNAL-DATE > WGLOB-SYSTEM-DATE-INT
               MOVE 'CS23410003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-INPUT-FIELDS-NOT-OK TO TRUE
           END-IF.

       3100-EDIT-FORMAT-DATE-X.
           EXIT.
      /
      *----------------------
       3200-EDIT-FORMAT-TIME.
      *----------------------

           MOVE MIR-CPEVNT-TRXN-TIME  TO WS-FORMAT-TIME.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 6                     TO L0280-LENGTH.
           MOVE 6                     TO L0280-INPUT-SIZE.
           MOVE WS-FORMAT-TIME        TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF NOT L0280-OK
               MOVE 'CS23410004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-INPUT-FIELDS-NOT-OK TO TRUE
           END-IF.

       3200-EDIT-FORMAT-TIME-X.
           EXIT.
      /
      *-----------------------
       3300-EDIT-SEQUENCE-NUM.
      *-----------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CPEVNT-SEQ-NUM    TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-SEQ-NUM
           ELSE
               MOVE 'CS23410005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-INPUT-FIELDS-NOT-OK TO TRUE
               GO TO 3300-EDIT-SEQUENCE-NUM-X
           END-IF.

      ***  CLEAR CASE PROCESSING WILL USE SEQUENCE NUMBERS 500 AND UP,
      ***  THEREFORE, CAN MANUALLY CREATE SEQUENCE NUMBERS UNDER 500.

           IF  ((WS-SEQ-NUM > 499)
           OR   (WS-SEQ-NUM < 1))
               MOVE 'CS23410006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-INPUT-FIELDS-NOT-OK TO TRUE
           END-IF.

       3300-EDIT-SEQUENCE-NUM-X.
           EXIT.
      /
      *-------------------
       3400-EDIT-ACTIVITY.
      *-------------------

      ***  ACTIVITY MUST EXIST ON EDIT/DACTV.
           MOVE MIR-EVNT-ACTV-CD      TO WEDIT-ETBL-VALU-ID.
           PERFORM  ACTV-1000-EDIT-ACTIVITY
               THRU ACTV-1000-EDIT-ACTIVITY-X.

           IF NOT WEDIT-IO-OK
               MOVE 'CS23410007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-INPUT-FIELDS-NOT-OK TO TRUE
           END-IF.

       3400-EDIT-ACTIVITY-X.
           EXIT.
      /
      *-----------------
       3500-EDIT-ACTION.
      *-----------------

      ***  ACTION MUST EXIST ON EDIT/DACTN FOR CREATE
           MOVE MIR-EVNT-ACT-CD       TO WEDIT-ETBL-VALU-ID.
           PERFORM  ACTN-1000-EDIT-ACTION
               THRU ACTN-1000-EDIT-ACTION-X.

           IF NOT WEDIT-IO-OK
               MOVE 'CS23410008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-INPUT-FIELDS-NOT-OK TO TRUE
           END-IF.

       3500-EDIT-ACTION-X.
           EXIT.
      /
      *-----------------------
       3600-EDIT-COVERAGE-NUM.
      *-----------------------

      * IF THE RECORD IS FOR A POLICY THE COVERAGE NUMBER MUST BE VALID

           IF MIR-CVG-NUM    = SPACES
           OR MIR-CVG-NUM    = '00'
              GO TO 3600-EDIT-COVERAGE-NUM-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF NOT L0280-OK
               SET WS-INPUT-FIELDS-NOT-OK TO TRUE
               MOVE 'CS23410012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3600-EDIT-COVERAGE-NUM-X
           END-IF.

       3600-EDIT-COVERAGE-NUM-X.
           EXIT.
      /
      *-------------------
       7000-BUILD-DALG-KEY.
      *-------------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE SPACES                TO  WS-CLIENT-BROWSE-KEY.

           MOVE 'C'                   TO  WDALG-CPEVNT-POL-CLI-CD.
           MOVE MIR-CPEVNT-POL-CLI-ID TO  WDALG-CPEVNT-POL-CLI-ID.

           MOVE MIR-CPEVNT-TRXN-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE       TO WDALG-CPEVNT-TRXN-DT.
           MOVE MIR-CPEVNT-TRXN-TIME      TO WS-FORMAT-TIME.
           MOVE WS-FORMAT-TIME            TO WDALG-CPEVNT-TRXN-TIME.
           MOVE MIR-CPEVNT-SEQ-NUM        TO WDALG-CPEVNT-SEQ-NUM.
           MOVE MIR-EVNT-ACTV-CD          TO WDALG-EVNT-ACTV-CD.
           MOVE MIR-CPEVNT-GR-CD          TO WDALG-CPEVNT-GR-CD.
           MOVE WGLOB-USER-ID             TO WDALG-USER-ID.
           MOVE WDALG-KEY                 TO WS-CLIENT-BROWSE-KEY.

       7000-BUILD-DALG-KEY-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                       TO  MIR-EVNT-ACT-CD.
           MOVE SPACES                       TO  MIR-CVG-NUM.
015904*    MOVE SPACES                       TO  MIR-DV-MSG-TXT.
015904     MOVE SPACES                       TO  MIR-MSG-TXT.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WS-FCN-WORK-AREA.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
       COPY NCPEACTN.
       COPY NCPEACTV.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY CCPS5600.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
016537*COPY CCPNPOL.
      /
016537*COPY CCPNCVG.
      /
       COPY CCPNEDIT.
      /
       COPY NCPADALG.
016537*COPY NCPBDALG.
       COPY NCPCDALG.
       COPY NCPNDALG.
016537*COPY NCPUDALG.
      /
       COPY NCPNDALT.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2341                     **
      *****************************************************************
