      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0075.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0075                                         **
      **  REMARKS:  PROCESS DRIVER FOR PASS TRANSACTION:  MAINTAIN   **
      **            POLICY NUMBER ASSIGNMENT SCREEN                  **
      **            THIS PROGRAM ALLOWS THE USER TO INQUIRE, BROWSE  **
      **            MODIFY, ADD, AND DELETE POLCICY NUMBER RANGES    **
      **            FOR A GIVEN COMPANY/CLASS OF BUSINESS COMBINATION**
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
007678**  5.6       INITIAL SYSTEM DESIGN                            **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      /
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0075'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970*                                     BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID                 VALUES ARE
                   '1180', '1181', '1182', '1183', '1184'.
               88  WS-BUS-FCN-RETRIEVE                 VALUE '1180'.
               88  WS-BUS-FCN-CREATE                   VALUE '1181'.
               88  WS-BUS-FCN-UPDATE                   VALUE '1182'.
               88  WS-BUS-FCN-DELETE                   VALUE '1183'.
               88  WS-BUS-FCN-LIST                     VALUE '1184'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1180'.
           05  WS-ID                        PIC X(01).
               88  WS-ID-VALID              VALUE 'Y' 'N'.
           05  WS-PASS-KEY-DISPLAY.
               10  WS-PASS-KEY-COID         PIC X(02).
               10  FILLER                   PIC X(01)  VALUE SPACES.
               10  WS-PASS-KEY-CLASS        PIC X(01).
           05  WS-POL-ASIGN-STRT-ID-GRP.
               10  WS-POL-ASIGN-STRT-ID     PIC 9(09).
               10  FILLER                   PIC X(01)  VALUE SPACES.
           05  WS-POL-ASIGN-END-ID-GRP.
               10  WS-POL-ASIGN-END-ID      PIC 9(09).
               10  FILLER                   PIC X(01)  VALUE SPACES.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '1180'.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4)  BINARY.
025970         88  WS-DEFAULT-MAX-BROWSE-LINE          VALUE +12.
      /
      ***************************************************************
      *  LINKAGE COPYBOOKS
      ***************************************************************
014221 COPY CCWWLOCK.
      /
016537*COPY CCWL0620.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
014221 COPY XCWL8090.
      /
      ***************************************************************
      *  I/O COPYBOOKS                                              *
      ***************************************************************
      /
       COPY CCFRPASS.
       COPY CCFWPASS.
       COPY CCFHPASS.
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
      /
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
      /
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
      /
       COPY NCWM0075.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X

           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.


      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *
025970*    MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.


           IF WS-BUS-FCN-RETRIEVE
           OR WS-BUS-FCN-UPDATE
           OR WS-BUS-FCN-DELETE
              PERFORM 8000-CHECK-KEY-FIELDS
                 THRU 8000-CHECK-KEY-FIELDS-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
           OR NOT WGLOB-GOOD-RETURN
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-CREATE
                       THRU 4000-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

014221     PERFORM  PASS-1000-READ-TWRK-TS
014221         THRU PASS-1000-READ-TWRK-TS-X.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

      ****************************************************************
      * EACH RECORD OF THE BROWSE SCREEN.  THIS WILL ALLOW
      * USERS TO CHOSE A RECORD(S) TO PERFORM INQUIRE,
      * MAINTAIN OR DELETE PROCESSING FOR THE RECORD
      * SELECTED.
      *
      *  CHECK ENTER CODE FIELDS FOR INPUT
      ****************************************************************


           MOVE LOW-VALUES            TO WPASS-KEY.
           MOVE HIGH-VALUES           TO WPASS-ENDBR-KEY.

           MOVE WGLOB-COMPANY-CODE    TO WPASS-ENDBR-CO-ID.

           IF MIR-BUS-CLAS-CD GREATER SPACES
              MOVE MIR-BUS-CLAS-CD    TO WPASS-BUS-CLAS-CD
           END-IF.

           PERFORM PASS-1000-BROWSE
              THRU PASS-1000-BROWSE-X

           PERFORM PASS-2000-READ-NEXT
              THRU PASS-2000-READ-NEXT-X.

           IF NOT WPASS-IO-OK
           OR WPASS-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM PASS-3000-END-BROWSE
                  THRU PASS-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WPASS-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM PASS-3000-END-BROWSE
              THRU PASS-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /

      *------------
       4000-CREATE.
      *------------

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE MIR-BUS-CLAS-CD       TO WPASS-BUS-CLAS-CD.

           PERFORM PASS-1000-READ
              THRU PASS-1000-READ-X.

           IF  WPASS-IO-OK
               MOVE WPASS-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-CREATE-X
           END-IF.

      *
      ***  POLICY NUMBER ASSIGNMENT KEY EDITS.
      *
           MOVE MIR-BUS-CLAS-CD       TO WEDIT-ETBL-VALU-ID.

           PERFORM CLAS-1000-EDIT-CLASS
              THRU CLAS-1000-EDIT-CLASS-X.

           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *MSG:    CLASS OF BUSINESS NOT FOUND ON EDIT/CLASS
               MOVE 'NS00750002'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-BUS-CLAS-CD   TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-CREATE-X
           END-IF.

      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM PASS-1000-CREATE
              THRU PASS-1000-CREATE-X.

      ***  INITIALIZE START AND END RANGE

           MOVE '000000000 '          TO RPASS-POL-ASIGN-STRT-ID.
           MOVE '999999999 '          TO RPASS-POL-ASIGN-END-ID.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM PASS-1000-WRITE
              THRU PASS-1000-WRITE-X.

014221     PERFORM  PASS-1000-READ-TWRK-TS
014221         THRU PASS-1000-READ-TWRK-TS-X.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-CREATE-X.
           EXIT.
      /

      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------
      *
      *   MAINTENANCE PROCESSING INCLUDES EDITING THE
      *   DATA AND UPDATING, DELETING AND CREATING RECORDS.
      *
014221*    PERFORM PASS-1000-READ-FOR-UPDATE
014221*       THRU PASS-1000-READ-FOR-UPDATE-X.
014221
014221     PERFORM  PASS-2000-UPDATE-TWRK-TS
014221         THRU PASS-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'PASS'            TO WGLOB-MSG-PARM (01)
014221         MOVE WPASS-KEY         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF  NOT WPASS-IO-OK
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM 5300-EDIT-PASS-SCREEN-DATA
              THRU 5300-EDIT-PASS-SCREEN-DATA-X.

           PERFORM PASS-2000-REWRITE
              THRU PASS-2000-REWRITE-X.

014221     PERFORM  PASS-1000-READ-TWRK-TS
014221         THRU PASS-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'MAINTENANCE COMPLETED - CONTINUE'
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.

      /
      *---------------------------
       5300-EDIT-PASS-SCREEN-DATA.
      *---------------------------

           IF  MIR-POL-ASIGN-IND = SPACES
               MOVE RPASS-POL-ASIGN-IND
                                      TO MIR-POL-ASIGN-IND
           ELSE
               MOVE MIR-POL-ASIGN-IND TO WS-ID
               IF  WS-ID-VALID
                   MOVE MIR-POL-ASIGN-IND
                                      TO RPASS-POL-ASIGN-IND
               ELSE
      *MSG:    'POLICY ID MUST BE Y OR N'
                   MOVE 'NS00750004'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM 5310-EDIT-START-RANGE
              THRU 5310-EDIT-START-RANGE-X.

           PERFORM 5320-EDIT-END-RANGE
              THRU 5320-EDIT-END-RANGE-X.

           IF WGLOB-MSG-ERROR-SW = 0
              PERFORM 5330-EDIT-START-END-RANGE
                 THRU 5330-EDIT-START-END-RANGE-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM 5340-EDIT-RANGE-OVERLAP
                  THRU 5340-EDIT-RANGE-OVERLAP-X
           END-IF.


       5300-EDIT-PASS-SCREEN-DATA-X.
           EXIT.

      /
      *----------------------
       5310-EDIT-START-RANGE.
      *----------------------

           MOVE   RPASS-POL-ASIGN-STRT-ID
                                      TO WS-POL-ASIGN-STRT-ID-GRP.

           EVALUATE MIR-POL-ASIGN-STRT-ID

               WHEN SPACES
                    MOVE WS-POL-ASIGN-STRT-ID
                                      TO MIR-POL-ASIGN-STRT-ID

               WHEN OTHER
                    MOVE 'N'          TO L0280-SIGN-IND
                    MOVE ZERO         TO L0280-PRECISION
                    MOVE LENGTH OF MIR-POL-ASIGN-STRT-ID
                                      TO L0280-INPUT-SIZE
                    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 0
                    MOVE MIR-POL-ASIGN-STRT-ID
                                      TO L0280-INPUT-DATA
                    PERFORM 0280-1000-NUMERIC-EDIT
                       THRU 0280-1000-NUMERIC-EDIT-X
                    IF  L0280-OK
020874*                 COMPUTE L0290-INPUT-NUMBER =
020874*                                L0280-OUTPUT-V00 * 1
020874                  MOVE L0280-OUTPUT-V00
020874                                TO L0290-INPUT-V00
                        MOVE 0        TO L0290-PRECISION
                        MOVE LENGTH OF MIR-POL-ASIGN-STRT-ID
                                      TO L0290-MAX-OUT-LEN
020874*                 PERFORM  0290-1000-NUMERIC-FORMAT
020874*                     THRU 0290-1000-NUMERIC-FORMAT-X
020874                  PERFORM  0290-2000-FORMAT-FOR-MIR
020874                      THRU 0290-2000-FORMAT-FOR-MIR-X
                        MOVE L0290-OUTPUT-DATA
                                      TO MIR-POL-ASIGN-STRT-ID
                        MOVE L0290-OUTPUT-DATA
                                      TO
                             WS-POL-ASIGN-STRT-ID
                    ELSE
      *MSG:    'POLICY START RANGE MUST BE NUMERIC'
                        MOVE 'NS00750005'
                                      TO WGLOB-MSG-REF-INFO
                        PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                    END-IF
           END-EVALUATE.

       5310-EDIT-START-RANGE-X.
           EXIT.

      /
      *--------------------
       5320-EDIT-END-RANGE.
      *--------------------

           MOVE   RPASS-POL-ASIGN-END-ID
                                      TO WS-POL-ASIGN-END-ID-GRP.

           EVALUATE MIR-POL-ASIGN-END-ID

               WHEN SPACES
                    MOVE WS-POL-ASIGN-END-ID
                                      TO MIR-POL-ASIGN-END-ID

               WHEN OTHER
                    MOVE 'N'          TO L0280-SIGN-IND
                    MOVE ZERO         TO L0280-PRECISION
                    MOVE LENGTH OF MIR-POL-ASIGN-END-ID
                                      TO L0280-INPUT-SIZE
                    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 0
                    MOVE MIR-POL-ASIGN-END-ID
                                      TO L0280-INPUT-DATA
                    PERFORM 0280-1000-NUMERIC-EDIT
                       THRU 0280-1000-NUMERIC-EDIT-X
                    IF  L0280-OK
020874*                 COMPUTE L0290-INPUT-NUMBER =
020874*                         L0280-OUTPUT-V00 * 1
020874                  MOVE L0280-OUTPUT-V00
020874                                TO L0290-INPUT-V00
                        MOVE 0        TO L0290-PRECISION
                        MOVE LENGTH OF MIR-POL-ASIGN-END-ID
                                      TO L0290-MAX-OUT-LEN
020874*                 PERFORM  0290-1000-NUMERIC-FORMAT
020874*                     THRU 0290-1000-NUMERIC-FORMAT-X
020874                  PERFORM  0290-2000-FORMAT-FOR-MIR
020874                      THRU 0290-2000-FORMAT-FOR-MIR-X
                        MOVE L0290-OUTPUT-DATA
                                      TO MIR-POL-ASIGN-END-ID
                        MOVE L0290-OUTPUT-DATA
                                      TO
                             WS-POL-ASIGN-END-ID
                    ELSE
      *MSG:    'POLICY END RANGE MUST BE NUMERIC'
                        MOVE 'NS00750006'
                                      TO WGLOB-MSG-REF-INFO
                        PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                    END-IF
           END-EVALUATE.

       5320-EDIT-END-RANGE-X.
           EXIT.


      *--------------------------
       5330-EDIT-START-END-RANGE.
      *--------------------------

           IF  WS-POL-ASIGN-STRT-ID NUMERIC
           AND WS-POL-ASIGN-END-ID  NUMERIC
               IF WS-POL-ASIGN-STRT-ID < WS-POL-ASIGN-END-ID
                   CONTINUE
               ELSE
      *MSG:    'START RANGE MUST NOT BE GREATER THAN END RANGE'
                   MOVE 'NS00750007'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       5330-EDIT-START-END-RANGE-X.
           EXIT.


      *------------------------
       5340-EDIT-RANGE-OVERLAP.
      *------------------------
      *
      ***  SAVE RECORD CONTENT FOR LATTER UPDATE
      *
           MOVE RPASS-REC-INFO        TO HPASS-REC-INFO.

           PERFORM  PASS-3000-UNLOCK
               THRU PASS-3000-UNLOCK-X.

           MOVE LOW-VALUES            TO WPASS-KEY.
           MOVE HIGH-VALUES           TO WPASS-ENDBR-KEY.

           MOVE WGLOB-COMPANY-CODE    TO WPASS-ENDBR-CO-ID.

           PERFORM PASS-1000-BROWSE
              THRU PASS-1000-BROWSE-X.

           IF WPASS-IO-OK
              PERFORM  5341-EDIT-RANGE-LOOP
                  THRU 5341-EDIT-RANGE-LOOP-X
                  UNTIL NOT WPASS-IO-OK
                  OR WGLOB-MSG-ERROR-SW > 0
              PERFORM  PASS-3000-END-BROWSE
                  THRU PASS-3000-END-BROWSE-X
           END-IF.

           MOVE HPASS-KEY             TO WPASS-KEY.

           PERFORM  PASS-1000-READ-FOR-UPDATE
               THRU PASS-1000-READ-FOR-UPDATE-X.

           MOVE     HPASS-REC-INFO    TO RPASS-REC-INFO.

           IF       WGLOB-MSG-ERROR-SW = 0
               MOVE WS-POL-ASIGN-STRT-ID
                                      TO RPASS-POL-ASIGN-STRT-ID
               MOVE WS-POL-ASIGN-END-ID
                                      TO RPASS-POL-ASIGN-END-ID
           END-IF.

       5340-EDIT-RANGE-OVERLAP-X.
           EXIT.

      *---------------------
       5341-EDIT-RANGE-LOOP.
      *---------------------

           PERFORM  PASS-2000-READ-NEXT
               THRU PASS-2000-READ-NEXT-X.

           IF  WPASS-IO-OK
           AND RPASS-KEY NOT = HPASS-KEY
           AND RPASS-POL-ASIGN
           AND HPASS-POL-ASIGN
               IF WS-POL-ASIGN-STRT-ID > RPASS-POL-ASIGN-END-ID
               OR RPASS-POL-ASIGN-STRT-ID > WS-POL-ASIGN-END-ID
                    CONTINUE
               ELSE
      *MSG:    'RANGE MUST NOT OVERLAP WITH OTHER BUSINESS CLASS'
                   MOVE 'NS00750008'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       5341-EDIT-RANGE-LOOP-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

      ***************************************************************
      * DELETE PROCESSING CONSISTS OF DELETING THE
      * RECORD (BACKOUTS ARE HANDLED IN THE MAINLINE).
      *
      * BUILD PASS KEY FROM KEY AREA ON SCREEN.
      ***************************************************************

           MOVE MIR-BUS-CLAS-CD       TO WPASS-BUS-CLAS-CD.

014221*    PERFORM PASS-1000-READ-FOR-UPDATE
014221*       THRU PASS-1000-READ-FOR-UPDATE-X
014221
014221     PERFORM  PASS-2000-UPDATE-TWRK-TS
014221         THRU PASS-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'PASS'            TO WGLOB-MSG-PARM (01)
014221         MOVE WPASS-KEY         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WPASS-IO-OK
               PERFORM PASS-1000-DELETE
                  THRU PASS-1000-DELETE-X
               IF WPASS-IO-OK
      *MSG:       DELETE COMPLETED MESSAGE
                  MOVE 'XS00000011'   TO WGLOB-MSG-REF-INFO
               ELSE
      *MSG:       RECORD (@1) LOST IN DELETE
                  MOVE WPASS-KEY      TO WGLOB-MSG-PARM (1)
                  MOVE 'XS00000010'   TO WGLOB-MSG-REF-INFO
               END-IF
           ELSE
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WPASS-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.


       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *****************************************************************
      *   CHECK KEY FIELDS
      *   ENSURE THAT THE POLICY NUMBER ASSIGNMENT ROW EXISTS
      *****************************************************************
      *----------------------
       8000-CHECK-KEY-FIELDS.
      *----------------------

           MOVE MIR-BUS-CLAS-CD       TO WPASS-BUS-CLAS-CD.

           PERFORM 8100-READ-PASS-INFO
              THRU 8100-READ-PASS-INFO-X.

       8000-CHECK-KEY-FIELDS-X.
           EXIT.

      *--------------------
       8100-READ-PASS-INFO.
      *--------------------

           PERFORM PASS-1000-READ
              THRU PASS-1000-READ-X.

           IF WPASS-IO-NOT-FOUND
      *MSG:    "RECORD NOT FOUND"
               MOVE MIR-CO-ID         TO WS-PASS-KEY-COID
               MOVE MIR-BUS-CLAS-CD   TO WS-PASS-KEY-CLASS
               MOVE WS-PASS-KEY-DISPLAY
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM 9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
           END-IF.

       8100-READ-PASS-INFO-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           IF  WS-BUS-FCN-LIST
013578*        MOVE SPACES            TO MIR-ENT-TABLE
               MOVE SPACES            TO MIR-BUS-CLAS-CD-G
               MOVE SPACES            TO MIR-POL-ASIGN-IND-G
               MOVE SPACES            TO MIR-POL-ASIGN-STRT-ID-G
               MOVE SPACES            TO MIR-POL-ASIGN-END-ID-G
               MOVE SPACES            TO MIR-DV-BUS-CLAS-TXT-G
           ELSE
               MOVE SPACES            TO MIR-POL-ASIGN-IND
               MOVE SPACES            TO MIR-POL-ASIGN-STRT-ID
               MOVE SPACES            TO MIR-POL-ASIGN-END-ID
               MOVE SPACES            TO MIR-DV-BUS-CLAS-TXT
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  WS-BUS-FCN-LIST
               PERFORM 9210-MOVE-PASS-TO-SCRN-1
                  THRU 9210-MOVE-PASS-TO-SCRN-1-X
                VARYING I FROM 1 BY 1
                  UNTIL I > WS-MAX-BROWSE-LINES
                     OR WPASS-IO-EOF

               IF  NOT WPASS-IO-EOF
                   MOVE RPASS-CO-ID   TO MIR-CO-ID
                   MOVE RPASS-BUS-CLAS-CD
                                      TO MIR-BUS-CLAS-CD
               END-IF

               IF  WPASS-IO-EOF
               AND MIR-BUS-CLAS-CD-T (1) NOT = SPACES
                   MOVE MIR-BUS-CLAS-CD-T (1)
                                      TO MIR-BUS-CLAS-CD
               END-IF
           ELSE
               MOVE RPASS-POL-ASIGN-IND
                                      TO MIR-POL-ASIGN-IND
               MOVE RPASS-POL-ASIGN-STRT-ID
                                      TO MIR-POL-ASIGN-STRT-ID
               MOVE RPASS-POL-ASIGN-END-ID
                                      TO MIR-POL-ASIGN-END-ID
               MOVE RPASS-BUS-CLAS-CD TO WEDIT-ETBL-VALU-ID
               PERFORM CLAS-2000-DESC
                  THRU CLAS-2000-DESC-X
               IF  WEDIT-IO-OK
                   MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-DV-BUS-CLAS-TXT
               ELSE
                   MOVE SPACES        TO MIR-DV-BUS-CLAS-TXT
               END-IF
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      /
      *-------------------------
       9210-MOVE-PASS-TO-SCRN-1.
      *-------------------------

013578*    MOVE SPACE                 TO MIR-ENT-T   (I).
           MOVE RPASS-BUS-CLAS-CD     TO MIR-BUS-CLAS-CD-T (I).
           MOVE RPASS-POL-ASIGN-IND   TO MIR-POL-ASIGN-IND-T    (I).
           MOVE RPASS-POL-ASIGN-STRT-ID
                                      TO MIR-POL-ASIGN-STRT-ID-T  (I).
           MOVE RPASS-POL-ASIGN-END-ID   TO MIR-POL-ASIGN-END-ID-T  (I).

           MOVE RPASS-BUS-CLAS-CD     TO WEDIT-ETBL-VALU-ID.

           PERFORM CLAS-2000-DESC
              THRU CLAS-2000-DESC-X.

           IF  WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-DV-BUS-CLAS-TXT-T (I)
           ELSE
               MOVE SPACES            TO MIR-DV-BUS-CLAS-TXT-T (I)
           END-IF.

           PERFORM PASS-2000-READ-NEXT
              THRU PASS-2000-READ-NEXT-X.

       9210-MOVE-PASS-TO-SCRN-1-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                      WS-WORKING-STORAGE.
025970     INITIALIZE                      WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                      WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY         TO TRUE.
025970     SET WS-DEFAULT-MAX-BROWSE-LINE  TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PASS
014221                         '$VAR2' BY 'PASS'.
      /
       COPY CCPECLAS.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
016537*COPY CCPL0620.

      *COPY CCCL2435.
      *COPY CCPS2435.

      *COPY NCCL3340.
      /
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY CCPNEDIT.
      /
       COPY CCPAPASS.
       COPY CCPNPASS.
       COPY CCPBPASS.
       COPY CCPCPASS.
       COPY CCPUPASS.
       COPY CCPXPASS.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM NSOM0075                       *
      ******************************************************************
