      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM0131.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0131                                         **
      **  REMARKS:  RHDR - MAINTAIN RATE HEADERS (RH).               **
      **            THIS PROCESS DRIVER PERFORMS ALL MAINTENANCE     **
      **            FUNCTIONS FOR THE RATE HEADER TABLE (RH) VIA     **
      **            THE RHDR TRANSATION                              **
      **  DOMAIN :  AT                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557691**  5.5       ONLINE PROCESSING FOR US QUALIFIED PRODUCT       **
557694**  5.5       MINIMUM DISTRB. FOR QUALIFIED CONTRACTS          **
557708**  5.5       HANDLING OF CICS ABENDS                          **
557767**  5.5       JOINT AGE CALCULATION                            **
008454**  5.5.2     RT TABLE NORMALIZATION                           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
010302**  5.6       CHANGE LOCATION CODE TO LOCATION GROUP           **
010314**  5.6       HANDLE NEW SCREEN FIELD FOR DEPOSIT TERM         **
012168**  5.6       DATES MOVED TO MIR-RH-EFF-DT MUSTBE 10BYTES      **
012143**  5.6V      ADD DUR VALS B,D. DEP BASED SURR CHGS SUPP       **
014035**  5.6V      CLEAN-UP                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
016534**  6.2       ADD DUR TYPE "I"                                 **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
015951**  6.3       DISABILITY RIDERS ON TRAD POLICIES (6.1.1E)      **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
022730**  6.5       MOVE UNIT VALUES TO RATE HEADER/RATE LOAD        **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028230**  6.7       FIX FIELDS PREFIX                                **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0131'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
025970*    05  TRANSACTION-NAME    PIC X(04)  VALUE 'RHDR'.
025970*    05  NUM-ERR-LN          PIC 9(02)  VALUE 01.
025970*    05  ERROR-LINE-SCREEN   PIC 9(02)  VALUE 01.
025970*    05  WS-MAX-PARM-LENGTH  PIC S9(02) VALUE 64.
025970
010302     05  WS-TOT-PARM-LENGTH  PIC S9(03) VALUE ZEROS.
010302     05  WS-RTBL-ID-MASK.
010302         10  WS-RTBL-ID-X    OCCURS 6 TIMES PIC X(01).
010302     05  WS-RTTYPE-MASK.
010302         10  WS-RTTYPE-X     OCCURS 5 TIMES PIC X(01).
010302     05  WS-SAVE-INT-DT      PIC X(10).
010302     05  WS-SAVE-EXT-DT      PIC X(09).
           05  WS-BUS-FCN-ID       PIC X(04).
               88  WS-BUS-FCN-ID-VALID       VALUES '1200' '1201' '1202'
                                                    '1203' '1204'.
               88  WS-BUS-FCN-RETRIEVE       VALUE  '1200'.
               88  WS-BUS-FCN-CREATE         VALUE  '1201'.
               88  WS-BUS-FCN-UPDATE         VALUE  '1202'.
               88  WS-BUS-FCN-DELETE         VALUE  '1203'.
               88  WS-BUS-FCN-LIST           VALUE  '1204'.
025970*    05  WS-TWRK-KEY                   PIC X(04) VALUE  '1200'.
025970
025970 01  WS-CONSTANTS.
025970     05  WS-TRANSACTION-NAME             PIC X(04).
025970         88 WS-TRANSACTION-RHDR          VALUE 'RHDR'.
025970     05  WS-NUM-ERR-LN                   PIC 9(02).
025970         88 WS-NUM-ERR-LN-DEFAULT        VALUE 01.
025970     05  WS-ERROR-LN-SCRN                PIC 9(02).
025970         88 WS-ERROR-LN-SCRN-DEFAULT     VALUE 01.
025970     05  WS-MAX-PARM-LENGTH              PIC S9(02).
025970         88 WS-MAX-PARM-LENGTH-DEFAULT   VALUE 64.
025970     05  WS-TWRK-KEY                     PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '1200'.
025970     05  WS-END-OF-FILE                  PIC X(37).
025970         88 WS-END-OF-FILE-DEFAULT       VALUE '*****'.
025970     05  WS-HIGH-AMT                  PIC  9(13)
025970                                           VALUE 9999999999999.
025970  
      *
      * COUNTERS
      *
       01  CNTS.
           05 I                      PIC  9(3).
           05 J                      PIC  9(3).
025970*    05 LINE-10                PIC S9(4) VALUE +720.
      *
      * SWITCHES
      *
       01  SW.
           05 SW-END-OF-FILE         PIC 9.
              88 SW-END-OF-FILE-REACHED    VALUES 7 8 9.
              88 SW-NOT-END-OF-FILE        VALUE 0.
      *
      * MISCELLANEOUS WORKING STORAGE DECLARES.
      *
       01  WS.
025970*    05 WS-END-OF-FILE         PIC X(37) VALUE '*****'.
           05 WS-FILE-START-KEY-ALL.
              10 FILLER              PIC X(02).
              10 WS-FILE-START-KEY   PIC X(37).
           05 WS-KEY-ALL-HOLD.
              10 FILLER              PIC X(02).
              10 WS-KEY-HOLD         PIC X(37).
           05 WS-FIRST-KEY-HOLD      PIC X(37).
           05 WS-LAST-KEY-HOLD       PIC X(37).
016548*    05 WS-LAST-ON-SCREEN-HOLD PIC S9(4)       COMP.
016548     05 WS-LAST-ON-SCREEN-HOLD PIC S9(4)       BINARY.
008454     05 WS-SUB                 PIC S9(4).
010302     05 WS-SUB1                PIC S9(4).
008454     05 S                      PIC S9(4).
       01  WS-START                  PIC X(37).
      *
014035*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
       COPY XCWLDTLK.
008455
008455 COPY XCWL0280.
008455*
008455 COPY XCWL0290.
008455*
       COPY XCWL1640.
      *
       COPY XCWL1660.
      *
014221 COPY XCWL8090.
      *
013578*COPY CCWCRHDR.
      *
      *****************************************************************
      ** MISCELLANEOUS WORKING STORAGE AREA                          **
      *****************************************************************
       01  MISC-WS.
025970*    05  FILLER                       PIC  X(13)
025970*                                          VALUE 'MISC WS START'.
           05  CHAR-ATTRIBUTE               PIC  X(01).
           05  NUM-ATTRIBUTE                PIC  X(01).
008455*    05  WS-BAND-AMT                  PIC S9(09).
008455     05  WS-AMT                       PIC  9(13).
025970*    05  WS-HIGH-AMT                  PIC  9(13)
025970*                                           VALUE 9999999999999.
008455     05  WS-BAND-AMT                  PIC  9(13).
008455     05  WS-BAND-AMT-X REDEFINES WS-BAND-AMT
008455                                      PIC  X(13).
008455     05  WS-MIR-LEN                   PIC  9(02).
           05  BANDS-EDIT-COMPLETE-SW       PIC  X(01).
               88  BANDS-EDIT-NOT-COMPLETE       VALUE '0'.
               88  BANDS-EDIT-IS-COMPLETE        VALUE '1'.
           05  ERROR-LINE                   PIC  X(79).
           05  ERROR-COUNTER       COMP-3   PIC S9(03).

           05  RH-I                COMP-3   PIC S9(03).
           05  RH-KEY-IO-DATA.
               10  RH-KEY-SMOKERS-CODE-IND  PIC  X(01).
               10  RH-KEY-PAR-CODE-IND      PIC  X(01).
               10  RH-KEY-SEX-IND           PIC  X(01).
               10  RH-KEY-SUB-TABLE-1-IND   PIC  X(01).
               10  RH-KEY-SUB-TABLE-2-IND   PIC  X(01).
               10  RH-KEY-SUB-TABLE-3-IND   PIC  X(01).
               10  RH-KEY-SUB-TABLE-4-IND   PIC  X(01).
010302*        10  RH-KEY-CURRENT-LOCATION-IND
010302*                                     PIC  X(01).
010302         10  RH-KEY-LOC-TYP-CD        PIC  X(01).
010302         10  RH-KEY-LOC-DT-TYP-CD     PIC  X(01).
               10  RH-KEY-DBO-IND           PIC  X(01).
557691         10  RH-KEY-PQ-IND            PIC  X(01).
557767         10  RH-KEY-JT-IND            PIC  X(01).
               10  RH-KEY-AGE-TYPE          PIC  X(01).
               10  RH-KEY-DURATION-TYPE     PIC  X(01).
               10  RH-KEY-DATE-TYPE         PIC  X(01).
               10  RH-KEY-BANDING-TYPE      PIC  X(01).
               10  RH-KEY-BAND-USE          PIC  X(01).
               10  RH-KEY-DISPLAY-EFF-DATE.
                   15 RH-KEY-DISPLAY-EFF-YEAR
                                            PIC  9(04).
                   15 FILLER                PIC  X(01).
                   15 RH-KEY-DISPLAY-EFF-MONTH
                                            PIC  9(02).
                   15 FILLER                PIC  X(01).
                   15 RH-KEY-DISPLAY-EFF-DAY
                                            PIC  9(02).
               10  RH-KEY-MAX-DUR           PIC  X(03).
               10  RH-KEY-MAX-DUR-N REDEFINES
                   RH-KEY-MAX-DUR           PIC  9(03).
               10  RH-KEY-SELECT-PERIOD     PIC  X(03).
               10  RH-KEY-SELECT-PERIOD-N REDEFINES
                   RH-KEY-SELECT-PERIOD     PIC  9(03).
008454         10  RH-KEY-RT-TYPE           PIC  X(05).
010314         10  RH-KEY-DPOS-TRM-IND      PIC  X(01).
012525         10  RH-KEY-CVG-TRM-IND       PIC  X(01).
012525         10  FILLER                   PIC  X(12).
012525*        10  FILLER                   PIC  X(13).
010314*        10  FILLER                   PIC  X(15).
008454*        10  FILLER                   PIC  X(20).
               10  RH-KEY-BANDS             OCCURS 6.
008455*            15  RH-KEY-BAND-AMOUNT   PIC  X(09).
008455             15  RH-KEY-BAND-AMOUNT   PIC  X(14).
008455*            15  RH-KEY-BAND-AMOUNT-N REDEFINES
008455*                RH-KEY-BAND-AMOUNT   PIC 9(09).
008455             15  RH-KEY-BAND-AMOUNT-N PIC  9(13).
                   15  RH-KEY-RATE-LOAD-PTR PIC  X(06).

       COPY CCFWRH.
      *
       COPY CCFRRH.
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
       COPY CCWWDSWA.
008454 COPY CCWWRHDR.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0131.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      **********************
       2000-PROCESS-REQUEST.
      **********************
      *
008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
      *
025970*    MOVE ZERO                  TO BANDS-EDIT-COMPLETE-SW.
025970*    MOVE 1                     TO ERROR-LINE-SCREEN.
025970*    MOVE ZERO                  TO RH-I.
025970*    MOVE 0                     TO SW-END-OF-FILE.

025970*    MOVE MIR-RH-ID             TO WRH-RH-ID.
013578     IF  NOT WS-BUS-FCN-LIST
008454         MOVE MIR-RH-EFF-DT     TO L1640-EXTERNAL-DATE
008454         PERFORM  2100-VALIDATE-EFF-DATE
008454             THRU 2100-VALIDATE-EFF-DATE-X
008454     END-IF.
      *
           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
           EVALUATE  TRUE
               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X
               WHEN WS-BUS-FCN-CREATE
                    PERFORM  5000-PROCESS-CREATE
                        THRU 5000-PROCESS-CREATE-X
               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  6000-PROCESS-UPDATE
                        THRU 6000-PROCESS-UPDATE-X
               WHEN WS-BUS-FCN-DELETE
                    PERFORM  7000-PROCESS-DELETE
                        THRU 7000-PROCESS-DELETE-X
               WHEN WS-BUS-FCN-LIST
                    PERFORM  4000-PROCESS-LIST
                        THRU 4000-PROCESS-LIST-X
               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      ************************
       2100-VALIDATE-EFF-DATE.
      ************************
      *
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE
                                      TO WRH-RH-IDT-NUM-N
           ELSE
               MOVE 'CS01310002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       2100-VALIDATE-EFF-DATE-X.
           EXIT.
      *
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************
      *
014221*    PERFORM  RH-1000-READ
014221*        THRU RH-1000-READ-X.
      *
014221     PERFORM  RH-1000-READ-TWRK-TS
014221         THRU RH-1000-READ-TWRK-TS-X.

      *
           IF WRH-IO-NOT-FOUND
               MOVE 'CS01310004'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  RH-1000-CREATE
                   THRU RH-1000-CREATE-X
           ELSE
               MOVE RRH-RH-EFF-DT TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
557660     END-IF.
      *
           PERFORM  8000-MOVE-RECORD-TO-SCREEN
               THRU 8000-MOVE-RECORD-TO-SCREEN-X.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.

008454*------------------
008454 4000-PROCESS-LIST.
008454*------------------

008454     MOVE 'RH'                  TO RHDR-FILE-TYPE.
008454     PERFORM 4240-INIT-RHDR-HOLD-AREA
008454        THRU 4240-INIT-RHDR-HOLD-AREA-X.
008454
008454     PERFORM 4010-MOVE-MAP-TO-DIRS
008454         THRU 4010-MOVE-MAP-TO-DIRS-X.
008454
008454     PERFORM 4040-SET-PROCESSING-OPTION
008454         THRU 4040-SET-PROCESSING-OPTION-X.
008454
008454     PERFORM 4060-PROCESS-DATA
008454         THRU 4060-PROCESS-DATA-X.
008454
008454 4000-PROCESS-LIST-X.
008454     EXIT.
008454*
008454*-----------------------
008454 4010-MOVE-MAP-TO-DIRS.
008454*-----------------------
008454***********************************************************
008454*   MOVE THE SCREEN INPUT TO THE DIRECTORY SCREEN WORK AREA
008454***********************************************************
008454
008454     MOVE 'RH'                  TO RHDR-FILE-TYPE.
008454     MOVE MIR-RH-ID             TO RHDR-FILE-START-KEY.
008454
008454     PERFORM
008454         VARYING I FROM 1 BY 1
008454         UNTIL   I > +36
008454
008454         MOVE MIR-RH-ID-T (I)   TO RHDR-HOLD-MAP-PTR(I)
008454         MOVE MIR-RH-EFF-DT-T (I)
                                      TO RHDR-HOLD-MAP-EDAT(I)
008454
008454     END-PERFORM.
008454
008454 4010-MOVE-MAP-TO-DIRS-X.
008454     EXIT.
008454
008454*
008454*----------------------------
008454 4040-SET-PROCESSING-OPTION.
008454*----------------------------
008454**************************************************
008454*   DETERMINE WHAT KIND OF PROCESSING WILL BE DONE
008454**************************************************
008454
008454*
008454* IF ANY ERRORS ENCOUNTERED, REDISPLAY THE SCREEN
008454*
008454     IF WGLOB-MSG-ERROR-SW EQUAL 1
008454         MOVE RHDR-REDISPLAY    TO RHDR-PROC-OPTION
008454         GO TO 4040-SET-PROCESSING-OPTION-X
008454     END-IF.
008454
008454* USE SCROLL OPTION FROM SCREEN
008454*
008454     MOVE RHDR-BROWSE-FWD       TO RHDR-PROC-OPTION.
008454
008454
008454 4040-SET-PROCESSING-OPTION-X.
008454     EXIT.
008454*
008454*-------------------
008454 4060-PROCESS-DATA.
008454*-------------------
008454****************************************
008454*   PROCESS DATA AS PER RHDR-PROC-OPTION
008454****************************************
008454
008454     IF RHDR-PROC-BROWSE-FWD
008454         PERFORM  4090-FILL-SCREEN
008454             THRU 4090-FILL-SCREEN-X
008454     END-IF.
008454
008454 4060-PROCESS-DATA-X.
008454     EXIT.
008454*
008454*------------------
008454 4090-FILL-SCREEN.
008454*------------------
008454*****************************************
008454*   LOAD NEW SCREEN FROM APPROPRIATE FILE
008454*****************************************
008454
008454*
008454* SET UP WORK AREA
008454*
008454* NOTE: IF BROWSING BACKWARD, WANT THE PREVIOUS SCREEN IN
008454* ARRAY ENTRIES 25-48 AND FILL CURRENT SCREEN WORKING
008454* BACK FROM 24 TO 1
008454* INITIALLY, THE CURRENT SCREEN IS THE SAME AS THE PREVIOUS
008454* IF FILE START KEY ENTERED, IGNORE THE PREVIOUS SCREEN (LEAVE
008454* 24-48 BLANK)
008454*
008454* FOR A FORWARD BROWSE IGNORE THE PREVIOUS SCREEN AND JUST
008454* FILL CURRENT SCREEN FORWARD FROM 1 TO 24
008454*
028230*    MOVE SPACES                TO DSWA-SCREEN-WORK-AREA.
028230     MOVE SPACES                TO WDSWA-SCREEN-WORK-AREA.
008454
008454     IF RHDR-ONE-COLUMN
008454         MOVE 12                TO RHDR-MAX-INX
008454     ELSE
008454         MOVE 36                TO RHDR-MAX-INX
008454     END-IF.
008454
008454
028230*    MOVE 1                     TO DSWA-SCREEN-KEY-FIRST.
028230*    MOVE 0                     TO DSWA-SCREEN-KEY-LAST.
028230     MOVE 1                     TO WDSWA-SCREEN-KEY-FIRST.
028230     MOVE 0                     TO WDSWA-SCREEN-KEY-LAST.
008454
008454*
008454* START BROWSE
008454*
008454     PERFORM 4110-START-BROWSE
008454         THRU 4110-START-BROWSE-X.
008454
008454*
008454* BROWSE THE FILE
008454*
008454     PERFORM 4120-BROWSE-FORWARD
008454        THRU 4120-BROWSE-FORWARD-X.
008454
008454*
008454* END THE BROWSE
008454*
008454     PERFORM RH-3000-END-BROWSE
008454        THRU RH-3000-END-BROWSE-X.
008454*
008454* MOVE WORK LINE BACK TO SCREEN LINE
008454*
008454     PERFORM 4180-MOVE-WORK-TO-SCREEN
008454         THRU 4180-MOVE-WORK-TO-SCREEN-X
008454         VARYING I FROM 1 BY 1
008454         UNTIL I > +36.
013578*
013578     IF MIR-RH-ID-T (36) NOT = SPACE
013578         MOVE MIR-RH-ID-T (36)        TO MIR-RH-ID
013578         MOVE MIR-RH-EFF-DT-T (36)    TO MIR-RH-EFF-DT
013578     END-IF.
008454*
008454* MOVE FILE TYPE TO COMMUNICATION AREA
008454*
008454 4090-FILL-SCREEN-X.
008454     EXIT.
008454*
008454*-----------------------------
008454 4100-MOVE-LINE-TO-WORK-LINE.
008454*-----------------------------
008454*********************************************
008454*   MOVE SCREEN LINE TO SCREEN LINE WORK AREA
008454*********************************************
008454
028230*    COMPUTE J = I + DSWA-SCREEN-KEY-FIRST - 1.
028230     COMPUTE J = I + WDSWA-SCREEN-KEY-FIRST - 1.
008454
028230*    MOVE RHDR-HOLD-MAP-KEY(I)  TO DSWA-SCREEN-WORK-LINE(J).
028230     MOVE RHDR-HOLD-MAP-KEY(I)  TO WDSWA-SCREEN-WORK-LINE(J).
008454
008454 4100-MOVE-LINE-TO-WORK-LINE-X.
008454     EXIT.
008454
008454*-------------------
008454 4110-START-BROWSE.
008454*-------------------
008454****************************************
008454*   START BROWSE ON THE APPROPRIATE FILE
008454****************************************
008454
008454     IF RHDR-FILE-START-KEY NOT EQUAL SPACES
008454         MOVE RHDR-FILE-START-KEY
                                      TO RHDR-KEY
008454         PERFORM 4160-COMPRESS-KEY
008454            THRU 4160-COMPRESS-KEY-X
008454         MOVE RHDR-KEY-ALL      TO WRH-KEY
008454         MOVE HIGH-VALUES       TO WRH-ENDBR-KEY
008454         PERFORM RH-1000-BROWSE
008454             THRU RH-1000-BROWSE-X
008454         MOVE WRH-IO-STATUS     TO SW-END-OF-FILE
008454
008454     ELSE
008454         MOVE WS-FILE-START-KEY-ALL
                                      TO WRH-KEY
008454         MOVE HIGH-VALUES       TO WRH-ENDBR-KEY
008454         PERFORM RH-1000-BROWSE
008454            THRU RH-1000-BROWSE-X
008454         MOVE WRH-IO-STATUS     TO SW-END-OF-FILE
008454     END-IF.
008454
008454 4110-START-BROWSE-X.
008454     EXIT.
008454*
008454*---------------------
008454 4120-BROWSE-FORWARD.
008454*---------------------
008454*****************************
008454*   BROWSE FORWARD PROCESSING
008454*****************************
008454
008454*
008454* LOAD SCREEN WORK AREA
008454*
008454     PERFORM 4130-BROWSING-FORWARD
008454         THRU 4130-BROWSING-FORWARD-X
008454         VARYING I FROM 1 BY 1
008454         UNTIL (I > RHDR-MAX-INX
008454           OR SW-END-OF-FILE-REACHED).
008454
008454     PERFORM 4160-COMPRESS-KEY
008454         THRU 4160-COMPRESS-KEY-X.
008454
008454     IF SW-END-OF-FILE-REACHED
008454         GO TO 4120-BROWSE-FORWARD-X
008454     END-IF.
008454
008454     PERFORM 4140-READ-NEXT
008454         THRU 4140-READ-NEXT-X.
008454
008454 4120-BROWSE-FORWARD-X.
008454     EXIT.

008454*-----------------------
008454 4130-BROWSING-FORWARD.
008454*-----------------------
008454************************************************
008454*   READ ONE RECORD FORWARD AND LOAD SCREEN LINE
008454************************************************
008454
008454     PERFORM 4140-READ-NEXT
008454         THRU 4140-READ-NEXT-X.
008454
008454     IF SW-NOT-END-OF-FILE
008454         PERFORM 4150-BREAKOUT-KEY-FIELDS
008454             THRU 4150-BREAKOUT-KEY-FIELDS-X
028230*        ADD 1              TO DSWA-SCREEN-KEY-LAST
028230*        MOVE RHDR-KEY          TO DSWA-SCREEN-KEY
028230*              (DSWA-SCREEN-KEY-LAST)
028230         ADD 1              TO WDSWA-SCREEN-KEY-LAST
028230         MOVE RHDR-KEY          TO WDSWA-SCREEN-KEY
028230               (WDSWA-SCREEN-KEY-LAST)
008454     END-IF.
008454
008454     IF SW-NOT-END-OF-FILE
008454     AND RHDR-ONE-COLUMN
028230*        ADD 12             TO DSWA-SCREEN-KEY-LAST
028230*        MOVE RHDR-DATA         TO DSWA-SCREEN-KEY
028230*              (DSWA-SCREEN-KEY-LAST)
028230*        SUBTRACT 12 FROM DSWA-SCREEN-KEY-LAST
028230         ADD 12             TO WDSWA-SCREEN-KEY-LAST
028230         MOVE RHDR-DATA         TO WDSWA-SCREEN-KEY
028230               (WDSWA-SCREEN-KEY-LAST)
028230         SUBTRACT 12 FROM WDSWA-SCREEN-KEY-LAST
008454     END-IF.
008454
008454 4130-BROWSING-FORWARD-X.
008454     EXIT.
008454*
008454*----------------
008454 4140-READ-NEXT.
008454*----------------
008454********************
008454*   READ NEXT RECORD
008454********************
008454
008454     PERFORM RH-2000-READ-NEXT
008454        THRU RH-2000-READ-NEXT-X.
008454     MOVE WRH-IO-STATUS         TO SW-END-OF-FILE.
008454
008454 4140-READ-NEXT-X.
008454     EXIT.
008454
008454*
008454*--------------------------
008454 4150-BREAKOUT-KEY-FIELDS.
008454*--------------------------
008454**********************************
008454*   MOVE KEY FIELDS TO SCREEN LINE
008454**********************************
008454
008454     MOVE SPACES                TO RHDR-KEY.
008454     MOVE SPACES                TO RHDR-DATA.
008454
008454
008454     MOVE RRH-RH-ID             TO RHDR-KEY-RH-HEADER-PTR.
008454     MOVE RRH-RH-EFF-DT         TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
008454     MOVE L1640-EXTERNAL-DATE   TO RHDR-KEY-RH-EFF-DATE.
008454
008454
008454 4150-BREAKOUT-KEY-FIELDS-X.
008454     EXIT.
008454*
008454*-------------------
008454 4160-COMPRESS-KEY.
008454*-------------------
008454*******************************************************
008454*   COMPRESS A KEY FROM THE SCREEN TO OBTAIN A FILE KEY
008454*******************************************************
008454
008454     IF RHDR-KEY EQUAL LOW-VALUES
008454     OR RHDR-KEY EQUAL SPACES
008454         GO TO 4160-COMPRESS-KEY-X
008454     END-IF.
008454
008454     MOVE RHDR-KEY-RH-HEADER-PTR                     TO RRH-RH-ID.
008454     MOVE RHDR-KEY-RH-EFF-DATE  TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
008454     IF L1640-VALID
008454         MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
008454         PERFORM 1660-2000-CONVERT-INT-TO-INV
008454            THRU 1660-2000-CONVERT-INT-TO-INV-X
008454         MOVE L1660-INVERTED-DATE
                                      TO RRH-RH-IDT-NUM-N
008454     END-IF.
008454
008454
008454 4160-COMPRESS-KEY-X.
008454     EXIT.
008454
008454*********************************
008454*   MOVE WORK LINE TO SCREEN LINE
008454*********************************
008454*--------------------------
008454 4180-MOVE-WORK-TO-SCREEN.
008454*--------------------------
028230*    COMPUTE J = I + DSWA-SCREEN-KEY-FIRST - 1.
028230     COMPUTE J = I + WDSWA-SCREEN-KEY-FIRST - 1.
008454
028230*    MOVE DSWA-SCREEN-WORK-LINE(J)
028230     MOVE WDSWA-SCREEN-WORK-LINE(J)
                                      TO RHDR-HOLD-MAP-KEY(I).
013578     MOVE RHDR-HOLD-MAP-PTR(I)  TO MIR-RH-ID-T (I).
013578     MOVE RHDR-HOLD-MAP-EDAT(I) TO MIR-RH-EFF-DT-T (I).
008454
008454 4180-MOVE-WORK-TO-SCREEN-X.
008454     EXIT.
008454*
008454
008454*------------------------
008454 4230-FORMAT-OUTPUT-MAP.
008454*------------------------
008454*
008454* MOVE FROM WORKING TO MAP
008454*
008454     PERFORM
008454         VARYING  I FROM 1 BY 1
008454         UNTIL I > +36
008454
008454         MOVE RHDR-HOLD-MAP-PTR  (I)
                                      TO MIR-RH-ID-T (I)
008454         MOVE RHDR-HOLD-MAP-EDAT (I)
                                      TO MIR-RH-EFF-DT-T (I)
008454
008454     END-PERFORM.
008454
008454     IF WGLOB-MSG-ERROR-SW > 0
008454        GO TO 4230-FORMAT-OUTPUT-MAP-X
008454     END-IF.
008454
008454 4230-FORMAT-OUTPUT-MAP-X.
008454     EXIT.
008454*
008454*--------------------------
008454 4240-INIT-RHDR-HOLD-AREA.
008454*--------------------------
008454************************************************
008454* CLEAN DIRS HOLD AREA
008454************************************************
008454
008454     MOVE SPACES                TO RHDR-FILE-START-KEY.
008454     PERFORM
008454         VARYING I FROM 1 BY 1
008454         UNTIL I > +44
008454
008454         MOVE SPACES            TO RHDR-HOLD-KEY (I)
008454
008454     END-PERFORM.
008454
008454     MOVE SPACES                TO  RHDR-KEY-DECODE.
008454
008454 4240-INIT-RHDR-HOLD-AREA-X.
008454     EXIT.
010302*
      *********************
       5000-PROCESS-CREATE.
      *********************
      *
           PERFORM  RH-1000-READ
               THRU RH-1000-READ-X.
      *
           IF WRH-IO-NOT-FOUND
               PERFORM  RH-1000-CREATE
                   THRU RH-1000-CREATE-X
               MOVE L1640-INTERNAL-DATE TO RRH-RH-EFF-DT
               PERFORM  RH-1000-WRITE
                   THRU RH-1000-WRITE-X
014221         PERFORM  RH-1000-READ-TWRK-TS
014221             THRU RH-1000-READ-TWRK-TS-X
           ELSE
               MOVE 'CS00000005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5000-PROCESS-CREATE-X.
           EXIT.
      *
      *********************
       6000-PROCESS-UPDATE.
      *********************
      *
014221*    PERFORM  RH-1000-READ-FOR-UPDATE
014221*        THRU RH-1000-READ-FOR-UPDATE-X.
      *
014221     PERFORM  RH-2000-UPDATE-TWRK-TS
014221         THRU RH-2000-UPDATE-TWRK-TS-X.
      *
           IF WRH-IO-NOT-FOUND
               MOVE 'CS01310004' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221          MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221          MOVE 'RH'             TO WGLOB-MSG-PARM (01)
014221          MOVE WRH-KEY          TO WGLOB-MSG-PARM (02)
014221          PERFORM  0260-1000-GENERATE-MESSAGE
014221              THRU 0260-1000-GENERATE-MESSAGE-X
014221          GO TO 6000-PROCESS-UPDATE-X
014221     END-IF.
      *
      *
           MOVE WRH-RH-ID             TO MIR-RH-ID.
           MOVE L1640-EXTERNAL-DATE   TO MIR-RH-EFF-DT.
      *
           MOVE MIR-RH-SMKR-CD-IND    TO RH-KEY-SMOKERS-CODE-IND.
           MOVE MIR-RH-PAR-CD-IND     TO RH-KEY-PAR-CODE-IND.
           MOVE MIR-RH-SEX-CD-IND     TO RH-KEY-SEX-IND.
           MOVE MIR-RH-STBL-1-CD-IND  TO RH-KEY-SUB-TABLE-1-IND.
           MOVE MIR-RH-STBL-2-CD-IND  TO RH-KEY-SUB-TABLE-2-IND.
           MOVE MIR-RH-STBL-3-CD-IND  TO RH-KEY-SUB-TABLE-3-IND.
           MOVE MIR-RH-STBL-4-CD-IND  TO RH-KEY-SUB-TABLE-4-IND.
010302*    MOVE MIR-CL             TO RH-KEY-CURRENT-LOCATION-IND.
010302     MOVE MIR-RH-LOC-TYP-CD     TO RH-KEY-LOC-TYP-CD.
010302     MOVE MIR-RH-LOC-DT-TYP-CD  TO RH-KEY-LOC-DT-TYP-CD.
           MOVE MIR-RH-DB-OPT-CD-IND  TO RH-KEY-DBO-IND.
557691     MOVE MIR-RH-PNSN-QUALF-IND TO RH-KEY-PQ-IND.
557767     MOVE MIR-RH-JNT-LIFE-CD-IND                 TO RH-KEY-JT-IND.
           MOVE MIR-RH-AGE-TYP-CD     TO RH-KEY-AGE-TYPE.
           MOVE MIR-RH-DUR-TYP-CD     TO RH-KEY-DURATION-TYPE.
           MOVE MIR-RH-DT-TYP-CD      TO RH-KEY-DATE-TYPE.
           MOVE MIR-RH-BAND-TYP-CD    TO RH-KEY-BANDING-TYPE.
           MOVE MIR-RH-BAND-USE-CD    TO RH-KEY-BAND-USE.
           MOVE L1640-INTERNAL-DATE   TO RH-KEY-DISPLAY-EFF-DATE.
           MOVE MIR-RH-MAX-DUR        TO RH-KEY-MAX-DUR.
           MOVE MIR-RH-SELCT-PERI-DUR TO RH-KEY-SELECT-PERIOD.
008454     MOVE MIR-RH-RT-TYP-CD      TO RH-KEY-RT-TYPE.
010314     MOVE MIR-RH-DPOS-TRM-IND   TO RH-KEY-DPOS-TRM-IND.
012525     MOVE MIR-RH-CVG-TRM-IND    TO RH-KEY-CVG-TRM-IND.
      *
           MOVE MIR-RH-BAND-1-AMT-T  (01)
                                      TO RH-KEY-BAND-AMOUNT (1).
           MOVE MIR-RTBL-1-ID-T (01)  TO RH-KEY-RATE-LOAD-PTR (1).
           MOVE MIR-RH-BAND-1-AMT-T  (02)
                                      TO RH-KEY-BAND-AMOUNT (2).
           MOVE MIR-RTBL-1-ID-T (02)  TO RH-KEY-RATE-LOAD-PTR (2).
           MOVE MIR-RH-BAND-1-AMT-T  (03)
                                      TO RH-KEY-BAND-AMOUNT (3).
           MOVE MIR-RTBL-1-ID-T (03)  TO RH-KEY-RATE-LOAD-PTR (3).
           MOVE MIR-RH-BAND-1-AMT-T  (04)
                                      TO RH-KEY-BAND-AMOUNT (4).
           MOVE MIR-RTBL-1-ID-T (04)  TO RH-KEY-RATE-LOAD-PTR (4).
           MOVE MIR-RH-BAND-1-AMT-T  (05)
                                      TO RH-KEY-BAND-AMOUNT (5).
           MOVE MIR-RTBL-1-ID-T (05)  TO RH-KEY-RATE-LOAD-PTR (5).
           MOVE MIR-RH-BAND-1-AMT-T  (06)
                                      TO RH-KEY-BAND-AMOUNT (6).
           MOVE MIR-RTBL-1-ID-T (06)  TO RH-KEY-RATE-LOAD-PTR (6).
008455     PERFORM
008455         VARYING I FROM 1 BY 1 UNTIL I > 6
008455         MOVE RH-KEY-BAND-AMOUNT (I)
008455                                TO L0280-INPUT-DATA
008455         MOVE 'N'               TO L0280-SIGN-IND
008455         MOVE 0                 TO L0280-PRECISION
008455         MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (I)
008455                                TO L0280-INPUT-SIZE
008455                                L0280-LENGTH
008455         PERFORM 0280-1000-NUMERIC-EDIT
008455            THRU 0280-1000-NUMERIC-EDIT-X
008455         IF L0280-OK
008455            MOVE L0280-OUTPUT   TO RH-KEY-BAND-AMOUNT-N (I)
020874*           MOVE L0280-OUTPUT   TO L0290-INPUT-NUMBER
020874            MOVE L0280-OUTPUT   TO L0290-INPUT-V00
008455            MOVE 0              TO L0290-PRECISION
008455            MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (I)
008455                                TO L0290-MAX-OUT-LEN
020874*           PERFORM  0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874            PERFORM  0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455            MOVE L0290-OUTPUT-DATA
008455                                TO RH-KEY-BAND-AMOUNT (I)
008455         END-IF
008455     END-PERFORM.
008455
      *
           PERFORM  6100-EDIT-SCREEN-INPUT
               THRU 6100-EDIT-SCREEN-INPUT-X.
      *
           IF WGLOB-MSG-ERROR-SW = 0
              PERFORM  6900-UPDATE-RH-REC
                  THRU 6900-UPDATE-RH-REC-X
014221        PERFORM  RH-1000-READ-TWRK-TS
014221            THRU RH-1000-READ-TWRK-TS-X
014221     ELSE
014221        PERFORM  RH-3000-UNLOCK
014221            THRU RH-3000-UNLOCK-X
557660     END-IF.
      *
       6000-PROCESS-UPDATE-X.
           EXIT.
      *
      ************************
       6100-EDIT-SCREEN-INPUT.
      ************************
      *
           IF RH-KEY-SMOKERS-CODE-IND = 'Y'
           OR RH-KEY-SMOKERS-CODE-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RH-KEY-PAR-CODE-IND = 'Y'
           OR RH-KEY-PAR-CODE-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-SEX-IND = 'Y'
           OR RH-KEY-SEX-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-SUB-TABLE-1-IND = 'Y'
           OR RH-KEY-SUB-TABLE-1-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-SUB-TABLE-2-IND = 'Y'
           OR RH-KEY-SUB-TABLE-2-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310027'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-SUB-TABLE-3-IND = 'Y'
           OR RH-KEY-SUB-TABLE-3-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-SUB-TABLE-4-IND = 'Y'
           OR RH-KEY-SUB-TABLE-4-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
010302*    IF RH-KEY-CURRENT-LOCATION-IND = 'Y'
010302*    OR RH-KEY-CURRENT-LOCATION-IND = 'N'
010302     IF RH-KEY-LOC-TYP-CD      = 'I'
010302     OR RH-KEY-LOC-TYP-CD      = 'C'
010302     OR RH-KEY-LOC-TYP-CD      = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
010302     IF RH-KEY-LOC-DT-TYP-CD   = 'P'
010302     OR RH-KEY-LOC-DT-TYP-CD   = 'I'
010302     OR RH-KEY-LOC-DT-TYP-CD   = 'A'
010302     OR RH-KEY-LOC-DT-TYP-CD   = 'E'
034802*        NEXT SENTENCE
034802         CONTINUE
010302     ELSE
010302         MOVE 'CS01310037'      TO WGLOB-MSG-REF-INFO
010302         PERFORM  0260-1000-GENERATE-MESSAGE
010302             THRU 0260-1000-GENERATE-MESSAGE-X
010302     END-IF.
010302*
557660     IF RH-KEY-DBO-IND = 'Y'
           OR RH-KEY-DBO-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557691     IF RH-KEY-PQ-IND = 'Y'
557691     OR RH-KEY-PQ-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
557691     ELSE
557691* MSG  PENSION QUALIFIER MUST BE N OR Y
557691         MOVE 'CS01310019'      TO WGLOB-MSG-REF-INFO
557691         PERFORM  0260-1000-GENERATE-MESSAGE
557691            THRU 0260-1000-GENERATE-MESSAGE-X
557691     END-IF.
557691*
557767     IF RH-KEY-JT-IND = 'Y'
557767     OR RH-KEY-JT-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
557767     ELSE
557767* MSG  JOINT AGE MUST BE N OR Y
557767         MOVE 'CS01310032'      TO WGLOB-MSG-REF-INFO
557767         PERFORM  0260-1000-GENERATE-MESSAGE
557767            THRU 0260-1000-GENERATE-MESSAGE-X
557767     END-IF.
557767*
557660     IF RH-KEY-AGE-TYPE = 'I'
           OR RH-KEY-AGE-TYPE = 'A'
           OR RH-KEY-AGE-TYPE = 'U'
           OR RH-KEY-AGE-TYPE = 'N'
557694     OR RH-KEY-AGE-TYPE = 'D'
557694     OR RH-KEY-AGE-TYPE = 'E'
557694     OR RH-KEY-AGE-TYPE = 'L'
557694     OR RH-KEY-AGE-TYPE = 'Q'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-DURATION-TYPE = 'M'
           OR RH-KEY-DURATION-TYPE = 'A'
           OR RH-KEY-DURATION-TYPE = 'N'
557694     OR RH-KEY-DURATION-TYPE = 'E'
557694     OR RH-KEY-DURATION-TYPE = 'L'
557694     OR RH-KEY-DURATION-TYPE = 'Q'
557691     OR RH-KEY-DURATION-TYPE = 'G'
012143     OR RH-KEY-DURATION-TYPE = 'B'
012143     OR RH-KEY-DURATION-TYPE = 'D'
016534     OR RH-KEY-DURATION-TYPE = 'I'
022730     OR RH-KEY-DURATION-TYPE = 'U'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-DATE-TYPE = 'E'
           OR RH-KEY-DATE-TYPE = 'I'
010314     OR RH-KEY-DATE-TYPE = 'D'
           OR RH-KEY-DATE-TYPE = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-BANDING-TYPE = 'S'
           OR RH-KEY-BANDING-TYPE = 'R'
           OR RH-KEY-BANDING-TYPE = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
557660     IF RH-KEY-BAND-USE = 'D'
           OR RH-KEY-BAND-USE = 'F'
           OR RH-KEY-BAND-USE = 'V'
           OR RH-KEY-BAND-USE = 'S'
           OR RH-KEY-BAND-USE = 'Q'
           OR RH-KEY-BAND-USE = 'N'
015951     OR RH-KEY-BAND-USE = 'P'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
      *  SELECT PERIOD MUST BE NUMERIC
      *
           IF RH-KEY-SELECT-PERIOD IS NUMERIC
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RH-KEY-MAX-DUR IS NUMERIC
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS01310009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF  RH-KEY-MAX-DUR        IS NUMERIC
               IF  RH-KEY-MAX-DUR-N  >  120
                   MOVE 'CS01310010'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
008454
008454     MOVE RH-KEY-RT-TYPE        TO WEDIT-ETBL-VALU-ID.
008454     PERFORM  RTTP-1000-EDIT
008454         THRU RTTP-1000-EDIT-X.
008454     IF WEDIT-IO-STATUS NOT = '0'
008454         MOVE 'CS01310033'      TO WGLOB-MSG-REF-INFO
008454         PERFORM  0260-1000-GENERATE-MESSAGE
008454             THRU 0260-1000-GENERATE-MESSAGE-X
008454     END-IF.
008454*
010314     IF  RH-KEY-DPOS-TRM-IND = 'Y' OR
010314         RH-KEY-DPOS-TRM-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
010314     ELSE
010314* MSG: DEPOSIT TERM MUST BE 'Y' OR 'N'  RE-ENTER.
010314         MOVE 'CS01310034'      TO WGLOB-MSG-REF-INFO
010314         PERFORM  0260-1000-GENERATE-MESSAGE
010314             THRU 0260-1000-GENERATE-MESSAGE-X
010314     END-IF.
012525     IF  RH-KEY-CVG-TRM-IND = 'Y' OR
012525         RH-KEY-CVG-TRM-IND = 'N'
012525         CONTINUE
012525     ELSE
012525* MSG: COVERAGE TERM MUST BE 'Y' OR 'N'  RE-ENTER.
012525         MOVE 'CS01310039'     TO WGLOB-MSG-REF-INFO
012525         PERFORM  0260-1000-GENERATE-MESSAGE
012525             THRU 0260-1000-GENERATE-MESSAGE-X
012525     END-IF.
      *
      ************************************************************
      * THE FOLLOWING ARE CROSS EDITS BETWEEN FIELDS
      ************************************************************
      *
      *  AGE AND DURATION REQUIRED WHEN USING SELECT PERIOD
      *
           IF RH-KEY-SELECT-PERIOD NOT = ZERO
               IF RH-KEY-DURATION-TYPE = 'N'
               OR RH-KEY-AGE-TYPE NOT = 'I'
                   MOVE 'CS01310025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
           IF RH-KEY-BANDING-TYPE = 'N'
               IF RH-KEY-BAND-USE = 'N'
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE 'CS01310016'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
557660     IF RH-KEY-BANDING-TYPE = 'R'
           OR RH-KEY-BANDING-TYPE = 'S'
               IF RH-KEY-BAND-USE = 'N'
                   MOVE 'CS01310017'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

015951* MSG: RATCHED BANDING IS NOT ALLOWED FOR BANDING USE
015951* USE PERCENTAGE DISABILITY
015951*
015951     IF  RH-KEY-BANDING-TYPE = 'R'
015951     AND RH-KEY-BAND-USE = 'P'
015951         MOVE 'CS01310038'  TO WGLOB-MSG-REF-INFO
015951         PERFORM  0260-1000-GENERATE-MESSAGE
015951             THRU 0260-1000-GENERATE-MESSAGE-X
015951     END-IF.

      ************************************************************
      * EDIT BAND AMOUNTS AND POINTERS
      ************************************************************
           MOVE ZEROS                 TO WS-BAND-AMT.
008455     MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (1)
008455                                TO WS-MIR-LEN.
           PERFORM  6120-EDIT-BANDING-VALUES
               THRU 6120-EDIT-BANDING-VALUES-X
               VARYING RH-I FROM 1 BY 1
               UNTIL RH-I > 6.
      *
       6100-EDIT-SCREEN-INPUT-X.
           EXIT.
      *
      **************************
       6120-EDIT-BANDING-VALUES.
      **************************
      *
      **************************************************************
      * TEST BAND AMOUNTS FOR BEING NUMERIC
      **************************************************************
      *
008455*    IF RH-KEY-BAND-AMOUNT (RH-I) IS NUMERIC
008455     MOVE RH-KEY-BAND-AMOUNT (RH-I)
008455                                TO L0280-INPUT-DATA.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE  0                    TO L0280-PRECISION.
008455     MOVE WS-MIR-LEN            TO L0280-INPUT-SIZE.
008455     MOVE WS-MIR-LEN            TO L0280-LENGTH.
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF L0280-OK
008455*        NEXT SENTENCE
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE WS-MIR-LEN        TO L0290-MAX-OUT-LEN
020874*           PERFORM  0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874            PERFORM  0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO RH-KEY-BAND-AMOUNT (RH-I)
008455                                   MIR-RH-BAND-1-AMT-T (RH-I)
           ELSE
               MOVE 'CS01310018'      TO WGLOB-MSG-REF-INFO
               MOVE RH-I              TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6120-EDIT-BANDING-VALUES-X
557660     END-IF.
      *
      *
      **************************************************************
      * WHEN A BAND AMOUNT = 999999999
      * THIS MUST BE THE LAST OF THE BANDS - THEREFORE ALL FOLLOWING
      * BAND DATA IS INITIALIZED TO ENSURE GARBAGE IS DELETED
      **************************************************************
           IF BANDS-EDIT-IS-COMPLETE
               PERFORM  6122-INIT-BAND-DATA
                   THRU 6122-INIT-BAND-DATA-X
               GO TO 6120-EDIT-BANDING-VALUES-X
557660     END-IF.
      *
008455*    IF  RH-KEY-BAND-AMOUNT-N (RH-I) = 999999999
008455     COMPUTE WS-AMT = RH-KEY-BAND-AMOUNT-N (RH-I) + 1
008455         ON SIZE ERROR
008455             MOVE 1             TO BANDS-EDIT-COMPLETE-SW
008455*    END-IF.
      *
      *************************************************************
      * TO ENSURE ERROR MESSAGES ARE NOT OVERWRITTEN
      *************************************************************
      *
           IF WGLOB-MSG-ERROR-SW = 0
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               GO TO 6120-EDIT-BANDING-VALUES-X
557660     END-IF.
      *
      *************************************************************
      * 1ST RATE LOAD BAND AMOUNT CANNOT = ZEROS
      *************************************************************
           IF RH-I = 1
008455         IF  RH-KEY-BAND-AMOUNT-N (RH-I) =  ZEROS
                   MOVE 'CS01310020'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 6120-EDIT-BANDING-VALUES-X
557660         END-IF
557660     END-IF.
      *
      *
      *************************************************************
      * EACH APPLICABLE BAND AMT MUST BE GREATER THAN PRIOR AMT
      *************************************************************

           IF  RH-KEY-BAND-AMOUNT-N (RH-I)     NOT  =  ZEROS
008455     AND RH-I NOT = 1
               IF  RH-KEY-BAND-AMOUNT-N (RH-I) NOT  >
008455             WS-BAND-AMT
                   MOVE 'CS01310022'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 6120-EDIT-BANDING-VALUES-X
557660         END-IF
557660     END-IF.
      *
      *
      *************************************************************
      * WHEN THE BANDING TYPE = N
      *      THERE IS ONLY 1 BAND AMOUNT
      *              AND THE BAND AMOUNT MUST = 999999999
      *************************************************************
           IF RH-KEY-BANDING-TYPE = 'N'
               IF RH-I = 1
008455             IF  RH-KEY-BAND-AMOUNT-N (1) NOT  =  WS-HIGH-AMT
008455*            IF  RH-KEY-BAND-AMOUNT-N (1) NOT  =  999999999
                       MOVE 'CS01310021'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       GO TO 6120-EDIT-BANDING-VALUES-X
034802*            ELSE
034802*                NEXT SENTENCE
557660             END-IF
               ELSE
                   IF  RH-KEY-BAND-AMOUNT-N (RH-I)  >  ZEROS
                       MOVE 'CS01310021'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       GO TO 6120-EDIT-BANDING-VALUES-X
034802*            ELSE
034802*                NEXT SENTENCE
                   END-IF
557660         END-IF
557660     END-IF.
      *
      *
      *************************************************************
      * THE LAST VALID BAND AMOUNT MUST = 999999999
      *************************************************************
           IF  RH-KEY-BAND-AMOUNT-N (RH-I) =  ZEROS
008455*        IF  WS-BAND-AMT NOT = 999999999
008455         IF  WS-BAND-AMT NOT = WS-HIGH-AMT
               AND WS-BAND-AMT NOT = 000000000
                   MOVE 'CS01310023'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 6120-EDIT-BANDING-VALUES-X
557660         END-IF
557660     END-IF.
      *
           IF RH-I = 6
008455*        IF  WS-BAND-AMT NOT = 999999999
008455         IF  WS-BAND-AMT NOT = WS-HIGH-AMT
               AND WS-BAND-AMT NOT = 000000000
008455*            IF  RH-KEY-BAND-AMOUNT-N (RH-I) NOT = 999999999
008455             IF  RH-KEY-BAND-AMOUNT-N (RH-I) NOT = WS-HIGH-AMT
                       MOVE 'CS01310023'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       GO TO 6120-EDIT-BANDING-VALUES-X
557660             END-IF
557660         END-IF
557660     END-IF.
      *
      *
      **************************************************************
      * IF THE BAND AMOUNT = ZERO
      * THEN INITIALIZE THE RATE LOAD POINTER TO ELIMINATE POSSIBLE
      * GARBAGE (NOTE - THE INITIALIZE BAND ROUTINE ALSO INITIALIZES
      * THE BAND AMOUNT, BUT IS NOT NECESSARY FOR THIS SITUATION)
      **************************************************************
008455     IF  RH-KEY-BAND-AMOUNT-N (RH-I)  =  ZEROS
               PERFORM  6122-INIT-BAND-DATA
                   THRU 6122-INIT-BAND-DATA-X
               GO TO 6120-EDIT-BANDING-VALUES-X
557660     END-IF.
      *
      *
      *************************************************************
      * RESET THE WS-BAND-AMT FIELD
      *************************************************************
008455     MOVE RH-KEY-BAND-AMOUNT-N (RH-I)
                                      TO WS-BAND-AMT.
      *
       6120-EDIT-BANDING-VALUES-X.
           EXIT.
      *
      *********************
       6122-INIT-BAND-DATA.
      *********************
      *
008455     MOVE ZEROS                 TO RH-KEY-BAND-AMOUNT   (RH-I).
           MOVE ZEROS                 TO RH-KEY-BAND-AMOUNT-N (RH-I).
           MOVE SPACES                TO RH-KEY-RATE-LOAD-PTR (RH-I).
020874*    MOVE ZEROS                 TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (01)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
      *
557660     EVALUATE RH-I
             WHEN 1
008455*        MOVE ZEROS         TO MIR-RH-BAND-1-AMT-T  (01)
008455         MOVE L0290-OUTPUT-DATA TO MIR-RH-BAND-1-AMT-T (01)
               MOVE SPACES            TO MIR-RTBL-1-ID-T (01)
             WHEN 2
008455*        MOVE ZEROS         TO MIR-RH-BAND-1-AMT-T  (02)
008455         MOVE L0290-OUTPUT-DATA TO MIR-RH-BAND-1-AMT-T (02)
               MOVE SPACES            TO MIR-RTBL-1-ID-T (02)
             WHEN 3
008455*        MOVE ZEROS         TO MIR-RH-BAND-1-AMT-T  (03)
008455         MOVE L0290-OUTPUT-DATA TO MIR-RH-BAND-1-AMT-T (03)
               MOVE SPACES            TO MIR-RTBL-1-ID-T (03)
             WHEN 4
008455*        MOVE ZEROS         TO MIR-RH-BAND-1-AMT-T  (04)
008455         MOVE L0290-OUTPUT-DATA TO MIR-RH-BAND-1-AMT-T (04)
               MOVE SPACES            TO MIR-RTBL-1-ID-T (04)
             WHEN 5
008455*        MOVE ZEROS         TO MIR-RH-BAND-1-AMT-T  (05)
008455         MOVE L0290-OUTPUT-DATA TO MIR-RH-BAND-1-AMT-T (05)
               MOVE SPACES            TO MIR-RTBL-1-ID-T (05)
             WHEN 6
008455*        MOVE ZEROS         TO MIR-RH-BAND-1-AMT-T  (06)
008455         MOVE L0290-OUTPUT-DATA TO MIR-RH-BAND-1-AMT-T (06)
               MOVE SPACES            TO MIR-RTBL-1-ID-T (06)
           END-EVALUATE.
      *
       6122-INIT-BAND-DATA-X.
           EXIT.
      *
      ********************
       6900-UPDATE-RH-REC.
      ********************
      *
           MOVE RH-KEY-SMOKERS-CODE-IND
                                      TO RRH-RH-SMKR-CD-IND.
           MOVE RH-KEY-PAR-CODE-IND   TO RRH-RH-PAR-CD-IND.
           MOVE RH-KEY-SEX-IND        TO RRH-RH-SEX-CD-IND.
           MOVE RH-KEY-SUB-TABLE-1-IND          TO RRH-RH-STBL-1-CD-IND.
           MOVE RH-KEY-SUB-TABLE-2-IND          TO RRH-RH-STBL-2-CD-IND.
           MOVE RH-KEY-SUB-TABLE-3-IND          TO RRH-RH-STBL-3-CD-IND.
           MOVE RH-KEY-SUB-TABLE-4-IND          TO RRH-RH-STBL-4-CD-IND.
010302*    MOVE RH-KEY-CURRENT-LOCATION-IND TO RRH-RH-CRNT-LOC-IND.
010302     MOVE RH-KEY-LOC-TYP-CD     TO RRH-RH-LOC-TYP-CD.
010302     MOVE RH-KEY-LOC-DT-TYP-CD  TO RRH-RH-LOC-DT-TYP-CD.
           MOVE RH-KEY-DBO-IND        TO RRH-RH-DB-OPT-CD-IND.
557691     MOVE RH-KEY-PQ-IND         TO RRH-RH-PNSN-QUALF-IND.
557767     MOVE RH-KEY-JT-IND         TO RRH-RH-JNT-LIFE-CD-IND.
           MOVE RH-KEY-AGE-TYPE       TO RRH-RH-AGE-TYP-CD.
           MOVE RH-KEY-DURATION-TYPE  TO RRH-RH-DUR-TYP-CD.
           MOVE RH-KEY-DATE-TYPE      TO RRH-RH-DT-TYP-CD.
           MOVE RH-KEY-BANDING-TYPE   TO RRH-RH-BAND-TYP-CD.
           MOVE RH-KEY-BAND-USE       TO RRH-RH-BAND-USE-CD.
           MOVE RH-KEY-DISPLAY-EFF-DATE
                                      TO RRH-RH-EFF-DT.
           MOVE RH-KEY-SELECT-PERIOD-N       TO RRH-RH-SELCT-PERI-DUR-N.
008454     MOVE RH-KEY-RT-TYPE        TO RRH-RH-RT-TYP-CD.
010314     MOVE RH-KEY-DPOS-TRM-IND   TO RRH-RH-DPOS-TRM-IND.
012525     MOVE RH-KEY-CVG-TRM-IND    TO RRH-RH-CVG-TRM-IND.
           MOVE RH-KEY-MAX-DUR-N      TO RRH-RH-MAX-DUR-N.
           PERFORM  6920-MOVE-RH-KEY-BANDS
               THRU 6920-MOVE-RH-KEY-BANDS-X
               VARYING RH-I FROM 1 BY 1
               UNTIL RH-I > 6.
      *
           PERFORM  RH-2000-REWRITE
               THRU RH-2000-REWRITE-X.
      *
       6900-UPDATE-RH-REC-X.
           EXIT.
      *
      ************************
       6920-MOVE-RH-KEY-BANDS.
      ************************
      *
008455     MOVE RH-KEY-BAND-AMOUNT-N (RH-I)
                                      TO RRH-RH-BAND-AMT (RH-I).
           MOVE RH-KEY-RATE-LOAD-PTR (RH-I)
                                      TO RRH-RTBL-ID      (RH-I).
      *
       6920-MOVE-RH-KEY-BANDS-X.
           EXIT.
      *
      *********************
       7000-PROCESS-DELETE.
      *********************
      *
014221*    PERFORM  RH-1000-READ-FOR-UPDATE
014221*        THRU RH-1000-READ-FOR-UPDATE-X.
      *
014221     PERFORM  RH-2000-UPDATE-TWRK-TS
014221         THRU RH-2000-UPDATE-TWRK-TS-X.
      *
           IF WRH-IO-NOT-FOUND
               MOVE 'CS01310004' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-DELETE-X
           END-IF.
      *
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221          MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221          MOVE 'RH'             TO WGLOB-MSG-PARM (01)
014221          MOVE WRH-KEY          TO WGLOB-MSG-PARM (02)
014221          PERFORM  0260-1000-GENERATE-MESSAGE
014221              THRU 0260-1000-GENERATE-MESSAGE-X
014221          GO TO 7000-PROCESS-DELETE-X
014221     END-IF.
      *
           PERFORM  RH-1000-DELETE
               THRU RH-1000-DELETE-X.
      *
       7000-PROCESS-DELETE-X.
           EXIT.
      *
      ****************************
       8000-MOVE-RECORD-TO-SCREEN.
      ****************************
      *
           MOVE RRH-RH-SMKR-CD-IND    TO MIR-RH-SMKR-CD-IND.
           MOVE RRH-RH-PAR-CD-IND     TO MIR-RH-PAR-CD-IND.
           MOVE RRH-RH-SEX-CD-IND     TO MIR-RH-SEX-CD-IND.
           MOVE RRH-RH-STBL-1-CD-IND  TO MIR-RH-STBL-1-CD-IND.
           MOVE RRH-RH-STBL-2-CD-IND  TO MIR-RH-STBL-2-CD-IND.
           MOVE RRH-RH-STBL-3-CD-IND  TO MIR-RH-STBL-3-CD-IND.
           MOVE RRH-RH-STBL-4-CD-IND  TO MIR-RH-STBL-4-CD-IND.
010302*    MOVE RRH-RH-CRNT-LOC-IND     TO MIR-CL.

010302     MOVE RRH-RH-LOC-TYP-CD     TO MIR-RH-LOC-TYP-CD.
010302     MOVE RRH-RH-LOC-DT-TYP-CD  TO MIR-RH-LOC-DT-TYP-CD.
           MOVE RRH-RH-DB-OPT-CD-IND  TO MIR-RH-DB-OPT-CD-IND.
557691     MOVE RRH-RH-PNSN-QUALF-IND TO MIR-RH-PNSN-QUALF-IND.
557767     MOVE RRH-RH-JNT-LIFE-CD-IND        TO MIR-RH-JNT-LIFE-CD-IND.
           MOVE RRH-RH-AGE-TYP-CD     TO MIR-RH-AGE-TYP-CD.
           MOVE RRH-RH-DUR-TYP-CD     TO MIR-RH-DUR-TYP-CD.
           MOVE RRH-RH-DT-TYP-CD      TO MIR-RH-DT-TYP-CD.
           MOVE RRH-RH-BAND-TYP-CD    TO MIR-RH-BAND-TYP-CD.
           MOVE RRH-RH-BAND-USE-CD    TO MIR-RH-BAND-USE-CD.
           MOVE RRH-RH-SELCT-PERI-DUR-N
                                      TO MIR-RH-SELCT-PERI-DUR.
           MOVE RRH-RH-MAX-DUR-N      TO MIR-RH-MAX-DUR.
008454     MOVE RRH-RH-RT-TYP-CD      TO MIR-RH-RT-TYP-CD.
010314     MOVE RRH-RH-DPOS-TRM-IND   TO MIR-RH-DPOS-TRM-IND.
           MOVE L1640-EXTERNAL-DATE   TO MIR-RH-EFF-DT.
008455*    MOVE RRH-RH-BAND-AMT  (1) TO WS-BAND-AMT.
008455*    MOVE WS-BAND-AMT          TO MIR-RH-BAND-1-AMT-T  (01).
020874*    MOVE RRH-RH-BAND-AMT  (1)  TO L0290-INPUT-NUMBER.
020874     MOVE RRH-RH-BAND-AMT  (1)  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (01)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-RH-BAND-1-AMT-T  (01).
           MOVE RRH-RTBL-ID      (1)  TO MIR-RTBL-1-ID-T (01).

008455*    MOVE RRH-RH-BAND-AMT  (2) TO WS-BAND-AMT.
008455*    MOVE WS-BAND-AMT          TO MIR-RH-BAND-1-AMT-T  (02).
020874*    MOVE RRH-RH-BAND-AMT  (2)  TO L0290-INPUT-NUMBER.
020874     MOVE RRH-RH-BAND-AMT  (2)  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (02)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-RH-BAND-1-AMT-T  (02).
           MOVE RRH-RTBL-ID      (2)  TO MIR-RTBL-1-ID-T (02).

008455*    MOVE RRH-RH-BAND-AMT  (3) TO WS-BAND-AMT.
008455*    MOVE WS-BAND-AMT          TO MIR-RH-BAND-1-AMT-T  (03).
020874*    MOVE RRH-RH-BAND-AMT  (3)  TO L0290-INPUT-NUMBER.
020874     MOVE RRH-RH-BAND-AMT  (3)  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (03)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-RH-BAND-1-AMT-T  (03).
           MOVE RRH-RTBL-ID      (3)  TO MIR-RTBL-1-ID-T (03).

008455*    MOVE RRH-RH-BAND-AMT  (4) TO WS-BAND-AMT.
008455*    MOVE WS-BAND-AMT          TO MIR-RH-BAND-1-AMT-T  (04).
020874*    MOVE RRH-RH-BAND-AMT  (4)  TO L0290-INPUT-NUMBER.
020874     MOVE RRH-RH-BAND-AMT  (4)  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (04)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-RH-BAND-1-AMT-T  (04).
           MOVE RRH-RTBL-ID      (4)  TO MIR-RTBL-1-ID-T (04).

008455*    MOVE RRH-RH-BAND-AMT  (5) TO WS-BAND-AMT.
008455*    MOVE WS-BAND-AMT          TO MIR-RH-BAND-1-AMT-T  (05).
020874*    MOVE RRH-RH-BAND-AMT  (5)  TO L0290-INPUT-NUMBER.
020874     MOVE RRH-RH-BAND-AMT  (5)  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (05)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-RH-BAND-1-AMT-T  (05).
           MOVE RRH-RTBL-ID      (5)  TO MIR-RTBL-1-ID-T (05).

008455*    MOVE RRH-RH-BAND-AMT  (6) TO WS-BAND-AMT.
008455*    MOVE WS-BAND-AMT          TO MIR-RH-BAND-1-AMT-T  (06).
020874*    MOVE RRH-RH-BAND-AMT  (6)  TO L0290-INPUT-NUMBER.
020874     MOVE RRH-RH-BAND-AMT  (6)  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-RH-BAND-1-AMT-T (05)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-RH-BAND-1-AMT-T  (06).
           MOVE RRH-RTBL-ID      (6)  TO MIR-RTBL-1-ID-T (06).
012525     MOVE RRH-RH-CVG-TRM-IND    TO MIR-RH-CVG-TRM-IND.

      *
       8000-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE SW.
025970     INITIALIZE WS.
025970     INITIALIZE CNTS.
025970     INITIALIZE MISC-WS.
025970
025970     SET WS-TRANSACTION-RHDR           TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT           TO TRUE.
025970     SET WS-NUM-ERR-LN-DEFAULT         TO TRUE.
025970     SET WS-ERROR-LN-SCRN-DEFAULT      TO TRUE.
025970     SET WS-MAX-PARM-LENGTH-DEFAULT    TO TRUE.
025970     SET WS-END-OF-FILE-DEFAULT        TO TRUE.
025970     SET BANDS-EDIT-NOT-COMPLETE       TO TRUE.
025970
025970     MOVE ZERO                         TO I.
025970     MOVE ZERO                         TO J.
025970
025970     MOVE SPACES                       TO WS-FILE-START-KEY-ALL.
025970     MOVE SPACES                       TO WS-KEY-ALL-HOLD. 
025970     MOVE SPACES                       TO WS-START.
025970
025970     MOVE SPACES                       TO RH-KEY-IO-DATA.
025970     INITIALIZE RH-KEY-IO-DATA.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970     MOVE MIR-RH-ID                    TO WRH-RH-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
025970
      *
008455*
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
025970 COPY XCPS0280.
008455 COPY XCPL0280.
008455*
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
025970 COPY XCPS1660.
       COPY XCPL1660.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
014660*COPY XCPPMEXT.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY RH
014221                         '$VAR2' BY 'RH'.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS ROUTINES                                    *
      *****************************************************************
      *
       COPY CCPURH.
      *
       COPY CCPBRH.
      *
       COPY CCPARH.
      *
       COPY CCPXRH.
      *
       COPY CCPCRH.
      *
008454 COPY CCPNRH.
      *
008454 COPY CCPNEDIT.
008454 COPY CCPERTTP.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0131                     **
      *****************************************************************
