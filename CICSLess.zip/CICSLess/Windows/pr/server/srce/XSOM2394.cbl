      *------------------------
       IDENTIFICATION DIVISION.
      *------------------------

       PROGRAM-ID. XSOM2394.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM2394                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE DBRL TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025244**  6.6       ADD INFORMATIONAL MESSAGE                        **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *---------------------
       ENVIRONMENT DIVISION.
      *---------------------

      *--------------
       DATA DIVISION.
      *--------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM2394'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '2394'.
           05  WS-SUB                                PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY.
           
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES                     PIC S9(4) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT         VALUE +20.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY XCFWDBRL.
       COPY XCFRDBRL.
      /
       COPY XCFRXTAB.
       COPY XCFWXTAB.
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM2394.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*           PERFORM  9300-SETUP-MSIN-REFERENCE
025970*               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2394'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  DBRL-1000-TBL-BROWSE
               THRU DBRL-1000-TBL-BROWSE-X.

           PERFORM  DBRL-2000-TBL-READ-NEXT
               THRU DBRL-2000-TBL-READ-NEXT-X.

           IF  WDBRL-IO-EOF
               PERFORM  DBRL-3000-TBL-END-BROWSE
                   THRU DBRL-3000-TBL-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2010-BROWSE-DBRL
               THRU 2010-BROWSE-DBRL-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WDBRL-IO-EOF.

           IF  WDBRL-IO-EOF
025244         MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
025244         PERFORM  0260-1000-GENERATE-MESSAGE
025244             THRU 0260-1000-GENERATE-MESSAGE-X
025244*        CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE
025244         MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
025244* TO VIEW MORE DATA - SELECT MORE
025244         PERFORM  0260-1000-GENERATE-MESSAGE
025244             THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE RDBRL-DBSRL-ID         
                                 TO MIR-DBSRL-ID
           END-IF.

           PERFORM  DBRL-3000-TBL-END-BROWSE
               THRU DBRL-3000-TBL-END-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
       2010-BROWSE-DBRL.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  DBRL-2000-TBL-READ-NEXT
               THRU DBRL-2000-TBL-READ-NEXT-X.

       2010-BROWSE-DBRL-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES       TO WDBRL-KEY.
           MOVE MIR-DBSRL-ID     TO WDBRL-DBSRL-ID.

           MOVE HIGH-VALUES      TO WDBRL-ENDBR-KEY.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES         TO MIR-DBSRL-ID-G.
           MOVE SPACES         TO MIR-DBSRL-CHILD-TBL-ID-G.
           MOVE SPACES         TO MIR-DBSRL-PARNT-TBL-ID-G.
           MOVE SPACES         TO MIR-DBSRL-PGM-ID-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RDBRL-DBSRL-ID         
                              TO MIR-DBSRL-ID-T (WS-SUB).
           MOVE RDBRL-DBSRL-CHILD-TBL-ID 
                              TO MIR-DBSRL-CHILD-TBL-ID-T (WS-SUB).
           MOVE RDBRL-DBSRL-PARNT-TBL-ID
                              TO MIR-DBSRL-PARNT-TBL-ID-T (WS-SUB).
           MOVE RDBRL-DBSRL-PGM-ID         
                              TO MIR-DBSRL-PGM-ID-T (WS-SUB).
       
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  9300-SETUP-MSIN-REFERENCE
025970         THRU 9300-SETUP-MSIN-REFERENCE-X.

           INITIALIZE          WS-WORKING-STORAGE.
025970*           MOVE 20          TO WS-MAX-LIST-LINES.

025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET  WS-MAX-LIST-LINES-DEFAULT  TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY XCPEDBRI.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
       COPY XCPTDBRL.
       COPY XCPNXTAB.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM XSOM2394                     **
      *****************************************************************
