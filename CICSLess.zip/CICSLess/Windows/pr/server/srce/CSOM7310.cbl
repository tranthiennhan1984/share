      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM7310.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7310                                         **
      **  REMARKS:  DEATH BENEFIT GUARANTEE LOCK IN PROCESS          **
      **            THIS MODULE PERFORMS THE LOCK IN FUNCTION FOR THE**
      **            POLICY DEATH BENEFIT GUARANTEE VALUE             **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7310'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID                 PIC X(04).
                   88 WS-BUS-FCN-LOCK-IN        VALUE '7310'.
               10  WS-EFF-DT                     PIC X(10).
               10  WS-POLICY-LOCK-IND            PIC X.
                   88 WS-POLICY-LOCKED           VALUE 'Y'.
                   88 WS-POLICY-NOT-LOCKED       VALUE 'N'.
               10  WS-POLICY-UPDATE-IND          PIC X.
                   88 WS-POLICY-UPDATE-REQUIRED     VALUE 'Y'.
                   88 WS-POLICY-UPDATE-NOT-REQUIRED VALUE 'N'.


      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
       COPY XCWWWKDT.
       COPY CCWWINDX.
       COPY CCWWLOCK.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
      *
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFHPOL.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCWWCVGS.
       COPY CCFRPOLP.
       COPY CCFWPOLS.
      *
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************

020478 COPY CCWL2626.
       COPY CCWLPGA.
       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
       COPY CCWL0201.
       COPY CCWL0289.
       COPY CCWL0620.
       COPY CCWL2430.
       COPY CCWL4780.
       COPY CCWL7301.
       COPY CCWL7306.
       COPY FCWL8170.
       COPY FCWLFUND.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7310.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.


      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID                    TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LOCK-IN
                    PERFORM  3000-DBG-LOCKIN
                        THRU 3000-DBG-LOCKIN-X

               WHEN OTHER
      *MSG: INVALID FUNCTION ID - PROCESSING STOPPED
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7310'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.


      *---------------
       3000-DBG-LOCKIN.
      *---------------

           PERFORM  8100-BLANK-DATA-FIELDS
               THRU 8100-BLANK-DATA-FIELDS-X.

           IF  MIR-DV-EFF-DT = SPACE
      *MSG LOCKIN EFFECTIVE DATE IS BLANK
               MOVE 'CS73100008'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3000-DBG-LOCKIN-X
           END-IF.

           MOVE MIR-DV-EFF-DT          TO L1640-EXTERNAL-DATE.
           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE    TO WS-EFF-DT.

           MOVE MIR-POL-ID           TO WPOL-POL-ID.


           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '2'
                    PERFORM  3100-EDIT-DBG-LOCKIN
                        THRU 3100-EDIT-DBG-LOCKIN-X


               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM  3200-PROCESS-DBG-LOCKIN
                        THRU 3200-PROCESS-DBG-LOCKIN-X


               WHEN OTHER
                    SET MIR-RETRN-RQST-FAILED  TO TRUE

           END-EVALUATE.


           IF  WS-POLICY-LOCKED
               SET WS-POLICY-NOT-LOCKED         TO TRUE

               IF  WS-POLICY-UPDATE-REQUIRED
                   PERFORM  0289-1000-INIT-PARM-INFO
                       THRU 0289-1000-INIT-PARM-INFO-X
                   MOVE WS-EFF-DT    TO L0289-LO-PAC-DT
                   MOVE WS-EFF-DT    TO L0289-LO-CRC-DT
                   MOVE WS-EFF-DT    TO L0289-LO-DD2-DT
                   MOVE WS-EFF-DT    TO L0289-PROC-EFF-DT
                   PERFORM  0289-1000-OBTAIN-NXT-ACTV
                       THRU 0289-1000-OBTAIN-NXT-ACTV-X
                   IF  L0289-RETRN-OK
                       MOVE L0289-NXT-ACTV-TYP-CD
                            TO RPOL-NXT-ACTV-TYP-CD
                       MOVE L0289-NXT-ACTV-DT
                            TO RPOL-POL-NXT-ACTV-DT
                   ELSE
                       MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
                       MOVE WGLOB-PROCESS-DATE
                                 TO RPOL-POL-NXT-ACTV-DT
                   END-IF
                   MOVE WGLOB-PROCESS-DATE
                                      TO RPOL-PREV-FILE-MAINT-DT
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
                   PERFORM  POL-1000-READ-TWRK-TS
                       THRU POL-1000-READ-TWRK-TS-X
               ELSE
                   PERFORM  POL-3000-UNLOCK
                       THRU POL-3000-UNLOCK-X
               END-IF
           END-IF.


       3000-DBG-LOCKIN-X.
           EXIT.


      *---------------------
       3100-EDIT-DBG-LOCKIN.
      *---------------------

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WPOL-POL-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'POL'            TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3100-EDIT-DBG-LOCKIN-X
           END-IF.

           PERFORM  3150-POLICY-EDIT
               THRU 3150-POLICY-EDIT-X.

           IF MIR-RETRN-RQST-FAILED
              GO TO 3100-EDIT-DBG-LOCKIN-X
           END-IF.


           PERFORM  7301-1000-BUILD-PARM-INFO
               THRU 7301-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT            TO L7301-EFF-DT.

           PERFORM  7301-3000-EDIT-DBG-LOCKIN
               THRU 7301-3000-EDIT-DBG-LOCKIN-X.

           IF  L7301-RETRN-ERROR
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3100-EDIT-DBG-LOCKIN-X
           END-IF.


           IF  L7301-DBG-ACUM-VALU-APROX
      *MSG: FUND UNIT PRICE NOT AVAILABLE, LOCK-IN WILL BE DEFERRED
               MOVE 'CS73100001'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  8200-MOVE-OUTPUT-FIELDS
               THRU 8200-MOVE-OUTPUT-FIELDS-X.

       3100-EDIT-DBG-LOCKIN-X.
           EXIT.


      *----------------
       3150-POLICY-EDIT.
      *----------------

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  7306-1000-BUILD-PARM-INFO
               THRU 7306-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID       TO L7306-POL-ID.

           PERFORM  7306-1000-GET-DBG-INFO
               THRU 7306-1000-GET-DBG-INFO-X.

           PERFORM  5100-GET-CLI-NM
               THRU 5100-GET-CLI-NM-X.

           IF  NOT RPOL-POL-STAT-IN-FORCE
      *MSG: POLICY MUST BE IN-FORCE TO PROCESS A LOCK-IN
               MOVE 'CS73100002'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3150-POLICY-EDIT-X
           END-IF.

           IF  L7306-POL-DBG-RESET-NONE
      *MSG: POLICY DOESNOT HAVE LOCK-IN OPTION
               MOVE 'CS73100003'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3150-POLICY-EDIT-X
           END-IF.


           IF L7306-POL-DBG-LOCK-QTY = ZERO
      *MSG: MAXIMUM LOCK-IN PER YEAR HAS BEEN REACHED
               MOVE 'CS73100005'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                  SET MIR-RETRN-RQST-FAILED  TO TRUE
                  GO TO 3150-POLICY-EDIT-X
               END-IF
           END-IF.


           PERFORM  3160-CHK-DEFER-LOCK-IN
               THRU 3160-CHK-DEFER-LOCK-IN-X.
           IF MIR-RETRN-RQST-FAILED
              GO TO 3150-POLICY-EDIT-X
           END-IF.


           IF  (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT  AND
                RPOL-POL-NXT-ACTV-DT NOT < WGLOB-PROCESS-DATE)
           OR  RPOL-POL-NXT-ACTV-DT = SPACE
                 CONTINUE
           ELSE
      *MSG: ACTIVITY DUE, AUTO REDO TO CURRENT PROCESS DATE WHEN PROCESS
      *     IS CONFIRMED
               MOVE 'CS73100004'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3150-POLICY-EDIT-X.
           EXIT.


      *----------------------
       3160-CHK-DEFER-LOCK-IN.
      *----------------------

           MOVE RPOL-POL-ID             TO WPOLS-POL-ID.
           SET  RPOLP-POL-PAYO-STAT-ACTV-DEFR  TO TRUE.
           MOVE RPOLP-POL-PAYO-STAT-CD  TO WPOLS-POL-PAYO-STAT-CD.
           MOVE WS-EFF-DT               TO WPOLS-POL-PAYO-NXT-DT.
           MOVE ZERO                    TO WPOLS-POL-PAYO-NUM.
           MOVE WPOLS-KEY               TO WPOLS-ENDBR-KEY.
           MOVE 99999                   TO WPOLS-ENDBR-POL-PAYO-NUM.

           PERFORM  POLS-1000-BROWSE
               THRU POLS-1000-BROWSE-X.

           PERFORM  3165-READ-DEFER-REC
               THRU 3165-READ-DEFER-REC-X
               UNTIL WPOLS-IO-EOF
               OR    MIR-RETRN-RQST-FAILED.

           PERFORM  POLS-3000-END-BROWSE
               THRU POLS-3000-END-BROWSE-X.

       3160-CHK-DEFER-LOCK-IN-X.
           EXIT.

      *-------------------
       3165-READ-DEFER-REC.
      *-------------------

           PERFORM  POLS-2000-READ-NEXT
               THRU POLS-2000-READ-NEXT-X.

           IF WPOLS-IO-EOF
              GO TO 3165-READ-DEFER-REC-X
           END-IF.

           IF NOT RPOLP-POL-PAYO-TYP-LOCK
              GO TO 3165-READ-DEFER-REC-X
           END-IF.

      *MSG: A DEFERRED LOCK-IN AT CURRENT DATE EXISTS, NO MORE LOCK-IN
      *     ALLOWED TO-DAY
           MOVE 'CS73100010'     TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           SET MIR-RETRN-RQST-FAILED  TO TRUE.

       3165-READ-DEFER-REC-X.
           EXIT.

      *-----------------------
       3200-PROCESS-DBG-LOCKIN.
      *-----------------------


           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
               MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3200-PROCESS-DBG-LOCKIN-X
           END-IF.

           IF  WPOL-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WPOL-POL-ID          TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3200-PROCESS-DBG-LOCKIN-X
           END-IF.

           SET  WS-POLICY-LOCKED         TO TRUE.

           PERFORM  3150-POLICY-EDIT
               THRU 3150-POLICY-EDIT-X.

           IF MIR-RETRN-RQST-FAILED
              GO TO 3200-PROCESS-DBG-LOCKIN-X
           END-IF.


           IF  (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT  AND
                RPOL-POL-NXT-ACTV-DT NOT < WGLOB-PROCESS-DATE)
           OR  RPOL-POL-NXT-ACTV-DT = SPACE
                 CONTINUE
           ELSE
              PERFORM  5200-INVOKE-REDO
                  THRU 5200-INVOKE-REDO-X
           END-IF.

           IF MIR-RETRN-RQST-FAILED
              GO TO 3200-PROCESS-DBG-LOCKIN-X
           END-IF.


           PERFORM  7301-1000-BUILD-PARM-INFO
               THRU 7301-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT            TO L7301-EFF-DT.

           PERFORM  7301-4000-PROCESS-DBG-LOCKIN
               THRU 7301-4000-PROCESS-DBG-LOCKIN-X.

           IF  L7301-RETRN-ERROR
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3200-PROCESS-DBG-LOCKIN-X
           END-IF.

           IF  L7301-DBG-ACUM-VALU-APROX
               PERFORM  3250-DEFER-DBG-LOCKIN
                   THRU 3250-DEFER-DBG-LOCKIN-X
               SET  WS-POLICY-UPDATE-REQUIRED  TO TRUE
               GO TO 3200-PROCESS-DBG-LOCKIN-X
           END-IF.

           IF  L7301-DBG-LOCKIN-REJECTED
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3200-PROCESS-DBG-LOCKIN-X
           END-IF.


           SET  WS-POLICY-UPDATE-REQUIRED    TO TRUE.

      *MSG: LOCK IN PROCESSED SUCESSFULLY
           MOVE 'CS73100006'     TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.



           SET L0290-REPORT-FORMAT       TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           MOVE L7301-CURR-ACUM-AMT      TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-ACUM-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.

      *MSG: NEW RESET VALUE @1
           MOVE 'CS73100009'       TO WGLOB-MSG-REF-INFO.
           MOVE L0290-OUTPUT-DATA  TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


           PERFORM  8200-MOVE-OUTPUT-FIELDS
               THRU 8200-MOVE-OUTPUT-FIELDS-X.


       3200-PROCESS-DBG-LOCKIN-X.
           EXIT.


      *---------------------
       3250-DEFER-DBG-LOCKIN.
      *---------------------

           PERFORM  8170-1000-BUILD-PARM-INFO
               THRU 8170-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                TO L8170-EFF-DT.
           SET LFUND-ACTV-DBG-LOCKIN     TO TRUE

           INITIALIZE LFUND-FND-INFO (1).
           MOVE +1                       TO LFUND-FND-CTR.
           MOVE -100.00                  TO LFUND-ALLOC-PCT (1).
           SET LFUND-ALLOC-PERCENT (1)  TO TRUE.

           PERFORM  8170-2000-DEFER-TRANSACTION
               THRU 8170-2000-DEFER-TRANSACTION-X.

           IF NOT L8170-RETRN-OK
              SET MIR-RETRN-RQST-FAILED  TO TRUE
           ELSE
      *MSG: LOCK-IN HAS BEEN DEFERRED
              MOVE 'CS73100007'     TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  8200-MOVE-OUTPUT-FIELDS
               THRU 8200-MOVE-OUTPUT-FIELDS-X.

       3250-DEFER-DBG-LOCKIN-X.
           EXIT.


      *----------------
       5100-GET-CLI-NM.
      *----------------

           MOVE ZERO                      TO I.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           INITIALIZE L0620-INPUT-PARM-INFO.

           IF  L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
           END-IF.

           MOVE L2430-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME          TO MIR-DV-OWN-CLI-NM.

       5100-GET-CLI-NM-X.
           EXIT.


      *-----------------
       5200-INVOKE-REDO.
      *-----------------

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           SET L4780-REDO-WARNING             TO TRUE.
           SET L4780-MSG-SUPPRESS             TO TRUE.
           MOVE WS-EFF-DT                     TO L4780-EFF-DT.
           MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE          TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           EVALUATE  TRUE
               WHEN L4780-RETRN-ERROR
               WHEN L4780-RETRN-INVALID-REQUEST
                    SET MIR-RETRN-RQST-FAILED  TO TRUE

               WHEN (L4780-RETRN-OK
                    AND L4780-ACTIVITY-DUE
                    AND L4780-REDO-ALLOW)
                   PERFORM  POL-3000-UNLOCK
                       THRU POL-3000-UNLOCK-X
                   SET WS-POLICY-NOT-LOCKED TO TRUE
                   MOVE WS-EFF-DT           TO L0201-EFF-DT
                   SET L0201-AUTO-REDO      TO TRUE
                   PERFORM  0201-1000-AUTO-PROCESSING
                       THRU 0201-1000-AUTO-PROCESSING-X
                   PERFORM  0289-1000-INIT-PARM-INFO
                       THRU 0289-1000-INIT-PARM-INFO-X
                   MOVE WS-EFF-DT  TO L0289-LO-PAC-DT
                   MOVE WS-EFF-DT  TO L0289-LO-CRC-DT
                   MOVE WS-EFF-DT  TO L0289-LO-DD2-DT
                   MOVE WS-EFF-DT  TO L0289-PROC-EFF-DT
                   PERFORM  0289-1000-OBTAIN-NXT-ACTV
                       THRU 0289-1000-OBTAIN-NXT-ACTV-X
                   IF  L0289-RETRN-OK
                       MOVE L0289-NXT-ACTV-TYP-CD
                            TO RPOL-NXT-ACTV-TYP-CD
                       MOVE L0289-NXT-ACTV-DT
                            TO RPOL-POL-NXT-ACTV-DT
                   ELSE
                       MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
                       MOVE WGLOB-PROCESS-DATE
                                 TO RPOL-POL-NXT-ACTV-DT
                   END-IF
                   MOVE RPOL-REC-INFO             TO HPOL-REC-INFO
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
                   SET WS-POLICY-LOCKED           TO TRUE
                   MOVE HPOL-REC-INFO             TO RPOL-REC-INFO
                   MOVE WGLOB-PROCESS-DATE TO RPOL-PREV-FILE-MAINT-DT
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
                   SET WS-POLICY-NOT-LOCKED       TO TRUE
                   IF  L0201-RETRN-OK
                       PERFORM  POL-1000-READ-FOR-UPDATE
                           THRU POL-1000-READ-FOR-UPDATE-X
                       SET WS-POLICY-LOCKED  TO TRUE
                       MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
      *MSG: 'AUTO REDO PROCESSING COMPLETED
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       SET MIR-RETRN-RQST-FAILED  TO TRUE
                       IF  NOT L0201-INCOMPLETE-DUE-ACTV
                           MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
      *MSG: PROBLEM IN AUTO REDO PROCESSING
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
                       END-IF
                   END-IF
           END-EVALUATE.

       5200-INVOKE-REDO-X.
           EXIT.

      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.


      *-----------------------
       8200-MOVE-OUTPUT-FIELDS.
      *-----------------------

           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE L7301-LOCK-IN-AMT        TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DBGA-RESET-AMT TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DBGA-RESET-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE L7301-LOCK-IN-ADJ-AMT    TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-DBGA-RESET-ADJ-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-DBGA-RESET-ADJ-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE L7301-CURR-LOCK-IN-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-DBGA-CRNT-RESET-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-DBGA-CRNT-RESET-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE L7301-CURR-ACUM-AMT      TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DBGA-ACUM-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DBGA-ACUM-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE L7301-ALLOW-LOCK-QTY     TO L0290-INPUT-V00.
           MOVE ZERO                     TO L0290-PRECISION
           MOVE LENGTH OF MIR-POL-DBG-LOCK-QTY TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-POL-DBG-LOCK-QTY.


           MOVE L7301-LOCK-IN-DT            TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE         TO MIR-DBGA-RESET-DT.


       8200-MOVE-OUTPUT-FIELDS-X.
           EXIT.



      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *-------------------------
       9990-INIT-WORKING-STORAGE.
      *-------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7301-0000-INIT-PARM-INFO
025970         THRU 7301-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7306-0000-INIT-PARM-INFO
025970         THRU 7306-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8170-0000-INIT-PARM-INFO
025970         THRU 8170-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
           INITIALIZE WS-WORK-FIELDS.
025970     MOVE SPACES                         TO WWKDT-WORK-FIELDS.
           SET  WS-POLICY-NOT-LOCKED           TO TRUE.
           SET  WS-POLICY-UPDATE-NOT-REQUIRED  TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
       COPY NCPPCVGS.
      *
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      *
      *****************************************************************
      *  LINKAGE COPYBOOKS
      ************************************S*****************************

025970 COPY XCPS8090.
       COPY CCPSPGA.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
       COPY XCPL0260.
      *
       COPY XCPS0290.
       COPY XCPL0290.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
       COPY XCPL8090.
      *
025970 COPY CCPS0201.
       COPY CCPL0201.
      *
       COPY CCPS0289.
       COPY CCPL0289.
      *
025970 COPY CCPS0620.
       COPY CCPL0620.
      *
       COPY CCPS2430.
       COPY CCPL2430.
      *
       COPY CCPS4780.
       COPY CCPL4780.
      *
       COPY CCPS7301.
       COPY CCPL7301.
      *
       COPY CCPS7306.
       COPY CCPL7306.
      *
       COPY FCPS8170.
       COPY FCPL8170.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNCVG.
       COPY CCPBPOLS.

      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM7310                     **
      *****************************************************************
