      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2560.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2560                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE IPRD AND IPDF TABLES                     **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2560'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
025970*    05  WS-CONSTANTS.
025970*        10  WS-TWRK-KEY               PIC X(04)
025970*                                      VALUE '2560'.
025970*        10  WS-MAX                    PIC S9(03) COMP-3
025970*                                      VALUE 139.

           05  WS-VARIABLES.
               10  WS-BUS-FCN-ID             PIC X(04).
                   88  WS-BUS-FCN-RETRIEVE   VALUE '2560'.
               10  WS-COUNT                  PIC S9(03) COMP-3.
               10  WS-CODE.
                   15  WS-F-P-CD             PIC X(01).
                       88  WS-CODE-NONE      VALUE SPACE.
                       88  WS-CODE-PLAN      VALUE 'P'.
                       88  WS-CODE-FND       VALUE 'F'.
                   15  WS-FND-PLAN-ID        PIC X(06).
               10  WS-PRFL-PCT-IND           PIC X(01).
                   88  WS-PRFL-PCT-YES       VALUE 'Y'.
                   88  WS-PRFL-PCT-NO        VALUE 'N'.
               10  WS-TOT-INITIAL            PIC S9(03)V9(04) COMP-3.
               10  WS-TOT-SUBSEQ             PIC S9(03)V9(04) COMP-3.
               10  WS-PRFLD-EFF-DT           PIC X(10).
               10  WS-PRFLD-SEQ-NUM          PIC 9(03).

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '2560'.
025970     05  WS-MAX                        PIC S9(03) COMP-3.
025970         88  WS-MAX-DEFAULT            VALUE 139.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWIPDF.
       COPY CCFRIPDF.
      /
       COPY CCFWIPRD.
       COPY CCFRIPRD.
      /
       COPY CCFWIPRO.
       COPY CCFRIPRO.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2560.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*                             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2560'   TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000' TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-RETRIEVE.
      *--------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7200-VALIDATE-KEY
               THRU 7200-VALIDATE-KEY-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-RETRIEVE-X
           END-IF.
      *
      *  MOVE THE DETAIL DATA FROM THE PROFILE TABLE
      *
           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

           PERFORM  7400-GET-DETAIL-FUNDS
               THRU 7400-GET-DETAIL-FUNDS-X.

           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.
           PERFORM  IPRO-1000-READ-TWRK-TS
               THRU IPRO-1000-READ-TWRK-TS-X.

       2000-RETRIEVE-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WIPRD-KEY.
           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *------------------
       7200-VALIDATE-KEY.
      *------------------
           MOVE SPACES                 TO WS-PRFLD-EFF-DT.
           MOVE ZERO                   TO WS-PRFLD-SEQ-NUM.
           
           MOVE MIR-PRFLD-EFF-DT       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                       TO WIPRD-PRFLD-EFF-DT
                                          WS-PRFLD-EFF-DT                                       
           ELSE
      *MSG: EFFECTIVE DATE IS INVALID
               MOVE 'CS25600001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 7200-VALIDATE-KEY-X
           END-IF.

           MOVE MIR-PRFLD-SEQ-NUM      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-INPUT-SIZE.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           SET L0280-SPACES-PERMITTED  TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT       TO WIPRD-PRFLD-SEQ-NUM
                                          WS-PRFLD-SEQ-NUM               
           ELSE
      *MSG: SEQUENCE NUMBER MUST BE VALID NUMERIC
               MOVE 'CS25600002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 7200-VALIDATE-KEY-X
           END-IF.

           PERFORM  IPRD-1000-READ
               THRU IPRD-1000-READ-X.

           IF  WIPRD-IO-NOT-FOUND
      *MSG: INVESTOR PROFILE DETAIL RECORD (@1) DOES NOT EXIST
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'CS25600003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  WGLOB-RETURN-ERROR
               GO TO 7200-VALIDATE-KEY-X
           END-IF.

           MOVE LOW-VALUE              TO WIPDF-KEY.
           MOVE MIR-PRFL-ID            TO WIPDF-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPDF-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPDF-PRFLD-SEQ-NUM.
           MOVE ZERO                   TO WIPDF-PRFLDF-SEQ-NUM.

           MOVE WIPDF-KEY              TO WIPDF-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT          TO WIPDF-ENDBR-PRFLD-EFF-DT.
           MOVE 999                    TO WIPDF-ENDBR-PRFLD-SEQ-NUM.
           MOVE 999                    TO WIPDF-ENDBR-PRFLDF-SEQ-NUM.

           PERFORM  IPDF-1000-BROWSE
               THRU IPDF-1000-BROWSE-X.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

           IF  NOT WIPDF-IO-OK
           AND WIPDF-PRFLDF-SEQ-NUM = ZERO
      *MSG: INVESTOR PROFILE DETAIL FUND RECORD (@1) DOES NOT EXIST
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'CS25600004'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  IPDF-3000-END-BROWSE
               THRU IPDF-3000-END-BROWSE-X.

           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.
           PERFORM  IPRO-1000-READ
               THRU IPRO-1000-READ-X.

           IF  NOT WIPRO-IO-OK
      *MSG: INVESTOR PROFILE RECORD (@1) DOES NOT EXIST
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'CS25600005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       7200-VALIDATE-KEY-X.
           EXIT.
      /
      *----------------------
       7400-GET-DETAIL-FUNDS.
      *----------------------

           MOVE ZERO                   TO WS-TOT-INITIAL.
           MOVE ZERO                   TO WS-TOT-SUBSEQ.

           MOVE LOW-VALUE              TO WIPDF-KEY.
           MOVE MIR-PRFL-ID            TO WIPDF-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPDF-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPDF-PRFLD-SEQ-NUM.
           MOVE ZERO                   TO WIPDF-PRFLDF-SEQ-NUM.

           MOVE WIPDF-KEY              TO WIPDF-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT          TO WIPDF-ENDBR-PRFLD-EFF-DT.
           MOVE 999                    TO WIPDF-ENDBR-PRFLD-SEQ-NUM.
           MOVE 999                    TO WIPDF-ENDBR-PRFLDF-SEQ-NUM.

           PERFORM  IPDF-1000-BROWSE
               THRU IPDF-1000-BROWSE-X.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

      * DURING CREATE THE DETAIL FUND SHOULD BE AN EMPTY TABLE
       
           IF WIPDF-IO-OK
              IF WIPDF-PRFLD-SEQ-NUM NOT = WS-PRFLD-SEQ-NUM
                 PERFORM  IPDF-3000-END-BROWSE
                     THRU IPDF-3000-END-BROWSE-X
                 GO TO 7400-GET-DETAIL-FUNDS-X    
              END-IF
           END-IF.
           
           PERFORM
               VARYING WS-COUNT FROM 1 BY 1
               UNTIL NOT WIPDF-IO-OK
               OR    WS-COUNT > WS-MAX
               OR    WIPDF-PRFL-ID NOT = MIR-PRFL-ID
               OR    WIPDF-PRFLD-EFF-DT NOT = WS-PRFLD-EFF-DT
               OR    WIPDF-PRFLD-SEQ-NUM NOT = WS-PRFLD-SEQ-NUM

               PERFORM  9250-MOVE-RECORD-TO-MIR-2
                   THRU 9250-MOVE-RECORD-TO-MIR-2-X

               PERFORM  IPDF-2000-READ-NEXT
                   THRU IPDF-2000-READ-NEXT-X
           END-PERFORM.

           MOVE WS-TOT-INITIAL         TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-PRFLD-INIT-PCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-DV-PRFLD-INIT-PCT.

           MOVE WS-TOT-SUBSEQ          TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-PRFLD-SUBSEQ-PCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-DV-PRFLD-SUBSEQ-PCT.
      
      *
      *  COMPLETION MESSAGE
      *  (WHEN EOF, DETERMINE IF PHYSICAL OR LOGICAL EOF)
      *
           IF  WIPDF-IO-EOF
      *MSG: END OF LIST
               MOVE 'XS00000015'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE WIPDF-PRFLDF-SEQ-NUM
                                       TO L0290-INPUT-V00
               MOVE ZERO               TO L0290-PRECISION
               MOVE LENGTH OF MIR-PRFLDF-SEQ-NUM
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-PRFLDF-SEQ-NUM
               SET WGLOB-MORE-DATA-EXISTS
                                       TO TRUE
      *MSG: TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  IPDF-3000-END-BROWSE
               THRU IPDF-3000-END-BROWSE-X.

       7400-GET-DETAIL-FUNDS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-PRFLD-STAT-CD.
           MOVE SPACES                 TO MIR-PRFLD-STAT-CHNG-DT.
           MOVE SPACES                 TO MIR-PRFLD-POL-CHNG-DT.
           MOVE SPACES                 TO MIR-PRFL-XPRY-DT.
           MOVE SPACES                 TO MIR-DV-PRFLDF-FND-PLAN-ID-G.
           MOVE SPACES                 TO MIR-PRFLDF-INIT-PCT-G.
           MOVE SPACES                 TO MIR-PRFLDF-SUBSEQ-PCT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           MOVE RIPRD-PRFLD-STAT-CD    TO MIR-PRFLD-STAT-CD.

           MOVE RIPRD-PRFLD-STAT-CHNG-DT
                                       TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PRFLD-STAT-CHNG-DT.

           MOVE RIPRD-PRFLD-POL-CHNG-DT
                                       TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PRFLD-POL-CHNG-DT.

           MOVE RIPRO-PRFL-XPRY-DT     TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PRFL-XPRY-DT.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9250-MOVE-RECORD-TO-MIR-2.
      *--------------------------

           IF  RIPDF-FND-ID = SPACE
               SET WS-CODE-PLAN        TO TRUE
               MOVE RIPDF-PLAN-ID      TO WS-FND-PLAN-ID
           ELSE
               SET WS-CODE-FND         TO TRUE
               MOVE RIPDF-FND-ID       TO WS-FND-PLAN-ID
           END-IF.

           MOVE WS-CODE                TO MIR-DV-PRFLDF-FND-PLAN-ID-T
                                          (WS-COUNT).

           MOVE RIPDF-PRFLDF-INIT-PCT  TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PRFLDF-INIT-PCT-T (1)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-PRFLDF-INIT-PCT-T
                                          (WS-COUNT).
           ADD RIPDF-PRFLDF-INIT-PCT   TO WS-TOT-INITIAL.

           MOVE RIPDF-PRFLDF-SUBSEQ-PCT
                                       TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PRFLDF-SUBSEQ-PCT-T (1)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-PRFLDF-SUBSEQ-PCT-T
                                          (WS-COUNT).
           ADD RIPDF-PRFLDF-SUBSEQ-PCT TO WS-TOT-SUBSEQ.

           IF RIPDF-PRFLDF-INIT-PCT NOT = RIPDF-PRFLDF-SUBSEQ-PCT
              SET WS-PRFL-PCT-NO       TO TRUE
              MOVE WS-PRFL-PCT-IND     TO MIR-DV-PRFLDF-PCT-IND
           END-IF.
           
       9250-MOVE-RECORD-TO-MIR-2-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-VARIABLES.
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE SPACES TO   WWKDT-WORK-FIELDS.
025970     SET WS-TWRK-KEY-DEFAULT    TO TRUE.
025970     SET WS-MAX-DEFAULT         TO TRUE.
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK          TO TRUE.
              
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  IPRO
                                '$VAR2'   BY 'IPRO'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNIPRD.
       COPY CCPBIPDF.
       COPY CCPNIPRO.
       COPY CCPUIPRO.


      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM2560                        **
      *****************************************************************
