      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8004.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8004                                         **
      **  REMARKS:  PROCESS DRIVER FOR POLICY/COVERAGE DIAGNOSTICS   **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       INITIAL CREATION                                 **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
016043**  6.1       PASS BACK UPDATEABLE DATA                        **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020136**  6.3       FORMAT RETURNED DATES CORRECTLY                  **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028262**  6.7       GLOBAL MESSAGE ERROR INDICATOR                   **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8004'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
028298 COPY CCWL2626.
014221 COPY XCWL8090.
014590*COPY XCWL0030.
      /

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-DIAGNOSTICS              VALUE '8004'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '8004'.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-SUB                                  PIC S9(04) COMP.
016548     05  WS-SUB                                  PIC S9(04)
016548                                                 BINARY.
           05  WS-INPUT-1-2                 PIC 9.99.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '8004'.
      *****************************************************************
      *  COMMON COPYBOOKS                                            *
      *****************************************************************
      /
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
016043 COPY XCWL0290.
020136/
020136 COPY XCWL1640.
020136/
       COPY CCWL6040.
      /
       COPY CCWL5900.
      /
       COPY CCWL5950.
      /
       COPY CCWL6060.
      /
020136 COPY XCWLDTLK.
020136*
       COPY CCWLPGA.
      /
      ***************************************************************
      * COVERAGE TABLE WORK AREA
      ***************************************************************
       COPY CCWWCVGS.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
021930*COPY CCFWCVGC.
021930*COPY CCFRCVGC.
021930*
      ***************************************************************
      * POLICY WORK AREA
      ***************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
      ***************************************************************
      * PLAN HEADER WORK AREA
      ***************************************************************
016537*COPY CCFRPH.
016537*COPY CCFWPH.
      /
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8004.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      

       0000-MAINLINE-X.
             GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

016043     PERFORM  0290-1000-BUILD-PARM-INFO
016043         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
016043     MOVE SPACES                  TO MIR-OUTPUT-AREA.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DIAGNOSTICS
                    PERFORM  8000-READ-POL-CVG-INFO
                        THRU 8000-READ-POL-CVG-INFO-X

                    IF  WGLOB-MSG-ERROR-SW > ZERO
028262*                 CONTINUE
028262                  PERFORM  9000-RETURN-DATA
028262                      THRU 9000-RETURN-DATA-X
                    ELSE
                        PERFORM 2500-CROSS-EDITS-ANALYSIS
                           THRU 2500-CROSS-EDITS-ANALYSIS-X
                    END-IF

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8004'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------------
       2500-CROSS-EDITS-ANALYSIS.
      *--------------------------

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  5100-PROCESS-COVERAGES
               THRU 5100-PROCESS-COVERAGES-X.

           PERFORM  5000-PROCESS-POLICY
               THRU 5000-PROCESS-POLICY-X.

016043     PERFORM  9000-RETURN-DATA
016043         THRU 9000-RETURN-DATA-X.
016043
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

       2500-CROSS-EDITS-ANALYSIS-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-POLICY.
      *--------------------

           PERFORM  6040-1000-BUILD-PARM-INFO
               THRU 6040-1000-BUILD-PARM-INFO-X.

           PERFORM  6040-1000-CROSS-EDIT-POL
               THRU 6040-1000-CROSS-EDIT-POL-X.

           IF  L6040-RETRN-ERROR
               SET RPOL-POL-EDIT-ERROR  TO TRUE
           END-IF.

           PERFORM  5950-1000-BUILD-PARM-INFO
               THRU 5950-1000-BUILD-PARM-INFO-X.

           PERFORM  5950-1000-ANALYZE-POL
               THRU 5950-1000-ANALYZE-POL-X.

       5000-PROCESS-POLICY-X.
           EXIT.
      /
      *-----------------------
       5100-PROCESS-COVERAGES.
      *-----------------------

           PERFORM  5900-1000-BUILD-PARM-INFO
               THRU 5900-1000-BUILD-PARM-INFO-X.

           PERFORM  5900-1000-CROSS-EDIT-CVGS
               THRU 5900-1000-CROSS-EDIT-CVGS-X.

           PERFORM  6060-1000-BUILD-PARM-INFO
               THRU 6060-1000-BUILD-PARM-INFO-X.

           PERFORM  6060-1000-ANALYZE-CVG
               THRU 6060-1000-ANALYZE-CVG-X.

       5100-PROCESS-COVERAGES-X.
           EXIT.
      /
      *-----------------------
       8000-READ-POL-CVG-INFO.
      *-----------------------

           MOVE MIR-POL-ID              TO WPOL-POL-ID.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 8000-READ-POL-CVG-INFO-X
014221     END-IF.

           IF  WPOL-IO-OK
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           ELSE
      *MSG:    "RECORD NOT FOUND"
               MOVE WPOL-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8000-READ-POL-CVG-INFO-X.
           EXIT.
      /
016043*-----------------
016043 9000-RETURN-DATA.
016043*-----------------
016043
020136     MOVE RPOL-POL-APP-CMPLT-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020136     MOVE L1640-EXTERNAL-DATE     TO MIR-POL-APP-CMPLT-DT.
020136
020136     MOVE RPOL-POL-NXT-ACTV-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020136     MOVE L1640-EXTERNAL-DATE     TO MIR-POL-NXT-ACTV-DT.
020136
020136*    MOVE RPOL-POL-APP-CMPLT-DT
020136*      TO MIR-POL-APP-CMPLT-DT.
020136*    MOVE RPOL-POL-NXT-ACTV-DT
020136*      TO MIR-POL-NXT-ACTV-DT.
016043     MOVE RPOL-NXT-ACTV-TYP-CD
016043       TO MIR-NXT-ACTV-TYP-CD.
016043     MOVE RPOL-POL-CSTAT-CD
016043       TO MIR-POL-CSTAT-CD.
016043     MOVE RPOL-POL-PREV-CSTAT-CD
016043       TO MIR-POL-PREV-CSTAT-CD.
020136*    MOVE RPOL-POL-STAT-CHNG-DT
020136*      TO MIR-POL-STAT-CHNG-DT.
020136     MOVE RPOL-POL-STAT-CHNG-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020136     MOVE L1640-EXTERNAL-DATE     TO MIR-POL-STAT-CHNG-DT.
020136
016043     MOVE RPOL-POL-CVG-ERROR-CD
016043       TO MIR-POL-CVG-ERROR-CD.
016043
016043     PERFORM  9010-RETURN-CVG-DATA
016043         THRU 9010-RETURN-CVG-DATA-X
016043      VARYING WS-SUB FROM 1 BY 1
016043        UNTIL WS-SUB > RPOL-POL-CVG-REC-CTR-N.
016043
016043 9000-RETURN-DATA-X.
016043     EXIT.
016043/
016043*---------------------
016043 9010-RETURN-CVG-DATA.
016043*---------------------
016043
020136     MOVE WCVGS-CVG-APP-CMPLT-DT (WS-SUB) TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020136     MOVE L1640-EXTERNAL-DATE TO MIR-CVG-APP-CMPLT-DT-T (WS-SUB).
020136
020136     MOVE WCVGS-CVG-CNVR-XPRY-DT (WS-SUB) TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020136     MOVE L1640-EXTERNAL-DATE TO MIR-CVG-CNVR-XPRY-DT-T (WS-SUB).
020136
020136     MOVE WCVGS-CVG-AD-XPRY-DT (WS-SUB) TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020136     MOVE L1640-EXTERNAL-DATE TO MIR-CVG-AD-XPRY-DT-T (WS-SUB).
020136
020136     MOVE WCVGS-CVG-WP-XPRY-DT (WS-SUB) TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020136     MOVE L1640-EXTERNAL-DATE TO MIR-CVG-WP-XPRY-DT-T (WS-SUB).
020136
020136*        MOVE WCVGS-CVG-APP-CMPLT-DT (WS-SUB)
016043*          TO MIR-CVG-APP-CMPLT-DT-T (WS-SUB).
016043*        MOVE WCVGS-CVG-CNVR-XPRY-DT (WS-SUB)
016043*          TO MIR-CVG-CNVR-XPRY-DT-T (WS-SUB).
016043*        MOVE WCVGS-CVG-AD-XPRY-DT (WS-SUB)
016043*          TO MIR-CVG-AD-XPRY-DT-T (WS-SUB).
016043*        MOVE WCVGS-CVG-WP-XPRY-DT (WS-SUB)
016043*          TO MIR-CVG-WP-XPRY-DT-T (WS-SUB).
016043         MOVE WCVGS-CVG-CSTAT-CD (WS-SUB)
016043           TO MIR-CVG-CSTAT-CD-T (WS-SUB).
016043         MOVE WCVGS-CVG-PREV-CSTAT-CD (WS-SUB)
016043           TO MIR-CVG-PREV-CSTAT-CD-T (WS-SUB).
020136*        MOVE WCVGS-CVG-STAT-PRCES-DT (WS-SUB)
020136*          TO MIR-CVG-STAT-PRCES-DT-T (WS-SUB).
020136     MOVE WCVGS-CVG-STAT-PRCES-DT (WS-SUB) TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020136     MOVE L1640-EXTERNAL-DATE TO MIR-CVG-STAT-PRCES-DT-T (WS-SUB).
020136
016043*        MOVE WCVGS-CVG-AD-MULT-FCT (WS-SUB)
016043*          TO WS-INPUT-1-2.
016043*        MOVE WS-INPUT-1-2
016043*          TO MIR-CVG-AD-MULT-FCT-T (WS-SUB).
016043*        MOVE WCVGS-CVG-WP-MULT-FCT (WS-SUB)
016043*          TO WS-INPUT-1-2.
016043*        MOVE WS-INPUT-1-2
016043*          TO MIR-CVG-WP-MULT-FCT-T (WS-SUB).
016043
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            WCVGS-CVG-AD-MULT-FCT (WS-SUB) * 100.
020874     MOVE WCVGS-CVG-AD-MULT-FCT (WS-SUB)  TO L0290-INPUT-V02.
016043     MOVE 2                               TO L0290-PRECISION.
016043     MOVE LENGTH OF MIR-CVG-AD-MULT-FCT-T (WS-SUB)
016043       TO L0290-MAX-OUT-LEN.
016043     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016043     MOVE L0290-OUTPUT-DATA TO MIR-CVG-AD-MULT-FCT-T (WS-SUB).
016043
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            WCVGS-CVG-WP-MULT-FCT (WS-SUB) * 100.
020874     MOVE WCVGS-CVG-WP-MULT-FCT (WS-SUB)  TO L0290-INPUT-V02.
016043     MOVE 2                               TO L0290-PRECISION.
016043     MOVE LENGTH OF MIR-CVG-WP-MULT-FCT-T (WS-SUB)
016043       TO L0290-MAX-OUT-LEN.
016043     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016043     MOVE L0290-OUTPUT-DATA TO MIR-CVG-WP-MULT-FCT-T (WS-SUB).
016043
016043 9010-RETURN-CVG-DATA-X.
016043     EXIT.
016043/
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                     TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID              TO WGLOB-REF-CLIENT-NUMBER.


       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5900-0000-INIT-PARM-INFO
025970         THRU 5900-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5950-0000-INIT-PARM-INFO
025970         THRU 5950-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6040-0000-INIT-PARM-INFO
025970         THRU 6040-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6060-0000-INIT-PARM-INFO
025970         THRU 6060-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.
025970     
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
       COPY NCPPCVGR.
      /
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
014660*COPY XCPPMEXT.
      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY XCCL8090.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL8090.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
016043 COPY XCPS0290.
016043 COPY XCPL0290.

025970 COPY XCPS1640.
020136 COPY XCPL1640.
      /
018764*COPY CCCL6060.
018764 COPY CCPL6060.
       COPY CCPS6060.
      /
018764*COPY CCCL5950.
018764 COPY CCPL5950.
       COPY CCPS5950.
      /
018764*COPY CCCL5900.
018764 COPY CCPL5900.
       COPY CCPS5900.
      /
018764*COPY CCCL6040.
018764 COPY CCPL6040.
       COPY CCPS6040.
      /
       COPY CCPSPGA.
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
014221 COPY CCPNPOL.
      /
       COPY CCPNCVG.
      /
       COPY CCPUPOL.
      /
       COPY CCPUCVG.
      /
016537*COPY CCPBCVGC.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM CSOM8004                       *
      ******************************************************************
