      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3070.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3070                                         **
      **  REMARKS:  PLBN - PLAN BONUS DECLARATION                    **
      **            THIS MODULE MAINTAINS THE PLBN TABLE             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013924**  5.6A      NEW                                              **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016016**  6.3       FUND BONUS (6.1.1E)                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021682**  6.4       BONUS DATE NOT REQUIRED FOR ANNUAL BONUS TYPE    **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3070'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
016548*    05  I                            PIC S9(04) COMP.
016548     05  I                            PIC S9(04) BINARY.
           05  WS-TRANS-NAME                PIC X(04)  VALUE 'PLBN'.
025970         88 WS-TRANS-NAME-DEFAULT          VALUE 'PLBN'.           
016548*    05  WS-SUB                       PIC S9(4)  COMP.
016548     05  WS-SUB                       PIC S9(4)  BINARY.
016548*    05  WS-MAX-BROWSE-CTR            PIC S9(4)  COMP.
016548     05  WS-MAX-BROWSE-CTR            PIC S9(4)  BINARY.
016548*    05  WS-CREATE-CTR                PIC S9(9)  COMP.
016548     05  WS-CREATE-CTR                PIC S9(9)  BINARY.
           05  WS-INVERTED-DATE             PIC 9(07).
           05  WS-INTERNAL-DATE.
               10  WS-INTERNAL-YYYY         PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-INTERNAL-MM           PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-INTERNAL-DD           PIC 9(02).
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '1620'.
               88  WS-BUS-FCN-CREATE        VALUE '1621'.
               88  WS-BUS-FCN-UPDATE        VALUE '1622'.
               88  WS-BUS-FCN-DELETE        VALUE '1623'.
               88  WS-BUS-FCN-LIST          VALUE '1624'.
               88  WS-BUS-FCN-LIST-DATE     VALUE '1625'.
               88  WS-BUS-FCN-CREATE-ALL    VALUE '1626'.
               88  WS-BUS-FCN-CREATE-TYPE   VALUE '1627'.
014221     05  WS-TWRK-KEY                  PIC X(04)
014221                                      VALUE '1620'.
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '1620'.
           05  WS-STAT-CD                   PIC X(01).
               88  WS-STAT-VALID            VALUE 'A' 'H'.
           05  WS-LAST-DATE-SW              PIC X(01).
               88  WS-LAST-DATE-OK          VALUE 'Y'.
               88  WS-LAST-DATE-NOT-OK      VALUE 'N'.
           05  WS-PLRT-IND-TABLE.
               10  WS-PLRT-ANBNP            PIC X(01).
                   88  WS-PLRT-ANBNP-EXIST             VALUE 'Y'.
                   88  WS-PLRT-ANBNP-NOT-EXIST         VALUE 'N'.
               10  WS-PLRT-ANBNR            PIC X(01).
                   88  WS-PLRT-ANBNR-EXIST             VALUE 'Y'.
                   88  WS-PLRT-ANBNR-NOT-EXIST         VALUE 'N'.
               10  WS-PLRT-ANBDV            PIC X(01).
                   88  WS-PLRT-ANBDV-EXIST             VALUE 'Y'.
                   88  WS-PLRT-ANBDV-NOT-EXIST         VALUE 'N'.
016016         10  WS-PLRT-INTBN            PIC X(01).
016016             88  WS-PLRT-INTBN-EXIST             VALUE 'Y'.
016016             88  WS-PLRT-INTBN-NOT-EXIST         VALUE 'N'.
016016     05  WS-PREV-EFF-DT-INV           PIC 9(07).
016016     05  WS-NEW-EFF-DT-INV            PIC 9(07).
016016     05  WS-STORE-BON-TYP-CD          PIC X(01).
      *
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
014221 COPY CCWWLOCK.
016016 COPY XCWWWKDT.
018764*COPY XCWLPTR.
      *
       COPY XCWEBLCH.
      *
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPLBN.
       COPY CCFRPLBN.
      *
       COPY CCFWPLBS.
      *

       COPY CCFWPLRT.
       COPY CCFRPLRT.
      *
       COPY CCFWPD.
       COPY CCFRPD.
      *
       COPY CCFWPH.
       COPY CCFRPH.
      *
       COPY CCFWSCOM.
       COPY CCFRSCOM.
      *
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY XCWL0290.
      *
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1660.
016537*COPY XCWL1670.
018763 COPY XCWL1670.
016016 COPY XCWL1680.
014221 COPY XCWL8090.
      *
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3070.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      *--------------
       0000-MAINLINE.
      *--------------
      *
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.
      *
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.
      *
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
      *
026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
           SET  MIR-RETRN-OK       TO TRUE.
           MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
               WHEN WS-BUS-FCN-LIST-DATE
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
               WHEN WS-BUS-FCN-CREATE-ALL
               WHEN WS-BUS-FCN-CREATE-TYPE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE


           END-EVALUATE.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------
      *
           PERFORM 6110-BUILD-KEY
              THRU 6110-BUILD-KEY-X.
      *
           IF WGLOB-RETURN-ERROR
              GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

014221     MOVE MIR-PLAN-ID       TO WPH-PLAN-ID
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X
014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WPH-PLAN-ID    TO WGLOB-MSG-PARM (1)
014221        MOVE 'PH'           TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3000-PROCESS-RETRIEVE-X
014221     END-IF.

           PERFORM PLBN-1000-READ
              THRU PLBN-1000-READ-X.

           IF WPLBN-IO-NOT-FOUND
      *MSG: RECORD NOT FOUND
              MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
              MOVE WPLBN-KEY          TO WGLOB-MSG-PARM (1)
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR TO TRUE
           ELSE
              PERFORM 9200-MOVE-RECORD-TO-SCREEN
                 THRU 9200-MOVE-RECORD-TO-SCREEN-X
016016****MSG:'INQUIRE COMPLETED - CONTINUE'
016016*       MOVE 'XS00000002'       TO WGLOB-MSG-REF-INFO
016016*       PERFORM 0260-1000-GENERATE-MESSAGE
016016*          THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------
      *

           COMPUTE WS-MAX-BROWSE-CTR = LENGTH OF MIR-SBSDRY-CO-ID-G
                                     / LENGTH OF MIR-SBSDRY-CO-ID-T (1).

      ****************************************************************
      * EACH RECORD OF THE BROWSE SCREEN.  THIS WILL ALLOW
      * USERS TO CHOSE A RECORD(S) TO PERFORM INQUIRE,
      * MAINTAIN OR DELETE PROCESSING FOR THE PLAN RATE RECORD
      * SELECTED.
      *
      *  CHECK ENTER CODE FIELDS FOR INPUT
      ****************************************************************

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3510-BROWSE-NORMAL
                       THRU 3510-BROWSE-NORMAL-X

               WHEN WS-BUS-FCN-LIST-DATE
                    PERFORM 3520-BROWSE-INVERTED
                       THRU 3520-BROWSE-INVERTED-X

           END-EVALUATE.
      *
       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------
       3510-BROWSE-NORMAL.
      *-------------------
      *
           MOVE LOW-VALUES            TO WPLBN-KEY.
           MOVE HIGH-VALUES           TO WPLBN-ENDBR-KEY.

           IF  MIR-PLAN-ID = SPACES
016016     OR  MIR-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
      * MSG: PLAN ID REQUIRED FOR BROWSE BY PLAN ID/SUBCOMPANY
               MOVE 'CS30700033'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  MIR-SBSDRY-CO-ID = SPACES
016016     OR  MIR-SBSDRY-CO-ID = EBLCH-BLANK-FIELD-CHAR
      * MSG: SUB COMPANY REQUIRED FOR BROWSE BY PLAN ID/SUBCOMPANY
               MOVE 'CS30700034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.


           MOVE MIR-PLAN-ID           TO WPLBN-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WPLBN-SBSDRY-CO-ID.
      *
           IF MIR-PLAN-BON-IDT-NUM = SPACE
               MOVE ZERO              TO WPLBN-PLAN-BON-IDT-NUM
           ELSE
               MOVE MIR-PLAN-BON-IDT-NUM
                                      TO L1640-EXTERNAL-DATE
               PERFORM 3540-EXTERNAL-TO-INVERTED
                  THRU 3540-EXTERNAL-TO-INVERTED-X
               IF WGLOB-RETURN-ERROR
                   GO TO 3510-BROWSE-NORMAL-X
               END-IF
               MOVE L1660-INVERTED-DATE
                                      TO WPLBN-PLAN-BON-IDT-NUM
           END-IF.
      *
           IF WGLOB-RETURN-ERROR
               GO TO 3510-BROWSE-NORMAL-X
           END-IF.

           MOVE WPLBN-KEY             TO WPLBN-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPLBN-ENDBR-PLAN-BON-IDT-NUM.

           PERFORM PLBN-1000-BROWSE
              THRU PLBN-1000-BROWSE-X.

           PERFORM PLBN-2000-READ-NEXT
              THRU PLBN-2000-READ-NEXT-X.

           PERFORM 3600-DISPLAY-RECORD
              THRU 3600-DISPLAY-RECORD-X
              VARYING WS-SUB FROM 1 BY 1
                UNTIL WS-SUB > WS-MAX-BROWSE-CTR
                   OR WPLBN-IO-EOF.
      *
           IF NOT WPLBN-IO-EOF
      *MSG: TO VIEW MORE DATA PRESS ENTER
               MOVE 'CS30700002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPLBN-PLAN-ID     TO MIR-PLAN-ID
               MOVE RPLBN-SBSDRY-CO-ID  TO MIR-SBSDRY-CO-ID
               MOVE RPLBN-PLAN-BON-IDT-NUM
                                      TO L1660-INVERTED-DATE
               PERFORM 3610-INVERTED-TO-EXTERNAL
                  THRU 3610-INVERTED-TO-EXTERNAL-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PLAN-BON-IDT-NUM
016016         MOVE RPLBN-PLAN-BON-TYP-CD TO MIR-PLAN-BON-TYP-CD
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
           ELSE
               IF  MIR-PLAN-ID-T (1)      > SPACES
                   MOVE MIR-PLAN-ID-T  (1)  TO MIR-PLAN-ID
                   MOVE MIR-SBSDRY-CO-ID-T (1)
                                      TO MIR-SBSDRY-CO-ID
                   MOVE MIR-PLAN-BON-IDT-NUM-T  (1)
                                      TO MIR-PLAN-BON-IDT-NUM
016016             MOVE MIR-PLAN-BON-TYP-CD-T  (1)
016016                                TO MIR-PLAN-BON-TYP-CD
      *MSG: END OF FILE REACHED
                   MOVE 'CS30700003'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORD FOUND FOR DISPLAY
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
           PERFORM PLBN-3000-END-BROWSE
              THRU PLBN-3000-END-BROWSE-X.
      *
       3510-BROWSE-NORMAL-X.
           EXIT.
      /
      *---------------------
       3520-BROWSE-INVERTED.
      *---------------------
      *
           IF  MIR-SBSDRY-CO-ID = SPACES
      * MSG: SUB COMPANY REQUIRED FOR BROWSE BY DECLARATION DATE
               MOVE 'CS30700036'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  MIR-PLAN-BON-IDT-NUM = SPACES
      * MSG: DECLARATION DATE REQUIRED FOR BROWSE BY DECLARATION DATE
               MOVE 'CS30700035'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           MOVE LOW-VALUES            TO WPLBS-KEY.
           MOVE HIGH-VALUES           TO WPLBS-ENDBR-KEY.

           IF  MIR-PLAN-ID > SPACES
               MOVE MIR-PLAN-ID       TO WPLBS-PLAN-ID
           END-IF.

           MOVE MIR-SBSDRY-CO-ID      TO WPLBS-SBSDRY-CO-ID.
      *
           MOVE MIR-PLAN-BON-IDT-NUM  TO L1640-EXTERNAL-DATE.

           PERFORM 3540-EXTERNAL-TO-INVERTED
              THRU 3540-EXTERNAL-TO-INVERTED-X.

           IF WGLOB-RETURN-ERROR
               GO TO 3520-BROWSE-INVERTED-X
           END-IF.

           MOVE L1660-INVERTED-DATE   TO WPLBS-PLAN-BON-IDT-NUM.

      *
           MOVE WPLBS-KEY             TO WPLBS-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPLBS-ENDBR-PLAN-BON-IDT-NUM.

           PERFORM PLBS-1000-BROWSE
              THRU PLBS-1000-BROWSE-X.

           PERFORM PLBS-2000-READ-NEXT
              THRU PLBS-2000-READ-NEXT-X.

           PERFORM 3600-DISPLAY-RECORD
              THRU 3600-DISPLAY-RECORD-X
              VARYING WS-SUB FROM 1 BY 1
                UNTIL WS-SUB > WS-MAX-BROWSE-CTR
                   OR WPLBS-IO-EOF.
      *
           IF NOT WPLBS-IO-EOF
      *MSG: TO VIEW MORE DATA PRESS ENTER
               MOVE 'CS30700002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPLBN-PLAN-ID     TO MIR-PLAN-ID
               MOVE RPLBN-SBSDRY-CO-ID TO MIR-SBSDRY-CO-ID
               MOVE RPLBN-PLAN-BON-IDT-NUM
                                      TO L1660-INVERTED-DATE
               PERFORM 3610-INVERTED-TO-EXTERNAL
                  THRU 3610-INVERTED-TO-EXTERNAL-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PLAN-BON-IDT-NUM
016016         MOVE RPLBN-PLAN-BON-TYP-CD TO MIR-PLAN-BON-TYP-CD
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
           ELSE
               IF  MIR-PLAN-ID-T (1)      > SPACES
                   MOVE MIR-PLAN-ID-T  (1)  TO MIR-PLAN-ID
                   MOVE MIR-SBSDRY-CO-ID-T (1)
                                      TO MIR-SBSDRY-CO-ID
                   MOVE MIR-PLAN-BON-IDT-NUM-T  (1)
                                      TO MIR-PLAN-BON-IDT-NUM
016016             MOVE MIR-PLAN-BON-TYP-CD-T  (1)
016016                                TO MIR-PLAN-BON-TYP-CD
      *MSG: END OF FILE REACHED
                   MOVE 'CS30700003'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORD FOUND FOR DISPLAY
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
           PERFORM PLBS-3000-END-BROWSE
              THRU PLBS-3000-END-BROWSE-X.
      *
       3520-BROWSE-INVERTED-X.
           EXIT.
      /
      *--------------------------
       3540-EXTERNAL-TO-INVERTED.
      *--------------------------
      *
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
           ELSE
               MOVE 'CS30700004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.
      *
       3540-EXTERNAL-TO-INVERTED-X.
           EXIT.
      /
      *--------------------
       3600-DISPLAY-RECORD.
      *--------------------
      *
           IF (WS-BUS-FCN-LIST-DATE
           AND RPLBN-SBSDRY-CO-ID NOT = MIR-SBSDRY-CO-ID)
               SUBTRACT +1 FROM WS-SUB
           ELSE
               MOVE RPLBN-PLAN-ID       TO MIR-PLAN-ID-T (WS-SUB)
               MOVE RPLBN-SBSDRY-CO-ID  TO MIR-SBSDRY-CO-ID-T (WS-SUB)
               MOVE RPLBN-PLAN-BON-IDT-NUM
                                      TO L1660-INVERTED-DATE
               PERFORM 3610-INVERTED-TO-EXTERNAL
                  THRU 3610-INVERTED-TO-EXTERNAL-X
               MOVE L1640-EXTERNAL-DATE
                                   TO MIR-PLAN-BON-IDT-NUM-T (WS-SUB)
016016         MOVE RPLBN-PLAN-BON-TYP-CD
016016                             TO MIR-PLAN-BON-TYP-CD-T (WS-SUB)
           END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM PLBN-2000-READ-NEXT
                  THRU PLBN-2000-READ-NEXT-X
           ELSE
               PERFORM PLBS-2000-READ-NEXT
                  THRU PLBS-2000-READ-NEXT-X
           END-IF.
      *
       3600-DISPLAY-RECORD-X.
           EXIT.
      /
      *--------------------------
       3610-INVERTED-TO-EXTERNAL.
      *--------------------------
      *
           PERFORM 1660-3000-CONVERT-INV-TO-INT
              THRU 1660-3000-CONVERT-INV-TO-INT-X.

           MOVE L1660-INTERNAL-DATE   TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
      *
       3610-INVERTED-TO-EXTERNAL-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *---------------------
      *
           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM 4100-CREATE-EDITS
              THRU 4100-CREATE-EDITS-X.
      *
           IF WGLOB-GOOD-RETURN
               CONTINUE
           ELSE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.
      *
           MOVE ZERO                  TO WS-CREATE-CTR.
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                   PERFORM 4200-CREATE-RECORD
                      THRU 4200-CREATE-RECORD-X

               WHEN WS-BUS-FCN-CREATE-TYPE
                   PERFORM 4300-CREATE-BY-TYP-INS
                      THRU 4300-CREATE-BY-TYP-INS-X

               WHEN WS-BUS-FCN-CREATE-ALL
                   PERFORM 4400-CREATE-ALL-PLANS
                      THRU 4400-CREATE-ALL-PLANS-X

           END-EVALUATE.

           IF WS-BUS-FCN-CREATE
              GO TO 4000-PROCESS-CREATE-X
           END-IF.
      *
      *MSG: CREATED @1 RECORDS
           MOVE 'CS30700006'          TO WGLOB-MSG-REF-INFO.
           MOVE WS-CREATE-CTR         TO L0290-INPUT-NUMBER.
           MOVE ZERO                  TO L0290-PRECISION.
           MOVE 9                     TO L0290-MAX-OUT-LEN.

           PERFORM 0290-1000-NUMERIC-FORMAT
              THRU 0290-1000-NUMERIC-FORMAT-X.
           MOVE L0290-OUTPUT-DATA     TO WGLOB-MSG-PARM (1).

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *------------------
       4100-CREATE-EDITS.
      *------------------
      *
           PERFORM 4130-EDIT-PLAN
              THRU 4130-EDIT-PLAN-X.
      *
           PERFORM 4150-EDIT-TYP-INS
              THRU 4150-EDIT-TYP-INS-X.
      *
           PERFORM 4170-EDIT-SUB-CO
              THRU 4170-EDIT-SUB-CO-X.
      *
           PERFORM 4190-EDIT-DATE
              THRU 4190-EDIT-DATE-X.
      *
       4100-CREATE-EDITS-X.
           EXIT.
      /
      *---------------
       4130-EDIT-PLAN.
      *---------------
      *
           IF  MIR-PLAN-ID = SPACE
               IF  WS-BUS-FCN-CREATE
      *MGS: PLAN ID MUST BE ENTERED
                  MOVE 'CS30700023'   TO WGLOB-MSG-REF-INFO
                  PERFORM 0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                  SET WGLOB-RETURN-ERROR  TO TRUE
                  GO TO 4130-EDIT-PLAN-X
               ELSE
                  GO TO 4130-EDIT-PLAN-X
               END-IF
           END-IF.
      *
           MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

           PERFORM PH-2000-READ-INDEX
              THRU PH-2000-READ-INDEX-X.
      *
           IF WPH-IO-NOT-FOUND
      *MGS: PLAN NOT CREATED YET
               MOVE 'CS30700007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.
      *
       4130-EDIT-PLAN-X.
           EXIT.
      /
      *------------------
       4150-EDIT-TYP-INS.
      *------------------
      *
           IF  MIR-PLAN-INS-TYP-CD = SPACE
               IF WS-BUS-FCN-CREATE-TYPE
      *MGS: TYPE OF INSURANCE MUST BE ENTERED
                  MOVE 'CS30700008'   TO WGLOB-MSG-REF-INFO
                  PERFORM 0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                  SET WGLOB-RETURN-ERROR  TO TRUE
                  GO TO 4150-EDIT-TYP-INS-X
               ELSE
                  GO TO 4150-EDIT-TYP-INS-X
               END-IF
           END-IF.
      *
       4150-EDIT-TYP-INS-X.
           EXIT.
      /
      *-----------------
       4170-EDIT-SUB-CO.
      *-----------------
      *
           MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.

           PERFORM SCOM-2000-READ-INDEX
              THRU SCOM-2000-READ-INDEX-X.
      *
           IF WSCOM-IO-NOT-FOUND
      *MGS: SUBSIDIARY COMPANY INVALID
               MOVE 'CS30700011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.
      *
       4170-EDIT-SUB-CO-X.
           EXIT.
      /
      *---------------
       4190-EDIT-DATE.
      *---------------
      *
016016* THE DATE BEING EDITED IN THIS PARAGRAPH IS THE DECLARATION DATE

           IF MIR-PLAN-BON-IDT-NUM = SPACE
016016****MSG: MUST SPECIFY PLAN BONUS DATE
016016*MSG: PLAN BONUS DECLARATION DATE MUST BE SPECIFIED
               MOVE 'CS30700012'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 4190-EDIT-DATE-X
           END-IF.
      *
           MOVE MIR-PLAN-BON-IDT-NUM  TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               MOVE L1640-INTERNAL-DATE
                                      TO WS-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE
                                      TO WS-INVERTED-DATE
           ELSE
016016****MSG: PLAN BONUS DATE INVALID
016016*MSG: PLAN BONUS DECLARATION DATE INVALID, RE-ENTER
               MOVE 'CS30700013'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.
      *
       4190-EDIT-DATE-X.
           EXIT.
      /
      *-------------------
       4200-CREATE-RECORD.
      *-------------------
      *
016016* EDIT THE BONUS TYPE
016016
016016     IF  MIR-PLAN-BON-TYP-VALID
016016         CONTINUE
016016     ELSE
016016*MSG: BONUS TYPE INVALID
016016         MOVE 'CS30700041'       TO WGLOB-MSG-REF-INFO
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016            IF  NOT WGLOB-MSG-SEVRTY-WARNING
016016                SET WGLOB-RETURN-ERROR TO TRUE
016016                GO TO 4200-CREATE-RECORD-X
016016            END-IF
016016     END-IF.
016016
016016*    PERFORM 4210-CHECK-PLAN-DIV-CD
016016*       THRU 4210-CHECK-PLAN-DIV-CD-X.

016016*    IF  WGLOB-GOOD-RETURN
016016*        CONTINUE
016016*    ELSE
016016*        GO TO 4200-CREATE-RECORD-X
016016*    END-IF.
016016
016016* ONLY CHECK PLAN DIVIDEND OPTION FOR BONUS TYPE ANNUAL
016016
016016     IF  MIR-PLAN-BON-TYP-ANN-BON
016016         PERFORM 4210-CHECK-PLAN-DIV-CD
016016            THRU 4210-CHECK-PLAN-DIV-CD-X
016016         IF  WGLOB-GOOD-RETURN
016016             CONTINUE
016016         ELSE
016016             GO TO 4200-CREATE-RECORD-X
016016         END-IF
016016     END-IF.
016016
016016*    PERFORM 4600-CHECK-FOR-PLRT-RECS
016016*       THRU 4600-CHECK-FOR-PLRT-RECS-X.
016016
016016     IF  MIR-PLAN-BON-TYP-ANN-BON
016016         PERFORM 4600-CHECK-FOR-PLRT-RECS
016016            THRU 4600-CHECK-FOR-PLRT-RECS-X
016016     ELSE
016016         PERFORM 4610-CHECK-FOR-INT-PLRT-REC
016016            THRU 4610-CHECK-FOR-INT-PLRT-REC-X
016016     END-IF.
016016
           IF  WS-PLRT-ANBNP-NOT-EXIST
016016     AND MIR-PLAN-BON-TYP-ANN-BON
      * MSG: UNABLE TO CREATE, PLAN RATE TYPE @1 IS MISSING
                 MOVE 'CS30700037'    TO WGLOB-MSG-REF-INFO
                 MOVE 'ANBNP'         TO WGLOB-MSG-PARM (1)
                 PERFORM 0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                 SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  WS-PLRT-ANBNR-NOT-EXIST
016016     AND MIR-PLAN-BON-TYP-ANN-BON
      * MSG: UNABLE TO CREATE, PLAN RATE TYPE @1 IS MISSING
                 MOVE 'CS30700037'    TO WGLOB-MSG-REF-INFO
                 MOVE 'ANBNR'         TO WGLOB-MSG-PARM (1)
                 PERFORM 0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                 SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  WS-PLRT-ANBDV-NOT-EXIST
016016     AND MIR-PLAN-BON-TYP-ANN-BON
      * MSG: UNABLE TO CREATE, PLAN RATE TYPE @1 IS MISSING
                 MOVE 'CS30700037'    TO WGLOB-MSG-REF-INFO
                 MOVE 'ANBDV'         TO WGLOB-MSG-PARM (1)
                 PERFORM 0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                 SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  WGLOB-GOOD-RETURN
               CONTINUE
           ELSE
               GO TO 4200-CREATE-RECORD-X
           END-IF.

016016     IF  WS-PLRT-INTBN-NOT-EXIST
016016     AND MIR-PLAN-BON-TYP-INT-BON
016016*MSG: UNABLE TO CREATE, PLAN RATE TYPE @1 IS MISSING
016016           MOVE 'CS30700037'    TO WGLOB-MSG-REF-INFO
016016           MOVE 'INTBN'         TO WGLOB-MSG-PARM (1)
016016           PERFORM 0260-1000-GENERATE-MESSAGE
016016              THRU 0260-1000-GENERATE-MESSAGE-X
016016              IF  NOT WGLOB-MSG-SEVRTY-WARNING
016016                  SET WGLOB-RETURN-ERROR TO TRUE
016016                  GO TO 4200-CREATE-RECORD-X
016016              END-IF
016016     END-IF.
016016
           MOVE WPH-PLAN-ID           TO WPLBN-PLAN-ID.
           MOVE WSCOM-SBSDRY-CO-ID    TO WPLBN-SBSDRY-CO-ID.
           MOVE WS-INVERTED-DATE      TO WPLBN-PLAN-BON-IDT-NUM.

           PERFORM PLBN-1000-READ
              THRU PLBN-1000-READ-X.
      *
           IF WPLBN-IO-OK
      *MSG: PLAN BONUS RECORD ALREADY EXISTS
               MOVE 'CS30700014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
016016         GO TO 4200-CREATE-RECORD-X
016016     END-IF.
016016*    ELSE
016016*        PERFORM 4500-CHECK-PREV-PLBN
016016*           THRU 4500-CHECK-PREV-PLBN-X
016016*        IF NOT WS-LAST-DATE-NOT-OK
016016*            ADD +1                TO WS-CREATE-CTR
016016*            MOVE WS-INVERTED-DATE
016016*                               TO WPLBN-PLAN-BON-IDT-NUM
016016*            PERFORM PLBN-1000-CREATE
016016*               THRU PLBN-1000-CREATE-X
016016*            PERFORM PLBN-1000-WRITE
016016*               THRU PLBN-1000-WRITE-X
016016*            PERFORM 9200-MOVE-RECORD-TO-SCREEN
016016*               THRU 9200-MOVE-RECORD-TO-SCREEN-X
016016*        END-IF
016016*    END-IF.
016016
016016     PERFORM 4500-CHECK-PREV-PLBN
016016        THRU 4500-CHECK-PREV-PLBN-X.
016016
016016* CREATE THE PLBN RECORD
016016
016016     MOVE MIR-PLAN-BON-TYP-CD  TO WS-STORE-BON-TYP-CD.
016016
016016     IF  WS-LAST-DATE-OK
016016         ADD +1                TO WS-CREATE-CTR
016016         MOVE WS-INVERTED-DATE TO WPLBN-PLAN-BON-IDT-NUM
016016         PERFORM PLBN-1000-CREATE
016016            THRU PLBN-1000-CREATE-X
016016         PERFORM PLBN-1000-WRITE
016016            THRU PLBN-1000-WRITE-X
016016
014221         MOVE MIR-PLAN-ID      TO WPH-PLAN-ID
014221         PERFORM PH-1000-READ-TWRK-TS
014221            THRU PH-1000-READ-TWRK-TS-X

016016         PERFORM 9200-MOVE-RECORD-TO-SCREEN
016016            THRU 9200-MOVE-RECORD-TO-SCREEN-X
016016     END-IF.

016016* THIS NEXT LINE OF CODE IS NOT STANDARD. BONUS TYPE CODE IS
016016* NOT A KEY FIELD ON PLBN, BUT THE VALUE IS INPUT ON THE FIRST
016016* SCREEN OF THE CREATE BECAUSE IT IS NEEDED FOR THE CREATE EDITS.
016016* WHEN THE PLBN IS CREATED THE BONUS TYPE IS ALWAYS DEFAULTED TO
016016* ANNUAL SO HERE WE SHOULD MOVE BACK THE VALUE WHICH WAS INPUT
016016* ON THE FIRST CREATE SCREEN IF IT IS NOT ANNUAL.
016016
016016     IF  WS-STORE-BON-TYP-CD NOT = RPLBN-PLAN-BON-TYP-CD
016016         PERFORM  PLBN-1000-READ-FOR-UPDATE
016016             THRU PLBN-1000-READ-FOR-UPDATE-X
016016         MOVE WS-STORE-BON-TYP-CD  TO RPLBN-PLAN-BON-TYP-CD
016016         PERFORM  PLBN-2000-REWRITE
016016             THRU PLBN-2000-REWRITE-X
016016     END-IF.

      *
       4200-CREATE-RECORD-X.
           EXIT.
      *
      *-----------------------
       4210-CHECK-PLAN-DIV-CD.
      *-----------------------
      *
           PERFORM PH-1000-READ
              THRU PH-1000-READ-X.

           IF  NOT WPH-IO-OK
      * MSG: PLAN NOT CREATED YET
               MOVE 'CS30700007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  RPH-PLAN-NON-PAR
      * MSG: UNABLE TO CREATE, PLAN DIDVIDEND OPTION IS
      *      NON-PARTICIPATING
                   MOVE 'CS30700027'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR  TO TRUE
               END-IF
           END-IF.
      *
       4210-CHECK-PLAN-DIV-CD-X.
           EXIT.
      /
      *-----------------------
       4300-CREATE-BY-TYP-INS.
      *-----------------------
      *
016016* ONLY FOR BONUS TYPE ANNUAL
016016     SET MIR-PLAN-BON-TYP-ANN-BON TO TRUE.
016016
           MOVE LOW-VALUES            TO WPH-PLAN-ID.
           MOVE HIGH-VALUES           TO WPH-ENDBR-PLAN-ID.

           PERFORM PH-1000-BROWSE
              THRU PH-1000-BROWSE-X.

           PERFORM PH-2000-READ-NEXT
              THRU PH-2000-READ-NEXT-X.

           PERFORM 4320-CREATE-RECORDS
              THRU 4320-CREATE-RECORDS-X
              UNTIL WPH-IO-EOF.

           PERFORM PH-3000-END-BROWSE
              THRU PH-3000-END-BROWSE-X.

      *
       4300-CREATE-BY-TYP-INS-X.
           EXIT.
      /
      *--------------------
       4320-CREATE-RECORDS.
      *--------------------
      *
           IF  NOT RPH-PLAN-PAR
               PERFORM PH-2000-READ-NEXT
                  THRU PH-2000-READ-NEXT-X
               GO TO 4320-CREATE-RECORDS-X
           END-IF.

           MOVE RPH-PLAN-ID           TO WPD-PLAN-ID.
           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.

           IF RPD-PLAN-INS-TYP-CD NOT = MIR-PLAN-INS-TYP-CD
               PERFORM PH-2000-READ-NEXT
                  THRU PH-2000-READ-NEXT-X
               GO TO 4320-CREATE-RECORDS-X
           END-IF.

           PERFORM 4600-CHECK-FOR-PLRT-RECS
              THRU 4600-CHECK-FOR-PLRT-RECS-X.

           EVALUATE TRUE

              WHEN ( WS-PLRT-ANBNP-NOT-EXIST AND
                     WS-PLRT-ANBNR-NOT-EXIST AND
                     WS-PLRT-ANBDV-NOT-EXIST     )
                    CONTINUE

              WHEN ( WS-PLRT-ANBNP-EXIST AND
                     WS-PLRT-ANBNR-EXIST AND
                     WS-PLRT-ANBDV-EXIST     )
                   PERFORM 4440-PROCESS-PLBN
                      THRU 4440-PROCESS-PLBN-X

              WHEN ( WS-PLRT-ANBNP-NOT-EXIST OR
                     WS-PLRT-ANBNR-NOT-EXIST OR
                     WS-PLRT-ANBDV-NOT-EXIST     )
                   PERFORM 4330-GEN-NO-PLRT-MSG
                      THRU 4330-GEN-NO-PLRT-MSG-X

           END-EVALUATE.
      *
           PERFORM PH-2000-READ-NEXT
              THRU PH-2000-READ-NEXT-X.
      *
       4320-CREATE-RECORDS-X.
           EXIT.
      /
      *--------------------
       4330-GEN-NO-PLRT-MSG.
      *--------------------

           IF  WS-PLRT-ANBNP-NOT-EXIST
      * MSG: UNABLE TO CREATE PLAN @1, PLAN RATE TYPE @1 IS MISSING
                 MOVE 'CS30700040'    TO WGLOB-MSG-REF-INFO
                 MOVE RPH-PLAN-ID     TO WGLOB-MSG-PARM (1)
                 MOVE 'ANBNP'         TO WGLOB-MSG-PARM (2)
                 PERFORM 0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-PLRT-ANBNR-NOT-EXIST
      * MSG: UNABLE TO CREATE PLAN @1, PLAN RATE TYPE @1 IS MISSING
                 MOVE 'CS30700040'    TO WGLOB-MSG-REF-INFO
                 MOVE RPH-PLAN-ID     TO WGLOB-MSG-PARM (1)
                 MOVE 'ANBNR'         TO WGLOB-MSG-PARM (2)
                 PERFORM 0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-PLRT-ANBDV-NOT-EXIST
      * MSG: UNABLE TO CREATE PLAN @1, PLAN RATE TYPE @1 IS MISSING
                 MOVE 'CS30700040'    TO WGLOB-MSG-REF-INFO
                 MOVE RPH-PLAN-ID     TO WGLOB-MSG-PARM (1)
                 MOVE 'ANBDV'         TO WGLOB-MSG-PARM (2)
                 PERFORM 0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4330-GEN-NO-PLRT-MSG-X.
           EXIT.

      /
      *----------------------
       4400-CREATE-ALL-PLANS.
      *----------------------
      *
016016* ONLY FOR BONUS TYPE ANNUAL
016016     SET MIR-PLAN-BON-TYP-ANN-BON TO TRUE.
016016
           MOVE LOW-VALUES            TO WPH-PLAN-ID.
           MOVE HIGH-VALUES           TO WPH-ENDBR-PLAN-ID.

           PERFORM PH-1000-BROWSE
              THRU PH-1000-BROWSE-X.

           PERFORM PH-2000-READ-NEXT
              THRU PH-2000-READ-NEXT-X.

           PERFORM 4420-CREATE-RECORDS
              THRU 4420-CREATE-RECORDS-X
              UNTIL WPH-IO-EOF.

           PERFORM PH-3000-END-BROWSE
              THRU PH-3000-END-BROWSE-X.

       4400-CREATE-ALL-PLANS-X.
           EXIT.
      /
      *--------------------
       4420-CREATE-RECORDS.
      *--------------------
      *
           IF  NOT RPH-PLAN-PAR
               PERFORM PH-2000-READ-NEXT
                  THRU PH-2000-READ-NEXT-X
               GO TO 4420-CREATE-RECORDS-X
           END-IF.

           PERFORM 4600-CHECK-FOR-PLRT-RECS
              THRU 4600-CHECK-FOR-PLRT-RECS-X.

           EVALUATE TRUE

              WHEN ( WS-PLRT-ANBNP-NOT-EXIST AND
                     WS-PLRT-ANBNR-NOT-EXIST AND
                     WS-PLRT-ANBDV-NOT-EXIST     )
                    CONTINUE

              WHEN ( WS-PLRT-ANBNP-EXIST AND
                     WS-PLRT-ANBNR-EXIST AND
                     WS-PLRT-ANBDV-EXIST     )

                   MOVE RPH-PLAN-ID   TO WPD-PLAN-ID
                   PERFORM PD-1000-READ
                      THRU PD-1000-READ-X
                   PERFORM 4440-PROCESS-PLBN
                      THRU 4440-PROCESS-PLBN-X

              WHEN ( WS-PLRT-ANBNP-NOT-EXIST OR
                     WS-PLRT-ANBNR-NOT-EXIST OR
                     WS-PLRT-ANBDV-NOT-EXIST     )
                   PERFORM 4330-GEN-NO-PLRT-MSG
                      THRU 4330-GEN-NO-PLRT-MSG-X

           END-EVALUATE.


           PERFORM PH-2000-READ-NEXT
              THRU PH-2000-READ-NEXT-X.
      *
       4420-CREATE-RECORDS-X.
           EXIT.
      *
      *------------------
       4440-PROCESS-PLBN.
      *------------------
      *
           MOVE RPH-PLAN-ID           TO WPLBN-PLAN-ID.
           MOVE WSCOM-SBSDRY-CO-ID    TO WPLBN-SBSDRY-CO-ID.
           MOVE WS-INVERTED-DATE      TO WPLBN-PLAN-BON-IDT-NUM.

           PERFORM PLBN-1000-READ
              THRU PLBN-1000-READ-X.
      *
           IF WPLBN-IO-NOT-FOUND
               PERFORM 4500-CHECK-PREV-PLBN
                  THRU 4500-CHECK-PREV-PLBN-X
               IF  WS-LAST-DATE-NOT-OK
                   CONTINUE
               ELSE
                   MOVE WS-INVERTED-DATE
                                      TO WPLBN-PLAN-BON-IDT-NUM
                   PERFORM PLBN-1000-CREATE
                      THRU PLBN-1000-CREATE-X
                   PERFORM PLBN-1000-WRITE
                      THRU PLBN-1000-WRITE-X
      *MSG: PLAN @1 CREATED FOR SUB-COMPANY @2 EFFECTIVE @3
                   MOVE 'CS30700028'  TO WGLOB-MSG-REF-INFO
                   MOVE RPH-PLAN-ID   TO WGLOB-MSG-PARM (1)
                   MOVE WSCOM-SBSDRY-CO-ID
                                      TO WGLOB-MSG-PARM (2)
                   MOVE MIR-PLAN-BON-IDT-NUM
                                      TO WGLOB-MSG-PARM (3)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   ADD +1                  TO WS-CREATE-CTR
               END-IF
           END-IF.

       4440-PROCESS-PLBN-X.
           EXIT.
      /
      *---------------------
       4500-CHECK-PREV-PLBN.
      *---------------------
016016* THIS PARAGRAPH READS THE PREVIOUS (MOST RECENT)
016016* PLAN BONUS RECORD (IF ONE EXISTS)

           SET WS-LAST-DATE-OK  TO TRUE.
           MOVE LOW-VALUES            TO WPLBN-PLAN-BON-IDT-NUM.
           MOVE WPLBN-KEY             TO WPLBN-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPLBN-ENDBR-PLAN-BON-IDT-NUM.

           PERFORM PLBN-1000-BROWSE
              THRU PLBN-1000-BROWSE-X.

           PERFORM PLBN-2000-READ-NEXT
              THRU PLBN-2000-READ-NEXT-X.

           IF  WPLBN-IO-OK
016016         IF  MIR-PLAN-BON-TYP-ANN-BON
                   PERFORM 4510-CHECK-DECL-DATE
                      THRU 4510-CHECK-DECL-DATE-X
016016         ELSE
016016             PERFORM 4520-CHECK-INT-DECL-DATE
016016                THRU 4520-CHECK-INT-DECL-DATE-X
016016         END-IF
           END-IF.

           PERFORM PLBN-3000-END-BROWSE
              THRU PLBN-3000-END-BROWSE-X.

       4500-CHECK-PREV-PLBN-X.
           EXIT.
      /
      *---------------------
       4510-CHECK-DECL-DATE.
      *---------------------
016016* THIS PARAGRAPH IS FOR BONUS TYPE ANNUAL

           MOVE RPLBN-PLAN-BON-IDT-NUM           TO L1660-INVERTED-DATE.

           PERFORM 3610-INVERTED-TO-EXTERNAL
              THRU 3610-INVERTED-TO-EXTERNAL-X.

           ADD 1                    TO L1660-YYYY-1.
           IF WS-INTERNAL-YYYY NOT = L1660-YYYY-1
      * MSG:  DECLARATION DATE MUST IN FOLLOWING YEAR OF PREV RECORD
      *       FOR PLAN @1
                    MOVE 'CS30700030' TO WGLOB-MSG-REF-INFO
                    MOVE RPH-PLAN-ID  TO WGLOB-MSG-PARM (1)
                    PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                    SET WS-LAST-DATE-NOT-OK TO TRUE
016016              SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       4510-CHECK-DECL-DATE-X.
           EXIT.
      /
016016*-------------------------
016016 4520-CHECK-INT-DECL-DATE.
016016*-------------------------
016016*
016016* THIS PARAGRAPH IS FOR BONUS TYPE INTEREST
016016
016016     IF  WS-INVERTED-DATE > RPLBN-PLAN-BON-IDT-NUM
016016*MSG:  BONUS DECLARATION DATE CANNOT BE EARLIER THAN
016016*       LAST DECLARATION DATE
016016         MOVE 'CS30700042' TO WGLOB-MSG-REF-INFO
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016         IF  NOT WGLOB-MSG-SEVRTY-WARNING
016016             SET WS-LAST-DATE-NOT-OK TO TRUE
016016             SET WGLOB-RETURN-ERROR  TO TRUE
016016         END-IF
016016     END-IF.
016016
016016 4520-CHECK-INT-DECL-DATE-X.
016016     EXIT.
016016/
      *-------------------------
       4600-CHECK-FOR-PLRT-RECS.
      *-------------------------
      *
016016* THIS PARAGRAPH IS FOR BONUS TYPE ANNUAL

           SET WS-PLRT-ANBNP-NOT-EXIST   TO TRUE.
           SET WS-PLRT-ANBNR-NOT-EXIST   TO TRUE.
           SET WS-PLRT-ANBDV-NOT-EXIST   TO TRUE.


           SET WPLRT-PLAN-RT-TYP-ANBNP        TO TRUE.
           MOVE RPH-PLAN-ID           TO WPLRT-PLAN-ID.

           PERFORM PLRT-1000-READ
              THRU PLRT-1000-READ-X.

           IF  WPLRT-IO-OK
               SET WS-PLRT-ANBNP-EXIST         TO TRUE
           END-IF.

           SET WPLRT-PLAN-RT-TYP-ANBNR    TO TRUE.
           PERFORM PLRT-1000-READ
              THRU PLRT-1000-READ-X.

           IF  WPLRT-IO-OK
               SET WS-PLRT-ANBNR-EXIST    TO  TRUE
           END-IF.


           SET WPLRT-PLAN-RT-TYP-ANBDV    TO TRUE.
           PERFORM PLRT-1000-READ
              THRU PLRT-1000-READ-X.

           IF  WPLRT-IO-OK
               SET WS-PLRT-ANBDV-EXIST    TO  TRUE
           END-IF.
      *
       4600-CHECK-FOR-PLRT-RECS-X.
           EXIT.
      /
016016*----------------------------
016016 4610-CHECK-FOR-INT-PLRT-REC.
016016*----------------------------
016016*
016016* THIS PARAGRAPH IS FOR BONUS TYPE INTEREST
016016
016016     SET WS-PLRT-INTBN-NOT-EXIST    TO TRUE.
016016
016016     SET WPLRT-PLAN-RT-TYP-INTBN    TO TRUE.
016016     MOVE RPH-PLAN-ID               TO WPLRT-PLAN-ID.
016016
016016     PERFORM PLRT-1000-READ
016016        THRU PLRT-1000-READ-X.
016016
016016     IF  WPLRT-IO-OK
016016         SET WS-PLRT-INTBN-EXIST    TO TRUE
016016     END-IF.
016016*
016016 4610-CHECK-FOR-INT-PLRT-REC-X.
016016     EXIT.
016016/
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM 6110-BUILD-KEY
              THRU 6110-BUILD-KEY-X.

016016     IF WGLOB-RETURN-ERROR
016016        GO TO 5000-PROCESS-UPDATE-X
016016     END-IF.

016016*    IF WGLOB-GOOD-RETURN
016016*        PERFORM PLBN-1000-READ-FOR-UPDATE
016016*           THRU PLBN-1000-READ-FOR-UPDATE-X
016016*    END-IF.

016016     PERFORM PLBN-1000-READ
016016        THRU PLBN-1000-READ-X.

016016     IF WPLBN-IO-NOT-FOUND
016016*MSG: RECORD NOT FOUND
016016         MOVE 'XS00000001'  TO WGLOB-MSG-REF-INFO
016016         MOVE WPLBN-KEY     TO WGLOB-MSG-PARM (1)
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016         SET WGLOB-RETURN-ERROR TO TRUE
016016     END-IF.
      *
016016*    IF WGLOB-GOOD-RETURN
016016*        PERFORM PLBN-1000-READ-FOR-UPDATE
016016*           THRU PLBN-1000-READ-FOR-UPDATE-X
016016*        IF WPLBN-IO-NOT-FOUND
016016*MSG: RECORD NOT FOUND
016016*            MOVE 'XS00000001'  TO WGLOB-MSG-REF-INFO
016016*            MOVE WPLBN-KEY     TO WGLOB-MSG-PARM (1)
016016*            PERFORM 0260-1000-GENERATE-MESSAGE
016016*               THRU 0260-1000-GENERATE-MESSAGE-X
016016*            SET WGLOB-RETURN-ERROR TO TRUE
016016*        END-IF
016016*    END-IF.
      *
           IF WGLOB-RETURN-ERROR
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
               PERFORM 9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.
      *
016016     IF  MIR-PLAN-BON-TYP-VALID
016016         CONTINUE
016016     ELSE
016016*MSG: BONUS TYPE INVALID
016016         MOVE 'CS30700041'       TO WGLOB-MSG-REF-INFO
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016            IF  NOT WGLOB-MSG-SEVRTY-WARNING
016016                SET WGLOB-RETURN-ERROR TO TRUE
016016                GO TO 5000-PROCESS-UPDATE-X
016016            END-IF
016016     END-IF.
016016
016016* CANNOT UPDATE BONUS IF THE STATUS IS HISTORY
016016     IF  RPLBN-PLAN-BON-TYP-INT-BON
016016     AND RPLBN-PLAN-BON-STAT-HISTORY
016016*MSG: BONUS STATUS IS HISTORY - CANNOT UPDATE
016016         MOVE 'CS30700047'          TO WGLOB-MSG-REF-INFO
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016         IF  NOT WGLOB-MSG-SEVRTY-WARNING
016016             SET WGLOB-RETURN-ERROR TO TRUE
016016             PERFORM  9200-MOVE-RECORD-TO-SCREEN
016016                 THRU 9200-MOVE-RECORD-TO-SCREEN-X
016016             GO TO 5000-PROCESS-UPDATE-X
016016         END-IF
016016     END-IF.
016016
016016     PERFORM 5210-EDIT-EFF-DATE
016016        THRU 5210-EDIT-EFF-DATE-X.
016016
016016* READ AGAIN THE PLBN RECORD TO BE UPDATED BECAUSE DURING THE
016016* EDITS OF EFFECTIVE DATE A PREVIOUS PLBN MAY HAVE BEEN READ
016016     PERFORM 6110-BUILD-KEY
016016        THRU 6110-BUILD-KEY-X.
016016
016016     PERFORM PLBN-1000-READ-FOR-UPDATE
016016        THRU PLBN-1000-READ-FOR-UPDATE-X.
016016
016016     IF WPLBN-IO-NOT-FOUND
016016*MSG: RECORD NOT FOUND
016016         MOVE 'XS00000001'  TO WGLOB-MSG-REF-INFO
016016         MOVE WPLBN-KEY     TO WGLOB-MSG-PARM (1)
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
018763         PERFORM  PH-3000-UNLOCK
018763             THRU PH-3000-UNLOCK-X
016016         SET WGLOB-RETURN-ERROR TO TRUE
016016     END-IF.
016016
           PERFORM 5220-EDIT-STATUS
              THRU 5220-EDIT-STATUS-X.
      *
016016     IF WGLOB-MSG-ERROR-SW > ZERO
018763        PERFORM  PH-3000-UNLOCK
018763            THRU PH-3000-UNLOCK-X
016016         GO TO 5000-PROCESS-UPDATE-X
016016     END-IF.
016016
021682*    MOVE MIR-PLAN-BON-EFF-DT   TO L1640-EXTERNAL-DATE.
021682*
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
021682*    PERFORM 1640-7000-MIR-TO-INT
021682*       THRU 1640-7000-MIR-TO-INT-X.
021682*
021682*    MOVE L1640-INTERNAL-DATE      TO RPLBN-PLAN-BON-EFF-DT.
021682*
021682     IF  MIR-PLAN-BON-EFF-DT = SPACE
021682         MOVE WWKDT-ZERO-DT        TO RPLBN-PLAN-BON-EFF-DT
021682     ELSE
021682         MOVE MIR-PLAN-BON-EFF-DT  TO L1640-EXTERNAL-DATE
021682
021682         PERFORM  1640-7000-MIR-TO-INT
021682             THRU 1640-7000-MIR-TO-INT-X
021682
021682         MOVE L1640-INTERNAL-DATE  TO RPLBN-PLAN-BON-EFF-DT
021682     END-IF.
021682
016016     MOVE MIR-PLAN-BON-TYP-CD   TO RPLBN-PLAN-BON-TYP-CD.
016016
           PERFORM PLBN-2000-REWRITE
              THRU PLBN-2000-REWRITE-X.

014221     PERFORM PH-2000-REWRITE
014221        THRU PH-2000-REWRITE-X.
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X.

      *
           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               CONTINUE
           ELSE
      *MSG: MAINTENANCE COMPLETE
               MOVE 'CS30700015'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       5000-PROCESS-UPDATE-X.
           EXIT.
      /
016016*-------------------
016016 5210-EDIT-EFF-DATE.
016016*-------------------
016016* BONUS EFFECTIVE DATE SET TO LOW DATE FOR ANNUAL BONUS TYPE
016016     IF  MIR-PLAN-BON-TYP-ANN-BON
021682*        MOVE WWKDT-LOW-DT TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
021682*        PERFORM 1640-8000-INTERNAL-TO-MIR
021682*           THRU 1640-8000-INTERNAL-TO-MIR-X
021682*        MOVE L1640-EXTERNAL-DATE TO MIR-PLAN-BON-EFF-DT
021682         MOVE SPACE               TO MIR-PLAN-BON-EFF-DT
016016*MSG: BONUS EFFECTIVE DATE SET TO LOW DATE FOR ANNUAL BONUS TYPE
016016         MOVE 'CS30700043'      TO WGLOB-MSG-REF-INFO
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016     END-IF.
016016
016016* ALL OTHER BONUS DATE EDITS ARE ONLY FOR INTEREST BONUS TYPE
016016
016016     IF  MIR-PLAN-BON-TYP-INT-BON
016016     AND MIR-PLAN-BON-EFF-DT = SPACES
016016*MSG: BONUS EFFECTIVE DATE MUST BE ENTERED
016016         MOVE 'CS30700046'      TO WGLOB-MSG-REF-INFO
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016         IF  NOT WGLOB-MSG-SEVRTY-WARNING
016016             SET WGLOB-RETURN-ERROR  TO TRUE
016016             GO TO 5210-EDIT-EFF-DATE-X
016016         END-IF
016016     END-IF.
016016
016016* READ THE PREVIOUS PLBN SO THAT THE EFFECTIVE DATES CAN
016016* BE COMPARED
016016
016016     IF  MIR-PLAN-BON-TYP-INT-BON
016016         PERFORM 5215-EDIT-PREV-EFF-DATE
016016            THRU 5215-EDIT-PREV-EFF-DATE-X
016016     END-IF.
016016
016016 5210-EDIT-EFF-DATE-X.
016016     EXIT.
016016/
016016*------------------------
016016 5215-EDIT-PREV-EFF-DATE.
016016*------------------------
016016* STORE THE NEW EFFECTIVE DATE AS AN INVERTED DATE IN WORKING
016016* STORAGE SO THAT IT CAN BE USED IN A COMPARISON WITH THE
016016* PREVIOUS EFFECTIVE DATE
016016
016016     MOVE MIR-PLAN-BON-EFF-DT    TO L1640-EXTERNAL-DATE.
016016
016016     PERFORM 3540-EXTERNAL-TO-INVERTED
016016        THRU 3540-EXTERNAL-TO-INVERTED-X.
016016
016016     MOVE L1660-INVERTED-DATE    TO WS-NEW-EFF-DT-INV.
016016
016016     MOVE WPLBN-KEY              TO WPLBN-ENDBR-KEY.
016016     MOVE HIGH-VALUES            TO WPLBN-ENDBR-PLAN-BON-IDT-NUM.
016016
016016     PERFORM PLBN-1000-BROWSE
016016        THRU PLBN-1000-BROWSE-X.
016016
016016* THIS BROWSE WILL READ THE PLBN WHICH IS TO BE EDITED
016016     PERFORM PLBN-2000-READ-NEXT
016016        THRU PLBN-2000-READ-NEXT-X.
016016
018763     MOVE SPACE                  TO RPLBN-PLAN-BON-TYP-CD.
018763
016016* THIS BROWSE WILL READ THE PREVIOUS PLBN
016016     PERFORM PLBN-2000-READ-NEXT
016016        THRU PLBN-2000-READ-NEXT-X
018763*    WITH TEST AFTER
016016     UNTIL NOT WPLBN-IO-OK
016016            OR WPLBN-IO-EOF
016016            OR RPLBN-PLAN-BON-TYP-INT-BON.
016016
016016     IF  WPLBN-IO-OK
016016         CONTINUE
016016     ELSE
016016* THERE IS NO PREVIOUS PLBN
016016         PERFORM PLBN-3000-END-BROWSE
016016            THRU PLBN-3000-END-BROWSE-X
016016         GO TO 5215-EDIT-PREV-EFF-DATE-X
016016     END-IF.
016016
016016* STORE THE PREVIOUS EFFECTIVE DATE IN WORKING STORAGE
016016     MOVE RPLBN-PLAN-BON-EFF-DT  TO L1660-INTERNAL-DATE.
016016
016016     PERFORM 1660-2000-CONVERT-INT-TO-INV
016016        THRU 1660-2000-CONVERT-INT-TO-INV-X.
016016
016016     MOVE L1660-INVERTED-DATE    TO WS-PREV-EFF-DT-INV.
016016
016016* COMPARE THE EFFECTIVE DATE TO THE PREVIOUS EFFECTIVE DATE
016016*
016016* FIRSTLY - IT CANNOT BE EARLIER
016016     IF  WS-PREV-EFF-DT-INV NOT > WS-NEW-EFF-DT-INV
016016*MSG: BONUS EFFECTIVE DATE CANNOT BE EARLIER THAN
016016*     LAST EFFECTIVE DATE
016016         MOVE 'CS30700044'      TO WGLOB-MSG-REF-INFO
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016         IF  NOT WGLOB-MSG-SEVRTY-WARNING
016016             PERFORM PLBN-3000-END-BROWSE
016016                THRU PLBN-3000-END-BROWSE-X
016016             SET WGLOB-RETURN-ERROR  TO TRUE
016016             GO TO 5215-EDIT-PREV-EFF-DATE-X
016016         END-IF
016016     END-IF.
016016
016016* SECONDLY - GIVE A WARNING IF IT IS LESS THAN 30 DAYS
016016* AFTER THE PREVIOUS EFFECTIVE DATE
016016     MOVE RPLBN-PLAN-BON-EFF-DT  TO L1680-INTERNAL-1.
016016
016016     MOVE MIR-PLAN-BON-EFF-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
016016     MOVE L1640-INTERNAL-DATE    TO L1680-INTERNAL-2.
016016
016016     PERFORM 1680-2000-COMP-DAYS-BETWEEN
016016        THRU 1680-2000-COMP-DAYS-BETWEEN-X.
016016
016016     IF  L1680-TOTAL-DAYS < 30
016016*MSG: WARNING - BONUS EFFECTIVE DATE LESS THAN ONE MONTH FROM
016016*     LAST EFFECTIVE DATE
016016         MOVE 'CS30700045'      TO WGLOB-MSG-REF-INFO
016016         PERFORM 0260-1000-GENERATE-MESSAGE
016016            THRU 0260-1000-GENERATE-MESSAGE-X
016016     END-IF.
016016
016016     PERFORM PLBN-3000-END-BROWSE
016016        THRU PLBN-3000-END-BROWSE-X.
016016
016016 5215-EDIT-PREV-EFF-DATE-X.
016016     EXIT.
016016/
      *-----------------
       5220-EDIT-STATUS.
      *-----------------
      *
           IF MIR-PLAN-BON-STAT-CD = SPACE
               MOVE RPLBN-PLAN-BON-STAT-CD
                                      TO MIR-PLAN-BON-STAT-CD
               GO TO 5220-EDIT-STATUS-X
           END-IF.
      *
           IF MIR-PLAN-BON-STAT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO WS-STAT-CD
           ELSE
               MOVE MIR-PLAN-BON-STAT-CD
                                      TO WS-STAT-CD
           END-IF.
      *
           IF WS-STAT-VALID
               MOVE WS-STAT-CD        TO RPLBN-PLAN-BON-STAT-CD
           ELSE
               MOVE 'CS30700017'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       5220-EDIT-STATUS-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM 6110-BUILD-KEY
              THRU 6110-BUILD-KEY-X.
      *
           IF WGLOB-GOOD-RETURN
               PERFORM PLBN-1000-READ-FOR-UPDATE
                  THRU PLBN-1000-READ-FOR-UPDATE-X
           ELSE
               PERFORM  PH-3000-UNLOCK
                   THRU PH-3000-UNLOCK-X
018763         SET WGLOB-RETURN-ERROR    TO TRUE
018763         GO TO 6000-PROCESS-DELETE-X
           END-IF.


           IF WPLBN-IO-NOT-FOUND
      *MSG: RECORD LOST IN DELETE
              MOVE 'CS30700020'  TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR TO TRUE
014221        PERFORM  PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
018763        GO TO 6000-PROCESS-DELETE-X
018763     END-IF.

016016* CANNOT DELETE BONUS IF THE STATUS IS HISTORY
016016     IF  RPLBN-PLAN-BON-STAT-HISTORY
016016*MSG: BONUS STATUS IS HISTORY - CANNOT DELETE
016016         MOVE 'CS30700048'     TO WGLOB-MSG-REF-INFO
016016         PERFORM  0260-1000-GENERATE-MESSAGE
016016             THRU 0260-1000-GENERATE-MESSAGE-X
018763         PERFORM  PH-3000-UNLOCK
018763             THRU PH-3000-UNLOCK-X
016016         PERFORM  9200-MOVE-RECORD-TO-SCREEN
016016             THRU 9200-MOVE-RECORD-TO-SCREEN-X
016016         GO TO 6000-PROCESS-DELETE-X
016016     END-IF.
           PERFORM PLBN-1000-DELETE
              THRU PLBN-1000-DELETE-X.

014221     PERFORM PH-2000-REWRITE
014221        THRU PH-2000-REWRITE-X.
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X.

      *MSG: RECORD DELETED
           MOVE 'CS30700021'  TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.
      *
           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.
      *
       6000-PROCESS-DELETE-X.
           EXIT.
      *
      *---------------
       6110-BUILD-KEY.
      *---------------
      *
           MOVE MIR-PLAN-ID           TO WPLBN-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WPLBN-SBSDRY-CO-ID.
      *
           IF MIR-PLAN-BON-IDT-NUM = SPACE
               MOVE ZERO              TO WPLBN-PLAN-BON-IDT-NUM
           ELSE
               MOVE MIR-PLAN-BON-IDT-NUM
                                      TO L1640-EXTERNAL-DATE
               PERFORM 3540-EXTERNAL-TO-INVERTED
                  THRU 3540-EXTERNAL-TO-INVERTED-X
               IF NOT WGLOB-RETURN-ERROR
                   MOVE L1660-INVERTED-DATE
                                      TO WPLBN-PLAN-BON-IDT-NUM
               END-IF
           END-IF.
      *
       6110-BUILD-KEY-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      *
           IF WS-BUS-FCN-LIST
           OR WS-BUS-FCN-LIST-DATE
               MOVE SPACE             TO MIR-PLAN-ID-G
               MOVE SPACE             TO MIR-SBSDRY-CO-ID-G
               MOVE SPACE             TO MIR-PLAN-BON-IDT-NUM-G
               MOVE SPACE             TO MIR-PLAN-INS-TYP-CD
016016         MOVE SPACE             TO MIR-PLAN-BON-TYP-CD-G
           ELSE
               MOVE SPACE             TO MIR-PLAN-BON-STAT-CD
016016         MOVE SPACE             TO MIR-PLAN-BON-EFF-DT
           END-IF.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *
           MOVE RPLBN-PLAN-BON-STAT-CD       TO MIR-PLAN-BON-STAT-CD.
016016     MOVE RPLBN-PLAN-BON-EFF-DT        TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
016016     MOVE L1640-EXTERNAL-DATE          TO MIR-PLAN-BON-EFF-DT.
016016     MOVE RPLBN-PLAN-BON-TYP-CD        TO MIR-PLAN-BON-TYP-CD.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET WS-TRANS-NAME-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.

       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014660*COPY XCPPMEXT.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
016016 COPY XCPL1680.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
014221/
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPAPLBN.
       COPY CCPBPLBN.
       COPY CCPNPLBN.
       COPY CCPUPLBN.
       COPY CCPXPLBN.
       COPY CCPCPLBN.
      /
       COPY CCPBPLBS.
      /
       COPY CCPNPD.
      /
       COPY CCPNPLRT.
      /
       COPY CCPBPH.
       COPY CCPNPH.
014221 COPY CCPUPH.
      /
       COPY CCPNSCOM.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
016537*COPY XCCPHNDL.
       COPY XCCP0030.
023118
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3070                     *
      ****************************************************************
