      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8001.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8001                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE CREATE FUNCTION OF      **
      **            POLICY INFORMATION                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       ORIGINAL - NEW FOR RELEASE 6.0                   **
014660**  6.0       MESSAGE SUPPORT                                  **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
026839**  6.7       LOST RECORD(WPOL)IN MAINTAIN ERR WITH PLAN EXP DT**
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
029049**  7.1       CREATE  EXISTING POLICY WITH CONTRACTUAL PAYOUT  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8001'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
028298 COPY CCWL2626.
       COPY XCWL8090.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-CREATE       VALUE '8001'.
016440     05  WS-DV-JET-CREATE-IND        PIC X(01).
016440         88 WS-DV-JET-CREATE-YES     VALUE 'Y'.

018633*01  WS-TWRK-KEY                     PIC X(04)  VALUE '8000'.
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '8000'.
018633      15  FILLER                     PIC X(01).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY CCWWFRMT.
016537*COPY XCWEBLCH.
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      /
       COPY CCWLPGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
       COPY CCWL8240.
      /
       COPY NCWL5740.
      /
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8001.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*              TO WS-BUS-FCN-ID.
025970*    MOVE MIR-DV-JET-CREAT-IND
025970*              TO WS-DV-JET-CREATE-IND.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8001'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST     TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-CREATE.
      *------------

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  MIR-POL-ID    = SPACES
               PERFORM  2100-ASSIGN
                   THRU 2100-ASSIGN-X
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF WPOL-IO-OK
      *MSG: RECORD (@1) ALREADY EXISTS
               MOVE 'XS00000003'     TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
029049         SET  MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  8240-1000-BUILD-PARM-INFO
               THRU 8240-1000-BUILD-PARM-INFO-X.
           MOVE WPOL-POL-ID          TO L8240-POL-ID.
           PERFORM  8240-1000-RETRIEVE-POLW
               THRU 8240-1000-RETRIEVE-POLW-X.

           PERFORM  5740-1000-BUILD-PARM-INFO
               THRU 5740-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID-BASE     TO L5740-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX      TO L5740-POL-ID-SFX.

           PERFORM  2200-MOVE-MIR-TO-L5740
               THRU 2200-MOVE-MIR-TO-L5740-X.

016440     IF WS-DV-JET-CREATE-YES
016440        SET L5740-BYPASS-PACK TO TRUE
016440     END-IF.

           PERFORM  5740-1000-CREATE-POLICY
               THRU 5740-1000-CREATE-POLICY-X.

026839     IF  L5740-RETRN-PLAN-ERROR
026839         MOVE 'CS80010002'       TO WGLOB-MSG-REF-INFO
026839         PERFORM  0260-1000-GENERATE-MESSAGE
026839             THRU 0260-1000-GENERATE-MESSAGE-X
026839     END-IF.
026839
           IF  NOT L5740-RETRN-OK
               GO TO 2000-CREATE-X
           END-IF.

016440*    IF  MIR-POL-APPL-CTL-CD = 'NB'
016440*    AND MIR-POL-APP-SIGN-DT NOT = SPACES
016440     IF  MIR-POL-APP-SIGN-DT NOT = SPACES
               PERFORM  2230-UPDATE-APP-SIGN-DT
                   THRU 2230-UPDATE-APP-SIGN-DT-X
014221     ELSE
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
           END-IF.

           SET MIR-RETRN-OK          TO TRUE.
      *MSG: RECORD CREATED - CONTINUE
           MOVE 'XS00000004'         TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2000-CREATE-X.
           EXIT.
      /
      *------------
       2100-ASSIGN.
      *------------

           PERFORM  5740-1000-BUILD-PARM-INFO
               THRU 5740-1000-BUILD-PARM-INFO-X.

           PERFORM  2200-MOVE-MIR-TO-L5740
               THRU 2200-MOVE-MIR-TO-L5740-X.

           PERFORM  5740-2000-ASSGN-CRT-POLICY
               THRU 5740-2000-ASSGN-CRT-POLICY-X.

           IF  NOT L5740-RETRN-OK
               IF L5740-RETRN-ASSGN-INVALID
      *MSG:       POLICY NUMBER NOT ASSIGNED
                  MOVE 'CS80010001'     TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
026839         IF L5740-RETRN-PLAN-ERROR
026839            MOVE 'CS80010002'       TO WGLOB-MSG-REF-INFO
026839            PERFORM  0260-1000-GENERATE-MESSAGE
026839                THRU 0260-1000-GENERATE-MESSAGE-X
026839         END-IF
               GO TO 2100-ASSIGN-X
           END-IF.

           MOVE L5740-POL-ID-BASE    TO MIR-POL-ID-BASE.
           MOVE L5740-POL-ID-SFX     TO MIR-POL-ID-SFX.

016440*    IF  MIR-POL-APPL-CTL-CD = 'NB'
016440*    AND MIR-POL-APP-SIGN-DT NOT = SPACES
016440     IF  MIR-POL-APP-SIGN-DT NOT = SPACES
               PERFORM  2230-UPDATE-APP-SIGN-DT
                   THRU 2230-UPDATE-APP-SIGN-DT-X
           END-IF.

           SET MIR-RETRN-OK          TO TRUE.
      *MSG: RECORD CREATED - CONTINUE
           MOVE 'XS00000004'         TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2100-ASSIGN-X.
           EXIT.
      /
      *-----------------------
       2200-MOVE-MIR-TO-L5740.
      *-----------------------

           MOVE MIR-PLAN-ID               TO L5740-PLAN-ID.
           MOVE MIR-APP-FORM-TYP-ID       TO L5740-APP-FORM-TYP-ID.
           MOVE MIR-POL-ISS-LOC-CD        TO L5740-ISS-LOC-CD.
           MOVE MIR-SBSDRY-CO-ID          TO L5740-SBSDRY-CO-ID.
           MOVE 'N'                       TO L5740-UNMTCH-MAIL-IND.
016440*    MOVE MIR-POL-APPL-CTL-CD       TO L5740-POL-APPL-CTL-CD.

016440*    EVALUATE TRUE

016440*       WHEN L5740-POL-APPL-CTL-CD = 'NB'
016440*            PERFORM  2210-MOVE-APP-SIGN-DATE
016440*                THRU 2210-MOVE-APP-SIGN-DATE-X
016440*
016440*       WHEN L5740-POL-APPL-CTL-CD = 'AD'
016440*            PERFORM  2220-MOVE-ISS-EFF-DATE
016440*                THRU 2220-MOVE-ISS-EFF-DATE-X
016440*
016440*    END-EVALUATE.

016440     PERFORM  2205-MOVE-APP-RECV-DATE
016440         THRU 2205-MOVE-APP-RECV-DATE-X.

016440     PERFORM  2210-MOVE-APP-SIGN-DATE
016440         THRU 2210-MOVE-APP-SIGN-DATE-X.

           IF L5740-EFF-DT = SPACES
              MOVE WGLOB-PROCESS-DATE   TO L5740-EFF-DT
           END-IF.

       2200-MOVE-MIR-TO-L5740-X.
           EXIT.
      /
016440*-----------------------
016440 2205-MOVE-APP-RECV-DATE.
016440*-----------------------
016440
016440     IF MIR-POL-APP-RECV-DT NOT = SPACES
016440        MOVE MIR-POL-APP-RECV-DT  TO L1640-EXTERNAL-DATE
020462*       PERFORM 1640-3000-EXTERNAL-TO-INT
020462*          THRU 1640-3000-EXTERNAL-TO-INT-X
020462        PERFORM 1640-7000-MIR-TO-INT
020462           THRU 1640-7000-MIR-TO-INT-X
016440        IF L1640-RETRN-OK
016440           MOVE L1640-INTERNAL-DATE TO L5740-EFF-DT
016440        END-IF
016440     END-IF.
016440
016440 2205-MOVE-APP-RECV-DATE-X.
016440     EXIT.
016440/
      *-----------------------
       2210-MOVE-APP-SIGN-DATE.
      *-----------------------

           IF MIR-POL-APP-SIGN-DT NOT = SPACES
              MOVE MIR-POL-APP-SIGN-DT  TO L1640-EXTERNAL-DATE
020462*       PERFORM  1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462        PERFORM 1640-7000-MIR-TO-INT
020462           THRU 1640-7000-MIR-TO-INT-X
              IF L1640-RETRN-OK
                 MOVE L1640-INTERNAL-DATE TO L5740-EFF-DT
              END-IF
           END-IF.

       2210-MOVE-APP-SIGN-DATE-X.
           EXIT.

016440*----------------------
016440*2220-MOVE-ISS-EFF-DATE.
016440*----------------------
016440*
016440*    IF MIR-POL-ISS-EFF-DT NOT = SPACES
016440*       MOVE MIR-POL-ISS-EFF-DT  TO L1640-EXTERNAL-DATE
016440*       PERFORM  1640-3000-EXTERNAL-TO-INT
016440*           THRU 1640-3000-EXTERNAL-TO-INT-X
016440*       IF L1640-RETRN-OK
016440*          MOVE L1640-INTERNAL-DATE TO L5740-EFF-DT
016440*       END-IF
016440*    END-IF.
016440*
016440*2220-MOVE-ISS-EFF-DATE-X.
016440*    EXIT.

      *-----------------------
       2230-UPDATE-APP-SIGN-DT.
      *-----------------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE MIR-POL-APP-SIGN-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-RETRN-OK
               MOVE L1640-INTERNAL-DATE TO RPOL-POL-APP-SIGN-DT
           END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       2230-UPDATE-APP-SIGN-DT-X.
           EXIT.


      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE MIR-POL-ID-BASE     TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX      TO WPOL-POL-ID-SFX.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
      *
      * FOR POLICY RELATED TRANSACTION
      *
           SET  WGLOB-REF-POLICY          TO TRUE.

           MOVE MIR-POL-ID-BASE           TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  5740-0000-INIT-PARM-INFO
025970         THRU 5740-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8240-0000-INIT-PARM-INFO
025970         THRU 8240-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.
025970     MOVE MIR-DV-JET-CREAT-IND   TO WS-DV-JET-CREATE-IND.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
018633*--------------------
018633*9500-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*    MOVE WS-TWRK-KEY               TO  L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                     TO  L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM          TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9900-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY CCPSPGA.
       COPY CCPS8240.
      /
       COPY NCPS5740.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
018764*COPY CCCL8240.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL8240.
      /
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      /
018764*COPY NCCL5740.
018764 COPY NCPL5740.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM8001                     **
      *****************************************************************
