      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. SSOM1731.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1731                                         **
      **  REMARKS:  FINQ - SEG FUND SYSTEM - FUND ACTIVITY SCREEN.   **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016679**  6.2       DESCRIPTION                                      **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018972**  6.3       PCR FOR IIAB PLATFORM                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
023257**  6.4       WORKING STORAGE INITIALIZATION                   **
022673**  6.5       ADVANCE LIST OF ACTIVITIES WITH MORE BUTTON      **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1731'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                        PIC X(04).
               88  WS-BUS-FCN-ACTV                  VALUE '1731'.
           05  WS-SUB                               PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES                    PIC S9(04) BINARY
025970*                                             VALUE 20.
       01  GENERAL-WORK-AREA.
           03  WS-ACB-TOT                        PIC S9(15)V99  COMP-3.
           03  WS-SIGN6-G.
               05  WS-SIGN6-T                    OCCURS  139
                                                 PIC X(01).
           03  HOLD-EFFDT                        PIC X(10).
           03  HOLD-SEQ                          PIC 9(3) VALUE 0.
           03  HOLD-SEQ-X  REDEFINES  HOLD-SEQ   PIC X(3).
           03  EFFDT-I                           PIC X(10).
025970*    03  L1                                PIC S9999 COMP VALUE 1.
025970     03  L1                                PIC S9999 BINARY.
025970         88  L1-DEFAULT                    VALUE 1.
           03  OUTPUT-LINE                       PIC X(79).
           03  EDIT-999                          PIC 999.
           03  NEW-SCREEN-SW                     PIC 9.
               88  NEW-SCREEN                    VALUE 1.
               88  OLD-SCREEN                    VALUE 0.

       01  KEY-WORK-AREAS.
025970*    03  WK-SEQ                    PIC 9(4) COMP.
025970     03  WK-SEQ                    PIC 9(4) BINARY.
           03  WK-NEXT-FUND              PIC X(5).
           03  WK-FS-HIGH-KEY.
               05  FILLER                PIC X(14).
               05  WK-FS-HIGH-FUND       PIC X(05).
           03  WK-FA-HIGH-KEY.
               05  FILLER                PIC X(14).
               05  WK-FA-HIGH-EFF-DT     PIC 9(7).
025970*        05  WK-FA-HIGH-SEQ-NUM    PIC S9(4)  COMP.
025970         05  WK-FA-HIGH-SEQ-NUM    PIC S9(4)  BINARY.
           03  WK-FD-HIGH-KEY.
               05  FILLER                PIC X(14).
               05  WK-FD-HIGH-FUND       PIC X(5).
               05  WK-FD-HIGH-DATE       PIC 9(7).
025970*        05  WK-FD-HIGH-SEQ        PIC 9(4)    COMP.
025970         05  WK-FD-HIGH-SEQ        PIC 9(4)    BINARY.
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
026057 COPY CCWWIHSD.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY SCFWFA.
       COPY SCFRFA.
      /
       COPY SCFWFC.
       COPY SCFRFC.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************

020478 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
018764*COPY XCWLPTR.
      /
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
       COPY XCWL0290.
      /
       COPY CCWL5400.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1731.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.
      *
      *  VALIDATE / CHECK POLICY ACCESS
      *
           PERFORM  2100-VALIDATE-POLICY
               THRU 2100-VALIDATE-POLICY-X.

           IF  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2400-EDIT-DATE-FIELD
               THRU 2400-EDIT-DATE-FIELD-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2500-NOW-GET-FUND
               THRU 2500-NOW-GET-FUND-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-ACTV
                    PERFORM  4000-PROCESS-LIST
                        THRU 4000-PROCESS-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM1731'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *---------------------
       2100-VALIDATE-POLICY.
      *---------------------

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2100-VALIDATE-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET  L5400-STAT-MSG-NOT-REQD TO TRUE.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  NOT L5400-RETRN-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       2100-VALIDATE-POLICY-X.
           EXIT.
      /

      *---------------------
       2400-EDIT-DATE-FIELD.
      *---------------------

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2400-EDIT-DATE-FIELD-X
           END-IF.

           MOVE HOLD-EFFDT            TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO EFFDT-I
               MOVE HOLD-EFFDT        TO MIR-CIA-EFF-DT
           ELSE
               MOVE WWKDT-ZERO-DT     TO EFFDT-I
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE EFFDT-I               TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.

       2400-EDIT-DATE-FIELD-X.
           EXIT.

      *------------------
       2500-NOW-GET-FUND.
      *------------------

           MOVE WPOL-POL-ID           TO WFC-POL-ID.
023257*    MOVE MIR-CVG-NUM           TO WFC-CVG-NUM-N.
023257*
023257     SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
023257     SET L0280-SPACES-PERMITTED     TO TRUE.
023257     MOVE ZERO                      TO L0280-PRECISION.
023257     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-LENGTH.
023257     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-INPUT-SIZE.
023257     MOVE MIR-CVG-NUM               TO L0280-INPUT-DATA.
023257
023257     PERFORM  0280-1000-NUMERIC-EDIT
023257         THRU 0280-1000-NUMERIC-EDIT-X.
023257
023257     IF  L0280-OK
023257         MOVE L0280-OUTPUT-V00      TO WFC-CVG-NUM-N
023257     ELSE
023257         MOVE ZERO                  TO WFC-CVG-NUM-N
023257     END-IF.
023257
           PERFORM  FC-1000-READ
               THRU FC-1000-READ-X.

           IF NOT WFC-IO-OK
               MOVE 'SS17310001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2500-NOW-GET-FUND-X.
           EXIT.
      *--------------------
       4000-PROCESS-LIST .
      *--------------------

018972     MOVE 1                     TO L1.

      * VALIDATE NUMERIC FORMAT OF SEQUENCE NUMBER

           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CIA-SEQ-NUM       TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO HOLD-SEQ-X
020874*        MOVE HOLD-SEQ-X        TO MIR-CIA-SEQ-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE 0                    TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CIA-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CIA-SEQ-NUM

022673*        COMPUTE WK-SEQ = 1000 - L0280-OUTPUT
022673         IF  MIR-CIA-TYP-CD NOT = SPACES
022673             MOVE L0280-OUTPUT  TO WK-SEQ
022673         ELSE
022673             COMPUTE  WK-SEQ
022673                   =  1000 - L0280-OUTPUT
022673         END-IF
           ELSE
               SET WGLOB-RETURN-ERROR       TO TRUE
      * MSG: SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'SS17310005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-LIST-X
           END-IF.

           IF EFFDT-I = WWKDT-ZERO-DT
               MOVE 'SS17310003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-LIST-X
           END-IF.

           MOVE EFFDT-I               TO L1660-INTERNAL-DATE.
           PERFORM 1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE   TO WFA-CIA-IDT-NUM-N.

           MOVE RFC-POL-ID            TO WFA-POL-ID.
           MOVE RFC-CVG-NUM-N         TO WFA-CVG-NUM-N.
           MOVE RFC-INV-CVG-STAT-CD   TO MIR-CFN-STAT-CD.

           IF WFA-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE TO WFA-CO-ID
           ELSE
               MOVE SPACES            TO WFA-CO-ID
           END-IF.

           MOVE WK-SEQ                TO WFA-CIA-SEQ-NUM.
           MOVE WFA-KEY               TO WK-FA-HIGH-KEY.
           MOVE 9999999               TO WK-FA-HIGH-EFF-DT.
           MOVE +999                  TO WK-FA-HIGH-SEQ-NUM.
           MOVE WK-FA-HIGH-KEY        TO WFA-ENDBR-KEY.

           PERFORM  FA-1000-BROWSE
               THRU FA-1000-BROWSE-X.

           IF WFA-IO-EOF
           AND WS-BUS-FCN-ACTV
               MOVE 'SS17310004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-LIST-X
           END-IF.

           PERFORM 4100-READ-NEXT-FA
               THRU 4100-READ-NEXT-FA-X
           UNTIL NOT WFA-IO-OK
              OR L1 > 50.

           PERFORM  FA-3000-END-BROWSE
               THRU FA-3000-END-BROWSE-X.

           IF  L1 = 1
           AND WS-BUS-FCN-ACTV
               MOVE 'SS17310004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

020874*    MOVE RFA-CIA-SEQ-NUM       TO HOLD-SEQ.
020874*    MOVE HOLD-SEQ-X            TO MIR-CIA-SEQ-NUM.
020874     MOVE RFA-CIA-SEQ-NUM       TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CIA-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CIA-SEQ-NUM.
           IF L1 NOT = 1
               MOVE 1                 TO NEW-SCREEN-SW
           END-IF.

       4000-PROCESS-LIST-X.
           EXIT.
      /
      *--------------------
       4100-READ-NEXT-FA.
      *---------------------

           PERFORM  FA-2000-READ-NEXT
               THRU FA-2000-READ-NEXT-X.

022673*    IF L1 > 50
022673     IF  L1 = 50
               COMPUTE WK-SEQ = 1000 - RFA-CIA-SEQ-NUM
020874*        MOVE WK-SEQ            TO EDIT-999
020874*        MOVE EDIT-999          TO MIR-CIA-SEQ-NUM
020874         MOVE WK-SEQ                TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CIA-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CIA-SEQ-NUM
               MOVE RFA-CIA-TYP-CD    TO MIR-CIA-TYP-CD
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RFA-CIA-EFF-DT    TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CIA-EFF-DT
022673         ADD +1                 TO L1
               GO TO 4100-READ-NEXT-FA-X
           END-IF.

           IF NOT WFA-IO-OK
              GO TO 4100-READ-NEXT-FA-X
           END-IF.

           MOVE RFA-CIA-EFF-DT        TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CIA-EFF-DT-T (L1).
           COMPUTE RFA-CIA-SEQ-NUM = 1000 - RFA-CIA-SEQ-NUM.
020874*    MOVE RFA-CIA-SEQ-NUM       TO EDIT-999.
020874*    MOVE EDIT-999              TO MIR-CIA-SEQ-NUM-T (L1).
020874     MOVE RFA-CIA-SEQ-NUM       TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CIA-SEQ-NUM-T (L1)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CIA-SEQ-NUM-T (L1).
           MOVE RFA-CIA-TYP-CD        TO MIR-CIA-TYP-CD-T (L1).
020469     MOVE RFA-CIA-CRCY-CD       TO MIR-CIA-CRCY-CD-T (L1).
020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CIA-CLI-TRXN-AMT * 100.
020874     MOVE RFA-CIA-CLI-TRXN-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-CLI-TRXN-AMT-T (L1)
                                      TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS     TO TRUE.
           SET L0290-SIGN-DISPLAY            TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-CLI-TRXN-AMT-T (L1).

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CIA-FND-TRXN-AMT * 100.
020874     MOVE RFA-CIA-FND-TRXN-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-FND-TRXN-AMT-T (L1)
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-FND-TRXN-AMT-T (L1).

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CIA-LOAD-AMT * 100.
020874     MOVE RFA-CIA-LOAD-AMT      TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT-T (L1)
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT-T (L1).

           MOVE RFA-CIA-REVRS-PRCES-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CIA-REVRS-PRCES-DT-T (L1).
           MOVE RFA-CIA-REVRS-REASN-CD TO MIR-CIA-REASN-CD-T (L1).
           PERFORM 4110-BOTH-PRINT
               THRU 4110-BOTH-PRINT-X.

           MOVE SPACES                TO OUTPUT-LINE.

       4100-READ-NEXT-FA-X.
           EXIT.
      /
      *----------------
       4110-BOTH-PRINT.
      *----------------
            IF  L1 < 51
                ADD 1          TO L1
            END-IF.

       4110-BOTH-PRINT-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES            TO WFC-KEY.
           MOVE MIR-CIA-EFF-DT        TO HOLD-EFFDT.
           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

            MOVE SPACES          TO  WS-SIGN6-G.
            MOVE SPACES          TO  MIR-CIA-EFF-DT-G.
            MOVE SPACES          TO  MIR-CIA-SEQ-NUM-G.
            MOVE SPACES          TO  MIR-CIA-TYP-CD-G.
            MOVE SPACES          TO  MIR-CIA-CLI-TRXN-AMT-G.
            MOVE SPACES          TO  MIR-CIA-FND-TRXN-AMT-G.
            MOVE SPACES          TO  MIR-CIA-LOAD-AMT-G.
            MOVE SPACES          TO  MIR-CIA-REVRS-PRCES-DT-G.
            MOVE SPACES          TO  MIR-CIA-REASN-CD-G.
020469      MOVE SPACES          TO  MIR-CIA-CRCY-CD-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE GENERAL-WORK-AREA.
025970     INITIALIZE KEY-WORK-AREAS.
025970     MOVE SPACE                      TO WWKDT-WORK-FIELDS.
025970
025970     SET L1-DEFAULT                  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
025970 COPY XCPS1670.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY XCPL0290.
       COPY XCPS0290.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
      /
       COPY SCPBFA.
      /
       COPY SCPNFC.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM SSOM1731
      *****************************************************************
