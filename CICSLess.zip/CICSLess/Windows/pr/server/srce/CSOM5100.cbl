      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5100.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5100                                         **
      **  REMARKS:  BENE - MAINTAIN BENEFICIARY INFORMATION (BENE)   **
      **            TABLE.                                           **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE FUNCTIONS **
      **            FOR THE BENEFICIARY INFORMATION (BENE) TABLE.    **
      **            BENEFICIARY DESIGNATIONS CAN BE ADDED AT THE     **
      **            POLICY OR COVERAGE LEVEL, AND CAN BE ON A NAME   **
      **            BASIS OR A CLIENT NUMBER BASIS (NOTE FOR THE     **
      **            LATTER A CLI ENTRY MUST EXIST ON THE SYSTEM.)    **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
555201**  5.5       GENERATE MESSAGES CC56000001 AND CC56000002      **
555201**            FOR INQUIRE AND MAINTAIN WHEN CLIENT IS IN       **
555201**            CONSOLIDATION.                                   **
557660**  5.5       CHANGE TO STANDARD                               **
557708**  5.5       ABEND HANDLING                                   **
010387**  5.5.2     VALIDATE ADDRESS TYPE AGAINST EDIT TABLE         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010310**  5.6       SQL I/O PERFORMANCE ENHANCEMENTS                 **
010311**  5.6       CODE CLEANUP - INITIALIZE PGA AREA               **
012624**  6.0       POLICY ACCESS VERIFICATION                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       VUL APPLICATION ENTRY                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL LOCKING                                  **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016387**  6.2       REMOVE CLIENT CONSOLIDATION (FUSE)               **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017657**  6.2       PCR - WRONG CVG-NUM ON RELA - BENEFICIARY        **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020477**  6.4       MINIMUM DISTRIBUTION RULES                       **
021620**  6.4       CODE CLEAN-UP AND STANDARDIZATION                **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
023025**  6.7       CLIENT ID DEFAULT ISSUE ON BENEFICIARY UPDATE    **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5100'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
      /
      /
014590*COPY XCWL0030.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY XCWTATRB.
      /
       COPY XCWEBLCH.
      /
       COPY CCWWINDX.
      /
014221 COPY CCWWLOCK.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4)  BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT  VALUE +12.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '1050'.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES       PIC S9(4)  VALUE +12 BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1050' THRU '1054'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1050'.
               88  WS-BUS-FCN-CREATE        VALUE '1051'.
               88  WS-BUS-FCN-UPDATE        VALUE '1052'.
               88  WS-BUS-FCN-DELETE        VALUE '1053'.
               88  WS-BUS-FCN-SEARCH        VALUE '1054'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1050'.
           05 WS-BENE-KEY-DISPLAY.
               10 WS-BENE-POL-ID-DISPLAY    PIC X(10).
               10 WS-BENE-SEQ-NUM-DISPLAY   PIC 9(03).
           05  WS-SEQ-NO                    PIC 9(03)  VALUE ZEROES.
           05  WS-PIC-9-3                   PIC 9(03).
           05  WS-PIC-Z-3                   PIC ZZ9.
           05  WS-TOTAL-DEPOSITS            PIC S9(11)V99  COMP-3.
           05  WS-BNFY-CONT-EXISTS-IND      PIC X(01).
               88  WS-BNFY-CONT-EXISTS-NO              VALUE 'N'.
               88  WS-BNFY-CONT-EXISTS                 VALUE 'Y'.
           05  WS-BNFY-PRIMARY-EXISTS-IND   PIC X(01).
               88  WS-BNFY-PRIMARY-EXISTS-NO           VALUE 'N'.
               88  WS-BNFY-PRIMARY-EXISTS              VALUE 'Y'.
           05  WS-BNFY-PERC-CONTINGENT      PIC 9(03).
               88  WS-BNFY-PERC-CONT-ZERO              VALUE ZEROES.
               88  WS-BNFY-PERC-CONT-100               VALUE 100.
           05  WS-BNFY-PERC-PRIMARY         PIC 9(03).
               88  WS-BNFY-PERC-PRIMARY-ZERO           VALUE ZEROES.
               88  WS-BNFY-PERC-PRIMARY-100            VALUE 100.
           05  WS-BNFY-PERC-ERROR-IND       PIC X(01).
               88  WS-BNFY-PERC-ERROR-NO               VALUE 'N'.
               88  WS-BNFY-PERC-ERROR                  VALUE 'Y'.
           05  WS-LOOP-CVG-NUM              PIC X(02).
           05  WS-DISP-CVG-NUM.
               10  WS-DISP-CVG-NUM-N        PIC 9(02).
           05  WS-DISP-SEQ-NUM.
               10  WS-DISP-SEQ-NUM-N        PIC 9(03).
           05  WS-OLD-VALUES.
               10  WS-OLD-CLI-ID            PIC X(10).
               10  WS-OLD-CVG-NO            PIC X(02).
023025     05  WS-BENE-VALUES.
023025         10  WS-CLI-ID                PIC X(10).
023025         10  WS-BNFY-NM               PIC X(54).               
020477     05  WS-DESGNT-BNFY-COUNT         PIC 9(03).
020477     05  WS-DESGNT-BNFY-SEQ-NUM       PIC 9(03).
026055     05  WS-POL-BNFY-XIST-IND         PIC X(01).
026055         88  WS-POL-BNFY-XIST         VALUE 'Y'.
026055         88  WS-POL-BNFY-XIST-NO      VALUE 'N'.

      /
      *****************************************************************
      *  LINKAGE COPYBOOKS                                            *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL0280.
020874 COPY XCWL0290.

      /
014221 COPY XCWL8090.
020477/
020477 COPY XCWL8960.
      /
       COPY CCWL0832.
      /
       COPY CCWL2435.
      /
       COPY CCWL2440.
      /
       COPY CCWL5120.
      /
       COPY CCWL5400.
      /
       COPY CCWL5600.
      /
016537*COPY CCWL5950.
016537*COPY CCWW5950.
      /
016503 COPY CCWL0289.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWBENC.
       COPY CCFWBENE.
       COPY CCFRBENE.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
      /
       COPY CCFWPOL.
      /
       COPY CCFWRL.
       COPY CCFRRL.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY CCWLPGA.
      /
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM5100.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      /
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------
       2000-PROCESS-REQUEST.
      *--------------------
020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.
           SET  MIR-RETRN-OK      TO TRUE.
           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

           IF MIR-CVG-NUM NOT = SPACES
               MOVE 'N'                TO L0280-SIGN-IND
               MOVE 0                  TO L0280-PRECISION
               MOVE 2                  TO L0280-LENGTH
               MOVE 2                  TO L0280-INPUT-SIZE
               MOVE MIR-CVG-NUM        TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
020874*            MOVE L0280-OUTPUT-V00 TO WS-DISP-CVG-NUM-N
020874*            MOVE WS-DISP-CVG-NUM  TO MIR-CVG-NUM
020874             MOVE L0280-OUTPUT-V00      TO L0290-INPUT-V00
020874             MOVE 0                     TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-CVG-NUM
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM
               END-IF
           END-IF.

014653     IF MIR-BNFY-SEQ-NUM = SPACE
014653        MOVE ZEROS          TO MIR-BNFY-SEQ-NUM
014653     END-IF.


015904*    SET MIR-UPDNM-ENABLE            TO TRUE.
015904*    SET MIR-BENNM-ENABLE            TO TRUE.
015904*    SET MIR-CLINO-ENABLE            TO TRUE.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
010311     PERFORM  PGA-1000-BUILD-PARMS
010311         THRU PGA-1000-BUILD-PARMS-X.


           IF WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  8000-CHECK-KEY-FIELDS
               THRU 8000-CHECK-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  NOT WGLOB-GOOD-RETURN
014221     OR  MIR-RETRN-TS-MISMATCH
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

016503     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF MIR-BNFY-SEQ-NUM NOT = SPACES
               MOVE 'N'                TO L0280-SIGN-IND
               MOVE 0                  TO L0280-PRECISION
               MOVE 3                  TO L0280-LENGTH
               MOVE 3                  TO L0280-INPUT-SIZE
               MOVE MIR-BNFY-SEQ-NUM          TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
020874*            MOVE L0280-OUTPUT-V00 TO WS-DISP-SEQ-NUM-N
020874*            MOVE WS-DISP-SEQ-NUM  TO MIR-BNFY-SEQ-NUM
020874             MOVE L0280-OUTPUT-V00      TO L0290-INPUT-V00
020874             MOVE 0                     TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-BNFY-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-BNFY-SEQ-NUM
               END-IF
           END-IF.

           IF  WS-BUS-FCN-RETRIEVE
           OR  WS-BUS-FCN-UPDATE
           OR  WS-BUS-FCN-DELETE
               MOVE MIR-POL-ID-BASE         TO WBENE-POL-ID-BASE
               MOVE MIR-POL-ID-SFX          TO WBENE-POL-ID-SFX
               MOVE MIR-BNFY-SEQ-NUM        TO WBENE-BNFY-SEQ-NUM
               MOVE WBENE-POL-ID            TO WS-BENE-POL-ID-DISPLAY
               MOVE WBENE-BNFY-SEQ-NUM      TO WS-BENE-SEQ-NUM-DISPLAY
               PERFORM  BENE-1000-READ
                   THRU BENE-1000-READ-X
               IF WBENE-IO-NOT-FOUND
                   PERFORM  9100-BLANK-DATA-FIELDS
                       THRU 9100-BLANK-DATA-FIELDS-X
      *MSG:       'RECORD @1 NOT FOUND'
                   MOVE WS-BENE-KEY-DISPLAY TO WGLOB-MSG-PARM (1)
                   MOVE 'XS00000001'        TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-PROCESS-REQUEST-X
               END-IF
           END-IF.

013578*    IF MIR-CVG-NUM > SPACES
013578*        IF  WS-BUS-FCN-RETRIEVE
013578*        OR  WS-BUS-FCN-CREATE
013578*        OR  WS-BUS-FCN-UPDATE
013578*        OR  WS-BUS-FCN-DELETE
013578*MSG:    'CVG # @1 WILL BE IGNORED FOR I,C,M & D ENTER CODES'
013578*            MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
013578*            MOVE 'CS51000030'       TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            MOVE SPACES             TO MIR-CVG-NUM
013578*        END-IF
013578*    END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-SEARCH
                   PERFORM  3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

026055     IF  WS-POL-BNFY-XIST-IND NOT = SPACE
026055         MOVE WS-POL-BNFY-XIST-IND   TO MIR-DV-POL-BNFY-XIST-IND
026055     END-IF.

015904*    SET MIR-UPDNM-ENABLE            TO TRUE.
015904*    SET MIR-BENNM-ENABLE            TO TRUE.
015904*    SET MIR-CLINO-ENABLE            TO TRUE.

015904*    IF MIR-POL-ID-BASE > SPACES
015904*        IF  MIR-BNFY-NM = SPACES
015904*        AND MIR-CLI-ID = SPACES
015904*            CONTINUE
015904*        ELSE
015904*            IF  MIR-CLI-ID NOT = SPACES
015904*                SET MIR-BENNM-DISABLE TO TRUE
015904*            ELSE
015904*                SET MIR-UPDNM-DISABLE TO TRUE
015904*                SET MIR-CLINO-DISABLE TO TRUE
015904*            END-IF
015904*        END-IF
015904*    END-IF.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *---------------------
       3000-PROCESS-RETRIEVE.
      *---------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.


014653*    IF RPOL-POL-BNFY-PCT-NOT-100
014653*MSG:   'BENEFICIARY PERCENTS DO NOT TOTAL 100%'
014653*        MOVE 'CS51000001'           TO WGLOB-MSG-REF-INFO
014653*        PERFORM  0260-1000-GENERATE-MESSAGE
014653*            THRU 0260-1000-GENERATE-MESSAGE-X
014653*    END-IF.

           IF RBENE-CLI-ID > SPACES
016387*        PERFORM  7000-CLI-CNSLDT-CHECK
016387*            THRU 7000-CLI-CNSLDT-CHECK-X
023025         MOVE RBENE-CLI-ID           TO WS-CLI-ID
023025         MOVE RBENE-BNFY-NM          TO WS-BNFY-NM
016387         PERFORM  7000-CLI-ACCESS-CHECK
016387             THRU 7000-CLI-ACCESS-CHECK-X
               PERFORM  7100-CLI-ID-NAME-CHECK
                   THRU 7100-CLI-ID-NAME-CHECK-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *-----------------
       3500-PROCESS-LIST.
      *-----------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE +1                         TO WS-SUB.

           IF MIR-CVG-NUM = SPACES
           OR MIR-CVG-NUM = ZEROES
               PERFORM  3520-POL-CVG-BROWSE
                   THRU 3520-POL-CVG-BROWSE-X
           ELSE
               PERFORM  3560-CVG-BROWSE
                   THRU 3560-CVG-BROWSE-X
           END-IF.

       3500-PROCESS-LIST-X.
           EXIT.


      *--------------------
       3520-POL-CVG-BROWSE.
      *--------------------

           MOVE LOW-VALUES             TO WBENE-KEY.
           MOVE MIR-POL-ID-BASE        TO WBENE-POL-ID-BASE
           MOVE MIR-POL-ID-SFX         TO WBENE-POL-ID-SFX
           MOVE MIR-BNFY-SEQ-NUM       TO WBENE-BNFY-SEQ-NUM.
           MOVE WBENE-KEY              TO WBENE-ENDBR-KEY.
           MOVE '999'                  TO WBENE-ENDBR-BNFY-SEQ-NUM.

           PERFORM  BENE-1000-BROWSE
               THRU BENE-1000-BROWSE-X.

           IF WBENE-IO-EOF
      *MSG:   'NO RECORDS FOUND TO DISPLAY'
026055*       MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
026055        MOVE 'CS51000036'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
026055        SET WS-POL-BNFY-XIST-NO TO TRUE
              GO TO 3520-POL-CVG-BROWSE-X
           END-IF.

           PERFORM  BENE-2000-READ-NEXT
               THRU BENE-2000-READ-NEXT-X.

           IF WBENE-IO-EOF
              PERFORM  BENE-3000-END-BROWSE
                  THRU BENE-3000-END-BROWSE-X
      *MSG:   'NO RECORDS FOUND TO DISPLAY'
026055*       MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
026055        MOVE 'CS51000036'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
026055        SET WS-POL-BNFY-XIST-NO TO TRUE
              GO TO 3520-POL-CVG-BROWSE-X
           END-IF.

           PERFORM  3535-POL-BENE-BROWSE-READ
               THRU 3535-POL-BENE-BROWSE-READ-X
              UNTIL WS-SUB > WS-MAX-BROWSE-LINES
                 OR WBENE-IO-EOF.

           PERFORM  3540-POL-BENE-BROWSE-FINISH
               THRU 3540-POL-BENE-BROWSE-FINISH-X.

       3520-POL-CVG-BROWSE-X.
           EXIT.
      /
      *--------------------------
       3535-POL-BENE-BROWSE-READ.
      *--------------------------

           IF RBENE-CVG-NUM = ZEROES
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               ADD 1                       TO WS-SUB
           END-IF.

           PERFORM  BENE-2000-READ-NEXT
               THRU BENE-2000-READ-NEXT-X.

       3535-POL-BENE-BROWSE-READ-X.
           EXIT.
      /
      *----------------------------
       3540-POL-BENE-BROWSE-FINISH.
      *----------------------------

           IF WBENE-IO-EOF
      *MSG:   'END OF LIST'
              MOVE 'XS00000015'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
              PERFORM  BENE-2000-READ-NEXT
                  THRU BENE-2000-READ-NEXT-X
                 UNTIL RBENE-CVG-NUM = ZEROES
                    OR WBENE-IO-EOF
              IF WBENE-IO-OK
                 MOVE RBENE-BNFY-SEQ-NUM  TO MIR-BNFY-SEQ-NUM
                 SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG:        '** TO VIEW MORE DATA PRESS ENTER **'
                 MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
              ELSE
      *MSG:    'END OF LIST'
                 MOVE 'XS00000015'   TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
557660        END-IF
           END-IF.

026055     IF  WS-POL-BNFY-XIST-IND = SPACE
026055         SET  WS-POL-BNFY-XIST-NO   TO TRUE
026055     END-IF.

           PERFORM  BENE-3000-END-BROWSE
               THRU BENE-3000-END-BROWSE-X.

       3540-POL-BENE-BROWSE-FINISH-X.
           EXIT.
      /
      *----------------
       3560-CVG-BROWSE.
      *----------------

           MOVE LOW-VALUES                 TO WBENC-KEY.
           MOVE MIR-POL-ID-BASE            TO WBENC-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WBENC-POL-ID-SFX.
           MOVE MIR-CVG-NUM                TO WBENC-CVG-NUM.
           MOVE MIR-BNFY-SEQ-NUM           TO WBENC-BNFY-SEQ-NUM.
           MOVE WBENC-KEY                  TO WBENC-ENDBR-KEY.
           MOVE '999'                      TO WBENC-ENDBR-BNFY-SEQ-NUM.

           PERFORM  BENC-1000-BROWSE
               THRU BENC-1000-BROWSE-X.

           IF WBENC-IO-EOF
      *MSG:   'NO RECORDS FOUND TO DISPLAY'
026055*       MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
026055        MOVE 'CS51000036'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
026055        SET WS-POL-BNFY-XIST-NO TO TRUE
              GO TO 3560-CVG-BROWSE-X
           END-IF.

           PERFORM  BENC-2000-READ-NEXT
               THRU BENC-2000-READ-NEXT-X.

           IF WBENC-IO-EOF
              PERFORM  BENC-3000-END-BROWSE
                  THRU BENC-3000-END-BROWSE-X
      *MSG:  'NO RECORDS FOUND TO DISPLAY'
026055*       MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
026055        MOVE 'CS51000036'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
026055        SET WS-POL-BNFY-XIST-NO TO TRUE
              GO TO 3560-CVG-BROWSE-X
           END-IF.

           PERFORM  3580-CVG-BENC-BROWSE-READ
               THRU 3580-CVG-BENC-BROWSE-READ-X
               VARYING WS-SUB FROM 1 BY +1
                 UNTIL WS-SUB > WS-MAX-BROWSE-LINES
                    OR WBENC-IO-EOF.

           PERFORM  3590-CVG-BENC-BROWSE-FINISH
               THRU 3590-CVG-BENC-BROWSE-FINISH-X.

       3560-CVG-BROWSE-X.
           EXIT.
      /

      *--------------------------
       3580-CVG-BENC-BROWSE-READ.
      *--------------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  BENC-2000-READ-NEXT
               THRU BENC-2000-READ-NEXT-X.

       3580-CVG-BENC-BROWSE-READ-X.
           EXIT.
      /
      *----------------------------
       3590-CVG-BENC-BROWSE-FINISH.
      *----------------------------

           IF WBENC-IO-EOF
      *MSG:    'END OF LIST'
               MOVE 'XS00000015'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RBENE-CVG-NUM        TO  MIR-CVG-NUM
               MOVE RBENE-BNFY-SEQ-NUM   TO  MIR-BNFY-SEQ-NUM
      *MSG:    '** TO VIEW MORE DATA PRESS ENTER **'
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  BENC-3000-END-BROWSE
               THRU BENC-3000-END-BROWSE-X.

       3590-CVG-BENC-BROWSE-FINISH-X.
           EXIT.
      /
      *-------------------
       4000-PROCESS-CREATE.
      *--------------------

      *MSG:  'SEQ AUTOMATICALLY ASSIGNED ON RECORD CREATION'
           MOVE 'CS51000002'               TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE ZEROES                     TO WS-SEQ-NO.

           MOVE MIR-POL-ID-BASE            TO WBENE-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WBENE-POL-ID-SFX.
010310*    MOVE '999'                      TO WBENE-BNFY-SEQ-NUM.
010310     MOVE '001'                      TO WBENE-BNFY-SEQ-NUM.
           MOVE WBENE-KEY                  TO WBENE-ENDBR-KEY.
010310*    MOVE '001'                      TO WBENE-ENDBR-BNFY-SEQ-NUM.
010310     MOVE '999'                      TO WBENE-ENDBR-BNFY-SEQ-NUM.
010310*    PERFORM  BENE-1000-BROWSE-PREV
010310*        THRU BENE-1000-BROWSE-PREV-X.
010310     PERFORM  BENE-2000-READ-MAX
010310         THRU BENE-2000-READ-MAX-X.

           IF WBENE-IO-OK
010310*        PERFORM  BENE-2000-READ-PREV
010310*            THRU BENE-2000-READ-PREV-X
010310*        IF WBENE-IO-OK
010310*            MOVE WBENE-BNFY-SEQ-NUM TO WS-SEQ-NO
010310*        END-IF
010310*        PERFORM  BENE-3000-END-BROWSE-PREV
010310*            THRU BENE-3000-END-BROWSE-PREV-X
010310*            MOVE WBENE-BNFY-SEQ-NUM TO WS-SEQ-NO
010310             MOVE WBENE-MAX-BNFY-SEQ-NUM TO WS-SEQ-NO
           END-IF.

           IF WS-SEQ-NO  = '999'
      *MSG: 'MAXIMUM NUMBER OF BENEFICIARY RELATIONSHIPS CREATED (999)'
               MOVE 'CS51000003'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           ADD 1                           TO WS-SEQ-NO.

           MOVE MIR-POL-ID-BASE             TO WBENE-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX              TO WBENE-POL-ID-SFX.
           MOVE WS-SEQ-NO                   TO WBENE-BNFY-SEQ-NUM.

           PERFORM  BENE-1000-CREATE
               THRU BENE-1000-CREATE-X.

           PERFORM  BENE-1000-WRITE
               THRU BENE-1000-WRITE-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE WS-SEQ-NO                  TO MIR-BNFY-SEQ-NUM.


      *MSG:  'RECORD CREATED - CONTINUE'
           MOVE 'XS00000004'               TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE 'N'                        TO RPOL-POL-BNFY-PCT-IND.

016503     PERFORM 0289-1000-INIT-PARM-INFO
016503        THRU 0289-1000-INIT-PARM-INFO-X.

016503     PERFORM 0289-1000-OBTAIN-NXT-ACTV
016503        THRU 0289-1000-OBTAIN-NXT-ACTV-X.

016503     IF L0289-RETRN-OK
016503        MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503        MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503        MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503        MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *------------------
       5000-PROCESS-UPDATE.
      *------------------

020477     PERFORM  5100-CHECK-MULTIPLE-BENE
020477         THRU 5100-CHECK-MULTIPLE-BENE-X.

           MOVE MIR-POL-ID-BASE             TO WBENE-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX              TO WBENE-POL-ID-SFX.
           MOVE MIR-BNFY-SEQ-NUM            TO WBENE-BNFY-SEQ-NUM.

           PERFORM  BENE-1000-READ-FOR-UPDATE
               THRU BENE-1000-READ-FOR-UPDATE-X.

           IF WBENE-IO-NOT-FOUND
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      *MSG:    'LOST RECORD @1 IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WS-BENE-KEY-DISPLAY    TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

023025*    IF RBENE-CLI-ID > SPACES
023025*       PERFORM  7000-CLI-CNSLDT-CHECK
023025*           THRU 7000-CLI-CNSLDT-CHECK-X
023025*       PERFORM  7000-CLI-ACCESS-CHECK
023025*           THRU 7000-CLI-ACCESS-CHECK-X
023025*       PERFORM  7100-CLI-ID-NAME-CHECK
023025*           THRU 7100-CLI-ID-NAME-CHECK-X
023025*    END-IF.

           IF RBENE-BNFY-TYP-IRREVOCABLE
      *MSG:    'THIS IS AN IRREVOCABLE BENEFICIARY DESIGNATION'
               MOVE 'CS51000004'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE RBENE-CLI-ID               TO WS-OLD-CLI-ID.
           MOVE RBENE-CVG-NUM              TO WS-OLD-CVG-NO.

           PERFORM  5300-MAINTAIN-EDITS
               THRU 5300-MAINTAIN-EDITS-X.

           PERFORM  5400-CROSS-EDITS
               THRU 5400-CROSS-EDITS-X.

           PERFORM  BENE-2000-REWRITE
               THRU BENE-2000-REWRITE-X.

014221     PERFORM  POL-2000-REWRITE
014221         THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
      *MSG:    'RECORD UPDATED'
               MOVE 'XS00000008'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           ELSE
      *MSG:    'MAINTENANCE COMPLETED - CONTINUE'
               MOVE 'XS00000007'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           IF  WS-OLD-CLI-ID NOT = RBENE-CLI-ID
           OR ((RBENE-CLI-ID > SPACES
           OR WS-OLD-CLI-ID > SPACES)
           AND WS-OLD-CVG-NO NOT = RBENE-CVG-NUM)
               PERFORM  5500-RL-UPDATE
                   THRU 5500-RL-UPDATE-X
           END-IF.


014653*    PERFORM  7300-BNFY-PERC-CHECK
014653*        THRU 7300-BNFY-PERC-CHECK-X.
014653*
014653*    PERFORM  POL-1000-READ-FOR-UPDATE
014653*        THRU POL-1000-READ-FOR-UPDATE-X.
014653*    IF NOT WPOL-IO-OK
014653*MSG:    'RECORD @1 NOT FOUND'
014653*        MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
014653*        MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
014653*        PERFORM  0260-1000-GENERATE-MESSAGE
014653*            THRU 0260-1000-GENERATE-MESSAGE-X
014653*        PERFORM  POL-3000-UNLOCK
014653*            THRU POL-3000-UNLOCK-X
014653*        GO TO 5200-MAINTAIN-2-X
014653*    END-IF.
014653*
014653*    IF RPOL-POL-CVG-REC-CTR-N > ZERO
014653*        PERFORM  5600-READ-TRAILERS-IN
014653*            THRU 5600-READ-TRAILERS-IN-X
014653*            VARYING I FROM 1 BY 1
014653*            UNTIL I > RPOL-POL-CVG-REC-CTR-N
014653*    END-IF.
014653*
014653*    IF  RPOL-POL-STAT-PENDING
014653*    OR  RPOL-POL-STAT-COMPLETE
014653*        PERFORM  5950-1000-BUILD-PARM-INFO
014653*            THRU 5950-1000-BUILD-PARM-INFO-X
014653*        PERFORM  5950-1000-ANALYZE-POL
014653*            THRU 5950-1000-ANALYZE-POL-X
014653*    END-IF.
014653*
014653*    PERFORM  POL-2000-REWRITE
014653*        THRU POL-2000-REWRITE-X.
014653*
014653*    IF RPOL-POL-CVG-REC-CTR-N > ZERO
014653*        PERFORM  5700-WRITE-TRAILERS-OUT
014653*            THRU 5700-WRITE-TRAILERS-OUT-X
014653*            VARYING I FROM 1 BY 1
014653*            UNTIL I > RPOL-POL-CVG-REC-CTR-N
014653*    END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
020477*-------------------------
020477 5100-CHECK-MULTIPLE-BENE.
020477*-------------------------
020477
020477     MOVE ZERO                   TO WS-DESGNT-BNFY-COUNT.
020477     MOVE ZERO                   TO WS-DESGNT-BNFY-SEQ-NUM.
020477     MOVE LOW-VALUES             TO WBENE-KEY.
020477     MOVE MIR-POL-ID-BASE        TO WBENE-POL-ID-BASE.
020477     MOVE MIR-POL-ID-SFX         TO WBENE-POL-ID-SFX.
020477     MOVE ZERO                   TO WBENE-BNFY-SEQ-NUM.
020477     MOVE WBENE-KEY              TO WBENE-ENDBR-KEY.
020477     MOVE 999                    TO WBENE-ENDBR-BNFY-SEQ-NUM.
020477
020477     PERFORM  BENE-1000-BROWSE
020477         THRU BENE-1000-BROWSE-X.
020477
020477     PERFORM  BENE-2000-READ-NEXT
020477         THRU BENE-2000-READ-NEXT-X.
020477
020477     IF  WBENE-IO-OK
020477         PERFORM
020477            UNTIL NOT WBENE-IO-OK
020477            IF  RBENE-DESGNT-BNFY
020477                ADD 1            TO WS-DESGNT-BNFY-COUNT
020477                MOVE RBENE-BNFY-SEQ-NUM
020477                                 TO WS-DESGNT-BNFY-SEQ-NUM
020477            END-IF
020477            PERFORM  BENE-2000-READ-NEXT
020477                THRU BENE-2000-READ-NEXT-X
020477         END-PERFORM
020477     END-IF.
020477
020477     PERFORM  BENE-3000-END-BROWSE
020477         THRU BENE-3000-END-BROWSE-X.
020477
020477
020477 5100-CHECK-MULTIPLE-BENE-X.
020477     EXIT.
020477/
      *--------------------
       5300-MAINTAIN-EDITS.
      *--------------------

           IF MIR-BNFY-NM > SPACES
               IF MIR-BNFY-NM = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES             TO MIR-BNFY-NM
               END-IF
               MOVE MIR-BNFY-NM            TO RBENE-BNFY-NM
           ELSE
               MOVE RBENE-BNFY-NM          TO MIR-BNFY-NM
           END-IF.

           IF MIR-CLI-ID > SPACES
           AND RBENE-CLI-ID NOT = MIR-CLI-ID
               PERFORM  5310-EDIT-CLI-ID
                   THRU 5310-EDIT-CLI-ID-X
           ELSE
               MOVE RBENE-CLI-ID           TO MIR-CLI-ID
           END-IF.

023025     IF MIR-CLI-ID > SPACES
023025         MOVE MIR-CLI-ID             TO WS-CLI-ID
023025         MOVE MIR-BNFY-NM            TO WS-BNFY-NM
023025         PERFORM  7000-CLI-ACCESS-CHECK
023025             THRU 7000-CLI-ACCESS-CHECK-X
023025         PERFORM  7100-CLI-ID-NAME-CHECK
023025             THRU 7100-CLI-ID-NAME-CHECK-X
023025     END-IF.

           IF MIR-DV-BNFY-UPDT-IND > SPACES
               IF MIR-DV-BNFY-UPDT-IND = 'Y'
               AND MIR-CLI-ID > SPACES
                   PERFORM  5320-UPDATE-CLI-NAME
                       THRU 5320-UPDATE-CLI-NAME-X
               ELSE
                   IF  MIR-DV-BNFY-UPDT-IND NOT = 'Y'
                   AND MIR-DV-BNFY-UPDT-IND NOT = 'N'
      *MSG:  'INVALID UPDATE NAME INDICATOR, MUST BE 'Y' OR 'N''
                       MOVE 'CS51000029'     TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   END-IF
               END-IF
           ELSE
               MOVE 'N'                    TO MIR-DV-BNFY-UPDT-IND
           END-IF.

           IF MIR-CLI-ADDR-TYP-CD > SPACES
               IF MIR-CLI-ADDR-TYP-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES             TO RBENE-CLI-ADDR-TYP-CD
010387             MOVE SPACES             TO MIR-CLI-ADDR-TYP-CD
               ELSE
010387*            MOVE MIR-CLI-ADDR-TYP-CD   TO RBENE-CLI-ADDR-TYP-CD
010387             PERFORM  5325-EDIT-ADDR-TYPE
010387                 THRU 5325-EDIT-ADDR-TYPE-X
               END-IF
           ELSE
               MOVE RBENE-CLI-ADDR-TYP-CD  TO MIR-CLI-ADDR-TYP-CD
           END-IF.

           IF MIR-CVG-NUM > SPACES
               IF MIR-CVG-NUM = ZEROES
                   MOVE MIR-CVG-NUM         TO RBENE-CVG-NUM
               ELSE
                   PERFORM  5330-EDIT-CVG-NUM
                       THRU 5330-EDIT-CVG-NUM-X
               END-IF
           ELSE
               MOVE RBENE-CVG-NUM          TO MIR-CVG-NUM
           END-IF.

           IF MIR-BNFY-DESGNT-CD > SPACES
               IF MIR-BNFY-DESGNT-CD = 'P'
               OR MIR-BNFY-DESGNT-CD = 'C'
                   MOVE MIR-BNFY-DESGNT-CD    TO RBENE-BNFY-DESGNT-CD
               ELSE
      *MSG:  'INVALID CONTINGENT/PRIMARY CODES, MUST BE 'P' OR 'C'
                   MOVE 'CS51000005'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               MOVE RBENE-BNFY-DESGNT-CD   TO MIR-BNFY-DESGNT-CD
           END-IF.

           IF MIR-BNFY-PRCDS-PCT > SPACES
               PERFORM  5340-EDIT-BNFY-PERCENT
                   THRU 5340-EDIT-BNFY-PERCENT-X
           ELSE
               MOVE RBENE-BNFY-PRCDS-PCT   TO MIR-BNFY-PRCDS-PCT
           END-IF.

           IF MIR-BNFY-TYP-CD > SPACES
               IF MIR-BNFY-TYP-CD = 'I'
               OR MIR-BNFY-TYP-CD = 'O'
               OR MIR-BNFY-TYP-CD = 'P'
                   MOVE MIR-BNFY-TYP-CD          TO RBENE-BNFY-TYP-CD
               ELSE
      *MSG:  'BENEFICIARY TYPE CODE, MUST BE 'I', 'O' OR 'P'
                   MOVE 'CS51000006'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               MOVE RBENE-BNFY-TYP-CD      TO MIR-BNFY-TYP-CD
           END-IF.

           PERFORM  5350-EDIT-BNFY-REL-INSRD
               THRU 5350-EDIT-BNFY-REL-INSRD-X.

           IF MIR-BNFY-MINR-IND > SPACES
               IF MIR-BNFY-MINR-IND = 'Y'
               OR MIR-BNFY-MINR-IND = 'N'
                   MOVE MIR-BNFY-MINR-IND       TO RBENE-BNFY-MINR-IND
               ELSE
      *MSG:  'MINOR INDICATOR, MUST BE 'Y' OR 'N'
                   MOVE 'CS51000007'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               MOVE RBENE-BNFY-MINR-IND    TO MIR-BNFY-MINR-IND
           END-IF.

020477     IF  MIR-DESGNT-BNFY-IND > SPACES
020477         PERFORM  8960-1000-BUILD-PARM-INFO
020477             THRU 8960-1000-BUILD-PARM-INFO-X
020477
020477         MOVE 'DESGNT-BNFY-IND'      TO L8960-AV-TBL-CD
020477         MOVE MIR-DESGNT-BNFY-IND    TO L8960-AV-CD
020477
020477         PERFORM  8960-1000-VALIDATE-CODE
020477             THRU 8960-1000-VALIDATE-CODE-X
020477
020477         IF  L8960-RETRN-OK
020477             MOVE MIR-DESGNT-BNFY-IND
020477                                     TO RBENE-DESGNT-BNFY-IND
020477         ELSE
020477*MSG: ALLOWED VALUE IS ONLY Y OR N FOR DESIGNATED BENEFICIARY
020477*     INDICATOR
020477             MOVE 'CS51000032'       TO WGLOB-MSG-REF-INFO
020477             PERFORM  0260-1000-GENERATE-MESSAGE
020477                 THRU 0260-1000-GENERATE-MESSAGE-X
020477         END-IF
020477     ELSE
020477         MOVE RBENE-DESGNT-BNFY-IND  TO MIR-DESGNT-BNFY-IND
020477     END-IF.

       5300-MAINTAIN-EDITS-X.
           EXIT.
      /
      *-----------------
       5310-EDIT-CLI-ID.
      *-----------------

           IF MIR-CLI-ID = EBLCH-BLANK-FIELD-CHAR
023025*        MOVE SPACES                 TO RBENE-BNFY-NM
023025*        MOVE SPACES                 TO MIR-BNFY-NM
               MOVE SPACES                 TO RBENE-CLI-ID
               MOVE SPACES                 TO MIR-CLI-ID
               MOVE SPACES                 TO RBENE-CLI-ADDR-TYP-CD
               GO TO 5310-EDIT-CLI-ID-X
           END-IF.

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID                  TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF L2435-RETRN-CLI-NOT-FOUND
      *MSG:   'BENEFICIARY CLIENT NUMBER DOES NOT EXIST'
               MOVE 'CS51000008'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5310-EDIT-CLI-ID-X
           END-IF.

           MOVE MIR-CLI-ID                  TO RBENE-CLI-ID.

           IF MIR-BNFY-NM NOT = SPACES
      *MSG:    'BENEFICIARY NAME IGNORED'
               MOVE 'CS51000010'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  5320-UPDATE-CLI-NAME
               THRU 5320-UPDATE-CLI-NAME-X.

       5310-EDIT-CLI-ID-X.
           EXIT.
      /
      *---------------------
       5320-UPDATE-CLI-NAME.
      *---------------------

           MOVE RBENE-CLI-ID               TO L5120-CLI-ID.

           PERFORM  5120-1000-CLI-NAME-UPDATE
               THRU 5120-1000-CLI-NAME-UPDATE-X.

           MOVE L5120-CLI-NAME             TO RBENE-BNFY-NM.

      *MSG:   'BENEFICIARY NAME DEFAULTED FROM CLIENT RECORD'
           MOVE 'CS51000011'               TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE L5120-CLI-NAME             TO MIR-BNFY-NM.

       5320-UPDATE-CLI-NAME-X.
           EXIT.
      /
010387*--------------------
010387 5325-EDIT-ADDR-TYPE.
010387*--------------------
010387
010387     MOVE MIR-CLI-ADDR-TYP-CD           TO WEDIT-ETBL-VALU-ID.
010387
010387     PERFORM  ADDR-1000-EDIT
010387         THRU ADDR-1000-EDIT-X.
010387
010387     IF WEDIT-IO-OK
010387         MOVE MIR-CLI-ADDR-TYP-CD       TO RBENE-CLI-ADDR-TYP-CD
010387     ELSE
010387*MSG:  'ADDRESS TYPE MUST BE IN EDIT TYPE 'ADDR'
010387         MOVE 'CS51000031'           TO WGLOB-MSG-REF-INFO
010387         PERFORM  0260-1000-GENERATE-MESSAGE
010387             THRU 0260-1000-GENERATE-MESSAGE-X
010387     END-IF.

010387 5325-EDIT-ADDR-TYPE-X.
010387     EXIT.
      /
      *------------------
       5330-EDIT-CVG-NUM.
      *------------------

           MOVE 'N'                        TO L0280-SIGN-IND.
           MOVE 0                          TO L0280-PRECISION.
           MOVE 2                          TO L0280-LENGTH.
           MOVE 2                          TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-NUM                 TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     'COVERAGE NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS51000012'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5330-EDIT-CVG-NUM-X
           ELSE
020874*        MOVE L0280-OUTPUT-V00       TO WCVG-CVG-NUM-N
020874*        MOVE WCVG-CVG-NUM           TO MIR-CVG-NUM
020874         MOVE L0280-OUTPUT-V00      TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM
           END-IF.

           MOVE MIR-POL-ID-BASE             TO WCVG-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX              TO WCVG-POL-ID-SFX.
           MOVE MIR-CVG-NUM                 TO WCVG-CVG-NUM.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF NOT WCVG-IO-OK
      *MSG:   COVERAGE MUST EXIST
               MOVE 'CS51000013'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5330-EDIT-CVG-NUM-X
           END-IF.

           MOVE MIR-CVG-NUM                 TO RBENE-CVG-NUM.

       5330-EDIT-CVG-NUM-X.
           EXIT.
      /
      *-----------------------
       5340-EDIT-BNFY-PERCENT.
      *-----------------------

           MOVE 'N'                        TO L0280-SIGN-IND.
           MOVE 0                          TO L0280-PRECISION.
           MOVE 3                          TO L0280-LENGTH.
           MOVE 3                          TO L0280-INPUT-SIZE.
           MOVE MIR-BNFY-PRCDS-PCT              TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     'BENEFICIARY PERCENT NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS51000014'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT           TO RBENE-BNFY-PRCDS-PCT
           END-IF.

       5340-EDIT-BNFY-PERCENT-X.
           EXIT.
      /
      *-------------------------
       5350-EDIT-BNFY-REL-INSRD.
      *-------------------------

           IF MIR-BNFY-REL-INSRD-CD = SPACES
               MOVE RBENE-BNFY-REL-INSRD-CD TO MIR-BNFY-REL-INSRD-CD
           END-IF.

           IF MIR-BNFY-REL-INSRD-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES                 TO MIR-BNFY-REL-INSRD-CD
           END-IF.

           MOVE MIR-BNFY-REL-INSRD-CD         TO WEDIT-ETBL-VALU-ID.

           PERFORM  BTOI-1000-EDIT-BENEF-TO-INS
               THRU BTOI-1000-EDIT-BENEF-TO-INS-X.

           IF WEDIT-IO-OK
               MOVE MIR-BNFY-REL-INSRD-CD  TO RBENE-BNFY-REL-INSRD-CD
           ELSE
      *MSG:  'INVALID RELATION TO INSURED TYPE, SEE EDIT TABLE 'BTOI'
               MOVE 'CS51000015'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5350-EDIT-BNFY-REL-INSRD-X.
           EXIT.
      /
      *-----------------
       5400-CROSS-EDITS.
      *-----------------

           IF RBENE-CLI-ID = SPACES
           AND RBENE-BNFY-NM = SPACES
      *MSG:   'BENEFICIARY NAME OR CLIENT # MUST BE ENTERED'
               MOVE 'CS51000016'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF RBENE-BNFY-NM > SPACES
           OR RBENE-CLI-ID > SPACES
               PERFORM  5410-ADDR-CHECK
                   THRU 5410-ADDR-CHECK-X
           END-IF.

           IF RBENE-CLI-ID > SPACES
           AND (MIR-CLI-ID NOT = RBENE-CLI-ID
           OR  MIR-CVG-NUM NOT = RBENE-CVG-NUM)
               PERFORM  5420-RL-CHECK
                   THRU 5420-RL-CHECK-X
           END-IF.

020477     IF  RBENE-DESGNT-BNFY-IND = 'Y'
020477     AND RBENE-BNFY-DESGNT-CD NOT = 'P'
020477*MSG:  DESIGNATED BENEFICIARY SHOULD BE DEFINED AS PRIMARY
020477         MOVE 'CS51000033'           TO WGLOB-MSG-REF-INFO
020477         PERFORM  0260-1000-GENERATE-MESSAGE
020477             THRU 0260-1000-GENERATE-MESSAGE-X
020477     END-IF.
020477
020477     IF  RBENE-DESGNT-BNFY-IND = 'Y'
020477         PERFORM  5430-PERCENTAGE-CHECK
020477             THRU 5430-PERCENTAGE-CHECK-X
020477     END-IF.

       5400-CROSS-EDITS-X.
           EXIT.
      /
      *----------------
       5410-ADDR-CHECK.
      *----------------

           IF RBENE-BNFY-NM > SPACES
           AND RBENE-CLI-ID = SPACES
               IF RBENE-CLI-ADDR-TYP-CD = SPACES
                   GO TO 5410-ADDR-CHECK-X
               ELSE
      *MSG:   'ADDRESS TYPE INVALID WHEN BENEFICIARY NAME
      *MSG:    ENTERED, PLEASE CORRECT'
                   MOVE 'CS51000017'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5410-ADDR-CHECK-X
               END-IF
           END-IF.

           IF RBENE-CLI-ADDR-TYP-CD = SPACES
      *MSG:   'BENEFICIARY ADDRESS TYPE DEFAULTED TO 'PR''
               MOVE 'CS51000018'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'PR'                   TO RBENE-CLI-ADDR-TYP-CD
               MOVE 'PR'                   TO MIR-CLI-ADDR-TYP-CD
           END-IF.

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.
           MOVE RBENE-CLI-ID               TO L2440-CLI-ID.
           MOVE RBENE-CLI-ADDR-TYP-CD      TO L2440-CLI-ADDR-TYP-CD.

           IF RBENE-CLI-ADDR-TYP-CD = 'PR'
               PERFORM  2440-1000-PRIMARY-ADDRESS
                   THRU 2440-1000-PRIMARY-ADDRESS-X
           ELSE
               PERFORM  2440-2000-OTHER-ADDRESS
                   THRU 2440-2000-OTHER-ADDRESS-X
               IF L2440-RETRN-NO-ADDRESS
      *MSG:   'CLIENT ADDRESS NOT FOUND, TYPE 'PR' DEFAULTED'
                   MOVE 'CS51000019'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'PR'               TO RBENE-CLI-ADDR-TYP-CD
                   MOVE 'PR'               TO L2440-CLI-ADDR-TYP-CD
                   MOVE 'PR'               TO MIR-CLI-ADDR-TYP-CD
                   PERFORM  2440-1000-PRIMARY-ADDRESS
                       THRU 2440-1000-PRIMARY-ADDRESS-X
               END-IF
           END-IF.

           EVALUATE TRUE

               WHEN L2440-ADDR-STAT-INCOMPLETE
      *MSG:   'ADDRESS IS INCOMPLETE FOR CLIENT @1'
                   MOVE RBENE-CLI-ID       TO WGLOB-MSG-PARM (1)
                   MOVE 'CS51000020'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN L2440-ADDR-STAT-ERROR
      *MSG:   'ADDRESS STATUS ERROR CODE FOUND FOR CLIENT @1,
      *MSG:    ADDRESS TYPE @2'
                   MOVE RBENE-CLI-ID       TO WGLOB-MSG-PARM (1)
                   MOVE RBENE-CLI-ADDR-TYP-CD TO WGLOB-MSG-PARM (2)
                   MOVE 'CS51000021'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

       5410-ADDR-CHECK-X.
           EXIT.
      /
      *--------------
       5420-RL-CHECK.
      *--------------

           MOVE RBENE-CLI-ID               TO WRL-CLI-ID.

016440*    IF RPOL-POL-APPL-CTL-ADMIN
016440*        MOVE 'ADMIN'                TO WRL-REL-SYS-ID
016440*    ELSE
016440*        IF RPOL-POL-APPL-CTL-NBS
016440*            MOVE 'NEWBUS'           TO WRL-REL-SYS-ID
016440*        END-IF
016440*    END-IF.

016440     MOVE WGLOB-SYS-CTL-ID           TO WRL-REL-SYS-ID.

           MOVE RPOL-POL-ID                TO WRL-REL-SYS-REF-POL-ID.

           MOVE RBENE-CVG-NUM              TO WRL-REL-SYS-REF-CVG-NUM.

           MOVE 'B'                        TO WRL-REL-TYP-CD.

           PERFORM  RL-1000-READ
               THRU RL-1000-READ-X.

           IF WRL-IO-OK
      *MSG:  'CLIENT ALREADY LISTED AS BENEFICIARY FOR
      *MSG:   THIS POLICY/COVERAGE'
               MOVE 'CS51000009'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5420-RL-CHECK-X.
           EXIT.
      /
020477*----------------------
020477 5430-PERCENTAGE-CHECK.
020477*----------------------
020477
020477     IF  RBENE-BNFY-PRCDS-PCT NOT = 100
020477*MSG : DESIGNATED PRIMARY BENEFICIARY SHOULD HAVE A 100% SHARE
020477         MOVE 'CS51000034'           TO WGLOB-MSG-REF-INFO
020477         PERFORM  0260-1000-GENERATE-MESSAGE
020477             THRU 0260-1000-GENERATE-MESSAGE-X
020477     END-IF.
020477
020477     IF  WS-DESGNT-BNFY-COUNT > 1
020477     OR  (WS-DESGNT-BNFY-COUNT = 1
020477     AND  WS-DESGNT-BNFY-SEQ-NUM NOT = RBENE-BNFY-SEQ-NUM)
020477*MSG:  THERE SHOULD ONLY BE ONE DESIGNATED BENEFICIARY
020477        MOVE 'CS51000035'        TO WGLOB-MSG-REF-INFO
020477        PERFORM  0260-1000-GENERATE-MESSAGE
020477            THRU 0260-1000-GENERATE-MESSAGE-X
020477     END-IF.
020477
020477 5430-PERCENTAGE-CHECK-X.
020477     EXIT.
020477/

      *---------------
       5500-RL-UPDATE.
      *---------------

           IF  WS-OLD-CLI-ID > SPACES
               PERFORM  7200-RELATION-CHANGE
                   THRU 7200-RELATION-CHANGE-X
               PERFORM  0832-2000-DELETE-REL
                   THRU 0832-2000-DELETE-REL-X
           END-IF.


           IF RBENE-CLI-ID > SPACES
               MOVE SPACES                 TO RRL-REC-INFO
               PERFORM  7200-RELATION-CHANGE
                   THRU 7200-RELATION-CHANGE-X
               PERFORM  0832-1000-UPDATE-REL
                   THRU 0832-1000-UPDATE-REL-X
           END-IF.

       5500-RL-UPDATE-X.
           EXIT.
      /
      *----------------------
       5600-READ-TRAILERS-IN.
      *----------------------

           MOVE WPOL-KEY                   TO WCVG-KEY.
           MOVE I                          TO WCVG-CVG-NUM-N.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF WCVG-IO-OK
               MOVE RCVG-CVG-INFO          TO WCVGS-CVG-INFO (I)
               MOVE RCVG-CVG-NUM           TO WCVGS-CVG-SEQ-NUM (I)
           END-IF.

       5600-READ-TRAILERS-IN-X.
           EXIT.
      /
      *------------------------
021620*5700-WRITE-TRAILERS-OUT.
      *------------------------

021620*    MOVE WPOL-KEY                   TO WCVG-KEY.
021620*    MOVE I                          TO WCVG-CVG-NUM-N.

021620*    PERFORM  CVG-1000-READ-FOR-UPDATE
021620*        THRU CVG-1000-READ-FOR-UPDATE-X.

021620*    MOVE WCVGS-CVG-INFO (I)         TO RCVG-CVG-INFO.

021620*    PERFORM  CVG-2000-REWRITE
021620*        THRU CVG-2000-REWRITE-X.

021620*5700-WRITE-TRAILERS-OUT-X.
021620*    EXIT.
021620*
      *-------------------
       6000-PROCESS-DELETE.
      *-------------------

           MOVE MIR-POL-ID-BASE             TO WCVG-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX              TO WCVG-POL-ID-SFX.
           MOVE MIR-BNFY-SEQ-NUM            TO WBENE-BNFY-SEQ-NUM.

           PERFORM  BENE-1000-READ-FOR-UPDATE
               THRU BENE-1000-READ-FOR-UPDATE-X.

           IF RBENE-BNFY-TYP-IRREVOCABLE
      *MSG:  'THIS IS AN IRREVOCABLE BENEFICIARY DESIGNATION'
               MOVE 'CS51000004'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF RBENE-CLI-ID > SPACES
016387*        PERFORM  7000-CLI-CNSLDT-CHECK
016387*            THRU 7000-CLI-CNSLDT-CHECK-X
023025         MOVE RBENE-CLI-ID           TO WS-CLI-ID
016387         PERFORM  7000-CLI-ACCESS-CHECK
016387             THRU 7000-CLI-ACCESS-CHECK-X
           END-IF.

           IF WBENE-IO-OK
               PERFORM  BENE-1000-DELETE
                   THRU BENE-1000-DELETE-X
      *MSG:  'DELETE COMPLETED - CONTINUE'
               MOVE 'XS00000011'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-2000-REWRITE
014221             THRU POL-2000-REWRITE-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
           ELSE
      *MSG:  'RECORD @1 LOST IN DELETE - CONTACT SYSTEMS'
               MOVE WS-BENE-KEY-DISPLAY    TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
557660     END-IF.

           IF RBENE-CLI-ID NOT = SPACES
               PERFORM  7200-RELATION-CHANGE
                   THRU 7200-RELATION-CHANGE-X
               PERFORM  0832-2000-DELETE-REL
                   THRU 0832-2000-DELETE-REL-X
           END-IF.

014653*    PERFORM  7300-BNFY-PERC-CHECK
014653*        THRU 7300-BNFY-PERC-CHECK-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.

      *----------------------
016387*7000-CLI-CNSLDT-CHECK.
016387 7000-CLI-ACCESS-CHECK.
      *----------------------

      *
      * INITIALIZE INPUT PARAMETERS
      *
           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

023025*    MOVE RBENE-CLI-ID              TO L5600-CLI-ID.
023025     MOVE WS-CLI-ID                 TO L5600-CLI-ID.
555201*    SET  L5600-CNSLDT-MSG-NOT-REQD TO TRUE.
016387*    IF  WS-BUS-FCN-RETRIEVE
016387*        SET  L5600-GEN-CNSLDT-MSG-WARN TO TRUE
016387*    END-IF.

      *
      * CALL MODULE TO CHECK CLIENT ACCESS
      *
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

      *
      * CHECK THE RETURN
      *
           IF  L5600-RETRN-CLI-NOT-FOUND
               MOVE 'CS51000008'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
016387*        GO TO 7000-CLI-CNSLDT-CHECK-X
016387         GO TO 7000-CLI-ACCESS-CHECK-X
           END-IF.

           IF  L5600-RETRN-OK

               EVALUATE TRUE

                  WHEN L5600-CNFD-ACCS-RESTRICTED
                       PERFORM  9100-BLANK-DATA-FIELDS
                           THRU 9100-BLANK-DATA-FIELDS-X
016387*                GO TO 7000-CLI-CNSLDT-CHECK-X
016387                 GO TO 7000-CLI-ACCESS-CHECK-X

016387*           WHEN L5600-CNSLDT-ACCS-RESTRICTED
                  WHEN L5600-CCAS-ACCS-RESTRICTED
016387*                GO TO 7000-CLI-CNSLDT-CHECK-X
016387                 GO TO 7000-CLI-ACCESS-CHECK-X

               END-EVALUATE

           END-IF.

016387*7000-CLI-CNSLDT-CHECK-X.
016387 7000-CLI-ACCESS-CHECK-X.
           EXIT.
      /
      *-----------------------
       7100-CLI-ID-NAME-CHECK.
      *-----------------------

023025*    MOVE RBENE-CLI-ID               TO L5120-CLI-ID.
023025*    MOVE RBENE-BNFY-NM              TO L5120-CLI-NAME.
023025     MOVE WS-CLI-ID                  TO L5120-CLI-ID.
023025     MOVE WS-BNFY-NM                 TO L5120-CLI-NAME.

           PERFORM  5120-2000-CLI-NAME-COMPARE
               THRU 5120-2000-CLI-NAME-COMPARE-X.

           IF L5120-BENE-NAME-MATCH-NO
      *MSG:  'BENEFICIARY NAME DOES NOT MATCH NAME FOR CLIENT @1'
023025*       MOVE RBENE-CLI-ID           TO WGLOB-MSG-PARM (1)
023025        MOVE WS-CLI-ID              TO WGLOB-MSG-PARM (1)
              MOVE 'CS51000026'           TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7100-CLI-ID-NAME-CHECK-X.
           EXIT.
      /
      *---------------------
       7200-RELATION-CHANGE.
      *---------------------

           IF  WS-OLD-CLI-ID > SPACES
               MOVE WS-OLD-CLI-ID          TO RRL-CLI-ID
           ELSE
               MOVE RBENE-CLI-ID           TO RRL-CLI-ID
           END-IF.

016440*    IF RPOL-POL-APPL-CTL-ADMIN
016440*        MOVE 'ADMIN'                TO RRL-REL-SYS-ID
016440*    ELSE
016440*        IF RPOL-POL-APPL-CTL-NBS
016440*            MOVE 'NEWBUS'           TO RRL-REL-SYS-ID
016440*        END-IF
016440*    END-IF.

016440     MOVE WGLOB-SYS-CTL-ID           TO RRL-REL-SYS-ID.

           MOVE RBENE-POL-ID               TO RRL-REL-SYS-REF-POL-ID.

017657* CVG-NUM IS ALWAYS DEFAULTED TO ZEROS WHEN NEW RECORD IS CREATED
017657* WE MUST ALSO LOOK AT THE CLI-ID TO SEE IF IT IS A NEW CLIENT ON
017657* BENE

           IF  WS-OLD-CVG-NO > SPACES
017657     AND WS-OLD-CLI-ID > SPACES
               MOVE WS-OLD-CVG-NO          TO RRL-REL-SYS-REF-CVG-NUM
           ELSE
               MOVE RBENE-CVG-NUM          TO RRL-REL-SYS-REF-CVG-NUM
           END-IF.

           MOVE 'B'                        TO RRL-REL-TYP-CD.
014221*    MOVE WGLOB-PROCESS-DATE         TO RRL-REL-PREV-UPDT-DT.
           MOVE 'A'                        TO RRL-REL-CREAT-TYP-CD.

       7200-RELATION-CHANGE-X.
           EXIT.
      /
014653*---------------------
014653*7300-BNFY-PERC-CHECK.
014653*---------------------

014653*    SET WS-BNFY-CONT-EXISTS-NO      TO TRUE.
014653*    SET WS-BNFY-PRIMARY-EXISTS-NO   TO TRUE.
014653*    SET WS-BNFY-PERC-CONT-ZERO      TO TRUE.
014653*    SET WS-BNFY-PERC-PRIMARY-ZERO   TO TRUE.
014653*
014653*    SET WS-BNFY-PERC-ERROR-NO       TO TRUE.
014653*
014653*    MOVE ZEROES                     TO WS-LOOP-CVG-NUM.
014653*
014653*    MOVE MIR-POL-I1                  TO WCVG-POL-ID-BASE.
014653*    MOVE MIR-POL-I2                  TO WCVG-POL-ID-SFX.
014653*    MOVE ZEROES                     TO WBENE-BNFY-SEQ-NUM.
014653*
014653*    MOVE WBENE-KEY                  TO WBENE-ENDBR-KEY.
014653*    MOVE '999'                      TO WBENE-ENDBR-BNFY-SEQ-NUM.
014653*
014653*    PERFORM  BENE-1000-BROWSE
014653*        THRU BENE-1000-BROWSE-X.
014653*
014653*    PERFORM  BENE-2000-READ-NEXT
014653*        THRU BENE-2000-READ-NEXT-X.
014653*
014653*    PERFORM  7310-BEN-PERC-POL-CHECK
014653*        THRU 7310-BEN-PERC-POL-CHECK-X
014653*       UNTIL WBENE-IO-EOF.
014653*
014653*    PERFORM  7330-BNFY-PERC-ERROR-CHECK
014653*        THRU 7330-BNFY-PERC-ERROR-CHECK-X.
014653*
014653*    PERFORM  BENE-3000-END-BROWSE
014653*        THRU BENE-3000-END-BROWSE-X.
014653*
014653*    MOVE MIR-POL-I1                  TO WCVG-POL-ID-BASE.
014653*    MOVE MIR-POL-I2                  TO WCVG-POL-ID-SFX.
014653*    MOVE ZEROES                     TO WBENC-CVG-NUM.
014653*    MOVE ZEROES                     TO WBENC-BNFY-SEQ-NUM.
014653*
014653*    MOVE WBENC-KEY                  TO WBENC-ENDBR-KEY.
014653*    MOVE 99                         TO WBENC-ENDBR-CVG-NUM.
014653*    MOVE '999'                      TO WBENC-ENDBR-BNFY-SEQ-NUM.
014653*
014653*    PERFORM  BENC-1000-BROWSE
014653*        THRU BENC-1000-BROWSE-X.
014653*
014653*    IF WBENC-IO-OK
014653*        PERFORM  BENC-2000-READ-NEXT
014653*            THRU BENC-2000-READ-NEXT-X
014653*        MOVE RBENE-CVG-NUM          TO WS-LOOP-CVG-NUM
014653*        PERFORM  7320-BEN-PERC-CVG-CHECK
014653*            THRU 7320-BEN-PERC-CVG-CHECK-X
014653*           UNTIL WBENC-IO-EOF
014653*        PERFORM  BENC-3000-END-BROWSE
014653*            THRU BENC-3000-END-BROWSE-X
014653*    END-IF.
014653*
014653*    PERFORM  7330-BNFY-PERC-ERROR-CHECK
014653*        THRU 7330-BNFY-PERC-ERROR-CHECK-X.
014653*
014653*    PERFORM  POL-1000-READ-FOR-UPDATE
014653*        THRU POL-1000-READ-FOR-UPDATE-X.
014653*
014653*    IF WS-BNFY-PERC-ERROR
014653*        SET RPOL-POL-BNFY-PCT-NOT-100 TO TRUE
014653*    ELSE
014653*        SET RPOL-POL-BNFY-PCT-100     TO TRUE
014653*    END-IF.
014653*
014653*    PERFORM  POL-2000-REWRITE
014653*        THRU POL-2000-REWRITE-X.
014653*
014653*7300-BNFY-PERC-CHECK-X.
014653*    EXIT.
014653*/
014653*------------------------
014653* 7310-BEN-PERC-POL-CHECK.
014653*------------------------
014653*
014653*    IF RBENE-CVG-NUM = ZEROES
014653*        EVALUATE TRUE
014653*
014653*            WHEN RBENE-BNFY-DESGNT-CONTINGENT
014653*                ADD RBENE-BNFY-PRCDS-PCT
014653*                                    TO WS-BNFY-PERC-CONTINGENT
014653*                SET WS-BNFY-CONT-EXISTS TO TRUE
014653*
014653*            WHEN RBENE-BNFY-DESGNT-PRIMARY
014653*                ADD RBENE-BNFY-PRCDS-PCT
014653*                                    TO WS-BNFY-PERC-PRIMARY
014653*                SET WS-BNFY-PRIMARY-EXISTS TO TRUE
014653*
014653*        END-EVALUATE
014653*    END-IF.
014653*
014653*    PERFORM  BENE-2000-READ-NEXT
014653*        THRU BENE-2000-READ-NEXT-X.
014653*
014653*7310-BEN-PERC-POL-CHECK-X.
014653*    EXIT.
014653*/
014653*------------------------
014653*7320-BEN-PERC-CVG-CHECK.
014653*------------------------
014653*
014653*    IF RBENE-CVG-NUM NOT = WS-LOOP-CVG-NUM
014653*        PERFORM  7330-BNFY-PERC-ERROR-CHECK
014653*            THRU 7330-BNFY-PERC-ERROR-CHECK-X
014653*    END-IF.
014653*
014653*    EVALUATE TRUE
014653*
014653*        WHEN RBENE-BNFY-DESGNT-CONTINGENT
014653*            ADD RBENE-BNFY-PRCDS-PCT
014653*                                  TO WS-BNFY-PERC-CONTINGENT
014653*            SET WS-BNFY-CONT-EXISTS    TO TRUE
014653*
014653*        WHEN RBENE-BNFY-DESGNT-PRIMARY
014653*            ADD RBENE-BNFY-PRCDS-PCT   TO WS-BNFY-PERC-PRIMARY
014653*            SET WS-BNFY-PRIMARY-EXISTS TO TRUE
014653*
014653*    END-EVALUATE.
014653*
014653*    PERFORM  BENC-2000-READ-NEXT
014653*        THRU BENC-2000-READ-NEXT-X.
014653*
014653*7320-BEN-PERC-CVG-CHECK-X.
014653*    EXIT.
014653*/
014653*---------------------------
014653*7330-BNFY-PERC-ERROR-CHECK.
014653*---------------------------
014653*
014653*    IF NOT WS-BNFY-PERC-CONT-100
014653*    AND WS-BNFY-CONT-EXISTS
014653*        PERFORM  7340-BEN-PERC-CONT-ERROR-MSG
014653*            THRU 7340-BEN-PERC-CONT-ERROR-MSG-X
014653*    END-IF.
014653*
014653*    IF NOT WS-BNFY-PERC-PRIMARY-100
014653*    AND WS-BNFY-PRIMARY-EXISTS
014653*        PERFORM  7350-BEN-PERC-PRIM-ERROR-MSG
014653*            THRU 7350-BEN-PERC-PRIM-ERROR-MSG-X
014653*    END-IF.
014653*
014653*    MOVE RBENE-CVG-NUM              TO WS-LOOP-CVG-NUM.
014653*
014653*    SET WS-BNFY-CONT-EXISTS-NO      TO TRUE.
014653*    SET WS-BNFY-PRIMARY-EXISTS-NO   TO TRUE.
014653*    SET WS-BNFY-PERC-CONT-ZERO      TO TRUE.
014653*    SET WS-BNFY-PERC-PRIMARY-ZERO   TO TRUE.
014653*
014653*7330-BNFY-PERC-ERROR-CHECK-X.
014653*    EXIT.
014653*/
014653*-----------------------------
014653*7340-BEN-PERC-CONT-ERROR-MSG.
014653*-----------------------------
014653*
014653*    IF WS-LOOP-CVG-NUM = ZEROES
014653*MSG:     'POLICY CONTINGENT BENEFICIARY % DOES NOT TOTAL 100%'
014653*         MOVE 'CS51000022'           TO WGLOB-MSG-REF-INFO
014653*        PERFORM  0260-1000-GENERATE-MESSAGE
014653*            THRU 0260-1000-GENERATE-MESSAGE-X
014653*    ELSE
014653*MSG:CONTINGENT BENEFICIARY % DOES NOT TOTAL 100% FOR COVERAGE @1
014653*        MOVE WS-LOOP-CVG-NUM        TO WGLOB-MSG-PARM (1)
014653*        MOVE 'CS51000023'           TO WGLOB-MSG-REF-INFO
014653*        PERFORM  0260-1000-GENERATE-MESSAGE
014653*            THRU 0260-1000-GENERATE-MESSAGE-X
014653*    END-IF.
014653*
014653*    IF WGLOB-MSG-SEVRTY-FATAL
014653*        SET WS-BNFY-PERC-ERROR      TO TRUE
014653*    END-IF.
014653*
014653*7340-BEN-PERC-CONT-ERROR-MSG-X.
014653*    EXIT.
014653*/
014653*-----------------------------
014653*7350-BEN-PERC-PRIM-ERROR-MSG.
014653*-----------------------------
014653*
014653*    IF WS-LOOP-CVG-NUM = ZEROES
014653*MSG:     'POLICY PRIMARY BENEFICIARY % DOES NOT TOTAL 100%'
014653*        MOVE 'CS51000024'           TO WGLOB-MSG-REF-INFO
014653*        PERFORM  0260-1000-GENERATE-MESSAGE
014653*            THRU 0260-1000-GENERATE-MESSAGE-X
014653*    ELSE
014653*MSG:  'PRIMARY BENEFICIARY %
014653*MSG:  % DOES NOT TOTAL 100% FOR COVERAGE @1'
014653*        MOVE WS-LOOP-CVG-NUM        TO WGLOB-MSG-PARM (1)
014653*        MOVE 'CS51000025'           TO WGLOB-MSG-REF-INFO
014653*        PERFORM  0260-1000-GENERATE-MESSAGE
014653*            THRU 0260-1000-GENERATE-MESSAGE-X
014653*    END-IF.
014653*
014653*    IF WGLOB-MSG-SEVRTY-FATAL
014653*        SET WS-BNFY-PERC-ERROR      TO TRUE
014653*    END-IF.
014653*
014653*7350-BEN-PERC-PRIM-ERROR-MSG-X.
014653*    EXIT.
014653*/
      *----------------------
       8000-CHECK-KEY-FIELDS.
      *----------------------

      *
      * CHECK FOR VALID POLICY, AND VERIFY ACCESS IS ALLOWED
      * ----------------------------------------------------
      * IF INVALID POLICY, WGLOB-MSG-ERROR-SW WILL BE SET > 0 BY
      * 0260-1000-GENERATE-MESSAGE. IF ACCESS IS NOT ALLOWED,
      * WGLOB-RETURN-CODE IS SET (WGLOB-MSG-ERROR-SW IS RESET TO ZERO
      * BY POLICY ACCESS VERIFICATION MODULE).
      *
           MOVE MIR-POL-ID-BASE             TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX              TO WPOL-POL-ID-SFX.

014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.

014221     EVALUATE TRUE
014221         WHEN  WS-BUS-FCN-RETRIEVE
014221         WHEN  WS-BUS-FCN-CREATE
014221         WHEN  WS-BUS-FCN-SEARCH
014221               PERFORM  POL-1000-READ-TWRK-TS
014221                   THRU POL-1000-READ-TWRK-TS-X
014221         WHEN  WS-BUS-FCN-UPDATE
014221         WHEN  WS-BUS-FCN-DELETE
014221               PERFORM  POL-2000-UPDATE-TWRK-TS
014221                   THRU POL-2000-UPDATE-TWRK-TS-X
014221               IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                   MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221                   MOVE 'POL'             TO WGLOB-MSG-PARM (01)
014221                   MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
014221                   PERFORM  0260-1000-GENERATE-MESSAGE
014221                       THRU 0260-1000-GENERATE-MESSAGE-X
014221                   GO TO 8000-CHECK-KEY-FIELDS-X
014221                END-IF
014221     END-EVALUATE.

           IF WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  8100-VERIFY-POLICY-ACCESS
                   THRU 8100-VERIFY-POLICY-ACCESS-X
           END-IF.

      *
      *  VALIDATE SEQUENCE NUMBER (BENEFICIARY)
      *
           MOVE 'N'                        TO L0280-SIGN-IND.
           MOVE 0                          TO L0280-PRECISION.
           MOVE 3                          TO L0280-LENGTH.
           MOVE 3                          TO L0280-INPUT-SIZE.
           MOVE MIR-BNFY-SEQ-NUM                  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     'SEQUENCE NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS51000027'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *
      *  VALIDATE COVERAGE NUMBER
      *
           IF MIR-CVG-NUM = SPACES
               GO TO 8000-CHECK-KEY-FIELDS-X
           END-IF.

           MOVE 'N'                        TO L0280-SIGN-IND.
           MOVE 0                          TO L0280-PRECISION.
           MOVE 2                          TO L0280-LENGTH.
           MOVE 2                          TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-NUM                TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     'COVERAGE NUMBER MUST BE VALID NUMERIC OR SPACES'
               MOVE 'CS51000028'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8000-CHECK-KEY-FIELDS-X.
           EXIT.

      *--------------------------
       8100-VERIFY-POLICY-ACCESS.
      *--------------------------

      *
      * VERIFY POLICY ACCESS ALLOWED (NOT A CONFIDENTIAL POLICY)
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    SET  L5400-CTL-MSG-NOT-REQD TO TRUE.

016440     IF WS-BUS-FCN-UPDATE
016440        SET L5400-POL-XFER-UPDATE TO TRUE
016440     END-IF.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               MOVE '1'                TO WGLOB-RETURN-CODE
           END-IF.

       8100-VERIFY-POLICY-ACCESS-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-CVG-NUM-G.
           MOVE SPACES                 TO MIR-BNFY-SEQ-NUM-G.
           MOVE SPACES                 TO MIR-CLI-ID-G.
           MOVE SPACES                 TO MIR-BNFY-NM-G.
           MOVE SPACES                 TO MIR-BNFY-TYP-CD-G.
           MOVE SPACES                 TO MIR-BNFY-DESGNT-CD-G.
           MOVE SPACES                 TO MIR-BNFY-PRCDS-PCT-G.
           MOVE SPACES                 TO MIR-BNFY-REL-INSRD-CD-G.
020477     MOVE SPACES                 TO MIR-DESGNT-BNFY-IND-G.
           MOVE SPACES                 TO MIR-BNFY-NM.
           MOVE SPACES                 TO MIR-CLI-ADDR-TYP-CD.
           MOVE SPACES                 TO MIR-BNFY-DESGNT-CD.
           MOVE SPACES                 TO MIR-BNFY-PRCDS-PCT.
           MOVE SPACES                 TO MIR-BNFY-TYP-CD.
           MOVE SPACES                 TO MIR-BNFY-REL-INSRD-CD.
           MOVE SPACES                 TO MIR-BNFY-MINR-IND.
020477     MOVE SPACES                 TO MIR-DESGNT-BNFY-IND.


           IF NOT WS-BUS-FCN-SEARCH
               MOVE SPACES             TO MIR-CVG-NUM
               MOVE SPACES             TO MIR-CLI-ID
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  WS-BUS-FCN-SEARCH
               MOVE RBENE-CVG-NUM          TO MIR-CVG-NUM-T (WS-SUB)
020874*        MOVE RBENE-BNFY-SEQ-NUM    TO WS-PIC-9-3
020874*        MOVE WS-PIC-9-3            TO MIR-BNFY-SEQ-NUM-T (WS-SUB)
020874         MOVE RBENE-BNFY-SEQ-NUM    TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BNFY-SEQ-NUM-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-BNFY-SEQ-NUM-T (WS-SUB)
               MOVE RBENE-CLI-ID           TO MIR-CLI-ID-T (WS-SUB)
               MOVE RBENE-BNFY-NM          TO MIR-BNFY-NM-T (WS-SUB)
               MOVE RBENE-BNFY-TYP-CD    TO MIR-BNFY-TYP-CD-T (WS-SUB)
               MOVE RBENE-BNFY-DESGNT-CD
                                     TO MIR-BNFY-DESGNT-CD-T (WS-SUB)
020874*        MOVE RBENE-BNFY-PRCDS-PCT   TO WS-PIC-Z-3
020874*        MOVE WS-PIC-Z-3        TO MIR-BNFY-PRCDS-PCT-T (WS-SUB)
020874         MOVE RBENE-BNFY-PRCDS-PCT  TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BNFY-PRCDS-PCT-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-BNFY-PRCDS-PCT-T (WS-SUB)
               MOVE RBENE-BNFY-REL-INSRD-CD
                                    TO MIR-BNFY-REL-INSRD-CD-T (WS-SUB)
020477         MOVE RBENE-DESGNT-BNFY-IND  TO MIR-DESGNT-BNFY-IND-T
020477                                        (WS-SUB)
           ELSE
               MOVE RBENE-BNFY-NM          TO MIR-BNFY-NM
               MOVE RBENE-CLI-ID           TO MIR-CLI-ID
               MOVE 'N'                    TO MIR-DV-BNFY-UPDT-IND
               MOVE RBENE-CLI-ADDR-TYP-CD  TO MIR-CLI-ADDR-TYP-CD
               MOVE RBENE-CVG-NUM          TO MIR-CVG-NUM
               MOVE RBENE-BNFY-DESGNT-CD   TO MIR-BNFY-DESGNT-CD
020874*        MOVE RBENE-BNFY-PRCDS-PCT   TO WS-PIC-9-3
020874*        MOVE WS-PIC-9-3             TO MIR-BNFY-PRCDS-PCT
020874         MOVE RBENE-BNFY-PRCDS-PCT  TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BNFY-PRCDS-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-BNFY-PRCDS-PCT
               MOVE RBENE-BNFY-TYP-CD      TO MIR-BNFY-TYP-CD
               MOVE RBENE-BNFY-REL-INSRD-CD TO MIR-BNFY-REL-INSRD-CD
               MOVE RBENE-BNFY-MINR-IND    TO MIR-BNFY-MINR-IND
020477         MOVE RBENE-DESGNT-BNFY-IND  TO MIR-DESGNT-BNFY-IND
           END-IF.

026055     SET WS-POL-BNFY-XIST            TO TRUE.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                      TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0832-0000-INIT-PARM-INFO
025970         THRU 0832-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5120-0000-INIT-PARM-INFO
025970         THRU 5120-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

025970 COPY XCPS8090.
010311 COPY CCPSPGA.
018764*COPY CCCL0832.
025970 COPY CCPS0832.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL0832.
      /
       COPY CCPS2435.
      /
018764*COPY CCCL2435.
018764 COPY CCPL2435.
      /
018764*COPY CCCL2440.
018764 COPY CCPL2440.
020478 COPY CCPS2440.
      /
018764*COPY CCCL5120.
025970 COPY CCPS5120.
018764 COPY CCPL5120.
      /
       COPY CCPS5400.
      /
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
       COPY CCPS5600.
      /
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      /
016537*COPY CCPS5950.
      /
016537*COPY CCCL5950.
      /
016503 COPY CCPS0289.
      /
018764*COPY CCCL0289.
018764 COPY CCPL0289.
      /
010387 COPY CCPEADDR.
      /
       COPY NCPEBTOI.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
      /
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
020477 COPY XCPS8960.
020477 COPY XCPL8960.
020477/
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014660*COPY XCPPMEXT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPBBENC.
      /
       COPY CCPABENE.
       COPY CCPBBENE.
       COPY CCPCBENE.
       COPY CCPNBENE.
       COPY CCPUBENE.
016537*COPY CCPVBENE.
       COPY CCPXBENE.
010310 COPY CCPFBENE.
      /
       COPY CCPNCVG.
021930*COPY CCPUCVG.
      /
016503 COPY NCPPCVGS.
       COPY CCPNEDIT.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNRL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
557708*COPY XCCPHNDL.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM5100                     **
      *****************************************************************
