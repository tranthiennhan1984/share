      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM0452.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0452                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE MAINTAIN FUNCTION       **
      **            FOR THE INFORCE POLICY MODIFICATION.             **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
025390**  7.0       PHST FOR UPDATE POLICY DISCOUNT PERCENT          **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0452'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-UPDATE             VALUE '0452'.
           05  WS-REDO-SW                        PIC X(01).
               88  WS-REDO-OK                    VALUE 'Y'.
               88  WS-REDO-NOT-OK                VALUE 'N'.
           05  WS-EFF-DT                         PIC X(10).
           05  WS-ISS-EFF-DT                     PIC X(10).
           05  WS-DBG-ADD-RIDER-IND              PIC X.
               88  WS-DBG-ADD-RIDER-YES          VALUE 'Y'.
           05  WS-DBG-DEL-RIDER-IND              PIC X.
               88  WS-DBG-DEL-RIDER-YES          VALUE 'Y'.
           05  WS-DBG-EDIT-IND                   PIC X.
               88  WS-DBG-EDIT-OK                VALUE 'Y'.
               88  WS-DBG-EDIT-ERROR             VALUE 'E'.
           05  WS-DBG-ANNV-VALU-CHG-IND          PIC X.
               88  WS-DBG-ANNV-VALU-CHG-YES      VALUE 'Y'.
               88  WS-DBG-ANNV-VALU-CHG-NO       VALUE 'N'.
           05  WS-DBG-MAV-CHG-IND                PIC X.
               88  WS-DBG-MAV-CHG-YES            VALUE 'Y'.
               88  WS-DBG-MAV-CHG-NO             VALUE 'N'.
           05  WS-DBG-ROLU-CHG-IND               PIC X.
               88  WS-DBG-ROLU-CHG-YES           VALUE 'Y'.
               88  WS-DBG-ROLU-CHG-NO            VALUE 'N'.
           05  WS-DBG-ANNV-VALU-RIDER-IND        PIC X.
               88  WS-DBG-ANNV-VALU-RIDER        VALUE 'Y'.
               88  WS-DBG-ANNV-VALU-RIDER-NONE   VALUE 'N'.
           05  WS-DBG-MAV-RIDER-IND              PIC X.
               88  WS-DBG-MAV-RIDER              VALUE 'Y'.
               88  WS-DBG-MAV-RIDER-NONE         VALUE 'N'.
           05  WS-DBG-ROLU-RIDER-IND             PIC X.
               88  WS-DBG-ROLU-RIDER             VALUE 'Y'.
               88  WS-DBG-ROLU-RIDER-NONE        VALUE 'N'.

           05  WS-FND-PRICE-AVAIL-IND            PIC X.
               88  WS-FND-PRICE-AVAIL-YES        VALUE 'Y'.
               88  WS-FND-PRICE-AVAIL-NO         VALUE 'N'.
           05  WS-DBG-DEFER-REQUIRE-IND          PIC X.
               88  WS-DBG-DEFER-REQUIRE-YES      VALUE 'Y'.
               88  WS-DBG-DEFER-REQUIRE-NO       VALUE 'N'.
           05  WS-IPROF-ERROR-IND                PIC X.
               88  WS-IPROF-ERROR-NO             VALUE 'N'.
               88  WS-IPROF-ERROR-YES            VALUE 'Y'.
           05  WS-IPROF-PRCES-TYP-CD             PIC X.
               88  WS-IPROF-PRCES-TYP-EDIT       VALUE 'E'.
               88  WS-IPROF-PRCES-TYP-ALL        VALUE 'A'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWCVGS.
       COPY CCWWINDX.
       COPY CCWWLOCK.
       COPY XCWWWKDT.
       COPY XCWEBLCH.
       COPY CCWWIHSD.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.

       COPY CCFRPH.
       COPY CCFWPH.

       COPY CCFHPOL.
       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFRPDBG.
       COPY CCFWPDBG.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0201.
       COPY CCWL0289.
025390 COPY XCWL0290.
       COPY CCWL0620.
       COPY CCWL0985.
031037 COPY CCWL2408.
028298 COPY CCWL2626.

       COPY CCWL2420.
       COPY CCWL2430.
       COPY CCWL2664.
       COPY CCWL2735.
       COPY CCWL3330.
       COPY CCWL4750.
       COPY CCWL4780.
       COPY CCWL5400.
       COPY CCWL7300.
       COPY CCWL7306.
       COPY CCWLPGA.
       COPY CCWLFRNE.

       COPY FCWL8170.
       COPY FCWLFUND.

       COPY XCWL0316.
       COPY XCWL1640.
       COPY XCWL1670.
       COPY XCWL1680.

       COPY XCWL8090.

       COPY XCWLCOMM REPLACING '$VAR1' BY '0452'.
           15  LCOMM-TWRK-AREA         PIC X(264).
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0452.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0452'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------
      *
      * PERFORM EDITS
      *
           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.
           SET WS-REDO-OK                TO TRUE

           PERFORM  COMM-1000-RETRIEVE-TWRK
               THRU COMM-1000-RETRIEVE-TWRK-X.

           IF  NOT LCOMM-RETRN-OK
               MOVE SPACE                TO LCOMM-TWRK-AREA
           END-IF.

           PERFORM  COMM-3000-DELETE-TWRK
               THRU COMM-3000-DELETE-TWRK-X.

           IF  MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  2300-VERIFY-PASS
                   THRU 2300-VERIFY-PASS-X
               IF  WS-REDO-NOT-OK
               OR  MIR-RETRN-TS-MISMATCH
                   GO TO 2000-UPDATE-X
               END-IF
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
      *
      * VALIDATE CLIENTS DATE OF DEATH FIELDS
      *
           PERFORM  0985-1000-BUILD-PARM-INFO
               THRU 0985-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                TO L0985-EFF-DT.

           PERFORM  0985-1000-VAL-POL-DT-OF-DTH
               THRU 0985-1000-VAL-POL-DT-OF-DTH-X.

           IF  NOT L0985-RETRN-OK
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  2220-EDIT-FRNE
               THRU 2220-EDIT-FRNE-X.

           PERFORM  2420-1000-BUILD-PARM-INFO
               THRU 2420-1000-BUILD-PARM-INFO-X.

           PERFORM  2210-MOVE-MIR-TO-L2420
               THRU 2210-MOVE-MIR-TO-L2420-X.

           MOVE WS-EFF-DT                TO L2420-EFF-DT.
           SET L2420-PRCES-NON-BILLING   TO TRUE.
           SET L2420-PRCES-TYP-EDIT-ONLY TO TRUE.
           SET L2420-REDO-WARNING        TO TRUE.

           SET WS-IPROF-ERROR-NO         TO TRUE.
           SET WS-IPROF-PRCES-TYP-EDIT   TO TRUE.
           PERFORM  6500-EDIT-IPROF
               THRU 6500-EDIT-IPROF-X.

           PERFORM  2420-1000-MODIFY-POLICY
               THRU 2420-1000-MODIFY-POLICY-X.

           PERFORM  6600-UPDATE-IPROF
               THRU 6600-UPDATE-IPROF-X.

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               PERFORM  6000-EDIT-POLG-DBG-INFO
                   THRU 6000-EDIT-POLG-DBG-INFO-X
               IF WS-DBG-DEFER-REQUIRE-YES
      *MSG: FUND PRICES NOT AVAILABLE, DEATH BENEFIT RIDER CHANGE WILL
      *     BE DEFERRED
                  MOVE 'CS04520013'      TO WGLOB-MSG-REF-INFO
                  PERFORM 0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           MOVE L2420-POLICY-CHG-DATA    TO LCOMM-TWRK-AREA.
           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.

           IF  L2420-RETRN-ERROR
           OR  L2420-EDIT-ERROR
           OR  WS-DBG-EDIT-ERROR
           OR  WS-IPROF-ERROR-YES
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

      * REDISPLAY CLIENT NAME

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID              TO L2430-POL-ID.
           MOVE ZERO                     TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE                L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM
                                         TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                         TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                         TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                         TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD     TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME    TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES               TO MIR-DV-OWN-CLI-NM
           END-IF.

       2000-UPDATE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  2110-EDIT-POLICY
               THRU 2110-EDIT-POLICY-X.

           PERFORM  2120-EDIT-EFF-DT
               THRU 2120-EDIT-EFF-DT-X.

           PERFORM  2130-CHECK-IHSD-DATE
               THRU 2130-CHECK-IHSD-DATE-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       2110-EDIT-POLICY.
      *-----------------

           MOVE MIR-POL-ID-BASE          TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX           TO WPOL-POL-ID-SFX.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X

           IF  NOT WPOL-IO-OK
               SET WGLOB-RETURN-ERROR    TO TRUE
               MOVE 'CS00000019'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-POLICY-X
           END-IF.

           PERFORM  7306-1000-BUILD-PARM-INFO
               THRU 7306-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID              TO L7306-POL-ID.
           PERFORM  7306-1000-GET-DBG-INFO
               THRU 7306-1000-GET-DBG-INFO-X.

           IF  RPOL-POL-SUSPENDED
      *MSGS: POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2110-EDIT-POLICY-X
               END-IF
           END-IF.

           IF  RPOL-POL-STAT-BEFORE-SETL
      *MSGS: PENDING POLICY - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000238'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2110-EDIT-POLICY-X
               END-IF
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET L5400-CRCY-MSG-REQD       TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.
           SET L5400-POL-XFER-UPDATE     TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2110-EDIT-POLICY-X.
           EXIT.
      /
      *-----------------
       2120-EDIT-EFF-DT.
      *-----------------

           MOVE MIR-PCHST-EFF-IDT-NUM    TO L1640-EXTERNAL-DATE
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-INTERNAL-DATE = WWKDT-ZERO-DT
               MOVE 'CS00000054'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
           END-IF.

       2120-EDIT-EFF-DT-X.
           EXIT.

      *--------------------
       2130-CHECK-IHSD-DATE.
      *--------------------

      * EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE

           IF  WGLOB-RETURN-ERROR
               GO TO 2130-CHECK-IHSD-DATE-X
           END-IF.

           MOVE WS-EFF-DT            TO WIHSD-EFF-DT.
           PERFORM  IHSD-2000-CHK-IHSD-PROCESS
               THRU IHSD-2000-CHK-IHSD-PROCESS-X.

           IF WIHSD-CHK-EFF-DT-NOT-OK
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

       2130-CHECK-IHSD-DATE-X.
           EXIT.
      /
      *-----------------------------
       2210-MOVE-MIR-TO-L2420.
      *-----------------------------
      * BUILD LINKAGE AREA TO POLICY CHANGE MODULE

      * OBTAIN L2420 DATA INPUT FROM COMM AREA. IF A FIELD HAS BEEN
      * CHANGED BY THE USER, IT WILL REPLACE L2420 VALUE IN CODE BELOW

           MOVE SPACES                   TO L2420-POLICY-CHG-DATA.

           IF  MIR-POL-DB-OPT-CD     NOT = SPACES
               MOVE MIR-POL-DB-OPT-CD    TO L2420-DBEN
           END-IF.

           IF  MIR-POL-ISS-EFF-DT    NOT = SPACES
               MOVE MIR-POL-ISS-EFF-DT   TO L2420-ISS-EFF-DT
           END-IF.

           IF  MIR-DV-ANNV-VALU-IND NOT = SPACE
               MOVE MIR-DV-ANNV-VALU-IND
                                         TO L2420-DBG-ANNV-VALU-IND
           END-IF.

           IF  MIR-DV-POL-DBG-MAV-IND NOT = SPACE
               MOVE MIR-DV-POL-DBG-MAV-IND
                                         TO L2420-DBG-MAV-IND
           END-IF.

           IF  MIR-DV-POL-DBG-ROLU-IND NOT = SPACE
               MOVE MIR-DV-POL-DBG-ROLU-IND
                                         TO L2420-DBG-ROLU-IND
           END-IF.

           IF  MIR-POL-ENHC-NELCT-QTY NOT = SPACE
               MOVE MIR-POL-ENHC-NELCT-QTY
                                         TO L2420-POL-ENHC-NELCT-QTY
           END-IF.

           EVALUATE TRUE

               WHEN MIR-PRFL-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES           TO L2420-PRFL-ID

               WHEN MIR-PRFL-ID = SPACE
                   PERFORM  6700-READ-INV-PRFL
                       THRU 6700-READ-INV-PRFL-X
                   MOVE MIR-PRFL-ID      TO L2420-PRFL-ID

               WHEN OTHER
                   MOVE MIR-PRFL-ID      TO L2420-PRFL-ID

           END-EVALUATE.

025390     IF  MIR-PREM-DSCNT-TYP-CD  NOT = SPACES
025390         MOVE MIR-PREM-DSCNT-TYP-CD  TO L2420-PREM-DSCNT-TYP-CD
025390     END-IF.
025390
025390     IF  MIR-POL-PREM-DSCNT-PCT NOT = SPACES
025390         MOVE MIR-POL-PREM-DSCNT-PCT TO L2420-POL-PREM-DSCNT-PCT
025390     END-IF.
029060
029060     IF  MIR-POL-ANPAYO-1-AMT NOT = SPACES
029060         MOVE MIR-POL-ANPAYO-1-AMT TO L2420-POL-ANPAYO-1-AMT-X
029060     END-IF.
029060
029060     IF  MIR-POL-ANPAYO-2-AMT NOT = SPACES
029060         MOVE MIR-POL-ANPAYO-2-AMT TO L2420-POL-ANPAYO-2-AMT-X
029060     END-IF.
029060
           MOVE L2420-POLICY-CHG-DATA    TO LCOMM-TWRK-AREA.

       2210-MOVE-MIR-TO-L2420-X.
           EXIT.


      *----------------------------
       2220-EDIT-FRNE.
      *----------------------------

           PERFORM  0316-1000-BUILD-PARM-INFO
               THRU 0316-1000-BUILD-PARM-INFO-X.

           SET  L0316-RGN-EXIT-FRGN-CNTNT-EDIT
                                         TO TRUE
           MOVE RPOL-POL-CTRY-CD         TO L0316-CTRY-CD.

           PERFORM  0316-1000-GET-RGN-EXIT-PGM
               THRU 0316-1000-GET-RGN-EXIT-PGM-X.

           IF  NOT L0316-RETRN-OK
      *MSG: NO FOREIGN CONTENT INSTRUCTION REGIONAL EXIT FOUND FOR @1
      *     COUNTRY CODE
               MOVE 'CS04520002'         TO WGLOB-MSG-REF-INFO
               MOVE RPOL-POL-CTRY-CD     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2220-EDIT-FRNE-X
           END-IF.

           IF  L0316-RGN-EXIT-STAT-ACTV
               PERFORM  2221-FRNE-RGN-EXIT
                   THRU 2221-FRNE-RGN-EXIT-X
           END-IF.

       2220-EDIT-FRNE-X.
           EXIT.

      *----------------------------
       2221-FRNE-RGN-EXIT.
      *----------------------------

           PERFORM  FRNE-1000-BUILD-PARM-INFO
               THRU FRNE-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID              TO LFRNE-POL-ID.
           MOVE WS-EFF-DT                TO LFRNE-EFF-DT.
           SET LFRNE-RQST-FC-EDIT        TO TRUE.

           PERFORM  FRNE-1000-REGION-EXIT
               THRU FRNE-1000-REGION-EXIT-X.

           IF  NOT LFRNE-RETRN-OK
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2221-FRNE-RGN-EXIT-X.
           EXIT.


      *-----------------
       2300-VERIFY-PASS.
      *-----------------

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: 'TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2,
      *      PROCESS NOT COMPLETE'
               MOVE 'XS00000303'         TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2300-VERIFY-PASS-X
           END-IF.

           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           MOVE MIR-POL-ISS-EFF-DT       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE      TO WS-ISS-EFF-DT.

           SET WS-REDO-OK                TO  TRUE.
           IF  (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
           AND  RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
               CONTINUE
           ELSE
               PERFORM  5000-INVOKE-REDO
                   THRU 5000-INVOKE-REDO-X
           END-IF.

           IF WS-REDO-NOT-OK
              GO TO 2300-VERIFY-PASS-X
           END-IF.

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT                TO L4750-EFF-DT.
           SET L4750-FCN-DRVR-SECONDARY  TO TRUE.
           SET L4750-PRCES-EXCLUSIVE     TO TRUE.
           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  2320-VERIFY-MODB-CHANGES
                   THRU 2320-VERIFY-MODB-CHANGES-X
               PERFORM  6100-UPDATE-POLG-DBG-INFO
                   THRU 6100-UPDATE-POLG-DBG-INFO-X
           END-IF.

031037     MOVE ZERO                     TO WGLOB-PCHST-REL-SEQ-NUM.
      * IF THE DATA HAS NOT BEEN CHANGED, BYPASS REMAINING UPDATES.

           IF  L2420-POLICY-CHG-DATA = SPACES
           AND L4750-POL-UPDATE-NOT-REQD
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
               GO TO 2300-VERIFY-PASS-X
           END-IF.

           PERFORM  2340-UPDATE-POL-AND-CVGS
               THRU 2340-UPDATE-POL-AND-CVGS-X.

           IF  WGLOB-RETURN-ERROR
               MOVE 'XS00000229'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           END-IF.

       2300-VERIFY-PASS-X.
           EXIT.

      *-------------------------
       2320-VERIFY-MODB-CHANGES.
      *-------------------------

           SET WS-IPROF-ERROR-NO         TO TRUE.
           SET WS-IPROF-PRCES-TYP-EDIT   TO TRUE.
           PERFORM  6500-EDIT-IPROF
               THRU 6500-EDIT-IPROF-X.

           PERFORM  2420-1000-BUILD-PARM-INFO
               THRU 2420-1000-BUILD-PARM-INFO-X.

           MOVE LCOMM-TWRK-AREA          TO L2420-POLICY-CHG-DATA.
           MOVE WS-EFF-DT                TO L2420-EFF-DT.
           SET L2420-PRCES-NON-BILLING   TO TRUE.
031037
031037     PERFORM  2408-0000-INIT-PARM-INFO
031037         THRU 2408-0000-INIT-PARM-INFO-X.
031037     MOVE RPOL-POL-ID              TO L2408-POL-ID.
031037     MOVE L2420-EFF-DT             TO L2408-EFF-DT.
031037     PERFORM  2408-2000-NXT-PHST-SEQ
031037         THRU 2408-2000-NXT-PHST-SEQ-X.
031037     MOVE L2408-NXT-PCHST-SEQ-NUM  TO WGLOB-PCHST-REL-SEQ-NUM.
031037     MOVE L2408-NXT-PCHST-SEQ-NUM  TO L2420-PCHST-SEQ-NUM.
031037
           PERFORM  2420-1000-MODIFY-POLICY
               THRU 2420-1000-MODIFY-POLICY-X.

           IF  L2420-RETRN-ERROR
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

           SET WS-IPROF-PRCES-TYP-ALL    TO TRUE.
           PERFORM  6600-UPDATE-IPROF
               THRU 6600-UPDATE-IPROF-X.
           IF  WS-IPROF-ERROR-YES
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2320-VERIFY-MODB-CHANGES-X.
           EXIT.

      *-------------------------
       2340-UPDATE-POL-AND-CVGS.
      *-------------------------

           MOVE RPOL-REC-INFO            TO HPOL-REC-INFO.
           MOVE MIR-POL-ID-BASE          TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX           TO WPOL-POL-ID-SFX.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE HPOL-REC-INFO            TO RPOL-REC-INFO.

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.
           IF  WS-EFF-DT < RPOL-POL-ISS-EFF-DT
               MOVE RPOL-POL-ISS-EFF-DT  TO L0289-LO-PAC-DT
               MOVE RPOL-POL-ISS-EFF-DT  TO L0289-LO-CRC-DT
               MOVE RPOL-POL-ISS-EFF-DT  TO L0289-LO-DD2-DT
               MOVE RPOL-POL-ISS-EFF-DT  TO L0289-PROC-EFF-DT
           ELSE
               MOVE WS-EFF-DT            TO L0289-LO-PAC-DT
               MOVE WS-EFF-DT            TO L0289-LO-CRC-DT
               MOVE WS-EFF-DT            TO L0289-LO-DD2-DT
               MOVE WS-EFF-DT            TO L0289-PROC-EFF-DT
           END-IF.
           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.
           IF  L0289-RETRN-OK
               MOVE L0289-NXT-ACTV-TYP-CD
                                         TO RPOL-NXT-ACTV-TYP-CD
               MOVE L0289-NXT-ACTV-DT
                                         TO RPOL-POL-NXT-ACTV-DT
           ELSE
               MOVE 'RSH'                TO RPOL-NXT-ACTV-TYP-CD
               MOVE WGLOB-PROCESS-DATE
                                         TO RPOL-POL-NXT-ACTV-DT
           END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

       2340-UPDATE-POL-AND-CVGS-X.
           EXIT.


      *-----------------
       5000-INVOKE-REDO.
      *-----------------

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 5000-INVOKE-REDO-X
           END-IF.

           IF  WS-ISS-EFF-DT = RPOL-POL-ISS-EFF-DT
               CONTINUE
           ELSE
               GO TO 5000-INVOKE-REDO-X
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           SET L4780-REDO-WARNING        TO TRUE.
           SET L4780-MSG-SUPPRESS        TO TRUE.
           MOVE WS-EFF-DT                TO L4780-EFF-DT.
           MOVE RPOL-PREV-BTCH-PRCES-DT  TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE     TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           EVALUATE  TRUE
               WHEN L4780-RETRN-ERROR
               WHEN L4780-RETRN-INVALID-REQUEST
                    SET WS-REDO-NOT-OK   TO TRUE
               WHEN  (L4780-RETRN-OK
               AND L4780-ACTIVITY-DUE
               AND L4780-REDO-ALLOW)
                   MOVE WS-EFF-DT        TO L0201-EFF-DT
                   SET L0201-AUTO-REDO   TO TRUE
                   PERFORM  0201-1000-AUTO-PROCESSING
                       THRU 0201-1000-AUTO-PROCESSING-X
                   PERFORM  0289-1000-INIT-PARM-INFO
                       THRU 0289-1000-INIT-PARM-INFO-X
                   MOVE WS-EFF-DT        TO L0289-LO-PAC-DT
                   MOVE WS-EFF-DT        TO L0289-LO-CRC-DT
                   MOVE WS-EFF-DT        TO L0289-LO-DD2-DT
                   MOVE WS-EFF-DT        TO L0289-PROC-EFF-DT
                   PERFORM  0289-1000-OBTAIN-NXT-ACTV
                       THRU 0289-1000-OBTAIN-NXT-ACTV-X
                   IF  L0289-RETRN-OK
                       MOVE L0289-NXT-ACTV-TYP-CD
                                         TO RPOL-NXT-ACTV-TYP-CD
                       MOVE L0289-NXT-ACTV-DT
                                         TO RPOL-POL-NXT-ACTV-DT
                   ELSE
                       MOVE 'RSH'        TO RPOL-NXT-ACTV-TYP-CD
                       MOVE WGLOB-PROCESS-DATE
                                         TO RPOL-POL-NXT-ACTV-DT
                   END-IF
                   MOVE RPOL-REC-INFO    TO HPOL-REC-INFO
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
                   MOVE HPOL-REC-INFO    TO RPOL-REC-INFO
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
                   PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                       THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
                   PERFORM  POL-1000-READ-TWRK-TS
                       THRU POL-1000-READ-TWRK-TS-X
                   IF  L0201-RETRN-OK
                       MOVE 'XS00000307' TO  WGLOB-MSG-REF-INFO
      *MSG: 'AUTO REDO PROCESSING COMPLETED
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       SET WS-REDO-NOT-OK
                                         TO TRUE
                       IF  NOT L0201-INCOMPLETE-DUE-ACTV
                           MOVE 'XS00000308'
                                         TO WGLOB-MSG-REF-INFO
      *MSG: PROBLEM IN AUTO REDO PROCESSING
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
                       END-IF
                   END-IF
           END-EVALUATE.

       5000-INVOKE-REDO-X.
           EXIT.

      *-----------------------
       6000-EDIT-POLG-DBG-INFO.
      *-----------------------

           MOVE MIR-DV-ANNV-VALU-IND     TO WS-DBG-ANNV-VALU-RIDER-IND.
           MOVE MIR-DV-POL-DBG-MAV-IND   TO WS-DBG-MAV-RIDER-IND.
           MOVE MIR-DV-POL-DBG-ROLU-IND  TO WS-DBG-ROLU-RIDER-IND.

           SET  WS-DBG-EDIT-OK           TO TRUE.
           SET  WS-DBG-ANNV-VALU-CHG-NO  TO TRUE.
           SET  WS-DBG-MAV-CHG-NO        TO TRUE.
           SET  WS-DBG-ROLU-CHG-NO       TO TRUE.
           SET  WS-DBG-DEFER-REQUIRE-NO  TO TRUE.

           IF  WS-DBG-ANNV-VALU-RIDER-IND NOT =
               L7306-POL-DBG-ANNV-VALU-IND
               SET WS-DBG-ANNV-VALU-CHG-YES
                                         TO TRUE
           END-IF.

           IF  WS-DBG-MAV-RIDER-IND NOT =
               L7306-POL-DBG-MAV-IND
               SET WS-DBG-MAV-CHG-YES    TO TRUE
           END-IF.

           IF  WS-DBG-ROLU-RIDER-IND NOT =
               L7306-POL-DBG-ROLU-IND
               SET WS-DBG-ROLU-CHG-YES   TO TRUE
           END-IF.

           IF  WS-DBG-ANNV-VALU-CHG-NO
           AND WS-DBG-MAV-CHG-NO
           AND WS-DBG-ROLU-CHG-NO
               GO TO 6000-EDIT-POLG-DBG-INFO-X
           END-IF.

           IF  RPOL-POL-INS-TYP-FPA
           OR  RPOL-POL-INS-TYP-SEG-FUND
               CONTINUE
           ELSE
      *MSG: DEATH BENEFIT RIDER FOR ANNUITY POLICY ONLY
               MOVE 'CS04520004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DBG-EDIT-ERROR     TO TRUE
               GO TO 6000-EDIT-POLG-DBG-INFO-X
           END-IF.

           IF  L7306-POL-DBG-BASIC-CSV
      * MSG: BASIC PLAN OPTION = CSV. NO OTHER DEATH BENEFIT GUARANTEES
      *      ALLOWED
               MOVE 'CS04520003'         TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DBG-EDIT-ERROR     TO TRUE
               GO TO 6000-EDIT-POLG-DBG-INFO-X
           END-IF.

           INITIALIZE  WS-DBG-ADD-RIDER-IND.
           INITIALIZE  WS-DBG-DEL-RIDER-IND.

           IF  WS-DBG-ANNV-VALU-CHG-YES
               IF  L7306-POL-DBG-ANNV-VALU-NONE
                   SET WS-DBG-ADD-RIDER-YES
                                         TO TRUE
               ELSE
                   SET WS-DBG-DEL-RIDER-YES
                                         TO TRUE
               END-IF
           END-IF.

           IF  WS-DBG-MAV-CHG-YES
               IF  L7306-POL-DBG-MAV-NONE
                   SET WS-DBG-ADD-RIDER-YES
                                         TO TRUE
               ELSE
                   SET WS-DBG-DEL-RIDER-YES
                                         TO TRUE
               END-IF
           END-IF.

           IF  WS-DBG-ROLU-CHG-YES
               IF  L7306-POL-DBG-ROLU-NONE
                   SET WS-DBG-ADD-RIDER-YES
                                         TO TRUE
               ELSE
                   SET WS-DBG-DEL-RIDER-YES
                                         TO TRUE
               END-IF
           END-IF.

           IF  WS-DBG-ADD-RIDER-YES
           AND WS-DBG-DEL-RIDER-YES
      * MSG: CANNOT ADD AND DELETE DEATH BENEFIT GUARANTEES RIDERS AT
      *      THE SAME TIME
              MOVE 'CS04520005'          TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              SET WS-DBG-EDIT-ERROR      TO TRUE
              GO TO 6000-EDIT-POLG-DBG-INFO-X
           END-IF.

           IF  L7306-POL-DBG-BASIC-NONE
           AND L7306-POL-DBG-RESET-NONE
           AND WS-DBG-ADD-RIDER-YES
      *MSG: NO BASIC PLAN OPTION OR RESET/LOCK-IN OPTION. NO OTHER
      *     DEATH BENEFIT GUARANTEE ALLOWED
               MOVE 'CS04520006'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WS-DBG-EDIT-ERROR TO TRUE
                   GO TO 6000-EDIT-POLG-DBG-INFO-X
               END-IF
           END-IF.

           MOVE ZERO                     TO I.
           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.

           PERFORM 3330-1000-BUILD-PARM-INFO
              THRU 3330-1000-BUILD-PARM-INFO-X.

           SET L3330-LOC-GR-TYP-DTHBG    TO TRUE.

           PERFORM 3330-1000-GET-LOC-GROUP
              THRU 3330-1000-GET-LOC-GROUP-X.

           IF  L3330-RETRN-OK
               CONTINUE
           ELSE
      * MSG: LOCATION GROUP NOT FOUND FOR DTHBG
              MOVE 'CS04520007'          TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET WS-DBG-EDIT-ERROR      TO TRUE
              GO TO 6000-EDIT-POLG-DBG-INFO-X
           END-IF.

           PERFORM  6010-EDIT-ANNV-VALU-RIDER
               THRU 6010-EDIT-ANNV-VALU-RIDER-X.

           PERFORM  6020-EDIT-MAV-RIDER
               THRU 6020-EDIT-MAV-RIDER-X.

           PERFORM  6030-EDIT-ROLU-RIDER
               THRU 6030-EDIT-ROLU-RIDER-X.

           IF WS-DBG-EDIT-ERROR
              GO TO 6000-EDIT-POLG-DBG-INFO-X
           END-IF.

           PERFORM  6050-EDIT-RIDER-CHG
               THRU 6050-EDIT-RIDER-CHG-X.

       6000-EDIT-POLG-DBG-INFO-X.
           EXIT.

      *--------------------------
       6010-EDIT-ANNV-VALU-RIDER.
      *--------------------------

           IF WS-DBG-ANNV-VALU-CHG-NO
           OR WS-DBG-ANNV-VALU-RIDER-NONE
              GO TO 6010-EDIT-ANNV-VALU-RIDER-X
           END-IF.

           MOVE LOW-VALUES               TO WPDBG-KEY.
           MOVE RPOL-PLAN-ID             TO WPDBG-PLAN-ID.
           MOVE L3330-LOC-GR-ID          TO WPDBG-LOC-GR-ID.
           SET  WPDBG-PLAN-DBG-TYP-ANNV-VALU
                                         TO TRUE.

           PERFORM  PDBG-1000-READ
               THRU PDBG-1000-READ-X.

           IF  NOT WPDBG-IO-OK
      *MSG: ACCOUNT VALUE ON A SPECIFIED ANNIVERSARY NOT ALLOWED FOR
      *     THE PLAN
               MOVE 'CS04520008'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DBG-EDIT-ERROR     TO TRUE
               GO TO 6010-EDIT-ANNV-VALU-RIDER-X
           END-IF.

           IF  L7306-POL-DBG-RESET
      *MSG: POLICY HAS BASIC RESET/LOCK-IN OPTION. ACCOUNT VALUE ON A
      *     SPECIFIED ANNIVERSARY CAN'T BE ADDED
               MOVE 'CS04520009'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DBG-EDIT-ERROR     TO TRUE
               GO TO 6010-EDIT-ANNV-VALU-RIDER-X
           END-IF.

       6010-EDIT-ANNV-VALU-RIDER-X.
           EXIT.

      *-------------------
       6020-EDIT-MAV-RIDER.
      *-------------------

           IF WS-DBG-MAV-CHG-NO
           OR WS-DBG-MAV-RIDER-NONE
              GO TO 6020-EDIT-MAV-RIDER-X
           END-IF.

           MOVE LOW-VALUES               TO WPDBG-KEY.
           MOVE RPOL-PLAN-ID             TO WPDBG-PLAN-ID.
           MOVE L3330-LOC-GR-ID          TO WPDBG-LOC-GR-ID.
           SET  WPDBG-PLAN-DBG-TYP-MAV   TO TRUE.

           PERFORM PDBG-1000-READ
              THRU PDBG-1000-READ-X.

           IF NOT WPDBG-IO-OK
      *MSG: MAXIMUM ACCOUNT VALUE NOT ALLOWED FOR THE PLAN
              MOVE 'CS04520010'          TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET WS-DBG-EDIT-ERROR      TO TRUE
              GO TO 6020-EDIT-MAV-RIDER-X
           END-IF.

       6020-EDIT-MAV-RIDER-X.
           EXIT.

      *--------------------
       6030-EDIT-ROLU-RIDER.
      *--------------------

           IF WS-DBG-ROLU-CHG-NO
           OR WS-DBG-ROLU-RIDER-NONE
              GO TO 6030-EDIT-ROLU-RIDER-X
           END-IF.

           MOVE LOW-VALUES               TO WPDBG-KEY.
           MOVE RPOL-PLAN-ID             TO WPDBG-PLAN-ID.
           MOVE L3330-LOC-GR-ID          TO WPDBG-LOC-GR-ID.
           SET  WPDBG-PLAN-DBG-TYP-ROLU  TO TRUE.

           PERFORM PDBG-1000-READ
              THRU PDBG-1000-READ-X.

           IF NOT WPDBG-IO-OK
      *MSG: PREMIUM ROLLUP-UP NOT ALLOWED FOR THE PLAN
              MOVE 'CS04520011'          TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET WS-DBG-EDIT-ERROR      TO TRUE
              GO TO 6030-EDIT-ROLU-RIDER-X
           END-IF.

       6030-EDIT-ROLU-RIDER-X.
           EXIT.

      *--------------------
       6050-EDIT-RIDER-CHG.
      *--------------------

           PERFORM  7300-1000-BUILD-PARM-INFO
               THRU 7300-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                TO L7300-EFF-DT.

           IF  WS-DBG-ANNV-VALU-CHG-YES
               SET L7300-DBG-CHNG-ANNV-VALU
                                         TO TRUE
           END-IF.

           IF  WS-DBG-MAV-CHG-YES
               SET L7300-DBG-CHNG-MAV    TO TRUE
           END-IF.

           IF  WS-DBG-ROLU-CHG-YES
               SET L7300-DBG-CHNG-ROLU   TO TRUE
           END-IF.


           EVALUATE TRUE

               WHEN  WS-DBG-ADD-RIDER-YES
                     SET L7300-DBG-ADD-RIDER
                                         TO TRUE

               WHEN  WS-DBG-DEL-RIDER-YES
                     SET L7300-DBG-DEL-RIDER
                                         TO TRUE

           END-EVALUATE.

           SET L7300-PRCES-TYP-EDIT-ONLY TO TRUE
           PERFORM  7300-2000-DBG-CHNG
               THRU 7300-2000-DBG-CHNG-X.

           IF  NOT L7300-RETRN-OK
               SET WS-DBG-EDIT-ERROR     TO TRUE
           END-IF.

           IF  L7300-DEFER-REQUIRE-YES
               SET  WS-DBG-DEFER-REQUIRE-YES
                                         TO TRUE
           END-IF.

       6050-EDIT-RIDER-CHG-X.
           EXIT.

      *-------------------------
       6100-UPDATE-POLG-DBG-INFO.
      *-------------------------

           PERFORM  6000-EDIT-POLG-DBG-INFO
               THRU 6000-EDIT-POLG-DBG-INFO-X.

           IF  WS-DBG-ANNV-VALU-CHG-NO
           AND WS-DBG-MAV-CHG-NO
           AND WS-DBG-ROLU-CHG-NO
               GO TO 6100-UPDATE-POLG-DBG-INFO-X
           END-IF.

           IF WS-DBG-EDIT-ERROR
              SET  WGLOB-RETURN-ERROR    TO TRUE
              GO TO 6100-UPDATE-POLG-DBG-INFO-X
           END-IF.

           IF WS-DBG-DEFER-REQUIRE-YES
              PERFORM  6150-DEFER-CHG-RIDER
                  THRU 6150-DEFER-CHG-RIDER-X
              GO TO 6100-UPDATE-POLG-DBG-INFO-X
           END-IF.

           PERFORM  6140-UPDATE-RIDER-CHG
               THRU 6140-UPDATE-RIDER-CHG-X.

           PERFORM  7306-1000-BUILD-PARM-INFO
               THRU 7306-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID              TO L7306-POL-ID.
           PERFORM  7306-1000-GET-DBG-INFO
               THRU 7306-1000-GET-DBG-INFO-X.

       6100-UPDATE-POLG-DBG-INFO-X.
           EXIT.

      *--------------------
       6140-UPDATE-RIDER-CHG.
      *--------------------

           PERFORM  7300-1000-BUILD-PARM-INFO
               THRU 7300-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                TO L7300-EFF-DT.

           IF  WS-DBG-ANNV-VALU-CHG-YES
               SET L7300-DBG-CHNG-ANNV-VALU
                                         TO TRUE
           END-IF.

           IF  WS-DBG-MAV-CHG-YES
               SET L7300-DBG-CHNG-MAV    TO TRUE
           END-IF.

           IF  WS-DBG-ROLU-CHG-YES
               SET L7300-DBG-CHNG-ROLU   TO TRUE
           END-IF.


           EVALUATE TRUE

               WHEN  WS-DBG-ADD-RIDER-YES
                     SET L7300-DBG-ADD-RIDER
                                         TO TRUE

               WHEN  WS-DBG-DEL-RIDER-YES
                     SET L7300-DBG-DEL-RIDER
                                         TO TRUE

           END-EVALUATE.

           PERFORM  7300-2000-DBG-CHNG
               THRU 7300-2000-DBG-CHNG-X.

           IF NOT L7300-RETRN-OK
              SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

       6140-UPDATE-RIDER-CHG-X.
           EXIT.

      *---------------------
       6150-DEFER-CHG-RIDER.
      *---------------------

           PERFORM  8170-1000-BUILD-PARM-INFO
               THRU 8170-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                TO L8170-EFF-DT.

           IF  WS-DBG-ADD-RIDER-YES
               SET LFUND-ACTV-DBG-ADD-RIDER
                                         TO TRUE
           ELSE
               SET LFUND-ACTV-DBG-DEL-RIDER
                                         TO TRUE
           END-IF.

           IF  WS-DBG-ANNV-VALU-CHG-YES
               SET L8170-DBG-CHG-ANNV-VALU
                                         TO TRUE
           END-IF.

           IF  WS-DBG-MAV-CHG-YES
               SET L8170-DBG-CHG-MAV     TO TRUE
           END-IF.

           IF  WS-DBG-ROLU-CHG-YES
               SET L8170-DBG-CHG-ROLU    TO TRUE
           END-IF.

           INITIALIZE LFUND-FND-INFO (1).
           MOVE +1                       TO LFUND-FND-CTR.
           MOVE -100.00                  TO LFUND-ALLOC-PCT (1).
           SET LFUND-ALLOC-PERCENT (1)   TO TRUE.

           PERFORM  8170-2000-DEFER-TRANSACTION
               THRU 8170-2000-DEFER-TRANSACTION-X.

           IF NOT L8170-RETRN-OK
              SET WGLOB-RETURN-ERROR     TO TRUE
           ELSE
      * MSG: FUND PRICES NOT AVAILABLE, DEATH BENEFIT GUARANTEES CHANGES
      *      HAS BEEN DEFERRED
              MOVE 'CS04520012'          TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6150-DEFER-CHG-RIDER-X.
           EXIT.


      *----------------
       6500-EDIT-IPROF.
      *----------------

           PERFORM  2664-1000-BUILD-PARM-INFO
               THRU 2664-1000-BUILD-PARM-INFO-X.

           SET L2664-PRCES-TYP-EDIT-ONLY TO TRUE.
           MOVE WS-EFF-DT                TO  L2664-EFF-DT.
           IF MIR-PRFL-ID = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACES                TO L2420-PRFL-ID
           ELSE
              MOVE MIR-PRFL-ID           TO L2664-PRFL-ID
           END-IF.
           MOVE RPOL-SBSDRY-CO-ID        TO L2664-SBSDRY-CO-ID.
           SET  L2664-NORMAL-PROCESSING  TO TRUE.

           PERFORM  2664-1000-IPROF-EDIT
               THRU 2664-1000-IPROF-EDIT-X.

           IF L2664-RETRN-ERROR
              SET  WS-IPROF-ERROR-YES    TO TRUE
           END-IF.

       6500-EDIT-IPROF-X.
           EXIT.

      *------------------
       6600-UPDATE-IPROF.
      *------------------

           PERFORM  2664-1000-BUILD-PARM-INFO
               THRU 2664-1000-BUILD-PARM-INFO-X.

           IF  WS-IPROF-PRCES-TYP-EDIT
               SET  L2664-PRCES-TYP-EDIT-ONLY
                                         TO TRUE
           END-IF.

           MOVE WS-EFF-DT                TO L2664-EFF-DT.
           IF MIR-PRFL-ID = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACES                TO L2420-PRFL-ID
           ELSE
              MOVE MIR-PRFL-ID           TO L2664-PRFL-ID
           END-IF.
           MOVE RPOL-SBSDRY-CO-ID        TO L2664-SBSDRY-CO-ID.
           SET  L2664-NORMAL-PROCESSING  TO TRUE.

           PERFORM  2664-2000-IPROF-UPDATE
               THRU 2664-2000-IPROF-UPDATE-X.

           IF L2664-RETRN-ERROR
              SET  WS-IPROF-ERROR-YES    TO TRUE
           END-IF.

       6600-UPDATE-IPROF-X.
           EXIT.

      *------------------
       6700-READ-INV-PRFL.
      *------------------

      * NEED TO GET INVESTOR PROFILE INFORMATION.

           PERFORM 2735-1000-BUILD-PARM-INFO
              THRU 2735-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID              TO L2735-POL-ID.
           PERFORM 2735-1000-GET-PRFL
              THRU 2735-1000-GET-PRFL-X.

           IF  L2735-RETRN-PRFL-FND
               MOVE L2735-PRFL-ID        TO MIR-PRFL-ID
           ELSE
               MOVE SPACES               TO MIR-PRFL-ID
           END-IF.

       6700-READ-INV-PRFL-X.
           EXIT.

      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------


           IF  L2420-DBEN       NOT = HIGH-VALUES
               MOVE RPOL-POL-DB-OPT-CD   TO MIR-POL-DB-OPT-CD
           END-IF.

           IF  L2420-ISS-EFF-DT NOT = HIGH-VALUES
               MOVE RPOL-POL-ISS-EFF-DT  TO L1640-INTERNAL-DATE
               PERFORM 1640-8000-INTERNAL-TO-MIR
                  THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE  TO MIR-POL-ISS-EFF-DT
           END-IF.

025390     IF  L2420-PREM-DSCNT-TYP-CD NOT = HIGH-VALUES
025390         MOVE RPOL-PREM-DSCNT-TYP-CD   TO MIR-PREM-DSCNT-TYP-CD
025390     END-IF.
025390
025390     IF  L2420-POL-PREM-DSCNT-PCT NOT = HIGH-VALUES
025390         MOVE RPOL-POL-PREM-DSCNT-PCT TO L0290-INPUT-V03
025390         MOVE 3                       TO L0290-PRECISION
025390         MOVE LENGTH OF MIR-POL-PREM-DSCNT-PCT
025390                                      TO L0290-MAX-OUT-LEN
025390         PERFORM  0290-2000-FORMAT-FOR-MIR
025390             THRU 0290-2000-FORMAT-FOR-MIR-X
025390         MOVE L0290-OUTPUT-DATA       TO MIR-POL-PREM-DSCNT-PCT
025390     END-IF.
029060
029060     IF  L2420-POL-ANPAYO-1-AMT-X NOT = HIGH-VALUES
029060         MOVE RPOL-POL-ANPAYO-1-AMT   TO L0290-INPUT-V02
029060         MOVE 2                       TO L0290-PRECISION
029060         MOVE LENGTH OF MIR-POL-ANPAYO-1-AMT
029060                                TO L0290-MAX-OUT-LEN
029060         PERFORM  0290-2000-FORMAT-FOR-MIR
029060             THRU 0290-2000-FORMAT-FOR-MIR-X
029060         MOVE L0290-OUTPUT-DATA     TO MIR-POL-ANPAYO-1-AMT
029060     END-IF.
029060
029060     IF  L2420-POL-ANPAYO-2-AMT-X NOT = HIGH-VALUES
029060         MOVE RPOL-POL-ANPAYO-2-AMT   TO L0290-INPUT-V02
029060         MOVE 2                       TO L0290-PRECISION
029060         MOVE LENGTH OF MIR-POL-ANPAYO-2-AMT
029060                                TO L0290-MAX-OUT-LEN
029060         PERFORM  0290-2000-FORMAT-FOR-MIR
029060             THRU 0290-2000-FORMAT-FOR-MIR-X
029060         MOVE L0290-OUTPUT-DATA     TO MIR-POL-ANPAYO-2-AMT
029060     END-IF.

           IF MIR-PRFL-ID = SPACE
              PERFORM  6700-READ-INV-PRFL
                  THRU 6700-READ-INV-PRFL-X
           END-IF.


       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  POL-1000-CALL-AUDIT
                   THRU POL-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0201-0000-INIT-PARM-INFO
               THRU 0201-0000-INIT-PARM-INFO-X.

           PERFORM  0289-0000-INIT-PARM-INFO
               THRU 0289-0000-INIT-PARM-INFO-X.

025390     PERFORM  0290-0000-INIT-PARM-INFO
025390         THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0316-0000-INIT-PARM-INFO
               THRU 0316-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  0985-0000-INIT-PARM-INFO
               THRU 0985-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  1670-0000-INIT-PARM-INFO
               THRU 1670-0000-INIT-PARM-INFO-X.

           PERFORM  1680-0000-INIT-PARM-INFO
               THRU 1680-0000-INIT-PARM-INFO-X.
031037
031037     PERFORM  2408-0000-INIT-PARM-INFO
031037         THRU 2408-0000-INIT-PARM-INFO-X.

           PERFORM  2420-0000-INIT-PARM-INFO
               THRU 2420-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
           PERFORM  2664-0000-INIT-PARM-INFO
               THRU 2664-0000-INIT-PARM-INFO-X.

           PERFORM  2735-0000-INIT-PARM-INFO
               THRU 2735-0000-INIT-PARM-INFO-X.

           PERFORM  3330-0000-INIT-PARM-INFO
               THRU 3330-0000-INIT-PARM-INFO-X.

           PERFORM  4750-0000-INIT-PARM-INFO
               THRU 4750-0000-INIT-PARM-INFO-X.

           PERFORM  4780-0000-INIT-PARM-INFO
               THRU 4780-0000-INIT-PARM-INFO-X.

           PERFORM  5400-0000-INIT-PARM-INFO
               THRU 5400-0000-INIT-PARM-INFO-X.

           PERFORM  7300-0000-INIT-PARM-INFO
               THRU 7300-0000-INIT-PARM-INFO-X.

           PERFORM  7306-0000-INIT-PARM-INFO
               THRU 7306-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           PERFORM  8170-0000-INIT-PARM-INFO
               THRU 8170-0000-INIT-PARM-INFO-X.

           PERFORM  FRNE-0000-INIT-PARM-INFO
               THRU FRNE-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-AREA.
           INITIALIZE FREQUENTLY-USED-INDICES.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           INITIALIZE WIHSD-INFO.
           MOVE SPACES                 TO WWKDT-WORK-FIELDS.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY CCPPMIDT.
       COPY CCPPPLIN.
       COPY CCPPIHSD.
       COPY NCPPCVGR.
       COPY NCPPCVGS.
       COPY XCPPCOMM.
       COPY XCPPEXIT.
       COPY XCPPINIT.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY CCPS0201.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0201.

       COPY CCPS0289.
       COPY CCPL0289.

       COPY CCPS0620.
       COPY CCPL0620.

       COPY CCPS0985.
       COPY CCPL0985.

031037 COPY CCPS2408.
031037 COPY CCPL2408.
031037
       COPY CCPS2420.
       COPY CCPL2420.

       COPY CCPS2430.
       COPY CCPL2430.

       COPY CCPS2664.
       COPY CCPL2664.

       COPY CCPS2735.
       COPY CCPL2735.

       COPY CCPS3330.
       COPY CCPL3330.

       COPY CCPS4750.
       COPY CCPL4750.

       COPY CCPS4780.
       COPY CCPL4780.

       COPY CCPS5400.
       COPY CCPL5400.

       COPY CCPS7300.
       COPY CCPL7300.

       COPY CCPS7306.
       COPY CCPL7306.

       COPY CCPSPGA.

       COPY CCPLPOL.

       COPY CCPSFRNE.
       COPY CCPLFRNE.

       COPY FCPS8170.
       COPY FCPL8170.

       COPY XCPL0260.

025390 COPY XCPS0290.
025390 COPY XCPL0290.

       COPY XCPS0316.
       COPY XCPL0316.

       COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPS1670.
       COPY XCPS1680.
       COPY XCPL1680.

       COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.
       COPY CCPUCVG.

       COPY CCPNPDBG.

       COPY CCPNPH.

       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM0452                     **
      *****************************************************************
