      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM5226.

      * COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5226                                         **
      **  REMARKS:  UNLINK CREDIT CARD INFO.                         **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016395**  6.2       UNLINK CREDIT CARD INFO. FROM A POLICY           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018581**  6.4       CORRECT FUNCTIONALITY OF PROGRAM                 **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      *---------------------
       ENVIRONMENT DIVISION.
      *---------------------

      *--------------
       DATA DIVISION.
      *--------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5226'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.
018581*COPY XCWWFNDM.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-LIST                     VALUE '5226'.          
           05  WS-IF-VALIDATE-OK            PIC X(01).
               88  WS-VALIDATE-OK                      VALUE 'Y'.
               88  WS-VALIDATE-FAILED                  VALUE 'N'.
           05  WS-IF-OK-TO-REMOVE                      PIC X(01).
               88  WS-CANNOT-REMOVE                    VALUE 'N'.
               88  WS-OK-TO-REMOVE                     VALUE 'Y'.
           05  WS-IF-OK-TO-DELETE                      PIC X(01).
               88  WS-CANNOT-DELETE                    VALUE 'N'.
               88  WS-OK-TO-DELETE                     VALUE 'Y'.
           05  WS-IF-POLICY-RELATED                    PIC X(01).
               88  WS-POLICY-IS-RELATED                VALUE 'Y'.
               88  WS-POLICY-NOT-RELATED               VALUE 'N'.
018581*    05  WS-CLI-CRC-NUM                          PIC X(01).
018581     05  WS-CLI-CRC-NUM                          PIC 9(01).
      *
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
      *
021930*COPY XCWWWKDT.
       COPY CCFWRL.
       COPY CCFRRL.
       COPY CCWL0068.
028298 COPY CCWL2626.
       COPY NCWL0240.
       COPY CCWL5600.
      *
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWCRCD.
       COPY CCFRCRCD.
       COPY CCFWCLCR.
       COPY CCFRCLCR.
      *
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
018581** LINKAGE TO NUMERIC VALIDATION MODULE
018581*COPY XCWL0280.
018581*
018581** LINKAGE TO NUMERIC EDITING MODULE
018581*COPY XCWL0290.
018581*
018581** LINKAGE TO DATE CONVERSION MODULES
018581*COPY XCWL1640.
018581*COPY XCWL1660.
      *
      * DATE MANIPULATION WORK AREAS
021930*COPY XCWLDTLK.
      *
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
021930*COPY CCWWCVGS.
      *
      *----------------
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *----------------
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5226.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET WGLOB-GOOD-RETURN TO TRUE.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      * MOVE BUSINESS FUNCTION ID TO WORK FIELD AND EVALUATE.

           MOVE MIR-BUS-FCN-ID   TO WS-BUS-FCN-ID.
           SET  MIR-RETRN-OK     TO TRUE. 
018581*    PERFORM  0290-1000-BUILD-PARM-INFO
018581*        THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.
018581*    PERFORM  2200-EDIT-CONTROL-FIELDS-2
018581*        THRU 2200-EDIT-CONTROL-FIELDS-2-X.
018581*    IF  WS-VALIDATE-FAILED
018581*        GO TO 2000-PROCESS-REQUEST-X
018581*    END-IF.
           PERFORM  8000-PROCESS-REMOVE
               THRU 8000-PROCESS-REMOVE-X.

       2000-PROCESS-REQUEST-X.
           EXIT.

018581*---------------------------
018581*2200-EDIT-CONTROL-FIELDS-2.
018581*---------------------------
018581*
018581*    MOVE 'Y'                 TO WS-IF-VALIDATE-OK.
018581*    MOVE MIR-CRC-TYP-CD      TO WCRCD-CRC-TYP-CD.
018581*    MOVE MIR-CRC-ID          TO WCRCD-CRC-ID.
018581*
018581*    PERFORM  CRCD-1000-READ
018581*        THRU CRCD-1000-READ-X.
018581*
018581*    IF  WCRCD-IO-OK
018581*        CONTINUE
018581*    ELSE
018581*        PERFORM  9100-BLANK-DATA-FIELDS
018581*            THRU 9100-BLANK-DATA-FIELDS-X
018581*    END-IF.
018581*
018581*2200-EDIT-CONTROL-FIELDS-2-X.
018581*    EXIT.
018581*
      *--------------------
       6250-CHECK-POLC-POL.
      *--------------------

018581*    IF  RRL-REL-TYP-PAYOR
018581     IF  NOT RRL-REL-TYP-PAYOR
               GO TO 6250-CHECK-POLC-POL-X
           END-IF.

           PERFORM  0068-1000-BUILD-PARM-INFO
               THRU 0068-1000-BUILD-PARM-INFO-X.

           MOVE RRL-CLI-ID              TO L0068-CLI-ID.
           MOVE RRL-REL-SYS-REF-POL-ID  TO L0068-POL-ID.
018581*    MOVE RCLCR-CLI-CRC-NUM       TO L0068-POL-CLI-REL-SUB-CD.
018581     MOVE WS-CLI-CRC-NUM          TO L0068-POL-CLI-REL-SUB-CD.

           PERFORM  0068-1000-FIND-POL-USING-BNK
               THRU 0068-1000-FIND-POL-USING-BNK-X.

           IF  NOT L0068-RETRN-OK
               GO TO 6250-CHECK-POLC-POL-X
           END-IF.

018581     IF  L0068-POL-BILL-TYP-CRC
018581         CONTINUE
018581     ELSE
018581         GO TO 6250-CHECK-POLC-POL-X
018581     END-IF.
018581
           MOVE 'Y' TO WS-IF-POLICY-RELATED.

       6250-CHECK-POLC-POL-X.
           EXIT.

      *--------------------
       8000-PROCESS-REMOVE.
      *--------------------

018581*    PERFORM  8500-EDITS-FOR-ATTACH-REMOVE
018581*        THRU 8500-EDITS-FOR-ATTACH-REMOVE-X.
018581     SET WS-VALIDATE-OK TO TRUE.
018581     PERFORM  8500-EDITS-FOR-REMOVE
018581         THRU 8500-EDITS-FOR-REMOVE-X.

           IF  WS-VALIDATE-FAILED
               GO TO 8000-PROCESS-REMOVE-X
           END-IF.

           MOVE MIR-CRC-TYP-CD    TO WCRCD-CRC-TYP-CD.
           MOVE MIR-CRC-ID        TO WCRCD-CRC-ID.
  
           PERFORM  CRCD-1000-READ
               THRU CRCD-1000-READ-X.

           IF  NOT WCRCD-IO-OK
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      *MSG:    CREDIT CARD RECORD NOT FOUND ON CRCD FILE
               MOVE 'CS52260003'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-PROCESS-REMOVE-X
           END-IF.

           MOVE MIR-CRC-TYP-CD    TO WCLCR-CRC-TYP-CD.
           MOVE MIR-CRC-ID        TO WCLCR-CRC-ID.
           MOVE MIR-CLI-ID        TO WCLCR-CLI-ID.
  
           PERFORM  CLCR-1000-READ-FOR-UPDATE
               THRU CLCR-1000-READ-FOR-UPDATE-X.

           IF  NOT WCLCR-IO-OK
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      *MSG:    CLIENT CREDIT CARD RECORD NOT FOUND ON CLCR FILE
               MOVE 'CS52260004'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-PROCESS-REMOVE-X
           END-IF.

           PERFORM  9200-MOVE-CLCR-TO-SCREEN
               THRU 9200-MOVE-CLCR-TO-SCREEN-X.

           MOVE LOW-VALUES        TO WRL-KEY.
           MOVE RCLCR-CLI-ID      TO WRL-CLI-ID.
018581     MOVE WGLOB-SYS-CTL-ID  TO WRL-REL-SYS-ID.
           MOVE WRL-KEY           TO WRL-ENDBR-KEY.
018581*    MOVE HIGH-VALUES       TO WRL-ENDBR-REL-SYS-ID.
           MOVE HIGH-VALUES       TO WRL-ENDBR-REL-SYS-REF-ID.
           MOVE HIGH-VALUES       TO WRL-ENDBR-REL-TYP-CD.

018581     SET WS-OK-TO-REMOVE    TO TRUE.
018581     MOVE RCLCR-CLI-CRC-NUM TO WS-CLI-CRC-NUM.

           PERFORM  RL-1000-BROWSE
               THRU RL-1000-BROWSE-X.
           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.
           IF  NOT WRL-IO-OK
               PERFORM  RL-3000-END-BROWSE
                   THRU RL-3000-END-BROWSE-X
           ELSE
               PERFORM  8200-SEARCH-POLICIES
                   THRU 8200-SEARCH-POLICIES-X
                  UNTIL WRL-IO-EOF
                     OR WS-CANNOT-REMOVE
               PERFORM  RL-3000-END-BROWSE
                   THRU RL-3000-END-BROWSE-X
           END-IF.

           IF  WS-CANNOT-REMOVE
               GO TO 8000-PROCESS-REMOVE-X
           END-IF.
        
           PERFORM  CLCR-1000-DELETE
               THRU CLCR-1000-DELETE-X.

018581     SET L0240-REQIR-TYP-CRC TO TRUE. 
           MOVE MIR-CLI-ID        TO L0240-CLIENT-NUMBER.
           MOVE RCLCR-CLI-CRC-NUM TO L0240-ACCT-NO.
           PERFORM  0240-2000-PRCES-RAC-PMT-RQIR
               THRU 0240-2000-PRCES-RAC-PMT-RQIR-X.

       8000-PROCESS-REMOVE-X.
           EXIT.

      *---------------------
       8200-SEARCH-POLICIES.
      *---------------------

           MOVE 'N' TO WS-IF-POLICY-RELATED.
           PERFORM  6250-CHECK-POLC-POL
               THRU 6250-CHECK-POLC-POL-X.
           IF  WS-POLICY-IS-RELATED
               EVALUATE TRUE
                   WHEN L0068-POL-STAT-IN-FORCE
      *MSG:             CREDIT CARD CURRENTLY IN USE
                        MOVE 'CS52260001' TO WGLOB-MSG-REF-INFO
                        MOVE L0068-POL-ID TO WGLOB-MSG-PARM (1)
018581                  MOVE MIR-CLI-ID   TO WGLOB-MSG-PARM (2)
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                        IF  WGLOB-MSG-SEVRTY-FATAL
                            MOVE 'N'      TO WS-IF-OK-TO-REMOVE
                        END-IF

                   WHEN L0068-POL-STAT-TERMINATED
                   WHEN L0068-POL-STAT-REJECTED
      *MSG:             CREDIT CARD CURRENTLY USED BY 
      *MSG:             TERMINATED/REJECTED POLICY
                        MOVE 'CS52260002' TO WGLOB-MSG-REF-INFO
                        MOVE L0068-POL-ID TO WGLOB-MSG-PARM (1)
018581                  MOVE MIR-CLI-ID   TO WGLOB-MSG-PARM (2)
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                        IF  WGLOB-MSG-SEVRTY-FATAL
                            MOVE 'N'      TO WS-IF-OK-TO-REMOVE
                        END-IF
      
               END-EVALUATE
           END-IF.

           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

       8200-SEARCH-POLICIES-X.
           EXIT.

      *-----------------------------
018581*8500-EDITS-FOR-ATTACH-REMOVE.
018581 8500-EDITS-FOR-REMOVE.
      *-----------------------------

018581*    MOVE 'Y' TO WS-IF-VALIDATE-OK.
           IF  MIR-CLI-ID = SPACES
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
018581         MOVE 'N' TO WS-IF-VALIDATE-OK
018581*MSG:    CLIENT MUST BE CODED
018581         MOVE 'CS52260005' TO WGLOB-MSG-REF-INFO
018581         PERFORM  0260-1000-GENERATE-MESSAGE
018581             THRU 0260-1000-GENERATE-MESSAGE-X
018581         GO TO 8500-EDITS-FOR-REMOVE-X
018581*        GO TO 8500-EDITS-FOR-ATTACH-REMOVE-X
           END-IF.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID TO L5600-CLI-ID.

018581     PERFORM  5600-1000-CLI-CHK
018581         THRU 5600-1000-CLI-CHK-X.

           IF  L5600-RETRN-CLI-NOT-FOUND
           OR  L5600-CNFD-ACCS-RESTRICTED
           OR  L5600-CCAS-ACCS-RESTRICTED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               MOVE 'N'    TO WS-IF-VALIDATE-OK
           END-IF.

018581*8500-EDITS-FOR-ATTACH-REMOVE-X.
018581 8500-EDITS-FOR-REMOVE-X.
           EXIT.

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-CRC-TYP-CD.
           MOVE SPACES                TO MIR-CRC-ID.
           MOVE SPACES                TO MIR-CLI-ID.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *-------------------------
       9200-MOVE-CLCR-TO-SCREEN.
      *-------------------------

           MOVE RCLCR-CRC-TYP-CD      TO MIR-CRC-TYP-CD.
           MOVE RCLCR-CRC-ID          TO MIR-CRC-ID.
           MOVE RCLCR-CLI-ID          TO MIR-CLI-ID.

       9200-MOVE-CLCR-TO-SCREEN-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0068-0000-INIT-PARM-INFO
025970         THRU 0068-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0240-0000-INIT-PARM-INFO
025970         THRU 0240-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *                      PROCESSING COPYBOOKS                     *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPSPGA.
       COPY XCPPINIT.
       COPY XCPPEXIT.
018764*COPY CCCL0068.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL0068.
       COPY CCPS0068.
      *****************************************************************
      *                      LINK COPYBOOKS                           *
      *****************************************************************
018581*COPY XCPL0280.
018581*COPY XCPL0290.
018581*COPY XCPS0290.
018581*COPY XCPL1640.
018581*COPY XCPL1660.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY NCCL0240.
025970 COPY NCPS0240.
018764 COPY NCPL0240.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.
       COPY CCPNCRCD.
       COPY CCPUCLCR.
       COPY CCPXCLCR.
       COPY CCPBRL.
      *****************************************************************
      *  FILE I/O COPYBOOKS                                           *
      *****************************************************************
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM5226                     **
      *****************************************************************

