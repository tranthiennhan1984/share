      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7353.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7353                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE DELETE FUNCTION   **
      **            FOR THE PDCL AND PDCB TABLE                      **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7353'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                          PIC X(04).
               88  WS-BUS-FCN-DELETE                  VALUE '7353'.
           05  WS-PDCL-INFO.
               10  WS-PDCL-DTHCLM-SEQ-NUM             PIC S9(04) BINARY.

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                            PIC X(04).
               88 WS-TWRK-KEY-DEFAULT                 VALUE '7350'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFWPDCL.
       COPY CCFRPDCL.

       COPY CCFWPDCB.
       COPY CCFRPDCB.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL0280.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7353.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7353'            TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-DELETE.
      *------------

      * VALIDATE KEY INFO

           PERFORM  8000-EDIT-INFO
               THRU 8000-EDIT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
               GO TO 2000-DELETE-X
           END-IF.

      * DELETE PDCB RECORD

           PERFORM  2100-DELETE-PDCB
               THRU 2100-DELETE-PDCB-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

      * DELETE PDCL RECORD

           PERFORM  2200-DELETE-PDCL
               THRU 2200-DELETE-PDCL-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

      *MSG:  'DELETE COMPLETED - CONTINUE'
           MOVE 'XS00000011'           TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       2000-DELETE-X.
           EXIT.

      *-----------------
       2100-DELETE-PDCB.
      *-----------------

           MOVE LOW-VALUES               TO WPDCB-KEY.
           MOVE WGLOB-COMPANY-CODE       TO WPDCB-CO-ID.
           MOVE RPOL-POL-ID              TO WPDCB-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM   TO WPDCB-DTHCLM-SEQ-NUM.

           MOVE WPDCB-KEY                TO WPDCB-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WPDCB-ENDBR-CLI-ID.

           PERFORM  PDCB-1000-DELETE-KEY-RANGE
              THRU  PDCB-1000-DELETE-KEY-RANGE-X.

       2100-DELETE-PDCB-X.
           EXIT.

      *-----------------
       2200-DELETE-PDCL.
      *-----------------

           MOVE LOW-VALUES              TO WPDCL-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCL-CO-ID.
           MOVE RPOL-POL-ID             TO WPDCL-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM  TO WPDCL-DTHCLM-SEQ-NUM.

           PERFORM  PDCL-1000-READ-FOR-UPDATE
               THRU PDCL-1000-READ-FOR-UPDATE-X.

           IF  NOT WPDCL-IO-OK
      *MSG:  'RECORD @1 LOST IN DELETE - CONTACT SYSTEMS'
               MOVE WPDCL-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2200-DELETE-PDCL-X
           END-IF.

           PERFORM  PDCL-1000-DELETE
               THRU PDCL-1000-DELETE-X.

       2200-DELETE-PDCL-X.
           EXIT.

      *---------------
       8000-EDIT-INFO.
      *---------------

      * VALIDATE KEY INFOMATION

            PERFORM  8010-EDIT-KEY-INFO
                THRU 8010-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

      * VALIDATE PDCL STATUS

            PERFORM  8020-EDIT-PDCL
                THRU 8020-EDIT-PDCL-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

       8000-EDIT-INFO-X.
           EXIT.

      *-------------------
       8010-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
               MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
               MOVE 'POL'             TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      * VALIDATE PDCL SEQ NUM
      *
           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE ZERO                       TO L0280-PRECISION.
           MOVE 5                          TO L0280-LENGTH.
           MOVE 5                          TO L0280-INPUT-SIZE.
           MOVE MIR-DTHCLM-SEQ-NUM         TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'SEQUENCE NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS73530001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 8010-EDIT-KEY-INFO-X
           ELSE
               MOVE L0280-OUTPUT           TO WS-PDCL-DTHCLM-SEQ-NUM
           END-IF.

       8010-EDIT-KEY-INFO-X.
           EXIT.
      /
      *---------------
       8020-EDIT-PDCL.
      *---------------

           MOVE LOW-VALUES              TO WPDCL-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCL-CO-ID.
           MOVE RPOL-POL-ID             TO WPDCL-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM  TO WPDCL-DTHCLM-SEQ-NUM.

           PERFORM  PDCL-1000-READ
               THRU PDCL-1000-READ-X.

           IF  WPDCL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPDCL-KEY              TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8020-EDIT-PDCL-X
           END-IF.

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
               CONTINUE
           ELSE
      *MSG:  'DELETE IS ONLY ALLOWED ON RECORDS WITH STATUS = PENDING
      *       OR ERROR'
               MOVE 'CS73530002'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8020-EDIT-PDCL-X
           END-IF.

       8020-EDIT-PDCL-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.

           SET WS-TWRK-KEY-DEFAULT   TO TRUE.
           SET MIR-RETRN-OK          TO TRUE.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
       COPY XCPS8090.
       COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNPDCL.
       COPY CCPUPDCL.
       COPY CCPXPDCL.

       COPY CCPGPDCB.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7353                     **
      *****************************************************************
