      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM0130.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM0130                                         **
      **  REMARKS:  FADM - PROCESS SEGREGATED FUND ADMINISTRATIVE    **
      **                   CHARGES.                                  **
      **                   THIS MODULE IS USED TO FORCE AN ANNUAL    **
      **                   ADMINISTRATIVE CHARGE THAT IS DIFFERENT   **
      **                   FROM THE SYSTEM-CALCULATED ADMINISTRATIVE **
      **                   CHARGE FOR A SEGREGATED FUND PRODUCT.     **
      **                   THE CHARGE IS NORMALLY DEDUCTED ON THE    **
      **                   UNIT ALLOCATION BATCH RUN FOLLOWING A     **
      **                   POLICY ANNIVERSARY.                       **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557701**  5.5       UNDO/REDO FOR SEGFUNDS                           **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZING FOR INTL SUPPORT             **
009320**  5.5.1     SET GUI RETURN ERROR                             **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012134**  5.6V      TAXATION OF VAR UL AND VAR ANNUITIES             **
012137**  5.6V      SEC CONFIRMATIONS                                **
012141**  5.6V      PORTFOLIO EXPANSION                              **
012146**  5.6V      MORTALITY AND EXPENSE CHARGES                    **
012696**  5.6V      POLICY ALLOCATION                                **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
012624**  6.0       GLOBAL SECURITY CHANGES - POLICY ACCESS          **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
016422**  6.1       FUND ADMIN CHARGE                                **
014221**  6.2       INCREASE LENGTH FOR FS, FD, FA FC INCREASE       **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016761**  6.2       REMOVE WGLOB-GUI-RETRN-CD                        **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
016307**  6.3       ADMIN CHARGES AS A PERCENT OF FUND VALUE (6.1.1E)**
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
020906**  6.4       REMOVAL OF UNUSED FIELDS FROM GLOBAL AREA        **
021311**  6.4       MULTI-PLATFORM SUPPORT                           **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
020463**  6.4       INVESTOR PROFILES                                **
023091**  6.5       FIX REDO FOR MULTI CURRENCY PAYMENT              **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
032329**  7.0       99 COVERAGES AND 98 FUNDS HANDLING               **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0130'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *
      /
       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
007766 COPY XCWWCVGM.
012141 COPY XCWWFNDM.

       01  WS-PGM-WORK-AREA.
025970*    05  TRANSACTION-NAME      PIC X(04)  VALUE 'FADM'.
025970*    05  EMPTY-FIELD           PIC X      VALUE SPACES.
025970     05  WS-PRCES-STATE-CD     PIC X(01).
025970     05  WS-SUB                PIC 9(04)  VALUE ZEROS.

025970 01  WS-CONSTANTS.
025970     05  TRANSACTION-NAME      PIC X(04).
025970         88  TRANSACTION-NAME-DEFAULT     VALUE 'FADM'.
025970     05  WS-MAX-LINES          PIC S9(04) BINARY.
032329*        88  WS-MAX-LINES-DEFAULT         VALUE +25.
032329         88  WS-MAX-LINES-DEFAULT         VALUE 98.
      /
       01  WS-SCREEN-WORK-AREA.
012141*    05  WS-SCREEN-FS-DATA    OCCURS 15.
032329*    05  WS-SCREEN-FS-DATA    OCCURS 25.
032329     05  WS-SCREEN-FS-DATA    OCCURS 98.
013578*        10  WS-FNUM               PIC 9(2).
013578*        10  WS-A-FNUM       REDEFINES WS-FNUM      PIC X(02).
               10  WS-FUND-CODE          PIC X(05).
               10  WS-A-FUND-CODE  REDEFINES WS-FUND-CODE PIC X(5).
008455*        10  WS-FVAL.
008455*            15  WS-FVAL-NO        PIC 9(11).
008455*            15  WS-FVAL-PT        PIC X(1).
008455*            15  WS-FVAL-PC        PIC V9(2).
008455*        10  WS-A-FVAL REDEFINES WS-FVAL.
008455*            15  WS-A-FVAL-NO        PIC X(11).
008455*            15  WS-A-FVAL-PT        PIC X(1).
008455*            15  WS-A-FVAL-PC        PIC X(2).
008455*        10  WS-AF   REDEFINES  WS-FVAL.
008455*            15  WS-FVAL-NUM       PIC ZZZZZZZZZZ9.99.
008455         10  WS-FVAL               PIC X(18).
008455         10  WS-FVAL-NUM           PIC S9(15)V99 COMP-3.
020464         10  WS-SCREEN-FS-DEFR-AMT.
020464             15  WS-SCREEN-FS-DEFR-IN-N  PIC S9(15)V99
020464                                         COMP-3.
020464             15  WS-SCREEN-FS-DEFR-OUT-N PIC S9(15)V99
020464                                         COMP-3.
008455*        10  WS-ACHG.
008455*            15  WS-ACHG-NO        PIC 9(7).
008455*            15  WS-ACHG-PT        PIC X(1).
008455*            15  WS-ACHG-PC        PIC V9(2).
008455*        10  WS-A-ACHG REDEFINES WS-ACHG.
008455*            15  WS-A-ACHG-NO        PIC X(7).
008455*            15  WS-A-ACHG-PT        PIC X(1).
008455*            15  WS-A-ACHG-PC        PIC X(2).
008455*        10  WS-AC     REDEFINES WS-ACHG.
008455*            15  WS-ACHG-NUM       PIC 9999999.99.
008455         10  WS-ACHG               PIC X(16).
008455         10  WS-ACHG-NUM           PIC S9(13)V99 COMP-3.
               10  WS-PCHG.
                   15  WS-PCHG-NO        PIC 9(3).
                   15  WS-PCHG-PT        PIC X(1).
                   15  WS-PCHG-PC        PIC V9(4).
               10  WS-A-PCHG REDEFINES WS-PCHG.
                   15  WS-A-PCHG-NO        PIC X(3).
                   15  WS-A-PCHG-PT        PIC X(1).
                   15  WS-A-PCHG-PC        PIC X(4).
               10  WS-AP     REDEFINES WS-PCHG.
                   15  WS-PCHG-NUM       PIC 999.9999.

025970*01  WS-PRCES-STATE-CD             PIC X(01)   VALUE SPACES.
025970*01  WS-SUB                        PIC 9(04)   VALUE ZEROS.
012141*01  WS-MAX-LINES                  PIC 9(02)   VALUE 15.
025970*01  WS-MAX-LINES                  PIC 9(02)   VALUE 25.
025970*01  HOLD-SQ                       PIC 9(04).
025970*01  HOLD-RUN-ID                   PIC X(01)   VALUE '0'.
025970*01  C-DUR                         PIC S9(07)  COMP-3.

       01  READ-WORK-AREA               PIC X(80).
       01  HEADER-MISC-WORK-AREAS.
           05  TRAN-CODE-HOLD           PIC X.
008453     05  EDATE-HOLD               PIC X(10).
008453*    05  EDATE-HOLD.
008453*        10  EDATE-DAY            PIC 9(2).
008453*        10  EDATE-MO             PIC 9(3).
008453*        10  EDATE-YEAR           PIC 9(4).
           05  KEY-HOLD.
               10  HOLD-POL-ID.
                   15  HOLD-POL-ID-BASE PIC X(09).
                   15  HOLD-POL-ID-SFX  PIC X(01).
               10  COV-HOLD             PIC XX.
               10  COV-HOLD-N           REDEFINES
                   COV-HOLD             PIC 99.
557701     05  REASON-HOLD              PIC X(03).
008455*    05  AMOUNT-HOLD.
008455*        10  AMOUNT-HOLD-NO       PIC 9(7).
008455*        10  AMOUNT-HOLD-PT       PIC X(1).
008455*        10  AMOUNT-HOLD-PC       PIC V9(2).
008455*    05  AMOUNT-HOLD-A  REDEFINES AMOUNT-HOLD.
008455*        10  AMOUNT-A-HOLD-NO     PIC X(7).
008455*        10  AMOUNT-A-HOLD-PT     PIC X(1).
008455*        10  AMOUNT-A-HOLD-PC     PIC X(2).
008455*    05  AMOUNT-NH  REDEFINES AMOUNT-HOLD.
008455*        10  AMOUNT-NUM-HOLD      PIC 9999999.99.
008455     05  AMOUNT-HOLD              PIC X(18).
008455     05  AMOUNT-NUM-HOLD          PIC S9(15)V99 COMP-3.
           05  ALLOC-HOLD               PIC X.
012696*        88  VALID-ALLOC-CODE     VALUE 'A' 'C' 'D'.
012696         88  VALID-ALLOC-CODE     VALUE 'C' 'D'.
           05  HOLD-ERRORS.
               10  HOLD-ERROR           PIC X(79)  OCCURS 3.
           05  PRINT-ERROR-SW           PIC 9.
           05  PRINT-OFF-SW             PIC 9.
               88  PRINT-OFF                VALUE 1.
           05  TRAN-UPDATE-SW           PIC 99.
               88  TRAN-UPDATE              VALUE 1.
           05  CLEAR-SW                 PIC 99.
               88  CLEAR-SW-ON              VALUE 1.
           05  ERROR-LINE-SCREEN        PIC 99.
           05  UPDATE-SW                PIC 9.
               88  NO-UPDATE                VALUE 0.
               88  UPDATE-REQUIRED          VALUE 1.
           05  PROCESS-SW               PIC 9.
               88  NO-PROCESS               VALUE 0.
               88  PROCESSING-DONE          VALUE 1.
           05 FADM-CALL-SW              PIC 9.
               88  NO-CALL                  VALUE 0.
               88  DO-CALL                  VALUE 1.
557701     05  WS-REBUILD-AFTER-UNDO-SW         PIC X(01).
557701         88  WS-REBUILD-AFTER-UNDO-NO         VALUE 'N'.
557701         88  WS-REBUILD-AFTER-UNDO-YES        VALUE 'Y'.
016503     05  WS-REBUILD-AFTER-REDO-SW         PIC X(01).
016503         88  WS-REBUILD-AFTER-REDO-NO     VALUE 'N'.
016503         88  WS-REBUILD-AFTER-REDO-YES    VALUE 'Y'.
016503     05  WS-REDO-SWITCH          PIC X(01).
016503         88  WS-REDO-OK          VALUE 'Y'.
016503         88  WS-REDO-NOT-OK      VALUE 'N'.
016548*    05  I                        PIC S9(4)  COMP.
016548     05  I                        PIC S9(4)  BINARY.
016548*    05  J                        PIC S9(4)  COMP.
016548     05  J                        PIC S9(4)  BINARY.
016548*    05  N8                       PIC S9(4)  COMP.
016548     05  N8                       PIC S9(4)  BINARY.
           05  WS-NUM-FIELD             PIC S9(7)V99 COMP-3.
557973*    05  WS-CONTROL-TOTAL         PIC S9(11)V9999 COMP-3.
557973     05  WS-CONTROL-TOTAL         PIC S9(13)V9999 COMP-3.
557973*    05  WS-AMOUNT                PIC S9(11)V99 COMP-3.
557973     05  WS-AMOUNT                PIC S9(13)V99 COMP-3.
557973*    05  WS-NUM-PC                PIC S9(3)V9(4) COMP-3.
557973     05  WS-NUM-PC                PIC S9(9)V9(4) COMP-3.
557973*    05  WS-ALLOC-NUM             PIC S9(7)V9999 COMP-3.
557973     05  WS-ALLOC-NUM             PIC S9(13)V9999 COMP-3.
020469     05  WS-POL-CRCY-CD           PIC X(02) VALUE SPACES.
           05  WS-BUS-FCN-ID            PIC X(04).
               88  WS-BUS-FCN-VALID     VALUE '1830' '1831'.
               88  WS-BUS-FCN-AMOUNT    VALUE '1830'.
               88  WS-BUS-FCN-PERCENT   VALUE '1831'.
       01  WS-TWRK-FIELDS.
           05  WS-TWRK-WORK-AREA.
       COPY SCWWPDTQ.
014221*    05  WS-TWRK-LENGTH       PIC S9(05) VALUE +13400.
      /
      *************************************************************
      * COMMON COPYBOOKS
      *************************************************************

016503 COPY XCWWWKDT.
      /
557756*COPY CCWTYSNO.
      /
014221 COPY CCWWLOCK.
      /
      *************************************************************
      * I/O COPYBOOKS
      *************************************************************

014035*COPY SCFRFA.
      /
       COPY SCFRFC.
      /
       COPY SCFRFD.
      /
       COPY SCFRFS.
      /
       COPY CCFWCVG.
      /
       COPY CCFRCVG.
      /
557701 COPY CCFHPOL.
557701/
       COPY CCFWPOL.
      /
      *************************************************************
      * CALLED MODULE PARAMETER INFORMATION
      *************************************************************

016108 COPY CCWL0985.
020478 COPY CCWL2626.
016108/
557701 COPY CCWL4750.
557701/
       COPY CCWL5400.
      /
016503 COPY CCWL0201.
016503/
016503 COPY CCWL0289.
020463/
020463 COPY CCWL2735.
016503/
016503 COPY CCWL4780.
016503/
       COPY SCWL0410.
      /
       COPY SCWL0500.
      /
       COPY SCWL6340.
      /
       COPY SCWLSEGF.
      /
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
      /
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL8090.
      /
020469 COPY XCWL8640.
020469/
      *************************************************************
      * INPUT PARAMETER INFORMATION
      *************************************************************

      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.

       COPY CCWLPGA.
      /
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0130.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

021311     PERFORM  9990-INIT-WORKING-STORAGE
021311         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

021311*    SET MIR-RETRN-OK           TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
021311*    MOVE SPACE TO WPOL-KEY.
008455
008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  0200-PROCESS-REQUEST
               THRU 0200-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *----------------
       0150-INIT-TRANS.
      *----------------

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

       0150-INIT-TRANS-X.
           EXIT.
      /
      *---------------------
       0200-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0150-INIT-TRANS
               THRU 0150-INIT-TRANS-X.

           MOVE 1                 TO PRINT-ERROR-SW.
           SET PRINT-OFF          TO TRUE.
           MOVE 0                 TO WGLOB-MSG-ERROR-SW.
           SET NO-CALL            TO TRUE.
557701     SET WS-REBUILD-AFTER-UNDO-NO  TO TRUE.

025970*    MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.
           MOVE MIR-DV-PRCES-STATE-CD    TO WS-PRCES-STATE-CD.

           PERFORM  1000-SET-UP-INPUT
               THRU 1000-SET-UP-INPUT-X.

           IF NOT MIR-RETRN-OK
              GO TO 0200-PROCESS-REQUEST-X
           END-IF.

016503     SET  WS-REDO-OK               TO TRUE.

           PERFORM  1100-PROCESS-TRANS-PHASE
               THRU 1100-PROCESS-TRANS-PHASE-X.

016503     IF  WS-REDO-NOT-OK
014221     OR  MIR-RETRN-TS-MISMATCH
016503         GO TO 0200-PROCESS-REQUEST-X
016503     END-IF.

           IF  FADM-CALL-SW = 1
               PERFORM  1200-CALL-FADM
                   THRU 1200-CALL-FADM-X
557660     END-IF.

           PERFORM  1300-FORMAT-OUTPUT-SCREEN
               THRU 1300-FORMAT-OUTPUT-SCREEN-X.

       0200-PROCESS-REQUEST-X.
           EXIT.
      /
      *
      *------------------
       1000-SET-UP-INPUT.
      *------------------

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.
           MOVE ZERO                  TO UPDATE-SW.
           MOVE ZERO                  TO CLEAR-SW.

           PERFORM  1800-MOVE-SCREEN-TO-WS
               THRU 1800-MOVE-SCREEN-TO-WS-X.

       1000-SET-UP-INPUT-X.
           EXIT.
      /
      *-------------------------
       1100-PROCESS-TRANS-PHASE.
      *-------------------------

557660*    IF MIR-FORCE = '1'
557660*        PERFORM  1400-TRAN-PHASE-0
557660*            THRU 1400-TRAN-PHASE-0-X
557660*    ELSE
557660*    IF MIR-FORCE = '2'
557660*        PERFORM  1500-TRAN-PHASE-1
557660*            THRU 1500-TRAN-PHASE-1-X
557660*    ELSE
557660*    IF MIR-FORCE = '3'
557660*        PERFORM  1600-TRAN-PHASE-2
557660*            THRU 1600-TRAN-PHASE-2-X

           EVALUATE MIR-DV-PRCES-STATE-CD
557660
557660         WHEN '1'
557660             PERFORM  1400-TRAN-PHASE-0
557660                 THRU 1400-TRAN-PHASE-0-X
557660
557660         WHEN '2'
557660             PERFORM  1500-TRAN-PHASE-1
557660                 THRU 1500-TRAN-PHASE-1-X
557660
557660         WHEN '3'
557660             PERFORM  1600-TRAN-PHASE-2
557660                 THRU 1600-TRAN-PHASE-2-X
557660
557660     END-EVALUATE.
557660
       1100-PROCESS-TRANS-PHASE-X.
           EXIT.
      /
      *---------------
       1200-CALL-FADM.
      *---------------

           MOVE LSEGF-INV-CVG-REC-INFO                  TO RFC-REC-INFO.
           MOVE 'ADM'                 TO LSEGF-INPUT-TYP-CD.
           MOVE HOLD-POL-ID-BASE      TO LSEGF-INPUT-POL-ID-BASE.
           MOVE HOLD-POL-ID-SFX       TO LSEGF-INPUT-POL-ID-SFX.
           MOVE COV-HOLD              TO LSEGF-INPUT-CVG-NUM.
           MOVE LSEGF-INV-CVG-CFN-EFF-DT
                                      TO LSEGF-INPUT-EFF-DT.
           MOVE +0                    TO LSEGF-INPUT-SEQ-NUM
           MOVE +0                    TO LSEGF-INPUT-SURR-PCT.
557701     MOVE 'ANO'                 TO LSEGF-INPUT-REASN-CD.
008455*    COMPUTE LSEGF-INPUT-AMT = AMOUNT-HOLD-NO + AMOUNT-HOLD-PC.
008455     MOVE AMOUNT-NUM-HOLD       TO LSEGF-INPUT-AMT.
012134     MOVE ZEROS                 TO LSEGF-INPUT-TAX-YR.
           MOVE +0                    TO LSEGF-INPUT-LOAD-AMT.
           MOVE 'N'                   TO LSEGF-INPUT-LOAD-FORCE-IND.
           MOVE SPACES                TO LSEGF-INPUT-SRC-CD.

012696*    IF ALLOC-HOLD = 'A'
012696*        IF RFC-OUT-FND-ALLOC-CD = 'P'
012696*            MOVE 'B'       TO LSEGF-INPUT-ALLOC-IND
012696*        ELSE
012696*            MOVE 'D'       TO LSEGF-INPUT-ALLOC-IND
012696*        END-IF
012696*    ELSE
           MOVE ALLOC-HOLD            TO LSEGF-INPUT-ALLOC-IND
012696*    END-IF.

           MOVE SPACES                TO LSEGF-INPUT-COMM-PRCES-IND.
025388*    MOVE SPACES                TO LSEGF-INPUT-REG-FND-SRC-CD.
025388     SET  LSEGF-INPUT-FND-REG-CONTRB  TO TRUE.
557701     MOVE REASON-HOLD           TO LSEGF-INPUT-REASN-CD.

           MOVE 0                     TO J.
           PERFORM  1250-FORMAT-FD-FADM
               THRU 1250-FORMAT-FD-FADM-X
               VARYING I FROM 1 BY 1
               UNTIL I > LSEGF-FND-CTR.

012696*    IF (ALLOC-HOLD = 'A')
012696*    AND (RFC-OUT-FND-ALLOC-CD = 'P')
012696*        MOVE LSEGF-FND-CTR TO LSEGF-FIA-REC-CTR
012696*    ELSE
           MOVE J                     TO LSEGF-FIA-REC-CTR
012696*    END-IF.

           MOVE 'ADM'                 TO LSEGF-CIA-FIA-OPT-CD.

           PERFORM  6340-1000-BUILD-PARM-INFO
               THRU 6340-1000-BUILD-PARM-INFO-X.
           MOVE LSEGF-INPUT-EFF-DT    TO L6340-EFF-DT.
           MOVE LSEGF-INPUT-AMT       TO L6340-ADMIN-AMT.
           MOVE COV-HOLD-N            TO L6340-CVG-NUM.
           MOVE ALLOC-HOLD            TO L6340-ALLOC-CD.
557701     MOVE REASON-HOLD           TO L6340-REASN-CD.
012137     MOVE MIR-SUPRES-CNFRM-IND  TO L6340-SUPP-CONFIRM-CD.
016503     SET L6340-REDO-WARNING     TO TRUE.
           PERFORM 6340-1000-PROCESS-ADMIN
              THRU 6340-1000-PROCESS-ADMIN-X.
557701
557701     IF  WS-REBUILD-AFTER-UNDO-YES
557701         GO TO 1200-CALL-FADM-X
557701     END-IF.
557701
           IF L6340-RETRN-ERROR
              MOVE 1                  TO WGLOB-MSG-ERROR-SW
016761*       SET WGLOB-GUI-RETRN-ERROR TO TRUE
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               MOVE 0                 TO WS-CONTROL-TOTAL
               MOVE 1                 TO I
008455*        COMPUTE WS-AMOUNT = AMOUNT-HOLD-NO + AMOUNT-HOLD-PC
008455         MOVE AMOUNT-NUM-HOLD
008455                                TO WS-AMOUNT
               PERFORM  2900-REFORMAT-SCREEN
                   THRU 2900-REFORMAT-SCREEN-X
                   VARYING J FROM 1 BY 1
                   UNTIL J > LSEGF-FND-CTR
               IF WGLOB-MSG-ERROR-SW = 1
                   CONTINUE
               ELSE
                   PERFORM  2925-CHECK-TOTAL
                       THRU 2925-CHECK-TOTAL-X
                   MOVE 'SS01300018'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557973*            MOVE +8000        TO WTSQP-QUEUE-LENGTH
012696*            MOVE +8400        TO WTSQP-QUEUE-LENGTH
                   MOVE LSEGF-FC-FS-INFO
                                      TO WPDTQ-CMFC-AREA
                   MOVE LSEGF-FA-FD-INFO
                                      TO WPDTQ-CMFA-AREA

                   PERFORM  9800-WRITE-TWRK
                       THRU 9800-WRITE-TWRK-X

                   IF NOT L8090-RETRN-OK
                      MOVE 'XS00000092' TO WGLOB-MSG-REF-INFO
                      PERFORM  0260-1000-GENERATE-MESSAGE
                          THRU 0260-1000-GENERATE-MESSAGE-X
                   END-IF
557660         END-IF
557660     END-IF.

       1200-CALL-FADM-X.
           EXIT.
      /
      *--------------------
       1250-FORMAT-FD-FADM.
      *--------------------

           IF LSEGF-INPUT-ALLOC-IND = 'C'
008455*        COMPUTE WS-ALLOC-NUM = WS-ACHG-NO (I) + WS-ACHG-PC (I)
008455         MOVE WS-ACHG-NUM (I)   TO WS-ALLOC-NUM
           ELSE
               IF LSEGF-INPUT-ALLOC-IND = 'D'
                   COMPUTE WS-ALLOC-NUM
                           = WS-PCHG-NO (I) + WS-PCHG-PC (I)
012696         ELSE
012696             MOVE ZERO          TO LSEGF-INPUT-ALLOC-AMT (I)
012696             MOVE WS-FUND-CODE (I)
                                      TO LSEGF-INPUT-FND-ID (I)
557660         END-IF
557660     END-IF.

012696*    IF LSEGF-INPUT-ALLOC-IND NOT = 'B'
           IF WS-ALLOC-NUM NOT = 0
               COMPUTE J = J + 1
               MOVE WS-ALLOC-NUM      TO LSEGF-INPUT-ALLOC-AMT (J)
               MOVE WS-FUND-CODE (I)  TO LSEGF-INPUT-FND-ID (J)
034802*    ELSE
034802*        NEXT SENTENCE
           END-IF.
012696*    ELSE
012696*        MOVE 0                    TO LSEGF-INPUT-ALLOC-AMT (I)
012696*        MOVE WS-FUND-CODE (I)     TO LSEGF-INPUT-FND-ID (I)
012696*    END-IF.

      *---------------------
       1250-FORMAT-FD-FADM-X.
      *---------------------
           EXIT.
      /
      *--------------------------
       1300-FORMAT-OUTPUT-SCREEN.
      *--------------------------

           IF (CLEAR-SW-ON)
           OR (MIR-DV-PRCES-STATE-CD = '1'
           AND WS-PRCES-STATE-CD = '1')
               PERFORM  3000-FORMAT-TOP-LINE
                   THRU 3000-FORMAT-TOP-LINE-X
           ELSE
013578*        PERFORM  6050-FORMAT-FUND-NO
013578*            THRU 6050-FORMAT-FUND-NO-X
013578*            VARYING I FROM 1 BY 1
013578*            UNTIL I > LSEGF-FND-CTR
               PERFORM  3000-FORMAT-TOP-LINE
                   THRU 3000-FORMAT-TOP-LINE-X
               PERFORM  3100-MOVE-WS-TO-SCREEN
                   THRU 3100-MOVE-WS-TO-SCREEN-X
557660     END-IF.
      /
      *----------------------------
       1300-FORMAT-OUTPUT-SCREEN-X.
      *----------------------------
           EXIT.
      /
      *------------------
       1400-TRAN-PHASE-0.
      *------------------

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  2300-GET-POLICY
                   THRU 2300-GET-POLICY-X
557660     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221         GO TO 1400-TRAN-PHASE-0-X
014221     END-IF.

020463* CHECK FOR INVESTOR PROFILE
020463     PERFORM  2735-1000-BUILD-PARM-INFO
020463         THRU 2735-1000-BUILD-PARM-INFO-X.
020463     MOVE  RPOL-POL-ID   TO L2735-POL-ID.
020463     PERFORM  2735-1000-GET-PRFL
020463         THRU 2735-1000-GET-PRFL-X.
020463     IF L2735-RETRN-PRFL-FND
020463*MSG: THIS POLICY CONTAINS AN INVESTOR PROFILE.
020463*     THE ALLOCATIONS ENTERED FOR THIS ACTIVITY MAY NOT MATCH
020463*     THE ALLOCATIONS DEFINED FOR THE PROFILE
020463        MOVE 'SS01300024'      TO WGLOB-MSG-REF-INFO
020463        PERFORM  0260-1000-GENERATE-MESSAGE
020463           THRU  0260-1000-GENERATE-MESSAGE-X
020463
020463         IF  WGLOB-MSG-SEVRTY-FATAL
020463             SET WGLOB-RETURN-ERROR  TO TRUE
020463         END-IF
020463
020463     END-IF.
020463
           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  2350-EDATE-EDITS
                   THRU 2350-EDATE-EDITS-X
557660     END-IF.

016108     IF WGLOB-MSG-ERROR-SW = 0
016108         PERFORM  2360-VAL-DATE-OF-DTH
016108             THRU 2360-VAL-DATE-OF-DTH-X
016108     END-IF.

      *
      * NEED TO CALL FUNCTION DRIVER - EDIT PASS
      *
           IF WGLOB-MSG-ERROR-SW = ZERO
              PERFORM 1410-EDIT-ADMIN-FLDS
                 THRU 1410-EDIT-ADMIN-FLDS-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  2400-GET-FC
                   THRU 2400-GET-FC-X
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  2500-GET-CASH-VALUES
                   THRU 2500-GET-CASH-VALUES-X
557660     END-IF.

           PERFORM  2600-FORMAT-PHASE-0
               THRU 2600-FORMAT-PHASE-0-X.

      *--------------------
       1400-TRAN-PHASE-0-X.
      *--------------------
           EXIT.
      /
      *--------------------
       1410-EDIT-ADMIN-FLDS.
      *--------------------

           PERFORM  6340-1000-BUILD-PARM-INFO
               THRU 6340-1000-BUILD-PARM-INFO-X.
008455*    COMPUTE L6340-ADMIN-AMT = AMOUNT-HOLD-NO + AMOUNT-HOLD-PC.
008455     MOVE AMOUNT-NUM-HOLD       TO L6340-ADMIN-AMT.
           MOVE L1640-INTERNAL-DATE   TO L6340-EFF-DT.
           MOVE COV-HOLD-N            TO L6340-CVG-NUM.
           MOVE ALLOC-HOLD            TO L6340-ALLOC-CD.
557701     MOVE REASON-HOLD           TO L6340-REASN-CD.
           SET L6340-PRCES-TYP-EDIT-ONLY TO TRUE.
012137     MOVE MIR-SUPRES-CNFRM-IND  TO L6340-SUPP-CONFIRM-CD.
016503     SET L6340-REDO-WARNING     TO TRUE.
           PERFORM 6340-1000-PROCESS-ADMIN
              THRU 6340-1000-PROCESS-ADMIN-X.
           IF L6340-RETRN-ERROR
              MOVE 1                  TO WGLOB-MSG-ERROR-SW
016761*       SET WGLOB-GUI-RETRN-ERROR TO TRUE
           END-IF.

       1410-EDIT-ADMIN-FLDS-X.
           EXIT.
      /
      *------------------
       1500-TRAN-PHASE-1.
      *------------------

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  2300-GET-POLICY
                   THRU 2300-GET-POLICY-X
557660     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221         GO TO 1500-TRAN-PHASE-1-X
014221     END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  2350-EDATE-EDITS
                   THRU 2350-EDATE-EDITS-X
557660     END-IF.

016108     IF WGLOB-MSG-ERROR-SW = 0
016108         PERFORM  2360-VAL-DATE-OF-DTH
016108             THRU 2360-VAL-DATE-OF-DTH-X
016108     END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  2400-GET-FC
                   THRU 2400-GET-FC-X
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  4200-MOVE-SCREEN-TO-WS
                   THRU 4200-MOVE-SCREEN-TO-WS-X
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
      *
      ***** NO ERROR IN TOP INFORMATION *****
      *
               MOVE 0                 TO WS-CONTROL-TOTAL
               PERFORM  2800-EDIT-BOTTOM-DATA
                   THRU 2800-EDIT-BOTTOM-DATA-X
                   VARYING I FROM 1 BY 1
                   UNTIL I > LSEGF-FND-CTR
               IF WGLOB-MSG-ERROR-SW = 0
                   PERFORM  2850-TOTAL-CHECK
                       THRU 2850-TOTAL-CHECK-X
                   PERFORM  2650-FORMAT-PHASE-1
                       THRU 2650-FORMAT-PHASE-1-X
               ELSE
                   PERFORM  2650-FORMAT-PHASE-1
                       THRU 2650-FORMAT-PHASE-1-X
557660         END-IF
           ELSE
      *
      ***** ERROR IN TOP INFORMATION *****
      *
               SET NO-CALL TO TRUE
557660     END-IF.

557973*    MOVE +8000           TO WTSQP-QUEUE-LENGTH.
012696*    MOVE +8400           TO WTSQP-QUEUE-LENGTH.

           PERFORM  9700-RETRIEVE-TWRK
               THRU 9700-RETRIEVE-TWRK-X.

           IF L8090-RETRN-OK
              MOVE WPDTQ-CMFC-AREA        TO LSEGF-FC-FS-INFO
              MOVE WPDTQ-CMFA-AREA        TO LSEGF-FA-FD-INFO
              PERFORM  9900-DELETE-TWRK
                  THRU 9900-DELETE-TWRK-X
           END-IF.


       1500-TRAN-PHASE-1-X.
           EXIT.
      /
      *------------------
       1600-TRAN-PHASE-2.
      *------------------

           SET NO-CALL          TO TRUE.
557973*    MOVE +8000           TO WTSQP-QUEUE-LENGTH.
012696*    MOVE +8400           TO WTSQP-QUEUE-LENGTH.

           PERFORM  9700-RETRIEVE-TWRK
               THRU 9700-RETRIEVE-TWRK-X.

           IF  L8090-RETRN-OK
               MOVE WPDTQ-CMFC-AREA        TO LSEGF-FC-FS-INFO
               MOVE WPDTQ-CMFA-AREA        TO LSEGF-FA-FD-INFO
               PERFORM  9900-DELETE-TWRK
                   THRU 9900-DELETE-TWRK-X
           ELSE
               MOVE 'XS00000092'       TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 1600-TRAN-PHASE-2-X
           END-IF.

           PERFORM  2300-GET-POLICY
               THRU 2300-GET-POLICY-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221         GO TO 1600-TRAN-PHASE-2-X
014221     END-IF.

           PERFORM  2400-GET-FC
               THRU 2400-GET-FC-X.

016503* INVOKE REDO PROCESSING IF REQUIRED.
016503
016503     SET WS-REDO-OK                  TO TRUE.
016503     PERFORM  1605-INVOKE-REDO
016503         THRU 1605-INVOKE-REDO-X.

016503     IF  WS-REDO-NOT-OK
016503         GO TO 1600-TRAN-PHASE-2-X
016503     END-IF.
557701
557701     PERFORM  1610-INVOKE-UNDO
557701         THRU 1610-INVOKE-UNDO-X.
557701
557701     IF  NOT WGLOB-GOOD-RETURN
557701         GO TO 1600-TRAN-PHASE-2-X
557701     END-IF.
557701
           MOVE 'VER'             TO LSEGF-CIA-FIA-OPT-CD.
           PERFORM  6340-1000-BUILD-PARM-INFO
              THRU  6340-1000-BUILD-PARM-INFO-X.
           MOVE LSEGF-INPUT-EFF-DT         TO L6340-EFF-DT.
           MOVE LSEGF-INPUT-AMT            TO L6340-ADMIN-AMT.
           MOVE COV-HOLD-N                 TO L6340-CVG-NUM.
           MOVE ALLOC-HOLD                 TO L6340-ALLOC-CD.
557701     MOVE REASON-HOLD                TO L6340-REASN-CD.
012137     MOVE MIR-SUPRES-CNFRM-IND
                                      TO L6340-SUPP-CONFIRM-CD.
016503     SET L6340-REDO-WARNING     TO TRUE.
           PERFORM 6340-2000-VERIFY-ADMIN
              THRU 6340-2000-VERIFY-ADMIN-X.
           IF L6340-RETRN-OK
              MOVE 'SS01300001'  TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              MOVE LSEGF-INV-CVG-REC-INFO  TO RFC-REC-INFO
              MOVE RFC-CVG-CFN-REC-CTR     TO LSEGF-FND-CTR
              SET LSEGF-INV-CVG-CFN-OPT-UPD-FILE TO TRUE
              PERFORM  0500-1000-PROCESS-FC-FS
                  THRU 0500-1000-PROCESS-FC-FS-X
              IF L0500-RETRN-OK
016503           PERFORM  1700-SET-POL-NXT-ACTV
016503              THRU  1700-SET-POL-NXT-ACTV-X
                 PERFORM  POL-2000-REWRITE
                      THRU POL-2000-REWRITE-X
014221           PERFORM  POL-1000-READ-TWRK-TS
014221               THRU POL-1000-READ-TWRK-TS-X
                 MOVE LSEGF-INPUT-CVG-NUM  TO I
                 PERFORM CVGR-2000-REWRITE-COVERAGE
                    THRU CVGR-2000-REWRITE-COVERAGE-X
557660         END-IF
557660     END-IF.
      *

       1600-TRAN-PHASE-2-X.
           EXIT.

016503*-----------------
016503 1605-INVOKE-REDO.
016503*-----------------
016503
016503     IF  (RPOL-POL-NXT-ACTV-DT NOT = WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503         GO TO 1605-INVOKE-REDO-X
016503     END-IF.
016503
016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503         GO TO 1605-INVOKE-REDO-X
016503     END-IF.

016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     MOVE LSEGF-INPUT-EFF-DT            TO L4780-EFF-DT.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
016503     SET L4780-PRCES-INCLUSIVE          TO TRUE.
016503
016503     PERFORM  4780-1000-GET-NEXT-ACT-DT
016503         THRU 4780-1000-GET-NEXT-ACT-DT-X.
016503
016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              SET WS-REDO-NOT-OK           TO TRUE
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503             MOVE LSEGF-INPUT-EFF-DT  TO L0201-EFF-DT
016503             PERFORM  POL-3000-UNLOCK
016503                 THRU POL-3000-UNLOCK-X
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X

016503             PERFORM  1700-SET-POL-NXT-ACTV
016503                THRU  1700-SET-POL-NXT-ACTV-X

016503             MOVE RPOL-REC-INFO            TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503             MOVE HPOL-REC-INFO            TO RPOL-REC-INFO
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
016503             PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016503                 THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
016503             IF  L0201-RETRN-OK
016503                 PERFORM  POL-1000-READ-FOR-UPDATE
016503                     THRU POL-1000-READ-FOR-UPDATE-X
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503                 GO TO 1605-INVOKE-REDO-X
016503             END-IF
016503*
016503*  REBUILD SEGFUND TSQ'S, ETC.
016503*
016503             SET WS-REBUILD-AFTER-REDO-YES TO TRUE
016503             MOVE 0                     TO FADM-CALL-SW
016503
016307*  UNLOCK POLICY
016307             MOVE  RPOL-KEY             TO  WPOL-KEY
016307             PERFORM  POL-3000-UNLOCK
016307                 THRU POL-3000-UNLOCK-X
016307
016503             PERFORM  1500-TRAN-PHASE-1
016503                 THRU 1500-TRAN-PHASE-1-X
016503
016503             IF  FADM-CALL-SW = 1
016503                 PERFORM  1200-CALL-FADM
016503                     THRU 1200-CALL-FADM-X
016503                 MOVE 0                 TO FADM-CALL-SW
016503             END-IF
016503     END-EVALUATE.
016503
016503 1605-INVOKE-REDO-X.
016503     EXIT.

557701/
557701******************
557701 1610-INVOKE-UNDO.
557701******************
557701
557701*  UNLOCK POLICY PRIOR TO UNDO
557701     PERFORM  POL-3000-UNLOCK
557701         THRU POL-3000-UNLOCK-X.
557701
557701     PERFORM  4750-1000-BUILD-PARM-INFO
557701         THRU 4750-1000-BUILD-PARM-INFO-X.
557701

012137     IF MIR-SUPRES-CNFRM-IND = 'Y'
012137        SET L4750-SUPPRESS-CONFIRM  TO TRUE
012137     END-IF.

557701     SET L4750-FCN-DRVR-SECONDARY TO TRUE.
           MOVE LSEGF-INPUT-EFF-DT    TO L4750-EFF-DT.
557701     SET  L4750-PRCES-EXCLUSIVE   TO TRUE.
557701
557701     PERFORM  4750-1000-UNDO-PROCESSING
557701         THRU 4750-1000-UNDO-PROCESSING-X.
557701
557701     IF  NOT L4750-RETRN-OK
557701         SET WGLOB-RETURN-ERROR      TO TRUE
557701     END-IF.
557701
557701     IF  L4750-POL-UPDATE-NOT-REQD
557701*  RELOCK POLICY
557701         MOVE  RPOL-KEY         TO  WPOL-KEY
557701         PERFORM  POL-1000-READ-FOR-UPDATE
557701             THRU POL-1000-READ-FOR-UPDATE-X
557701         GO TO 1610-INVOKE-UNDO-X
557701     END-IF.
557701
557701*  SAVE POLICY CHANGES DONE BY UNDO PROCESS
557701     MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
557701
557701     MOVE RPOL-KEY              TO WPOL-KEY.
557701     PERFORM  POL-1000-READ-FOR-UPDATE
557701         THRU POL-1000-READ-FOR-UPDATE-X.

016503     PERFORM  1700-SET-POL-NXT-ACTV
016503        THRU  1700-SET-POL-NXT-ACTV-X.

557701     MOVE HPOL-REC-INFO         TO RPOL-REC-INFO.
557701
557701     PERFORM  POL-2000-REWRITE
557701         THRU POL-2000-REWRITE-X.
557701     PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
557701         THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.
557701
557701*  REBUILD SEGFUND TSQ'S, ETC. AS UNDO WILL HAVE CHANGED
557701*  TRANSACTIONS DATED AFTER THIS ONE
557701*
557701     SET WS-REBUILD-AFTER-UNDO-YES TO TRUE.
557701     SET NO-CALL                   TO TRUE.
557701
557701     PERFORM  1500-TRAN-PHASE-1
557701         THRU 1500-TRAN-PHASE-1-X.
557701
557701
557701     IF  DO-CALL
557701         PERFORM  1200-CALL-FADM
557701             THRU 1200-CALL-FADM-X
557701         SET NO-CALL               TO TRUE
557701     END-IF.
557701
016422*  RELOCK POLICY
016422*    MOVE  RPOL-KEY             TO  WPOL-KEY.
016422*    PERFORM  POL-1000-READ-FOR-UPDATE
016422*        THRU POL-1000-READ-FOR-UPDATE-X.
557701
557701 1610-INVOKE-UNDO-X.
557701     EXIT.
      /
016503*----------------------
016503 1700-SET-POL-NXT-ACTV.
016503*----------------------

016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503
016503     MOVE LSEGF-INPUT-EFF-DT TO L0289-LO-PAC-DT.
016503     MOVE LSEGF-INPUT-EFF-DT TO L0289-LO-CRC-DT.
016503     MOVE LSEGF-INPUT-EFF-DT TO L0289-PROC-EFF-DT.
016503
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD
016503           TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT
016503           TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE
016503                     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

016503 1700-SET-POL-NXT-ACTV-X.
016503     EXIT.

      *-----------------------
       1800-MOVE-SCREEN-TO-WS.
      *-----------------------

           PERFORM  4150-MOVE-TOP-TO-WS
               THRU 4150-MOVE-TOP-TO-WS-X.

           PERFORM  4200-MOVE-SCREEN-TO-WS
               THRU 4200-MOVE-SCREEN-TO-WS-X.

       1800-MOVE-SCREEN-TO-WS-X.
           EXIT.
      /
      *----------------
       2100-EDIT-INPUT.
      *----------------

           IF HOLD-POL-ID              = SPACES
               MOVE 'SS01300011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE COV-HOLD              TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO COV-HOLD-N
           END-IF.

           IF COV-HOLD NOT NUMERIC
007766*    OR (COV-HOLD < 00 OR COV-HOLD > 20)
007766     OR (COV-HOLD < 00 OR COV-HOLD > WCVGM-MAX-WCVGS-NUM)
               MOVE 'SS01300009'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
008455*    MOVE '7'                  TO L0280-LENGTH.
           MOVE '2'                   TO L0280-PRECISION.
           MOVE AMOUNT-HOLD           TO L0280-INPUT-DATA.
020906*    IF WGLOB-ENVRMNT-GUI
020906     IF WGLOB-ENVRMNT-ONLINE
008455        MOVE LENGTH OF MIR-CIA-CLI-TRXN-AMT
                                      TO L0280-INPUT-SIZE
008455     ELSE
008455*    LIMIT THE AMOUNT FIELD SIZE TO 10 FOR 3270 ENVIRONMENT
008455*    FOR IT WILL DISPLAY ********* IF IT EXCEEDS THIS LENGTH
008455        MOVE 10                 TO L0280-INPUT-SIZE
008455     END-IF.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO AMOUNT-NUM-HOLD
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         PERFORM  8200-FORMAT-AMOUNT
008455             THRU 8200-FORMAT-AMOUNT-X
008455         MOVE L0290-OUTPUT-DATA TO AMOUNT-HOLD
008455*    END-IF.
008455*
008455*    IF AMOUNT-A-HOLD-NO NOT NUMERIC
008455*      OR AMOUNT-A-HOLD-PT NOT = '.'
008455*      OR AMOUNT-A-HOLD-PC NOT NUMERIC
008455     ELSE
               MOVE 'SS01300014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
012137*    VALIDATE VALUE FOR SUPPRESS CONFIRMATION FIELD
012137     IF  MIR-SUPRES-CNFRM-IND NOT = SPACES
012137         IF    MIR-SUPRES-CNFRM-IND NOT = 'Y'
012137         AND   MIR-SUPRES-CNFRM-IND NOT = 'N'
012137*MSG: SUPPRESS CONFIRMATION STATEMENT INVALID. ENTER  'Y' OR 'N'
012137               MOVE 'SS01300022'             TO WGLOB-MSG-REF-INFO
012137               PERFORM  0260-1000-GENERATE-MESSAGE
012137                   THRU 0260-1000-GENERATE-MESSAGE-X
012137         END-IF
012137     ELSE
012137         MOVE 'N'               TO MIR-SUPRES-CNFRM-IND
012137     END-IF.
012137

       2100-EDIT-INPUT-X.
           EXIT.
      /
      *----------------
       2300-GET-POLICY.
      *----------------

           MOVE HOLD-POL-ID-BASE      TO WPOL-POL-ID-BASE.
           MOVE HOLD-POL-ID-SFX       TO WPOL-POL-ID-SFX.

016422*    IF  WPOL-KEY = RPOL-KEY
016422*        GO TO 2300-GET-POLICY-X
016422*    END-IF.
016422*
014221     EVALUATE MIR-DV-PRCES-STATE-CD
014221
014221         WHEN '1'
014221         WHEN '2'
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
014221             PERFORM  POL-1000-READ-FOR-UPDATE
014221                 THRU POL-1000-READ-FOR-UPDATE-X
014221
014221         WHEN '3'
014221             PERFORM  POL-2000-UPDATE-TWRK-TS
014221                 THRU POL-2000-UPDATE-TWRK-TS-X
014221             IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                 MOVE 'XS00000303'    TO WGLOB-MSG-REF-INFO
014221                 MOVE 'POL'           TO WGLOB-MSG-PARM (01)
014221                 MOVE WPOL-KEY        TO WGLOB-MSG-PARM (02)
014221                 PERFORM  0260-1000-GENERATE-MESSAGE
014221                     THRU 0260-1000-GENERATE-MESSAGE-X
014221                 GO TO 2300-GET-POLICY-X
014221             END-IF
014221
014221     END-EVALUATE.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2300-GET-POLICY-X
557660     END-IF.
      *
      ***  POLICY ACCESS VERIFICATION
      *

012624     IF RPOL-POL-SUSPENDED
012624*MSG: POLICY CURRENTLY SUPENDED - CANNOT MAINTAIN OR PROCESS
012624        MOVE 'XS00000240'      TO  WGLOB-MSG-REF-INFO
012624        PERFORM  0260-1000-GENERATE-MESSAGE
012624            THRU 0260-1000-GENERATE-MESSAGE-X
012624        IF WGLOB-MSG-SEVRTY-FATAL
012624        OR WGLOB-MSG-SEVRTY-SYSTEM
012624           GO TO 2300-GET-POLICY-X
012624        END-IF
012624     END-IF.

016440*    IF RPOL-POL-APPL-CTL-NBS
016440*MSG : NUWBUS POLICY - CANNOT MAINTAIN OR PROCESS
016440*       MOVE 'XS00000238'      TO  WGLOB-MSG-REF-INFO
016440*       PERFORM  0260-1000-GENERATE-MESSAGE
016440*           THRU 0260-1000-GENERATE-MESSAGE-X
016440*       IF WGLOB-MSG-SEVRTY-FATAL
016440*       OR WGLOB-MSG-SEVRTY-SYSTEM
016440*          GO TO 2300-GET-POLICY-X
016440*       END-IF
016440*    END-IF.
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.
016440     SET L5400-POL-XFER-UPDATE  TO TRUE.
           PERFORM 5400-1000-POL-CHK
              THRU 5400-1000-POL-CHK-X.
           IF  L5400-CNFD-ACCS-RESTRICTED
012624*    OR  L5400-CTL-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
012624*    OR  L5400-STAT-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               GO TO 2300-GET-POLICY-X
557660     END-IF.

           MOVE RPOL-POL-ID           TO LPGA-POLICY-NUMBER.

           IF  COV-HOLD = 0
           OR  COV-HOLD > RPOL-POL-CVG-REC-CTR-N
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2300-GET-POLICY-X
557660     END-IF.

           IF  RPOL-POL-CVG-REC-CTR-N NOT = 0
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.
016440     IF WCVGS-CVG-STAT-BEFORE-SETL (COV-HOLD-N)
016440* MSG: COVERAGE NOT IN FORCE - CANNOT MAINTAIN OR PROCESS
016440        MOVE 'XS00000244'       TO WGLOB-MSG-REF-INFO
016440         PERFORM  0260-1000-GENERATE-MESSAGE
016440             THRU 0260-1000-GENERATE-MESSAGE-X
016440     END-IF.

       2300-GET-POLICY-X.
           EXIT.
      /
      *-----------------
       2350-EDATE-EDITS.
      *-----------------

           MOVE COV-HOLD              TO J.
           MOVE EDATE-HOLD            TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
               MOVE 'SS01300017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               MOVE L1640-INTERNAL-DATE
                                      TO LSEGF-INV-CVG-CFN-EFF-DT
               MOVE L1640-INTERNAL-DATE
                                      TO LSEGF-CIA-FIA-EFF-DT
           END-IF.

       2350-EDATE-EDITS-X.
           EXIT.
      /
016108*---------------------
016108 2360-VAL-DATE-OF-DTH.
016108*---------------------
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE LSEGF-INV-CVG-CFN-EFF-DT  TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE +1                    TO WGLOB-MSG-ERROR-SW
016108     END-IF.
016108
016108 2360-VAL-DATE-OF-DTH-X.
016108     EXIT.
016108/
      *------------
       2400-GET-FC.
      *------------

           MOVE COV-HOLD              TO I.
014591*    MOVE WCVGS-PLAN-ID-BASE (I)   TO LSEGF-PLAN-ID-BASE.
014591*    MOVE WCVGS-PLAN-ID-RS (I)  TO LSEGF-PLAN-ID-RS.
014591     MOVE WCVGS-PLAN-ID (I)     TO LSEGF-PLAN-ID.
012146     MOVE WCVGS-CVG-UNIT-TYP-CD (I)
                                      TO LSEGF-CVG-UNIT-TYP-CD.
           MOVE SPACES                TO LSEGF-ALLOC-INFO.
           SET LSEGF-INV-CVG-CFN-OPT-READ-INQ TO TRUE.
           PERFORM  0500-1000-PROCESS-FC-FS
               THRU 0500-1000-PROCESS-FC-FS-X.

           IF L0500-RETRN-ERROR
              GO TO 2400-GET-FC-X
           END-IF.

           MOVE LSEGF-INV-CVG-REC-INFO   TO RFC-REC-INFO.
           IF RFC-EARLST-CIA-DT    > LSEGF-INV-CVG-CFN-EFF-DT
              MOVE 'SS01300021'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2400-GET-FC-X
           END-IF.

           MOVE 1                     TO J.
           PERFORM 8000-MOVE-FS-TO-WS
              THRU 8000-MOVE-FS-TO-WS-X
              VARYING I FROM 1 BY 1
              UNTIL I > LSEGF-FND-CTR.
           IF J = 1
              MOVE 'SS01300012'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
012696*        IF ALLOC-HOLD NOT = 'A'
               COMPUTE LSEGF-FND-CTR = J - 1
012696*        END-IF
           END-IF.

       2400-GET-FC-X.
           EXIT.
      /
      *---------------------
       2500-GET-CASH-VALUES.
      *---------------------

           MOVE ZERO            TO LSEGF-INV-CVG-CFN-SEQ-NUM.
016537*    PERFORM  0410-1000-SEG-FND-CV
016537*        THRU 0410-1000-SEG-FND-CV-X.
016537     PERFORM  0410-0100-SEG-FND-CV
016537         THRU 0410-0100-SEG-FND-CV-X.

           IF L0410-RETRN-ERROR
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  2520-MOVE-CASH-VALUES
                   THRU 2520-MOVE-CASH-VALUES-X
                   VARYING I FROM 1 BY 1
                   UNTIL I > LSEGF-FND-CTR
           END-IF.

       2500-GET-CASH-VALUES-X.
           EXIT.
      /
      *---------------------
       2520-MOVE-CASH-VALUES.
      *---------------------

020469*    MOVE LSEGF-CFN-CV-AMT   (I)               TO WS-FVAL-NUM (I).
020874*    COMPUTE L0290-INPUT-NUMBER = LSEGF-CFN-CV-AMT (I) * 100.
020469*    MOVE LSEGF-CFN-CV-AMT (I)  TO L0290-INPUT-V02.
020464*    MOVE LSEGF-CFN-FND-CRCY-CV-AMT (I)
020464*                               TO WS-FVAL-NUM (I).
020464*    MOVE LSEGF-CFN-FND-CRCY-CV-AMT (I)
020469*                               TO L0290-INPUT-V02.
020464     MOVE LSEGF-CFN-DEFR-IN-AMT  (I)
020464                                  TO WS-SCREEN-FS-DEFR-IN-N  (I).
020464     MOVE LSEGF-CFN-DEFR-OUT-AMT (I)
020464                                  TO WS-SCREEN-FS-DEFR-OUT-N (I).
020464     COMPUTE  WS-FVAL-NUM (I)
020464           =  LSEGF-CFN-FND-CRCY-CV-AMT (I)
020464           +  LSEGF-CFN-DEFR-IN-AMT     (I)
020464           +  LSEGF-CFN-DEFR-OUT-AMT    (I).
020464
020464     MOVE WS-FVAL-NUM (I)       TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO WS-FVAL (I).

020464*    MOVE LSEGF-CFN-POL-CRCY-CV-AMT (I)
020464*                               TO L0290-INPUT-V02.
020464     COMPUTE  L0290-INPUT-V02
020464           =  LSEGF-CFN-POL-CRCY-CV-AMT  (I)
020464           +  LSEGF-CFN-POL-DEFR-IN-AMT  (I)
020464           +  LSEGF-CFN-POL-DEFR-OUT-AMT (I).
020464
020469     MOVE 2                     TO L0290-PRECISION.
020469     MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (WS-SUB)
020469                                TO L0290-MAX-OUT-LEN.
020469     PERFORM  0290-2000-FORMAT-FOR-MIR
020469         THRU 0290-2000-FORMAT-FOR-MIR-X.
020469     MOVE L0290-OUTPUT-DATA    TO MIR-DV-FIA-POL-CRCY-AMT-T (I).

       2520-MOVE-CASH-VALUES-X.
           EXIT.
      /
      *-------------------
       2600-FORMAT-PHASE-0.
      *--------------------

           IF WGLOB-MSG-ERROR-SW = 1
               SET NO-CALL        TO TRUE
               GO TO 2600-FORMAT-PHASE-0-X
557660     END-IF.

557660***  IF ALLOC-HOLD = 'A'
557660
557660     EVALUATE ALLOC-HOLD
557660
012696*        WHEN 'A'
012696*            MOVE 1             TO FADM-CALL-SW
012696*            MOVE '3'           TO MIR-FORCE
012696*            MOVE 'P'           TO LTPI-CURSOR-POS-IND
557660***  ELSE
557660***  IF ALLOC-HOLD = 'D'
557660
557660         WHEN  'D'
                   SET NO-CALL        TO TRUE
                   MOVE '2'           TO WS-PRCES-STATE-CD
557660
557660         WHEN 'C'
                   SET NO-CALL        TO TRUE
                   MOVE '2'           TO WS-PRCES-STATE-CD
557660
557660     END-EVALUATE.

           IF VALID-ALLOC-CODE
               CONTINUE
012696     ELSE
012696         MOVE 'SS01300023'      TO WGLOB-MSG-REF-INFO
012696         PERFORM  0260-1000-GENERATE-MESSAGE
012696             THRU 0260-1000-GENERATE-MESSAGE-X

557660     END-IF.


       2600-FORMAT-PHASE-0-X.
           EXIT.
      /
      *-------------------
       2650-FORMAT-PHASE-1.
      *-------------------

           IF WGLOB-MSG-ERROR-SW = 1
               SET NO-CALL        TO TRUE
           ELSE
               MOVE 1                 TO FADM-CALL-SW
               MOVE '3'               TO WS-PRCES-STATE-CD
557660     END-IF.

       2650-FORMAT-PHASE-1-X.
           EXIT.
      /
      *----------------------
       2800-EDIT-BOTTOM-DATA.
      *----------------------

           IF ALLOC-HOLD = 'C'
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
008455*        MOVE '7'                  TO L0280-LENGTH
               MOVE '2'               TO L0280-PRECISION
               MOVE WS-ACHG (I)       TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-FIA-FND-TRXN-AMT-T (I)
008455                                TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-ACHG-NUM (I)
008455             MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             PERFORM  8202-FORMAT-ACHG
008455                 THRU 8202-FORMAT-ACHG-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO WS-ACHG (I)
008455             COMPUTE WS-CONTROL-TOTAL = WS-CONTROL-TOTAL +
008455                                        WS-ACHG-NUM (I)
008455*        END-IF
008455*        IF WS-A-ACHG-NO (I) NOT NUMERIC
008455*        OR WS-A-ACHG-PT (I) NOT = '.'
008455*        OR WS-A-ACHG-PC (I) NOT NUMERIC
008455         ELSE
                   MOVE 1             TO WGLOB-MSG-ERROR-SW
                   MOVE 'SS01300010'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
008455*        ELSE
008455*            COMPUTE WS-CONTROL-TOTAL = WS-CONTROL-TOTAL +
008455*                    WS-ACHG-NO (I) + WS-ACHG-PC (I)
557660         END-IF
557660     END-IF.

           IF ALLOC-HOLD = 'D'
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE '7'               TO L0280-LENGTH
               MOVE '2'               TO L0280-PRECISION
               MOVE WS-PCHG (I)       TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-PCHG-NUM (I)
               END-IF
               IF WS-A-PCHG-NO (I) NOT NUMERIC
                 OR WS-A-PCHG-PT (I) NOT = '.'
                 OR WS-A-PCHG-PC (I) NOT NUMERIC
                   MOVE 1             TO WGLOB-MSG-ERROR-SW
                   MOVE 'SS01300006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   COMPUTE WS-CONTROL-TOTAL = WS-CONTROL-TOTAL +
                             WS-PCHG-NO (I) + WS-PCHG-PC (I)
557660         END-IF
557660     END-IF.

      *------------------------
       2800-EDIT-BOTTOM-DATA-X.
      *------------------------
           EXIT.
      /
      *-----------------
       2850-TOTAL-CHECK.
      *-----------------

           IF ALLOC-HOLD = 'D'
               IF WS-CONTROL-TOTAL NOT = 100.0000
                   MOVE 'SS01300019'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               IF ALLOC-HOLD = 'C'
008455*            COMPUTE WS-AMOUNT = AMOUNT-HOLD-NO + AMOUNT-HOLD-PC
008455             MOVE AMOUNT-NUM-HOLD
                                      TO WS-AMOUNT
                   IF WS-CONTROL-TOTAL NOT = WS-AMOUNT
                       MOVE 'SS01300003'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
557660             END-IF
557660         END-IF
557660     END-IF.

       2850-TOTAL-CHECK-X.
           EXIT.
      /
      *---------------------
       2900-REFORMAT-SCREEN.
      *---------------------

           IF I > LSEGF-FIA-REC-CTR
             OR WS-FUND-CODE (J) NOT = LSEGF-INPUT-FND-ID (I)
012696*        IF ALLOC-HOLD = 'A'
012696*        OR ALLOC-HOLD = 'D'
012696         IF ALLOC-HOLD = 'D'
                   MOVE ZERO          TO WS-ACHG-NUM (J)
020874*            MOVE 0             TO L0290-INPUT-NUMBER
020874             MOVE ZERO          TO L0290-INPUT-V02
008455             PERFORM  8202-FORMAT-ACHG
008455                 THRU 8202-FORMAT-ACHG-X
008455             MOVE L0290-OUTPUT-DATA
008455                                TO WS-ACHG (J)
                   GO TO 2900-REFORMAT-SCREEN-X
557660         END-IF
557660     END-IF.

           IF I > LSEGF-FIA-REC-CTR
             OR WS-FUND-CODE (J) NOT = LSEGF-INPUT-FND-ID (I)
012696*        IF LSEGF-INPUT-ALLOC-IND = 'B'
012696*        OR LSEGF-INPUT-ALLOC-IND = 'C'
012696         IF LSEGF-INPUT-ALLOC-IND = 'C'
                   MOVE ZERO          TO WS-PCHG-NUM (J)
                   GO TO 2900-REFORMAT-SCREEN-X
557660         END-IF
557660     END-IF.

           MOVE LSEGF-FIA-REC-INFO (I)                  TO RFD-REC-INFO.

020469*    COMPUTE RFD-FIA-FND-TRXN-AMT = -1.0 * RFD-FIA-FND-TRXN-AMT.
023091*    IF  RPOL-POL-MULT-CRCY
020469         COMPUTE RFD-FIA-ORIG-TRXN-AMT = -1.0
020469                                           * RFD-FIA-ORIG-TRXN-AMT
023091*    ELSE
023091*        COMPUTE RFD-FIA-FND-TRXN-AMT  = -1.0
023091*                                          * RFD-FIA-FND-TRXN-AMT
023091*    END-IF.

012696*    IF ALLOC-HOLD = 'A'
012696*    OR ALLOC-HOLD = 'D'
012696     IF ALLOC-HOLD = 'D'
020469*        MOVE RFD-FIA-FND-TRXN-AMT
020469*                               TO WS-ACHG-NUM (J)
023091*        IF  RPOL-POL-MULT-CRCY
020469             MOVE RFD-FIA-ORIG-TRXN-AMT TO WS-ACHG-NUM (J)
023091*        ELSE
023091*            MOVE RFD-FIA-FND-TRXN-AMT  TO WS-ACHG-NUM (J)
023091*        END-IF
020874*        COMPUTE L0290-INPUT-NUMBER = RFD-FIA-FND-TRXN-AMT * 100
020874         MOVE RFD-FIA-FND-TRXN-AMT TO L0290-INPUT-V02
008455         PERFORM  8202-FORMAT-ACHG
008455             THRU 8202-FORMAT-ACHG-X
008455         MOVE L0290-OUTPUT-DATA TO WS-ACHG (J)
557660     END-IF.

012696*    IF LSEGF-INPUT-ALLOC-IND = 'B'
012696*    OR LSEGF-INPUT-ALLOC-IND = 'C'
012696     IF LSEGF-INPUT-ALLOC-IND = 'C'
020469*        COMPUTE WS-NUM-PC ROUNDED
020469*            = RFD-FIA-FND-TRXN-AMT / WS-AMOUNT * 100.0000
023091*        IF  RPOL-POL-MULT-CRCY
020469             COMPUTE WS-NUM-PC ROUNDED
020469             = RFD-FIA-ORIG-TRXN-AMT / WS-AMOUNT * 100.0000
023091*        ELSE
023091*            COMPUTE WS-NUM-PC ROUNDED
023091*            = RFD-FIA-FND-TRXN-AMT / WS-AMOUNT * 100.0000
023091*        END-IF
               MOVE WS-NUM-PC         TO WS-PCHG-NUM (J)
               COMPUTE WS-CONTROL-TOTAL
                   = WS-CONTROL-TOTAL + WS-NUM-PC
557660     END-IF.

           ADD 1                  TO I.

       2900-REFORMAT-SCREEN-X.
           EXIT.
      /
      *-----------------
       2925-CHECK-TOTAL.
      *-----------------

           IF ALLOC-HOLD = 'C'
               IF WS-CONTROL-TOTAL NOT = 100.0000
                   MOVE 0             TO J
                   PERFORM  2950-FIND-FIRST-FUND
                       THRU 2950-FIND-FIRST-FUND-X
                       VARYING I FROM 1 BY 1
012141*                UNTIL I > 15
012141                 UNTIL I > WFNDM-MAX-WFUND-NUM
                       OR J NOT = 0
                   COMPUTE WS-NUM-PC
                       = WS-PCHG-NO (J) + WS-PCHG-PC (J)
                       - WS-CONTROL-TOTAL + 100.0000
                   MOVE WS-NUM-PC     TO WS-PCHG-NUM (J)
557660         END-IF
557660     END-IF.

       2925-CHECK-TOTAL-X.
           EXIT.
      /
      *---------------------
       2950-FIND-FIRST-FUND.
      *---------------------

           IF LSEGF-INPUT-FND-ID (1) = WS-FUND-CODE (I)
               MOVE I                 TO J
557660     END-IF.

       2950-FIND-FIRST-FUND-X.
           EXIT.
      /
      *---------------------
       3000-FORMAT-TOP-LINE.
      *---------------------

           MOVE HOLD-POL-ID-BASE      TO MIR-POL-ID-BASE.
           MOVE HOLD-POL-ID-SFX       TO MIR-POL-ID-SFX.
           MOVE COV-HOLD              TO MIR-CVG-NUM.
           MOVE EDATE-HOLD            TO MIR-CIA-EFF-DT.
557701     MOVE REASON-HOLD           TO MIR-CIA-REASN-CD.
008455*    MOVE AMOUNT-HOLD-A     TO MIR-CIA-CLI-TRXN-AMT.
008455     MOVE AMOUNT-HOLD           TO MIR-CIA-CLI-TRXN-AMT.
020469     MOVE RPOL-POL-CRCY-CD      TO WS-POL-CRCY-CD.

       3000-FORMAT-TOP-LINE-X.
           EXIT.
      /
      *-----------------------
       3100-MOVE-WS-TO-SCREEN.
      *-----------------------

557660     PERFORM
557660         VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-LINES
557660
557660*        MOVE WS-A-FNUM (WS-SUB)      TO MIR-FNUM-T (WS-SUB)
013578*        IF WS-A-FNUM( WS-SUB ) NUMERIC
013578*           MOVE WS-A-FNUM ( WS-SUB)
013578*                               TO MIR-FNUM-T (WS-SUB)
013578*        ELSE
013578*           MOVE SPACES         TO MIR-FNUM-T (WS-SUB)
013578*        END-IF
               MOVE WS-FUND-CODE (WS-SUB)
                                      TO MIR-FND-ID-T (WS-SUB)
008455*        MOVE WS-A-FVAL (WS-SUB)
008455*                               TO MIR-DV-CFN-APROX-AMT-T (WS-SUB)
008455         MOVE WS-FVAL (WS-SUB)  TO MIR-DV-CFN-APROX-AMT-T (WS-SUB)
008455
008455*        MOVE WS-A-ACHG (WS-SUB)
008455*                               TO MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
008455         MOVE WS-ACHG (WS-SUB)  TO MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
008455
               MOVE WS-A-PCHG (WS-SUB)
                                      TO MIR-DV-OUT-ALLOC-PCT-T (WS-SUB)

020469*       RETRIEVE THE FUNDS CURRENCY
020469*       WHICH IS STORED BY COUNTRY CODE ON THE
020469*       CRCY TABLE
020469        IF  WS-FUND-CODE (WS-SUB) NOT = SPACES
020469            PERFORM  8640-1000-BUILD-PARM-INFO
020469                THRU 8640-1000-BUILD-PARM-INFO-X
020469            MOVE WS-FUND-CODE (WS-SUB)
020469                                TO L8640-FND-ID
020469            PERFORM  8640-1000-GET-FND-CRCY-CD
020469                THRU 8640-1000-GET-FND-CRCY-CD-X
020469            IF  L8640-RETRN-OK
020469                MOVE L8640-FND-CRCY-CD
020469                                TO MIR-FIA-CRCY-CD-T (WS-SUB)
020469*               FOR EACH OF THE FUNDS MOVE THE POLICY CURRENCY TO
020469*               MIR
020469                MOVE WS-POL-CRCY-CD
020469                                TO MIR-POL-CRCY-CD-T (WS-SUB)
020469           ELSE
020469                MOVE SPACES     TO MIR-FIA-CRCY-CD-T (WS-SUB)
020469                MOVE SPACES     TO MIR-POL-CRCY-CD-T (WS-SUB)
020469           END-IF
020469        END-IF
557660
           END-PERFORM.

       3100-MOVE-WS-TO-SCREEN-X.
           EXIT.
      /
      *-------------------
       4150-MOVE-TOP-TO-WS.
      *-------------------

           MOVE MIR-POL-ID-BASE       TO HOLD-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO HOLD-POL-ID-SFX.
           MOVE MIR-CVG-NUM           TO COV-HOLD.
           MOVE KEY-HOLD              TO LSEGF-INV-CVG-REST-KEY-INFO.
           MOVE MIR-CIA-EFF-DT        TO EDATE-HOLD.
557701     MOVE MIR-CIA-REASN-CD      TO REASON-HOLD.
008455*    MOVE MIR-CIA-CLI-TRXN-AMT        TO AMOUNT-HOLD-A.
008455     MOVE MIR-CIA-CLI-TRXN-AMT  TO AMOUNT-HOLD.
008455     SET L0280-SIGN-NOT-PERMITTED TO TRUE
008455     MOVE 2                     TO L0280-PRECISION
008455     MOVE MIR-CIA-CLI-TRXN-AMT  TO L0280-INPUT-DATA
008455     MOVE LENGTH OF MIR-CIA-CLI-TRXN-AMT
008455                                TO L0280-INPUT-SIZE
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X
008455     IF L0280-OK
008455        MOVE L0280-OUTPUT       TO AMOUNT-NUM-HOLD
008455     END-IF
008455
012137     IF MIR-SUPRES-CNFRM-IND = 'Y'
012137        SET L6340-SUPPRESS-CONFIRM  TO TRUE
012137     END-IF.

           EVALUATE TRUE
              WHEN WS-BUS-FCN-AMOUNT
                   MOVE 'C'              TO  ALLOC-HOLD
              WHEN WS-BUS-FCN-PERCENT
                   MOVE 'D'              TO  ALLOC-HOLD
              WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'     TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID   TO  WGLOB-MSG-PARM (01)
                   MOVE 'SSOM0130'       TO  WGLOB-MSG-PARM (02)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST TO  TRUE
           END-EVALUATE.


       4150-MOVE-TOP-TO-WS-X.
           EXIT.
      /
      *----------------------
       4200-MOVE-SCREEN-TO-WS.
      *----------------------

557660     PERFORM
557660         VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-LINES
557660
               MOVE MIR-FND-ID-T (WS-SUB)
                                      TO WS-A-FUND-CODE (WS-SUB)
008455*        MOVE MIR-DV-CFN-APROX-AMT-T (WS-SUB)
008455*                               TO WS-A-FVAL (WS-SUB)
008455         MOVE MIR-DV-CFN-APROX-AMT-T (WS-SUB)
                                      TO WS-FVAL   (WS-SUB)
008455         SET L0280-SIGN-NOT-PERMITTED TO TRUE
008455         MOVE 2                 TO L0280-PRECISION
008455         MOVE MIR-DV-CFN-APROX-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (WS-SUB)
008455                                TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
008455         PERFORM  0280-1000-NUMERIC-EDIT
008455             THRU 0280-1000-NUMERIC-EDIT-X
008455         IF L0280-OK
008455            MOVE L0280-OUTPUT   TO WS-FVAL-NUM (WS-SUB)
008455         END-IF
008455
008455*        MOVE MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
008455*                               TO WS-A-ACHG (WS-SUB)
008455         MOVE MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
                                      TO WS-ACHG   (WS-SUB)
008455         SET L0280-SIGN-NOT-PERMITTED TO TRUE
008455         MOVE 2                 TO L0280-PRECISION
008455         MOVE MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
008455                                TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
008455         PERFORM  0280-1000-NUMERIC-EDIT
008455             THRU 0280-1000-NUMERIC-EDIT-X
008455         IF L0280-OK
008455            MOVE L0280-OUTPUT   TO WS-ACHG-NUM (WS-SUB)
008455         END-IF
               MOVE MIR-DV-OUT-ALLOC-PCT-T (WS-SUB)
                                      TO WS-A-PCHG (WS-SUB)
557660
           END-PERFORM.

       4200-MOVE-SCREEN-TO-WS-X.
           EXIT.
      /
013578*--------------------
013578*6050-FORMAT-FUND-NO.
013578*--------------------
013578*
013578*    MOVE I                     TO WS-FNUM (I).
013578*
013578*6050-FORMAT-FUND-NO-X.
013578*    EXIT.
      /
      *------------------.
       8000-MOVE-FS-TO-WS.
      *------------------.

           MOVE LSEGF-CFN-REC-INFO (I)   TO RFS-REC-INFO.
           MOVE RFS-FND-ID            TO WS-FUND-CODE (J).
012696*    MOVE RFS-CFN-OUT-ALLOC-PCT TO WS-PCHG-NUM (J).
           MOVE 0.0                   TO WS-ACHG-NUM (J).
           MOVE 0.0                   TO WS-PCHG-NUM (J).
020874*    MOVE 0                     TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     PERFORM  8202-FORMAT-ACHG
008455         THRU 8202-FORMAT-ACHG-X.
008455     MOVE L0290-OUTPUT-DATA     TO WS-ACHG (J).
           ADD 1                     TO J.

       8000-MOVE-FS-TO-WS-X.
           EXIT.
      /
008455*------------------.
008455 8200-FORMAT-AMOUNT.
008455*------------------.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CIA-CLI-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

008455 8200-FORMAT-AMOUNT-X.
008455     EXIT.
008455/
008455*------------------.
008455 8202-FORMAT-ACHG.
008455*------------------.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-FIA-FND-TRXN-AMT-T (1)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455
008455 8202-FORMAT-ACHG-X.
008455     EXIT.
008455/

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /

      *---------------------
       9500-BUILD-TWRK-KEY.
      *--------------------

           MOVE +1                  TO  L8090-TEMP-WRK-SEQ-NUM.
           SET L8090-TEMP-WRK-TYP-SEG-ACTV    TO  TRUE.
014221*    MOVE WS-TWRK-LENGTH       TO  L8090-AREA-LEN.
014221     MOVE LENGTH OF WS-TWRK-WORK-AREA TO  L8090-AREA-LEN.

       9500-BUILD-TWRK-KEY-X.
           EXIT.
      /
      *-------------------
       9700-RETRIEVE-TWRK.
      *-------------------

           PERFORM  9500-BUILD-TWRK-KEY
               THRU 9500-BUILD-TWRK-KEY-X.

           PERFORM  8090-2000-RETRIEVE-TWRK
               THRU 8090-2000-RETRIEVE-TWRK-X.

           IF L8090-RETRN-OK
              MOVE L8090-AREA-INFO-TEXT  TO  WS-TWRK-WORK-AREA
           END-IF.

       9700-RETRIEVE-TWRK-X.
           EXIT.
      /
      *---------------
       9800-WRITE-TWRK.
      *---------------

           PERFORM  9500-BUILD-TWRK-KEY
               THRU 9500-BUILD-TWRK-KEY-X.

           MOVE WS-TWRK-WORK-AREA    TO  L8090-AREA-INFO-TEXT.

           PERFORM  8090-1000-WRITE-TWRK
               THRU 8090-1000-WRITE-TWRK-X.

       9800-WRITE-TWRK-X.
           EXIT.
      /
      *---------------
       9900-DELETE-TWRK.
      *---------------

           PERFORM  9500-BUILD-TWRK-KEY
               THRU 9500-BUILD-TWRK-KEY-X.

           PERFORM  8090-3000-DELETE-TWRK
               THRU 8090-3000-DELETE-TWRK-X.

       9900-DELETE-TWRK-X.
           EXIT.
      /
021311*--------------------------
021311 9990-INIT-WORKING-STORAGE.
021311*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
021311
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0410-0000-INIT-PARM-INFO
025970         THRU 0410-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0500-0000-INIT-PARM-INFO
025970         THRU 0500-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6340-0000-INIT-PARM-INFO
025970         THRU 6340-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8640-0000-INIT-PARM-INFO
025970         THRU 8640-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-SCREEN-WORK-AREA.
025970     INITIALIZE READ-WORK-AREA.
025970     INITIALIZE HEADER-MISC-WORK-AREAS.
025970     INITIALIZE WS-TWRK-FIELDS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
021311     INITIALIZE LSEGF-PARM-INFO.

021311     SET MIR-RETRN-OK           TO TRUE.
025970     SET TRANSACTION-NAME-DEFAULT
025970                                TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT   TO TRUE.

025970     MOVE SPACES                TO WS-TWRK-WORK-AREA.
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.
021311     MOVE SPACE                 TO WPOL-KEY.

025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
021311
021311 9990-INIT-WORKING-STORAGE-X.
021311     EXIT.
021311/
      ****************************************************
      * COMMON COPYBOOKS
      ****************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
025970 COPY SCPS0410.
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
013578*COPY XCCPTSQP.
      /
      ****************************************************
      * PROCESSING COPYBOOKS
      ****************************************************

       COPY NCPPCVGS.
      /
       COPY NCPPCVGR.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014660*COPY XCPPMEXT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      ****************************************************
      * LINKAGE PROCESSING COPYBOOKS
      ****************************************************

016108 COPY CCPS0985.
018764*COPY CCCL0985.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY CCPL0985.
020463/
020463 COPY CCPS2735.
020463 COPY CCPL2735.
016108/
557701 COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.
557701/
018764*COPY CCCL0201.
025970 COPY CCPS0201.
018764 COPY CCPL0201.
      /
016503 COPY CCPS4780.
018764*COPY CCCL4780.
018764 COPY CCPL4780.
      /
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
014035*COPY SCPS0410.
018764*COPY SCCL0410.
018764 COPY SCPL0410.
      /
018764*COPY SCCL0500.
025970 COPY SCPS0500.
018764 COPY SCPL0500.
      /
       COPY SCPS6340.
018764*COPY SCCL6340.
018764 COPY SCPL6340.
557756/
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
016537*COPY XCPS8090.
      /
020469 COPY XCPS8640.
020469 COPY XCPL8640.
020469/
      ****************************************************
      * FILE I/O PROCESS MODULES
      ****************************************************

       COPY CCPUPOL.
014221 COPY CCPNPOL.
      /
       COPY CCPNCVG.
      /
       COPY CCPUCVG.
      /
      ****************************************************
      * ERROR HANDLING ROUTINES
      ****************************************************

557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM SSOM0130                     **
      *****************************************************************


