      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM2362.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM2362                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE UPDATE FUNCTION       **
      **            FOR MULTIPLE REQUIREMENTS.                       **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016056**  6.1       NEW FOR INGENIUM 6.1                             **
014221**  6.2       LOGICAL LOCKING                                  **
016387**  6.2       REMOVAL OF CLIENT CONSOLIDATION                  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENT                           **
016548**  6.2       CHANGE COMP TO BINARY                            **
017944**  6.2       PCR - POLICY ANALYSIS FOR 'SCH'                  **
018115**  6.2       MULTIPLE REQUIREMENTS UPDATES WITH RESOLVE ON    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019982**  6.3       PCR FOR IIAB PLATFORM                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
026895**  6.7       UPDATE STATUS EFFECTIVE DATE WHEN STATUS CHANGES **
029083**  6.7       REQUIREMENT FOLLOW-UP DATE RECALCULATION         **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
035393**  7.1       CITS TRANSMITTAL                                 **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM2362'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-UPDATE             VALUE '2362'.

           05  WS-SWITCHES.
               10  WS-VALIDATE-FAIL-SW           PIC X(01).
                   88  WS-VALIDATE-FAIL          VALUE 'Y'.
                   88  WS-VALIDATE-OKAY          VALUE 'N'.

               10  WS-EDITS-OK-SW                PIC X(01).
                   88  WS-ALL-EDITS-OK           VALUE 'Y'.
                   88  WS-EDITS-FAILED           VALUE 'N'.

               10  WS-CROSS-EDITS-OK-SW          PIC X(01).
                   88  WS-CROSS-EDITS-OK         VALUE 'Y'.
                   88  WS-CROSS-EDITS-FAILED     VALUE 'N'.

               10  WS-FUP-UPDATE                 PIC X(01).
                   88  WS-CALC-FOLLOW-UP         VALUE 'Y'.
                   88  WS-NO-CALC-FOLLOW-UP      VALUE 'N'.

               10  WS-FUP-NUMBER-EDIT-IND        PIC X(01).
                   88  WS-FUP-NUMBER-EDIT-OK     VALUE 'Y'.
                   88  WS-FUP-NUMBER-EDIT-FAILED VALUE 'N'.

               10  WS-TEST-DATE-UPDATE-IND       PIC X(01).
                   88  WS-CALC-VALIDITY-DATE     VALUE 'Y'.
                   88  WS-NO-CALC-VALIDITY-DATE  VALUE 'N'.

               10  WS-RTAB-READ-IND              PIC X(01).
                   88  WS-RTAB-AVAILABLE         VALUE 'Y'.
                   88  WS-RTAB-NOT-AVAILABLE     VALUE 'N'.

               10  WS-VALID-LAB-CODE-IND         PIC X(01).
                   88  WS-VALID-LAB-CODE-FOUND   VALUE 'Y'.
                   88  WS-VALID-LAB-CODE-NOTFND  VALUE 'N'.

               10  WS-NEW-STATUS-CODE-IND        PIC X(01).
                   88  WS-NEW-STATUS-OK          VALUE 'Y'.
                   88  WS-NEW-STATUS-NOT-OK      VALUE 'N'.

               10  WS-USER-ID-CHANGE-IND         PIC X(01).
                   88  WS-USER-ID-CHANGED        VALUE 'Y'.
                   88  WS-USER-ID-NOT-CHANGED    VALUE 'N'.

               10  WS-YES-NO-VALID-SW            PIC X(01).
                   88  WS-YES-NO-VALID           VALUE 'Y' 'N'.

               10  WS-OLD-STATUS-CODE            PIC X(03).
                   88  WS-OLD-OUTSTANDING        VALUE
                       'NTO' 'ORD' 'RCD'
017944*                'SAA' 'SCC' 'SIR'.
017944                 'SAA' 'SCC' 'SIR' 'SCH'.

               10  WS-EDIT-STATUS-CODE           PIC X(03).
                   88  WS-SYSTEM-STATUS-CODE     VALUE
                       'SCC' 'SCH'
                       'SIR' 'SAA'.
                   88  VALID-STATUS-CODE         VALUE
                       'CAN' 'NTO' 'ORD'
                       'RAC' 'RCD' 'RRJ'
                       'WVD' 'SCC' 'SIR'
                       'SAA' 'SCH'.
                   88  WS-RECEIVED-STATUS        VALUE
                       'RAC' 'RCD' 'RRJ'.
                   88  WS-WAIVED-CANCELLED       VALUE
                       'WVD' 'CAN'.

               10  WS-EDIT-FOLLOWUP-NO           PIC X(01).
                   88  VALID-FOLLOWUP-NO         VALUE
                       '1' '2' '3'.


025970*    05  WS-CLI-REQT-LIMIT                 PIC 999
025970*                                          VALUE 50.
025970*    05  WS-POL-REQT-LIMIT                 PIC 999
025970*                                          VALUE 20.
025970*    05  WS-REQT-LIMIT                     PIC 999
025970*                                          VALUE 50.
025970*    05  WS-POLICIES-MAX                   PIC 999
025970*                                          VALUE 10.
           05  WS-LOOP-MAX                       PIC 999.
           05  WS-IDX                            PIC 999.
           05  WS-PIC-Z                          PIC Z.
016548*    05  WS-SUB                            PIC S9(04) COMP.
016548     05  WS-SUB                            PIC S9(04) BINARY.
           05  WS-POL-OR-CLI-NUMBER.
               10  WS-POL-OR-CLI-CODE            PIC X(01).
                   88  WS-UW-REQUIREMENT         VALUE 'C'.
                   88  WS-ISSUE-REQUIREMENT      VALUE 'P'.
           05  WS-EXTERNAL-START-DATE            PIC X(10).
           05  WS-TEMP-DATE                      PIC X(10).
           05  WS-SAVE-REQT-STATUS               PIC X(03).
014221*    05  WS-SAVE-RREQT-REC-INFO            PIC X(148).
014221     05  WS-SAVE-RREQT-REC-INFO            PIC X(164).
014221     05  WS-EDIT-RREQT-REC-INFO            PIC X(164).
014221     05  WS-LOGICAL-LOCK-ERROR-SW          PIC X(01).
014221         88  WS-LOGICAL-LOCK-ERROR         VALUE 'Y'.
014221         88  WS-LOGICAL-LOCK-ERROR-NO      VALUE 'N'.
018115     05  WS-CLIENT-DECISION-SW             PIC X(01).
018115         88  WS-CLIENT-DECISION-NEEDED     VALUE 'Y'.
018115         88  WS-CLIENT-DECISION-NOT-NEEDED VALUE 'N'.
035393     05  WS-INDEX                          PIC S9(5) COMP-3.

025970/
025970 01  WS-CONSTANTS.
025970     05  WS-CLI-REQT-LIMIT                 PIC 999.
025970         88  WS-DEFAULT-CLI-REQT-LIMIT             VALUE 50.
025970     05  WS-POL-REQT-LIMIT                 PIC 999.
025970         88  WS-DEFAULT-POL-REQT-LIMIT             VALUE 20.
025970     05  WS-REQT-LIMIT                     PIC 999.
025970         88  WS-DEFAULT-REQT-LIMIT                 VALUE 50.
025970     05  WS-POLICIES-MAX                   PIC 999.
025970         88  WS-DEFAULT-POLICIES-MAX               VALUE 10.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
       COPY XCWWWKDT.
       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.

       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFRSCOM.
       COPY CCFWSCOM.

       COPY NCFRREQT.
       COPY NCFWREQT.

       COPY NCFRRTAB.
       COPY NCFWRTAB.

016503 COPY CCFRCVG.
016503 COPY CCFWCVG.

016503 COPY CCWWCVGS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
035393 COPY CCWLCITC.
035393 COPY CCWLCITU.
035393
028298 COPY CCWL2626.
       COPY CCWLPGA.
       COPY XCWLDTLK.

016503 COPY CCWL0289.
       COPY CCWL5400.
       COPY CCWL5600.

016440 COPY CCWL2222.

       COPY NCWL0095.
       COPY NCWL0760.
       COPY NCWL1030.
       COPY NCWL1090.
       COPY NCWL2437.
       COPY NCWL7180.

       COPY XCWL0220.
       COPY XCWL0280.
020874 COPY XCWL0290.
035393 COPY XCWL0319.
       COPY XCWL1640.
       COPY XCWL1670.
       COPY XCWL1680.
014221 COPY XCWL8090.

      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY NCWM2362.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     IF  MIR-CLI-ID = SPACE
028298         PERFORM  FPCK-1000-CHECK-POLICY
028298             THRU FPCK-1000-CHECK-POLICY-X
028298     ELSE
028298         PERFORM  FCCK-1000-CHECK-CLIENT
028298             THRU FCCK-1000-CHECK-CLIENT-X
028298     END-IF.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

014221     MOVE ZEROS                 TO WLOCK-IDX.
014221     INITIALIZE                 WLOCK-MULT-TWRK-TS-TABLE.

019982     INITIALIZE                 L2222-PARM-INFO.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM2362'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-UPDATE.
      *------------

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  2100-VALIDATE-CONTROL-FIELDS
               THRU 2100-VALIDATE-CONTROL-FIELDS-X.

           IF  WS-VALIDATE-FAIL
               GO TO 2000-UPDATE-X
           END-IF.

           MOVE WGLOB-SYSTEM-DATE-INT  TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*         THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE    TO WS-EXTERNAL-START-DATE.

           IF  WS-UW-REQUIREMENT
               MOVE WS-CLI-REQT-LIMIT  TO WS-LOOP-MAX
           ELSE
               MOVE WS-POL-REQT-LIMIT  TO WS-LOOP-MAX
           END-IF.

014221     SET WS-LOGICAL-LOCK-ERROR-NO          TO TRUE.

014221     PERFORM  REQT-3000-SET-MBTS-TWRK-TS
014221         THRU REQT-3000-SET-MBTS-TWRK-TS-X.

018115     SET WS-CLIENT-DECISION-NOT-NEEDED
018115                                 TO TRUE.
           PERFORM  3000-UPDATE-REQUIREMENT
               THRU 3000-UPDATE-REQUIREMENT-X
               VARYING WS-IDX FROM 1 BY 1
               UNTIL   WS-IDX > WS-REQT-LIMIT.

014221     PERFORM  REQT-2000-BUILD-MBTS-TWRK
014221         THRU REQT-2000-BUILD-MBTS-TWRK-X.

018115     IF  WS-CLIENT-DECISION-NEEDED
018115         PERFORM  1030-1000-BUILD-PARM-INFO
018115             THRU 1030-1000-BUILD-PARM-INFO-X
018115         MOVE RREQT-CLI-ID  TO L1030-CLIENT-ID
018115         PERFORM  1030-1000-CLIENT-DECISION
018115             THRU 1030-1000-CLIENT-DECISION-X
018115     END-IF.
014221     IF  WS-LOGICAL-LOCK-ERROR
014221         SET WGLOB-RETURN-ERROR           TO TRUE
014221         GO TO 2000-UPDATE-X
014221     END-IF.

      ***  UPDATE ACTIVITY DATE IF CLIENT.

           IF  WS-UW-REQUIREMENT
               PERFORM  7250-UPD-CLIENT-ACTIVITY-DT
                   THRU 7250-UPD-CLIENT-ACTIVITY-DT-X
           END-IF.

           PERFORM  7800-REFRESH-POLICY-STATUS
               THRU 7800-REFRESH-POLICY-STATUS-X
               VARYING WS-IDX FROM 1 BY 1
               UNTIL (WS-IDX > WS-POLICIES-MAX)
               OR    (MIR-POL-ID-BASE-T (WS-IDX) = SPACE
               AND    MIR-POL-ID-SFX-T  (WS-IDX) = SPACE).

           IF  WS-ISSUE-REQUIREMENT
               MOVE MIR-POL-ID-BASE    TO WPOL-POL-ID-BASE
               MOVE MIR-POL-ID-SFX     TO WPOL-POL-ID-SFX

016503*        PERFORM  POL-1000-READ
016503*            THRU POL-1000-READ-X

016503         PERFORM  POL-1000-READ-FOR-UPDATE
016503             THRU POL-1000-READ-FOR-UPDATE-X

               IF  WPOL-IO-OK
                   MOVE RPOL-POL-CSTAT-CD
                                       TO MIR-POL-CSTAT-CD
016503             PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503                 THRU CVGS-1000-LOAD-CVGS-ARRAY-X
016503             PERFORM  0289-1000-INIT-PARM-INFO
016503                 THRU 0289-1000-INIT-PARM-INFO-X
016503             PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503                 THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503             IF  L0289-RETRN-OK
016503                 MOVE L0289-NXT-ACTV-TYP-CD
016503                              TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE L0289-NXT-ACTV-DT  TO RPOL-POL-NXT-ACTV-DT
016503             ELSE
016503                 MOVE 'RSH'              TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE WGLOB-PROCESS-DATE TO RPOL-POL-NXT-ACTV-DT
016503             END-IF
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
               END-IF
           END-IF.

       2000-UPDATE-X.
           EXIT.

      *-----------------------------
       2100-VALIDATE-CONTROL-FIELDS.
      *-----------------------------

      ***  ONE OF CLIENT OR POLICY MUST BE GIVEN.

           SET WS-VALIDATE-OKAY       TO TRUE.

           IF  (MIR-CLI-ID = SPACES)
           AND (MIR-POL-ID-BASE = SPACES)
           AND (MIR-POL-ID-SFX = SPACES)
      * MSG: EITHER CLIENT OR POLICY MUST BE ENTERED
               MOVE 'NS23620001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-FAIL   TO TRUE
               GO TO 2100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

      ***  BOTH CLIENT AND POLICY CANNOT BE GIVEN.

           IF  (MIR-CLI-ID      NOT =  SPACES)
           AND (MIR-POL-ID-BASE NOT =  SPACES)
           AND (MIR-POL-ID-SFX  NOT =  SPACES)
      * MSG: ENTER EITHER CLIENT OR POLICY, BUT NOT BOTH
               MOVE 'NS23620002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-FAIL   TO TRUE
               GO TO 2100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

      ***  CHECK CLIENT / POLICY.

           IF  MIR-CLI-ID NOT =  SPACES
               PERFORM  2200-CHECK-CLIENT
                   THRU 2200-CHECK-CLIENT-X
           ELSE
               PERFORM  2210-CHECK-POLICY
                   THRU 2210-CHECK-POLICY-X
           END-IF.

       2100-VALIDATE-CONTROL-FIELDS-X.
           EXIT.

      *------------------
       2200-CHECK-CLIENT.
      *------------------

      ***  CHECK CONFIDENTIALITY.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

016387*    SET L5600-CNSLDT-MSG-NOT-REQD
016387*                               TO TRUE.
016387*    SET L5600-GEN-CNSLDT-MSG-ERROR
016387*                               TO TRUE.

           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           IF  L5600-CNFD-ACCS-RESTRICTED
           OR  L5600-CCAS-ACCS-RESTRICTED
               SET WS-VALIDATE-FAIL   TO TRUE
           ELSE
               SET WS-UW-REQUIREMENT  TO TRUE
           END-IF.

       2200-CHECK-CLIENT-X.
           EXIT.

      *------------------
       2210-CHECK-POLICY.
      *------------------

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
               MOVE MIR-POL-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-FAIL   TO TRUE
               GO TO 2210-CHECK-POLICY-X
           END-IF.

016440* IF POLICY IS IN FORCE, CALL SUBROUTINE TO DETERMINE
016440* IF ANY PENDING COVERAGES EXIST

016440     IF RPOL-POL-STAT-IN-FORCE
016440        PERFORM 2222-1000-BUILD-PARM-INFO
016440           THRU 2222-1000-BUILD-PARM-INFO-X
016440        MOVE RPOL-POL-ID       TO L2222-POL-ID
016440        PERFORM 2222-1000-FIND-PEND-CVG
016440           THRU 2222-1000-FIND-PEND-CVG-X
016440     END-IF.

016440*    IF NOT RPOL-POL-APPL-CTL-NBS
016440     IF  L2222-INFORCE-POL-INFORCE-CVG
               MOVE 'XS00000239'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET  WS-VALIDATE-FAIL
                                      TO TRUE
                   GO TO 2210-CHECK-POLICY-X
               END-IF
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

016440     SET L5400-POL-XFER-UPDATE  TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               SET WS-VALIDATE-FAIL   TO TRUE
               GO TO 2210-CHECK-POLICY-X
           END-IF.

           IF  L5400-BRCH-ACCS-RESTRICTED
               SET WS-VALIDATE-FAIL   TO TRUE
               GO TO 2210-CHECK-POLICY-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW     >  ZERO
               SET WS-VALIDATE-FAIL   TO TRUE
           ELSE
               SET WS-ISSUE-REQUIREMENT
                                      TO TRUE
           END-IF.

       2210-CHECK-POLICY-X.
           EXIT.
      /
      *------------------------
       3000-UPDATE-REQUIREMENT.
      *------------------------

           IF  MIR-REQIR-ID-T (WS-IDX) = SPACE
           OR  MIR-CPREQ-SEQ-NUM-T (WS-IDX) NOT NUMERIC
               GO TO 3000-UPDATE-REQUIREMENT-X
           END-IF.

           PERFORM  3100-INITIALIZE-SWITCHES
               THRU 3100-INITIALIZE-SWITCHES-X.

           SET WS-RTAB-NOT-AVAILABLE  TO TRUE.

      ***  ATTEMPT TO FIND REQT RECORD.

           MOVE WS-POL-OR-CLI-CODE    TO WREQT-CPREQ-POL-CLI-CD.

           IF WS-UW-REQUIREMENT
               MOVE MIR-CLI-ID        TO WREQT-CLI-ID
           ELSE
               MOVE MIR-POL-ID        TO WREQT-POL-ID
           END-IF.

           MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WREQT-REQIR-ID.
           MOVE MIR-CPREQ-SEQ-NUM-T (WS-IDX)
                                      TO WREQT-CPREQ-SEQ-NUM.

014221     PERFORM  REQT-1000-READ
014221         THRU REQT-1000-READ-X.

014221*    PERFORM  REQT-1000-READ-FOR-UPDATE
014221*        THRU REQT-1000-READ-FOR-UPDATE-X.

           IF  NOT WREQT-IO-OK
               MOVE 'NS23620018'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-UPDATE-REQUIREMENT-X
           END-IF.

      ***  PERFORM EDITS.

           MOVE RREQT-REC-INFO        TO WS-SAVE-RREQT-REC-INFO.
           PERFORM  5000-EDIT-DATA-FIELDS
               THRU 5000-EDIT-DATA-FIELDS-X.

           IF  WS-SAVE-RREQT-REC-INFO NOT = RREQT-REC-INFO
014221         MOVE WREQT-KEY         TO WLOCK-PRCES-TWRK-TS-KEY
014221         IF  WREQT-CPREQ-POL-CLI-CD = 'P'
014221            IF  WREQT-POLICY-COMPANY-REQ
014221                MOVE WGLOB-COMPANY-CODE
014221                            TO WLOCK-PRCES-TWRK-TS-CO-ID
014221            ELSE
014221                MOVE SPACES TO WLOCK-PRCES-TWRK-TS-CO-ID
014221            END-IF
014221         END-IF
014221         IF  WREQT-CPREQ-POL-CLI-CD = 'C'
014221            IF  WREQT-CLIENT-COMPANY-REQ
014221                MOVE WGLOB-COMPANY-CODE
014221                            TO WLOCK-PRCES-TWRK-TS-CO-ID
014221            ELSE
014221                MOVE SPACES TO WLOCK-PRCES-TWRK-TS-CO-ID
014221            END-IF
014221         END-IF
014221         MOVE RREQT-REC-INFO  TO
014221                     WS-EDIT-RREQT-REC-INFO
014221         PERFORM  REQT-4000-UPDATE-MBTS-TW-TS
014221             THRU REQT-4000-UPDATE-MBTS-TW-TS-X
014221         IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221             MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221             MOVE 'REQT'            TO WGLOB-MSG-PARM (01)
014221             MOVE WREQT-KEY         TO WGLOB-MSG-PARM (02)
014221             PERFORM  0260-1000-GENERATE-MESSAGE
014221                 THRU 0260-1000-GENERATE-MESSAGE-X
014221             SET WS-LOGICAL-LOCK-ERROR       TO TRUE
014221             GO TO 3000-UPDATE-REQUIREMENT-X
014221         END-IF
014221         IF  NOT WREQT-IO-OK
014221             MOVE 'NS23620018'      TO WGLOB-MSG-REF-INFO
014221             MOVE MIR-REQIR-ID-T (WS-IDX)
014221                                    TO WGLOB-MSG-PARM (1)
014221             MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
014221             PERFORM  0260-1000-GENERATE-MESSAGE
014221                 THRU 0260-1000-GENERATE-MESSAGE-X
014221             GO TO 3000-UPDATE-REQUIREMENT-X
014221         END-IF

014221         MOVE  WS-EDIT-RREQT-REC-INFO TO RREQT-REC-INFO

               PERFORM  5600-CROSS-EDITS
                   THRU 5600-CROSS-EDITS-X

               IF  NOT WS-USER-ID-CHANGED
                   MOVE WGLOB-USER-ID TO RREQT-USER-ID
                   MOVE WGLOB-USER-ID TO MIR-USER-ID-T
                                         (WS-IDX)
               END-IF
               PERFORM  REQT-2000-REWRITE
                   THRU REQT-2000-REWRITE-X
035393
035393         IF  WS-OLD-STATUS-CODE NOT =  RREQT-CPREQ-STAT-CD
035393             PERFORM  7950-REQS-EVENT
035393                 THRU 7950-REQS-EVENT-X
035393         ELSE
035393             PERFORM  7900-REQU-EVENT
035393                 THRU 7900-REQU-EVENT-X
035393         END-IF

014221         PERFORM  REQT-1000-READ
014221             THRU REQT-1000-READ-X

014221         MOVE RREQT-PREV-UPDT-TS  TO WLOCK-MULT-TWRK-TS (WS-IDX)

      ***  CHECK IF MAINTAIN REQUIRES ANALYZE.

               PERFORM  5240-CHECK-ANALYZE
                   THRU 5240-CHECK-ANALYZE-X
014221*    ELSE
014221*        PERFORM  REQT-3000-UNLOCK
014221*            THRU REQT-3000-UNLOCK-X
           END-IF.

      ***  CALL THE REQUIREMENT RESOLUTION MODULE IF IT WAS REQUESTED
      ***  AND THERE WERE NO EDIT OR CROSS EDIT ERRORS.

           IF  WS-ALL-EDITS-OK
           AND WS-CROSS-EDITS-OK
           AND MIR-DV-REVW-REQIR-IND-T (WS-IDX) = 'Y'
               MOVE 'N'               TO MIR-DV-REVW-REQIR-IND-T
                                         (WS-IDX)
               PERFORM  7180-1000-BUILD-PARM-INFO
                   THRU 7180-1000-BUILD-PARM-INFO-X
               MOVE RREQT-CLI-ID      TO L7180-CLI-ID
               MOVE RREQT-CPREQ-DESGNT-ID
                                      TO L7180-LAB-CD
               MOVE RREQT-REQIR-ID    TO L7180-REQIR-CD
               MOVE RREQT-CPREQ-SEQ-NUM
                                      TO L7180-SEQ-NUM
               PERFORM  7180-1000-RESOLVE-REQT
                   THRU 7180-1000-RESOLVE-REQT-X

               IF  L7180-REQIR-STAT-UPDT
                   MOVE L7180-NEW-REQIR-STAT-CD
                                      TO MIR-CPREQ-STAT-CD-T
                                         (WS-IDX)
               END-IF

               IF  L7180-CLI-DECISION-RQST
018115             SET WS-CLIENT-DECISION-NEEDED
018115                                TO TRUE
018115*            PERFORM  1030-1000-BUILD-PARM-INFO
018115*                THRU 1030-1000-BUILD-PARM-INFO-X
018115*            MOVE RREQT-CLI-ID  TO L1030-CLIENT-ID
018115*            PERFORM  1030-1000-CLIENT-DECISION
018115*                THRU 1030-1000-CLIENT-DECISION-X
               END-IF

           END-IF.

           MOVE RREQT-CPREQ-CREAT-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-CREAT-DT-T
                                         (WS-IDX).

       3000-UPDATE-REQUIREMENT-X.
           EXIT.

      *-------------------------
       3100-INITIALIZE-SWITCHES.
      *-------------------------

           SET WS-RTAB-NOT-AVAILABLE  TO TRUE.
           SET WS-ALL-EDITS-OK        TO TRUE.
           SET WS-CROSS-EDITS-OK      TO TRUE.
           SET WS-NEW-STATUS-NOT-OK   TO TRUE.
           SET WS-NO-CALC-FOLLOW-UP   TO TRUE.
           SET WS-VALID-LAB-CODE-NOTFND
                                      TO TRUE.
           SET WS-NO-CALC-VALIDITY-DATE
                                      TO TRUE.
           SET WS-FUP-NUMBER-EDIT-OK  TO TRUE.
           SET WS-USER-ID-NOT-CHANGED TO TRUE.

       3100-INITIALIZE-SWITCHES-X.
           EXIT.
      /
      *----------------------
       5000-EDIT-DATA-FIELDS.
      *----------------------

      ***  FETCH REQUIREMENT TABLE ENTRY.

           PERFORM  5310-FETCH-RTAB
               THRU 5310-FETCH-RTAB-X.


      ***  BASIC FIELD EDITS.

           PERFORM  5320-EDIT-REQT-STATUS
               THRU 5320-EDIT-REQT-STATUS-X.
           PERFORM  5340-EDIT-REQT-STATUS-DATE
               THRU 5340-EDIT-REQT-STATUS-DATE-X.

           PERFORM  5360-EDIT-USER-ID
               THRU 5360-EDIT-USER-ID-X.
           PERFORM  5370-EDIT-DESIGNATION
               THRU 5370-EDIT-DESIGNATION-X.

           PERFORM  5380-EDIT-TEST-DATE
               THRU 5380-EDIT-TEST-DATE-X.
           PERFORM  5400-EDIT-TEST-RESULT
               THRU 5400-EDIT-TEST-RESULT-X.

           PERFORM  5405-EDIT-RESULTS-IND
               THRU 5405-EDIT-RESULTS-IND-X.
           PERFORM  5410-EDIT-RESOLVE-IND
               THRU 5410-EDIT-RESOLVE-IND-X.


      ***  FOLLOW-UP DETAILS.

029083*    IF  (MIR-CPREQ-FOLWUP-NUM-T (WS-IDX) = SPACES)
029083*    AND (MIR-CPREQ-FOLWUP-DT-T  (WS-IDX) = SPACES)
029083*    AND (WS-CALC-FOLLOW-UP)
029083     IF  (MIR-CPREQ-FOLWUP-NUM-T (WS-IDX) = SPACES
029083       OR  MIR-CPREQ-FOLWUP-NUM-T (WS-IDX) = ZERO)
029083     AND (MIR-CPREQ-FOLWUP-DT-T  (WS-IDX) = SPACES
029083       OR  MIR-CPREQ-FOLWUP-DT-T  (WS-IDX) = ZERO)
029083     AND (WS-CALC-FOLLOW-UP)
               PERFORM  5420-CALCULATE-FOLLOW-UP
                   THRU 5420-CALCULATE-FOLLOW-UP-X
           ELSE

               MOVE MIR-CPREQ-FOLWUP-DT-T (WS-IDX)
                                   TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X

               IF  (MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                       NOT = RREQT-CPREQ-FOLWUP-NUM)
               OR  (L1640-INTERNAL-DATE
                       NOT = RREQT-CPREQ-FOLWUP-DT)
                   PERFORM  5440-EDIT-FUP-NUMBER
                       THRU 5440-EDIT-FUP-NUMBER-X
                   PERFORM  5460-EDIT-FUP-DATE
                       THRU 5460-EDIT-FUP-DATE-X
               END-IF
           END-IF.


      ***  VALIDITY DATE.

           IF  (MIR-CPREQ-VALID-DT-T (WS-IDX) = SPACES)
           AND (WS-CALC-VALIDITY-DATE)
               PERFORM  5480-CALCULATE-VALIDITY-DATE
                   THRU 5480-CALCULATE-VALIDITY-DATE-X
           ELSE
               PERFORM  5500-EDIT-VALIDITY-DATE
                   THRU 5500-EDIT-VALIDITY-DATE-X
           END-IF.

           IF  WS-SAVE-RREQT-REC-INFO = RREQT-REC-INFO
               GO TO 5000-EDIT-DATA-FIELDS-X
           END-IF.

      ***  DESIGNATION FIELD - LAB CODE WILL BE DEFAULTED FOR LAB
      ***  REQUIREMENTS IF NOTHING WAS ENTERED

           IF  (MIR-CPREQ-DESGNT-ID-T (WS-IDX) = SPACES)
           AND (RREQT-CPREQ-DESGNT-ID =  SPACES)
           AND (RRTAB-LAB-ID     NOT  =  SPACES)
               MOVE RRTAB-LAB-ID      TO RREQT-CPREQ-DESGNT-ID
               MOVE RRTAB-LAB-ID      TO MIR-CPREQ-DESGNT-ID-T
                                         (WS-IDX)
           END-IF.

      ***  PAID INDICATOR.

           IF  MIR-CPREQ-PD-IND-T (WS-IDX) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-PD-IND-T
                                         (WS-IDX)
               MOVE SPACES            TO RREQT-CPREQ-PD-IND
               GO TO 5000-EDIT-DATA-FIELDS-X
           END-IF.

           IF  MIR-CPREQ-PD-IND-T (WS-IDX) = SPACES
               MOVE RREQT-CPREQ-PD-IND
                                      TO MIR-CPREQ-PD-IND-T
                                         (WS-IDX)
           ELSE
               MOVE MIR-CPREQ-PD-IND-T (WS-IDX)
                                      TO RREQT-CPREQ-PD-IND
           END-IF.

       5000-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      ****************************************************************
      *   CHECK ANALYZE:
      *   CHECK IF THIS MAINTAIN REQUIRES THAT THE INSURED / POLICY
      *   BE RE-ANALYZED TO POSSIBLY CORRECT THE STATUS CODES
      *   ON COVERAGES AND / OR POLICIES.
      ****************************************************************
       5240-CHECK-ANALYZE.


      ***  STATUS MUST BE VALID AND CHANGED.

           IF  WS-NEW-STATUS-OK AND
              (WS-OLD-STATUS-CODE NOT = RREQT-CPREQ-STAT-CD)
               CONTINUE
           ELSE
               GO TO 5240-CHECK-ANALYZE-X
           END-IF.


      ***  NO ANALYZE IF WAS AND STILL IS OUTSTANDING.

           IF  WS-OLD-OUTSTANDING
           AND RREQT-CPREQ-STAT-OUTSTANDING
               GO TO 5240-CHECK-ANALYZE-X
           END-IF.

      ***  NO ANALYZE IF WASN'T AND STILL ISN'T OUTSTANDING.

           IF (NOT WS-OLD-OUTSTANDING) AND
              (NOT RREQT-CPREQ-STAT-OUTSTANDING)
               GO TO 5240-CHECK-ANALYZE-X
           END-IF.

      ***  RE-ANALYZE.

           PERFORM  7700-FORCE-ANALYZE
               THRU 7700-FORCE-ANALYZE-X.

      *   CHECK IF CWA REQT STATUS CHANGED BY ANALYZE
           IF  MIR-REQIR-ID-T (WS-IDX) = 'CWA'
               MOVE RREQT-CPREQ-STAT-CD
                                      TO WS-SAVE-REQT-STATUS
               PERFORM  REQT-1000-READ
                   THRU REQT-1000-READ-X

               IF  RREQT-CPREQ-STAT-CD  NOT =  WS-SAVE-REQT-STATUS

      * MSG (S) SYSTEM DETERMINED STATUS OF (@1) CANNOT BE CHANGED TO @2

                   MOVE 'NS23620003'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WS-IDX        TO WGLOB-MSG-PARM (2)

                   MOVE RREQT-CPREQ-STAT-CD
                                      TO WGLOB-MSG-PARM (3)
                   MOVE WS-SAVE-REQT-STATUS
                                      TO WGLOB-MSG-PARM (4)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-EDITS-FAILED
                                      TO TRUE
               END-IF

           END-IF.

       5240-CHECK-ANALYZE-X.
           EXIT.

      ****************************************************************
      *   FETCH REQUIREMENT TABLE RECORD.
      *   THE RTAB RECORD IS FETCH AND AN INDICATOR SET TO INDICATE
      *   STATUS.
      ****************************************************************
       5310-FETCH-RTAB.


      ***  FETCH RTAB RECORD.

           MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WRTAB-REQIR-ID.

           PERFORM  RTAB-1000-READ
               THRU RTAB-1000-READ-X.

           SET WS-RTAB-AVAILABLE      TO TRUE.

           IF  WRTAB-IO-NOT-FOUND
      * MSG : REQUIREMENT TABLE ENTRY NOT FOUND FOR REQT
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (3)
               MOVE 'NS23620004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-RTAB-NOT-AVAILABLE
                                      TO TRUE
           END-IF.

       5310-FETCH-RTAB-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT REQUIREMENT STATUS.
      ****************************************************************
       5320-EDIT-REQT-STATUS.


      ***  SAVE OLD STATUS & INIT FLAGS.

           MOVE RREQT-CPREQ-STAT-CD   TO WS-OLD-STATUS-CODE.
           SET WS-NEW-STATUS-NOT-OK   TO TRUE.
           SET WS-NO-CALC-FOLLOW-UP   TO TRUE.

      ***  RESTORE FILE VALUE.

           IF  MIR-CPREQ-STAT-CD-T (WS-IDX) =  SPACES
               MOVE RREQT-CPREQ-STAT-CD
                                      TO MIR-CPREQ-STAT-CD-T
                                         (WS-IDX)
               GO TO 5320-EDIT-REQT-STATUS-X
           END-IF.

           IF  MIR-CPREQ-STAT-CD-T (WS-IDX) = RREQT-CPREQ-STAT-CD
               GO TO 5320-EDIT-REQT-STATUS-X
           END-IF.


      ***  HANDLE DELETION.

           IF  MIR-CPREQ-STAT-CD-T (WS-IDX) =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-STAT-CD-T
                                         (WS-IDX)
           END-IF.

           MOVE MIR-CPREQ-STAT-CD-T (WS-IDX)
                                      TO WS-EDIT-STATUS-CODE.


      ***  SYSTEM SUGGESTED STATUS CODES CANNOT BE ENTERED BY USER

           IF  WS-SYSTEM-STATUS-CODE
               MOVE 'NS23620005'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WS-EDITS-FAILED
                                      TO TRUE
                   GO TO 5320-EDIT-REQT-STATUS-X
               END-IF

           END-IF.

      ***  EDIT STATUS CODE.

           IF  NOT VALID-STATUS-CODE
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

      * MSG : INVALID REQUIREMENT STATUS
               MOVE 'NS23620006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5320-EDIT-REQT-STATUS-X
           END-IF.

      ***  DIARY LOG.

           IF (WS-OLD-STATUS-CODE NOT = MIR-CPREQ-STAT-CD-T (WS-IDX))
               MOVE MIR-CPREQ-STAT-CD-T (WS-IDX)
                                      TO L0760-DAL-ACTION
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD & SET SWITCH.

           SET WS-NEW-STATUS-OK       TO TRUE.
           MOVE MIR-CPREQ-STAT-CD-T (WS-IDX)
                                      TO RREQT-CPREQ-STAT-CD.
           IF WS-OLD-STATUS-CODE NOT =  RREQT-CPREQ-STAT-CD
               SET WS-CALC-FOLLOW-UP  TO TRUE
           END-IF.

       5320-EDIT-REQT-STATUS-X.
           EXIT.
      /
      ****************************************************************
      *   SET / EDIT REQUIREMENT STATUS DATE.
      *   DEFAULTS TO TODAY IF NOT GIVEN.  A FATALITY CHECK IS
      *   MADE IF THE STATUS DATE IS IN THE FUTURE.
      ****************************************************************
       5340-EDIT-REQT-STATUS-DATE.


      ***  NO CHANGE IF NEITHER STATUS CODE OR DATE UPDATED.

           IF  (MIR-CPREQ-EFF-DT-T (WS-IDX) = SPACES)
           AND (WS-OLD-STATUS-CODE = MIR-CPREQ-STAT-CD-T (WS-IDX))

               MOVE RREQT-CPREQ-EFF-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X

               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-EFF-DT-T
                                         (WS-IDX)
                   GO TO 5340-EDIT-REQT-STATUS-DATE-X
               END-IF

           END-IF.

           MOVE MIR-CPREQ-EFF-DT-T (WS-IDX)
                                      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-INTERNAL-DATE = RREQT-CPREQ-EFF-DT
026895     AND WS-OLD-STATUS-CODE  = MIR-CPREQ-STAT-CD-T (WS-IDX)
               GO TO 5340-EDIT-REQT-STATUS-DATE-X
           END-IF.

026895     IF  WS-OLD-STATUS-CODE NOT = MIR-CPREQ-STAT-CD-T (WS-IDX)
026895     AND L1640-INTERNAL-DATE    = RREQT-CPREQ-EFF-DT
026895         MOVE WGLOB-SYSTEM-DATE-INT TO L1640-INTERNAL-DATE
026895         PERFORM 1640-8000-INTERNAL-TO-MIR
026895             THRU 1640-8000-INTERNAL-TO-MIR-X
026895         MOVE L1640-EXTERNAL-DATE TO MIR-CPREQ-EFF-DT-T (WS-IDX)
026895     END-IF.
026895


      ***  USE TODAY IF STATUS DATE NOT CHANGED, OR DELETED.

           IF  (MIR-CPREQ-EFF-DT-T (WS-IDX) = SPACES)
           OR  (MIR-CPREQ-EFF-DT-T (WS-IDX) = EBLCH-BLANK-FIELD-CHAR)
               MOVE WGLOB-SYSTEM-DATE-INT
                                      TO RREQT-CPREQ-EFF-DT
               MOVE WS-EXTERNAL-START-DATE
                                      TO MIR-CPREQ-EFF-DT-T
                                         (WS-IDX)
               GO TO 5340-EDIT-REQT-STATUS-DATE-X
           END-IF.

      ***  CHECK DATE VALID.

           MOVE MIR-CPREQ-EFF-DT-T (WS-IDX)
                                      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID

      * MSG : INVALID STATUS DATE, FORMAT MUST BE VALID OR BLANK
               MOVE 'NS23620044'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE

               GO TO 5340-EDIT-REQT-STATUS-DATE-X
           END-IF.


      ***  CHECK NOT IN FUTURE.

           IF  L1640-INTERNAL-DATE    >  WGLOB-SYSTEM-DATE-INT
      * MSG : STATUS DATE MUST NOT BE IN THE FUTURE
               MOVE 'NS23620045'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WS-EDITS-FAILED
                                      TO TRUE
                   GO TO 5340-EDIT-REQT-STATUS-DATE-X
               END-IF

           END-IF.


      ***  DIARY LOG.

           MOVE L1640-INTERNAL-DATE   TO WS-TEMP-DATE.
           IF (L1640-INTERNAL-DATE  NOT  =  RREQT-CPREQ-EFF-DT)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE L1640-INTERNAL-DATE
                                      TO L0760-MESSAGE-PARMS (2)
               MOVE RREQT-CPREQ-EFF-DT
                                      TO L0760-MESSAGE-PARMS (1)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.

           MOVE WS-TEMP-DATE          TO RREQT-CPREQ-EFF-DT.

       5340-EDIT-REQT-STATUS-DATE-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT USER ID:
      *   MUST BE (A) LOGON USER, (B) 'AGENT' OR (C) VALID USER ID.
      *   BOTH (B) AND (C) GENERATE A WARN/FATAL MESSAGE.
      ****************************************************************
       5360-EDIT-USER-ID.


           SET WS-USER-ID-NOT-CHANGED TO TRUE.

           IF  MIR-USER-ID-T (WS-IDX) = RREQT-USER-ID
               GO TO 5360-EDIT-USER-ID-X
           END-IF.

      ***  DEFAULTS TO LOGON USER.

           IF  (MIR-USER-ID-T (WS-IDX) = SPACES)
           OR  (MIR-USER-ID-T (WS-IDX) = EBLCH-BLANK-FIELD-CHAR)
               MOVE WGLOB-USER-ID     TO MIR-USER-ID-T
                                         (WS-IDX)
               MOVE WGLOB-USER-ID     TO RREQT-USER-ID
               GO TO 5360-EDIT-USER-ID-X
           END-IF.


      ***  OWN USER ID IS OK.

           IF  MIR-USER-ID-T (WS-IDX) =  WGLOB-USER-ID
               GO TO 5360-EDIT-USER-ID-X
           END-IF.


      ***  CHECK VALIDITY.

           IF  MIR-USER-ID-T (WS-IDX) =  'AGENT'
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

      * MSG: USER ID (@3) CHANGED TO AGENT USER ID
               MOVE WGLOB-USER-ID     TO WGLOB-MSG-PARM (3)
               MOVE 'NS23620007'      TO WGLOB-MSG-REF-INFO

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE MIR-USER-ID-T (WS-IDX)
                                      TO L0220-USER-ID
               MOVE WGLOB-COMPANY-CODE
                                      TO L0220-COMPANY-CODE
               PERFORM  0220-1000-VERIFY-USER-ID
                   THRU 0220-1000-VERIFY-USER-ID-X
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

               MOVE MIR-USER-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (3)

               IF  L0220-USER-OK
                   MOVE WGLOB-USER-ID TO WGLOB-MSG-PARM (4)
      * MSG:  USER ID ENTERED IS (@3). MUST BE (@4) OR (AGENT)
                   MOVE 'NS23620008'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      * MSG : USER ID (@3) NOT VALID
                   MOVE 'NS23620009'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

           END-IF.


      ***  HANDLE FATAL TYPE ERROR.

           IF  WGLOB-MSG-SEVRTY-FATAL
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5360-EDIT-USER-ID-X
           END-IF.


      ***  UPDATE RECORD & DIARY LOG.

           MOVE MIR-USER-ID-T (WS-IDX)
                                      TO RREQT-USER-ID.
           MOVE 'UPDT'                TO L0760-DAL-ACTION.
           MOVE 'NS2362'              TO L0760-MSG-SRCE.
           MOVE '0010'                TO L0760-MSG-NUMBER.

      * MSG :  USER ID (@1) CHANGED TO (@2)
           MOVE WGLOB-USER-ID         TO L0760-MESSAGE-PARMS (1).
           MOVE MIR-USER-ID-T (WS-IDX)
                                      TO L0760-MESSAGE-PARMS (2).
           PERFORM  7000-WRITE-DALG
               THRU 7000-WRITE-DALG-X.

           SET WS-USER-ID-CHANGED     TO TRUE.

       5360-EDIT-USER-ID-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT DESIGNATION.
      ****************************************************************
       5370-EDIT-DESIGNATION.


      ***  RESTORE FILE VALUE.

           IF  MIR-CPREQ-DESGNT-ID-T (WS-IDX) =  SPACES
               MOVE RREQT-CPREQ-DESGNT-ID
                                      TO MIR-CPREQ-DESGNT-ID-T
                                         (WS-IDX)
               GO TO 5370-EDIT-DESIGNATION-X
           END-IF.


      ***  HANDLE DELETION.

           IF  MIR-CPREQ-DESGNT-ID-T (WS-IDX) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-DESGNT-ID-T
                                         (WS-IDX)
               MOVE SPACES            TO RREQT-CPREQ-DESGNT-ID
               GO TO 5370-EDIT-DESIGNATION-X
           END-IF.

           MOVE MIR-CPREQ-DESGNT-ID-T (WS-IDX)
                                      TO WEDIT-ETBL-VALU-ID.
           PERFORM  LABC-1000-EDIT-LAB-CODE
               THRU LABC-1000-EDIT-LAB-CODE-X.

           IF  WEDIT-IO-OK
               SET WS-VALID-LAB-CODE-FOUND
                                      TO TRUE
           ELSE
               SET WS-VALID-LAB-CODE-NOTFND
                                      TO TRUE
           END-IF.

           IF  MIR-CPREQ-DESGNT-ID-T (WS-IDX) = RREQT-CPREQ-DESGNT-ID
               GO TO 5370-EDIT-DESIGNATION-X
           END-IF.

      *  ONLY PERFORM EDIT WHEN A LAB CODE FOUND ON RTAB RECORD

           IF  RRTAB-LAB-ID  NOT  =  SPACES

              IF  NOT WEDIT-IO-OK
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   MOVE 'NS23620011'  TO WGLOB-MSG-REF-INFO
      * MSG: LAB CODE NOT FOUND ON EDIT TABLE LABCD
                   MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WS-IDX        TO WGLOB-MSG-PARM (2)

                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5370-EDIT-DESIGNATION-X
               END-IF

           END-IF.


      ***  DIARY LOG.

           IF (MIR-CPREQ-DESGNT-ID-T (WS-IDX)
                                 NOT = RREQT-CPREQ-DESGNT-ID)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS2362'          TO L0760-MSG-SRCE
               MOVE '0012'            TO L0760-MSG-NUMBER
      * MSG : DESIGNATION (@1) CHANGED TO (@2)

               MOVE RREQT-CPREQ-DESGNT-ID
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-DESGNT-ID-T (WS-IDX)
                                      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.

           MOVE MIR-CPREQ-DESGNT-ID-T (WS-IDX)
                                      TO RREQT-CPREQ-DESGNT-ID.

       5370-EDIT-DESIGNATION-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT TEST DATE.
      *   IF TEST DATE IS DELETED, THE VALIDITY DATE WILL ALSO BE
      *   DELETED.  GIVE WARNING IF REQUIREMENT NOT AT LEAST ORDERED
      *   YET.  CHECK FATALITY IF TEST DATE IS IN THE FUTURE.
      ****************************************************************
       5380-EDIT-TEST-DATE.

           SET WS-NO-CALC-VALIDITY-DATE
                                      TO TRUE.

           IF  MIR-CPREQ-TST-DT-T (WS-IDX) =  SPACES
               MOVE RREQT-CPREQ-TST-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-TST-DT-T
                                         (WS-IDX)
           END-IF.

      ***  HANDLE DELETION.

           IF  MIR-CPREQ-TST-DT-T (WS-IDX) =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-TST-DT-T
                                         (WS-IDX)
               MOVE SPACES            TO MIR-CPREQ-VALID-DT-T
                                         (WS-IDX)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS2362'          TO L0760-MSG-SRCE
               MOVE '0013'            TO L0760-MSG-NUMBER
      * MSG : TEST DATE (@1) UPDATED TO (@2)
               MOVE RREQT-CPREQ-TST-DT
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-TST-DT-T (WS-IDX)
                                      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-TST-DT
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-VALID-DT
               SET WS-CALC-VALIDITY-DATE
                                      TO TRUE

               IF  WS-RECEIVED-STATUS
                   MOVE 'NS23620014'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WS-IDX        TO WGLOB-MSG-PARM (2)

      * MSG : TEST DATE SHOULD EXIST FOR A REVIEWED REQUIREMENT
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5380-EDIT-TEST-DATE-X
               ELSE
                   GO TO 5380-EDIT-TEST-DATE-X
               END-IF

           END-IF.


      ***  WHEN STATUS GOES TO RECEIVED, WAIVED OR CANCELLED THEN IF
      ***  DATE CONTAINS SPACES, DEFAULT IT TO CURRENT DATE

           IF  MIR-CPREQ-TST-DT-T (WS-IDX) = SPACES

               IF  WS-NEW-STATUS-OK
               AND (WS-RECEIVED-STATUS
               OR   WS-WAIVED-CANCELLED)
                   MOVE WGLOB-SYSTEM-DATE-INT
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM  1640-8000-INTERNAL-TO-MIR
020462                 THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-TST-DT-T
                                         (WS-IDX)
               END-IF

           END-IF.


      ***  IF DATE IS BLANK THEN EXIT.

           IF  MIR-CPREQ-TST-DT-T (WS-IDX) = SPACES
               GO TO 5380-EDIT-TEST-DATE-X
           END-IF.


      ***  EXPECT STATUS TO BE ORDERED OR BETTER IF DATE ENTERED.

           IF  WS-NEW-STATUS-OK
           AND (RREQT-CPREQ-STAT-WANTED
           OR   RREQT-CPREQ-STAT-ORDERED)
           AND WS-UW-REQUIREMENT

      * MSG : TEST DETAILS ENTERED BEFORE REQT ORDERED
               MOVE 'NS23620015'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WS-EDITS-FAILED
                                      TO TRUE
                   GO TO 5380-EDIT-TEST-DATE-X
               END-IF

           END-IF.


      ***  CHECK VALIDITY.

           MOVE MIR-CPREQ-TST-DT-T (WS-IDX) TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-INTERNAL-DATE = RREQT-CPREQ-TST-DT
               GO TO 5380-EDIT-TEST-DATE-X
           END-IF.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-TEMP-DATE
           ELSE
      * MSG :INVALID TEST DATE, FORMAT MUST BE VALID
               MOVE 'NS23620016'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5380-EDIT-TEST-DATE-X
           END-IF.


      ***  CHECK NOT IN FUTURE.

           IF  L1640-INTERNAL-DATE    >  WGLOB-SYSTEM-DATE-INT
               MOVE 'NS23620017'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG: WARNING...TEST DATE IS IN THE FUTURE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF WGLOB-MSG-SEVRTY-FATAL
                   SET WS-EDITS-FAILED
                                      TO TRUE
                   GO TO 5380-EDIT-TEST-DATE-X
               END-IF

           END-IF.


      ***  DIARY LOG ENTRY FOR TEST DATE.

           IF (WS-TEMP-DATE NOT = RREQT-CPREQ-TST-DT)
      * MSG : TEST DATE (@1) UPDATED TO (@2)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS2362'          TO L0760-MSG-SRCE
               MOVE '0013'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-TST-DT  TO L0760-MESSAGE-PARMS (1)
               MOVE WS-TEMP-DATE      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.

           MOVE WS-TEMP-DATE          TO RREQT-CPREQ-TST-DT.
           SET WS-CALC-VALIDITY-DATE  TO TRUE.

       5380-EDIT-TEST-DATE-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT TEST RESULT:
      *   GIVE WARNING IF REQUIREMENT NOT AT LEAST ORDERED YET.
      *   LOOKUP RESULT ON THE EDIT TABLE.
      ****************************************************************
       5400-EDIT-TEST-RESULT.

           IF  MIR-CPREQ-TST-RSLT-CD-T (WS-IDX) = SPACES
               MOVE RREQT-CPREQ-TST-RSLT-CD
                                      TO MIR-CPREQ-TST-RSLT-CD-T
                                         (WS-IDX)
               GO TO 5400-EDIT-TEST-RESULT-X
           END-IF.


      ***  HANDLE DELETION.

           IF  MIR-CPREQ-TST-RSLT-CD-T (WS-IDX) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-TST-RSLT-CD-T
                                         (WS-IDX)
               MOVE SPACES            TO RREQT-CPREQ-TST-RSLT-CD
               GO TO 5400-EDIT-TEST-RESULT-X
           END-IF.


      ***  EXPECT STATUS TO BE ORDERED OR BETTER.

           IF  WS-NEW-STATUS-OK
           AND RREQT-CPREQ-STAT-WANTED
           AND WS-UW-REQUIREMENT
      * MSG : TEST DETAILS ENTERED BEFORE REQT ORDERED
               MOVE 'NS23620015'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WS-EDITS-FAILED
                                      TO TRUE
                   GO TO 5400-EDIT-TEST-RESULT-X
               END-IF

           END-IF.

           IF  MIR-CPREQ-TST-RSLT-CD-T (WS-IDX) =
               RREQT-CPREQ-TST-RSLT-CD
               GO TO 5400-EDIT-TEST-RESULT-X
           END-IF.

      ***  LOOKUP ON EDIT TABLE.

           MOVE MIR-CPREQ-TST-RSLT-CD-T (WS-IDX)
                                      TO WEDIT-ETBL-VALU-ID.
           PERFORM  RESL-1000-EDIT-TEST-RESULT
               THRU RESL-1000-EDIT-TEST-RESULT-X.
           IF  NOT WEDIT-IO-OK
      * MSG : TEST RESULT MUST BE IN EDIT TYPE RESLT
               MOVE 'NS23620020'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5400-EDIT-TEST-RESULT-X
           END-IF.


      ***  DIARY LOG.

           IF (MIR-CPREQ-TST-RSLT-CD-T (WS-IDX)
                                NOT = RREQT-CPREQ-TST-RSLT-CD)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS2362'          TO L0760-MSG-SRCE
               MOVE '0021'            TO L0760-MSG-NUMBER

               MOVE RREQT-CPREQ-TST-RSLT-CD
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-TST-RSLT-CD-T (WS-IDX)
                                      TO L0760-MESSAGE-PARMS (2)
      * MSG :  TEST RESULT (@1) UPDATED TO (@2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.

           MOVE MIR-CPREQ-TST-RSLT-CD-T (WS-IDX)
                                      TO RREQT-CPREQ-TST-RSLT-CD.

       5400-EDIT-TEST-RESULT-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT RESULTS-IND:
      *   NEW RESULTS INDICATOR MUST BE 'Y' OR 'N' (YES/NO). DETERMINES
      *   WHETHER OR NOT OLD RESULTS CAN BE USED TO RESOLVE THE REQT.
      *   OLD RESULTS ARE LAB TESTS CREATED BEFORE THE REQT WAS
      *   ORDERED.
      ****************************************************************
       5405-EDIT-RESULTS-IND.

           IF  MIR-CPREQ-NEW-RSLT-IND-T (WS-IDX) = SPACES
               MOVE RREQT-CPREQ-NEW-RSLT-IND
                                      TO MIR-CPREQ-NEW-RSLT-IND-T
                                         (WS-IDX)
               GO TO 5405-EDIT-RESULTS-IND-X
           END-IF.

      ***  HANDLE DELETION.
           IF MIR-CPREQ-NEW-RSLT-IND-T (WS-IDX)
                                    = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-NEW-RSLT-IND-T
                                         (WS-IDX)
           END-IF.

           IF  MIR-CPREQ-NEW-RSLT-IND-T (WS-IDX)
                                    = RREQT-CPREQ-NEW-RSLT-IND
               GO TO 5405-EDIT-RESULTS-IND-X
           END-IF.

      ***  ONLY 'Y' OR 'N' ARE ACCEPTED.
           MOVE MIR-CPREQ-NEW-RSLT-IND-T (WS-IDX)
                                      TO WS-YES-NO-VALID-SW.
           IF  WS-YES-NO-VALID
               CONTINUE
           ELSE
               MOVE 'NS23620022'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG : NEW RESULTS INDICATOR MUST BE Y OR N
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5405-EDIT-RESULTS-IND-X
           END-IF.

      ***  DIARY LOG.
           IF (MIR-CPREQ-NEW-RSLT-IND-T (WS-IDX)
                                   NOT = RREQT-CPREQ-NEW-RSLT-IND)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS2362'          TO L0760-MSG-SRCE
               MOVE '0023'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-NEW-RSLT-IND
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-NEW-RSLT-IND-T (WS-IDX)
                                      TO L0760-MESSAGE-PARMS (2)
      * MSG : NEW RESULTS INDICATOR (@1) UPDATED TO (@2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.
           MOVE MIR-CPREQ-NEW-RSLT-IND-T (WS-IDX)
                                      TO RREQT-CPREQ-NEW-RSLT-IND.


      *  THE FOLLOWING EDIT WAS ORIGINALLY IN THE CROSS EDITS SECTION.
      *  IT IS NOW HERE TO POSITION THE CURSOR WHEN THE EDIT FAILS.

           IF  RREQT-CPREQ-NEW-RSLT-ONLY
           AND RRTAB-LAB-ID   = SPACES
               MOVE 'NS23620024'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG:NEW RESULTS IND CAN ONLY BE SPECIFIED FOR A LAB REQUIREMENT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5405-EDIT-RESULTS-IND-X
           END-IF.

       5405-EDIT-RESULTS-IND-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT RESOLVE IND:
      *   THE RESOLVE INDICATOR MUST BE 'Y' OR 'N'. THIS FIELD IS
      *   USED TO TRIGGER THE REQUIREMENT RESOLUTION PROCESSING.
      ****************************************************************
       5410-EDIT-RESOLVE-IND.

           IF  MIR-DV-REVW-REQIR-IND-T (WS-IDX) = SPACES
               MOVE 'N'               TO MIR-DV-REVW-REQIR-IND-T
                                         (WS-IDX)
               GO TO 5410-EDIT-RESOLVE-IND-X
           END-IF.

      ***  HANDLE DELETION.
           IF  MIR-DV-REVW-REQIR-IND-T (WS-IDX)
                                     = EBLCH-BLANK-FIELD-CHAR
               MOVE 'N'               TO MIR-DV-REVW-REQIR-IND-T
                                         (WS-IDX)
           END-IF.

      ***  ONLY 'Y' OR 'N' ARE ACCEPTED.
           MOVE MIR-DV-REVW-REQIR-IND-T (WS-IDX)
                                      TO WS-YES-NO-VALID-SW.
           IF  WS-YES-NO-VALID
               CONTINUE
           ELSE
               MOVE 'NS23620025'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

      * MSG : RESOLVE INDICATOR MUST BE Y OR N
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5410-EDIT-RESOLVE-IND-X
           END-IF.

       5410-EDIT-RESOLVE-IND-X.
           EXIT.
      /
      ****************************************************************
      *   CALCULATE FOLLOW UP DETAILS:
      *   USER HAS NOT SUPPLIED FOLLOW-UP DETAILS, SO CALCULATE
      *   THE FIRST FOLLOW-UP AUTOMATICALLY.  WARNINGS WILL BE
      *   GENERATED IF THE FOLLOW-UP DATE IS PAST THE FINAL
      *   DISPOSITION WARNING DATE.
      ****************************************************************
       5420-CALCULATE-FOLLOW-UP.


      ***  IF NOT CHANGED TO ORDERED, CLEAR ANY FOLLOWUP INFORMATION.

           IF  RREQT-CPREQ-STAT-ORDERED
           AND WS-RTAB-AVAILABLE
               CONTINUE
           ELSE
               MOVE ZEROS             TO RREQT-CPREQ-FOLWUP-NUM
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-NUM-T
                                         (WS-IDX)
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-FOLWUP-DT
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-DT-T
                                         (WS-IDX)
               GO TO 5420-CALCULATE-FOLLOW-UP-X
           END-IF.


      ***  REQUIREMENT JUST ORDERED, CALCULATE FIRST FOLLOWUP.

           MOVE 1                     TO RREQT-CPREQ-FOLWUP-NUM.
           PERFORM  RFUP-1000-SET-FOLLOWUP
               THRU RFUP-1000-SET-FOLLOWUP-X.


      ***  CHECK AGAINST FINAL DISPOSITION DATE.

           PERFORM  7500-CHECK-FINAL-DISP
               THRU 7500-CHECK-FINAL-DISP-X.


      ***  UPDATE SCREEN FIELDS.

020874*    MOVE RREQT-CPREQ-FOLWUP-NUM   TO WS-PIC-Z.
020874*    MOVE WS-PIC-Z              TO MIR-CPREQ-FOLWUP-NUM-T
020874*                                  (WS-IDX).
020874     MOVE RREQT-CPREQ-FOLWUP-NUM TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-CPREQ-FOLWUP-NUM-T (WS-IDX).

           MOVE RREQT-CPREQ-FOLWUP-DT TO L1640-INTERNAL-DATE.
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-FOLWUP-DT-T
                                         (WS-IDX)
           END-IF.

       5420-CALCULATE-FOLLOW-UP-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT FOLLOW-UP NUMBER:
      *   USER HAS ENTERED SOME OR ALL OF THE FOLLOW-UP DETAILS.
      *   CHECK FOLLOW-UP NUMBER FOR VALIDITY.  NOTE THAT FOLLOW-UP
      *   DETAILS ARE PERMITTED EVEN IN THE RTAB RECORD DOES NOT
      *   CURRENTLY EXIST.
      ****************************************************************
       5440-EDIT-FUP-NUMBER.

           SET WS-FUP-NUMBER-EDIT-OK  TO TRUE.

      ***  REDISPLAY IF NOT UPDATED.

           IF  MIR-CPREQ-FOLWUP-NUM-T (WS-IDX) = SPACES
020874*        MOVE RREQT-CPREQ-FOLWUP-NUM
020874*                               TO WS-PIC-Z
020874*        MOVE WS-PIC-Z          TO MIR-CPREQ-FOLWUP-NUM-T
020874*                                  (WS-IDX)
020874         MOVE RREQT-CPREQ-FOLWUP-NUM TO L0290-INPUT-V00
020874         MOVE 0                      TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
020874                                     TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA
020874                           TO MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.

           IF  MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      = RREQT-CPREQ-FOLWUP-NUM
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.

      ***  HANDLE DELETION.

           IF  MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-NUM-T
                                         (WS-IDX)
               MOVE ZEROS             TO RREQT-CPREQ-FOLWUP-NUM
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.




      ***  EXIT IF NOT GIVEN & NOT ON RECORD.

           IF  MIR-CPREQ-FOLWUP-NUM-T (WS-IDX) = SPACES
               MOVE ZERO              TO RREQT-CPREQ-FOLWUP-NUM
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.


      ***  CHECK NUMERIC.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 1                     TO L0280-LENGTH.
           MOVE 1                     TO L0280-INPUT-SIZE.
           MOVE MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               CONTINUE
           ELSE
               MOVE 'NS23620026'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG : FOLLOW-UP # MUST BE NUMERIC

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FUP-NUMBER-EDIT-FAILED
                                      TO TRUE
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.


      ***  CHECK VALID RANGE.

           MOVE MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      TO WS-EDIT-FOLLOWUP-NO
           IF  NOT VALID-FOLLOWUP-NO
               MOVE 'NS23620027'      TO WGLOB-MSG-REF-INFO
      * MSG : FOLLOW-UP # MUST BE 1, 2 OR 3'
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FUP-NUMBER-EDIT-FAILED
                                      TO TRUE
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.


      ***  CHECK WITHIN DEFINED FOLLOW-UPS.

           IF  WS-RTAB-AVAILABLE
               MOVE MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      TO WS-SUB

               IF  RRTAB-FOLWUP-DY-DUR  (WS-SUB) = ZERO
                   MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WS-IDX        TO WGLOB-MSG-PARM (2)

                   MOVE MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (3)
                   MOVE RRTAB-REQIR-ID
                                      TO WGLOB-MSG-PARM (4)
                   MOVE 'NS23620028'  TO WGLOB-MSG-REF-INFO
      * MSG : FOLLOW-UP NUMBER (@3) NOT DEFINED FOR REQUIREMENT (@4)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE ZERO          TO RREQT-CPREQ-FOLWUP-NUM
                   MOVE SPACE         TO MIR-CPREQ-FOLWUP-NUM-T
                                         (WS-IDX)
                   GO TO 5440-EDIT-FUP-NUMBER-X
               END-IF

           END-IF.


      ***  DIARY LOG.

           IF (MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      NOT = RREQT-CPREQ-FOLWUP-NUM)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS2362'          TO L0760-MSG-SRCE
               MOVE '0029'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-FOLWUP-NUM
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      TO L0760-MESSAGE-PARMS (2)
      * MSG :  FOLLOW-UP NUMBER (@1) UPDATED TO (@2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.
      *    CONVERT MIR-CPREQ-FOLWUP-NUM  TO NUMERIC.
           MOVE MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
                                      TO RREQT-CPREQ-FOLWUP-NUM.

       5440-EDIT-FUP-NUMBER-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT FOLLOW-UP DATE:
      *   USER HAS ENTERED SOME OR ALL OF THE FOLLOW-UP DETAILS.
      *   CHECK FOLLOW-UP DATE FOR VALIDITY.  IF A FOLLOW-UP NUMBER HAS
      *   BEEN GIVEN, AND NO DATE IS KNOWN, IT WILL BE CALCULATED.
      *   IF THE FOLLOW-UP DATE (ENTERED OR CALCULATED) IS BEFORE TODAY,
      *   FATALITY WILL BE CHECKED.  WARNINGS WILL BE GENERATED IF THE
      *   FOLLOW-UP DATE IS PAST THE FINAL DISPOSITION WARNING DATE.
      ****************************************************************
       5460-EDIT-FUP-DATE.

      ***  HANDLE ENTIRE FOLLOW-UP DELETION.
           IF  WS-FUP-NUMBER-EDIT-OK AND
              (RREQT-CPREQ-FOLWUP-NUM = ZERO)
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-DT-T
                                         (WS-IDX)
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-FOLWUP-DT
               GO TO 5460-EDIT-FUP-DATE-X
           END-IF.

      ***  RESTORE FILE VALUE.
           IF  MIR-CPREQ-FOLWUP-DT-T (WS-IDX)  = SPACES
               MOVE RREQT-CPREQ-FOLWUP-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X

               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-FOLWUP-DT-T
                                         (WS-IDX)
               END-IF

           END-IF.

      ***  HANDLE FIELD DELETION.
           IF  MIR-CPREQ-FOLWUP-DT-T (WS-IDX) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-DT-T
                                         (WS-IDX)
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-FOLWUP-DT
           END-IF.

      ***  HANDLE BLANK VALUE.

           IF (MIR-CPREQ-FOLWUP-DT-T (WS-IDX) = SPACES)

               IF  WS-FUP-NUMBER-EDIT-OK
               AND WS-RTAB-AVAILABLE
                   PERFORM  RFUP-1000-SET-FOLLOWUP
                       THRU RFUP-1000-SET-FOLLOWUP-X
                   PERFORM  7500-CHECK-FINAL-DISP
                       THRU 7500-CHECK-FINAL-DISP-X
                   GO TO 5460-EDIT-FUP-DATE-X
               ELSE
                   GO TO 5460-EDIT-FUP-DATE-X
               END-IF

           END-IF.

      ***  CHECK VALIDITY.
           MOVE MIR-CPREQ-FOLWUP-DT-T (WS-IDX)
                                      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-INTERNAL-DATE = RREQT-CPREQ-FOLWUP-DT
               GO TO 5460-EDIT-FUP-DATE-X
           END-IF.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-TEMP-DATE
           ELSE
               MOVE 'NS23620030'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG : INVALID FOLLOW-UP DATE, FORMAT MUST BE VALID

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5460-EDIT-FUP-DATE-X
           END-IF.

      ***  WARN USER IF FOLLOW-UP ALREADY PAST.
           IF  L1640-INTERNAL-DATE < WGLOB-SYSTEM-DATE-INT
               MOVE 'NS23620031'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG : FOLLOW-UP DATE IS BEFORE TODAY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WS-EDITS-FAILED
                                      TO TRUE
                   GO TO 5460-EDIT-FUP-DATE-X
               END-IF

           END-IF.

      ***  DIARY LOG.
           IF (WS-TEMP-DATE NOT = RREQT-CPREQ-FOLWUP-DT)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS2362'          TO L0760-MSG-SRCE
               MOVE '0032'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-FOLWUP-DT
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE WS-TEMP-DATE      TO L0760-MESSAGE-PARMS (2)
      * MSG: FOLLOW-UP DATE (@1) UPDATED TO (@2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.

      ***  UPDATE RECORD.
           MOVE WS-TEMP-DATE          TO RREQT-CPREQ-FOLWUP-DT.

      ***  CHECK AGAINST FINAL DISPOSITION DATE.
           PERFORM  7500-CHECK-FINAL-DISP
               THRU 7500-CHECK-FINAL-DISP-X.

       5460-EDIT-FUP-DATE-X.
           EXIT.
      /
      ****************************************************************
      *   CALCULATE REQUIREMENT VALIDITY DATE:
      *   USER HAS NOT SUPPLIED THE VALIDITY DATE AND A VALID TEST DATE
      *   IS AVAILABLE, SO CALCULATE THE VALIDATY DATE AUTOMATICALLY.
      ****************************************************************
       5480-CALCULATE-VALIDITY-DATE.

      ***  CALCULATE NEW VALIDITY DATE (IF CAN)
           IF  WS-RTAB-AVAILABLE
               PERFORM  RVAL-1000-SET-REQT-VALIDITY
                   THRU RVAL-1000-SET-REQT-VALIDITY-X
           END-IF.

      ***  REDISPLAY VALIDITY DATE.
           IF  RREQT-CPREQ-VALID-DT   = WWKDT-ZERO-DT
               MOVE SPACES            TO MIR-CPREQ-VALID-DT-T
                                         (WS-IDX)
           ELSE
               MOVE RREQT-CPREQ-VALID-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-VALID-DT-T
                                         (WS-IDX)
           END-IF.

       5480-CALCULATE-VALIDITY-DATE-X.
           EXIT.
      /
      ****************************************************************
      *  EDIT REQUIREMENT VALIDITY DATE:
      *  THE USER HAS ENTERED A REQUIREMENT VALIDITY DATE - CHECK VALID.
      ****************************************************************
       5500-EDIT-VALIDITY-DATE.

      ***  REDISPLAY IF BLANK.
           IF  MIR-CPREQ-VALID-DT-T (WS-IDX) = SPACES
               MOVE RREQT-CPREQ-VALID-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-VALID-DT-T
                                         (WS-IDX)
               GO TO 5500-EDIT-VALIDITY-DATE-X
           END-IF.

      ***  FIELD DELETION.
           IF  MIR-CPREQ-VALID-DT-T (WS-IDX) = EBLCH-BLANK-FIELD-CHAR
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-VALID-DT
               MOVE SPACES            TO MIR-CPREQ-VALID-DT-T
                                         (WS-IDX)

               IF  WS-RECEIVED-STATUS
                   MOVE 'NS23620033'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WS-IDX        TO WGLOB-MSG-PARM (2)
      * MSG :  VALIDITY DATE SHOULD EXIST FOR A REVIEWED REQUIREMENT
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5500-EDIT-VALIDITY-DATE-X
               ELSE
                   GO TO 5500-EDIT-VALIDITY-DATE-X
               END-IF

           END-IF.

      ***  CHECK PROPER DATE.
           MOVE MIR-CPREQ-VALID-DT-T (WS-IDX)
                                      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-INTERNAL-DATE = RREQT-CPREQ-VALID-DT
               GO TO 5500-EDIT-VALIDITY-DATE-X
           END-IF.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-TEMP-DATE
           ELSE
               MOVE 'NS23620034'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG:  VALIDITY DATE SHOULD EXIST FOR A REVIEWED REQUIREMENT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-EDITS-FAILED    TO TRUE
               GO TO 5500-EDIT-VALIDITY-DATE-X
           END-IF.

      ***  DIARY LOG.
           IF (WS-TEMP-DATE NOT = RREQT-CPREQ-VALID-DT)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS2362'          TO L0760-MSG-SRCE
               MOVE '0035'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-VALID-DT
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE WS-TEMP-DATE      TO L0760-MESSAGE-PARMS (2)
      * MSG : REQT VALIDITY DATE (@1) UPDATED TO (@2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.

      ***  UPDATE RECORD.
           MOVE WS-TEMP-DATE          TO RREQT-CPREQ-VALID-DT.

       5500-EDIT-VALIDITY-DATE-X.
           EXIT.
      /
      ****************************************************************
      *  CROSS EDITS:                                                *
      *       PERFORM ANY NECESSARY CROSS EDITS.                     *
      ****************************************************************
       5600-CROSS-EDITS.

           IF  RRTAB-LAB-ID   = SPACES
           AND WS-VALID-LAB-CODE-FOUND
               MOVE 'NS23620036'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG :LAB CODE NOT ALLOWED FOR NON-LAB REQUIREMENTS
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-CROSS-EDITS-FAILED
                                      TO TRUE
           END-IF.

           IF  RRTAB-LAB-ID   NOT = SPACES
           AND RREQT-CPREQ-DESGNT-ID  = SPACES
               MOVE 'NS23620037'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG : LAB CODE REQUIRED FOR A LAB REQUIREMENT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-CROSS-EDITS-FAILED
                                      TO TRUE
           END-IF.

           IF  MIR-DV-REVW-REQIR-IND-T (WS-IDX) = 'Y'
           AND RREQT-CPREQ-DESGNT-ID  = SPACES
               MOVE 'N'               TO MIR-DV-REVW-REQIR-IND-T
                                         (WS-IDX)
               MOVE 'NS23620038'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE WS-IDX            TO WGLOB-MSG-PARM (2)
      * MSG :  REQUIREMENT RESOLUTION CAN ONLY BE REQUESTED FOR
      *        LAB REQUIREMENTS
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-CROSS-EDITS-FAILED
                                      TO TRUE
           END-IF.

       5600-CROSS-EDITS-X.
           EXIT.

      ****************************************************************
      *  WRITE DIARY LOG VARIABLE:        INPUT: L0760-DAL-ACTION
      *  WRITE AN ENTRY TO THE DIARY LOG TO      L0760-MESS-NUMBER
      *  DESCRIBE THE CHANGES THAT ARE BEING     L0760-MESSAGE-PARMS ()
      *  MADE TO THE REQUIREMENT FILE.
      ****************************************************************
       7000-WRITE-DALG.

      ***  SETUP GENERAL INFORMATION FROM REQUIREMENT RECORD.
      ***  NOTE THAT RREQT-POL-CLI-ID IS EITHER POLICY OR CLIENT ID.
           MOVE RREQT-CPREQ-POL-CLI-CD
                                      TO L0760-POL-OR-CLI-TYPE.
           MOVE RREQT-POL-CLI-ID      TO L0760-POL-OR-CLI-ID.

           MOVE RREQT-REQIR-ID        TO L0760-DAL-ACTIVITY

           MOVE ZERO                  TO L0760-CVG-NUM-N.

      ***  LINK TO DIARY LOG WRITE MODULE.
           PERFORM  0760-1000-PROCESS-DAL-ENTRY
               THRU 0760-1000-PROCESS-DAL-ENTRY-X.

       7000-WRITE-DALG-X.
           EXIT.
      /
      ****************************************************************
      *   UPDATE CLIENT ACTIVITY DATE:
      *   IF THE CLIENT IS NOT CURRENTLY LOCKED BY CLEAR CASE, LOCK
      *   THE NAL RECORD, UPDATE THE LAST ACTIVITY DATE AND REWRITE IT.
      ****************************************************************
       7250-UPD-CLIENT-ACTIVITY-DT.

      ***  LOCK THE CLIENT.
           MOVE MIR-CLI-ID            TO L2437-CLI-ID.
           MOVE WGLOB-SYSTEM-DATE-INT TO L2437-PREV-UWG-ACTV-DT.
           SET L2437-PREV-UWG-ACTV-DT-UPDT
                                      TO TRUE.
           PERFORM  2437-2000-UPDT-CLI-INFO
               THRU 2437-2000-UPDT-CLI-INFO-X.

      ***  CHECK CLEAR CASE LOCK.

           IF  L2437-CLI-CCAS-LOCK-LOCKED
               GO TO 7250-UPD-CLIENT-ACTIVITY-DT-X
           END-IF.

       7250-UPD-CLIENT-ACTIVITY-DT-X.
           EXIT.


      ****************************************************************
      *   CHECK FOLLOW-UP DATE VS FINAL DISPOSITION DATE.
      *   THE FINAL DISPOSITION DATE AND RUSH IND ARE FETCHED.  A
      *   MESSAGE IS GENERATED IF THE RUSH IND IS SET, OR IF THE FINAL
      *   DISPOSITION DATE IS BEFORE THE FOLLOW-UP DATE, OR IF THE
      *   FINAL DISPOSITION WARNING DATE IS BEFORE THE FOLLOW-UP DATE.
      ****************************************************************
       7500-CHECK-FINAL-DISP.

      ***  FETCH DATA INTO L0095 INTERFACE.
           PERFORM  7510-FETCH-FINAL-DISP
               THRU 7510-FETCH-FINAL-DISP-X.

      ***  CHECK RUSH INDICATOR.
           IF  L0095-RUSH-IND = 'Y'

               IF  WS-UW-REQUIREMENT
                   MOVE L0095-CLI-ID  TO WGLOB-MSG-PARM (1)
                   MOVE L0095-RUSH-POL-ID
                                      TO WGLOB-MSG-PARM (2)
                   MOVE 'NS23620039'  TO WGLOB-MSG-REF-INFO
      * MSG : CLIENT @1 IS INSURED ON RUSH POLICY @2
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L0095-RUSH-POL-ID
                                      TO WGLOB-MSG-PARM (1)
                   MOVE 'NS23620040'  TO WGLOB-MSG-REF-INFO
      * MSG : POLICY @1 IS A RUSH POLICY
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

           END-IF.

           IF  L0095-FINAL-DISP-DT = WWKDT-ZERO-DT
           OR  RPOL-POL-SUSPENDED
               GO TO 7500-CHECK-FINAL-DISP-X
           END-IF.

      ***  CHECK FINAL DISPOSITION AGAINST FOLLOW-UP DATE.

           IF  L0095-FINAL-DISP-DT NOT > RREQT-CPREQ-FOLWUP-DT
               MOVE L0095-FDD-POL-ID  TO WGLOB-MSG-PARM (1)
               MOVE RREQT-CPREQ-FOLWUP-DT
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (2)
               MOVE L0095-FINAL-DISP-DT
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (3)
               MOVE 'NS23620041'      TO WGLOB-MSG-REF-INFO
      * MSG : POLICY(@1): FOLLOW-UP(@2) > FINAL DISPOSITION(@3)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7500-CHECK-FINAL-DISP-X
           END-IF.

      ***  FETCH SUB-COMPANY PROFILE.

           MOVE L0095-SBSDRY-CO-ID    TO WSCOM-SBSDRY-CO-ID.
           PERFORM  SCOM-1000-READ
               THRU SCOM-1000-READ-X.
           IF  WSCOM-IO-NOT-FOUND
               MOVE L0095-SBSDRY-CO-ID
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000234'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7500-CHECK-FINAL-DISP-X
           END-IF.

      ***  COMPUTE FINAL DISPOSITION WARNING DATE.

           SUBTRACT RSCOM-DISP-WARN-DY-DUR
                    FROM ZERO GIVING L1680-NUMBER-OF-DAYS.
           MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
           MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
           MOVE L0095-FINAL-DISP-DT   TO L1680-INTERNAL-1.
           PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
               THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
      ***  CHECK FINAL DISPOSITION WARNING AGAINST FOLLOW-UP DATE.
           IF  L1680-INTERNAL-2 NOT > RREQT-CPREQ-FOLWUP-DT
               MOVE L0095-FDD-POL-ID  TO WGLOB-MSG-PARM (1)
               MOVE RREQT-CPREQ-FOLWUP-DT
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (2)
               MOVE L1680-INTERNAL-2  TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (3)
               MOVE 'NS23620042'      TO WGLOB-MSG-REF-INFO
      * MSG : POLICY(@1): FOLLOW-UP(@2) > FINAL DISP WARNING(@3)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7500-CHECK-FINAL-DISP-X.
           EXIT.
      /
      ****************************************************************
      *   FETCH FINAL DISPOSITION DATA.
      *   THE FINAL DISPOSITION DATE AND RUSH INDICATOR ARE FETCHED,
      *   FROM THE POLICY FOR ISSUE REQUIREMENTS, OR BY SEARCHING
      *   ALL POLICIES FOR UNDERWRITING REQUIREMENTS.  AT EXIT, THE
      *   DATA IS LEFT IN THE L0095 INTERFACE AREA.
      ****************************************************************
       7510-FETCH-FINAL-DISP.


      ***  ISSUE REQUIREMENT - FROM THIS POLICY.
           IF  WS-ISSUE-REQUIREMENT
               MOVE MIR-POL-ID-BASE   TO WPOL-POL-ID-BASE
               MOVE MIR-POL-ID-SFX    TO WPOL-POL-ID-SFX
               PERFORM  POL-1000-READ
                   THRU POL-1000-READ-X
               MOVE MIR-POL-ID        TO L0095-FDD-POL-ID
                                         L0095-RUSH-POL-ID
               MOVE RPOL-POL-FINAL-DISP-DT
                                      TO L0095-FINAL-DISP-DT
               MOVE RPOL-POL-RUSH-IND TO L0095-RUSH-IND
               MOVE RPOL-SBSDRY-CO-ID TO L0095-SBSDRY-CO-ID
               GO TO 7510-FETCH-FINAL-DISP-X
           END-IF.

      ***  UNDERWRITING REQUIREMNT - INVOKE SEARCH WORKER.
           PERFORM  0095-1000-BUILD-PARM-INFO
               THRU 0095-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CLI-ID            TO L0095-CLI-ID.
           PERFORM  0095-1000-INSRD-POL-CHK
               THRU 0095-1000-INSRD-POL-CHK-X.

       7510-FETCH-FINAL-DISP-X.
           EXIT.


      ****************************************************************
      *   FORCE ANALYZE OF INSURED / POLICY.
      *   INVOKE THE ANALYSIS PROGRAM TO UPDATE THE STATUS'S OF
      *   THE RELEVANT COVERAGES AND/OR POLICIES.  THIS ROUTINE SHOULD
      *   ONLY BE EXECUTED WHEN THERE IS A POSSIBILITY OF THE STATUS'S
      *   BEING CHANGED BY THE CHANGES MADE TO THE REQUIREMENT FILE.
      ****************************************************************
       7700-FORCE-ANALYZE.

           PERFORM  1090-1000-BUILD-PARM-INFO
               THRU 1090-1000-BUILD-PARM-INFO-X.

      ***  PERFORM ANALYSIS.
           IF  WS-UW-REQUIREMENT
               MOVE MIR-CLI-ID        TO L1090-CLI-ID
               PERFORM  1090-1000-INSRD-ANALYZE
                   THRU 1090-1000-INSRD-ANALYZE-X
           ELSE
               MOVE MIR-POL-ID        TO L1090-POL-ID
               PERFORM  1090-2000-POL-ANALYZE
                   THRU 1090-2000-POL-ANALYZE-X
           END-IF.


      ***  CHECK ERROR.
           IF  NOT L1090-RETRN-OK
               MOVE L1090-RQST-CD     TO WGLOB-MSG-PARM (1)
               MOVE L1090-CLI-ID      TO WGLOB-MSG-PARM (2)
               MOVE L1090-POL-ID      TO WGLOB-MSG-PARM (3)
               MOVE L1090-RETRN-CD    TO WGLOB-MSG-PARM (4)
               MOVE 'NS23620043'      TO WGLOB-MSG-REF-INFO
      * MSG :  ANALYSIS FAILURE - CONTACT SYSTEMS
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7700-FORCE-ANALYZE-X.
           EXIT.

      *---------------------------
       7800-REFRESH-POLICY-STATUS.
      *---------------------------

           MOVE MIR-POL-ID-BASE-T (WS-IDX)
                                      TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX-T (WS-IDX)
                                      TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               MOVE RPOL-POL-CSTAT-CD TO MIR-POL-CSTAT-CD-T
                                         (WS-IDX)
           END-IF.

       7800-REFRESH-POLICY-STATUS-X.
           EXIT.
035393
035393*-----------------
035393 7900-REQU-EVENT.
035393*-----------------
035393
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         SET L0319-XTRNL-EVNT-CITS-CRQUPDT
035393                                     TO TRUE
035393     ELSE
035393         SET L0319-XTRNL-EVNT-CITS-REQUPDT
035393                                     TO TRUE
035393     END-IF.
035393
035393     MOVE WGLOB-SYS-CTL-ID           TO L0319-SYS-CTL-ID
035393     PERFORM  0319-1000-GET-EVNT-EXIT-PGM
035393         THRU 0319-1000-GET-EVNT-EXIT-PGM-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         PERFORM  7970-CITU-EXIT
035393             THRU 7970-CITU-EXIT-X
035393     ELSE
035393         PERFORM  7980-CITC-EXIT
035393             THRU 7980-CITC-EXIT-X
035393     END-IF.
035393
035393 7900-REQU-EVENT-X.
035393     EXIT.
035393
035393*----------------
035393 7950-REQS-EVENT.
035393*----------------
035393
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         SET L0319-XTRNL-EVNT-CITS-CRQSTAT
035393                                     TO TRUE
035393     ELSE
035393         SET L0319-XTRNL-EVNT-CITS-REQSTAT
035393                                     TO TRUE
035393     END-IF.
035393
035393     MOVE WGLOB-SYS-CTL-ID           TO L0319-SYS-CTL-ID
035393     PERFORM  0319-1000-GET-EVNT-EXIT-PGM
035393         THRU 0319-1000-GET-EVNT-EXIT-PGM-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         PERFORM  7970-CITU-EXIT
035393             THRU 7970-CITU-EXIT-X
035393     ELSE
035393         PERFORM  7980-CITC-EXIT
035393             THRU 7980-CITC-EXIT-X
035393     END-IF.
035393
035393 7950-REQS-EVENT-X.
035393     EXIT.
035393
035393*---------------
035393 7970-CITU-EXIT.
035393*---------------
035393
035393     PERFORM
035393         VARYING WS-INDEX FROM 1     BY 1
035393         UNTIL   WS-INDEX > L0319-XTRNL-EVNT-CNT
035393
035393         IF  L0319-XTRNL-EVNT-PUBLISH (WS-INDEX)
035393
035393             PERFORM  CITU-0000-INIT-PARM-INFO
035393                 THRU CITU-0000-INIT-PARM-INFO-X
035393             MOVE MIR-CLI-ID         TO LCITU-CLI-ID
035393             MOVE L0319-XTRNL-EVNT-PGM-ID (WS-INDEX)
035393                                     TO LCITU-CALL-PGM-ID
035393             MOVE L0319-XTRNL-DOC-ID (WS-INDEX)
035393                                     TO LCITU-DOC-ID
035393             MOVE L0319-XTRNL-SYS-ID (WS-INDEX)
035393                                     TO LCITU-XTRNL-SYS-ID
035393             MOVE L0319-XTRNL-EVNT-ID
035393                                     TO LCITU-XTRNL-EVNT-ID
035393             PERFORM  CITU-1000-UW-CHANGE
035393                 THRU CITU-1000-UW-CHANGE-X
035393
035393         END-IF
035393     END-PERFORM.
035393
035393 7970-CITU-EXIT-X.
035393     EXIT.
035393
035393*---------------
035393 7980-CITC-EXIT.
035393*---------------
035393
035393     PERFORM
035393         VARYING WS-INDEX FROM 1     BY 1
035393         UNTIL   WS-INDEX > L0319-XTRNL-EVNT-CNT
035393
035393         IF  L0319-XTRNL-EVNT-PUBLISH (WS-INDEX)
035393
035393             PERFORM  CITC-0000-INIT-PARM-INFO
035393                 THRU CITC-0000-INIT-PARM-INFO-X
035393             MOVE RPOL-POL-ID        TO LCITC-POL-ID
035393             MOVE RPOL-SERV-BR-ID    TO LCITC-SERV-BR-ID
035393             MOVE RPOL-SERV-AGT-ID   TO LCITC-AGT-ID
035393             MOVE L0319-XTRNL-EVNT-PGM-ID (WS-INDEX)
035393                                     TO LCITC-CALL-PGM-ID
035393             MOVE L0319-XTRNL-DOC-ID (WS-INDEX)
035393                                     TO LCITC-DOC-ID
035393             MOVE L0319-XTRNL-SYS-ID (WS-INDEX)
035393                                     TO LCITC-XTRNL-SYS-ID
035393             MOVE L0319-XTRNL-EVNT-ID
035393                                     TO LCITC-XTRNL-EVNT-ID
035393             PERFORM  CITC-1000-PEND-POL-CHANGE
035393                 THRU CITC-1000-PEND-POL-CHANGE-X
035393
035393         END-IF
035393     END-PERFORM.
035393
035393 7980-CITC-EXIT-X.
035393     EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

           IF  MIR-POL-ID-BASE NOT = SPACES
           OR  MIR-POL-ID-SFX  NOT = SPACES
               MOVE 'P'               TO WGLOB-REF-POLICY-OR-CLIENT
               MOVE MIR-POL-ID-BASE   TO WGLOB-REF-POLICY-NUMBER
               MOVE MIR-POL-ID-SFX    TO WGLOB-REF-POLICY-SUFFIX
           ELSE

               IF  MIR-CLI-ID NOT = SPACES
                   MOVE 'C'           TO WGLOB-REF-POLICY-OR-CLIENT
                   MOVE MIR-CLI-ID    TO WGLOB-REF-CLIENT-NUMBER
               END-IF

           END-IF.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

035393     PERFORM  CITC-0000-INIT-PARM-INFO
035393         THRU CITC-0000-INIT-PARM-INFO-X.
035393
035393     PERFORM  CITU-0000-INIT-PARM-INFO
035393         THRU CITU-0000-INIT-PARM-INFO-X.
035393
026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0095-0000-INIT-PARM-INFO
025970         THRU 0095-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0220-0000-INIT-PARM-INFO
025970         THRU 0220-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
025970     PERFORM  0760-0000-INIT-PARM-INFO
025970         THRU 0760-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1030-0000-INIT-PARM-INFO
025970         THRU 1030-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1090-0000-INIT-PARM-INFO
025970         THRU 1090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2222-0000-INIT-PARM-INFO
025970         THRU 2222-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7180-0000-INIT-PARM-INFO
025970         THRU 7180-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-WORKING-STORAGE.
025970     INITIALIZE                         FREQUENTLY-USED-INDICES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-CLI-REQT-LIMIT      TO TRUE.
025970     SET WS-DEFAULT-POL-REQT-LIMIT      TO TRUE.
025970     SET WS-DEFAULT-REQT-LIMIT          TO TRUE.
025970     SET WS-DEFAULT-POLICIES-MAX        TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     MOVE SPACES                        TO WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPSPGA.

       COPY NCPELABC.
       COPY NCPERESL.

       COPY NCPPRFUP.
       COPY NCPPRVAL.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
016503 COPY NCPPCVGS.
      /
014221 COPY CCPPMBTS REPLACING ==:VAR1:== BY REQT
014221                         '$VAR2' BY 'REQT'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************

035393 COPY CCPSCITC.
035393 COPY CCPLCITC.
035393
035393 COPY CCPSCITU.
035393 COPY CCPLCITU.
035393
018764*COPY CCCL0289.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL0289.
016503 COPY CCPS0289.

018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.

018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.

018764*COPY CCCL2222.
018764 COPY CCPL2222.
016440 COPY CCPS2222.

018764*COPY NCCL0095.
018764 COPY NCPL0095.
       COPY NCPS0095.

018764*COPY NCCL0760.
025970 COPY NCPS0760.
018764 COPY NCPL0760.

018764*COPY NCCL1030.
018764 COPY NCPL1030.
       COPY NCPS1030.

018764*COPY NCCL1090.
018764 COPY NCPL1090.
       COPY NCPS1090.

018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.

018764*COPY NCCL7180.
018764 COPY NCPL7180.
       COPY NCPS7180.

021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.

018764*COPY XCCL0220.
025970 COPY XCPS0220.
018764 COPY XCPL0220.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
035393
035393 COPY XCPS0319.
035393 COPY XCPL0319.
035393
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
       COPY XCPL1680.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
       COPY CCPNPOL.
016503 COPY CCPUPOL.
       COPY CCPNSCOM.
014221 COPY NCPBREQT.
       COPY NCPNREQT.
       COPY NCPUREQT.
       COPY NCPNRTAB.
016503 COPY CCPNCVG.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************

026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM NSOM2362                        **
      *****************************************************************
