      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3030.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3030                                         **
      **  REMARKS:  PROCESS DRIVER FOR PBIL TRANSACTION              **
      **            BILL TYPE AND MODE MAINTENANCE.  THIS PROGRAM    **
      **            ALLOWS THE USER TO INQUIRE, BROWSE, MODIFY,      **
      **            CREATE AND DELETE BILL TYPE AND MODE COMBINATIONS**
      **            FOR A GIVEN PLAN/LOCATION GROUP.                 **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010649**  5.6       INITIAL CREATION                                 **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016395**  6.2       CREDIT CARD BILLING                              **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      /
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3030'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

016537*COPY CCWL0620.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 WS-SUB-DEFAULT              VALUE ZERO.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 I-DEFAULT                   VALUE ZERO.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
016548     05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
016548                                      BINARY.
025970         88 WS-MAX-BROWSE-LINES-DEFAULT          VALUE +12.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '0800'.
               88  WS-BUS-FCN-CREATE        VALUE '0801'.
               88  WS-BUS-FCN-UPDATE        VALUE '0802'.
               88  WS-BUS-FCN-DELETE        VALUE '0803'.
               88  WS-BUS-FCN-LIST          VALUE '0804'.
014221     05  WS-TWRK-KEY                  PIC X(04)  VALUE '0800'.
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '0800'.
           05  WS-PLAN-BILL-TYP-CD-CD                     PIC X(01).
               88  WS-PLAN-BILL-TYP-CD-VALID              VALUES
016395*            '1' '2' '3' '4' '5' '7' '8' '9' 'G' 'S' 'P'.
020467*            '1' '2' '3' '4' '5' '7' '8' '9' 'C' 'G' 'S' 'P'.
020467             '1' '2' '3' '4' '5' '7' '8' '9' 'C' 'D' 'G' 'S' 'P'.
               88  WS-PLAN-BILL-TYP-CD-DIRECT             VALUE '1'.
               88  WS-PLAN-BILL-TYP-CD-PDF                VALUE '2'.
               88  WS-PLAN-BILL-TYP-CD-PST-DT-CHQ         VALUE '3'.
               88  WS-PLAN-BILL-TYP-CD-PAC                VALUE '4'.
               88  WS-PLAN-BILL-TYP-CD-MILITARY           VALUE '5'.
               88  WS-PLAN-BILL-TYP-CD-WV-DISAB           VALUE '7'.
               88  WS-PLAN-BILL-TYP-CD-WV-DEATH           VALUE '8'.
               88  WS-PLAN-BILL-TYP-CD-APL                VALUE '9'.
020467         88  WS-PLAN-BILL-TYP-CD-DD2                VALUE 'D'.
               88  WS-PLAN-BILL-TYP-CD-OTHER-LIST         VALUE 'G'.
016395         88  WS-PLAN-BILL-TYP-CD-CRC                VALUE 'C'.
               88  WS-PLAN-BILL-TYP-CD-SINGLE             VALUE 'S'.
               88  WS-PLAN-BILL-TYP-CD-SALARY-DED         VALUE 'P'.

           05  WS-BILL-MODE-CD              PIC X(02).
               88  WS-BILL-MODE-VALID                     VALUES
                   '01' '03' '06' '12'.
           05  WS-DEFAULT-SWITCH            PIC X(01).
               88  WS-MORE-THAN-ONE-DFLT               VALUE  'Y'.
               88  WS-ONLY-ONE-DFLT                    VALUE  'N'.
014221/
014221 COPY CCWWLOCK.
      /
      ***************************************************************
      * BILL TYPE/MODE WORK AREA
      ***************************************************************
       COPY CCFRPBTM.
       COPY CCFWPBTM.
       COPY CCFHPBTM.
      /
      ***************************************************************
      * PLAN HEADER WORK AREA
      ***************************************************************
       COPY CCFRPH.
       COPY CCFWPH.
      /
014221*****************************************************************
014221*  CALLED MODULE PARAMETER INFORMATION                          *
014221*****************************************************************
014221 COPY XCWL8090.
014221/
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
      /
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3030.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.


      **********************
       2000-PROCESS-REQUEST.
      **********************

           SET  MIR-RETRN-OK       TO TRUE.
           MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.

           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *

           IF WS-BUS-FCN-RETRIEVE
           OR WS-BUS-FCN-UPDATE
           OR WS-BUS-FCN-DELETE
              PERFORM 2110-CHECK-PBTM
                 THRU 2110-CHECK-PBTM-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.


           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /

      *****************************************************************
      *   CHECK PBTM:
      *   ENSURE THAT THE BILL TYPE/BILL MODE ROW EXISTS.
      *****************************************************************
      *****************
       2110-CHECK-PBTM.
      *****************

014221     IF  WS-BUS-FCN-RETRIEVE
014221         MOVE MIR-PLAN-ID       TO WPH-PLAN-ID
014221         PERFORM PH-1000-READ-TWRK-TS
014221            THRU PH-1000-READ-TWRK-TS-X
014221         IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221            MOVE WPH-PLAN-ID    TO WGLOB-MSG-PARM (1)
014221            MOVE 'PH'           TO WGLOB-MSG-PARM (2)
014221            MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221            PERFORM  0260-1000-GENERATE-MESSAGE
014221                THRU 0260-1000-GENERATE-MESSAGE-X
014221            GO TO 2110-CHECK-PBTM-X
014221         END-IF
014221     END-IF.

           MOVE MIR-PLAN-ID           TO WPBTM-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPBTM-LOC-GR-ID.
           MOVE MIR-PLAN-BILL-TYP-CD  TO WPBTM-PLAN-BILL-TYP-CD.
           MOVE MIR-PLAN-BILL-MODE-CD TO WPBTM-PLAN-BILL-MODE-CD.

           PERFORM 8100-READ-PBTM-INFO
              THRU 8100-READ-PBTM-INFO-X.

       2110-CHECK-PBTM-X.
           EXIT.
      /
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *******************
       3500-PROCESS-LIST.
      *******************

      ****************************************************************
      * EACH RECORD OF THE BROWSE SCREEN.  THIS WILL ALLOW
      * USERS TO CHOOSE A RECORD(S) TO PERFORM INQUIRE,
      * MAINTAIN OR DELETE PROCESSING FOR THE BILL TYPE/BILL MODE
      * RECORD SELECTED.
      *
      *  CHECK ENTER CODE FIELDS FOR INPUT
      ****************************************************************

           MOVE SPACES                TO MIR-LOC-GR-ID-G.
           MOVE SPACES                TO MIR-PLAN-BILL-TYP-CD-G.
           MOVE SPACES                TO MIR-PLAN-BILL-MODE-CD-G.
           MOVE SPACES                TO MIR-PLAN-BILL-DFLT-IND-G.

           MOVE LOW-VALUES            TO WPBTM-KEY.
           MOVE HIGH-VALUES           TO WPBTM-ENDBR-KEY.

           IF  MIR-PLAN-ID = SPACES
      *MSG:    PLAN ID IS REQUIRED
               MOVE 'CS30300001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO  TO  3500-PROCESS-LIST-X
           END-IF.

           MOVE MIR-PLAN-ID           TO WPBTM-PLAN-ID.
           MOVE MIR-PLAN-ID           TO WPBTM-ENDBR-PLAN-ID.

           IF  MIR-LOC-GR-ID = SPACES
               CONTINUE
           ELSE
               MOVE MIR-LOC-GR-ID     TO WPBTM-LOC-GR-ID
           END-IF.

           IF  MIR-PLAN-BILL-TYP-CD = SPACES
               CONTINUE
           ELSE
               MOVE MIR-PLAN-BILL-TYP-CD
                                      TO WPBTM-PLAN-BILL-TYP-CD
           END-IF.

           IF  MIR-PLAN-BILL-MODE-CD = SPACES
               CONTINUE
           ELSE
               MOVE MIR-PLAN-BILL-MODE-CD
                                      TO WPBTM-PLAN-BILL-MODE-CD
           END-IF.

           PERFORM PBTM-1000-BROWSE
              THRU PBTM-1000-BROWSE-X.

           PERFORM PBTM-2000-READ-NEXT
              THRU PBTM-2000-READ-NEXT-X.

           IF NOT WPBTM-IO-OK
           OR WPBTM-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM PBTM-3000-END-BROWSE
                  THRU PBTM-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WPBTM-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM PBTM-3000-END-BROWSE
              THRU PBTM-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      /
      *********************
       4000-PROCESS-CREATE.
      *********************

           MOVE MIR-PLAN-ID           TO WPBTM-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPBTM-LOC-GR-ID.
           MOVE MIR-PLAN-BILL-TYP-CD  TO WPBTM-PLAN-BILL-TYP-CD.
           MOVE MIR-PLAN-BILL-MODE-CD TO WPBTM-PLAN-BILL-MODE-CD.

           PERFORM PBTM-1000-READ
              THRU PBTM-1000-READ-X.

           IF  WPBTM-IO-OK
               MOVE WPBTM-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  BILL TYPE/BILL MODE OPTIONS KEY FIELD EDITS.
      *
           PERFORM 5300-EDIT-PBTM-KEY-FIELDS
              THRU 5300-EDIT-PBTM-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW = 0
               CONTINUE
           ELSE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.
      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM PBTM-1000-CREATE
              THRU PBTM-1000-CREATE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM PBTM-1000-WRITE
              THRU PBTM-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PBTM-1000-CALL-AUDIT
                  THRU PBTM-1000-CALL-AUDIT-X
           END-IF.

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X.
014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID    TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'           TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4000-PROCESS-CREATE-X
014221     END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /

      *********************
       5000-PROCESS-UPDATE.
      *********************
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM PBTM-1000-READ-FOR-UPDATE
              THRU PBTM-1000-READ-FOR-UPDATE-X.

           IF  WPBTM-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PBTM-1000-CALL-AUDIT
                      THRU PBTM-1000-CALL-AUDIT-X
               END-IF
           ELSE
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

      *   SAVE PLAN BILLING OPTION RECORD IN HOLD AREA
           MOVE RPBTM-REC-INFO        TO HPBTM-REC-INFO.

           PERFORM 5310-EDIT-PBTM-DATA-FIELDS
              THRU 5310-EDIT-PBTM-DATA-FIELDS-X.

      *   RESTORE PLAN BILLING OPTION RECORD FROM HOLD AREA
           MOVE HPBTM-REC-INFO        TO RPBTM-REC-INFO.
           MOVE HPBTM-KEY             TO WPBTM-KEY.


           IF  WGLOB-MSG-ERROR-SW = 0
               PERFORM PBTM-2000-REWRITE
                  THRU PBTM-2000-REWRITE-X
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PBTM-1000-CALL-AUDIT
                      THRU PBTM-1000-CALL-AUDIT-X
               END-IF
014221         PERFORM PH-2000-REWRITE
014221            THRU PH-2000-REWRITE-X
014221         PERFORM PH-1000-READ-TWRK-TS
014221            THRU PH-1000-READ-TWRK-TS-X
014221     ELSE
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
      *MSG:    MAINTENANCE COMPLETE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.

      /
      ***************************
       5300-EDIT-PBTM-KEY-FIELDS.
      ***************************

           MOVE MIR-PLAN-ID            TO WPH-PLAN-ID.

           PERFORM PH-1000-READ
              THRU PH-1000-READ-X.

           IF  WPH-IO-OK
               CONTINUE
           ELSE
      *MSG:    'INVALID PLAN/RS'
               MOVE 'CS30300003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5300-EDIT-PBTM-KEY-FIELDS-X
           END-IF.

           MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.

           PERFORM LCGP-1000-EDIT-LCGP-LOCATION
              THRU LCGP-1000-EDIT-LCGP-LOCATION-X.

           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *MSG:    'INVALID LOCATION GROUP.  MUST BE IN EDIT/LOCGP'
               MOVE 'CS30300004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5300-EDIT-PBTM-KEY-FIELDS-X
           END-IF.


           MOVE MIR-PLAN-BILL-TYP-CD  TO WS-PLAN-BILL-TYP-CD-CD.

           IF  WS-PLAN-BILL-TYP-CD-VALID
               CONTINUE
           ELSE
      *MSG:    'VALID BILL TYPES ARE (@1)'
               MOVE 'CS30300005'      TO WGLOB-MSG-REF-INFO
               MOVE '1, 2, 3, 4, 5, 7, 8, 9, G, S, P'
                                      TO WGLOB-MSG-PARM(01)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5300-EDIT-PBTM-KEY-FIELDS-X
           END-IF.

           MOVE MIR-PLAN-BILL-MODE-CD TO WS-BILL-MODE-CD.

           IF  WS-BILL-MODE-VALID
               CONTINUE
           ELSE
      *MSG:    'BILL MODE MUST BE ONE OF (@1)'
               MOVE 'CS30300006'      TO WGLOB-MSG-REF-INFO
               MOVE '01, 03, 06, 12'  TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5300-EDIT-PBTM-KEY-FIELDS-X
           END-IF.

       5300-EDIT-PBTM-KEY-FIELDS-X.
           EXIT.

      ****************************
       5310-EDIT-PBTM-DATA-FIELDS.
      ****************************

           EVALUATE MIR-PLAN-BILL-DFLT-IND
               WHEN 'N'
                    MOVE MIR-PLAN-BILL-DFLT-IND
                                      TO HPBTM-PLAN-BILL-DFLT-IND

               WHEN 'Y'
                    PERFORM 5320-CHECK-FOR-OTHER-DEFAULT
                       THRU 5320-CHECK-FOR-OTHER-DEFAULT-X
                    IF  WS-MORE-THAN-ONE-DFLT
      *MSG:    'ONLY ONE DEFAULT BILL TYPE AND MODE ALLOWED'
                        MOVE 'CS30300007'
                                      TO WGLOB-MSG-REF-INFO
                        PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                    ELSE
                        MOVE MIR-PLAN-BILL-DFLT-IND
                                      TO HPBTM-PLAN-BILL-DFLT-IND
                    END-IF

               WHEN OTHER
      *MSG:    'DEFAULT INDICATOR MUST BE Y OR N
                    MOVE 'CS30300008' TO WGLOB-MSG-REF-INFO
                    PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

       5310-EDIT-PBTM-DATA-FIELDS-X.
           EXIT.

      /
      *****************************************************************
      *   CHECK FOR OTHER DEFAULT:                                    *
      *       ONLY ONE DEFAULT VALUE (OF 'Y') IS ALLOWED PER LOCATION *
      *       GROUP.  CHECK TO MAKE SURE THAT NO OTHERS EXIST.        *
      *****************************************************************
      *----------------------------
       5320-CHECK-FOR-OTHER-DEFAULT.
      *----------------------------

           MOVE LOW-VALUES            TO WPBTM-KEY.
           MOVE HIGH-VALUES           TO WPBTM-ENDBR-KEY.

           MOVE MIR-PLAN-ID           TO WPBTM-PLAN-ID.
           MOVE MIR-PLAN-ID           TO WPBTM-ENDBR-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPBTM-LOC-GR-ID.
           MOVE MIR-LOC-GR-ID         TO WPBTM-ENDBR-LOC-GR-ID.

           SET WS-ONLY-ONE-DFLT        TO TRUE.

           PERFORM  PBTM-1000-BROWSE
               THRU PBTM-1000-BROWSE-X.

           PERFORM
               UNTIL NOT WPBTM-IO-OK
                  OR RPBTM-PLAN-BILL-DFLT-IND = 'Y'
               PERFORM  PBTM-2000-READ-NEXT
                   THRU PBTM-2000-READ-NEXT-X
           END-PERFORM.

           IF  WPBTM-IO-OK
               SET WS-MORE-THAN-ONE-DFLT  TO TRUE
           END-IF.

           PERFORM  PBTM-3000-END-BROWSE
               THRU PBTM-3000-END-BROWSE-X.

       5320-CHECK-FOR-OTHER-DEFAULT-X.
           EXIT.

      /
      *********************
       6000-PROCESS-DELETE.
      *********************
      ***************************************************************
      * DELETE PROCESSING PART 2 CONSISTS OF DELETING THE
      * RECORD (BACKOUTS ARE HANDLED IN THE MAINLINE).
      *
      * BUILD PBTM KEY FROM KEY AREA ON SCREEN.
      ***************************************************************

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  8050-BUILD-PBTM-KEY
               THRU 8050-BUILD-PBTM-KEY-X.

           PERFORM PBTM-1000-READ-FOR-UPDATE
              THRU PBTM-1000-READ-FOR-UPDATE-X.

           IF  WPBTM-IO-OK
               PERFORM 6210-PROCESS-DELETE-PART-2
                  THRU 6210-PROCESS-DELETE-PART-2-X
           ELSE
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WPBTM-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      ****************************
       6210-PROCESS-DELETE-PART-2.
      ****************************

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PBTM-1000-CALL-AUDIT
                  THRU PBTM-1000-CALL-AUDIT-X
           END-IF.

           PERFORM PBTM-1000-DELETE
              THRU PBTM-1000-DELETE-X.

           IF  WPBTM-IO-OK
      *MSG:    DELETE COMPLETED MESSAGE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PBTM-1000-CALL-AUDIT
                      THRU PBTM-1000-CALL-AUDIT-X
               END-IF
014221         PERFORM  PH-2000-REWRITE
014221             THRU PH-2000-REWRITE-X
014221         PERFORM  PH-1000-READ-TWRK-TS
014221             THRU PH-1000-READ-TWRK-TS-X
           ELSE
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WPBTM-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

       6210-PROCESS-DELETE-PART-2-X.
           EXIT.
      /
      *********************
       8050-BUILD-PBTM-KEY.
      *********************

           MOVE MIR-PLAN-ID           TO WPBTM-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPBTM-LOC-GR-ID.
           MOVE MIR-PLAN-BILL-TYP-CD  TO WPBTM-PLAN-BILL-TYP-CD.
           MOVE MIR-PLAN-BILL-MODE-CD TO WPBTM-PLAN-BILL-MODE-CD.

       8050-BUILD-PBTM-KEY-X.
           EXIT.
      /
      **********************
       8100-READ-PBTM-INFO.
      **********************

           IF  RPBTM-PLAN-ID   = WPBTM-PLAN-ID
           AND RPBTM-LOC-GR-ID = WPBTM-LOC-GR-ID
           AND RPBTM-PLAN-BILL-TYP-CD  = WPBTM-PLAN-BILL-TYP-CD
           AND RPBTM-PLAN-BILL-MODE-CD = WPBTM-PLAN-BILL-MODE-CD
               GO TO 8100-READ-PBTM-INFO-X
           END-IF.

           PERFORM PBTM-1000-READ
              THRU PBTM-1000-READ-X.

           IF WPBTM-IO-NOT-FOUND
      *MSG:    "RECORD NOT FOUND"
               MOVE WPBTM-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8100-READ-PBTM-INFO-X.
           EXIT.
      /
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      ************************
       9100-BLANK-DATA-FIELDS.
      ************************

           IF WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-LOC-GR-ID-G
               MOVE SPACES            TO MIR-PLAN-BILL-TYP-CD-G
               MOVE SPACES            TO MIR-PLAN-BILL-MODE-CD-G
               MOVE SPACES            TO MIR-PLAN-BILL-DFLT-IND-G
           ELSE
               MOVE SPACES            TO MIR-PLAN-BILL-DFLT-IND
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************

           IF WS-BUS-FCN-LIST
               PERFORM 9210-MOVE-PBTM-TO-SCRN-1
                  THRU 9210-MOVE-PBTM-TO-SCRN-1-X
                VARYING I FROM 1 BY 1
                  UNTIL I > WS-MAX-BROWSE-LINES
                     OR WPBTM-IO-EOF

               IF  NOT WPBTM-IO-EOF
                   MOVE RPBTM-PLAN-ID TO MIR-PLAN-ID
                   MOVE RPBTM-LOC-GR-ID
                                      TO MIR-LOC-GR-ID
                   MOVE RPBTM-PLAN-BILL-TYP-CD
                                      TO MIR-PLAN-BILL-TYP-CD
                   MOVE RPBTM-PLAN-BILL-MODE-CD
                                      TO MIR-PLAN-BILL-MODE-CD
               END-IF
           ELSE
               MOVE RPBTM-PLAN-BILL-DFLT-IND
                                      TO MIR-PLAN-BILL-DFLT-IND
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      /
      **************************
       9210-MOVE-PBTM-TO-SCRN-1.
      **************************

           MOVE RPBTM-LOC-GR-ID       TO MIR-LOC-GR-ID-T (I).
           MOVE RPBTM-PLAN-BILL-TYP-CD
                                      TO MIR-PLAN-BILL-TYP-CD-T  (I).
           MOVE RPBTM-PLAN-BILL-MODE-CD
                                     TO MIR-PLAN-BILL-MODE-CD-T  (I).
           MOVE RPBTM-PLAN-BILL-DFLT-IND
                                     TO MIR-PLAN-BILL-DFLT-IND-T (I).


           PERFORM PBTM-2000-READ-NEXT
              THRU PBTM-2000-READ-NEXT-X.

       9210-MOVE-PBTM-TO-SCRN-1-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-SUB-DEFAULT TO TRUE.
025970     SET I-DEFAULT TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.

       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
       COPY CCPNEDIT.
       COPY CCPELCGP.
      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
016537*COPY CCPL0620.
018764*COPY CCCLPBTM.
018764 COPY CCPLPBTM.
      /
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY CCPNPH.
014221 COPY CCPUPH.
      /
       COPY CCPAPBTM.
       COPY CCPNPBTM.
       COPY CCPBPBTM.
       COPY CCPCPBTM.
       COPY CCPUPBTM.
       COPY CCPXPBTM.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM CSOM3030                       *
      ******************************************************************
