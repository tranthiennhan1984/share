      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2562.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2562                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE IPRD TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2562'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-CONSTANTS.
               10  WS-TWRK-KEY               PIC X(04)
                                             VALUE '2562'.
025970             88  WS-TWRK-KEY-DEFAULT   VALUE '2562'.
               10  WS-MAX                    PIC S9(03)       COMP-3
                                             VALUE 139.
025970             88  WS-MAX-DEFAULT             VALUE 139.
               10  WS-FND-COUNT-MIN          PIC S9(03)       COMP-3
                                             VALUE 2.
025970             88  WS-FND-COUNT-MIN-DEFAULT   VALUE 2.


           05  WS-VARIABLES.
               10  WS-BUS-FCN-ID             PIC X(04).
                   88  WS-BUS-FCN-UPDATE     VALUE '2562'.
               10  WS-DATA-EDIT-SW           PIC X(01).
                   88  WS-DATA-EDIT-ERRORS   VALUE 'Y'.
                   88  WS-DATA-EDIT-NOERRORS VALUE 'N'.
               10  WS-STATUS-SW              PIC X(01).
                   88  WS-STATUS-UNKNOWN     VALUE SPACE.
                   88  WS-STATUS-TO-ACTV     VALUE 'A'.
               10  WS-CODE.
                   15  WS-F-P-CD             PIC X(01).
                       88  WS-CODE-NONE      VALUE SPACE.
                       88  WS-CODE-BLCH      VALUE '*'.
                       88  WS-CODE-PLAN      VALUE 'P'.
                       88  WS-CODE-FND       VALUE 'F'.
                   15  WS-FND-PLAN-ID        PIC X(06).
               10  WS-PRFL-PCT-IND           PIC X(01).
                   88  WS-PRFL-PCT-YES       VALUE 'Y'.
                   88  WS-PRFL-PCT-NO        VALUE 'N'.
               10  WS-PRFLD-EFF-DT           PIC X(10).
               10  WS-PRFLD-SEQ-NUM          PIC 9(03).
               10  WS-FND-SEQ-NUM            PIC 9(03).
               10  WS-TOT-INITIAL            PIC S9(03)V9(04) COMP-3.
               10  WS-TOT-SUBSEQ             PIC S9(03)V9(04) COMP-3.
               10  WS-FND-COUNT              PIC S9(03)       COMP-3.
               10  WS-COUNT                  PIC S9(03)       COMP-3.
               10  WS-F-P-COUNT              PIC S9(03)       COMP-3.
               10  WS-LCF-FOUND-IND          PIC X(01).
                   88  WS-LCF-FOUND-Y        VALUE 'Y'.
                   88  WS-LCF-FOUND-N        VALUE 'N'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY FCWLFUND.
       COPY XCWWWKDT.
       COPY XCWL8090.
       COPY XCWL8960.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWIPRD.
       COPY CCFRIPRD.
       COPY CCFWIPRO.
       COPY CCFRIPRO.

       COPY CCFWIPDF.
       COPY CCFRIPDF.
       COPY CCFRPD.
       COPY CCFWPD.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2562.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2562'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------
       2000-UPDATE.
      *-----------
      *
      *  THE RECORD MUST EXIST, AND HAVE A CURRENT TIMESTAMP
      *
           SET WS-DATA-EDIT-NOERRORS   TO TRUE.
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  IPRO-2000-UPDATE-TWRK-TS
               THRU IPRO-2000-UPDATE-TWRK-TS-X.

           IF  WIPRO-IO-NOT-FOUND
      *MSG: INVESTOR PROFILE RECORD (@1) DOES NOT EXIST
               MOVE MIR-PRFL-ID
                                       TO WGLOB-MSG-PARM (1)
               MOVE 'CS25620001'
                                       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                                       TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2'
               MOVE 'XS00000303'
                                       TO WGLOB-MSG-REF-INFO
               MOVE 'IPRO'
                                       TO WGLOB-MSG-PARM (1)
               MOVE WIPRO-KEY
                                       TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  IPRD-1000-READ
               THRU IPRD-1000-READ-X.

           IF  WIPRD-IO-NOT-FOUND
      *MSG: INVESTOR PROFILE RECORD (@1) DOES NOT EXIST
               MOVE MIR-PRFL-ID
                                       TO WGLOB-MSG-PARM (1)
               MOVE 'CS25620001'
                                       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                                       TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WS-DATA-EDIT-ERRORS
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

      * UPDATE EXISTING 'ACTIVE' RECORD STATUS IF APPLICABLE

           IF NOT RIPRD-PRFLD-STAT-PEND
              PERFORM  8400-UPDATE-ACTIVE-IPRD
                  THRU 8400-UPDATE-ACTIVE-IPRD-X
           END-IF.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  8500-MOVE-DATA
               THRU 8500-MOVE-DATA-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

      *  UPDATE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  IPRO-2000-REWRITE
               THRU IPRO-2000-REWRITE-X.

       2000-UPDATE-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WIPRD-KEY.
           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.
           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.

           MOVE MIR-PRFLD-EFF-DT       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                       TO WS-PRFLD-EFF-DT
               MOVE WS-PRFLD-EFF-DT    TO WIPRD-PRFLD-EFF-DT

           ELSE
      *MSG: INVALID EFFECTIVE DATE
               MOVE 'CS25620002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           MOVE MIR-PRFLD-SEQ-NUM      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-INPUT-SIZE.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           SET L0280-SPACES-PERMITTED  TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT       TO WS-PRFLD-SEQ-NUM
               MOVE WS-PRFLD-SEQ-NUM   TO WIPRD-PRFLD-SEQ-NUM
           ELSE
      *MSG: SEQUENCE NUMBER MUST BE VALID NUMERIC
               MOVE 'CS25620003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *--------------------
       8000-EDITS.
      *--------------------

           PERFORM  8100-EDIT-PRFLD-STAT-CD
               THRU 8100-EDIT-PRFLD-STAT-CD-X.

           PERFORM  8200-EDIT-PRFLD-POL-CHNG-DT
               THRU 8200-EDIT-PRFLD-POL-CHNG-DT-X.

           PERFORM  8300-EDIT-IPDF
               THRU 8300-EDIT-IPDF-X.

       8000-EDITS-X.
           EXIT.

      *------------------------
       8100-EDIT-PRFLD-STAT-CD.
      *------------------------

           IF  RIPRD-PRFLD-STAT-CD = MIR-PRFLD-STAT-CD
               GO TO 8100-EDIT-PRFLD-STAT-CD-X
           END-IF.

           SET WS-STATUS-UNKNOWN       TO TRUE.
           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PRFLD-STAT-CD'        TO L8960-AV-TBL-CD.
           MOVE MIR-PRFLD-STAT-CD      TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  NOT L8960-RETRN-OK
      *MSG: INVESTOR PROFILE STATUS MUST BE VALID
               MOVE 'CS25620004'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.

           EVALUATE TRUE

           WHEN RIPRD-PRFLD-STAT-HIST
      *MSG: PROFILE STATUS (@1) IS HISTORY - UPDATE PROCESS CANCELLED
               MOVE 'CS25620005'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE

           WHEN RIPRD-PRFLD-STAT-ACTV
      *MSG: PROFILE STATUS (@1) CAN ONLY BE CHANGED FROM PENDING TO
      *     ACTIVE
               MOVE 'CS25620006'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE

           WHEN OTHER
               MOVE MIR-PRFLD-STAT-CD  TO RIPRD-PRFLD-STAT-CD
               IF  NOT RIPRD-PRFLD-STAT-ACTV
      *MSG: PROFILE STATUS (@1) CAN ONLY BE CHANGED FROM PENDING TO
      *     ACTIVE
                   MOVE 'CS25620006'   TO WGLOB-MSG-REF-INFO
                   MOVE MIR-PRFL-ID    TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-DATA-EDIT-ERRORS
                                       TO TRUE
               ELSE
                   SET WS-STATUS-TO-ACTV
                                       TO TRUE
                   IF  WS-PRFLD-EFF-DT >  WGLOB-PROCESS-DATE
      *MSG: EFFECTIVE DATE CANNOT BE IN THE FUTURE WHEN PROFILE STATUS
      *     IS CHANGED ACTIVE
                       MOVE 'CS25620007'
                                       TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       SET WS-DATA-EDIT-ERRORS
                                       TO TRUE
                   END-IF
               END-IF
           END-EVALUATE.

       8100-EDIT-PRFLD-STAT-CD-X.
           EXIT.
      /
      *----------------------------
       8200-EDIT-PRFLD-POL-CHNG-DT.
      *----------------------------

           IF  MIR-PRFLD-POL-CHNG-DT = RIPRD-PRFLD-POL-CHNG-DT
               GO TO 8200-EDIT-PRFLD-POL-CHNG-DT-X
           END-IF.

           IF  MIR-PRFLD-POL-CHNG-DT NOT = SPACE
      *MSG: POLICY MODIFICATION DATE CAN ONLY BE UPDATED TO SPACES
               MOVE 'CS25620008'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.

       8200-EDIT-PRFLD-POL-CHNG-DT-X.
           EXIT.
      /

      *---------------
       8300-EDIT-IPDF.
      *---------------

           MOVE ZERO                   TO WS-FND-COUNT.
           MOVE ZERO                   TO WS-FND-SEQ-NUM.
           MOVE ZERO                   TO WS-TOT-INITIAL.
           MOVE ZERO                   TO WS-TOT-SUBSEQ.
           MOVE MIR-DV-PRFLDF-PCT-IND  TO WS-PRFL-PCT-IND.
           
           PERFORM  8310-EDIT-IPDF-ROW
               THRU 8310-EDIT-IPDF-ROW-X
               VARYING WS-COUNT FROM 1 BY 1
               UNTIL   WS-COUNT > WS-MAX.

           IF  WS-FND-COUNT < WS-FND-COUNT-MIN
      *MSG: THERE MUST BE AT LEAST TWO FUNDS
               MOVE 'CS25620015'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.

           IF  WS-FND-COUNT > LFUND-FND-MAX-CTR
      *MSG: TOTAL NUMBER OF FUNDS FOR PROFILE (@1) EXCEEDS LIMITATION
               MOVE 'CS25620016'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
               GO TO 8300-EDIT-IPDF-X 
           END-IF.

           IF WS-TOT-INITIAL NOT = 100
      *MSG: TOTAL INITIAL ALLOCATIONS MUST EQUAL 100%
               MOVE 'CS25620010'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.

           IF  WS-PRFL-PCT-NO
           AND WS-TOT-SUBSEQ NOT = 100
      *MSG: TOTAL SUBSEQUENT ALLOCATIONS MUST EQUAL 100%
               MOVE 'CS25620017'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.

       8300-EDIT-IPDF-X.
           EXIT.

      *-------------------
       8310-EDIT-IPDF-ROW.
      *-------------------

           MOVE MIR-DV-PRFLDF-FND-PLAN-ID-T (WS-COUNT)
                                       TO WS-CODE.
                                       
           IF WS-COUNT > 1
              PERFORM  8340-XREF-FUND-PLAN
                  THRU 8340-XREF-FUND-PLAN-X
                  VARYING WS-F-P-COUNT FROM 1 BY 1
                  UNTIL   WS-F-P-COUNT > WS-FND-SEQ-NUM
                  OR WS-DATA-EDIT-ERRORS
           END-IF.

           EVALUATE TRUE
               WHEN WS-CODE-NONE
               WHEN WS-CODE-BLCH
                   GO TO 8310-EDIT-IPDF-ROW-X
               WHEN WS-CODE-FND
                   ADD 1               TO WS-FND-COUNT
               WHEN WS-CODE-PLAN
      * CHECK TO SEE IF LCF PLAN
                   PERFORM  8320-LCF-CHECK
                       THRU 8320-LCF-CHECK-X
                   IF WS-LCF-FOUND-Y
      *MSG: LCF PLAN (@1) NOT ALLOWED ON PROFILE
                       MOVE 'CS25620019'   TO WGLOB-MSG-REF-INFO
                       MOVE WS-FND-PLAN-ID TO WGLOB-MSG-PARM (01)
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       SET WS-DATA-EDIT-ERRORS TO TRUE
                   END-IF
                   ADD 1               TO WS-FND-COUNT
               WHEN OTHER
      *MSG: ENTER EITHER FUND ID OR PLAN ID
                   MOVE 'CS25620011'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-DATA-EDIT-ERRORS
                                       TO TRUE
           END-EVALUATE.

           ADD 1                       TO WS-FND-SEQ-NUM.

           MOVE MIR-PRFLDF-INIT-PCT-T (WS-COUNT)
                                       TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PRFLDF-INIT-PCT-T (1)
                                       TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1
           MOVE 4                      TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           SET L0280-SPACES-PERMITTED  TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               ADD L0280-OUTPUT-V04    TO WS-TOT-INITIAL
           ELSE
      *MSG: INVALID ALLOCATION PERCENT. PLEASE RE-ENTER
               MOVE 'CS25620012'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.

           IF  WS-PRFL-PCT-YES
               MOVE MIR-PRFLDF-INIT-PCT-T (WS-COUNT)   
                                TO MIR-PRFLDF-SUBSEQ-PCT-T (WS-COUNT)
               ADD L0280-OUTPUT-V04    TO WS-TOT-SUBSEQ
               GO TO 8310-EDIT-IPDF-ROW-X
           END-IF.

           MOVE MIR-PRFLDF-SUBSEQ-PCT-T (WS-COUNT)
                                       TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PRFLDF-SUBSEQ-PCT-T (1)
                                       TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1
           MOVE 4                      TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           SET L0280-SPACES-PERMITTED  TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               ADD L0280-OUTPUT-V04    TO WS-TOT-SUBSEQ
           ELSE
      *MSG: INVALID ALLOCATION PERCENT. PLEASE RE-ENTER
               MOVE 'CS25620012'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.
           
       8310-EDIT-IPDF-ROW-X.
           EXIT.

      *---------------
       8320-LCF-CHECK.
      *---------------
           SET WS-LCF-FOUND-N TO TRUE.
      * NEED TO READ PD TO SEE IF THE PLAN IS A LOAN COLLATERAL FUND
      * AS THESE ARE NOT ALLOWED ON A PROFILE.
           MOVE WS-FND-PLAN-ID TO WPD-PLAN-ID.

           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.

           IF RPD-PLAN-COLFND
               SET WS-LCF-FOUND-Y TO TRUE
           END-IF.

       8320-LCF-CHECK-X.
           EXIT.

      *-------------------
       8340-XREF-FUND-PLAN.
      *-------------------

           IF WS-CODE = MIR-DV-PRFLDF-FND-PLAN-ID-T (WS-F-P-COUNT)
      *MSG: THE SAME FUND/PLAN CANNOT BE SELECTED MORE THAN ONCE ON
      *     THE SAME INVESTOR PROFILE DETAIL RECORD
               MOVE 'CS25620018'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.

       8340-XREF-FUND-PLAN-X.
           EXIT.

      /
      *------------------------
       8400-UPDATE-ACTIVE-IPRD.
      *------------------------

           MOVE LOW-VALUE              TO WIPRD-KEY.
           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.
           MOVE WWKDT-HIGH-DT          TO WIPRD-PRFLD-EFF-DT.
           MOVE 999                    TO WIPRD-PRFLD-SEQ-NUM.

           MOVE WIPRD-KEY              TO WIPRD-ENDBR-KEY.
           MOVE WWKDT-LOW-DT           TO WIPRD-ENDBR-PRFLD-EFF-DT.
           MOVE ZERO                   TO WIPRD-ENDBR-PRFLD-SEQ-NUM.

           PERFORM  IPRD-1000-BROWSE-PREV
               THRU IPRD-1000-BROWSE-PREV-X.

           MOVE SPACE                  TO RIPRD-PRFLD-STAT-CD.

           PERFORM  IPRD-2000-READ-PREV
               THRU IPRD-2000-READ-PREV-X
               UNTIL NOT WIPRD-IO-OK
               OR RIPRD-PRFLD-STAT-ACTV.

           IF  NOT WIPRD-IO-OK
               PERFORM  IPRD-3000-END-BROWSE-PREV
                   THRU IPRD-3000-END-BROWSE-PREV-X
               GO TO 8400-UPDATE-ACTIVE-IPRD-X
           END-IF.

           IF  RIPRD-PRFLD-STAT-ACTV
           AND RIPRD-PRFLD-EFF-DT > WS-PRFLD-EFF-DT
      *MSG: EFFECTIVE DATE OF CURRENT ACTIVE RECORD >= EFFECTIVE DATE
      *     OF PENDING RECORD
               MOVE 'CS25620013'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DATA-EDIT-ERRORS TO TRUE
           END-IF.

           PERFORM  IPRD-3000-END-BROWSE-PREV
               THRU IPRD-3000-END-BROWSE-PREV-X.

           IF  WS-DATA-EDIT-ERRORS
               GO TO 8400-UPDATE-ACTIVE-IPRD-X
           END-IF.

           PERFORM  IPRD-1000-READ-FOR-UPDATE
               THRU IPRD-1000-READ-FOR-UPDATE-X.

           IF  NOT WIPRD-IO-OK
      *MSG: READ ERROR ON INVESTOR PROFILE DETAIL
               MOVE 'CS25620014'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET RIPRD-PRFLD-STAT-HIST
                                       TO TRUE
               PERFORM  IPRD-2000-REWRITE
                   THRU IPRD-2000-REWRITE-X
           END-IF.

       8400-UPDATE-ACTIVE-IPRD-X.
           EXIT.

      *---------------
       8500-MOVE-DATA.
      *---------------

           MOVE ZERO                   TO WS-FND-SEQ-NUM.
           PERFORM  8510-UPDATE-IPDF
               THRU 8510-UPDATE-IPDF-X
               VARYING WS-COUNT FROM 1 BY 1
               UNTIL   WS-COUNT > WS-MAX.

           IF  WGLOB-RETURN-ERROR
               GO TO 8500-MOVE-DATA-X
           END-IF.

           PERFORM  8520-DELETE-OLD-IPDF
               THRU 8520-DELETE-OLD-IPDF-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 8500-MOVE-DATA-X
           END-IF.

           PERFORM  8530-UPDATE-IPRD
               THRU 8530-UPDATE-IPRD-X.

       8500-MOVE-DATA-X.
           EXIT.

      *-----------------
       8510-UPDATE-IPDF.
      *-----------------

           MOVE MIR-DV-PRFLDF-FND-PLAN-ID-T (WS-COUNT)
                                       TO WS-CODE.

           IF  WS-CODE-NONE
           OR  WS-CODE-BLCH
               GO TO 8510-UPDATE-IPDF-X
           END-IF.

           ADD  1                      TO WS-FND-SEQ-NUM.
           MOVE MIR-PRFL-ID            TO WIPDF-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPDF-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPDF-PRFLD-SEQ-NUM.

           MOVE WS-FND-SEQ-NUM         TO WIPDF-PRFLDF-SEQ-NUM.

           PERFORM  IPDF-1000-READ-FOR-UPDATE
               THRU IPDF-1000-READ-FOR-UPDATE-X.
      
           IF  NOT WIPDF-IO-OK
               PERFORM  IPDF-1000-CREATE
                   THRU IPDF-1000-CREATE-X
               PERFORM  8515-SETUP-IPDF-FIELDS
                   THRU 8515-SETUP-IPDF-FIELDS-X
               PERFORM  IPDF-1000-WRITE
                   THRU IPDF-1000-WRITE-X
           ELSE
               PERFORM  8515-SETUP-IPDF-FIELDS
                   THRU 8515-SETUP-IPDF-FIELDS-X
               PERFORM  IPDF-2000-REWRITE
                   THRU IPDF-2000-REWRITE-X
           END-IF.
      
       8510-UPDATE-IPDF-X.
           EXIT.

      *-----------------------
       8515-SETUP-IPDF-FIELDS.
      *-----------------------
      
           IF  WS-CODE-FND
               MOVE WS-FND-PLAN-ID     TO RIPDF-FND-ID
               MOVE SPACE              TO RIPDF-PLAN-ID
           ELSE
               MOVE WS-FND-PLAN-ID     TO RIPDF-PLAN-ID
               MOVE SPACE              TO RIPDF-FND-ID
           END-IF.

           MOVE MIR-PRFLDF-INIT-PCT-T (WS-COUNT)
                                       TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PRFLDF-INIT-PCT-T (1)
                                       TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1
           MOVE 4                      TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           SET L0280-SPACES-PERMITTED  TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V04   TO RIPDF-PRFLDF-INIT-PCT
           ELSE
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           MOVE MIR-PRFLDF-SUBSEQ-PCT-T (WS-COUNT)
                                       TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PRFLDF-SUBSEQ-PCT-T (1)
                                       TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1
           MOVE 4                      TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           SET L0280-SPACES-PERMITTED  TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V04   TO RIPDF-PRFLDF-SUBSEQ-PCT
           ELSE
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.
      
       8515-SETUP-IPDF-FIELDS-X.
           EXIT.
      
      *---------------------
       8520-DELETE-OLD-IPDF.
      *---------------------
      
           MOVE LOW-VALUE              TO WIPDF-KEY.
           MOVE MIR-PRFL-ID            TO WIPDF-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPDF-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPDF-PRFLD-SEQ-NUM.
           MOVE WS-FND-SEQ-NUM         TO WIPDF-PRFLDF-SEQ-NUM.
           ADD  1                      TO WIPDF-PRFLDF-SEQ-NUM.

           MOVE WIPDF-KEY              TO WIPDF-ENDBR-KEY.
           MOVE 999                    TO WIPDF-ENDBR-PRFLDF-SEQ-NUM.

           PERFORM  IPDF-1000-BROWSE
               THRU IPDF-1000-BROWSE-X.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

           PERFORM  8525-DELETE-IPDF
               THRU 8525-DELETE-IPDF-X
               UNTIL NOT WIPDF-IO-OK.

           PERFORM  IPDF-3000-END-BROWSE
               THRU IPDF-3000-END-BROWSE-X.

       8520-DELETE-OLD-IPDF-X.
           EXIT.

      *-----------------
       8525-DELETE-IPDF.
      *-----------------

           PERFORM  IPDF-1000-READ-FOR-UPDATE
               THRU IPDF-1000-READ-FOR-UPDATE-X.

           PERFORM  IPDF-1000-DELETE
               THRU IPDF-1000-DELETE-X.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

       8525-DELETE-IPDF-X.
           EXIT.

      *-----------------
       8530-UPDATE-IPRD.
      *-----------------

           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPRD-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPRD-PRFLD-SEQ-NUM.

           PERFORM  IPRD-1000-READ-FOR-UPDATE
               THRU IPRD-1000-READ-FOR-UPDATE-X.

           IF  NOT WIPRD-IO-OK
      *MSG: READ ERROR ON INVESTOR PROFILE DETAIL
               MOVE 'CS25620014'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 8530-UPDATE-IPRD-X
           END-IF.

           MOVE MIR-PRFLD-STAT-CD      TO RIPRD-PRFLD-STAT-CD.
           IF  WS-STATUS-TO-ACTV
               MOVE WGLOB-PROCESS-DATE TO RIPRD-PRFLD-STAT-CHNG-DT
               MOVE RIPRD-PRFLD-STAT-CHNG-DT
                                       TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE    TO MIR-PRFLD-STAT-CHNG-DT
           END-IF.

           MOVE WWKDT-ZERO-DT          TO RIPRD-PRFLD-POL-CHNG-DT.

           PERFORM  IPRD-2000-REWRITE
               THRU IPRD-2000-REWRITE-X.

       8530-UPDATE-IPRD-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-PRFLD-STAT-CD.
           MOVE SPACES                 TO MIR-PRFLD-POL-CHNG-DT.
           MOVE SPACES                 TO MIR-DV-PRFLDF-PCT-IND.
           MOVE SPACES                 TO MIR-PRFLD-SEQ-NUM.

           MOVE SPACES                 TO MIR-DV-PRFLDF-FND-PLAN-ID-G.
           MOVE SPACES                 TO MIR-PRFLDF-INIT-PCT-G.
           MOVE SPACES                 TO MIR-PRFLDF-SUBSEQ-PCT-G.

           MOVE SPACES                 TO MIR-DV-PRFLD-INIT-PCT.
           MOVE SPACES                 TO MIR-DV-PRFLD-SUBSEQ-PCT.
           MOVE SPACES                 TO MIR-PRFLD-STAT-CHNG-DT.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE RIPRD-PRFLD-STAT-CD    TO MIR-PRFLD-STAT-CD.

           MOVE RIPRD-PRFLD-POL-CHNG-DT
                                       TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PRFLD-POL-CHNG-DT.

           MOVE RIPRD-PRFLD-STAT-CHNG-DT
                                       TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PRFLD-STAT-CHNG-DT.

           MOVE LOW-VALUE              TO WIPDF-KEY.
           MOVE MIR-PRFL-ID            TO WIPDF-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPDF-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPDF-PRFLD-SEQ-NUM.
           MOVE ZERO                   TO WIPDF-PRFLDF-SEQ-NUM.

           MOVE WIPDF-KEY              TO WIPDF-ENDBR-KEY.
           MOVE 999                    TO WIPDF-ENDBR-PRFLDF-SEQ-NUM.

           PERFORM  IPDF-1000-BROWSE
               THRU IPDF-1000-BROWSE-X.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

           PERFORM  9250-MOVE-RECORD-TO-MIR-2
               THRU 9250-MOVE-RECORD-TO-MIR-2-X
               VARYING WS-COUNT FROM 1 BY 1
               UNTIL NOT WIPDF-IO-OK
               OR    WS-COUNT > WS-MAX.

           PERFORM  IPDF-3000-END-BROWSE
               THRU IPDF-3000-END-BROWSE-X.

           MOVE RIPDF-PRFLDF-SEQ-NUM   TO L0290-INPUT-V00.
           MOVE ZERO                   TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-PRFLD-SEQ-NUM.

           MOVE WS-TOT-INITIAL         TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-PRFLD-INIT-PCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-DV-PRFLD-INIT-PCT.

           MOVE WS-TOT-SUBSEQ          TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-PRFLD-SUBSEQ-PCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-DV-PRFLD-SUBSEQ-PCT.
      
       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9250-MOVE-RECORD-TO-MIR-2.
      *--------------------------

           IF  RIPDF-FND-ID = SPACE
               SET WS-CODE-PLAN        TO TRUE
               MOVE RIPDF-PLAN-ID      TO WS-FND-PLAN-ID
           ELSE
               SET WS-CODE-FND         TO TRUE
               MOVE RIPDF-FND-ID       TO WS-FND-PLAN-ID
           END-IF.

           MOVE WS-CODE                TO MIR-DV-PRFLDF-FND-PLAN-ID-T
                                          (WS-COUNT).

           MOVE RIPDF-PRFLDF-INIT-PCT  TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PRFLDF-INIT-PCT-T (1)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-PRFLDF-INIT-PCT-T
                                          (WS-COUNT).

           MOVE RIPDF-PRFLDF-SUBSEQ-PCT
                                       TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PRFLDF-SUBSEQ-PCT-T (1)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-PRFLDF-SUBSEQ-PCT-T
                                          (WS-COUNT).

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

       9250-MOVE-RECORD-TO-MIR-2-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-VARIABLES.           
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK             TO  TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT      TO TRUE.
025970     SET  WS-MAX-DEFAULT           TO TRUE.    
025970     SET  WS-FND-COUNT-MIN-DEFAULT TO TRUE.  

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  IPRO
                                '$VAR2'   BY 'IPRO'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
       COPY XCPL8960.
       COPY XCPS8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNIPRD.
       COPY CCPUIPRD.
       COPY CCPVIPRD.
       COPY CCPAIPDF.
       COPY CCPBIPDF.
       COPY CCPCIPDF.
       COPY CCPUIPDF.
       COPY CCPXIPDF.
       COPY CCPNIPRO.
       COPY CCPUIPRO.
       COPY CCPNPD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM2562                     **
      *****************************************************************
