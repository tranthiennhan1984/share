      ************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0581.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER : CSOM0581                                          **
      **  REMARKS: DCLM - DISABILITY CLAIM INFORMATION               **
      **           THIS MODULE ALLOWS THE USER TO CREATE, MAINTAIN,  **
      **           BROWSE AND INQUIRE ON DATA PARTICULAR TO THE      **
      **           CLAIMS ADJUDICATION PROCESS, WITH POLICY AND      **
      **           COVERAGE INFORMATION DISPLAYED FROM THE POLICY    **
      **           AND COVERAGE FILES.  AUTOMATIC CLAIMS PAYMENTS    **
      **           WILL BE CONTROLLED FROM THIS SCREEN BY APPROVING  **
      **           THE OVERALL CLAIM, POLICY AND SUBSEQUENT COVERAGE **
      **           FOR PAYMENTS TO MADE BY THE SYSTEM.               **
      **                                                             **
      **  DOMAIN :  CM                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557668**  5.5       SELECTION LISTS (CLIENT SCRATCPAD)               **
557708**  5.5       ABEND HANDLING                                   **
008445**  5.5.2     GENERATE MIR FROM TADB                           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       PUT WORK DATES THRU THE DATE ROUTINE TO GET      **
005409**            VALID DATE PRIOR TO MOVING TO DB2 TABLES         **
007685**  5.6       NAIC MODEL REGULATION SUPPORT                    **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       MODIFICATIONS FOR MULTI-CO                       **
012624**  6.0       GLOBAL SECURITY CHANGES                          **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       MODIFICATIONS FOR FORMAT FULL NAME               **
014660**  6.0       GLOBAL MESSAGING                                 **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
015951**  6.3       DISABILITY RIDERS ON TRAD POLICIES (6.1.1E)      **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
016494**  6.3       CALC WILL BE SET TO NONE TO ENSURE NO DB AMT*    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020913**  6.4       ELIMINATION OF PROCESSING COPYBOOKS              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
027105**  6.6       99 COVERAGES HANDLING                            **
026766**  6.6       PERFORMANCE MONITORING                           **
024187**  6.7       REMOVE DATE ROUTINE LIMITS                       **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0581'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.
           05  WS-CROSS-EDITS               PIC X(01).
               88  WS-CROSS-EDITS-OK        VALUE 'Y'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1270' '1271' '1272'
                                                  '1273' '1275'
                                                  '1276'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1270'.
               88  WS-BUS-FCN-CREATE        VALUE '1271'.
               88  WS-BUS-FCN-UPDATE        VALUE '1272'.
               88  WS-BUS-FCN-DELETE        VALUE '1273'.
               88  WS-BUS-FCN-CLMLIST       VALUE '1275'.
               88  WS-BUS-FCN-POLLIST       VALUE '1276'.
014221     05  WS-TWRK-KEY                  PIC X(04) VALUE '1270'.
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '1270'.
           05  WS-PO-UPDATE-SW              PIC X(01).
               88  WS-PO-UPDATE             VALUE 'Y'.
008455*    05  WS-NUM-7V2                   PIC 9(07).99  VALUE ZEROS.
           05  WS-NUM-1V2                   PIC 9.99   VALUE ZEROS.
025970         88 WS-NUM-1V2-DEFAULT        VALUE ZEROS.
013578*    05  WS-MAX-SCREEN-LINES          PIC S9(04) COMP VALUE +10.
016548*    05  WS-MAX-SCREEN-LINES          PIC S9(04) COMP VALUE +100.
016548     05  WS-MAX-SCREEN-LINES          PIC S9(04)
016548                                      BINARY VALUE +100.
025970         88 WS-MAX-SCREEN-LINES-DEFAULT        VALUE +100.
016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.
           05  WS-HOLD-RIDER-NO             PIC XX.
           05  WS-HOLD-RIDER-NO-N           REDEFINES
               WS-HOLD-RIDER-NO             PIC 99.
           05  WS-VALID-REC-SW              PIC X(01).
               88  WS-VALID-REC             VALUE 'Y'.
               88  WS-VALID-REC-NO          VALUE 'N'.
015951     05  WS-DI-POL-CVG-FOUND-SW       PIC X(01).
015951         88  WS-DI-POL-CVG-FOUND      VALUE 'Y'.
015951         88  WS-DI-POL-CVG-NOT-FOUND  VALUE 'N'.


       01  WS-EDIT-WORK-AREA.
           05  WS-EDIT-DISAB-TYPE           PIC X      VALUE SPACES.
               88  WS-VALID-DISAB-TYPE      VALUE 'A' 'S'.
           05  WS-EDIT-APPROVAL-SW          PIC X      VALUE SPACES.
               88  WS-VALID-APPROVAL-SW     VALUE 'Y' 'N'.
           05  WS-EDIT-CLAIM-MTHD           PIC X(3)   VALUE SPACES.
               88  WS-VALID-CLAIM-MTHD      VALUE 'CHQ' 'CHK' 'EFT'
                                                  'TRD' 'TRP'.
           05  WS-EDIT-CLAIM-RELA           PIC X      VALUE SPACES.
               88  WS-VALID-CLAIM-RELA      VALUE 'I' 'P' 'A' 'O' 'S'.
           05  WS-EDIT-AUTO-PYMT-SW         PIC X      VALUE SPACES.
               88  WS-VALID-AUTO-PYMT-SW    VALUE 'Y' 'N'.
           05  WS-EDIT-MAX-BEN-TYPE         PIC X      VALUE SPACES.
               88  WS-VALID-MAX-BEN-TYPE    VALUE 'A' 'M' 'Y' 'O'.
           05  WS-EDIT-BEN-ST-IND           PIC X      VALUE SPACES.
               88  WS-VALID-BEN-ST-IND      VALUE 'N' 'A' 'P' 'O' 'C'.


       COPY CCWWCVDI.
027105 COPY XCWWCVGM.
       COPY CCWWRECP.
020913*COPY CCWW3330.
      *
      *****************************************************************
      * COMMON COPYBOOKS                                              *
      *****************************************************************
       COPY CCWWINDX.
014221 COPY CCWWLOCK.
       COPY XCWEBLCH.
       COPY XCWWWKDT.
020478 COPY CCWL2626.
       COPY XCWLDTLK.
021930*COPY XCWL1660.
021930*COPY CCWL3330.
015951 COPY CCWL0186.
021930*COPY CCWT3330.
      *
      *****************************************************************
      * I/O COPYBOOKS                                                 *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.

       COPY CCFWPOL.

       COPY CCFREDIT.
       COPY CCFWEDIT.

       COPY CCFRDCL.
       COPY CCFWDCL.

       COPY CCFRDCD.
       COPY CCFWDCD.
       COPY CCFWDCD1.

       COPY CCFRCODI.
       COPY CCFWCODI.

021930*COPY NCFRDOCM.
021930*COPY NCFWDOCM.
021930*COPY CCFRPLRT.
021930*COPY CCFWPLRT.
021930*COPY CCFWRH.
021930*COPY CCFRRH.
015951 COPY CCFWPH.
015951 COPY CCFRPH.
021930*COPY CCFWRT.
021930*COPY CCFRRT.
021930*COPY CCFWLGAS.
021930*COPY CCFRLGAS.


      *
      *****************************************************************
      * CALLED MODULE COPYBOOKS                                       *
      *****************************************************************
016503 COPY CCWL0289.
       COPY CCWL0577.
016108 COPY CCWL0985.
       COPY CCWL2430.
       COPY CCWL2435.
       COPY CCWL2440.
       COPY CCWL5020.
007685*COPY CCWL5206.
016537*COPY NCWL0303.
       COPY CCWL5400.
       COPY CCWL6820.
557668 COPY CCWL0620.

       COPY XCWL0280.
008455 COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1670.
       COPY XCWL1680.
014221 COPY XCWL8090.

      *****************************************************************
      * INPUT PARAMETER INFORMATION                                   *
      *****************************************************************

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0581.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      ***************************
       2000-PROCESS-REQUEST.
      ***************************

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.


           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           EVALUATE TRUE


             WHEN WS-BUS-FCN-RETRIEVE
                 PERFORM  3000-PROCESS-RETRIEVE
                     THRU 3000-PROCESS-RETRIEVE-X

             WHEN WS-BUS-FCN-CREATE
                 PERFORM  4000-PROCESS-CREATE
                     THRU 4000-PROCESS-CREATE-X

             WHEN WS-BUS-FCN-CLMLIST OR WS-BUS-FCN-POLLIST
                 PERFORM  3500-PROCESS-LIST
                     THRU 3500-PROCESS-LIST-X

             WHEN WS-BUS-FCN-UPDATE
                 PERFORM  5000-PROCESS-UPDATE
                     THRU 5000-PROCESS-UPDATE-X

             WHEN WS-BUS-FCN-DELETE
                 PERFORM  6000-PROCESS-DELETE
                     THRU 6000-PROCESS-DELETE-X

             WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0581'
                                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.


      *****************************************************************
      *  INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      ****************************************************************
      **************
       3000-PROCESS-RETRIEVE.
      **************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7000-INQUIRE-EDITS
               THRU 7000-INQUIRE-EDITS-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
016440     OR WGLOB-RETURN-ERROR
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           MOVE LOW-VALUES            TO WDCD1-KEY.
           MOVE HIGH-VALUES           TO WDCD1-ENDBR-KEY.
           MOVE MIR-POL-ID-BASE       TO WDCD1-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WDCD1-POL-ID-SFX.
           MOVE MIR-DI-CLM-ID         TO WDCD1-DI-CLM-ID.

      ***  BROWSE THE DCD FILE AND READ THE RECORD.
      ***  IF THE KEY HAS NOT CHANGED SCROLL FORWARD TO THE NEXT RECORD.
           PERFORM  DCD1-1000-BROWSE
               THRU DCD1-1000-BROWSE-X.
           IF  NOT WDCD1-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.

           PERFORM  DCD1-2000-READ-NEXT
               THRU DCD1-2000-READ-NEXT-X.

           PERFORM  3200-GET-NUMBER-COVERAGES
               THRU 3200-GET-NUMBER-COVERAGES-X.


           IF  WDCD1-IO-OK
               MOVE RDCD-POL-ID-BASE
                                  TO MIR-POL-ID-BASE
               MOVE RDCD-POL-ID-SFX
                                  TO MIR-POL-ID-SFX
               MOVE WS-HOLD-RIDER-NO
                                  TO MIR-CVG-NUM
               MOVE RDCD-DI-CLM-ID                  TO MIR-DI-CLM-ID
               PERFORM  7010-EDIT-POLICY-NUMBER
                   THRU 7010-EDIT-POLICY-NUMBER-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
015951         MOVE WS-HOLD-RIDER-NO-N  TO  I
               PERFORM  3300-CHECK-CVG
                   THRU 3300-CHECK-CVG-X
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.



013578***  DETERMINE IF WE ARE AT END OF THE FILE

013578*    IF WDCD1-IO-OK
013578*        PERFORM  3060-CHK-DCD1-EOF
013578*            THRU 3060-CHK-DCD1-EOF-X
013578*    END-IF.

013578*    EVALUATE TRUE

013578*        WHEN WDCD1-IO-OK

013578*            MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
013578*            SET WGLOB-MORE-DATA-EXISTS TO TRUE
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X

013578*        WHEN WDCD1-IO-EOF

013578*            MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X

013578*        WHEN OTHER

013578*            MOVE 'XS00000002'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X

013578*    END-EVALUATE.

           PERFORM  DCD1-3000-END-BROWSE
               THRU DCD1-3000-END-BROWSE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.


013578*------------------
013578*3060-CHK-DCD1-EOF.
013578*------------------

013578*    IF WS-HOLD-RIDER-NO-N = WCVDI-CTR
013578*        PERFORM  DCD1-2000-READ-NEXT
013578*            THRU DCD1-2000-READ-NEXT-X
013578*    END-IF.
013578*
013578*3060-CHK-DCD1-EOF-X.
013578*    EXIT.


      *--------------------------
       3200-GET-NUMBER-COVERAGES.
      *--------------------------

      *****     READ POL FILE FOR NUMBER OF COVERAGES
           MOVE RDCD-POL-ID-BASE      TO WPOL-POL-ID.
           MOVE RDCD-POL-ID-SFX       TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF WPOL-IO-OK
               MOVE RPOL-POL-CVG-REC-CTR-N
                                      TO WCVDI-CTR
           ELSE
               MOVE ZERO              TO WCVDI-CTR
557660     END-IF.

       3200-GET-NUMBER-COVERAGES-X.
           EXIT.

      *****************
       3300-CHECK-CVG.
      *****************

      *** DO CVG DEFAULTS IF CVG DETAILS CREATED ON CVG CREATE
           IF WCVDI-CVG-BNFT-STAT-NO-DFLT (I)
               PERFORM  0577-1000-BUILD-PARM-INFO
                   THRU 0577-1000-BUILD-PARM-INFO-X
               MOVE I                 TO L0577-CVG-NUM

               PERFORM  0577-2000-DEF-CVG-CLAIM
                   THRU 0577-2000-DEF-CVG-CLAIM-X
               MOVE L0577-REDC-EP-DUR TO MIR-REDC-EP-DUR
               MOVE L0577-CVG-BNFT-STAT-CD
                                      TO MIR-CVG-BNFT-STAT-CD
008455*        MOVE L0577-MTHLY-BNFT-AMT         TO WS-NUM-7V2
008455*        MOVE WS-NUM-7V2                   TO MIR-MTHLY-BNFT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = L0577-MTHLY-BNFT-AMT * 100
020874         MOVE L0577-MTHLY-BNFT-AMT TO L0290-INPUT-V02
008455         MOVE 2                    TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MTHLY-BNFT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MTHLY-BNFT-AMT
557660     END-IF.


       3300-CHECK-CVG-X.
           EXIT.

      *****************************************************************
      *  BROWSE PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************
      *************
       3500-PROCESS-LIST.
      *************

           PERFORM  8000-BUILD-PO-KEY
               THRU 8000-BUILD-PO-KEY-X.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF WPOL-IO-OK
               MOVE RPOL-POL-CVG-REC-CTR-N
                                      TO WCVDI-CTR
           ELSE
               MOVE ZERO              TO WCVDI-CTR
557660     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  3505-BROWSE-EDITS
               THRU 3505-BROWSE-EDITS-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           IF WS-BUS-FCN-POLLIST
               MOVE LOW-VALUES        TO WDCD1-KEY
               MOVE HIGH-VALUES       TO WDCD1-ENDBR-KEY
               MOVE MIR-POL-ID-BASE        TO WDCD1-POL-ID-BASE
               MOVE MIR-POL-ID-SFX        TO WDCD1-POL-ID-SFX
               MOVE MIR-DI-CLM-ID     TO WDCD1-DI-CLM-ID
               PERFORM  DCD1-1000-BROWSE
                   THRU DCD1-1000-BROWSE-X
               MOVE WDCD1-IO-STATUS   TO WDCD-IO-STATUS
           ELSE
               IF WS-BUS-FCN-CLMLIST
                   MOVE LOW-VALUES    TO WDCD-KEY
                   MOVE HIGH-VALUES   TO WDCD-ENDBR-KEY
                   MOVE MIR-POL-ID-BASE    TO WDCD-POL-ID-BASE
                   MOVE MIR-POL-ID-SFX    TO WDCD-POL-ID-SFX
                   MOVE MIR-DI-CLM-ID TO WDCD-DI-CLM-ID
                   PERFORM  DCD-1000-BROWSE
                       THRU DCD-1000-BROWSE-X
557660         END-IF
557660     END-IF.

           IF NOT WDCD-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
      *MSG: END OF FILE FOUND ON INITIAL BROWSE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           IF WS-BUS-FCN-POLLIST
                PERFORM  DCD1-2000-READ-NEXT
                    THRU DCD1-2000-READ-NEXT-X
                MOVE WDCD1-IO-STATUS  TO WDCD-IO-STATUS
           ELSE
               IF WS-BUS-FCN-CLMLIST
                    PERFORM  DCD-2000-READ-NEXT
                        THRU DCD-2000-READ-NEXT-X
557660         END-IF
557660     END-IF.

      *****     READ POL FILE FOR NUMBER OF COVERAGES

           PERFORM  3200-GET-NUMBER-COVERAGES
               THRU 3200-GET-NUMBER-COVERAGES-X.

           IF RDCD-POL-ID-BASE NOT = MIR-POL-ID-BASE
           OR RDCD-POL-ID-SFX NOT = MIR-POL-ID-SFX
           OR RDCD-DI-CLM-ID NOT = MIR-DI-CLM-ID
               MOVE '01'              TO MIR-CVG-NUM
557660     END-IF.

           MOVE MIR-CVG-NUM           TO WS-HOLD-RIDER-NO.
           IF WS-HOLD-RIDER-NO-N > WCVDI-CTR
               MOVE '01'              TO MIR-CVG-NUM
               MOVE MIR-CVG-NUM       TO WS-HOLD-RIDER-NO
557660     END-IF.

           MOVE WS-HOLD-RIDER-NO-N    TO I.

           MOVE 1                     TO WS-LINE.

           PERFORM  3510-DISPLAY-RECORD
               THRU 3510-DISPLAY-RECORD-X
               UNTIL WS-LINE > WS-MAX-SCREEN-LINES
               OR NOT WDCD-IO-OK.

           IF  WDCD-IO-OK
               SET WS-VALID-REC-NO      TO TRUE
               PERFORM  3520-GET-NEXT-VALID-REC
                   THRU 3520-GET-NEXT-VALID-REC-X
                   UNTIL WS-VALID-REC
                   OR    NOT WDCD-IO-OK
               IF  WDCD-IO-OK
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *
      *        MSG: TO VIEW MORE DATA, PRESS ENTER
      *
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE RDCD-POL-ID-BASE
                                      TO MIR-POL-ID-BASE
                   MOVE RDCD-POL-ID-SFX
                                      TO MIR-POL-ID-SFX
                   MOVE WS-HOLD-RIDER-NO
                                      TO MIR-CVG-NUM
                   MOVE RDCD-DI-CLM-ID                  TO MIR-DI-CLM-ID
               END-IF
           END-IF.

           IF  NOT WDCD-IO-OK
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: INQUIRE COMPLETE - CONTINUE
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF WS-BUS-FCN-POLLIST
               PERFORM  DCD1-3000-END-BROWSE
                   THRU DCD1-3000-END-BROWSE-X
           ELSE
               IF WS-BUS-FCN-CLMLIST
                   PERFORM  DCD-3000-END-BROWSE
                       THRU DCD-3000-END-BROWSE-X
               END-IF
           END-IF.

       3500-PROCESS-LIST-X.
           EXIT.

      *****************************************************************
      *  BROWSE EDITS:
      *      - CVG NUMBER MUST BE BLANK OR NUMERIC
      *      - BROWSE TYPE MUST BE VALID
      *      - LETTER RSN SHOULD NOT BE ENTERED
      *****************************************************************
      *******************
       3505-BROWSE-EDITS.
      *******************

           IF MIR-CVG-NUM = SPACES
               MOVE '01'              TO MIR-CVG-NUM
               MOVE MIR-CVG-NUM       TO WS-HOLD-RIDER-NO
           ELSE
               PERFORM  7020-EDIT-CVG-NUMBER
                   THRU 7020-EDIT-CVG-NUMBER-X
557660     END-IF.


007685*    PERFORM  7060-PROCESS-LETTER-RSN
007685*        THRU 7060-PROCESS-LETTER-RSN-X.
013578*    PERFORM  7060-PROCESS-DOC-ID
013578*        THRU 7060-PROCESS-DOC-ID-X.

       3505-BROWSE-EDITS-X.
           EXIT.

      *****************************************************************
      *  DISPLAY RECORD PROCESSING: MOVE RECORD TO SCREEN, READ NEXT
      *      RECORD
      *****************************************************************
      *********************
       3510-DISPLAY-RECORD.
      *********************

           MOVE RDCD-DI-CLM-ID        TO WDCL-DI-CLM-ID.
           PERFORM  DCL-1000-READ
               THRU DCL-1000-READ-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WS-HOLD-RIDER-NO-N < WCVDI-CTR
               ADD  1                       TO WS-HOLD-RIDER-NO-N
               MOVE WS-HOLD-RIDER-NO-N                              TO I
           ELSE
               IF WS-BUS-FCN-POLLIST
                   PERFORM  DCD1-2000-READ-NEXT
                       THRU DCD1-2000-READ-NEXT-X
                   MOVE 1             TO WS-HOLD-RIDER-NO-N
                   MOVE WS-HOLD-RIDER-NO-N
                                      TO I
                   MOVE WDCD1-IO-STATUS
                                      TO WDCD-IO-STATUS
               ELSE
                   PERFORM  DCD-2000-READ-NEXT
                       THRU DCD-2000-READ-NEXT-X
                   MOVE 1             TO WS-HOLD-RIDER-NO-N
                   MOVE WS-HOLD-RIDER-NO-N
                                      TO I
557660         END-IF
557660     END-IF.

      *****     READ POL FILE FOR NUMBER OF COVERAGES

           PERFORM  3200-GET-NUMBER-COVERAGES
               THRU 3200-GET-NUMBER-COVERAGES-X.

       3510-DISPLAY-RECORD-X.
           EXIT.
      *
      *------------------------
       3520-GET-NEXT-VALID-REC.
      *------------------------
      *
      * VERIFY POLICY ACCESS
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    SET L5400-CTL-MSG-NOT-REQD     TO TRUE.
           SET L5400-CNFD-MSG-REQD        TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD    TO TRUE.
           SET L5400-BRCH-MSG-NOT-REQD    TO TRUE.
012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
012624*    OR  L5400-CTL-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
               IF WS-BUS-FCN-POLLIST
                   PERFORM  DCD1-2000-READ-NEXT
                       THRU DCD1-2000-READ-NEXT-X
                   MOVE WDCD1-IO-STATUS
                                      TO WDCD-IO-STATUS
               ELSE
                   PERFORM  DCD-2000-READ-NEXT
                       THRU DCD-2000-READ-NEXT-X
               END-IF

      *****     READ POL FILE FOR NUMBER OF COVERAGES

               PERFORM  3200-GET-NUMBER-COVERAGES
                   THRU 3200-GET-NUMBER-COVERAGES-X
           ELSE
               SET WS-VALID-REC             TO TRUE
           END-IF.

       3520-GET-NEXT-VALID-REC-X.
           EXIT.

      *****************************************************************
      *  CREATE PROCESSING: TWO PASSES REQUIRED
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      *      ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING
      *****************************************************************
      *************
       4000-PROCESS-CREATE.
      *************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.


           PERFORM  4100-CREATE-EDITS
               THRU 4100-CREATE-EDITS-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      *** UPDATE POLICY CLAIM FIELDS
           ADD 1                   TO RPOL-POL-DI-CLM-REC-CTR-N.
           MOVE 'O'                   TO RPOL-POL-CLM-STAT-CD.
           MOVE MIR-DI-CLM-ID         TO RPOL-DI-CLM-ID.

016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.

016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.

016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

      ***  CREATE NEW DCD RECORD.
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  0577-1000-BUILD-PARM-INFO
               THRU 0577-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-DI-CLM-ID        TO L0577-CLM-ID.
           MOVE RDCL-CLI-ID           TO L0577-CLI-ID.
           PERFORM  0577-1000-CREAT-POL-CLM-DFLT
               THRU 0577-1000-CREAT-POL-CLM-DFLT-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       4000-PROCESS-CREATE-X.
           EXIT.

      *****************************************************************
      *  CREATE EDITS:
      *      - EDIT POLICY NUMBER
      *      - EDIT COVERAGE NUMBER
      *      - LOAD COVERAGE ARRAY
      *      - EDIT CLAIM NUMBER
      *      - EDIT POLICY TO CLAIM
      *      - EDIT INSURED VS. CLIENT ON CLAIM
      *      - EDIT BROWSE TYPE
      *      - PROCESS LETTER REASON
      *****************************************************************
      *------------------
       4100-CREATE-EDITS.
      *------------------

           PERFORM  4110-EDIT-POLICY-NUMBER
               THRU 4110-EDIT-POLICY-NUMBER-X.

           IF WPOL-IO-NOT-FOUND
016440     OR WGLOB-RETURN-ERROR
               GO TO 4100-CREATE-EDITS-X
557660     END-IF.

           MOVE RPOL-POL-CVG-REC-CTR-N                     TO WCVDI-CTR.

           PERFORM  7020-EDIT-CVG-NUMBER
               THRU 7020-EDIT-CVG-NUMBER-X.

           IF WPOL-IO-OK
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WGLOB-PROCESS-DATE      TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         PERFORM  POL-3000-UNLOCK
016108             THRU POL-3000-UNLOCK-X
016108         GO TO 4100-CREATE-EDITS-X
016108     END-IF.

           MOVE MIR-CVG-NUM           TO WS-HOLD-RIDER-NO.

           PERFORM  7030-EDIT-CLAIM-NUMBER
               THRU 7030-EDIT-CLAIM-NUMBER-X.

      *** IF A CLAIM DOES NOT ALREADY EXIST, BYPASS REMAINING EDITS
           IF MIR-DI-CLM-ID = SPACES
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 4100-CREATE-EDITS-X
557660     END-IF.

           PERFORM  4140-EDIT-POLICY-CLAIM
               THRU 4140-EDIT-POLICY-CLAIM-X.


007685*    PERFORM  7060-PROCESS-LETTER-RSN
007685*        THRU 7060-PROCESS-LETTER-RSN-X.
013578*    PERFORM  7060-PROCESS-DOC-ID
013578*        THRU 7060-PROCESS-DOC-ID-X.

      *** IF ANY ERRORS WERE UNCOUNTERED, UNLOCK THE PO FILE
           IF WGLOB-MSG-ERROR-SW NOT = ZERO
           AND WPOL-IO-OK
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
557660     END-IF.

       4100-CREATE-EDITS-X.
           EXIT.

      *****************************************************************
      *  POLICY EDITS:
      *      - POLICY MUST EXIST
      *      - POLICY MUST BE A HEALTH POLICY
      *      - POLICY MUST NOT BE TERMINATED
      *****************************************************************
      *------------------------
       4110-EDIT-POLICY-NUMBER.
      *------------------------

           PERFORM  8000-BUILD-PO-KEY
               THRU 8000-BUILD-PO-KEY-X.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           IF NOT WPOL-IO-OK
      *** MSG (S) POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4110-EDIT-POLICY-NUMBER-X
557660     END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
012624*    SET L5400-SYS-APPL-CTL-ADMIN TO TRUE.
016440     SET L5400-POL-XFER-UPDATE    TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

016440     IF  L5400-XFER-ACCS-RESTRICTED
016440         PERFORM  POL-3000-UNLOCK
016440             THRU POL-3000-UNLOCK-X
016440         MOVE '1'            TO WGLOB-RETURN-CODE
016440         GO TO 4110-EDIT-POLICY-NUMBER-X
016440     END-IF.

015951*    IF NOT RPOL-POL-INS-TYP-HEALTH
015951*MSG: POLICY MUST BE A HEALTH POLICY
015951*       MOVE 'CS05810064'      TO WGLOB-MSG-REF-INFO
015951*       PERFORM 0260-1000-GENERATE-MESSAGE
015951*          THRU 0260-1000-GENERATE-MESSAGE-X
015951*    END-IF.

           IF RPOL-POL-STAT-TERMINATED
           OR RPOL-POL-STAT-REJECTED
      *MSG: POLICY MUST BE INFORCE OR PENDING
               MOVE 'CS05810067'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF RPOL-POL-STAT-PENDING
      *MSG: WARNING .... POLICY IS PENDING
               MOVE 'CS05810068'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

015951*
015951*    IF  NOT A HEALTH POLICY, CHECK FOR DI COVERAGES
015951*
015951     IF  NOT RPOL-POL-INS-TYP-HEALTH
015951         SET WS-DI-POL-CVG-NOT-FOUND TO TRUE
015951         PERFORM  8400-READ-RIDERS-IN
015951             THRU 8400-READ-RIDERS-IN-X
015951             VARYING I FROM 1 BY 1
015951               UNTIL I > RPOL-POL-CVG-REC-CTR-N
015951         PERFORM 4111-CHECK-FOR-DI-CVG
015951            THRU 4111-CHECK-FOR-DI-CVG-X
015951             VARYING I FROM 1 BY 1
015951               UNTIL I > RPOL-POL-CVG-REC-CTR-N
015951                  OR WS-DI-POL-CVG-FOUND
015951     ELSE
015951         SET WS-DI-POL-CVG-FOUND TO TRUE
015951     END-IF.
015951
015951     IF WS-DI-POL-CVG-NOT-FOUND
015951*MSG: POLICY HAS NO IN-FORCE HEALTH COVERAGES
015951         MOVE 'CS05810064'      TO WGLOB-MSG-REF-INFO
015951         PERFORM 0260-1000-GENERATE-MESSAGE
015951            THRU 0260-1000-GENERATE-MESSAGE-X
015951     END-IF.

       4110-EDIT-POLICY-NUMBER-X.
           EXIT.

015951 4111-CHECK-FOR-DI-CVG.
015951
015951     IF WCVGS-CVG-INS-TYP-HEALTH (I)
015951     AND WCVGS-CVG-STAT-IN-FORCE (I)
015951         SET WS-DI-POL-CVG-FOUND TO TRUE
015951     END-IF.
015951
015951 4111-CHECK-FOR-DI-CVG-X.
015951     EXIT.


      *****************************************************************
      *  EDIT POLICY/CLAIM
      *      - WARNING IF POLICY ISSUED AFTER DISABILITY DATE
      *      - CLIENT ON CLAIM MASTER RECORD MUST MATCH AN INSURED
      *        CLIENT ON POLICY
      *      - POLICY MUST NOT BE ON CLAIM (DCD RECORD MUST NOT EXIST)
      *****************************************************************
      *-----------------------
       4140-EDIT-POLICY-CLAIM.
      *-----------------------

           IF NOT WPOL-IO-OK
           OR NOT WDCL-IO-OK
           OR MIR-DI-CLM-ID = SPACES
               GO TO 4140-EDIT-POLICY-CLAIM-X
557660     END-IF.

           IF RPOL-POL-ISS-EFF-DT > RDCL-INSRD-DISAB-DT
      *** MSG (W) WARNING....POLICY ISSUE DATE EXCEEDS DISABILITY DATE
               MOVE 'CS05810069'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE  1                    TO  I.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-3100-GET-PRIM-INSRD
               THRU 2430-3100-GET-PRIM-INSRD-X

           IF L2430-CLI-ID NOT = RDCL-CLI-ID
      *** MSG (S) INSURED ON CLAIM IS NOT AN INSURED ON POLICY
               MOVE 'CS05810075'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  8200-BUILD-DCD-KEY
               THRU 8200-BUILD-DCD-KEY-X.

           PERFORM  DCD-1000-READ
               THRU DCD-1000-READ-X.
           IF WDCD-IO-OK
      *** MSG (S) POLICY (@1) IS ALREADY ON CLAIM (@2)
               MOVE 'CS05810073'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WDCL-DI-CLM-ID    TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4140-EDIT-POLICY-CLAIM-X.
           EXIT.


      *****************************************************************
      *  UPDATE PROCESSING:
      *                  GET RECORD, EDIT DATA FIELDS AND UPDATE RECORD.
      *                  FIELDS WITH ERRORS ARE NOT UPDATED.
      *****************************************************************
      *****************
       5000-PROCESS-UPDATE.
      *****************

013578     PERFORM 7000-INQUIRE-EDITS
013578        THRU 7000-INQUIRE-EDITS-X.

016440     IF WGLOB-RETURN-ERROR
016440        GO TO 5000-PROCESS-UPDATE-X
016440     END-IF.

013578     PERFORM  9230-MOVE-RECORD-TO-SCREEN
013578         THRU 9230-MOVE-RECORD-TO-SCREEN-X.

      *** GET CLAIM
           PERFORM  8100-BUILD-DCL-KEY
               THRU 8100-BUILD-DCL-KEY-X.
           PERFORM  DCL-1000-READ-FOR-UPDATE
               THRU DCL-1000-READ-FOR-UPDATE-X.

           IF WDCL-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WDCL-KEY          TO WGLOB-MSG-PARM (1)
      *
      *        MSG: LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

      *** GET CLAIM DETAILS
           PERFORM  8200-BUILD-DCD-KEY
               THRU 8200-BUILD-DCD-KEY-X.
           PERFORM  DCD-1000-READ-FOR-UPDATE
               THRU DCD-1000-READ-FOR-UPDATE-X.

           IF WDCD-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WDCD-KEY          TO WGLOB-MSG-PARM (1)
      *
      *        MSG: LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

      *** GET POLICY
           PERFORM  8000-BUILD-PO-KEY
               THRU 8000-BUILD-PO-KEY-X.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  9100-BLANK-DATA-FIELDS
014221             THRU 9100-BLANK-DATA-FIELDS-X
014221         PERFORM  DCL-3000-UNLOCK
014221             THRU DCL-3000-UNLOCK-X
014221         PERFORM  DCD-3000-UNLOCK
014221             THRU DCD-3000-UNLOCK-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: POLICY NOT IN FILE
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
014221         PERFORM  DCL-3000-UNLOCK
014221             THRU DCL-3000-UNLOCK-X
014221         PERFORM  DCD-3000-UNLOCK
014221             THRU DCD-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.
016503
016503     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           MOVE 'N'                   TO WS-PO-UPDATE-SW.


      *** GET COVERAGE
           MOVE MIR-CVG-NUM           TO WS-HOLD-RIDER-NO.
           MOVE WS-HOLD-RIDER-NO-N    TO I.

           PERFORM  8400-READ-RIDERS-IN
015951*        THRU 8400-READ-RIDERS-IN-X.
015951         THRU 8400-READ-RIDERS-IN-X
015951             VARYING I FROM 1 BY 1
015951               UNTIL I > RPOL-POL-CVG-REC-CTR-N.
           IF NOT WCVG-IO-OK
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

015951     MOVE WS-HOLD-RIDER-NO-N    TO I.

013578*    PERFORM  9212-LOAD-INSURED
013578*        THRU 9212-LOAD-INSURED-X.

013578*    PERFORM  CVDI-1000-BUILD-ARRAY
013578*        THRU CVDI-1000-BUILD-ARRAY-X.

           PERFORM  2430-1000-BUILD-POL-REL-INFO
               THRU 2430-1000-BUILD-POL-REL-INFO-X.

           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.

           PERFORM  7600-XEDIT-DATA-FIELDS
               THRU 7600-XEDIT-DATA-FIELDS-X.

015951     IF  WCVGS-CVG-INS-TYP-HEALTH (I)
015951     AND WCVGS-CVG-STAT-IN-FORCE (I)
015951         PERFORM 7700-CALC-NEW-MTHLY-BNFT-AMT
015951            THRU 7700-CALC-NEW-MTHLY-BNFT-AMT-X
015951*
015951*        MSG: COVERAGE IS NOT IN-FORCE AND HEALTH TYPE
015951*
015951     ELSE
015951         MOVE 'CS05810086'      TO WGLOB-MSG-REF-INFO
015951         PERFORM  0260-1000-GENERATE-MESSAGE
015951             THRU 0260-1000-GENERATE-MESSAGE-X
015951         GO TO 5000-PROCESS-UPDATE-X
015951     END-IF.
           PERFORM  DCL-2000-REWRITE
               THRU DCL-2000-REWRITE-X.

           PERFORM  DCD-2000-REWRITE
               THRU DCD-2000-REWRITE-X.

           PERFORM  CVDI-3000-UPDATE-AREA
               THRU CVDI-3000-UPDATE-AREA-X.

014221*    IF NOT RDCD-CLM-AUTO-PMT-APPROVED
014221*        MOVE 'N'               TO WS-PO-UPDATE-SW
014221*    END-IF.

      *** RESCHEDULE THE NEXT CLAIM PAYMENT DATE
014221*    IF WS-PO-UPDATE
016503*        MOVE WWKDT-ZERO-DT     TO RPOL-POL-NXT-ACTV-DT
014221*        MOVE WGLOB-PROCESS-DATE        TO RPOL-PREV-FILE-MAINT-DT
014221     MOVE WGLOB-PROCESS-DATE        TO RPOL-PREV-FILE-MAINT-DT.
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

014221*    ELSE
014221*        PERFORM  POL-3000-UNLOCK
014221*            THRU POL-3000-UNLOCK-X
014221*    END-IF.

      *** A SEPARATE INDICATOR IS USED FOR CROSS EDITS SO WE KNOW IF
      *** THE POSITION HAS ALREADY BEEN SET.
           IF WS-DATA-EDITS-OK
           AND WS-CROSS-EDITS-OK
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: MAINTENANCE COMPLETED - CONTINUE
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: RECORD UPDATED
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.


       5000-PROCESS-UPDATE-X.
           EXIT.


      *****************************************************************
      *  DELETE PROCESSING: REMOVE RECORD
      *****************************************************************
      *************
       6000-PROCESS-DELETE.
      *************

           PERFORM  7000-INQUIRE-EDITS
               THRU 7000-INQUIRE-EDITS-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
016440     OR WGLOB-RETURN-ERROR
               GO TO 6000-PROCESS-DELETE-X
557660     END-IF.

           PERFORM  3200-GET-NUMBER-COVERAGES
               THRU 3200-GET-NUMBER-COVERAGES-X.

           PERFORM  8200-BUILD-DCD-KEY
               THRU 8200-BUILD-DCD-KEY-X.

           PERFORM  DCD-1000-READ-FOR-UPDATE
               THRU DCD-1000-READ-FOR-UPDATE-X.

           IF WDCD-IO-NOT-FOUND
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WDCD-KEY          TO WGLOB-MSG-PARM (1)
      *
      *        MSG: RECORD (@1) LOST IN DELETE - CONTACT SYSTEMS
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 6000-PROCESS-DELETE-X
557660     END-IF.

      *** UPDATE POLICY FIELDS
           PERFORM  8000-BUILD-PO-KEY
               THRU 8000-BUILD-PO-KEY-X.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  9100-BLANK-DATA-FIELDS
014221             THRU 9100-BLANK-DATA-FIELDS-X
014221         PERFORM  DCD-3000-UNLOCK
014221             THRU DCD-3000-UNLOCK-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF NOT WPOL-IO-OK
      *** MSG (S) POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 6000-PROCESS-DELETE-X
557660     END-IF.

016503     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
016503
           MOVE RPOL-POL-CVG-REC-CTR-N                     TO WCVDI-CTR.

           PERFORM  CVDI-1000-BUILD-ARRAY
               THRU CVDI-1000-BUILD-ARRAY-X.

           SUBTRACT 1            FROM RPOL-POL-DI-CLM-REC-CTR-N.
           MOVE SPACE                 TO RPOL-DI-CLM-ID.
           MOVE SPACE                 TO RPOL-POL-CLM-STAT-CD.

016503*    MOVE WWKDT-ZERO-DT         TO RPOL-POL-NXT-ACTV-DT.
016503*    IF RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*        MOVE 'RSH'             TO RPOL-NXT-ACTV-TYP-CD
016503*    END-IF.
           MOVE WGLOB-PROCESS-DATE    TO RPOL-PREV-FILE-MAINT-DT.

016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.

016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.

016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  CVDI-4000-DELETE-AREA
               THRU CVDI-4000-DELETE-AREA-X
               VARYING WCVDI-I FROM 1 BY 1
               UNTIL WCVDI-I > WCVDI-CTR
               OR WCODI-IO-EOF.

           PERFORM  DCD-1000-DELETE
               THRU DCD-1000-DELETE-X.

           MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO.
      *
      *    MSG: DELETE COMPLETED - CONTINUE
      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      ***  RESET COMMAND CODE TO INQUIRE.


      *** LOAD INSURED'S NAME
           PERFORM  8100-BUILD-DCL-KEY
               THRU 8100-BUILD-DCL-KEY-X.

           PERFORM  DCL-1000-READ
               THRU DCL-1000-READ-X.

           IF WDCL-IO-OK
               PERFORM  9212-LOAD-INSURED
                   THRU 9212-LOAD-INSURED-X
557660     END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.



      *****************************************************************
      *  INQUIRE EDITS:
      *      - POLICY MUST EXIST
      *      - COVERAGE MUST EXIST
      *      - CLAIM MUST EXIST
      *      - POLICY MUST BE ON CLAIM
      *      - BROWSE TYPE MUST BE BLANK
      *      - EDIT AND PROCESS LETTER REQUEST
      *****************************************************************
      *-------------------
       7000-INQUIRE-EDITS.
      *-------------------

           PERFORM  7010-EDIT-POLICY-NUMBER
               THRU 7010-EDIT-POLICY-NUMBER-X.

           PERFORM  7020-EDIT-CVG-NUMBER
               THRU 7020-EDIT-CVG-NUMBER-X.

           PERFORM  7030-EDIT-CLAIM-NUMBER
               THRU 7030-EDIT-CLAIM-NUMBER-X.

           PERFORM  7040-EDIT-POLICY-CLAIM
               THRU 7040-EDIT-POLICY-CLAIM-X.

007685*    PERFORM  7060-PROCESS-LETTER-RSN
007685*        THRU 7060-PROCESS-LETTER-RSN-X.
013578*    PERFORM  7060-PROCESS-DOC-ID
013578*        THRU 7060-PROCESS-DOC-ID-X.

016108     PERFORM  7050-VAL-DATE-OF-DTH
016108         THRU 7050-VAL-DATE-OF-DTH-X.

       7000-INQUIRE-EDITS-X.
           EXIT.

      ******************************************************************
      *  EDIT POLICY NUMBER
      *      - POLICY MUST EXIST
      ******************************************************************
       7010-EDIT-POLICY-NUMBER.

           PERFORM  8000-BUILD-PO-KEY
               THRU 8000-BUILD-PO-KEY-X.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: POLICY NOT IN FILE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7010-EDIT-POLICY-NUMBER-X
           END-IF.

           IF  WS-BUS-FCN-UPDATE
           OR  WS-BUS-FCN-DELETE
           OR  WS-BUS-FCN-RETRIEVE

               PERFORM  5400-1000-BUILD-PARM-INFO
                   THRU 5400-1000-BUILD-PARM-INFO-X
012624*        SET L5400-SYS-APPL-CTL-ADMIN TO TRUE
016440         IF  WS-BUS-FCN-UPDATE
016440         OR  WS-BUS-FCN-DELETE
016440             SET L5400-POL-XFER-UPDATE    TO  TRUE
016440         END-IF

               PERFORM  5400-1000-POL-CHK
                   THRU 5400-1000-POL-CHK-X

016440         IF  L5400-XFER-ACCS-RESTRICTED
016440             MOVE '1'             TO WGLOB-RETURN-CODE
016440         END-IF

           END-IF.

       7010-EDIT-POLICY-NUMBER-X.
           EXIT.

      ******************************************************************
      *  EDIT COVERAGE NUMBER
      *      - COVERAGE MUST BE NUMERIC
      *      - COVERAGE RECORD MUST EXIST
      ******************************************************************
      *---------------------
       7020-EDIT-CVG-NUMBER.
      *---------------------

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-HOLD-RIDER-NO-N
               MOVE WS-HOLD-RIDER-NO  TO MIR-CVG-NUM
           ELSE
      *** MSG (S) COVERAGE NUMBER MUST BE NUMERIC - FORMAT 99
013578*        MOVE 'CS00000058'      TO WGLOB-MSG-REF-INFO
013578         MOVE 'CS05810058'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7020-EDIT-CVG-NUMBER-X
557660     END-IF.

      *** REMAINING EDITS DO NOT APPLY TO THE BROWSE FUNCTION
           IF WS-BUS-FCN-CLMLIST
           OR WS-BUS-FCN-POLLIST
               GO TO 7020-EDIT-CVG-NUMBER-X
557660     END-IF.

           IF NOT WPOL-IO-OK
               GO TO 7020-EDIT-CVG-NUMBER-X
557660     END-IF.

           IF WS-HOLD-RIDER-NO-N > RPOL-POL-CVG-REC-CTR-N
           OR WS-HOLD-RIDER-NO-N = ZERO
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: COVERAGE RECORD MUST EXIT. RE-ENTER
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7020-EDIT-CVG-NUMBER-X
557660     END-IF.

015951     IF NOT WS-BUS-FCN-DELETE
015951        MOVE RPOL-POL-ID           TO WCVG-POL-ID
015951        MOVE MIR-CVG-NUM           TO WCVG-CVG-NUM
015951        PERFORM  CVG-1000-READ
015951            THRU CVG-1000-READ-X
015951        IF NOT WCVG-IO-OK
015951           MOVE 'CS00000024'       TO WGLOB-MSG-REF-INFO
015951*
015951*          MSG: COVERAGE FILE PROBLEM. CALL SYSTEMS
015951*
015951           PERFORM  0260-1000-GENERATE-MESSAGE
015951               THRU 0260-1000-GENERATE-MESSAGE-X
015951        END-IF
015951     END-IF.


       7020-EDIT-CVG-NUMBER-X.
           EXIT.

      *****************************************************************
      *  CLAIM NUMBER EDIT
      *      - CLAIM MUST EXIST
      *****************************************************************
      *-----------------------
       7030-EDIT-CLAIM-NUMBER.
      *-----------------------

           IF MIR-DI-CLM-ID = SPACES
               MOVE 'CS05810001'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CLAIM-NO IS REQUIRED TO VIEW CLAIM INFORMATION
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7030-EDIT-CLAIM-NUMBER-X
557660     END-IF.

           PERFORM  8100-BUILD-DCL-KEY
               THRU 8100-BUILD-DCL-KEY-X.

           PERFORM  DCL-1000-READ
               THRU DCL-1000-READ-X.

           IF NOT WDCL-IO-OK
               MOVE 'CS05810002'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: DISABILITY CLAIM RECORD NOT ON FILE
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

      *** THE FOLLOWING EDIT ONLY APPLIES TO A CREATE
           IF NOT WS-BUS-FCN-CREATE
               GO TO 7030-EDIT-CLAIM-NUMBER-X
557660     END-IF.

           IF NOT RDCL-CLM-CRNT-STAT-OPEN
      *** MSG (S) CLAIM MUST BE OPEN TO ADD POLICIES
               MOVE 'CS05810065'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7030-EDIT-CLAIM-NUMBER-X.
           EXIT.

      *****************************************************************
      *  EDIT POLICY/CLAIM
      *      - POLICY MUST BE ON CLAIM (DCD RECORD MUST EXIST)
      *****************************************************************
       7040-EDIT-POLICY-CLAIM.

           IF MIR-DI-CLM-ID = SPACES
           OR NOT WPOL-IO-OK
           OR NOT WDCL-IO-OK
               GO TO 7040-EDIT-POLICY-CLAIM-X
557660     END-IF.

           PERFORM  8200-BUILD-DCD-KEY
               THRU 8200-BUILD-DCD-KEY-X.

           PERFORM  DCD-1000-READ
               THRU DCD-1000-READ-X.
           IF NOT WDCD-IO-OK
      *** MSG (S) POLICY (@1) MUST BE ON CLAIM (@2)
               MOVE 'CS05810072'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WDCL-DI-CLM-ID    TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7040-EDIT-POLICY-CLAIM-X.
           EXIT.

016108*---------------------
016108 7050-VAL-DATE-OF-DTH.
016108*---------------------
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     IF  NOT WS-BUS-FCN-UPDATE
016108     AND NOT WS-BUS-FCN-DELETE
016108         GO TO 7050-VAL-DATE-OF-DTH-X
016108     END-IF.
016108
016108     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016108         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
016108
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WGLOB-PROCESS-DATE      TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE 1                   TO WGLOB-MSG-ERROR-SW
016108     END-IF.
016108
016108 7050-VAL-DATE-OF-DTH-X.
016108     EXIT.
016108*


013578*****************************************************************
013578*  PROCESS LETTER REASON
013578*      - LETTER REASON MUST BE ON ETAB
013578*****************************************************************
013578*7060-PROCESS-LETTER-RSN.
013578*7060-PROCESS-DOC-ID.
013578*
013578*    IF MIR-LETTER = SPACES
013578*    IF MIR-DOC-ID  = SPACES
013578*        GO TO 7060-PROCESS-LETTER-RSN-X
013578*        GO TO 7060-PROCESS-DOC-ID-X
013578*    END-IF.
013578*
013578*    MOVE MIR-LETTER              TO WEDIT-ETBL-VALU-ID.
013578*    PERFORM  FRMT-1000-EDIT
013578*        THRU FRMT-1000-EDIT-X.
013578*
013578*    MOVE MIR-DOC-ID            TO WDOCM-DOC-ID.
013578*    MOVE WGLOB-EDIT-LANG       TO WDOCM-DOC-LANG-CD.
013578*
013578*    PERFORM  DOCM-1000-READ
013578*        THRU DOCM-1000-READ-X.
013578*
013578*    IF NOT WEDIT-IO-OK
013578*    IF NOT WDOCM-IO-OK
013578*MSG : DOCUMENT ID IS NOT IN DOCM TABLE
013578*        MOVE 'CS05810062'      TO WGLOB-MSG-REF-INFO
013578*
013578*        MSG: LETTER IS NOT ON ETAB/PFFRM
013578*
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    END-IF.
013578*
013578*    IF WS-BUS-FCN-CLMLIST
013578*    OR WS-BUS-FCN-POLLIST
013578*        MOVE 'CS05810070'      TO WGLOB-MSG-REF-INFO
013578*
013578*        MSG: LETTER REQUEST NOT VALID ON A BROWSE
013578*
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    END-IF.
013578*
013578*    IF WGLOB-MSG-ERROR-SW NOT = ZERO
013578*        MOVE 'CS05810071'      TO WGLOB-MSG-REF-INFO
013578*
013578*        MSG: LETTER NOT REQUESTED DUE TO ERRORS
013578*
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        GO TO 7060-PROCESS-LETTER-RSN-X
013578*        GO TO 7060-PROCESS-DOC-ID-X
013578*    END-IF.
013578*
013578*    PERFORM  PGA-1000-BUILD-PARMS
013578*        THRU PGA-1000-BUILD-PARMS-X.
013578*
013578*    PERFORM  5206-1000-BUILD-PARM-INFO
013578*        THRU 5206-1000-BUILD-PARM-INFO-X.
013578*    MOVE ZERO                 TO L5206-RSN-CD.
013578*    MOVE MIR-LETTER           TO L5206-LETTER-RSN-CD.
013578*    MOVE WS-HOLD-RIDER-NO     TO L5206-COVERAGE.
013578*    MOVE ZEROES               TO L5206-CF-SEQ-NUM.
013578*    PERFORM  5206-2000-WRITE-LETTER
013578*        THRU 5206-2000-WRITE-LETTER-X.
013578*
013578*    PERFORM  0303-1000-BUILD-PARM-INFO
013578*        THRU 0303-1000-BUILD-PARM-INFO-X.
013578*
013578*    SET L0303-TRNXT-TYP-MISC-PRT TO TRUE.
013578*
013578*    MOVE MIR-DOC-ID            TO L0303-DOC-ID.
013578*    MOVE WS-HOLD-RIDER-NO      TO L0303-CVG-NUM.
013578*    MOVE ZEROES                TO L0303-TRNXT-TRXN-SEQ-NUM.
013578*
013578*    MOVE RPOL-POL-ID           TO L0303-POL-ID.
013578*    MOVE RPOL-POL-APPL-CTL-CD  TO L0303-APPL-ID.
013578*    MOVE RPOL-SBSDRY-CO-ID     TO L0303-SBSDRY-CO-ID.
013578*    MOVE WGLOB-PROCESS-DATE    TO L0303-TRNXT-TRXN-EFF-DT.
013578*
013578*    PERFORM  0303-1000-WRITE-PRTX-TRAN
013578*        THRU 0303-1000-WRITE-PRTX-TRAN-X.
013578*
013578*    MOVE SPACES               TO MIR-LETTER.
013578*    MOVE SPACES                TO MIR-DOC-ID.
013578*
013578*    MOVE 'CS05810063'          TO WGLOB-MSG-REF-INFO
013578*
013578*        MSG: PRINT REQUEST HAS BEEN PROCESSED
013578*
013578*    PERFORM  0260-1000-GENERATE-MESSAGE
013578*        THRU 0260-1000-GENERATE-MESSAGE-X.
013578*
013578*7060-PROCESS-LETTER-RSN-X.
013578*7060-PROCESS-DOC-ID-X.
013578*    EXIT.

      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
      ***********************
       7500-EDIT-DATA-FIELDS.
      ***********************

           SET WS-DATA-EDITS-OK TO TRUE.

           PERFORM  7501-EDIT-DISAB-DATE
               THRU 7501-EDIT-DISAB-DATE-X.

           PERFORM  7502-EDIT-DISAB-RSN
               THRU 7502-EDIT-DISAB-RSN-X.

           PERFORM  7503-EDIT-REPORT-DATE
               THRU 7503-EDIT-REPORT-DATE-X.

           PERFORM  7504-EDIT-DISAB-TYPE
               THRU 7504-EDIT-DISAB-TYPE-X.

           PERFORM  7505-EDIT-CURR-OCC-CODE
               THRU 7505-EDIT-CURR-OCC-CODE-X.

           PERFORM  7506-EDIT-CLOSE-DATE
               THRU 7506-EDIT-CLOSE-DATE-X.

           PERFORM  7507-EDIT-CLOSE-RSN
               THRU 7507-EDIT-CLOSE-RSN-X.

           PERFORM  7508-EDIT-COMMENTS
               THRU 7508-EDIT-COMMENTS-X.

           PERFORM  7510-EDIT-APPROVAL-SW
               THRU 7510-EDIT-APPROVAL-SW-X.

           PERFORM  7511-EDIT-CLAIM-MTHD
               THRU 7511-EDIT-CLAIM-MTHD-X.

           PERFORM  7512-EDIT-CLAIM-RELA
               THRU 7512-EDIT-CLAIM-RELA-X.

           PERFORM  7513-EDIT-AUTO-PYMT-SW
               THRU 7513-EDIT-AUTO-PYMT-SW-X.

           PERFORM  7514-EDIT-AUTO-PYMT-EXP-DATE
               THRU 7514-EDIT-AUTO-PYMT-EXP-DATE-X.

           PERFORM  7515-EDIT-ADDR-TYPE-CODE
               THRU 7515-EDIT-ADDR-TYPE-CODE-X.

           PERFORM  7520-EDIT-MAX-BEN-TYPE
               THRU 7520-EDIT-MAX-BEN-TYPE-X.

           PERFORM  7521-EDIT-MAX-BEN-PERIOD
               THRU 7521-EDIT-MAX-BEN-PERIOD-X.

           PERFORM  7522-EDIT-RED-ELIM-PERIOD
               THRU 7522-EDIT-RED-ELIM-PERIOD-X.

           PERFORM  7523-EDIT-OWN-OCC-PERIOD
               THRU 7523-EDIT-OWN-OCC-PERIOD-X.

           PERFORM  7524-EDIT-BEN-ST-IND
               THRU 7524-EDIT-BEN-ST-IND-X.

           PERFORM  7525-EDIT-CURR-BEN-AMT
               THRU 7525-EDIT-CURR-BEN-AMT-X.

           PERFORM  7526-EDIT-BEN-ADJ-RSN
               THRU 7526-EDIT-BEN-ADJ-RSN-X.

           PERFORM  7527-EDIT-BEN-EXP-DATE
               THRU 7527-EDIT-BEN-EXP-DATE-X.

           PERFORM  7528-EDIT-RESID-MULT
               THRU 7528-EDIT-RESID-MULT-X.

           PERFORM  7529-EDIT-RESID-DISAB-DATE
               THRU 7529-EDIT-RESID-DISAB-DATE-X.

015951     PERFORM  7530-EDIT-CVG-DISAB-PCT
015951         THRU 7530-EDIT-CVG-DISAB-PCT-X.

       7500-EDIT-DATA-FIELDS-X.
           EXIT.

      *****************************************************************
      *  DISABILITY DATE - MUST BE IN VALID DATE FORMAT
      *****************************************************************
      **********************
       7501-EDIT-DISAB-DATE.
      **********************

           IF MIR-INSRD-DISAB-DT = SPACES
               MOVE RDCL-INSRD-DISAB-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-INSRD-DISAB-DT
               GO TO 7501-EDIT-DISAB-DATE-X
557660     END-IF.

           MOVE MIR-INSRD-DISAB-DT    TO L1640-EXTERNAL-DATE.
005409*    SET L1640-DO-NOT-USE-LEAP-YEAR TO TRUE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
              MOVE 'CS05810003'       TO WGLOB-MSG-REF-INFO
      *
      *        MSG: DISABILITY DATE MUST BE ENTERED IN VALID FORMAT
      *
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              MOVE 'N'                TO WS-DATA-EDITS
              GO TO 7501-EDIT-DISAB-DATE-X
557660     END-IF.

           MOVE L1640-INTERNAL-DATE   TO RDCL-INSRD-DISAB-DT.

      *** RECALC DISABILITY AGE
           MOVE L2435-CLI-BTH-DT      TO L1680-INTERNAL-1.
           MOVE RDCL-INSRD-DISAB-DT   TO L1680-INTERNAL-2.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
           IF  L1680-NUMBER-OF-YEARS > ZERO
               MOVE L1680-NUMBER-OF-YEARS
024187                                TO L0290-INPUT-V00
024187         MOVE 0                 TO L0290-PRECISION
024187         MOVE LENGTH OF MIR-DV-CLI-DISAB-AGE
024187                                TO L0290-MAX-OUT-LEN
024187         PERFORM  0290-2000-FORMAT-FOR-MIR
024187             THRU 0290-2000-FORMAT-FOR-MIR-X
024187         MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-CLI-DISAB-AGE
           ELSE
               MOVE ZERO              TO MIR-DV-CLI-DISAB-AGE
557660     END-IF.

      *** RECALC NEXT SCHEDULED PAYMENT DATE
           PERFORM  6820-1000-BUILD-PARM-INFO
               THRU 6820-1000-BUILD-PARM-INFO-X.

           MOVE RDCD-PREV-SCHD-PMT-DT TO L6820-PREV-SCHD-PMT-DT.
           MOVE RPOL-POL-CEAS-DT      TO L6820-POL-CEAS-DT.
           PERFORM  6820-1000-CALC-PMT-DT
               THRU 6820-1000-CALC-PMT-DT-X.

           IF  L6820-RETRN-OK
               MOVE L6820-CLM-PMT-DT  TO L1640-INTERNAL-DATE
           END-IF.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DV-NXT-CLM-PMT-DT.

           MOVE 'Y'                   TO WS-PO-UPDATE-SW.

       7501-EDIT-DISAB-DATE-X.
           EXIT.

      *****************************************************************
      *  DISABILITY REASON - MUST BE IN ETAB/DISRE
      *****************************************************************
      *********************
       7502-EDIT-DISAB-RSN.
      *********************

           IF MIR-DISAB-REASN-CD = SPACES
               MOVE RDCL-DISAB-REASN-CD
                                      TO MIR-DISAB-REASN-CD
               GO TO 7502-EDIT-DISAB-RSN-X
557660     END-IF.

           IF MIR-DISAB-REASN-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-DISAB-REASN-CD
557660     END-IF.

           MOVE MIR-DISAB-REASN-CD    TO WEDIT-ETBL-VALU-ID
           PERFORM  DISR-1000-EDIT-DISAB-RSN
               THRU DISR-1000-EDIT-DISAB-RSN-X
           IF NOT WEDIT-IO-OK
               MOVE 'CS05810004'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: DISABILITY REASON MUST BE IN ETAB/DISRE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE MIR-DISAB-REASN-CD            TO RDCL-DISAB-REASN-CD
557660     END-IF.

       7502-EDIT-DISAB-RSN-X.
           EXIT.

      *****************************************************************
      *  REPORT DATE - MUST BE IN VALID DATE FORMAT
      *****************************************************************
      ***********************
       7503-EDIT-REPORT-DATE.
      ***********************

           IF MIR-DISAB-RPT-DT = SPACES
               MOVE RDCL-DISAB-RPT-DT TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-DISAB-RPT-DT
               GO TO 7503-EDIT-REPORT-DATE-X
557660     END-IF.

           MOVE MIR-DISAB-RPT-DT      TO L1640-EXTERNAL-DATE.
005409*    SET L1640-DO-NOT-USE-LEAP-YEAR TO TRUE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'CS05810005'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: REPORT DATE MUST BE ENTERED IN VALID FORMAT
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO RDCL-DISAB-RPT-DT
557660     END-IF.

       7503-EDIT-REPORT-DATE-X.
           EXIT.

      *****************************************************************
      *  DISABILITY TYPE - MUST BE (A)CCIDENT OR (S)ICKNESS
      *****************************************************************
      **********************
       7504-EDIT-DISAB-TYPE.
      **********************

           IF MIR-INSRD-DISAB-TYP-CD = SPACES
               MOVE RDCL-INSRD-DISAB-TYP-CD
                                      TO MIR-INSRD-DISAB-TYP-CD
               GO TO 7504-EDIT-DISAB-TYPE-X
557660     END-IF.

           IF MIR-INSRD-DISAB-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-INSRD-DISAB-TYP-CD
               MOVE SPACES            TO RDCL-INSRD-DISAB-TYP-CD
               GO TO 7504-EDIT-DISAB-TYPE-X
557660     END-IF.

           MOVE MIR-INSRD-DISAB-TYP-CD            TO WS-EDIT-DISAB-TYPE.
           IF WS-VALID-DISAB-TYPE
               MOVE MIR-INSRD-DISAB-TYP-CD
                                      TO RDCL-INSRD-DISAB-TYP-CD
           ELSE
               MOVE 'CS05810006'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: DISABILITY TYPE MUST BE A OR S
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7504-EDIT-DISAB-TYPE-X.
           EXIT.

      *****************************************************************
      *  CURRENT OCCUPATION CODE - MUST BE IN ETAB/OCCCD
      *****************************************************************
      *************************
       7505-EDIT-CURR-OCC-CODE.
      *************************

           IF MIR-INSRD-CRNT-OCCP-CD = SPACES
               MOVE RDCL-INSRD-CRNT-OCCP-CD
                                      TO MIR-INSRD-CRNT-OCCP-CD
               GO TO 7505-EDIT-CURR-OCC-CODE-X
557660     END-IF.

           IF MIR-INSRD-CRNT-OCCP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-INSRD-CRNT-OCCP-CD
               MOVE SPACES            TO RDCL-INSRD-CRNT-OCCP-CD
               GO TO 7505-EDIT-CURR-OCC-CODE-X
557660     END-IF.

           MOVE MIR-INSRD-CRNT-OCCP-CD             TO WEDIT-ETBL-VALU-ID
           PERFORM  OCCD-1000-EDIT
               THRU OCCD-1000-EDIT-X
           IF NOT WEDIT-IO-OK
               MOVE 'CS05810007'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CURRENT OCCUPATION CODE MUST BE IN ETAB/OCCCD
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE MIR-INSRD-CRNT-OCCP-CD
                                      TO RDCL-INSRD-CRNT-OCCP-CD
557660     END-IF.

       7505-EDIT-CURR-OCC-CODE-X.
           EXIT.

      *****************************************************************
      *  CLOSE DATE - MUST BE IN VALID DATE FORMAT
      *****************************************************************
      **********************
       7506-EDIT-CLOSE-DATE.
      **********************

           IF MIR-DI-CLM-CLOS-DT = SPACES
               MOVE RDCL-DI-CLM-CLOS-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-DI-CLM-CLOS-DT
               GO TO 7506-EDIT-CLOSE-DATE-X
557660     END-IF.

           MOVE MIR-DI-CLM-CLOS-DT    TO L1640-EXTERNAL-DATE.
005409*    MOVE 'E'                      TO L1640-LEAP-YEAR-SW.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'CS05810008'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CLOSE DATE MUST BE ENTERED IN VALID FORMAT
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO RDCL-DI-CLM-CLOS-DT
557660     END-IF.

       7506-EDIT-CLOSE-DATE-X.
           EXIT.

      *****************************************************************
      *  CLOSE REASON - MUST BE IN ETAB/CLSRE
      *****************************************************************
      *********************
       7507-EDIT-CLOSE-RSN.
      *********************

           IF MIR-CLM-CLOS-REASN-CD = SPACES
               MOVE RDCL-CLM-CLOS-REASN-CD
                                      TO MIR-CLM-CLOS-REASN-CD
               GO TO 7507-EDIT-CLOSE-RSN-X
557660     END-IF.

           MOVE MIR-CLM-CLOS-REASN-CD TO WEDIT-ETBL-VALU-ID
           PERFORM  CLSR-1000-EDIT-CLOSE-RSN
               THRU CLSR-1000-EDIT-CLOSE-RSN-X
           IF NOT WEDIT-IO-OK
               MOVE 'CS05810009'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CLOSE REASON MUST BE IN ETAB/CLSRE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE MIR-CLM-CLOS-REASN-CD
                                      TO RDCL-CLM-CLOS-REASN-CD
557660     END-IF.

       7507-EDIT-CLOSE-RSN-X.
           EXIT.

      *****************************************************************
      *  COMMENTS - NO EDITS
      *****************************************************************
      ********************
       7508-EDIT-COMMENTS.
      ********************

           IF MIR-DI-CLM-RMRK-TXT = SPACES
               MOVE RDCL-DI-CLM-RMRK-TXT
                                      TO MIR-DI-CLM-RMRK-TXT
               GO TO 7508-EDIT-COMMENTS-X
557660     END-IF.

           IF MIR-DI-CLM-RMRK-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-DI-CLM-RMRK-TXT
557660     END-IF.

           MOVE MIR-DI-CLM-RMRK-TXT   TO RDCL-DI-CLM-RMRK-TXT.

       7508-EDIT-COMMENTS-X.
           EXIT.

      *****************************************************************
      *  CLAIM APPROVAL SWITCH - MUST BE (Y)ES OR (N)O
      *****************************************************************
      ***********************
       7510-EDIT-APPROVAL-SW.
      ***********************

           IF MIR-CLM-APROV-CD = SPACES
               MOVE RDCD-CLM-APROV-CD TO MIR-CLM-APROV-CD
               GO TO 7510-EDIT-APPROVAL-SW-X
557660     END-IF.

           IF MIR-CLM-APROV-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CLM-APROV-CD
               MOVE SPACES            TO RDCD-CLM-APROV-CD
               GO TO 7510-EDIT-APPROVAL-SW-X
557660     END-IF.

           MOVE MIR-CLM-APROV-CD      TO WS-EDIT-APPROVAL-SW.
           IF WS-VALID-APPROVAL-SW
               MOVE MIR-CLM-APROV-CD  TO RDCD-CLM-APROV-CD
           ELSE
               MOVE 'CS05810010'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CLAIM APPROVAL SWITCH MUST BE Y OR N
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

           IF  RDCD-CLM-APPROVED
           AND RDCL-CLM-CRNT-STAT-CLOSED
               MOVE 'CS05810011'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CANNOT APPROVE CLAIM FOR PAYMENT - CLAIM CLOSED
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7510-EDIT-APPROVAL-SW-X.
           EXIT.

      *****************************************************************
      *  METHOD OF PAYMENT - MUST BE CHQ, EFT, TRD OR TRP
      *****************************************************************
      **********************
       7511-EDIT-CLAIM-MTHD.
      **********************

           IF MIR-CLM-PAYO-MTHD-CD = SPACES
               MOVE RDCD-CLM-PAYO-MTHD-CD
                                      TO MIR-CLM-PAYO-MTHD-CD
               GO TO 7511-EDIT-CLAIM-MTHD-X
557660     END-IF.

           IF MIR-CLM-PAYO-MTHD-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE RPOL-CLM-PAYO-MTHD-CD
                                      TO MIR-CLM-PAYO-MTHD-CD
               MOVE RPOL-CLM-PAYO-MTHD-CD
                                      TO RDCD-CLM-PAYO-MTHD-CD
               GO TO 7511-EDIT-CLAIM-MTHD-X
557660     END-IF.

           MOVE MIR-CLM-PAYO-MTHD-CD  TO WS-EDIT-CLAIM-MTHD.
           IF WS-VALID-CLAIM-MTHD
               MOVE MIR-CLM-PAYO-MTHD-CD
                                      TO RDCD-CLM-PAYO-MTHD-CD
           ELSE
               MOVE 'CS05810012'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CLAIM PAYMENT METHOD MUST BE CHQ, EFT, TRD OR TRP
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7511-EDIT-CLAIM-MTHD-X.
           EXIT.

      *****************************************************************
      *  RECEPIENT OF PAYMENT - MUST BE (I)NSURED, (P)AYOR, (A)SSIGNEE,
      *                         (O)WNER, (S)POUSE OR BLANK
      *****************************************************************
      **********************
       7512-EDIT-CLAIM-RELA.
      **********************

           IF MIR-PAYO-RECIP-TYP-CD = SPACES
               MOVE RDCD-PAYO-RECIP-TYP-CD
                                      TO MIR-PAYO-RECIP-TYP-CD
               GO TO 7512-EDIT-CLAIM-RELA-X
557660     END-IF.

           IF MIR-PAYO-RECIP-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-PAYO-RECIP-TYP-CD
013578*        MOVE SPACE             TO MIR-RDESC
               MOVE SPACE             TO RDCD-PAYO-RECIP-TYP-CD
               GO TO 7512-EDIT-CLAIM-RELA-X
557660     END-IF.

           MOVE MIR-PAYO-RECIP-TYP-CD
                                      TO WS-EDIT-CLAIM-RELA.
           IF WS-VALID-CLAIM-RELA
               MOVE MIR-PAYO-RECIP-TYP-CD
                                      TO RDCD-PAYO-RECIP-TYP-CD
013578*        MOVE MIR-PAYO-RECIP-TYP-CD
013578*                               TO WEDIT-ETBL-VALU-ID
013578*        PERFORM  RELA-2000-DESC
013578*            THRU RELA-2000-DESC-X
013578*        IF WEDIT-IO-OK
013578*            MOVE REDIT-ETBL-DESC-TXT
013578*                               TO MIR-RDESC
013578*        END-IF
           ELSE
               MOVE 'CS05810013'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CLAIM PAYMENT RECIPIENT MUST BE I,P,A,O,S OR BLANK
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7512-EDIT-CLAIM-RELA-X.
           EXIT.

      *****************************************************************
      *  AUTO PAYMENT SWITCH - MUST BE (Y)ES OR (N)O
      *****************************************************************
      ************************
       7513-EDIT-AUTO-PYMT-SW.
      ************************

           IF MIR-CLM-AUTO-PMT-IND = SPACES
               MOVE RDCD-CLM-AUTO-PMT-IND
                                      TO MIR-CLM-AUTO-PMT-IND
               GO TO 7513-EDIT-AUTO-PYMT-SW-X
557660     END-IF.

           IF MIR-CLM-AUTO-PMT-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CLM-AUTO-PMT-IND
               MOVE SPACES            TO RDCD-CLM-AUTO-PMT-IND
               GO TO 7513-EDIT-AUTO-PYMT-SW-X
557660     END-IF.

           MOVE MIR-CLM-AUTO-PMT-IND  TO WS-EDIT-AUTO-PYMT-SW.
           IF WS-VALID-AUTO-PYMT-SW
               MOVE MIR-CLM-AUTO-PMT-IND
                                      TO RDCD-CLM-AUTO-PMT-IND
           ELSE
               MOVE 'CS05810014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *
      *        MSG: AUTO PAYMENT SWITCH MUST BE Y OR N
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7513-EDIT-AUTO-PYMT-SW-X.
           EXIT.

      *****************************************************************
      *  AUTO PAYMENT EXPIRY DATE - MUST BE IN VALID DATE FORMAT
      *****************************************************************
      ******************************
       7514-EDIT-AUTO-PYMT-EXP-DATE.
      ******************************

           IF MIR-AUTO-PMT-XPRY-DT = SPACES
               MOVE RDCD-AUTO-PMT-XPRY-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-AUTO-PMT-XPRY-DT
               GO TO 7514-EDIT-AUTO-PYMT-EXP-DATE-X
557660     END-IF.

           IF MIR-AUTO-PMT-XPRY-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-AUTO-PMT-XPRY-DT
               MOVE WWKDT-ZERO-DT     TO RDCD-AUTO-PMT-XPRY-DT
               GO TO 7514-EDIT-AUTO-PYMT-EXP-DATE-X
557660     END-IF.

           MOVE MIR-AUTO-PMT-XPRY-DT  TO L1640-EXTERNAL-DATE.
005409*    MOVE 'E'                      TO L1640-LEAP-YEAR-SW.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'CS05810016'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: AUTO PYMT EXP DATE MUST BE ENTERED IN VALID FORMAT
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO RDCD-AUTO-PMT-XPRY-DT
557660     END-IF.

       7514-EDIT-AUTO-PYMT-EXP-DATE-X.
           EXIT.

      *****************************************************************
      *  ADDRESS TYPE CODE
      *****************************************************************
      **************************
       7515-EDIT-ADDR-TYPE-CODE.
      **************************

           IF MIR-CLI-ADDR-TYP-CD = SPACES
               MOVE RDCD-CLI-ADDR-TYP-CD
                                      TO MIR-CLI-ADDR-TYP-CD
               GO TO 7515-EDIT-ADDR-TYPE-CODE-X
557660     END-IF.

           IF MIR-CLI-ADDR-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RDCD-CLI-ADDR-TYP-CD
               MOVE SPACES            TO MIR-CLI-ADDR-TYP-CD
               GO TO 7515-EDIT-ADDR-TYPE-CODE-X
557660     END-IF.

           MOVE MIR-CLI-ADDR-TYP-CD   TO WEDIT-ETBL-VALU-ID.
           PERFORM  ADDR-1000-EDIT
               THRU ADDR-1000-EDIT-X.
           IF  NOT WEDIT-IO-OK
               MOVE 'CS05810082'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: ADDRESS TYPE MUST BE IN EDIT-ADTYP
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
               GO TO 7515-EDIT-ADDR-TYPE-CODE-X
557660     END-IF.

           MOVE MIR-CLI-ADDR-TYP-CD   TO RDCD-CLI-ADDR-TYP-CD.

       7515-EDIT-ADDR-TYPE-CODE-X.
           EXIT.

      *****************************************************************
      *  MAXIMUM BENEFIT TYPE - MUST BE (A)GE, (M)ONTHS, (Y)EARS OR
      *                         (O)VERRIDE
      *****************************************************************
      ************************
       7520-EDIT-MAX-BEN-TYPE.
      ************************

           IF MIR-MAX-BNFT-TYP-CD = SPACES
               MOVE WCVDI-MAX-BNFT-TYP-CD (I)
                                      TO MIR-MAX-BNFT-TYP-CD
               GO TO 7520-EDIT-MAX-BEN-TYPE-X
557660     END-IF.

           IF MIR-MAX-BNFT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-MAX-BNFT-TYP-CD
               MOVE SPACES            TO WCVDI-MAX-BNFT-TYP-CD (I)
               GO TO 7520-EDIT-MAX-BEN-TYPE-X
557660     END-IF.

           MOVE MIR-MAX-BNFT-TYP-CD   TO WS-EDIT-MAX-BEN-TYPE.
           IF WS-VALID-MAX-BEN-TYPE
               MOVE MIR-MAX-BNFT-TYP-CD
                                      TO WCVDI-MAX-BNFT-TYP-CD (I)
           ELSE
               MOVE 'CS05810018'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: MAX BENEFIT PERIOD QUALIFIER MUST BE A, M, Y OR O
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7520-EDIT-MAX-BEN-TYPE-X.
           EXIT.

      *****************************************************************
      *  MAXIMUM BENEFIT PERIOD - MUST BE NUMERIC.
      *****************************************************************
      **************************
       7521-EDIT-MAX-BEN-PERIOD.
      **************************

           IF MIR-MAX-BNFT-DUR = SPACES
               MOVE WCVDI-MAX-BNFT-DUR-N (I)
                                      TO MIR-MAX-BNFT-DUR
               GO TO 7521-EDIT-MAX-BEN-PERIOD-X
557660     END-IF.

           IF MIR-MAX-BNFT-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-MAX-BNFT-DUR
               MOVE ZEROS             TO WCVDI-MAX-BNFT-DUR-N (I)
               GO TO 7521-EDIT-MAX-BEN-PERIOD-X
557660     END-IF.

      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE '2'                   TO L0280-INPUT-SIZE.

      ***  PERFORM NUMERIC EDIT.
           MOVE MIR-MAX-BNFT-DUR      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WCVDI-MAX-BNFT-DUR-N (I)
               MOVE WCVDI-MAX-BNFT-DUR-N (I)
                                      TO MIR-MAX-BNFT-DUR
           ELSE
               MOVE 'CS05810017'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: MAX BENEFIT PERIOD MUST BE A VALID NUMERIC
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7521-EDIT-MAX-BEN-PERIOD-X.
           EXIT.

      *****************************************************************
      *  REDUCED ELIMINATION PERIOD - MUST BE NUMERIC
      *****************************************************************
      ***************************
       7522-EDIT-RED-ELIM-PERIOD.
      ***************************

           IF MIR-REDC-EP-DUR = SPACES
               MOVE WCVDI-REDC-EP-DUR-N   (I)
                                      TO MIR-REDC-EP-DUR
               GO TO 7522-EDIT-RED-ELIM-PERIOD-X
557660     END-IF.

           IF MIR-REDC-EP-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-REDC-EP-DUR
               MOVE ZEROS             TO WCVDI-REDC-EP-DUR-N   (I)
               GO TO 7522-EDIT-RED-ELIM-PERIOD-X
557660     END-IF.

      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '3'                   TO L0280-INPUT-SIZE.

      ***  PERFORM NUMERIC EDIT.
           MOVE MIR-REDC-EP-DUR       TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WCVDI-REDC-EP-DUR-N   (I)
               MOVE WCVDI-REDC-EP-DUR-N   (I)
                                      TO MIR-REDC-EP-DUR
           ELSE
               MOVE 'CS05810019'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: REDUCED ELIMINATION PERIOD MUST BE A VALID NUMERIC
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

      *** RECALC NEXT SCHEDULED PAYMENT DATE
           PERFORM  6820-1000-BUILD-PARM-INFO
               THRU 6820-1000-BUILD-PARM-INFO-X.

           MOVE RDCD-PREV-SCHD-PMT-DT TO L6820-PREV-SCHD-PMT-DT.
           MOVE RPOL-POL-CEAS-DT      TO L6820-POL-CEAS-DT.
           PERFORM  6820-1000-CALC-PMT-DT
               THRU 6820-1000-CALC-PMT-DT-X.

           MOVE L6820-CLM-PMT-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DV-NXT-CLM-PMT-DT.

           MOVE 'Y'                   TO WS-PO-UPDATE-SW.

       7522-EDIT-RED-ELIM-PERIOD-X.
           EXIT.

      *****************************************************************
      *  OWN OCCUPATION PERIOD - MUST BE NUMERIC
      *****************************************************************
      **************************
       7523-EDIT-OWN-OCC-PERIOD.
      **************************

           IF MIR-OWN-OCCP-DUR = SPACES
               MOVE WCVDI-OWN-OCCP-DUR-N (I)
                                      TO MIR-OWN-OCCP-DUR
               GO TO 7523-EDIT-OWN-OCC-PERIOD-X
557660     END-IF.

           IF MIR-OWN-OCCP-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-OWN-OCCP-DUR
               MOVE ZEROS             TO WCVDI-OWN-OCCP-DUR-N (I)
               GO TO 7523-EDIT-OWN-OCC-PERIOD-X
557660     END-IF.

      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE '2'                   TO L0280-INPUT-SIZE.

      ***  PERFORM NUMERIC EDIT.
           MOVE MIR-OWN-OCCP-DUR      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WCVDI-OWN-OCCP-DUR-N (I)
               MOVE WCVDI-OWN-OCCP-DUR-N (I)
                                      TO MIR-OWN-OCCP-DUR
           ELSE
               MOVE 'CS05810020'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: OWN OCCUPATION PERIOD MUST BE A VALID NUMERIC
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7523-EDIT-OWN-OCC-PERIOD-X.
           EXIT.

      *****************************************************************
      *  BENEFIT STATUS INDICATOR - MUST BE (N)ON-APPLICABLE, (P)ENDING,
      *                             (O)PEN OR (C)LOSED
      *****************************************************************
      **********************
       7524-EDIT-BEN-ST-IND.
      **********************

           IF MIR-CVG-BNFT-STAT-CD = SPACES
               MOVE WCVDI-CVG-BNFT-STAT-CD (I)
                                      TO MIR-CVG-BNFT-STAT-CD
               GO TO 7524-EDIT-BEN-ST-IND-X
557660     END-IF.

           IF MIR-CVG-BNFT-STAT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE 1                 TO I
               PERFORM  2430-1000-BUILD-PARM-INFO
                   THRU 2430-1000-BUILD-PARM-INFO-X
               PERFORM  2430-3100-GET-PRIM-INSRD
                   THRU 2430-3100-GET-PRIM-INSRD-X
               IF NOT WCVGS-CVG-INS-TYP-HEALTH (I)
016494**       OR WCVGS-CVG-SUM-INS-AMT (I) = ZERO
               OR L2430-CLI-ID NOT = RDCL-CLI-ID
                   MOVE 'N'           TO MIR-CVG-BNFT-STAT-CD
                   MOVE 'N'           TO WCVDI-CVG-BNFT-STAT-CD (I)
                   GO                    TO 7524-EDIT-BEN-ST-IND-X
               END-IF
               IF WCVGS-CVG-SUPP-BNFT-CD (I) = 'A'
                   MOVE 'A'           TO MIR-CVG-BNFT-STAT-CD
                   MOVE 'A'           TO WCVDI-CVG-BNFT-STAT-CD (I)
                   GO                    TO 7524-EDIT-BEN-ST-IND-X
               ELSE
                   MOVE 'P'           TO MIR-CVG-BNFT-STAT-CD
                   MOVE 'P'           TO WCVDI-CVG-BNFT-STAT-CD (I)
                   GO TO 7524-EDIT-BEN-ST-IND-X
               END-IF
           END-IF.

           MOVE MIR-CVG-BNFT-STAT-CD  TO WS-EDIT-BEN-ST-IND.
           IF NOT WS-VALID-BEN-ST-IND
               MOVE 'CS05810021'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: BENEFIT STATUS MUST BE N, 'A', P, O OR C
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
               GO TO 7524-EDIT-BEN-ST-IND-X
557660     END-IF.

           IF MIR-CVG-BNFT-STAT-CD = 'N'
               MOVE 'CS05810076'      TO WGLOB-MSG-REF-INFO
      *** MSG (W) WARNING ... BEN-ST INDICATES BENEFITS ARE NOT PAYABLE
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-DATA-EDITS
                   GO TO 7524-EDIT-BEN-ST-IND-X
557660         END-IF
557660     END-IF.

           IF  MIR-CVG-BNFT-STAT-CD = 'A'
           AND WCVGS-CVG-SUPP-BNFT-CD (I) NOT = 'A'
               MOVE 'CS05810080'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: BEN-ST OF 'A' VALID ONLY ON AD&D SUPP BENEFIT RIDERS
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
               GO TO 7524-EDIT-BEN-ST-IND-X
557660     END-IF.

           MOVE MIR-CVG-BNFT-STAT-CD  TO WCVDI-CVG-BNFT-STAT-CD (I).

           IF WCVDI-CVG-BNFT-STAT-OPEN-BNFT (I)
               MOVE RDCL-INSRD-DISAB-DT
                                      TO L1680-INTERNAL-1
               MOVE WCVDI-REDC-EP-DUR-N   (I)
                                      TO L1680-NUMBER-OF-DAYS
               MOVE ZEROES            TO L1680-NUMBER-OF-MONTHS
               MOVE ZEROES            TO L1680-NUMBER-OF-YEARS
               PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
                  THRU  1680-3000-ADD-Y-M-D-TO-DATE-X
               IF L1680-INTERNAL-2 < RDCD-PREV-SCHD-PMT-DT
                   MOVE 'CS05810081'  TO WGLOB-MSG-REF-INFO
      *
      *            MSG: WARNING - PAYMENTS PROCESSED ON THIS POLICY
      *
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

      *** RECALC NEXT SCHEDULED PAYMENT DATE
           PERFORM  6820-1000-BUILD-PARM-INFO
               THRU 6820-1000-BUILD-PARM-INFO-X.

           MOVE RDCD-PREV-SCHD-PMT-DT TO L6820-PREV-SCHD-PMT-DT.
           MOVE RPOL-POL-CEAS-DT      TO L6820-POL-CEAS-DT.
           PERFORM  6820-1000-CALC-PMT-DT
               THRU 6820-1000-CALC-PMT-DT-X.

           MOVE L6820-CLM-PMT-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DV-NXT-CLM-PMT-DT.

           MOVE 'Y'                   TO WS-PO-UPDATE-SW.

       7524-EDIT-BEN-ST-IND-X.
           EXIT.

      *****************************************************************
      *  CURRENT BENEFIT AMOUNT - MUST BE NUMERIC
      *****************************************************************
      ************************
       7525-EDIT-CURR-BEN-AMT.
      ************************

           IF MIR-MTHLY-BNFT-AMT = SPACES
008455*        MOVE WCVDI-MTHLY-BNFT-AMT (I) TO WS-NUM-7V2
008455*        MOVE WS-NUM-7V2            TO MIR-MTHLY-BNFT-AMT
008455         MOVE WCVDI-MTHLY-BNFT-AMT (I)
                                      TO L0290-INPUT-NUMBER
020874*        COMPUTE L0290-INPUT-NUMBER = WCVDI-MTHLY-BNFT-AMT (I)
020874*                                     * 100
020874         MOVE WCVDI-MTHLY-BNFT-AMT (I) TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MTHLY-BNFT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MTHLY-BNFT-AMT
               GO TO 7525-EDIT-CURR-BEN-AMT-X
557660     END-IF.

           IF MIR-MTHLY-BNFT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROS                 TO WS-NUM-7V2
008455*        MOVE WS-NUM-7V2            TO MIR-MTHLY-BNFT-AMT
008455         MOVE ZEROS             TO MIR-MTHLY-BNFT-AMT
               MOVE ZEROS             TO WCVDI-MTHLY-BNFT-AMT (I)
               GO TO 7525-EDIT-CURR-BEN-AMT-X
557660     END-IF.

      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '2'                   TO L0280-PRECISION.
008455*    MOVE '7'            TO L0280-LENGTH.
008455*    MOVE '10'           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-MTHLY-BNFT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

      ***  PERFORM NUMERIC EDIT.
           MOVE MIR-MTHLY-BNFT-AMT
                                      TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVDI-MTHLY-BNFT-AMT (I)
008455*        MOVE WCVDI-MTHLY-BNFT-AMT (I) TO WS-NUM-7V2
008455*        MOVE WS-NUM-7V2            TO MIR-MTHLY-BNFT-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MTHLY-BNFT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MTHLY-BNFT-AMT
           ELSE
               MOVE 'CS05810022'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CURRENT BENEFIT AMOUNT MUST BE A VALID NUMERIC
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7525-EDIT-CURR-BEN-AMT-X.
           EXIT.

      *****************************************************************
      *  BENEFIT ADJUSTMENT REASON - MUST BE IN ETAB/ADJRE
      *****************************************************************
      ***********************
       7526-EDIT-BEN-ADJ-RSN.
      ***********************

           IF MIR-BNFT-ADJ-REASN-CD = SPACES
               MOVE WCVDI-BNFT-ADJ-REASN-CD (I)
                                      TO MIR-BNFT-ADJ-REASN-CD
               GO TO 7526-EDIT-BEN-ADJ-RSN-X
557660     END-IF.

           IF MIR-BNFT-ADJ-REASN-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-BNFT-ADJ-REASN-CD
               MOVE SPACES            TO WCVDI-BNFT-ADJ-REASN-CD (I)
               GO TO 7526-EDIT-BEN-ADJ-RSN-X
557660     END-IF.

           MOVE MIR-BNFT-ADJ-REASN-CD TO WEDIT-ETBL-VALU-ID.
           PERFORM  ADJR-1000-EDIT-BEN-ADJ-RSN
               THRU ADJR-1000-EDIT-BEN-ADJ-RSN-X.
           IF NOT WEDIT-IO-OK
               MOVE 'CS05810023'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: BENEFIT ADJUSTMENT REASON MUST BE IN ETAB/ADJRE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE MIR-BNFT-ADJ-REASN-CD
                                      TO WCVDI-BNFT-ADJ-REASN-CD (I)
557660     END-IF.

       7526-EDIT-BEN-ADJ-RSN-X.
           EXIT.

      *****************************************************************
      *  BENEFIT EXPIRY DATE - MUST BE IN VALID DATE FORMAT
      *****************************************************************
      ************************
       7527-EDIT-BEN-EXP-DATE.
      ************************

           IF MIR-BNFT-XPRY-DT = SPACES
               MOVE WCVDI-BNFT-XPRY-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-BNFT-XPRY-DT
               GO TO 7527-EDIT-BEN-EXP-DATE-X
557660     END-IF.

           IF MIR-BNFT-XPRY-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-BNFT-XPRY-DT
               MOVE WWKDT-ZERO-DT     TO WCVDI-BNFT-XPRY-DT (I)
               GO TO 7527-EDIT-BEN-EXP-DATE-X
557660     END-IF.

           MOVE MIR-BNFT-XPRY-DT      TO L1640-EXTERNAL-DATE.
005409*    MOVE 'E'                      TO L1640-LEAP-YEAR-SW.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'CS05810024'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: BENEFIT EXPIRY DATE MUST BE ENTERED IN VALID FORMAT
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WCVDI-BNFT-XPRY-DT (I)
557660     END-IF.

       7527-EDIT-BEN-EXP-DATE-X.
           EXIT.

      *****************************************************************
      *  RESIDUAL MULTIPLIER - MUST BE NUMERIC
      *****************************************************************
      **********************
       7528-EDIT-RESID-MULT.
      **********************

           IF MIR-RSDUE-BNFT-FCT = SPACES
020874*        MOVE WCVDI-RSDUE-BNFT-FCT (I)
020874*                               TO WS-NUM-1V2
020874*        MOVE WS-NUM-1V2        TO MIR-RSDUE-BNFT-FCT
020874         MOVE WCVDI-RSDUE-BNFT-FCT (I)  TO L0290-INPUT-V02
020874         MOVE 2                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-RSDUE-BNFT-FCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-RSDUE-BNFT-FCT
               GO TO 7528-EDIT-RESID-MULT-X
557660     END-IF.

           IF MIR-RSDUE-BNFT-FCT = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE ZEROS             TO WS-NUM-1V2
020874*        MOVE WS-NUM-1V2        TO MIR-RSDUE-BNFT-FCT
020874         MOVE ZEROS                 TO L0290-INPUT-V02
020874         MOVE 2                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-RSDUE-BNFT-FCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-RSDUE-BNFT-FCT
               MOVE ZEROS             TO WCVDI-RSDUE-BNFT-FCT (I)
               GO TO 7528-EDIT-RESID-MULT-X
557660     END-IF.

      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '2'                   TO L0280-PRECISION.
           MOVE '1'                   TO L0280-LENGTH.
           MOVE '4'                   TO L0280-INPUT-SIZE.

      ***  PERFORM NUMERIC EDIT.
           MOVE MIR-RSDUE-BNFT-FCT    TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVDI-RSDUE-BNFT-FCT (I)
020874*        MOVE WCVDI-RSDUE-BNFT-FCT (I)
020874*                               TO WS-NUM-1V2
020874*        MOVE WS-NUM-1V2        TO MIR-RSDUE-BNFT-FCT
020874         MOVE WCVDI-RSDUE-BNFT-FCT (I) TO L0290-INPUT-V02
020874         MOVE 2                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-RSDUE-BNFT-FCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-RSDUE-BNFT-FCT
           ELSE
               MOVE 'CS05810025'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: RESIDUAL MULTIPLIER MUST BE A VALID NUMERIC
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7528-EDIT-RESID-MULT-X.
           EXIT.

      *****************************************************************
      *  RESIDUAL DISABILITY DATE - MUST BE IN VALID DATE FORMAT
      *****************************************************************
      ****************************
       7529-EDIT-RESID-DISAB-DATE.
      ****************************

           IF MIR-RSDUE-BNFT-STRT-DT = SPACES
               MOVE WCVDI-RSDUE-BNFT-STRT-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-RSDUE-BNFT-STRT-DT
               GO TO 7529-EDIT-RESID-DISAB-DATE-X
557660     END-IF.

           IF MIR-RSDUE-BNFT-STRT-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-RSDUE-BNFT-STRT-DT
               MOVE WWKDT-ZERO-DT     TO WCVDI-RSDUE-BNFT-STRT-DT (I)
               GO TO 7529-EDIT-RESID-DISAB-DATE-X
557660     END-IF.

           MOVE MIR-RSDUE-BNFT-STRT-DT           TO L1640-EXTERNAL-DATE.
005409*    MOVE 'E'                      TO L1640-LEAP-YEAR-SW.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'CS05810026'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: RESIDUAL DISAB DATE MUST BE ENTERED IN VALID FORMAT
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WCVDI-RSDUE-BNFT-STRT-DT (I)
557660     END-IF.

       7529-EDIT-RESID-DISAB-DATE-X.
           EXIT.

015951*****************************************************************
015951*  COVERAGE DISABILITY PERCENTAGE - MUST BE NUMERIC
015951*                                 - IF ENTERED, MTHLY-BNFT-AMT
015951*                                   CALCULATED BY SYSTEM
015951*****************************************************************
015951************************
015951 7530-EDIT-CVG-DISAB-PCT.
015951************************
015951
015951     IF MIR-CVG-DISAB-PCT = SPACES
015951         MOVE WCVDI-CVG-DISAB-PCT(I)  TO L0290-INPUT-NUMBER
020874*        COMPUTE L0290-INPUT-NUMBER = WCVDI-CVG-DISAB-PCT(I)
020874*                                     * 100
020874         MOVE WCVDI-CVG-DISAB-PCT(I)  TO L0290-INPUT-V02
015951         MOVE 2                       TO L0290-PRECISION
015951         MOVE LENGTH OF MIR-CVG-DISAB-PCT
015951                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
015951         MOVE L0290-OUTPUT-DATA       TO MIR-CVG-DISAB-PCT
015951         GO TO 7530-EDIT-CVG-DISAB-PCT-X
015951     END-IF.
015951
015951     IF  MIR-CVG-DISAB-PCT = EBLCH-BLANK-FIELD-CHAR
015951         MOVE ZEROS                   TO MIR-CVG-DISAB-PCT
015951         MOVE ZEROS                   TO WCVDI-CVG-DISAB-PCT(I)
015951         GO TO 7530-EDIT-CVG-DISAB-PCT-X
015951     END-IF.
015951
015951***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
015951
015951     MOVE MIR-CVG-DISAB-PCT       TO L0280-INPUT-DATA.
015951     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
015951     MOVE '2'                         TO L0280-PRECISION.
015951     MOVE LENGTH OF MIR-CVG-DISAB-PCT TO L0280-INPUT-SIZE.
015951
015951     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
015951
015951***  PERFORM NUMERIC EDIT.
015951
015951     PERFORM 0280-1000-NUMERIC-EDIT
015951        THRU 0280-1000-NUMERIC-EDIT-X.
015951
015951     IF L0280-OK
015951         MOVE L0280-OUTPUT-V02        TO WCVDI-CVG-DISAB-PCT(I)
               MOVE L0280-OUTPUT            TO L0290-INPUT-NUMBER
015951         MOVE 2                       TO L0290-PRECISION
015951         MOVE LENGTH OF MIR-CVG-DISAB-PCT
015951                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
015951         MOVE L0290-OUTPUT-DATA       TO MIR-CVG-DISAB-PCT
015951     ELSE
015951*MSG: PERCENTAGE DISABILITY MUST BE A NUMERIC PERCENT IN
015951*     FORMAT 999.99
015951         MOVE 'CS05810089'            TO WGLOB-MSG-REF-INFO
015951         PERFORM 0260-1000-GENERATE-MESSAGE
015951            THRU 0260-1000-GENERATE-MESSAGE-X
015951         MOVE 'N'                     TO WS-DATA-EDITS
015951         GO TO 7530-EDIT-CVG-DISAB-PCT-X
015951     END-IF.
015951
015951     IF  L0280-OUTPUT-V02 > 100
015951*MSG: PERCENTAGE DISABILITY CANNOT EXCEED 100 PERCENT
015951         MOVE 'CS05810087'        TO WGLOB-MSG-REF-INFO
015951         PERFORM 0260-1000-GENERATE-MESSAGE
015951            THRU 0260-1000-GENERATE-MESSAGE-X
015951         MOVE 'N'                 TO WS-DATA-EDITS
015951     END-IF.
015951
015951 7530-EDIT-CVG-DISAB-PCT-X.
015951     EXIT.
015951

      *****************************************************************
      *  PERFORM ALL REQUIRED CROSS EDITS.
      *****************************************************************
      *-----------------------
       7600-XEDIT-DATA-FIELDS.
      *-----------------------

           SET WS-CROSS-EDITS-OK  TO TRUE.

           IF RDCL-INSRD-DISAB-DT NOT = WWKDT-ZERO-DT
               PERFORM  7601-XEDIT-DISAB-DATE
                   THRU 7601-XEDIT-DISAB-DATE-X
557660     END-IF.

           IF RDCL-DISAB-RPT-DT NOT = WWKDT-ZERO-DT
               PERFORM  7602-XEDIT-REPORT-DATE
                   THRU 7602-XEDIT-REPORT-DATE-X
557660     END-IF.

           IF RDCL-DI-CLM-CLOS-DT NOT = WWKDT-ZERO-DT
               PERFORM  7603-XEDIT-CLOSE-DATE
                   THRU 7603-XEDIT-CLOSE-DATE-X
557660     END-IF.

           PERFORM  7605-XEDIT-MTHD-RELA
               THRU 7605-XEDIT-MTHD-RELA-X.

           PERFORM  7613-XEDIT-ADDR-TYPE-CODE
               THRU 7613-XEDIT-ADDR-TYPE-CODE-X.

           PERFORM  7611-XEDIT-AUTO-PAY-IND
               THRU 7611-XEDIT-AUTO-PAY-IND-X.

           IF RDCD-AUTO-PMT-XPRY-DT   NOT = WWKDT-ZERO-DT
               PERFORM  7604-XEDIT-AUTO-PMT-EXP-DATE
                   THRU 7604-XEDIT-AUTO-PMT-EXP-DATE-X
557660     END-IF.

           PERFORM  7606-XEDIT-MAX-BEN-TYPE
               THRU 7606-XEDIT-MAX-BEN-TYPE-X.

           PERFORM  7607-XEDIT-RED-ELIM-PERIOD
               THRU 7607-XEDIT-RED-ELIM-PERIOD-X.

           PERFORM  7612-XEDIT-BEN-STATUS
               THRU 7612-XEDIT-BEN-STATUS-X.

           PERFORM  7608-XEDIT-BEN-ADJ-RSN
               THRU 7608-XEDIT-BEN-ADJ-RSN-X.

           PERFORM  7609-XEDIT-BEN-EXP-DATE
               THRU 7609-XEDIT-BEN-EXP-DATE-X.

           IF WCVDI-RSDUE-BNFT-STRT-DT (I) NOT = WWKDT-ZERO-DT
           OR WCVDI-RSDUE-BNFT-FCT (I) NOT = ZEROES
               PERFORM  7610-XEDIT-RESID-BENEFIT
                   THRU 7610-XEDIT-RESID-BENEFIT-X
557660     END-IF.

015951     PERFORM  7614-XEDIT-DISAB-PCT
015951         THRU 7614-XEDIT-DISAB-PCT-X.

       7600-XEDIT-DATA-FIELDS-X.
           EXIT.

      *****************************************************************
      *  DISABILITY DATE
      *****************************************************************
      ***********************
       7601-XEDIT-DISAB-DATE.
      ***********************

           IF RDCL-INSRD-DISAB-DT < RPOL-POL-ISS-EFF-DT
               MOVE 'CS05810027'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: DISABILITY DATE CANNOT BE PRIOR TO ISSUE DATE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

           IF RDCL-INSRD-DISAB-DT > WGLOB-PROCESS-DATE
               MOVE 'CS05810028'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: DISABILITY DATE CANNOT BE IN THE FUTURE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

       7601-XEDIT-DISAB-DATE-X.
           EXIT.

      *****************************************************************
      *  REPORT DATE
      *****************************************************************
      ************************
       7602-XEDIT-REPORT-DATE.
      ************************

           IF RDCL-DISAB-RPT-DT < RDCL-INSRD-DISAB-DT
               MOVE 'CS05810029'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: REPORT DATE CANNOT BE PRIOR TO DISABILITY DATE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

           IF RDCL-DISAB-RPT-DT > WGLOB-PROCESS-DATE
               MOVE 'CS05810030'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: REPORT DATE CANNOT BE IN THE FUTURE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

       7602-XEDIT-REPORT-DATE-X.
           EXIT.

      *****************************************************************
      *  CLOSE DATE
      *****************************************************************
      ***********************
       7603-XEDIT-CLOSE-DATE.
      ***********************

           IF RDCL-DI-CLM-CLOS-DT < RDCL-INSRD-DISAB-DT
               MOVE 'CS05810031'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CLAIM CLOSE DATE CANNOT BE PRIOR TO DISAB DATE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

           IF RDCL-DI-CLM-CLOS-DT > WGLOB-PROCESS-DATE
               MOVE 'CS05810032'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CLAIM CLOSE DATE CANNOT BE IN THE FUTURE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

       7603-XEDIT-CLOSE-DATE-X.
           EXIT.

      *****************************************************************
      *  AUTO PAYMENT EXPIRY DATE
      *****************************************************************
      ******************************
       7604-XEDIT-AUTO-PMT-EXP-DATE.
      ******************************

           IF  RDCD-CLM-AUTO-PMT-APPROVED
           AND RDCD-AUTO-PMT-XPRY-DT   < WGLOB-PROCESS-DATE
               MOVE 'CS05810033'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: AUTO PAYMENT EXPIRY DATE HAS BEEN REACHED
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-CROSS-EDITS
557660         END-IF
557660     END-IF.

       7604-XEDIT-AUTO-PMT-EXP-DATE-X.
           EXIT.

      *****************************************************************
      *  PAYMENT METHOD & RECIPIENT
      *****************************************************************
      **********************
       7605-XEDIT-MTHD-RELA.
      **********************

           IF  RDCD-CLM-PAYO-MTHD-CHQ
               IF  RDCD-PAYO-RECIP-TYP-CD = SPACES
                   MOVE 'CS05810034'  TO WGLOB-MSG-REF-INFO
                   MOVE RDCD-CLM-PAYO-MTHD-CD
                                      TO WGLOB-MSG-PARM (1)
      *
      *            MSG: FOR METHOD @1 RECIPIENT MUST BE ENTERED
      *
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
                   GO TO 7605-XEDIT-MTHD-RELA-X
               END-IF

               PERFORM  RECP-1000-GET-RECIPIENT
                   THRU RECP-1000-GET-RECIPIENT-X
               IF  NOT WRECP-RETRN-OK
                   MOVE 'CS05810037'  TO WGLOB-MSG-REF-INFO

      *   MSG: NO RELATIONSHIP RECORD EXISTS FOR RECIPIENT

                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
                   GO TO 7605-XEDIT-MTHD-RELA-X
               END-IF
           END-IF.

           IF  RDCD-CLM-PAYO-MTHD-EFT
               IF  RDCD-PAYO-RECIP-TYP-CD = SPACES
                   MOVE 'CS05810034'  TO WGLOB-MSG-REF-INFO
                   MOVE RDCD-CLM-PAYO-MTHD-CD
                                      TO WGLOB-MSG-PARM (1)
      *
      *            MSG: FOR METHOD @1 RECIPIENT MUST BE ENTERED
      *
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
                   GO TO 7605-XEDIT-MTHD-RELA-X
               END-IF

               PERFORM  RECP-1000-GET-RECIPIENT
                   THRU RECP-1000-GET-RECIPIENT-X
               IF  NOT WRECP-RETRN-OK
                   MOVE 'CS05810037'  TO WGLOB-MSG-REF-INFO

      *   MSG: NO RELATIONSHIP RECORD EXISTS FOR RECIPIENT

                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
                   GO TO 7605-XEDIT-MTHD-RELA-X
               END-IF

               PERFORM  5020-1000-BUILD-PARM-INFO
                   THRU 5020-1000-BUILD-PARM-INFO-X
               MOVE WRECP-CLI-ID      TO L5020-CLI-ID
               PERFORM  5020-1000-GET-BANK-INFO
                   THRU 5020-1000-GET-BANK-INFO-X
               IF NOT L5020-RETRN-OK
                   MOVE 'CS05810038'  TO WGLOB-MSG-REF-INFO
                   MOVE L5020-CLI-ID  TO WGLOB-MSG-PARM (1)
      *MSG: NO BANKING INFO EXISTS FOR CLIENT @1
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
               END-IF
           END-IF.

           IF  RDCD-CLM-PAYO-MTHD-TRD
           OR  RDCD-CLM-PAYO-MTHD-TRP
               IF  RDCD-PAYO-RECIP-TYP-CD NOT = SPACES
                   MOVE 'CS05810035'  TO WGLOB-MSG-REF-INFO
                   MOVE RDCD-CLM-PAYO-MTHD-CD
                                      TO WGLOB-MSG-PARM (1)
      *
      *            MSG: FOR METHOD @1 RECIPIENT MUST BE BLANK
      *
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
                   GO TO 7605-XEDIT-MTHD-RELA-X
               END-IF

               IF RPOL-CLM-PAYE-POL-CVG-INFO = SPACES
                   MOVE 'CS05810036'  TO WGLOB-MSG-REF-INFO
                   MOVE RDCD-CLM-PAYO-MTHD-CD
                                      TO WGLOB-MSG-PARM (1)
      *
      *            MSG: FOR METHOD @1 TRANSFER POLICY MUST BE ENTERED
      *
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
                   GO TO 7605-XEDIT-MTHD-RELA-X
               END-IF
           END-IF.

       7605-XEDIT-MTHD-RELA-X.
           EXIT.

      *****************************************************************
      *  MAXIMUM BENEFIT TYPE
      *****************************************************************
      *************************
       7606-XEDIT-MAX-BEN-TYPE.
      *************************

           IF  WCVDI-MAX-BNFT-TYP-CD (I) = SPACES
               MOVE 'CS05810046'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: MAX BENEFIT QUALIFIER REQUIRED TO CALC BEN EXP DATE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

       7606-XEDIT-MAX-BEN-TYPE-X.
           EXIT.

      *****************************************************************
      *  REDUCED ELIMINATION PERIOD
      *****************************************************************
      ****************************
       7607-XEDIT-RED-ELIM-PERIOD.
      ****************************

           IF WCVGS-CVG-STBL-2-CD (I) NOT NUMERIC
               IF WCVDI-REDC-EP-DUR-N   (I) = ZERO
                   GO TO 7607-XEDIT-RED-ELIM-PERIOD-X
               ELSE
                   MOVE 'CS05810079'  TO WGLOB-MSG-REF-INFO
      *
      *    MSG: CVG ELIM PERIOD NOT NUMERIC - RED ELIM CHANGED TO ZERO
      *
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE ZERO          TO WCVDI-REDC-EP-DUR-N   (I)
                   MOVE ZERO          TO MIR-REDC-EP-DUR
                   GO TO 7607-XEDIT-RED-ELIM-PERIOD-X
557660         END-IF
557660     END-IF.

           IF WCVGS-REDC-EP-SELCT-IND (I) = 'N'
               IF WCVDI-REDC-EP-DUR-N   (I) = WCVGS-CVG-STBL-2-CD (I)
                   GO TO 7607-XEDIT-RED-ELIM-PERIOD-X
               ELSE
                   MOVE 'CS05810066'  TO WGLOB-MSG-REF-INFO
      *
      *    MSG: HOSP NOT ELECTED-REDUCED ELIM PERIOD CHANGED TO DEFAULT
      *
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                MOVE WCVGS-CVG-STBL-2-CD (I)
                                      TO WCVDI-REDC-EP-DUR-N (I)
                   MOVE WCVGS-CVG-STBL-2-CD (I)
                                      TO MIR-REDC-EP-DUR
                   GO TO 7607-XEDIT-RED-ELIM-PERIOD-X
557660          END-IF
557660     END-IF.

           IF  WCVDI-REDC-EP-DUR-N   (I) > WCVGS-CVG-STBL-2-CD (I)
               MOVE 'CS05810039'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: REDUCED EP BENEFIT CANNOT BE GREATER THAN EP
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

       7607-XEDIT-RED-ELIM-PERIOD-X.
           EXIT.

      *****************************************************************
      *  BENEFIT ADJUSTMENT REASON
      *****************************************************************
      ************************
       7608-XEDIT-BEN-ADJ-RSN.
      ************************

           IF NOT WCVDI-CVG-BNFT-STAT-NON-APP (I)
              IF  WCVDI-MTHLY-BNFT-AMT (I) NOT = WCVGS-CVG-FACE-AMT (I)
              AND WCVDI-BNFT-ADJ-REASN-CD (I) = SPACES
                   MOVE 'CS05810040'  TO WGLOB-MSG-REF-INFO
      *
      *            MSG: ADJ RSN REQUIRED IF BENEFIT AMOUNTS DIFFER
      *
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
557660         END-IF
557660     END-IF.

       7608-XEDIT-BEN-ADJ-RSN-X.
           EXIT.

      *****************************************************************
      *  BENEFIT EXPIRY DATE
      *****************************************************************
      *************************
       7609-XEDIT-BEN-EXP-DATE.
      *************************

           EVALUATE WCVDI-MAX-BNFT-TYP-CD (I)

               WHEN 'A'

                   IF  L2435-RETRN-OK
                       MOVE L2435-CLI-BTH-DT
                                      TO L1680-INTERNAL-1
                       ADD WCVDI-MAX-BNFT-DUR-N (I) TO L1680-INT-YYYY-1
                       MOVE L1680-INTERNAL-1
                                      TO WCVDI-BNFT-XPRY-DT (I)
                   ELSE
                       MOVE WWKDT-ZERO-DT
                                      TO WCVDI-BNFT-XPRY-DT (I)
                   END-IF

               WHEN 'M'

                   MOVE RDCL-INSRD-DISAB-DT
                                      TO L1680-INTERNAL-1
                   MOVE WCVDI-REDC-EP-DUR-N (I)
                                      TO L1680-NUMBER-OF-DAYS
                   MOVE ZEROES        TO L1680-NUMBER-OF-MONTHS
                   MOVE ZEROES        TO L1680-NUMBER-OF-YEARS
                   PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
                       THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
                   MOVE L1680-INTERNAL-2
                                      TO L1680-INTERNAL-1
                   MOVE WWKDT-ZERO-DT TO L1680-INTERNAL-2
                   MOVE ZEROES        TO L1680-NUMBER-OF-DAYS
                   MOVE WCVDI-MAX-BNFT-DUR-N(I)
                                      TO
                                             L1680-NUMBER-OF-MONTHS
                   PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
                       THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
                   MOVE L1680-INTERNAL-2
                                      TO WCVDI-BNFT-XPRY-DT (I)

               WHEN 'Y'

                   MOVE RDCL-INSRD-DISAB-DT
                                      TO L1680-INTERNAL-1
                   MOVE WCVDI-REDC-EP-DUR-N (I)
                                      TO L1680-NUMBER-OF-DAYS
                   MOVE ZEROES        TO L1680-NUMBER-OF-MONTHS
                   MOVE ZEROES        TO L1680-NUMBER-OF-YEARS
                   PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
                       THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
                   MOVE L1680-INTERNAL-2
                                      TO L1680-INTERNAL-1
                   MOVE WWKDT-ZERO-DT TO L1680-INTERNAL-2
                   MOVE ZEROES        TO L1680-NUMBER-OF-DAYS
                   MOVE WCVDI-MAX-BNFT-DUR-N (I)
                                      TO
                                                 L1680-NUMBER-OF-YEARS
                   PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
                      THRU  1680-3000-ADD-Y-M-D-TO-DATE-X
                   MOVE L1680-INTERNAL-2
                                      TO WCVDI-BNFT-XPRY-DT (I)

           END-EVALUATE.

           IF  WCVDI-BNFT-XPRY-DT (I) = WWKDT-ZERO-DT
               IF  WCVDI-MAX-BNFT-TYP-CD (I) = 'O'
                   MOVE 'CS05810045'  TO WGLOB-MSG-REF-INFO
      *
      *            MSG: BENEFIT EXP DATE REQ'D WHEN OVERRIDE QUALIFIER
      *
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
                   GO TO 7609-XEDIT-BEN-EXP-DATE-X
               ELSE
                   GO TO 7609-XEDIT-BEN-EXP-DATE-X
557660         END-IF
557660     END-IF.

           MOVE WCVDI-BNFT-XPRY-DT (I)           TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-BNFT-XPRY-DT.

           IF WCVDI-BNFT-XPRY-DT (I) < WCVGS-CVG-ISS-EFF-DT (I)
               MOVE 'CS05810041'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: BENEFIT EXPIRY DATE CANNOT BE PRIOR TO CVG ISSUE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

           IF WCVDI-BNFT-XPRY-DT (I) < RDCL-INSRD-DISAB-DT
               MOVE 'CS05810042'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: BENEFIT EXPIRY DATE CANNOT BE PRIOR TO DISAB DATE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

       7609-XEDIT-BEN-EXP-DATE-X.
           EXIT.

      *****************************************************************
      *  RESIDUAL DISABILITY DATE
      *****************************************************************
      **************************
       7610-XEDIT-RESID-BENEFIT.
      **************************

           IF WCVGS-CVG-STBL-1-CD (I) NOT NUMERIC
               MOVE 'CS05810074'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: QUAL PERIOD INVALID - RESID BENEFITS NOT POSSIBLE
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
               GO TO 7610-XEDIT-RESID-BENEFIT-X
557660     END-IF.

           MOVE RDCL-INSRD-DISAB-DT   TO L1680-INTERNAL-1.
           MOVE WCVGS-CVG-STBL-1-CD (I)
                                      TO L1680-NUMBER-OF-DAYS.
           MOVE ZEROES                TO L1680-NUMBER-OF-MONTHS.
           MOVE ZEROES                TO L1680-NUMBER-OF-YEARS.
           PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
              THRU  1680-3000-ADD-Y-M-D-TO-DATE-X.

           IF WCVDI-RSDUE-BNFT-STRT-DT (I) < L1680-INTERNAL-2
               MOVE 'CS05810044'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: QUAL PERIOD FOR RESIDUAL BENEFITS NOT YET STAISFIED
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

       7610-XEDIT-RESID-BENEFIT-X.
           EXIT.

      *****************************************************************
      *  CANNOT HAVE AUTO PAY ON WHEN CLAIM IS NOT APPROVED
      *****************************************************************
       7611-XEDIT-AUTO-PAY-IND.

           IF  RDCD-CLM-AUTO-PMT-APPROVED
           AND NOT RDCD-CLM-APPROVED
               MOVE 'CS05810015'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: CANNOT APPROVE AUTO PAYMENT - CLAIM NOT APPROVED
      *
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS
557660     END-IF.

       7611-XEDIT-AUTO-PAY-IND-X.
           EXIT.

      *****************************************************************
      *  BENEFIT STATUS MUST BE N IF INSUREDS DO NOT MATCH OR COVERAGE
      *  DOES NOT PAY BENEFITS
      *****************************************************************
       7612-XEDIT-BEN-STATUS.

           IF  WCVDI-CVG-BNFT-STAT-NON-APP (I)
               GO TO 7612-XEDIT-BEN-STATUS-X
           END-IF.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-3100-GET-PRIM-INSRD
               THRU 2430-3100-GET-PRIM-INSRD-X.
           IF L2430-CLI-ID NOT = RDCL-CLI-ID
               MOVE 'N'               TO WCVDI-CVG-BNFT-STAT-CD (I)
               MOVE 'N'               TO MIR-CVG-BNFT-STAT-CD
               MOVE 'CS05810077'      TO WGLOB-MSG-REF-INFO
      *** MSG (S) CVG INSURED DOES NOT MATCH CLAIM INSURED
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7612-XEDIT-BEN-STATUS-X
           ELSE
               IF NOT WCVGS-CVG-INS-TYP-HEALTH (I)
016494*        OR WCVGS-CVG-SUM-INS-AMT (I) = ZERO
                   MOVE 'N'           TO WCVDI-CVG-BNFT-STAT-CD (I)
                   MOVE 'N'           TO MIR-CVG-BNFT-STAT-CD
                   MOVE 'CS05810078'  TO WGLOB-MSG-REF-INFO
                   MOVE I             TO WGLOB-MSG-PARM (1)
      *** WARNING COVERAGE (@1) BENEFIT TYPE IS NOT A PAYABLE
      *** TYPE - BEN-ST CHANGED TO N
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       7612-XEDIT-BEN-STATUS-X.
           EXIT.

      *****************************************************************
      *  ADDRESS TYPE CODE SHOULD ONLY BE PRESENT WHEN RECIPIENT IS
      *  A CLIENT.  ADDRESS RECORD SHOULD EXIST.  CHECK FOR BAD
      *  OR INCOMPLETE ADDRESS.
      *****************************************************************
       7613-XEDIT-ADDR-TYPE-CODE.

           IF RDCD-CLI-ADDR-TYP-CD = SPACES
               IF RDCD-PAYO-RECIP-TYP-CD NOT = SPACES
                   PERFORM  7900-DEF-ADDR-TYP-CD
                       THRU 7900-DEF-ADDR-TYP-CD-X
                   MOVE RDCD-CLI-ADDR-TYP-CD
                                      TO MIR-CLI-ADDR-TYP-CD
                   MOVE 'CS05810083'  TO WGLOB-MSG-REF-INFO
                   MOVE RDCD-CLI-ADDR-TYP-CD
                                      TO WGLOB-MSG-PARM (1)
      ***  MSG (I) ADDRESS TYPE DEFAULTED TO (@1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   GO TO 7613-XEDIT-ADDR-TYPE-CODE-X
557660         END-IF
           ELSE
               IF RDCD-PAYO-RECIP-TYP-CD = SPACES
                   MOVE 'CS05810084'  TO WGLOB-MSG-REF-INFO
      ***  MSG (S) ADDRESS CODE SHOULD BE BLANK IF NO RECIPIENT
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-CROSS-EDITS
                   GO TO 7613-XEDIT-ADDR-TYPE-CODE-X
557660         END-IF
557660     END-IF.

           PERFORM  RECP-1000-GET-RECIPIENT
               THRU RECP-1000-GET-RECIPIENT-X.

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.
           MOVE WRECP-CLI-ID          TO L2440-CLI-ID.
           MOVE RDCD-CLI-ADDR-TYP-CD  TO L2440-CLI-ADDR-TYP-CD.
           IF RDCD-CLI-ADDR-TYP-CD = 'PR'
               PERFORM  2440-1000-PRIMARY-ADDRESS
                   THRU 2440-1000-PRIMARY-ADDRESS-X
           ELSE
               PERFORM  2440-3000-CHK-OTHER-ADDRESS
                   THRU 2440-3000-CHK-OTHER-ADDRESS-X
557660     END-IF.

           IF L2440-RETRN-NO-ADDRESS
               MOVE 'N'               TO WS-CROSS-EDITS
               MOVE 'XS00000214'      TO WGLOB-MSG-REF-INFO
               MOVE 'PR'              TO RDCD-CLI-ADDR-TYP-CD
               MOVE RDCD-CLI-ADDR-TYP-CD
                                      TO MIR-CLI-ADDR-TYP-CD
      ***  ADTYPE INVALID OR ADDR NOT FOUND...PR DEFAULTED
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7613-XEDIT-ADDR-TYPE-CODE-X
557660     END-IF.

           IF L2440-ADDR-STAT-ERROR
               MOVE 'XS00000211'      TO WGLOB-MSG-REF-INFO
               MOVE L2440-CLI-ID      TO WGLOB-MSG-PARM (1)
      ***  MSG (W) BAD ADDRESS ON ADDR FOR CLIENT (@1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF L2440-ADDR-STAT-INCOMPLETE
               MOVE 'XS00000212'      TO WGLOB-MSG-REF-INFO
               MOVE L2440-CLI-ID      TO WGLOB-MSG-PARM (1)
      ***  MSG (W)  ADDRESS ON ADDR IS INCOMPLETE FOR CLIENT (@1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7613-XEDIT-ADDR-TYPE-CODE-X.
           EXIT.

015951*-----------------------------
015951 7614-XEDIT-DISAB-PCT.
015951*-----------------------------
015951
015951     IF  WCVDI-MTHLY-BNFT-AMT (I) NOT = ZERO
015951     AND WCVDI-CVG-DISAB-PCT (I)  NOT = ZERO
015951*MSG: MONTHLY BENEFIT AMOUNT CANNOT BE ENTERED WHEN DISABILITY
015951*     PERCENTAGE APPLIED, AMOUNT RE-CALCULATED
015951         MOVE 'CS05810085'        TO WGLOB-MSG-REF-INFO
015951         PERFORM 0260-1000-GENERATE-MESSAGE
015951            THRU 0260-1000-GENERATE-MESSAGE-X
015951         MOVE 'N'                 TO WS-DATA-EDITS
015951     END-IF.
015951
015951     IF  WCVDI-MTHLY-BNFT-AMT (I) = ZERO
015951     AND WCVDI-CVG-DISAB-PCT (I)  = ZERO
015951*MSG: MONTHLY BENEFIT AMOUNT OR DISABILITY PERCENTAGE
015951*     MUST BE ENTERED
015951         MOVE 'CS05810091'        TO WGLOB-MSG-REF-INFO
015951         PERFORM 0260-1000-GENERATE-MESSAGE
015951            THRU 0260-1000-GENERATE-MESSAGE-X
015951         MOVE 'N'                 TO WS-DATA-EDITS
015951     END-IF.
015951
015951 7614-XEDIT-DISAB-PCT-X.
015951     EXIT.
015951
015951*****************************************************************
015951* USING THE DISCOUNT PERCENTAGE FROM 186 CALCULATE THE NEW
015951* MONTHLY BENEFIT AMOUNT = WCVGS-CVG-FACE-AMT * PCT FROM PLRT
015951*****************************************************************
015951*-----------------------------
015951 7700-CALC-NEW-MTHLY-BNFT-AMT.
015951*-----------------------------
015951
015951     IF  WCVDI-CVG-DISAB-PCT(I)  =  ZERO
015951         MOVE WCVGS-CVG-FACE-AMT (I)
015951                                    TO WCVDI-MTHLY-BNFT-AMT (I)
015951     ELSE
015951         PERFORM  7710-CALC-PCT-MTHLY-BNFT-AMT
015951             THRU 7710-CALC-PCT-MTHLY-BNFT-AMT-X
015951     END-IF.
015951
015951 7700-CALC-NEW-MTHLY-BNFT-AMT-X.
015951     EXIT.
015951
015951*-----------------------------
015951 7710-CALC-PCT-MTHLY-BNFT-AMT.
015951*-----------------------------
015951
015951     INITIALIZE L0186-PARM-INFO.
015951
015951* OBTAIN THE RATE IN ORDER TO CALCULATE THE NEW MONTHLY BENEFIT
015951* AMOUNT
015951
015951     PERFORM  PLIN-1000-PLAN-HEADER-IN
015951         THRU PLIN-1000-PLAN-HEADER-IN-X.
015951
015951     SET L0186-PLAN-RT-TYP-DIPCT TO TRUE.
015951
015951     PERFORM  0186-1000-BUILD-PARM-INFO
015951         THRU 0186-1000-BUILD-PARM-INFO-X.
015951
015951     MOVE RDCL-INSRD-DISAB-DT    TO L0186-EFF-DT.
015951     MOVE 'P'                    TO L0186-BAND-USE-CD.
015951
015951* DISABILITY PERCENTAGE IS REQUIRED BY 186 TO IDENTIFY THE CORRECT
015951* BANDING AS THIS FIELD WILL ONLY BE USED BY DISABILITY PRODUCTS
015951* THE MOVE HAS NOT BEEN ADDED TO 0186-1000-BUILD-PARM-INFO
015951* AS NORMAL.
015951
015951     MOVE WCVDI-CVG-DISAB-PCT(I) TO L0186-CVG-DISAB-PCT (I).
015951
015951     PERFORM  0186-3000-GET-PLRT
015951         THRU 0186-3000-GET-PLRT-X.
015951
015951     IF NOT L0186-RETRN-OK
015951        OR  L0186-RETRN-BAD-PLRT-ACCESS
015951        OR  L0186-RETRN-BAD-RHDR-ACCESS
015951        OR  L0186-RETRN-BAD-RLTB-ACCESS
015951        OR  L0186-RETRN-BAD-LGAS-ACCESS
015951*MSG:DISABILITY BENEFIT RATE @1 NOT FOUND.DISABILITY BENEFIT
015951*AMOUNT NOT CALCULATED.
015951             MOVE 'CS05810088'    TO WGLOB-MSG-REF-INFO
015951             MOVE L0186-ID        TO WGLOB-MSG-PARM (1)
015951             PERFORM  0260-1000-GENERATE-MESSAGE
015951                 THRU 0260-1000-GENERATE-MESSAGE-X
015951             GO TO 7710-CALC-PCT-MTHLY-BNFT-AMT-X
015951     END-IF.
015951
015951     IF  L0186-RETRN-OK
015951         IF  L0186-RT(1) = ZERO
015951*MSG: PREMIUM SALES TAX RATE ZERO FOR RLTB @1
015951             MOVE 'CS05810090'   TO WGLOB-MSG-REF-INFO
015951             PERFORM 0260-1000-GENERATE-MESSAGE
015951                THRU 0260-1000-GENERATE-MESSAGE-X
015951             GO TO 7710-CALC-PCT-MTHLY-BNFT-AMT-X
015951         ELSE
020874*            COMPUTE L0290-INPUT-NUMBER ROUNDED =
020874*                    WCVGS-CVG-FACE-AMT (I) * L0186-RT (1)
020874             COMPUTE L0290-INPUT-V00 ROUNDED =
020874                     WCVGS-CVG-FACE-AMT (I) * L0186-RT (1)
015951             MOVE 0              TO L0290-PRECISION
015951             MOVE LENGTH OF MIR-MTHLY-BNFT-AMT
015951                                 TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*              THRU  0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874               THRU  0290-2000-FORMAT-FOR-MIR-X
015951             MOVE L0290-OUTPUT-DATA  TO MIR-MTHLY-BNFT-AMT
015951             MOVE L0290-INPUT-NUMBER TO WCVDI-MTHLY-BNFT-AMT (I)
015951         END-IF
015951     END-IF.
015951
015951 7710-CALC-PCT-MTHLY-BNFT-AMT-X.
015951     EXIT.

      *****************************************************************
      *   DEFAULT CLIENT ADDRESS TYPE CODE BASED ON RECIPIENT CODE
      *****************************************************************
       7900-DEF-ADDR-TYP-CD.

           IF  RDCD-PAYO-RECIP-TYP-CD = SPACES
               GO TO 7900-DEF-ADDR-TYP-CD-X
           END-IF.

           EVALUATE TRUE

               WHEN RDCD-PAYO-RECIP-TYP-OWNER

                   PERFORM  2430-1000-BUILD-PARM-INFO
                       THRU 2430-1000-BUILD-PARM-INFO-X
                   PERFORM  2430-2100-GET-OWNER
                       THRU 2430-2100-GET-OWNER-X

                   MOVE L2430-CLI-ADDR-TYP-CD
                                      TO  RDCD-CLI-ADDR-TYP-CD

               WHEN RDCD-PAYO-RECIP-TYP-ASSIGNEE

                   PERFORM  2430-1000-BUILD-PARM-INFO
                       THRU 2430-1000-BUILD-PARM-INFO-X
                   PERFORM  2430-2600-GET-ASSIGNEE
                       THRU 2430-2600-GET-ASSIGNEE-X

                   MOVE L2430-CLI-ADDR-TYP-CD
                                      TO  RDCD-CLI-ADDR-TYP-CD

               WHEN RDCD-PAYO-RECIP-TYP-SPOUSE

                   PERFORM  2430-1000-BUILD-PARM-INFO
                       THRU 2430-1000-BUILD-PARM-INFO-X
                   PERFORM  2430-2700-GET-SPOUSE
                       THRU 2430-2700-GET-SPOUSE-X

                   MOVE L2430-CLI-ADDR-TYP-CD
                                      TO  RDCD-CLI-ADDR-TYP-CD

           END-EVALUATE.


       7900-DEF-ADDR-TYP-CD-X.
           EXIT.

      *****************************************************************
      *  BUILD PO KEY FROM MIR KEY FIELDS
      *****************************************************************
       8000-BUILD-PO-KEY.

           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID.
           MOVE MIR-POL-ID-SFX            TO WPOL-POL-ID-SFX.

       8000-BUILD-PO-KEY-X.
           EXIT.

      *****************************************************************
      *  BUILD DCL KEY FROM MIR KEY FIELDS
      *****************************************************************
       8100-BUILD-DCL-KEY.

           MOVE MIR-DI-CLM-ID         TO WDCL-DI-CLM-ID.

       8100-BUILD-DCL-KEY-X.
           EXIT.

      *****************************************************************
      *  BUILD DCD KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
      ********************
       8200-BUILD-DCD-KEY.
      ********************

           MOVE MIR-POL-ID-BASE            TO WDCD-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WDCD-POL-ID-SFX.
           MOVE MIR-DI-CLM-ID              TO WDCD-DI-CLM-ID.

       8200-BUILD-DCD-KEY-X.
           EXIT.

      ****************************************************************
      * READ IN THE COVERAGES
      ****************************************************************
      *********************
       8400-READ-RIDERS-IN.
      *********************

           MOVE RPOL-POL-ID           TO WCVG-POL-ID
           MOVE I                     TO WCVG-CVG-NUM-N
           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X
           IF NOT WCVG-IO-OK
              MOVE 'CS00000024'       TO WGLOB-MSG-REF-INFO
      *
      *       MSG: COVERAGE FILE PROBLEM. CALL SYSTEMS
      *
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
              MOVE RCVG-CVG-INFO      TO WCVGS-CVG-INFO (I)
              MOVE RCVG-CVG-NUM       TO WCVGS-CVG-SEQ-NUM (I)
           END-IF.

       8400-READ-RIDERS-IN-X.
           EXIT.

      *****************************************************************
      *  CHECK FOR VALID SECURITY LEVEL
      *****************************************************************
      *********************

      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      ************************
       9100-BLANK-DATA-FIELDS.
      ************************

           IF NOT (WS-BUS-FCN-CLMLIST
               OR WS-BUS-FCN-POLLIST)
               PERFORM  9110-BLANK-SCREEN-1
                   THRU 9110-BLANK-SCREEN-1-X
           ELSE
               PERFORM  9120-BLANK-SCREEN-2
                   THRU 9120-BLANK-SCREEN-2-X
557660     END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *****************************************************************
      *  SET EACH NON-KEY FIELD ON SCREEN 1 TO SPACES
      *****************************************************************
      *********************
       9110-BLANK-SCREEN-1.
      *********************

           MOVE SPACES                TO MIR-CLM-CRNT-STAT-CD.
           MOVE SPACES                TO MIR-INSRD-DISAB-DT.
           MOVE SPACES                TO MIR-DISAB-REASN-CD.
           MOVE SPACES                TO MIR-DISAB-RPT-DT.
           MOVE SPACES                TO MIR-INSRD-DISAB-TYP-CD.
           MOVE SPACES                TO MIR-CLI-SEX-CD.
           MOVE SPACES                TO MIR-DV-CLI-DISAB-AGE.
           MOVE SPACES                TO MIR-DV-CLI-INSRD-AGE.
           MOVE SPACES                TO MIR-OCCP-ID.
           MOVE SPACES                TO MIR-INSRD-CRNT-OCCP-CD.
           MOVE SPACES                TO MIR-DI-CLM-CLOS-DT.
           MOVE SPACES                TO MIR-CLM-CLOS-REASN-CD.
           MOVE SPACES                TO MIR-DI-CLM-RMRK-TXT.
           MOVE SPACES                TO MIR-CLM-APROV-CD.
           MOVE SPACES                TO MIR-CLM-PAYO-MTHD-CD.
           MOVE SPACES                TO MIR-PAYO-RECIP-TYP-CD.
013578*    MOVE SPACES                TO MIR-RDESC.
           MOVE SPACES                TO MIR-CLM-AUTO-PMT-IND.
           MOVE SPACES                TO MIR-CLI-ADDR-TYP-CD.
           MOVE SPACES                TO MIR-AUTO-PMT-XPRY-DT.
           MOVE SPACES                TO MIR-PREV-CLM-PMT-DT.
           MOVE SPACES                TO MIR-DV-NXT-CLM-PMT-DT.
           MOVE SPACES                TO MIR-CVG-ISS-EFF-DT.
           MOVE SPACES                TO MIR-PLAN-ID.
           MOVE SPACES                TO MIR-CVG-STBL-1-CD.
           MOVE SPACES                TO MIR-CVG-STBL-2-CD.
           MOVE SPACES                TO MIR-CVG-STBL-3-CD.
           MOVE SPACES                TO MIR-CVG-STBL-4-CD.
           MOVE SPACES                TO MIR-MAX-BNFT-TYP-CD.
           MOVE SPACES                TO MIR-MAX-BNFT-DUR.
           MOVE SPACES                TO MIR-REDC-EP-SELCT-IND.
           MOVE SPACES                TO MIR-REDC-EP-DUR.
           MOVE SPACES                TO MIR-OWN-OCCP-SELCT-IND.
           MOVE SPACES                TO MIR-OWN-OCCP-DUR.
           MOVE SPACES                TO MIR-CVG-LTA-SELCT-IND.
           MOVE SPACES                TO MIR-CVG-LTB-SELCT-IND.
           MOVE SPACES                TO MIR-PDISAB-SELCT-IND.
           MOVE SPACES                TO MIR-CVG-COLA-SELCT-CD.
           MOVE SPACES                TO MIR-CVG-BNFT-STAT-CD.
           MOVE SPACES                TO MIR-CVG-ORIG-FACE-AMT.
           MOVE SPACES                TO MIR-MTHLY-BNFT-AMT.
           MOVE SPACES                TO MIR-BNFT-ADJ-REASN-CD.
           MOVE SPACES                TO MIR-CVG-MAT-XPRY-DT.
           MOVE SPACES                TO MIR-BNFT-XPRY-DT.
           MOVE SPACES                TO MIR-RSDUE-BNFT-FCT.
           MOVE SPACES                TO MIR-RSDUE-BNFT-STRT-DT.
           MOVE SPACES                TO MIR-UW-USER-ID.

       9110-BLANK-SCREEN-1-X.
           EXIT.

      *****************************************************************
      *  SET EACH NON-KEY FIELD ON SCREEN 2 TO SPACES
      *****************************************************************
      *********************
       9120-BLANK-SCREEN-2.
      *********************

           MOVE SPACES                TO MIR-POL-ID-SFX-G.
           MOVE SPACES                TO MIR-CVG-NUM-G.
           MOVE SPACES                TO MIR-DI-CLM-ID-G.
           MOVE SPACES                TO MIR-CLM-CRNT-STAT-CD-G.
           MOVE SPACES                TO MIR-INSRD-DISAB-DT-G.
           MOVE SPACES                TO MIR-DISAB-REASN-CD-G.
           MOVE SPACES                TO MIR-DI-CLM-CLOS-DT-G.
           MOVE SPACES                TO MIR-CLM-CLOS-REASN-CD-G.
           MOVE SPACES                TO MIR-CVG-BNFT-STAT-CD-G.
           MOVE SPACES                TO MIR-MTHLY-BNFT-AMT-G.

       9120-BLANK-SCREEN-2-X.
           EXIT.

      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-CRCY-ACCS-RESTRICTED
012624*    OR L5400-CTL-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
           OR L5400-STAT-ACCS-RESTRICTED
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

013578*    IF NOT (WS-BUS-FCN-CLMLIST
013578*        OR WS-BUS-FCN-POLLIST)
013578*        PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
013578*            THRU 9210-MOVE-RECORD-TO-SCREEN-1-X
013578*    ELSE
013578*        PERFORM  9220-MOVE-RECORD-TO-SCREEN-2
013578*            THRU 9220-MOVE-RECORD-TO-SCREEN-2-X
013578*    END-IF.

013578     EVALUATE TRUE

013578       WHEN WS-BUS-FCN-UPDATE
013578         PERFORM  9230-MOVE-RECORD-TO-SCREEN
013578             THRU 9230-MOVE-RECORD-TO-SCREEN-X

013578       WHEN (WS-BUS-FCN-CLMLIST
013578         OR  WS-BUS-FCN-POLLIST)
013578         PERFORM  9220-MOVE-RECORD-TO-SCREEN-2
013578             THRU 9220-MOVE-RECORD-TO-SCREEN-2-X

013578       WHEN OTHER
013578         PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
013578             THRU 9210-MOVE-RECORD-TO-SCREEN-1-X

013578     END-EVALUATE.


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 1
      *****************************************************************
      ******************************
       9210-MOVE-RECORD-TO-SCREEN-1.
      ******************************

           PERFORM  9212-LOAD-INSURED
               THRU 9212-LOAD-INSURED-X.

           PERFORM  8200-BUILD-DCD-KEY
               THRU 8200-BUILD-DCD-KEY-X.
           PERFORM  DCD-1000-READ
               THRU DCD-1000-READ-X.

           PERFORM  CVDI-1000-BUILD-ARRAY
               THRU CVDI-1000-BUILD-ARRAY-X.

           IF WCVDI-CTR = ZERO
               MOVE '00'              TO MIR-CVG-NUM
               MOVE WS-HOLD-RIDER-NO-N                              TO I
               MOVE RDCD-POL-ID       TO RPOL-POL-ID
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: COVERAGE RECORD MUST EXIT. RE-ENTER
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 9210-MOVE-RECORD-TO-SCREEN-1-X
           ELSE
               MOVE WS-HOLD-RIDER-NO-N                              TO I
               MOVE RDCD-POL-ID       TO RPOL-POL-ID
               PERFORM  8400-READ-RIDERS-IN
                   THRU 8400-READ-RIDERS-IN-X
               IF NOT WCVG-IO-OK
                   GO TO 9210-MOVE-RECORD-TO-SCREEN-1-X
557660         END-IF
557660     END-IF.

013578*    MOVE WCVDI-CTR             TO MIR-POL-CVG-REC-CTR.

           MOVE RDCL-CLM-CRNT-STAT-CD TO MIR-CLM-CRNT-STAT-CD.

           MOVE RDCL-INSRD-DISAB-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-INSRD-DISAB-DT.

           MOVE RDCL-DISAB-REASN-CD   TO MIR-DISAB-REASN-CD.

           MOVE RDCL-DISAB-RPT-DT     TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DISAB-RPT-DT.

           MOVE RDCL-INSRD-DISAB-TYP-CD
                                      TO MIR-INSRD-DISAB-TYP-CD.
           MOVE L2435-CLI-SEX-CD      TO MIR-CLI-SEX-CD.

           MOVE L2435-CLI-BTH-DT      TO L1680-INTERNAL-1.
           MOVE RDCL-INSRD-DISAB-DT   TO L1680-INTERNAL-2.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
           IF  L1680-NUMBER-OF-YEARS > ZERO
               MOVE L1680-NUMBER-OF-YEARS
024187                                TO L0290-INPUT-V00
024187         MOVE 0                 TO L0290-PRECISION
024187         MOVE LENGTH OF MIR-DV-CLI-DISAB-AGE
024187                                TO L0290-MAX-OUT-LEN
024187         PERFORM  0290-2000-FORMAT-FOR-MIR
024187             THRU 0290-2000-FORMAT-FOR-MIR-X
024187         MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-CLI-DISAB-AGE
           ELSE
               MOVE ZERO              TO MIR-DV-CLI-DISAB-AGE
557660     END-IF.

           MOVE L2435-CLI-BTH-DT      TO L1680-INTERNAL-1.
           MOVE WGLOB-PROCESS-DATE    TO L1680-INTERNAL-2.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
           IF  L1680-NUMBER-OF-YEARS > ZERO
               MOVE L1680-NUMBER-OF-YEARS
024187                                TO L0290-INPUT-V00
024187         MOVE 0                 TO L0290-PRECISION
024187         MOVE LENGTH OF MIR-DV-CLI-INSRD-AGE
024187                                TO L0290-MAX-OUT-LEN
024187         PERFORM  0290-2000-FORMAT-FOR-MIR
024187             THRU 0290-2000-FORMAT-FOR-MIR-X
024187         MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-CLI-INSRD-AGE
           ELSE
               MOVE ZERO              TO MIR-DV-CLI-INSRD-AGE
557660     END-IF.

           MOVE L2435-OCCP-ID         TO MIR-OCCP-ID.

           MOVE RDCL-INSRD-CRNT-OCCP-CD
                                      TO MIR-INSRD-CRNT-OCCP-CD.

           MOVE RDCL-DI-CLM-CLOS-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DI-CLM-CLOS-DT.

           MOVE RDCL-CLM-CLOS-REASN-CD         TO MIR-CLM-CLOS-REASN-CD.
           MOVE RDCL-DI-CLM-RMRK-TXT  TO MIR-DI-CLM-RMRK-TXT.

           MOVE RDCD-CLM-APROV-CD     TO MIR-CLM-APROV-CD.
           MOVE RDCD-CLM-PAYO-MTHD-CD TO MIR-CLM-PAYO-MTHD-CD.
           MOVE RDCD-PAYO-RECIP-TYP-CD
                                      TO MIR-PAYO-RECIP-TYP-CD.


013578*    MOVE RDCD-PAYO-RECIP-TYP-CD            TO WEDIT-ETBL-VALU-ID.
013578*    PERFORM  RELA-2000-DESC
013578*        THRU RELA-2000-DESC-X.
013578*    IF WEDIT-IO-OK
013578*        MOVE REDIT-ETBL-DESC-TXT
013578*                               TO MIR-RDESC
013578*    END-IF.

           MOVE RDCD-CLI-ADDR-TYP-CD  TO MIR-CLI-ADDR-TYP-CD.
           MOVE RDCD-CLM-AUTO-PMT-IND TO MIR-CLM-AUTO-PMT-IND.

           MOVE RDCD-AUTO-PMT-XPRY-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-AUTO-PMT-XPRY-DT.

           MOVE RDCD-PREV-CLM-PMT-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-CLM-PMT-DT.

      *** RECALC NEXT SCHEDULED PAYMENT DATE
           PERFORM  6820-1000-BUILD-PARM-INFO
               THRU 6820-1000-BUILD-PARM-INFO-X.

           MOVE RDCD-PREV-SCHD-PMT-DT TO L6820-PREV-SCHD-PMT-DT.
           MOVE RPOL-POL-CEAS-DT      TO L6820-POL-CEAS-DT.
           PERFORM  6820-1000-CALC-PMT-DT
               THRU 6820-1000-CALC-PMT-DT-X.

           IF  L6820-RETRN-OK
               MOVE L6820-CLM-PMT-DT  TO L1640-INTERNAL-DATE
           END-IF.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DV-NXT-CLM-PMT-DT.

           MOVE WCVGS-CVG-ISS-EFF-DT (I)
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CVG-ISS-EFF-DT.

           MOVE WCVGS-PLAN-ID(I)      TO MIR-PLAN-ID.
           MOVE WCVGS-CVG-STBL-1-CD (I)
                                      TO MIR-CVG-STBL-1-CD.
           MOVE WCVGS-CVG-STBL-2-CD (I)
                                      TO MIR-CVG-STBL-2-CD.
           MOVE WCVGS-CVG-STBL-3-CD (I)
                                      TO MIR-CVG-STBL-3-CD.
           MOVE WCVGS-CVG-STBL-4-CD (I)
                                      TO MIR-CVG-STBL-4-CD.

      ***FIELDS RENAMED DUE TO SEPARATE CODI TABLE

           MOVE WCVDI-MAX-BNFT-TYP-CD (I)
                                      TO MIR-MAX-BNFT-TYP-CD.
           MOVE WCVDI-MAX-BNFT-DUR-N (I)
                                      TO MIR-MAX-BNFT-DUR.

           MOVE WCVGS-REDC-EP-SELCT-IND (I)
                                      TO MIR-REDC-EP-SELCT-IND.
           MOVE WCVDI-REDC-EP-DUR-N   (I)
                                      TO MIR-REDC-EP-DUR.
           MOVE WCVGS-OWN-OCCP-SELCT-IND (I)
                                      TO MIR-OWN-OCCP-SELCT-IND.
           MOVE WCVDI-OWN-OCCP-DUR-N (I)
                                      TO MIR-OWN-OCCP-DUR.
           MOVE WCVGS-CVG-LTA-SELCT-IND (I)
                                      TO MIR-CVG-LTA-SELCT-IND.
           MOVE WCVGS-CVG-LTB-SELCT-IND (I)
                                      TO MIR-CVG-LTB-SELCT-IND.
           MOVE WCVGS-PDISAB-SELCT-IND (I)
                                      TO MIR-PDISAB-SELCT-IND.
           MOVE WCVGS-CVG-COLA-SELCT-CD (I)
                                      TO MIR-CVG-COLA-SELCT-CD.
           MOVE WCVDI-CVG-BNFT-STAT-CD (I)
                                      TO MIR-CVG-BNFT-STAT-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = WCVDI-CVG-DISAB-PCT (I)
020874*                                 * 100.
020874     MOVE WCVDI-CVG-DISAB-PCT (I) TO L0290-INPUT-V02.
015951     MOVE 2                       TO L0290-PRECISION.
015951     MOVE LENGTH OF MIR-CVG-DISAB-PCT
015951                                  TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
015951     MOVE L0290-OUTPUT-DATA       TO MIR-CVG-DISAB-PCT.

008455*    MOVE WCVGS-CVG-ORIG-FACE-AMT (I)  TO WS-NUM-7V2.
008455*    MOVE WS-NUM-7V2                TO MIR-CVG-ORIG-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-ORIG-FACE-AMT (I)
020874*                                 * 100.
020874     MOVE WCVGS-CVG-ORIG-FACE-AMT (I) TO L0290-INPUT-V02.
008455     MOVE 2                           TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-ORIG-FACE-AMT
                                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-ORIG-FACE-AMT.

008455*    MOVE WCVDI-MTHLY-BNFT-AMT (I)   TO WS-NUM-7V2.
008455*    MOVE WS-NUM-7V2                TO MIR-MTHLY-BNFT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WCVDI-MTHLY-BNFT-AMT (I)
020874*                                 * 100.
020874     MOVE WCVDI-MTHLY-BNFT-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MTHLY-BNFT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA         TO MIR-MTHLY-BNFT-AMT.

           MOVE WCVDI-BNFT-ADJ-REASN-CD (I)
                                      TO MIR-BNFT-ADJ-REASN-CD.

           MOVE WCVGS-CVG-MAT-XPRY-DT (I)
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CVG-MAT-XPRY-DT.

           MOVE WCVDI-BNFT-XPRY-DT (I)           TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-BNFT-XPRY-DT.

020874*    MOVE WCVDI-RSDUE-BNFT-FCT (I)
020874*                               TO WS-NUM-1V2.
020874*    MOVE WS-NUM-1V2            TO MIR-RSDUE-BNFT-FCT.
020874     MOVE WCVDI-RSDUE-BNFT-FCT (I) TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-RSDUE-BNFT-FCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-RSDUE-BNFT-FCT.

           MOVE WCVDI-RSDUE-BNFT-STRT-DT (I)
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-RSDUE-BNFT-STRT-DT.

           MOVE WCVGS-UW-USER-ID (I)  TO MIR-UW-USER-ID.

       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.

      ******************************************************************
      *  LOAD INSURED'S FIRST AND LAST NAMES FROM NA RECORD
      ******************************************************************
       9212-LOAD-INSURED.

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE RDCL-CLI-ID           TO MIR-CLI-ID.

           MOVE RDCL-CLI-ID           TO L2435-CLI-ID.
           MOVE 'N'                   TO L2435-ATTAIN-AGE-IND.
           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.
           IF L2435-RETRN-OK
557668*        MOVE L2435-CLI-NM-COMPRESSED TO MIR-DV-CLI-NM
557668         INITIALIZE L0620-INPUT-PARM-INFO
557668         IF L2435-CLI-SEX-CD = 'C'
557668             MOVE L2435-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668         ELSE
557668             MOVE L2435-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668             MOVE L2435-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
014653             MOVE L2435-CLI-MID-INIT-NM
014653                                TO L0620-CLI-MID-INIT-NM
014653             MOVE L2435-CLI-SFX-NM
014653                                TO L0620-CLI-SFX-NM
557668         END-IF
557668         MOVE L2435-CLI-SEX-CD  TO L0620-CLI-SEX-CD
557668
557668         PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668             THRU 0620-1000-FORMAT-SCREEN-NAME-X
557668
557668         MOVE L0620-SCREEN-NAME TO MIR-DV-INSRD-CLI-NM
557668
           END-IF.

       9212-LOAD-INSURED-X.
           EXIT.

      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 2
      *****************************************************************
      ******************************
       9220-MOVE-RECORD-TO-SCREEN-2.
      ******************************


           PERFORM  CVDI-1000-BUILD-ARRAY
               THRU CVDI-1000-BUILD-ARRAY-X.

           IF  WCVDI-CTR                =  ZERO
               MOVE  ZERO             TO WS-HOLD-RIDER-NO
           END-IF.
      *
      * VERIFY POLICY ACCESS
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    SET L5400-CTL-MSG-NOT-REQD     TO TRUE.
           SET L5400-CNFD-MSG-REQD        TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD    TO TRUE.
           SET L5400-BRCH-MSG-NOT-REQD    TO TRUE.
012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-CRCY-ACCS-RESTRICTED
012624*    OR L5400-CTL-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
           OR L5400-STAT-ACCS-RESTRICTED
               GO TO 9220-MOVE-RECORD-TO-SCREEN-2-X
           END-IF.

013578*    MOVE RDCD-POL-ID           TO MIR-POL-ID-SFX-T (WS-LINE).
013578     MOVE RDCD-POL-ID-BASE      TO MIR-POL-ID-BASE-T (WS-LINE).
013578     MOVE RDCD-POL-ID-SFX       TO MIR-POL-ID-SFX-T (WS-LINE).
           MOVE WS-HOLD-RIDER-NO      TO MIR-CVG-NUM-T (WS-LINE).
           MOVE RDCL-DI-CLM-ID        TO MIR-DI-CLM-ID-T (WS-LINE).

           MOVE RDCL-CLM-CRNT-STAT-CD
                                    TO MIR-CLM-CRNT-STAT-CD-T (WS-LINE).

           MOVE RDCL-INSRD-DISAB-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-INSRD-DISAB-DT-T (WS-LINE).

           MOVE RDCL-DISAB-REASN-CD   TO MIR-DISAB-REASN-CD-T (WS-LINE).

           MOVE RDCL-DI-CLM-CLOS-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DI-CLM-CLOS-DT-T (WS-LINE).

           MOVE RDCL-CLM-CLOS-REASN-CD
                                   TO MIR-CLM-CLOS-REASN-CD-T (WS-LINE).

           IF  WCVDI-CTR  =  ZERO
               MOVE  SPACES          TO MIR-CVG-BNFT-STAT-CD-T (WS-LINE)
               MOVE  SPACES
                          TO MIR-MTHLY-BNFT-AMT-T (WS-LINE)
           ELSE
               MOVE WCVDI-CVG-BNFT-STAT-CD (I)
                                 TO MIR-CVG-BNFT-STAT-CD-T (WS-LINE)
008455*        MOVE WCVDI-MTHLY-BNFT-AMT (I)   TO WS-NUM-7V2
008455*        MOVE WS-NUM-7V2     TO MIR-MTHLY-BNFT-AMT-T (WS-LINE)
020874*        COMPUTE L0290-INPUT-NUMBER = WCVDI-MTHLY-BNFT-AMT (I)
020874*                                     * 100
020874         MOVE WCVDI-MTHLY-BNFT-AMT (I)  TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MTHLY-BNFT-AMT-T (WS-LINE)
008455                                        TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                          TO MIR-MTHLY-BNFT-AMT-T (WS-LINE)
015951         MOVE WCVDI-CVG-DISAB-PCT(I)  TO L0290-INPUT-NUMBER
020874*        COMPUTE L0290-INPUT-NUMBER = WCVDI-CVG-DISAB-PCT(I)
020874*                                     * 100
020874         MOVE WCVDI-CVG-DISAB-PCT(I)  TO L0290-INPUT-V02
015951         MOVE 2                       TO L0290-PRECISION
015951         MOVE LENGTH OF MIR-CVG-DISAB-PCT
015951                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
015951         MOVE L0290-OUTPUT-DATA
015951                                TO MIR-CVG-DISAB-PCT-T(WS-LINE)
           END-IF.

           ADD 1                          TO WS-LINE.

           IF MIR-POL-ID-BASE = SPACES
               MOVE RDCD-POL-ID-BASE  TO MIR-POL-ID-BASE
               MOVE RDCD-POL-ID-SFX   TO MIR-POL-ID-SFX
           END-IF.

           IF MIR-DI-CLM-ID = SPACES
               MOVE RDCD-DI-CLM-ID    TO MIR-DI-CLM-ID
           END-IF.

       9220-MOVE-RECORD-TO-SCREEN-2-X.
           EXIT.

      ******************************
       9230-MOVE-RECORD-TO-SCREEN.
      ******************************

           PERFORM  9212-LOAD-INSURED
               THRU 9212-LOAD-INSURED-X.

           PERFORM  8200-BUILD-DCD-KEY
               THRU 8200-BUILD-DCD-KEY-X.
           PERFORM  DCD-1000-READ
               THRU DCD-1000-READ-X.

           PERFORM  CVDI-1000-BUILD-ARRAY
               THRU CVDI-1000-BUILD-ARRAY-X.

           IF WCVDI-CTR = ZERO
               MOVE '00'              TO MIR-CVG-NUM
               MOVE WS-HOLD-RIDER-NO-N                              TO I
               MOVE RDCD-POL-ID       TO RPOL-POL-ID
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: COVERAGE RECORD MUST EXIT. RE-ENTER
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 9230-MOVE-RECORD-TO-SCREEN-X
           ELSE
               MOVE WS-HOLD-RIDER-NO-N                              TO I
               MOVE RDCD-POL-ID       TO RPOL-POL-ID
               PERFORM  8400-READ-RIDERS-IN
                   THRU 8400-READ-RIDERS-IN-X
               IF NOT WCVG-IO-OK
               GO TO 9230-MOVE-RECORD-TO-SCREEN-X
557660         END-IF
557660     END-IF.

013578*    MOVE WCVDI-CTR             TO MIR-POL-CVG-REC-CTR.
           MOVE RDCL-CLM-CRNT-STAT-CD TO MIR-CLM-CRNT-STAT-CD.

           MOVE L2435-CLI-SEX-CD      TO MIR-CLI-SEX-CD.


           MOVE L2435-CLI-BTH-DT      TO L1680-INTERNAL-1.
           MOVE WGLOB-PROCESS-DATE    TO L1680-INTERNAL-2.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
           IF  L1680-NUMBER-OF-YEARS > ZERO
               MOVE L1680-NUMBER-OF-YEARS
024187                                TO L0290-INPUT-V00
024187         MOVE 0                 TO L0290-PRECISION
024187         MOVE LENGTH OF MIR-DV-CLI-INSRD-AGE
024187                                TO L0290-MAX-OUT-LEN
024187         PERFORM  0290-2000-FORMAT-FOR-MIR
024187             THRU 0290-2000-FORMAT-FOR-MIR-X
024187         MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-CLI-INSRD-AGE
           ELSE
               MOVE ZERO              TO MIR-DV-CLI-INSRD-AGE
           END-IF.

           MOVE WCVGS-CVG-ISS-EFF-DT (I)
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CVG-ISS-EFF-DT.

           MOVE WCVGS-PLAN-ID(I)      TO MIR-PLAN-ID.

      ***FIELDS RENAMED DUE TO SEPARATE CODI TABLE

           MOVE WCVGS-CVG-COLA-SELCT-CD (I)
                                      TO MIR-CVG-COLA-SELCT-CD.


           MOVE WCVGS-CVG-MAT-XPRY-DT (I)
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CVG-MAT-XPRY-DT.

020874*    COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-ORIG-FACE-AMT (I)
020874*                                 * 100.
020874     MOVE WCVGS-CVG-ORIG-FACE-AMT (I) TO L0290-INPUT-V02.
015951     MOVE 2                           TO L0290-PRECISION.
015951     MOVE LENGTH OF MIR-CVG-ORIG-FACE-AMT
015951                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
015951     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-ORIG-FACE-AMT.

           MOVE WCVGS-UW-USER-ID (I)  TO MIR-UW-USER-ID.

       9230-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0186-0000-INIT-PARM-INFO
025970         THRU 0186-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0577-0000-INIT-PARM-INFO
025970         THRU 0577-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5020-0000-INIT-PARM-INFO
025970         THRU 5020-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6820-0000-INIT-PARM-INFO
025970         THRU 6820-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-WORK-AREA.
025970     INITIALIZE WCVDI-WORK-AREA.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET WS-NUM-1V2-DEFAULT TO TRUE.
025970     SET WS-MAX-SCREEN-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.


      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.

       COPY CCPEADDR.
       COPY CCPEADJR.
       COPY CCPECLSR.
       COPY CCPEDISR.
007685*COPY CCPEFRMT.
       COPY CCPEOCCD.
       COPY CCPPRECP.
016537*COPY CCPERELA.
       COPY CCPPCVDI.
       COPY NCPPCVGS.
015951 COPY CCPPMIDT.
      ****************************************************************
      * LINKAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY CCCL0289.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY CCPL0289.
018764*COPY CCCL0577.
018764 COPY CCPL0577.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
018764*COPY CCCL2435.
018764 COPY CCPL2435.
018764*COPY CCCL2440.
020478 COPY CCPS2440.
018764 COPY CCPL2440.
018764*COPY CCCL5020.
018764 COPY CCPL5020.
007685*COPY CCCL5206.
016537*COPY NCCL0303.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
018764*COPY CCCL6820.
018764 COPY CCPL6820.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.

025970 COPY XCPS0280.
       COPY XCPL0280.
008455 COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
       COPY XCPL1680.
025970 COPY CCPS0620.
557668 COPY CCPL0620.

021930*COPY CCPSPGA.
016503 COPY CCPS0289.
       COPY CCPS0577.
016108 COPY CCPS0985.
       COPY CCPS2430.
       COPY CCPS2435.
       COPY CCPS5020.
007685*COPY CCPS5206.
016537*COPY NCPS0303.
       COPY CCPS5400.
       COPY CCPS6820.
008455 COPY XCPS0290.
015951 COPY CCPS0186.
018764*COPY CCCL0186.
018764 COPY CCPL0186.
021930*COPY XCPL1660.
018764*COPY CCCL3330.
021930*COPY CCPL3330.
021930*COPY CCPS3330.

      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPACODI.
       COPY CCPBCODI.
       COPY CCPUCODI.
       COPY CCPXCODI.
       COPY CCPCCODI.

021930*COPY CCPCRH.
021930*COPY CCPBRH.
021930*COPY CCPBRT.
021930*COPY CCPBPLRT.
021930*COPY CCPBLGAS.
021930*COPY CCPNRT.
021930*COPY CCPNPLRT.

       COPY CCPNCVG.

       COPY CCPBDCD.
       COPY CCPNDCD.
       COPY CCPUDCD.
       COPY CCPXDCD.
       COPY CCPBDCD1.

       COPY CCPNDCL.
       COPY CCPUDCL.
016537*COPY CCPCDCL.

       COPY CCPNEDIT.

016537*COPY NCPNDOCM.

       COPY CCPNPOL.
       COPY CCPUPOL.

015951 COPY CCPNPH.
015951 COPY CCPPPLIN.

      *****************************************************************
      * ERROR HANDLING ROUTINES                                       *
      *****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0581                     **
      *****************************************************************
