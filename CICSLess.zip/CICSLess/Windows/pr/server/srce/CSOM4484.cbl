      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4484.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4484                                         **
      **  REMARKS:  PGAL - POLICY GAIN ALLOCATION LIST               **
      **            THIS MODULE RETRIEVES RECORED FROM PGAL TABLE    **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4484'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-LINE                  PIC S9(04) BINARY
025970                                      VALUE +100.
025970         88  WS-MAX-LINE-DEFAULT      VALUE +100.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '4484'.
           05  WS-SUB                       PIC S9(04) BINARY.
           05  WS-POL-ID.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
025970*    05  WS-MAX-LINE                  PIC S9(04) BINARY
025970*                                     VALUE +100.
           05  WS-KEY-SW                    PIC X.
               88  WS-KEY-PGAL              VALUE 'L'.
               88  WS-KEY-PGAM              VALUE 'M'.
           05  WS-IO-STATUS                 PIC 9.
               88  WS-IO-OK                 VALUE ZERO.
               88  WS-IO-EOF                VALUE 8.
026057     05  WS-PGAL-EFF-DT               PIC X(10).

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
021930*COPY CCWWLOCK.
       COPY XCWWWKDT.
026057 COPY CCWWIHSD.
026057 COPY CCWWLOCK.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPGAM.
       COPY CCFWPGAL.
       COPY CCFRPGAL.
      /
021930*COPY CCFWPOL.
021930*COPY CCFRPOL.
021930*
026057 COPY CCFWPOL.
026057 COPY CCFRPOL.
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
021930*COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
021930*COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
       COPY XCWLCOMM REPLACING '$VAR1' BY '4480'.
           15  LCOMM-DATA.
               20  LCOMM-POL-ID                 PIC X(10).
               20  LCOMM-KEY-SW                 PIC X(01).

      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4484.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  COMM-1000-INITIALIZE
               THRU COMM-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970*    MOVE MIR-POL-ID-BASE         TO WS-POL-ID-BASE.
025970*    MOVE MIR-POL-ID-SFX          TO WS-POL-ID-SFX.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3000-PROCESS-LIST
                       THRU 3000-PROCESS-LIST-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4484'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-LIST.
      *----------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  WS-POL-ID  = SPACES
      *MSG:  POLICY ID MUST BE FILLED
              MOVE 'CS44840001'         TO WGLOB-MSG-REF-INFO
021930*       MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
021930        MOVE WS-POL-ID             TO WGLOB-MSG-PARM (1)
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR    TO TRUE
              GO TO 3000-PROCESS-LIST-X
           END-IF.

026057     MOVE WS-POL-ID               TO WPOL-POL-ID.
026057     PERFORM  POL-1000-READ-TWRK-TS
026057         THRU POL-1000-READ-TWRK-TS-X.
026057
026057     IF WPOL-IO-NOT-FOUND
026057*MSG: POLICY RECORD (@1) NOT FOUND
026057        MOVE 'CS44840002'       TO WGLOB-MSG-REF-INFO
026057        MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
026057        PERFORM 0260-1000-GENERATE-MESSAGE
026057           THRU 0260-1000-GENERATE-MESSAGE-X
026057        SET WGLOB-RETURN-ERROR  TO TRUE
026057        GO TO 3000-PROCESS-LIST-X
026057     END-IF.

           MOVE SPACE                   TO WS-KEY-SW.

           PERFORM  COMM-1000-RETRIEVE-TWRK
               THRU COMM-1000-RETRIEVE-TWRK-X.

           IF  NOT LCOMM-RETRN-NOT-FOUND
               IF  LCOMM-POL-ID = WS-POL-ID
                   MOVE LCOMM-KEY-SW    TO WS-KEY-SW
               END-IF
               PERFORM  COMM-3000-DELETE-TWRK
                   THRU COMM-3000-DELETE-TWRK-X
           END-IF.

           PERFORM 6000-BUILD-KEY
              THRU 6000-BUILD-KEY-X.

           IF WGLOB-RETURN-ERROR
              GO TO 3000-PROCESS-LIST-X
           END-IF.

           MOVE ZEROS                   TO WS-SUB.

           IF  WS-KEY-PGAL
               PERFORM  PGAL-1000-BROWSE-PREV
                   THRU PGAL-1000-BROWSE-PREV-X
               PERFORM  PGAL-2000-READ-PREV
                   THRU PGAL-2000-READ-PREV-X
               MOVE WPGAL-IO-STATUS     TO WS-IO-STATUS
           ELSE
               PERFORM  PGAM-1000-BROWSE-PREV
                   THRU PGAM-1000-BROWSE-PREV-X
               PERFORM  PGAM-2000-READ-PREV
                   THRU PGAM-2000-READ-PREV-X
               MOVE WPGAM-IO-STATUS     TO WS-IO-STATUS
           END-IF.

           PERFORM  3400-RETRIEVE-ALLOC-REC
               THRU 3400-RETRIEVE-ALLOC-REC-X
               UNTIL NOT WS-IO-OK
                  OR WS-SUB > WS-MAX-LINE.

           IF  NOT WS-IO-EOF
      *MSG: TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPGAL-PGAL-ALLOC-TYP-CD
                                        TO MIR-PGAL-ALLOC-TYP-CD
               MOVE RPGAL-PGAL-EFF-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE TO MIR-PGAL-EFF-DT

               MOVE RPGAL-PGAL-SEQ-NUM
                                        TO MIR-PGAL-SEQ-NUM
               SET WGLOB-MORE-DATA-EXISTS
                                        TO TRUE
           ELSE
               IF  MIR-PGAL-ALLOC-TYP-CD-T (1) > SPACES
                   MOVE MIR-PGAL-ALLOC-TYP-CD-T (1)
                                        TO MIR-PGAL-ALLOC-TYP-CD
                   MOVE MIR-PGAL-EFF-DT-T (1)
                                        TO MIR-PGAL-EFF-DT
                   MOVE MIR-PGAL-SEQ-NUM-T (1)
                                        TO MIR-PGAL-SEQ-NUM
      *MSG: END OF FILE REACHED
                   MOVE 'XS00000025'    TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORD FOUND FOR DISPLAY
                   MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  WS-KEY-PGAL
               PERFORM  PGAL-3000-END-BROWSE-PREV
                   THRU PGAL-3000-END-BROWSE-PREV-X
           ELSE
               PERFORM  PGAM-3000-END-BROWSE-PREV
                   THRU PGAM-3000-END-BROWSE-PREV-X
           END-IF.

           MOVE WS-POL-ID               TO LCOMM-POL-ID.
           MOVE WS-KEY-SW               TO LCOMM-KEY-SW.
           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.

       3000-PROCESS-LIST-X.
           EXIT.
      /
      *---------------------------
       3400-RETRIEVE-ALLOC-REC.
      *---------------------------

           ADD +1                       TO WS-SUB.

           IF  WS-SUB > WS-MAX-LINE
               GO TO 3400-RETRIEVE-ALLOC-REC-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

           IF  WS-KEY-PGAL
               PERFORM  PGAL-2000-READ-PREV
                   THRU PGAL-2000-READ-PREV-X
               MOVE WPGAL-IO-STATUS     TO WS-IO-STATUS
           ELSE
               PERFORM  PGAM-2000-READ-PREV
                   THRU PGAM-2000-READ-PREV-X
               MOVE WPGAM-IO-STATUS     TO WS-IO-STATUS
           END-IF.

       3400-RETRIEVE-ALLOC-REC-X.
           EXIT.
      /
      *---------------
       6000-BUILD-KEY.
      *---------------

           EVALUATE TRUE
               WHEN WS-KEY-PGAL
                   PERFORM  6100-BUILD-PGAL-KEY
                       THRU 6100-BUILD-PGAL-KEY-X

               WHEN WS-KEY-PGAM
                   PERFORM  6200-BUILD-PGAM-KEY
                       THRU 6200-BUILD-PGAM-KEY-X

               WHEN OTHER
                   IF  (MIR-PGAL-SEQ-NUM = ZERO
                   OR   MIR-PGAL-SEQ-NUM = SPACE)
                   AND (MIR-PGAL-EFF-DT  = SPACE)
                   AND (MIR-PGAL-ALLOC-TYP-CD NOT = SPACE)
                       PERFORM  6100-BUILD-PGAL-KEY
                           THRU 6100-BUILD-PGAL-KEY-X
                       SET WS-KEY-PGAL  TO TRUE
                   ELSE
                       PERFORM  6200-BUILD-PGAM-KEY
                           THRU 6200-BUILD-PGAM-KEY-X
                       SET WS-KEY-PGAM  TO TRUE
                   END-IF

           END-EVALUATE.


026057     IF WGLOB-RETURN-ERROR
026057        GO TO 6000-BUILD-KEY-X
026057     END-IF.
026057
026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-PGAL-EFF-DT        TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WGLOB-RETURN-ERROR     TO TRUE
026057        GO TO 6000-BUILD-KEY-X
026057     END-IF.

       6000-BUILD-KEY-X.
           EXIT.

      *--------------------
       6100-BUILD-PGAL-KEY.
      *--------------------

           MOVE WS-POL-ID               TO WPGAL-POL-ID.

           IF  MIR-PGAL-SEQ-NUM = ZERO
           OR  MIR-PGAL-SEQ-NUM = SPACE
               MOVE 999                 TO WPGAL-PGAL-SEQ-NUM
           ELSE
               MOVE MIR-PGAL-SEQ-NUM    TO WPGAL-PGAL-SEQ-NUM
           END-IF.

           MOVE MIR-PGAL-ALLOC-TYP-CD   TO WPGAL-PGAL-ALLOC-TYP-CD

           IF  MIR-PGAL-EFF-DT = SPACES
               MOVE WWKDT-HIGH-DT       TO WPGAL-PGAL-EFF-DT
           ELSE
               MOVE MIR-PGAL-EFF-DT     TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X

               IF  L1640-NOT-VALID
      * MSG: INVALID DATE
                   MOVE 'XS00000036'    TO WGLOB-MSG-REF-INFO
                   MOVE MIR-PGAL-EFF-DT TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                        TO TRUE
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                        TO WPGAL-PGAL-EFF-DT
026057             MOVE L1640-INTERNAL-DATE TO WS-PGAL-EFF-DT
               END-IF
           END-IF.

           MOVE WPGAL-KEY               TO WPGAL-ENDBR-KEY.
           MOVE WWKDT-LOW-DT            TO WPGAL-ENDBR-PGAL-EFF-DT
           MOVE LOW-VALUES              TO
                                        WPGAL-ENDBR-PGAL-ALLOC-TYP-CD.
           MOVE ZERO                    TO WPGAL-ENDBR-PGAL-SEQ-NUM.

       6100-BUILD-PGAL-KEY-X.
           EXIT.

      *--------------------
       6200-BUILD-PGAM-KEY.
      *--------------------

           MOVE WS-POL-ID               TO WPGAM-POL-ID.

           IF  MIR-PGAL-SEQ-NUM = ZERO
           OR  MIR-PGAL-SEQ-NUM = SPACE
               MOVE 999                 TO WPGAM-PGAL-SEQ-NUM
           ELSE
               MOVE MIR-PGAL-SEQ-NUM    TO WPGAM-PGAL-SEQ-NUM
           END-IF.

           IF  MIR-PGAL-ALLOC-TYP-CD = SPACE
               MOVE HIGH-VALUE          TO WPGAM-PGAL-ALLOC-TYP-CD
           ELSE
               MOVE MIR-PGAL-ALLOC-TYP-CD
                                        TO WPGAM-PGAL-ALLOC-TYP-CD
           END-IF.

           IF  MIR-PGAL-EFF-DT = SPACES
               MOVE WWKDT-HIGH-DT       TO WPGAM-PGAL-EFF-DT
           ELSE
               MOVE MIR-PGAL-EFF-DT     TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X

               IF  L1640-NOT-VALID
      * MSG: INVALID DATE
                   MOVE 'XS00000036'    TO WGLOB-MSG-REF-INFO
                   MOVE MIR-PGAL-EFF-DT TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                        TO TRUE
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                        TO WPGAM-PGAL-EFF-DT
026057             MOVE L1640-INTERNAL-DATE TO WS-PGAL-EFF-DT
               END-IF
           END-IF.

           MOVE WPGAM-KEY               TO WPGAM-ENDBR-KEY.
           MOVE WWKDT-LOW-DT            TO WPGAM-ENDBR-PGAL-EFF-DT
           MOVE LOW-VALUES              TO
                                        WPGAM-ENDBR-PGAL-ALLOC-TYP-CD.
           MOVE ZERO                    TO WPGAM-ENDBR-PGAL-SEQ-NUM.

       6200-BUILD-PGAM-KEY-X.
           EXIT.


      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                  TO MIR-POL-ID-G.
           MOVE SPACES                  TO MIR-PGAL-ALLOC-TYP-CD-G.
           MOVE SPACES                  TO MIR-PGAL-EFF-DT-G.
           MOVE SPACES                  TO MIR-PGAL-SEQ-NUM-G.
           MOVE SPACES                  TO MIR-PGAL-ALLOC-TYP-CD-G.
           MOVE SPACES                  TO MIR-PGAL-TRXN-TYP-CD-G.
           MOVE SPACES                  TO MIR-PGAL-TRXN-STAT-CD-G.
           MOVE SPACES                  TO MIR-PGAL-OPN-PRIN-AMT-G.
           MOVE SPACES                  TO MIR-PGAL-OPN-GAIN-AMT-G.
           MOVE SPACES                  TO MIR-PGAL-TRXN-PRIN-AMT-G.
           MOVE SPACES                  TO MIR-PGAL-TRXN-GAIN-AMT-G.
           MOVE SPACES                  TO MIR-PGAL-SURR-CHRG-AMT-G.
           MOVE SPACES                  TO MIR-PGAL-APROX-CV-IND-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           MOVE RPGAL-POL-ID            TO MIR-POL-ID-T (WS-SUB).
           MOVE RPGAL-PGAL-ALLOC-TYP-CD
                                        TO MIR-PGAL-ALLOC-TYP-CD-T
                                           (WS-SUB).

           MOVE RPGAL-PGAL-EFF-DT       TO L1640-INTERNAL-DATE
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE     TO MIR-PGAL-EFF-DT-T  (WS-SUB).

           MOVE RPGAL-PGAL-SEQ-NUM      TO MIR-PGAL-SEQ-NUM-T (WS-SUB).
           MOVE RPGAL-PGAL-TRXN-STAT-CD
                                        TO MIR-PGAL-TRXN-STAT-CD-T
                                           (WS-SUB).
           MOVE RPGAL-PGAL-APROX-CV-IND
                                        TO MIR-PGAL-APROX-CV-IND-T
                                           (WS-SUB).
           MOVE RPGAL-PGAL-TRXN-TYP-CD
                                        TO MIR-PGAL-TRXN-TYP-CD-T
                                           (WS-SUB).
           MOVE RPGAL-PGAL-ALLOC-TYP-CD
                                        TO MIR-PGAL-ALLOC-TYP-CD-T
                                           (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-OPN-PRIN-AMT * 100.
020874     MOVE RPGAL-PGAL-OPN-PRIN-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY       TO TRUE.
           SET L0290-SIGN-POS-DISPLAY   TO TRUE.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-OPN-PRIN-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-PGAL-OPN-PRIN-AMT-T
                                           (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-OPN-GAIN-AMT * 100.
020874     MOVE RPGAL-PGAL-OPN-GAIN-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY       TO TRUE.
           SET L0290-SIGN-POS-DISPLAY   TO TRUE.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-OPN-GAIN-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-PGAL-OPN-GAIN-AMT-T
                                           (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-TRXN-PRIN-AMT * 100.
020874     MOVE RPGAL-PGAL-TRXN-PRIN-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-POS-DISPLAY    TO TRUE.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PGAL-TRXN-PRIN-AMT-T
                                           (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-TRXN-GAIN-AMT * 100.
020874     MOVE RPGAL-PGAL-TRXN-GAIN-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-POS-DISPLAY    TO TRUE.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PGAL-TRXN-GAIN-AMT-T
                                           (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-SURR-CHRG-AMT * 100.
020874     MOVE RPGAL-PGAL-SURR-CHRG-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-POS-DISPLAY    TO TRUE.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-PGAL-SURR-CHRG-AMT-T
                                           (WS-SUB).

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  WS-MAX-LINE-DEFAULT         TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     MOVE MIR-POL-ID-BASE             TO WS-POL-ID-BASE.
025970     MOVE MIR-POL-ID-SFX              TO WS-POL-ID-SFX.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
021930*COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
021930*                        '$VAR2' BY 'POL'.
021930*
026057 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
026057                         '$VAR2' BY 'POL'.
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
      /
025970 COPY XCPS1670.
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
021930*COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY XCPS8090.
       COPY XCPL8090.
      /
       COPY XCPSCOMM.
       COPY XCPPCOMM.
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPVPGAM.
      /
       COPY CCPVPGAL.
      /
021930*COPY CCPNPOL.
021930*COPY CCPUPOL.
021930*
026057 COPY CCPNPOL.
026057 COPY CCPUPOL.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM4480                     *
      ****************************************************************
