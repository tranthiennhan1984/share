      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3000.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3000                                         **
      **  REMARKS:  PROCESS DRIVER FOR PLRT TRANSACTION              **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010302**  5.6       INITIAL CREATION                                 **
012136**  5.6V      ADD 'FLREG' VALUE TO WS-PLAN-RATE-TYPE           **
012138**  5.6V      ADD 'SECGP' VALUE TO WS-PLAN-RATE-TYPE           **
012139**  5.6V      SUPPORT REFUND OF EXCESS SALES LOAD (I.E         **
012139**            ADD 'FLDT ', 'PLDT ', 'SLDT ' VALUES             **
012139**            TO WS-PLAN-RATE-TYPE )                           **
013585**  5.6A      NEW FOR 5.6A -CONTRACTUAL PAYOUT                 **
013924**  5.6A      NEW FOR RELEASE 5.6A - ANNUAL BONUS              **
013930**  5.6A      NEW FOR RELEASE 5.6A - TERMINAL BONUS            **
013994**  5.6A      NEW FOR RELEASE 5.6A -                           **
013994**            BONUS AND DIVIDEND VESTING                       **
013578**  6.0       ELIMINATE SUPPORT OF CHARACTER INTERFACE         **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
016195**  6.1       CODE CLEANUP                                     **
014221**  6.2       LOGICAL RECORD LOCKING                           **
015919**  6.2       NEW FOR RELEASE 6.2 - TAMRA                      **
016548**  6.2       CHANGE COMP TO BINARY                            **
016016**  6.3       FUND BONUS (6.1.1E)                              **
016109**  6.3       FREE FUND TRANSFERS (6.1.2J)                     **
016307**  6.3       ADMIN CHARGES AS A PERCENT OF FUND VALUE (6.1.1E)**
016315**  6.3       CODE CLEAN-UP (UK)                               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018905**  6.3       DURATION BASED MATURITY/EXPIRY AGE AND TERM      **
020477**  6.4       MINIMUM DISTRIBUTION RULES                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      *
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3000'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

025970 01  WS-CONSTANTS.

025970     05  WS-MAX-BROWSE-LINES              PIC S9(4)  BINARY.
025970         88 WS-MAX-BROWSE-LINES-DEFAULT   VALUE +12.
025970    05  WS-TWRK-KEY                       PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT           VALUE '0770'.
025970
       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970*                                     BINARY.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-VALID                    VALUES ARE
                   '0770', '0771', '0772', '0773', '0774'.
               88  WS-BUS-FCN-RETRIEVE                 VALUE '0770'.
               88  WS-BUS-FCN-CREATE                   VALUE '0771'.
               88  WS-BUS-FCN-UPDATE                   VALUE '0772'.
               88  WS-BUS-FCN-DELETE                   VALUE '0773'.
               88  WS-BUS-FCN-LIST                     VALUE '0774'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '0770'.
020477*    05  WS-PLRT-KEY.
020477*        10  WS-PLAN-RATE-TYPE        PIC X(05).
020477*            88  WS-VALID-PLAN-RATE-TYPE         VALUES
020477*            'EIPAR' 'MIAGE' 'MIAMT' 'MXADB' 'INCOM' 'PREMS'
020477*            'PREMU' 'COLAR' 'COLAU' 'ADAGE' 'EQAGE' 'FCOMM'
016195*            'DRCOM' 'MININ' 'GVART' 'FARED' 'FREEW' 'PSURC'
020477*            'DRCOM' 'MNINT' 'GVART' 'FARED' 'FREEW' 'PSURC'
020477*            'SURRC' 'MNPYT' 'PAYLD' 'MXLIR' 'COMMT' 'PSURT'
020477*            'SURRT' 'ISCHG' 'ADMEX' 'COINS' 'GCOIN' 'DBCOR'
020477*            'GUIDA' 'GUIDS' 'ENHAN' 'QPDEP' 'TXCOI' 'LIFXP'
016315*            'GUARD' 'MNRIF' 'MXLIF' 'XFERE' 'PAKIT' 'CVANP'
020477*            'GUARD' 'MNRIF' 'MXLIF' 'XFERE'         'CVANP'
016315*            'PREMR' 'VANGD' 'VANSD' 'DXGTD' 'DXCAN' 'UNVTP'
020477*            'MCVLD' 'MCVIR' 'PMTLD' 'TAXWH' 'SCIIR' 'FLREG'
012139*            'FLSTD' 'FLDT ' 'PLDT ' 'SLDT '.
012136*            'FLSTD'.
013924*            'FLSTD' 'FLDT ' 'PLDT ' 'SLDT ' 'SECGP'.
020477*            'FLSTD' 'FLDT ' 'PLDT ' 'SLDT ' 'SECGP'
020477*            'ANBDV' 'ANBNP' 'ANBNR'
020477*            'TBBDT' 'TBDDT' 'TBBMT' 'TBDMT' 'TBBSR' 'TBDSR'
020477*            'VSTBN' 'VSTDV'
020477*            'TAMRA'
020477*            'ADMFE' 'ADMWV'
020477*            'CPAYN' 'DIPCT'
020477*            'INTBN'
016109*            'MTAGE' 'MTYRS'
020477*            'MTAGE' 'MTYRS' 'FREET'
020477*            'CVAGE' 'CVYRS' 'EXAGE' 'EXYRS'
020477*            'CPAYO'.
      *
014221 COPY CCWWLOCK.
       COPY XCWEBLCH.
      *
      ***************************************************************
      * COMM AREA
      ***************************************************************
013578*COPY CCWCCOMM.
      *
      ***************************************************************
      * PLAN RATE WORK AREA
      ***************************************************************
       COPY CCFRPLRT.
       COPY CCFWPLRT.
      *
      ***************************************************************
      * PLAN HEADER WORK AREA
      ***************************************************************
       COPY CCFRPH.
       COPY CCFWPH.
014221*****************************************************************
014221*  CALLED MODULE PARAMETER INFORMATION                          *
014221*****************************************************************
014221 COPY XCWL8090.
020477 COPY XCWL8960.
      *
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
      *
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3000.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ****************
       0000-MAINLINE.
      ****************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.

      **************************
       2000-PROCESS-REQUEST.
      **************************

           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3000'   TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *

      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************

           IF  MIR-PLAN-ID = SPACES
      *MSG:    PLAN ID IS REQUIRED
               MOVE 'CS30000001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO  TO  3000-PROCESS-RETRIEVE-X
           END-IF.

           IF  MIR-PLAN-RT-TYP-CD = SPACES
      *MSG:    PLAN RATE TYPE IS REQUIRED
               MOVE 'CS30000002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X
014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221        MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3000-PROCESS-RETRIEVE-X
014221     END-IF.

           MOVE MIR-PLAN-ID           TO WPLRT-PLAN-ID.
020477*    MOVE MIR-PLAN-RT-TYP-CD    TO WS-PLAN-RATE-TYPE.
020477*    MOVE WS-PLAN-RATE-TYPE     TO WPLRT-PLAN-RT-TYP-CD.
020477     MOVE MIR-PLAN-RT-TYP-CD    TO WPLRT-PLAN-RT-TYP-CD.

           PERFORM PLRT-1000-READ
              THRU PLRT-1000-READ-X.

           IF WPLRT-IO-NOT-FOUND
      *MSG:    RECORD NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WPLRT-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE

               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
      *MSG:'INQUIRE COMPLETED - CONTINUE'
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *******************
       3500-PROCESS-LIST.
      *******************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE LOW-VALUES            TO WPLRT-KEY.
           MOVE HIGH-VALUES           TO WPLRT-ENDBR-KEY.

           MOVE MIR-PLAN-ID           TO WPLRT-PLAN-ID.
           MOVE MIR-PLAN-ID           TO WPLRT-ENDBR-PLAN-ID.

           IF MIR-PLAN-RT-TYP-CD > SPACES
020477*       MOVE MIR-PLAN-RT-TYP-CD TO WS-PLAN-RATE-TYPE
020477*       MOVE WS-PLAN-RATE-TYPE  TO WPLRT-PLAN-RT-TYP-CD
020477        MOVE MIR-PLAN-RT-TYP-CD TO WPLRT-PLAN-RT-TYP-CD
           END-IF.

           PERFORM PLRT-1000-BROWSE
              THRU PLRT-1000-BROWSE-X

           IF WPLRT-IO-OK
               PERFORM PLRT-2000-READ-NEXT
                  THRU PLRT-2000-READ-NEXT-X
           END-IF.

           IF NOT WPLRT-IO-OK
           OR WPLRT-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM PLRT-3000-END-BROWSE
                  THRU PLRT-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WPLRT-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM PLRT-3000-END-BROWSE
              THRU PLRT-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      *

      *********************
       4000-PROCESS-CREATE.
      *********************

           MOVE MIR-PLAN-ID           TO WPLRT-PLAN-ID.
           MOVE MIR-PLAN-RT-TYP-CD    TO WPLRT-PLAN-RT-TYP-CD.
020477*    MOVE MIR-PLAN-RT-TYP-CD    TO WS-PLAN-RATE-TYPE.

           PERFORM PLRT-1000-READ
              THRU PLRT-1000-READ-X.

           IF  WPLRT-IO-OK
               MOVE WPLRT-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  PLAN RATE KEY EDITS.
      *
           PERFORM 5300-EDIT-PLRT-KEY-FIELDS
              THRU 5300-EDIT-PLRT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW = 0
               CONTINUE
           ELSE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM PLRT-1000-CREATE
              THRU PLRT-1000-CREATE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM PLRT-1000-WRITE
              THRU PLRT-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PLRT-1000-CALL-AUDIT
                  THRU PLRT-1000-CALL-AUDIT-X
           END-IF.

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      *

      *********************
       5000-PROCESS-UPDATE.
      *********************

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           MOVE MIR-PLAN-ID           TO WPLRT-PLAN-ID.
           MOVE MIR-PLAN-RT-TYP-CD    TO WPLRT-PLAN-RT-TYP-CD.

           PERFORM PLRT-1000-READ-FOR-UPDATE
              THRU PLRT-1000-READ-FOR-UPDATE-X.

           IF  WPLRT-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PLRT-1000-CALL-AUDIT
                      THRU PLRT-1000-CALL-AUDIT-X
               END-IF
           ELSE
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
      * MSG    RECORD LOST IN MAINTAIN
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           IF MIR-RH-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-RH-ID
           END-IF.

           IF MIR-RH-ID NOT = SPACE
               MOVE MIR-RH-ID         TO RPLRT-RH-ID
               PERFORM PLRT-2000-REWRITE
                  THRU PLRT-2000-REWRITE-X
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PLRT-1000-CALL-AUDIT
                      THRU PLRT-1000-CALL-AUDIT-X
               END-IF
014221         PERFORM PH-2000-REWRITE
014221            THRU PH-2000-REWRITE-X
014221         PERFORM PH-1000-READ-TWRK-TS
014221            THRU PH-1000-READ-TWRK-TS-X
      * MSG    MAINTAINANCE COMPLETE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM PLRT-3000-UNLOCK
                  THRU PLRT-3000-UNLOCK-X
      * MSG    RECORD *NOT* UPDATED
               MOVE 'XS00000039'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPLRT-RH-ID       TO MIR-RH-ID
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.

      *
      ****************************
       5300-EDIT-PLRT-KEY-FIELDS.
      ****************************

           MOVE MIR-PLAN-ID               TO WPH-PLAN-ID.

           PERFORM PH-2000-READ-INDEX
              THRU PH-2000-READ-INDEX-X.

           IF  WPH-IO-OK
               CONTINUE
           ELSE
      *MSG:    'PLAN NOT FOUND'
               MOVE 'CS30000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5300-EDIT-PLRT-KEY-FIELDS-X
           END-IF.

020477     PERFORM  8960-1000-BUILD-PARM-INFO
020477         THRU 8960-1000-BUILD-PARM-INFO-X.
020477
020477     MOVE 'PLAN-RT-TYP-CD'      TO L8960-AV-TBL-CD.
020477     MOVE MIR-PLAN-RT-TYP-CD    TO L8960-AV-CD.
020477
020477     PERFORM  8960-1000-VALIDATE-CODE
020477         THRU 8960-1000-VALIDATE-CODE-X.
020477
020477     IF  L8960-RETRN-OK
020477*    IF  WS-VALID-PLAN-RATE-TYPE
               CONTINUE
           ELSE
      *MSG:    'PLAN RATE NOT FOUND'
               MOVE 'CS30000004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5300-EDIT-PLRT-KEY-FIELDS-X.
           EXIT.
      *
      *********************
       6000-PROCESS-DELETE.
      *********************

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  8050-BUILD-PLRT-KEY
               THRU 8050-BUILD-PLRT-KEY-X.

           PERFORM PLRT-1000-READ-FOR-UPDATE
              THRU PLRT-1000-READ-FOR-UPDATE-X

           IF  WPLRT-IO-OK
               PERFORM 6210-PROCESS-PROCESS-DELETE
                  THRU 6210-PROCESS-PROCESS-DELETE-X
           ELSE

014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WPLRT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      *
      ****************************
       6210-PROCESS-PROCESS-DELETE.
      ****************************

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PLRT-1000-CALL-AUDIT
                  THRU PLRT-1000-CALL-AUDIT-X
           END-IF.

           PERFORM PLRT-1000-DELETE
              THRU PLRT-1000-DELETE-X.

           IF WPLRT-IO-OK
      *MSG:   DELETE COMPLETED MESSAGE
              MOVE 'XS00000011'       TO WGLOB-MSG-REF-INFO
              IF  WGLOB-AUDIT-REQUESTED
                  PERFORM PLRT-1000-CALL-AUDIT
                     THRU PLRT-1000-CALL-AUDIT-X
              END-IF
014221        PERFORM  PH-2000-REWRITE
014221            THRU PH-2000-REWRITE-X
014221        PERFORM  PH-1000-READ-TWRK-TS
014221            THRU PH-1000-READ-TWRK-TS-X
           ELSE
      *MSG:   RECORD (@1) LOST IN DELETE
              MOVE WPLRT-KEY          TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000010'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
           END-IF.

       6210-PROCESS-PROCESS-DELETE-X.
           EXIT.
      *
      ********************
       8050-BUILD-PLRT-KEY.
      ********************

           MOVE MIR-PLAN-ID           TO WPLRT-PLAN-ID.
           MOVE MIR-PLAN-ID           TO WPLRT-ENDBR-PLAN-ID.
           MOVE MIR-PLAN-RT-TYP-CD    TO WPLRT-PLAN-RT-TYP-CD.
           MOVE MIR-PLAN-RT-TYP-CD    TO WPLRT-ENDBR-PLAN-RT-TYP-CD.

       8050-BUILD-PLRT-KEY-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      ***********************
       9100-BLANK-DATA-FIELDS.
      ***********************

           MOVE SPACES                TO MIR-PLAN-RT-TYP-CD-G.
           MOVE SPACES                TO MIR-RH-ID-G.
           MOVE SPACES                TO MIR-RH-ID.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      ***************************
       9200-MOVE-RECORD-TO-SCREEN.
      ***************************

           IF  WS-BUS-FCN-LIST
               PERFORM 9210-MOVE-PLRT-TO-SCRN-1
                  THRU 9210-MOVE-PLRT-TO-SCRN-1-X
                VARYING I FROM 1 BY 1
                  UNTIL I > WS-MAX-BROWSE-LINES
                     OR WPLRT-IO-EOF

               IF  NOT WPLRT-IO-EOF
                   MOVE RPLRT-PLAN-ID TO MIR-PLAN-ID
                   MOVE RPLRT-PLAN-RT-TYP-CD
                                      TO MIR-PLAN-RT-TYP-CD
               END-IF

               IF  WPLRT-IO-EOF
               AND MIR-PLAN-RT-TYP-CD-T (1) NOT = SPACES
                   MOVE MIR-PLAN-RT-TYP-CD-T (1)
                                      TO MIR-PLAN-RT-TYP-CD
               END-IF
           ELSE
               MOVE RPLRT-RH-ID       TO MIR-RH-ID
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *
      *************************
       9210-MOVE-PLRT-TO-SCRN-1.
      *************************

           MOVE RPLRT-PLAN-RT-TYP-CD  TO MIR-PLAN-RT-TYP-CD-T (I).
           MOVE RPLRT-RH-ID           TO MIR-RH-ID-T (I).

           PERFORM PLRT-2000-READ-NEXT
              THRU PLRT-2000-READ-NEXT-X.

       9210-MOVE-PLRT-TO-SCRN-1-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      **************************
       9300-SETUP-MSIN-REFERENCE.
      **************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.

       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      *
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
025970 COPY XCPS8090.
020477 COPY XCPS8960.
020477 COPY XCPL8960.
018764*COPY CCCLPLRT.
018764 COPY CCPLPLRT.
      *
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY CCPNPH.
014221 COPY CCPUPH.
      *
       COPY CCPAPLRT.
       COPY CCPNPLRT.
       COPY CCPBPLRT.
       COPY CCPCPLRT.
       COPY CCPUPLRT.
       COPY CCPXPLRT.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM CSOM3000                       *
      ******************************************************************
