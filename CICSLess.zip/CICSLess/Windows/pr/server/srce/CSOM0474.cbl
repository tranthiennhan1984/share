      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0474.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0474                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE LIST FUNCTION           **
      **            FOR THE PBRQ TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0474'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORK-AREA.
           05  WS-CONSTANT-FIELDS.
               10  WS-MAX-LIST-LINES             PIC S9(04) BINARY.
                   88  WS-MAX-LIST-LINES-DEFAULT VALUE 100.

           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID                 PIC X(04).
                   88  WS-BUS-FCN-LIST           VALUE '0474'.
               10  WS-SUB                        PIC S9(04) BINARY.
               10  WS-EFF-DT-INT                 PIC X(10).
036742*        10  WS-TS                         PIC X(26).
036742         10  WS-GEN-ID                     PIC 9(10).
               10  WS-VALIDATE-NO-SW             PIC X(01).
                   88  WS-VALIDATE-NOT-OK        VALUE 'N'.
                   88  WS-VALIDATE-OK            VALUE 'Y'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
036742 COPY XCWWCNST.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
036742*COPY CCFWPBRS.
036742 COPY CCFWPBRQ.
       COPY CCFRPBRQ.

       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
       COPY XCWL1640.
      /
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0474.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0474'          TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'        TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                             TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-LIST.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WS-VALIDATE-NOT-OK
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

036742*    PERFORM  PBRS-1000-BROWSE-PREV
036742*        THRU PBRS-1000-BROWSE-PREV-X.
036742*
036742*    PERFORM  PBRS-2000-READ-PREV
036742*        THRU PBRS-2000-READ-PREV-X.
036742     PERFORM  PBRQ-1000-BROWSE-PREV
036742         THRU PBRQ-1000-BROWSE-PREV-X.
036742
036742     PERFORM  PBRQ-2000-READ-PREV
036742         THRU PBRQ-2000-READ-PREV-X.

036742*    IF  WPBRS-IO-EOF
036742     IF  WPBRQ-IO-EOF
036742*        PERFORM  PBRS-3000-END-BROWSE-PREV
036742*            THRU PBRS-3000-END-BROWSE-PREV-X
036742         PERFORM  PBRQ-3000-END-BROWSE-PREV
036742             THRU PBRQ-3000-END-BROWSE-PREV-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

036742*    PERFORM  2010-BROWSE-PBRS
036742*        THRU 2010-BROWSE-PBRS-X
036742*        VARYING WS-SUB FROM 1 BY 1
036742*        UNTIL   WS-SUB > WS-MAX-LIST-LINES
036742*        OR      WPBRS-IO-EOF.
036742     PERFORM  2010-BROWSE-PBRQ
036742         THRU 2010-BROWSE-PBRQ-X
036742         VARYING WS-SUB FROM 1 BY 1
036742         UNTIL   WS-SUB > WS-MAX-LIST-LINES
036742         OR      WPBRQ-IO-EOF.

036742*    IF  WPBRS-IO-OK
036742     IF  WPBRQ-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
               MOVE 'XS00000014'             TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-MOVE-RECORD-TO-KEY
                   THRU 9100-MOVE-RECORD-TO-KEY-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'             TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

036742*    PERFORM  PBRS-3000-END-BROWSE-PREV
036742*        THRU PBRS-3000-END-BROWSE-PREV-X.
036742     PERFORM  PBRQ-3000-END-BROWSE-PREV
036742         THRU PBRQ-3000-END-BROWSE-PREV-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
036742*2010-BROWSE-PBRS.
036742 2010-BROWSE-PBRQ.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

036742*    PERFORM  PBRS-2000-READ-PREV
036742*        THRU PBRS-2000-READ-PREV-X.
036742     PERFORM  PBRQ-2000-READ-PREV
036742         THRU PBRQ-2000-READ-PREV-X.

036742*2010-BROWSE-PBRS-X.
036742 2010-BROWSE-PBRQ-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           SET WS-VALIDATE-OK                TO TRUE.
           PERFORM  2110-EDIT-POL-ID
               THRU 2110-EDIT-POL-ID-X.

           PERFORM  2120-EDIT-EFF-DT
               THRU 2120-EDIT-EFF-DT-X.

036742*    IF  MIR-POL-RQST-CREAT-TS = SPACE
036742     IF  MIR-PBRQST-GEN-ID     = SPACE
036742*        MOVE WWKDT-HIGH-TS            TO WS-TS
036742         MOVE WCNST-MAX-PBRQST-GEN-ID-N
                                             TO WS-GEN-ID
           ELSE
036742*        MOVE MIR-POL-RQST-CREAT-TS    TO WS-TS
036742         MOVE MIR-PBRQST-GEN-ID        TO L0280-INPUT-DATA
036742         MOVE LENGTH OF MIR-PBRQST-GEN-ID
036742                                       TO L0280-INPUT-SIZE
036742         MOVE L0280-INPUT-SIZE         TO L0280-LENGTH
036742         MOVE ZERO                     TO L0280-PRECISION
036742         SET L0280-SIGN-NOT-PERMITTED  TO TRUE
036742         SET L0280-SPACES-PERMITTED    TO TRUE
036742
036742         PERFORM  0280-1000-NUMERIC-EDIT
036742             THRU 0280-1000-NUMERIC-EDIT-X
036742
036742         IF  L0280-OK
036742             MOVE L0280-OUTPUT-V00     TO WS-GEN-ID
036742         ELSE
036742             MOVE WCNST-MAX-PBRQST-GEN-ID-N
036742                                       TO WS-GEN-ID
036742         END-IF
           END-IF.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *-----------------
       2110-EDIT-POL-ID.
      *-----------------

           IF  MIR-POL-ID = SPACES
      *MSG: POLICY ID MUST BE ENTERED
               MOVE 'CS04740001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
               GO TO 2110-EDIT-POL-ID-X
           END-IF.

           MOVE MIR-POL-ID                   TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      * MSG POLICY (@1) NOT FOUND
               MOVE 'XS00000070'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ID               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

       2110-EDIT-POL-ID-X.
           EXIT.
      /
      *-----------------
       2120-EDIT-EFF-DT.
      *-----------------

           IF  MIR-PBRQST-EFF-DT = SPACE
               MOVE WWKDT-HIGH-DT            TO WS-EFF-DT-INT
               GO TO 2120-EDIT-EFF-DT-X
           END-IF.

           MOVE MIR-PBRQST-EFF-DT            TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      * MSG INVALID EFFECTIVE DATE
               MOVE 'XS00000355'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
               GO TO 2120-EDIT-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE          TO WS-EFF-DT-INT.

       2120-EDIT-EFF-DT-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

036742*    MOVE HIGH-VALUES            TO WPBRS-KEY.
036742*    MOVE MIR-POL-ID             TO WPBRS-POL-ID.
036742*    MOVE WS-EFF-DT-INT          TO WPBRS-PBRQST-EFF-DT.
036742*    MOVE WS-TS                  TO WPBRS-POL-RQST-CREAT-TS.
036742*
036742*    MOVE WPBRS-KEY              TO WPBRS-ENDBR-KEY.
036742*    MOVE WWKDT-LOW-DT           TO WPBRS-ENDBR-PBRQST-EFF-DT.
036742*    MOVE WWKDT-LOW-TS           TO WPBRS-ENDBR-POL-RQST-CREAT-TS.
036742     MOVE HIGH-VALUES            TO WPBRQ-KEY.
036742     MOVE MIR-POL-ID             TO WPBRQ-POL-ID.
036742     MOVE WS-EFF-DT-INT          TO WPBRQ-PBRQST-EFF-DT.
036742     MOVE WS-GEN-ID              TO WPBRQ-PBRQST-GEN-ID.
036742
036742     MOVE WPBRQ-KEY              TO WPBRQ-ENDBR-KEY.
036742     MOVE WWKDT-LOW-DT           TO WPBRQ-ENDBR-PBRQST-EFF-DT.
036742     MOVE ZERO                   TO WPBRQ-ENDBR-PBRQST-GEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                  TO MIR-PBRQST-EFF-DT-G.
           MOVE SPACE                  TO MIR-OFFANNV-PD-DT-G.
           MOVE SPACE                  TO MIR-BILL-MODE-CD-G.
           MOVE SPACE                  TO MIR-PBRQST-BILL-TYP-CD-G.
           MOVE SPACE                  TO MIR-PBRQST-MODE-FCT-G.
           MOVE SPACE                  TO MIR-PBRQST-PFEE-FCT-G.
           MOVE SPACE                  TO MIR-MODE-FCT-RESTR-IND-G.
           MOVE SPACE                  TO MIR-PFEE-RESTR-IND-G.
           MOVE SPACE                  TO MIR-PBRQST-SNDRY-AMT-G.
           MOVE SPACE                  TO MIR-SNDRY-REASN-CD-G.
           MOVE SPACE                  TO MIR-PBRQST-PMT-DRW-DY-G.
           MOVE SPACE                  TO MIR-CLI-ID-G.
           MOVE SPACE                  TO MIR-CLI-BNK-ACCT-NUM-G.
           MOVE SPACE                  TO MIR-CLI-ADDR-TYP-CD-G.
           MOVE SPACE                  TO MIR-PBRQST-SFB-CD-G.
           MOVE SPACE                  TO MIR-SFB-SEMI-MTHLY-DY-G.
           MOVE SPACE                  TO MIR-PBRQST-SFB-STRT-DT-G.
           MOVE SPACE                  TO MIR-PBRQST-SFB-END-DT-G.
           MOVE SPACE                  TO MIR-SFB-GP-END-DT-NUM-G.
           MOVE SPACE                  TO MIR-SFB-GP-STRT-DT-NUM-G.
036742*    MOVE SPACE                  TO MIR-POL-RQST-CREAT-TS-G.
036742     MOVE SPACE                  TO MIR-PBRQST-GEN-ID-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9100-MOVE-RECORD-TO-KEY.
      *------------------------

           MOVE RPBRQ-POL-ID           TO MIR-POL-ID.

           MOVE RPBRQ-PBRQST-EFF-DT    TO L1640-INTERNAL-DATE.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE    TO MIR-PBRQST-EFF-DT.

036742*    MOVE RPBRQ-POL-RQST-CREAT-TS
036742*                                TO MIR-POL-RQST-CREAT-TS.
036742     MOVE RPBRQ-PBRQST-GEN-ID    TO L0290-INPUT-V00.
036742     MOVE ZERO                   TO L0290-PRECISION.
036742     MOVE LENGTH OF MIR-PBRQST-GEN-ID
036742                                 TO L0290-MAX-OUT-LEN.
036742     SET L0290-LEAD-ZEROS-SUPPRESS
036742                                 TO TRUE.
036742     PERFORM  0290-2000-FORMAT-FOR-MIR
036742         THRU 0290-2000-FORMAT-FOR-MIR-X.
036742
036742     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-GEN-ID.

       9100-MOVE-RECORD-TO-KEY-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           MOVE RPBRQ-PBRQST-EFF-DT    TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PBRQST-EFF-DT-T
                                          (WS-SUB).

           MOVE RPBRQ-OFFANNV-PD-DT    TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-OFFANNV-PD-DT-T
                                          (WS-SUB).

           MOVE RPBRQ-PBRQST-BILL-TYP-CD
                                       TO MIR-PBRQST-BILL-TYP-CD-T
                                          (WS-SUB).

           MOVE RPBRQ-BILL-MODE-CD     TO MIR-BILL-MODE-CD-T
                                          (WS-SUB).

           MOVE RPBRQ-MODE-FCT-RESTR-IND
                                       TO MIR-MODE-FCT-RESTR-IND-T
                                          (WS-SUB).

           MOVE RPBRQ-PFEE-RESTR-IND   TO MIR-PFEE-RESTR-IND-T
                                          (WS-SUB).

           MOVE RPBRQ-SNDRY-REASN-CD   TO MIR-SNDRY-REASN-CD-T
                                          (WS-SUB).

           IF  RPBRQ-PBRQST-PMT-DRW-DY = ZERO
               MOVE SPACES             TO MIR-PBRQST-PMT-DRW-DY-T
                                          (WS-SUB)
           ELSE
               MOVE RPBRQ-PBRQST-PMT-DRW-DY
                                       TO L0290-INPUT-V00
               MOVE ZERO               TO L0290-PRECISION
               MOVE LENGTH OF MIR-PBRQST-PMT-DRW-DY-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-PBRQST-PMT-DRW-DY-T
                                          (WS-SUB)
           END-IF.

           IF  RPBRQ-PBRQST-SNDRY-AMT = ZERO
               MOVE SPACES             TO MIR-PBRQST-SNDRY-AMT-T
                                          (WS-SUB)
           ELSE
               MOVE RPBRQ-PBRQST-SNDRY-AMT
                                       TO L0290-INPUT-V02
               MOVE 2                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-PBRQST-SNDRY-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-PBRQST-SNDRY-AMT-T
                                          (WS-SUB)
           END-IF.

           IF  RPBRQ-PBRQST-MODE-FCT = ZERO
               MOVE SPACES             TO MIR-PBRQST-MODE-FCT-T
                                          (WS-SUB)
           ELSE
               MOVE RPBRQ-PBRQST-MODE-FCT
                                       TO L0290-INPUT-V07
               MOVE 7                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-PBRQST-MODE-FCT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-PBRQST-MODE-FCT-T
                                          (WS-SUB)
           END-IF.

           IF  RPBRQ-PBRQST-PFEE-FCT  = ZERO
               MOVE SPACES             TO MIR-PBRQST-PFEE-FCT-T
                                          (WS-SUB)
           ELSE
               MOVE RPBRQ-PBRQST-PFEE-FCT
                                       TO L0290-INPUT-V07
               MOVE 7                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-PBRQST-PFEE-FCT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-PBRQST-PFEE-FCT-T
                                          (WS-SUB)
           END-IF.

           MOVE RPBRQ-PBRQST-STAT-CD   TO MIR-PBRQST-STAT-CD-T
                                          (WS-SUB).

           MOVE RPBRQ-CLI-ID           TO MIR-CLI-ID-T
                                          (WS-SUB).

           MOVE RPBRQ-CLI-BNK-ACCT-NUM TO L0290-INPUT-V00.
           MOVE ZERO                   TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CLI-BNK-ACCT-NUM-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           SET L0290-LEAD-ZEROS-SUPPRESS
                                       TO TRUE.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA      TO MIR-CLI-BNK-ACCT-NUM-T
                                          (WS-SUB).

           MOVE RPBRQ-CLI-ADDR-TYP-CD  TO MIR-CLI-ADDR-TYP-CD-T
                                          (WS-SUB).

           MOVE RPBRQ-PBRQST-SFB-CD    TO MIR-PBRQST-SFB-CD-T
                                          (WS-SUB).

           MOVE RPBRQ-SFB-SEMI-MTHLY-DY
                                       TO MIR-SFB-SEMI-MTHLY-DY-T
                                          (WS-SUB).
           MOVE RPBRQ-PBRQST-SFB-STRT-DT
                                       TO L1640-INTERNAL-DATE
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X
           MOVE L1640-EXTERNAL-DATE    TO MIR-PBRQST-SFB-STRT-DT-T
                                          (WS-SUB).
           MOVE RPBRQ-PBRQST-SFB-END-DT
                                       TO L1640-INTERNAL-DATE
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X
           MOVE L1640-EXTERNAL-DATE    TO MIR-PBRQST-SFB-END-DT-T
                                          (WS-SUB).
           MOVE RPBRQ-SFB-GP-STRT-DT-NUM
                                       TO L1640-INTERNAL-DATE
           PERFORM  1640-4000-INTERNAL-TO-EXT-S
               THRU 1640-4000-INTERNAL-TO-EXT-S-X
           MOVE L1640-EXTERNAL-DATE    TO MIR-SFB-GP-STRT-DT-NUM-T
                                          (WS-SUB).
           MOVE RPBRQ-SFB-GP-END-DT-NUM
                                       TO L1640-INTERNAL-DATE
           PERFORM  1640-4000-INTERNAL-TO-EXT-S
               THRU 1640-4000-INTERNAL-TO-EXT-S-X
           MOVE L1640-EXTERNAL-DATE    TO MIR-SFB-GP-END-DT-NUM-T
                                          (WS-SUB).

036742*    MOVE RPBRQ-POL-RQST-CREAT-TS
036742*                                TO MIR-POL-RQST-CREAT-TS-T
036742*                                   (WS-SUB).
036742     MOVE RPBRQ-PBRQST-GEN-ID    TO L0290-INPUT-V00.
036742     MOVE ZERO                   TO L0290-PRECISION.
036742     MOVE LENGTH OF MIR-PBRQST-GEN-ID-T (WS-SUB)
036742                                 TO L0290-MAX-OUT-LEN.
036742     SET L0290-LEAD-ZEROS-SUPPRESS
036742                                 TO TRUE.
036742     PERFORM  0290-2000-FORMAT-FOR-MIR
036742         THRU 0290-2000-FORMAT-FOR-MIR-X.
036742
036742     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-GEN-ID-T
036742                                    (WS-SUB).


       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           INITIALIZE WS-WORK-AREA.
           SET WS-MAX-LIST-LINES-DEFAULT     TO TRUE.
           MOVE SPACE                        TO WWKDT-WORK-FIELDS.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
      /
036742 COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0280.
       COPY XCPS0290.
      /
       COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
      /
036742*COPY CCPVPBRS.
036742 COPY CCPVPBRQ.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCP0030.
      /
       COPY XCCPERR.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM0474                     **
      *****************************************************************
