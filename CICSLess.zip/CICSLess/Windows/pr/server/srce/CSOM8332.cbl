      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8332.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8332                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE UPDATE FUNCTION   **
      **            FOR THE POLX TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8332'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-UPDATE            VALUE '8332'.
           05  WS-POL-XEMP-EFF-DT               PIC X(10).

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                      PIC X(04).
               88 WS-TWRK-KEY-DEFAULT           VALUE '8330'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFWPOLX.
       COPY CCFRPOLX.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY CCWLPGA.

       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8332.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8332'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-UPDATE.
      *------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

      * VALIDATE KEY INFO

           PERFORM  8000-EDIT-KEY-INFO
               THRU 8000-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-UPDATE-X
           END-IF.

      * READ POLX

           MOVE LOW-VALUES              TO WPOLX-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPOLX-CO-ID.
           MOVE RPOL-POL-ID             TO WPOLX-POL-ID.
           MOVE WS-POL-XEMP-EFF-DT      TO WPOLX-POL-XEMP-EFF-DT.

           PERFORM  POLX-1000-READ-FOR-UPDATE
               THRU POLX-1000-READ-FOR-UPDATE-X.

           IF  NOT WPOLX-IO-OK
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'          TO WGLOB-MSG-REF-INFO
               MOVE WPOLX-KEY             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

      * EDIT POLX

           PERFORM  2100-EDIT-POLX
               THRU 2100-EDIT-POLX-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  POLX-3000-UNLOCK
                   THRU POLX-3000-UNLOCK-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  POLX-2000-REWRITE
               THRU POLX-2000-REWRITE-X.

      * REWRITE POLICY TABLE

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
      *MSG:    'RECORD UPDATED'
               MOVE 'XS00000008'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-UPDATE-X
           ELSE
      *MSG:    'MAINTENANCE COMPLETED - CONTINUE'
               MOVE 'XS00000007'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2000-UPDATE-X.
           EXIT.

      *---------------
       2100-EDIT-POLX.
      *---------------

           PERFORM  2110-EDIT-FND-OPT-PREV-AMT
               THRU 2110-EDIT-FND-OPT-PREV-AMT-X.

           PERFORM  2120-EDIT-FND-OPT-CRNT-AMT
               THRU 2120-EDIT-FND-OPT-CRNT-AMT-X.

           PERFORM  2130-EDIT-ESTMT-MAX-PREM-AMT
               THRU 2130-EDIT-ESTMT-MAX-PREM-AMT-X.

           PERFORM  2140-EDIT-POL-ACUM-FND-AMT
               THRU 2140-EDIT-POL-ACUM-FND-AMT-X.

           PERFORM  2150-EDIT-SIDFND-CSV-AMT
               THRU 2150-EDIT-SIDFND-CSV-AMT-X.

           PERFORM  2160-EDIT-REMN-ADDL-DPOS-AMT
               THRU 2160-EDIT-REMN-ADDL-DPOS-AMT-X.

           MOVE RPOLX-POL-XEMP-STAT-CD  TO MIR-POL-XEMP-STAT-CD.

       2100-EDIT-POLX-X.
           EXIT.

      *---------------------------
       2110-EDIT-FND-OPT-PREV-AMT.
      *---------------------------

           MOVE MIR-FND-OPT-PREV-AMT    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-FND-OPT-PREV-AMT
                                        TO L0280-INPUT-SIZE.
           MOVE +2                      TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED     TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      * MSG: 'INVALID AMOUNT - FUND OPTIMIZATION, PRIOR TO ANNIVERSARY'
               MOVE 'CS83320001'        TO WGLOB-MSG-REF-INFO
               MOVE  MIR-FND-OPT-PREV-AMT      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V02    TO RPOLX-FND-OPT-PREV-AMT
           END-IF.

       2110-EDIT-FND-OPT-PREV-AMT-X.
           EXIT.

      *---------------------------
       2120-EDIT-FND-OPT-CRNT-AMT.
      *---------------------------

           MOVE MIR-FND-OPT-CRNT-AMT    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-FND-OPT-CRNT-AMT
                                        TO L0280-INPUT-SIZE.
           MOVE +2                      TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED     TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      * MSG: 'INVALID AMOUNT- FUND OPTIMIZATION, CURRENT ANNIVERSARY'
               MOVE 'CS83320002'        TO WGLOB-MSG-REF-INFO
               MOVE  MIR-FND-OPT-CRNT-AMT      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V02    TO RPOLX-FND-OPT-CRNT-AMT
           END-IF.

       2120-EDIT-FND-OPT-CRNT-AMT-X.
           EXIT.

      *-----------------------------
       2130-EDIT-ESTMT-MAX-PREM-AMT.
      *-----------------------------

           MOVE MIR-ESTMT-MAX-PREM-AMT  TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-ESTMT-MAX-PREM-AMT
                                        TO L0280-INPUT-SIZE.
           MOVE +2                      TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      * MSG: 'INVALID ESTIMATED MAXIMUM PREMIUM AMOUNT'
               MOVE 'CS83320003'        TO WGLOB-MSG-REF-INFO
               MOVE  MIR-ESTMT-MAX-PREM-AMT   TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V02    TO RPOLX-ESTMT-MAX-PREM-AMT
           END-IF.

       2130-EDIT-ESTMT-MAX-PREM-AMT-X.
           EXIT.

      *---------------------------
       2140-EDIT-POL-ACUM-FND-AMT.
      *---------------------------

           MOVE MIR-POL-ACUM-FND-AMT    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-POL-ACUM-FND-AMT
                                        TO L0280-INPUT-SIZE.
           MOVE +2                      TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      * MSG: 'INVALID POLICY ACCUMULATING FUND AMOUNT'
               MOVE 'CS83320004'        TO WGLOB-MSG-REF-INFO
               MOVE  MIR-POL-ACUM-FND-AMT  TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V02    TO RPOLX-POL-ACUM-FND-AMT
           END-IF.

       2140-EDIT-POL-ACUM-FND-AMT-X.
           EXIT.

      *-------------------------
       2150-EDIT-SIDFND-CSV-AMT.
      *-------------------------

           MOVE MIR-SIDFND-CSV-AMT      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-SIDFND-CSV-AMT
                                        TO L0280-INPUT-SIZE.
           MOVE +2                      TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      * MSG: 'INVALID SIDE FUND NET CASH SURRENDER VALUE'
               MOVE 'CS83320005'        TO WGLOB-MSG-REF-INFO
               MOVE  MIR-SIDFND-CSV-AMT TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V02    TO RPOLX-SIDFND-CSV-AMT
           END-IF.

       2150-EDIT-SIDFND-CSV-AMT-X.
           EXIT.

      *-----------------------------
       2160-EDIT-REMN-ADDL-DPOS-AMT.
      *-----------------------------

           MOVE MIR-REMN-ADDL-DPOS-AMT  TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-REMN-ADDL-DPOS-AMT
                                        TO L0280-INPUT-SIZE.
           MOVE +2                      TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED     TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      * MSG: 'INVALID REMAINING MAXIMUM PREMIUM AMOUNT'
               MOVE 'CS83320006'        TO WGLOB-MSG-REF-INFO
               MOVE  MIR-REMN-ADDL-DPOS-AMT
                                        TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V02    TO RPOLX-REMN-ADDL-DPOS-AMT
           END-IF.

       2160-EDIT-REMN-ADDL-DPOS-AMT-X.
           EXIT.

      *-------------------
       8000-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
               MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
               MOVE 'POL'             TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-EDIT-KEY-INFO-X
           END-IF.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-EDIT-KEY-INFO-X
           END-IF.
      *
      * VALIDATE EFFECTIVE DATE
      *
           MOVE MIR-POL-XEMP-EFF-DT        TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               MOVE 'XS00000036'           TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-XEMP-EFF-DT    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE    TO WS-POL-XEMP-EFF-DT
           END-IF.

       8000-EDIT-KEY-INFO-X.
           EXIT.

      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-IO-AREA.
           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  POLX-1000-CALL-AUDIT
                   THRU POLX-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.

           SET WS-TWRK-KEY-DEFAULT      TO TRUE.
           SET MIR-RETRN-OK             TO TRUE.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY CCPLPOLX.

       COPY XCPS8090.

       COPY XCPL0260.

       COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPL0290.
       COPY XCPS0290.

       COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPUPOLX.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM8332                     **
      *****************************************************************
