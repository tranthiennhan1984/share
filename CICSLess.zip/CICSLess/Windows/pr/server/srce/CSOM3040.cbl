      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3040.


       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3040                                         **
      **  REMARKS:  PROCESS DRIVER FOR PVAR                          **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010650**  5.6       INITIAL PROGRAM DESIGN                           **
012136**  5.6V      ADD NEW FREE LOOK FIELDS                         **
012145**  5.6V      ADD NEW FIELDS ON PLAN LOCATION TABLE            **
014035**  5.6V      CHANGES TO STANDARDIZE BROWSE SCREEN             **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018845**  6.3       SURRENDER VALUE LAPSE                            **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3040'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID            PIC X(04).
                   88  WS-BUS-FCN-RETRIEVE  VALUE '0810'.
                   88  WS-BUS-FCN-CREATE    VALUE '0811'.
                   88  WS-BUS-FCN-UPDATE    VALUE '0812'.
                   88  WS-BUS-FCN-DELETE    VALUE '0813'.
                   88  WS-BUS-FCN-LIST      VALUE '0814'.
               10  WS-MESSAGE-SW            PIC X(01).
                   88  WS-VALID-MESSAGE     VALUE 'Y'.
                   88  WS-INVALID-MESSAGE   VALUE 'N'.
014221     05  WS-TWRK-KEY                  PIC X(04)
014221                                      VALUE '0810'.
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '0810'.
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
016548*    05  WS-MAX-LINES                 PIC S9(04) COMP
016548     05  WS-MAX-LINES                 PIC S9(04) BINARY
014035*                                                VALUE +12.
014035                                                 VALUE +48.
025970         88 WS-MAX-LINES-DEFAULT          VALUE +48.
           05  WS-FREE-WTHDR-QTY-N          PIC 9(03).
           05  WS-FREE-WTHDR-QTY  REDEFINES WS-FREE-WTHDR-QTY-N.
               10  FILLER                   PIC X.
               10  WS-FREE-WTHDR-QTY-A      PIC X(02).
      /
016537*COPY XCWL0280.
      /
012145 COPY XCWL0290.
014221/
014221 COPY XCWL8090.
      /
014035*COPY XCWEBLCH.
      /
       COPY CCWL3043.
      /
016537*COPY XCFWXTAB.
016537*COPY XCFRXTAB.
      /
       COPY CCFWPLGR.
       COPY CCFRPLGR.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
012136 COPY CCFWPD.
012136 COPY CCFRPD.
012136/
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
014035*COPY XCWWWKDT.
014035*COPY CCWWINDX.
014221 COPY CCWWLOCK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3040.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK       TO TRUE.
           MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.
      *
      *    PROCESS SCREEN FUNCTIONS


           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /

      *---------------------
       3000-PROCESS-RETRIEVE.
      *---------------------

      *
      *  INQUIRY PROCESSING.  VERIFY RECORD EXISTS AND DISPLAY
      *  RECORD.
      *

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-PLGR-KEY
               THRU 7100-BUILD-PLGR-KEY-X.

014221     MOVE MIR-PLAN-ID       TO WPH-PLAN-ID
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X
014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WPH-PLAN-ID    TO WGLOB-MSG-PARM (1)
014221        MOVE 'PH'           TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221                THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3000-PROCESS-RETRIEVE-X
014221     END-IF.

           PERFORM  PLGR-1000-READ
               THRU PLGR-1000-READ-X.

           IF  WPLGR-IO-NOT-FOUND
               MOVE WPLGR-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /

      *------------------
       3500-PROCESS-LIST.
      *------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE +1                    TO WS-SUB.

           MOVE LOW-VALUES            TO WPLGR-KEY.
           MOVE HIGH-VALUES           TO WPLGR-ENDBR-KEY.

           MOVE MIR-PLAN-ID           TO WPLGR-PLAN-ID.
           MOVE WPLGR-PLAN-ID         TO WPLGR-ENDBR-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPLGR-LOC-GR-ID.

           PERFORM  PLGR-1000-BROWSE
               THRU PLGR-1000-BROWSE-X.

           PERFORM  PLGR-2000-READ-NEXT
               THRU PLGR-2000-READ-NEXT-X.

           IF  NOT WPLGR-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PLGR-3000-END-BROWSE
                   THRU PLGR-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           MOVE +1                    TO WS-SUB.
           PERFORM  3600-PLGR-INQ-READ
               THRU 3600-PLGR-INQ-READ-X
               UNTIL (WS-SUB  > WS-MAX-LINES)
               OR   WPLGR-IO-EOF.


           IF  WPLGR-IO-EOF
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RPLGR-PLAN-ID     TO MIR-PLAN-ID
               MOVE RPLGR-LOC-GR-ID   TO MIR-LOC-GR-ID
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PLGR-3000-END-BROWSE
               THRU PLGR-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------
       3600-PLGR-INQ-READ.
      *-------------------

           MOVE RPLGR-LOC-GR-ID       TO MIR-LOC-GR-ID-T (WS-SUB).
014035*    MOVE RPLGR-FREE-WTHDR-CD          TO MIR-FWDC-T (WS-SUB).
014035*    MOVE RPLGR-FREE-WTHDR-QTY         TO WS-FREE-WTHDR-QTY-N.
014035*    MOVE WS-FREE-WTHDR-QTY-A          TO MIR-FWDN-T (WS-SUB).
014035*    MOVE RPLGR-FREE-WTHDR-PERI-CD     TO MIR-FWDP-T (WS-SUB).
014035*    MOVE RPLGR-SURR-CHRG-IND          TO MIR-SURC-T (WS-SUB).
014035*    MOVE RPLGR-NET-FREE-WTHDR-IND     TO MIR-NETF-T (WS-SUB).
014035*    MOVE RPLGR-INIT-GRACE-MO-DUR      TO MIR-ULIM-T (WS-SUB).
014035*    MOVE RPLGR-INIT-GRACE-DY-DUR      TO MIR-ULID-T (WS-SUB).
014035*    MOVE RPLGR-UL-NLAPS-GUAR-DUR      TO MIR-ULNG-T (WS-SUB).
014035*    MOVE RPLGR-UL-NLAPS-DED-QTY       TO MIR-ULPM-T (WS-SUB).

           ADD  +1                           TO WS-SUB.

           PERFORM  PLGR-2000-READ-NEXT
               THRU PLGR-2000-READ-NEXT-X.

       3600-PLGR-INQ-READ-X.
           EXIT.
      /

      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      *
      * CREATE NEW MESSAGE RECORD.  THE RECORD IS CREATED WITH THE
      * KEY FIELDS ENTERED.  THE REMAINING DATA WILL BE UPDATED VIA
      * THE MAINTAIN SCREEN.
      *

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-PLGR-KEY
               THRU 7100-BUILD-PLGR-KEY-X.

           PERFORM  PLGR-1000-READ
               THRU PLGR-1000-READ-X.

           IF  WPLGR-IO-OK
               MOVE WPLGR-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  4100-CREATE-EDITS
               THRU 4100-CREATE-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  7100-BUILD-PLGR-KEY
               THRU 7100-BUILD-PLGR-KEY-X.

           PERFORM  PLGR-1000-CREATE
               THRU PLGR-1000-CREATE-X.

018845     PERFORM  4500-CREATE-PLGR-DEFAULT
018845         THRU 4500-CREATE-PLGR-DEFAULT-X

           PERFORM  PLGR-1000-WRITE
               THRU PLGR-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PLGR-1000-CALL-AUDIT
                  THRU PLGR-1000-CALL-AUDIT-X
           END-IF.

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /

      *------------------
       4100-CREATE-EDITS.
      *------------------
      *
      * EDIT INPUT FIELDS.
      *

           PERFORM  4200-EDIT-PLAN-ID
               THRU 4200-EDIT-PLAN-ID-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4100-CREATE-EDITS-X
           END-IF.

           PERFORM  4400-EDIT-LCGP
               THRU 4400-EDIT-LCGP-X.

       4100-CREATE-EDITS-X.
           EXIT.
      /

      *------------------
       4200-EDIT-PLAN-ID.
      *------------------
      *
           IF  MIR-PLAN-ID =  SPACES
      *MSG: PLAN CODE MUST NOT BE BLANK
               MOVE 'CS30400001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4200-EDIT-PLAN-ID-X
           END-IF.

           IF  WPH-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE     TO  WPH-CO-ID
           ELSE
               MOVE SPACES            TO  WPH-CO-ID
           END-IF.

           MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  NOT WPH-IO-OK
           OR  RPH-PLAN-ID NOT = MIR-PLAN-ID
      *MSG: PLAN NOT FOUND - @1 @2
               MOVE 'CS30400002'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-ID       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4200-EDIT-PLAN-ID-X.
           EXIT.
      /
      *---------------
       4400-EDIT-LCGP.
      *---------------
      *

           MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.

           PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
               THRU LCGP-1000-EDIT-LCGP-LOCATION-X.

           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *MSG: LOCATION GROUP (@1) SHOULD BE ON EDIT LOCGP
               MOVE 'CS30400003'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-LOC-GR-ID     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4400-EDIT-LCGP-X.
           EXIT.
      /
018845*---------------------
018845 4500-CREATE-PLGR-DEFAULT.
018845*---------------------
018845*
018845     PERFORM  8005-GET-PLAN-DFLT
018845         THRU 8005-GET-PLAN-DFLT-X.
018845
018845* CHECK PLAN DEFAULT INSURANCE TYPE & MTHV PRCES SW
018845* DEFAULT SHORTAGE CALCUALTION CODE TO CSV
018845     IF WPD-IO-OK
018845        IF (RPD-PLAN-INS-TYP-FLEXIBLE
018845        OR  RPD-PLAN-INS-TYP-SEG-FUND)
018845        AND RPD-MTHV-PRCES
018845            SET RPLGR-SHRT-CALC-CSV TO TRUE
018845        END-IF
018845     END-IF.
026055
026055     SET RPLGR-DTHCLM-INT-DT-NONE   TO TRUE.
018845
018845 4500-CREATE-PLGR-DEFAULT-X.
018845     EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  7100-BUILD-PLGR-KEY
               THRU 7100-BUILD-PLGR-KEY-X.

           PERFORM  PLGR-1000-READ-FOR-UPDATE
               THRU PLGR-1000-READ-FOR-UPDATE-X.

           IF  WPLGR-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PLGR-1000-CALL-AUDIT
                      THRU PLGR-1000-CALL-AUDIT-X
               END-IF
           ELSE
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               MOVE WPLGR-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  8000-EDIT-FIELDS
               THRU 8000-EDIT-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  PLGR-2000-REWRITE
               THRU PLGR-2000-REWRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PLGR-1000-CALL-AUDIT
                  THRU PLGR-1000-CALL-AUDIT-X
           END-IF.

014221     PERFORM PH-2000-REWRITE
014221        THRU PH-2000-REWRITE-X
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
           ELSE

               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO

               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  7100-BUILD-PLGR-KEY
               THRU 7100-BUILD-PLGR-KEY-X.

           PERFORM  PLGR-1000-READ-FOR-UPDATE
               THRU PLGR-1000-READ-FOR-UPDATE-X.

           IF  WPLGR-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PLGR-1000-CALL-AUDIT
                      THRU PLGR-1000-CALL-AUDIT-X
               END-IF
               PERFORM  PLGR-1000-DELETE
                   THRU PLGR-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO MIR-FREE-WTHDR-CD
               MOVE SPACES            TO MIR-FREE-WTHDR-QTY
               MOVE SPACES            TO MIR-FREE-WTHDR-PERI-CD
               MOVE SPACES            TO MIR-SURR-CHRG-IND
               MOVE SPACES            TO MIR-NET-FREE-WTHDR-IND
               MOVE SPACES            TO MIR-INIT-GRACE-MO-DUR
               MOVE SPACES            TO MIR-INIT-GRACE-DY-DUR
               MOVE SPACES            TO MIR-UL-NLAPS-GUAR-DUR
               MOVE SPACES            TO MIR-UL-NLAPS-DED-QTY
012136         MOVE SPACES            TO MIR-FREE-LK-REQIR-CD
012136         MOVE SPACES            TO MIR-FREE-LK-FND-CD
012136         MOVE SPACES            TO MIR-FREE-LK-DT-CALC-CD
012136         MOVE SPACES            TO MIR-NTU-PRCES-CD
012145         MOVE SPACES            TO MIR-DSCNT-LOAN-CV-IND
012145         MOVE SPACES            TO MIR-MAX-LOAN-CV-PCT
018845         MOVE SPACES            TO MIR-SHRT-CALC-CD
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PLGR-1000-CALL-AUDIT
                      THRU PLGR-1000-CALL-AUDIT-X
               END-IF
014221         PERFORM  PH-2000-REWRITE
014221             THRU PH-2000-REWRITE-X
014221         PERFORM  PH-1000-READ-TWRK-TS
014221             THRU PH-1000-READ-TWRK-TS-X
           ELSE
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               MOVE WPLGR-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *--------------------
       7100-BUILD-PLGR-KEY.
      *--------------------

           MOVE MIR-PLAN-ID           TO WPLGR-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPLGR-LOC-GR-ID.

       7100-BUILD-PLGR-KEY-X.
           EXIT.
      /

      *-----------------
       8000-EDIT-FIELDS.
      *-----------------

           PERFORM  8005-GET-PLAN-DFLT
               THRU 8005-GET-PLAN-DFLT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-FIELDS-X
           END-IF.

           PERFORM  3043-0000-INIT-PARM-INFO
               THRU 3043-0000-INIT-PARM-INFO-X.

           PERFORM  8010-BUILD-EDIT-LINKAGE
               THRU 8010-BUILD-EDIT-LINKAGE-X.

           PERFORM  3043-1000-PLGR-EDITS
               THRU 3043-1000-PLGR-EDITS-X.

           EVALUATE TRUE

               WHEN L3043-RETRN-INVALID-REQUEST
                    MOVE +1           TO WGLOB-RETURN-CODE

               WHEN L3043-RETRN-ERRORS
                    MOVE +1           TO WGLOB-RETURN-CODE
                    PERFORM  8020-EDIT-RETURN-SCREEN
                        THRU 8020-EDIT-RETURN-SCREEN-X

               WHEN L3043-RETRN-OK
                    PERFORM  8020-EDIT-RETURN-SCREEN
                        THRU 8020-EDIT-RETURN-SCREEN-X

            END-EVALUATE.

       8000-EDIT-FIELDS-X.
           EXIT.
      /

      *-------------------
       8005-GET-PLAN-DFLT.
      *-------------------

           MOVE MIR-PLAN-ID           TO WPD-PLAN-ID.

           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.

           IF  NOT WPD-IO-OK
      *MSG: PLAN DEFAULT RECORD - @1 @2, NOT FOUND
               MOVE 'CS30400004'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-ID       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8005-GET-PLAN-DFLT-X.
           EXIT.
      /
      *------------------------
       8010-BUILD-EDIT-LINKAGE.
      *------------------------

           MOVE MIR-FREE-WTHDR-CD     TO L3043-FREE-WTHDR-CD.
           MOVE MIR-FREE-WTHDR-QTY    TO L3043-FREE-WTHDR-QTY.
           MOVE MIR-FREE-WTHDR-PERI-CD      TO L3043-FREE-WTHDR-PERI-CD.
           MOVE MIR-SURR-CHRG-IND     TO L3043-SURR-CHRG-RSTRCT-IND.
           MOVE MIR-NET-FREE-WTHDR-IND      TO L3043-NET-FREE-WTHDR-IND.
           MOVE MIR-INIT-GRACE-MO-DUR TO L3043-INIT-GRACE-MO-DUR.
           MOVE MIR-INIT-GRACE-DY-DUR TO L3043-INIT-GRACE-DY-DUR.
           MOVE MIR-UL-NLAPS-GUAR-DUR TO L3043-UL-NLAPS-GUAR-DUR.
           MOVE MIR-UL-NLAPS-DED-QTY  TO L3043-UL-NLAPS-DED-QTY.
012136     MOVE MIR-FREE-LK-REQIR-CD  TO L3043-FREE-LK-REQIR-CD.
012136     MOVE MIR-FREE-LK-FND-CD    TO L3043-FREE-LK-FND-CD.
012136     MOVE MIR-FREE-LK-DT-CALC-CD      TO L3043-FREE-LK-DT-CALC-CD.
012136     MOVE MIR-NTU-PRCES-CD      TO L3043-NTU-PRCES-CD.
012145     MOVE MIR-DSCNT-LOAN-CV-IND TO L3043-DSCNT-LOAN-CV-IND.
012145     MOVE MIR-MAX-LOAN-CV-PCT   TO L3043-MAX-LOAN-CV-PCT.
018845     MOVE MIR-SHRT-CALC-CD      TO L3043-SHRT-CALC-CD.
026055     MOVE MIR-DTHCLM-INT-DT-CD  TO L3043-DTHCLM-INT-DT-CD.

       8010-BUILD-EDIT-LINKAGE-X.
           EXIT.
      /

      *------------------------
       8020-EDIT-RETURN-SCREEN.
      *------------------------

            IF  L3043-FREE-WTHDR-CD      NOT =  HIGH-VALUES
                MOVE L3043-FREE-WTHDR-CD
                                      TO MIR-FREE-WTHDR-CD
            END-IF.

            IF  L3043-FREE-WTHDR-QTY     NOT  =  HIGH-VALUES
                MOVE L3043-FREE-WTHDR-QTY
                                      TO MIR-FREE-WTHDR-QTY
            END-IF.

            IF  L3043-FREE-WTHDR-PERI-CD  NOT =  HIGH-VALUES
                MOVE L3043-FREE-WTHDR-PERI-CD
                                      TO MIR-FREE-WTHDR-PERI-CD
            END-IF.

            IF  L3043-SURR-CHRG-RSTRCT-IND NOT =  HIGH-VALUES
                MOVE L3043-SURR-CHRG-RSTRCT-IND
                                      TO MIR-SURR-CHRG-IND
            END-IF.

            IF  L3043-NET-FREE-WTHDR-IND NOT  =  HIGH-VALUES
                MOVE L3043-NET-FREE-WTHDR-IND
                                      TO MIR-NET-FREE-WTHDR-IND
            END-IF.

            IF  L3043-INIT-GRACE-MO-DUR   NOT =  HIGH-VALUES
                MOVE L3043-INIT-GRACE-MO-DUR
                                      TO MIR-INIT-GRACE-MO-DUR
            END-IF.

            IF  L3043-INIT-GRACE-DY-DUR   NOT  =  HIGH-VALUES
                MOVE L3043-INIT-GRACE-DY-DUR
                                      TO MIR-INIT-GRACE-DY-DUR
            END-IF.

            IF  L3043-UL-NLAPS-GUAR-DUR   NOT  =  HIGH-VALUES
                MOVE L3043-UL-NLAPS-GUAR-DUR
                                      TO MIR-UL-NLAPS-GUAR-DUR
            END-IF.

            IF  L3043-UL-NLAPS-DED-QTY   NOT  =  HIGH-VALUES
                MOVE L3043-UL-NLAPS-DED-QTY
                                      TO MIR-UL-NLAPS-DED-QTY
            END-IF.

012136      IF  L3043-FREE-LK-REQIR-CD   NOT  =  HIGH-VALUES
012136          MOVE L3043-FREE-LK-REQIR-CD
                                      TO MIR-FREE-LK-REQIR-CD
012136      END-IF.

012136      IF  L3043-FREE-LK-FND-CD     NOT  =  HIGH-VALUES
012136          MOVE L3043-FREE-LK-FND-CD
                                      TO MIR-FREE-LK-FND-CD
012136      END-IF.

012136      IF  L3043-FREE-LK-DT-CALC-CD NOT  =  HIGH-VALUES
012136          MOVE L3043-FREE-LK-DT-CALC-CD
                                      TO MIR-FREE-LK-DT-CALC-CD
012136      END-IF.

012136      IF  L3043-NTU-PRCES-CD       NOT  =  HIGH-VALUES
012136          MOVE L3043-NTU-PRCES-CD
                                      TO MIR-NTU-PRCES-CD
012136      END-IF.

012145      IF  L3043-DSCNT-LOAN-CV-IND  NOT  =  HIGH-VALUES
012145          MOVE L3043-DSCNT-LOAN-CV-IND
                                      TO MIR-DSCNT-LOAN-CV-IND
012145      END-IF.

012145      IF  L3043-MAX-LOAN-CV-PCT    NOT =  HIGH-VALUES
012145          MOVE L3043-MAX-LOAN-CV-PCT
                                      TO MIR-MAX-LOAN-CV-PCT
012145      END-IF.

018845      IF  L3043-SHRT-CALC-CD       NOT =  HIGH-VALUES
018845          MOVE L3043-SHRT-CALC-CD TO MIR-SHRT-CALC-CD
018845      END-IF.

026055      IF  L3043-DTHCLM-INT-DT-CD   NOT =  HIGH-VALUES
026055          MOVE L3043-DTHCLM-INT-DT-CD
026055                                TO MIR-DTHCLM-INT-DT-CD
026055      END-IF.

       8020-EDIT-RETURN-SCREEN-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           IF  WS-BUS-FCN-LIST
               MOVE SPACES                 TO MIR-LOC-GR-ID-G
014035*        MOVE SPACES                 TO MIR-FWDC-G
014035*        MOVE SPACES                 TO MIR-FWDN-G
014035*        MOVE SPACES                 TO MIR-FWDP-G
014035*        MOVE SPACES                 TO MIR-SURC-G
014035*        MOVE SPACES                 TO MIR-NETF-G
014035*        MOVE SPACES                 TO MIR-ULIM-G
014035*        MOVE SPACES                 TO MIR-ULID-G
014035*        MOVE SPACES                 TO MIR-ULNG-G
014035*        MOVE SPACES                 TO MIR-ULPM-G

           ELSE
               MOVE SPACES            TO MIR-FREE-WTHDR-CD
               MOVE SPACES            TO MIR-FREE-WTHDR-QTY
               MOVE SPACES            TO MIR-FREE-WTHDR-PERI-CD
               MOVE SPACES            TO MIR-SURR-CHRG-IND
               MOVE SPACES            TO MIR-NET-FREE-WTHDR-IND
               MOVE SPACES            TO MIR-INIT-GRACE-MO-DUR
               MOVE SPACES            TO MIR-INIT-GRACE-DY-DUR
               MOVE SPACES            TO MIR-UL-NLAPS-GUAR-DUR
               MOVE SPACES            TO MIR-UL-NLAPS-DED-QTY
012136         MOVE SPACES            TO MIR-FREE-LK-REQIR-CD
012136         MOVE SPACES            TO MIR-FREE-LK-FND-CD
012136         MOVE SPACES            TO MIR-FREE-LK-DT-CALC-CD
012136         MOVE SPACES            TO MIR-NTU-PRCES-CD
012145         MOVE SPACES            TO MIR-DSCNT-LOAN-CV-IND
012145         MOVE SPACES            TO MIR-MAX-LOAN-CV-PCT
018845         MOVE SPACES            TO MIR-SHRT-CALC-CD
026055         MOVE SPACES            TO MIR-DTHCLM-INT-DT-CD

           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RPLGR-FREE-WTHDR-CD   TO MIR-FREE-WTHDR-CD.
           MOVE RPLGR-FREE-WTHDR-QTY  TO WS-FREE-WTHDR-QTY-N.
           MOVE WS-FREE-WTHDR-QTY-A   TO MIR-FREE-WTHDR-QTY.
           MOVE RPLGR-FREE-WTHDR-PERI-CD
                                      TO MIR-FREE-WTHDR-PERI-CD.
           MOVE RPLGR-SURR-CHRG-IND   TO MIR-SURR-CHRG-IND.
           MOVE RPLGR-NET-FREE-WTHDR-IND
                                      TO MIR-NET-FREE-WTHDR-IND.
           MOVE RPLGR-INIT-GRACE-MO-DUR
                                      TO MIR-INIT-GRACE-MO-DUR.
           MOVE RPLGR-INIT-GRACE-DY-DUR
                                      TO MIR-INIT-GRACE-DY-DUR.
           MOVE RPLGR-UL-NLAPS-GUAR-DUR
                                      TO MIR-UL-NLAPS-GUAR-DUR.
           MOVE RPLGR-UL-NLAPS-DED-QTY TO MIR-UL-NLAPS-DED-QTY.
012136     MOVE RPLGR-FREE-LK-REQIR-CD TO MIR-FREE-LK-REQIR-CD.
012136     MOVE RPLGR-FREE-LK-FND-CD  TO MIR-FREE-LK-FND-CD.
012136     MOVE RPLGR-FREE-LK-DT-CALC-CD
                                      TO MIR-FREE-LK-DT-CALC-CD.
012136     MOVE RPLGR-NTU-PRCES-CD    TO MIR-NTU-PRCES-CD.
012145     MOVE RPLGR-DSCNT-LOAN-CV-IND
                                      TO MIR-DSCNT-LOAN-CV-IND.
012145*    MOVE RPLGR-MAX-LOAN-CV-PCT TO MIR-MAX-LOAN-CV-PCT.

012145     PERFORM  0290-1000-BUILD-PARM-INFO
012145         THRU 0290-1000-BUILD-PARM-INFO-X.

020874*    COMPUTE L0290-INPUT-NUMBER = RPLGR-MAX-LOAN-CV-PCT * 10000
020874     MOVE RPLGR-MAX-LOAN-CV-PCT TO L0290-INPUT-V04.
012145     MOVE 4                     TO L0290-PRECISION.
012145     MOVE LENGTH OF MIR-MAX-LOAN-CV-PCT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
012145     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-LOAN-CV-PCT.

018845     MOVE RPLGR-SHRT-CALC-CD TO MIR-SHRT-CALC-CD.

026055     MOVE RPLGR-DTHCLM-INT-DT-CD  TO MIR-DTHCLM-INT-DT-CD.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  3043-0000-INIT-PARM-INFO
025970         THRU 3043-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
       COPY CCPS3043.
018764*COPY CCCL3043.
018764 COPY CCPL3043.
       COPY CCPELCGP.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      ****************************************************************
      * LINKING COPYBOOKS                                            *
      ****************************************************************
012145 COPY XCPL0290.
      /
012145 COPY XCPS0290.
      /
014035*COPY XCPL0280.
      /
018764*COPY CCCLPLGR.
018764 COPY CCPLPLGR.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS
      ****************************************************************
014660*COPY XCPPMEXT.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
016537*COPY XCPNXTAB.
      /
       COPY CCPAPLGR.
       COPY CCPBPLGR.
       COPY CCPCPLGR.
       COPY CCPNPLGR.
       COPY CCPUPLGR.
       COPY CCPXPLGR.
      /
       COPY CCPNPH.
014221/
014221 COPY CCPUPH.
      /
012136 COPY CCPNPD.
012136/
      *****************************************************************
      **                 END OF PROGRAM CSOM3040                     **
      *****************************************************************
