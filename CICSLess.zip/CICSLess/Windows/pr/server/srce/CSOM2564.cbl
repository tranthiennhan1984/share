      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM2564.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2564                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE IPRD TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2564'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-CONSTANTS.
               10  WS-MAX-LIST-LINES                 PIC S9(04) BINARY
                                                     VALUE 100.
025970             88  WS-MAX-LIST-LINES-DEFAULT     VALUE 100.

           05  WS-VARIABLES.
               10  WS-BUS-FCN-ID                     PIC X(04).
                   88  WS-BUS-FCN-LIST               VALUE '2564'.
               10  WS-SUB                            PIC S9(04) BINARY.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWIPRD.
       COPY CCFRIPRD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2564.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2564'
                                          TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                                          TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  IPRD-1000-BROWSE-PREV
               THRU IPRD-1000-BROWSE-PREV-X.

           IF WIPRD-IO-OK
               PERFORM  IPRD-2000-READ-PREV
                   THRU IPRD-2000-READ-PREV-X
           END-IF.

           IF NOT WIPRD-IO-OK 
           OR WIPRD-IO-EOF
               PERFORM  IPRD-3000-END-BROWSE-PREV
                   THRU IPRD-3000-END-BROWSE-PREV-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2010-BROWSE-IPRD
               THRU 2010-BROWSE-IPRD-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WIPRD-IO-EOF.

           IF  WIPRD-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE RIPRD-PRFL-ID         TO MIR-PRFL-ID
               MOVE RIPRD-PRFLD-EFF-DT
                                          TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE   TO MIR-PRFLD-EFF-DT

               MOVE RIPRD-PRFLD-SEQ-NUM   TO L0290-INPUT-V00
               MOVE ZERO                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                          TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA     TO MIR-PRFLD-SEQ-NUM

           END-IF.

           PERFORM  IPRD-3000-END-BROWSE-PREV
               THRU IPRD-3000-END-BROWSE-PREV-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-IPRD.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  IPRD-2000-READ-PREV
               THRU IPRD-2000-READ-PREV-X.

       2010-BROWSE-IPRD-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE HIGH-VALUES            TO WIPRD-KEY.
           MOVE LOW-VALUES             TO WIPRD-ENDBR-KEY.
           MOVE WWKDT-LOW-DT           TO WIPRD-ENDBR-PRFLD-EFF-DT.
           MOVE ZERO                   TO WIPRD-ENDBR-PRFLD-SEQ-NUM.

           IF  MIR-PRFL-ID = SPACE
           OR  MIR-PRFL-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE HIGH-VALUE         TO WIPRD-PRFL-ID
               MOVE WWKDT-HIGH-DT      TO WIPRD-PRFLD-EFF-DT
               MOVE 999                TO WIPRD-PRFLD-SEQ-NUM
               GO TO 7000-BUILD-KEYS-X
           ELSE
               MOVE MIR-PRFL-ID        TO WIPRD-PRFL-ID
           END-IF.

           IF  MIR-PRFLD-EFF-DT = SPACE
               MOVE WWKDT-HIGH-DT      TO WIPRD-PRFLD-EFF-DT
               MOVE 999                TO WIPRD-PRFLD-SEQ-NUM
               GO TO 7000-BUILD-KEYS-X
           ELSE
               MOVE MIR-PRFLD-EFF-DT   TO L1640-EXTERNAL-DATE
               PERFORM  1640-7000-MIR-TO-INT
                   THRU 1640-7000-MIR-TO-INT-X

               IF  L1640-VALID
                   MOVE L1640-INTERNAL-DATE
                                       TO WIPRD-PRFLD-EFF-DT

               ELSE
      *MSG: EFFECTIVE DATE IS INVALID
                   MOVE 'CS25640001'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           IF  MIR-PRFLD-SEQ-NUM = SPACE
               MOVE 999                TO WIPRD-PRFLD-SEQ-NUM
               GO TO 7000-BUILD-KEYS-X
           ELSE
               MOVE MIR-PRFLD-SEQ-NUM  TO L0280-INPUT-DATA
               MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-INPUT-SIZE
               MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-LENGTH
               MOVE ZERO               TO L0280-PRECISION
               SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
               SET L0280-SPACES-PERMITTED
                                       TO TRUE

               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X

               IF  L0280-OK
                   MOVE L0280-OUTPUT   TO WIPRD-PRFLD-SEQ-NUM
               ELSE
      *MSG: SEQUENCE NUMBER MUST BE VALID NUMERIC
                   MOVE 'CS25640002'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-PRFL-ID-G.
           MOVE SPACES                 TO MIR-PRFLD-EFF-DT-G.
           MOVE SPACES                 TO MIR-PRFLD-SEQ-NUM-G.
           MOVE SPACES                 TO MIR-PRFLD-STAT-CD-G.
           MOVE SPACES                 TO MIR-PRFLD-POL-CHNG-DT-G.
           MOVE SPACES                 TO MIR-PRFL-XPRY-DT-G.


       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RIPRD-PRFL-ID          TO MIR-PRFL-ID-T (WS-SUB).

           MOVE RIPRD-PRFLD-EFF-DT
                                       TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PRFLD-EFF-DT-T
                                          (WS-SUB).


           MOVE WIPRD-PRFLD-SEQ-NUM    TO L0290-INPUT-V00
           MOVE ZERO                   TO L0290-PRECISION
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM-T (1)
                                       TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA      TO MIR-PRFLD-SEQ-NUM-T
                                          (WS-SUB).

           MOVE RIPRD-PRFLD-STAT-CD    TO MIR-PRFLD-STAT-CD-T
                                          (WS-SUB).

           MOVE RIPRD-PRFLD-POL-CHNG-DT
                                       TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PRFLD-POL-CHNG-DT-T
                                          (WS-SUB).


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-VARIABLES.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  WS-MAX-LIST-LINES-DEFAULT TO TRUE.
025970     SET  MIR-RETRN-OK    TO  TRUE.
025970     MOVE MIR-BUS-FCN-ID  TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPVIPRD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2564                      *
      *****************************************************************
