      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0601.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0601                                         **
      **  REMARKS:  PROCESS DRIVER FOR SYSTEM PROFILE MAINTENANCE    **
      **            TRANSACTION:     PSYS                            **
      **            THIS PROGRAM ALLOWS THE USER TO INQUIRE, MODIFY, **
      **            ADD AND DELETE PSYS RECORDS.  THE PSYS RECORD    **
      **            CONTAINS OVERALL SYSTEM SETUP INFORMATION.       **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007678**  5.6       PARTITIONING OF CLIENT AND POLICY TABLES         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       MULTI-COMPANY                                    **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
014221**  6.2       LOGICAL LOCKING                                  **
016400**  6.2       PCR - ADD SYS-CTL-ID FOR DISPLAY                 **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019632**  6.3.1     PRODUCT XPRESS CONNECTOR 1.0                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023315**  6.5       EXPAND PORT NUMBER                               **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028458**  6.7       INGENIUM TO PATHFINDER INTEGRATION               **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0601'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
007766 COPY XCWWCVGM.
014221 COPY CCWWLOCK.

      /
       COPY XCWEBLCH.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       01  WS-WORK-AREAS.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK                    VALUE '0'.
           05  WS-SECURITY                  PIC X(01).
               88  WS-INVALID-SECURITY                 VALUE '1'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1310' '1311'
                                                  '1312' '1313'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1310'.
               88  WS-BUS-FCN-CREATE        VALUE '1311'.
               88  WS-BUS-FCN-UPDATE        VALUE '1312'.
               88  WS-BUS-FCN-DELETE        VALUE '1313'.
014221     05  WS-TWRK-KEY                  PIC X(04) VALUE '1310'.
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '1310'.
           05  WS-PIC-999                   PIC 999.
           05  WS-PIC-99                    PIC 99.
008455*    05  WS-PIC-DOLLAR                PIC 9(9).99.
           05  WS-PIC-POLICY                PIC 9(10).
           05  WS-TEST-RANGE                PIC S9(18) COMP-3.
               88  WS-MXCAA-VALID           VALUE +1 THRU +999.
               88  WS-MXSRCH-VALID          VALUE +1 THRU +99.
007766*        88  WS-MAXCO-VALID           VALUE +1 THRU +20.
013578*        88  WS-MAXCL-VALID           VALUE +1 THRU +10.
013578         88  WS-MAXCL-VALID           VALUE +1 THRU +28.
               88  WS-MAXCC-VALID           VALUE +1 THRU +5.
           05  WS-MIB-HARDWARE              PIC X(01).
               88  WS-MIBHW-VALID           VALUE 'M' 'N' 'P'.
               88  WS-MIBHW-MAINFRAME       VALUE 'M'.
               88  WS-MIBHW-NONE            VALUE 'N'.
               88  WS-MIBHW-PC              VALUE 'P'.
016440     05  WS-CCAS-CD                   PIC X(01).
016440         88  WS-CCAS-VALID            VALUE 'F' 'B'.
016440         88  WS-CCAS-BACKGROUND       VALUE 'B'.
016440         88  WS-CCAS-FOREGROUND       VALUE 'F'.
007678     05  WS-CLI-ID-ASIGN-IND          PIC X(01).
007678         88  WS-CLI-ID-ASIGN-VALID       VALUE 'Y' 'N'.
007678         88  WS-CLI-ID-ASIGN-NOT-USED    VALUE 'N'.
007678         88  WS-CLI-ID-ASIGN-USED        VALUE 'Y'.
      /
019632 COPY XCWWCWA.
019632 COPY XCWL0002.
      /
       COPY XCWL0280.
008455 COPY XCWL0290.
      /
021930*COPY XCWLDTLK.
021930*COPY XCWL1640.
014221 COPY XCWL8090.
019632 COPY XCWL8960.
      /
       COPY CCFWPSYS.
       COPY CCFRPSYS.
      /

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0601.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           SET MIR-RETRN-OK              TO  TRUE.

           PERFORM INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *      PROCESS USER REQUEST
      *****************************************************************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
      *    PROCESS SCREEN FUNCTIONS
      *

           MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.

           EVALUATE TRUE
               WHEN  WS-BUS-FCN-RETRIEVE
                   PERFORM 3000-PROCESS-RETRIEVE
                      THRU 3000-PROCESS-RETRIEVE-X

               WHEN  WS-BUS-FCN-CREATE
                   PERFORM 4000-PROCESS-CREATE
                      THRU 4000-PROCESS-CREATE-X

               WHEN  WS-BUS-FCN-UPDATE
                   PERFORM 5000-PROCESS-UPDATE
                      THRU 5000-PROCESS-UPDATE-X

               WHEN  WS-BUS-FCN-DELETE
                   PERFORM 6000-PROCESS-DELETE
                      THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    SET MIR-RETRN-INVALD-RQST         TO TRUE
                    MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0601'   TO WGLOB-MSG-PARM (2)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *---------------------
       3000-PROCESS-RETRIEVE.
      *---------------------
      *****************************************************************
      *  INQUIRY PROCESSING: RETRIEVE RECORD AND DISPLAY
      *****************************************************************

010418     SET WPSYS-SYS-CTL-INGENIUM TO TRUE.

014221*    PERFORM  PSYS-1000-READ
014221*        THRU PSYS-1000-READ-X.

014221     PERFORM  PSYS-1000-READ-TWRK-TS
014221         THRU PSYS-1000-READ-TWRK-TS-X.

           IF WPSYS-IO-NOT-FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WPSYS-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *-------------------
       4000-PROCESS-CREATE.
      *-------------------
      *****************************************************************
      *  CREATE PROCESSING: TWO PASSES REQUIRED
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      *      ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING
      *****************************************************************

010418     SET WPSYS-SYS-CTL-INGENIUM TO TRUE.

           PERFORM  PSYS-1000-READ
               THRU PSYS-1000-READ-X.

           IF WPSYS-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WPSYS-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PSYS-1000-CREATE
                   THRU PSYS-1000-CREATE-X
               PERFORM  PSYS-1000-WRITE
                   THRU PSYS-1000-WRITE-X
014221         PERFORM  PSYS-1000-READ-TWRK-TS
014221             THRU PSYS-1000-READ-TWRK-TS-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE 'XS00000016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *------------------
       5000-PROCESS-UPDATE.
      *------------------

010418     SET WPSYS-SYS-CTL-INGENIUM TO TRUE.

014221*    PERFORM  PSYS-1000-READ-FOR-UPDATE
014221*        THRU PSYS-1000-READ-FOR-UPDATE-X.

014221     PERFORM  PSYS-2000-UPDATE-TWRK-TS
014221         THRU PSYS-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'PSYS'                TO WGLOB-MSG-PARM (01)
014221         MOVE WPSYS-KEY             TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF WPSYS-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WPSYS-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.
           PERFORM  PSYS-2000-REWRITE
               THRU PSYS-2000-REWRITE-X.
014221     PERFORM  PSYS-1000-READ-TWRK-TS
014221         THRU PSYS-1000-READ-TWRK-TS-X.

      *
      *    THIS FIELD IS UPDATED IN THE REWRITE, SO DISPLAY THE
      *    NEW VALUE
      *
014221*    MOVE RPSYS-PREV-UPDT-DT    TO L1640-INTERNAL-DATE.
014221*    PERFORM  1640-2000-INTERNAL-TO-EXT
014221*        THRU 1640-2000-INTERNAL-TO-EXT-X.
014221*    MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-UPDT-DT.

           IF WS-DATA-EDITS-OK
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

019632*
019632*    RE-ESTABLISH THE GLOBAL AREA PERSISTANT DATA
019632*
019632     IF WS-DATA-EDITS-OK
025970*        PERFORM  0002-1000-BUILD-PARM-INFO
025970*            THRU 0002-1000-BUILD-PARM-INFO-X
025970         PERFORM  0002-0000-INIT-PARM-INFO
025970             THRU 0002-0000-INIT-PARM-INFO-X
019632         PERFORM  0002-2000-ESTB-GLOB-INFO
019632             THRU 0002-2000-ESTB-GLOB-INFO-X
019632     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *------------
       6000-PROCESS-DELETE.
      *------------

010418     SET WPSYS-SYS-CTL-INGENIUM TO TRUE.

           PERFORM  PSYS-1000-READ-FOR-UPDATE
               THRU PSYS-1000-READ-FOR-UPDATE-X.

           IF WPSYS-IO-NOT-FOUND
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WPSYS-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PSYS-1000-DELETE
                   THRU PSYS-1000-DELETE-X
557660     END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.

      /
      *----------------------
       7500-EDIT-DATA-FIELDS.
      *----------------------
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************

           MOVE '0'                   TO WS-DATA-EDITS.

007678*    PERFORM  7510-EDIT-NXTCN
007678*        THRU 7510-EDIT-NXTCN-X.

007678     PERFORM  7512-EDIT-CLIAS
007678         THRU 7512-EDIT-CLIAS-X.

           PERFORM  7520-EDIT-MXCAA
               THRU 7520-EDIT-MXCAA-X.

           PERFORM  7530-EDIT-MAXCL
               THRU 7530-EDIT-MAXCL-X.

           PERFORM  7540-EDIT-MAXCC
               THRU 7540-EDIT-MAXCC-X.

           PERFORM  7550-EDIT-MXSRCH
               THRU 7550-EDIT-MXSRCH-X.

           PERFORM  7570-EDIT-MIBHW
               THRU 7570-EDIT-MIBHW-X.

           PERFORM  7580-EDIT-MMDRT
               THRU 7580-EDIT-MMDRT-X.

007766*    PERFORM  7590-EDIT-MAXCO
007766*        THRU 7590-EDIT-MAXCO-X.
007766     MOVE WCVGM-MAX-WCVGS-NUM   TO WS-PIC-99.
007766     MOVE WS-PIC-99             TO MIR-DV-MAX-POL-CVG-QTY.

016440     PERFORM  7595-EDIT-CCAS-OPT
016440         THRU 7595-EDIT-CCAS-OPT-X.

019632     PERFORM  7610-EDIT-PX-CALC-IND
019632         THRU 7610-EDIT-PX-CALC-IND-X.
019632
019632     PERFORM  7620-EDIT-PX-SRVR-PORT-NUM
019632         THRU 7620-EDIT-PX-SRVR-PORT-NUM-X.
019632
019632     PERFORM  7630-EDIT-PX-CHAR-SET-CD
019632         THRU 7630-EDIT-PX-CHAR-SET-CD-X.
019632
019632     MOVE MIR-SYS-CTL-PX-SRVR-NM  TO RPSYS-SYS-CTL-PX-SRVR-NM.
019632
019632     PERFORM  7640-XEDIT-PX-DATA
019632         THRU 7640-XEDIT-PX-DATA-X.

028458     PERFORM  7650-EDIT-PFC-ENBL-IND
028458         THRU 7650-EDIT-PFC-ENBL-IND-X.
028458
028458     PERFORM  7660-EDIT-PFC-SRVR-PORT-NUM
028458         THRU 7660-EDIT-PFC-SRVR-PORT-NUM-X.
028458
028458     PERFORM  7670-EDIT-PFC-CHAR-SET-CD
028458         THRU 7670-EDIT-PFC-CHAR-SET-CD-X.
028458
028458     MOVE MIR-PFC-SRVR-NM  TO RPSYS-PFC-SRVR-NM.
028458
028458     PERFORM  7680-XEDIT-PFC-DATA
028458         THRU 7680-XEDIT-PFC-DATA-X.

       7500-EDIT-DATA-FIELDS-X.
           EXIT.

007678*----------------
007678*7510-EDIT-NXTCN.
007678*----------------
007678*****************************************************************
007678*  NEXT-CLIENT-NO: MUST BE NUMERIC
007678*****************************************************************
007678*
007678*    IF MIR-NXTCN = SPACES
007678*        MOVE RPSYS-NXT-AVAIL-CLI-ID   TO WS-PIC-POLICY
007678*        MOVE WS-PIC-POLICY            TO MIR-NXTCN
007678*        GO TO 7510-EDIT-NXTCN-X
557660*    END-IF.
007678*
007678*    IF MIR-NXTCN = EBLCH-BLANK-FIELD-CHAR
007678*        MOVE 0                        TO WS-PIC-POLICY
007678*        MOVE WS-PIC-POLICY            TO MIR-NXTCN
557660*    END-IF.
007678*
007678*    MOVE 'N'                          TO L0280-SIGN-IND.
007678*    MOVE 0                            TO L0280-PRECISION.
007678*    MOVE 10                           TO L0280-LENGTH.
007678*    MOVE 10                           TO L0280-INPUT-SIZE.
007678*    MOVE MIR-NXTCN                    TO L0280-INPUT-DATA.
007678*
007678*    PERFORM  7600-NUMERIC-EDIT
007678*        THRU 7600-NUMERIC-EDIT-X.
007678*
007678*    IF L0280-OK
007678*        MOVE L0280-OUTPUT             TO WS-PIC-POLICY
007678*        MOVE WS-PIC-POLICY            TO MIR-NXTCN
007678*        MOVE WS-PIC-POLICY            TO RPSYS-NXT-AVAIL-CLI-ID
007678*    ELSE
007678*        MOVE 'CS06010004'             TO WGLOB-MSG-REF-INFO
007678*        PERFORM 0260-1000-GENERATE-MESSAGE
007678*           THRU 0260-1000-GENERATE-MESSAGE-X
007678*        MOVE -1                       TO MIR-NXTCN-L
007678*        MOVE '1'                      TO WS-DATA-EDITS
007678*        MOVE TATRB-DATA-ERROR         TO MIR-NXTCN-A
557660*    END-IF.
007678*
007678*7510-EDIT-NXTCN-X.
007678*    EXIT.

007678*----------------
007678 7512-EDIT-CLIAS.
007678*----------------
007678*****************************************************************
007678*  CLIENT ASSIGNMENT CD
007678*****************************************************************
007678
007678     IF MIR-CLI-ID-ASIGN-IND = SPACES
007678         MOVE RPSYS-CLI-ID-ASIGN-IND
                                      TO MIR-CLI-ID-ASIGN-IND
007678         GO TO 7512-EDIT-CLIAS-X
007678     END-IF.
007678
007678     IF MIR-CLI-ID-ASIGN-IND = EBLCH-BLANK-FIELD-CHAR
007678         MOVE SPACES            TO MIR-CLI-ID-ASIGN-IND
007678     END-IF.
007678
007678     MOVE MIR-CLI-ID-ASIGN-IND  TO WS-CLI-ID-ASIGN-IND.
007678
007678     IF WS-CLI-ID-ASIGN-VALID
007678         MOVE MIR-CLI-ID-ASIGN-IND
                                      TO RPSYS-CLI-ID-ASIGN-IND
007678     ELSE
007678         MOVE 'CS06010004'      TO WGLOB-MSG-REF-INFO
007678         PERFORM 0260-1000-GENERATE-MESSAGE
007678            THRU 0260-1000-GENERATE-MESSAGE-X
007678         MOVE '1'               TO WS-DATA-EDITS
007678     END-IF.
007678
007678 7512-EDIT-CLIAS-X.
007678     EXIT.

      *----------------
       7520-EDIT-MXCAA.
      *----------------
      *****************************************************************
      *  MAX-CLI-ASSIGN: MUST BE NUMERIC IN RANGE 1 TO 999
      *****************************************************************

           IF MIR-MAX-CLI-ID-TRY-NUM = SPACES
020874*        MOVE RPSYS-MAX-CLI-ID-TRY-NUM
020874*                               TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-MAX-CLI-ID-TRY-NUM
020874         MOVE RPSYS-MAX-CLI-ID-TRY-NUM  TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-CLI-ID-TRY-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-CLI-ID-TRY-NUM
               GO TO 7520-EDIT-MXCAA-X
557660     END-IF.

           IF MIR-MAX-CLI-ID-TRY-NUM = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-MAX-CLI-ID-TRY-NUM
020874         MOVE 0                     TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-CLI-ID-TRY-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-CLI-ID-TRY-NUM
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-CLI-ID-TRY-NUM              TO L0280-INPUT-DATA.

           PERFORM  7600-NUMERIC-EDIT
               THRU 7600-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-999
020874*                                         WS-TEST-RANGE
020874*        MOVE WS-PIC-999        TO MIR-MAX-CLI-ID-TRY-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874                                          WS-TEST-RANGE
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-CLI-ID-TRY-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-CLI-ID-TRY-NUM
               IF WS-MXCAA-VALID
                   MOVE L0280-OUTPUT  TO RPSYS-MAX-CLI-ID-TRY-NUM
               ELSE
                   MOVE 'CS06010001'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WGLOB-MSG-SEVRTY-WARNING
                       MOVE L0280-OUTPUT
                                      TO RPSYS-MAX-CLI-ID-TRY-NUM
                   ELSE
                       MOVE '1'       TO WS-DATA-EDITS
                   END-IF
               END-IF
           ELSE
               MOVE 'CS06010005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.

       7520-EDIT-MXCAA-X.
           EXIT.

      *----------------
       7530-EDIT-MAXCL.
      *----------------
      *****************************************************************
      *  MAX CLIENTS / POLICY: MUST BE NUMERIC IN RANGE 1 TO 10
      *****************************************************************

           IF  MIR-MAX-CLI-ON-POL-QTY                     =  SPACES
               MOVE RPSYS-MAX-CLI-ON-POL-QTY
                                      TO WS-PIC-99
               MOVE WS-PIC-99         TO MIR-MAX-CLI-ON-POL-QTY
               GO TO 7530-EDIT-MAXCL-X
557660     END-IF.

           IF  MIR-MAX-CLI-ON-POL-QTY =  EBLCH-BLANK-FIELD-CHAR
               MOVE 0                 TO WS-PIC-99
               MOVE WS-PIC-99         TO MIR-MAX-CLI-ON-POL-QTY
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-CLI-ON-POL-QTY              TO L0280-INPUT-DATA.

           PERFORM  7600-NUMERIC-EDIT
               THRU 7600-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WS-PIC-99
               MOVE L0280-OUTPUT      TO WS-TEST-RANGE
               MOVE WS-PIC-99         TO MIR-MAX-CLI-ON-POL-QTY
               IF  WS-MAXCL-VALID
                   MOVE L0280-OUTPUT  TO RPSYS-MAX-CLI-ON-POL-QTY
               ELSE
                   MOVE 'CS06010011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF  WGLOB-MSG-SEVRTY-WARNING
                       MOVE L0280-OUTPUT
                                      TO RPSYS-MAX-CLI-ON-POL-QTY
                   ELSE
                       MOVE '1'       TO WS-DATA-EDITS
                   END-IF
               END-IF
           ELSE
               MOVE 'CS06010012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.

       7530-EDIT-MAXCL-X.
           EXIT.

      *----------------
       7540-EDIT-MAXCC.
      *----------------
      *****************************************************************
      *  MAX CLIENTS / COVERAGE: MUST BE NUMERIC IN RANGE 1 TO 5
      *****************************************************************

           IF  MIR-MAX-CLI-ON-CVG-QTY                     =  SPACES
               MOVE RPSYS-MAX-CLI-ON-CVG-QTY
                                      TO WS-PIC-99
               MOVE WS-PIC-99         TO MIR-MAX-CLI-ON-CVG-QTY
               GO TO 7540-EDIT-MAXCC-X
557660     END-IF.

           IF  MIR-MAX-CLI-ON-CVG-QTY  =  EBLCH-BLANK-FIELD-CHAR
               MOVE 0                 TO WS-PIC-99
               MOVE WS-PIC-99         TO MIR-MAX-CLI-ON-CVG-QTY
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-CLI-ON-CVG-QTY              TO L0280-INPUT-DATA.

           PERFORM  7600-NUMERIC-EDIT
               THRU 7600-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WS-PIC-99
               MOVE L0280-OUTPUT      TO WS-TEST-RANGE
               MOVE WS-PIC-99         TO MIR-MAX-CLI-ON-CVG-QTY
               IF  WS-MAXCC-VALID
                   MOVE L0280-OUTPUT  TO RPSYS-MAX-CLI-ON-CVG-QTY
               ELSE
                   MOVE 'CS06010013'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF  WGLOB-MSG-SEVRTY-WARNING
                       MOVE L0280-OUTPUT
                                      TO RPSYS-MAX-CLI-ON-CVG-QTY
                   ELSE
                       MOVE '1'       TO WS-DATA-EDITS
                   END-IF
               END-IF
           ELSE
               MOVE 'CS06010014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.

       7540-EDIT-MAXCC-X.
           EXIT.

      *-----------------
       7550-EDIT-MXSRCH.
      *-----------------
      *****************************************************************
      *  MAX-SEARCH-LIST: MUST BE NUMERIC IN RANGE 1 TO 99
      *****************************************************************

           IF MIR-MAX-CLI-SRCH-QTY = SPACES
               MOVE RPSYS-MAX-CLI-SRCH-QTY
                                      TO WS-PIC-99
               MOVE WS-PIC-99         TO MIR-MAX-CLI-SRCH-QTY
               GO TO 7550-EDIT-MXSRCH-X
557660     END-IF.

           IF MIR-MAX-CLI-SRCH-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE 0                 TO WS-PIC-99
               MOVE WS-PIC-99         TO MIR-MAX-CLI-SRCH-QTY
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-CLI-SRCH-QTY  TO L0280-INPUT-DATA.
           PERFORM  7600-NUMERIC-EDIT
               THRU 7600-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-PIC-99
                                                WS-TEST-RANGE
               MOVE WS-PIC-99         TO MIR-MAX-CLI-SRCH-QTY
               IF WS-MXSRCH-VALID
                   MOVE L0280-OUTPUT  TO RPSYS-MAX-CLI-SRCH-QTY
               ELSE
                   MOVE 'CS06010009'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WGLOB-MSG-SEVRTY-WARNING
                       MOVE L0280-OUTPUT
                                      TO RPSYS-MAX-CLI-SRCH-QTY
                   ELSE
                       MOVE '1'       TO WS-DATA-EDITS
                   END-IF
               END-IF
           ELSE
               MOVE 'CS06010010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.

       7550-EDIT-MXSRCH-X.
           EXIT.

      *----------------
       7570-EDIT-MIBHW.
      *----------------
      *****************************************************************
      *  MIB-HARDWARE-USED: M - MAINFRAME, N - NONE, P - PERSONAL COMP.
      *****************************************************************

           IF MIR-MIB-COMUN-TYP-CD = SPACES
               MOVE RPSYS-MIB-COMUN-TYP-CD
                                      TO MIR-MIB-COMUN-TYP-CD
               GO TO 7570-EDIT-MIBHW-X
557660     END-IF.

           IF MIR-MIB-COMUN-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-MIB-COMUN-TYP-CD
557660     END-IF.

           MOVE MIR-MIB-COMUN-TYP-CD  TO WS-MIB-HARDWARE.

           IF WS-MIBHW-VALID
               MOVE MIR-MIB-COMUN-TYP-CD
                                      TO RPSYS-MIB-COMUN-TYP-CD
               GO TO 7570-EDIT-MIBHW-X
557660     END-IF.

           MOVE 'CS06010003'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           IF NOT WGLOB-MSG-SEVRTY-WARNING
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.

       7570-EDIT-MIBHW-X.
           EXIT.

      *----------------
       7580-EDIT-MMDRT.
      *----------------
      *****************************************************************
      *  MAX-PERSNL-MDRT: MUST BE NUMERIC GREATER THAN 0
      *****************************************************************

           IF MIR-MAX-PERS-MDRT-AMT = SPACES
008455*        MOVE RPSYS-MAX-PERS-MDRT-AMT  TO WS-PIC-DOLLAR
008455*        MOVE WS-PIC-DOLLAR            TO MIR-MAX-PERS-MDRT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPSYS-MAX-PERS-MDRT-AMT
020874*                                     * 100
020874         MOVE RPSYS-MAX-PERS-MDRT-AMT TO L0290-INPUT-V02
008455         PERFORM  9700-FORMAT-MMDRT
008455             THRU 9700-FORMAT-MMDRT-X
               GO TO 7580-EDIT-MMDRT-X
557660     END-IF.

           IF MIR-MAX-PERS-MDRT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE 0                        TO WS-PIC-DOLLAR
008455*        MOVE WS-PIC-DOLLAR            TO MIR-MAX-PERS-MDRT-AMT
008455         MOVE ZEROS             TO MIR-MAX-PERS-MDRT-AMT
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                            TO L0280-LENGTH.
008455*    MOVE 12                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-MAX-PERS-MDRT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
           MOVE MIR-MAX-PERS-MDRT-AMT TO L0280-INPUT-DATA.

           PERFORM  7600-NUMERIC-EDIT
               THRU 7600-NUMERIC-EDIT-X.

           IF L0280-OK
008455*        MOVE L0280-OUTPUT-DOLLAR      TO WS-PIC-DOLLAR
008455*        MOVE WS-PIC-DOLLAR            TO MIR-MAX-PERS-MDRT-AMT
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         PERFORM  9700-FORMAT-MMDRT
008455             THRU 9700-FORMAT-MMDRT-X
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPSYS-MAX-PERS-MDRT-AMT
           ELSE
               MOVE 'CS06010008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
557660     END-IF.

       7580-EDIT-MMDRT-X.
           EXIT.

007766*----------------
007766*7590-EDIT-MAXCO.
007766*----------------
007766*****************************************************************
007766*  MAX COVERAGES: MUST BE NUMERIC IN RANGE 1 TO 20
007766*****************************************************************
007766*
007766*    IF  MIR-DV-MAX-POL-CVG-QTY                     =  SPACES
007766*        MOVE RPSYS-MAX-CVG-ON-POL-QTY TO WS-PIC-99
007766*        MOVE WS-PIC-99                TO MIR-DV-MAX-POL-CVG-QTY
007766*        GO TO 7590-EDIT-MAXCO-X
007766*    END-IF.
007766*
007766*    IF  MIR-DV-MAX-POL-CVG-QTY  =  EBLCH-BLANK-FIELD-CHAR
007766*        MOVE 0                        TO WS-PIC-99
007766*        MOVE WS-PIC-99                TO MIR-DV-MAX-POL-CVG-QTY
007766*    END-IF.
007766*
007766*    MOVE 'N'                          TO L0280-SIGN-IND.
007766*    MOVE 0                            TO L0280-PRECISION.
007766*    MOVE 2                            TO L0280-LENGTH.
007766*    MOVE 2                            TO L0280-INPUT-SIZE.
007766*    MOVE MIR-DV-MAX-POL-CVG-QTY        TO L0280-INPUT-DATA.
007766*
007766*    PERFORM  7600-NUMERIC-EDIT
007766*        THRU 7600-NUMERIC-EDIT-X.
007766*
007766*    IF  L0280-OK
007766*        MOVE L0280-OUTPUT             TO WS-PIC-99
007766*        MOVE L0280-OUTPUT             TO WS-TEST-RANGE
007766*        MOVE WS-PIC-99                TO MIR-DV-MAX-POL-CVG-QTY
007766*        IF  WS-MAXCO-VALID
007766*            MOVE L0280-OUTPUT         TO RPSYS-MAX-CVG-ON-POL-QTY
007766*        ELSE
007766*            MOVE 'CS06010015'         TO WGLOB-MSG-REF-INFO
007766*            PERFORM  0260-1000-GENERATE-MESSAGE
007766*                THRU 0260-1000-GENERATE-MESSAGE-X
007766*            IF  WGLOB-MSG-SEVRTY-WARNING
007766*                MOVE L0280-OUTPUT     TO RPSYS-MAX-CVG-ON-POL-QTY
007766*            ELSE
007766*                MOVE -1               TO MIR-DV-MAX-POL-CVG-QTY-L
007766*                MOVE '1'              TO WS-DATA-EDITS
007766*                MOVE TATRB-DATA-ERROR TO MIR-DV-MAX-POL-CVG-QTY-A
007766*            END-IF
007766*        END-IF
007766*    ELSE
007766*        MOVE 'CS06010016'             TO WGLOB-MSG-REF-INFO
007766*        PERFORM  0260-1000-GENERATE-MESSAGE
007766*            THRU 0260-1000-GENERATE-MESSAGE-X
007766*        MOVE -1                       TO MIR-DV-MAX-POL-CVG-QTY-L
007766*        MOVE '1'                      TO WS-DATA-EDITS
007766*        MOVE TATRB-DATA-ERROR         TO MIR-DV-MAX-POL-CVG-QTY-A
007766*    END-IF.
007766*
007766*7590-EDIT-MAXCO-X.
007766*    EXIT.
      /
016440*------------------
016440 7595-EDIT-CCAS-OPT.
016440*------------------
016440*****************************************************************
016440*  CCAS-OPT-CD : B - BACKGROUND, F -FOREGROUND.
016440*****************************************************************
016440
016440     IF MIR-CCAS-PRCES-OPT-CD = SPACES
016440         MOVE RPSYS-CCAS-PRCES-OPT-CD
016440                                TO MIR-CCAS-PRCES-OPT-CD
016440         GO TO 7595-EDIT-CCAS-OPT-X
016440     END-IF.
016440
016440     IF MIR-CCAS-PRCES-OPT-CD = EBLCH-BLANK-FIELD-CHAR
016440         MOVE SPACE             TO MIR-CCAS-PRCES-OPT-CD
016440     END-IF.
016440
016440     MOVE MIR-CCAS-PRCES-OPT-CD TO WS-CCAS-CD.
016440
016440     IF WS-CCAS-VALID
016440         MOVE MIR-CCAS-PRCES-OPT-CD
016440                                TO RPSYS-CCAS-PRCES-OPT-CD
016440         GO TO 7595-EDIT-CCAS-OPT-X
016440     END-IF.
016440
016440     MOVE 'CS06010017'          TO WGLOB-MSG-REF-INFO.
016440     PERFORM 0260-1000-GENERATE-MESSAGE
016440         THRU 0260-1000-GENERATE-MESSAGE-X.
016440
016440     IF NOT WGLOB-MSG-SEVRTY-WARNING
016440         MOVE '1'               TO WS-DATA-EDITS
016440     END-IF.
016440
016440 7595-EDIT-CCAS-OPT-X.
016440     EXIT.
      /

      *------------------
       7600-NUMERIC-EDIT.
      *------------------

           PERFORM 0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               GO TO 7600-NUMERIC-EDIT-X
557660     END-IF.

           MOVE '1'                   TO WS-DATA-EDITS.

           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7600-NUMERIC-EDIT-X
557660     END-IF.

       7600-NUMERIC-EDIT-X.
           EXIT.
      /
019632*----------------------
019632 7610-EDIT-PX-CALC-IND.
019632*----------------------
019632
019632     PERFORM  8960-1000-BUILD-PARM-INFO
019632         THRU 8960-1000-BUILD-PARM-INFO-X.
019632
019632     MOVE 'PX-CALC-IND'           TO L8960-AV-TBL-CD.
019632     MOVE MIR-PX-CALC-IND         TO L8960-AV-CD.
019632
019632     PERFORM  8960-1000-VALIDATE-CODE
019632         THRU 8960-1000-VALIDATE-CODE-X.
019632
019632     IF  NOT L8960-RETRN-OK
019632*MSG:    'INVALID PX CALCULATOR INDICATOR'
019632         MOVE 'CS06010018'      TO WGLOB-MSG-REF-INFO
019632         PERFORM 0260-1000-GENERATE-MESSAGE
019632            THRU 0260-1000-GENERATE-MESSAGE-X
019632         IF  NOT WGLOB-MSG-SEVRTY-WARNING
019632             MOVE '1'                 TO WS-DATA-EDITS
019632         END-IF
019632         GO TO 7610-EDIT-PX-CALC-IND-X
019632     END-IF.
019632
019632     MOVE MIR-PX-CALC-IND             TO RPSYS-PX-CALC-IND.
019632
019632 7610-EDIT-PX-CALC-IND-X.
019632     EXIT.
019632
019632*--------------------------
019632 7620-EDIT-PX-SRVR-PORT-NUM.
019632*--------------------------
019632
019632     SET  L0280-SIGN-NOT-PERMITTED       TO TRUE.
019632     MOVE 0                              TO L0280-PRECISION.
019632     MOVE LENGTH OF MIR-PX-SRVR-PORT-NUM TO L0280-INPUT-SIZE.
019632     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
019632                          - L0280-PRECISION.
019632     MOVE MIR-PX-SRVR-PORT-NUM           TO L0280-INPUT-DATA.
019632
019632     PERFORM  0280-1000-NUMERIC-EDIT
019632         THRU 0280-1000-NUMERIC-EDIT-X.
019632
019632     IF L0280-OK
023315*        MOVE L0280-OUTPUT        TO RPSYS-PX-SRVR-PORT-NUM
023315         CONTINUE
019632     ELSE
019632*MSG:    'PX SERVER PORT NUMBER NOT NUMERIC'
019632         MOVE 'CS06010019'      TO WGLOB-MSG-REF-INFO
019632         PERFORM 0260-1000-GENERATE-MESSAGE
019632            THRU 0260-1000-GENERATE-MESSAGE-X
019632         IF  NOT WGLOB-MSG-SEVRTY-WARNING
019632             MOVE '1'                 TO WS-DATA-EDITS
019632         END-IF
023315         GO TO 7620-EDIT-PX-SRVR-PORT-NUM-X
019632     END-IF.
019632
023315     IF  L0280-OUTPUT > 65000
023315*MSG:   'MAXIMUM NUMBER OF PORT SUPPORT IN SERVER IS 65000'
023315         MOVE 'CS06010023'           TO WGLOB-MSG-REF-INFO
023315         PERFORM  0260-1000-GENERATE-MESSAGE
023315             THRU 0260-1000-GENERATE-MESSAGE-X
023315         IF  NOT WGLOB-MSG-SEVRTY-WARNING
023315             MOVE '1'                TO WS-DATA-EDITS
023315         END-IF
023315     ELSE
019632         MOVE L0280-OUTPUT           TO RPSYS-PX-SRVR-PORT-NUM
023315     END-IF.
023315
019632 7620-EDIT-PX-SRVR-PORT-NUM-X.
019632     EXIT.
019632
019632*-------------------------
019632 7630-EDIT-PX-CHAR-SET-CD.
019632*-------------------------
019632
019632     PERFORM  8960-1000-BUILD-PARM-INFO
019632         THRU 8960-1000-BUILD-PARM-INFO-X.
019632
019632     MOVE 'PX-CHAR-SET-CD'        TO L8960-AV-TBL-CD.
019632     MOVE MIR-PX-CHAR-SET-CD      TO L8960-AV-CD.
019632
019632     PERFORM  8960-1000-VALIDATE-CODE
019632         THRU 8960-1000-VALIDATE-CODE-X.
019632
019632     IF  NOT L8960-RETRN-OK
019632*MSG:    'INVALID CHARACTER SET FOR PX CALCULATOR'
019632         MOVE 'CS06010020'      TO WGLOB-MSG-REF-INFO
019632         PERFORM 0260-1000-GENERATE-MESSAGE
019632            THRU 0260-1000-GENERATE-MESSAGE-X
019632         IF  NOT WGLOB-MSG-SEVRTY-WARNING
019632             MOVE '1'                 TO WS-DATA-EDITS
019632         END-IF
019632         GO TO 7630-EDIT-PX-CHAR-SET-CD-X
019632     END-IF.
019632
019632     MOVE MIR-PX-CHAR-SET-CD          TO RPSYS-PX-CHAR-SET-CD.
019632
019632 7630-EDIT-PX-CHAR-SET-CD-X.
019632     EXIT.
019632
019632*------------------
019632 7640-XEDIT-PX-DATA.
019632*------------------
019632
019632     IF  RPSYS-PX-CALC
019632     AND RPSYS-SYS-CTL-PX-SRVR-NM = SPACE
019632*MSG:    'PX SERVER NAME CANNOT BE BLANK'
019632         MOVE 'CS06010021'      TO WGLOB-MSG-REF-INFO
019632         PERFORM 0260-1000-GENERATE-MESSAGE
019632            THRU 0260-1000-GENERATE-MESSAGE-X
019632         IF  NOT WGLOB-MSG-SEVRTY-WARNING
019632             MOVE '1'                 TO WS-DATA-EDITS
019632         END-IF
019632     END-IF.
019632
019632
019632     IF  RPSYS-PX-CALC
019632     AND RPSYS-PX-SRVR-PORT-NUM = ZERO
019632*MSG:    'PX SERVER PORT CANNOT BE ZERO'
019632         MOVE 'CS06010022'      TO WGLOB-MSG-REF-INFO
019632         PERFORM 0260-1000-GENERATE-MESSAGE
019632            THRU 0260-1000-GENERATE-MESSAGE-X
019632         IF  NOT WGLOB-MSG-SEVRTY-WARNING
019632             MOVE '1'                 TO WS-DATA-EDITS
019632         END-IF
019632     END-IF.
019632
019632 7640-XEDIT-PX-DATA-X.
019632     EXIT.

028458*----------------------
028458 7650-EDIT-PFC-ENBL-IND.
028458*----------------------
028458
028458     PERFORM  8960-1000-BUILD-PARM-INFO
028458         THRU 8960-1000-BUILD-PARM-INFO-X.
028458
028458     MOVE 'PFC-ENBL-IND'          TO L8960-AV-TBL-CD.
028458     MOVE MIR-PFC-ENBL-IND        TO L8960-AV-CD.
028458
028458     PERFORM  8960-1000-VALIDATE-CODE
028458         THRU 8960-1000-VALIDATE-CODE-X.
028458
028458     IF  NOT L8960-RETRN-OK
028458*MSG:    'PATHFINDER CLIENT ENBALE INDICATOR IS INVALID'
028458         MOVE 'CS06010024'      TO WGLOB-MSG-REF-INFO
028458         PERFORM 0260-1000-GENERATE-MESSAGE
028458            THRU 0260-1000-GENERATE-MESSAGE-X
028458         IF  NOT WGLOB-MSG-SEVRTY-WARNING
028458             MOVE '1'                 TO WS-DATA-EDITS
028458         END-IF
028458         GO TO 7650-EDIT-PFC-ENBL-IND-X
028458     END-IF.
028458
028458     MOVE MIR-PFC-ENBL-IND            TO RPSYS-PFC-ENBL-IND.
028458
028458 7650-EDIT-PFC-ENBL-IND-X.
028458     EXIT.
028458
028458*--------------------------
028458 7660-EDIT-PFC-SRVR-PORT-NUM.
028458*--------------------------
028458
028458     SET  L0280-SIGN-NOT-PERMITTED       TO TRUE.
028458     MOVE 0                              TO L0280-PRECISION.
028458     MOVE LENGTH OF MIR-PFC-SRVR-PORT-NUM TO L0280-INPUT-SIZE.
028458     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
028458                          - L0280-PRECISION.
028458     MOVE MIR-PFC-SRVR-PORT-NUM          TO L0280-INPUT-DATA.
028458
028458     PERFORM  0280-1000-NUMERIC-EDIT
028458         THRU 0280-1000-NUMERIC-EDIT-X.
028458
028458     IF L0280-OK
028458         CONTINUE
028458     ELSE
028458*MSG:    'PATHFINDER CLIENT SERVER PORT NUMBER IS NOT NUMERIC'
028458         MOVE 'CS06010025'      TO WGLOB-MSG-REF-INFO
028458         PERFORM 0260-1000-GENERATE-MESSAGE
028458            THRU 0260-1000-GENERATE-MESSAGE-X
028458         IF  NOT WGLOB-MSG-SEVRTY-WARNING
028458             MOVE '1'                 TO WS-DATA-EDITS
028458         END-IF
028458         GO TO 7660-EDIT-PFC-SRVR-PORT-NUM-X
028458     END-IF.
028458
028458     IF  L0280-OUTPUT > 65000
028458*MSG:   'MAXIMUM NUMBER OF PORT SUPPORT IN SERVER IS 65000'
028458         MOVE 'CS06010023'           TO WGLOB-MSG-REF-INFO
028458         PERFORM  0260-1000-GENERATE-MESSAGE
028458             THRU 0260-1000-GENERATE-MESSAGE-X
028458         IF  NOT WGLOB-MSG-SEVRTY-WARNING
028458             MOVE '1'                TO WS-DATA-EDITS
028458         END-IF
028458     ELSE
028458         MOVE L0280-OUTPUT           TO RPSYS-PFC-SRVR-PORT-NUM
028458     END-IF.
028458
028458 7660-EDIT-PFC-SRVR-PORT-NUM-X.
028458     EXIT.
028458
028458*-------------------------
028458 7670-EDIT-PFC-CHAR-SET-CD.
028458*-------------------------
028458
028458     PERFORM  8960-1000-BUILD-PARM-INFO
028458         THRU 8960-1000-BUILD-PARM-INFO-X.
028458
028458     MOVE 'PFC-CHAR-SET-CD'        TO L8960-AV-TBL-CD.
028458     MOVE MIR-PFC-CHAR-SET-CD      TO L8960-AV-CD.
028458
028458     PERFORM  8960-1000-VALIDATE-CODE
028458         THRU 8960-1000-VALIDATE-CODE-X.
028458
028458     IF  NOT L8960-RETRN-OK
028458*MSG:    'PATHFINDER CLIENT CHARACTER SET IS INVALID'
028458         MOVE 'CS06010026'      TO WGLOB-MSG-REF-INFO
028458         PERFORM 0260-1000-GENERATE-MESSAGE
028458            THRU 0260-1000-GENERATE-MESSAGE-X
028458         IF  NOT WGLOB-MSG-SEVRTY-WARNING
028458             MOVE '1'                 TO WS-DATA-EDITS
028458         END-IF
028458         GO TO 7670-EDIT-PFC-CHAR-SET-CD-X
028458     END-IF.
028458
028458     MOVE MIR-PFC-CHAR-SET-CD         TO RPSYS-PFC-CHAR-SET-CD.
028458
028458 7670-EDIT-PFC-CHAR-SET-CD-X.
028458     EXIT.
028458
028458*------------------
028458 7680-XEDIT-PFC-DATA.
028458*------------------
028458
028458     IF  RPSYS-PFC-ENBL
028458     AND RPSYS-PFC-SRVR-NM = SPACE
028458*MSG:    'PATHFINDER CLIENT SERVER NAME CANNOT BE BLANK'
028458         MOVE 'CS06010027'      TO WGLOB-MSG-REF-INFO
028458         PERFORM 0260-1000-GENERATE-MESSAGE
028458            THRU 0260-1000-GENERATE-MESSAGE-X
028458         IF  NOT WGLOB-MSG-SEVRTY-WARNING
028458             MOVE '1'                 TO WS-DATA-EDITS
028458         END-IF
028458     END-IF.
028458
028458
028458     IF  RPSYS-PFC-ENBL
028458     AND RPSYS-PFC-SRVR-PORT-NUM = ZERO
028458*MSG:    'PATHFINDER CLIENT SERVER PORT CANNOT BE ZERO'
028458         MOVE 'CS06010028'      TO WGLOB-MSG-REF-INFO
028458         PERFORM 0260-1000-GENERATE-MESSAGE
028458            THRU 0260-1000-GENERATE-MESSAGE-X
028458         IF  NOT WGLOB-MSG-SEVRTY-WARNING
028458             MOVE '1'                 TO WS-DATA-EDITS
028458         END-IF
028458     END-IF.
028458
028458 7680-XEDIT-PFC-DATA-X.
028458     EXIT.

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************

014221*    MOVE SPACES                TO MIR-PREV-UPDT-DT.
007678*    MOVE SPACES TO MIR-NXTCN.
007678     MOVE SPACES                TO MIR-CLI-ID-ASIGN-IND.
           MOVE SPACES                TO MIR-MAX-CLI-ID-TRY-NUM.
           MOVE SPACES                TO MIR-MAX-CLI-ON-POL-QTY.
           MOVE SPACES                TO MIR-MAX-CLI-ON-CVG-QTY.
           MOVE SPACES                TO MIR-MIB-COMUN-TYP-CD.
           MOVE SPACES                TO MIR-MAX-PERS-MDRT-AMT.
           MOVE SPACES                TO MIR-DV-MAX-POL-CVG-QTY.
           MOVE SPACES                TO MIR-MAX-CLI-SRCH-QTY.
016440     MOVE SPACES                TO MIR-CCAS-PRCES-OPT-CD.
019632     MOVE SPACES                TO MIR-PX-CALC-IND.
019632     MOVE SPACES                TO MIR-SYS-CTL-PX-SRVR-NM.
019632     MOVE SPACES                TO MIR-PX-SRVR-PORT-NUM.
019632     MOVE SPACES                TO MIR-PX-CHAR-SET-CD.
028458     MOVE SPACES                TO MIR-PFC-ENBL-IND.
028458     MOVE SPACES                TO MIR-PFC-SRVR-NM.
028458     MOVE SPACES                TO MIR-PFC-SRVR-PORT-NUM.
028458     MOVE SPACES                TO MIR-PFC-CHAR-SET-CD.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *  CALL DATE ROUTINE M0993BAT TO PERFORM DATE CONVERSION
      *****************************************************************

007678*    MOVE RPSYS-NXT-AVAIL-CLI-ID     TO MIR-NXTCN.
007678     MOVE RPSYS-CLI-ID-ASIGN-IND          TO MIR-CLI-ID-ASIGN-IND.
020874*    MOVE RPSYS-MAX-CLI-ID-TRY-NUM
020874*                               TO WS-PIC-999.
020874*    MOVE WS-PIC-999            TO MIR-MAX-CLI-ID-TRY-NUM.
020874     MOVE RPSYS-MAX-CLI-ID-TRY-NUM TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MAX-CLI-ID-TRY-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-CLI-ID-TRY-NUM.
           MOVE RPSYS-MAX-CLI-ON-POL-QTY
                                      TO WS-PIC-99.
           MOVE WS-PIC-99             TO MIR-MAX-CLI-ON-POL-QTY.
           MOVE RPSYS-MAX-CLI-ON-CVG-QTY
                                      TO WS-PIC-99.
           MOVE WS-PIC-99             TO MIR-MAX-CLI-ON-CVG-QTY.
           MOVE RPSYS-MIB-COMUN-TYP-CD          TO MIR-MIB-COMUN-TYP-CD.
008455*    MOVE RPSYS-MAX-PERS-MDRT-AMT    TO WS-PIC-DOLLAR.
008455*    MOVE WS-PIC-DOLLAR              TO MIR-MAX-PERS-MDRT-AMT.
020874*    COMPUTE  L0290-INPUT-NUMBER = RPSYS-MAX-PERS-MDRT-AMT
020874*                                  * 100.
020874     MOVE RPSYS-MAX-PERS-MDRT-AMT TO L0290-INPUT-V02.
008455     PERFORM  9700-FORMAT-MMDRT
008455         THRU 9700-FORMAT-MMDRT-X.
007766*    MOVE RPSYS-MAX-CVG-ON-POL-QTY   TO WS-PIC-99.
007766     MOVE WCVGM-MAX-WCVGS-NUM   TO WS-PIC-99.
           MOVE WS-PIC-99             TO MIR-DV-MAX-POL-CVG-QTY.
           MOVE RPSYS-MAX-CLI-SRCH-QTY                     TO WS-PIC-99.
           MOVE WS-PIC-99             TO MIR-MAX-CLI-SRCH-QTY.

014221*    MOVE RPSYS-PREV-UPDT-DT    TO L1640-INTERNAL-DATE.
014221*    PERFORM  1640-2000-INTERNAL-TO-EXT
014221*        THRU 1640-2000-INTERNAL-TO-EXT-X.
014221*    MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-UPDT-DT.

016440     MOVE RPSYS-CCAS-PRCES-OPT-CD TO MIR-CCAS-PRCES-OPT-CD.
016400     MOVE RPSYS-SYS-CTL-ID        TO MIR-SYS-CTL-ID.


019632     MOVE RPSYS-PX-CALC-IND        TO MIR-PX-CALC-IND.
019632     MOVE RPSYS-SYS-CTL-PX-SRVR-NM TO MIR-SYS-CTL-PX-SRVR-NM.

020874*    MOVE RPSYS-PX-SRVR-PORT-NUM   TO L0290-INPUT-NUMBER.
020874     MOVE RPSYS-PX-SRVR-PORT-NUM   TO L0290-INPUT-V00.
019632     MOVE 0                        TO L0290-PRECISION.
019632     MOVE LENGTH OF MIR-PX-SRVR-PORT-NUM
019632                                   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
019632     MOVE L0290-OUTPUT-DATA        TO MIR-PX-SRVR-PORT-NUM.

019632     MOVE RPSYS-PX-CHAR-SET-CD     TO MIR-PX-CHAR-SET-CD.

028458     MOVE RPSYS-PFC-ENBL-IND       TO MIR-PFC-ENBL-IND.
028458     MOVE RPSYS-PFC-SRVR-NM        TO MIR-PFC-SRVR-NM.
028458
028458     MOVE RPSYS-PFC-SRVR-PORT-NUM  TO L0290-INPUT-V00.
028458     MOVE 0                        TO L0290-PRECISION.
028458     MOVE LENGTH OF MIR-PFC-SRVR-PORT-NUM
028458                                   TO L0290-MAX-OUT-LEN.
028458     PERFORM  0290-2000-FORMAT-FOR-MIR
028458         THRU 0290-2000-FORMAT-FOR-MIR-X.
028458     MOVE L0290-OUTPUT-DATA        TO MIR-PFC-SRVR-PORT-NUM.
028458
028458     MOVE RPSYS-PFC-CHAR-SET-CD    TO MIR-PFC-CHAR-SET-CD.


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
008455*------------------
008455 9700-FORMAT-MMDRT.
008455*------------------
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MAX-PERS-MDRT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-PERS-MDRT-AMT.
008455 9700-FORMAT-MMDRT-X.
008455     EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0002-0000-INIT-PARM-INFO
025970         THRU 0002-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORK-AREAS.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
008455/
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      /
021930*COPY XCPL1640.
021930*
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************

       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PSYS
014221                         '$VAR2' BY 'PSYS'.
019632 COPY XCPS0002.
019632 COPY XCPL0002.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
019632 COPY XCPS8960.
019632 COPY XCPL8960.
019632/
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPAPSYS.
       COPY CCPNPSYS.
       COPY CCPUPSYS.
       COPY CCPXPSYS.

       COPY CCPCPSYS.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM0601                     **
      *****************************************************************
