      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0241.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0241                                         **
      **  REMARKS:  RCPT- CASH RECEIPTS (ALSO MREC-MISCELLANEOUS     **
      **            RECEIPTS).                                       **
      **            PROCESS SPECIFIC PRE-FORMATTED CASH RECEIPTS IN  **
      **            THE GENERAL LEDGER. THIS MODULE IS ALSO USED TO  **
      **            PROCESS CASH RECEIPTS (FROM THE MREC TRANSACTION)**
      **            THAT DO NOT APPEAR ON RCPT. THE MODULE CALLS A   **
      **            UTILITY TO GENERATE THE ACCOUNTING EXTRACTS      **
      **            WHICH ARE USED TO UPDATE THE GENERAL LEDGER AND  **
      **            TO RECORD CASH RECEIVED FROM SOURCES OTHER THAN  **
      **            POLICY INCOME.                                   **
      **                                                             **
      **  DOMAIN :  AC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557658**  5.5       YEAR 2000                                        **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZING FOR INT'L SUPPORT            **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEANUP AND STANDARDIZATION                 **
010418**  5.6       MULTI-COMPANY                                    **
011925**  5.6       RENAME MODULES X*5480 TO C*5480                  **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODES CLEAN UP                                   **
016457**  6.2       REMOVE TRAN '00'                                 **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017150**  6.3       CURRENCY SCALING (6.1.2J)                        **
017484**  6.3       BLANK OUT ASTERISK FIELDS                        **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0241'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           03  TRANSACTION-NAME             PIC X(04).
           03  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUES
                   '1290' '1291' '1292' '1293'.
               88  WS-BUS-FCN-CSHRCPT       VALUE  '1290'.
               88  WS-BUS-FCN-CSHREVS       VALUE  '1291'.
               88  WS-BUS-FCN-MISRCPT       VALUE  '1292'.
               88  WS-BUS-FCN-MISREVS       VALUE  '1293'.

016548*    03  WS-TABLE-SIZE                PIC S9(04) COMP.
016548     03  WS-TABLE-SIZE                PIC S9(04) BINARY.
013578         88  WS-CSHRCPT-TABLE-SIZE    VALUE 11.
013578         88  WS-CSHREVS-TABLE-SIZE    VALUE 11.
013578         88  WS-MISRCPT-TABLE-SIZE    VALUE 100.
013578         88  WS-MISREVS-TABLE-SIZE    VALUE 100.
013578
      **** THREE REQUIRED FIELDS FOR INITIALIZING PGA CODED HERE
      **** INSTEAD OF PULLING IN THE POLICY AND COVERAGE FILES
           03  RPOL-POL-ID                  PIC X(10)  VALUE SPACES.
           03  RPOL-POL-BASE-CVG-NUM        PIC 9(02)  VALUE ZERO.
      **** HOLD-RUN-ID IS REQUIRED BY CCPSPGA, THAT'S WHY IT'S HERE.
025970*    03  HOLD-RUN-ID                  PIC X(01)  VALUE '0'.

       01  MISC-WORK-AREAS.
           02  MD-MISC-WORK-AREAS.
               03  ERROR-SW                 PIC 9(01).
               03  ERROR-INX                PIC 9(02).
025970*        03  ERROR-LINE-SCREEN        PIC 9(02)  VALUE 1.
               03  UPDATE-SW                PIC 9(01).
                   88  NO-UPDATE                       VALUE 0.
                   88  UPDATE-REQUIRED                 VALUE 1.
               03  ERROR-IN-DUMP            PIC X(01).
               03  TOTAL-OUT-SW             PIC 9(01).
                   88 TOTAL-REQUIRED                   VALUE 1.
               03  ERROR-HOLDER             PIC X(24).
008455*        03  HOLD-TB1LI.
008455*            05  HTB1                 PIC X(09).
008455*            05  HTB1N REDEFINES HTB1 PIC 9(09).
008455*            05  DECIMAL              PIC X(01)  VALUE '.'.
008455*            05  HTB2                 PIC X(02).
008455*            05  HTB2N REDEFINES HTB2 PIC V9(02).
016548*        03  I                        PIC S9(04) COMP.
016548         03  I                        PIC S9(04) BINARY.
557973*****    03  TOTAL-NUMBERS            PIC S9(09)V99.
557973         03  TOTAL-NUMBERS            PIC S9(15)V99.
557973*****    03  TOTAL-CASH-THIS-SCREEN   PIC S9(09)V99.
557973         03  TOTAL-CASH-THIS-SCREEN   PIC S9(15)V99.
025970*        03  RPOL-PREV-FILE-MAINT-DT  PIC X(10)  VALUE
025970*            '0000-00-00'.
008455*        03  EDIT-1                   PIC Z(09).99-.
008455*        03  EDIT-1B                  PIC Z(15).99-.
008455*        03  EDIT-2                   PIC Z(08)9.99.
               03  WS-DATE.
557658*            05  FILLER               PIC X(02).
557658*            05  WS-YR                PIC 9(02).
557658*            05  FILLER               PIC X(05).
557658             05  WS-YR                PIC 9(04).
557658             05  FILLER               PIC X(06).

010418         03  WS-SBSDRY-CO-ID-USED     PIC X(02).
010418         03  WS-SBSDRY-CO-DIFF-SW     PIC X(01).
010418             88  WS-SBSDRY-CO-DIFF    VALUE 'Y'.
010418             88  WS-SBSDRY-CO-SAME    VALUE 'N'.


           02  HOLD-ALL.
               03  HOLD-CASH-AREAS.
008455*            04  HOLD-BKAMT           PIC X(12) OCCURS 4 TIMES.
008455             04  HOLD-BKAMT           PIC X(18) OCCURS 4 TIMES.
008455*            04  HOLD-CR              PIC X(12) OCCURS 11 TIMES.
008455*            04  HOLD-DB              PIC X(12) OCCURS 11 TIMES.
013578*            04  HOLD-CR              PIC X(18) OCCURS 11 TIMES.
013578*            04  HOLD-DB              PIC X(18) OCCURS 11 TIMES.
013578             04  HOLD-CR              PIC X(18) OCCURS 100 TIMES.
013578             04  HOLD-DB              PIC X(18) OCCURS 100 TIMES.

               03  HOLD-ST-SWITCHES.
013578             04  HOLD-ST-SW           PIC X(01) OCCURS 100 TIMES.
013578*            04  HOLD-ST-SW           PIC X(01) OCCURS 11 TIMES.

               03  HOLD-ENTRY-AREAS.
                   04  HOLD-BKACCT-ACC OCCURS 4 TIMES.
                       05  HOLD-DESCBK      PIC X(07).
                       05  HOLD-BKACCT      PIC X(06).
010418                 05  HOLD-BKSC        PIC X(02).
                       05  HOLD-BKBRD       PIC X(05).
010418*                05  HOLD-BKLOB       PIC X(01).
                   04  HOLD-TDESC           PIC X(20).
                   04  HOLD-VOUCHER         PIC X(07).
013578*            04  HOLD-EACH       OCCURS 11 TIMES.
013578             04  HOLD-EACH       OCCURS 100 TIMES.
                       05  HOLD-DESC        PIC X(14).
010418*                05  HOLD-LOB-LIN     PIC X(01).
                       05  HOLD-BRD-LIN     PIC X(05).
010418                 05  HOLD-SC-LIN      PIC X(02).
                       05  HOLD-ACCT-LIN    PIC X(06).
                       05  HOLD-DESC-LIN    PIC X(20).

               03  HOLD-CONVERTED-AREAS.
557973*****        04  HT01                 PIC S9(09)V99 OCCURS  4.
557973             04  HT01                 PIC S9(15)V99 OCCURS  4.
557973*****        04  HTM                  PIC S9(09)V99 OCCURS 11.
013578*            04  HTM                  PIC S9(15)V99 OCCURS 11.
013578             04  HTM                  PIC S9(15)V99 OCCURS 100.

               03  E0241-WORK-INFO.
       COPY CCWE0241.
       
025970 01  WS-CONSTANT-FIELDS.
025970     05  HOLD-RUN-ID                      PIC X(01).
025970         88 HOLD-RUN-ID-DEFAULT           VALUE '0'.              
025970     05  ERROR-LINE-SCREEN                PIC 9(02).
025970         88  ERROR-LINE-SCREEN-DEFAULT    VALUE 1.
025970     05  RPOL-PREV-FILE-MAINT-DT          PIC X(10). 
025970         88  RPOL-PREV-FILE-MAINT-DT-DEF  VALUE '0000-00-00'.


557756*COPY CCWTYSNO.
      /
      ***************************************************************
      *    COMMON COPYBOOKS
      ***************************************************************
017484 COPY XCWEBLCH.
      /
       COPY XCWWWKDT.
      /
      ***************************************************************
      *    I/O COPYBOOKS
      ***************************************************************
       COPY CCFWAC.
       COPY CCFRAC.
      /
      ***************************************************************
      *    CALLED MODULE PARAMETER INFORMATION
      ***************************************************************
       COPY XCWL0280.
       COPY XCWL0290.
      /
       COPY CCWL5277.
011925*COPY XCWL5480.
016537*COPY CCWL5480.
016457*COPY CCWL5200.
      /
       COPY CCWLACCT.
       COPY CCWL5860.
      /
      ***************************************************************
      *    INPUT PARAMETER INFORMATION
      ***************************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY CCWLPGA.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0241.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      /
      *---------------
015543*0000-MAIN-LINE.
015543 0000-MAINLINE.
      *---------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

015543*0000-MAIN-LINE-X.
015543 0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK          TO TRUE.
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF  NOT WS-BUS-FCN-ID-VALID
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
               MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
               MOVE 'CSOM0241'        TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-INVALD-RQST  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-CSHRCPT
013578              SET WS-CSHRCPT-TABLE-SIZE  TO TRUE
013578
013578         WHEN WS-BUS-FCN-CSHREVS
013578              SET WS-CSHREVS-TABLE-SIZE  TO TRUE
013578
013578         WHEN WS-BUS-FCN-MISRCPT
013578              SET WS-MISRCPT-TABLE-SIZE  TO TRUE
013578
013578         WHEN WS-BUS-FCN-MISREVS
013578              SET WS-MISREVS-TABLE-SIZE  TO TRUE
013578
013578     END-EVALUATE.
013578
013578*    IF  WGLOB-MSG-ERROR-SW = 1
013578*        SET MIR-RETRN-RQST-FAILED  TO TRUE
013578*        GO TO 2000-PROCESS-REQUEST-X
013578*    END-IF.
013578*
           PERFORM 3000-MOVE-DATA-FROM-MAP
              THRU 3000-MOVE-DATA-FROM-MAP-X.

           PERFORM 3100-SET-UP-OUTPUT-MAP
              THRU 3100-SET-UP-OUTPUT-MAP-X.

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.
           MOVE ZERO                  TO UPDATE-SW.
           MOVE ZERO                  TO TOTAL-OUT-SW.

010418     SET WS-SBSDRY-CO-SAME      TO TRUE.
010418     MOVE SPACE                 TO WS-SBSDRY-CO-ID-USED.

010418*    PERFORM  5480-1000-BUILD-PARM-INFO
010418*        THRU 5480-1000-BUILD-PARM-INFO-X.

           MOVE WGLOB-CURRENCY-CODE   TO MIR-USER-SESN-CRCY-CD.

           IF HOLD-TDESC = SPACES
      *MSG: TRANSACTION DESCRIPTION REQUIRED. ENTER
              MOVE 'CS02410002'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
010311*       GO TO 2000-PROCESS-TRANS-CONT
010311        PERFORM  3200-MOVE-AMOUNTS-MIR
010311            THRU 3200-MOVE-AMOUNTS-MIR-X
010311        GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           MOVE ZERO                  TO HOLD-ST-SWITCHES.
           MOVE 'Y'                   TO L0280-SPACE-PERMITTED-IND.
           MOVE 'N'                   TO L0280-SIGN-IND.
008455*    MOVE 12                  TO L0280-LENGTH.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                   TO L0290-LENGTH.
           MOVE 2                     TO L0290-PRECISION.

           PERFORM  2400-MOVE-NUMBERS
               THRU 2400-MOVE-NUMBERS-X
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE.
013578*        UNTIL   I > 11.

           IF  WGLOB-MSG-ERROR-SW = 1
010311*        GO TO 2000-PROCESS-TRANS-CONT
010311         PERFORM  3200-MOVE-AMOUNTS-MIR
010311             THRU 3200-MOVE-AMOUNTS-MIR-X
010311         GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           MOVE ZERO                  TO TOTAL-NUMBERS.
           MOVE ZERO                  TO TOTAL-CASH-THIS-SCREEN.
           PERFORM  2300-ADD-NUMBERS
               THRU 2300-ADD-NUMBERS-X
               VARYING I FROM 1 BY 1
013578*        UNTIL   I > 11.
013578         UNTIL   I > WS-TABLE-SIZE.

           IF  TOTAL-NUMBERS NOT = ZERO
      *MSG: DEBITS NOT EQUAL TO CREDITS BY.............. @1
               MOVE 'CS00000039'      TO WGLOB-MSG-REF-INFO
557973*****    MOVE TOTAL-NUMBERS   TO EDIT-1
557973*****    MOVE EDIT-1          TO WGLOB-MSG-PARM (1)
008455*        MOVE TOTAL-NUMBERS   TO EDIT-1B
008455*        MOVE EDIT-1B         TO WGLOB-MSG-PARM (1)
               COMPUTE L0290-INPUT-NUMBER
                     = TOTAL-NUMBERS * L0290-CRCY-MULT-FCT
017150         MOVE WGLOB-CRCY-SCALE-QTY TO L0290-PRECISION
017150*        COMPUTE L0290-INPUT-NUMBER = TOTAL-NUMBERS * 100
017150*        MOVE 2                 TO L0290-PRECISION
               MOVE 40                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY   TO TRUE
               PERFORM  0290-1000-NUMERIC-FORMAT
                   THRU 0290-1000-NUMERIC-FORMAT-X
008455         MOVE L0290-OUTPUT-DATA TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
010311*        GO TO 2000-PROCESS-TRANS-CONT
010311         PERFORM  3200-MOVE-AMOUNTS-MIR
010311             THRU 3200-MOVE-AMOUNTS-MIR-X
010311         GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  TOTAL-CASH-THIS-SCREEN = 0
      *MSG: AMOUNTS MUST BE ENTERED.
               MOVE 'CS00000041'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
010311*        GO TO 2000-PROCESS-TRANS-CONT
010311         PERFORM  3200-MOVE-AMOUNTS-MIR
010311             THRU 3200-MOVE-AMOUNTS-MIR-X
010311         GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           MOVE WGLOB-PROCESS-DATE    TO WS-DATE.
           PERFORM  2100-CHECK-BANK-ACNT
               THRU 2100-CHECK-BANK-ACNT-X
               VARYING I FROM 1 BY 1
               UNTIL   I > 4.

           PERFORM  2200-CHECK-ACNT
               THRU 2200-CHECK-ACNT-X
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE.
013578*        UNTIL   I > 11.

           IF  WGLOB-MSG-ERROR-SW > ZEROS
010311*        GO TO 2000-PROCESS-TRANS-CONT
010311         PERFORM  3200-MOVE-AMOUNTS-MIR
010311             THRU 3200-MOVE-AMOUNTS-MIR-X
010311         GO TO 2000-PROCESS-REQUEST-X
           END-IF.

010418     IF WS-SBSDRY-CO-DIFF
010418        MOVE 'CS02410013'       TO WGLOB-MSG-REF-INFO
010418* MSG:  SUB-CO'S NOT THE SAME - OUT OF BALANCE MAY OCCUR
010418        PERFORM  0260-1000-GENERATE-MESSAGE
010418            THRU 0260-1000-GENERATE-MESSAGE-X
010418        IF WGLOB-MSG-ERROR-SW > ZEROS
010418           PERFORM  3200-MOVE-AMOUNTS-MIR
010418               THRU 3200-MOVE-AMOUNTS-MIR-X
010418           GO TO 2000-PROCESS-REQUEST-X
010418        END-IF
010418     END-IF.



           MOVE 1                     TO TOTAL-OUT-SW.
           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
      *MSG: PLEASE VERIFY
               MOVE 'CS02410009'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  3200-MOVE-AMOUNTS-MIR
                   THRU 3200-MOVE-AMOUNTS-MIR-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2500-PROCESS-DEBITS
               THRU 2500-PROCESS-DEBITS-X
               VARYING I FROM 1 BY 1
               UNTIL   I > 4.

           PERFORM  2600-PROCESS-CREDITS
               THRU 2600-PROCESS-CREDITS-X
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE.
013578*        UNTIL   I > 11.

      *MSG: ENTRIES PROCESSED FOR THIS SCREEN..........$ @1
           MOVE 'CS02410007'          TO WGLOB-MSG-REF-INFO.
557973*****MOVE TOTAL-CASH-THIS-SCREEN TO EDIT-1.
557973*****MOVE EDIT-1              TO WGLOB-MSG-PARM (1).
008455*    MOVE TOTAL-CASH-THIS-SCREEN TO EDIT-1B.
008455*    MOVE EDIT-1B             TO WGLOB-MSG-PARM (1).
           COMPUTE L0290-INPUT-NUMBER
                   = TOTAL-CASH-THIS-SCREEN * L0290-CRCY-MULT-FCT.
017150*    MOVE WGLOB-CRCY-SCALE-QTY  TO L0290-PRECISION.
017150*    COMPUTE L0290-INPUT-NUMBER = TOTAL-CASH-THIS-SCREEN * 100.
017150*    MOVE 2                     TO L0290-PRECISION.
           MOVE 40                    TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY   TO TRUE
           PERFORM  0290-1000-NUMERIC-FORMAT
               THRU 0290-1000-NUMERIC-FORMAT-X.
008455     MOVE L0290-OUTPUT-DATA     TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

010418*
010418*  UPDATE USER SESSION TOTALS AND DISPLAY TOTAL RECEIPTS
010418*
010418*    PERFORM  5480-2000-UPDATE-SUMMARY
010418*        THRU 5480-2000-UPDATE-SUMMARY-X.
010418*
010418*MSG: TOTAL RECEIPTS.............................$ @1
010418*    MOVE 'CS02410008'        TO WGLOB-MSG-REF-INFO.
010418*****MOVE L5480-TOT-CSH-GNRL-AMT
010418*****                         TO EDIT-1.
010418*****MOVE EDIT-1              TO WGLOB-MSG-PARM (1).
010418*    MOVE L5480-TOT-CSH-GNRL-AMT
010418*                             TO EDIT-1B.
010418*    MOVE EDIT-1B             TO WGLOB-MSG-PARM (1).
010418*    COMPUTE L0290-INPUT-NUMBER = L5480-TOT-CSH-GNRL-AMT * 100.
010418*    MOVE 2                   TO L0290-PRECISION.
010418*    MOVE 40                  TO L0290-MAX-OUT-LEN.
010418*    SET L0290-MESSAGE-FORMAT TO TRUE
010418*    SET L0290-SIGN-DISPLAY   TO TRUE
010418*    SET L0290-SIGN-FLOAT     TO TRUE
010418*    PERFORM  0290-1000-NUMERIC-FORMAT
010418*        THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA   TO WGLOB-MSG-PARM (1).
010418*    PERFORM  0260-1000-GENERATE-MESSAGE
010418*        THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9500-INIT-MIR-FIELDS
              THRU 9500-INIT-MIR-FIELDS-X.

      *
      * CONTINUE PROCESSING THIS TRANSACTION
      *
010311*2000-PROCESS-TRANS-CONT.

           PERFORM  3200-MOVE-AMOUNTS-MIR
               THRU 3200-MOVE-AMOUNTS-MIR-X.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *---------------------
       2100-CHECK-BANK-ACNT.
      *---------------------

010418     IF HT01 (I) = ZERO
010418         GO TO 2100-CHECK-BANK-ACNT-X
010418     END-IF.
010418*
           MOVE SPACES                TO WAC-KEY.
010418***  IF HT01 (I) NOT = ZERO
010418***      MOVE HOLD-BKACCT (I) TO WAC-ACCT-ID-INFO
557658*        MOVE WS-YR           TO WAC-ACCT-YR-CD-N
010418***      MOVE WS-YR           TO WAC-ACCT-YR
010418***      MOVE WGLOB-CURRENCY-CODE TO WAC-ACCT-CRCY-CD
010418***      MOVE HOLD-BKBRD (I)  TO WAC-BR-OR-DEPT-ID
010418***      MOVE HOLD-BKLOB (I)  TO WAC-ACCT-LOB-DIVSN-CD
010418***      PERFORM AC-1000-READ
010418***         THRU AC-1000-READ-X
557658*        MOVE ZEROS           TO WAC-ACCT-YR-CD-N
010418***      MOVE ZEROS           TO WAC-ACCT-YR
010418***      IF NOT WAC-IO-OK
      *MSG: INVALID ACCOUNT KEY IN: @1
010418***         MOVE 'CS02410003' TO WGLOB-MSG-REF-INFO
010418***         MOVE HOLD-DESCBK (I)
010418***                           TO WGLOB-MSG-PARM (1)
010418***         PERFORM  0260-1000-GENERATE-MESSAGE
010418***             THRU 0260-1000-GENERATE-MESSAGE-X
010418***      ELSE
010418***         PERFORM  2110-CHECK-BANK-ACNT-AUTH
010418***             THRU 2110-CHECK-BANK-ACNT-AUTH-X
010418***      END-IF
010418***  END-IF.

010418***  MOVE SPACES              TO WAC-ACCT-BASE-ID.
010418*
010418     MOVE HOLD-BKACCT (I)       TO WAC-ACCT-ID-INFO.
010418     MOVE WS-YR                 TO WAC-ACCT-YR.
010418     MOVE HOLD-BKSC (I)         TO WAC-SBSDRY-CO-ID.
010418     MOVE WGLOB-CURRENCY-CODE   TO WAC-ACCT-CRCY-CD.
010418     MOVE HOLD-BKBRD (I)        TO WAC-BR-OR-DEPT-ID.
010418     PERFORM AC-1000-READ
010418        THRU AC-1000-READ-X.
010418     MOVE ZEROS                 TO WAC-ACCT-YR.
010418*
010418     IF NOT WAC-IO-OK
      *MSG: INVALID ACCOUNT KEY IN: @1
010418        MOVE 'CS02410003'       TO WGLOB-MSG-REF-INFO
010418        MOVE HOLD-DESCBK (I)
010418                                TO WGLOB-MSG-PARM (1)
010418        PERFORM  0260-1000-GENERATE-MESSAGE
010418            THRU 0260-1000-GENERATE-MESSAGE-X
010418     ELSE
010418        PERFORM  2110-CHECK-BANK-ACNT-AUTH
010418            THRU 2110-CHECK-BANK-ACNT-AUTH-X
010418     END-IF.

010418     IF WS-SBSDRY-CO-ID-USED = SPACES
010418         MOVE HOLD-BKSC (I)     TO WS-SBSDRY-CO-ID-USED
010418     ELSE
010418         IF HOLD-BKSC (I) NOT = WS-SBSDRY-CO-ID-USED
010418            SET WS-SBSDRY-CO-DIFF     TO TRUE
010418         END-IF
010418     END-IF.

       2100-CHECK-BANK-ACNT-X.
           EXIT.

      *--------------------------
       2110-CHECK-BANK-ACNT-AUTH.
      *--------------------------

           IF  RAC-ACCT-CONTROLLABLE
               PERFORM  5860-1000-CNTL-ACCT-ACCESS
                   THRU 5860-1000-CNTL-ACCT-ACCESS-X
               IF  L5860-RETRN-UNAUTHORIZED
      *MSG: SECURITY ACCESS DENIED ON ACCOUNT @1
                   MOVE 'CS02410010'  TO WGLOB-MSG-REF-INFO
                   MOVE HOLD-DESCBK (I)
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2110-CHECK-BANK-ACNT-AUTH-X.
           EXIT.
      /
      *----------------
       2200-CHECK-ACNT.
      *----------------

           MOVE SPACES                TO WAC-KEY.
010418*
010418     IF HTM (I) = ZERO
010418         GO TO 2200-CHECK-ACNT-X
010418     END-IF.
010418*
010418***  IF  HTM (I) NOT = ZERO
010418***      MOVE HOLD-ACCT-LIN (I)    TO WAC-ACCT-ID-INFO
557658*        MOVE WS-YR                TO WAC-ACCT-YR-CD-N
010418***      MOVE WS-YR                TO WAC-ACCT-YR
010418***      MOVE WGLOB-CURRENCY-CODE  TO WAC-ACCT-CRCY-CD
010418***      MOVE HOLD-BRD-LIN (I)     TO WAC-BR-OR-DEPT-ID
010418***      MOVE HOLD-LOB-LIN (I)     TO WAC-ACCT-LOB-DIVSN-CD
010418***      PERFORM  AC-1000-READ
010418***          THRU AC-1000-READ-X
557658*        MOVE ZEROS                TO WAC-ACCT-YR-CD-N
010418***      MOVE ZEROS                TO WAC-ACCT-YR
010418***      IF  NOT WAC-IO-OK
      *MSG: INVALID ACCOUNT KEY IN: @1
010418***          MOVE 'CS02410003'      TO WGLOB-MSG-REF-INFO
010418***          MOVE HOLD-DESC (I)     TO WGLOB-MSG-PARM (1)
010418***          PERFORM  0260-1000-GENERATE-MESSAGE
010418***              THRU 0260-1000-GENERATE-MESSAGE-X
010418***      ELSE
010418***          PERFORM  2210-CHECK-ACNT-AUTH
010418***              THRU 2210-CHECK-ACNT-AUTH-X
010418***      END-IF
010418***  END-IF.
010418***  MOVE SPACES                          TO WAC-ACCT-BASE-ID.
010418*
010418     MOVE HOLD-ACCT-LIN (I)     TO WAC-ACCT-ID-INFO.
010418     MOVE WS-YR                 TO WAC-ACCT-YR.
010418     MOVE HOLD-SC-LIN (I)       TO WAC-SBSDRY-CO-ID.
010418     MOVE WGLOB-CURRENCY-CODE   TO WAC-ACCT-CRCY-CD.
010418     MOVE HOLD-BRD-LIN (I)      TO WAC-BR-OR-DEPT-ID.
010418     PERFORM  AC-1000-READ
010418         THRU AC-1000-READ-X.
010418     MOVE ZEROS                 TO WAC-ACCT-YR.
010418*
010418     IF  NOT WAC-IO-OK
      *MSG: INVALID ACCOUNT KEY IN: @1
010418         MOVE 'CS02410003'      TO WGLOB-MSG-REF-INFO
010418         MOVE HOLD-DESC (I)     TO WGLOB-MSG-PARM (1)
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418     ELSE
010418         PERFORM  2210-CHECK-ACNT-AUTH
010418             THRU 2210-CHECK-ACNT-AUTH-X
010418     END-IF.
010418*
010418     IF WS-SBSDRY-CO-ID-USED = SPACES
010418         MOVE HOLD-SC-LIN (I)   TO WS-SBSDRY-CO-ID-USED
010418     ELSE
010418         IF HOLD-SC-LIN (I) NOT = WS-SBSDRY-CO-ID-USED
010418            SET WS-SBSDRY-CO-DIFF  TO TRUE
010418         END-IF
010418     END-IF.

       2200-CHECK-ACNT-X.
           EXIT.

      *---------------------
       2210-CHECK-ACNT-AUTH.
      *---------------------

           IF  RAC-ACCT-CONTROLLABLE
               PERFORM  5860-1000-CNTL-ACCT-ACCESS
                   THRU 5860-1000-CNTL-ACCT-ACCESS-X
               IF  L5860-RETRN-UNAUTHORIZED
      *MSG: SECURITY ACCESS DENIED ON ACCOUNT @1
                   MOVE 'CS02410010'  TO WGLOB-MSG-REF-INFO
                   MOVE HOLD-DESC (I) TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE RAC-ACCT-SUB-TYP-CD
                                      TO HOLD-ST-SW (I)
               END-IF
           ELSE
               MOVE RAC-ACCT-SUB-TYP-CD
                                      TO HOLD-ST-SW (I)
           END-IF.

       2210-CHECK-ACNT-AUTH-X.
           EXIT.
      /
      *-----------------
       2300-ADD-NUMBERS.
      *-----------------

           IF  I < 5
               ADD HT01 (I)       TO TOTAL-CASH-THIS-SCREEN
               ADD HT01 (I)       TO TOTAL-NUMBERS
           END-IF.

           ADD HTM (I)            TO TOTAL-NUMBERS.

       2300-ADD-NUMBERS-X.
           EXIT.

      *------------------
       2400-MOVE-NUMBERS.
      *------------------

           MOVE ZEROES                TO HTM (I).
           IF  HOLD-CR (I) NOT = SPACES
               MOVE HOLD-CR (I)       TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (I)
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE HTM (I) = -1 * L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*              THRU  0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874               THRU  0290-2000-FORMAT-FOR-MIR-X  
                   MOVE L0290-OUTPUT-DATA
                                      TO HOLD-CR (I)
               ELSE
      *MSG: NON-NUMERIC CREDIT AMOUNT IN: @1
                   MOVE 'CS02410004'  TO WGLOB-MSG-REF-INFO
                   MOVE HOLD-DESC (I) TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  HOLD-DB (I) NOT = SPACES
               MOVE HOLD-DB (I)       TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (I)
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   PERFORM  2410-FORMAT-DEBITS
                       THRU 2410-FORMAT-DEBITS-X
               ELSE
      *MSG: NON-NUMERIC DEBIT AMOUNT IN: @1
                   MOVE 'CS02410005'  TO WGLOB-MSG-REF-INFO
                   MOVE HOLD-DESC (I) TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  WS-BUS-FCN-CSHREVS
           OR  WS-BUS-FCN-MISREVS
               COMPUTE HTM (I) = -1 * HTM (I)
           END-IF.

           IF  I < 5
               CONTINUE
           ELSE
               GO TO 2400-MOVE-NUMBERS-X
           END-IF.

           MOVE HOLD-BKAMT (I)        TO L0280-INPUT-DATA.
016457*    MOVE LENGTH OF MIR-DV-ACCT-TRXN-AMT-T (I)
016457     MOVE LENGTH OF MIR-ACCT-TRXN-AMT-T (I)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  NOT L0280-OK
      *MSG: NON-NUMERIC BANK/TRUST AMOUNT IN: @1
               MOVE 'CS02410006'      TO WGLOB-MSG-REF-INFO
               MOVE HOLD-DESCBK (I)   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO HT01 (I)
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
016457*        MOVE LENGTH OF MIR-DV-ACCT-TRXN-AMT-T (I)
016457         MOVE LENGTH OF MIR-ACCT-TRXN-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*          THRU  0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU  0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO HOLD-BKAMT (I)
               IF  WS-BUS-FCN-CSHREVS
               OR  WS-BUS-FCN-MISREVS
                   COMPUTE HT01 (I) = -1 * HT01 (I)
               END-IF
           END-IF.

       2400-MOVE-NUMBERS-X.
           EXIT.
      /
      *-------------------
       2410-FORMAT-DEBITS.
      *-------------------

           IF  L0280-OUTPUT = ZERO
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*          THRU  0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU  0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA TO HOLD-DB (I)
           ELSE
               IF  HTM (I) NOT = ZERO
      *MSG: RE-ENTER WITH EITHER A DEBIT OR A CREDIT
                   MOVE 'CS00000038'  TO WGLOB-MSG-REF-INFO
                   MOVE HOLD-DESC (I) TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO HTM (I)
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*              THRU  0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874               THRU  0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO HOLD-DB (I)
               END-IF
           END-IF.

       2410-FORMAT-DEBITS-X.
           EXIT.

      *--------------------
       2500-PROCESS-DEBITS.
      *--------------------

           MOVE SPACE                 TO E0241-WORK-INFO.
           INITIALIZE L5277-INPUT-PARM-INFO.
           MOVE WGLOB-PROCESS-DATE    TO L5277-PRCES-DT.
016457     MOVE WWKDT-ZERO-DT         TO L5277-PREV-DT.
016457     MOVE WWKDT-ZERO-DT         TO LACCT-PREV-ACCT-DT.
016457     MOVE WWKDT-ZERO-DT         TO L5277-ISS-DT.
016457     SET L5277-SNGL-SIDE-ENTR-NO  TO TRUE.
016457     SET L5277-ACCT-TRXN-STAT-ACTV TO TRUE.

           IF  HT01 (I) NOT = ZERO
               MOVE HT01 (I)          TO L5277-AMT
               MOVE HT01 (I)          TO E0241-DEBIT
               MOVE HOLD-BKACCT (I)   TO L5277-BASE-ID
               MOVE HOLD-BKACCT (I)   TO E0241-ACCT
010418         MOVE HOLD-BKSC   (I)   TO L5277-SBSDRY-CO-ID
010418         MOVE HOLD-BKSC   (I)   TO E0241-SUBCO
               MOVE HOLD-BKBRD  (I)   TO L5277-BR-OR-DEPT-ID
               MOVE HOLD-BKBRD  (I)   TO E0241-BRC
010418*        MOVE HOLD-BKLOB  (I)         TO L5277-LOB-DIVSN-CD
010418*        MOVE HOLD-BKLOB  (I)         TO E0241-LOB
               MOVE HOLD-TDESC        TO E0241-DESCRIPTION
               MOVE HOLD-TDESC        TO L5277-DESC-INFO
010418*        ADD  L5277-AMT               TO L5480-CSH-GNRL-AMT
               MOVE 'B'               TO L5277-SUB-TYP-CD
               PERFORM  2700-PROCESS1L
                   THRU 2700-PROCESS1L-X
           END-IF.

       2500-PROCESS-DEBITS-X.
           EXIT.
      /
      *---------------------
       2600-PROCESS-CREDITS.
      *---------------------

           MOVE SPACE                 TO E0241-WORK-INFO.
           INITIALIZE L5277-INPUT-PARM-INFO.
           MOVE WGLOB-PROCESS-DATE    TO L5277-PRCES-DT.
016457     MOVE WWKDT-ZERO-DT         TO L5277-PREV-DT.
016457     MOVE WWKDT-ZERO-DT         TO LACCT-PREV-ACCT-DT.
016457     MOVE WWKDT-ZERO-DT         TO L5277-ISS-DT.
016457     SET L5277-SNGL-SIDE-ENTR-NO  TO TRUE.
016457     SET L5277-ACCT-TRXN-STAT-ACTV TO TRUE.

           IF  HTM (I) NOT = ZERO
               MOVE HOLD-ACCT-LIN (I) TO L5277-BASE-ID
               MOVE HOLD-ACCT-LIN (I) TO E0241-ACCT
010418         MOVE HOLD-SC-LIN   (I) TO L5277-SBSDRY-CO-ID
010418         MOVE HOLD-SC-LIN   (I) TO E0241-SUBCO
010418*        MOVE HOLD-LOB-LIN  (I)       TO L5277-LOB-DIVSN-CD
010418*        MOVE HOLD-LOB-LIN  (I)       TO E0241-LOB
               MOVE HOLD-BRD-LIN  (I) TO L5277-BR-OR-DEPT-ID
               MOVE HOLD-BRD-LIN  (I) TO E0241-BRC
               MOVE HTM (I)           TO L5277-AMT
               MOVE HTM (I)           TO E0241-DEBIT
               PERFORM  2610-SET-UP-DESCRIPTION
                   THRU 2610-SET-UP-DESCRIPTION-X
              MOVE HOLD-ST-SW (I)     TO L5277-SUB-TYP-CD
              PERFORM  2700-PROCESS1L
                  THRU 2700-PROCESS1L-X
           END-IF.

       2600-PROCESS-CREDITS-X.
           EXIT.
      /
      *------------------------
       2610-SET-UP-DESCRIPTION.
      *------------------------

           IF  HOLD-DESC-LIN (I) = SPACES
               MOVE HOLD-TDESC        TO E0241-DESCRIPTION
               MOVE HOLD-TDESC        TO L5277-DESC-INFO
           ELSE
               MOVE HOLD-DESC-LIN (I) TO E0241-DESCRIPTION
               MOVE HOLD-DESC-LIN (I) TO L5277-DESC-INFO
           END-IF.

       2610-SET-UP-DESCRIPTION-X.
           EXIT.

      *---------------
       2700-PROCESS1L.
      *---------------

           MOVE WGLOB-PROCESS-DATE    TO E0241-DATE.
           MOVE WGLOB-PROCESS-DATE    TO L5277-PRCES-DT.
           MOVE WGLOB-PROCESS-DATE    TO WS-DATE.


016457*    INITIALIZE L5200-INPUT-PARM-INFO.
016457*    MOVE WWKDT-ZERO-DT         TO L5200-POL-PREV-FILE-MAINT-DT.
016457*    SET L5200-EXAM-TRNXT-NOT-REQD
016457*                               TO TRUE.
016457*    MOVE E0241-WORK-INFO       TO L5200-AUDIT-INFO.
016457*
016457*    PERFORM  5200-1000-WRITE-AUDIT-TRNXT
016457*        THRU 5200-1000-WRITE-AUDIT-TRNXT-X.
016457*
           MOVE WS-YR                 TO L5277-YR-CD.
           MOVE WS-YR                 TO E0241-YEAR.
           MOVE WGLOB-CURRENCY-CODE   TO L5277-CRCY-CD.
           MOVE WGLOB-CURRENCY-CODE   TO E0241-CURR.
           MOVE HOLD-VOUCHER          TO L5277-VCHR-ID.
016457*    MOVE 'C'                   TO L5277-SRC-CD.
016457*    MOVE '77'                  TO L5277-ACCT-XTRCT-TYP-CD.
016457     SET L5277-ACCT-XTRCT-TYP-REGULAR
016457                                TO TRUE.

           PERFORM  5277-1000-WRITE-ACCT
               THRU 5277-1000-WRITE-ACCT-X.

       2700-PROCESS1L-X.
           EXIT.
      /
      *------------------------
       3000-MOVE-DATA-FROM-MAP.
      *------------------------

           MOVE ZEROS                 TO E0241-YEAR.
      *****AMOUNT
           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
016457*            MOVE MIR-DV-ACCT-TRXN-AMT-T (I)
016457             MOVE MIR-ACCT-TRXN-AMT-T (I)
                                      TO HOLD-BKAMT (I)
           END-PERFORM.

      ***** CREDIT AMOUNTS
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
                   MOVE MIR-DV-TRNXT-CR-AMT-T (I)
                                      TO HOLD-CR (I)
           END-PERFORM.

      ***** DEBIT AMOUNTS
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
                   MOVE MIR-DV-TRNXT-DR-AMT-T (I)
                                      TO HOLD-DB (I)
           END-PERFORM.

           INSPECT HOLD-CASH-AREAS REPLACING ALL LOW-VALUES BY ZERO.
           MOVE SPACE                 TO HOLD-ENTRY-AREAS.
016457*    MOVE MIR-DV-ACCT-DESC-TXT  TO HOLD-TDESC.
016457*    MOVE MIR-DV-CHQ-VCHR-NUM   TO HOLD-VOUCHER.
016457     MOVE MIR-ACCT-DESC-TXT     TO HOLD-TDESC.
016457     MOVE MIR-CHQ-VCHR-ID       TO HOLD-VOUCHER.

      *----------------------------------------------------------------
      *    INPUT NAMES FOR  ACCOUNT DESCRIPTION NAMES
      *----------------------------------------------------------------
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
016457*           MOVE MIR-DV-SCRN-ACCT-DESC-TXT-T (I)  TO HOLD-DESC (I)
016457            MOVE MIR-DV-ACCT-DESC-TXT-T (I)       TO HOLD-DESC (I)
           END-PERFORM.

      *----------------------------------------------------------------
      *    INPUT NAMES FOR  VALID BANKS
      *----------------------------------------------------------------
           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
                   MOVE MIR-DV-BNK-ACCT-DESC-TXT-T (I)
                                      TO HOLD-DESCBK (I)
           END-PERFORM.

      *----------------------------------------------------------------
      *    INPUT MOVES FOR  VALID BANK ACCOUNTS
      *----------------------------------------------------------------
           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
                   MOVE MIR-DV-BNK-ACCT-BASE-ID-T (I)
                                      TO HOLD-BKACCT (I)
           END-PERFORM.

      *----------------------------------------------------------------
      *    MOVES FOR THE BRANCH/DEPT. OF THE DIFFERENT BANKS
      *----------------------------------------------------------------
           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
017484             IF  MIR-DV-BNK-BR-OR-DEPT-ID-T (I) =
017484                 EBLCH-BLANK-FIELD-CHAR
017484                 MOVE  SPACES   TO MIR-DV-BNK-BR-OR-DEPT-ID-T (I)
017484             END-IF
                   MOVE MIR-DV-BNK-BR-OR-DEPT-ID-T (I)
                                      TO HOLD-BKBRD (I)
           END-PERFORM.

      *----------------------------------------------------------------
      *    MOVES FOR THE DIVISION OF THE DIFFERENT BANKS
      *----------------------------------------------------------------
010418*    SUB COMPANY
           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
017484             IF  MIR-DV-BNK-SBSDRY-CO-ID-T (I) =
017484                 EBLCH-BLANK-FIELD-CHAR
017484                 MOVE  SPACES   TO MIR-DV-BNK-SBSDRY-CO-ID-T (I)
017484             END-IF
010418*            MOVE MIR-BKLOB-T (I)     TO HOLD-BKLOB (I)
010418             MOVE MIR-DV-BNK-SBSDRY-CO-ID-T (I)
                                      TO HOLD-BKSC  (I)
           END-PERFORM.

      ***** DESCRIPTIONS
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
016457*            MOVE MIR-DV-ACCT-DESC-TXT-T (I)
016457             MOVE MIR-ACCT-DESC-TXT-T (I)
                                      TO HOLD-DESC-LIN (I)
           END-PERFORM.

010418***** SUB COMPANY
           PERFORM
               VARYING I FROM 1 BY 1
013578        UNTIL   I > WS-TABLE-SIZE
013578*       UNTIL   I > 11
017484             IF  MIR-SBSDRY-CO-ID-T (I) = EBLCH-BLANK-FIELD-CHAR
017484                 MOVE  SPACES   TO MIR-SBSDRY-CO-ID-T (I)
017484             END-IF
010418*            MOVE MIR-LLOB-T (I)      TO HOLD-LOB-LIN (I)
010418             MOVE MIR-SBSDRY-CO-ID-T (I)
                                      TO HOLD-SC-LIN  (I)
           END-PERFORM.

      ***** BRANCH/DEPT
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
017484             IF  MIR-BR-OR-DEPT-ID-T (I) = EBLCH-BLANK-FIELD-CHAR
017484                 MOVE  SPACES   TO MIR-BR-OR-DEPT-ID-T (I)
017484             END-IF
                   MOVE MIR-BR-OR-DEPT-ID-T (I)
                                      TO HOLD-BRD-LIN (I)
           END-PERFORM.

      ***** ACCOUNT NUMBER BASE
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
                   MOVE MIR-ACCT-BASE-ID-T (I)
                                      TO HOLD-ACCT-LIN (I)
           END-PERFORM.

           INSPECT HOLD-ENTRY-AREAS REPLACING ALL LOW-VALUES BY SPACES.

       3000-MOVE-DATA-FROM-MAP-X.
           EXIT.


010418*------------------
010418 3050-CHECK-SUB-CO.
010418*------------------
010418
010418     IF HOLD-SC-LIN (I) NOT = WS-SBSDRY-CO-ID-USED
010418         SET WS-SBSDRY-CO-DIFF     TO TRUE
010418         MOVE 12                TO I
010418     END-IF.
010418
010418 3050-CHECK-SUB-CO-X.
010418     EXIT.


      /
      *-----------------------
       3100-SET-UP-OUTPUT-MAP.
      *-----------------------

016457*    MOVE HOLD-TDESC            TO MIR-DV-ACCT-DESC-TXT.
016457*    MOVE HOLD-VOUCHER          TO MIR-DV-CHQ-VCHR-NUM.
016457     MOVE HOLD-TDESC            TO MIR-ACCT-DESC-TXT.
016457     MOVE HOLD-VOUCHER          TO MIR-CHQ-VCHR-ID.

010418******SUB-COMPANY ID
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
010418*            MOVE HOLD-LOB-LIN (I)    TO MIR-LLOB-T (I)
010418             MOVE HOLD-SC-LIN  (I)
                                      TO MIR-SBSDRY-CO-ID-T  (I)
           END-PERFORM.

      *****BRANCH/DEPT
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
                   MOVE HOLD-BRD-LIN (I)
                                      TO MIR-BR-OR-DEPT-ID-T (I)
           END-PERFORM.

      *****ACCOUNT AMOUNTS LINE 5 TO 11
      ***** CREDIT AMOUNTS
      ***** DEBIT AMOUNTS
      *****ACCOUNT BASE
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
                   MOVE HOLD-ACCT-LIN (I)
                                      TO MIR-ACCT-BASE-ID-T (I)
           END-PERFORM.

      ***** DESCRIPTIONS
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
                   MOVE HOLD-DESC-LIN (I)
016457*                               TO MIR-DV-ACCT-DESC-TXT-T (I)
016457                                TO MIR-ACCT-DESC-TXT-T (I)
           END-PERFORM.

      *----------------------------------------------------------------
      *    OUTPUT MOVES FOR BANK NAMES
      *----------------------------------------------------------------
           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
                   MOVE HOLD-DESCBK (I)
                                      TO MIR-DV-BNK-ACCT-DESC-TXT-T (I)
           END-PERFORM.

      *----------------------------------------------------------------
      *    OUTPUT MOVES FOR ACCOUNT DESCRIPTION NAMES
      *----------------------------------------------------------------
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
016457*            MOVE HOLD-DESC (I) TO MIR-DV-SCRN-ACCT-DESC-TXT-T (I)
016457             MOVE HOLD-DESC (I) TO MIR-DV-ACCT-DESC-TXT-T (I)
           END-PERFORM.

      *----------------------------------------------------------------
      *    OUTPUT MOVES FOR  VALID BANK ACCOUNTS
      *----------------------------------------------------------------
           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
                   MOVE HOLD-BKACCT (I)
                                      TO MIR-DV-BNK-ACCT-BASE-ID-T (I)
           END-PERFORM.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
                   MOVE HOLD-BKBRD (I) TO MIR-DV-BNK-BR-OR-DEPT-ID-T (I)
           END-PERFORM.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
010418*            MOVE HOLD-BKLOB (I)  TO MIR-BKLOB-T (I)
010418             MOVE HOLD-BKSC  (I)  TO MIR-DV-BNK-SBSDRY-CO-ID-T (I)
           END-PERFORM.

       3100-SET-UP-OUTPUT-MAP-X.
           EXIT.
      /
      *----------------------
       3200-MOVE-AMOUNTS-MIR.
      *----------------------

      *****ACCOUNT AMOUNTS LINE 5 TO 11
           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
008455*        MOVE HOLD-BKAMT (I)      TO MIR-DV-ACCT-TRXN-AMT-T (I)
               MOVE 2                 TO L0280-PRECISION
               MOVE 'N'               TO L0280-SIGN-IND
008455         MOVE HOLD-BKAMT (I)    TO L0280-INPUT-DATA
016457*        MOVE LENGTH OF MIR-DV-ACCT-TRXN-AMT-T (I)
016457         MOVE LENGTH OF MIR-ACCT-TRXN-AMT-T (I)
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
008455         PERFORM  0280-1000-NUMERIC-EDIT
008455             THRU 0280-1000-NUMERIC-EDIT-X
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
016457*        MOVE LENGTH OF MIR-DV-ACCT-TRXN-AMT-T (I)
016457         MOVE LENGTH OF MIR-ACCT-TRXN-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY        TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
016457*        MOVE L0290-OUTPUT-DATA TO MIR-DV-ACCT-TRXN-AMT-T (I)
016457         MOVE L0290-OUTPUT-DATA TO MIR-ACCT-TRXN-AMT-T (I)
           END-PERFORM.

      ***** DEBIT AMOUNTS
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
                   MOVE 2             TO L0280-PRECISION
                   MOVE 'N'           TO L0280-SIGN-IND
008455             MOVE HOLD-DB (I)   TO L0280-INPUT-DATA
008455             MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (I)
                                      TO L0280-INPUT-SIZE
008455             COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
008455             PERFORM  0280-1000-NUMERIC-EDIT
008455                 THRU 0280-1000-NUMERIC-EDIT-X
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM  0290-2000-FORMAT-FOR-MIR
020874                 THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-TRNXT-DR-AMT-T (I)
                   MOVE 2             TO L0280-PRECISION
                   MOVE 'N'           TO L0280-SIGN-IND
008455             MOVE HOLD-CR (I)   TO L0280-INPUT-DATA
008455             MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (I)
                                      TO L0280-INPUT-SIZE
008455             COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
008455             PERFORM  0280-1000-NUMERIC-EDIT
008455                 THRU 0280-1000-NUMERIC-EDIT-X
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*              THRU  0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874               THRU  0290-2000-FORMAT-FOR-MIR-X 
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-TRNXT-CR-AMT-T (I)
           END-PERFORM.

       3200-MOVE-AMOUNTS-MIR-X.
           EXIT.
      /
      *---------------------
       9500-INIT-MIR-FIELDS.
      *---------------------

           MOVE LOW-VALUES            TO MIR-ACCT-BASE-ID-G.
010418     MOVE SPACES                TO MIR-SBSDRY-CO-ID-G.
           MOVE SPACES                TO MIR-BR-OR-DEPT-ID-G.
010418*    MOVE SPACES                     TO MIR-LLOB-TABLE.
016457*    MOVE SPACES                TO MIR-DV-ACCT-DESC-TXT-G.
016457     MOVE SPACES                TO MIR-ACCT-DESC-TXT-G.

016457*    MOVE SPACES                TO MIR-DV-ACCT-DESC-TXT.
016457*    MOVE SPACE                 TO MIR-DV-CHQ-VCHR-NUM.
016457     MOVE SPACES                TO MIR-ACCT-DESC-TXT.
016457     MOVE SPACE                 TO MIR-CHQ-VCHR-ID.
      *
      * CHANGE .00 TO 0.00 BELOW
      *
008455*    MOVE ZEROS                      TO EDIT-2
020874*    MOVE ZEROS                 TO L0290-INPUT-NUMBER
020874     MOVE ZEROS                 TO L0290-INPUT-V02
008455     MOVE 2                     TO L0290-PRECISION
008455     SET  L0290-SIGN-DISPLAY        TO TRUE
008455     MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X
008455
           PERFORM
               VARYING I FROM 1 BY 1
013578         UNTIL   I > WS-TABLE-SIZE
013578*        UNTIL   I > 11
008455*            MOVE EDIT-2        TO MIR-DV-TRNXT-DR-AMT-T (I)
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-TRNXT-DR-AMT-T (I)
                                         MIR-DV-TRNXT-CR-AMT-T (I)
                                         HOLD-CR   (I)
                                         HOLD-DB   (I)
           END-PERFORM.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > 4
008455*            MOVE EDIT-2        TO MIR-DV-ACCT-TRXN-AMT-T (I)
008455             MOVE L0290-OUTPUT-DATA
016457*                               TO MIR-DV-ACCT-TRXN-AMT-T (I)
016457                                TO MIR-ACCT-TRXN-AMT-T (I)
                                         HOLD-BKAMT  (I)
           END-PERFORM.

       9500-INIT-MIR-FIELDS-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5277-0000-INIT-PARM-INFO
025970         THRU 5277-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5860-0000-INIT-PARM-INFO
025970         THRU 5860-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-PGM-WORK-AREA.
025970
025970     INITIALIZE  MISC-WORK-AREAS.
025970
025970     MOVE SPACES TO  WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970
025970     SET HOLD-RUN-ID-DEFAULT         TO TRUE.
025970     SET ERROR-LINE-SCREEN-DEFAULT   TO TRUE.
025970     SET RPOL-PREV-FILE-MAINT-DT-DEF TO TRUE. 
025970 
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING MODULES                                   *
      *****************************************************************
025970 COPY CCPS5277.
       COPY CCPSPGA.
016457*COPY CCCL5200.
018764*COPY CCCL5277.
018764 COPY CCPL5277.
018764*COPY CCCL5860.
025970 COPY CCPS5860.
018764 COPY CCPL5860.
011925*COPY XCCL5480.
016537*COPY CCCL5480.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
008455 COPY XCPS0290.
011925*COPY XCPS5480.
016537*COPY CCPS5480.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNAC.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0241                     **
      *****************************************************************


