      *************************
       IDENTIFICATION DIVISION.
      *************************


       PROGRAM-ID. NSOM0210.


       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0210                                         **
      **  REMARKS:  PRRQ-PRINT REQUESTS FOR POLICY AND CLIENT        **
      **            DOCUMENTS. THE PRINT REQUEST TRANSACTION         **
      **            (PRRQ/DEMI) ALLOWS THE USER TO REQUEST A NUMBER  **
      **            OF POLICY CONTRACT DOCUMENTS, EITHER  AS A GROUP **
      **            OR INDIVIDUALLY, AND ALSO TO REQUEST MISCELLAN-  **
      **            EOUS POLICY AND CLIENTS DOCUMENTS INDIVIDUALLY.  **
      **            THE REQUESTS ARE WRITTEN TO THE PRTX FILE.       **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       REMOVE UNUSED COPYBOOK                           **
557693**  5.5       PERIODIC STATEMENT PRODUCTION                    **
557708**  5.5       ABEND HANDLING                                   **
007685**  5.6       ADD COST DISCLOSURE PRINT REQUEST                **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       STANDARDIZATION AND CODE CLEANUP                 **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016457**  6.2       MIN. # OF COPIES = 1                             **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0210'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

      *****************************
      * GENERAL WORKING STORAGE
      *****************************

025970*01  WS-PGM-ID-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'PRRQ'.
      *
      *
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ACTLOG        VALUE '0210'.
               88  WS-BUS-FCN-CLRCASE       VALUE '0211'.
               88  WS-BUS-FCN-CNFWKST       VALUE '0212'.
               88  WS-BUS-FCN-LABRSLT       VALUE '0213'.
               88  WS-BUS-FCN-PREDFND       VALUE '0214'.
               88  WS-BUS-FCN-PRTOTHR       VALUE '0215'.
               88  WS-BUS-FCN-REQT          VALUE '0216'.
               88  WS-BUS-FCN-POL-ONLY      VALUE '0214'.
               88  WS-BUS-FCN-CLI-ONLY      VALUE '0212' '0213' '0211'.
               88  WS-BUS-FCN-POL-OR-CLI    VALUE '0216' '0215' '0210'.
           05  WS-DOMAIN-SW                 PIC X(01).
               88  WS-DOMAIN-POLICY         VALUE 'P'.
               88  WS-DOMAIN-CLIENT         VALUE 'C'.
557693     05  WS-PER-STMT-SW               PIC X(01).
557693         88  WS-PER-STMT-YES          VALUE 'Y'.
557693         88  WS-PER-STMT-NO           VALUE 'N'.
           05  WS-COPIES                    PIC 99.
               88  WS-COPIES-VALID                     VALUE 1 THRU 99.
           05  WS-REQUIREMENT-ERROR-SW      PIC X(01).
               88  WS-REQUIREMENT-ERROR                VALUE 'Y'.
               88  WS-REQUIREMENT-NO-ERROR             VALUE 'N'.

           05  WS-SELECTION-ERROR-SW         PIC X(01).
               88  WS-SELECTION-ERROR                  VALUE 'Y'.
               88  WS-SELECTION-NO-ERROR               VALUE 'N'.
016548*    05  WS-MISC-DOCUMENT-CNTR         PIC S9(04) COMP.
016548     05  WS-MISC-DOCUMENT-CNTR         PIC S9(04) BINARY.
016548*    05  WS-SUB                        PIC S9(04) COMP.
016548     05  WS-SUB                        PIC S9(04) BINARY.
557693*    05  WS-SELECT-MAX                 PIC  99   VALUE 14.
007685*    05  WS-SELECT-MAX                 PIC  99   VALUE 15.
007685*    05  WS-SELECT-MAX                 PIC  99   VALUE 16.
025970*    05  WS-SELECT-MAX                 PIC  99   VALUE 17.
023447*    05  WS-TRNXT-DOC-CPY-QTY-X.
023447*        10  WS-TRNXT-DOC-CPY-QTY      PIC 9(02).

007685*    05  HOLD-RUN-ID                   PIC X(01)  VALUE '0'.

       01  WS-REQUIREMENT.
           05  WS-REQUIREMENT-CODE          PIC X(05)  VALUE SPACES.
           05  WS-SEQUENCE-NUMBER           PIC X(03)  VALUE SPACES.
           05  WS-SEQUENCE-NUMBER-9         REDEFINES
               WS-SEQUENCE-NUMBER           PIC 9(03).
           05  FILLER                       PIC X(02)  VALUE SPACES.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'PRRQ'.
025970     05  WS-SELECT-MAX                 PIC  99.
025970         88  WS-DEFAULT-SELECT-MAX               VALUE 17.

       COPY XCWEBLCH.
      *
      *****************************
      * WS PARAMETER AREA
      *****************************

028298 COPY CCWL2626.
557693 COPY NCWL0760.
      *
       COPY NCWL7080.
      *
       COPY NCWL7090.
      *
016457 COPY XCWL0280.
016457
557660*COPY CCWWCCON.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
       COPY CCFRPOL.
      *
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0210.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023118
023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     IF  MIR-CLI-ID = SPACE
028298         PERFORM  FPCK-1000-CHECK-POLICY
028298             THRU FPCK-1000-CHECK-POLICY-X
028298     ELSE
028298         PERFORM  FCCK-1000-CHECK-CLIENT
028298             THRU FCCK-1000-CHECK-CLIENT-X
028298     END-IF.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

      *****************************************************************
      *     CHECK SECURITY PERMISSION AND DISTRIBUTE CONTROL TO
      *     THE APPROPRIATE PROCESSING ROUTINE.
      *****************************************************************

025970     IF  MIR-POL-ID = EBLCH-BLANK-FIELD-CHAR
025970         MOVE SPACES            TO MIR-POL-ID
025970     END-IF.
025970
025970     IF  MIR-CLI-ID = EBLCH-BLANK-FIELD-CHAR
025970         MOVE SPACES        TO MIR-CLI-ID
025970     END-IF.
025970
025970     PERFORM  9300-SETUP-MSIN-REFERENCE
025970         THRU 9300-SETUP-MSIN-REFERENCE-X.
023118*
023118*    MOVE MIR-BUS-FCN-ID        TO  WS-BUS-FCN-ID.
023118*    SET WS-REQUIREMENT-NO-ERROR  TO  TRUE.
023118*    SET WS-SELECTION-NO-ERROR    TO  TRUE.

013578     PERFORM  2200-SET-RQST-IND
013578         THRU 2200-SET-RQST-IND-X.

           PERFORM  3000-DETERMINE-SELECTION
               THRU 3000-DETERMINE-SELECTION-X.

           PERFORM  3020-DETERMINE-FUNCTION-AREA
               THRU 3020-DETERMINE-FUNCTION-AREA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           IF  WS-BUS-FCN-POL-ONLY
           OR  (WS-BUS-FCN-POL-OR-CLI
                AND WS-DOMAIN-POLICY)
               PERFORM  7080-1000-BUILD-PARM-INFO
                   THRU 7080-1000-BUILD-PARM-INFO-X

               PERFORM  4000-BUILD-POL-RQSTS
                   THRU 4000-BUILD-POL-RQSTS-X

               MOVE MIR-POL-ID        TO L7080-POL-ID
               MOVE MIR-TRNXT-LANG-CD TO L7080-LANG-CD
               MOVE MIR-REQIR-ID      TO L7080-REQT-CD
               MOVE MIR-CPREQ-SEQ-NUM TO L7080-REQT-SEQ
               MOVE MIR-TRNXT-RPT-DSTRB-CD
                                      TO L7080-ROUTING
023447*        MOVE MIR-TRNXT-DOC-CPY-QTY
023447*                               TO L7080-COPY-QTY
               MOVE MIR-DOC-ID        TO L7080-DOC-NAME
557693         MOVE MIR-TRNXT-RQST-STRT-DT
                                      TO L7080-STRT-DT
557693         MOVE MIR-TRNXT-RQST-END-DT
                                      TO L7080-END-DT
023447         MOVE MIR-DV-RAPD-PRT-RQST-IND
023447                                TO L7080-DV-RAPD-PRT-RQST-IND
029060         MOVE MIR-TRNXT-TRXN-EFF-DT
029060                                TO L7080-TRNXT-TRXN-EFF-DT
029060         MOVE MIR-TRNXT-TRXN-SEQ-NUM
029060                                TO L7080-TRNXT-TRXN-SEQ-NUM

               PERFORM  7080-1000-GEN-POL-DOC
                   THRU 7080-1000-GEN-POL-DOC-X

               IF  L7080-RETRN-ERROR
                   PERFORM  5000-POL-ERROR-ATTRIBUTES
                       THRU 5000-POL-ERROR-ATTRIBUTES-X
                   GO TO 2000-PROCESS-REQUEST-X
557693         ELSE
015543             PERFORM  2100-PER-STMT-CHECK
015543                 THRU 2100-PER-STMT-CHECK-X
               END-IF
           END-IF.

           IF  WS-BUS-FCN-CLI-ONLY
           OR  (WS-BUS-FCN-POL-OR-CLI
                AND WS-DOMAIN-CLIENT)
               PERFORM  7090-1000-BUILD-PARM-INFO
                   THRU 7090-1000-BUILD-PARM-INFO-X

               PERFORM  4100-BUILD-CLI-RQST
                   THRU 4100-BUILD-CLI-RQST-X

               MOVE MIR-CLI-ID        TO L7090-CLI-ID
               MOVE MIR-TRNXT-LANG-CD TO L7090-LANG-CD
               MOVE MIR-REQIR-ID      TO L7090-REQT-CD
               MOVE MIR-CPREQ-SEQ-NUM TO L7090-REQT-SEQ
               MOVE MIR-TRNXT-RPT-DSTRB-CD
                                      TO L7090-ROUTING
               MOVE MIR-UWG-WRKSHT-NUM               TO L7090-WRKSHT-NUM
023447*        MOVE MIR-TRNXT-DOC-CPY-QTY
023447*                               TO L7090-COPY-QTY
               MOVE MIR-DOC-ID        TO L7090-DOC-NAME
023447         MOVE MIR-DV-RAPD-PRT-RQST-IND
023447                                TO L7090-DV-RAPD-PRT-RQST-IND

               PERFORM  7090-1000-GEN-CLI-DOC
                   THRU 7090-1000-GEN-CLI-DOC-X

               IF  L7090-RETRN-ERROR
                   PERFORM  5100-CLI-ERROR-ATTRIBUTES
                       THRU 5100-CLI-ERROR-ATTRIBUTES-X

                   GO TO 2000-PROCESS-REQUEST-X
               END-IF
           END-IF.


      *
      * RESET VALUES IF NO SELECTION ERRORS WERE DETECTED
      *

           IF  NOT WS-SELECTION-ERROR
               MOVE SPACES            TO MIR-POL-ID
               MOVE SPACES            TO MIR-CLI-ID
               MOVE SPACES            TO MIR-DOC-ID
               MOVE SPACES            TO MIR-TRNXT-LANG-CD
               MOVE SPACES            TO MIR-UWG-WRKSHT-NUM
               MOVE SPACES            TO MIR-REQIR-ID
               MOVE SPACES            TO MIR-CPREQ-SEQ-NUM
               MOVE SPACES            TO MIR-TRNXT-RPT-DSTRB-CD
016457*        MOVE SPACES            TO MIR-TRNXT-DOC-CPY-QTY
023447*        MOVE '01'              TO MIR-TRNXT-DOC-CPY-QTY
557693         MOVE SPACES            TO MIR-TRNXT-RQST-STRT-DT
557693         MOVE SPACES            TO MIR-TRNXT-RQST-END-DT
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
015543 2100-PER-STMT-CHECK.
015543
015543     IF WS-PER-STMT-YES
015543         INITIALIZE L0760-INPUT-PARM-INFO
015543         MOVE 'P'       TO L0760-POL-OR-CLI-TYPE
015543         MOVE MIR-POL-ID  TO L0760-POL-OR-CLI-ID
015543         MOVE 'PERST'   TO L0760-DAL-ACTIVITY
015543         MOVE 'REQ'     TO L0760-DAL-ACTION
015543         MOVE ZEROS     TO L0760-CVG-NUM
015543         MOVE MIR-TRNXT-RQST-STRT-DT
015543                        TO L0760-MESSAGE-PARMS (1)
015543         MOVE MIR-TRNXT-RQST-END-DT
015543                        TO L0760-MESSAGE-PARMS (2)
015543         MOVE SPACES    TO L0760-MESSAGE-NUMBER
015543         PERFORM  0760-1000-PROCESS-DAL-ENTRY
015543             THRU 0760-1000-PROCESS-DAL-ENTRY-X
015543     END-IF.
015543
015543 2100-PER-STMT-CHECK-X.
015543     EXIT.
      *
013578*------------------
013578 2200-SET-RQST-IND.
013578*------------------

           EVALUATE WS-BUS-FCN-ID
             WHEN '0211'
015904*        MOVE 'Y'         TO MIR-DV-CNTRCT-RQST-IND-T (10)
015904         MOVE 'Y'         TO MIR-DV-CCAS-RQST-IND
             WHEN '0212'
015904*        MOVE 'Y'         TO MIR-DV-CNTRCT-RQST-IND-T (11)
015904         MOVE 'Y'         TO MIR-DV-CNFD-RQST-IND
             WHEN '0210'
015904*        MOVE 'Y'         TO MIR-DV-CNTRCT-RQST-IND-T (12)
015904         MOVE 'Y'         TO MIR-DV-DAL-RQST-IND
             WHEN '0213'
015904*        MOVE 'Y'         TO MIR-DV-CNTRCT-RQST-IND-T (13)
015904         MOVE 'Y'         TO MIR-DV-LAB-RSLT-RQST-IND
             WHEN '0216'
015904*        MOVE 'Y'         TO MIR-DV-CNTRCT-RQST-IND-T (14)
015904         MOVE 'Y'         TO MIR-DV-CLI-REQIR-RQST-IND
           END-EVALUATE.

013578 2200-SET-RQST-IND-X.
           EXIT.

      *-------------------------
       3000-DETERMINE-SELECTION.
      *-------------------------

023447*    IF  MIR-TRNXT-DOC-CPY-QTY = SPACE
023447*        MOVE '01'                    TO MIR-TRNXT-DOC-CPY-QTY
023447*    ELSE
023447*        MOVE MIR-TRNXT-DOC-CPY-QTY   TO L0280-INPUT-DATA
023447*        MOVE LENGTH OF MIR-TRNXT-DOC-CPY-QTY
023447*                                     TO L0280-INPUT-SIZE
023447*        MOVE LENGTH OF MIR-TRNXT-DOC-CPY-QTY
023447*                                     TO L0280-LENGTH
023447*        SET L0280-SIGN-NOT-PERMITTED TO TRUE
023447*        MOVE ZERO                    TO L0280-PRECISION
023447*        PERFORM  0280-1000-NUMERIC-EDIT
023447*            THRU 0280-1000-NUMERIC-EDIT-X
023447*        IF  L0280-OK
023447*            MOVE L0280-OUTPUT-V00    TO WS-TRNXT-DOC-CPY-QTY
023447*            MOVE WS-TRNXT-DOC-CPY-QTY-X
023447*                                     TO MIR-TRNXT-DOC-CPY-QTY
023447*        ELSE
016457* MSG: 'INVALID NUMERIC FIELD'
023447*            MOVE 'XS00000018'      TO WGLOB-MSG-REF-INFO
023447*            PERFORM  0260-1000-GENERATE-MESSAGE
023447*                THRU 0260-1000-GENERATE-MESSAGE-X
023447*            GO TO 3000-DETERMINE-SELECTION-X
023447*        END-IF
023447*    END-IF.
      ******************************************************************
      *    COMPARE THE SELECTION OPTIONS AGAINST THE OTHER FIELDS
      *    ON THE SCREEN FOR CROSS-EDIT LIMITATIONS.
      *****************************************************************

      *
      *    VERIFY THAT AT LEAST ONE SELECTION OR A DOCUMENT NAME HAS
      *    BEEN ENTERED
      *
           IF  (MIR-DOC-ID = SPACES)
013578*        IF  (MIR-DV-CNTRCT-RQST-IND-T   (1) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T   (2) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T   (3) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T   (4) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T   (5) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T   (6) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T   (7) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T   (8) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T   (9) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T  (10) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T  (11) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T  (12) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T  (13) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T  (14) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T  (15) = SPACES)
013578*        AND (MIR-DV-CNTRCT-RQST-IND-T  (16) = SPACES)
015904*        IF  (MIR-DV-CNTRCT-RQST-IND-T   (1) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T   (2) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T   (3) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T   (4) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T   (5) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T   (6) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T   (7) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T   (8) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T   (9) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T  (10) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T  (11) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T  (12) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T  (13) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T  (14) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T  (15) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T  (16) = 'N')
015904*        AND (MIR-DV-CNTRCT-RQST-IND-T  (17) = 'N')
015904         IF  (MIR-DV-CNTRCT-RQST-IND         = 'N')
015904         AND (MIR-DV-POL-RQST-IND            = 'N')
015904         AND (MIR-DV-FP-RQST-IND             = 'N')
015904         AND (MIR-DV-PG-RQST-IND             = 'N')
015904         AND (MIR-DV-SUMM-RQST-IND           = 'N')
015904         AND (MIR-DV-STAT-RQST-IND           = 'N')
015904         AND (MIR-DV-AGT-RQST-IND            = 'N')
015904         AND (MIR-DV-AMEND-RQST-IND          = 'N')
015904         AND (MIR-DV-CCAS-RQST-IND           = 'N')
015904         AND (MIR-DV-CNFD-RQST-IND           = 'N')
015904         AND (MIR-DV-DAL-RQST-IND            = 'N')
015904         AND (MIR-DV-LAB-RSLT-RQST-IND       = 'N')
015904         AND (MIR-DV-CLI-REQIR-RQST-IND      = 'N')
015904         AND (MIR-DV-PERI-RQST-IND           = 'N')
015904         AND (MIR-DV-COST-RQST-IND           = 'N')
015904         AND (MIR-DV-ANN-STMT-RQST-IND       = 'N')

      *MSG: MUST MAKE SELECTION OR ENTER DOCUMENT NA....
                   MOVE 'NS02100001'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3000-DETERMINE-SELECTION-X
               END-IF
           END-IF.

      *
      *    VERIFY THAT A VALID PRINT SELECTION HAS BEEN CHOSEN
      *

           PERFORM  3010-SELECTION-ERROR-MESSAGE
               THRU 3010-SELECTION-ERROR-MESSAGE-X
015904*        VARYING WS-SUB FROM 1 BY 1
015904*        UNTIL WS-SUB > WS-SELECT-MAX.

      *
      *    IF CONTRACT REQUEST(S) HAVE BEEN SELECTED, NO DOCUMENT SHOULD
      *    HAVE BEEN ENTERED OR MISCELLANEOUS REQUEST HAVE BEEN SELECTED
      *

013578*    IF ((MIR-DV-CNTRCT-RQST-IND-T (1) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (2) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (3) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (4) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (5) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (6) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (7) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (8) NOT = SPACES)
557693*    OR  (MIR-DV-CNTRCT-RQST-IND-T (9) NOT = SPACES))
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (9) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (15) NOT = SPACES)
013578*    OR  (MIR-DV-CNTRCT-RQST-IND-T (16) NOT = SPACES))
015904*    IF ((MIR-DV-CNTRCT-RQST-IND-T (1) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (2) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (3) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (4) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (5) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (6) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (7) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (8) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (9) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (15) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (16) NOT = 'N')
015904*    OR  (MIR-DV-CNTRCT-RQST-IND-T (17) NOT = 'N'))
015904     IF ((MIR-DV-CNTRCT-RQST-IND       NOT = 'N')
015904     OR  (MIR-DV-POL-RQST-IND          NOT = 'N')
015904     OR  (MIR-DV-FP-RQST-IND           NOT = 'N')
015904     OR  (MIR-DV-PG-RQST-IND           NOT = 'N')
015904     OR  (MIR-DV-SUMM-RQST-IND         NOT = 'N')
015904     OR  (MIR-DV-STAT-RQST-IND         NOT = 'N')
015904     OR  (MIR-DV-AGT-RQST-IND          NOT = 'N')
015904     OR  (MIR-DV-AMEND-RQST-IND        NOT = 'N')
015904     OR  (MIR-DV-PERI-RQST-IND         NOT = 'N')
015904     OR  (MIR-DV-COST-RQST-IND         NOT = 'N')
015904     OR  (MIR-DV-ANN-STMT-RQST-IND     NOT = 'N'))

               PERFORM  3001-SCRIN-T
                   THRU 3001-SCRIN-T-X

               GO TO 3000-DETERMINE-SELECTION-X
           END-IF.

      *
      *    ONLY ONE MISCELLANEOUS REQUEST MAY BE SELECTED
      *
           MOVE ZEROS                 TO  WS-MISC-DOCUMENT-CNTR.

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (10) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (10) NOT = 'N'
015904     IF  MIR-DV-CCAS-RQST-IND          NOT = 'N'
               ADD +1          TO  WS-MISC-DOCUMENT-CNTR
           END-IF.


013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (11) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (11) NOT = 'N'
015904     IF  MIR-DV-CNFD-RQST-IND          NOT = 'N'
               ADD +1          TO  WS-MISC-DOCUMENT-CNTR
           END-IF.

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (12) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (12) NOT = 'N'
015904     IF  MIR-DV-DAL-RQST-IND           NOT = 'N'
               ADD +1          TO  WS-MISC-DOCUMENT-CNTR
           END-IF.

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (13) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (13) NOT = 'N'
015904     IF  MIR-DV-LAB-RSLT-RQST-IND      NOT = 'N'
               ADD +1          TO  WS-MISC-DOCUMENT-CNTR
           END-IF.

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (14) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (14) NOT = 'N'
015904     IF  MIR-DV-CLI-REQIR-RQST-IND     NOT = 'N'
               ADD +1          TO  WS-MISC-DOCUMENT-CNTR
           END-IF.

           IF  WS-MISC-DOCUMENT-CNTR > +1
      *MSG: SELECT ONLY 1 MISC DOCUMENT AT A TIME
                   MOVE 'NS02100014'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3000-DETERMINE-SELECTION-X
           END-IF.


      *
      *    A MISCELLANEOUS REQUEST REQUIRES THAT A DOCUMENT HAS BEEN
      *    ENTERED
      *

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (10) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (10) NOT = 'N'
015904     IF  MIR-DV-CCAS-RQST-IND          NOT = 'N'
               IF  MIR-DOC-ID        = SPACES
      *MSG: MISCELLANEOUS REQUEST REQUIRES DOCUMENT
                   MOVE 'NS02100013'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3000-DETERMINE-SELECTION-X
               ELSE
                   SET WS-BUS-FCN-CLRCASE      TO TRUE
                   GO TO 3000-DETERMINE-SELECTION-X
               END-IF
           END-IF.

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (11) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (11) NOT = 'N'
015904     IF  MIR-DV-CNFD-RQST-IND          NOT = 'N'
               IF  MIR-DOC-ID         = SPACES
      *MSG: MISCELLANEOUS REQUEST REQUIRES DOCUMENT
                   MOVE 'NS02100013'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3000-DETERMINE-SELECTION-X
               ELSE
                   SET WS-BUS-FCN-CNFWKST      TO TRUE
                   GO TO 3000-DETERMINE-SELECTION-X
               END-IF
           END-IF.

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (12) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (12) NOT = 'N'
015904     IF  MIR-DV-DAL-RQST-IND           NOT = 'N'
               IF  MIR-DOC-ID        = SPACES
      *MSG: MISCELLANEOUS REQUEST REQUIRES DOCUMENT
                   MOVE 'NS02100013'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3000-DETERMINE-SELECTION-X
               ELSE
                   SET WS-BUS-FCN-ACTLOG       TO TRUE
                   GO TO 3000-DETERMINE-SELECTION-X
               END-IF
           END-IF.

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (13) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (13) NOT = 'N'
015904     IF  MIR-DV-LAB-RSLT-RQST-IND      NOT = 'N'
               IF  MIR-DOC-ID        = SPACES
      *MSG: MISCELLANEOUS REQUEST REQUIRES DOCUMENT
                   MOVE 'NS02100013'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3000-DETERMINE-SELECTION-X
               ELSE
                   SET WS-BUS-FCN-LABRSLT        TO TRUE
                   GO TO 3000-DETERMINE-SELECTION-X
               END-IF
           END-IF.

013578*    IF  MIR-DV-CNTRCT-RQST-IND-T (14) NOT = SPACES
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (14) NOT = 'N'
015904     IF  MIR-DV-CLI-REQIR-RQST-IND     NOT = 'N'
               IF  MIR-DOC-ID        = SPACES
      *MSG: MISCELLANEOUS REQUEST REQUIRES DOCUMENT
                   MOVE 'NS02100013'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3000-DETERMINE-SELECTION-X
               ELSE
                   SET WS-BUS-FCN-REQT           TO TRUE
                   GO TO 3000-DETERMINE-SELECTION-X
               END-IF
           END-IF.

           IF  NOT (MIR-DOC-ID = SPACES)
               SET WS-BUS-FCN-PRTOTHR           TO TRUE
           END-IF.

       3000-DETERMINE-SELECTION-X.
           EXIT.
      *
      *-------------
       3001-SCRIN-T.
      *-------------

           IF  (MIR-DOC-ID NOT = SPACES)
      *MSG: DOCUMENT NAME NOT ALLOWED FOR CONTRACT R....
               MOVE 'NS02100002'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           ELSE

013578*        IF  (MIR-DV-CNTRCT-RQST-IND-T (10) NOT = SPACES)
013578*        OR  (MIR-DV-CNTRCT-RQST-IND-T (11) NOT = SPACES)
013578*        OR  (MIR-DV-CNTRCT-RQST-IND-T (12) NOT = SPACES)
013578*        OR  (MIR-DV-CNTRCT-RQST-IND-T (13) NOT = SPACES)
013578*        OR  (MIR-DV-CNTRCT-RQST-IND-T (14) NOT = SPACES)
015904*        IF  (MIR-DV-CNTRCT-RQST-IND-T (10) NOT = 'N')
015904*        OR  (MIR-DV-CNTRCT-RQST-IND-T (11) NOT = 'N')
015904*        OR  (MIR-DV-CNTRCT-RQST-IND-T (12) NOT = 'N')
015904*        OR  (MIR-DV-CNTRCT-RQST-IND-T (13) NOT = 'N')
015904*        OR  (MIR-DV-CNTRCT-RQST-IND-T (14) NOT = 'N')
015904         IF  (MIR-DV-CCAS-RQST-IND          NOT = 'N')
015904         OR  (MIR-DV-CNFD-RQST-IND          NOT = 'N')
015904         OR  (MIR-DV-DAL-RQST-IND           NOT = 'N')
015904         OR  (MIR-DV-LAB-RSLT-RQST-IND      NOT = 'N')
015904         OR  (MIR-DV-CLI-REQIR-RQST-IND     NOT = 'N')

      *MSG: SELECT CONTRACT REQUESTS ONLY
      *                             OR MISCELLANEOUS REQUEST ONLY
                   MOVE 'NS02100011'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               ELSE
                   SET WS-BUS-FCN-PREDFND  TO TRUE
               END-IF
           END-IF.

       3001-SCRIN-T-X.
           EXIT.

      *
      *-----------------------------
       3010-SELECTION-ERROR-MESSAGE.
      *-----------------------------

013578*    IF  (MIR-DV-CNTRCT-RQST-IND-T (WS-SUB) NOT =  SPACES)
015904*    IF  (MIR-DV-CNTRCT-RQST-IND-T (WS-SUB) NOT =  'N')
015904*    AND (MIR-DV-CNTRCT-RQST-IND-T (WS-SUB) NOT =  'Y')
015904     IF  ((MIR-DV-CNTRCT-RQST-IND           NOT =  'N')
015904     AND  (MIR-DV-CNTRCT-RQST-IND           NOT =  'Y'))
015904     OR  ((MIR-DV-POL-RQST-IND              NOT =  'N')
015904     AND  (MIR-DV-POL-RQST-IND              NOT =  'Y'))
015904     OR  ((MIR-DV-FP-RQST-IND               NOT =  'N')
015904     AND  (MIR-DV-FP-RQST-IND               NOT =  'Y'))
015904     OR  ((MIR-DV-PG-RQST-IND               NOT =  'N')
015904     AND  (MIR-DV-PG-RQST-IND               NOT =  'Y'))
015904     OR  ((MIR-DV-SUMM-RQST-IND             NOT =  'N')
015904     AND  (MIR-DV-SUMM-RQST-IND             NOT =  'Y'))
015904     OR  ((MIR-DV-STAT-RQST-IND             NOT =  'N')
015904     AND  (MIR-DV-STAT-RQST-IND             NOT =  'Y'))
015904     OR  ((MIR-DV-AGT-RQST-IND              NOT =  'N')
015904     AND  (MIR-DV-AGT-RQST-IND              NOT =  'Y'))
015904     OR  ((MIR-DV-AMEND-RQST-IND            NOT =  'N')
015904     AND  (MIR-DV-AMEND-RQST-IND            NOT =  'Y'))
015904     OR  ((MIR-DV-CCAS-RQST-IND             NOT =  'N')
015904     AND  (MIR-DV-CCAS-RQST-IND             NOT =  'Y'))
015904     OR  ((MIR-DV-CNFD-RQST-IND             NOT =  'N')
015904     AND  (MIR-DV-CNFD-RQST-IND             NOT =  'Y'))
015904     OR  ((MIR-DV-DAL-RQST-IND              NOT =  'N')
015904     AND  (MIR-DV-DAL-RQST-IND              NOT =  'Y'))
015904     OR  ((MIR-DV-LAB-RSLT-RQST-IND         NOT =  'N')
015904     AND  (MIR-DV-LAB-RSLT-RQST-IND         NOT =  'Y'))
015904     OR  ((MIR-DV-CLI-REQIR-RQST-IND        NOT =  'N')
015904     AND  (MIR-DV-CLI-REQIR-RQST-IND        NOT =  'Y'))
015904     OR  ((MIR-DV-PERI-RQST-IND             NOT =  'N')
015904     AND  (MIR-DV-PERI-RQST-IND             NOT =  'Y'))
015904     OR  ((MIR-DV-COST-RQST-IND             NOT =  'N')
015904     AND  (MIR-DV-COST-RQST-IND             NOT =  'Y'))
015904     OR  ((MIR-DV-ANN-STMT-RQST-IND         NOT =  'N')
015904     AND  (MIR-DV-ANN-STMT-RQST-IND         NOT =  'Y'))

               SET WS-SELECTION-ERROR       TO TRUE
      *MSG:  'Y' AND 'N' ARE THE ONLY VALID PRINT SECECTIONS
               MOVE 'NS02100023'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3010-SELECTION-ERROR-MESSAGE-X.
           EXIT.
      *
      *-----------------------------
       3020-DETERMINE-FUNCTION-AREA.
      *-----------------------------

      *************************************************************
      *    DETERMINE WHICH FUNCTIONAL AREA THAT WILL BE PROCESSING
      *************************************************************

           IF  MIR-POL-ID > SPACES
           AND MIR-CLI-ID > SPACES
      *MSG: ENTER POLICY OR CLIENT NUMBER ONLY
               MOVE 'NS02100016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3020-DETERMINE-FUNCTION-AREA-X
           END-IF.

           IF  WS-BUS-FCN-PREDFND
           AND MIR-POL-ID = SPACES
      *MSG: POLCIY NUMBER REQUIRED
               MOVE 'NS02100003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 3020-DETERMINE-FUNCTION-AREA-X
           END-IF.

           IF  (WS-BUS-FCN-CNFWKST
           OR  WS-BUS-FCN-LABRSLT
           OR  WS-BUS-FCN-CLRCASE)
           AND MIR-CLI-ID = SPACES

      *MSG: CLIENT NUMBER REQUIRED
               MOVE 'NS02100020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 3020-DETERMINE-FUNCTION-AREA-X
           END-IF.

           IF  (WS-BUS-FCN-REQT
           OR  WS-BUS-FCN-PRTOTHR
           OR  WS-BUS-FCN-ACTLOG)
               IF  MIR-CLI-ID = SPACES
               AND MIR-POL-ID = SPACES
      *MSG: POLICY NUMBER OR CLIENT NUMBER REQUIRED
                   MOVE 'NS02100015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

                   GO TO 3020-DETERMINE-FUNCTION-AREA-X
               END-IF
           END-IF.

           IF  WS-BUS-FCN-POL-OR-CLI
               IF  MIR-POL-ID > SPACES
                   SET WS-DOMAIN-POLICY        TO TRUE
               ELSE
                   SET WS-DOMAIN-CLIENT        TO TRUE
               END-IF
           END-IF.

       3020-DETERMINE-FUNCTION-AREA-X.
           EXIT.

      *
      *---------------------
       4000-BUILD-POL-RQSTS.
      *---------------------

      *
      *    THERE CAN BE MULTIPLE CONTRACT DOCUMENT REQUESTS. HOWEVER
      *    THESE CANNOT BE COMBINED WITH MISCELLANEOUS REQUESTS, SO
      *    EXIT AFTER PROCESSING ANY CONTRACT DOCUMENT REQUESTS.
      *


           IF  WS-BUS-FCN-PREDFND
               SET L7080-POL-RQST-CONTRACT   TO TRUE
               MOVE ZERO              TO WS-SUB
               PERFORM  4010-POL-RQST-TABLE
                   THRU 4010-POL-RQST-TABLE-X

               GO TO 4000-BUILD-POL-RQSTS-X
           END-IF.

      *
      *    ONLY ONE MISCELLANEOUS REQUEST MAY BE PROCESSED AT A TIME
      *    THEREFORE, AS SOON AS WE FIND ONE TO PROCESS, EXIT THE
      *    PARAGRAPH.
      *

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (12) = 'Y'
015904     IF  MIR-DV-DAL-RQST-IND           = 'Y'

      *
      *    DIARY ACTIVITY LOG
      *

               SET L7080-POL-RQST-DIARY-ACT-LOG  TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (12)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (12)
015904         MOVE 'N'               TO MIR-DV-DAL-RQST-IND
               GO TO 4000-BUILD-POL-RQSTS-X
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (14) = 'Y'
015904     IF  MIR-DV-CLI-REQIR-RQST-IND     = 'Y'

      *
      *    POLICY REQUIREMENTS
      *

               SET L7080-POL-RQST-REQUIREMENTS   TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (14)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (14)
015904         MOVE 'N'               TO MIR-DV-CLI-REQIR-RQST-IND
               GO TO 4000-BUILD-POL-RQSTS-X
           END-IF.

           IF  NOT (MIR-DOC-ID = SPACE)

      *
      *    MISCELLANEOUS DOCUMENT SELECTED
      *

               SET L7080-POL-RQST-MISC-DOCUMENT  TO TRUE
               GO TO 4000-BUILD-POL-RQSTS-X
           END-IF.

       4000-BUILD-POL-RQSTS-X.
           EXIT.
      *
      *--------------------
       4010-POL-RQST-TABLE.
      *--------------------

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (1) = 'Y'
015904     IF  MIR-DV-CNTRCT-RQST-IND       = 'Y'

      *
      *    ALL DOCUMENTS SELECTED
      *

               ADD +1                               TO WS-SUB
               SET L7080-POL-RQST-ALL-DOCS (WS-SUB) TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (1)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (1)
015904         MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (2) = 'Y'
015904     IF  MIR-DV-POL-RQST-IND          = 'Y'

      *
      *    ENTIRE POLICY SELECTED
      *

               ADD +1                               TO WS-SUB
               SET L7080-POL-RQST-ENTIRE-CNTRCT (WS-SUB)
                                      TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (2)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (2)
015904         MOVE 'N'               TO MIR-DV-POL-RQST-IND
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (3) = 'Y'
015904     IF  MIR-DV-FP-RQST-IND           = 'Y'

      *
      *    FACE PAGE ONLY SELECTED
      *

               ADD +1                               TO WS-SUB
               SET L7080-POL-RQST-FACE-PAGE (WS-SUB)
                                      TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (3)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (3)
015904         MOVE 'N'               TO MIR-DV-FP-RQST-IND
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (4) = 'Y'
015904     IF  MIR-DV-PG-RQST-IND           = 'Y'

      *
      *    CONTRACT PAGE ONLY SELECTED
      *

               ADD +1                               TO WS-SUB
               SET L7080-POL-RQST-CNTRCT-PAGE (WS-SUB)
                                      TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (4)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (4)
015904         MOVE 'N'               TO MIR-DV-PG-RQST-IND
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (5) = 'Y'

      *
      *    AGENT CARD SELECTED
      *

015904*        ADD +1                               TO WS-SUB
015904*        SET L7080-POL-RQST-AGENT-CARD (WS-SUB)
015904*                               TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (5)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (5)
015904*    END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (6) = 'Y'
015904     IF  MIR-DV-SUMM-RQST-IND         = 'Y'

      *
      *    POLICY SUMMARY SELECTED
      *

               ADD +1                               TO WS-SUB
               SET L7080-POL-RQST-POL-SUMMARY (WS-SUB)
                                      TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (6)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (6)
015904         MOVE 'N'               TO MIR-DV-SUMM-RQST-IND
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (7) = 'Y'
015904     IF  MIR-DV-STAT-RQST-IND         = 'Y'

      *
      *    POLICY STATUS SELECTED
      *

               ADD +1                               TO WS-SUB
               SET L7080-POL-RQST-POL-STATUS (WS-SUB)
                                      TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (7)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (7)
015904         MOVE 'N'               TO MIR-DV-STAT-RQST-IND
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (8) = 'Y'
015904     IF  MIR-DV-AGT-RQST-IND          = 'Y'

      *
      *    AGENT INVOICE SELECTED
      *

               ADD +1                               TO WS-SUB
               SET L7080-POL-RQST-AGENT-INVOICE (WS-SUB)
                                      TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (8)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (8)
015904         MOVE 'N'               TO MIR-DV-AGT-RQST-IND
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (9) = 'Y'
015904     IF  MIR-DV-AMEND-RQST-IND        = 'Y'

      *
      *    POLICY AMENDMENTS SELECTED
      *

               ADD +1                               TO WS-SUB
               SET L7080-POL-RQST-AMENDMENTS (WS-SUB)
                                      TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (9)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (9)
015904         MOVE 'N'               TO MIR-DV-AMEND-RQST-IND
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (15) = 'Y'
015904     IF  MIR-DV-PERI-RQST-IND          = 'Y'
557693
557693*
557693*    PERIODIC STATEMENTS SELECTED
557693*
557693
557693         ADD +1                               TO WS-SUB
557693         SET L7080-POL-RQST-PER-STMT (WS-SUB) TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (15)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (15)
015904         MOVE 'N'               TO MIR-DV-PERI-RQST-IND
557693         SET WS-PER-STMT-YES                  TO TRUE
557693     ELSE
557693         SET WS-PER-STMT-NO                   TO TRUE
557693     END-IF.
557693
007685
007685*
007685*    COST DISCLOSURE SELECTED
007685*
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (16) = 'Y'
015904     IF  MIR-DV-COST-RQST-IND          = 'Y'
007685         ADD +1                               TO WS-SUB
007685         SET L7080-POL-RQST-COST-DISCLOSE (WS-SUB) TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (16)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (16)
015904         MOVE 'N'               TO MIR-DV-COST-RQST-IND
007685     END-IF.
007685
013578*
013578*    ANNUAL STATEMENT SELECTED
013578*
015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (17) = 'Y'
015904     IF  MIR-DV-ANN-STMT-RQST-IND      = 'Y'
013578         ADD +1                               TO WS-SUB
013578         SET L7080-POL-RQST-ANNUAL-STMT (WS-SUB) TO TRUE
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (17)
015904         MOVE 'N'               TO MIR-DV-ANN-STMT-RQST-IND
013578     END-IF.
013578
       4010-POL-RQST-TABLE-X.
           EXIT.

      *
      *--------------------
       4100-BUILD-CLI-RQST.
      *--------------------

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (10) = 'Y'
015904     IF  MIR-DV-CCAS-RQST-IND          = 'Y'

      *
      *    CLEAR CASE KICKOUT SELECTED
      *

               SET L7090-CLI-RQST-CLEAR-CASE-KO   TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (10)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (10)
015904         MOVE 'N'               TO MIR-DV-CCAS-RQST-IND
               GO TO 4100-BUILD-CLI-RQST-X
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (11) = 'Y'
015904     IF  MIR-DV-CNFD-RQST-IND          = 'Y'

      *
      *    CONFIDENTIAL WORKSHEET
      *

               SET L7090-CLI-RQST-UW-CON-WRKSHT   TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (11)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (11)
015904         MOVE 'N'               TO MIR-DV-CNFD-RQST-IND
               GO TO 4100-BUILD-CLI-RQST-X
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (12) = 'Y'
015904     IF  MIR-DV-DAL-RQST-IND           = 'Y'

      *
      *    DIARY ACTIVITY LOG
      *

               SET L7090-CLI-RQST-DIARY-ACT-LOG   TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (12)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (12)
015904         MOVE 'N'               TO MIR-DV-DAL-RQST-IND
               GO TO 4100-BUILD-CLI-RQST-X
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (13) = 'Y'
015904     IF  MIR-DV-LAB-RSLT-RQST-IND      = 'Y'

      *
      *    LAB RESULTS
      *

               SET L7090-CLI-RQST-LAB-RESULTS     TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (13)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (13)
015904         MOVE 'N'               TO MIR-DV-LAB-RSLT-RQST-IND
               GO TO 4100-BUILD-CLI-RQST-X
           END-IF.

015904*    IF  MIR-DV-CNTRCT-RQST-IND-T (14) = 'Y'
015904     IF  MIR-DV-CLI-REQIR-RQST-IND     = 'Y'

      *
      *    CLIENT REQUIREMENTS
      *

               SET L7090-CLI-RQST-REQUIREMENTS    TO TRUE
013578*        MOVE SPACES            TO MIR-DV-CNTRCT-RQST-IND-T (14)
015904*        MOVE 'N'               TO MIR-DV-CNTRCT-RQST-IND-T (14)
015904         MOVE 'N'               TO MIR-DV-CLI-REQIR-RQST-IND
               GO TO 4100-BUILD-CLI-RQST-X
           END-IF.

           IF  NOT (MIR-DOC-ID = SPACES)

      *
      *    MISCELLANEOUS DOCUMENT SELECTED
      *

               SET L7090-CLI-RQST-MISC-DOCUMENT   TO TRUE
               GO TO 4100-BUILD-CLI-RQST-X
           END-IF.


       4100-BUILD-CLI-RQST-X.
           EXIT.
      *
      *--------------------------
       5000-POL-ERROR-ATTRIBUTES.
      *--------------------------

      *
      *    VALIDATION OF THE L7080-NNNN FIELDS
      *

           IF  L7080-POL-ID = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR     TO TRUE
           END-IF.

           IF  L7080-LANG-CD = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR     TO TRUE
           END-IF.

           IF  L7080-REQT-CD = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR     TO TRUE
           END-IF.

           IF  L7080-REQT-SEQ = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR     TO TRUE
           END-IF.

           IF  L7080-ROUTING = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR     TO TRUE
           END-IF.

023447*    IF  L7080-COPY-QTY = HIGH-VALUES
023447*        SET WS-REQUIREMENT-ERROR     TO TRUE
023447*    END-IF.

           IF  L7080-DOC-NAME = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR     TO TRUE
           END-IF.

557693     IF  L7080-STRT-DT  = HIGH-VALUES
557693         SET WS-REQUIREMENT-ERROR     TO TRUE
557693     END-IF.
557693
557693     IF  L7080-END-DT  = HIGH-VALUES
557693         SET WS-REQUIREMENT-ERROR     TO TRUE
557693     END-IF.
557693
       5000-POL-ERROR-ATTRIBUTES-X.
           EXIT.
      *
      *--------------------------
       5100-CLI-ERROR-ATTRIBUTES.
      *--------------------------

           IF  L7090-CLI-ID = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR      TO TRUE
           END-IF.

           IF  L7090-LANG-CD = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR      TO TRUE
           END-IF.

           IF  L7090-WRKSHT-NUM = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR      TO TRUE
           END-IF.

           IF  L7090-REQT-CD = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR      TO TRUE
           END-IF.

           IF  L7090-REQT-SEQ = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR      TO TRUE
           END-IF.

           IF  L7090-ROUTING = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR      TO TRUE
           END-IF.

023447*    IF  L7090-COPY-QTY = HIGH-VALUES
023447*        SET WS-REQUIREMENT-ERROR      TO TRUE
023447*    END-IF.

           IF  L7090-DOC-NAME = HIGH-VALUES
               SET WS-REQUIREMENT-ERROR      TO TRUE
           END-IF.

       5100-CLI-ERROR-ATTRIBUTES-X.
           EXIT.

      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

      *****************************************************************
      *    MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS BEING
      *    WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU
      *    PROCESSING.
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023118/
023118*--------------------------
023118 9990-INIT-WORKING-STORAGE.
023118*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0760-0000-INIT-PARM-INFO
025970         THRU 0760-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  7080-0000-INIT-PARM-INFO
025970         THRU 7080-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7090-0000-INIT-PARM-INFO
025970         THRU 7090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                        WS-PGM-WORK-AREA.
025970     INITIALIZE                        WS-REQUIREMENT.
025970
025970*    IF  MIR-POL-ID = EBLCH-BLANK-FIELD-CHAR
025970*        MOVE SPACES            TO MIR-POL-ID
025970*    END-IF.
025970*
025970*    IF  MIR-CLI-ID = EBLCH-BLANK-FIELD-CHAR
025970*        MOVE SPACES        TO MIR-CLI-ID
025970*    END-IF.
025970*
025970*    PERFORM  9300-SETUP-MSIN-REFERENCE
025970*        THRU 9300-SETUP-MSIN-REFERENCE-X.
023118
025970     SET WS-DEFAULT-TRANS-NAME         TO TRUE.
025970     SET WS-DEFAULT-SELECT-MAX         TO TRUE.
023118     SET WS-REQUIREMENT-NO-ERROR       TO TRUE.
023118     SET WS-SELECTION-NO-ERROR         TO TRUE.
023118
023118     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.
      *
      ****************************************************************
      *    PROCESSING COPYBOOKS
      ****************************************************************

028298 COPY CCPPFCCK.
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY CCPSPGA.
      *
       COPY XCPPEXIT.
      *
       COPY XCPPINIT.
      *
      ****************************************************************
      *    LINK COPYBOOKS
      ****************************************************************

018764*COPY NCCL0760.
025970 COPY NCPS0760.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY NCPL0760.
      *
       COPY NCPS7080.
      *
018764*COPY NCCL7080.
018764 COPY NCPL7080.
      *
       COPY NCPS7090.
      *
018764*COPY NCCL7090.
018764 COPY NCPL7090.
      *
025970 COPY XCPS0280.
016457 COPY XCPL0280.
018763*COPY XCPL0030.
018763 COPY XCCP0030.

      *
      ****************************************************************
      *    MESSAGE COPYBOOKS
      ****************************************************************
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
      *****************************************************************
      *    ERROR HANDLING MODULES
      *****************************************************************

557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *

      *****************************************************************
      **                 END OF PROGRAM NSOM0210                     **
      *****************************************************************
