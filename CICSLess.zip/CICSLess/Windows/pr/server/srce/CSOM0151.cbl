      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. CSOM0151.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  CSOM0151                                         **
      **  REMARKS:  PPOL - PROTECTED POLICY MAINTENANCE.             **
      **            THIS PROCESS DRIVER IS USED TO UPDATE FINANCIAL  **
      **            BALANCES AND SYSTEM CONTROL FIELDS ON THE POL    **
      **            TABLE. LOAN INFORMATION STORED ON THE POLL TABLE **
      **            IS ALSO UPDATED.                                 **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557665**  5.5       ENHANCEMENT TO INGENIUM SCHEDULER                **
557668**  5.5       SELECTION LIST                                   **
557697**  5.5       SPECIAL FREQUENCY BILLING                        **
557699**  5.5       AUDIT FACILITY                                   **
557708**  5.5       ABEND HANDLING                                   **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557788**  5.5       POLICY TABLE SPLIT                               **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       DATA CLEANUP                                     **
010397**  5.6       CREATE SCREEN 3,ADD NEW FIELDS TO SCREEN 3       **
010397**            & DUPLICATE THE LOAN INFO. FROM SC1 TO SC3       **
010418**  5.6       ADD SUB-COMPANY-CODE FIELD                       **
006002**  6.0       NEW COUNTRY LOCATION TABLE                       **
013578**  6.0       REMOVE 3270 LOGIC, MIR RENAMES                   **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
012181**  6.2       FIELD RENAME - DIV-DCLR-DUR-AMT                  **
014221**  6.2       LOGICAL LOCKING                                  **
016395**  6.2       CREDIT CARD BILLING                              **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016109**  6.3       FREE FUND TRANSFERS (6.1.2J)                     **
016641**  6.3       EXTENSIVE NUMERIC FORMATTING                     **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018842**  6.3       NET LOAN PROCESSSING                             **
018845**  6.3       SURRENDER VALUE LAPSE                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020074**  6.4       ALLOWED VALUE FOR POL STATUS                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020455**  6.4       UNIT PRICE CORRECTION                            **
021239**  6.4       FUND UNIT VALUE                                  **
020452**  6.4       FOREIGN CONTENT FOR RRSP PRODUCTS                **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0151'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
007766 COPY XCWWCVGM.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE          VALUE '0150'.
               88  WS-BUS-FCN-UPDATE            VALUE '0152'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                         VALUE '0150'.
           05  WS-ERROR-SW                  PIC X.
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-ERROR-NOT-FOUND       VALUE 'N'.
           05  PRINT-ERROR-SW               PIC 9.
           05  UPDATE-SW                    PIC X.
               88  NO-UPDATE                VALUE 'N'.
               88  UPDATE-REQUIRED          VALUE 'Y'.
557788     05  WS-REGC-OWNER-UPDT           PIC X.
557788         88  WS-REGC-OWNER-NO-UPDT    VALUE 'N'.
557788         88  WS-REGC-OWNER-UPDT-REQ   VALUE 'Y'.
557788     05  WS-REGC-SPOU-UPDT            PIC X.
557788         88  WS-REGC-SPOU-NO-UPDT     VALUE 'N'.
557788         88  WS-REGC-SPOU-UPDT-REQ    VALUE 'Y'.
557697     05  WS-SFB-UPDT                  PIC X.
557697         88  WS-SFB-NO-UPDT           VALUE 'N'.
557697         88  WS-SFB-UPDT-REQUIRED     VALUE 'Y'.
           05  WS-THRSHD-PERI               PIC X.
               88  WS-THRSHD-PERI-VALID     VALUE 'N' 'P' 'L'.
           05  WS-ALLOC                     PIC X.
               88  WS-ALLOC-VALID           VALUE 'N' 'O' 'R'.
           05  WS-FREE-WTHDR                PIC X.
               88  WS-FREE-WTHDR-VALID      VALUE 'N' 'P' 'F' 'C'.
           05  WS-FREE-WTHDR-PERI           PIC X.
               88  WS-FREE-WTHDR-PERI-VALID VALUE 'N' 'P' 'L' 'C'.
016109     05  WS-FREE-XFER                 PIC X.
016109         88  WS-FREE-XFER-VALID       VALUE 'N' 'D' 'F' 'C'.
016109     05  WS-FREE-XFER-PERI            PIC X.
016109         88  WS-FREE-XFER-PERI-VALID  VALUE 'N' 'P' 'L' 'C'.
557697     05  WS-SFB-NEG-SUSP-IND          PIC X.
557697         88  WS-SFB-NEG-SUSP-IND-VALID    VALUE 'Y' 'N'.
016548*    05  WS-RESET-YEAR                PIC S9(04)  COMP.
016548     05  WS-RESET-YEAR                PIC S9(04)  BINARY.
018845     05  WS-SHRT-CALC-CD              PIC X.
018845         88  WS-SHRT-CALC-VALID       VALUE 'A' 'N' 'S'.
018845         88  WS-SHRT-CALC-ACUM-VALU   VALUE 'A'.
018845         88  WS-SHRT-CALC-NONE        VALUE 'N'.
018845         88  WS-SHRT-CALC-CSV         VALUE 'S'.
025970     05  WS-SUB                       PIC S9(04)  BINARY.

025970 01 WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '0150'.
025970     05  CV-DATE                      PIC X(10).
025970         88 CV-DATE-DEFAULT           VALUE '0000-00-00'.
025970
       01  WS-UPDT-POLL-SW                  PIC X(01).
           88  WS-UPDT-POLL-REQD            VALUE 'Y'.
           88  WS-UPDT-POLL-NOT-REQD        VALUE 'N'.

557788 01  WS-REGC-WORK-AREA.
557788     03  FILLER                       OCCURS 2 TIMES.
557788         05  WS-REG-CNTRB-1-AMT       PIC S9(11)V99(02) COMP-3.
557788         05  WS-REG-CNTRB-2-AMT       PIC S9(11)V99(02) COMP-3.
557788         05  WS-REG-CNTRB-RECPT-DT    PIC X(10).
557788         05  WS-REG-RECPT-1-AMT       PIC S9(11)V99(02) COMP-3.
557788         05  WS-REG-RECPT-2-AMT       PIC S9(11)V99(02) COMP-3.
557788         05  WS-REG-CNTRB-SPCL-AMT    PIC S9(11)V99(02) COMP-3.
557788         05  WS-REG-CNTRB-XFER-DT     PIC X(10).
557756*
557756* ALL LITERALS IN 'FIELD-NAME-AREA' HAVE BEEN DELETED.
557756*
      *
       COPY XCWWWKDT.
       COPY CCWWINDX.
014221 COPY CCWWLOCK.
013578*COPY CCWCCOMM.
013578*COPY CCWC0151.
      *

025970*01  CV-DATE                          PIC X(10)
025970*                                     VALUE '0000-00-00'.

028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL1640.
014221 COPY XCWL8090.
020074 COPY XCWL8960.
       COPY XCWEBLCH.
020074*COPY CCWTSTCD.
      *
       01  NUMERIC-HOLD-FIELDS.
           02  WS-DISPLAY-WORK-AREA.
               03  WS-DISP-0-5.
                   05  WS-HOLD-0-5          PIC .9(5).
               03  WS-DISP-2-0.
                   05  WS-HOLD-2-0          PIC 9(2).
               03  WS-DISP-2-7.
                   05  WS-HOLD-2-7          PIC 9(2).9(7).
               03  WS-DISP-3-0.
                   05  WS-HOLD-3-0          PIC 9(3).
               03  WS-DISP-4-0.
                   05  WS-HOLD-4-0          PIC 9(4).
008455*        03  WS-DISP-5-2-S.
008455*            05  WS-HOLD-5-2-S        PIC 9(5).9(2)-.
008455*        03  WS-DISP-7-0.
008455*            05  WS-HOLD-7-0          PIC 9(7).
008455*        03  WS-DISP-7-2-S.
008455*            05  WS-HOLD-7-2-S        PIC 9(7).9(2)-.
008455*        03  WS-DISP-S5-2.
008455*            05  WS-HOLD-S5-2         PIC +9(5).9(2).
008455*        03  WS-DISP-S7-2.
008455*            05  WS-HOLD-S7-2         PIC +9(7).9(2).
008455*        03  WS-DISP-S8-2.
008455*            05  WS-HOLD-S8-2         PIC +9(8).9(2).
008455*        03  WS-DISP-9-2-S.
008455*            05  WS-HOLD-9-2-S        PIC 9(9).9(2)-.
008455*        03  WS-DISP-S9-2.
008455*            05  WS-HOLD-S9-2         PIC +9(9).9(2).
           02  WS-PACK-WORK-AREA.
               03  FILLER-S18-0.
                   05  WS-PACK-S18-0        PIC S9(18)      COMP-3.
               03  FILLER-S13-5             REDEFINES
                   FILLER-S18-0.
                   05  WS-PACK-S13-5        PIC S9(13)V9(5) COMP-3.
               03  FILLER-S11-7             REDEFINES
                   FILLER-S18-0.
                   05  WS-PACK-S11-7        PIC S9(11)V9(7) COMP-3.

      *---- WORKING STORAGE AREAS FOR FILES

       COPY CCWTMETH.
016503 COPY CCWL0289.
557668 COPY CCWL0620.
       COPY CCWL2430.
557697 COPY CCWL2520.
557788 COPY CCWL2530.
       COPY CCWL5400.
016537*COPY CCWWTR00.
016537*COPY CCWWTR08.
      *

       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
      *-----  NUMERIC EDITING
       COPY XCWL0280.
008455 COPY XCWL0290.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
016537*COPY CCFRPH.
016537*COPY CCFWPH.
      *
       COPY CCFWPOL.
       COPY CCFRPOL.
      *
016503 COPY CCFWCVG.
016503 COPY CCFRCVG.
      *
       COPY CCFWPOLL.
       COPY CCFRPOLL.
      *
006002 COPY XCFWCTLC.
006002 COPY XCFRCTLC.
006002*
       COPY CCWWCVGS.
016503 COPY CCWLPGA.
      *
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0151.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ****************
       0000-MAIN-LINE.
      ****************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAIN-LINE-X.
           EXIT.
      *
      ***************************
       2000-PROCESS-REQUEST.
      ***************************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.

           IF  WGLOB-MSG-ERROR-SW     >  ZERO
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           MOVE MIR-POL-ID            TO WPOL-POL-ID.
           MOVE WPOL-POL-ID           TO WPOLL-POL-ID.
025970*    SET  NO-UPDATE                  TO TRUE.
025970*    SET  WS-REGC-OWNER-NO-UPDT      TO TRUE.
025970*    SET  WS-REGC-SPOU-NO-UPDT       TO TRUE.
025970*    SET  WS-SFB-NO-UPDT             TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           EVALUATE TRUE
               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X
               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  4000-PROCESS-UPDATE
                       THRU 4000-PROCESS-UPDATE-X
               WHEN OTHER
                   SET MIR-RETRN-INVALD-RQST TO TRUE
557660     END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *-----------------------
       3000-PROCESS-RETRIEVE.
      *-----------------------

014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

      * POLICY CONTROL CHECK
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.
           IF  L5400-BRCH-ACCS-RESTRICTED
      * BLANK OUT DATA FIELDS, DISPLAY AND PROTECT FOR NBS POLICIES
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

557788     PERFORM  7200-GET-REGC-INFO
557788         THRU 7200-GET-REGC-INFO-X.

557697     PERFORM  2520-1000-BUILD-PARM-INFO
557697         THRU 2520-1000-BUILD-PARM-INFO-X.
557697     MOVE RPOL-POL-ID           TO L2520-POL-ID.
557697     MOVE RPOL-PLAN-ID          TO L2520-PLAN-ID.
557697     PERFORM  2520-1000-GET-SFB-INFO
557697         THRU 2520-1000-GET-SFB-INFO-X.

           IF  L5400-STAT-ACCS-RESTRICTED
               PERFORM  8000-MOVE-RECORD-TO-SCREEN
                   THRU 8000-MOVE-RECORD-TO-SCREEN-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  8000-MOVE-RECORD-TO-SCREEN
               THRU 8000-MOVE-RECORD-TO-SCREEN-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *-----------------------
       4000-PROCESS-UPDATE.
      *-----------------------

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221            GO TO 4000-PROCESS-UPDATE-X
014221     END-IF.

557699*    IF  NOT WPOL-IO-OK
557699     IF  WPOL-IO-OK
557699         IF  WGLOB-AUDIT-REQUESTED
557699             PERFORM  POL-1000-CALL-AUDIT
557699                 THRU POL-1000-CALL-AUDIT-X
557699         END-IF
557699     ELSE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4000-PROCESS-UPDATE-X
557660     END-IF.

016440* IF THE POLICY HAS A STATUS CODE OF TRANSFERRED 'M'
016440* THE USER SHOULD BE ABLE TO CHANGE THE STATUS CODE BACK TO
016440* SOMETHING ELSE
016440* IN THIS SITUATION WE SHOULD BYPASS THE POLICY CONTROL CHECK

016440     IF  RPOL-POL-STAT-XFER-XTRNL
016440     AND MIR-POL-CSTAT-CD NOT = RPOL-POL-CSTAT-CD
016440         CONTINUE
016440     ELSE
016440* POLICY CONTROL CHECK
016440         PERFORM  5400-1000-BUILD-PARM-INFO
016440             THRU 5400-1000-BUILD-PARM-INFO-X
016440         SET L5400-POL-XFER-UPDATE        TO TRUE
016440         PERFORM  5400-1000-POL-CHK
016440             THRU 5400-1000-POL-CHK-X
016440         IF  L5400-BRCH-ACCS-RESTRICTED
016440         OR  L5400-XFER-ACCS-RESTRICTED
016440             PERFORM  9100-BLANK-DATA-FIELDS
016440                 THRU 9100-BLANK-DATA-FIELDS-X
016440             PERFORM  POL-3000-UNLOCK
016440                 THRU POL-3000-UNLOCK-X
016440             GO TO 4000-PROCESS-UPDATE-X
016440         END-IF
016440     END-IF.

557788     PERFORM  7200-GET-REGC-INFO
557788         THRU 7200-GET-REGC-INFO-X.

557697     PERFORM  2520-1000-BUILD-PARM-INFO
557697         THRU 2520-1000-BUILD-PARM-INFO-X.
557697     MOVE RPOL-POL-ID           TO L2520-POL-ID.
557697     MOVE RPOL-PLAN-ID          TO L2520-PLAN-ID.
557697     PERFORM  2520-1000-GET-SFB-INFO
557697         THRU 2520-1000-GET-SFB-INFO-X.


           SET WS-ERROR-NOT-FOUND          TO TRUE.

      *
           PERFORM  5100-EDIT-SCREEN-1
               THRU 5100-EDIT-SCREEN-1-X.
      *
557697     PERFORM  5400-XEDIT-SCREEN-1
557697         THRU 5400-XEDIT-SCREEN-1-X.
557697
           PERFORM  5200-EDIT-SCREEN-2
               THRU 5200-EDIT-SCREEN-2-X.
013578*
013578     PERFORM  5500-DISP-NON-UPDATE-FIELDS
013578         THRU 5500-DISP-NON-UPDATE-FIELDS-X.

           IF  UPDATE-REQUIRED
557697     OR  WS-SFB-UPDT-REQUIRED
557788     OR  WS-REGC-OWNER-UPDT-REQ
557788     OR  WS-REGC-SPOU-UPDT-REQ
016503         PERFORM  4100-UPDATE-RECORDS
016503             THRU 4100-UPDATE-RECORDS-X
557788*        IF  RPOL-NXT-ACTV-TYP-CD    =  'SCH'
557788*            PERFORM  POL-2000-REWRITE
557788*                THRU POL-2000-REWRITE-X
557788*        ELSE
557788*            MOVE 'RSH'              TO RPOL-NXT-ACTV-TYP-CD
557788*            PERFORM  POL-2000-REWRITE
557788*                THRU POL-2000-REWRITE-X
557788*        END-IF
016503*        IF  UPDATE-REQUIRED
016503*            IF  RPOL-NXT-ACTV-TYP-CD    =  'SCH'
016503*                PERFORM  POL-2000-REWRITE
016503*                    THRU POL-2000-REWRITE-X
016503*            ELSE
016503*                MOVE 'RSH'     TO RPOL-NXT-ACTV-TYP-CD
016503*            PERFORM  POL-2000-REWRITE
016503*                THRU POL-2000-REWRITE-X
016503*            END-IF
016503*        ELSE
016503*            PERFORM  POL-3000-UNLOCK
016503*                THRU POL-3000-UNLOCK-X
016503*        END-IF
016503*        IF  WS-SFB-UPDT-REQUIRED
016503*            PERFORM  2520-2000-UPDT-SFB-INFO
016503*                THRU 2520-2000-UPDT-SFB-INFO-X
016503*        END-IF
016503*        IF  WS-REGC-OWNER-UPDT-REQ
016503*        OR  WS-REGC-SPOU-UPDT-REQ
016503*            PERFORM  7300-UPDATE-REGC-INFO
016503*                THRU 7300-UPDATE-REGC-INFO-X
016503*        END-IF
016503*        IF  WGLOB-AUDIT-REQUESTED
016503*            PERFORM  POL-1000-CALL-AUDIT
016503*                THRU POL-1000-CALL-AUDIT-X
016503*        END-IF
           ELSE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
557660     END-IF.

       4000-PROCESS-UPDATE-X.
           EXIT.
      *
016503*********************
016503 4100-UPDATE-RECORDS.
016503*********************

016503     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD
016503                             TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT
016503                             TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'   TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.
016503     PERFORM  POL-2000-REWRITE
016503         THRU POL-2000-REWRITE-X.

016503     IF  WS-SFB-UPDT-REQUIRED
016503         PERFORM  2520-2000-UPDT-SFB-INFO
016503             THRU 2520-2000-UPDT-SFB-INFO-X
016503     END-IF.

016503     IF  WS-REGC-OWNER-UPDT-REQ
016503     OR  WS-REGC-SPOU-UPDT-REQ
016503         PERFORM  7300-UPDATE-REGC-INFO
016503             THRU 7300-UPDATE-REGC-INFO-X
016503     END-IF.

016503     IF  WGLOB-AUDIT-REQUESTED
016503         PERFORM  POL-1000-CALL-AUDIT
016503             THRU POL-1000-CALL-AUDIT-X
016503     END-IF.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

016503 4100-UPDATE-RECORDS-X.
016503     EXIT.
      *
      ********************
       5100-EDIT-SCREEN-1.
      ********************

           PERFORM  5101-EDIT-PDTODT
               THRU 5101-EDIT-PDTODT-X.
           PERFORM  5102-EDIT-STATCD
               THRU 5102-EDIT-STATCD-X.
           PERFORM  5103-EDIT-TOTBILL
               THRU 5103-EDIT-TOTBILL-X.
           PERFORM  5104-EDIT-LASTPTD
               THRU 5104-EDIT-LASTPTD-X.
           PERFORM  5105-EDIT-LAST-MOD
               THRU 5105-EDIT-LAST-MOD-X.
           PERFORM  5106-EDIT-LAST-METHOD
               THRU 5106-EDIT-LAST-METHOD-X.
           PERFORM  5107-EDIT-LAST-MFACTOR
               THRU 5107-EDIT-LAST-MFACTOR-X.
           PERFORM  5108-EDIT-LAST-FFI
               THRU 5108-EDIT-LAST-FFI-X.
           PERFORM  5109-EDIT-BASECOV
               THRU 5109-EDIT-BASECOV-X.
           PERFORM  5110-EDIT-PARCOV
               THRU 5110-EDIT-PARCOV-X.
      *
      *---- LINE 2
      *
           PERFORM  5111-EDIT-ISSUE-LOCATION
               THRU 5111-EDIT-ISSUE-LOCATION-X.
           PERFORM  5112-EDIT-CURR-LOCATION
               THRU 5112-EDIT-CURR-LOCATION-X.
           PERFORM  5113-EDIT-LANOAMT
               THRU 5113-EDIT-LANOAMT-X.
016395*    PERFORM  5114-EDIT-AN-PAC-DT
016395*        THRU 5114-EDIT-AN-PAC-DT-X.
016395     PERFORM  5114-EDIT-AN-PMT-DT
016395         THRU 5114-EDIT-AN-PMT-DT-X.
           PERFORM  5115-EDIT-PREVFAC
               THRU 5115-EDIT-PREVFAC-X.
           PERFORM  5116-EDIT-TOTDIV
               THRU 5116-EDIT-TOTDIV-X.
           PERFORM  5117-EDIT-ACTYPE
               THRU 5117-EDIT-ACTYPE-X.
           PERFORM  5118-EDIT-PARDIG
               THRU 5118-EDIT-PARDIG-X.
      *
      *---- LINE 3
      *
           PERFORM  5119-EDIT-DIV-YTD
               THRU 5119-EDIT-DIV-YTD-X.
           PERFORM  5120-EDIT-DIV-DEP
               THRU 5120-EDIT-DIV-DEP-X.
           PERFORM  5121-EDIT-DIV-AVB
               THRU 5121-EDIT-DIV-AVB-X.
           PERFORM  5122-EDIT-DIV-IR
               THRU 5122-EDIT-DIV-IR-X.
           PERFORM  5123-EDIT-DIV-INT
               THRU 5123-EDIT-DIV-INT-X.
           PERFORM  5124-EDIT-DIV-YR
               THRU 5124-EDIT-DIV-YR-X.
           PERFORM  5125-EDIT-TOT-PUA
               THRU 5125-EDIT-TOT-PUA-X.
           PERFORM  5126-EDIT-CURR-PUA
               THRU 5126-EDIT-CURR-PUA-X.
           PERFORM  5127-EDIT-OYT
               THRU 5127-EDIT-OYT-X.

      *
      *---- LINE 4
      *
           SET WS-UPDT-POLL-NOT-REQD  TO TRUE.
           MOVE MIR-POL-ID            TO WPOLL-POL-ID.
           MOVE 'C'                   TO WPOLL-POL-LOAN-ID.

           PERFORM  POLL-1000-READ-FOR-UPDATE
               THRU POLL-1000-READ-FOR-UPDATE-X.

557699*    IF  NOT WPOLL-IO-OK
557699     IF  WPOLL-IO-OK
557699         IF  WGLOB-AUDIT-REQUESTED
557699             PERFORM  POLL-1000-CALL-AUDIT
557699                 THRU POLL-1000-CALL-AUDIT-X
557699         END-IF
557699     ELSE
               PERFORM  POLL-1000-CREATE
                   THRU POLL-1000-CREATE-X
           END-IF.

           PERFORM  5128-EDIT-LNAMT
               THRU 5128-EDIT-LNAMT-X.
           PERFORM  5129-EDIT-LNIR1
               THRU 5129-EDIT-LNIR1-X.
           PERFORM  5130-EDIT-LNIRM1
               THRU 5130-EDIT-LNIRM1-X.
           PERFORM  5131-EDIT-LNBIL1
               THRU 5131-EDIT-LNBIL1-X.
           PERFORM  5132-EDIT-LNITY1
               THRU 5132-EDIT-LNITY1-X.
           PERFORM  5133-EDIT-LNAVB1
               THRU 5133-EDIT-LNAVB1-X.
           PERFORM  5134-EDIT-LNIFV1
               THRU 5134-EDIT-LNIFV1-X.
010397     PERFORM  5168-EDIT-ANNBL1
010397         THRU 5168-EDIT-ANNBL1-X.
010397     PERFORM  5169-EDIT-PANBL1
010397         THRU 5169-EDIT-PANBL1-X.
           PERFORM  5301-EDIT-LNDTE1
               THRU 5301-EDIT-LNDTE1-X.

           IF  WS-UPDT-POLL-REQD
               SET UPDATE-REQUIRED    TO TRUE
               IF  WPOLL-IO-OK
                   PERFORM  POLL-2000-REWRITE
                       THRU POLL-2000-REWRITE-X
               ELSE
                   PERFORM  POLL-1000-WRITE
                       THRU POLL-1000-WRITE-X
               END-IF
557699         IF  WGLOB-AUDIT-REQUESTED
557699             PERFORM  POLL-1000-CALL-AUDIT
557699                 THRU POLL-1000-CALL-AUDIT-X
557699         END-IF
           ELSE
               IF  WPOLL-IO-OK
                   PERFORM  POLL-3000-UNLOCK
                       THRU POLL-3000-UNLOCK-X
               END-IF
           END-IF.

      *
      *---- LINE 5
      *
           SET WS-UPDT-POLL-NOT-REQD  TO TRUE.
           MOVE MIR-POL-ID            TO WPOLL-POL-ID.
           MOVE 'O'                   TO WPOLL-POL-LOAN-ID.

           PERFORM  POLL-1000-READ-FOR-UPDATE
               THRU POLL-1000-READ-FOR-UPDATE-X.

557699*    IF  NOT WPOLL-IO-OK
557699     IF  WPOLL-IO-OK
557699         IF  WGLOB-AUDIT-REQUESTED
557699             PERFORM  POLL-1000-CALL-AUDIT
557699                 THRU POLL-1000-CALL-AUDIT-X
557699         END-IF
557699     ELSE
               PERFORM  POLL-1000-CREATE
                   THRU POLL-1000-CREATE-X
           END-IF.

           PERFORM  5135-EDIT-LNAMT2
               THRU 5135-EDIT-LNAMT2-X.
           PERFORM  5136-EDIT-LNIR2
               THRU 5136-EDIT-LNIR2-X.
           PERFORM  5137-EDIT-LNIRM2
               THRU 5137-EDIT-LNIRM2-X.
           PERFORM  5138-EDIT-LNBIL2
               THRU 5138-EDIT-LNBIL2-X.
           PERFORM  5139-EDIT-LNITY2
               THRU 5139-EDIT-LNITY2-X.
           PERFORM  5140-EDIT-LNAVB2
               THRU 5140-EDIT-LNAVB2-X.
           PERFORM  5141-EDIT-LNIFV2
               THRU 5141-EDIT-LNIFV2-X.
010397     PERFORM  5170-EDIT-ANNBL2
010397         THRU 5170-EDIT-ANNBL2-X.
010397     PERFORM  5171-EDIT-PANBL2
010397         THRU 5171-EDIT-PANBL2-X.
           PERFORM  5302-EDIT-LNDTE2
               THRU 5302-EDIT-LNDTE2-X.

           IF  WS-UPDT-POLL-REQD
               SET UPDATE-REQUIRED    TO TRUE
               IF  WPOLL-IO-OK
                   PERFORM  POLL-2000-REWRITE
                       THRU POLL-2000-REWRITE-X
               ELSE
                   PERFORM  POLL-1000-WRITE
                       THRU POLL-1000-WRITE-X
               END-IF
557699         IF  WGLOB-AUDIT-REQUESTED
557699             PERFORM  POLL-1000-CALL-AUDIT
557699                 THRU POLL-1000-CALL-AUDIT-X
557699         END-IF
           ELSE
               IF  WPOLL-IO-OK
                   PERFORM  POLL-3000-UNLOCK
                       THRU POLL-3000-UNLOCK-X
               END-IF
           END-IF.

      *
      *---- LINE 6
      *
           SET WS-UPDT-POLL-NOT-REQD  TO TRUE.
           MOVE MIR-POL-ID            TO WPOLL-POL-ID.
           MOVE 'A'                   TO WPOLL-POL-LOAN-ID.

           PERFORM  POLL-1000-READ-FOR-UPDATE
               THRU POLL-1000-READ-FOR-UPDATE-X.

557699*    IF  NOT WPOLL-IO-OK
557699     IF  WPOLL-IO-OK
557699         IF  WGLOB-AUDIT-REQUESTED
557699             PERFORM  POLL-1000-CALL-AUDIT
557699                 THRU POLL-1000-CALL-AUDIT-X
557699         END-IF
557699     ELSE
               PERFORM  POLL-1000-CREATE
                   THRU POLL-1000-CREATE-X
           END-IF.

           PERFORM  5142-EDIT-LNAMT3
               THRU 5142-EDIT-LNAMT3-X.
           PERFORM  5143-EDIT-LNIR3
               THRU 5143-EDIT-LNIR3-X.
           PERFORM  5144-EDIT-LNIRM3
               THRU 5144-EDIT-LNIRM3-X.
           PERFORM  5145-EDIT-LNBIL3
               THRU 5145-EDIT-LNBIL3-X.
           PERFORM  5146-EDIT-LNITY3
               THRU 5146-EDIT-LNITY3-X.
           PERFORM  5147-EDIT-LNAVB3
               THRU 5147-EDIT-LNAVB3-X.
           PERFORM  5148-EDIT-LNIFV3
               THRU 5148-EDIT-LNIFV3-X.
010397     PERFORM  5172-EDIT-ANNBL3
010397         THRU 5172-EDIT-ANNBL3-X.
010397     PERFORM  5173-EDIT-PANBL3
010397         THRU 5173-EDIT-PANBL3-X.
           PERFORM  5303-EDIT-APLDTE
               THRU 5303-EDIT-APLDTE-X.

           IF  WS-UPDT-POLL-REQD
               SET UPDATE-REQUIRED    TO TRUE
               IF  WPOLL-IO-OK
                   PERFORM  POLL-2000-REWRITE
                       THRU POLL-2000-REWRITE-X
               ELSE
                   PERFORM  POLL-1000-WRITE
                       THRU POLL-1000-WRITE-X
               END-IF
557699         IF  WGLOB-AUDIT-REQUESTED
557699             PERFORM  POLL-1000-CALL-AUDIT
557699                 THRU POLL-1000-CALL-AUDIT-X
557699         END-IF
           ELSE
               IF  WPOLL-IO-OK
                   PERFORM  POLL-3000-UNLOCK
                       THRU POLL-3000-UNLOCK-X
               END-IF
           END-IF.

      *
      *---- LINE 7
      *
           PERFORM  5149-EDIT-PDFAMT
               THRU 5149-EDIT-PDFAMT-X.
           PERFORM  5150-EDIT-PDFINT
               THRU 5150-EDIT-PDFINT-X.
           PERFORM  5151-EDIT-PDFIR
               THRU 5151-EDIT-PDFIR-X.
           PERFORM  5152-EDIT-PDFAVB
               THRU 5152-EDIT-PDFAVB-X.
           PERFORM  5153-EDIT-PDFIYR
               THRU 5153-EDIT-PDFIYR-X.
           PERFORM  5154-EDIT-SURACC
               THRU 5154-EDIT-SURACC-X.
           PERFORM  5155-EDIT-SURLN
               THRU 5155-EDIT-SURLN-X.
           PERFORM  5156-EDIT-TERPUA
               THRU 5156-EDIT-TERPUA-X.
           PERFORM  5157-EDIT-TPUACD
               THRU 5157-EDIT-TPUACD-X.
      *
      *---- LINE 8
      *
           PERFORM  5158-EDIT-MISSUSP
               THRU 5158-EDIT-MISSUSP-X.
           PERFORM  5159-EDIT-MISC-DATE
               THRU 5159-EDIT-MISC-DATE-X.
           PERFORM  5160-EDIT-PREM-SUSPENSE
               THRU 5160-EDIT-PREM-SUSPENSE-X.
           PERFORM  5161-EDIT-PREM-DATE
               THRU 5161-EDIT-PREM-DATE-X.
           PERFORM  5162-EDIT-DIV-SUSP
               THRU 5162-EDIT-DIV-SUSP-X.
           PERFORM  5163-EDIT-DISB-AMT
               THRU 5163-EDIT-DISB-AMT-X.
           PERFORM  5164-EDIT-DISB-DATE
               THRU 5164-EDIT-DISB-DATE-X.
557697     PERFORM  5165-EDIT-SF-PREM-RULE
557697         THRU 5165-EDIT-SF-PREM-RULE-X.
557697     PERFORM  5166-EDIT-SF-NEG-LIMIT
557697         THRU 5166-EDIT-SF-NEG-LIMIT-X.
557697     PERFORM  5167-EDIT-SF-BILL-AMT
557697         THRU 5167-EDIT-SF-BILL-AMT-X.
020455     PERFORM  5174-EDIT-UNDO-EFF-DT
020455         THRU 5174-EDIT-UNDO-EFF-DT-X.
026057     PERFORM  5175-EDIT-INV-HIST-DT
026057         THRU 5175-EDIT-INV-HIST-DT-X.

       5100-EDIT-SCREEN-1-X.
           EXIT.
      *
      *******************
       5101-EDIT-PDTODT.
      *******************

           IF  MIR-POL-PD-TO-DT-NUM = SPACES
               MOVE RPOL-POL-PD-TO-DT-NUM
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-PD-TO-DT-NUM
               GO TO 5101-EDIT-PDTODT-X
557660     END-IF.

           IF  MIR-POL-PD-TO-DT-NUM = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-POL-PD-TO-DT-NUM
               MOVE WWKDT-ZERO-DT     TO RPOL-POL-PD-TO-DT-NUM
               GO TO 5101-EDIT-PDTODT-X
557660     END-IF.

           MOVE MIR-POL-PD-TO-DT-NUM  TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE PD-TO-DTE (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO RPOL-POL-PD-TO-DT-NUM
557660     END-IF.

       5101-EDIT-PDTODT-X.
           EXIT.
      *
      ******************
       5102-EDIT-STATCD.
      ******************

           IF  MIR-POL-CSTAT-CD = SPACE
               MOVE RPOL-POL-CSTAT-CD TO MIR-POL-CSTAT-CD
               GO TO 5102-EDIT-STATCD-X
557660     END-IF.

           IF  MIR-POL-CSTAT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-POL-CSTAT-CD
557660     END-IF.

020074*    MOVE MIR-POL-CSTAT-CD      TO STATUS-FIND-CODE.
020074*    PERFORM  STCD-1000-FIND
020074*        THRU STCD-1000-FIND-X
020074*    IF  NOT STATUS-DATA-VALID
020074*        SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE W-STATUS (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
020074*        MOVE 'CS01510007'      TO WGLOB-MSG-REF-INFO
020074*        PERFORM  0260-1000-GENERATE-MESSAGE
020074*            THRU 0260-1000-GENERATE-MESSAGE-X
020074*    ELSE
020074*        SET UPDATE-REQUIRED          TO TRUE
020074*        MOVE MIR-POL-CSTAT-CD  TO RPOL-POL-CSTAT-CD
020074*    END-IF.
020074     PERFORM  8960-1000-BUILD-PARM-INFO
020074         THRU 8960-1000-BUILD-PARM-INFO-X.
020074
020074     MOVE 'POL-CSTAT-CD'              TO L8960-AV-TBL-CD.
020074     MOVE MIR-POL-CSTAT-CD            TO L8960-AV-CD.
020074
020074     PERFORM  8960-1000-VALIDATE-CODE
020074         THRU 8960-1000-VALIDATE-CODE-X.
020074
020074     IF  L8960-RETRN-OK
020074         SET UPDATE-REQUIRED          TO TRUE
020074         MOVE MIR-POL-CSTAT-CD        TO RPOL-POL-CSTAT-CD
020074     ELSE
020074         SET WS-ERROR-FOUND           TO TRUE
020074         MOVE 'CS01510007'            TO WGLOB-MSG-REF-INFO
020074         PERFORM  0260-1000-GENERATE-MESSAGE
020074             THRU 0260-1000-GENERATE-MESSAGE-X
020074     END-IF.

       5102-EDIT-STATCD-X.
           EXIT.
      *
      *---------------------------
       5103-EDIT-TOTBILL.
      *---------------------------

           IF  MIR-POL-TOT-BILL-AMT = SPACES
008455*        MOVE RPOL-POL-TOT-BILL-AMT   TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-TOT-BILL-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-TOT-BILL-AMT * 100
020874         MOVE RPOL-POL-TOT-BILL-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-TOT-BILL-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-TOT-BILL-AMT
               GO TO 5103-EDIT-TOTBILL-X
557660     END-IF.

           IF  MIR-POL-TOT-BILL-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-POL-TOT-BILL-AMT
008455         MOVE  ZEROS            TO MIR-POL-TOT-BILL-AMT
557660     END-IF.

           MOVE MIR-POL-TOT-BILL-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-TOT-BILL-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-TOT-BILL-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-TOT-BILL-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-TOT-BILL-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-TOT-BILL-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT   (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE AMT-BILLED (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5103-EDIT-TOTBILL-X.
           EXIT.
      *
      *---------------------------
       5104-EDIT-LASTPTD.
      *---------------------------

           IF  MIR-PREV-PD-TO-DT-NUM = SPACE
               MOVE RPOL-PREV-PD-TO-DT-NUM
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PREV-PD-TO-DT-NUM
               GO TO 5104-EDIT-LASTPTD-X
557660     END-IF.

           IF  MIR-PREV-PD-TO-DT-NUM = EBLCH-BLANK-FIELD-CHAR
               MOVE WWKDT-ZERO-DT     TO RPOL-PREV-PD-TO-DT-NUM
               MOVE SPACES            TO MIR-PREV-PD-TO-DT-NUM
               GO TO 5104-EDIT-LASTPTD-X
557660     END-IF.

           MOVE MIR-PREV-PD-TO-DT-NUM TO L1640-EXTERNAL-DATE
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE LAST-PDT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO RPOL-PREV-PD-TO-DT-NUM
557660     END-IF.

       5104-EDIT-LASTPTD-X.
           EXIT.
      *
      *---------------------------
       5105-EDIT-LAST-MOD.
      *---------------------------

           IF  MIR-POL-PREV-MODE-CD = SPACES
           OR  MIR-POL-PREV-MODE-CD = ZEROS
               MOVE RPOL-POL-PREV-MODE-CD-N
                                      TO MIR-POL-PREV-MODE-CD
               GO TO 5105-EDIT-LAST-MOD-X
557660     END-IF.

           IF  MIR-POL-PREV-MODE-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE '00'              TO MIR-POL-PREV-MODE-CD
557660     END-IF.

           IF  MIR-POL-PREV-MODE-CD NOT = '01'
           AND MIR-POL-PREV-MODE-CD NOT = '03'
           AND MIR-POL-PREV-MODE-CD NOT = '06'
           AND MIR-POL-PREV-MODE-CD NOT = '12'
           AND MIR-POL-PREV-MODE-CD NOT = '00'
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE LAST-MD (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-POL-PREV-MODE-CD
                                      TO RPOL-POL-PREV-MODE-CD-N
557660     END-IF.


       5105-EDIT-LAST-MOD-X.
           EXIT.
      *
      *---------------------------
       5106-EDIT-LAST-METHOD.
      *---------------------------
      *
      ***  LAST-BILLING-TYPE.
      *
           IF  MIR-PREV-BILL-TYP-CD = SPACES
               MOVE RPOL-PREV-BILL-TYP-CD
                                      TO MIR-PREV-BILL-TYP-CD
               GO TO 5106-EDIT-LAST-METHOD-X
557660     END-IF.

           IF  MIR-PREV-BILL-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RPOL-PREV-BILL-TYP-CD
               MOVE SPACES            TO MIR-PREV-BILL-TYP-CD
               GO TO 5106-EDIT-LAST-METHOD-X
557660     END-IF.

           MOVE MIR-PREV-BILL-TYP-CD  TO METH-FIND-CODE
           PERFORM  METH-1000-FIND
               THRU METH-1000-FIND-X
           IF  NOT METH-DATA-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE LAST-BT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-PREV-BILL-TYP-CD
                                      TO RPOL-PREV-BILL-TYP-CD
557660     END-IF.

       5106-EDIT-LAST-METHOD-X.
           EXIT.
      *
      *---------------------------
       5107-EDIT-LAST-MFACTOR.
      *---------------------------

           IF  MIR-POL-PREV-MODE-FCT = SPACES
020874*        MOVE RPOL-POL-PREV-MODE-FCT
020874*                               TO WS-HOLD-2-7
020874*        MOVE WS-DISP-2-7       TO MIR-POL-PREV-MODE-FCT
020874         MOVE RPOL-POL-PREV-MODE-FCT TO L0290-INPUT-V07
020874         MOVE 7                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-MODE-FCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-MODE-FCT
               GO TO 5107-EDIT-LAST-MFACTOR-X
557660     END-IF.

           IF  MIR-POL-PREV-MODE-FCT = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE +0                TO WS-HOLD-2-7
020874*        MOVE WS-DISP-2-7       TO MIR-POL-PREV-MODE-FCT
020874         MOVE +0                    TO L0290-INPUT-V07
020874         MOVE 7                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-MODE-FCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-MODE-FCT
557660     END-IF.

           MOVE MIR-POL-PREV-MODE-FCT TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 7                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 10                    TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
020874*        MOVE L0280-OUTPUT      TO WS-PACK-S18-0
020874*        MOVE WS-PACK-S11-7     TO RPOL-POL-PREV-MODE-FCT
020874*        MOVE WS-PACK-S11-7     TO WS-HOLD-2-7
020874*        MOVE WS-DISP-2-7       TO MIR-POL-PREV-MODE-FCT
020874         MOVE L0280-OUTPUT-V07      TO L0290-INPUT-V07
020874         MOVE L0280-OUTPUT-V07      TO RPOL-POL-PREV-MODE-FCT
020874         MOVE 7                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-MODE-FCT
020874                                TO L0290-MAX-OUT-LEN
020874         SET  L0290-SIGN-DISPLAY       TO TRUE
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-MODE-FCT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510012'      TO WGLOB-MSG-REF-INFO
557756*        MOVE W-NUMBER (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE LAST-MD-FACTOR (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5107-EDIT-LAST-MFACTOR-X.
           EXIT.
      *
      *---------------------------
       5108-EDIT-LAST-FFI.
      *---------------------------

           IF  MIR-POL-PREV-PFEE-FCT = SPACES
020874*        MOVE RPOL-POL-PREV-PFEE-FCT
020874*                               TO WS-HOLD-2-7
020874*        MOVE WS-DISP-2-7       TO MIR-POL-PREV-PFEE-FCT
020874         MOVE RPOL-POL-PREV-PFEE-FCT TO L0290-INPUT-V07
020874         MOVE 7                      TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-PFEE-FCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-PFEE-FCT
               GO TO 5108-EDIT-LAST-FFI-X
557660     END-IF.

           IF  MIR-POL-PREV-PFEE-FCT = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE +0                TO WS-HOLD-2-7
020874*        MOVE WS-DISP-2-7       TO MIR-POL-PREV-PFEE-FCT
020874         MOVE +0                    TO L0290-INPUT-V07
020874         MOVE 7                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-PFEE-FCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-PFEE-FCT
557660     END-IF.

           MOVE MIR-POL-PREV-PFEE-FCT TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 7                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 10                    TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
020874*        MOVE L0280-OUTPUT      TO WS-PACK-S18-0
020874*        MOVE WS-PACK-S11-7     TO RPOL-POL-PREV-PFEE-FCT
020874*        MOVE WS-PACK-S11-7     TO WS-HOLD-2-7
020874*        MOVE WS-DISP-2-7       TO MIR-POL-PREV-PFEE-FCT
020874         MOVE L0280-OUTPUT-V07      TO L0290-INPUT-V07
020874         MOVE L0280-OUTPUT-V07      TO RPOL-POL-PREV-PFEE-FCT
020874         MOVE 7                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-PFEE-FCT
020874                                    TO L0290-MAX-OUT-LEN
020874         SET L0290-SIGN-DISPLAY     TO TRUE
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-PFEE-FCT
           ELSE
557756*        MOVE W-NUMBER (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE LAST-FEE-FACTOR (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.
       5108-EDIT-LAST-FFI-X.
           EXIT.
      *
      *---------------------------
       5109-EDIT-BASECOV.
      *---------------------------

           IF  MIR-POL-BASE-CVG-NUM = SPACES
020874*        MOVE RPOL-POL-BASE-CVG-NUM
020874*                               TO WS-HOLD-2-0
020874*        MOVE WS-DISP-2-0       TO MIR-POL-BASE-CVG-NUM
020874         MOVE RPOL-POL-BASE-CVG-NUM TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-BASE-CVG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-BASE-CVG-NUM
               GO TO 5109-EDIT-BASECOV-X
557660     END-IF.

           IF  MIR-POL-BASE-CVG-NUM = EBLCH-BLANK-FIELD-CHAR
               MOVE '00'              TO MIR-POL-BASE-CVG-NUM
557660     END-IF.

           MOVE MIR-POL-BASE-CVG-NUM  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-HOLD-2-0
020874*        MOVE WS-DISP-2-0       TO MIR-POL-BASE-CVG-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-BASE-CVG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-BASE-CVG-NUM
               IF  L0280-OUTPUT > 0
007766*        AND L0280-OUTPUT < 21
007766         AND L0280-OUTPUT NOT > WCVGM-MAX-WCVGS-NUM
                   SET UPDATE-REQUIRED      TO TRUE
                   MOVE L0280-OUTPUT  TO RPOL-POL-BASE-CVG-NUM
               ELSE
                   SET WS-ERROR-FOUND       TO TRUE
                   MOVE 'CS01510005'  TO WGLOB-MSG-REF-INFO
007766             MOVE WCVGM-MAX-WCVGS-NUM
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE W-NUMBER (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE BASE-COV (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
       5109-EDIT-BASECOV-X.
           EXIT.
      *
      *---------------------------
       5110-EDIT-PARCOV.
      *---------------------------

           IF  MIR-POL-PAR-CVG-NUM = SPACES
020874*        MOVE RPOL-POL-PAR-CVG-NUM
020874*                               TO WS-HOLD-2-0
020874*        MOVE WS-DISP-2-0       TO MIR-POL-PAR-CVG-NUM
020874         MOVE RPOL-POL-PAR-CVG-NUM  TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PAR-CVG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PAR-CVG-NUM
               GO TO 5110-EDIT-PARCOV-X
557660     END-IF.

           IF  MIR-POL-PAR-CVG-NUM = EBLCH-BLANK-FIELD-CHAR
               MOVE '00'              TO MIR-POL-PAR-CVG-NUM
557660     END-IF.

           MOVE MIR-POL-PAR-CVG-NUM   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT      TO RPOL-POL-PAR-CVG-NUM
020874*        MOVE L0280-OUTPUT      TO WS-HOLD-2-0
020874*        MOVE WS-DISP-2-0       TO MIR-POL-PAR-CVG-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PAR-CVG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PAR-CVG-NUM
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE W-NUMBER (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PAR-COV (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
       5110-EDIT-PARCOV-X.
           EXIT.
      *
      *---------------------------
       5111-EDIT-ISSUE-LOCATION.
      *---------------------------

           IF  MIR-XHBT-ISS-LOC-CD = SPACES
               MOVE RPOL-XHBT-ISS-LOC-CD
                                      TO MIR-XHBT-ISS-LOC-CD
               GO TO 5111-EDIT-ISSUE-LOCATION-X
557660     END-IF.

           IF  MIR-XHBT-ISS-LOC-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RPOL-XHBT-ISS-LOC-CD
               MOVE SPACES            TO MIR-XHBT-ISS-LOC-CD
               GO TO 5111-EDIT-ISSUE-LOCATION-X
557660     END-IF.

006002*    MOVE MIR-XHBT-ISS-LOC-CD   TO WEDIT-ETBL-VALU-ID.
006002*    PERFORM  ILOC-1000-EDIT-ISSU-LOCATION
006002*        THRU ILOC-1000-EDIT-ISSU-LOCATION-X.
006002*    IF  NOT WEDIT-IO-OK

006002     MOVE MIR-XHBT-ISS-LOC-CD   TO WCTLC-CTRY-LOC-CD
006002     MOVE RPOL-POL-CTRY-CD      TO WCTLC-CTRY-CD
006002     MOVE WGLOB-COMPANY-CODE    TO WCTLC-CO-ID
006002     SET WCTLC-CTRY-LOC-TYP-ISSUE  TO TRUE
006002     PERFORM  CTLC-1000-READ
006002         THRU CTLC-1000-READ-X
006002     IF  NOT WCTLC-IO-OK
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE ISSUE-LOCATION (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-XHBT-ISS-LOC-CD
                                      TO RPOL-XHBT-ISS-LOC-CD
557660     END-IF.

       5111-EDIT-ISSUE-LOCATION-X.
           EXIT.
      *
      *---------------------------
       5112-EDIT-CURR-LOCATION.
      *---------------------------

           IF  MIR-XHBT-CRNT-LOC-CD = SPACES
               MOVE RPOL-XHBT-CRNT-LOC-CD
                                      TO MIR-XHBT-CRNT-LOC-CD
               GO TO 5112-EDIT-CURR-LOCATION-X
557660     END-IF.

           IF  MIR-XHBT-CRNT-LOC-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RPOL-XHBT-CRNT-LOC-CD
               MOVE SPACES            TO MIR-XHBT-CRNT-LOC-CD
               GO TO 5112-EDIT-CURR-LOCATION-X
557660     END-IF.

006002*    MOVE MIR-XHBT-CRNT-LOC-CD  TO WEDIT-ETBL-VALU-ID
006002*
006002*    PERFORM  CLOC-1000-EDIT-CURR-LOCATION
006002*        THRU CLOC-1000-EDIT-CURR-LOCATION-X.
006002*
006002*    IF  NOT WEDIT-IO-OK
006002     MOVE MIR-XHBT-CRNT-LOC-CD  TO WCTLC-CTRY-LOC-CD
006002     MOVE RPOL-POL-CTRY-CD      TO WCTLC-CTRY-CD
006002     MOVE WGLOB-COMPANY-CODE    TO WCTLC-CO-ID
006002     SET WCTLC-CTRY-LOC-TYP-CURRENT TO TRUE
006002     PERFORM  CTLC-1000-READ
006002         THRU CTLC-1000-READ-X
006002     IF  NOT WCTLC-IO-OK

               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE CURRENT-LOCATION (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-XHBT-CRNT-LOC-CD
                                      TO RPOL-XHBT-CRNT-LOC-CD
557660     END-IF.

       5112-EDIT-CURR-LOCATION-X.
           EXIT.
      *
      *---------------------------
       5113-EDIT-LANOAMT.
      *---------------------------

           IF  MIR-UL-LAPS-NOTI-AMT = SPACES
008455*        MOVE RPOL-UL-LAPS-NOTI-AMT   TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-UL-LAPS-NOTI-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-UL-LAPS-NOTI-AMT * 100
020874         MOVE RPOL-UL-LAPS-NOTI-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-UL-LAPS-NOTI-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-UL-LAPS-NOTI-AMT
               GO TO 5113-EDIT-LANOAMT-X
557660     END-IF.

           IF  MIR-UL-LAPS-NOTI-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-UL-LAPS-NOTI-AMT
008455         MOVE  ZEROS            TO MIR-UL-LAPS-NOTI-AMT
557660     END-IF.

           MOVE MIR-UL-LAPS-NOTI-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-UL-LAPS-NOTI-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-UL-LAPS-NOTI-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-UL-LAPS-NOTI-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-UL-LAPS-NOTI-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-UL-LAPS-NOTI-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE LAPSE-NTC-AMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5113-EDIT-LANOAMT-X.
           EXIT.
      *
      *---------------------------
016395*5114-EDIT-AN-PAC-DT.
016395 5114-EDIT-AN-PMT-DT.
      *---------------------------

016395*    IF  MIR-POL-PAC-DRW-DT = SPACES
016395     IF  MIR-POL-PMT-DRW-DT = SPACES
557665*        MOVE RPOL-POL-ANPAYO-PAC-DT  TO L1640-INTERNAL-DATE
016395*        MOVE RPOL-POL-PAC-DRW-DT
016395         MOVE RPOL-POL-PMT-DRW-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
016395*                               TO MIR-POL-PAC-DRW-DT
016395                                TO MIR-POL-PMT-DRW-DT
016395*        GO TO 5114-EDIT-AN-PAC-DT-X
016395         GO TO 5114-EDIT-AN-PMT-DT-X
557660     END-IF.

016395*    IF  MIR-POL-PAC-DRW-DT = EBLCH-BLANK-FIELD-CHAR
016395     IF  MIR-POL-PMT-DRW-DT = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-REQUIRED          TO TRUE
557665*        MOVE WWKDT-ZERO-DT           TO RPOL-POL-ANPAYO-PAC-DT
016395*        MOVE WWKDT-ZERO-DT     TO RPOL-POL-PAC-DRW-DT
016395         MOVE WWKDT-ZERO-DT     TO RPOL-POL-PMT-DRW-DT
016395*        MOVE SPACES            TO MIR-POL-PAC-DRW-DT
016395         MOVE SPACES            TO MIR-POL-PMT-DRW-DT
016395*        GO TO 5114-EDIT-AN-PAC-DT-X
016395         GO TO 5114-EDIT-AN-PMT-DT-X
557660     END-IF.

016395*    MOVE MIR-POL-PAC-DRW-DT    TO L1640-EXTERNAL-DATE
016395     MOVE MIR-POL-PMT-DRW-DT    TO L1640-EXTERNAL-DATE
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE ANN-PAC-DATE (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
557665*        MOVE L1640-INTERNAL-DATE     TO RPOL-POL-ANPAYO-PAC-DT
557665         MOVE L1640-INTERNAL-DATE
016395*                               TO RPOL-POL-PAC-DRW-DT
016395                                TO RPOL-POL-PMT-DRW-DT
557660     END-IF.

016395*5114-EDIT-AN-PAC-DT-X.
016395 5114-EDIT-AN-PMT-DT-X.
           EXIT.
      *
      *---------------------------
       5115-EDIT-PREVFAC.
      *---------------------------

           IF  MIR-POL-PREV-FACE-AMT = SPACES
008455*        MOVE RPOL-POL-PREV-FACE-AMT  TO WS-HOLD-9-2-S
008455*        MOVE WS-DISP-9-2-S           TO MIR-POL-PREV-FACE-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PREV-FACE-AMT * 100
020874         MOVE RPOL-POL-PREV-FACE-AMT TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PREV-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PREV-FACE-AMT
               GO TO 5115-EDIT-PREVFAC-X
557660     END-IF.

           IF  MIR-POL-PREV-FACE-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-POL-PREV-FACE-AMT
008455         MOVE  ZEROS            TO MIR-POL-PREV-FACE-AMT
557660     END-IF.

           MOVE MIR-POL-PREV-FACE-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-PREV-FACE-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-PREV-FACE-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-9-2-S
008455*        MOVE WS-DISP-9-2-S           TO MIR-POL-PREV-FACE-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PREV-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PREV-FACE-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PREV-FACE-AMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5115-EDIT-PREVFAC-X.
           EXIT.
      *
      *---------------------------
       5116-EDIT-TOTDIV.
      *---------------------------

           IF  MIR-DIV-DCLR-LTD-AMT = SPACES
008455*        MOVE RPOL-DIV-DCLR-LTD-AMT    TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-DIV-DCLR-LTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-DIV-DCLR-LTD-AMT * 100
020874         MOVE RPOL-DIV-DCLR-LTD-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DIV-DCLR-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DIV-DCLR-LTD-AMT
               GO TO 5116-EDIT-TOTDIV-X
557660     END-IF.

           IF  MIR-DIV-DCLR-LTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'              TO MIR-DIV-DCLR-LTD-AMT
008455         MOVE  ZEROS            TO MIR-DIV-DCLR-LTD-AMT
557660     END-IF.

           MOVE MIR-DIV-DCLR-LTD-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-DIV-DCLR-LTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-DIV-DCLR-LTD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-DIV-DCLR-LTD-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DIV-DCLR-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DIV-DCLR-LTD-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE TOT-DIV-DECL (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5116-EDIT-TOTDIV-X.
           EXIT.
      *
      *---------------------------
       5117-EDIT-ACTYPE.
      *---------------------------

           IF  MIR-POL-GL-ACCT-TYP-CD = SPACES
               MOVE RPOL-POL-GL-ACCT-TYP-CD
                                      TO MIR-POL-GL-ACCT-TYP-CD
               GO TO 5117-EDIT-ACTYPE-X
557660     END-IF.

           SET UPDATE-REQUIRED              TO TRUE.

           IF  MIR-POL-GL-ACCT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-POL-GL-ACCT-TYP-CD
557660     END-IF.

           MOVE MIR-POL-GL-ACCT-TYP-CD       TO RPOL-POL-GL-ACCT-TYP-CD.

       5117-EDIT-ACTYPE-X.
           EXIT.
      *
      *---------------------------
       5118-EDIT-PARDIG.
      *---------------------------

           IF  MIR-POL-ACCT-PAR-CD = SPACES
               MOVE RPOL-POL-ACCT-PAR-CD
                                      TO MIR-POL-ACCT-PAR-CD
               GO TO 5118-EDIT-PARDIG-X
557660     END-IF.

           IF  MIR-POL-ACCT-PAR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-POL-ACCT-PAR-CD
557660     END-IF.

           IF  MIR-POL-ACCT-PAR-CD = '0'
           OR  MIR-POL-ACCT-PAR-CD = '1'
           OR  MIR-POL-ACCT-PAR-CD = ' '
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-POL-ACCT-PAR-CD
                                      TO RPOL-POL-ACCT-PAR-CD
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE W-PD (WGLOB-LANG-SUB)   TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5118-EDIT-PARDIG-X.
           EXIT.
      *
      *---------------------------
       5119-EDIT-DIV-YTD.
      *---------------------------

012181*    IF  MIR-DIV-DCLR-YTD-AMT = SPACES
012181     IF  MIR-DIV-DCLR-DUR-AMT = SPACES
008455*        MOVE RPOL-DIV-DCLR-YTD-AMT   TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-DIV-DCLR-YTD-AMT
012181*        COMPUTE L0290-INPUT-NUMBER = RPOL-DIV-DCLR-YTD-AMT * 100
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-DIV-DCLR-DUR-AMT * 100
020874         MOVE RPOL-DIV-DCLR-DUR-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
012181*        MOVE LENGTH OF MIR-DIV-DCLR-YTD-AMT
012181         MOVE LENGTH OF MIR-DIV-DCLR-DUR-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
012181*        MOVE L0290-OUTPUT-DATA TO MIR-DIV-DCLR-YTD-AMT
012181         MOVE L0290-OUTPUT-DATA TO MIR-DIV-DCLR-DUR-AMT
               GO TO 5119-EDIT-DIV-YTD-X
557660     END-IF.

012181*    IF  MIR-DIV-DCLR-YTD-AMT = EBLCH-BLANK-FIELD-CHAR
012181     IF  MIR-DIV-DCLR-DUR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'              TO MIR-DIV-DCLR-YTD-AMT
012181*        MOVE  ZEROS            TO MIR-DIV-DCLR-YTD-AMT
012181         MOVE  ZEROS            TO MIR-DIV-DCLR-DUR-AMT
557660     END-IF.

012181*    MOVE MIR-DIV-DCLR-YTD-AMT  TO L0280-INPUT-DATA.
012181     MOVE MIR-DIV-DCLR-DUR-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
012181*    MOVE LENGTH OF MIR-DIV-DCLR-YTD-AMT
012181     MOVE LENGTH OF MIR-DIV-DCLR-DUR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
012181*                               TO RPOL-DIV-DCLR-YTD-AMT
012181                                TO RPOL-DIV-DCLR-DUR-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-DIV-DCLR-YTD-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
012181*        MOVE LENGTH OF MIR-DIV-DCLR-YTD-AMT
012181         MOVE LENGTH OF MIR-DIV-DCLR-DUR-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
012181*        MOVE L0290-OUTPUT-DATA TO MIR-DIV-DCLR-YTD-AMT
012181         MOVE L0290-OUTPUT-DATA TO MIR-DIV-DCLR-DUR-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE DIV-YTD (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510023'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5119-EDIT-DIV-YTD-X.
           EXIT.
      *
      *---------------------------
       5120-EDIT-DIV-DEP.
      *---------------------------

           IF  MIR-POL-DOD-ACUM-AMT = SPACES
008455*        MOVE RPOL-POL-DOD-ACUM-AMT   TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-POL-DOD-ACUM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-DOD-ACUM-AMT * 100
020874         MOVE RPOL-POL-DOD-ACUM-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-DOD-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-DOD-ACUM-AMT
               GO TO 5120-EDIT-DIV-DEP-X
557660     END-IF.

           IF  MIR-POL-DOD-ACUM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'              TO MIR-POL-DOD-ACUM-AMT
008455         MOVE  ZEROS            TO MIR-POL-DOD-ACUM-AMT
557660     END-IF.

           MOVE MIR-POL-DOD-ACUM-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-DOD-ACUM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-DOD-ACUM-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-POL-DOD-ACUM-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-DOD-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-DOD-ACUM-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE DIV-DEP (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510024'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5120-EDIT-DIV-DEP-X.
           EXIT.
      *
      *---------------------------
       5121-EDIT-DIV-AVB.
      *---------------------------

           IF  MIR-POL-DOD-AVB-AMT = SPACES
008455*        MOVE RPOL-POL-DOD-AVB-AMT    TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-POL-DOD-AVB-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-DOD-AVB-AMT * 100
020874         MOVE RPOL-POL-DOD-AVB-AMT TO L0290-INPUT-V02
008455         MOVE 2                    TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-DOD-AVB-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-DOD-AVB-AMT
               GO TO 5121-EDIT-DIV-AVB-X
557660     END-IF.

           IF  MIR-POL-DOD-AVB-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'              TO MIR-POL-DOD-AVB-AMT
008455         MOVE  ZEROS            TO MIR-POL-DOD-AVB-AMT
557660     END-IF.

           MOVE MIR-POL-DOD-AVB-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-DOD-AVB-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-DOD-AVB-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-POL-DOD-AVB-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-DOD-AVB-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-DOD-AVB-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE AVG-BAL (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5121-EDIT-DIV-AVB-X.
           EXIT.
      *
      *---------------------------
       5122-EDIT-DIV-IR.
      *---------------------------

           IF  MIR-POL-DOD-INT-RT = SPACES
016641*        MOVE RPOL-POL-DOD-INT-RT
016641*                               TO WS-HOLD-0-5
016641*        MOVE WS-DISP-0-5       TO MIR-POL-DOD-INT-RT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*            RPOL-POL-DOD-INT-RT * 100000
020874         MOVE RPOL-POL-DOD-INT-RT TO L0290-INPUT-V05
016641         MOVE 5  TO L0290-PRECISION
016641         MOVE LENGTH OF MIR-POL-DOD-INT-RT
016641                                TO L0290-MAX-OUT-LEN
016641         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016641         MOVE L0290-OUTPUT-DATA TO MIR-POL-DOD-INT-RT
               GO TO 5122-EDIT-DIV-IR-X
557660     END-IF.

           IF  MIR-POL-DOD-INT-RT = EBLCH-BLANK-FIELD-CHAR
               MOVE '.00000'          TO MIR-POL-DOD-INT-RT
557660     END-IF.

           MOVE MIR-POL-DOD-INT-RT    TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 5                     TO L0280-PRECISION.
           MOVE 0                     TO L0280-LENGTH.
016641*    MOVE 6                     TO L0280-INPUT-SIZE.
016641     MOVE 7                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT      TO WS-PACK-S18-0
               MOVE WS-PACK-S13-5     TO RPOL-POL-DOD-INT-RT
               MOVE WS-PACK-S13-5     TO WS-HOLD-0-5
               MOVE WS-DISP-0-5       TO MIR-POL-DOD-INT-RT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-R (WGLOB-LANG-SUB)  TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5122-EDIT-DIV-IR-X.
           EXIT.
      *
      *---------------------------
       5123-EDIT-DIV-INT.
      *---------------------------

           IF  MIR-DOD-CRNT-INT-AMT = SPACES
008455*        MOVE RPOL-DOD-CRNT-INT-AMT   TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-DOD-CRNT-INT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-DOD-CRNT-INT-AMT * 100
020874         MOVE RPOL-DOD-CRNT-INT-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DOD-CRNT-INT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DOD-CRNT-INT-AMT
               GO TO 5123-EDIT-DIV-INT-X
557660     END-IF.

           IF  MIR-DOD-CRNT-INT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'              TO MIR-DOD-CRNT-INT-AMT
008455         MOVE  ZEROS            TO MIR-DOD-CRNT-INT-AMT
557660     END-IF.

           MOVE MIR-DOD-CRNT-INT-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-DOD-CRNT-INT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-DOD-CRNT-INT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-DOD-CRNT-INT-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DOD-CRNT-INT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DOD-CRNT-INT-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE DIV-INT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510027'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5123-EDIT-DIV-INT-X.
           EXIT.
      *
      *---------------------------
       5124-EDIT-DIV-YR.
      *---------------------------

           IF  MIR-POL-PREV-DIV-DUR = SPACES
               MOVE RPOL-POL-PREV-DIV-DUR
                                      TO MIR-POL-PREV-DIV-DUR
               GO TO 5124-EDIT-DIV-YR-X
557660     END-IF.

           IF  MIR-POL-PREV-DIV-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE '000'             TO MIR-POL-PREV-DIV-DUR
557660     END-IF.

           MOVE MIR-POL-PREV-DIV-DUR  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT      TO RPOL-POL-PREV-DIV-DUR-N
               MOVE L0280-OUTPUT      TO WS-HOLD-3-0
               MOVE WS-DISP-3-0       TO MIR-POL-PREV-DIV-DUR
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE DV-Y (WGLOB-LANG-SUB)   TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5124-EDIT-DIV-YR-X.
           EXIT.
      *
      *---------------------------
       5125-EDIT-TOT-PUA.
      *---------------------------

           IF  MIR-PUA-LTD-FACE-AMT = SPACES
008455*        MOVE RPOL-PUA-LTD-FACE-AMT   TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-PUA-LTD-FACE-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-PUA-LTD-FACE-AMT * 100
020874         MOVE RPOL-PUA-LTD-FACE-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PUA-LTD-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PUA-LTD-FACE-AMT
               GO TO 5125-EDIT-TOT-PUA-X
557660     END-IF.

           IF  MIR-PUA-LTD-FACE-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-PUA-LTD-FACE-AMT
008455         MOVE  ZEROS            TO MIR-PUA-LTD-FACE-AMT
557660     END-IF.

           MOVE MIR-PUA-LTD-FACE-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PUA-LTD-FACE-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-PUA-LTD-FACE-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-PUA-LTD-FACE-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PUA-LTD-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PUA-LTD-FACE-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE TOT-PUA (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5125-EDIT-TOT-PUA-X.
           EXIT.
      *
      *---------------------------
       5126-EDIT-CURR-PUA.
      *---------------------------

           IF  MIR-PUA-YTD-FACE-AMT = SPACES
008455*        MOVE RPOL-PUA-YTD-FACE-AMT   TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-PUA-YTD-FACE-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-PUA-YTD-FACE-AMT * 100
020874         MOVE RPOL-PUA-YTD-FACE-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PUA-YTD-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PUA-YTD-FACE-AMT
               GO TO 5126-EDIT-CURR-PUA-X
557660     END-IF.

           IF  MIR-PUA-YTD-FACE-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-PUA-YTD-FACE-AMT
008455         MOVE  ZEROS            TO MIR-PUA-YTD-FACE-AMT
557660     END-IF.

           MOVE MIR-PUA-YTD-FACE-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PUA-YTD-FACE-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-PUA-YTD-FACE-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-PUA-YTD-FACE-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PUA-YTD-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PUA-YTD-FACE-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE CUR-PUA (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5126-EDIT-CURR-PUA-X.
           EXIT.
      *
      *---------------------------
       5127-EDIT-OYT.
      *---------------------------

           IF  MIR-POL-OYT-AMT = SPACES
008455*        MOVE RPOL-POL-OYT-AMT        TO WS-HOLD-7-0
008455*        MOVE WS-DISP-7-0             TO MIR-POL-OYT-AMT
020874*        MOVE RPOL-POL-OYT-AMT  TO L0290-INPUT-NUMBER
020874         MOVE RPOL-POL-OYT-AMT  TO L0290-INPUT-V00
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-OYT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-OYT-AMT
               GO TO 5127-EDIT-OYT-X
557660     END-IF.

           IF  MIR-POL-OYT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000'               TO MIR-POL-OYT-AMT
008455         MOVE  ZEROS            TO MIR-POL-OYT-AMT
557660     END-IF.

           MOVE MIR-POL-OYT-AMT       TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 7                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-OYT-AMT
                                      TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-OYT-AMT
                                      TO L0280-LENGTH.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT      TO RPOL-POL-OYT-AMT
008455*        MOVE L0280-OUTPUT            TO WS-HOLD-7-0
008455*        MOVE WS-DISP-7-0             TO MIR-POL-OYT-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-OYT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-OYT-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE OYT (WGLOB-LANG-SUB)    TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5127-EDIT-OYT-X.
           EXIT.
      *
      *---------------------------
       5128-EDIT-LNAMT.
      *---------------------------

           IF  MIR-LOAN-AMT-T (1)              =  SPACES
008455*        MOVE RPOLL-LOAN-AMT          TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AMT-T (1)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AMT * 100
020874         MOVE RPOLL-LOAN-AMT    TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AMT-T (1)
               GO TO 5128-EDIT-LNAMT-X
557660     END-IF.

           IF  MIR-LOAN-AMT-T (1)              =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-LOAN-AMT-T (1)
008455         MOVE  ZEROS            TO MIR-LOAN-AMT-T (1)
557660     END-IF.

           MOVE MIR-LOAN-AMT-T (1)    TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AMT-T (1)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AMT-T (1)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE LOAN-AMT-1 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5128-EDIT-LNAMT-X.
           EXIT.
      *
      *---------------------------
       5129-EDIT-LNIR1.
      *---------------------------

018842*    IF  MIR-LOAN-INT-RT-T (1)               =  SPACES
018842     IF  MIR-LOAN-INT-PCT-T (1)              =  SPACES
016641*        MOVE RPOLL-LOAN-INT-RT TO WS-HOLD-0-5
016641*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-RT-T (1)
020874*        COMPUTE L0290-INPUT-NUMBER =
018842*            RPOLL-LOAN-INT-RT * 100000
020874*            RPOLL-LOAN-INT-PCT * 10000
020874         MOVE RPOLL-LOAN-INT-PCT   TO L0290-INPUT-V04
018842*        MOVE 5  TO L0290-PRECISION
018842         MOVE 4  TO L0290-PRECISION
018842*        MOVE LENGTH OF MIR-LOAN-INT-RT-T (1)
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (1)
016641                                TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842*        MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-RT-T (1)
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (1)
               GO TO 5129-EDIT-LNIR1-X
557660     END-IF.

018842*    IF  MIR-LOAN-INT-RT-T (1) =  EBLCH-BLANK-FIELD-CHAR
018842     IF  MIR-LOAN-INT-PCT-T (1) =  EBLCH-BLANK-FIELD-CHAR
018842*        MOVE '.00000'          TO MIR-LOAN-INT-RT-T (1)
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (1)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (1)
557660     END-IF.

018842*    MOVE MIR-LOAN-INT-RT-T(1)  TO L0280-INPUT-DATA.
018842     MOVE MIR-LOAN-INT-PCT-T(1) TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
018842*    MOVE 5                     TO L0280-PRECISION.
018842     MOVE 4                     TO L0280-PRECISION.
018842*    MOVE 0                     TO L0280-LENGTH.
018842     MOVE 3                     TO L0280-LENGTH.
016641*    MOVE 6                     TO L0280-INPUT-SIZE.
018842*    MOVE 7                     TO L0280-INPUT-SIZE.
018842     MOVE LENGTH OF MIR-LOAN-INT-PCT-T (1)
018842                                TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
018842*        IF L0280-OUTPUT-V05 NOT = RPOLL-LOAN-INT-RT
018842         IF L0280-OUTPUT-V04 NOT = RPOLL-LOAN-INT-PCT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
018842*        MOVE L0280-OUTPUT      TO WS-PACK-S18-0
018842*        MOVE WS-PACK-S13-5     TO RPOLL-LOAN-INT-RT
018842*        MOVE WS-PACK-S13-5     TO WS-HOLD-0-5
018842*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-RT-T (1)
018842         MOVE L0280-OUTPUT-V04  TO RPOLL-LOAN-INT-PCT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*            L0280-OUTPUT-V04 * 10000
020874         MOVE L0280-OUTPUT-V04  TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (1)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (1)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-R-1 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5129-EDIT-LNIR1-X.
           EXIT.
      *
      *---------------------------
       5130-EDIT-LNIRM1.
      *---------------------------

018842*    IF  MIR-LOAN-INT-MAX-RT-T (1)              =  SPACES
018842     IF  MIR-LOAN-INT-MAX-PCT-T (1)             =  SPACES
016641*        MOVE RPOLL-LOAN-INT-MAX-RT
016641*                               TO WS-HOLD-0-5
016641*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-MAX-RT-T (1)
020874*        COMPUTE L0290-INPUT-NUMBER =
018842*            RPOLL-LOAN-INT-MAX-RT * 100000
020874*            RPOLL-LOAN-INT-MAX-PCT * 10000
020874         MOVE RPOLL-LOAN-INT-MAX-PCT          TO L0290-INPUT-V04
018842*        MOVE 5  TO L0290-PRECISION
018842         MOVE 4  TO L0290-PRECISION
018842*        MOVE LENGTH OF MIR-LOAN-INT-MAX-RT-T (1)
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (1)
016641                                TO L0290-MAX-OUT-LEN
016641         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842*        MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-RT-T (1)
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (1)
               GO TO 5130-EDIT-LNIRM1-X
557660     END-IF.

018842*    IF  MIR-LOAN-INT-MAX-RT-T (1) =  EBLCH-BLANK-FIELD-CHAR
018842     IF  MIR-LOAN-INT-MAX-PCT-T (1) =  EBLCH-BLANK-FIELD-CHAR
018842*        MOVE '.00000'          TO MIR-LOAN-INT-MAX-RT-T (1)
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (1)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (1)
557660     END-IF.

018842*    MOVE MIR-LOAN-INT-MAX-RT-T(1)
018842     MOVE MIR-LOAN-INT-MAX-PCT-T(1)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
018842*    MOVE 5                     TO L0280-PRECISION.
018842     MOVE 4                     TO L0280-PRECISION.
018842*    MOVE 0                     TO L0280-LENGTH.
018842     MOVE 3                     TO L0280-LENGTH.
016641*    MOVE 6                     TO L0280-INPUT-SIZE.
018842*    MOVE 7                     TO L0280-INPUT-SIZE.
018842     MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (1)
018842                                TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
018842*        IF L0280-OUTPUT-V05 NOT = RPOLL-LOAN-INT-MAX-RT
018842         IF L0280-OUTPUT-V04 NOT = RPOLL-LOAN-INT-MAX-PCT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
018842*        MOVE L0280-OUTPUT      TO WS-PACK-S18-0
018842*        MOVE WS-PACK-S13-5     TO RPOLL-LOAN-INT-MAX-RT
018842*        MOVE WS-PACK-S13-5     TO WS-HOLD-0-5
018842*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-MAX-RT-T(1)
018842         MOVE L0280-OUTPUT-V04  TO RPOLL-LOAN-INT-MAX-PCT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*            L0280-OUTPUT-V04 * 10000
020874         MOVE L0280-OUTPUT-V04           TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (1)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (1)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE MAX-R-1 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5130-EDIT-LNIRM1-X.
           EXIT.
      *
      *---------------------------
       5131-EDIT-LNBIL1.
      *---------------------------

           IF  MIR-LOAN-INT-BILL-AMT-T (1)              =  SPACES
008455*        MOVE RPOLL-LOAN-INT-BILL-AMT
008455*                                     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S        TO MIR-LOAN-INT-BILL-AMT-T (1)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RPOLL-LOAN-INT-BILL-AMT * 100
020874         MOVE RPOLL-LOAN-INT-BILL-AMT    TO L0290-INPUT-V02
008455         MOVE 2                          TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-BILL-AMT-T (1)
               GO TO 5131-EDIT-LNBIL1-X
557660     END-IF.

           IF  MIR-LOAN-INT-BILL-AMT-T (1) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'          TO MIR-LOAN-INT-BILL-AMT-T (1)
008455         MOVE  ZEROS            TO MIR-LOAN-INT-BILL-AMT-T (1)
557660     END-IF.

           MOVE MIR-LOAN-INT-BILL-AMT-T(1)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-INT-BILL-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO
                    RPOLL-LOAN-INT-BILL-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S         TO MIR-LOAN-INT-BILL-AMT-T (1)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-BILL-AMT-T (1)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-BIL-1 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510035'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5131-EDIT-LNBIL1-X.
           EXIT.
      *
      *---------------------------
       5132-EDIT-LNITY1.
      *---------------------------

           IF  MIR-LOAN-INT-YTD-AMT-T (1)              =  SPACES
008455*        MOVE RPOLL-LOAN-INT-YTD-AMT
008455*                                     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S          TO MIR-LOAN-INT-YTD-AMT-T (1)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-YTD-AMT * 100
020874         MOVE RPOLL-LOAN-INT-YTD-AMT     TO L0290-INPUT-V02
008455         MOVE 2                          TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-YTD-AMT-T (1)
               GO TO 5132-EDIT-LNITY1-X
557660     END-IF.

           IF  MIR-LOAN-INT-YTD-AMT-T (1) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'             TO MIR-LOAN-INT-YTD-AMT-T (1)
008455         MOVE  ZEROS            TO MIR-LOAN-INT-YTD-AMT-T (1)
557660     END-IF.

           MOVE MIR-LOAN-INT-YTD-AMT-T(1)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-INT-YTD-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO
                    RPOLL-LOAN-INT-YTD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S          TO MIR-LOAN-INT-YTD-AMT-T (1)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-YTD-AMT-T (1)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-YTD-1 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510036'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5132-EDIT-LNITY1-X.
           EXIT.
      *
      *---------------------------
       5133-EDIT-LNAVB1.
      *---------------------------

           IF  MIR-LOAN-AVB-AMT-T (1)               =  SPACES
008455*        MOVE RPOLL-LOAN-AVB-AMT      TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AVB-AMT-T (1)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AVB-AMT * 100
020874         MOVE RPOLL-LOAN-AVB-AMT     TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AVB-AMT-T (1)
               GO TO 5133-EDIT-LNAVB1-X
557660     END-IF.

           IF  MIR-LOAN-AVB-AMT-T (1) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-LOAN-AVB-AMT-T (1)
008455         MOVE  ZEROS            TO MIR-LOAN-AVB-AMT-T (1)
557660     END-IF.

           MOVE MIR-LOAN-AVB-AMT-T (1)              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-AVB-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-AVB-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AVB-AMT-T (1)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AVB-AMT-T (1)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE AVG-BAL-1 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510037'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5133-EDIT-LNAVB1-X.
           EXIT.
      *
      *---------------------------
       5134-EDIT-LNIFV1.
      *---------------------------

           IF  MIR-LOAN-INT-TYP-CD-T (1)          =  SPACES
               MOVE RPOLL-LOAN-INT-TYP-CD
                                      TO MIR-LOAN-INT-TYP-CD-T (1)
               GO TO 5134-EDIT-LNIFV1-X
557660     END-IF.

           IF  MIR-LOAN-INT-TYP-CD-T (1) =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-LOAN-INT-TYP-CD-T (1)
557660     END-IF.

           IF  MIR-LOAN-INT-TYP-CD-T (1)       NOT =  'F'
           AND MIR-LOAN-INT-TYP-CD-T (1)       NOT =  'V'
           AND MIR-LOAN-INT-TYP-CD-T (1)       NOT =  'D'
           AND MIR-LOAN-INT-TYP-CD-T (1)       NOT =  SPACE
               SET WS-ERROR-FOUND       TO TRUE
557756*        MOVE F-V-1 (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'        TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510038'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
013578         IF MIR-LOAN-INT-TYP-CD-T (1) NOT = RPOLL-LOAN-INT-TYP-CD
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE MIR-LOAN-INT-TYP-CD-T(1)
                                      TO RPOLL-LOAN-INT-TYP-CD
557660     END-IF.
       5134-EDIT-LNIFV1-X.
           EXIT.
      *
      *---------------------------
       5135-EDIT-LNAMT2.
      *---------------------------

           IF  MIR-LOAN-AMT-T (2)              =  SPACES
008455*        MOVE RPOLL-LOAN-AMT          TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AMT-T (2)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AMT * 100
020874         MOVE RPOLL-LOAN-AMT         TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AMT-T (2)
               GO TO 5135-EDIT-LNAMT2-X
557660     END-IF.

           IF  MIR-LOAN-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-LOAN-AMT-T (2)
008455         MOVE  ZEROS            TO MIR-LOAN-AMT-T (2)
557660     END-IF.

           MOVE MIR-LOAN-AMT-T (2)    TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AMT-T (2)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AMT-T (2)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE LOAN-AMT-2 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510039'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5135-EDIT-LNAMT2-X.
           EXIT.
      *
      *---------------------------
       5136-EDIT-LNIR2.
      *---------------------------

018842*    IF  MIR-LOAN-INT-RT-T (2)                =  SPACES
018842     IF  MIR-LOAN-INT-PCT-T (2)               =  SPACES
016641*        MOVE RPOLL-LOAN-INT-RT TO WS-HOLD-0-5
016641*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-RT-T (2)
020874*        COMPUTE L0290-INPUT-NUMBER =
018842*            RPOLL-LOAN-INT-RT * 100000
020874*            RPOLL-LOAN-INT-PCT * 10000
020874         MOVE RPOLL-LOAN-INT-PCT             TO L0290-INPUT-V04
018842*        MOVE 5  TO L0290-PRECISION
018842         MOVE 4  TO L0290-PRECISION
018842*        MOVE LENGTH OF MIR-LOAN-INT-RT-T (2)
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (2)
016641                                TO L0290-MAX-OUT-LEN
016641         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842*        MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-RT-T (2)
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (2)
               GO TO 5136-EDIT-LNIR2-X
557660     END-IF.

018842*    IF  MIR-LOAN-INT-RT-T (2) =  EBLCH-BLANK-FIELD-CHAR
018842     IF  MIR-LOAN-INT-PCT-T (2) =  EBLCH-BLANK-FIELD-CHAR
018842*        MOVE '.00000'          TO MIR-LOAN-INT-RT-T (2)
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V00
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (2)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (2)
557660     END-IF.

018842*    MOVE MIR-LOAN-INT-RT-T (2) TO L0280-INPUT-DATA.
018842     MOVE MIR-LOAN-INT-PCT-T (2) TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
018842*    MOVE 5                     TO L0280-PRECISION.
018842     MOVE 4                     TO L0280-PRECISION.
018842*    MOVE 0                     TO L0280-LENGTH.
018842     MOVE 3                     TO L0280-LENGTH.
016641*    MOVE 6                     TO L0280-INPUT-SIZE.
018842*    MOVE 7                     TO L0280-INPUT-SIZE.
018842     MOVE LENGTH OF MIR-LOAN-INT-PCT-T (2)
018842                                TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
018842*        IF L0280-OUTPUT-V05 NOT = RPOLL-LOAN-INT-RT
018842         IF L0280-OUTPUT-V04 NOT = RPOLL-LOAN-INT-PCT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
018842*        MOVE L0280-OUTPUT      TO WS-PACK-S18-0
018842*        MOVE WS-PACK-S13-5     TO RPOLL-LOAN-INT-RT
018842*        MOVE WS-PACK-S13-5     TO WS-HOLD-0-5
018842*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-RT-T(2)
018842         MOVE L0280-OUTPUT-V04  TO RPOLL-LOAN-INT-PCT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*            L0280-OUTPUT-V04 * 10000
020874         MOVE L0280-OUTPUT-V04                TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (2)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (2)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-R-2 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510040'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5136-EDIT-LNIR2-X.
           EXIT.
      *
      *---------------------------
       5137-EDIT-LNIRM2.
      *---------------------------

018842*    IF  MIR-LOAN-INT-MAX-RT-T (2)               =  SPACES
018842     IF  MIR-LOAN-INT-MAX-PCT-T (2)              =  SPACES
016641*        MOVE RPOLL-LOAN-INT-MAX-RT
016641*                               TO WS-HOLD-0-5
016641*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-MAX-RT-T (2)
020874*        COMPUTE L0290-INPUT-NUMBER =
018842*            RPOLL-LOAN-INT-MAX-RT * 100000
020874*            RPOLL-LOAN-INT-MAX-PCT * 10000
020874         MOVE RPOLL-LOAN-INT-MAX-PCT          TO L0290-INPUT-V04
018842*        MOVE 5  TO L0290-PRECISION
018842         MOVE 4  TO L0290-PRECISION
018842*        MOVE LENGTH OF MIR-LOAN-INT-MAX-RT-T (2)
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (2)
016641                                TO L0290-MAX-OUT-LEN
016641         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842*        MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-RT-T (2)
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (2)
               GO TO 5137-EDIT-LNIRM2-X
557660     END-IF.

018842*    IF  MIR-LOAN-INT-MAX-RT-T (2) =  EBLCH-BLANK-FIELD-CHAR
018842     IF  MIR-LOAN-INT-MAX-PCT-T (2) =  EBLCH-BLANK-FIELD-CHAR
018842*        MOVE '.00000'          TO MIR-LOAN-INT-MAX-RT-T (2)
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (2)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (2)
557660     END-IF.

018842*    MOVE MIR-LOAN-INT-MAX-RT-T (2)
018842     MOVE MIR-LOAN-INT-MAX-PCT-T (2)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
018842*    MOVE 5                     TO L0280-PRECISION.
018842     MOVE 4                     TO L0280-PRECISION.
018842*    MOVE 0                     TO L0280-LENGTH.
018842     MOVE 3                     TO L0280-LENGTH.
016641*    MOVE 6                     TO L0280-INPUT-SIZE.
018842*    MOVE 7                     TO L0280-INPUT-SIZE.
018842     MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (2)
018842                                TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
018842*        IF L0280-OUTPUT-V05 NOT = RPOLL-LOAN-INT-MAX-RT
018842         IF L0280-OUTPUT-V04 NOT = RPOLL-LOAN-INT-MAX-PCT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
018842*        MOVE L0280-OUTPUT      TO WS-PACK-S18-0
018842*        MOVE WS-PACK-S13-5     TO RPOLL-LOAN-INT-MAX-RT
018842*        MOVE WS-PACK-S13-5     TO WS-HOLD-0-5
018842*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-MAX-RT-T (2)
018842         MOVE L0280-OUTPUT-V04  TO RPOLL-LOAN-INT-MAX-PCT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*            L0280-OUTPUT-V04 * 10000
020874         MOVE L0280-OUTPUT-V04               TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (2)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (2)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE MAX-R-2 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510041'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5137-EDIT-LNIRM2-X.
           EXIT.
      *
      *---------------------------
       5138-EDIT-LNBIL2.
      *---------------------------

           IF  MIR-LOAN-INT-BILL-AMT-T (2)              =  SPACES
008455*        MOVE RPOLL-LOAN-INT-BILL-AMT
008455*                                     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S         TO MIR-LOAN-INT-BILL-AMT-T (2)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                RPOLL-LOAN-INT-BILL-AMT * 100
020874         MOVE RPOLL-LOAN-INT-BILL-AMT  TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-BILL-AMT-T (2)
               GO TO 5138-EDIT-LNBIL2-X
557660     END-IF.

           IF  MIR-LOAN-INT-BILL-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'          TO MIR-LOAN-INT-BILL-AMT-T (2)
008455         MOVE  ZEROS            TO MIR-LOAN-INT-BILL-AMT-T (2)
557660     END-IF.

           MOVE MIR-LOAN-INT-BILL-AMT-T(2)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-INT-BILL-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO
                    RPOLL-LOAN-INT-BILL-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S         TO MIR-LOAN-INT-BILL-AMT-T (2)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-BILL-AMT-T (2)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-BIL-2 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510042'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5138-EDIT-LNBIL2-X.
           EXIT.
      *
      *---------------------------
       5139-EDIT-LNITY2.
      *---------------------------

           IF  MIR-LOAN-INT-YTD-AMT-T (2)              =  SPACES
008455*        MOVE RPOLL-LOAN-INT-YTD-AMT
008455*                                     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S          TO MIR-LOAN-INT-YTD-AMT-T (2)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-YTD-AMT * 100
020874         MOVE RPOLL-LOAN-INT-YTD-AMT  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-YTD-AMT-T (2)
               GO TO 5139-EDIT-LNITY2-X
557660     END-IF.

           IF  MIR-LOAN-INT-YTD-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'             TO MIR-LOAN-INT-YTD-AMT-T (2)
008455         MOVE  ZEROS            TO MIR-LOAN-INT-YTD-AMT-T (2)
557660     END-IF.

           MOVE MIR-LOAN-INT-YTD-AMT-T(2)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-INT-YTD-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-INT-YTD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S          TO MIR-LOAN-INT-YTD-AMT-T (2)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-YTD-AMT-T (2)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-YTD-2 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510043'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5139-EDIT-LNITY2-X.
           EXIT.
      *
      *---------------------------
       5140-EDIT-LNAVB2.
      *---------------------------

           IF  MIR-LOAN-AVB-AMT-T (2)              =  SPACES
008455*        MOVE RPOLL-LOAN-AVB-AMT      TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AVB-AMT-T (2)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AVB-AMT * 100
020874         MOVE RPOLL-LOAN-AVB-AMT  TO L0290-INPUT-V02
008455         MOVE 2                   TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AVB-AMT-T (2)
               GO TO 5140-EDIT-LNAVB2-X
557660     END-IF.

           IF  MIR-LOAN-AVB-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-LOAN-AVB-AMT-T (2)
008455         MOVE  ZEROS            TO MIR-LOAN-AVB-AMT-T (2)
557660     END-IF.

           MOVE MIR-LOAN-AVB-AMT-T (2)              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-AVB-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-AVB-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AVB-AMT-T (2)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AVB-AMT-T (2)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE AVG-BAL-2 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510044'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5140-EDIT-LNAVB2-X.
           EXIT.
      *
      *---------------------------
       5141-EDIT-LNIFV2.
      *---------------------------

           IF  MIR-LOAN-INT-TYP-CD-T (2)           =  SPACES
               MOVE RPOLL-LOAN-INT-TYP-CD
                                      TO MIR-LOAN-INT-TYP-CD-T (2)
               GO TO 5141-EDIT-LNIFV2-X
557660     END-IF.

           IF  MIR-LOAN-INT-TYP-CD-T(2) =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-LOAN-INT-TYP-CD-T (2)
557660     END-IF.

           IF  MIR-LOAN-INT-TYP-CD-T (2)       NOT =  'F'
           AND MIR-LOAN-INT-TYP-CD-T (2)       NOT =  'V'
           AND MIR-LOAN-INT-TYP-CD-T (2)       NOT =  'D'
           AND MIR-LOAN-INT-TYP-CD-T (2)       NOT =  SPACE
               SET WS-ERROR-FOUND       TO TRUE
557756*        MOVE F-V-2 (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'        TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510045'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
013578         IF MIR-LOAN-INT-TYP-CD-T (2) NOT = RPOLL-LOAN-INT-TYP-CD
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE MIR-LOAN-INT-TYP-CD-T(2)
                                      TO RPOLL-LOAN-INT-TYP-CD
557660     END-IF.

       5141-EDIT-LNIFV2-X.
           EXIT.
      *
      *---------------------------
       5142-EDIT-LNAMT3.
      *---------------------------

           IF  MIR-LOAN-AMT-T (3)              =  SPACES
008455*        MOVE RPOLL-LOAN-AMT          TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AMT-T (3)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AMT * 100
020874         MOVE RPOLL-LOAN-AMT    TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AMT-T (3)
               GO TO 5142-EDIT-LNAMT3-X
557660     END-IF.

           IF  MIR-LOAN-AMT-T (3)              =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-LOAN-AMT-T (3)
008455         MOVE  ZEROS            TO MIR-LOAN-AMT-T (3)
557660     END-IF.

           MOVE MIR-LOAN-AMT-T (3)    TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-AMT-T (3)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AMT-T (3)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AMT-T (3)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE LOAN-AMT-A (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510046'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5142-EDIT-LNAMT3-X.
           EXIT.
      *
      *---------------------------
       5143-EDIT-LNIR3.
      *---------------------------

018842*    IF  MIR-LOAN-INT-RT-T (3)               =  SPACES
018842     IF  MIR-LOAN-INT-PCT-T (3)              =  SPACES
016641*        MOVE RPOLL-LOAN-INT-RT TO WS-HOLD-0-5
016641*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-RT-T (3)
020874*        COMPUTE L0290-INPUT-NUMBER =
018842*            RPOLL-LOAN-INT-RT * 100000
020874*            RPOLL-LOAN-INT-PCT * 10000
020874         MOVE RPOLL-LOAN-INT-PCT    TO L0290-INPUT-V04
018842*        MOVE 5  TO L0290-PRECISION
018842         MOVE 4  TO L0290-PRECISION
018842*        MOVE LENGTH OF MIR-LOAN-INT-RT-T (3)
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (3)
016641                                TO L0290-MAX-OUT-LEN
016641         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842*        MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-RT-T (3)
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (3)
               GO TO 5143-EDIT-LNIR3-X
557660     END-IF.

018842*    IF  MIR-LOAN-INT-RT-T (3) =  EBLCH-BLANK-FIELD-CHAR
018842     IF  MIR-LOAN-INT-PCT-T (3) =  EBLCH-BLANK-FIELD-CHAR
018842*        MOVE '.00000'          TO MIR-LOAN-INT-RT-T (3)
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (3)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (3)
557660     END-IF.

018842*    MOVE MIR-LOAN-INT-RT-T (3) TO L0280-INPUT-DATA.
018842     MOVE MIR-LOAN-INT-PCT-T (3) TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
018842*    MOVE 5                     TO L0280-PRECISION.
018842     MOVE 4                     TO L0280-PRECISION.
018842*    MOVE 0                     TO L0280-LENGTH.
018842     MOVE 3                     TO L0280-LENGTH.
016641*    MOVE 6                     TO L0280-INPUT-SIZE.
018842*    MOVE 7                     TO L0280-INPUT-SIZE.
018842     MOVE LENGTH OF MIR-LOAN-INT-PCT-T (3)
018842                                TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
018842*        IF L0280-OUTPUT-V05 NOT = RPOLL-LOAN-INT-RT
018842         IF L0280-OUTPUT-V04 NOT = RPOLL-LOAN-INT-PCT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
018842*        MOVE L0280-OUTPUT      TO WS-PACK-S18-0
018842*        MOVE WS-PACK-S13-5     TO RPOLL-LOAN-INT-RT
018842*        MOVE WS-PACK-S13-5     TO WS-HOLD-0-5
018842*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-RT-T (3)
018842         MOVE L0280-OUTPUT-V04  TO RPOLL-LOAN-INT-PCT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*            L0280-OUTPUT-V04 * 10000
020874         MOVE L0280-OUTPUT-V04  TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-PCT-T (3)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T (3)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-R-A (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510047'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5143-EDIT-LNIR3-X.
           EXIT.
      *
      *---------------------------
       5144-EDIT-LNIRM3.
      *---------------------------


018842*    IF  MIR-LOAN-INT-MAX-RT-T (3)             =  SPACES
018842     IF  MIR-LOAN-INT-MAX-PCT-T (3)            =  SPACES
016641*        MOVE RPOLL-LOAN-INT-MAX-RT
016641*                               TO WS-HOLD-0-5
016641*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-MAX-RT-T (3)
020874*        COMPUTE L0290-INPUT-NUMBER =
018842*            RPOLL-LOAN-INT-MAX-RT * 100000
020874*            RPOLL-LOAN-INT-MAX-PCT * 10000
020874         MOVE RPOLL-LOAN-INT-MAX-PCT  TO L0290-INPUT-V04
018842*        MOVE 5  TO L0290-PRECISION
018842         MOVE 4  TO L0290-PRECISION
018842*        MOVE LENGTH OF MIR-LOAN-INT-MAX-RT-T (3)
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (3)
016641                                TO L0290-MAX-OUT-LEN
016641         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842*        MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-RT-T (3)
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (3)
               GO TO 5144-EDIT-LNIRM3-X
557660     END-IF.

018842*    IF  MIR-LOAN-INT-MAX-RT-T (3) =  EBLCH-BLANK-FIELD-CHAR
018842     IF  MIR-LOAN-INT-MAX-PCT-T (3) =  EBLCH-BLANK-FIELD-CHAR
018842*        MOVE '.00000'          TO MIR-LOAN-INT-MAX-RT-T (3)
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (3)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (3)
557660     END-IF.

018842*    MOVE MIR-LOAN-INT-MAX-RT-T (3)
018842     MOVE MIR-LOAN-INT-MAX-PCT-T (3)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
018842*    MOVE 5                     TO L0280-PRECISION.
018842     MOVE 4                     TO L0280-PRECISION.
018842*    MOVE 0                     TO L0280-LENGTH.
018842     MOVE 3                     TO L0280-LENGTH.
016641*    MOVE 6                     TO L0280-INPUT-SIZE.
018842*    MOVE 7                     TO L0280-INPUT-SIZE.
018842     MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (3)
018842                                TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
018842*        IF L0280-OUTPUT-V05 NOT = RPOLL-LOAN-INT-MAX-RT
018842         IF L0280-OUTPUT-V04 NOT = RPOLL-LOAN-INT-MAX-PCT
                   SET WS-UPDT-POLL-REQD  TO TRUE
013578         END-IF
018842*        MOVE L0280-OUTPUT      TO WS-PACK-S18-0
018842*        MOVE WS-PACK-S13-5     TO RPOLL-LOAN-INT-MAX-RT
018842*        MOVE WS-PACK-S13-5     TO WS-HOLD-0-5
018842*        MOVE WS-DISP-0-5       TO MIR-LOAN-INT-MAX-RT-T (3)
018842         MOVE L0280-OUTPUT-V04  TO RPOLL-LOAN-INT-MAX-PCT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*            L0280-OUTPUT-V04 * 10000
020874         MOVE L0280-OUTPUT-V04  TO L0290-INPUT-V04
018842         MOVE 4  TO L0290-PRECISION
018842         MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T (3)
018842                                TO L0290-MAX-OUT-LEN
018842         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
018842         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T (3)
           ELSE
               SET WS-ERROR-FOUND         TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE MAX-R-A (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'          TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510048'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5144-EDIT-LNIRM3-X.
           EXIT.
      *
      *---------------------------
       5145-EDIT-LNBIL3.
      *---------------------------

           IF  MIR-LOAN-INT-BILL-AMT-T (3)            =  SPACES
008455*        MOVE RPOLL-LOAN-INT-BILL-AMT
008455*                                  TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S        TO MIR-LOAN-INT-BILL-AMT-T (3)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                RPOLL-LOAN-INT-BILL-AMT * 100
020874         MOVE RPOLL-LOAN-INT-BILL-AMT  TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-BILL-AMT-T (3)
               GO TO 5145-EDIT-LNBIL3-X
557660     END-IF.

           IF  MIR-LOAN-INT-BILL-AMT-T (3) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'         TO MIR-LOAN-INT-BILL-AMT-T (3)
008455         MOVE  ZEROS            TO MIR-LOAN-INT-BILL-AMT-T (3)
557660     END-IF.

           MOVE MIR-LOAN-INT-BILL-AMT-T (3)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                        TO L0280-LENGTH.
008455*    MOVE 10                       TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T(3)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-INT-BILL-AMT
                   SET WS-UPDT-POLL-REQD TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-INT-BILL-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR  TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S        TO MIR-LOAN-INT-BILL-AMT-T (3)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-BILL-AMT-T (3)
           ELSE
               SET WS-ERROR-FOUND        TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-BIL-A (WGLOB-LANG-SUB)
557756*                                  TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'         TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510049'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5145-EDIT-LNBIL3-X.
           EXIT.

      *
      *---------------------------
       5146-EDIT-LNITY3.
      *---------------------------

           IF  MIR-LOAN-INT-YTD-AMT-T (3)           =  SPACES
008455*        MOVE RPOLL-LOAN-INT-YTD-AMT
008455*                                  TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S        TO MIR-LOAN-INT-YTD-AMT-T (3)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-YTD-AMT * 100
020874         MOVE RPOLL-LOAN-INT-YTD-AMT  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-YTD-AMT-T (3)
               GO TO 5146-EDIT-LNITY3-X
557660     END-IF.

           IF  MIR-LOAN-INT-YTD-AMT-T (3) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'           TO MIR-LOAN-INT-YTD-AMT-T (3)
008455         MOVE  ZEROS            TO MIR-LOAN-INT-YTD-AMT-T (3)
557660     END-IF.

           MOVE MIR-LOAN-INT-YTD-AMT-T (3)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                        TO L0280-LENGTH.
008455*    MOVE 8                        TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T(3)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-INT-YTD-AMT
                   SET WS-UPDT-POLL-REQD TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-INT-YTD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR  TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S        TO MIR-LOAN-INT-YTD-AMT-T (3)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-YTD-AMT-T (3)
           ELSE
               SET WS-ERROR-FOUND        TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE INT-YTD-A (WGLOB-LANG-SUB)
557756*                                  TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'         TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510050'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5146-EDIT-LNITY3-X.
           EXIT.
      *
      *---------------------------
       5147-EDIT-LNAVB3.
      *---------------------------

           IF  MIR-LOAN-AVB-AMT-T (3)              =  SPACES
008455*        MOVE RPOLL-LOAN-AVB-AMT      TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AVB-AMT-T (3)
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AVB-AMT * 100
020874         MOVE RPOLL-LOAN-AVB-AMT  TO L0290-INPUT-V02
008455         MOVE 2                   TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AVB-AMT-T (3)
               GO TO 5147-EDIT-LNAVB3-X
557660     END-IF.

           IF  MIR-LOAN-AVB-AMT-T (3) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-LOAN-AVB-AMT-T (3)
008455         MOVE  ZEROS            TO MIR-LOAN-AVB-AMT-T (3)
557660     END-IF.

           MOVE MIR-LOAN-AVB-AMT-T (3)              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (3)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-AVB-AMT
                   SET WS-UPDT-POLL-REQD    TO TRUE
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-AVB-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-LOAN-AVB-AMT-T (3)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LOAN-AVB-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AVB-AMT-T (3)
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE AVG-BAL-A (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510051'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5147-EDIT-LNAVB3-X.
           EXIT.
      *
      *---------------------------
       5148-EDIT-LNIFV3.
      *---------------------------

           IF  MIR-LOAN-INT-TYP-CD-T (3)           =  SPACES
               MOVE RPOLL-LOAN-INT-TYP-CD
                                      TO MIR-LOAN-INT-TYP-CD-T (3)
               GO TO 5148-EDIT-LNIFV3-X
557660     END-IF.

           IF  MIR-LOAN-INT-TYP-CD-T (3) =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-LOAN-INT-TYP-CD-T (3)
557660     END-IF.

           IF  MIR-LOAN-INT-TYP-CD-T (3)        NOT =  'F'
           AND MIR-LOAN-INT-TYP-CD-T (3)        NOT =  'V'
           AND MIR-LOAN-INT-TYP-CD-T (3)        NOT =  'D'
           AND MIR-LOAN-INT-TYP-CD-T (3)        NOT =  SPACE
557756*        MOVE F-V-A (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'         TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510052'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND        TO TRUE
           ELSE
013578         IF MIR-LOAN-INT-TYP-CD-T (3) NOT = RPOLL-LOAN-INT-TYP-CD
                   SET WS-UPDT-POLL-REQD TO TRUE
013578         END-IF
               MOVE MIR-LOAN-INT-TYP-CD-T (3)
                                      TO RPOLL-LOAN-INT-TYP-CD
557660     END-IF.

       5148-EDIT-LNIFV3-X.
           EXIT.
      *
      *---------------------------
       5149-EDIT-PDFAMT.
      *---------------------------

           IF  MIR-POL-PDF-AMT = SPACES
008455*        MOVE RPOL-POL-PDF-AMT        TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-PDF-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PDF-AMT * 100
020874         MOVE RPOL-POL-PDF-AMT  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PDF-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PDF-AMT
               GO TO 5149-EDIT-PDFAMT-X
557660     END-IF.

           IF  MIR-POL-PDF-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-POL-PDF-AMT
008455         MOVE  ZEROS            TO MIR-POL-PDF-AMT
557660     END-IF.

           MOVE MIR-POL-PDF-AMT       TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-PDF-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-PDF-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-PDF-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PDF-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PDF-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PDF-BAL (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510053'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5149-EDIT-PDFAMT-X.
           EXIT.
      *
      *---------------------------
       5150-EDIT-PDFINT.
      *---------------------------

           IF  MIR-POL-PDF-INT-AMT = SPACES
008455*        MOVE RPOL-POL-PDF-INT-AMT    TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-POL-PDF-INT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PDF-INT-AMT * 100
020874         MOVE RPOL-POL-PDF-INT-AMT  TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PDF-INT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PDF-INT-AMT
               GO TO 5150-EDIT-PDFINT-X
557660     END-IF.

           IF  MIR-POL-PDF-INT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-POL-PDF-INT-AMT
008455         MOVE  ZEROS            TO MIR-POL-PDF-INT-AMT
557660     END-IF.

           MOVE MIR-POL-PDF-INT-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-PDF-INT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-PDF-INT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-POL-PDF-INT-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PDF-INT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PDF-INT-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PDF-INT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5150-EDIT-PDFINT-X.
           EXIT.
      *
      *---------------------------
       5151-EDIT-PDFIR.
      *---------------------------

           IF  MIR-POL-PDF-INT-RT = SPACES
016641*        MOVE RPOL-POL-PDF-INT-RT
016641*                               TO WS-HOLD-0-5
016641*        MOVE WS-DISP-0-5       TO MIR-POL-PDF-INT-RT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*            RPOL-POL-PDF-INT-RT * 100000
020874         MOVE RPOL-POL-PDF-INT-RT  TO L0290-INPUT-V05
016641         MOVE 5                    TO L0290-PRECISION
016641         MOVE LENGTH OF MIR-POL-PDF-INT-RT
016641                                TO L0290-MAX-OUT-LEN
016641         SET L0290-SIGN-SUPPRESS              TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016641         MOVE L0290-OUTPUT-DATA TO MIR-POL-PDF-INT-RT
               GO TO 5151-EDIT-PDFIR-X
557660     END-IF.

           IF  MIR-POL-PDF-INT-RT = EBLCH-BLANK-FIELD-CHAR
               MOVE '.00000'          TO MIR-POL-PDF-INT-RT
557660     END-IF.

           MOVE MIR-POL-PDF-INT-RT    TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 5                     TO L0280-PRECISION.
           MOVE 0                     TO L0280-LENGTH.
016641*    MOVE 6                     TO L0280-INPUT-SIZE.
016641     MOVE 7                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT      TO WS-PACK-S18-0
               MOVE WS-PACK-S13-5     TO RPOL-POL-PDF-INT-RT
               MOVE WS-PACK-S13-5     TO WS-HOLD-0-5
               MOVE WS-DISP-0-5       TO MIR-POL-PDF-INT-RT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE RATE (WGLOB-LANG-SUB)   TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510055'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5151-EDIT-PDFIR-X.
           EXIT.
      *
      *---------------------------
       5152-EDIT-PDFAVB.
      *---------------------------

           IF  MIR-POL-PDF-AVB-AMT = SPACES
008455*        MOVE RPOL-POL-PDF-AVB-AMT    TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-PDF-AVB-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PDF-AVB-AMT * 100
020874         MOVE RPOL-POL-PDF-AVB-AMT  TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PDF-AVB-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PDF-AVB-AMT
               GO TO 5152-EDIT-PDFAVB-X
557660     END-IF.

           IF  MIR-POL-PDF-AVB-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-POL-PDF-AVB-AMT
008455         MOVE  ZEROS            TO MIR-POL-PDF-AVB-AMT
557660     END-IF.

           MOVE MIR-POL-PDF-AVB-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-PDF-AVB-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-PDF-AVB-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-PDF-AVB-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PDF-AVB-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PDF-AVB-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE AVG-BAL (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510056'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5152-EDIT-PDFAVB-X.
           EXIT.
      *
      *---------------------------
       5153-EDIT-PDFIYR.
      *---------------------------

           IF  MIR-POL-PREV-ANNV-DUR = SPACES
               MOVE RPOL-POL-PREV-ANNV-DUR
                                      TO MIR-POL-PREV-ANNV-DUR
               GO TO 5153-EDIT-PDFIYR-X
557660     END-IF.

           IF  MIR-POL-PREV-ANNV-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE '000'             TO MIR-POL-PREV-ANNV-DUR
557660     END-IF.

           MOVE MIR-POL-PREV-ANNV-DUR TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT      TO RPOL-POL-PREV-ANNV-DUR-N
               MOVE L0280-OUTPUT      TO WS-HOLD-3-0
               MOVE WS-DISP-3-0       TO MIR-POL-PREV-ANNV-DUR
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE AN-Y (WGLOB-LANG-SUB)   TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510057'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5153-EDIT-PDFIYR-X.
           EXIT.
      *
      *---------------------------
       5154-EDIT-SURACC.
      *---------------------------

           IF  MIR-SURR-DIV-ACUM-AMT = SPACES
008455*        MOVE RPOL-SURR-DIV-ACUM-AMT    TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-SURR-DIV-ACUM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-SURR-DIV-ACUM-AMT * 100
020874         MOVE RPOL-SURR-DIV-ACUM-AMT  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-SURR-DIV-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-SURR-DIV-ACUM-AMT
               GO TO 5154-EDIT-SURACC-X
557660     END-IF.

           IF  MIR-SURR-DIV-ACUM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000.00'              TO MIR-SURR-DIV-ACUM-AMT
008455         MOVE  ZEROS            TO MIR-SURR-DIV-ACUM-AMT
557660     END-IF.

           MOVE MIR-SURR-DIV-ACUM-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-SURR-DIV-ACUM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-SURR-DIV-ACUM-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2-S
008455*        MOVE WS-DISP-5-2-S           TO MIR-SURR-DIV-ACUM-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-SURR-DIV-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-SURR-DIV-ACUM-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE SURR-ACC (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510058'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5154-EDIT-SURACC-X.
           EXIT.
      *
      *---------------------------
       5155-EDIT-SURLN.
      *---------------------------

           IF  MIR-POL-SURR-LOAN-AMT = SPACES
008455*        MOVE RPOL-POL-SURR-LOAN-AMT  TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-SURR-LOAN-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-SURR-LOAN-AMT * 100
020874         MOVE RPOL-POL-SURR-LOAN-AMT  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-SURR-LOAN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-SURR-LOAN-AMT
               GO TO 5155-EDIT-SURLN-X
557660     END-IF.

           IF  MIR-POL-SURR-LOAN-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-POL-SURR-LOAN-AMT
008455         MOVE  ZEROS            TO MIR-POL-SURR-LOAN-AMT
557660     END-IF.

           MOVE MIR-POL-SURR-LOAN-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-SURR-LOAN-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-SURR-LOAN-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-SURR-LOAN-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-SURR-LOAN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-SURR-LOAN-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE SURR-LOAN (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510059'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5155-EDIT-SURLN-X.
           EXIT.
      *
      *---------------------------
       5156-EDIT-TERPUA.
      *---------------------------

           IF  MIR-POL-TRMN-PUA-AMT = SPACES
008455*        MOVE RPOL-POL-TRMN-PUA-AMT   TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-TRMN-PUA-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-TRMN-PUA-AMT * 100
020874         MOVE RPOL-POL-TRMN-PUA-AMT  TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-TRMN-PUA-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-TRMN-PUA-AMT
               GO TO 5156-EDIT-TERPUA-X
557660     END-IF.

           IF  MIR-POL-TRMN-PUA-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-POL-TRMN-PUA-AMT
008455         MOVE  ZEROS            TO MIR-POL-TRMN-PUA-AMT
557660     END-IF.

           MOVE MIR-POL-TRMN-PUA-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-TRMN-PUA-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-TRMN-PUA-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-TRMN-PUA-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-TRMN-PUA-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-TRMN-PUA-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE SURR-PUA (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510060'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5156-EDIT-TERPUA-X.
           EXIT.
      *
      *---------------------------
       5157-EDIT-TPUACD.
      *---------------------------

           IF  MIR-TRMN-PUA-REASN-CD = SPACES
               MOVE RPOL-TRMN-PUA-REASN-CD
                                      TO MIR-TRMN-PUA-REASN-CD
               GO TO 5157-EDIT-TPUACD-X
557660     END-IF.

           SET UPDATE-REQUIRED              TO TRUE.

           IF  MIR-TRMN-PUA-REASN-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRMN-PUA-REASN-CD
557660     END-IF.

           MOVE MIR-TRMN-PUA-REASN-CD TO RPOL-TRMN-PUA-REASN-CD.

       5157-EDIT-TPUACD-X.
           EXIT.
      *
      *---------------------------
       5158-EDIT-MISSUSP.
      *---------------------------

           IF  MIR-POL-MISC-SUSP-AMT = SPACES
008455*        MOVE RPOL-POL-MISC-SUSP-AMT  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-MISC-SUSP-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-MISC-SUSP-AMT * 100
020874         MOVE RPOL-POL-MISC-SUSP-AMT  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-MISC-SUSP-AMT
               GO TO 5158-EDIT-MISSUSP-X
557660     END-IF.

           IF  MIR-POL-MISC-SUSP-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-MISC-SUSP-AMT
008455         MOVE  ZEROS            TO MIR-POL-MISC-SUSP-AMT
557660     END-IF.

           MOVE MIR-POL-MISC-SUSP-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-MISC-SUSP-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-MISC-SUSP-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-MISC-SUSP-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE MISC-SUSP (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510061'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5158-EDIT-MISSUSP-X.
           EXIT.
      *
      *---------------------------
       5159-EDIT-MISC-DATE.
      *---------------------------

           IF  MIR-POL-MISC-SUSP-DT = SPACES
               MOVE RPOL-POL-MISC-SUSP-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-MISC-SUSP-DT
               GO TO 5159-EDIT-MISC-DATE-X
557660     END-IF.

           IF  MIR-POL-MISC-SUSP-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE WWKDT-ZERO-DT     TO RPOL-POL-MISC-SUSP-DT
               MOVE SPACES            TO MIR-POL-MISC-SUSP-DT
               GO TO 5159-EDIT-MISC-DATE-X
557660     END-IF.

           MOVE MIR-POL-MISC-SUSP-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE MISC-DATE (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510062'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO RPOL-POL-MISC-SUSP-DT
557660     END-IF.

       5159-EDIT-MISC-DATE-X.
           EXIT.
      *
      *---------------------------
       5160-EDIT-PREM-SUSPENSE.
      *---------------------------

           IF  MIR-POL-PREM-SUSP-AMT = SPACES
008455*        MOVE RPOL-POL-PREM-SUSP-AMT  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-PREM-SUSP-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PREM-SUSP-AMT * 100
020874         MOVE RPOL-POL-PREM-SUSP-AMT  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PREM-SUSP-AMT
               GO TO 5160-EDIT-PREM-SUSPENSE-X
557660     END-IF.

           IF  MIR-POL-PREM-SUSP-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-PREM-SUSP-AMT
008455         MOVE  ZEROS            TO MIR-POL-PREM-SUSP-AMT
557660     END-IF.

           MOVE MIR-POL-PREM-SUSP-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-PREM-SUSP-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-PREM-SUSP-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PREM-SUSP-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PREM-SUSP (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510063'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5160-EDIT-PREM-SUSPENSE-X.
           EXIT.
      *
      *---------------------------
       5161-EDIT-PREM-DATE.
      *---------------------------

           IF  MIR-POL-PREM-SUSP-DT = SPACES
               MOVE RPOL-POL-PREM-SUSP-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-PREM-SUSP-DT
               GO TO 5161-EDIT-PREM-DATE-X
557660     END-IF.

           IF  MIR-POL-PREM-SUSP-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE WWKDT-ZERO-DT     TO RPOL-POL-PREM-SUSP-DT
               MOVE SPACES            TO MIR-POL-PREM-SUSP-DT
               GO TO 5161-EDIT-PREM-DATE-X
557660     END-IF.

           MOVE MIR-POL-PREM-SUSP-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE PREM-DATE (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510064'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO RPOL-POL-PREM-SUSP-DT
557660     END-IF.

       5161-EDIT-PREM-DATE-X.
           EXIT.
      *
      *---------------------------
       5162-EDIT-DIV-SUSP.
      *---------------------------

           IF  MIR-POL-DIV-SUSP-AMT = SPACES
008455*        MOVE RPOL-POL-DIV-SUSP-AMT   TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-DIV-SUSP-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-DIV-SUSP-AMT * 100
020874         MOVE RPOL-POL-DIV-SUSP-AMT  TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-DIV-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-DIV-SUSP-AMT
               GO TO 5162-EDIT-DIV-SUSP-X
557660     END-IF.

           IF  MIR-POL-DIV-SUSP-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-POL-DIV-SUSP-AMT
008455         MOVE  ZEROS            TO MIR-POL-DIV-SUSP-AMT
557660     END-IF.

           MOVE MIR-POL-DIV-SUSP-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-DIV-SUSP-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-DIV-SUSP-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-DIV-SUSP-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-DIV-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-DIV-SUSP-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE DIV-SUSP (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510065'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5162-EDIT-DIV-SUSP-X.
           EXIT.
      *
      *---------------------------
       5163-EDIT-DISB-AMT.
      *---------------------------

           IF  MIR-POL-OS-DISB-AMT = SPACES
008455*        MOVE RPOL-POL-OS-DISB-AMT    TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-POL-OS-DISB-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-OS-DISB-AMT * 100
020874         MOVE RPOL-POL-OS-DISB-AMT  TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-OS-DISB-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-OS-DISB-AMT
               GO TO 5163-EDIT-DISB-AMT-X
557660     END-IF.

           IF  MIR-POL-OS-DISB-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-POL-OS-DISB-AMT
008455         MOVE  ZEROS            TO MIR-POL-OS-DISB-AMT
557660     END-IF.

           MOVE MIR-POL-OS-DISB-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-OS-DISB-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-OS-DISB-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-POL-OS-DISB-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-OS-DISB-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-OS-DISB-AMT
           ELSE
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE DISP-AMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510066'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5163-EDIT-DISB-AMT-X.
           EXIT.
      *
      *---------------------------
       5164-EDIT-DISB-DATE.
      *---------------------------

           IF  MIR-POL-OS-DISB-DT = SPACES
               MOVE RPOL-POL-OS-DISB-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-OS-DISB-DT
               GO TO 5164-EDIT-DISB-DATE-X
557660     END-IF.

           IF  MIR-POL-OS-DISB-DT = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-REQUIRED          TO TRUE
               MOVE WWKDT-ZERO-DT     TO RPOL-POL-OS-DISB-DT
               MOVE SPACES            TO MIR-POL-OS-DISB-DT
               GO TO 5164-EDIT-DISB-DATE-X
557660     END-IF.

           MOVE MIR-POL-OS-DISB-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE DISB-DATE (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510067'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO RPOL-POL-OS-DISB-DT
557660     END-IF.

       5164-EDIT-DISB-DATE-X.
           EXIT.
      *
557697*-----------------------
557697 5165-EDIT-SF-PREM-RULE.
557697*-----------------------
557697     IF  MIR-SFB-NEG-SUSP-IND = SPACES
557697         MOVE L2520-SFB-NEG-SUSP-IND
                                      TO MIR-SFB-NEG-SUSP-IND
557697         GO TO 5165-EDIT-SF-PREM-RULE-X
557697     ELSE
557697         IF MIR-SFB-NEG-SUSP-IND = EBLCH-BLANK-FIELD-CHAR
557697            MOVE 'N'            TO MIR-SFB-NEG-SUSP-IND
557697         END-IF
557697     END-IF.
557697     MOVE MIR-SFB-NEG-SUSP-IND  TO  WS-SFB-NEG-SUSP-IND.
557697     IF  WS-SFB-NEG-SUSP-IND-VALID
557697         SET WS-SFB-UPDT-REQUIRED   TO TRUE
557697         MOVE MIR-SFB-NEG-SUSP-IND
                                      TO L2520-SFB-NEG-SUSP-IND
557697     ELSE
557697*MSG    'SPECIAL FREQUENCY PREMIUM RULE INVALID; MUST BE Y OR N'
557697         MOVE 'CS01510107'      TO WGLOB-MSG-REF-INFO
557697         SET WS-ERROR-FOUND         TO TRUE
557697         PERFORM  0260-1000-GENERATE-MESSAGE
557697            THRU  0260-1000-GENERATE-MESSAGE-X
557697     END-IF.
557697 5165-EDIT-SF-PREM-RULE-X.
557697     EXIT.

557697*-----------------------
557697 5166-EDIT-SF-NEG-LIMIT.
557697*-----------------------
557697     IF  MIR-SFB-NEG-SUSP-QTY = SPACES
557697         MOVE L2520-SFB-NEG-SUSP-QTY
                                      TO MIR-SFB-NEG-SUSP-QTY
557697         GO TO 5166-EDIT-SF-NEG-LIMIT-X
557697     ELSE
557697         IF  MIR-SFB-NEG-SUSP-QTY   =  EBLCH-BLANK-FIELD-CHAR
557697             MOVE ZEROS         TO MIR-SFB-NEG-SUSP-QTY
557697         END-IF
557697     END-IF.
557697     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
557697     SET L0280-SPACES-PERMITTED       TO TRUE.
557697     MOVE +2                    TO L0280-LENGTH.
557697     MOVE ZERO                  TO L0280-PRECISION.
557697     MOVE MIR-SFB-NEG-SUSP-QTY  TO L0280-INPUT-DATA.
557697     PERFORM  0280-1000-NUMERIC-EDIT
557697         THRU 0280-1000-NUMERIC-EDIT-X.
557697     IF  NOT L0280-OK
557697*MSG    'SPECIAL FREQUENCY NEGATIVE LIMIT MUST BE NUMERIC - @1'
557697         MOVE 'CS01510108'      TO  WGLOB-MSG-REF-INFO
557697         MOVE '99'              TO  WGLOB-MSG-PARM (1)
557697         SET WS-ERROR-FOUND            TO  TRUE
557697         PERFORM  0260-1000-GENERATE-MESSAGE
557697            THRU 0260-1000-GENERATE-MESSAGE-X
557697     ELSE
557697         IF  L0280-OUTPUT > 12
557697*MSG 'SPECIAL FREQUENCY NEGATIVE LIMIT INVALID;MUST BE 00 THRU 12'
557697             MOVE 'CS01510109'  TO WGLOB-MSG-REF-INFO
557697             SET WS-ERROR-FOUND            TO TRUE
557697             PERFORM  0260-1000-GENERATE-MESSAGE
557697                 THRU 0260-1000-GENERATE-MESSAGE-X
557697         ELSE
557697             SET WS-SFB-UPDT-REQUIRED  TO TRUE
557697             MOVE L0280-OUTPUT  TO L2520-SFB-NEG-SUSP-QTY
557697         END-IF
557697     END-IF.
557697 5166-EDIT-SF-NEG-LIMIT-X.
557697     EXIT.

557697*----------------------
557697 5167-EDIT-SF-BILL-AMT.
557697*----------------------
557697     IF  MIR-SFB-NXT-BILL-AMT = SPACES
008455*        MOVE L2520-SFB-NXT-BILL-AMT TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-SFB-NXT-BILL-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = L2520-SFB-NXT-BILL-AMT * 100
020874         MOVE L2520-SFB-NXT-BILL-AMT  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-SFB-NXT-BILL-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-SFB-NXT-BILL-AMT
557697         GO TO 5167-EDIT-SF-BILL-AMT-X
557697     END-IF.
557697     IF  MIR-POL-OS-DISB-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-SFB-NXT-BILL-AMT
008455         MOVE  ZEROS            TO MIR-SFB-NXT-BILL-AMT
557697     END-IF.
557697     MOVE MIR-SFB-NXT-BILL-AMT  TO L0280-INPUT-DATA.
557697     SET L0280-SIGN-PERMITTED         TO TRUE.
557697     MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-SFB-NXT-BILL-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
557697     PERFORM  0280-1000-NUMERIC-EDIT
557697         THRU 0280-1000-NUMERIC-EDIT-X.

557697     IF  L0280-OK
557697         SET WS-SFB-UPDT-REQUIRED     TO TRUE
557697         MOVE L0280-OUTPUT-DOLLAR
                                      TO L2520-SFB-NXT-BILL-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-SFB-NXT-BILL-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-SFB-NXT-BILL-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-SFB-NXT-BILL-AMT
557697     ELSE
557697*MSG 'SF BILL AMT MUST BE NUMERIC - @1
557697         MOVE 'CS01510110'      TO WGLOB-MSG-REF-INFO
008455*        MOVE '9999999.99'            TO WGLOB-MSG-PARM (1)
557697         SET WS-ERROR-FOUND           TO TRUE
557697         PERFORM  0260-1000-GENERATE-MESSAGE
557697             THRU 0260-1000-GENERATE-MESSAGE-X
557697     END-IF.
557697 5167-EDIT-SF-BILL-AMT-X.
557697     EXIT.
      *

010397*---------------------------
010397 5168-EDIT-ANNBL1.
010397*---------------------------
010397
010397     IF  MIR-LOAN-ANNV-AMT-T (1)              =  SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-ANNV-AMT
020874*                                     * 100
020874         MOVE RPOLL-LOAN-ANNV-AMT  TO L0290-INPUT-V02
010397         MOVE 2                    TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-ANNV-AMT-T (1)
010397         GO TO 5168-EDIT-ANNBL1-X
010397     END-IF.
010397
010397     IF  MIR-LOAN-ANNV-AMT-T (1) =  EBLCH-BLANK-FIELD-CHAR
010397         MOVE '00000000.00'     TO MIR-LOAN-ANNV-AMT-T (1)
010397     END-IF.
010397
010397     MOVE MIR-LOAN-ANNV-AMT-T (1)
                                      TO L0280-INPUT-DATA.
010397     SET L0280-SIGN-NOT-PERMITTED       TO TRUE.
010397     MOVE 2                     TO L0280-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
010397     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
010397     PERFORM  0280-1000-NUMERIC-EDIT
010397         THRU 0280-1000-NUMERIC-EDIT-X.
010397
010397     IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-ANNV-AMT
010397             SET WS-UPDT-POLL-REQD      TO TRUE
013578         END-IF
010397         MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-ANNV-AMT
010397         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
010397         MOVE 2                 TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-ANNV-AMT-T (1)
010397     ELSE
010397*MSG: INVALID AMOUNT FOR FIELD ANNIVERSARY BALANCE (1)
010397         MOVE 'CS01510113'      TO WGLOB-MSG-REF-INFO
010397         PERFORM  0260-1000-GENERATE-MESSAGE
010397             THRU 0260-1000-GENERATE-MESSAGE-X
010397         SET WS-ERROR-FOUND           TO TRUE
010397     END-IF.
010397
010397 5168-EDIT-ANNBL1-X.
010397     EXIT.
010397
010397
010397*---------------------------
010397 5169-EDIT-PANBL1.
010397*---------------------------
010397
010397     IF  MIR-LOAN-PREV-ANNV-AMT-T (1)              =  SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-PREV-ANNV-AMT
020874*                                     * 100
020874         MOVE RPOLL-LOAN-PREV-ANNV-AMT  TO L0290-INPUT-V02
010397         MOVE 2                         TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-PREV-ANNV-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-PREV-ANNV-AMT-T (1)
010397         GO TO 5169-EDIT-PANBL1-X
010397     END-IF.
010397
010397     IF  MIR-LOAN-PREV-ANNV-AMT-T (1) =  EBLCH-BLANK-FIELD-CHAR
010397         MOVE '00000000.00'     TO MIR-LOAN-PREV-ANNV-AMT-T (1)
010397     END-IF.
010397
010397     MOVE MIR-LOAN-PREV-ANNV-AMT-T (1)
                                      TO L0280-INPUT-DATA.
010397     SET L0280-SIGN-NOT-PERMITTED       TO TRUE.
010397     MOVE 2                     TO L0280-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-PREV-ANNV-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
010397     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
010397     PERFORM  0280-1000-NUMERIC-EDIT
010397         THRU 0280-1000-NUMERIC-EDIT-X.
010397
010397     IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-PREV-ANNV-AMT
010397             SET WS-UPDT-POLL-REQD      TO TRUE
013578         END-IF
010397         MOVE L0280-OUTPUT-DOLLAR
                                      TO
010397                                    RPOLL-LOAN-PREV-ANNV-AMT
010397         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
010397         MOVE 2                 TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-PREV-ANNV-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-PREV-ANNV-AMT-T (1)
010397     ELSE
010397*MSG: INVALID AMOUNT FOR FIELD PREV ANNIVERSARY BALANCE (1)
010397         MOVE 'CS01510114'      TO WGLOB-MSG-REF-INFO
010397         PERFORM  0260-1000-GENERATE-MESSAGE
010397             THRU 0260-1000-GENERATE-MESSAGE-X
010397         SET WS-ERROR-FOUND           TO TRUE
010397     END-IF.
010397
010397 5169-EDIT-PANBL1-X.
010397     EXIT.
010397
010397
010397
010397*---------------------------
010397 5170-EDIT-ANNBL2.
010397*---------------------------
010397
010397     IF  MIR-LOAN-ANNV-AMT-T (2)              =  SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-ANNV-AMT
020874*                                     * 100
020874         MOVE RPOLL-LOAN-ANNV-AMT  TO L0290-INPUT-V02
010397         MOVE 2                    TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-ANNV-AMT-T (2)
010397         GO TO 5170-EDIT-ANNBL2-X
010397     END-IF.
010397
010397     IF  MIR-LOAN-ANNV-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
010397         MOVE '00000000.00'     TO MIR-LOAN-ANNV-AMT-T (2)
010397     END-IF.
010397
010397     MOVE MIR-LOAN-ANNV-AMT-T (2)
                                      TO L0280-INPUT-DATA.
010397     SET L0280-SIGN-NOT-PERMITTED       TO TRUE.
010397     MOVE 2                     TO L0280-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
010397     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
010397     PERFORM  0280-1000-NUMERIC-EDIT
010397         THRU 0280-1000-NUMERIC-EDIT-X.
010397
010397     IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-ANNV-AMT
010397             SET WS-UPDT-POLL-REQD  TO TRUE
013578         END-IF
010397         MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-ANNV-AMT
010397         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
010397         MOVE 2                 TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-ANNV-AMT-T (2)
010397     ELSE
010397*MSG: INVALID AMOUNT FOR FIELD ANNIVERSARY BALANCE (2)
010397         MOVE 'CS01510115'      TO WGLOB-MSG-REF-INFO
010397         PERFORM  0260-1000-GENERATE-MESSAGE
010397             THRU 0260-1000-GENERATE-MESSAGE-X
010397         SET WS-ERROR-FOUND           TO TRUE
010397     END-IF.
010397
010397 5170-EDIT-ANNBL2-X.
010397     EXIT.
010397
010397
010397*---------------------------
010397 5171-EDIT-PANBL2.
010397*---------------------------
010397
010397     IF  MIR-LOAN-PREV-ANNV-AMT-T (2)              =  SPACES
020874*        COMPUTE L0290-INPUT-NUMBER   = RPOLL-LOAN-PREV-ANNV-AMT
020874*                                     * 100
020874         MOVE RPOLL-LOAN-PREV-ANNV-AMT  TO L0290-INPUT-V02
010397         MOVE 2                         TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-PREV-ANNV-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-PREV-ANNV-AMT-T (2)
010397         GO TO 5171-EDIT-PANBL2-X
010397     END-IF.
010397
010397     IF  MIR-LOAN-PREV-ANNV-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
010397         MOVE '00000000.00'     TO MIR-LOAN-PREV-ANNV-AMT-T (2)
010397     END-IF.
010397
010397     MOVE MIR-LOAN-PREV-ANNV-AMT-T (2)
                                      TO L0280-INPUT-DATA.
010397     SET L0280-SIGN-NOT-PERMITTED       TO TRUE.
010397     MOVE 2                     TO L0280-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
010397     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
010397     PERFORM  0280-1000-NUMERIC-EDIT
010397         THRU 0280-1000-NUMERIC-EDIT-X.
010397
010397     IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-PREV-ANNV-AMT
010397             SET WS-UPDT-POLL-REQD      TO TRUE
013578         END-IF
010397         MOVE L0280-OUTPUT-DOLLAR
                                      TO
010397                                     RPOLL-LOAN-PREV-ANNV-AMT
010397         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
010397         MOVE 2                 TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-PREV-ANNV-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-PREV-ANNV-AMT-T (2)
010397     ELSE
010397*MSG: INVALID AMOUNT FOR FIELD PREV ANNIVERSARY BALANCE (2)
010397         MOVE 'CS01510116'      TO WGLOB-MSG-REF-INFO
010397         PERFORM  0260-1000-GENERATE-MESSAGE
010397             THRU 0260-1000-GENERATE-MESSAGE-X
010397         SET WS-ERROR-FOUND           TO TRUE
010397     END-IF.
010397
010397 5171-EDIT-PANBL2-X.
010397     EXIT.
010397
010397
010397
010397*---------------------------
010397 5172-EDIT-ANNBL3.
010397*---------------------------
010397
010397     IF  MIR-LOAN-ANNV-AMT-T (3)              =  SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-ANNV-AMT
020874*                                     * 100
020874         MOVE RPOLL-LOAN-ANNV-AMT  TO L0290-INPUT-V02
010397         MOVE 2                    TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-ANNV-AMT-T (3)
010397         GO TO 5172-EDIT-ANNBL3-X
010397     END-IF.
010397
010397     IF  MIR-LOAN-ANNV-AMT-T (3) =  EBLCH-BLANK-FIELD-CHAR
010397         MOVE '00000000.00'     TO MIR-LOAN-ANNV-AMT-T (3)
010397     END-IF.
010397
010397     MOVE MIR-LOAN-ANNV-AMT-T (3)
                                      TO L0280-INPUT-DATA.
010397     SET L0280-SIGN-NOT-PERMITTED       TO TRUE.
010397     MOVE 2                     TO L0280-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (3)
                                      TO L0280-INPUT-SIZE.
010397     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
010397     PERFORM  0280-1000-NUMERIC-EDIT
010397         THRU 0280-1000-NUMERIC-EDIT-X.
010397
010397     IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-ANNV-AMT
010397             SET WS-UPDT-POLL-REQD      TO TRUE
013578         END-IF
010397         MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOLL-LOAN-ANNV-AMT
010397         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
010397         MOVE 2                 TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-ANNV-AMT-T (3)
010397     ELSE
010397*MSG: INVALID AMOUNT FOR FIELD ANNIVERSARY BALANCE (3)
010397         MOVE 'CS01510117'      TO WGLOB-MSG-REF-INFO
010397         PERFORM  0260-1000-GENERATE-MESSAGE
010397             THRU 0260-1000-GENERATE-MESSAGE-X
010397         SET WS-ERROR-FOUND           TO TRUE
010397     END-IF.
010397
010397 5172-EDIT-ANNBL3-X.
010397     EXIT.
010397
010397
010397*---------------------------
010397 5173-EDIT-PANBL3.
010397*---------------------------
010397
010397     IF  MIR-LOAN-PREV-ANNV-AMT-T (3)              =  SPACES
020874*        COMPUTE L0290-INPUT-NUMBER   = RPOLL-LOAN-PREV-ANNV-AMT
020874*                                     * 100
020874         MOVE RPOLL-LOAN-PREV-ANNV-AMT  TO L0290-INPUT-V02
010397         MOVE 2                         TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-PREV-ANNV-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-PREV-ANNV-AMT-T (3)
010397         GO TO 5173-EDIT-PANBL3-X
010397     END-IF.
010397
010397     IF  MIR-LOAN-PREV-ANNV-AMT-T (3) =  EBLCH-BLANK-FIELD-CHAR
010397         MOVE '00000000.00'     TO MIR-LOAN-PREV-ANNV-AMT-T (3)
010397     END-IF.
010397
010397     MOVE MIR-LOAN-PREV-ANNV-AMT-T (3)
                                      TO L0280-INPUT-DATA.
010397     SET L0280-SIGN-NOT-PERMITTED       TO TRUE.
010397     MOVE 2                     TO L0280-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (3)
                                      TO L0280-INPUT-SIZE.
010397     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
010397     PERFORM  0280-1000-NUMERIC-EDIT
010397         THRU 0280-1000-NUMERIC-EDIT-X.
010397
010397     IF  L0280-OK
013578         IF L0280-OUTPUT-DOLLAR NOT = RPOLL-LOAN-PREV-ANNV-AMT
010397             SET WS-UPDT-POLL-REQD      TO TRUE
013578         END-IF
010397         MOVE L0280-OUTPUT-DOLLAR
                                      TO
010397                                    RPOLL-LOAN-PREV-ANNV-AMT
010397         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
010397         MOVE 2                 TO L0290-PRECISION
010397         MOVE LENGTH OF MIR-LOAN-PREV-ANNV-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
010397         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-PREV-ANNV-AMT-T (3)
010397     ELSE
010397*MSG: INVALID AMOUNT FOR FIELD PREV ANNIVERSARY BALANCE (3)
010397         MOVE 'CS01510118'      TO WGLOB-MSG-REF-INFO
010397         PERFORM  0260-1000-GENERATE-MESSAGE
010397             THRU 0260-1000-GENERATE-MESSAGE-X
010397         SET WS-ERROR-FOUND           TO TRUE
010397     END-IF.
010397
010397 5173-EDIT-PANBL3-X.
010397     EXIT.
      *
020455*---------------------------
020455 5174-EDIT-UNDO-EFF-DT.
020455*---------------------------
020455
020455     EVALUATE TRUE
020455
020455         WHEN MIR-POL-UNDO-EFF-DT = SPACES
020455              MOVE RPOL-POL-UNDO-EFF-DT
020455                                 TO L1640-INTERNAL-DATE
020455              PERFORM  1640-8000-INTERNAL-TO-MIR
020455                  THRU 1640-8000-INTERNAL-TO-MIR-X
020455              MOVE L1640-EXTERNAL-DATE
020455                                 TO MIR-POL-UNDO-EFF-DT
020455              SET UPDATE-REQUIRED TO TRUE
020455              GO TO 5174-EDIT-UNDO-EFF-DT-X
020455
020455         WHEN MIR-POL-UNDO-EFF-DT = EBLCH-BLANK-FIELD-CHAR
020455              MOVE WWKDT-ZERO-DT TO RPOL-POL-UNDO-EFF-DT
020455              MOVE SPACES        TO MIR-POL-UNDO-EFF-DT
020455              GO TO 5174-EDIT-UNDO-EFF-DT-X
020455
020455     END-EVALUATE.
020455
020455     MOVE MIR-POL-UNDO-EFF-DT   TO L1640-EXTERNAL-DATE.
020455     PERFORM  1640-7000-MIR-TO-INT
020455         THRU 1640-7000-MIR-TO-INT-X.
020455     IF  L1640-NOT-VALID
020455         SET WS-ERROR-FOUND           TO TRUE
020455*MSG: INVALID POLICY UNDO DATE
020455         MOVE 'CS01510001'      TO WGLOB-MSG-REF-INFO
020455         PERFORM  0260-1000-GENERATE-MESSAGE
020455             THRU 0260-1000-GENERATE-MESSAGE-X
020455     ELSE
020455         SET UPDATE-REQUIRED          TO TRUE
020455         MOVE L1640-INTERNAL-DATE
020455                                TO RPOL-POL-UNDO-EFF-DT
020455     END-IF.
020455
020455 5174-EDIT-UNDO-EFF-DT-X.
020455     EXIT.
020455

026057*---------------------------
026057 5175-EDIT-INV-HIST-DT.
026057*---------------------------
026057
026057     EVALUATE TRUE
026057
026057         WHEN MIR-POL-INV-HIST-DT = SPACES
026057              MOVE RPOL-POL-INV-HIST-DT
026057                                 TO L1640-INTERNAL-DATE
026057              PERFORM  1640-8000-INTERNAL-TO-MIR
026057                  THRU 1640-8000-INTERNAL-TO-MIR-X
026057              MOVE L1640-EXTERNAL-DATE
026057                                 TO MIR-POL-INV-HIST-DT
026057              GO TO 5175-EDIT-INV-HIST-DT-X
026057
026057         WHEN MIR-POL-INV-HIST-DT = EBLCH-BLANK-FIELD-CHAR
026057              MOVE WWKDT-ZERO-DT TO RPOL-POL-INV-HIST-DT
026057              MOVE SPACES        TO MIR-POL-INV-HIST-DT
026057              SET UPDATE-REQUIRED TO TRUE
026057              GO TO 5175-EDIT-INV-HIST-DT-X
026057
026057     END-EVALUATE.
026057
026057     MOVE MIR-POL-INV-HIST-DT   TO L1640-EXTERNAL-DATE.
026057     PERFORM  1640-7000-MIR-TO-INT
026057         THRU 1640-7000-MIR-TO-INT-X.
026057     IF  L1640-NOT-VALID
026057         SET WS-ERROR-FOUND           TO TRUE
026057*MSG: INVALID POLICY INVESTMENT HISTORY START DATE
026057         MOVE 'CS01510130'      TO WGLOB-MSG-REF-INFO
026057         PERFORM  0260-1000-GENERATE-MESSAGE
026057             THRU 0260-1000-GENERATE-MESSAGE-X
026057     ELSE
026057         SET UPDATE-REQUIRED          TO TRUE
026057         MOVE L1640-INTERNAL-DATE
026057                                TO RPOL-POL-INV-HIST-DT
026057     END-IF.
026057
026057 5175-EDIT-INV-HIST-DT-X.
026057     EXIT.

      *------------------------
       5200-EDIT-SCREEN-2.
      *------------------------
      *
           PERFORM  5201-EDIT-REG-TOT
               THRU 5201-EDIT-REG-TOT-X.

           PERFORM  5202-EDIT-REG-AMD
               THRU 5202-EDIT-REG-AMD-X.

           PERFORM  5203-EDIT-REG-AJF
               THRU 5203-EDIT-REG-AJF-X.

           PERFORM  5204-EDIT-REG-RMD
               THRU 5204-EDIT-REG-RMD-X.

           PERFORM  5205-EDIT-REG-RJF
               THRU 5205-EDIT-REG-RJF-X.

           PERFORM  5206-EDIT-REG-ASP
               THRU 5206-EDIT-REG-ASP-X.

           PERFORM  5207-EDIT-MIN-PAYMENT
               THRU 5207-EDIT-MIN-PAYMENT-X.

           PERFORM  5208-EDIT-CASUAL-PAYMENT
               THRU 5208-EDIT-CASUAL-PAYMENT-X.

           PERFORM  5209-EDIT-PAY-YTD
               THRU 5209-EDIT-PAY-YTD-X.

           PERFORM  5210-EDIT-PAY-LTD
               THRU 5210-EDIT-PAY-LTD-X.

           PERFORM  5211-EDIT-ANN-SUS
               THRU 5211-EDIT-ANN-SUS-X.

           PERFORM  5212-EDIT-PAY-DATE
               THRU 5212-EDIT-PAY-DATE-X.
      *
           PERFORM  5213-EDIT-SPOUSAL-RCPT-MD
               THRU 5213-EDIT-SPOUSAL-RCPT-MD-X.

           PERFORM  5214-EDIT-SPOUSAL-RCPT-JF
               THRU 5214-EDIT-SPOUSAL-RCPT-JF-X.

           PERFORM  5215-EDIT-SPOUSAL-AMT-MD
               THRU 5215-EDIT-SPOUSAL-AMT-MD-X.

           PERFORM  5216-EDIT-SPOUSAL-AMT-JF
               THRU 5216-EDIT-SPOUSAL-AMT-JF-X.

           PERFORM  5217-EDIT-SPOUSAL-AMT-SPEC
               THRU 5217-EDIT-SPOUSAL-AMT-SPEC-X.
      *
           PERFORM  5218-EDIT-SPOUSAL-RCPT-DATE
               THRU 5218-EDIT-SPOUSAL-RCPT-DATE-X.

           PERFORM  5219-EDIT-SPOUSAL-CNTR-DATE
               THRU 5219-EDIT-SPOUSAL-CNTR-DATE-X.

           PERFORM  5220-EDIT-PREV-YR-MIN
               THRU 5220-EDIT-PREV-YR-MIN-X.

           PERFORM  5221-EDIT-MAX-PYMT
               THRU 5221-EDIT-MAX-PYMT-X.

           PERFORM  5222-EDIT-PREV-YR-MAX
               THRU 5222-EDIT-PREV-YR-MAX-X.

           PERFORM  5223-EDIT-PREV-YR-CASUAL
               THRU 5223-EDIT-PREV-YR-CASUAL-X.

           PERFORM  5224-EDIT-PREV-YR-TOT-PYMT
               THRU 5224-EDIT-PREV-YR-TOT-PYMT-X.

           PERFORM  5225-EDIT-LOCKED-IN-IND
               THRU 5225-EDIT-LOCKED-IN-IND-X.

           PERFORM  5226-EDIT-SURR-CURR-AMT
               THRU 5226-EDIT-SURR-CURR-AMT-X.

           PERFORM  5227-EDIT-SURR-PREV-AMT
               THRU 5227-EDIT-SURR-PREV-AMT-X.

           PERFORM  5228-EDIT-THRESH-AMT
               THRU 5228-EDIT-THRESH-AMT-X.

           PERFORM  5229-EDIT-THRESH-PERIOD
               THRU 5229-EDIT-THRESH-PERIOD-X.

           PERFORM  5230-EDIT-PREV-FACE-DECRS
               THRU 5230-EDIT-PREV-FACE-DECRS-X.

           PERFORM  5231-EDIT-POL-CSV-ALLOC
               THRU 5231-EDIT-POL-CSV-ALLOC-X.

           PERFORM  5232-EDIT-FREE-DRAW-CD
               THRU 5232-EDIT-FREE-DRAW-CD-X.

           PERFORM  5233-EDIT-FREE-DRAW-PERIOD
               THRU 5233-EDIT-FREE-DRAW-PERIOD-X.

           PERFORM  5234-EDIT-DRAWS-REMAINING
               THRU 5234-EDIT-DRAWS-REMAINING-X.

           PERFORM  5235-EDIT-DRAW-AMOUNT
               THRU 5235-EDIT-DRAW-AMOUNT-X.

           PERFORM  5236-EDIT-RESET-YEAR
               THRU 5236-EDIT-RESET-YEAR-X.

016109     PERFORM  5237-EDIT-FREE-XFER-CD
016109         THRU 5237-EDIT-FREE-XFER-CD-X.
016109
016109     PERFORM  5238-EDIT-FREE-XFER-PERIOD
016109         THRU 5238-EDIT-FREE-XFER-PERIOD-X.
016109
016109     PERFORM  5239-EDIT-XFERS-REMAINING
016109         THRU 5239-EDIT-XFERS-REMAINING-X.
016109
016109     PERFORM  5240-EDIT-XFER-AMOUNT
016109         THRU 5240-EDIT-XFER-AMOUNT-X.

018845     PERFORM  5250-EDIT-SHRT-CALC-CD
018845         THRU 5250-EDIT-SHRT-CALC-CD-X.

021239     PERFORM  5260-EDIT-UNIT-TYP-CD
021239         THRU 5260-EDIT-UNIT-TYP-CD-X.
021239
020452     PERFORM  5270-EDIT-FRGN-TST-EFF-DT
020452         THRU 5270-EDIT-FRGN-TST-EFF-DT-X.
020452
       5200-EDIT-SCREEN-2-X.
           EXIT.
      *
      *------------------------
       5201-EDIT-REG-TOT.
      *------------------------

           IF  MIR-POL-REG-TOT-AMT = SPACES
008455*        MOVE RPOL-POL-REG-TOT-AMT    TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-REG-TOT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-REG-TOT-AMT * 100
020874         MOVE RPOL-POL-REG-TOT-AMT  TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-REG-TOT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-REG-TOT-AMT
               GO TO 5201-EDIT-REG-TOT-X
557660     END-IF.

           IF  MIR-POL-REG-TOT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-POL-REG-TOT-AMT
008455         MOVE  ZEROS            TO MIR-POL-REG-TOT-AMT
557660     END-IF.

           MOVE MIR-POL-REG-TOT-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-REG-TOT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-REG-TOT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-POL-REG-TOT-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-REG-TOT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-REG-TOT-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE REG-POL-AM (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510068'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5201-EDIT-REG-TOT-X.
           EXIT.
      *
      *------------------------
       5202-EDIT-REG-AMD.
      *------------------------

           IF  MIR-REG-CNTRB-1-AMT-T (1) = SPACES
557788*        MOVE RPOL-POL-REG-1-AMT      TO WS-HOLD-7-2-S
008455*        MOVE WS-REG-CNTRB-1-AMT (1)  TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-CNTRB-1-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-1-AMT (1) * 100
020874         MOVE WS-REG-CNTRB-1-AMT (1)  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-1-AMT-T (1)
               GO TO 5202-EDIT-REG-AMD-X
557660     END-IF.

           IF  MIR-REG-CNTRB-1-AMT-T (1) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-REG-CNTRB-1-AMT
008455         MOVE  ZEROS            TO MIR-REG-CNTRB-1-AMT-T (1)
557660     END-IF.

           MOVE MIR-REG-CNTRB-1-AMT-T (1)   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-POL-REG-1-AMT
557788         SET WS-REGC-OWNER-UPDT-REQ   TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-CNTRB-1-AMT (1)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-CNTRB-1-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-1-AMT-T (1)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE REG-AM-M-D (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510069'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5202-EDIT-REG-AMD-X.
           EXIT.
      *
      *------------------------
       5203-EDIT-REG-AJF.
      *------------------------

           IF  MIR-REG-CNTRB-2-AMT-T (1) = SPACES
557788*        MOVE RPOL-POL-REG-2-AMT      TO WS-HOLD-7-2-S
008455*        MOVE WS-REG-CNTRB-2-AMT (1)  TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-CNTRB-2-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-2-AMT (1) * 100
020874         MOVE WS-REG-CNTRB-2-AMT (1)  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-2-AMT-T (1)
               GO TO 5203-EDIT-REG-AJF-X
557660     END-IF.

           IF  MIR-REG-CNTRB-2-AMT-T (1) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-REG-CNTRB-2-AMT
008455         MOVE  ZEROS            TO MIR-REG-CNTRB-2-AMT-T (1)
557660     END-IF.

           MOVE MIR-REG-CNTRB-2-AMT-T (1)   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-POL-REG-2-AMT
557788         SET WS-REGC-OWNER-UPDT-REQ   TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-CNTRB-2-AMT (1)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-CNTRB-2-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-2-AMT-T (1)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE REG-AM-J-F (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510070'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5203-EDIT-REG-AJF-X.
           EXIT.
      *
      *------------------------
       5204-EDIT-REG-RMD.
      *------------------------

           IF  MIR-REG-RECPT-1-AMT-T (1) = SPACES
557788*        MOVE RPOL-REG-RECPT-1-AMT    TO WS-HOLD-7-2-S
008455*        MOVE WS-REG-RECPT-1-AMT (1)  TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-RECPT-1-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-REG-RECPT-1-AMT (1) * 100
020874         MOVE WS-REG-RECPT-1-AMT (1)  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-1-AMT-T (1)
               GO TO 5204-EDIT-REG-RMD-X
557660     END-IF.

           IF  MIR-REG-RECPT-1-AMT-T (1) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-REG-RECPT-1-AMT
008455         MOVE  ZEROS            TO MIR-REG-RECPT-1-AMT-T (1)
557660     END-IF.

           MOVE MIR-REG-RECPT-1-AMT-T (1)   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-REG-RECPT-1-AMT
557788         SET WS-REGC-OWNER-UPDT-REQ   TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-RECPT-1-AMT (1)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-RECPT-1-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-1-AMT-T (1)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE REG-RE-M-D (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510071'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5204-EDIT-REG-RMD-X.
           EXIT.
      *
      *------------------------
       5205-EDIT-REG-RJF.
      *------------------------

           IF  MIR-REG-RECPT-2-AMT-T (1) = SPACES
557788*        MOVE RPOL-REG-RECPT-2-AMT    TO WS-HOLD-7-2-S
008455*        MOVE WS-REG-RECPT-2-AMT (1)  TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-RECPT-2-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-REG-RECPT-2-AMT (1) * 100
020874         MOVE WS-REG-RECPT-2-AMT (1)  TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-2-AMT-T (1)
               GO TO 5205-EDIT-REG-RJF-X
557660     END-IF.

           IF  MIR-REG-RECPT-2-AMT-T (1) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-REG-RECPT-2-AMT
008455         MOVE  ZEROS            TO MIR-REG-RECPT-2-AMT-T (1)
557660     END-IF.

           MOVE MIR-REG-RECPT-2-AMT-T (1)   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-REG-RECPT-2-AMT
557788         SET WS-REGC-OWNER-UPDT-REQ   TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-RECPT-2-AMT (1)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-RECPT-2-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-2-AMT-T (1)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE REG-RE-J-F (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510072'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5205-EDIT-REG-RJF-X.
           EXIT.
      *
      *------------------------
       5206-EDIT-REG-ASP.
      *------------------------

           IF  MIR-REG-CNTRB-SPCL-AMT-T (1) = SPACES
557788*        MOVE RPOL-POL-REG-SPCL-AMT   TO WS-HOLD-7-2-S
008455*        MOVE WS-REG-CNTRB-SPCL-AMT (1)  TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S              TO MIR-REG-CNTRB-SPCL-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WS-REG-CNTRB-SPCL-AMT (1) * 100
020874         MOVE WS-REG-CNTRB-SPCL-AMT (1)  TO L0290-INPUT-V02
008455         MOVE 2                          TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-SPCL-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-SPCL-AMT-T (1)
               GO TO 5206-EDIT-REG-ASP-X
557660     END-IF.

           IF  MIR-REG-CNTRB-SPCL-AMT-T (1) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-REG-CNTRB-SPCL-AMT
008455         MOVE  ZEROS            TO MIR-REG-CNTRB-SPCL-AMT-T (1)
557660     END-IF.

           MOVE MIR-REG-CNTRB-SPCL-AMT-T (1)     TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-CNTRB-SPCL-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-POL-REG-SPCL-AMT
557788         SET WS-REGC-OWNER-UPDT-REQ   TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-CNTRB-SPCL-AMT(1)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2-S
008455*        MOVE WS-DISP-7-2-S           TO MIR-REG-CNTRB-SPCL-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-SPCL-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-SPCL-AMT-T (1)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE REG-AM-SPE (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510073'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5206-EDIT-REG-ASP-X.
           EXIT.
      *
      *------------------------
       5207-EDIT-MIN-PAYMENT.
      *------------------------

           IF  MIR-POL-RRIF-MNPMT-AMT = SPACES
008455*        MOVE RPOL-POL-RRIF-MNPMT-AMT TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-RRIF-MNPMT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-RRIF-MNPMT-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-RRIF-MNPMT-AMT  TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-RRIF-MNPMT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-RRIF-MNPMT-AMT
               GO TO 5207-EDIT-MIN-PAYMENT-X
557660     END-IF.

           IF  MIR-POL-RRIF-MNPMT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-RRIF-MNPMT-AMT
008455         MOVE  ZEROS            TO MIR-POL-RRIF-MNPMT-AMT
557660     END-IF.

           MOVE MIR-POL-RRIF-MNPMT-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-RRIF-MNPMT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-RRIF-MNPMT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-RRIF-MNPMT-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-RRIF-MNPMT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-RRIF-MNPMT-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE MIN-PAYMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510074'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5207-EDIT-MIN-PAYMENT-X.
           EXIT.
      *
      *------------------------
       5208-EDIT-CASUAL-PAYMENT.
      *------------------------

           IF  MIR-CASL-PMT-YTD-AMT = SPACES
008455*        MOVE RPOL-CASL-PMT-YTD-AMT   TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-CASL-PMT-YTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-CASL-PMT-YTD-AMT
020874*                                     * 100
020874         MOVE RPOL-CASL-PMT-YTD-AMT    TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CASL-PMT-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CASL-PMT-YTD-AMT
               GO TO 5208-EDIT-CASUAL-PAYMENT-X
557660     END-IF.

           IF  MIR-CASL-PMT-YTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-CASL-PMT-YTD-AMT
008455         MOVE  ZEROS            TO MIR-CASL-PMT-YTD-AMT
557660     END-IF.

           MOVE MIR-CASL-PMT-YTD-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CASL-PMT-YTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-CASL-PMT-YTD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-CASL-PMT-YTD-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CASL-PMT-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CASL-PMT-YTD-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE CASUAL-PAYMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510075'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5208-EDIT-CASUAL-PAYMENT-X.
           EXIT.
      *
      *-------------------------
       5209-EDIT-PAY-YTD.
      *-------------------------

           IF  MIR-POL-ANPAYO-YTD-AMT = SPACES
008455*        MOVE RPOL-POL-ANPAYO-YTD-AMT TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-ANPAYO-YTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-ANPAYO-YTD-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-ANPAYO-YTD-AMT    TO L0290-INPUT-V02
008455         MOVE 2                          TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-ANPAYO-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-ANPAYO-YTD-AMT
               GO TO 5209-EDIT-PAY-YTD-X
557660     END-IF.

           IF  MIR-POL-ANPAYO-YTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-ANPAYO-YTD-AMT
008455         MOVE  ZEROS            TO MIR-POL-ANPAYO-YTD-AMT
557660     END-IF.

           MOVE MIR-POL-ANPAYO-YTD-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-ANPAYO-YTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-ANPAYO-YTD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-ANPAYO-YTD-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-ANPAYO-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-ANPAYO-YTD-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PAYMT-YTD (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510076'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5209-EDIT-PAY-YTD-X.
           EXIT.
      *
      *-------------------------
       5210-EDIT-PAY-LTD.
      *-------------------------

           IF  MIR-POL-ANPAYO-LTD-AMT = SPACES
008455*        MOVE RPOL-POL-ANPAYO-LTD-AMT TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-ANPAYO-LTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-ANPAYO-LTD-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-ANPAYO-LTD-AMT    TO L0290-INPUT-V02
008455         MOVE 2                          TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-ANPAYO-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-ANPAYO-LTD-AMT
               GO TO 5210-EDIT-PAY-LTD-X
557660     END-IF.

           IF  MIR-POL-ANPAYO-LTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-ANPAYO-LTD-AMT
008455         MOVE  ZEROS            TO MIR-POL-ANPAYO-LTD-AMT
557660     END-IF.

           MOVE MIR-POL-ANPAYO-LTD-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-ANPAYO-LTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-ANPAYO-LTD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-ANPAYO-LTD-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-ANPAYO-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-ANPAYO-LTD-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PAYMT-LTD (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510077'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5210-EDIT-PAY-LTD-X.
           EXIT.
      *
      *-------------------------
       5211-EDIT-ANN-SUS.
      *-------------------------

           IF  MIR-POL-ANTY-SUSP-AMT = SPACES
008455*        MOVE RPOL-POL-ANTY-SUSP-AMT  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-ANTY-SUSP-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-ANTY-SUSP-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-ANTY-SUSP-AMT    TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-ANTY-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-ANTY-SUSP-AMT
               GO TO 5211-EDIT-ANN-SUS-X
557660     END-IF.

           IF  MIR-POL-ANTY-SUSP-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-ANTY-SUSP-AMT
008455         MOVE  ZEROS            TO MIR-POL-ANTY-SUSP-AMT
557660     END-IF.

           MOVE MIR-POL-ANTY-SUSP-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-ANTY-SUSP-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-ANTY-SUSP-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-ANTY-SUSP-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-ANTY-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-ANTY-SUSP-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE ANN-SUSP (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510078'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5211-EDIT-ANN-SUS-X.
           EXIT.
      *
      *-------------------------
       5212-EDIT-PAY-DATE.
      *-------------------------

           IF  MIR-POL-ANPAYO-PMT-DT  = SPACES
               MOVE RPOL-POL-ANPAYO-PMT-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-ANPAYO-PMT-DT
               GO TO 5212-EDIT-PAY-DATE-X
557660     END-IF.

           IF  MIR-POL-ANPAYO-PMT-DT  = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-REQUIRED          TO TRUE
               MOVE WWKDT-ZERO-DT     TO RPOL-POL-ANPAYO-PMT-DT
               MOVE SPACES            TO MIR-POL-ANPAYO-PMT-DT
               GO TO 5212-EDIT-PAY-DATE-X
557660     END-IF.

           MOVE MIR-POL-ANPAYO-PMT-DT TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE PAYMT-DATE (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510079'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO RPOL-POL-ANPAYO-PMT-DT
557660     END-IF.

       5212-EDIT-PAY-DATE-X.
           EXIT.
      *
      *---------------------------
       5213-EDIT-SPOUSAL-RCPT-MD.
      *---------------------------

           IF  MIR-REG-RECPT-1-AMT-T (2) =  SPACES
557788*        MOVE RPOL-REGSP-RECPT-1-AMT  TO WS-HOLD-S7-2
008455*        MOVE WS-REG-RECPT-1-AMT (2)  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-RECPT-1-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-REG-RECPT-1-AMT (2)
020874*                                     * 100
020874         MOVE WS-REG-RECPT-1-AMT (2)    TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-1-AMT-T (2)
               GO TO 5213-EDIT-SPOUSAL-RCPT-MD-X
557660     END-IF.

           IF  MIR-REG-RECPT-1-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-REG-RECPT-1-AMT
008455         MOVE  ZEROS            TO MIR-REG-RECPT-1-AMT-T (2)
557660     END-IF.

           MOVE MIR-REG-RECPT-1-AMT-T (2)   TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-REGSP-RECPT-1-AMT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-RECPT-1-AMT (2)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-RECPT-1-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-1-AMT-T (2)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE S-REC-M-D (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510080'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5213-EDIT-SPOUSAL-RCPT-MD-X.
           EXIT.
      *
      *---------------------------
       5214-EDIT-SPOUSAL-RCPT-JF.
      *---------------------------

           IF  MIR-REG-RECPT-2-AMT-T (2) =  SPACES
557788*        MOVE RPOL-REGSP-RECPT-2-AMT  TO WS-HOLD-S7-2
008455*        MOVE WS-REG-RECPT-2-AMT (2)  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-RECPT-2-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-REG-RECPT-2-AMT (2)
020874*                                     * 100
020874         MOVE WS-REG-RECPT-2-AMT (2)    TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-2-AMT-T (2)
               GO TO 5214-EDIT-SPOUSAL-RCPT-JF-X
557660     END-IF.

           IF  MIR-REG-RECPT-2-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-REG-RECPT-2-AMT
008455         MOVE  ZEROS            TO MIR-REG-RECPT-2-AMT-T (2)
557660     END-IF.

           MOVE MIR-REG-RECPT-2-AMT-T (2)   TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-REGSP-RECPT-2-AMT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-RECPT-2-AMT (2)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-RECPT-2-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-2-AMT-T (2)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE S-REC-J-F (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510081'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5214-EDIT-SPOUSAL-RCPT-JF-X.
           EXIT.
      *
      *---------------------------
       5215-EDIT-SPOUSAL-AMT-MD.
      *---------------------------

           IF  MIR-REG-CNTRB-1-AMT-T (2) =  SPACES
557788*        MOVE RPOL-POL-REGSP-1-AMT    TO WS-HOLD-S7-2
008455*        MOVE WS-REG-CNTRB-1-AMT (2)  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-CNTRB-1-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-1-AMT (2)
020874*                                     * 100
020874         MOVE WS-REG-CNTRB-1-AMT (2)    TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-1-AMT-T (2)
               GO TO 5215-EDIT-SPOUSAL-AMT-MD-X
557660     END-IF.

           IF  MIR-REG-CNTRB-1-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-REG-CNTRB-1-AMT
008455         MOVE  ZEROS            TO MIR-REG-CNTRB-1-AMT-T (2)
           END-IF.

           MOVE MIR-REG-CNTRB-1-AMT-T (2)   TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-POL-REGSP-1-AMT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-CNTRB-1-AMT (2)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-CNTRB-1-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-1-AMT-T (2)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE S-AMOUNT-M-D (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510082'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5215-EDIT-SPOUSAL-AMT-MD-X.
           EXIT.
      *
      *---------------------------
       5216-EDIT-SPOUSAL-AMT-JF.
      *---------------------------

           IF  MIR-REG-CNTRB-2-AMT-T (2) =  SPACES
557788*        MOVE RPOL-POL-REGSP-2-AMT    TO WS-HOLD-S7-2
008455*        MOVE WS-REG-CNTRB-2-AMT (2)  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-CNTRB-2-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-2-AMT (2)
020874*                                     * 100
020874         MOVE WS-REG-CNTRB-2-AMT (2) TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-2-AMT-T (2)
               GO TO 5216-EDIT-SPOUSAL-AMT-JF-X
557660     END-IF.

           IF  MIR-REG-CNTRB-2-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-REG-CNTRB-2-AMT
008455         MOVE  ZEROS            TO MIR-REG-CNTRB-2-AMT-T (2)
557660     END-IF.

           MOVE MIR-REG-CNTRB-2-AMT-T (2)   TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-POL-REGSP-2-AMT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-CNTRB-2-AMT (2)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-CNTRB-2-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY       TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-2-AMT-T (2)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE S-AMOUNT-J-F (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510083'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5216-EDIT-SPOUSAL-AMT-JF-X.
           EXIT.
      *
      *---------------------------
       5217-EDIT-SPOUSAL-AMT-SPEC.
      *---------------------------

           IF  MIR-REG-CNTRB-SPCL-AMT-T (2) =  SPACES
557788*        MOVE RPOL-POL-REGSP-SPCL-AMT TO WS-HOLD-S7-2
008455*        MOVE WS-REG-CNTRB-SPCL-AMT (2)  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-CNTRB-SPCL-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WS-REG-CNTRB-SPCL-AMT (2) * 100
020874         MOVE WS-REG-CNTRB-SPCL-AMT (2) TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-SPCL-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY         TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-SPCL-AMT-T (2)
               GO TO 5217-EDIT-SPOUSAL-AMT-SPEC-X
557660     END-IF.

           IF  MIR-REG-CNTRB-SPCL-AMT-T (2) =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-REG-CNTRB-SPCL-AMT
008455         MOVE  ZEROS            TO MIR-REG-CNTRB-SPCL-AMT-T (2)
557660     END-IF.

           MOVE MIR-REG-CNTRB-SPCL-AMT-T (2)    TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-REG-CNTRB-SPCL-AMT-T (2)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L0280-OUTPUT-DOLLAR     TO RPOL-POL-REGSP-SPCL-AMT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-REG-CNTRB-SPCL-AMT(2)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-REG-CNTRB-SPCL-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-SPCL-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-SPCL-AMT-T (2)
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE S-AMOUNT-SPECIAL (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510084'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5217-EDIT-SPOUSAL-AMT-SPEC-X.
           EXIT.
      *
      *----------------------------
       5218-EDIT-SPOUSAL-RCPT-DATE.
      *----------------------------

           IF  MIR-REG-CNTRB-RECPT-DT =  SPACES
557788*        MOVE RPOL-POL-REGSP-RECPT-DT TO L1640-INTERNAL-DATE
557788         MOVE WS-REG-CNTRB-RECPT-DT (2)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-REG-CNTRB-RECPT-DT
               GO TO 5218-EDIT-SPOUSAL-RCPT-DATE-X
557660     END-IF.

           IF  MIR-REG-CNTRB-RECPT-DT =  EBLCH-BLANK-FIELD-CHAR
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE WWKDT-ZERO-DT           TO RPOL-POL-REGSP-RECPT-DT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE WWKDT-ZERO-DT     TO WS-REG-CNTRB-RECPT-DT(2)
               MOVE SPACES            TO MIR-REG-CNTRB-RECPT-DT
               GO TO 5218-EDIT-SPOUSAL-RCPT-DATE-X
557660     END-IF.

           MOVE MIR-REG-CNTRB-RECPT-DT    TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE S-RECEIPT-DATE (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510085'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L1640-INTERNAL-DATE     TO RPOL-POL-REGSP-RECPT-DT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE L1640-INTERNAL-DATE
                                      TO WS-REG-CNTRB-RECPT-DT(2)
557660     END-IF.

       5218-EDIT-SPOUSAL-RCPT-DATE-X.
           EXIT.
      *
      *----------------------------
       5219-EDIT-SPOUSAL-CNTR-DATE.
      *----------------------------

           IF  MIR-REG-CNTRB-XFER-DT =  SPACES
557788*        MOVE RPOL-POL-REGSP-XFER-DT  TO L1640-INTERNAL-DATE
557788         MOVE WS-REG-CNTRB-XFER-DT (2)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-REG-CNTRB-XFER-DT
               GO TO 5219-EDIT-SPOUSAL-CNTR-DATE-X
557660     END-IF.

           IF  MIR-REG-CNTRB-XFER-DT =  EBLCH-BLANK-FIELD-CHAR
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE WWKDT-ZERO-DT           TO RPOL-POL-REGSP-XFER-DT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE WWKDT-ZERO-DT     TO WS-REG-CNTRB-XFER-DT(2)
               MOVE SPACES            TO MIR-REG-CNTRB-XFER-DT
               GO TO 5219-EDIT-SPOUSAL-CNTR-DATE-X
557660     END-IF.

           MOVE MIR-REG-CNTRB-XFER-DT    TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE S-CONTRIBUTION-LIT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510001'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510086'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
557788*        SET UPDATE-REQUIRED          TO TRUE
557788*        MOVE L1640-INTERNAL-DATE     TO RPOL-POL-REGSP-XFER-DT
557788         SET WS-REGC-SPOU-UPDT-REQ    TO TRUE
557788         MOVE L1640-INTERNAL-DATE
                                      TO WS-REG-CNTRB-XFER-DT(2)
557660     END-IF.

       5219-EDIT-SPOUSAL-CNTR-DATE-X.
           EXIT.
      *

      *------------------------
       5220-EDIT-PREV-YR-MIN.
      *------------------------

           IF  MIR-RRIF-MNPMT-PYR-AMT = SPACES
008455*        MOVE RPOL-RRIF-MNPMT-PYR-AMT TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-RRIF-MNPMT-PYR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-RRIF-MNPMT-PYR-AMT
020874*                                     * 100
020874         MOVE RPOL-RRIF-MNPMT-PYR-AMT   TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-RRIF-MNPMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-RRIF-MNPMT-PYR-AMT
               GO TO 5220-EDIT-PREV-YR-MIN-X
557660     END-IF.

           IF  MIR-RRIF-MNPMT-PYR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-RRIF-MNPMT-PYR-AMT
008455         MOVE  ZEROS            TO MIR-RRIF-MNPMT-PYR-AMT
557660     END-IF.

           MOVE MIR-RRIF-MNPMT-PYR-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-RRIF-MNPMT-PYR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-RRIF-MNPMT-PYR-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-RRIF-MNPMT-PYR-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-RRIF-MNPMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-RRIF-MNPMT-PYR-AMT
               GO TO 5220-EDIT-PREV-YR-MIN-X
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PREV-YR-MIN-PAYMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510087'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5220-EDIT-PREV-YR-MIN-X.
           EXIT.
      *
      *------------------------
       5221-EDIT-MAX-PYMT.
      *------------------------

           IF  MIR-POL-LIF-MXPMT-AMT = SPACES
008455*        MOVE RPOL-POL-LIF-MXPMT-AMT  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-LIF-MXPMT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-LIF-MXPMT-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-LIF-MXPMT-AMT   TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-LIF-MXPMT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-LIF-MXPMT-AMT
                GO TO 5221-EDIT-MAX-PYMT-X
557660     END-IF.

           IF  MIR-POL-LIF-MXPMT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-LIF-MXPMT-AMT
008455         MOVE  ZEROS            TO MIR-POL-LIF-MXPMT-AMT
557660     END-IF.

           MOVE MIR-POL-LIF-MXPMT-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-LIF-MXPMT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-LIF-MXPMT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-LIF-MXPMT-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-LIF-MXPMT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-LIF-MXPMT-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE MAX-PAYMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510088'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5221-EDIT-MAX-PYMT-X.
           EXIT.
      *
      *------------------------
       5222-EDIT-PREV-YR-MAX.
      *------------------------

           IF  MIR-LIF-MXPMT-PYR-AMT = SPACES
008455*        MOVE RPOL-LIF-MXPMT-PYR-AMT  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-LIF-MXPMT-PYR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-LIF-MXPMT-PYR-AMT
020874*                                     * 100
020874         MOVE RPOL-LIF-MXPMT-PYR-AMT   TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LIF-MXPMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LIF-MXPMT-PYR-AMT
               GO TO 5222-EDIT-PREV-YR-MAX-X
557660     END-IF.

           IF  MIR-LIF-MXPMT-PYR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-LIF-MXPMT-PYR-AMT
008455         MOVE  ZEROS            TO MIR-LIF-MXPMT-PYR-AMT
           END-IF.

           MOVE MIR-LIF-MXPMT-PYR-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-LIF-MXPMT-PYR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-LIF-MXPMT-PYR-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-LIF-MXPMT-PYR-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-LIF-MXPMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-LIF-MXPMT-PYR-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PREV-YR-MAX-PAYMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510089'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5222-EDIT-PREV-YR-MAX-X.
           EXIT.
      *
      *-------------------------
       5223-EDIT-PREV-YR-CASUAL.
      *-------------------------

           IF  MIR-CASL-PMT-PYR-AMT = SPACES
008455*        MOVE RPOL-CASL-PMT-PYR-AMT   TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-CASL-PMT-PYR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-CASL-PMT-PYR-AMT * 100
020874         MOVE RPOL-CASL-PMT-PYR-AMT   TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CASL-PMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CASL-PMT-PYR-AMT
               GO TO 5223-EDIT-PREV-YR-CASUAL-X
557660     END-IF.

           IF  MIR-CASL-PMT-PYR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-CASL-PMT-PYR-AMT
008455         MOVE  ZEROS            TO MIR-CASL-PMT-PYR-AMT
557660     END-IF.

           MOVE MIR-CASL-PMT-PYR-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CASL-PMT-PYR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-CASL-PMT-PYR-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-CASL-PMT-PYR-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CASL-PMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CASL-PMT-PYR-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PREV-YR-CASUAL-PAYMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510090'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5223-EDIT-PREV-YR-CASUAL-X.
           EXIT.
      *
      *---------------------------
       5224-EDIT-PREV-YR-TOT-PYMT.
      *---------------------------

           IF  MIR-POL-ANPAYO-PYR-AMT  = SPACES
008455*        MOVE RPOL-POL-ANPAYO-PYR-AMT TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-ANPAYO-PYR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-ANPAYO-PYR-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-ANPAYO-PYR-AMT   TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-ANPAYO-PYR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-ANPAYO-PYR-AMT
               GO TO 5224-EDIT-PREV-YR-TOT-PYMT-X
557660     END-IF.

           IF  MIR-POL-ANPAYO-PYR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-ANPAYO-PYR-AMT
008455         MOVE  ZEROS            TO MIR-POL-ANPAYO-PYR-AMT
557660     END-IF.

           MOVE MIR-POL-ANPAYO-PYR-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-ANPAYO-PYR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-ANPAYO-PYR-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-ANPAYO-PYR-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-ANPAYO-PYR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-ANPAYO-PYR-AMT
           ELSE
557756*        MOVE AMOUNT (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*        MOVE PREV-YR-PAYMT (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (2)
557756*        MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510091'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5224-EDIT-PREV-YR-TOT-PYMT-X.
           EXIT.
      *
      *------------------------
       5225-EDIT-LOCKED-IN-IND.
      *------------------------

           IF MIR-POL-LOCK-FND-IND = SPACES
               MOVE RPOL-POL-LOCK-FND-IND
                                      TO MIR-POL-LOCK-FND-IND
               GO TO 5225-EDIT-LOCKED-IN-IND-X
557660     END-IF.

           IF  MIR-POL-LOCK-FND-IND = 'Y'
           OR  MIR-POL-LOCK-FND-IND = 'N'
               MOVE MIR-POL-LOCK-FND-IND
                                      TO RPOL-POL-LOCK-FND-IND
               SET UPDATE-REQUIRED          TO TRUE
           ELSE
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510092'      TO WGLOB-MSG-REF-INFO
557756*        MOVE LOCKED-IN-FUNDS (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5225-EDIT-LOCKED-IN-IND-X.
           EXIT.

      *------------------------
       5226-EDIT-SURR-CURR-AMT.
      *------------------------

           IF  MIR-POL-CRNT-PSUR-AMT  = SPACES
008455*        MOVE RPOL-POL-CRNT-PSUR-AMT  TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-CRNT-PSUR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-CRNT-PSUR-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-CRNT-PSUR-AMT   TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-CRNT-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-CRNT-PSUR-AMT
               GO TO 5226-EDIT-SURR-CURR-AMT-X
557660     END-IF.

           IF  MIR-POL-CRNT-PSUR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-CRNT-PSUR-AMT
               MOVE  ZEROS            TO MIR-POL-CRNT-PSUR-AMT
557660     END-IF.

           MOVE MIR-POL-CRNT-PSUR-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-CRNT-PSUR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-CRNT-PSUR-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-CRNT-PSUR-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-CRNT-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-CRNT-PSUR-AMT
           ELSE
557756*        MOVE S-SURR-CURR-P (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510093'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5226-EDIT-SURR-CURR-AMT-X.
           EXIT.

      *------------------------
       5227-EDIT-SURR-PREV-AMT.
      *------------------------

           IF  MIR-POL-PREV-PSUR-AMT  = SPACES
008455*        MOVE RPOL-POL-PREV-PSUR-AMT TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-PREV-PSUR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PREV-PSUR-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-PREV-PSUR-AMT   TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PREV-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PREV-PSUR-AMT
               GO TO 5227-EDIT-SURR-PREV-AMT-X
557660     END-IF.

           IF  MIR-POL-PREV-PSUR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-POL-PREV-PSUR-AMT
008455         MOVE  ZEROS            TO MIR-POL-PREV-PSUR-AMT
557660     END-IF.

           MOVE MIR-POL-PREV-PSUR-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-PREV-PSUR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-PREV-PSUR-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-POL-PREV-PSUR-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-PREV-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-PREV-PSUR-AMT
           ELSE
557756*        MOVE S-SURR-PREV-P (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510094'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5227-EDIT-SURR-PREV-AMT-X.
           EXIT.

      *---------------------
       5228-EDIT-THRESH-AMT.
      *---------------------

           IF  MIR-POL-AFR-THRSHD-AMT  = SPACES
008455*        MOVE RPOL-POL-AFR-THRSHD-AMT TO WS-HOLD-S5-2
008455*        MOVE WS-DISP-S5-2            TO MIR-POL-AFR-THRSHD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-AFR-THRSHD-AMT
020874*                                     * 100
020874         MOVE RPOL-POL-AFR-THRSHD-AMT   TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-AFR-THRSHD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-AFR-THRSHD-AMT
               GO TO 5228-EDIT-THRESH-AMT-X
557660     END-IF.

           IF  MIR-POL-AFR-THRSHD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+00000.00'             TO MIR-POL-AFR-THRSHD-AMT
008455         MOVE  ZEROS            TO MIR-POL-AFR-THRSHD-AMT
557660     END-IF.

           MOVE MIR-POL-AFR-THRSHD-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 9                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-AFR-THRSHD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
010311*    PERFORM  0280-1000-NUMERIC-EDIT
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-AFR-THRSHD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S5-2
008455*        MOVE WS-DISP-S5-2            TO MIR-POL-AFR-THRSHD-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-AFR-THRSHD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-AFR-THRSHD-AMT
           ELSE
557756*        MOVE S-THRESH-AMT  (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510095'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5228-EDIT-THRESH-AMT-X.
           EXIT.

      *------------------------
       5229-EDIT-THRESH-PERIOD.
      *------------------------

           IF  MIR-AFR-THRSHD-PERI-CD = SPACES
               MOVE RPOL-AFR-THRSHD-PERI-CD
                                      TO MIR-AFR-THRSHD-PERI-CD
               GO TO 5229-EDIT-THRESH-PERIOD-X
557660     END-IF.

           IF  MIR-AFR-THRSHD-PERI-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RPOL-AFR-THRSHD-PERI-CD
               MOVE SPACES            TO MIR-AFR-THRSHD-PERI-CD
               GO TO 5229-EDIT-THRESH-PERIOD-X
557660     END-IF.

           MOVE MIR-AFR-THRSHD-PERI-CD                TO WS-THRSHD-PERI.
           IF  NOT WS-THRSHD-PERI-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE S-THRESH-PER  (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510096'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-AFR-THRSHD-PERI-CD
                                      TO RPOL-AFR-THRSHD-PERI-CD
557660     END-IF.

       5229-EDIT-THRESH-PERIOD-X.
           EXIT.

      *--------------------------
       5230-EDIT-PREV-FACE-DECRS.
      *--------------------------

           IF  MIR-POL-TOT-AFR-AMT = SPACES
008455*        MOVE RPOL-POL-TOT-AFR-AMT    TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-POL-TOT-AFR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-POL-TOT-AFR-AMT * 100
020874         MOVE RPOL-POL-TOT-AFR-AMT   TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-TOT-AFR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-TOT-AFR-AMT
               GO TO 5230-EDIT-PREV-FACE-DECRS-X
557660     END-IF.

           IF  MIR-POL-TOT-AFR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-POL-TOT-AFR-AMT
008455         MOVE  ZEROS            TO MIR-POL-TOT-AFR-AMT
557660     END-IF.

           MOVE MIR-POL-TOT-AFR-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-TOT-AFR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
010311*    PERFORM  0280-1000-NUMERIC-EDIT
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-POL-TOT-AFR-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-POL-TOT-AFR-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-TOT-AFR-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-TOT-AFR-AMT
           ELSE
557756*        MOVE S-PREV-FA-DECR (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510097'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5230-EDIT-PREV-FACE-DECRS-X.
           EXIT.

      *------------------------
       5231-EDIT-POL-CSV-ALLOC.
      *------------------------

           IF  MIR-POL-AFR-ALLOC-CD = SPACES
               MOVE RPOL-POL-AFR-ALLOC-CD
                                      TO MIR-POL-AFR-ALLOC-CD
               GO TO 5231-EDIT-POL-CSV-ALLOC-X
557660     END-IF.

           IF  MIR-POL-AFR-ALLOC-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RPOL-POL-AFR-ALLOC-CD
               MOVE SPACES            TO MIR-POL-AFR-ALLOC-CD
               GO TO 5231-EDIT-POL-CSV-ALLOC-X
557660     END-IF.

           MOVE MIR-POL-AFR-ALLOC-CD  TO WS-ALLOC.
           IF  NOT WS-ALLOC-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE S-POL-CSV-ALLOC (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510098'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-POL-AFR-ALLOC-CD
                                      TO RPOL-POL-AFR-ALLOC-CD
557660     END-IF.

       5231-EDIT-POL-CSV-ALLOC-X.
           EXIT.

      *-----------------------
       5232-EDIT-FREE-DRAW-CD.
      *-----------------------

           IF  MIR-FREE-WTHDR-CD = SPACES
               MOVE RPOL-FREE-WTHDR-CD              TO MIR-FREE-WTHDR-CD
               GO TO 5232-EDIT-FREE-DRAW-CD-X
557660     END-IF.

           IF  MIR-FREE-WTHDR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RPOL-FREE-WTHDR-CD
               MOVE SPACES            TO MIR-FREE-WTHDR-CD
               GO TO 5232-EDIT-FREE-DRAW-CD-X
557660     END-IF.

           MOVE MIR-FREE-WTHDR-CD     TO WS-FREE-WTHDR.
           IF  NOT WS-FREE-WTHDR-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE S-FW-CODE     (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510099'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-FREE-WTHDR-CD TO RPOL-FREE-WTHDR-CD
557660     END-IF.

       5232-EDIT-FREE-DRAW-CD-X.
           EXIT.

      *---------------------------
       5233-EDIT-FREE-DRAW-PERIOD.
      *---------------------------

           IF  MIR-FREE-WTHDR-PERI-CD = SPACES
               MOVE RPOL-FREE-WTHDR-PERI-CD
                                      TO MIR-FREE-WTHDR-PERI-CD
               GO TO 5233-EDIT-FREE-DRAW-PERIOD-X
557660     END-IF.

           IF  MIR-FREE-WTHDR-PERI-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RPOL-FREE-WTHDR-PERI-CD
               MOVE SPACES            TO MIR-FREE-WTHDR-PERI-CD
               GO TO 5233-EDIT-FREE-DRAW-PERIOD-X
557660     END-IF.

           MOVE MIR-FREE-WTHDR-PERI-CD            TO WS-FREE-WTHDR-PERI.
           IF  NOT WS-FREE-WTHDR-PERI-VALID
               SET WS-ERROR-FOUND           TO TRUE
557756*        MOVE S-FW-PERIOD   (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510100'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-REQUIRED          TO TRUE
               MOVE MIR-FREE-WTHDR-PERI-CD
                                      TO RPOL-FREE-WTHDR-PERI-CD
557660     END-IF.

       5233-EDIT-FREE-DRAW-PERIOD-X.
           EXIT.

      *--------------------------
       5234-EDIT-DRAWS-REMAINING.
      *--------------------------

           IF  MIR-FREE-WTHDR-QTY  = SPACES
               MOVE RPOL-FREE-WTHDR-QTY
                                      TO WS-HOLD-2-0
               MOVE WS-DISP-2-0       TO MIR-FREE-WTHDR-QTY
               GO TO 5234-EDIT-DRAWS-REMAINING-X
557660     END-IF.

           IF  MIR-FREE-WTHDR-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE '+00'             TO MIR-FREE-WTHDR-QTY
557660     END-IF.

           MOVE MIR-FREE-WTHDR-QTY    TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT
                                      TO RPOL-FREE-WTHDR-QTY
               MOVE L0280-OUTPUT      TO WS-HOLD-2-0
               MOVE WS-DISP-2-0       TO MIR-FREE-WTHDR-QTY
           ELSE
557756*        MOVE S-FW-QTY      (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510101'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5234-EDIT-DRAWS-REMAINING-X.
           EXIT.

      *----------------------
       5235-EDIT-DRAW-AMOUNT.
      *----------------------

           IF  MIR-FREE-WTHDR-TOT-AMT  = SPACES
008455*        MOVE RPOL-FREE-WTHDR-TOT-AMT TO WS-HOLD-S8-2
008455*        MOVE WS-DISP-S8-2            TO MIR-FREE-WTHDR-TOT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-FREE-WTHDR-TOT-AMT
020874*                                     * 100
020874         MOVE RPOL-FREE-WTHDR-TOT-AMT  TO L0290-INPUT-V02
008455         MOVE 2                        TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-FREE-WTHDR-TOT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-FREE-WTHDR-TOT-AMT
               GO TO 5235-EDIT-DRAW-AMOUNT-X
557660     END-IF.

           IF  MIR-FREE-WTHDR-TOT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+00000000.00'          TO MIR-FREE-WTHDR-TOT-AMT
008455         MOVE  ZEROS            TO MIR-FREE-WTHDR-TOT-AMT
557660     END-IF.

           MOVE MIR-FREE-WTHDR-TOT-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 8                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-FREE-WTHDR-TOT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPOL-FREE-WTHDR-TOT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S8-2
008455*        MOVE WS-DISP-S8-2            TO MIR-FREE-WTHDR-TOT-AMT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-FREE-WTHDR-TOT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-FREE-WTHDR-TOT-AMT
           ELSE
557756*        MOVE S-FW-AMT      (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510102'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5235-EDIT-DRAW-AMOUNT-X.
           EXIT.

      *---------------------
       5236-EDIT-RESET-YEAR.
      *---------------------

           IF  MIR-POL-PREV-RESET-YR   = SPACES
557659*        MOVE RPOL-PREV-RESET-YR-QTY  TO WS-HOLD-4-0
020874*        MOVE RPOL-POL-PREV-RESET-YR
020874*                               TO WS-HOLD-4-0
020874*        MOVE WS-HOLD-4-0       TO MIR-POL-PREV-RESET-YR
020874         MOVE RPOL-POL-PREV-RESET-YR TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-RESET-YR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-RESET-YR
               GO TO 5236-EDIT-RESET-YEAR-X
557660     END-IF.

           IF  MIR-POL-PREV-RESET-YR  = EBLCH-BLANK-FIELD-CHAR
020874*        COMPUTE WS-RESET-YEAR = RPOL-POL-ISS-EFF-DT-YR - 1
020874*        MOVE WS-RESET-YEAR     TO MIR-POL-PREV-RESET-YR
020874         COMPUTE L0290-INPUT-V00 = RPOL-POL-ISS-EFF-DT-YR - 1
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-RESET-YR
020874                                    TO L0290-MAX-OUT-LEN
020874         SET L0290-SIGN-DISPLAY     TO TRUE
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-RESET-YR
557660     END-IF.

           MOVE MIR-POL-PREV-RESET-YR TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-LENGTH.
           MOVE 4                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               SET UPDATE-REQUIRED          TO TRUE
               MOVE L0280-OUTPUT
557659*                   TO RPOL-PREV-RESET-YR-QTY-N
557659                                TO RPOL-POL-PREV-RESET-YR
020874*        MOVE L0280-OUTPUT      TO WS-HOLD-4-0
020874*        MOVE WS-DISP-4-0       TO MIR-POL-PREV-RESET-YR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PREV-RESET-YR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-RESET-YR
           ELSE
557756*        MOVE S-RESET-YEAR  (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*        MOVE 'CS01510003'            TO WGLOB-MSG-REF-INFO
557756         MOVE 'CS01510103'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND           TO TRUE
557660     END-IF.

       5236-EDIT-RESET-YEAR-X.
           EXIT.
      *
016109*-----------------------
016109 5237-EDIT-FREE-XFER-CD.
016109*-----------------------
016109
016109     MOVE MIR-POL-FREE-XFER-CD TO WS-FREE-XFER.
016109     IF NOT WS-FREE-XFER-VALID
016109         SET WS-ERROR-FOUND           TO TRUE
016109         MOVE 'CS01510119'      TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109     ELSE
016109         SET UPDATE-REQUIRED          TO TRUE
016109         MOVE MIR-POL-FREE-XFER-CD TO RPOL-POL-FREE-XFER-CD
016109     END-IF.
016109
016109 5237-EDIT-FREE-XFER-CD-X.
016109     EXIT.

016109*---------------------------
016109 5238-EDIT-FREE-XFER-PERIOD.
016109*---------------------------
016109
016109     MOVE MIR-FREE-XFER-PERI-CD  TO WS-FREE-XFER-PERI.
016109     IF  NOT WS-FREE-XFER-PERI-VALID
016109         SET WS-ERROR-FOUND           TO TRUE
016109         MOVE 'CS01510120'      TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109     ELSE
016109         SET UPDATE-REQUIRED          TO TRUE
016109         MOVE MIR-FREE-XFER-PERI-CD
016109                                TO RPOL-FREE-XFER-PERI-CD
016109     END-IF.
016109
016109 5238-EDIT-FREE-XFER-PERIOD-X.
016109     EXIT.

016109*--------------------------
016109 5239-EDIT-XFERS-REMAINING.
016109*--------------------------
016109
016109     MOVE MIR-POL-FREE-XFER-QTY     TO L0280-INPUT-DATA.
016109     SET L0280-SIGN-PERMITTED   TO TRUE.
016109     MOVE 0                     TO L0280-PRECISION.
016109     MOVE 2                     TO L0280-LENGTH.
016109     MOVE 2                     TO L0280-INPUT-SIZE.
016109     PERFORM  0280-1000-NUMERIC-EDIT
016109         THRU 0280-1000-NUMERIC-EDIT-X.
016109
016109     IF  L0280-OK
016109         SET UPDATE-REQUIRED    TO TRUE
016109         MOVE L0280-OUTPUT      TO RPOL-POL-FREE-XFER-QTY
016109         MOVE L0280-OUTPUT      TO WS-HOLD-2-0
016109         MOVE WS-DISP-2-0       TO MIR-POL-FREE-XFER-QTY
016109     ELSE
016109* MSG: INVALID VALUE FOR DATA FIELD #-FT
016109         MOVE 'CS01510121'      TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109         SET WS-ERROR-FOUND     TO TRUE
016109     END-IF.
016109
016109 5239-EDIT-XFERS-REMAINING-X.
016109     EXIT.

016109*----------------------
016109 5240-EDIT-XFER-AMOUNT.
016109*----------------------
016109
016109     IF  MIR-FREE-XFER-TOT-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RPOL-FREE-XFER-TOT-AMT
020874*                                     * 100
020874         MOVE RPOL-FREE-XFER-TOT-AMT  TO L0290-INPUT-V02
016109         MOVE 2                       TO L0290-PRECISION
016109         MOVE LENGTH OF MIR-FREE-XFER-TOT-AMT
016109                                TO L0290-MAX-OUT-LEN
016109         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016109         MOVE L0290-OUTPUT-DATA TO MIR-FREE-XFER-TOT-AMT
016109         GO TO 5240-EDIT-XFER-AMOUNT-X
016109     END-IF.
016109
016109     MOVE MIR-FREE-XFER-TOT-AMT       TO L0280-INPUT-DATA.
016109     SET L0280-SIGN-PERMITTED         TO TRUE.
016109     MOVE 2                     TO L0280-PRECISION.
016109     MOVE LENGTH OF MIR-FREE-XFER-TOT-AMT
016109                                TO L0280-INPUT-SIZE.
016109     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
016109     PERFORM  0280-1000-NUMERIC-EDIT
016109         THRU 0280-1000-NUMERIC-EDIT-X.
016109
016109     IF  L0280-OK
016109         SET UPDATE-REQUIRED          TO TRUE
016109         MOVE L0280-OUTPUT-DOLLAR
016109                                TO RPOL-FREE-XFER-TOT-AMT
016109         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
016109         MOVE 2                 TO L0290-PRECISION
016109         MOVE LENGTH OF MIR-FREE-XFER-TOT-AMT
016109                                TO L0290-MAX-OUT-LEN
016109         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016109         MOVE L0290-OUTPUT-DATA TO MIR-FREE-XFER-TOT-AMT
016109     ELSE
016109* MSG: INVALID VALUE FOR DATA FIELD FT-AMT
016109         MOVE 'CS01510122'      TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109         SET WS-ERROR-FOUND           TO TRUE
016109     END-IF.
016109
016109 5240-EDIT-XFER-AMOUNT-X.
016109     EXIT.

018845*------------------------
018845 5250-EDIT-SHRT-CALC-CD.
018845*------------------------
018845
018845     MOVE MIR-POL-SHRT-CALC-CD   TO  WS-SHRT-CALC-CD.
018845
018845*DO NOT ALLOW THE SHORTAGE CALCULATION CODE TO BE CHANGED
018845*ON SUSPENDED POLICY
018845     IF  RPOL-POL-SUSPENDED
018845*MSG:SHORTAGE CALCULATION TYPE NOT ALLOWED CHANGE WHEN
018845*    POLICY SUSPENDED
018845         MOVE 'CS01510127'        TO WGLOB-MSG-REF-INFO
018845         PERFORM  0260-1000-GENERATE-MESSAGE
018845             THRU 0260-1000-GENERATE-MESSAGE-X
018845         GO TO 5250-EDIT-SHRT-CALC-CD-X
018845     END-IF.
018845
018845*CHECK MONTHIVERSARY INDICATOR TO ALLOW CHANGE ON THE
018845*SHORTAGE CALCULATION CODE
018845     IF (RPOL-POL-INS-TYP-FLEXIBLE
018845     OR  RPOL-POL-INS-TYP-SEG-FUND)
018845
018845         EVALUATE  TRUE
018845
018845             WHEN  RPOL-POL-MTHV-PRCES-NO
018845               IF  NOT WS-SHRT-CALC-NONE
018845*MSG:SHORTAGE CALC TYPE MUST BE NOT APPLICABLE, CHECK PLAN
018845                   MOVE 'CS01510123'  TO WGLOB-MSG-REF-INFO
018845                   PERFORM  0260-1000-GENERATE-MESSAGE
018845                       THRU 0260-1000-GENERATE-MESSAGE-X
018845                   SET WS-ERROR-FOUND TO TRUE
018845                   GO TO 5250-EDIT-SHRT-CALC-CD-X
018845               END-IF
018845
018845             WHEN  RPOL-POL-MTHV-PRCES
018845               IF  WS-SHRT-CALC-NONE
018845*MSG:SHORTAGE CALC TYPE MUST BE ACCUMULATED VALUE OR CASH
018845*    SURRENDER VALUE
018845                   MOVE 'CS01510124'  TO WGLOB-MSG-REF-INFO
018845                   PERFORM  0260-1000-GENERATE-MESSAGE
018845                       THRU 0260-1000-GENERATE-MESSAGE-X
018845                   SET WS-ERROR-FOUND TO TRUE
018845                   GO TO 5250-EDIT-SHRT-CALC-CD-X
018845               END-IF
018845
018845         END-EVALUATE
018845
018845     END-IF.
018845
018845* PLAN NOT SET UP CORRECTLY FOR NON UL PRODUCTS
018845     IF NOT (RPOL-POL-INS-TYP-FLEXIBLE
018845     OR      RPOL-POL-INS-TYP-SEG-FUND)
018845         IF  RPOL-POL-MTHV-PRCES
018845*MSG: PLAN SHORTAGE CALC TYPE MUST BE NOT-APPLICABLE FOR NON
018845*     UL PRODUCTS
018845             MOVE 'CS01510125'        TO WGLOB-MSG-REF-INFO
018845             PERFORM  0260-1000-GENERATE-MESSAGE
018845                 THRU 0260-1000-GENERATE-MESSAGE-X
018845             SET WS-ERROR-FOUND          TO TRUE
018845             GO TO 5250-EDIT-SHRT-CALC-CD-X
018845         END-IF
018845     END-IF.
018845
018845     IF NOT (RPOL-POL-INS-TYP-FLEXIBLE
018845     OR      RPOL-POL-INS-TYP-SEG-FUND)
018845         IF  RPOL-POL-MTHV-PRCES-NO
018845         AND NOT WS-SHRT-CALC-NONE
018845*MSG:SHORTAGE CALC TYPE MUST BE NOT-APPLICABLE FOR NON UL PRODUCTS
018845             MOVE 'CS01510126'        TO WGLOB-MSG-REF-INFO
018845             PERFORM  0260-1000-GENERATE-MESSAGE
018845                 THRU 0260-1000-GENERATE-MESSAGE-X
018845             SET WS-ERROR-FOUND          TO TRUE
018845             GO TO 5250-EDIT-SHRT-CALC-CD-X
018845         END-IF
018845     END-IF.
018845
018845     MOVE MIR-POL-SHRT-CALC-CD  TO RPOL-POL-SHRT-CALC-CD
018845     SET UPDATE-REQUIRED        TO TRUE.
018845
018845 5250-EDIT-SHRT-CALC-CD-X.
018845     EXIT.

021239*----------------------------
021239 5260-EDIT-UNIT-TYP-CD.
021239*----------------------------
021239
021239     EVALUATE TRUE
021239
021239         WHEN MIR-POL-UNIT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
021239              MOVE SPACE         TO MIR-POL-UNIT-TYP-CD
021239              MOVE SPACE         TO RPOL-POL-UNIT-TYP-CD
020455              SET UPDATE-REQUIRED TO TRUE
021239              GO TO 5260-EDIT-UNIT-TYP-CD-X
021239
021239         WHEN MIR-POL-UNIT-TYP-CD = SPACE
021239              MOVE RPOL-POL-UNIT-TYP-CD TO MIR-POL-UNIT-TYP-CD
021239              GO TO 5260-EDIT-UNIT-TYP-CD-X
021239
021239     END-EVALUATE.
021239
021239     MOVE MIR-POL-UNIT-TYP-CD    TO WEDIT-ETBL-VALU-ID.
021239
021239     PERFORM  UVTP-1000-EDIT
021239         THRU UVTP-1000-EDIT-X.
021239
021239     IF  NOT WEDIT-IO-OK
021239         SET WS-ERROR-FOUND           TO TRUE
021239*MSG: POLICY UNIT TYPE CODE (@1) NOT ON EDIT (@2)
021239         MOVE 'CS01510002'            TO WGLOB-MSG-REF-INFO
021239         MOVE MIR-POL-UNIT-TYP-CD      TO WGLOB-MSG-PARM (1)
021239         MOVE 'UVTYP'                  TO WGLOB-MSG-PARM (2)
021239         PERFORM  0260-1000-GENERATE-MESSAGE
021239             THRU 0260-1000-GENERATE-MESSAGE-X
021239     ELSE
021239         SET UPDATE-REQUIRED          TO TRUE
021239         MOVE MIR-POL-UNIT-TYP-CD
021239                                TO RPOL-POL-UNIT-TYP-CD
021239     END-IF.
021239
021239 5260-EDIT-UNIT-TYP-CD-X.
021239     EXIT.
021239
020452*----------------------------
020452 5270-EDIT-FRGN-TST-EFF-DT.
020452*----------------------------
020452
020452     IF  MIR-POL-FRGN-TST-DT = SPACES
020452         MOVE RPOL-POL-FRGN-TST-DT  TO L1640-INTERNAL-DATE
020452         PERFORM  1640-8000-INTERNAL-TO-MIR
020452             THRU 1640-8000-INTERNAL-TO-MIR-X
020452         MOVE L1640-EXTERNAL-DATE    TO MIR-POL-FRGN-TST-DT
020452         GO TO 5270-EDIT-FRGN-TST-EFF-DT-X
020452     END-IF.
020452
020452     IF  MIR-POL-FRGN-TST-DT = EBLCH-BLANK-FIELD-CHAR
020452         IF  RPOL-POL-REG
020452             MOVE RPOL-POL-ISS-EFF-DT  TO L1640-INTERNAL-DATE
020452             PERFORM  1640-8000-INTERNAL-TO-MIR
020452                 THRU 1640-8000-INTERNAL-TO-MIR-X
020452             MOVE L1640-EXTERNAL-DATE
020452               TO MIR-POL-FRGN-TST-DT
020452             MOVE L1640-INTERNAL-DATE
020452               TO RPOL-POL-FRGN-TST-DT
020452*MSG: FOREIGN CONTENT TEST DATE DEFAULT TO ISSUE DATE
020452             MOVE 'CS01510128'        TO WGLOB-MSG-REF-INFO
020452             PERFORM  0260-1000-GENERATE-MESSAGE
020452                 THRU 0260-1000-GENERATE-MESSAGE-X
020452*MSG: WARNING - FOREIGN CONTENT TEST DATE UPDATED MANUALLY,
020452*     UNDO/REDO BEFORE CHANGES MAY BE REQUIRED.
020452             MOVE 'CS01510004'        TO WGLOB-MSG-REF-INFO
020452             PERFORM  0260-1000-GENERATE-MESSAGE
020452                 THRU 0260-1000-GENERATE-MESSAGE-X
020452         ELSE
020452             MOVE WWKDT-ZERO-DT    TO MIR-POL-FRGN-TST-DT
020452             MOVE WWKDT-ZERO-DT    TO RPOL-POL-FRGN-TST-DT
020452         END-IF
020452         GO TO 5270-EDIT-FRGN-TST-EFF-DT-X
020452     END-IF.
020452
020452     MOVE MIR-POL-FRGN-TST-DT           TO L1640-EXTERNAL-DATE.
020452
020452     PERFORM  1640-7000-MIR-TO-INT
020452         THRU 1640-7000-MIR-TO-INT-X.
020452
020452     IF  L1640-NOT-VALID
020452         SET WS-ERROR-FOUND       TO TRUE
020452*MSG: INVALID FOREIGN CONTENT TEST DATE
020452         MOVE 'CS01510003'        TO WGLOB-MSG-REF-INFO
020452         PERFORM  0260-1000-GENERATE-MESSAGE
020452             THRU 0260-1000-GENERATE-MESSAGE-X
020452         GO TO 5270-EDIT-FRGN-TST-EFF-DT-X
020452     END-IF.
020452
020452     IF  L1640-INTERNAL-DATE > WGLOB-PROCESS-DATE
020452         SET WS-ERROR-FOUND       TO TRUE
020452*MSG: DATE OF LAST FOREIGN CONTENT TEST CANNOT BE IN THE FUTURE
020452         MOVE 'CS01510129'        TO WGLOB-MSG-REF-INFO
020452         PERFORM  0260-1000-GENERATE-MESSAGE
020452             THRU 0260-1000-GENERATE-MESSAGE-X
020452         GO TO 5270-EDIT-FRGN-TST-EFF-DT-X
020452     ELSE
020452         IF  L1640-INTERNAL-DATE NOT = RPOL-POL-FRGN-TST-DT
020452*MSG: WARNING - FOREIGN CONTENT TEST DATE UPDATED MANUALLY,
020452*     UNDO/REDO MAY BE REQUIRED.
020452             MOVE 'CS01510004'            TO WGLOB-MSG-REF-INFO
020452             PERFORM  0260-1000-GENERATE-MESSAGE
020452                 THRU 0260-1000-GENERATE-MESSAGE-X
020452         END-IF
020452         SET UPDATE-REQUIRED      TO TRUE
020452         MOVE L1640-INTERNAL-DATE TO RPOL-POL-FRGN-TST-DT
020452     END-IF.
020452
020452 5270-EDIT-FRGN-TST-EFF-DT-X.
020452     EXIT.
020452
      *---------------------------
       5301-EDIT-LNDTE1.
      *---------------------------

           IF  MIR-LOAN-DT-T (1)               =  SPACES
               MOVE RPOLL-LOAN-DT     TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LOAN-DT-T (1)
               GO TO 5301-EDIT-LNDTE1-X
557660     END-IF.

           IF  MIR-LOAN-DT-T (1)               =  EBLCH-BLANK-FIELD-CHAR
013578         IF RPOLL-LOAN-DT NOT = WWKDT-ZERO-DT
                   MOVE WWKDT-ZERO-DT     TO RPOLL-LOAN-DT
                   SET WS-UPDT-POLL-REQD        TO TRUE
013578         END-IF
               MOVE SPACES            TO MIR-LOAN-DT-T (1)
               GO TO 5301-EDIT-LNDTE1-X
557660     END-IF.

           IF  MIR-LOAN-DT-T (1)           NOT =  SPACES
               MOVE MIR-LOAN-DT-T (1) TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
                   SET WS-ERROR-FOUND       TO TRUE
557756*            MOVE LOAN-DATE-1 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*            MOVE 'CS01510001'        TO WGLOB-MSG-REF-INFO
557756             MOVE 'CS01510104'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
013578             GO TO 5301-EDIT-LNDTE1-X
013578         END-IF
013578         IF L1640-INTERNAL-DATE NOT = RPOLL-LOAN-DT
                   SET WS-UPDT-POLL-REQD TO TRUE
                   MOVE L1640-INTERNAL-DATE
                                      TO RPOLL-LOAN-DT
               END-IF
557660     END-IF.

       5301-EDIT-LNDTE1-X.
           EXIT.
      *
      *---------------------------
       5302-EDIT-LNDTE2.
      *---------------------------

           IF  MIR-LOAN-DT-T (2)               =  SPACES
               MOVE RPOLL-LOAN-DT     TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LOAN-DT-T (2)
               GO TO 5302-EDIT-LNDTE2-X
557660     END-IF.

           IF  MIR-LOAN-DT-T (2)               =  EBLCH-BLANK-FIELD-CHAR
013578         IF RPOLL-LOAN-DT NOT = WWKDT-ZERO-DT
                   MOVE WWKDT-ZERO-DT     TO RPOLL-LOAN-DT
                   SET WS-UPDT-POLL-REQD        TO TRUE
013578         END-IF
               MOVE SPACES            TO MIR-LOAN-DT-T (2)
               GO TO 5302-EDIT-LNDTE2-X
557660     END-IF.

           IF  MIR-LOAN-DT-T (2) NOT = SPACES
               MOVE MIR-LOAN-DT-T (2) TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF L1640-NOT-VALID
                   SET WS-ERROR-FOUND       TO TRUE
557756*            MOVE LOAN-DATE-2 (WGLOB-LANG-SUB)
557756*                                     TO WGLOB-MSG-PARM (1)
557756*            MOVE 'CS01510001'        TO WGLOB-MSG-REF-INFO
557756             MOVE 'CS01510105'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
013578             GO TO 5302-EDIT-LNDTE2-X
013578         END-IF
013578         IF L1640-INTERNAL-DATE NOT = RPOLL-LOAN-DT
                   SET WS-UPDT-POLL-REQD    TO TRUE
                   MOVE L1640-INTERNAL-DATE
                                      TO RPOLL-LOAN-DT
557660         END-IF
557660     END-IF.

       5302-EDIT-LNDTE2-X.
           EXIT.
      *
      *---------------------------
       5303-EDIT-APLDTE.
      *---------------------------

           IF  MIR-LOAN-DT-T (3)              =  SPACES
               MOVE RPOLL-LOAN-DT     TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LOAN-DT-T (3)
               GO TO 5303-EDIT-APLDTE-X
557660     END-IF.

           IF  MIR-LOAN-DT-T (3)              =  EBLCH-BLANK-FIELD-CHAR
013578         IF RPOLL-LOAN-DT NOT = WWKDT-ZERO-DT
                   MOVE WWKDT-ZERO-DT     TO RPOLL-LOAN-DT
                   SET WS-UPDT-POLL-REQD        TO TRUE
013578         END-IF
               MOVE SPACES            TO MIR-LOAN-DT-T (3)
               GO TO 5303-EDIT-APLDTE-X
557660     END-IF.

           IF  MIR-LOAN-DT-T (3)          NOT =  SPACES
               MOVE MIR-LOAN-DT-T (3) TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
                   SET WS-ERROR-FOUND       TO TRUE
557756*            MOVE APL-DATE (WGLOB-LANG-SUB) TO WGLOB-MSG-PARM (1)
557756*            MOVE 'CS01510001'        TO WGLOB-MSG-REF-INFO
557756             MOVE 'CS01510106'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
013578             GO TO 5303-EDIT-APLDTE-X
013578         END-IF
013578         IF L1640-INTERNAL-DATE NOT = RPOLL-LOAN-DT
                   SET WS-UPDT-POLL-REQD    TO TRUE
                   MOVE L1640-INTERNAL-DATE
                                      TO RPOLL-LOAN-DT
557660         END-IF
557660     END-IF.

       5303-EDIT-APLDTE-X.
           EXIT.

      *
557697*--------------------
557697 5400-XEDIT-SCREEN-1.
557697*--------------------
557697
557697     IF  MIR-SFB-NEG-SUSP-IND = 'Y'
557697         IF  L2520-SFB-NEG-SUSP-QTY < 01
557697*MSG 'SF PREM RULE IS Y; SF NEG LIMIT MUST BE GREATER THAN 0'
557697             MOVE 'CS01510111'  TO WGLOB-MSG-REF-INFO
557697             SET WS-ERROR-FOUND       TO TRUE
557697
557697             PERFORM  0260-1000-GENERATE-MESSAGE
557697                 THRU 0260-1000-GENERATE-MESSAGE-X
557697
557697         END-IF
557697     ELSE
557697         IF L2520-SFB-NEG-SUSP-QTY > 0
557697*MSG 'SF PREM RULE IS N; SF NEG LIMIT MUST BE 0'
557697             MOVE 'CS01510112'  TO WGLOB-MSG-REF-INFO
557697             SET WS-ERROR-FOUND       TO TRUE
557697
557697             PERFORM  0260-1000-GENERATE-MESSAGE
557697                 THRU 0260-1000-GENERATE-MESSAGE-X
010311         END-IF
557697     END-IF.
557697
557697 5400-XEDIT-SCREEN-1-X.
557697     EXIT.
013578*
013578*----------------------------
013578 5500-DISP-NON-UPDATE-FIELDS.
013578*----------------------------
013578*
010418     MOVE RPOL-SBSDRY-CO-ID          TO MIR-SBSDRY-CO-ID.
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578     INITIALIZE L0620-INPUT-PARM-INFO.
013578*
013578     IF  L2430-CLI-SEX-COMPANY
013578         MOVE L2430-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
013578     ELSE
013578         MOVE L2430-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
013578         MOVE L2430-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
013578         MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
013578         MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
013578     END-IF.
013578*
013578     MOVE L2430-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
013578     PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578         THRU 0620-1000-FORMAT-SCREEN-NAME-X.
013578     MOVE L0620-SCREEN-NAME          TO MIR-DV-OWN-CLI-NM.
013578*
013578 5500-DISP-NON-UPDATE-FIELDS-X.
013578     EXIT.
      *
557788*-------------------
557788 7200-GET-REGC-INFO.
557788*-------------------

557788     PERFORM  2530-1000-BUILD-PARM-INFO
557788         THRU 2530-1000-BUILD-PARM-INFO-X.
557788     MOVE RPOL-POL-ID           TO L2530-REG-POL-ID.
557788     PERFORM  2530-1100-GET-REGC-OWNER
557788         THRU 2530-1100-GET-REGC-OWNER-X.
557788     MOVE L2530-REG-CNTRB-1-AMT TO WS-REG-CNTRB-1-AMT (1).
557788     MOVE L2530-REG-CNTRB-2-AMT TO WS-REG-CNTRB-2-AMT (1).
557788     MOVE L2530-REG-CNTRB-RECPT-DT
                                      TO WS-REG-CNTRB-RECPT-DT (1).
557788     MOVE L2530-REG-RECPT-1-AMT TO WS-REG-RECPT-1-AMT (1).
557788     MOVE L2530-REG-RECPT-2-AMT TO WS-REG-RECPT-2-AMT (1).
557788     MOVE L2530-REG-CNTRB-SPCL-AMT
                                      TO WS-REG-CNTRB-SPCL-AMT (1).
557788     MOVE L2530-REG-CNTRB-XFER-DT
                                      TO WS-REG-CNTRB-XFER-DT (1).
557788
557788     PERFORM  2530-1000-BUILD-PARM-INFO
557788         THRU 2530-1000-BUILD-PARM-INFO-X.
557788     MOVE RPOL-POL-ID           TO L2530-REG-POL-ID.
016537*    PERFORM  2530-1100-GET-REGC-SPOUSE
016537*        THRU 2530-1100-GET-REGC-SPOUSE-X.
016537     PERFORM  2530-1200-GET-REGC-SPOUSE
016537         THRU 2530-1200-GET-REGC-SPOUSE-X.
557788     MOVE L2530-REG-CNTRB-1-AMT TO WS-REG-CNTRB-1-AMT (2).
557788     MOVE L2530-REG-CNTRB-2-AMT TO WS-REG-CNTRB-2-AMT (2).
557788     MOVE L2530-REG-CNTRB-RECPT-DT
                                      TO WS-REG-CNTRB-RECPT-DT (2).
557788     MOVE L2530-REG-RECPT-1-AMT TO WS-REG-RECPT-1-AMT (2).
557788     MOVE L2530-REG-RECPT-2-AMT TO WS-REG-RECPT-2-AMT (2).
557788     MOVE L2530-REG-CNTRB-SPCL-AMT
                                      TO WS-REG-CNTRB-SPCL-AMT (2).
557788     MOVE L2530-REG-CNTRB-XFER-DT
                                      TO WS-REG-CNTRB-XFER-DT (2).
557788
557788 7200-GET-REGC-INFO-X.
557788     EXIT.
      *
557788*----------------------
557788 7300-UPDATE-REGC-INFO.
557788*----------------------

557788     IF  WS-REGC-OWNER-UPDT-REQ
557788         MOVE WS-REG-CNTRB-1-AMT (1)
                                      TO L2530-REG-CNTRB-1-AMT
557788         MOVE WS-REG-CNTRB-2-AMT (1)
                                      TO L2530-REG-CNTRB-2-AMT
557788         MOVE WS-REG-CNTRB-RECPT-DT (1)
557788                                TO L2530-REG-CNTRB-RECPT-DT
557788         MOVE WS-REG-RECPT-1-AMT (1)
                                      TO L2530-REG-RECPT-1-AMT
557788         MOVE WS-REG-RECPT-2-AMT (1)
                                      TO L2530-REG-RECPT-2-AMT
557788         MOVE WS-REG-CNTRB-SPCL-AMT (1)
557788                                TO L2530-REG-CNTRB-SPCL-AMT
557788         MOVE WS-REG-CNTRB-XFER-DT (1)
                                      TO L2530-REG-CNTRB-XFER-DT
557788         PERFORM  2530-2100-UPDATE-REGC-OWNER
557788             THRU 2530-2100-UPDATE-REGC-OWNER-X
557788     END-IF.
557788
557788     IF  WS-REGC-SPOU-UPDT-REQ
557788         MOVE WS-REG-CNTRB-1-AMT (2)
                                      TO L2530-REG-CNTRB-1-AMT
557788         MOVE WS-REG-CNTRB-2-AMT (2)
                                      TO L2530-REG-CNTRB-2-AMT
557788         MOVE WS-REG-CNTRB-RECPT-DT (2)
557788                                TO L2530-REG-CNTRB-RECPT-DT
557788         MOVE WS-REG-RECPT-1-AMT (2)
                                      TO L2530-REG-RECPT-1-AMT
557788         MOVE WS-REG-RECPT-2-AMT (2)
                                      TO L2530-REG-RECPT-2-AMT
557788         MOVE WS-REG-CNTRB-SPCL-AMT (2)
557788                                TO L2530-REG-CNTRB-SPCL-AMT
557788         MOVE WS-REG-CNTRB-XFER-DT (2)
                                      TO L2530-REG-CNTRB-XFER-DT
016537*        PERFORM  2530-2100-UPDATE-REGC-SPOUSE
016537*            THRU 2530-2100-UPDATE-REGC-SPOUSE-X
016537         PERFORM  2530-2200-UPDATE-REGC-SPOUSE
016537             THRU 2530-2200-UPDATE-REGC-SPOUSE-X
557788     END-IF.
557788
557788 7300-UPDATE-REGC-INFO-X.
557788     EXIT.
      *
      *---------------------------
       8000-MOVE-RECORD-TO-SCREEN.
      *---------------------------


           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
      *
           MOVE SPACE                 TO MIR-DV-OWN-CLI-NM.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
557668*    MOVE L2430-CLI-NM-COMPRESSED  TO MIR-DV-OWN-CLI-ENTR-NM.
557668     INITIALIZE L0620-INPUT-PARM-INFO.
557668     IF  L2430-CLI-SEX-COMPANY
557668         MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668     ELSE
557668         MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668         MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
013578         MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
013578         MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
557668     END-IF.
557668     MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.

557668     PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668         THRU 0620-1000-FORMAT-SCREEN-NAME-X.

557668     MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.

           MOVE RPOL-POL-PD-TO-DT-NUM TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-PD-TO-DT-NUM
           ELSE
               MOVE SPACES            TO MIR-POL-PD-TO-DT-NUM
557660     END-IF.

           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
008455*    MOVE RPOL-POL-TOT-BILL-AMT    TO WS-HOLD-7-2-S.
008455*    MOVE WS-DISP-7-2-S            TO MIR-POL-TOT-BILL-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-TOT-BILL-AMT * 100.
020874     MOVE RPOL-POL-TOT-BILL-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-TOT-BILL-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-TOT-BILL-AMT.

           MOVE RPOL-PREV-PD-TO-DT-NUM           TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PREV-PD-TO-DT-NUM
           ELSE
               MOVE SPACES            TO MIR-PREV-PD-TO-DT-NUM
557660     END-IF.

           MOVE RPOL-POL-PREV-MODE-CD-N
                                      TO MIR-POL-PREV-MODE-CD.
           MOVE RPOL-PREV-BILL-TYP-CD TO MIR-PREV-BILL-TYP-CD.
020874*    MOVE RPOL-POL-PREV-MODE-FCT                   TO WS-HOLD-2-7.
020874*    MOVE WS-DISP-2-7           TO MIR-POL-PREV-MODE-FCT.
020874     MOVE RPOL-POL-PREV-MODE-FCT TO L0290-INPUT-V07.
020874     MOVE 7                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-PREV-MODE-FCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-MODE-FCT.
020874*    MOVE RPOL-POL-PREV-PFEE-FCT                   TO WS-HOLD-2-7.
020874*    MOVE WS-DISP-2-7           TO MIR-POL-PREV-PFEE-FCT.
020874     MOVE RPOL-POL-PREV-PFEE-FCT TO L0290-INPUT-V07.
020874     MOVE 7                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-PREV-PFEE-FCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-PFEE-FCT.
020874*    MOVE RPOL-POL-BASE-CVG-NUM TO WS-HOLD-2-0.
020874*    MOVE WS-DISP-2-0           TO MIR-POL-BASE-CVG-NUM.
020874     MOVE RPOL-POL-BASE-CVG-NUM TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-BASE-CVG-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-POL-BASE-CVG-NUM.
020874*    MOVE RPOL-POL-PAR-CVG-NUM  TO WS-HOLD-2-0.
020874*    MOVE WS-DISP-2-0           TO MIR-POL-PAR-CVG-NUM.
020874     MOVE RPOL-POL-PAR-CVG-NUM  TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-PAR-CVG-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PAR-CVG-NUM.
           MOVE RPOL-XHBT-ISS-LOC-CD  TO MIR-XHBT-ISS-LOC-CD.
           MOVE RPOL-XHBT-CRNT-LOC-CD TO MIR-XHBT-CRNT-LOC-CD.
008455*    MOVE RPOL-UL-LAPS-NOTI-AMT    TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-UL-LAPS-NOTI-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-UL-LAPS-NOTI-AMT * 100.
020874     MOVE RPOL-UL-LAPS-NOTI-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UL-LAPS-NOTI-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UL-LAPS-NOTI-AMT.

557665*    MOVE RPOL-POL-ANPAYO-PAC-DT   TO L1640-INTERNAL-DATE.
016395*    MOVE RPOL-POL-PAC-DRW-DT   TO L1640-INTERNAL-DATE.
016395     MOVE RPOL-POL-PMT-DRW-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
               MOVE L1640-EXTERNAL-DATE
016395*                               TO MIR-POL-PAC-DRW-DT
016395                                TO MIR-POL-PMT-DRW-DT
           ELSE
016395*        MOVE SPACES            TO MIR-POL-PAC-DRW-DT
016395         MOVE SPACES            TO MIR-POL-PMT-DRW-DT
557660     END-IF.

008455*    MOVE RPOL-POL-PREV-FACE-AMT   TO WS-HOLD-9-2-S.
008455*    MOVE WS-HOLD-9-2-S            TO MIR-POL-PREV-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PREV-FACE-AMT * 100.
020874     MOVE RPOL-POL-PREV-FACE-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PREV-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-FACE-AMT.
008455*    MOVE RPOL-DIV-DCLR-LTD-AMT    TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-DIV-DCLR-LTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-DIV-DCLR-LTD-AMT * 100.
020874     MOVE RPOL-DIV-DCLR-LTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIV-DCLR-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DIV-DCLR-LTD-AMT.
           MOVE RPOL-POL-GL-ACCT-TYP-CD
                                      TO MIR-POL-GL-ACCT-TYP-CD.
           MOVE RPOL-POL-ACCT-PAR-CD  TO MIR-POL-ACCT-PAR-CD.
008455*    MOVE RPOL-DIV-DCLR-YTD-AMT    TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-DIV-DCLR-YTD-AMT.
012181*    COMPUTE L0290-INPUT-NUMBER = RPOL-DIV-DCLR-YTD-AMT * 100.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-DIV-DCLR-DUR-AMT * 100.
020874     MOVE RPOL-DIV-DCLR-DUR-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
012181*    MOVE LENGTH OF MIR-DIV-DCLR-YTD-AMT
012181     MOVE LENGTH OF MIR-DIV-DCLR-DUR-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
012181*    MOVE L0290-OUTPUT-DATA     TO MIR-DIV-DCLR-YTD-AMT.
012181     MOVE L0290-OUTPUT-DATA     TO MIR-DIV-DCLR-DUR-AMT.
008455*    MOVE RPOL-POL-DOD-ACUM-AMT    TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-POL-DOD-ACUM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-DOD-ACUM-AMT * 100.
020874     MOVE RPOL-POL-DOD-ACUM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-DOD-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-DOD-ACUM-AMT.
008455*    MOVE RPOL-POL-DOD-AVB-AMT     TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-POL-DOD-AVB-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-DOD-AVB-AMT * 100.
020874     MOVE RPOL-POL-DOD-AVB-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-DOD-AVB-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-DOD-AVB-AMT.
016641*    MOVE RPOL-POL-DOD-INT-RT   TO WS-HOLD-0-5.
016641*    MOVE WS-HOLD-0-5           TO MIR-POL-DOD-INT-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*        RPOL-POL-DOD-INT-RT * 100000.
020874     MOVE RPOL-POL-DOD-INT-RT TO L0290-INPUT-V05.
016641     MOVE 5  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-POL-DOD-INT-RT
016641                          TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-POL-DOD-INT-RT.
008455*    MOVE RPOL-DOD-CRNT-INT-AMT    TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-DOD-CRNT-INT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-DOD-CRNT-INT-AMT * 100.
020874     MOVE RPOL-DOD-CRNT-INT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DOD-CRNT-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DOD-CRNT-INT-AMT.
           MOVE RPOL-POL-PREV-DIV-DUR TO MIR-POL-PREV-DIV-DUR.
008455*    MOVE RPOL-PUA-LTD-FACE-AMT    TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-PUA-LTD-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-PUA-LTD-FACE-AMT * 100.
020874     MOVE RPOL-PUA-LTD-FACE-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PUA-LTD-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PUA-LTD-FACE-AMT.
008455*    MOVE RPOL-PUA-YTD-FACE-AMT    TO WS-HOLD-7-2-S
008455*    MOVE WS-HOLD-7-2-S            TO MIR-PUA-YTD-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-PUA-YTD-FACE-AMT * 100.
020874     MOVE RPOL-PUA-YTD-FACE-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PUA-YTD-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PUA-YTD-FACE-AMT.
008455*    MOVE RPOL-POL-OYT-AMT         TO WS-HOLD-7-0.
008455*    MOVE WS-HOLD-7-0              TO MIR-POL-OYT-AMT.
020874*    MOVE RPOL-POL-OYT-AMT      TO L0290-INPUT-NUMBER.
020874     MOVE RPOL-POL-OYT-AMT      TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-OYT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-OYT-AMT.

           MOVE MIR-POL-ID            TO WPOLL-POL-ID.
           MOVE 'C'                   TO WPOLL-POL-LOAN-ID.

           PERFORM  POLL-1000-READ
               THRU POLL-1000-READ-X.

           IF  NOT WPOLL-IO-OK
               PERFORM  POLL-1000-CREATE
                   THRU POLL-1000-CREATE-X
           END-IF.

           MOVE RPOLL-POL-LOAN-ID     TO MIR-POL-LOAN-ID-T (1).
008455*    MOVE RPOLL-LOAN-AMT           TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-AMT-T(1).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AMT * 100.
020874     MOVE RPOLL-LOAN-AMT        TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-AMT-T(1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-AMT-T(1).
008455
016641*    MOVE RPOLL-LOAN-INT-RT     TO WS-HOLD-0-5.
016641*    MOVE WS-HOLD-0-5           TO MIR-LOAN-INT-RT-T(1).
020874*    COMPUTE L0290-INPUT-NUMBER =
018842*        RPOLL-LOAN-INT-RT * 100000.
020874*        RPOLL-LOAN-INT-PCT * 10000.
020874     MOVE RPOLL-LOAN-INT-PCT TO L0290-INPUT-V04.
018842*    MOVE 5  TO L0290-PRECISION.
018842     MOVE 4  TO L0290-PRECISION.
018842*    MOVE LENGTH OF MIR-LOAN-INT-RT-T(1)
018842     MOVE LENGTH OF MIR-LOAN-INT-PCT-T(1)
016641                          TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018842*    MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-RT-T(1).
018842     MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T(1).
018842*    MOVE RPOLL-LOAN-INT-MAX-RT TO WS-HOLD-0-5.
018842*    MOVE WS-HOLD-0-5           TO MIR-LOAN-INT-MAX-RT-T(1)

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*        RPOLL-LOAN-INT-MAX-PCT * 10000.
020874     MOVE RPOLL-LOAN-INT-MAX-PCT TO L0290-INPUT-V04.
018842     MOVE 4  TO L0290-PRECISION.
018842     MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T(1)
018842                          TO L0290-MAX-OUT-LEN.
018842     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018842     MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T(1).

008455
008455*    MOVE RPOLL-LOAN-INT-BILL-AMT  TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-INT-BILL-AMT-T(1).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-BILL-AMT * 100.
020874     MOVE RPOLL-LOAN-INT-BILL-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T(1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-INT-BILL-AMT-T(1).
008455
008455*    MOVE RPOLL-LOAN-INT-YTD-AMT   TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-LOAN-INT-YTD-AMT-T(1).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-YTD-AMT * 100.
020874     MOVE RPOLL-LOAN-INT-YTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T(1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-INT-YTD-AMT-T(1).
008455
008455*    MOVE RPOLL-LOAN-AVB-AMT       TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-AVB-AMT-T(1).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AVB-AMT * 100.
020874     MOVE RPOLL-LOAN-AVB-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-AVB-AMT-T(1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-AVB-AMT-T(1).
008455
           MOVE RPOLL-LOAN-INT-TYP-CD TO MIR-LOAN-INT-TYP-CD-T(1).


020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-ANNV-AMT * 100.
020874     MOVE RPOLL-LOAN-ANNV-AMT   TO L0290-INPUT-V02.
010397     MOVE 2                     TO L0290-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
010397     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-ANNV-AMT-T (1).

020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-PREV-ANNV-AMT * 100.
020874     MOVE RPOLL-LOAN-PREV-ANNV-AMT TO L0290-INPUT-V02.
010397     MOVE 2                        TO L0290-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
010397     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-PREV-ANNV-AMT-T (1).

           MOVE RPOLL-LOAN-DT         TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
              MOVE L1640-EXTERNAL-DATE               TO MIR-LOAN-DT-T(1)
           ELSE
               MOVE SPACES            TO MIR-LOAN-DT-T(1)
557660     END-IF.

           MOVE MIR-POL-ID            TO WPOLL-POL-ID.
           MOVE 'O'                   TO WPOLL-POL-LOAN-ID.

           PERFORM  POLL-1000-READ
               THRU POLL-1000-READ-X.

           IF  NOT WPOLL-IO-OK
               PERFORM  POLL-1000-CREATE
                   THRU POLL-1000-CREATE-X
           END-IF.

           MOVE RPOLL-POL-LOAN-ID     TO MIR-POL-LOAN-ID-T (2).
008455*    MOVE RPOLL-LOAN-AMT           TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-AMT-T(2).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AMT * 100.
020874     MOVE RPOLL-LOAN-AMT        TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-AMT-T(2)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-AMT-T(2).
008455
016641*    MOVE RPOLL-LOAN-INT-RT     TO WS-HOLD-0-5.
016641*    MOVE WS-HOLD-0-5           TO MIR-LOAN-INT-RT-T(2).
020874*    COMPUTE L0290-INPUT-NUMBER =
018842*        RPOLL-LOAN-INT-RT * 100000.
020874*        RPOLL-LOAN-INT-PCT * 10000.
020874     MOVE RPOLL-LOAN-INT-PCT TO L0290-INPUT-V04.
018842*    MOVE 5  TO L0290-PRECISION.
018842     MOVE 4  TO L0290-PRECISION.
018842*    MOVE LENGTH OF MIR-LOAN-INT-RT-T(2)
018842     MOVE LENGTH OF MIR-LOAN-INT-PCT-T(2)
016641                          TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018842*    MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-RT-T(2).
018842     MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T(2).

016641*    MOVE RPOLL-LOAN-INT-MAX-RT TO WS-HOLD-0-5.
016641*    MOVE WS-HOLD-0-5           TO MIR-LOAN-INT-MAX-RT-T(2).
020874*    COMPUTE L0290-INPUT-NUMBER =
018842*        RPOLL-LOAN-INT-MAX-RT * 100000.
020874*        RPOLL-LOAN-INT-MAX-PCT * 10000.
020874     MOVE RPOLL-LOAN-INT-MAX-PCT TO L0290-INPUT-V04.
018842*    MOVE 5  TO L0290-PRECISION.
018842     MOVE 4  TO L0290-PRECISION.
018842*    MOVE LENGTH OF MIR-LOAN-INT-MAX-RT-T(2)
018842     MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T(2)
016641                          TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018842*    MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-RT-T(2).
018842     MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T(2).
008455
008455*    MOVE RPOLL-LOAN-INT-BILL-AMT  TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-INT-BILL-AMT-T(2).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-BILL-AMT * 100.
020874     MOVE RPOLL-LOAN-INT-BILL-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T(2)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-INT-BILL-AMT-T(2).
008455
008455*    MOVE RPOLL-LOAN-INT-YTD-AMT   TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-LOAN-INT-YTD-AMT-T(2).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-YTD-AMT * 100.
020874     MOVE RPOLL-LOAN-INT-YTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T(2)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-INT-YTD-AMT-T(2).
008455
008455*    MOVE RPOLL-LOAN-AVB-AMT       TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-AVB-AMT-T(2).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AVB-AMT * 100.
020874     MOVE RPOL-POL-TOT-BILL-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-AVB-AMT-T(2)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-AVB-AMT-T(2).
008455
           MOVE RPOLL-LOAN-INT-TYP-CD TO MIR-LOAN-INT-TYP-CD-T(2).


020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-ANNV-AMT * 100.
020874     MOVE RPOLL-LOAN-ANNV-AMT   TO L0290-INPUT-V02.
010397     MOVE 2                     TO L0290-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
010397     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-ANNV-AMT-T (2).

020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-PREV-ANNV-AMT * 100.
020874     MOVE RPOLL-LOAN-PREV-ANNV-AMT TO L0290-INPUT-V02.
010397     MOVE 2                        TO L0290-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
010397     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-PREV-ANNV-AMT-T (2).

           MOVE RPOLL-LOAN-DT         TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LOAN-DT-T(2)
           ELSE
               MOVE SPACES            TO MIR-LOAN-DT-T(2)
557660     END-IF.

           MOVE MIR-POL-ID            TO WPOLL-POL-ID.
           MOVE 'A'                   TO WPOLL-POL-LOAN-ID.

           PERFORM  POLL-1000-READ
               THRU POLL-1000-READ-X.

           IF  NOT WPOLL-IO-OK
               PERFORM  POLL-1000-CREATE
                   THRU POLL-1000-CREATE-X
           END-IF.

           MOVE RPOLL-POL-LOAN-ID     TO MIR-POL-LOAN-ID-T (3).
008455*    MOVE RPOLL-LOAN-AMT           TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-AMT-T(3).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AMT * 100.
020874     MOVE RPOLL-LOAN-AMT        TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-AMT-T(3)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-AMT-T(3).
008455
016641*    MOVE RPOLL-LOAN-INT-RT     TO WS-HOLD-0-5.
016641*    MOVE WS-HOLD-0-5           TO MIR-LOAN-INT-RT-T(3).
020874*    COMPUTE L0290-INPUT-NUMBER =
018842*        RPOLL-LOAN-INT-RT * 100000.
020874*        RPOLL-LOAN-INT-PCT * 10000.
020874     MOVE RPOLL-LOAN-INT-PCT TO L0290-INPUT-V04.
018842*    MOVE 5  TO L0290-PRECISION.
018842     MOVE 4  TO L0290-PRECISION.
018842*    MOVE LENGTH OF MIR-LOAN-INT-RT-T(3)
018842     MOVE LENGTH OF MIR-LOAN-INT-PCT-T(3)
016641                          TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018842*    MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-RT-T(3).
018842     MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-PCT-T(3).

016641*    MOVE RPOLL-LOAN-INT-MAX-RT TO WS-HOLD-0-5.
016641*    MOVE WS-HOLD-0-5           TO MIR-LOAN-INT-MAX-RT-T(3).
020874*    COMPUTE L0290-INPUT-NUMBER =
018842*        RPOLL-LOAN-INT-MAX-RT * 100000.
020874*        RPOLL-LOAN-INT-MAX-PCT * 10000.
020874     MOVE RPOLL-LOAN-INT-MAX-PCT TO L0290-INPUT-V04.
018842*    MOVE 5  TO L0290-PRECISION.
018842     MOVE 4  TO L0290-PRECISION.
018842*    MOVE LENGTH OF MIR-LOAN-INT-MAX-RT-T(3)
018842     MOVE LENGTH OF MIR-LOAN-INT-MAX-PCT-T(3)
016641                          TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018842*    MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-RT-T(3).
018842     MOVE L0290-OUTPUT-DATA TO MIR-LOAN-INT-MAX-PCT-T(3).
008455
008455*    MOVE RPOLL-LOAN-INT-BILL-AMT  TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-INT-BILL-AMT-T(3).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-BILL-AMT * 100.
020874     MOVE RPOLL-LOAN-INT-BILL-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-INT-BILL-AMT-T(3)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-INT-BILL-AMT-T(3).
008455
008455*    MOVE RPOLL-LOAN-INT-YTD-AMT   TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-LOAN-INT-YTD-AMT-T(3).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-INT-YTD-AMT * 100.
020874     MOVE RPOLL-LOAN-INT-YTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-INT-YTD-AMT-T(3)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-INT-YTD-AMT-T(3).
008455
008455*    MOVE RPOLL-LOAN-AVB-AMT       TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-LOAN-AVB-AMT-T(3).
020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-AVB-AMT * 100.
020874     MOVE RPOLL-LOAN-AVB-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-AVB-AMT-T(3)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-AVB-AMT-T(3).
008455
           MOVE RPOLL-LOAN-INT-TYP-CD TO MIR-LOAN-INT-TYP-CD-T(3).

020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-ANNV-AMT * 100.
020874     MOVE RPOLL-LOAN-ANNV-AMT   TO L0290-INPUT-V02.
010397     MOVE 2                     TO L0290-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
010397     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-ANNV-AMT-T (3).

020874*    COMPUTE L0290-INPUT-NUMBER = RPOLL-LOAN-PREV-ANNV-AMT * 100.
020874     MOVE RPOLL-LOAN-PREV-ANNV-AMT TO L0290-INPUT-V02.
010397     MOVE 2                        TO L0290-PRECISION.
010397     MOVE LENGTH OF MIR-LOAN-ANNV-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
010397     MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-PREV-ANNV-AMT-T (3).

           MOVE RPOLL-LOAN-DT         TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LOAN-DT-T (3)
           ELSE
               MOVE SPACES            TO MIR-LOAN-DT-T (3)
557660     END-IF.

008455*    MOVE RPOL-POL-PDF-AMT         TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-POL-PDF-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PDF-AMT * 100.
020874     MOVE RPOL-POL-PDF-AMT      TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PDF-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PDF-AMT.
008455
008455*    MOVE RPOL-POL-PDF-INT-AMT     TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-POL-PDF-INT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PDF-INT-AMT * 100.
020874     MOVE RPOL-POL-PDF-INT-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PDF-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PDF-INT-AMT.
008455
016641*    MOVE RPOL-POL-PDF-INT-RT   TO WS-HOLD-0-5.
016641*    MOVE WS-HOLD-0-5           TO MIR-POL-PDF-INT-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*        RPOL-POL-PDF-INT-RT * 100000.
020874     MOVE RPOL-POL-PDF-INT-RT TO L0290-INPUT-V05.
016641     MOVE 5  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-POL-PDF-INT-RT
016641                          TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-POL-PDF-INT-RT.
008455
008455*    MOVE RPOL-POL-PDF-AVB-AMT     TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-POL-PDF-AVB-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PDF-AVB-AMT * 100.
020874     MOVE RPOL-POL-PDF-AVB-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PDF-AVB-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PDF-AVB-AMT.
008455
           MOVE RPOL-POL-PREV-ANNV-DUR         TO MIR-POL-PREV-ANNV-DUR.
008455
008455*    MOVE RPOL-SURR-DIV-ACUM-AMT   TO WS-HOLD-5-2-S.
008455*    MOVE WS-HOLD-5-2-S            TO MIR-SURR-DIV-ACUM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-SURR-DIV-ACUM-AMT * 100.
020874     MOVE RPOL-SURR-DIV-ACUM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-SURR-DIV-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-SURR-DIV-ACUM-AMT.
008455
008455*    MOVE RPOL-POL-SURR-LOAN-AMT   TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-POL-SURR-LOAN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-SURR-LOAN-AMT * 100.
020874     MOVE RPOL-POL-SURR-LOAN-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-SURR-LOAN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-SURR-LOAN-AMT.
008455
008455*    MOVE RPOL-POL-TRMN-PUA-AMT    TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-POL-TRMN-PUA-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-TRMN-PUA-AMT * 100.
020874     MOVE RPOL-POL-TRMN-PUA-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-TRMN-PUA-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-TRMN-PUA-AMT.
008455
           MOVE RPOL-TRMN-PUA-REASN-CD         TO MIR-TRMN-PUA-REASN-CD.

008455*    MOVE RPOL-POL-MISC-SUSP-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-MISC-SUSP-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-MISC-SUSP-AMT * 100.
020874     MOVE RPOL-POL-MISC-SUSP-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-MISC-SUSP-AMT.

           MOVE RPOL-POL-MISC-SUSP-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-MISC-SUSP-DT
           ELSE
               MOVE SPACES            TO MIR-POL-MISC-SUSP-DT
557660     END-IF.

008455*    MOVE RPOL-POL-PREM-SUSP-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-PREM-SUSP-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PREM-SUSP-AMT * 100.
020874     MOVE RPOL-POL-PREM-SUSP-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREM-SUSP-AMT.

           MOVE RPOL-POL-PREM-SUSP-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-PREM-SUSP-DT
           ELSE
               MOVE SPACES            TO MIR-POL-PREM-SUSP-DT
557660     END-IF.

008455*    MOVE RPOL-POL-DIV-SUSP-AMT    TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-POL-DIV-SUSP-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-DIV-SUSP-AMT * 100.
020874     MOVE RPOL-POL-DIV-SUSP-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-DIV-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-DIV-SUSP-AMT.
008455
008455*    MOVE RPOL-POL-OS-DISB-AMT     TO WS-HOLD-S9-2.
008455*    MOVE WS-HOLD-S9-2             TO MIR-POL-OS-DISB-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-OS-DISB-AMT * 100.
020874     MOVE RPOL-POL-OS-DISB-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-OS-DISB-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-OS-DISB-AMT.

           MOVE RPOL-POL-OS-DISB-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
              MOVE L1640-EXTERNAL-DATE             TO MIR-POL-OS-DISB-DT
           ELSE
              MOVE SPACES             TO MIR-POL-OS-DISB-DT
557660     END-IF.
557697     MOVE L2520-SFB-NEG-SUSP-IND          TO MIR-SFB-NEG-SUSP-IND.
557697     MOVE L2520-SFB-NEG-SUSP-QTY          TO MIR-SFB-NEG-SUSP-QTY.
008455
008455*    MOVE L2520-SFB-NXT-BILL-AMT   TO WS-HOLD-S9-2.
008455*    MOVE WS-HOLD-S9-2             TO MIR-SFB-NXT-BILL-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L2520-SFB-NXT-BILL-AMT * 100.
020874     MOVE L2520-SFB-NXT-BILL-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-SFB-NXT-BILL-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-SFB-NXT-BILL-AMT.

      *
      *----  SCREEN 2: MOVE PO DATA TO DISPLAY LINES
      *

008455*    MOVE RPOL-POL-REG-TOT-AMT     TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-POL-REG-TOT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-REG-TOT-AMT * 100.
020874     MOVE RPOL-POL-REG-TOT-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-REG-TOT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-REG-TOT-AMT.
008455
557788*    MOVE RPOL-POL-REG-1-AMT       TO WS-HOLD-7-2-S.
008455*    MOVE WS-REG-CNTRB-1-AMT (1)   TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-REG-CNTRB-1-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-1-AMT (1) * 100.
020874     MOVE WS-REG-CNTRB-1-AMT (1) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-CNTRB-1-AMT-T (1).
008455
557788*    MOVE RPOL-POL-REG-2-AMT       TO WS-HOLD-7-2-S.
008455*    MOVE WS-REG-CNTRB-2-AMT (1)   TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-REG-CNTRB-2-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-2-AMT (1) * 100.
020874     MOVE WS-REG-CNTRB-2-AMT (1) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-CNTRB-2-AMT-T (1).
008455
557788*    MOVE RPOL-REG-RECPT-1-AMT     TO WS-HOLD-7-2-S.
008455*    MOVE WS-REG-RECPT-1-AMT (1)   TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-REG-RECPT-1-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-RECPT-1-AMT (1) * 100.
020874     MOVE WS-REG-RECPT-1-AMT (1) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-RECPT-1-AMT-T (1).
008455
557788*    MOVE RPOL-REG-RECPT-2-AMT     TO WS-HOLD-7-2-S.
008455*    MOVE WS-REG-RECPT-2-AMT (1)   TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-REG-RECPT-2-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-RECPT-2-AMT (1) * 100.
020874     MOVE WS-REG-RECPT-2-AMT (1) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-RECPT-2-AMT-T (1).
008455
557788*    MOVE RPOL-POL-REG-SPCL-AMT    TO WS-HOLD-7-2-S.
008455*    MOVE WS-REG-CNTRB-SPCL-AMT(1) TO WS-HOLD-7-2-S.
008455*    MOVE WS-HOLD-7-2-S            TO MIR-REG-CNTRB-SPCL-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-SPCL-AMT(1) * 100.
020874     MOVE WS-REG-CNTRB-SPCL-AMT(1) TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-CNTRB-SPCL-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-CNTRB-SPCL-AMT-T (1).


008455*    MOVE RPOL-POL-RRIF-MNPMT-AMT  TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-RRIF-MNPMT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-RRIF-MNPMT-AMT * 100.
020874     MOVE RPOL-POL-RRIF-MNPMT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-RRIF-MNPMT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-RRIF-MNPMT-AMT.
008455
008455*    MOVE RPOL-CASL-PMT-YTD-AMT    TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-CASL-PMT-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-CASL-PMT-YTD-AMT * 100.
020874     MOVE RPOL-CASL-PMT-YTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CASL-PMT-YTD-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CASL-PMT-YTD-AMT.
008455
008455*    MOVE RPOL-POL-ANPAYO-YTD-AMT  TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-ANPAYO-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-ANPAYO-YTD-AMT * 100.
020874     MOVE RPOL-POL-ANPAYO-YTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-ANPAYO-YTD-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-ANPAYO-YTD-AMT.
008455
008455*    MOVE RPOL-POL-ANPAYO-LTD-AMT  TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-ANPAYO-LTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-ANPAYO-LTD-AMT * 100.
020874     MOVE RPOL-POL-ANPAYO-LTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-ANPAYO-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-ANPAYO-LTD-AMT.
008455
008455*    MOVE RPOL-POL-ANTY-SUSP-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-ANTY-SUSP-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-ANTY-SUSP-AMT * 100.
020874     MOVE RPOL-POL-ANTY-SUSP-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-ANTY-SUSP-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-ANTY-SUSP-AMT.

           MOVE RPOL-POL-ANPAYO-PMT-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
              MOVE L1640-EXTERNAL-DATE          TO MIR-POL-ANPAYO-PMT-DT
           ELSE
               MOVE SPACES            TO MIR-POL-ANPAYO-PMT-DT
557660     END-IF.

557788*    MOVE RPOL-REGSP-RECPT-1-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-REG-RECPT-1-AMT (2)   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-REG-RECPT-1-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-RECPT-1-AMT (2) * 100.
020874     MOVE WS-REG-RECPT-1-AMT (2) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-RECPT-1-AMT-T (2).
008455
557788*    MOVE RPOL-REGSP-RECPT-2-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-REG-RECPT-2-AMT (2)   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-REG-RECPT-2-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-RECPT-2-AMT (2) * 100.
020874     MOVE WS-REG-RECPT-2-AMT (2) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-RECPT-2-AMT-T (2).
008455
557788*    MOVE RPOL-POL-REGSP-1-AMT     TO WS-HOLD-S7-2.
008455*    MOVE WS-REG-CNTRB-1-AMT (2)   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-REG-CNTRB-1-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-1-AMT (2) * 100.
020874     MOVE WS-REG-CNTRB-1-AMT (2) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-CNTRB-1-AMT-T (2).
008455
557788*    MOVE RPOL-POL-REGSP-2-AMT     TO WS-HOLD-S7-2.
008455*    MOVE WS-REG-CNTRB-2-AMT (2)   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-REG-CNTRB-2-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-2-AMT (2) * 100.
020874     MOVE WS-REG-CNTRB-2-AMT (2) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-CNTRB-2-AMT-T (2).
008455
557788*    MOVE RPOL-POL-REGSP-SPCL-AMT  TO WS-HOLD-S7-2.
008455*    MOVE WS-REG-CNTRB-SPCL-AMT(2) TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-REG-CNTRB-SPCL-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-REG-CNTRB-SPCL-AMT(2) * 100.
020874     MOVE WS-REG-CNTRB-SPCL-AMT(2) TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REG-CNTRB-SPCL-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REG-CNTRB-SPCL-AMT-T (2).

557788*    MOVE RPOL-POL-REGSP-RECPT-DT  TO L1640-INTERNAL-DATE.
557788     MOVE WS-REG-CNTRB-RECPT-DT(2)
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
557788     IF  L1640-VALID
557788         MOVE L1640-EXTERNAL-DATE
                                      TO MIR-REG-CNTRB-RECPT-DT
557788     ELSE
557788         MOVE SPACES            TO MIR-REG-CNTRB-RECPT-DT
557788     END-IF.

557788*    MOVE RPOL-POL-REGSP-XFER-DT   TO L1640-INTERNAL-DATE.
557788     MOVE WS-REG-CNTRB-XFER-DT (2)
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
557788     IF L1640-VALID
557788         MOVE L1640-EXTERNAL-DATE
                                      TO MIR-REG-CNTRB-XFER-DT
557788     ELSE
557788         MOVE SPACES            TO MIR-REG-CNTRB-XFER-DT
557788     END-IF.

008455*    MOVE RPOL-RRIF-MNPMT-PYR-AMT  TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-RRIF-MNPMT-PYR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-RRIF-MNPMT-PYR-AMT * 100.
020874     MOVE RPOL-RRIF-MNPMT-PYR-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-RRIF-MNPMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-RRIF-MNPMT-PYR-AMT.
008455*    MOVE RPOL-POL-LIF-MXPMT-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-LIF-MXPMT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-LIF-MXPMT-AMT * 100.
020874     MOVE RPOL-POL-LIF-MXPMT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-LIF-MXPMT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-LIF-MXPMT-AMT.
008455*    MOVE RPOL-LIF-MXPMT-PYR-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-LIF-MXPMT-PYR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-LIF-MXPMT-PYR-AMT * 100.
020874     MOVE RPOL-LIF-MXPMT-PYR-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LIF-MXPMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LIF-MXPMT-PYR-AMT.
008455*    MOVE RPOL-CASL-PMT-PYR-AMT    TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-CASL-PMT-PYR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-CASL-PMT-PYR-AMT * 100.
020874     MOVE RPOL-CASL-PMT-PYR-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CASL-PMT-PYR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CASL-PMT-PYR-AMT.
008455*    MOVE RPOL-POL-ANPAYO-PYR-AMT  TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-ANPAYO-PYR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-ANPAYO-PYR-AMT * 100.
020874     MOVE RPOL-POL-ANPAYO-PYR-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-ANPAYO-PYR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-ANPAYO-PYR-AMT.
           MOVE RPOL-POL-LOCK-FND-IND TO MIR-POL-LOCK-FND-IND.

008455*    MOVE RPOL-POL-CRNT-PSUR-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-CRNT-PSUR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-CRNT-PSUR-AMT * 100.
020874     MOVE RPOL-POL-CRNT-PSUR-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-CRNT-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-CRNT-PSUR-AMT.
008455*    MOVE RPOL-POL-PREV-PSUR-AMT   TO WS-HOLD-S7-2.
008455*    MOVE WS-HOLD-S7-2             TO MIR-POL-PREV-PSUR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PREV-PSUR-AMT * 100.
020874     MOVE RPOL-POL-PREV-PSUR-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PREV-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREV-PSUR-AMT.
008455*    MOVE RPOL-POL-AFR-THRSHD-AMT  TO WS-HOLD-S5-2.
008455*    MOVE WS-HOLD-S5-2             TO MIR-POL-AFR-THRSHD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-AFR-THRSHD-AMT * 100.
020874     MOVE RPOL-POL-AFR-THRSHD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-AFR-THRSHD-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-AFR-THRSHD-AMT.
           MOVE RPOL-AFR-THRSHD-PERI-CD
                                      TO MIR-AFR-THRSHD-PERI-CD.
008455*    MOVE RPOL-POL-TOT-AFR-AMT     TO WS-HOLD-S9-2.
008455*    MOVE WS-HOLD-S9-2             TO MIR-POL-TOT-AFR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-TOT-AFR-AMT * 100.
020874     MOVE RPOL-POL-TOT-AFR-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-TOT-AFR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-TOT-AFR-AMT.
008455
           MOVE RPOL-POL-AFR-ALLOC-CD TO MIR-POL-AFR-ALLOC-CD.

           MOVE RPOL-FREE-WTHDR-CD    TO MIR-FREE-WTHDR-CD.
           MOVE RPOL-FREE-WTHDR-PERI-CD
                                      TO MIR-FREE-WTHDR-PERI-CD.
           MOVE RPOL-FREE-WTHDR-QTY   TO WS-HOLD-2-0.
           MOVE WS-HOLD-2-0           TO MIR-FREE-WTHDR-QTY.
008455*    MOVE RPOL-FREE-WTHDR-TOT-AMT  TO WS-HOLD-S8-2.
008455*    MOVE WS-HOLD-S8-2             TO MIR-FREE-WTHDR-TOT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-FREE-WTHDR-TOT-AMT * 100.
020874     MOVE RPOL-FREE-WTHDR-TOT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-FREE-WTHDR-TOT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-FREE-WTHDR-TOT-AMT.
557659*    MOVE RPOL-PREV-RESET-YR-QTY   TO MIR-POL-PREV-RESET-YR.
557659     MOVE RPOL-POL-PREV-RESET-YR         TO MIR-POL-PREV-RESET-YR.

010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

016109     MOVE RPOL-POL-FREE-XFER-CD    TO MIR-POL-FREE-XFER-CD.
016109     MOVE RPOL-FREE-XFER-PERI-CD   TO MIR-FREE-XFER-PERI-CD.
016109     MOVE RPOL-POL-FREE-XFER-QTY   TO WS-HOLD-2-0.
016109     MOVE WS-HOLD-2-0              TO MIR-POL-FREE-XFER-QTY.
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-FREE-XFER-TOT-AMT * 100.
020874     MOVE RPOL-FREE-XFER-TOT-AMT   TO L0290-INPUT-V02.
016109     MOVE 2                        TO L0290-PRECISION.
016109     MOVE LENGTH OF MIR-FREE-XFER-TOT-AMT
016109                                   TO L0290-MAX-OUT-LEN.
016109     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016109     MOVE L0290-OUTPUT-DATA        TO MIR-FREE-XFER-TOT-AMT.
018845     MOVE RPOL-POL-SHRT-CALC-CD    TO MIR-POL-SHRT-CALC-CD.
020452
020452     MOVE RPOL-POL-FRGN-TST-DT      TO L1640-INTERNAL-DATE.
020452     PERFORM  1640-8000-INTERNAL-TO-MIR
020452         THRU 1640-8000-INTERNAL-TO-MIR-X.
020452     IF L1640-VALID
020452         MOVE L1640-EXTERNAL-DATE    TO MIR-POL-FRGN-TST-DT
020452     ELSE
020452         MOVE SPACES                 TO MIR-POL-FRGN-TST-DT
020452     END-IF.
020452

021239     MOVE RPOL-POL-UNIT-TYP-CD       TO MIR-POL-UNIT-TYP-CD.

020455     MOVE RPOL-POL-UNDO-EFF-DT       TO L1640-INTERNAL-DATE.
020455     PERFORM  1640-8000-INTERNAL-TO-MIR
020455         THRU 1640-8000-INTERNAL-TO-MIR-X.
020455     IF  L1640-VALID
020455         MOVE L1640-EXTERNAL-DATE
020455                                TO MIR-POL-UNDO-EFF-DT
020455     ELSE
020455         MOVE SPACES            TO MIR-POL-UNDO-EFF-DT
020455     END-IF.
020455

026057     MOVE RPOL-POL-INV-HIST-DT  TO L1640-INTERNAL-DATE.
026057     PERFORM 1640-8000-INTERNAL-TO-MIR
026057        THRU 1640-8000-INTERNAL-TO-MIR-X.
026057     IF  L1640-VALID
026057         MOVE L1640-EXTERNAL-DATE
026057                                TO MIR-POL-INV-HIST-DT
026057     ELSE
026057         MOVE SPACES            TO MIR-POL-INV-HIST-DT
026057     END-IF.

       8000-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-DV-OWN-CLI-NM.
           MOVE SPACES                TO MIR-POL-CSTAT-CD.

      *
           MOVE SPACES                TO MIR-POL-PD-TO-DT-NUM.
           MOVE SPACES                TO MIR-POL-CSTAT-CD.
           MOVE SPACES                TO MIR-POL-TOT-BILL-AMT.
           MOVE SPACES                TO MIR-PREV-PD-TO-DT-NUM.
           MOVE SPACES                TO MIR-POL-PREV-MODE-CD.
           MOVE SPACES                TO MIR-PREV-BILL-TYP-CD.
           MOVE SPACES                TO MIR-POL-PREV-MODE-FCT.
           MOVE SPACES                TO MIR-POL-PREV-PFEE-FCT.
           MOVE SPACES                TO MIR-POL-BASE-CVG-NUM.
           MOVE SPACES                TO MIR-POL-PAR-CVG-NUM.
           MOVE SPACES                TO MIR-XHBT-ISS-LOC-CD.
           MOVE SPACES                TO MIR-XHBT-CRNT-LOC-CD.
           MOVE SPACES                TO MIR-UL-LAPS-NOTI-AMT.
016395*    MOVE SPACES                TO MIR-POL-PAC-DRW-DT.
016395     MOVE SPACES                TO MIR-POL-PMT-DRW-DT.
           MOVE SPACES                TO MIR-POL-PREV-FACE-AMT.
           MOVE SPACES                TO MIR-DIV-DCLR-LTD-AMT.
           MOVE SPACES                TO MIR-POL-GL-ACCT-TYP-CD.
           MOVE SPACES                TO MIR-POL-ACCT-PAR-CD.
012181*    MOVE SPACES                TO MIR-DIV-DCLR-YTD-AMT.
012181     MOVE SPACES                TO MIR-DIV-DCLR-DUR-AMT.
           MOVE SPACES                TO MIR-POL-DOD-ACUM-AMT.
           MOVE SPACES                TO MIR-POL-DOD-AVB-AMT.
           MOVE SPACES                TO MIR-POL-DOD-INT-RT.
           MOVE SPACES                TO MIR-DOD-CRNT-INT-AMT.
           MOVE SPACES                TO MIR-POL-PREV-DIV-DUR.
           MOVE SPACES                TO MIR-PUA-LTD-FACE-AMT.
           MOVE SPACES                TO MIR-PUA-YTD-FACE-AMT.
           MOVE SPACES                TO MIR-POL-OYT-AMT.
           MOVE SPACES                TO MIR-LOAN-AMT-T(1).
018842*    MOVE SPACES                TO MIR-LOAN-INT-RT-T(1).
018842     MOVE SPACES                TO MIR-LOAN-INT-PCT-T(1).
018842*    MOVE SPACES                TO MIR-LOAN-INT-MAX-RT-T(1).
018842     MOVE SPACES                TO MIR-LOAN-INT-MAX-PCT-T(1).
           MOVE SPACES                TO MIR-LOAN-INT-BILL-AMT-T(1).
           MOVE SPACES                TO MIR-LOAN-INT-YTD-AMT-T(1).
           MOVE SPACES                TO MIR-LOAN-AVB-AMT-T(1).
           MOVE SPACES                TO MIR-LOAN-INT-TYP-CD-T(1).
           MOVE SPACES                TO MIR-LOAN-DT-T(1).
010397     MOVE SPACES                TO MIR-LOAN-ANNV-AMT-T(1).
010397     MOVE SPACES                TO MIR-LOAN-PREV-ANNV-AMT-T(1).
           MOVE SPACES                TO MIR-LOAN-AMT-T(2).
018842*    MOVE SPACES                TO MIR-LOAN-INT-RT-T(2).
018842     MOVE SPACES                TO MIR-LOAN-INT-PCT-T(2).
018842*    MOVE SPACES                TO MIR-LOAN-INT-MAX-RT-T(2).
018842     MOVE SPACES                TO MIR-LOAN-INT-MAX-PCT-T(2).
           MOVE SPACES                TO MIR-LOAN-INT-BILL-AMT-T(2).
           MOVE SPACES                TO MIR-LOAN-INT-YTD-AMT-T(2).
           MOVE SPACES                TO MIR-LOAN-AVB-AMT-T(2).
           MOVE SPACES                TO MIR-LOAN-INT-TYP-CD-T(2).
           MOVE SPACES                TO MIR-LOAN-DT-T(2).
010397     MOVE SPACES                TO MIR-LOAN-ANNV-AMT-T(2).
010397     MOVE SPACES                TO MIR-LOAN-PREV-ANNV-AMT-T(2).
           MOVE SPACES                TO MIR-LOAN-AMT-T(3).
018842*    MOVE SPACES                TO MIR-LOAN-INT-RT-T(3).
018842     MOVE SPACES                TO MIR-LOAN-INT-PCT-T(3).
018842*    MOVE SPACES                TO MIR-LOAN-INT-MAX-RT-T(3).
018842     MOVE SPACES                TO MIR-LOAN-INT-MAX-PCT-T(3).
           MOVE SPACES                TO MIR-LOAN-INT-BILL-AMT-T(3).
           MOVE SPACES                TO MIR-LOAN-INT-YTD-AMT-T(3).
           MOVE SPACES                TO MIR-LOAN-AVB-AMT-T(3).
           MOVE SPACES                TO MIR-LOAN-INT-TYP-CD-T(3).
           MOVE SPACES                TO MIR-LOAN-DT-T(3).
010397     MOVE SPACES                TO MIR-LOAN-ANNV-AMT-T(3).
010397     MOVE SPACES                TO MIR-LOAN-PREV-ANNV-AMT-T(3).
           MOVE SPACES                TO MIR-POL-PDF-AMT.
           MOVE SPACES                TO MIR-POL-PDF-INT-AMT.
           MOVE SPACES                TO MIR-POL-PDF-INT-RT.
           MOVE SPACES                TO MIR-POL-PDF-AVB-AMT.
           MOVE SPACES                TO MIR-POL-PREV-ANNV-DUR.
           MOVE SPACES                TO MIR-SURR-DIV-ACUM-AMT.
           MOVE SPACES                TO MIR-POL-SURR-LOAN-AMT.
           MOVE SPACES                TO MIR-POL-TRMN-PUA-AMT.
           MOVE SPACES                TO MIR-TRMN-PUA-REASN-CD.
           MOVE SPACES                TO MIR-POL-MISC-SUSP-AMT.
           MOVE SPACES                TO MIR-POL-MISC-SUSP-DT.
           MOVE SPACES                TO MIR-POL-PREM-SUSP-AMT.
           MOVE SPACES                TO MIR-POL-PREM-SUSP-DT.
           MOVE SPACES                TO MIR-POL-DIV-SUSP-AMT.
           MOVE SPACES                TO MIR-POL-OS-DISB-AMT.
           MOVE SPACES                TO MIR-POL-OS-DISB-DT.
557697     MOVE SPACES                TO MIR-SFB-NEG-SUSP-IND.
557697     MOVE SPACES                TO MIR-SFB-NEG-SUSP-QTY.
557697     MOVE SPACES                TO MIR-SFB-NXT-BILL-AMT.
           MOVE SPACES                TO MIR-POL-REG-TOT-AMT.
           MOVE SPACES                TO MIR-REG-CNTRB-1-AMT-G.
           MOVE SPACES                TO MIR-REG-CNTRB-2-AMT-G.
           MOVE SPACES                TO MIR-REG-RECPT-1-AMT-G.
           MOVE SPACES                TO MIR-REG-RECPT-2-AMT-G.
           MOVE SPACES                TO MIR-REG-CNTRB-SPCL-AMT-G.
           MOVE SPACES                TO MIR-POL-RRIF-MNPMT-AMT.
           MOVE SPACES                TO MIR-CASL-PMT-YTD-AMT.
           MOVE SPACES                TO MIR-POL-ANPAYO-YTD-AMT.
           MOVE SPACES                TO MIR-POL-ANPAYO-LTD-AMT.
           MOVE SPACES                TO MIR-POL-ANTY-SUSP-AMT.
           MOVE SPACES                TO MIR-POL-ANPAYO-PMT-DT.
           MOVE SPACES                TO MIR-REG-CNTRB-RECPT-DT.
           MOVE SPACES                TO MIR-REG-CNTRB-XFER-DT.
           MOVE SPACES                TO MIR-RRIF-MNPMT-PYR-AMT.
           MOVE SPACES                TO MIR-POL-LIF-MXPMT-AMT.
           MOVE SPACES                TO MIR-LIF-MXPMT-PYR-AMT.
           MOVE SPACES                TO MIR-CASL-PMT-PYR-AMT.
           MOVE SPACES                TO MIR-POL-ANPAYO-PYR-AMT.
           MOVE SPACES                TO MIR-POL-LOCK-FND-IND.
           MOVE SPACES                TO MIR-POL-CRNT-PSUR-AMT.
           MOVE SPACES                TO MIR-POL-PREV-PSUR-AMT.
           MOVE SPACES                TO MIR-POL-AFR-THRSHD-AMT.
           MOVE SPACES                TO MIR-AFR-THRSHD-PERI-CD.
           MOVE SPACES                TO MIR-POL-TOT-AFR-AMT.
           MOVE SPACES                TO MIR-POL-AFR-ALLOC-CD.
           MOVE SPACES                TO MIR-FREE-WTHDR-CD.
           MOVE SPACES                TO MIR-FREE-WTHDR-PERI-CD.
           MOVE SPACES                TO MIR-FREE-WTHDR-QTY.
           MOVE SPACES                TO MIR-FREE-WTHDR-TOT-AMT.
           MOVE SPACES                TO MIR-POL-PREV-RESET-YR.
016109     MOVE SPACES                TO MIR-POL-FREE-XFER-CD.
016109     MOVE SPACES                TO MIR-FREE-XFER-PERI-CD.
016109     MOVE SPACES                TO MIR-POL-FREE-XFER-QTY.
016109     MOVE SPACES                TO MIR-FREE-XFER-TOT-AMT.
018845     MOVE SPACES                TO MIR-POL-SHRT-CALC-CD.
021239     MOVE SPACES                TO MIR-POL-UNIT-TYP-CD.
026057     MOVE SPACES                TO MIR-POL-INV-HIST-DT.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY       TO TRUE.
           MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2520-0000-INIT-PARM-INFO
025970         THRU 2520-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2530-0000-INIT-PARM-INFO
025970         THRU 2530-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-UPDT-POLL-SW.
025970     INITIALIZE NUMERIC-HOLD-FIELDS.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO. 
025970
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET CV-DATE-DEFAULT             TO TRUE.
025970     SET  NO-UPDATE                  TO TRUE.
025970     SET  WS-REGC-OWNER-NO-UPDT      TO TRUE.
025970     SET  WS-REGC-SPOU-NO-UPDT       TO TRUE.
025970     SET  WS-SFB-NO-UPDT             TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     MOVE SPACES                     TO WWKDT-WORK-FIELDS.
025970   
025970     PERFORM 9992-INIT-WORKING-ARRAY
025970        THRU 9992-INIT-WORKING-ARRAY-X
025970        VARYING WS-SUB FROM 1 BY 1
025970        UNTIL WS-SUB > 2.
025970
025970     MOVE ZERO                       TO WS-SUB.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
025970
025970*----------------------------
025970 9992-INIT-WORKING-ARRAY.
025970*----------------------------
025970
025970     MOVE ZEROS              TO WS-REG-CNTRB-1-AMT    (WS-SUB).
025970     MOVE ZEROS              TO WS-REG-CNTRB-2-AMT    (WS-SUB).
025970     MOVE ZEROS              TO WS-REG-RECPT-1-AMT    (WS-SUB). 
025970     MOVE ZEROS              TO WS-REG-RECPT-2-AMT    (WS-SUB). 
025970     MOVE ZEROS              TO WS-REG-CNTRB-SPCL-AMT (WS-SUB).
025970
025970     MOVE SPACES             TO WS-REG-CNTRB-RECPT-DT (WS-SUB).
025970     MOVE SPACES             TO WS-REG-CNTRB-XFER-DT  (WS-SUB).
025970
025970 9992-INIT-WORKING-ARRAY-X.
025970     EXIT.
025970
      *
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
025970 COPY XCPS0280.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0280.
      *
008455 COPY XCPS0290.
008455 COPY XCPL0290.
      *
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
020074*COPY CCPESTCD.
      *
       COPY CCPEMETH.
021239
021239 COPY CCPEUVTP.
      *
016537*COPY CCPNEDIT.
021239 COPY CCPNEDIT.
      *
       COPY CCPNPOL.
       COPY CCPUPOL.
      *
016503 COPY CCPNCVG.
      *
       COPY CCPCPOLL.
       COPY CCPNPOLL.
       COPY CCPAPOLL.
       COPY CCPUPOLL.
      *
006002 COPY XCPNCTLC.
006002*
006002*COPY CCPEILOC.
      *
006002*COPY CCPECLOC.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      *
016503 COPY NCPPCVGS.
      *
014660*COPY XCPPMEXT.
      *
018764*COPY CCCLPOL.
018764 COPY CCPLPOL.
018764*COPY CCCLPOLL.
018764 COPY CCPLPOLL.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
       COPY CCPS2430.
      *
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
      *
557697 COPY CCPS2520.
018764*COPY CCCL2520.
018764 COPY CCPL2520.
      *
557788 COPY CCPS2530.
018764*COPY CCCL2530.
018764 COPY CCPL2530.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
018764*COPY XCCL8090.
018764 COPY XCPL8090.
020074*
020074 COPY XCPS8960.
020074 COPY XCPL8960.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM0151                     **
      *****************************************************************
