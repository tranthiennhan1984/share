      *****************************************************************
      **  MEMBER :  CSOM3350                                         **
      **  REMARKS:  AGNB - AGENT BALANCE PROCESS DRIVER              **
      **            THIS PROGRAM WILL VALIDATE AND MAINTAIN THE      **
      **            WRITING AND SERVICING AGENTS FOR BUSINESS        **
      **            APPLICATIONS.                                    **
      **                                                             **
      **  DOMAIN :  AG                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010418**  5.6       INITIAL CREATION                                 **
012148**  5.6V      TRAIL COMMISSION PROCESSING                      **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
027250**  6.6       AGENT BALANCE INQUIRY SCROLL FUNCTION            **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       IDENTIFICATION DIVISION.

       PROGRAM-ID.    CSOM3350.

       COPY XCWWCRHT.

      **********************
       ENVIRONMENT DIVISION.
      **********************
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3350'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '0860'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '0860'.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(04) BINARY SYNC
025970                                      VALUE +12.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT
025970                                      VALUE +12.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT    VALUE 'AGNB'.
025970*01  WS-PGM-IDENTIFIER.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'AGNB'.
      *
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUES '0860' '0861' '0862'
                                                   '0863' '0864'.
               88  WS-BUS-FCN-RETRIEVE      VALUE  '0860'.
               88  WS-BUS-FCN-CREATE        VALUE  '0861'.
               88  WS-BUS-FCN-UPDATE        VALUE  '0862'.
               88  WS-BUS-FCN-DELETE        VALUE  '0863'.
               88  WS-BUS-FCN-LIST          VALUE  '0864'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '0860'.
016548*    05  WS-LINES-ON-SCREEN           PIC S9(04) COMP SYNC.
016548     05  WS-LINES-ON-SCREEN           PIC S9(04) BINARY SYNC.
016548*    05  WS-SUB                       PIC S9(04) COMP SYNC.
016548     05  WS-SUB                       PIC S9(04) BINARY SYNC.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(04) COMP SYNC
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(04) BINARY SYNC
025970*                                     VALUE +12.
           05  WS-COMPRESSED-NAME           PIC X(51)  VALUE SPACES.
           05  WS-SCREEN-NUM-ALPHA          PIC X(02).
           05  WS-SCREEN-NUM-NUMERIC
               REDEFINES WS-SCREEN-NUM-ALPHA PIC 9(02).
           05  WS-AGENT-RL-FOUND-SW         PIC X(01) VALUE 'N'.
               88  WS-AGENT-RL-FOUND        VALUE 'Y'.
025970         88  WS-AGENT-RL-FOUND-NO     VALUE 'N'.
023514     05  WS-MOS-ABBR-TXT              PIC X(36).
023514     05  WS-MOS-ABBR-TXT-R            REDEFINES
023514         WS-MOS-ABBR-TXT.
023514         10  WS-MOS-ABBR              PIC X(03) OCCURS 12.
023514     05  WS-MOS-ABBR-IDX              PIC 9(02).
023514     05  WS-WORK-YEAR                 PIC 9(04).
023514     05  WS-WORK-MONTH                PIC 9(02).
023514 COPY XCWLCOMM REPLACING '$VAR1' BY '0860'.
023514         15  LCOMM-FWD-YR             PIC 9(4).
023514         15  LCOMM-FWD-MO             PIC 9(2).
023514         15  LCOMM-BWD-YR             PIC 9(4).
023514         15  LCOMM-BWD-MO             PIC 9(2).
023514         15  LCOMM-FYR-COMM-AMT       PIC S9(11)V99 COMP-3.
023514         15  LCOMM-RENW-COMM-AMT      PIC S9(11)V99 COMP-3.
      *
       01  WS-EDIT-CHECKS.
           05  WS-ERROR-SW                  PIC X(01).
               88  ERROR-FOUND              VALUE 'Y'.
               88  NO-ERRORS-FOUND          VALUE 'N'.

      *    WORK AREA TO STORE THE 'R' AND 'M' AGENT CLIENT RELATIONSHIPS
       01  WS-AGNT-CLI-REL-GR.
           05  WS-MAIL-CLIENT-READ          PIC X(01).
               88  MAIL-CLIENT-READ         VALUE 'Y'.
               88  MAIL-CLIENT-NOT-READ     VALUE 'N'.
           05  WS-MAIL-CLIENT.
               10  WS-MAIL-CLI-ID           PIC X(10).
               10  WS-MAIL-ADDR-TYP-CD      PIC X(02).
               10  WS-MAIL-BNK-ACCT-NUM     PIC S9(03) COMP-3.
           05  WS-RES-CLIENT-READ           PIC X(01).
               88  RES-CLIENT-READ          VALUE 'Y'.
               88  RES-CLIENT-NOT-READ      VALUE 'N'.
           05  WS-RES-CLIENT.
               10  WS-RES-CLI-ID            PIC X(10).
               10  WS-RES-ADDR-TYP-CD       PIC X(02).
               10  WS-RES-BNK-ACCT-NUM      PIC S9(03) COMP-3.


       01  OTHER-MISC-WORK-AREAS.

           05  WS-EDIT-2                       PIC 999.99.
           05  WS-EDIT-8                       PIC 9.
      *
      *
016537*COPY CCWL2440.
      *
       COPY CCFWAG.
       COPY CCFRAG.
      *
016537*COPY CCFRBRCH.
016537*COPY CCFWBRCH.
      *
       COPY CCFWAB.
       COPY CCFRAB.
      *
021930*COPY CCFWAS.
021930*COPY CCFRAS.
      *
021930*COPY CCFWCC.
021930*COPY CCFRCC.
      *
021930*COPY CCFWRL.
021930*COPY CCFRRL.
      *
016537*COPY CCFWEDIT.
016537*COPY CCFREDIT.
      *
       COPY CCFWSCOM.
       COPY CCFRSCOM.
      *
016537*COPY XCFWCRCY.
016537*COPY XCFRCRCY.
      *
021930*COPY CCFWCLIN.
021930*COPY CCFRCLIB.
      *
       COPY XCWEBLCH.
      *
       COPY CCWL2435.
023514*
023514 COPY CCWL2455.
      *
       COPY CCWL0840.
      *
       COPY CCWL0620.
      *
       COPY XCWL0280.
      *
       COPY XCWL0290.
      *
021930*COPY XCWLDTLK.
021930*COPY XCWL1640.
      *
013578*COPY CCWCCOMM.
      *
018764*COPY XCWLPTR.
      *
014035*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
014221 COPY XCWL8090.

      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3350.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

023514     PERFORM  COMM-1000-INITIALIZE
023514         THRU COMM-1000-INITIALIZE-X.
023514
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

            PERFORM 0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    MOVE 'N'                   TO WS-ERROR-SW.
025970*    MOVE WGLOB-MOS-ABBR-TXT    TO WS-MOS-ABBR-TXT.


           IF NOT WS-BUS-FCN-LIST
               PERFORM 2200-VERIFY-AGENT-RECORDS
                  THRU 2200-VERIFY-AGENT-RECORDS-X
           END-IF.

           IF  ERROR-FOUND
               PERFORM  2400-CLEAR-SCREEN-VALUES
                   THRU 2400-CLEAR-SCREEN-VALUES-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE
              WHEN  WS-BUS-FCN-RETRIEVE
                 PERFORM  3000-PROCESS-INQUIRE
                    THRU  3000-PROCESS-INQUIRE-X

              WHEN  WS-BUS-FCN-LIST
                 PERFORM  3500-PROCESS-LIST
                    THRU  3500-PROCESS-LIST-X

              WHEN  WS-BUS-FCN-CREATE
                 PERFORM  4000-PROCESS-CREATE
                    THRU  4000-PROCESS-CREATE-X

              WHEN  WS-BUS-FCN-UPDATE
                 PERFORM  5000-PROCESS-UPDATE
                    THRU  5000-PROCESS-UPDATE-X

              WHEN  WS-BUS-FCN-DELETE
                 PERFORM  6000-PROCESS-DELETE
                    THRU  6000-PROCESS-DELETE-X

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *--------------------------
       2200-VERIFY-AGENT-RECORDS.
      *--------------------------
           MOVE MIR-AGT-ID            TO WAG-AGT-ID.
           MOVE MIR-AGT-ID            TO WAB-AGT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WAB-SBSDRY-CO-ID.

           PERFORM  AG-1000-READ
               THRU AG-1000-READ-X.

           PERFORM  AB-1000-READ
               THRU AB-1000-READ-X.

           IF  WS-BUS-FCN-CREATE
           AND NOT WAG-IO-OK
               MOVE 'XS00000064'      TO WGLOB-MSG-REF-INFO
               MOVE WAG-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'Y'               TO WS-ERROR-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  WS-BUS-FCN-CREATE
               AND WAB-IO-OK
                   MOVE 'CS33500001'  TO WGLOB-MSG-REF-INFO
                   MOVE 'Y'           TO WS-ERROR-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  (NOT WS-BUS-FCN-CREATE)
           AND (NOT WAG-IO-OK)
               MOVE 'XS00000064'      TO WGLOB-MSG-REF-INFO
               MOVE WAG-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'Y'               TO WS-ERROR-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  (NOT WS-BUS-FCN-CREATE)
               AND (NOT WAB-IO-OK)
                   MOVE 'CS33500002'  TO WGLOB-MSG-REF-INFO
                   MOVE WAB-KEY       TO WGLOB-MSG-PARM (1)
                   MOVE 'Y'           TO WS-ERROR-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2200-VERIFY-AGENT-RECORDS-X.
           EXIT.
      *
      *-------------------------
       2400-CLEAR-SCREEN-VALUES.
      *-------------------------

           MOVE SPACES                TO  MIR-AGT-ID-G.
           MOVE SPACES                TO  MIR-DV-COMM-AGT-NM-G.
           MOVE SPACES                TO  MIR-SBSDRY-CO-ID-G.
           MOVE SPACES                TO  MIR-AGT-PAYBL-BAL-AMT-G.
      *  SCREEN 02
023514*    MOVE SPACES                TO  MIR-FYR-COMM-CMO-AMT.
023514     MOVE SPACES                TO  MIR-FYR-COMM-AMT.
           MOVE SPACES                TO  MIR-FYR-COMM-YTD-AMT.
023514*    MOVE SPACES                TO  MIR-RENW-COMM-CMO-AMT.
023514     MOVE SPACES                TO  MIR-RENW-COMM-AMT.
012148     MOVE SPACES                TO  MIR-TRAIL-COMM-CMO-AMT.
           MOVE SPACES                TO  MIR-RENW-COMM-YTD-AMT.
012148     MOVE SPACES                TO  MIR-TRAIL-COMM-YTD-AMT.
           MOVE SPACES                TO  MIR-OVRID-COMM-CMO-AMT.
           MOVE SPACES                TO  MIR-OVRID-COMM-YTD-AMT.
           MOVE SPACES                TO  MIR-AGT-PAYO-CMO-AMT.
           MOVE SPACES                TO  MIR-AGT-PAYO-YTD-AMT.
           MOVE SPACES                TO  MIR-AGT-PAYBL-BAL-AMT.
      *  SCREEN 03
023118*    MOVE SPACES                TO  MIR-FYR-COMM-12-AMT-G.
023118*    MOVE SPACES                TO  MIR-RENW-COMM-12-AMT-G.
023118     MOVE SPACES                TO  MIR-FYR-COMM-AMT-G.
023118     MOVE SPACES                TO  MIR-RENW-COMM-AMT-G.
      *  SCREEN 04
           MOVE SPACES                TO  MIR-AGT-PRST-4-PCT-G.
           MOVE SPACES                TO  MIR-AGT-PROD-4-AMT-G.
           MOVE SPACES                TO  MIR-AGT-MDRT-4-AMT-G.
           MOVE SPACES                TO  MIR-CNVTN-ATND-4-IND-G.
           MOVE SPACES                TO  MIR-APTVTY-AWD-4-IND-G.
           MOVE SPACES                TO  MIR-NQA-4-IND-G.
023514     MOVE SPACES                TO  MIR-DV-BCKWRD-SCROLL-IND.
023514     MOVE SPACES                TO  MIR-AGT-COMM-YR-G.
023514     MOVE SPACES                TO  MIR-AGT-COMM-MO-G.

       2400-CLEAR-SCREEN-VALUES-X.
           EXIT.
      *
      *-------------------
       3000-PROCESS-INQUIRE.
      *-------------------

014221     MOVE RAG-AGT-ID            TO WAG-AGT-ID.
014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.
014221
           PERFORM 3200-GET-AGENT-NAME
              THRU 3200-GET-AGENT-NAME-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-COMM-AGT-NM.
           MOVE RAG-BR-ID             TO MIR-BR-ID.

023514     PERFORM  COMM-1000-RETRIEVE-TWRK
023514         THRU COMM-1000-RETRIEVE-TWRK-X.
023514
023514     PERFORM  2455-0000-INIT-PARM-INFO
023514         THRU 2455-0000-INIT-PARM-INFO-X.
023514
023514     IF  MIR-DV-BCKWRD-SCROLL-IND = SPACE
023514         MOVE RAB-CO-ID            TO L2455-CO-ID
023514         MOVE RAB-AGT-ID           TO L2455-AGT-ID
023514         MOVE RAB-SBSDRY-CO-ID     TO L2455-SBSDRY-CO-ID
023514
023514         MOVE WGLOB-PROCESS-DATE-YR
023514                                   TO L2455-PRCES-YR
023514         MOVE WGLOB-PROCESS-DATE-MO
023514                                   TO L2455-PRCES-MO
023514
023514         PERFORM  2455-2000-GET-AGT-BALANCE
023514             THRU 2455-2000-GET-AGT-BALANCE-X
023514         MOVE L2455-AGT-BAL-FYR-COMM-AMT (1)
023514                                   TO LCOMM-FYR-COMM-AMT
023514         MOVE L2455-AGT-BAL-RENW-COMM-AMT (1)
023514                                   TO LCOMM-RENW-COMM-AMT
023514         MOVE WGLOB-PROCESS-DATE-YR
023514                                   TO LCOMM-FWD-YR
023514         MOVE WGLOB-PROCESS-DATE-MO
023514                                   TO LCOMM-FWD-MO
023514     END-IF.
023514
023514     MOVE RAB-CO-ID                TO L2455-CO-ID.
023514     MOVE RAB-AGT-ID               TO L2455-AGT-ID.
023514     MOVE RAB-SBSDRY-CO-ID         TO L2455-SBSDRY-CO-ID.
023514
023514     EVALUATE TRUE
023514         WHEN MIR-DV-BCKWRD-SCROLL-IND = SPACE
023514             PERFORM  3010-NEXT-FWD-MONTH
023514                 THRU 3010-NEXT-FWD-MONTH-X
023514
023514             PERFORM  2455-1000-GET-AGT-HISTORY
023514                 THRU 2455-1000-GET-AGT-HISTORY-X
023514
023514             IF  NOT L2455-MORE-DATA-EXISTS
023514                 MOVE ZERO         TO LCOMM-BWD-YR
023514                 MOVE ZERO         TO LCOMM-BWD-MO
023514             ELSE
023514                 MOVE L2455-AGT-BAL-YR (12)
023514                                   TO LCOMM-FWD-YR
023514                 MOVE L2455-AGT-BAL-MO (12)
023514                                   TO LCOMM-FWD-MO
027250*                MOVE L2455-AGT-BAL-YR (13)
027250                 MOVE L2455-AGT-BAL-YR (12)
023514                                   TO LCOMM-BWD-YR
027250*                MOVE L2455-AGT-BAL-MO (13)
027250                 MOVE L2455-AGT-BAL-MO (12)
023514                                   TO LCOMM-BWD-MO
027250                 SUBTRACT 1      FROM LCOMM-BWD-MO
027250                 IF LCOMM-BWD-MO = ZERO
027250                    MOVE 12        TO LCOMM-BWD-MO
027250                    SUBTRACT 1   FROM LCOMM-BWD-YR
027250                 END-IF
023514             END-IF
023514
023514         WHEN MIR-DV-BCKWRD-SCROLL-IND = 'Y'
023514             IF  LCOMM-BWD-YR = ZERO
023514             OR  LCOMM-BWD-MO = ZERO
023514                 MOVE 'N'          TO MIR-DV-BCKWRD-SCROLL-IND
023514                 PERFORM  3010-NEXT-FWD-MONTH
023514                     THRU 3010-NEXT-FWD-MONTH-X
023514                 PERFORM  2455-1000-GET-AGT-HISTORY
023514                     THRU 2455-1000-GET-AGT-HISTORY-X
023514
023514             ELSE
023514                 PERFORM  3020-NEXT-BWD-MONTH
023514                     THRU 3020-NEXT-BWD-MONTH-X
023514                 SET  L2455-READ-DIR-BWD
023514                                   TO TRUE
023514                 PERFORM  2455-1000-GET-AGT-HISTORY
023514                     THRU 2455-1000-GET-AGT-HISTORY-X
023514
023514                 MOVE L2455-AGT-BAL-YR (12)
023514                                   TO LCOMM-FWD-YR
023514                 MOVE L2455-AGT-BAL-MO (12)
023514                                   TO LCOMM-FWD-MO
023514                 IF  L2455-MORE-DATA-EXISTS
023514                     MOVE L2455-AGT-BAL-YR (1)
023514                                   TO LCOMM-BWD-YR
023514                     MOVE L2455-AGT-BAL-MO (1)
023514                                   TO LCOMM-BWD-MO
023514                 END-IF
023514             END-IF
023514
023514         WHEN MIR-DV-BCKWRD-SCROLL-IND = 'N'
023514             PERFORM  3010-NEXT-FWD-MONTH
023514                 THRU 3010-NEXT-FWD-MONTH-X
023514             PERFORM  2455-1000-GET-AGT-HISTORY
023514                 THRU 2455-1000-GET-AGT-HISTORY-X
023514             MOVE L2455-AGT-BAL-YR (1)
023514                                   TO LCOMM-BWD-YR
023514             MOVE L2455-AGT-BAL-MO (1)
023514                                   TO LCOMM-BWD-MO
023514
023514             IF  L2455-MORE-DATA-EXISTS
023514                 MOVE L2455-AGT-BAL-YR (12)
023514                                   TO LCOMM-FWD-YR
023514                 MOVE L2455-AGT-BAL-MO (12)
023514                                   TO LCOMM-FWD-MO
023514             END-IF
023514
023514     END-EVALUATE.
023514
027250*    IF  L2455-AGT-BAL-YR (1) = ZERO
027250*        MOVE WGLOB-PROCESS-DATE-YR
027250*                                  TO WS-WORK-YEAR
027250*        MOVE WGLOB-PROCESS-DATE-MO
027250*                                  TO WS-WORK-MONTH
027250*    ELSE
027250*        MOVE L2455-AGT-BAL-YR (1) TO WS-WORK-YEAR
027250*        MOVE L2455-AGT-BAL-MO (1) TO WS-WORK-MONTH
027250*    END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

023514     PERFORM  COMM-3000-DELETE-TWRK
023514         THRU COMM-3000-DELETE-TWRK-X.
023514     PERFORM  COMM-2000-WRITE-TWRK
023514         THRU COMM-2000-WRITE-TWRK-X.

       3000-PROCESS-INQUIRE-X.
           EXIT.
023514
023514*--------------------
023514 3010-NEXT-FWD-MONTH.
023514*--------------------
023514
023514     MOVE LCOMM-FWD-YR           TO   L2455-PRCES-YR
023514     MOVE LCOMM-FWD-MO           TO   L2455-PRCES-MO
023514     SUBTRACT 1                  FROM L2455-PRCES-MO
023514     IF  L2455-PRCES-MO <= ZERO
023514         MOVE 12                 TO   L2455-PRCES-MO
023514         SUBTRACT 1              FROM L2455-PRCES-YR
023514     END-IF.
023514
023514 3010-NEXT-FWD-MONTH-X.
023514     EXIT.
023514
023514*--------------------
023514 3020-NEXT-BWD-MONTH.
023514*--------------------
023514
023514     MOVE LCOMM-BWD-YR           TO   L2455-PRCES-YR
023514     MOVE LCOMM-BWD-MO           TO   L2455-PRCES-MO
023514     ADD 1                       TO   L2455-PRCES-MO
023514     IF  L2455-PRCES-MO > 12
023514         MOVE 1                  TO   L2455-PRCES-MO
023514         ADD  1                  TO   L2455-PRCES-YR
023514     END-IF.
023514
023514 3020-NEXT-BWD-MONTH-X.
023514     EXIT.
      *
      *--------------------
       3200-GET-AGENT-NAME.
      *--------------------

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           PERFORM  7100-GET-AGT-RELATIONSHIPS
               THRU 7100-GET-AGT-RELATIONSHIPS-X.

           IF  WS-RES-CLI-ID = SPACES
               MOVE SPACES            TO L0620-SCREEN-NAME
               GO TO 3200-GET-AGENT-NAME-X
           END-IF.

           MOVE WS-RES-CLI-ID         TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  L2435-RETRN-OK
               PERFORM  7300-GET-STD-FMT-CLI-NAME
                   THRU 7300-GET-STD-FMT-CLI-NAME-X
           ELSE
               MOVE SPACES            TO L0620-SCREEN-NAME
           END-IF.

       3200-GET-AGENT-NAME-X.
           EXIT.
      *
      *--------------------
       3500-PROCESS-LIST.
      *--------------------

           MOVE SPACES                TO MIR-DV-COMM-AGT-NM-G.
           MOVE SPACES                TO MIR-SBSDRY-CO-ID-G.
           MOVE SPACES                TO MIR-AGT-PAYBL-BAL-AMT-G.

           MOVE LOW-VALUES            TO WAB-KEY.
           IF MIR-AGT-ID  = SPACES
               MOVE LOW-VALUES        TO WAB-KEY
               MOVE SPACES            TO MIR-AGT-ID-G
           ELSE
               MOVE MIR-AGT-ID        TO WAB-AGT-ID
               IF WGLOB-MSG-ERROR-SW > ZERO
                   MOVE MIR-AGT-ID-T (1)
                                      TO WAB-AGT-ID
               ELSE
                   MOVE SPACES        TO MIR-AGT-ID-G
               END-IF
           END-IF.
           MOVE HIGH-VALUES           TO WAB-ENDBR-KEY.

           IF  MIR-SBSDRY-CO-ID = SPACES
               CONTINUE
           ELSE
               MOVE MIR-SBSDRY-CO-ID  TO WAB-SBSDRY-CO-ID
               MOVE MIR-SBSDRY-CO-ID  TO WAB-ENDBR-SBSDRY-CO-ID
           END-IF.

           PERFORM  AB-1000-BROWSE
               THRU AB-1000-BROWSE-X.

           PERFORM  AB-2000-READ-NEXT
               THRU AB-2000-READ-NEXT-X.

           IF WAG-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               MOVE WAB-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  3510-PROCESS-LIST-READ
               THRU 3510-PROCESS-LIST-READ-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR    WAB-IO-EOF.

           IF WAB-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               MOVE WAB-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE MIR-AGT-ID-T (01) TO MIR-AGT-ID
           ELSE
               IF WGLOB-MSG-ERROR-SW = ZERO
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE RAB-AGT-ID    TO MIR-AGT-ID
                   MOVE RAB-SBSDRY-CO-ID
                                      TO MIR-SBSDRY-CO-ID
               END-IF
           END-IF.

           PERFORM  AB-3000-END-BROWSE
               THRU AB-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      *
      *-------------------------
       3510-PROCESS-LIST-READ.
      *-------------------------

           MOVE RAB-AGT-ID            TO  MIR-AGT-ID-T (WS-SUB).

           PERFORM  3200-GET-AGENT-NAME
               THRU 3200-GET-AGENT-NAME-X.

           MOVE L0620-SCREEN-NAME
             TO MIR-DV-COMM-AGT-NM-T (WS-SUB).
           MOVE RAB-SBSDRY-CO-ID      TO MIR-SBSDRY-CO-ID-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PAYBL-BAL-AMT * 100.
020874     MOVE RAB-AGT-PAYBL-BAL-AMT TO  L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-AGT-PAYBL-BAL-AMT-T (WS-SUB)
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY     TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA  TO  MIR-AGT-PAYBL-BAL-AMT-T (WS-SUB).

           PERFORM  AB-2000-READ-NEXT
               THRU AB-2000-READ-NEXT-X.

       3510-PROCESS-LIST-READ-X.
           EXIT.

      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      *
      ***  ENSURE THAT SUB-COMPANY CODE IS ON PSUB PROFILE
      *
           MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.

           PERFORM  SCOM-1000-READ
               THRU SCOM-1000-READ-X.

           IF NOT WSCOM-IO-OK
      *MSG : SUB-COMPANY MUST BE ON PSUB PROFILE
               MOVE 'CS33500031'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-ERROR-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  2400-CLEAR-SCREEN-VALUES
                   THRU 2400-CLEAR-SCREEN-VALUES-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  AB-1000-CREATE
               THRU AB-1000-CREATE-X.

           PERFORM  AB-1000-WRITE
               THRU AB-1000-WRITE-X.

014221     MOVE WAB-AGT-ID           TO WAG-AGT-ID.
014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.
014221
           PERFORM 3200-GET-AGENT-NAME
              THRU 3200-GET-AGENT-NAME-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-COMM-AGT-NM.
           MOVE RAG-BR-ID             TO MIR-BR-ID.

023514     INITIALIZE LCOMM-WORK-AREA.
023514     PERFORM  2455-0000-INIT-PARM-INFO
023514         THRU 2455-0000-INIT-PARM-INFO-X.
023514
023514     MOVE WGLOB-PROCESS-DATE-YR TO WS-WORK-YEAR.
023514     MOVE WGLOB-PROCESS-DATE-MO TO WS-WORK-MONTH.

027250     PERFORM
027250        VARYING WS-SUB FROM 1 BY 1
027250        UNTIL   WS-SUB > WS-MAX-BROWSE-LINES
027250
027250          MOVE WS-WORK-YEAR     TO L2455-AGT-BAL-YR (WS-SUB)
027250          MOVE WS-WORK-MONTH    TO L2455-AGT-BAL-MO (WS-SUB)
027250          SUBTRACT 1            FROM WS-WORK-MONTH
027250          IF  WS-WORK-MONTH <= ZERO
027250              MOVE 12           TO   WS-WORK-MONTH
027250              SUBTRACT 1        FROM WS-WORK-YEAR
027250          END-IF
027250     END-PERFORM.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'CS33500004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       4000-PROCESS-CREATE-X.
           EXIT.
      *
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

014221     MOVE MIR-AGT-ID           TO WAG-AGT-ID.
014221     PERFORM  AG-2000-UPDATE-TWRK-TS
014221         THRU AG-2000-UPDATE-TWRK-TS-X.
014221
014221     EVALUATE TRUE
014221
014221         WHEN WAG-IO-NOT-FOUND
014221*MSG: @2 RECORD (@1) NOT FOUND
014221              MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
014221              MOVE WAG-KEY           TO WGLOB-MSG-PARM (1)
014221              MOVE 'AG'              TO WGLOB-MSG-PARM (2)
014221              PERFORM  0260-1000-GENERATE-MESSAGE
014221                  THRU 0260-1000-GENERATE-MESSAGE-X
014221              GO TO 5000-PROCESS-UPDATE-X
014221
014221         WHEN MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MSIMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221              MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221              MOVE 'AG'              TO WGLOB-MSG-PARM (1)
014221              MOVE WAG-KEY           TO WGLOB-MSG-PARM (2)
014221              PERFORM  0260-1000-GENERATE-MESSAGE
014221                  THRU 0260-1000-GENERATE-MESSAGE-X
014221              GO TO 5000-PROCESS-UPDATE-X
014221
014221     END-EVALUATE.
014221
           MOVE MIR-AGT-ID            TO WAB-AGT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WAB-SBSDRY-CO-ID.

           PERFORM  AB-1000-READ-FOR-UPDATE
               THRU AB-1000-READ-FOR-UPDATE-X.

           IF  WAB-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS33500030'      TO WGLOB-MSG-REF-INFO
               MOVE WAB-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  AG-3000-UNLOCK
                   THRU AG-3000-UNLOCK-X
               PERFORM  2400-CLEAR-SCREEN-VALUES
                   THRU 2400-CLEAR-SCREEN-VALUES-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           MOVE  'N'                  TO  WS-ERROR-SW.

      ***  CLEAR THE TABLE OF ERROR NUMBERS WHICH ARE USED TO BUILD
      ***  THE SPECIFIC ERROR MESSAGES TO THE SCREEN

           PERFORM  5300-AGENT-FLD-MNT
               THRU 5300-AGENT-FLD-MNT-X.

           PERFORM  AB-2000-REWRITE
               THRU AB-2000-REWRITE-X.

014221     MOVE RAB-AGT-ID             TO WAG-AGT-ID.
014221     PERFORM  AG-2000-REWRITE
014221         THRU AG-2000-REWRITE-X.
014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.
014221

           IF  NO-ERRORS-FOUND
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      *
      *-------------------
       5300-AGENT-FLD-MNT.
      *-------------------

           PERFORM  3200-GET-AGENT-NAME
               THRU 3200-GET-AGENT-NAME-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-COMM-AGT-NM.
           MOVE WAB-AGT-ID            TO MIR-AGT-ID.
           MOVE WAB-SBSDRY-CO-ID      TO MIR-SBSDRY-CO-ID.
           MOVE WAB-AGT-ID            TO WAG-AGT-ID.

           PERFORM AG-1000-READ
              THRU AG-1000-READ-X.

           IF  WAG-IO-OK
               MOVE RAG-BR-ID         TO MIR-BR-ID
           END-IF.

           PERFORM  8500-EDIT-SCR-03
               THRU 8500-EDIT-SCR-03-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 4.

           PERFORM  8600-EDIT-SCR-04
               THRU 8600-EDIT-SCR-04-X.

       5300-AGENT-FLD-MNT-X.
           EXIT.
      *
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           MOVE 'N'                   TO WS-AGENT-RL-FOUND-SW.

           IF  RAB-AGT-PAYBL-BAL-AMT     NOT = 0
               MOVE 'CS33500003'      TO WGLOB-MSG-REF-INFO
               MOVE RAB-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

014221     MOVE MIR-AGT-ID           TO WAG-AGT-ID.
014221     PERFORM  AG-2000-UPDATE-TWRK-TS
014221         THRU AG-2000-UPDATE-TWRK-TS-X.
014221
014221     EVALUATE TRUE
014221
014221         WHEN WAG-IO-NOT-FOUND
014221*MSG: @2 RECORD (@1) NOT FOUND
014221              MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
014221              MOVE WAG-KEY           TO WGLOB-MSG-PARM (1)
014221              MOVE 'AG'              TO WGLOB-MSG-PARM (2)
014221              PERFORM  0260-1000-GENERATE-MESSAGE
014221                  THRU 0260-1000-GENERATE-MESSAGE-X
014221              GO TO 6000-PROCESS-DELETE-X
014221
014221         WHEN MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MSIMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221              MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221              MOVE 'AG'              TO WGLOB-MSG-PARM (1)
014221              MOVE WAG-KEY           TO WGLOB-MSG-PARM (2)
014221              PERFORM  0260-1000-GENERATE-MESSAGE
014221                  THRU 0260-1000-GENERATE-MESSAGE-X
014221              GO TO 6000-PROCESS-DELETE-X
014221
014221     END-EVALUATE.
014221

           PERFORM 3200-GET-AGENT-NAME
              THRU 3200-GET-AGENT-NAME-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-COMM-AGT-NM.
           MOVE RAG-BR-ID             TO MIR-BR-ID.
           MOVE MIR-AGT-ID            TO WAB-AGT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WAB-SBSDRY-CO-ID.

           PERFORM  AB-1000-READ-FOR-UPDATE
               THRU AB-1000-READ-FOR-UPDATE-X.

           IF WAB-IO-OK
              PERFORM  AB-1000-DELETE
                  THRU AB-1000-DELETE-X
           ELSE
              MOVE WAB-KEY            TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000010'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

014221     MOVE RAB-AGT-ID             TO WAG-AGT-ID.
014221     PERFORM  AG-2000-REWRITE
014221         THRU AG-2000-REWRITE-X.
014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.
014221
           PERFORM  2400-CLEAR-SCREEN-VALUES
               THRU 2400-CLEAR-SCREEN-VALUES-X.

           MOVE SPACES                TO MIR-DV-COMM-AGT-NM.
           MOVE SPACES                TO MIR-BR-ID.

       6000-PROCESS-DELETE-X.
           EXIT.
      *
      *---------------------------
       7100-GET-AGT-RELATIONSHIPS.
      *---------------------------
      *
      *    GET AGENT RESIDENTIAL RELATIONSHIP
      *
           INITIALIZE L0840-IO-PARM-INFO.
           INITIALIZE WS-RES-CLIENT.
           MOVE RAB-AGT-ID            TO L0840-AGT-ID.
           SET L0840-REL-TYP-RESIDENTIAL  TO TRUE.
           PERFORM  0840-5000-GET-AGT-REL
               THRU 0840-5000-GET-AGT-REL-X.
           IF L0840-RETRN-OK
               MOVE L0840-CLI-ID      TO WS-RES-CLI-ID
               MOVE L0840-ADDR-TYP-CD TO WS-RES-ADDR-TYP-CD
               MOVE L0840-BNK-ACCT-NUM    TO WS-RES-BNK-ACCT-NUM
           END-IF.
           SET RES-CLIENT-READ            TO TRUE.
      *
      *    GET AGENT MAILING RELATIONSHIP
      *
           INITIALIZE L0840-IO-PARM-INFO.
           INITIALIZE WS-MAIL-CLIENT.
           MOVE RAB-AGT-ID            TO L0840-AGT-ID.
           SET L0840-REL-TYP-MAILING      TO TRUE.
           PERFORM  0840-5000-GET-AGT-REL
               THRU 0840-5000-GET-AGT-REL-X.
           IF L0840-RETRN-OK
               MOVE L0840-CLI-ID      TO WS-MAIL-CLI-ID
               MOVE L0840-ADDR-TYP-CD TO WS-MAIL-ADDR-TYP-CD
               MOVE L0840-BNK-ACCT-NUM   TO WS-MAIL-BNK-ACCT-NUM
           END-IF.
           SET MAIL-CLIENT-READ           TO TRUE.

       7100-GET-AGT-RELATIONSHIPS-X.
           EXIT.

      *
      *-------------------------
       7300-GET-STD-FMT-CLI-NAME.
      *-------------------------
      *
      *    CALL STANDARD ROUTINE CSDU0620 TO GET CLIENT NAME IN
      *    THE STANDARD SCREEN FORMAT
      *
           INITIALIZE L0620-INPUT-PARM-INFO.
           IF L2435-CLI-SEX-CD = 'C'
               MOVE L2435-CLI-FULL-NAME
                                      TO L0620-CLI-CO-NM
           ELSE
               MOVE L2435-CLI-GIV-NM  TO L0620-CLI-GIV-NM
               MOVE L2435-CLI-SUR-NM  TO L0620-CLI-SUR-NM
               MOVE L2435-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
               MOVE L2435-CLI-SFX-NM  TO L0620-CLI-SFX-NM
           END-IF.
           MOVE L2435-CLI-SEX-CD      TO L0620-CLI-SEX-CD.

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

       7300-GET-STD-FMT-CLI-NAME-X.
           EXIT.
      *
      *-----------------
       8500-EDIT-SCR-03.
      *-----------------
      *
      *********************
      ***   EDIT MIR-AGT-PRST-4-PCT-T
      *********************

           IF MIR-AGT-PRST-4-PCT-T (WS-SUB) = SPACES
020874*        MOVE RAB-AGT-PRST-PCT (WS-SUB)
020874*                               TO WS-EDIT-2
020874*        MOVE WS-EDIT-2         TO MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874         MOVE RAB-AGT-PRST-PCT (WS-SUB) TO L0290-INPUT-V02
020874         MOVE 2                         TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-AGT-PRST-4-PCT-T (WS-SUB)
           ELSE
               IF MIR-AGT-PRST-4-PCT-T(WS-SUB)
                                       = EBLCH-BLANK-FIELD-CHAR
020874*            MOVE ZEROS         TO WS-EDIT-2
020874*            MOVE WS-EDIT-2     TO MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874             MOVE ZEROS                     TO L0290-INPUT-V02
020874             MOVE 2                         TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA
020874                                TO MIR-AGT-PRST-4-PCT-T (WS-SUB)
               END-IF
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE 3                 TO L0280-LENGTH
               MOVE 6                 TO L0280-INPUT-SIZE
               MOVE MIR-AGT-PRST-4-PCT-T (WS-SUB)
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO RAB-AGT-PRST-PCT (WS-SUB)
020874*            MOVE RAB-AGT-PRST-PCT (WS-SUB)
020874*                               TO WS-EDIT-2
020874*            MOVE WS-EDIT-2     TO MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874             MOVE RAB-AGT-PRST-PCT (WS-SUB) TO L0290-INPUT-V02
020874             MOVE 2                         TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA
020874                                TO MIR-AGT-PRST-4-PCT-T (WS-SUB)
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE WS-SUB        TO WS-EDIT-8
                   MOVE WS-EDIT-8     TO WGLOB-MSG-PARM (1)
                   MOVE 'CS33500069'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-PROD-4-AMT-T
      *********************

           IF MIR-AGT-PROD-4-AMT-T (WS-SUB) = SPACES
020874*        MOVE RAB-AGT-PROD-AMT (WS-SUB)
020874*                              TO L0290-INPUT-NUMBER
020874         MOVE RAB-AGT-PROD-AMT (WS-SUB)
020874                                TO L0290-INPUT-V00
               MOVE +0                TO L0290-PRECISION
               MOVE LENGTH OF MIR-AGT-PROD-4-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY        TO TRUE
               SET  L0290-SIGN-POS-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-AGT-PROD-4-AMT-T (WS-SUB)
           ELSE
               IF MIR-AGT-PROD-4-AMT-T (WS-SUB)
                                       = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-AGT-PROD-4-AMT-T (WS-SUB)
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 0                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-AGT-PROD-4-AMT-T (WS-SUB)
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1
               MOVE MIR-AGT-PROD-4-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT  TO RAB-AGT-PROD-AMT (WS-SUB)
020874*            MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
020874             MOVE L0280-OUTPUT  TO L0290-INPUT-V00
                   MOVE +0            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-AGT-PROD-4-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN
                   SET L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-AGT-PROD-4-AMT-T (WS-SUB)
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE WS-SUB        TO WS-EDIT-8
                   MOVE WS-EDIT-8     TO WGLOB-MSG-PARM (1)
                   MOVE 'CS33500070'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-MDRT-4-AMT-T
      *********************

           IF MIR-AGT-MDRT-4-AMT-T (WS-SUB) = SPACES
020874*        MOVE RAB-AGT-MDRT-AMT (WS-SUB)
020874*                              TO L0290-INPUT-NUMBER
020874         MOVE RAB-AGT-MDRT-AMT (WS-SUB)
020874                               TO L0290-INPUT-V00
               MOVE +0               TO L0290-PRECISION
               MOVE LENGTH OF MIR-AGT-MDRT-4-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY        TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-AGT-MDRT-4-AMT-T (WS-SUB)
           ELSE
               IF MIR-AGT-MDRT-4-AMT-T (WS-SUB)
                                       = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-AGT-MDRT-4-AMT-T (WS-SUB)
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 0                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-AGT-MDRT-4-AMT-T (WS-SUB)
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1
               MOVE MIR-AGT-MDRT-4-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT  TO RAB-AGT-MDRT-AMT (WS-SUB)
020874*            MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
020874             MOVE L0280-OUTPUT  TO L0290-INPUT-V00
                   MOVE +0            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-AGT-MDRT-4-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY        TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-AGT-MDRT-4-AMT-T (WS-SUB)
                ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE WS-SUB        TO WS-EDIT-8
                   MOVE WS-EDIT-8     TO WGLOB-MSG-PARM (1)
                   MOVE 'CS33500071'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***  EDIT MIR-CNVTN-ATND-4-IND-T
      *********************

           IF MIR-CNVTN-ATND-4-IND-T(WS-SUB) =  EBLCH-BLANK-FIELD-CHAR
              MOVE SPACES             TO MIR-CNVTN-ATND-4-IND-T(WS-SUB)
           END-IF.

           IF MIR-CNVTN-ATND-4-IND-T(WS-SUB) =  'Y'
           OR MIR-CNVTN-ATND-4-IND-T(WS-SUB) =  'N'
           OR MIR-CNVTN-ATND-4-IND-T(WS-SUB) =  ' '
              MOVE MIR-CNVTN-ATND-4-IND-T(WS-SUB)
                                      TO RAB-CNVTN-ATND-IND(WS-SUB)
           ELSE
              MOVE  'Y'               TO WS-ERROR-SW
              MOVE WS-SUB             TO WS-EDIT-8
              MOVE WS-EDIT-8          TO WGLOB-MSG-PARM (1)
              MOVE 'CS33500049'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *********************
      *** EDIT MIR-APTVTY-AWD-4-IND-T
      *********************

           IF MIR-APTVTY-AWD-4-IND-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACES             TO MIR-APTVTY-AWD-4-IND-T (WS-SUB)
           END-IF.

           IF MIR-APTVTY-AWD-4-IND-T (WS-SUB)  =  'Y'
           OR MIR-APTVTY-AWD-4-IND-T (WS-SUB)  =  'N'
           OR MIR-APTVTY-AWD-4-IND-T (WS-SUB)  =  ' '
              MOVE MIR-APTVTY-AWD-4-IND-T(WS-SUB)
                                      TO RAB-APTVTY-AWD-IND(WS-SUB)
           ELSE
              MOVE  'Y'               TO WS-ERROR-SW
              MOVE WS-SUB             TO WS-EDIT-8
              MOVE WS-EDIT-8          TO WGLOB-MSG-PARM (1)
              MOVE 'CS33500050'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *********************
      ***   EDIT MIR-NQA-4-IND-T
      *********************

           IF MIR-NQA-4-IND-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACES             TO MIR-NQA-4-IND-T (WS-SUB)
           END-IF.

           IF MIR-NQA-4-IND-T (WS-SUB)  =  'Y'
           OR MIR-NQA-4-IND-T (WS-SUB)  =  'N'
           OR MIR-NQA-4-IND-T (WS-SUB)  =  ' '
              MOVE MIR-NQA-4-IND-T (WS-SUB)
                                      TO RAB-NQA-IND (WS-SUB)
           ELSE
              MOVE  'Y'               TO WS-ERROR-SW
              MOVE WS-SUB             TO WS-EDIT-8
              MOVE WS-EDIT-8          TO WGLOB-MSG-PARM (1)
              MOVE 'CS33500051'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8500-EDIT-SCR-03-X.
           EXIT.
      *
      *-----------------
       8600-EDIT-SCR-04.
      *-----------------

      *********************
      ***   EDIT MIR-FYR-CPREM-CMO-AMT
      *********************

           IF  MIR-FYR-CPREM-CMO-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-FYR-CPREM-CMO-AMT * 100
020874         MOVE RAB-FYR-CPREM-CMO-AMT TO L0290-INPUT-V02
               MOVE +2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-FYR-CPREM-CMO-AMT
                                          TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-FYR-CPREM-CMO-AMT
           ELSE
               IF MIR-FYR-CPREM-CMO-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-FYR-CPREM-CMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-FYR-CPREM-CMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-FYR-CPREM-CMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-FYR-CPREM-CMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-FYR-CPREM-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-FYR-CPREM-CMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500072'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-FYR-CPREM-YTD-AMT
      *********************

           IF  MIR-FYR-CPREM-YTD-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-FYR-CPREM-YTD-AMT * 100
020874         MOVE RAB-FYR-CPREM-YTD-AMT TO L0290-INPUT-V02
               MOVE +2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-FYR-CPREM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-FYR-CPREM-YTD-AMT
           ELSE
               IF MIR-FYR-CPREM-YTD-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-FYR-CPREM-YTD-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-FYR-CPREM-YTD-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-FYR-CPREM-YTD-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-FYR-CPREM-YTD-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-FYR-CPREM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-FYR-CPREM-YTD-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500073'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-FYR-LCOMM-CMO-AMT
      *********************
           IF  MIR-FYR-LCOMM-CMO-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-FYR-LCOMM-CMO-AMT * 100
020874         MOVE RAB-FYR-LCOMM-CMO-AMT TO L0290-INPUT-V02
               MOVE +2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-FYR-LCOMM-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-FYR-LCOMM-CMO-AMT
           ELSE
               IF MIR-FYR-LCOMM-CMO-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-FYR-LCOMM-CMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-FYR-LCOMM-CMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-FYR-LCOMM-CMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-FYR-LCOMM-CMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-FYR-LCOMM-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-FYR-LCOMM-CMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500074'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-FYR-LCOMM-YTD-AMT
      *********************

           IF  MIR-FYR-LCOMM-YTD-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-FYR-LCOMM-YTD-AMT * 100
020874         MOVE RAB-FYR-LCOMM-YTD-AMT TO L0290-INPUT-V02
               MOVE +2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-FYR-LCOMM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-FYR-LCOMM-YTD-AMT
           ELSE
               IF MIR-FYR-LCOMM-YTD-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-FYR-LCOMM-YTD-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-FYR-LCOMM-YTD-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-FYR-LCOMM-YTD-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-FYR-LCOMM-YTD-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-FYR-LCOMM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-FYR-LCOMM-YTD-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500075'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-RENW-CPREM-CMO-AMT
      *********************
           IF  MIR-RENW-CPREM-CMO-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-RENW-CPREM-CMO-AMT * 100
020874         MOVE RAB-RENW-CPREM-CMO-AMT TO L0290-INPUT-V02
               MOVE +2                TO L0290-PRECISION
               MOVE LENGTH OF MIR-RENW-CPREM-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-RENW-CPREM-CMO-AMT
           ELSE
               IF MIR-RENW-CPREM-CMO-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-RENW-CPREM-CMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-RENW-CPREM-CMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-RENW-CPREM-CMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-RENW-CPREM-CMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-RENW-CPREM-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-RENW-CPREM-CMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500076'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-RENW-CPREM-YTD-AMT
      *********************
           IF  MIR-RENW-CPREM-YTD-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-RENW-CPREM-YTD-AMT * 100
020874         MOVE RAB-RENW-CPREM-YTD-AMT TO L0290-INPUT-V02
               MOVE +2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-RENW-CPREM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-RENW-CPREM-YTD-AMT
           ELSE
               IF MIR-RENW-CPREM-YTD-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-RENW-CPREM-YTD-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-RENW-CPREM-YTD-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-RENW-CPREM-YTD-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-RENW-CPREM-YTD-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-RENW-CPREM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-RENW-CPREM-YTD-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500077'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-RENW-LCOMM-CMO-AMT
      *********************

           IF  MIR-RENW-LCOMM-CMO-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-RENW-LCOMM-CMO-AMT * 100
020874         MOVE RAB-RENW-LCOMM-CMO-AMT TO L0290-INPUT-V02
               MOVE +2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-RENW-LCOMM-CMO-AMT
                                           TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-RENW-LCOMM-CMO-AMT
           ELSE
               IF MIR-RENW-LCOMM-CMO-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-RENW-LCOMM-CMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-RENW-LCOMM-CMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-RENW-LCOMM-CMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-RENW-LCOMM-CMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-RENW-LCOMM-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-RENW-LCOMM-CMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500078'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-RENW-LCOMM-YTD-AMT
      *********************

           IF  MIR-RENW-LCOMM-YTD-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-RENW-LCOMM-YTD-AMT * 100
020874         MOVE RAB-RENW-LCOMM-YTD-AMT TO L0290-INPUT-V02
               MOVE +2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-RENW-LCOMM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-RENW-LCOMM-YTD-AMT
           ELSE
               IF MIR-RENW-LCOMM-YTD-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-RENW-LCOMM-YTD-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-RENW-LCOMM-YTD-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-RENW-LCOMM-YTD-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-RENW-LCOMM-YTD-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-RENW-LCOMM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                  MOVE L0290-OUTPUT-DATA
                                      TO MIR-RENW-LCOMM-YTD-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500079'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-QLTY-BON-CMO-AMT
      *********************

           IF  MIR-QLTY-BON-CMO-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-QLTY-BON-CMO-AMT * 100
020874         MOVE RAB-QLTY-BON-CMO-AMT TO L0290-INPUT-V02
               MOVE +2                   TO L0290-PRECISION
               MOVE LENGTH OF MIR-QLTY-BON-CMO-AMT
                                         TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY   TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-QLTY-BON-CMO-AMT
           ELSE
               IF MIR-QLTY-BON-CMO-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-QLTY-BON-CMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-QLTY-BON-CMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-QLTY-BON-CMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-QLTY-BON-CMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-QLTY-BON-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY   TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-QLTY-BON-CMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500080'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-QLTY-BON-YTD-AMT
      *********************

           IF  MIR-QLTY-BON-YTD-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-QLTY-BON-YTD-AMT * 100
020874         MOVE RAB-QLTY-BON-YTD-AMT TO L0290-INPUT-V02
               MOVE +2                   TO L0290-PRECISION
               MOVE LENGTH OF MIR-QLTY-BON-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-QLTY-BON-YTD-AMT
           ELSE
               IF MIR-QLTY-BON-YTD-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-QLTY-BON-YTD-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-QLTY-BON-YTD-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-QLTY-BON-YTD-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-QLTY-BON-YTD-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-QLTY-BON-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY   TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-QLTY-BON-YTD-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500081'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-MKT-BON-CMO-AMT
      *********************

           IF  MIR-MKT-BON-CMO-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-MKT-BON-CMO-AMT * 100
020874         MOVE RAB-MKT-BON-CMO-AMT TO L0290-INPUT-V02
               MOVE +2                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-MKT-BON-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-MKT-BON-CMO-AMT
           ELSE
               IF MIR-MKT-BON-CMO-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-MKT-BON-CMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-MKT-BON-CMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-MKT-BON-CMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-MKT-BON-CMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-MKT-BON-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY   TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-MKT-BON-CMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500082'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-MKT-BON-YTD-AMT
      *********************

           IF  MIR-MKT-BON-YTD-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-MKT-BON-YTD-AMT * 100
020874         MOVE RAB-MKT-BON-YTD-AMT TO L0290-INPUT-V02
               MOVE +2                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-MKT-BON-YTD-AMT
                                        TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-MKT-BON-YTD-AMT
           ELSE
               IF MIR-MKT-BON-YTD-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-MKT-BON-YTD-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-MKT-BON-YTD-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-MKT-BON-YTD-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-MKT-BON-YTD-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-MKT-BON-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY   TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-MKT-BON-YTD-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500083'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-NHS-ALLOW-CMO-AMT
      *********************

           IF  MIR-NHS-ALLOW-CMO-AMT   = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-NHS-ALLOW-CMO-AMT * 100
020874         MOVE RAB-NHS-ALLOW-CMO-AMT TO L0290-INPUT-V02
               MOVE +2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-NHS-ALLOW-CMO-AMT
                                          TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-NHS-ALLOW-CMO-AMT
           ELSE
               IF MIR-NHS-ALLOW-CMO-AMT   = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-NHS-ALLOW-CMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-NHS-ALLOW-CMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-NHS-ALLOW-CMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-NHS-ALLOW-CMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-NHS-ALLOW-CMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY   TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X

                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-NHS-ALLOW-CMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500084'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-NHS-ALLOW-YTD-AMT
      *********************

           IF  MIR-NHS-ALLOW-YTD-AMT   = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-NHS-ALLOW-YTD-AMT * 100
020874         MOVE RAB-NHS-ALLOW-YTD-AMT TO L0290-INPUT-V02
               MOVE +2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-NHS-ALLOW-YTD-AMT
                                          TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-NHS-ALLOW-YTD-AMT
           ELSE
               IF MIR-NHS-ALLOW-YTD-AMT   = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-NHS-ALLOW-YTD-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-NHS-ALLOW-YTD-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-NHS-ALLOW-YTD-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-NHS-ALLOW-YTD-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-NHS-ALLOW-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-NHS-ALLOW-YTD-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500085'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-PWRIT-PMO-AMT
      *********************

           IF  MIR-AGT-PWRIT-PMO-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PWRIT-PMO-AMT * 100
020874         MOVE RAB-AGT-PWRIT-PMO-AMT TO L0290-INPUT-V02
               MOVE +2                TO L0290-PRECISION
               MOVE LENGTH OF MIR-AGT-PWRIT-PMO-AMT
                                      TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-AGT-PWRIT-PMO-AMT
           ELSE
               IF MIR-AGT-PWRIT-PMO-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-AGT-PWRIT-PMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-AGT-PWRIT-PMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-AGT-PWRIT-PMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-AGT-PWRIT-PMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-AGT-PWRIT-PMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-AGT-PWRIT-PMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500086'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-PWRIT-YTM-AMT
      *********************

           IF  MIR-AGT-PWRIT-YTM-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PWRIT-YTM-AMT * 100
020874         MOVE RAB-AGT-PWRIT-YTM-AMT TO L0290-INPUT-V02
               MOVE +2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-AGT-PWRIT-YTM-AMT
                                          TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-AGT-PWRIT-YTM-AMT
           ELSE
               IF MIR-AGT-PWRIT-YTM-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-AGT-PWRIT-YTM-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-AGT-PWRIT-YTM-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-AGT-PWRIT-YTM-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-AGT-PWRIT-YTM-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-AGT-PWRIT-YTM-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-AGT-PWRIT-YTM-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500087'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-LIFE-PWRIT-PMO-AMT
      *********************

           IF  MIR-LIFE-PWRIT-PMO-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-LIFE-PWRIT-PMO-AMT * 100
020874         MOVE RAB-LIFE-PWRIT-PMO-AMT TO L0290-INPUT-V02
               MOVE +2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-LIFE-PWRIT-PMO-AMT
                                           TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-LIFE-PWRIT-PMO-AMT
           ELSE
               IF MIR-LIFE-PWRIT-PMO-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-LIFE-PWRIT-PMO-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-LIFE-PWRIT-PMO-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-LIFE-PWRIT-PMO-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-LIFE-PWRIT-PMO-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-LIFE-PWRIT-PMO-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-LIFE-PWRIT-PMO-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500088'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-LIFE-PWRIT-YTM-AMT
      *********************

           IF  MIR-LIFE-PWRIT-YTM-AMT  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-LIFE-PWRIT-YTM-AMT * 100
020874         MOVE RAB-LIFE-PWRIT-YTM-AMT TO L0290-INPUT-V02
               MOVE +2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-LIFE-PWRIT-YTM-AMT
                                           TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-LIFE-PWRIT-YTM-AMT
           ELSE
               IF MIR-LIFE-PWRIT-YTM-AMT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-LIFE-PWRIT-YTM-AMT
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-LIFE-PWRIT-YTM-AMT
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-LIFE-PWRIT-YTM-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-LIFE-PWRIT-YTM-AMT
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-LIFE-PWRIT-YTM-AMT
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-LIFE-PWRIT-YTM-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500089'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-APP-PMO-QTY
      *********************

           IF  MIR-AGT-APP-PMO-QTY  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-APP-PMO-QTY * 100
020874         MOVE RAB-AGT-APP-PMO-QTY TO L0290-INPUT-V02
               MOVE +2                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-AGT-APP-PMO-QTY
                                        TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-AGT-APP-PMO-QTY
           ELSE
               IF MIR-AGT-APP-PMO-QTY  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-AGT-APP-PMO-QTY
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-AGT-APP-PMO-QTY
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-AGT-APP-PMO-QTY
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-AGT-APP-PMO-QTY
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-AGT-APP-PMO-QTY
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-AGT-APP-PMO-QTY
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500090'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-APP-YTM-QTY
      *********************

           IF  MIR-AGT-APP-YTM-QTY  = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-APP-YTM-QTY * 100
020874         MOVE RAB-AGT-APP-YTM-QTY TO L0290-INPUT-V02
               MOVE +2                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-AGT-APP-YTM-QTY
                                        TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-AGT-APP-YTM-QTY
           ELSE
               IF MIR-AGT-APP-YTM-QTY  = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-AGT-APP-YTM-QTY
               END-IF
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
               MOVE LENGTH OF MIR-AGT-APP-YTM-QTY
                                      TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               MOVE MIR-AGT-APP-YTM-QTY
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE RAB-AGT-APP-YTM-QTY
                                     = L0280-OUTPUT-DOLLAR
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
                   MOVE +2            TO L0290-PRECISION
                   MOVE LENGTH OF MIR-AGT-APP-YTM-QTY
                                      TO L0290-MAX-OUT-LEN
                   SET  L0290-SIGN-DISPLAY     TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                                      TO MIR-AGT-APP-YTM-QTY
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS33500091'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       8600-EDIT-SCR-04-X.
           EXIT.
      *--------------------
      ***************************************************
      ** NEW PARAGRAPH TO MOVE THE FIELDS TO THE SCREENS
      ***************************************************
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      * SCREEN 01
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-COMM-CMO-AMT * 100.
023514*    MOVE RAB-FYR-COMM-CMO-AMT  TO  L0290-INPUT-V02.
023514     MOVE LCOMM-FYR-COMM-AMT    TO  L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
023514*    MOVE LENGTH OF MIR-FYR-COMM-CMO-AMT
023514     MOVE LENGTH OF MIR-FYR-COMM-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY          TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
023514*    MOVE L0290-OUTPUT-DATA     TO  MIR-FYR-COMM-CMO-AMT.
023514     MOVE L0290-OUTPUT-DATA     TO  MIR-FYR-COMM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-COMM-YTD-AMT * 100.
020874     MOVE RAB-FYR-COMM-YTD-AMT  TO  L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-FYR-COMM-YTD-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY          TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-FYR-COMM-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-COMM-CMO-AMT * 100.
023514*    MOVE RAB-RENW-COMM-CMO-AMT  TO  L0290-INPUT-V02.
023514     MOVE LCOMM-RENW-COMM-AMT    TO  L0290-INPUT-V02.
           MOVE +2                     TO  L0290-PRECISION.
023514*    MOVE LENGTH OF MIR-RENW-COMM-CMO-AMT
023514     MOVE LENGTH OF MIR-RENW-COMM-AMT
                                       TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY     TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
023514*    MOVE L0290-OUTPUT-DATA     TO  MIR-RENW-COMM-CMO-AMT.
023514     MOVE L0290-OUTPUT-DATA     TO  MIR-RENW-COMM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-TRAIL-COMM-CMO-AMT * 100.
020874     MOVE RAB-TRAIL-COMM-CMO-AMT  TO  L0290-INPUT-V02.
012148     MOVE +2                      TO  L0290-PRECISION.
012148     MOVE LENGTH OF MIR-TRAIL-COMM-CMO-AMT
                                        TO  L0290-MAX-OUT-LEN.
012148     SET  L0290-SIGN-DISPLAY      TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
012148     MOVE L0290-OUTPUT-DATA       TO  MIR-TRAIL-COMM-CMO-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-COMM-YTD-AMT * 100.
020874     MOVE RAB-RENW-COMM-YTD-AMT   TO  L0290-INPUT-V02.
           MOVE +2                      TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-RENW-COMM-YTD-AMT
                                        TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY      TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO  MIR-RENW-COMM-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-TRAIL-COMM-YTD-AMT * 100.
020874     MOVE RAB-TRAIL-COMM-YTD-AMT  TO  L0290-INPUT-V02.
012148     MOVE +2                      TO  L0290-PRECISION.
012148     MOVE LENGTH OF MIR-TRAIL-COMM-YTD-AMT
                                        TO  L0290-MAX-OUT-LEN.
012148     SET  L0290-SIGN-DISPLAY      TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
012148     MOVE L0290-OUTPUT-DATA       TO  MIR-TRAIL-COMM-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-OVRID-COMM-CMO-AMT * 100.
020874     MOVE RAB-OVRID-COMM-CMO-AMT  TO  L0290-INPUT-V02.
           MOVE +2                      TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-OVRID-COMM-CMO-AMT
                                        TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY      TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO  MIR-OVRID-COMM-CMO-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-OVRID-COMM-YTD-AMT * 100.
020874     MOVE RAB-OVRID-COMM-YTD-AMT  TO  L0290-INPUT-V02.
           MOVE +2                      TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-OVRID-COMM-YTD-AMT
                                        TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY      TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO  MIR-OVRID-COMM-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PAYO-CMO-AMT * 100.
020874     MOVE RAB-AGT-PAYO-CMO-AMT    TO  L0290-INPUT-V02.
           MOVE +2                      TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-AGT-PAYO-CMO-AMT
                                        TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY      TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO  MIR-AGT-PAYO-CMO-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PAYO-YTD-AMT * 100.
020874     MOVE RAB-AGT-PAYO-YTD-AMT    TO  L0290-INPUT-V02.
           MOVE +2                      TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-AGT-PAYO-YTD-AMT
                                        TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY      TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO  MIR-AGT-PAYO-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PAYBL-BAL-AMT * 100.
020874     MOVE RAB-AGT-PAYBL-BAL-AMT   TO  L0290-INPUT-V02.
           MOVE +2                      TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-AGT-PAYBL-BAL-AMT
                                        TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY      TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-AGT-PAYBL-BAL-AMT.

      * SCREEN 02

           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
020874*        COMPUTE L0290-INPUT-NUMBER
020874*               = RAB-FYR-COMM-AMT (WS-SUB) * 100
023514*        MOVE RAB-FYR-COMM-AMT (WS-SUB) TO L0290-INPUT-V02
023514         MOVE L2455-AGT-BAL-FYR-COMM-AMT (WS-SUB)
023514                                        TO L0290-INPUT-V02
               MOVE +2                        TO  L0290-PRECISION
023118*        MOVE LENGTH OF MIR-FYR-COMM-12-AMT-T (WS-SUB)
023118         MOVE LENGTH OF MIR-FYR-COMM-AMT-T (WS-SUB)
                                              TO  L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY        TO  TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023118         MOVE L0290-OUTPUT-DATA TO MIR-FYR-COMM-AMT-T(WS-SUB)
023118*        MOVE L0290-OUTPUT-DATA TO MIR-FYR-COMM-12-AMT-T(WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = RAB-RENW-COMM-AMT (WS-SUB) * 100
023514*        MOVE RAB-RENW-COMM-AMT (WS-SUB) TO L0290-INPUT-V02
023514         MOVE L2455-AGT-BAL-RENW-COMM-AMT (WS-SUB)
023514                                         TO L0290-INPUT-V02
               MOVE +2                         TO L0290-PRECISION
023118*        MOVE LENGTH OF MIR-RENW-COMM-12-AMT-T (WS-SUB)
023118         MOVE LENGTH OF MIR-RENW-COMM-AMT-T (WS-SUB)
                                               TO  L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY         TO  TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
023118                           TO  MIR-RENW-COMM-AMT-T (WS-SUB)
023118*                          TO  MIR-RENW-COMM-12-AMT-T (WS-SUB)
027250*        MOVE WS-WORK-YEAR
027250         MOVE L2455-AGT-BAL-YR (WS-SUB)
023514                                 TO MIR-AGT-COMM-YR-T (WS-SUB)
023514
027250*        MOVE WS-WORK-MONTH      TO WS-MOS-ABBR-IDX
027250         MOVE L2455-AGT-BAL-MO (WS-SUB)   TO WS-MOS-ABBR-IDX
023514         MOVE WS-MOS-ABBR (WS-MOS-ABBR-IDX) TO
023514                                  MIR-AGT-COMM-MO-T (WS-SUB)
027250*        SUBTRACT 1                  FROM WS-WORK-MONTH
027250*        IF  WS-WORK-MONTH <= ZERO
027250*           MOVE 12                 TO   WS-WORK-MONTH
027250*           SUBTRACT 1              FROM WS-WORK-YEAR
027250*        END-IF

           END-PERFORM.

      * SCREEN 03
           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 4
020874*        MOVE RAB-AGT-PRST-PCT (WS-SUB)
020874*                               TO  WS-EDIT-2
020874*        MOVE WS-EDIT-2         TO  MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874         MOVE RAB-AGT-PRST-PCT (WS-SUB) TO L0290-INPUT-V02
020874         MOVE 2                         TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-AGT-PRST-4-PCT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PROD-AMT (WS-SUB)
020874         MOVE RAB-AGT-PROD-AMT (WS-SUB) TO L0290-INPUT-V00
               MOVE +0                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-AGT-PROD-4-AMT-T (WS-SUB)
                                              TO  L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY        TO  TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO  MIR-AGT-PROD-4-AMT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-MDRT-AMT (WS-SUB)
020874         MOVE RAB-AGT-MDRT-AMT (WS-SUB) TO L0290-INPUT-V00
               MOVE +0                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-AGT-MDRT-4-AMT-T (WS-SUB)
                                              TO  L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY        TO  TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO  MIR-AGT-MDRT-4-AMT-T (WS-SUB)
               MOVE RAB-CNVTN-ATND-IND (WS-SUB)
                                     TO  MIR-CNVTN-ATND-4-IND-T (WS-SUB)
               MOVE RAB-APTVTY-AWD-IND (WS-SUB)
                                     TO  MIR-APTVTY-AWD-4-IND-T (WS-SUB)
               MOVE RAB-NQA-IND      (WS-SUB)
                                      TO  MIR-NQA-4-IND-T  (WS-SUB)
           END-PERFORM.

      * SCREEN 04
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-CPREM-CMO-AMT * 100.
020874     MOVE RAB-FYR-CPREM-CMO-AMT TO L0290-INPUT-V02.
           MOVE +2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FYR-CPREM-CMO-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-FYR-CPREM-CMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-CPREM-YTD-AMT * 100.
020874     MOVE RAB-FYR-CPREM-YTD-AMT TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-FYR-CPREM-YTD-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-FYR-CPREM-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-LCOMM-CMO-AMT * 100.
020874     MOVE RAB-FYR-LCOMM-CMO-AMT TO L0290-INPUT-V02.
           MOVE +2                     TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-FYR-LCOMM-CMO-AMT
                                       TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY     TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-FYR-LCOMM-CMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-LCOMM-YTD-AMT * 100.
020874     MOVE RAB-FYR-LCOMM-YTD-AMT TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-FYR-LCOMM-YTD-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-FYR-LCOMM-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-CPREM-CMO-AMT * 100.
020874     MOVE RAB-RENW-CPREM-CMO-AMT TO L0290-INPUT-V02.
           MOVE +2                     TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-RENW-CPREM-CMO-AMT
                                       TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY     TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-RENW-CPREM-CMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-CPREM-YTD-AMT * 100.
020874     MOVE RAB-RENW-CPREM-YTD-AMT TO L0290-INPUT-V02.
           MOVE +2                     TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-RENW-CPREM-YTD-AMT
                                       TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY     TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-RENW-CPREM-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-LCOMM-CMO-AMT * 100.
020874     MOVE RAB-RENW-LCOMM-CMO-AMT TO L0290-INPUT-V02.
           MOVE +2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-RENW-LCOMM-CMO-AMT
                                       TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-RENW-LCOMM-CMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-LCOMM-YTD-AMT * 100.
020874     MOVE RAB-RENW-LCOMM-YTD-AMT TO L0290-INPUT-V02.
           MOVE +2                     TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-RENW-LCOMM-YTD-AMT
                                       TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY     TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-RENW-LCOMM-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-QLTY-BON-CMO-AMT * 100.
020874     MOVE RAB-QLTY-BON-CMO-AMT  TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-QLTY-BON-CMO-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-QLTY-BON-CMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-QLTY-BON-YTD-AMT * 100.
020874     MOVE RAB-QLTY-BON-YTD-AMT  TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-QLTY-BON-YTD-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY        TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-QLTY-BON-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-MKT-BON-CMO-AMT * 100.
020874     MOVE RAB-MKT-BON-CMO-AMT   TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-MKT-BON-CMO-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-MKT-BON-CMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-MKT-BON-YTD-AMT * 100.
020874     MOVE RAB-MKT-BON-YTD-AMT   TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-MKT-BON-YTD-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY        TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-MKT-BON-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-NHS-ALLOW-CMO-AMT * 100.
020874     MOVE RAB-NHS-ALLOW-CMO-AMT TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-NHS-ALLOW-CMO-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-NHS-ALLOW-CMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-NHS-ALLOW-YTD-AMT * 100.
020874     MOVE RAB-NHS-ALLOW-YTD-AMT TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-NHS-ALLOW-YTD-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-NHS-ALLOW-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PWRIT-PMO-AMT * 100.
020874     MOVE RAB-AGT-PWRIT-PMO-AMT TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-AGT-PWRIT-PMO-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-AGT-PWRIT-PMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PWRIT-YTM-AMT * 100.
020874     MOVE RAB-AGT-PWRIT-YTM-AMT TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-AGT-PWRIT-YTM-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-AGT-PWRIT-YTM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-LIFE-PWRIT-PMO-AMT * 100.
020874     MOVE RAB-LIFE-PWRIT-PMO-AMT TO L0290-INPUT-V02.
           MOVE +2                    TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-LIFE-PWRIT-PMO-AMT
                                      TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-LIFE-PWRIT-PMO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-LIFE-PWRIT-YTM-AMT * 100.
020874     MOVE RAB-LIFE-PWRIT-YTM-AMT TO L0290-INPUT-V02.
           MOVE +2                     TO  L0290-PRECISION.
           MOVE LENGTH OF MIR-LIFE-PWRIT-YTM-AMT
                                       TO  L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY     TO  TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO  MIR-LIFE-PWRIT-YTM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-APP-PMO-QTY * 100.
020874     MOVE RAB-AGT-APP-PMO-QTY   TO L0290-INPUT-V02.
           MOVE +2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-AGT-APP-PMO-QTY
                                      TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-AGT-APP-PMO-QTY.
020874*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-APP-YTM-QTY * 100.
020874     MOVE RAB-AGT-APP-YTM-QTY   TO L0290-INPUT-V02.
           MOVE +2                    TO L0290-PRECISION .
           MOVE LENGTH OF MIR-AGT-APP-YTM-QTY
                                      TO L0290-MAX-OUT-LEN .
           SET  L0290-SIGN-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-AGT-APP-YTM-QTY.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0840-0000-INIT-PARM-INFO
025970         THRU 0840-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2455-0000-INIT-PARM-INFO
025970         THRU 2455-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-CHECKS.
025970     INITIALIZE WS-AGNT-CLI-REL-GR.
025970     INITIALIZE OTHER-MISC-WORK-AREAS.
025970
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET  WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET  WS-TRANS-NAME-DEFAULT       TO TRUE.
025970     SET  MIR-RETRN-OK                TO  TRUE.
025970     SET  NO-ERRORS-FOUND             TO TRUE.
025970     SET  WS-AGENT-RL-FOUND-NO        TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970     MOVE WGLOB-MOS-ABBR-TXT    TO WS-MOS-ABBR-TXT.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

025970 COPY CCPS0840.
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
       COPY XCPS0290.
       COPY XCPL0290.
      *
021930*COPY XCPL1640.
      *
023514 COPY XCPSCOMM.
023514 COPY XCPPCOMM.
023514*
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
014660*COPY XCPPMEXT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
014035*COPY CCCL2440.
      *
018764*COPY CCCL0840.
018764 COPY CCPL0840.
014035*COPY CCPS0840.
      *
025970 COPY CCPS0620.
       COPY CCPL0620.
      *
      *
018764*COPY CCCL2435.
018764 COPY CCPL2435.

014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY AG
014221                         '$VAR2' BY 'AG'.

023514 COPY CCPS2455.
023514 COPY CCPL2455.

018764*COPY XCCL8090.
023514 COPY XCPS8090.
018764 COPY XCPL8090.
014221
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPAAB.
       COPY CCPBAB.
       COPY CCPNAB.
       COPY CCPUAB.
       COPY CCPXAB.
       COPY CCPCAB.
      *
016537*COPY CCPAAG.
016537*COPY CCPBAG.
       COPY CCPNAG.
       COPY CCPUAG.
016537*COPY CCPXAG.
014035*COPY CCPCAG.
      *
016537*COPY CCPNAS.
      *
016537*COPY CCPNCC.
      *
       COPY CCPNSCOM.
      *
016537*COPY XCPNCRCY.
      *
016537*COPY CCPBRL.
      *
016537*COPY CCPNCLIN.
      *
016537*COPY CCPNEDIT.
016537*COPY CCPNBRCH.
014035*COPY CCPEADDR.
      *
       COPY CCPS2435.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM3350                     **
      *****************************************************************
