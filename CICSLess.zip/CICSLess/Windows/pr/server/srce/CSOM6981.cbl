      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM6981.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6981                                         **
      **  REMARKS:  POLI - POLICY INQUIRY SCREENS                    **
      **            THIS MODULE PERFORMS THE POLICY INQUIRY FOR THE  **
      **            POLICY VAULES                                    **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
007766**            INCREASE NUMBER OF COVERAGES                     **
008453**            EXTERNAL DATE FORMAT                             **
008455**            AMOUNT FIELD SIZING FOR INTERNATIONAL            **
008455**            SUPPORT                                          **
008953**            FUND UNIT PRICE MAINT.-SEARCHING,                **
008953**            NO RE-ENTER                                      **
010418**            ENHANCED MULTI-COMPANY PROCESSING                **
011026**            MINUMUM CONTRACT VALUE CALCULATION               **
016057**            CLEANUP/DATA CAHNGES                             **
54-001**            CO RECORD UW INFO NOT DISPLAYED                  **
557668**            SELECTION LIST                                   **
557708**            HANDLING OF CICS ABENDS                          **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       NEW                                              **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016053**  6.1       MONEY FLOW                                       **
016057**  6.1       CODE CLEANUP AND STANDARDIZATION                 **
015904**  6.2       MIR CLEANUP                                      **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016686**  6.2       PROCESSING DATE CHANGE FOR CONCURRENCY           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
015705**  6.4       NAME FORMATTING                                  **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6981'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
007766 COPY XCWWCVGM.

025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                      PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT          VALUE 'POLI'.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                      PIC X(04)
025970*                                           VALUE 'POLI'.
007766     05  WS-SUBD                            PIC 9(03).
016548*    05  WS-START-CVGNO                     PIC S9(4)  COMP.
016548     05  WS-START-CVGNO                     PIC S9(4)  BINARY.
016548*    05  WS-END-CVGNO                       PIC S9(4)  COMP.
016548     05  WS-END-CVGNO                       PIC S9(4)  BINARY.
           05  WS-FOUND-PRIMARY-SW                PIC X(01).
               88  WS-FOUND-PRIMARY               VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS           VALUE 'N'.

           05  WS-SCREEN-CLIENT                   PIC X(10).

016548*    05  WS-SUB                             PIC S9(04)    COMP.
016548     05  WS-SUB                             PIC S9(04)    BINARY.

018633*01  WS-TWRK-KEY                      PIC X(04) VALUE '6981'.
018633*01  WS-WORK-AREA.
018633*    05  WS-WORK-PROGRAM-NUMBER       PIC X(04).
018633*    05  WS-WORK-CLIENT-NUMBER        PIC X(10).
018633*    05  WS-WORK-POL-ID.
018633*        10  WS-WORK-POL-ID-BASE      PIC X(09).
018633*        10  WS-WORK-POL-ID-SFX       PIC X(01).
018633*    05  WS-WORK-QUOTE-NUMBER         PIC X(06).
018633*    05  WS-WORK-CLAIM-NO             PIC X(06).
018633*    05  WS-WORK-SPECIFIC-AREA.
018633*        10  WS-WORK-BUS-FCN-ID       PIC X(04).
018633*        10  WS-WORK-DATE             PIC X(10).
018633*        10  FILLER                   PIC X(249).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '6981'.
018633     15  LCOMM-POL-ID.
018633         20  LCOMM-POL-ID-BASE        PIC X(09).
018633         20  LCOMM-POL-ID-SFX         PIC X(01).
018633     15  LCOMM-SPECIFIC-AREA.
018633         20  LCOMM-BUS-FCN-ID         PIC X(04).
018633         20  LCOMM-EFF-DT             PIC X(10).
018633
       01  WS-EDIT-PROCESS-CHECKS.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-BLANK         VALUE SPACES.
               88  WS-BUS-FCN-VALID         VALUE '6981'.
               88  WS-BUS-FCN-POL-VAL       VALUE '6981'.

           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.

           05  WS-CLIENT-FOUND-SW           PIC X(01).
               88  WS-CLIENT-FOUND          VALUE 'Y'.
               88  WS-NO-CLIENT-FOUND       VALUE 'N'.

           05  WS-POLICY.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-CVG-NUM              PIC X(02).
               88  WS-CVG-NUM-BLANK    VALUE SPACES ZEROS.
           05  WS-CVG-NUM-R            REDEFINES
               WS-CVG-NUM              PIC 9(02).
           05  WS-CURR-DATE.
               10  WS-CURR-YEAR             PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-CURR-MONTH            PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-CURR-DAY              PIC 9(02).
           05  WS-CV-DATE.
               10  WS-CV-DATE-YR            PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-CV-DATE-MO            PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-CV-DATE-DY            PIC 9(02).
008453     05  WS-SCREEN-DATE               PIC X(10).

           05  WS-POL-STATUS                PIC X(04).

008455 01  WS-NUMERIC-CONVERSIONS.
008455     05  WS-PIC-0-5                   PIC -.9(5).
008455     05  WS-PIC-1-2                   PIC -9.99.
008455     05  WS-PIC-1-4                   PIC -9.9(4).
008455     05  WS-PIC-1-5                   PIC -9.9(5).
008455     05  WS-PIC-2                     PIC -(2)9.
008455     05  WS-PIC-2-3                   PIC -(2)9.9(3).
008455     05  WS-PIC-2-7                   PIC --9.9(7).
008455     05  WS-PIC-P3-1                  PIC 999.9.
008455     05  WS-PIC-3-2                   PIC -(3)9.99.
008455     05  WS-PIC-3-3                   PIC -(3)9.999.
008455     05  WS-PIC-3-4                   PIC -(3)9.9(4).
008455     05  WS-PIC-2-4                   PIC -(2)9.9(4).
011026     05  WS-PIC-2-5                   PIC Z9.9(5).
008455     05  WS-PIC-3-6                   PIC -(3)9.9(6).
008455     05  WS-PIC-4-5                   PIC -(4)9.9(5).
008455     05  WS-PIC-5-4                   PIC -(5)9.9(4).
008455     05  WS-PIC-P6-5                  PIC Z(5)9.9(5).
008455     05  WS-PIC-8-5                   PIC -(8)9.9(5).

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
      *
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
026057 COPY XCWWWKDT.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
       COPY CCFWPOLC.
       COPY CCFRPOLC.
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************
020478 COPY CCWL2626.
008455 COPY XCWL0290.

557668 COPY CCWL0620.
       COPY CCWL2430.
      *
016440 COPY CCWL5400.
       COPY CCWL6981.
      *
       COPY XCWLDTLK.
016537*COPY XCWL0225.
       COPY XCWL0280.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM6981.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           INITIALIZE L2430-OUTPUT-PARM-INFO.
           INITIALIZE RPOL-REC-INFO.

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  0100-SET-MIR-VALUES
               THRU 0100-SET-MIR-VALUES-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------
       0100-SET-MIR-VALUES.
      *--------------------

           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX.
016686*    MOVE WS-SCREEN-DATE        TO MIR-APPL-CTL-PRCES-DT.
016686     MOVE WS-SCREEN-DATE        TO MIR-DV-EFF-DT.
           MOVE WS-BUS-FCN-ID         TO MIR-BUS-FCN-ID.

       0100-SET-MIR-VALUES-X.
           EXIT.
      *
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET MIR-RETRN-OK    TO TRUE.
           MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.
018633*    MOVE SPACES         TO WS-WORK-AREA.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           MOVE WGLOB-PROCESS-DATE    TO WS-CURR-DATE.
           MOVE SPACES                TO WS-SCREEN-CLIENT.

           PERFORM  2050-SET-WS-FROM-MIR
               THRU 2050-SET-WS-FROM-MIR-X.

018633*    IF  MIR-BUS-FCN-ID        NOT = WS-WORK-BUS-FCN-ID
018633*    OR  MIR-POL-ID-BASE       NOT = WS-WORK-POL-ID-BASE
018633*    OR  MIR-POL-ID-SFX        NOT = WS-WORK-POL-ID-SFX
018633     IF  MIR-BUS-FCN-ID        NOT = LCOMM-BUS-FCN-ID
018633     OR  MIR-POL-ID-BASE       NOT = LCOMM-POL-ID-BASE
018633     OR  MIR-POL-ID-SFX        NOT = LCOMM-POL-ID-SFX
016686*    OR  MIR-APPL-CTL-PRCES-DT NOT = WS-WORK-DATE
018633*    OR  MIR-DV-EFF-DT         NOT = WS-WORK-DATE
018633*        INITIALIZE                  WS-WORK-SPECIFIC-AREA
018633*        MOVE MIR-BUS-FCN-ID         TO WS-WORK-BUS-FCN-ID
018633     OR  MIR-DV-EFF-DT         NOT = LCOMM-EFF-DT
018633         INITIALIZE                  LCOMM-SPECIFIC-AREA
018633         MOVE MIR-BUS-FCN-ID         TO LCOMM-BUS-FCN-ID
016686*        MOVE MIR-APPL-CTL-PRCES-DT  TO WS-WORK-DATE
018633*        MOVE MIR-DV-EFF-DT          TO WS-WORK-DATE
018633         MOVE MIR-DV-EFF-DT          TO LCOMM-EFF-DT
           END-IF.

           SET WS-NO-ERRORS-FOUND      TO TRUE.

           PERFORM  2200-MORE-INITIAL-EDITS
               THRU 2200-MORE-INITIAL-EDITS-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.

           PERFORM  3000-DISPLAY-SCREEN
               THRU 3000-DISPLAY-SCREEN-X.

018633*    MOVE WS-POL-ID-BASE        TO WS-WORK-POL-ID-BASE.
018633*    MOVE WS-POL-ID-SFX         TO WS-WORK-POL-ID-SFX.
018633     MOVE WS-POL-ID-BASE        TO LCOMM-POL-ID-BASE.
018633     MOVE WS-POL-ID-SFX         TO LCOMM-POL-ID-SFX.

018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *---------------------
       2050-SET-WS-FROM-MIR.
      *---------------------

           IF  MIR-POL-ID-BASE = SPACES
018633*        MOVE WS-WORK-POL-ID-BASE TO MIR-POL-ID-BASE
018633*        MOVE WS-WORK-POL-ID-SFX  TO MIR-POL-ID-SFX
018633         MOVE LCOMM-POL-ID-BASE   TO MIR-POL-ID-BASE
018633         MOVE LCOMM-POL-ID-SFX    TO MIR-POL-ID-SFX
           END-IF.

           MOVE MIR-POL-ID-BASE         TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX          TO WS-POL-ID-SFX.
016686*    MOVE MIR-APPL-CTL-PRCES-DT   TO WS-SCREEN-DATE.
016686     MOVE MIR-DV-EFF-DT           TO WS-SCREEN-DATE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           MOVE '01'                    TO WS-CVG-NUM.

016686*    IF  MIR-APPL-CTL-PRCES-DT = SPACES
016686     IF  MIR-DV-EFF-DT         = SPACES
               MOVE WGLOB-PROCESS-DATE      TO L1640-INTERNAL-DATE
               MOVE WGLOB-PROCESS-DATE      TO WS-CV-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE     TO WS-SCREEN-DATE
           ELSE
016686*        MOVE MIR-APPL-CTL-PRCES-DT   TO WS-SCREEN-DATE
016686         MOVE MIR-DV-EFF-DT           TO WS-SCREEN-DATE
016686*        MOVE MIR-APPL-CTL-PRCES-DT   TO L1640-EXTERNAL-DATE
016686         MOVE MIR-DV-EFF-DT           TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-VALID
                   MOVE L1640-INTERNAL-DATE TO WS-CV-DATE
               END-IF
           END-IF.

       2050-SET-WS-FROM-MIR-X.
           EXIT.
      *
      *------------------------
       2200-MORE-INITIAL-EDITS.
      *------------------------

           MOVE WS-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'POLICY RECORD NOT FOUND (@1)'
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.

016440     SET L5400-POL-XFER-INQ     TO TRUE.

016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.

016440     IF  L5400-XFER-ACCS-RESTRICTED
016440         SET WS-ERROR-FOUND     TO TRUE
016440     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE WS-CVG-NUM            TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WS-CVG-NUM-R
007766         IF  WS-CVG-NUM > WCVGM-MAX-WCVGS-NUM
                   SET WS-ERROR-FOUND      TO TRUE
      *MSG:        'COVERAGE MUST BE NUMERIC'
                   MOVE 'XS00000079'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-CVG-NUM    TO WGLOB-MSG-PARM (1)
007766             MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'COVERAGE MUST BE NUMERIC'
               MOVE 'XS00000079'      TO WGLOB-MSG-REF-INFO
               MOVE WS-CVG-NUM        TO WGLOB-MSG-PARM (1)
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE WS-SCREEN-DATE        TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'DATE @1 INVALID'
               MOVE 'CS69810001'      TO WGLOB-MSG-REF-INFO
               MOVE WS-SCREEN-DATE    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CV-DATE               TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WS-ERROR-FOUND      TO TRUE
026057        GO TO 2200-MORE-INITIAL-EDITS-X
026057     END-IF.

           IF  RPOL-POL-CVG-REC-CTR-N = ZEROS
      *MSG:    'NO COVERAGES TO DISPLAY'
               MOVE 'XS00000095'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  WS-CVG-NUM-R > RPOL-POL-CVG-REC-CTR-N
      *MSG:        'COVERAGE (@1) DOES NOT EXIST'
                   MOVE 'XS00000080'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-CVG-NUM    TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  2210-READ-ALL-CVG
               THRU 2210-READ-ALL-CVG-X
               VARYING WS-SUBD FROM 1 BY 1
               UNTIL   WS-SUBD > RPOL-POL-CVG-REC-CTR-N
               OR      WS-ERROR-FOUND.

           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

       2200-MORE-INITIAL-EDITS-X.
           EXIT.
      *
      *------------------
       2210-READ-ALL-CVG.
      *------------------

           MOVE WS-POL-ID-BASE        TO WCVG-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WCVG-POL-ID-SFX.
           MOVE WS-SUBD               TO WCVG-CVG-NUM-N.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  WCVG-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'POLICY & COVERAGE (@1) OUT OF SYNC ...'
               MOVE 'XS00000084'      TO WGLOB-MSG-REF-INFO
               MOVE WS-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2210-READ-ALL-CVG-X
           END-IF.

           MOVE RCVG-CVG-INFO         TO WCVGS-CVG-INFO (WS-SUBD).
           MOVE WS-SUBD               TO WCVGS-CVG-SEQ-NUM-N (WS-SUBD).

       2210-READ-ALL-CVG-X.
           EXIT.
      *
      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------

           SET  WS-NO-CLIENT-FOUND TO TRUE.

           IF  WS-CVG-NUM-BLANK
               MOVE +1                TO WS-START-CVGNO
           ELSE
               MOVE WS-CVG-NUM-R      TO WS-START-CVGNO
           END-IF.

           MOVE WS-START-CVGNO        TO WS-END-CVGNO.

           IF  WS-END-CVGNO > RPOL-POL-CVG-REC-CTR-N
               MOVE RPOL-POL-CVG-REC-CTR-N
                                      TO WS-END-CVGNO
           END-IF.

      *
      * READ AND FORMAT OWNERS NAME
      *
           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.

557668     INITIALIZE L0620-INPUT-PARM-INFO.
557668     IF L2430-CLI-SEX-COMPANY
557668         MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668     ELSE
557668         MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668         MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
015705         MOVE L2430-CLI-MID-INIT-NM
015705                                TO L0620-CLI-MID-INIT-NM
015705         MOVE L2430-CLI-SFX-NM  TO L0620-CLI-SFX-NM
557668     END-IF.
557668     MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
557668     PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668         THRU 0620-1000-FORMAT-SCREEN-NAME-X.
557668     MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
           MOVE RPOL-POL-CVG-REC-CTR  TO MIR-POL-CVG-REC-CTR.

           MOVE RPOL-POL-CSTAT-CD     TO WS-POL-STATUS.

010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
010418
       2300-COMMON-LINE-SET-X.
           EXIT.
      *
      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

018633*    IF  WS-WORK-POL-ID-BASE = SPACES
018633     IF  LCOMM-POL-ID-BASE = SPACES
           AND WS-POLICY         = SPACES
               GO TO 2320-GET-OWNER-X
           END-IF.

           IF  L2430-CLI-ID = SPACES
               PERFORM  2400-CHECK-FOR-OWNER-CLI
                   THRU 2400-CHECK-FOR-OWNER-CLI-X
           ELSE
               IF  L2430-CLI-NM-COMPRESSED = SPACES
      *MSG:        'OWNER CLIENT NAME = SPACES'
                   MOVE 'CS69810006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2320-GET-OWNER-X.
           EXIT.
      *
      *-------------------------
       2400-CHECK-FOR-OWNER-CLI.
      *-------------------------

      *
      * BUILD START/END BROWSE KEY
      *
           MOVE LOW-VALUES            TO  WPOLC-KEY.
           MOVE RPOL-POL-ID           TO  WPOLC-POL-ID.
           MOVE 'O'                   TO  WPOLC-POL-CLI-REL-TYP-CD.

           MOVE WPOLC-KEY             TO  WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO  WPOLC-ENDBR-CLI-ID.

      *
      *  POSITION AT THE FIRST RECORD FOR THE GIVEN RELATIONSHIP
      *
           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

           IF  WPOLC-IO-OK
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

           IF  WPOLC-IO-EOF
      *MSG:    'PRIMARY POLICY OWNER IS NOT FOUND'
               MOVE 'CS69810007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           SET  WS-NO-PRIMARY-EXISTS TO TRUE.
           PERFORM  2500-DETERMINE-IF-PRIMARY
               THRU 2500-DETERMINE-IF-PRIMARY-X
               UNTIL WPOLC-IO-EOF
               OR    WS-FOUND-PRIMARY.

           IF  WS-NO-PRIMARY-EXISTS
      *MSG:    'PRIMARY POLICY OWNER IS NOT FOUND'
               MOVE 'CS69810007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           PERFORM  2600-FIND-OWNERS-LOOP
               THRU 2600-FIND-OWNERS-LOOP-X
               UNTIL WPOLC-IO-EOF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.


       2400-CHECK-FOR-OWNER-CLI-X.
           EXIT.

      *--------------------------
       2500-DETERMINE-IF-PRIMARY.
      *--------------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD = 'P'
               SET WS-FOUND-PRIMARY TO TRUE
               GO TO 2500-DETERMINE-IF-PRIMARY-X
           END-IF.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2500-DETERMINE-IF-PRIMARY-X.
           EXIT.

      *----------------------
       2600-FIND-OWNERS-LOOP.
      *----------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD NOT = 'P'
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
               GO TO 2600-FIND-OWNERS-LOOP-X
           END-IF.

           MOVE +0                    TO I.

54-001     PERFORM  2430-1000-BUILD-PARM-INFO
54-001         THRU 2430-1000-BUILD-PARM-INFO-X.

      *
      * WE HAVE FOUND THE REQUIRED RECORD, READ THE CLIENT FILE
      *
           MOVE  RPOLC-CLI-ID         TO  L2430-CLI-ID.

54-001     PERFORM  2430-2100-GET-OWNER
54-001         THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

       2600-FIND-OWNERS-LOOP-X.
           EXIT.
      *
      *--------------------
       3000-DISPLAY-SCREEN.
      *--------------------

           PERFORM  6981-1000-BUILD-PARM-INFO
               THRU 6981-1000-BUILD-PARM-INFO-X.

           MOVE WS-CVG-NUM-R          TO L6981-CVG.
           MOVE WS-SCREEN-DATE        TO L6981-SCREEN-DATE.
           MOVE WS-SCREEN-DATE        TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO L6981-EFF-DT.

           PERFORM  6981-1000-INQUIRE
               THRU 6981-1000-INQUIRE-X.

016053*    PERFORM  6981-2000-RETRN-PARM-INFO
      *        THRU 6981-2000-RETRN-PARM-INFO-X.
           PERFORM  3100-RETRN-PARM-INFO
016053         THRU 3100-RETRN-PARM-INFO-X.

       3000-DISPLAY-SCREEN-X.
           EXIT.
      /
      *--------------------------
       3100-RETRN-PARM-INFO.
      *--------------------------
      *
      * RETURN OUTPUT PARAMETERS
      *

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-ACMCV * 100.
020874     MOVE L6981-ACMCV          TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-MCV-ACUM-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-MCV-ACUM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-NETBCV * 100.
020464*    MOVE L6981-NETBCV         TO L0290-INPUT-V02.
020464*
020464* INCLUDE DEFERRED ACTIVITY AMOUNT IN NET BASE CASH VALUE
020464*
020464     COMPUTE L0290-INPUT-V02
020464           = L6981-NETBCV
020464           + (L6981-DV-POL-DEFR-IN-AMT
020464           + L6981-DV-POL-DEFR-OUT-AMT).

           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-NET-CSV-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-NET-CSV-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-MCVNCV * 100.
020464*    MOVE L6981-MCVNCV         TO L0290-INPUT-V02.
020464     COMPUTE  L0290-INPUT-V02
020874           =  L6981-MCVNCV
020464           + (L6981-DV-POL-DEFR-IN-AMT
020464           +  L6981-DV-POL-DEFR-OUT-AMT).
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-MCV-CSV-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-MCV-CSV-AMT.

020464*
020464* NET POLICY PENDING ACTIVITY AMOUNT
020464*
020464     COMPUTE L0290-INPUT-V02
020464           = (L6981-DV-POL-PEND-IN-AMT
020464           + L6981-DV-POL-PEND-OUT-AMT).
020464     MOVE 2                    TO L0290-PRECISION.
020464     SET L0290-SIGN-DISPLAY    TO TRUE.
020464     SET L0290-SIGN-FLOAT      TO TRUE.
020464     MOVE LENGTH OF MIR-DV-POL-PEND-ACTV-AMT TO L0290-MAX-OUT-LEN.
020464     PERFORM 0290-2000-FORMAT-FOR-MIR
020464        THRU 0290-2000-FORMAT-FOR-MIR-X.
020464     MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-PEND-ACTV-AMT.
020464*
020464* NET POLICY DEFERRED ACTIVITY AMOUNT
020464*
020464     COMPUTE L0290-INPUT-V02
020464           = (L6981-DV-POL-DEFR-IN-AMT
020464           + L6981-DV-POL-DEFR-OUT-AMT).
020464     MOVE 2                    TO L0290-PRECISION.
020464     SET L0290-SIGN-DISPLAY    TO TRUE.
020464     SET L0290-SIGN-FLOAT      TO TRUE.
020464     MOVE LENGTH OF MIR-DV-POL-DEFR-ACTV-AMT TO L0290-MAX-OUT-LEN.
020464     PERFORM 0290-2000-FORMAT-FOR-MIR
020464        THRU 0290-2000-FORMAT-FOR-MIR-X.
020464     MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-DEFR-ACTV-AMT.
020464
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-CV * 100.
020464*    MOVE L6981-CV             TO L0290-INPUT-V02.
020464*
020464* DEFERRED ACTIVITY AMOUNT IN CASH SURRENDER VALUE
020464*
020464     COMPUTE L0290-INPUT-V02
020464           = L6981-CV
020464           + (L6981-DV-POL-DEFR-IN-AMT
020464           + L6981-DV-POL-DEFR-OUT-AMT).
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-CSV-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-CSV-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-BASCV * 100.
020464*    MOVE L6981-BASCV           TO L0290-INPUT-V02.
020464*
020464* REMOVE PENDING ACTIVITY AMOUNT FROM BASE CASH VALUE
020464*
020464     COMPUTE L0290-INPUT-V02
020464           = L6981-BASCV
020464           - (L6981-DV-POL-PEND-IN-AMT
020464           + L6981-DV-POL-PEND-OUT-AMT).

           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-BASE-CV-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-BASE-CV-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-PUACV * 100.
020874     MOVE L6981-PUACV           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-VALU-PUA-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-VALU-PUA-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DIVS * 100.
020874     MOVE L6981-DIVS            TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-DOD-ACUM-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-POL-DOD-ACUM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DVINT * 100.
020874     MOVE L6981-DVINT           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DOD-CRNT-INT-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DOD-CRNT-INT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-PDF * 100.
020874     MOVE L6981-PDF             TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PDF-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-POL-PDF-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-PDFAC * 100.
020874     MOVE L6981-PDFAC           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PDF-INT-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-POL-PDF-INT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-RFND * 100.
020874     MOVE L6981-RFND           TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-PREM-RFND-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-PREM-RFND-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-LNAMT * 100.
020874     MOVE L6981-LNAMT          TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-LOAN-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-LOAN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-CLNINT * 100.
020874     MOVE L6981-CLNINT         TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-LOAN-INT-YTD-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-LOAN-INT-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-APL * 100.
020874     MOVE L6981-APL            TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-APL-AMT TO L0290-MAX-OUT-LEN.
015904     MOVE LENGTH OF MIR-DV-APL-LOAN-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-APL-AMT.
015904     MOVE L0290-OUTPUT-DATA    TO MIR-DV-APL-LOAN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-APLIN * 100.
020874     MOVE L6981-APLIN           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-APL-INT-YTD-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-APL-INT-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-PCHRG * 100.
020874     MOVE L6981-PCHRG           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-SURR-CHRG-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-SURR-CHRG-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-MKTAJ * 100.
020874     MOVE L6981-MKTAJ            TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-MKTVAL-ADJ-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-CF-MKTVAL-ADJ-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-MTVAJ * 100.
020874     MOVE L6981-MTVAJ           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-MTHV-ADJ-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-MTHV-ADJ-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-MSUSP * 100.
020874     MOVE L6981-MSUSP           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-POL-MISC-SUSP-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-PSUSP * 100.
020874     MOVE L6981-PSUSP           TO L0290-INPUT-V02.
016053     MOVE 2                     TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-POL-PREM-SUSP-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-OSDIS * 100.
020874     MOVE L6981-OSDIS           TO L0290-INPUT-V02.
016053     MOVE 2                     TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-POL-OS-DISB-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-POL-OS-DISB-AMT.

016053     MOVE L6981-CALCT          TO MIR-PLAN-CSV-DT-TYP-CD.

016053     MOVE L6981-RFNDR          TO WS-PIC-5-4.
016053     MOVE WS-PIC-5-4           TO MIR-TRM-PREM-RFND-RT.

016053     IF L6981-MAXLN IS POSITIVE
016053*    COMPUTE L0290-INPUT-NUMBER = L6981-MAXLN * 100.
016053*    MOVE 2                    TO L0290-PRECISION.
016053*    MOVE LENGTH OF MIR-DV-MAX-LOAN-AMT TO L0290-MAX-OUT-LEN.
016053*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053*    SET L0290-SIGN-DISPLAY        TO TRUE.
016053*    SET L0290-SIGN-FLOAT          TO TRUE.
016053*    PERFORM 0290-1000-NUMERIC-FORMAT
016053*       THRU 0290-1000-NUMERIC-FORMAT-X.
016053*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-MAX-LOAN-AMT.
020874*       COMPUTE L0290-INPUT-NUMBER = L6981-MAXLN * 100
020874        MOVE L6981-MAXLN          TO L0290-INPUT-V02
016053        MOVE 2                    TO L0290-PRECISION
016053        MOVE LENGTH OF MIR-DV-MAX-LOAN-AMT TO L0290-MAX-OUT-LEN
020874*       SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
016053        SET L0290-SIGN-DISPLAY        TO TRUE
016053        SET L0290-SIGN-FLOAT          TO TRUE
020874*       PERFORM 0290-1000-NUMERIC-FORMAT
020874*          THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
016053        MOVE L0290-OUTPUT-DATA    TO MIR-DV-MAX-LOAN-AMT
016053     ELSE
016053        MOVE ZERO TO MIR-DV-MAX-LOAN-AMT
016053     END-IF.
016053

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-TOTBN * 100.
020874     MOVE L6981-TOTBN          TO L0290-INPUT-V02.
016053     MOVE 2                    TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-POL-BON-CSH-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-BON-CSH-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-TBSURR * 100.
020874     MOVE L6981-TBSURR         TO L0290-INPUT-V02.
016053     MOVE 2                    TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-TRMNL-SURR-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-DV-TRMNL-SURR-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-POL-ACUM-AMT * 100.
020874     MOVE L6981-DV-POL-ACUM-AMT       TO L0290-INPUT-V02.
016053     MOVE 2                           TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-POL-ACUM-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-ACUM-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-POL-SIDFND-AFV-AMT
020874*                                * 100.
020874     MOVE L6981-DV-POL-SIDFND-AFV-AMT  TO L0290-INPUT-V02.
018846     MOVE 2                            TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-POL-SIDFND-AFV-AMT
018846       TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
018846     SET L0290-SIGN-DISPLAY        TO TRUE.
018846     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-SIDFND-AFV-AMT.
018846
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-SIDFND-NET-CV-AMT
020874*                               * 100.
020874     MOVE L6981-DV-SIDFND-NET-CV-AMT  TO L0290-INPUT-V02.
018846     MOVE 2                           TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-SIDFND-NET-CV-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
018846     SET L0290-SIGN-DISPLAY        TO TRUE.
018846     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA    TO MIR-DV-SIDFND-NET-CV-AMT.
018846
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-PDF-SUSP-AMT * 100.
020874     MOVE RPOL-POL-PDF-SUSP-AMT  TO L0290-INPUT-V02.
016053     MOVE 2                      TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-POL-PDF-SUSP-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-POL-PDF-SUSP-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-DIV-SUSP-AMT * 100.
020874     MOVE RPOL-POL-DIV-SUSP-AMT  TO L0290-INPUT-V02.
016053     MOVE 2                      TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-POL-DIV-SUSP-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-POL-DIV-SUSP-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-UL-SHRT-AMT * 100.
020874     MOVE RPOL-POL-UL-SHRT-AMT   TO L0290-INPUT-V02.
016053     MOVE 2                      TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-POL-UL-SHRT-AMT  TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-POL-UL-SHRT-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-POL-SURR-AMT * 100.
020874     MOVE L6981-DV-POL-SURR-AMT   TO L0290-INPUT-V02.
016053     MOVE 2                       TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-POL-SURR-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-SURR-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-UL-SHRT-AMT * 100.
020874     MOVE RPOL-POL-UL-SHRT-AMT   TO L0290-INPUT-V02.
016053     MOVE 2                      TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-POL-UL-SHRT-AMT  TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-DV-POL-UL-SHRT-AMT.
016053
016053***  COMPUTE L0290-INPUT-NUMBER = RPOL-POL-SE-XSLD-AMT * 100.
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-POL-SE-XSLD-AMT * 100.
031037*    MOVE L6981-POL-SE-XSLD-AMT   TO L0290-INPUT-V02.
031037*    MOVE 2                       TO L0290-PRECISION.
031037*    MOVE LENGTH OF MIR-DV-SE-XSLD-RFND-AMT TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
031037*    SET L0290-SIGN-DISPLAY        TO TRUE.
031037*    SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
031037*    PERFORM 0290-2000-FORMAT-FOR-MIR
031037*       THRU 0290-2000-FORMAT-FOR-MIR-X.
031037*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-SE-XSLD-RFND-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-OS-MPREM-AMT * 100.
020874     MOVE L6981-DV-OS-MPREM-AMT   TO L0290-INPUT-V02.
016053     MOVE 2                       TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-OS-MPREM-AMT
                                        TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016053     SET L0290-SIGN-DISPLAY        TO TRUE.
016053     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA    TO MIR-DV-OS-MPREM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-LOAN-MAX-DSCNT-PCT
020874*                                  * 100.
020874     MOVE L6981-DV-LOAN-MAX-DSCNT-PCT  TO L0290-INPUT-V02.
016057     MOVE 2                            TO L0290-PRECISION.
016057     MOVE LENGTH OF MIR-DV-LOAN-MAX-DSCNT-PCT
016057                               TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016057     SET L0290-SIGN-DISPLAY        TO TRUE.
016057     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016057     MOVE L0290-OUTPUT-DATA    TO MIR-DV-LOAN-MAX-DSCNT-PCT.

016053 3100-RETRN-PARM-INFO-X.
016053     EXIT.

      *
      /
      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.

018633*-------------------
018633*9500-BUILD-TWRK-KEY.
018633*-------------------
018633*
018633*    MOVE WS-TWRK-KEY
018633*      TO L8090-BUS-FCN-ID.
018633*    MOVE ZEROS
018633*      TO L8090-TEMP-WRK-SEQ-NUM.
018633*    SET L8090-USAGE-COMM TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9800-WRITE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*    MOVE 300
018633*      TO L8090-AREA-LEN.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*
018633*-------------------
018633*9900-DELETE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6981-0000-INIT-PARM-INFO
025970         THRU 6981-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-PROCESS-CHECKS.
025970     SET WS-TRANS-NAME-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
025970 COPY XCPS1670.
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
      *
       COPY CCPSPGA.
      *
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      *
008455 COPY XCPS0290.
008455 COPY XCPL0290.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
016440 COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440*
54-001 COPY CCPS6981.
018764*COPY CCCL6981.
018764 COPY CCPL6981.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
016537*COPY XCCL0225.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      *
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018633 COPY XCPL8090.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNCVG.
      *
       COPY CCPNPOL.
      *
       COPY CCPBPOLC.
      *
      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6981                     **
      *****************************************************************
