      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM1370.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM1370                                         **
      **  REMARKS:  LAB RESULTS TEST RANGE.                          **
      **            THIS PROGRAM WILL MAINTAIN THE DEFINED LABORATORY**
      **            TESTS AND SPECIFIC DETAILS ABOUT EACH TEST AND   **
      **            THE LAB.                                         **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016475**  6.1       REMOVE 9900-DELETE-TWRK LOGIC                    **
014221**  6.2       LOGICAL LOCKING                                  **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
018645**  6.4       REDEFINE LAB RESULTS                             **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM1370'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

       COPY XCWL8090.
018645 COPY XCWL8960.
014590*COPY XCWL0030.

       COPY XCWEBLCH.

014221 COPY CCWWLOCK.
      *
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID          VALUE '1540' '1541' '1542'
                                                   '1543' '1544'.
               88  WS-BUS-FCN-RETRIEVE       VALUE '1540'.
               88  WS-BUS-FCN-CREATE         VALUE '1541'.
               88  WS-BUS-FCN-UPDATE         VALUE '1542'.
               88  WS-BUS-FCN-DELETE         VALUE '1543'.
               88  WS-BUS-FCN-LIST           VALUE '1544'.
           05  WS-ADJUST-FACTOR             PIC S9     COMP-3.
016548*    05  WS-MAX-LINES-PER-SCREEN      PIC S9(04) COMP  VALUE +12.
025970*    05  WS-MAX-LINES-PER-SCREEN      PIC S9(04)
025970*                                     BINARY  VALUE +12.
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.
016548*    05  WS-DEST                      PIC S9(04) COMP.
016548     05  WS-DEST                      PIC S9(04) BINARY.
           05  WS-FORMAT-3-0                PIC 999.
           05  WS-SEX-FILE                  PIC X.
           05  WS-SEX-MIR                   PIC X.
           05  WS-INPUT-VALID-SW            PIC X.
               88  WS-INPUT-VALID           VALUE 'Y'.
               88  WS-INPUT-INVALID         VALUE 'N'.
           05  WS-EDIT-SEX                  PIC X.
               88  WS-VALID-SEX-CODE        VALUE ' ' 'F' 'M'.
           05  WS-EOF-LABT-SW               PIC X.
               88  WS-EOF-LABT              VALUE 'Y'.
           05  WS-RESULT-FILE.
               10  WS-RESULT-NUM            PIC S9(18) COMP-3.
           05  WS-RESULT-SCREEN             PIC X(8).
025970*
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LINES-PER-SCREEN      PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-SCREEN-LINES         VALUE +12.
025970*
016475*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1540'.
018633*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1544'.
018633*    05  WS-WORK-AREA.
018633*        10  WS-SCREEN-LAB-CODE       PIC X(04).
018633*        10  WS-SCREEN-TEST-NUMBER    PIC X(04).
018633*        10  WS-SCREEN-HIGH-AGE       PIC XXX.
018633*        10  WS-SCREEN-SEX            PIC X.
018633*        10  WS-SCREEN-ENTER-CODE     PIC X.
018633*        10  FILLER                   PIC X(287).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '1544'.
018633         15  LCOMM-LAB-CODE           PIC X(04).
018633         15  LCOMM-TEST-NUMBER        PIC X(04).
018633         15  LCOMM-HIGH-AGE           PIC XXX.
018633         15  LCOMM-SEX                PIC X.
018633         15  LCOMM-ENTER-CODE         PIC X.
018633
       COPY XCWL0280.
       COPY XCWL0290.
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
       COPY NCFWLABT.
       COPY NCFRLABT.
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM1370.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
018633
018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.



026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      ***************************************************************
      *   NORMAL PROCESSING: CHECK SECURITY PERMISSION & DISTRIBUTE
      *   CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      ***************************************************************
      ***************************
       2000-PROCESS-REQUEST.
      ***************************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

018633*    MOVE SPACES                TO  WS-WORK-AREA.
025970*    MOVE MIR-BUS-FCN-ID        TO  WS-BUS-FCN-ID.


           IF WS-BUS-FCN-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

      *
      *    *** VALIDATE KEY AND CONTROL FIELDS
      *
           PERFORM  2100-VALIDATE-CONTROL-FIELDS
               THRU 2100-VALIDATE-CONTROL-FIELDS-X.
           IF WS-INPUT-INVALID
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.


           EVALUATE TRUE


             WHEN WS-BUS-FCN-RETRIEVE
                 PERFORM  2500-PROCESS-RETRIEVE
                     THRU 2500-PROCESS-RETRIEVE-X

             WHEN WS-BUS-FCN-LIST
                  PERFORM  3000-PROCESS-LIST
                      THRU 3000-PROCESS-LIST-X

             WHEN WS-BUS-FCN-UPDATE
                 PERFORM  5000-PROCESS-UPDATE
                     THRU 5000-PROCESS-UPDATE-X

             WHEN WS-BUS-FCN-DELETE
                 PERFORM  6000-PROCESS-DELETE
                     THRU 6000-PROCESS-DELETE-X

             WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM1370'
                                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.


      *----------------------------------------------------------------
      *   VALIDATE CONTROL FIELDS:
      *   CHECK VALIDITY OF ALL KEY AND CONTROL FIELDS.
      *   NUMERIC FIELDS ARE RIGHT JUSTIFIED, ZERO FILLED AND CHECKED
      *   FOR VALIDITY.
      *----------------------------------------------------------------
       2100-VALIDATE-CONTROL-FIELDS.


           MOVE 'Y'                   TO WS-INPUT-VALID-SW.

           IF MIR-LTST-STD-AGE-QTY = SPACES
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  4130-EDIT-HIGH-AGE
                   THRU 4130-EDIT-HIGH-AGE-X
557660     END-IF.

       2100-VALIDATE-CONTROL-FIELDS-X.
           EXIT.

      *----------------------------------------------------------------
      *   INQUIRY PROCESSING:
      *----------------------------------------------------------------
       2500-PROCESS-RETRIEVE.

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  8000-BUILD-LABT-KEY
               THRU 8000-BUILD-LABT-KEY-X.
014221*    PERFORM  LABT-1000-READ
014221*        THRU LABT-1000-READ-X.

014221     PERFORM  LABT-1000-READ-TWRK-TS
014221         THRU LABT-1000-READ-TWRK-TS-X.

           IF WLABT-IO-OK
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
      *MSG:    MESSAGE (I) "INQUIRE COMPLETE, CONTINUE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    MESSAGE (S) "LAB TESTS RECORD NOT FOUND (@1)".
               MOVE 'NS13700007'      TO WGLOB-MSG-REF-INFO
               MOVE WLABT-LTST-STD-SEX-CD
                                      TO WS-SEX-FILE
               PERFORM  8500-TRANSLATE-SEX-1
                   THRU 8500-TRANSLATE-SEX-1-X
               MOVE WS-SEX-MIR        TO WLABT-LTST-STD-SEX-CD
               MOVE WLABT-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2500-PROCESS-RETRIEVE-X.
           EXIT.

       3000-PROCESS-LIST.

      *
      *    *** SETUP BROWSE KEYS.
      *
018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF L8090-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT    TO WS-WORK-AREA
018633*    END-IF.
018633*
           PERFORM  8300-SET-PAGING-KEY
               THRU 8300-SET-PAGING-KEY-X.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  3100-NEXT-PAGE
               THRU 3100-NEXT-PAGE-X.

018633*    MOVE MIR-LAB-ID            TO WS-SCREEN-LAB-CODE.
018633*    MOVE MIR-LTST-ID           TO WS-SCREEN-TEST-NUMBER.
018633*    MOVE MIR-LTST-STD-AGE-QTY  TO WS-SCREEN-HIGH-AGE.
018633*    MOVE MIR-LTST-STD-SEX-CD   TO WS-SCREEN-SEX.
018633*    MOVE MIR-BUS-FCN-ID        TO WS-SCREEN-ENTER-CODE.
018633     MOVE MIR-LAB-ID            TO LCOMM-LAB-CODE.
018633     MOVE MIR-LTST-ID           TO LCOMM-TEST-NUMBER.
018633     MOVE MIR-LTST-STD-AGE-QTY  TO LCOMM-HIGH-AGE.
018633     MOVE MIR-LTST-STD-SEX-CD   TO LCOMM-SEX.
018633     MOVE MIR-BUS-FCN-ID        TO LCOMM-ENTER-CODE.

018633*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.

       3000-PROCESS-LIST-X.
           EXIT.


      *----------------------------------------------------------------
      *   INQUIRY - NEXT PAGE PROCESSING:
      *   SETUP BROWSE KEYS, BEGIN BROWSE, AND LOAD DATA ARRAY UNTIL
      *   END-OF-FILE OR SCREEN IS FULL OR LAB CHANGES
      *----------------------------------------------------------------
       3100-NEXT-PAGE.

      *
      *    *** SET UP END BROWSE KEY
      *
           MOVE HIGH-VALUES           TO WLABT-ENDBR-KEY
           MOVE MIR-LAB-ID            TO WLABT-ENDBR-LAB-ID.

      *
      *    *** DISPLAY NEXT PAGE
      *
           MOVE +1                    TO WS-LINE.
           PERFORM  3200-DISPLAY-NEXT-PAGE
               THRU 3200-DISPLAY-NEXT-PAGE-X.

       3100-NEXT-PAGE-X.
           EXIT.

      *----------------------------------------------------------------
      *   INQUIRY - DISPLAY NEXT PAGE:        INPUT: WS-LINE
      *   BROWSE FORWARDS FROM THE CURRENT BROWSE KEY, LOADING RECORDS
      *   BEGINNING WITH WS-LINE, UNTIL FULL OR EOF.
      *----------------------------------------------------------------
       3200-DISPLAY-NEXT-PAGE.

      *
      *    *** BEGIN BROWSE
      *
           PERFORM  LABT-1000-BROWSE
               THRU LABT-1000-BROWSE-X.

           IF NOT WLABT-IO-OK
               IF WS-LINE > 1
      *MSG:        MESSAGE (I) "INQUIRE COMPLETED - CONTINUE"
      *MSG:        MESSAGE (I) "** END OF LIST **"
                   MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3200-DISPLAY-NEXT-PAGE-X
               ELSE
      *MSG:        MESSAGE (I) "NO RECORDS FOUND TO DISPLAY"
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3200-DISPLAY-NEXT-PAGE-X
557660         END-IF
557660     END-IF.

      *
      *    *** READ FIRST RECORD.
      *
           PERFORM  LABT-2000-READ-NEXT
               THRU LABT-2000-READ-NEXT-X.

      *
      *    *** SKIP TO SECOND RECORD IF FILLING PAGE (COMPLETING PAGING)
      *
           IF  WS-LINE > 1
               IF WLABT-IO-OK
                   PERFORM  LABT-2000-READ-NEXT
                       THRU LABT-2000-READ-NEXT-X
557660         END-IF
557660     END-IF.

      *
      *    *** SAVE FIRST RECORD ON SCREEN IN COMM AREA FOR A CHANGE IN
      *    *** DIRECTION. ALSO UPDATE THE MIR KEY FIELDS
      *
           IF WS-LINE = 1
               IF WLABT-IO-OK
                   MOVE RLABT-LAB-ID  TO MIR-LAB-ID
                   MOVE RLABT-LTST-ID TO MIR-LTST-ID
                   MOVE RLABT-LTST-STD-AGE-QTY
                                      TO MIR-LTST-STD-AGE-QTY
                   MOVE RLABT-LTST-STD-SEX-CD
                                      TO WS-SEX-FILE
                   PERFORM  8500-TRANSLATE-SEX-1
                       THRU 8500-TRANSLATE-SEX-1-X
                   MOVE WS-SEX-MIR    TO MIR-LTST-STD-SEX-CD
557660         END-IF
557660     END-IF.

      *
      *    *** LOAD SCREEN DATA ARRAY
      *
           PERFORM  3210-DISPLAY-RECORD-NEXT
               THRU 3210-DISPLAY-RECORD-NEXT-X
                    VARYING WS-LINE FROM WS-LINE BY 1
                    UNTIL (NOT WLABT-IO-OK)
                       OR (WS-LINE > WS-MAX-LINES-PER-SCREEN).

      *
      *    *** COMPLETION MESSAGE
      *
           IF WLABT-IO-OK
      *MSG:    MESSAGE (I) "** TO VIEW MORE DATA PRESS ENTER **"
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9250-UPDATE-SCREEN-KEYS
                   THRU 9250-UPDATE-SCREEN-KEYS-X
           ELSE
               IF WS-LINE > 1
      *MSG:        MESSAGE (I) "INQUIRE COMPLETED - CONTINUE"
      *MSG:        MESSAGE (I) "** END OF LIST **"
                   MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG:            MESSAGE (I) "NO RECORDS FOUND TO DISPLAY"
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

      *
      *    *** FINISH BROWSE
      *
           PERFORM  LABT-3000-END-BROWSE
               THRU LABT-3000-END-BROWSE-X.

       3200-DISPLAY-NEXT-PAGE-X.
           EXIT.

      *----------------------------------------------------------------
      *   INQUIRY - DISPLAY RECORD NEXT:           INPUT: WS -LINE
      *   DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE GIVEN BY
      *   BY WS-LINE AND RETRIEVE THE NEXT RECORD.
      *----------------------------------------------------------------
       3210-DISPLAY-RECORD-NEXT.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  LABT-2000-READ-NEXT
               THRU LABT-2000-READ-NEXT-X.

       3210-DISPLAY-RECORD-NEXT-X.
           EXIT.

      *----------------------------------------------------------------
      *   CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, REC
      *   AND ALLOW USER TO MODIFY.
      *----------------------------------------------------------------
       4000-PROCESS-CREATE.


016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

013578     PERFORM  9100-BLANK-DATA-FIELDS
013578         THRU 9100-BLANK-DATA-FIELDS-X.

      *
      *    *** CHECK CONTROL FIELDS.
      *
           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.

           IF WS-INPUT-INVALID
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      *
      *    *** CHECK RECORD EXISTANCE
      *
           PERFORM  8000-BUILD-LABT-KEY
               THRU 8000-BUILD-LABT-KEY-X.
           PERFORM  LABT-1000-READ
               THRU LABT-1000-READ-X.

           IF WLABT-IO-OK
               MOVE MIR-LTST-STD-SEX-CD
                                      TO WLABT-LTST-STD-SEX-CD
               MOVE WLABT-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    MESSAGE (S) "RECORD ALREADY EXISTS (@1)"
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  LABT-1000-CREATE
               THRU LABT-1000-CREATE-X.
           PERFORM  LABT-1000-WRITE
               THRU LABT-1000-WRITE-X.

014221     PERFORM  LABT-1000-READ-TWRK-TS
014221         THRU LABT-1000-READ-TWRK-TS-X.

      *MSG:MESSAGE (I) "RECORD CREATED - CONTINUE".
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE +1                    TO WS-LINE.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *MSG:MESSAGE (I) "MAINTAIN DETAILS".
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       4000-PROCESS-CREATE-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT KEY FIELDS: CHECK VALIDITY OF ALL KEY FIELDS TO ENSURE
      *   ALL NEW RECORDS ARE CREATED WITH VALID KEYS.
      *----------------------------------------------------------------
       4100-EDIT-KEY-FIELDS.

           MOVE 'Y'                   TO WS-INPUT-VALID-SW.

           PERFORM  4110-EDIT-LAB-CODE
               THRU 4110-EDIT-LAB-CODE-X.

           PERFORM  4120-EDIT-TEST-NUMBER
               THRU 4120-EDIT-TEST-NUMBER-X.

           PERFORM  4140-EDIT-SEX
               THRU 4140-EDIT-SEX-X.

           PERFORM  4130-EDIT-HIGH-AGE
               THRU 4130-EDIT-HIGH-AGE-X.

      *
      *    *** IF THE KEY FIELDS ARE VALID AN ADDITIONAL EDIT IS
      *    *** PERFORMED ON THE SEX FIELD.
      *
           IF WS-INPUT-VALID
               PERFORM  4200-CROSS-EDIT-SEX
                   THRU 4200-CROSS-EDIT-SEX-X
557660     END-IF.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT LAB CODE - AGAINST EDIT/LABCD
      *----------------------------------------------------------------
       4110-EDIT-LAB-CODE.

           MOVE MIR-LAB-ID            TO WEDIT-ETBL-VALU-ID.
           PERFORM  LABC-1000-EDIT-LAB-CODE
               THRU LABC-1000-EDIT-LAB-CODE-X.

           IF NOT WEDIT-IO-OK
      *MSG:    MESSAGE (S): LAB CODE MUST BE IN EDIT TYPE 'LABCD'
               MOVE 'XS00000088'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
557660     END-IF.

       4110-EDIT-LAB-CODE-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT TEST NUMBER - AGAINST EDIT/TSTNO
      *----------------------------------------------------------------
       4120-EDIT-TEST-NUMBER.

           MOVE MIR-LTST-ID           TO WEDIT-ETBL-VALU-ID.
           PERFORM  TSTN-1000-EDIT-TEST-NUMBER
               THRU TSTN-1000-EDIT-TEST-NUMBER-X.

           IF NOT WEDIT-IO-OK
      *MSG:    MESSAGE (S) 'TEST NUMBER INVALID - MUST BE IN EDIT-TSTNO'
               MOVE 'NS13700003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
557660     END-IF.

       4120-EDIT-TEST-NUMBER-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT HIGH AGE - CHECK FOR NUMERICS
      *----------------------------------------------------------------
       4130-EDIT-HIGH-AGE.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 3                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-LTST-STD-AGE-QTY  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:    MESSAGE (S) 'HIGH AGE MUST BE NUMERIC'
               MOVE 'NS13700004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 4130-EDIT-HIGH-AGE-X
557660     END-IF.

           MOVE L0280-OUTPUT          TO WS-FORMAT-3-0.
           MOVE WS-FORMAT-3-0         TO MIR-LTST-STD-AGE-QTY.

       4130-EDIT-HIGH-AGE-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT SEX - HARD-CODED VALUES
      *----------------------------------------------------------------
       4140-EDIT-SEX.

           MOVE MIR-LTST-STD-SEX-CD   TO WS-EDIT-SEX.

           IF WS-VALID-SEX-CODE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG:    MESSAGE (S) 'SEX CODE MUST BE BLANK, M OR F'
               MOVE 'XS00000067'      TO WGLOB-MSG-REF-INFO
               MOVE 'BLANK, M, OR F'  TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
557660     END-IF.

       4140-EDIT-SEX-X.
           EXIT.

      *----------------------------------------------------------------
      *   CROSS EDIT SEX - A LAB/TEST MUST USE 'BLANKS' FOR SEX CODE
      *                    OF 'M' AND 'F'. THEY CANNOT BE MIXED.
      *----------------------------------------------------------------
       4200-CROSS-EDIT-SEX.

      *
      *    *** SET FIRST KEY TO START GOING FORWARD AT
      *
           PERFORM  8000-BUILD-LABT-KEY
               THRU 8000-BUILD-LABT-KEY-X.
           MOVE SPACES                TO WLABT-LTST-STD-SEX-CD.
           MOVE ZEROS                 TO WLABT-LTST-STD-AGE-QTY.

           MOVE HIGH-VALUES           TO WLABT-ENDBR-KEY.
           MOVE MIR-LAB-ID            TO WLABT-ENDBR-LAB-ID.
           MOVE MIR-LTST-ID           TO WLABT-ENDBR-LTST-ID.

      *
      *    *** BEGIN BROWSE
      *
           PERFORM  LABT-1000-BROWSE
               THRU LABT-1000-BROWSE-X.

           IF WLABT-IO-OK
               PERFORM  LABT-2000-READ-NEXT
                   THRU LABT-2000-READ-NEXT-X
           ELSE
               GO TO 4200-CROSS-EDIT-SEX-X
557660     END-IF.

      *
      *    *** IF A RECORD FOR THIS LAB/TEST WAS FOUND COMPARE THE
      *    *** SEX ON THE FILE TO THE SEX ENTERED.
      *
           IF WLABT-IO-OK
               IF  MIR-LTST-STD-SEX-CD = SPACES
               AND RLABT-LTST-STD-SEX-CD  NOT = HIGH-VALUES
                   MOVE 'N'           TO WS-INPUT-VALID-SW
      *MSG:        MESSAGE (S) 'SEX CODE CANNOT BE SPACES'
                   MOVE 'NS13700015'  TO WGLOB-MSG-REF-INFO
               ELSE
                   IF  MIR-LTST-STD-SEX-CD NOT = SPACES
                   AND RLABT-LTST-STD-SEX-CD  = HIGH-VALUES
                       MOVE 'N'       TO WS-INPUT-VALID-SW
      *MSG:            MESSAGE (S) 'SEX CODE MUST BE SPACES'
                       MOVE 'NS13700016'
                                      TO WGLOB-MSG-REF-INFO
557660             END-IF
557660         END-IF
557660     END-IF.

           IF WS-INPUT-INVALID
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

      *
      *    *** END BROWSE
      *
           PERFORM  LABT-3000-END-BROWSE
               THRU LABT-3000-END-BROWSE-X.

       4200-CROSS-EDIT-SEX-X.
           EXIT.

      *----------------------------------------------------------------
      *   MAINTAIN PROCESSING:
      *   FETCH AND LOCK RECORD, EDIT INCOMING DATA FIELDS, AND UPDATE
      *   RECORD
      *----------------------------------------------------------------
       5000-PROCESS-UPDATE.


016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           PERFORM  8000-BUILD-LABT-KEY
               THRU 8000-BUILD-LABT-KEY-X.

014221*    PERFORM  LABT-1000-READ-FOR-UPDATE
014221*        THRU LABT-1000-READ-FOR-UPDATE-X.

014221     PERFORM  LABT-2000-UPDATE-TWRK-TS
014221         THRU LABT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'        TO WGLOB-MSG-REF-INFO
014221         MOVE 'LABT'              TO WGLOB-MSG-PARM (01)
014221         MOVE WLABT-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  9100-BLANK-DATA-FIELDS
014221             THRU 9100-BLANK-DATA-FIELDS-X
014221           GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF NOT WLABT-IO-OK
               MOVE WLABT-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    MESSAGE (S) "LOST RECORD IN MAINTAIN (@1) - CONTACT SYSTE
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WLABT-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  9210-GET-DESCRIPTION
               THRU 9210-GET-DESCRIPTION-X.
           MOVE REDIT-ETBL-DESC-TXT   TO MIR-ETBL-DESC-TXT.


           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

               PERFORM  5400-CROSS-EDITS
                   THRU 5400-CROSS-EDITS-X.

           PERFORM  LABT-2000-REWRITE
               THRU LABT-2000-REWRITE-X.

014221     PERFORM  LABT-1000-READ-TWRK-TS
014221         THRU LABT-1000-READ-TWRK-TS-X.

           IF WS-INPUT-VALID
      *MSG:    MESSAGE (I) "MAINTENANCE COMPLETED - CONTINUE"
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    MESSAGE (I) "RECORD UPDATED".
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.

      *----------------------------------------------------------------
      *   FIELD EDITS: CHECK VALIDITY OF ALL DATA FIELDS.
      *----------------------------------------------------------------
       5300-EDIT-DATA-FIELDS.

           MOVE 'Y'                   TO WS-INPUT-VALID-SW.

018645     PERFORM  5305-EDIT-RESULT-TYPE
018645         THRU 5305-EDIT-RESULT-TYPE-X.
018645
           PERFORM  5310-EDIT-PRECISION-CODE
               THRU 5310-EDIT-PRECISION-CODE-X.


           PERFORM  5320-EDIT-COMPANY-MINIMUM
               THRU 5320-EDIT-COMPANY-MINIMUM-X.

           PERFORM  5330-EDIT-COMPANY-MAXIMUM
               THRU 5330-EDIT-COMPANY-MAXIMUM-X.

           PERFORM  5340-EDIT-LAB-MINIMUM
               THRU 5340-EDIT-LAB-MINIMUM-X.

           PERFORM  5350-EDIT-LAB-MAXIMUM
               THRU 5350-EDIT-LAB-MAXIMUM-X.

           PERFORM  5360-EDIT-UNITS
               THRU 5360-EDIT-UNITS-X.

           PERFORM  5370-EDIT-ALPHA
               THRU 5370-EDIT-ALPHA-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.

018645*----------------------------------------------------------------
018645*   EDIT RESULT TYPE CODE
018645*----------------------------------------------------------------
018645 5305-EDIT-RESULT-TYPE.
018645
018645     IF  MIR-TST-RSLT-TYP-CD = SPACE
018645         MOVE RLABT-TST-RSLT-TYP-CD TO MIR-TST-RSLT-TYP-CD
018645         GO TO 5305-EDIT-RESULT-TYPE-X
018645     END-IF.
018645
018645     IF  MIR-TST-RSLT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
018645         MOVE SPACE                 TO MIR-TST-RSLT-TYP-CD
018645     END-IF.
018645
018645     PERFORM  8960-1000-BUILD-PARM-INFO
018645         THRU 8960-1000-BUILD-PARM-INFO-X.
018645     MOVE 'TST-RSLT-TYP-CD'         TO L8960-AV-TBL-CD.
018645     MOVE MIR-TST-RSLT-TYP-CD       TO L8960-AV-CD.
018645
018645     PERFORM  8960-1000-VALIDATE-CODE
018645         THRU 8960-1000-VALIDATE-CODE-X.
018645
018645     IF  NOT L8960-RETRN-OK
018645*MSG: 'INVALID TEST RESULT TYPE'
018645         MOVE 'NS13700027'  TO WGLOB-MSG-REF-INFO
018645         PERFORM  0260-1000-GENERATE-MESSAGE
018645             THRU 0260-1000-GENERATE-MESSAGE-X
018645         MOVE 'N'           TO WS-INPUT-VALID-SW
018645         GO TO 5305-EDIT-RESULT-TYPE-X
018645     ELSE
018645         MOVE MIR-TST-RSLT-TYP-CD   TO RLABT-TST-RSLT-TYP-CD
018645     END-IF.
018645
018645 5305-EDIT-RESULT-TYPE-X.
018645     EXIT.

      *----------------------------------------------------------------
      *   EDIT PRECISION CODE - BLANK OR NUMERIC
      *----------------------------------------------------------------
       5310-EDIT-PRECISION-CODE.


018645*    IF MIR-RSLT-PRECSN-QTY = SPACE
018645*    AND RLABT-RSLT-PRECSN-QTY = SPACES
018645     IF  MIR-TST-RSLT-TYP-CD = '3'
018645     AND RLABT-TST-RSLT-TYP-CD = '3'
018645     AND MIR-RSLT-PRECSN-QTY = ZERO
               IF ( MIR-CO-MIN-NRNG-QTY = SPACES OR
                    MIR-CO-MIN-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR)
               AND (MIR-CO-MAX-NRNG-QTY = SPACES OR
                    MIR-CO-MAX-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR)
               AND (MIR-LAB-MIN-NRNG-QTY = SPACES OR
                    MIR-LAB-MIN-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR)
               AND (MIR-LAB-MAX-NRNG-QTY = SPACES OR
                    MIR-LAB-MAX-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR)
               AND (MIR-UNIT-MESUR-TXT = SPACES OR
                    MIR-UNIT-MESUR-TXT = EBLCH-BLANK-FIELD-CHAR)
               AND (MIR-ALPHA-RESP-ETBL-ID = SPACES OR
                    MIR-ALPHA-RESP-ETBL-ID = EBLCH-BLANK-FIELD-CHAR)
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *MSG:        MESSAGE (S) 'PRECISION REQUIRED IF RANGE OR UNIT ...'
                   MOVE 'NS13700017'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   GO TO 5310-EDIT-PRECISION-CODE-X
557660         END-IF
557660     END-IF.

           IF MIR-RSLT-PRECSN-QTY = SPACE
018645*        MOVE RLABT-RSLT-PRECSN-QTY
018645*                               TO MIR-RSLT-PRECSN-QTY
018645         MOVE ZERO              TO L0290-PRECISION
018645         MOVE LENGTH OF MIR-RSLT-PRECSN-QTY
018645                                TO L0290-MAX-OUT-LEN
018645         MOVE RLABT-RSLT-PRECSN-QTY
018645                                TO L0290-INPUT-NUMBER
018645         PERFORM 0290-2000-FORMAT-FOR-MIR
018645            THRU 0290-2000-FORMAT-FOR-MIR-X
018645         MOVE L0290-OUTPUT-DATA TO MIR-RSLT-PRECSN-QTY
               GO TO 5310-EDIT-PRECISION-CODE-X
557660     END-IF.

           IF  MIR-RSLT-PRECSN-QTY     = EBLCH-BLANK-FIELD-CHAR
018645*        MOVE SPACES            TO MIR-RSLT-PRECSN-QTY
018645         MOVE ZERO              TO MIR-RSLT-PRECSN-QTY
               PERFORM  5311-INIT-RANGES
                   THRU 5311-INIT-RANGES-X
               MOVE SPACES            TO MIR-ALPHA-RESP-ETBL-ID
               MOVE SPACES            TO RLABT-ALPHA-RESP-ETBL-ID
018645*        IF RLABT-RSLT-PRECSN-ALPHA-VALUE
018645         IF RLABT-TST-RSLT-TYP-CD = '1'
      *MSG:        'ALPHA RESULT EDIT POINTER SET TO SPACES'
018645*            MOVE SPACES        TO RLABT-RSLT-PRECSN-QTY
018645             MOVE ZERO          TO RLABT-RSLT-PRECSN-QTY
                   MOVE 'NS13700020'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5310-EDIT-PRECISION-CODE-X
               ELSE
018645*            IF RLABT-RSLT-PRECSN-QTY NOT = SPACES
018645             IF RLABT-TST-RSLT-TYP-CD NOT = '3'
      *MSG:            CMPNY & LAB RANGE & UNIT OF MEASURE SET TO SPACES
018645*                MOVE SPACES    TO RLABT-RSLT-PRECSN-QTY
018645                 MOVE ZERO      TO RLABT-RSLT-PRECSN-QTY
                       MOVE 'NS13700018'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE SPACES    TO RLABT-ALPHA-RESP-ETBL-ID
                       GO TO 5310-EDIT-PRECISION-CODE-X
557660             END-IF
557660         END-IF
557660     END-IF.

018645*    IF  MIR-RSLT-PRECSN-QTY = 'A'
018645     IF  MIR-TST-RSLT-TYP-CD = '1'
018645*        MOVE MIR-RSLT-PRECSN-QTY
018645         MOVE ZERO
                                      TO RLABT-RSLT-PRECSN-QTY
      *MSG:        CMPNY & LAB RANGE & UNIT OF MEAURE SET TO SPACES
               PERFORM  5311-INIT-RANGES
                   THRU 5311-INIT-RANGES-X
               MOVE 'NS13700018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
018645         IF MIR-RSLT-PRECSN-QTY NOT EQUAL ZERO
018645*MSG: TEST PRECISION SHOULD ONLY BE DEFINED WHEN RESULT
018645*     TYPE IS 'NUMBER'.
018645             MOVE 'NS13700028'  TO WGLOB-MSG-REF-INFO
018645             PERFORM  0260-1000-GENERATE-MESSAGE
018645                THRU 0260-1000-GENERATE-MESSAGE-X
018645             MOVE ZERO          TO MIR-RSLT-PRECSN-QTY
018645         END-IF
               GO TO 5310-EDIT-PRECISION-CODE-X
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 1                     TO L0280-LENGTH.
           MOVE +0                    TO L0280-PRECISION.
           MOVE MIR-RSLT-PRECSN-QTY   TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:    MESSAGE (S) 'PRECISION IS INVALID - MUST BE 0 THRU 7'
               MOVE 'NS13700005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 5310-EDIT-PRECISION-CODE-X
557660     END-IF.

           IF L0280-OUTPUT < ZERO
           OR L0280-OUTPUT > 7
      *MSG:    MESSAGE (S) 'PRECISION IS INVALID - MUST BE 0 THRU 7'
               MOVE 'NS13700005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 5310-EDIT-PRECISION-CODE-X
557660     END-IF.
      *
      *    PRECISION IS A VALID NUMERIC, THEREFORE THE ALPHA
      *    RESPONSE SHOULD BE SPACES.
      *
      *      MESSAGE (I) 'ALPHA RESPONSE SET TO SPACES'
      *
      *    IF THE PRECISION IS CHANGED, THE RANGE FIELDS MUST BE
      *    ADJUSTED TO REFLECT THIS.  NOTE THAT SIGNIFICANT DIGITS
      *    CAN BE LOST (FROM EITHER END) WHEN PRECISION IS CHANGED.
      *    THIS IS NOT NECESSARY IF THE PREVIOUS PRECISION WAS BLANK.
      *
018645*    IF  RLABT-RSLT-PRECSN-QTY = SPACE
018645*    OR  RLABT-RSLT-PRECSN-ALPHA-VALUE
018645     IF  RLABT-TST-RSLT-TYP-CD NOT = '2'
018645*        MOVE MIR-RSLT-PRECSN-QTY
018645         MOVE ZERO
                                      TO RLABT-RSLT-PRECSN-QTY
018645         IF  MIR-RSLT-PRECSN-QTY NOT EQUAL ZERO
018645*MSG: TEST PRECISION SHOULD ONLY BE DEFINED WHEN RESULT
018645*     TYPE IS 'NUMBER'.
018645            MOVE 'NS13700028'   TO WGLOB-MSG-REF-INFO
018645            PERFORM  0260-1000-GENERATE-MESSAGE
018645                THRU 0260-1000-GENERATE-MESSAGE-X
018645            MOVE ZERO           TO MIR-RSLT-PRECSN-QTY
018645         END-IF
               GO TO 5310-EDIT-PRECISION-CODE-X
557660     END-IF.

           COMPUTE WS-ADJUST-FACTOR = L0280-OUTPUT
018645*                                - RLABT-RSLT-PRECSN-QTY-N.
018645                                 - RLABT-RSLT-PRECSN-QTY.

           IF WS-ADJUST-FACTOR NOT = ZERO
      *MSG:    MESSAGE (I) 'COMPANY OR LAB RANGES MAY BE TRUNCATED.'
               MOVE 'NS13700019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF WS-ADJUST-FACTOR < 0
               COMPUTE WS-ADJUST-FACTOR = WS-ADJUST-FACTOR * -1
               COMPUTE RLABT-CO-MIN-NRNG-QTY  =
                       RLABT-CO-MIN-NRNG-QTY  / (10 ** WS-ADJUST-FACTOR)
               COMPUTE RLABT-CO-MAX-NRNG-QTY  =
                       RLABT-CO-MAX-NRNG-QTY  / (10 ** WS-ADJUST-FACTOR)
               COMPUTE RLABT-LAB-MIN-NRNG-QTY =
                       RLABT-LAB-MIN-NRNG-QTY / (10 ** WS-ADJUST-FACTOR)
               COMPUTE RLABT-LAB-MAX-NRNG-QTY =
                       RLABT-LAB-MAX-NRNG-QTY / (10 ** WS-ADJUST-FACTOR)
           ELSE
               IF WS-ADJUST-FACTOR > 0
                  COMPUTE RLABT-CO-MIN-NRNG-QTY  =
                      RLABT-CO-MIN-NRNG-QTY  * (10 ** WS-ADJUST-FACTOR)
                  COMPUTE RLABT-CO-MAX-NRNG-QTY  =
                      RLABT-CO-MAX-NRNG-QTY  * (10 ** WS-ADJUST-FACTOR)
                  COMPUTE RLABT-LAB-MIN-NRNG-QTY =
                      RLABT-LAB-MIN-NRNG-QTY * (10 ** WS-ADJUST-FACTOR)
                  COMPUTE RLABT-LAB-MAX-NRNG-QTY =
                      RLABT-LAB-MAX-NRNG-QTY * (10 ** WS-ADJUST-FACTOR)
557660         END-IF
557660     END-IF.

018645*    MOVE MIR-RSLT-PRECSN-QTY   TO RLABT-RSLT-PRECSN-QTY.
018645     MOVE L0280-OUTPUT          TO RLABT-RSLT-PRECSN-QTY.

       5310-EDIT-PRECISION-CODE-X.
           EXIT.

      *----------------------------------------------------------------
      *   RE-INITIALIZE THE RANGE FIELDS.
      *----------------------------------------------------------------
       5311-INIT-RANGES.

           MOVE SPACES                TO MIR-CO-MIN-NRNG-QTY.
           MOVE SPACES                TO MIR-CO-MAX-NRNG-QTY.
           MOVE SPACES                TO MIR-LAB-MIN-NRNG-QTY.
           MOVE SPACES                TO MIR-LAB-MAX-NRNG-QTY.
           MOVE SPACES                TO MIR-UNIT-MESUR-TXT.
           MOVE SPACES                TO RLABT-UNIT-MESUR-TXT.
           MOVE ZEROS                 TO RLABT-CO-MIN-NRNG-QTY.
           MOVE ZEROS                 TO RLABT-CO-MAX-NRNG-QTY.
           MOVE ZEROS                 TO RLABT-LAB-MIN-NRNG-QTY.
           MOVE ZEROS                 TO RLABT-LAB-MAX-NRNG-QTY.

       5311-INIT-RANGES-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT COMPANY MINIMUM RANGE VALUE
      *----------------------------------------------------------------
       5320-EDIT-COMPANY-MINIMUM.

018645*    IF  RLABT-RSLT-PRECSN-ALPHA-VALUE
018645*    OR  RLABT-RSLT-PRECSN-QTY  = SPACES
018645     IF  RLABT-TST-RSLT-TYP-CD NOT = '2'
               IF  MIR-CO-MIN-NRNG-QTY = SPACES
               OR  MIR-CO-MIN-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROES        TO RLABT-CO-MIN-NRNG-QTY
                   MOVE SPACES        TO MIR-CO-MIN-NRNG-QTY
               ELSE
      *MSG:        MESSAGE 'COMPANY MINIMUM NOT ALLOWED FOR ALPHA TEST'
                   MOVE 'NS13700022'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   GO TO 5320-EDIT-COMPANY-MINIMUM-X
557660         END-IF
557660     END-IF.

           IF MIR-CO-MIN-NRNG-QTY = SPACE
               MOVE RLABT-CO-MIN-NRNG-QTY
                                      TO WS-RESULT-NUM
               PERFORM  8200-DISPLAY-RESULT
                   THRU 8200-DISPLAY-RESULT-X
               MOVE L0290-OUTPUT-DATA TO MIR-CO-MIN-NRNG-QTY
               GO TO 5320-EDIT-COMPANY-MINIMUM-X
557660     END-IF.

           IF MIR-CO-MIN-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-CO-MIN-NRNG-QTY
557660     END-IF.

           MOVE MIR-CO-MIN-NRNG-QTY   TO WS-RESULT-SCREEN.

013578     MOVE LENGTH OF MIR-CO-MIN-NRNG-QTY TO L0280-INPUT-SIZE.

           PERFORM  8100-EDIT-RESULT
               THRU 8100-EDIT-RESULT-X.

           IF NOT L0280-OK
      *MSG:    MESSAGE (S) 'COMPANY MINIMUM RESULT MUST BE A VALID NUMER
               MOVE 'NS13700008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 5320-EDIT-COMPANY-MINIMUM-X
557660     END-IF.

           MOVE L0280-OUTPUT          TO RLABT-CO-MIN-NRNG-QTY.
           MOVE RLABT-CO-MIN-NRNG-QTY TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CO-MIN-NRNG-QTY.

       5320-EDIT-COMPANY-MINIMUM-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT COMPANY MAXIMUM RANGE VALUE
      *----------------------------------------------------------------
       5330-EDIT-COMPANY-MAXIMUM.

018645*    IF  RLABT-RSLT-PRECSN-ALPHA-VALUE
018645*    OR  RLABT-RSLT-PRECSN-QTY  = SPACES
018645     IF  RLABT-TST-RSLT-TYP-CD NOT = '2'
               IF  MIR-CO-MAX-NRNG-QTY = SPACES
               OR  MIR-CO-MAX-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROES        TO RLABT-CO-MAX-NRNG-QTY
                   MOVE SPACES        TO MIR-CO-MAX-NRNG-QTY
               ELSE
      *MSG:        MESSAGE 'COMPANY MAXIMUM NOT ALLOWED FOR ALPHA TEST'
                   MOVE 'NS13700023'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   GO TO 5330-EDIT-COMPANY-MAXIMUM-X
557660         END-IF
557660     END-IF.

           IF MIR-CO-MAX-NRNG-QTY = SPACE
               MOVE RLABT-CO-MAX-NRNG-QTY
                                      TO WS-RESULT-NUM
               PERFORM  8200-DISPLAY-RESULT
                   THRU 8200-DISPLAY-RESULT-X
               MOVE L0290-OUTPUT-DATA TO MIR-CO-MAX-NRNG-QTY
               GO TO 5330-EDIT-COMPANY-MAXIMUM-X
557660     END-IF.

           IF MIR-CO-MAX-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-CO-MAX-NRNG-QTY
557660     END-IF.

           MOVE MIR-CO-MAX-NRNG-QTY   TO WS-RESULT-SCREEN.

013578     MOVE LENGTH OF MIR-CO-MAX-NRNG-QTY TO L0280-INPUT-SIZE.

           PERFORM  8100-EDIT-RESULT
               THRU 8100-EDIT-RESULT-X.

           IF NOT L0280-OK
      *MSG:    MESSAGE (S) 'COMPANY MAXIMUM RESULT MUST BE A VALID NUMER
               MOVE 'NS13700009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 5330-EDIT-COMPANY-MAXIMUM-X
557660     END-IF.

           MOVE L0280-OUTPUT          TO RLABT-CO-MAX-NRNG-QTY.
           MOVE RLABT-CO-MAX-NRNG-QTY TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CO-MAX-NRNG-QTY.

       5330-EDIT-COMPANY-MAXIMUM-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT LAB MINIMUM RANGE VALUE
      *----------------------------------------------------------------
       5340-EDIT-LAB-MINIMUM.

018645*    IF  RLABT-RSLT-PRECSN-ALPHA-VALUE
018645*    OR  RLABT-RSLT-PRECSN-QTY  = SPACES
018645     IF  RLABT-TST-RSLT-TYP-CD NOT = '2'
               IF  MIR-LAB-MIN-NRNG-QTY = SPACES
               OR  MIR-LAB-MIN-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROES        TO RLABT-LAB-MIN-NRNG-QTY
                   MOVE SPACES        TO MIR-LAB-MIN-NRNG-QTY
               ELSE
      *MSG:        MESSAGE 'LAB MINIMUM NOT ALLOWED FOR ALPHA TEST'
                   MOVE 'NS13700024'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   GO TO 5340-EDIT-LAB-MINIMUM-X
557660         END-IF
557660     END-IF.

           IF MIR-LAB-MIN-NRNG-QTY = SPACE
               MOVE RLABT-LAB-MIN-NRNG-QTY
                                      TO WS-RESULT-NUM
               PERFORM  8200-DISPLAY-RESULT
                   THRU 8200-DISPLAY-RESULT-X
               MOVE L0290-OUTPUT-DATA TO MIR-LAB-MIN-NRNG-QTY
               GO TO 5340-EDIT-LAB-MINIMUM-X
557660     END-IF.

           IF MIR-LAB-MIN-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-LAB-MIN-NRNG-QTY
557660     END-IF.

           MOVE MIR-LAB-MIN-NRNG-QTY  TO WS-RESULT-SCREEN.
013578     MOVE LENGTH OF MIR-LAB-MIN-NRNG-QTY TO L0280-INPUT-SIZE.

           PERFORM  8100-EDIT-RESULT
               THRU 8100-EDIT-RESULT-X.

           IF NOT L0280-OK
      *MSG:    MESSAGE (S) 'LAB MINIMUM RESULT MUST BE A VALID NUMERIC'
               MOVE 'NS13700010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 5340-EDIT-LAB-MINIMUM-X
557660     END-IF.

           MOVE L0280-OUTPUT          TO RLABT-LAB-MIN-NRNG-QTY.
           MOVE RLABT-LAB-MIN-NRNG-QTY                 TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-LAB-MIN-NRNG-QTY.

       5340-EDIT-LAB-MINIMUM-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT LAB MAXIMUM RANGE VALUE
      *----------------------------------------------------------------
       5350-EDIT-LAB-MAXIMUM.

018645*    IF  RLABT-RSLT-PRECSN-ALPHA-VALUE
018645*    OR  RLABT-RSLT-PRECSN-QTY  = SPACES
018645     IF  RLABT-TST-RSLT-TYP-CD NOT = '2'
               IF  MIR-LAB-MAX-NRNG-QTY = SPACES
               OR  MIR-LAB-MAX-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROES        TO RLABT-LAB-MAX-NRNG-QTY
                   MOVE SPACES        TO MIR-LAB-MAX-NRNG-QTY
               ELSE
      *MSG:        MESSAGE 'LAB MAXIMUM NOT ALLOWED FOR ALPHA TEST'
                   MOVE 'NS13700026'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   GO TO 5350-EDIT-LAB-MAXIMUM-X
557660         END-IF
557660     END-IF.

           IF MIR-LAB-MAX-NRNG-QTY = SPACE
               MOVE RLABT-LAB-MAX-NRNG-QTY
                                      TO WS-RESULT-NUM
               PERFORM  8200-DISPLAY-RESULT
                   THRU 8200-DISPLAY-RESULT-X
               MOVE L0290-OUTPUT-DATA TO MIR-LAB-MAX-NRNG-QTY
               GO TO 5350-EDIT-LAB-MAXIMUM-X
557660     END-IF.

           IF MIR-LAB-MAX-NRNG-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-LAB-MAX-NRNG-QTY
557660     END-IF.

           MOVE MIR-LAB-MAX-NRNG-QTY  TO WS-RESULT-SCREEN.

013578     MOVE LENGTH OF MIR-LAB-MAX-NRNG-QTY TO L0280-INPUT-SIZE.

           PERFORM  8100-EDIT-RESULT
               THRU 8100-EDIT-RESULT-X.

           IF NOT L0280-OK
               MOVE 'NS13700011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 5350-EDIT-LAB-MAXIMUM-X
557660     END-IF.

           MOVE L0280-OUTPUT          TO RLABT-LAB-MAX-NRNG-QTY.
           MOVE RLABT-LAB-MAX-NRNG-QTY                 TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-LAB-MAX-NRNG-QTY.

       5350-EDIT-LAB-MAXIMUM-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT UNIT OF MEASURE - COMMENT ONLY
      *----------------------------------------------------------------
       5360-EDIT-UNITS.

018645*    IF  RLABT-RSLT-PRECSN-ALPHA-VALUE
018645     IF  RLABT-TST-RSLT-TYP-CD = '1'
               IF  MIR-UNIT-MESUR-TXT = SPACES
               OR  MIR-UNIT-MESUR-TXT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO RLABT-UNIT-MESUR-TXT
                   MOVE SPACES        TO MIR-UNIT-MESUR-TXT
                   GO TO 5360-EDIT-UNITS-X
               ELSE
      *MSG:        MESSAGE 'UNIT OF MEASURE NOT ALLOWED FOR ALPHA TEST'
                   MOVE 'NS13700021'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   GO TO 5360-EDIT-UNITS-X
557660         END-IF
557660     END-IF.

           IF MIR-UNIT-MESUR-TXT = SPACE
               MOVE RLABT-UNIT-MESUR-TXT
                                      TO MIR-UNIT-MESUR-TXT
               GO TO 5360-EDIT-UNITS-X
557660     END-IF.

           IF MIR-UNIT-MESUR-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-UNIT-MESUR-TXT
557660     END-IF.

           MOVE MIR-UNIT-MESUR-TXT    TO RLABT-UNIT-MESUR-TXT.

       5360-EDIT-UNITS-X.
           EXIT.

      *----------------------------------------------------------------
      *   EDIT LAB ALPHA VALUE
      *----------------------------------------------------------------
       5370-EDIT-ALPHA.

018645*    IF  MIR-RSLT-PRECSN-QTY  = 'A'
018645     IF  MIR-TST-RSLT-TYP-CD  = '1'
               IF  MIR-ALPHA-RESP-ETBL-ID = SPACE
                   MOVE RLABT-ALPHA-RESP-ETBL-ID
                                      TO MIR-ALPHA-RESP-ETBL-ID
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               IF  MIR-ALPHA-RESP-ETBL-ID = SPACE
                   MOVE RLABT-ALPHA-RESP-ETBL-ID
                                      TO MIR-ALPHA-RESP-ETBL-ID
                   GO TO 5370-EDIT-ALPHA-X
557660         END-IF
557660     END-IF.

           IF  MIR-ALPHA-RESP-ETBL-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-ALPHA-RESP-ETBL-ID
018645*        IF  RLABT-RSLT-PRECSN-QTY NUMERIC
018645*        OR  RLABT-RSLT-PRECSN-QTY = SPACES
018645         IF  RLABT-TST-RSLT-TYP-CD NOT = '1'
                   MOVE SPACES        TO RLABT-ALPHA-RESP-ETBL-ID
                   GO TO 5370-EDIT-ALPHA-X
557660         END-IF
557660     END-IF.

      *
      *  THIS NEXT EDIT IS REALLY A CROSS EDIT, HOWEVER, IT MUST BE
      *  HERE TO ALLOW THE RECORD TO BE UPDATED PROPERLY.
      *
018645*    IF  MIR-RSLT-PRECSN-QTY  = SPACES
018645*    AND RLABT-RSLT-PRECSN-QTY = SPACES
018645     IF  MIR-TST-RSLT-TYP-CD = '3'
018645     AND RLABT-TST-RSLT-TYP-CD = '3'
               GO TO 5370-EDIT-ALPHA-X
557660     END-IF.

      *
      *  SEE IF A TABLE EXISTS BY THE INPUT NAME
      *
           MOVE MIR-ALPHA-RESP-ETBL-ID             TO WEDIT-ETBL-VALU-ID
           PERFORM  EDIT-1000-EDIT-TYPE
               THRU EDIT-1000-EDIT-TYPE-X
              IF WEDIT-IO-OK
                  MOVE MIR-ALPHA-RESP-ETBL-ID
                                      TO RLABT-ALPHA-RESP-ETBL-ID
              ELSE
                  MOVE 'NS13700025'   TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                  MOVE 'N'            TO WS-INPUT-VALID-SW
557660        END-IF.

       5370-EDIT-ALPHA-X.
           EXIT.
      *----------------------------------------------------------------
      *   PERFORM  CROSS EDITS AGAINST FILE FIELDS
      *----------------------------------------------------------------
       5400-CROSS-EDITS.

           IF RLABT-CO-MIN-NRNG-QTY  > RLABT-CO-MAX-NRNG-QTY
      *MSG:    MESSAGE (W) 'COMPANY MINIMUM EXCEEDS COMPANY MAXIMUM'
               MOVE 'NS13700012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-INPUT-VALID-SW
557660         END-IF
557660     END-IF.

           IF RLABT-LAB-MIN-NRNG-QTY > RLABT-LAB-MAX-NRNG-QTY
      *MSG:    MESSAGE (W) 'LAB MINIMUM EXCEEDS LAB MAXIMUM'
               MOVE 'NS13700013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-INPUT-VALID-SW
557660         END-IF
557660     END-IF.

       5400-CROSS-EDITS-X.
           EXIT.

      *----------------------------------------------------------------
      *   DELETE PROCESSING:
      *----------------------------------------------------------------
       6000-PROCESS-DELETE.


016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           PERFORM  8000-BUILD-LABT-KEY
               THRU 8000-BUILD-LABT-KEY-X.
014221*    PERFORM  LABT-1000-READ-FOR-UPDATE
014221*        THRU LABT-1000-READ-FOR-UPDATE-X.

014221     PERFORM  LABT-2000-UPDATE-TWRK-TS
014221         THRU LABT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'        TO WGLOB-MSG-REF-INFO
014221         MOVE 'LABT'              TO WGLOB-MSG-PARM (01)
014221         MOVE WLABT-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  9100-BLANK-DATA-FIELDS
014221             THRU 9100-BLANK-DATA-FIELDS-X
014221           GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF NOT WLABT-IO-OK
      *MSG:    MESSAGE (S) "LOST RECORD IN DELETE (@1) - CONTACT SYSTEMS
               MOVE WLABT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  LABT-1000-DELETE
                   THRU LABT-1000-DELETE-X
      *MSG:    MESSAGE (I) "DELETE COMPLETED - CONTINUE"
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.


       6000-PROCESS-DELETE-X.
           EXIT.

      *----------------------------------------------------------------
      *   BUILD LABT READ KEY.
      *----------------------------------------------------------------
       8000-BUILD-LABT-KEY.

           MOVE MIR-LAB-ID            TO WLABT-LAB-ID.
           MOVE MIR-LTST-ID           TO WLABT-LTST-ID.
           MOVE MIR-LTST-STD-SEX-CD   TO WS-SEX-MIR.
           PERFORM  8510-TRANSLATE-SEX-2
               THRU 8510-TRANSLATE-SEX-2-X.
           MOVE WS-SEX-FILE           TO WLABT-LTST-STD-SEX-CD.
           MOVE MIR-LTST-STD-AGE-QTY  TO WLABT-LTST-STD-AGE-QTY.

       8000-BUILD-LABT-KEY-X.
           EXIT.

      *----------------------------------------------------------------
      *   PERFORM  A NUMERIC EDIT ON A RESULT RANGE VALUE
      *----------------------------------------------------------------
       8100-EDIT-RESULT.

018645*    MOVE RLABT-RSLT-PRECSN-QTY-N
018645     MOVE RLABT-RSLT-PRECSN-QTY
                                      TO L0280-PRECISION.

           IF L0280-PRECISION = ZERO
               MOVE WLABT-RESULT-SIZE TO L0280-LENGTH
           ELSE
               COMPUTE L0280-LENGTH =
                       WLABT-RESULT-SIZE - L0280-PRECISION
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE WS-RESULT-SCREEN      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

       8100-EDIT-RESULT-X.
           EXIT.

      *----------------------------------------------------------------
      *   DISPLAY A TEST RESULT RANGE VALUE
      *----------------------------------------------------------------
       8200-DISPLAY-RESULT.

018645*    IF RLABT-RSLT-PRECSN-QTY = SPACES
018645*    OR RLABT-RSLT-PRECSN-ALPHA-VALUE
018645     IF  RLABT-TST-RSLT-TYP-CD NOT = '2'
               MOVE SPACES            TO L0290-OUTPUT-DATA
               GO TO 8200-DISPLAY-RESULT-X
557660     END-IF.

018645*    MOVE RLABT-RSLT-PRECSN-QTY-N
018645     MOVE RLABT-RSLT-PRECSN-QTY
                                      TO L0290-PRECISION.

008455*****IF L0290-PRECISION = ZERO
008455*****    MOVE WLABT-RESULT-SIZE      TO L0290-LENGTH
008455*****    ADD +1                      TO L0290-LENGTH
008455*****ELSE
008455*****    COMPUTE L0290-LENGTH =
008455*****            WLABT-RESULT-SIZE - L0290-PRECISION
008455*****END-IF.

           MOVE +8                    TO L0290-MAX-OUT-LEN.

008455*    MOVE 'N'                        TO L0290-SIGN-IND.
008455*    MOVE WS-RESULT-FILE             TO L0290-INPUT-DATA.
           MOVE WS-RESULT-NUM         TO L0290-INPUT-NUMBER.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS   TO TRUE.
           MOVE SPACES                TO L0290-OUTPUT-DATA.

020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

       8200-DISPLAY-RESULT-X.
           EXIT.

      *----------------------------------------------------------------
      *   BUILD PAGING KEY: SET KEY FOR START OF INQUIRY DISPLAY
      *----------------------------------------------------------------
       8300-SET-PAGING-KEY.

      *
      *    *** IF ANYTHING BUT PAGING IND HAS CHANGED, START FROM WHAT
      *    *** IS ENTERED IN KEY FIELDS
      *
018633*    IF  MIR-LAB-ID NOT = WS-SCREEN-LAB-CODE
018633*    OR  MIR-LTST-ID NOT = WS-SCREEN-TEST-NUMBER
018633*    OR  MIR-LTST-STD-AGE-QTY NOT = WS-SCREEN-HIGH-AGE
018633*    OR  MIR-LTST-STD-SEX-CD NOT = WS-SCREEN-SEX
018633*    OR  MIR-BUS-FCN-ID NOT = WS-SCREEN-ENTER-CODE
018633     IF  MIR-LAB-ID NOT = LCOMM-LAB-CODE
018633     OR  MIR-LTST-ID NOT = LCOMM-TEST-NUMBER
018633     OR  MIR-LTST-STD-AGE-QTY NOT = LCOMM-HIGH-AGE
018633     OR  MIR-LTST-STD-SEX-CD NOT = LCOMM-SEX
018633     OR  MIR-BUS-FCN-ID NOT = LCOMM-ENTER-CODE
               PERFORM  8000-BUILD-LABT-KEY
                   THRU 8000-BUILD-LABT-KEY-X
               GO TO 8300-SET-PAGING-KEY-X
557660     END-IF.



       8300-SET-PAGING-KEY-X.
           EXIT.

      *----------------------------------------------------------------
      *   TRANSLATE SEX: TRANSLATE SEX ON RECORD TO SEX FOR MIR
      *----------------------------------------------------------------
       8500-TRANSLATE-SEX-1.

           IF WS-SEX-FILE = HIGH-VALUES
               MOVE SPACES            TO WS-SEX-MIR
           ELSE
               MOVE WS-SEX-FILE       TO WS-SEX-MIR
557660     END-IF.

       8500-TRANSLATE-SEX-1-X.
           EXIT.

      *----------------------------------------------------------------
      *   TRANSLATE SEX: TRANSLATE SEX ON MIR TO SEX ON RECORD
      *----------------------------------------------------------------
       8510-TRANSLATE-SEX-2.

           IF WS-SEX-MIR = SPACES
               MOVE HIGH-VALUES       TO WS-SEX-FILE
           ELSE
               MOVE WS-SEX-MIR        TO WS-SEX-FILE
557660     END-IF.

       8510-TRANSLATE-SEX-2-X.
           EXIT.

      *----------------------------------------------------------------
      *   BLANK DATA FIELDS: SET EACH DATA (NON-KEY AND NON-CONTROL)
      *   FIELD ON THE SCREEN TO SPACES.
      *----------------------------------------------------------------
       9100-BLANK-DATA-FIELDS.

           IF WS-BUS-FCN-LIST
               PERFORM  9110-BLANK-DATA-LINE
                   THRU 9110-BLANK-DATA-LINE-X
                       VARYING WS-LINE FROM 1 BY 1
                           UNTIL WS-LINE > WS-MAX-LINES-PER-SCREEN
           ELSE
               PERFORM  9120-BLANK-DATA2
                   THRU 9120-BLANK-DATA2-X
557660     END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *----------------------------------------------------------------
      *   BLANK ALL THE FIELDS ON ONE LINE OF SCREEN
      *----------------------------------------------------------------
       9110-BLANK-DATA-LINE.

           MOVE SPACE             TO MIR-LTST-ID-T (WS-LINE).
           MOVE SPACE             TO MIR-LTST-STD-AGE-QTY-T (WS-LINE).
           MOVE SPACE             TO MIR-LTST-STD-SEX-CD-T (WS-LINE).
           MOVE SPACE             TO MIR-ETBL-DESC-TXT-T (WS-LINE).
           MOVE SPACE             TO MIR-RSLT-PRECSN-QTY-T (WS-LINE).
018645     MOVE SPACE             TO MIR-TST-RSLT-TYP-CD-T (WS-LINE).
           MOVE SPACE             TO MIR-CO-MIN-NRNG-QTY-T (WS-LINE).
           MOVE SPACE             TO MIR-CO-MAX-NRNG-QTY-T (WS-LINE).
           MOVE SPACE             TO MIR-LAB-MIN-NRNG-QTY-T (WS-LINE).
           MOVE SPACE             TO MIR-LAB-MAX-NRNG-QTY-T (WS-LINE).
           MOVE SPACE             TO MIR-ALPHA-RESP-ETBL-ID-T (WS-LINE).

       9110-BLANK-DATA-LINE-X.
           EXIT.

       9120-BLANK-DATA2.

           MOVE SPACE             TO MIR-ETBL-DESC-TXT.
           MOVE SPACE             TO MIR-RSLT-PRECSN-QTY.
018645     MOVE SPACE             TO MIR-TST-RSLT-TYP-CD.
           MOVE SPACE             TO MIR-CO-MIN-NRNG-QTY.
           MOVE SPACE             TO MIR-CO-MAX-NRNG-QTY.
           MOVE SPACE             TO MIR-LAB-MIN-NRNG-QTY.
           MOVE SPACE             TO MIR-LAB-MAX-NRNG-QTY.
           MOVE SPACE             TO MIR-UNIT-MESUR-TXT.
           MOVE SPACE             TO MIR-ALPHA-RESP-ETBL-ID.

       9120-BLANK-DATA2-X.
           EXIT.

      *----------------------------------------------------------------
      *   RECORD TO SCREEN:                          INPUT: WS -LINE
      *   SHIFT DATA FROM RECORD BUFFER TO THE SCREEN DISPLAY LINE
      *   INDICATED BY THE INPUT ITEM WS-LINE.
      *----------------------------------------------------------------
       9200-MOVE-RECORD-TO-SCREEN.


           PERFORM  9210-GET-DESCRIPTION
               THRU 9210-GET-DESCRIPTION-X.

           IF WS-BUS-FCN-LIST
               PERFORM  9220-MOVE-TO-SCREEN-1
                   THRU 9220-MOVE-TO-SCREEN-1-X
           ELSE
               PERFORM  9230-MOVE-TO-SCREEN-2
                   THRU 9230-MOVE-TO-SCREEN-2-X
557660     END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.


       9210-GET-DESCRIPTION.

      *
      **** ONLY GET TEST DESCRIPTION ON CHANGE IN TEST
      *
           IF RLABT-LTST-ID NOT = WEDIT-ETBL-VALU-ID
               MOVE RLABT-LTST-ID     TO WEDIT-ETBL-VALU-ID
               PERFORM  TSTN-2000-DESC
                   THRU TSTN-2000-DESC-X
557660     END-IF.

       9210-GET-DESCRIPTION-X.
           EXIT.

       9220-MOVE-TO-SCREEN-1.

           MOVE RLABT-LTST-ID         TO MIR-LTST-ID-T (WS-LINE).
           MOVE RLABT-LTST-STD-AGE-QTY
                                    TO MIR-LTST-STD-AGE-QTY-T (WS-LINE).

           MOVE REDIT-ETBL-DESC-TXT   TO MIR-ETBL-DESC-TXT-T (WS-LINE).

           MOVE RLABT-LTST-STD-SEX-CD TO WS-SEX-FILE.
           PERFORM  8500-TRANSLATE-SEX-1
               THRU 8500-TRANSLATE-SEX-1-X.
           MOVE WS-SEX-MIR           TO MIR-LTST-STD-SEX-CD-T (WS-LINE).
018645     MOVE RLABT-TST-RSLT-TYP-CD TO MIR-TST-RSLT-TYP-CD-T
018645                                   (WS-LINE).

018645*    MOVE RLABT-RSLT-PRECSN-QTY
018645*                              TO MIR-RSLT-PRECSN-QTY-T (WS-LINE).
018645     MOVE ZERO                 TO L0290-PRECISION .
018645     MOVE LENGTH OF MIR-RSLT-PRECSN-QTY-T (WS-LINE)
018645                               TO L0290-MAX-OUT-LEN.
018645     MOVE RLABT-RSLT-PRECSN-QTY
018645                               TO L0290-INPUT-NUMBER.
018645     PERFORM 0290-2000-FORMAT-FOR-MIR
018645        THRU 0290-2000-FORMAT-FOR-MIR-X.
018645     MOVE L0290-OUTPUT-DATA    TO MIR-RSLT-PRECSN-QTY-T
018645                                  (WS-LINE).

018645*    IF  RLABT-RSLT-PRECSN-ALPHA-VALUE
018645     IF  RLABT-TST-RSLT-TYP-CD = '1'
               MOVE SPACES           TO MIR-LAB-MAX-NRNG-QTY-T (WS-LINE)
               MOVE SPACES            TO MIR-CO-MIN-NRNG-QTY-T (WS-LINE)
               MOVE SPACES            TO MIR-CO-MAX-NRNG-QTY-T (WS-LINE)
               MOVE SPACES           TO MIR-LAB-MIN-NRNG-QTY-T (WS-LINE)
               MOVE RLABT-ALPHA-RESP-ETBL-ID
                                   TO MIR-ALPHA-RESP-ETBL-ID-T (WS-LINE)
               GO TO 9220-MOVE-TO-SCREEN-1-X
557660     END-IF.

           MOVE RLABT-CO-MIN-NRNG-QTY TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-CO-MIN-NRNG-QTY-T (WS-LINE).

           MOVE RLABT-CO-MAX-NRNG-QTY TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-CO-MAX-NRNG-QTY-T (WS-LINE).

           MOVE RLABT-LAB-MIN-NRNG-QTY                 TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA   TO MIR-LAB-MIN-NRNG-QTY-T (WS-LINE).

           MOVE RLABT-LAB-MAX-NRNG-QTY                 TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA   TO MIR-LAB-MAX-NRNG-QTY-T (WS-LINE).

           MOVE RLABT-ALPHA-RESP-ETBL-ID
                                  TO MIR-ALPHA-RESP-ETBL-ID-T (WS-LINE).

       9220-MOVE-TO-SCREEN-1-X.
           EXIT.

       9230-MOVE-TO-SCREEN-2.

           MOVE REDIT-ETBL-DESC-TXT   TO MIR-ETBL-DESC-TXT.
018645*    MOVE RLABT-RSLT-PRECSN-QTY TO MIR-RSLT-PRECSN-QTY.
018645     MOVE ZERO                  TO L0290-PRECISION.
018645     MOVE LENGTH OF MIR-RSLT-PRECSN-QTY
018645                                TO L0290-MAX-OUT-LEN.
018645     MOVE RLABT-RSLT-PRECSN-QTY
018645                                TO L0290-INPUT-NUMBER.
018645     PERFORM 0290-2000-FORMAT-FOR-MIR
018645        THRU 0290-2000-FORMAT-FOR-MIR-X.
018645     MOVE L0290-OUTPUT-DATA     TO MIR-RSLT-PRECSN-QTY.


018645     MOVE RLABT-TST-RSLT-TYP-CD TO MIR-TST-RSLT-TYP-CD.
           MOVE RLABT-CO-MIN-NRNG-QTY TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CO-MIN-NRNG-QTY.

           MOVE RLABT-CO-MAX-NRNG-QTY TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CO-MAX-NRNG-QTY.

           MOVE RLABT-LAB-MIN-NRNG-QTY                 TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-LAB-MIN-NRNG-QTY.

           MOVE RLABT-LAB-MAX-NRNG-QTY                 TO WS-RESULT-NUM.
           PERFORM  8200-DISPLAY-RESULT
               THRU 8200-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-LAB-MAX-NRNG-QTY.

           MOVE RLABT-UNIT-MESUR-TXT  TO MIR-UNIT-MESUR-TXT.

018645*    IF  RLABT-RSLT-PRECSN-ALPHA-VALUE
018645     IF  RLABT-TST-RSLT-TYP-CD = '1'
               MOVE SPACE             TO MIR-CO-MIN-NRNG-QTY
               MOVE SPACE             TO MIR-CO-MAX-NRNG-QTY
               MOVE SPACE             TO MIR-LAB-MIN-NRNG-QTY
               MOVE SPACE             TO MIR-LAB-MAX-NRNG-QTY
               MOVE SPACE             TO MIR-UNIT-MESUR-TXT
557660     END-IF.

           MOVE RLABT-ALPHA-RESP-ETBL-ID
                                      TO MIR-ALPHA-RESP-ETBL-ID.

       9230-MOVE-TO-SCREEN-2-X.
           EXIT.
      *----------------------------------------------------------------
      *   UPDATE SCREEN KEYS FROM RECORD:
      *   UPDATE THE SCREEN KEYS FROM THE RECORD BUFFER FOR BROWSE-TYPE
      *   INQUIRIES FOR PAGING.
      *----------------------------------------------------------------
       9250-UPDATE-SCREEN-KEYS.

           MOVE RLABT-LAB-ID          TO MIR-LAB-ID.
           MOVE RLABT-LTST-ID         TO MIR-LTST-ID.
           MOVE RLABT-LTST-STD-AGE-QTY          TO MIR-LTST-STD-AGE-QTY.
           MOVE RLABT-LTST-STD-SEX-CD TO WS-SEX-FILE.
           PERFORM  8500-TRANSLATE-SEX-1
               THRU 8500-TRANSLATE-SEX-1-X.
           MOVE WS-SEX-MIR            TO MIR-LTST-STD-SEX-CD.

       9250-UPDATE-SCREEN-KEYS-X.
           EXIT.

      *----------------------------------------------------------------
      *   SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS B
      *   WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *----------------------------------------------------------------
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-MAX-SCREEN-LINES    TO TRUE.
023514
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *
018633***************************
018633*9500-BUILD-TWRK-KEY.
018633***************************
018633*
018633*    MOVE WS-TWRK-KEY           TO L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                 TO L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM      TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*
018633***************************
018633*9700-RETRIEVE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM 8090-2000-RETRIEVE-TWRK
018633*       THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*
018633***************************
018633*9800-WRITE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    MOVE 300           TO L8090-AREA-LEN.
018633*
018633*    PERFORM 8090-1000-WRITE-TWRK
018633*       THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*
018633***************************
018633*9900-DELETE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*
018633*    PERFORM 8090-3000-DELETE-TWRK
018633*       THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPEEDIT.
       COPY NCPELABC.
       COPY NCPETSTN.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY LABT
014221                         '$VAR2' BY 'LABT'.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
008455 COPY XCPS0290.
       COPY XCPL0290.
      *
      ****************************************************************
      * GENERAL COPYBOOKS                                            *
      ****************************************************************
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
018645 COPY XCPS8960.
018645 COPY XCPL8960.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNEDIT.
      *
       COPY NCPALABT.
       COPY NCPBLABT.
       COPY NCPNLABT.
       COPY NCPULABT.
       COPY NCPXLABT.
       COPY NCPCLABT.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM1370                     **
      *****************************************************************
