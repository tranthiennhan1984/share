      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM2794.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2794                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE CBAC TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023440**  6.5       UPDATE EFT BANK CHANGES AUTOMATICALLY            **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2794'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST              VALUE '2794'.

           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-NO                  VALUE 'N'.
               88  WS-ERROR-YES                 VALUE 'Y'.

           05  WS-SUB                       PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES            PIC S9(04) BINARY
025970*                                         VALUE 20.
           05  WS-CLBACHNG-TS.
               10  WS-CLBACHNG-DATE         PIC X(10).
               10  WS-CLBACHNG-FILL         PIC X(01).
               10  WS-CLBACHNG-TIME         PIC X(15).
020478     05  WS-CLI-BNK-ACCT-NUM          PIC 9(3).
020478     05  WS-CLI-BNK-ACCT-DT           PIC X(10).
020478     05  WS-CLI-BNK-ACCT-TS           PIC X(26).
036742     05  WS-CLI-BNK-GEN-ID            PIC 9(10).

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES            PIC S9(04) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT  VALUE 20.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
036742 COPY XCWWCNST.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
020478*COPY CCFWCBAD.
020478*COPY CCFRCBAC.
020478 COPY CCFWCLIN.
020478 COPY CCFRCLIB.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0620.
020478 COPY CCWL2626.
       COPY NCWL2437.

       COPY XCWLDTLK.
020478 COPY XCWL0280.
020478 COPY XCWL0290.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2794.
      /
CVMQ71*PROCEDURE DIVISION   USING   WGLOB-GLOBAL-AREA
CVMQ71*                             MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION   USING DFHEIBLK
CVMQ71                              DFHCOMMAREA
CVMQ71                              WGLOB-GLOBAL-AREA
CVMQ71                              MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FCCK-1000-CHECK-CLIENT
020478         THRU FCCK-1000-CHECK-CLIENT-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID     TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2794'         TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'       TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'       TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                                            TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

020478     PERFORM  0290-1000-BUILD-PARM-INFO
020478         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

020478*    PERFORM  7000-BUILD-KEYS
020478*        THRU 7000-BUILD-KEYS-X.

      *
      *  EDIT CLIENT-ID
      *
           SET  WS-ERROR-NO                 TO TRUE.
           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WS-ERROR-YES
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               GO TO 2000-LIST-X
           END-IF.

020478     PERFORM  7000-BUILD-KEYS
020478         THRU 7000-BUILD-KEYS-X.
020478*    PERFORM  CBAD-1000-BROWSE-PREV
020478*        THRU CBAD-1000-BROWSE-PREV-X.
020478*
020478*    PERFORM  CBAD-2000-READ-PREV
020478*        THRU CBAD-2000-READ-PREV-X.

020478     PERFORM  CLIN-1000-BROWSE-PREV
020478         THRU CLIN-1000-BROWSE-PREV-X.
020478
020478     PERFORM  CLIN-2000-READ-PREV
020478         THRU CLIN-2000-READ-PREV-X.

020478*    IF  WCBAD-IO-EOF
020478     IF  WCLIN-IO-EOF
020478*        PERFORM  CBAD-3000-END-BROWSE-PREV
020478*            THRU CBAD-3000-END-BROWSE-PREV-X
020478         PERFORM  CLIN-3000-END-BROWSE-PREV
020478             THRU CLIN-3000-END-BROWSE-PREV-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2010-GET-CLIENT-BANK-REC
               THRU 2010-GET-CLIENT-BANK-REC-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
020478*        OR      WCBAD-IO-EOF.
020478         OR      WCLIN-IO-EOF.

020478*    IF  WCBAD-IO-EOF
020478     IF  WCLIN-IO-EOF
      *MSG: 'END OF LIST'
               MOVE 'XS00000015'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
020478*        MOVE RCBAC-CLI-ID            TO MIR-CLI-ID
020478*        MOVE RCBAC-CLBACHNG-TS       TO MIR-DV-CLBACHNG-TS
020478         MOVE RCLIB-CLI-ID            TO MIR-CLI-ID
020478         MOVE RCLIB-CLI-BNK-ACCT-DT   TO L1640-INTERNAL-DATE
020478         PERFORM  1640-8000-INTERNAL-TO-MIR
020478             THRU 1640-8000-INTERNAL-TO-MIR-X
020478         MOVE L1640-EXTERNAL-DATE     TO MIR-CLI-BNK-ACCT-DT
020478         MOVE RCLIB-CLI-BNK-ACCT-TS   TO MIR-CLI-BNK-ACCT-TS
036742         MOVE RCLIB-CLI-BNK-GEN-ID    TO WS-CLI-BNK-GEN-ID
036742         MOVE WS-CLI-BNK-GEN-ID       TO L0290-INPUT-V00
036742         MOVE  +0                     TO L0290-PRECISION
036742         MOVE LENGTH OF MIR-CLI-BNK-GEN-ID
036742                                      TO L0290-MAX-OUT-LEN
036742         SET L0290-LEAD-ZEROS-DISPLAY TO TRUE
036742         SET L0290-SIGN-SUPPRESS      TO TRUE
036742         PERFORM  0290-2000-FORMAT-FOR-MIR
036742             THRU 0290-2000-FORMAT-FOR-MIR-X
036742         MOVE L0290-OUTPUT-DATA       TO MIR-CLI-BNK-GEN-ID
           END-IF.

020478*    PERFORM  CBAD-3000-END-BROWSE-PREV
020478*        THRU CBAD-3000-END-BROWSE-PREV-X.
020478     PERFORM  CLIN-3000-END-BROWSE-PREV
020478         THRU CLIN-3000-END-BROWSE-PREV-X.

       2000-LIST-X.
           EXIT.


      *-------------------------
       2010-GET-CLIENT-BANK-REC.
      *-------------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

020478*    PERFORM  CBAD-2000-READ-PREV
020478*        THRU CBAD-2000-READ-PREV-X.
020478     PERFORM  CLIN-2000-READ-PREV
020478         THRU CLIN-2000-READ-PREV-X.

       2010-GET-CLIENT-BANK-REC-X.
           EXIT.
      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------
      *
      *  READ THE CLIENT FILE, FOR VALIDATE AND GET BACK NAME
      *
           MOVE  MIR-CLI-ID                 TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  L2437-RETRN-CLI-NOT-FOUND
      *MSG: CLIENT (@1) DOES NOT EXIST
               MOVE 'XS00000076'            TO WGLOB-MSG-REF-INFO
               MOVE L2437-WCLI-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WS-ERROR-YES            TO TRUE
                    MOVE SPACES             TO MIR-DV-CLI-NM
               GO TO  2100-VALIDATE-KEYS-X
           END-IF.
      *
      *  COMPRESS CLIENT NAME FOR DISPLAY
      *
           INITIALIZE                          L0620-INPUT-PARM-INFO

           IF  L2437-CLI-SEX-COMPANY
               MOVE L2437-CLI-ENTR-CO-NM    TO L0620-CLI-CO-NM
           ELSE
               MOVE L2437-CLI-ENTR-GIV-NM   TO L0620-CLI-GIV-NM
               MOVE L2437-CLI-ENTR-SUR-NM   TO L0620-CLI-SUR-NM
               MOVE L2437-CLI-MID-INIT-NM   TO L0620-CLI-MID-INIT-NM
               MOVE L2437-CLI-SFX-NM        TO L0620-CLI-SFX-NM
           END-IF.

           MOVE L2437-CLI-SEX-CD            TO L0620-CLI-SEX-CD
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X
           MOVE L0620-SCREEN-NAME           TO MIR-DV-CLI-NM.

020478     SET L0280-SPACES-PERMITTED       TO TRUE.
020478     MOVE 'N'               TO L0280-SIGN-IND
020478     MOVE ZERO              TO L0280-PRECISION
020478     MOVE LENGTH OF MIR-CLI-BNK-ACCT-NUM   TO L0280-LENGTH
020478     MOVE LENGTH OF MIR-CLI-BNK-ACCT-NUM   TO L0280-INPUT-SIZE
020478     MOVE MIR-CLI-BNK-ACCT-NUM  TO L0280-INPUT-DATA
020478     PERFORM  0280-1000-NUMERIC-EDIT
020478         THRU 0280-1000-NUMERIC-EDIT-X
020478     IF  L0280-OK
020478         MOVE L0280-OUTPUT  TO WS-CLI-BNK-ACCT-NUM
020478     ELSE
020478         SET WS-ERROR-YES   TO TRUE
020478*MSG: BANK NUMBER MUST BE NUMERIC BETWEEN 001 - 009
020478         MOVE 'CS27940001'  TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478     END-IF.

020478     IF  MIR-CLI-BNK-ACCT-DT = SPACES
020478         MOVE WWKDT-HIGH-DT            TO WS-CLI-BNK-ACCT-DT
020478     ELSE
020478         MOVE MIR-CLI-BNK-ACCT-DT
020478                                  TO L1640-EXTERNAL-DATE
020478         PERFORM  1640-7000-MIR-TO-INT
020478             THRU 1640-7000-MIR-TO-INT-X
020478
020478         IF  L1640-NOT-VALID
020478*MSG : INVALID BANK ACCOUNT EFFECTIVE DATE
020478             MOVE 'CS27940002'         TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478             SET WS-ERROR-YES   TO TRUE
020478             GO TO 2100-VALIDATE-KEYS-X
020478         ELSE
020478             MOVE L1640-INTERNAL-DATE  TO WS-CLI-BNK-ACCT-DT
020478         END-IF
020478
020478         IF  WS-CLI-BNK-ACCT-DT > WGLOB-PROCESS-DATE
020478*MSG : THE DATE IS IN THE FUTURE
020478             MOVE 'CS00000037'         TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478             SET WS-ERROR-YES   TO TRUE
020478         END-IF
020478     END-IF.
020478
020478     IF  MIR-CLI-BNK-ACCT-TS = SPACES
020478         MOVE WWKDT-HIGH-TS           TO WS-CLI-BNK-ACCT-TS
020478     ELSE
020478         MOVE MIR-CLI-BNK-ACCT-TS     TO WS-CLI-BNK-ACCT-TS
020478     END-IF.
020478
036742     IF  MIR-CLI-BNK-GEN-ID = SPACES
036742         MOVE WCNST-MAX-CLI-BNK-GEN-ID-N
036742                                      TO WS-CLI-BNK-GEN-ID
036742     ELSE
036742         SET L0280-SIGN-PERMITTED   TO TRUE
036742         MOVE 0                     TO L0280-PRECISION
036742         MOVE LENGTH OF MIR-CLI-BNK-GEN-ID
036742                                    TO L0280-INPUT-SIZE
036742         MOVE L0280-INPUT-SIZE      TO L0280-LENGTH
036742         MOVE MIR-CLI-BNK-GEN-ID    TO L0280-INPUT-DATA
036742         PERFORM  0280-1000-NUMERIC-EDIT
036742             THRU 0280-1000-NUMERIC-EDIT-X
036742         IF  NOT L0280-OK
036742         OR  L0280-OUTPUT < ZERO
036742         OR  L0280-OUTPUT > WCNST-MAX-CLI-BNK-GEN-ID-N
036742*MSG: INVALID GEN ID
036742             MOVE 'CS27940003'      TO WGLOB-MSG-REF-INFO
036742             PERFORM  0260-1000-GENERATE-MESSAGE
036742                 THRU 0260-1000-GENERATE-MESSAGE-X
036742         ELSE
036742             MOVE L0280-OUTPUT      TO WS-CLI-BNK-GEN-ID
036742         END-IF
036742     END-IF.
036742
       2100-VALIDATE-KEYS-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
020478*    MOVE LOW-VALUES                  TO WCBAD-KEY.
020478*    MOVE MIR-CLI-ID                  TO WCBAD-CLI-ID.
020478*    MOVE WWKDT-HIGH-TS               TO WCBAD-CLBACHNG-TS.
020478*
020478*    MOVE WCBAD-KEY                   TO WCBAD-ENDBR-KEY.
020478*    MOVE WWKDT-LOW-TS                TO WCBAD-ENDBR-CLBACHNG-TS.

020478     MOVE HIGH-VALUES           TO WCLIN-KEY.
020478     MOVE MIR-CLI-ID            TO WCLIN-CLI-ID.
020478     MOVE WS-CLI-BNK-ACCT-NUM   TO WCLIN-CLI-BNK-ACCT-NUM.
020478     MOVE WS-CLI-BNK-ACCT-DT    TO WCLIN-CLI-BNK-ACCT-DT.
020478     MOVE WS-CLI-BNK-ACCT-TS    TO WCLIN-CLI-BNK-ACCT-TS.
036742     MOVE WS-CLI-BNK-GEN-ID     TO WCLIN-CLI-BNK-GEN-ID.
020478
020478     MOVE WCLIN-KEY             TO WCLIN-ENDBR-KEY.
020478     MOVE WWKDT-LOW-DT          TO WCLIN-ENDBR-CLI-BNK-ACCT-DT.
020478     MOVE WWKDT-LOW-TS          TO WCLIN-ENDBR-CLI-BNK-ACCT-TS.
036742     MOVE ZEROS                 TO WCLIN-ENDBR-CLI-BNK-GEN-ID.

020478*    IF  WGLOB-MORE-DATA-EXISTS
020478*    AND MIR-DV-CLBACHNG-TS > WWKDT-LOW-TS
020478*        MOVE MIR-DV-CLBACHNG-TS      TO WCBAD-CLBACHNG-TS
020478*    END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                      TO MIR-DV-CLI-NM.
           MOVE SPACES                      TO MIR-DV-CLBACHNG-DT-G.
           MOVE SPACES                      TO MIR-DV-CLBACHNG-TIME-G.
           MOVE SPACES                      TO MIR-BNK-ID-G.
           MOVE SPACES                      TO MIR-BNK-BR-ID-G.
           MOVE SPACES                      TO MIR-BNK-ACCT-ID-G.
020478*    MOVE SPACES                      TO MIR-CLBACHNG-STAT-CD-G.
020478     MOVE SPACES                      TO MIR-CLI-BNK-ACCT-CD-G.
           MOVE SPACES                      TO MIR-CLBACHNG-REASN-CD-G.
020478     MOVE SPACES                      TO MIR-CLI-BNK-ACCT-DT-G.
020478     MOVE SPACES                      TO MIR-CLI-BNK-ACCT-TS-G.
036742     MOVE SPACES                      TO MIR-CLI-BNK-GEN-ID-G.
020478     MOVE SPACES                      TO MIR-CLI-BNK-ACCT-NUM-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

020478*    MOVE RCBAC-BNK-ID                TO MIR-BNK-ID-T (WS-SUB).
020478     MOVE RCLIB-BNK-ID                TO MIR-BNK-ID-T (WS-SUB).

020478*    MOVE RCBAC-BNK-BR-ID             TO
020478     MOVE RCLIB-BNK-BR-ID             TO
                                            MIR-BNK-BR-ID-T (WS-SUB).

020478*    MOVE RCBAC-BNK-ACCT-ID           TO
020478     MOVE RCLIB-BNK-ACCT-ID           TO
                                          MIR-BNK-ACCT-ID-T (WS-SUB).

020478*    MOVE RCBAC-CLBACHNG-TS           TO WS-CLBACHNG-TS.
020478     MOVE RCLIB-CLI-BNK-ACCT-TS       TO WS-CLBACHNG-TS.

           MOVE WS-CLBACHNG-DATE            TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE         TO
                                       MIR-DV-CLBACHNG-DT-T (WS-SUB).

           MOVE WS-CLBACHNG-TIME            TO
                                       MIR-DV-CLBACHNG-TIME-T (WS-SUB).

020478*    MOVE RCBAC-CLBACHNG-STAT-CD      TO
020478     MOVE RCLIB-CLI-BNK-ACCT-CD       TO
020478*                              MIR-CLBACHNG-STAT-CD-T (WS-SUB).
020478                               MIR-CLI-BNK-ACCT-CD-T (WS-SUB).

020478*    MOVE RCBAC-CLBACHNG-REASN-CD     TO
020478     MOVE RCLIB-CLBACHNG-REASN-CD     TO
                                     MIR-CLBACHNG-REASN-CD-T (WS-SUB).
020478     MOVE RCLIB-CLI-BNK-ACCT-DT       TO L1640-INTERNAL-DATE
020478     PERFORM 1640-8000-INTERNAL-TO-MIR
020478        THRU 1640-8000-INTERNAL-TO-MIR-X
020478     MOVE L1640-EXTERNAL-DATE         TO MIR-CLI-BNK-ACCT-DT-T
020478                                         (WS-SUB).
020478
020478     MOVE RCLIB-CLI-BNK-ACCT-NUM      TO L0290-INPUT-V00
020478     MOVE ZERO                  TO L0290-PRECISION
020478     MOVE LENGTH OF MIR-CLI-BNK-ACCT-NUM-T (WS-SUB)
020478                                      TO L0290-MAX-OUT-LEN
020478     PERFORM  0290-2000-FORMAT-FOR-MIR
020478         THRU 0290-2000-FORMAT-FOR-MIR-X
020478     MOVE L0290-OUTPUT-DATA           TO MIR-CLI-BNK-ACCT-NUM-T
020478                                         (WS-SUB).
020478     MOVE RCLIB-CLI-BNK-ACCT-TS       TO MIR-CLI-BNK-ACCT-TS-T
020478                                         (WS-SUB).
036742
036742     MOVE RCLIB-CLI-BNK-GEN-ID        TO WS-CLI-BNK-GEN-ID.
036742     MOVE  WS-CLI-BNK-GEN-ID          TO L0290-INPUT-V00.
036742     MOVE  +0                         TO L0290-PRECISION.
036742     MOVE LENGTH OF MIR-CLI-BNK-GEN-ID-T (WS-SUB)
036742                                      TO L0290-MAX-OUT-LEN.
036742     SET L0290-LEAD-ZEROS-DISPLAY     TO TRUE.
036742     SET L0290-SIGN-SUPPRESS          TO TRUE.
036742     PERFORM  0290-2000-FORMAT-FOR-MIR
036742          THRU 0290-2000-FORMAT-FOR-MIR-X.
036742     MOVE L0290-OUTPUT-DATA           TO MIR-CLI-BNK-GEN-ID-T
036742                                         (WS-SUB).
020478
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                      TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE          TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT            TO TRUE.
           MOVE MIR-CLI-ID                  TO WGLOB-REF-CLIENT-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE                          WS-WORKING-STORAGE.
025970*    MOVE 20                          TO WS-MAX-LIST-LINES.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970     SET WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK                TO TRUE.


       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFCCK.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
       COPY CCPL0620.

025970 COPY NCPS2437.
       COPY NCPL2437.

025970 COPY XCPS0280.
020478 COPY XCPL0280.
020478 COPY XCPS0290.
020478 COPY XCPL0290.
       COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
020478*COPY CCPVCBAD.
020478 COPY CCPVCLIN.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2794
      *****************************************************************

