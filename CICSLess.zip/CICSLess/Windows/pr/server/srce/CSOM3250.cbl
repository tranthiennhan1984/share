      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3250.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3250                                         **
      **  REMARKS:  THIS MODULE PROVIDES INFORMATION FOR THE         **
      **            INVESTEMENT DATA SUMMARY SECTION OF THE          **
      **            INVESTEMENT ANNUITY APPLICATION                  **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020473**  6.4       INVESTMENT ANNUITY APP ENTRY FLOW                **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3250'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC  X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '3250'.
           05  I                             PIC S9(04)
                                             BINARY.
       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                   PIC  X(04)
                                             VALUE '3250'.
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '3250'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCWWCVGS.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL3250.
      /
       COPY CCWL5400.
      /
       COPY XCWL0290.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3250.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

023118*    PERFORM  9990-INIT-WORKING-STORAGE
023118*        THRU 9990-INIT-WORKING-STORAGE-X.
023118*
025970*    MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3250'           TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.


      /
      *--------------
       2000-RETRIEVE.
      *--------------
      *
           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  8010-EDIT-KEY-FIELDS
               THRU 8010-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED      TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  3250-1000-BUILD-PARM-INFO
               THRU 3250-1000-BUILD-PARM-INFO-X.

           PERFORM  3250-1000-INQ-INV-DATA
               THRU 3250-1000-INQ-INV-DATA-X.

      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           PERFORM  3250-2000-RETRN-PARM-INFO
               THRU 3250-2000-RETRN-PARM-INFO-X.

       2000-RETRIEVE-X.
           EXIT.

      /
      *---------------------------
       8010-EDIT-KEY-FIELDS.
      *---------------------------

           PERFORM  8011-EDIT-POL-ID
               THRU 8011-EDIT-POL-ID-X.

           PERFORM  8013-XEDIT-POL-ID
               THRU 8013-XEDIT-POL-ID-X.

       8010-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *---------------------------
       8011-EDIT-POL-ID.
      *---------------------------
      *
      * CHECK POLICY EXISTS
      *
           IF  MIR-POL-ID-BASE  = SPACES
           AND MIR-POL-ID-SFX   = SPACES
      *MSG: POLICY NUMBER IS REQUIRED
               MOVE 'CS32500001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

           MOVE MIR-POL-ID               TO WPOL-POL-ID.

      *  UPDATE GROUP LEVEL TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD NOT FOUND
               MOVE 'XS00000070'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

       8011-EDIT-POL-ID-X.
           EXIT.


      *---------------------------
       8013-XEDIT-POL-ID.
      *---------------------------
      *
      * CHECK POLICY CONFIDENTIAL AND SECURITY ARE SATISFIED
      *

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
            END-IF.

       8013-XEDIT-POL-ID-X.
           EXIT.


      /
      *---------------------------
       9000-BLANK-DATA-FIELDS.
      *---------------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9300-SETUP-MSIN-REFERENCE.
      *---------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.

           SET  WGLOB-REF-POLICY         TO TRUE.
           MOVE MIR-POL-ID               TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3250-0000-INIT-PARM-INFO
025970         THRU 3250-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WGLOB-MSG-ERROR-SW.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET  WS-TWRK-KEY-DEFAULT     TO TRUE.
           SET  MIR-RETRN-OK       TO TRUE.
025970     MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POL
                                '$VAR2'   BY 'POL'.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS8090.
       COPY CCPS3250.
       COPY CCPL3250.
      /
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY XCPL0260.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **              END OF PROGRAM CSOM3250                        **
      *****************************************************************
