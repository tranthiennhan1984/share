      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. SSOM1884.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1884                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE FV TABLE                                 **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1884'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '1884'.
           05  WS-SUB                                PIC S9(04) BINARY.
           05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY.
           05  WS-FNDVL-EFF-DT                       PIC X(10).
           05  WS-FNDVL-IDT-NUM                      PIC X(07).
      /
       01  WS-CONSTANT-AREA.
           05  FILLER                                PIC X(01).

      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWFH.
       COPY SCFRFH.

       COPY SCFWFVAA.
       COPY SCFRFV.

       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWL0290.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1884.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  FVAA-1000-BROWSE
               THRU FVAA-1000-BROWSE-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

           IF  WFVAA-IO-EOF
               PERFORM  FVAA-3000-END-BROWSE
                   THRU FVAA-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2300-POPULATE-KEY-FIELDS
               THRU 2300-POPULATE-KEY-FIELDS-X.

           PERFORM  2200-BROWSE-FV
               THRU 2200-BROWSE-FV-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WFVAA-IO-EOF.

           IF  WFVAA-IO-EOF
      *MSG: *** END OF LIST ***
               MOVE 'CS00000023'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE

               PERFORM  2300-POPULATE-KEY-FIELDS
                   THRU 2300-POPULATE-KEY-FIELDS-X
           END-IF.

           PERFORM  FVAA-3000-END-BROWSE
               THRU FVAA-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-FND-ID
               THRU 2110-EDIT-FND-ID-X.

           PERFORM  2120-EDIT-FNDVL-EFF-DT
               THRU 2120-EDIT-FNDVL-EFF-DT-X.

           PERFORM  2130-EDIT-FNDVL-UNIT-TYP-CD
               THRU 2130-EDIT-FNDVL-UNIT-TYP-CD-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-FND-ID.
      *----------------------------

           MOVE MIR-FND-ID                  TO WFH-FND-ID.

           PERFORM  FH-1000-READ
               THRU FH-1000-READ-X.

           IF  WFH-IO-NOT-FOUND
      *MSG: @1 RECORD (@2) NOT FOUND
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                    TO WGLOB-MSG-PARM (1)
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-FND-ID-X
           END-IF.

           MOVE RFH-FND-TYP-CD              TO MIR-FND-TYP-CD.
           MOVE RFH-FND-PRIC-STRUCT-CD      TO MIR-FND-PRIC-STRUCT-CD.

       2110-EDIT-FND-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-FNDVL-EFF-DT.
      *----------------------------

           IF  MIR-FNDVL-EFF-DT = SPACE
               MOVE WWKDT-LOW-DT       TO WS-FNDVL-EFF-DT
               MOVE ZERO               TO WS-FNDVL-IDT-NUM
               GO TO 2120-EDIT-FNDVL-EFF-DT-X
           END-IF.

           MOVE MIR-FNDVL-EFF-DT            TO L1640-EXTERNAL-DATE.

           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID NEXT FUND VALUATION DATE
               MOVE 'SS18840002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2120-EDIT-FNDVL-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE    TO WS-FNDVL-EFF-DT.

           MOVE WS-FNDVL-EFF-DT        TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WS-FNDVL-IDT-NUM.

       2120-EDIT-FNDVL-EFF-DT-X.
           EXIT.

      *----------------------------
       2130-EDIT-FNDVL-UNIT-TYP-CD.
      *----------------------------

           EVALUATE TRUE

               WHEN MIR-FNDVL-UNIT-TYP-CD = SPACE
                    GO TO 2130-EDIT-FNDVL-UNIT-TYP-CD-X

               WHEN MIR-FNDVL-UNIT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
                    MOVE SPACE               TO MIR-FNDVL-UNIT-TYP-CD
                    GO TO 2130-EDIT-FNDVL-UNIT-TYP-CD-X

           END-EVALUATE.

           MOVE MIR-FNDVL-UNIT-TYP-CD        TO WEDIT-ETBL-VALU-ID.

           PERFORM  UVTP-1000-EDIT
               THRU UVTP-1000-EDIT-X.

           IF  NOT WEDIT-IO-OK
      *MSG: FUND UNIT TYPE (@1) NOT ON EDIT (@2)
               MOVE MIR-FNDVL-UNIT-TYP-CD    TO WGLOB-MSG-PARM (1)
               MOVE 'UVTYP'                  TO WGLOB-MSG-PARM (2)
               MOVE 'SS18840002'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2130-EDIT-FNDVL-UNIT-TYP-CD-X.
           EXIT.

      *-----------------
       2200-BROWSE-FV.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

       2200-BROWSE-FV-X.
           EXIT.
      /

      *----------------------------
       2300-POPULATE-KEY-FIELDS.
      *----------------------------

           MOVE RFV-FNDVL-UNIT-TYP-CD    TO MIR-FNDVL-UNIT-TYP-CD.

           MOVE RFV-FNDVL-EFF-DT         TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-FNDVL-EFF-DT.

       2300-POPULATE-KEY-FIELDS-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WFVAA-KEY.

           MOVE MIR-FND-ID             TO WFVAA-FND-ID.
           MOVE WS-FNDVL-IDT-NUM       TO WFVAA-FNDVL-IDT-NUM.
           MOVE MIR-FNDVL-UNIT-TYP-CD  TO WFVAA-FNDVL-UNIT-TYP-CD.

           MOVE WFVAA-KEY              TO WFVAA-ENDBR-KEY.
           MOVE ALL '9'                TO WFVAA-ENDBR-FNDVL-IDT-NUM.
           MOVE HIGH-VALUES            TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                  TO MIR-FND-ID-G.
           MOVE SPACE                  TO MIR-FNDVL-UNIT-TYP-CD-G.
           MOVE SPACE                  TO MIR-FNDVL-EFF-DT-G.
           MOVE SPACE                  TO MIR-PURCH-PRIC-AMT-G.
           MOVE SPACE                  TO MIR-SELL-PRIC-AMT-G.
           MOVE SPACE                  TO MIR-FNDVL-CHNG-IND-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RFV-FND-ID
             TO MIR-FND-ID-T (WS-SUB).

           MOVE RFV-FNDVL-UNIT-TYP-CD
             TO MIR-FNDVL-UNIT-TYP-CD-T (WS-SUB).

           MOVE RFV-FNDVL-EFF-DT
             TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
             TO MIR-FNDVL-EFF-DT-T (WS-SUB).

           MOVE RFV-PURCH-PRIC-AMT
             TO L0290-INPUT-V09.
           MOVE +9
             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PURCH-PRIC-AMT-T (WS-SUB)
             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-PURCH-PRIC-AMT-T (WS-SUB).

           MOVE RFV-SELL-PRIC-AMT
             TO L0290-INPUT-V09.
           MOVE +9
             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-SELL-PRIC-AMT-T (WS-SUB)
             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-SELL-PRIC-AMT-T (WS-SUB).

           MOVE RFV-FNDVL-CHNG-IND
             TO MIR-FNDVL-CHNG-IND-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE MIR-OUTPUT-AREA.
025970     MOVE SPACES               TO WWKDT-WORK-FIELDS.

           COMPUTE WS-MAX-LIST-LINES = LENGTH OF MIR-FND-ID-G
                                     / LENGTH OF MIR-FND-ID-T (1).

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPEUVTP.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY SCPBFVAA.
      /
       COPY SCPNFH.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM SSOM1884
      *****************************************************************
