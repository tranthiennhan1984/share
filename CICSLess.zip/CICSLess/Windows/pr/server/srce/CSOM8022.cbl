      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8022.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8022                                         **
      **  REMARKS:  PROCESS DRIVER FOR COVERAGE UPDATE               **
      **            THIS PROGRAM ALLOWS THE USER TO UPDATE ON THE    **
      **            POLICY COVERAGE TABLE (CVG AND ASSOCIATED TABLES **
      **            CVGC AND CVGA)                                   **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       ORIGINAL FOR 6.0                                 **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
015543**  6.0       CODE CLEANUP                                     **
016309**  6.1       CLEANUP LOCKING RECORDS                          **
016328**  6.1       FIX DATES USED FOR COMM AND PMT LOAD TGTS  **    **
014221**  6.2       LOGICAL LOCKING                                  **
015918**  6.2       MOVE GDLN CALCS FROM CVG LEVEL EDITS TO POL LVL  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017207**  6.2       FIX FOR INCORRECT SERVICING AGENT NAME           **
017259**  6.2       INITIALIZE ERROR SW                              **
012522**  6.3       MONTHIVERSARY PROCESSING FOR INVESTMENTS (6.1.1E)**
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
015951**  6.3       DISABILITY RIDERS ON TRAD POLICIES (6.1.1E)      **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
016227**  6.3       CODE CLEAN UP                                    **
016306**  6.3       MORTGAGE BACKED DECREASING TERM (6.1.1E)         **
016641**  6.3       EXTENSIVE NUMERIC FORMATTING                     **
016736**  6.3       CODE CLEANUP                                     **
018461**  6.3       PCR - PLANNED PERIODIC PREMIUM AMT               **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
018905**  6.3       DURATION BASED MATURITY/EXPIRY AGE AND TERM      **
017100**  6.4       CHANGE FIELD NAMES FROM CHG TO CHNG ABBREVIATION **
018633**  6.4       TWRK CLEANUP                                     **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023137**  6.5       PX CALC FOR UL TARGET                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
027183**  6.7       USER MESSAGE MISSING POLICY SUFFIX               **
025692**  6.7       REINSTATE ETI RPU OR EXPIRE WITH UNDERWRITING    **
025605**  6.7       COVERAGE ISSUE DATE CHANGE ON REISSUE            **
028786**  6.7       EXTERNAL AGENCY INTEGRATION - COMPENSATION CALC. **
028789**  6.7       EXTERNAL AGENCY INTEGRATION - REAL TIME INFO.    **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
029059**  7.1       CASH VALUE ACCUMULATION TEST                     **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************
      /
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8022'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
       COPY XCWL8090.
016537*COPY XCWWCVGM.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-UPDATE        VALUE '8022'.
       01  WS-EDIT-CHECKS.
           05  WS-ERROR-SW                   PIC X(01).
               88  WS-ERROR-FOUND            VALUE 'Y'.
               88  WS-ERROR-FOUND-NONE       VALUE 'N'.

           05  WS-PLAN-ERROR-SW              PIC X(01).
               88  WS-PLAN-ERROR-FOUND       VALUE 'Y'.
               88  WS-PLAN-ERROR-NOT-FOUND   VALUE 'N'.


       01  WS-NUMERIC-EDIT-FIELDS.
           05  WS-INPUT-3-6                  PIC 9(3).999999.
           05  WS-INPUT-2-3                  PIC 9(2).999.
           05  WS-INPUT-1-2                  PIC 9.99.
           05  WS-INPUT-1-2-S                PIC +9.99.
           05  WS-INPUT-2-3-S                PIC +9(2).999.
           05  WS-INPUT-3-2                  PIC 9(3).99.
           05  WS-DISPLAY-3                  PIC ZZ9.
           03  WS-DISPLAY-999                PIC 999.

       01  WS-PGM-WORK-AREA.
016548*    05  WS-HOLD-CLI-SUB               PIC S9(04) COMP.
016548     05  WS-HOLD-CLI-SUB               PIC S9(04) BINARY.
           05  WS-UPDATE-SW                  PIC 9.
               88  WS-UPDATE-NOT-REQUIRED   VALUE 0.
               88  WS-UPDATE-REQUIRED        VALUE 1.
           05  WS-CVG-NUM                    PIC 99.
           05  WS-CVG-NUM-R                  REDEFINES
               WS-CVG-NUM                    PIC X(2).
           05  WS-DISPLAY-CVG-NUM            PIC 99.
           05  WS-CVG-CLI-AGE-FLDS.
               10  FILLER                   OCCURS 5.
                   15  WS-CVG-CLI-CLI-ID    PIC X(10).
                   15  WS-CVG-CLI-ISS-AGE   PIC S9(03)    COMP-3.
                   15  WS-CVG-CLI-ADJ-AGE   PIC S9(03)    COMP-3.
016548*        10  WS-INS-SUB               PIC S9(04)    COMP.
016548         10  WS-INS-SUB               PIC S9(04)    BINARY.
020874*    05  WS-CVG-COMM-TRG-AMT          PIC X(012).
020874     05  WS-CVG-COMM-TRG-AMT          PIC X(011).
           05  WS-PMT-LOAD-TRG-AMT          PIC X(011).
016440*    05  WS-CVG-UWGDECN-CHG-IND       PIC X(01).
016440*        88  WS-CVG-UWGDECN-CHG-YES   VALUE 'Y'.
016440*        88  WS-CVG-UWGDECN-CHG-NO    VALUE 'N'.

012522     05  WS-MPREM-AMT                 PIC S9(11)V99.
015951     05  WS-HEALTH-POL-CVG-IND           PIC X(01).
015951         88  WS-HEALTH-POL-CVG-FOUND     VALUE 'Y'.
015951         88  WS-HEALTH-POL-CVG-NOT-FOUND VALUE 'N'.

018633*01  WS-TWRK-KEY                     PIC X(04)  VALUE '8020'.
018633*01  WS-WORK-AREA.
018633*    05  WS-OLD-CVG-CLI-INFO              PIC X(50).
018633*    05  WS-OLD-CVG-AGT-INFO              PIC X(18).
018633*    05  FILLER                           PIC X(232).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '8020'.
018633     15  LCOMM-CVG-CLI-INFO               PIC X(50).
018633     15  LCOMM-CVG-AGT-INFO               PIC X(18).
018633
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
       COPY CCWWINDX.
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWCVGC.
       COPY CCFRCVGC.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY CCWL0083.
      /
       COPY CCWL0570.
      /
029059*COPY CCWL0578.
      /
016440*COPY CCWL0580.
      /
016503 COPY CCWL0289.

016108 COPY CCWL0985.
016108/
012522 COPY XCWL0280.
012522/
       COPY XCWL0290.
      /
       COPY CCWL2430.
      /
       COPY NCWL2437.
      /
       COPY CCWL2450.
      /
016537*COPY CCWL2470.
      /
020478 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
       COPY CCWL5400.
      /
       COPY CCWL6090.
       COPY CCWL6100.
       COPY CCWL0620.
      /
       COPY CCWLPGA.
      /
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8022.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      /
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.

017259     SET WS-ERROR-FOUND-NONE     TO TRUE.
           MOVE ZERO                   TO WGLOB-MSG-ERROR-SW.
           SET WS-UPDATE-NOT-REQUIRED  TO TRUE.

           MOVE MIR-POL-ID             TO WPOL-POL-ID.
           MOVE MIR-CVG-NUM            TO WS-CVG-NUM-R.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:   INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8022'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO  TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------

018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF  L8090-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT  TO WS-WORK-AREA
018633*    END-IF.
018633*
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  2100-INITIAL-SYSTEM-EDITS
               THRU 2100-INITIAL-SYSTEM-EDITS-X.

           IF WS-ERROR-FOUND
014221     OR MIR-RETRN-TS-MISMATCH
014221        IF WS-ERROR-FOUND
016309            PERFORM  POL-3000-UNLOCK
016309                THRU POL-3000-UNLOCK-X
014221        END-IF
              GO TO 2000-UPDATE-X
           END-IF.


           PERFORM  0570-1000-BUILD-PARM-INFO
               THRU 0570-1000-BUILD-PARM-INFO-X.

016440*    PERFORM  0580-1000-BUILD-PARM-INFO
016440*        THRU 0580-1000-BUILD-PARM-INFO-X.


           MOVE ZERO                   TO WGLOB-MSG-ERROR-SW.
           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

016440     IF WCVGS-CVG-STAT-TERMINATED (WS-CVG-NUM)
016440        MOVE WS-CVG-NUM          TO WGLOB-MSG-PARM (1)
016440        MOVE 'CS80220006'        TO WGLOB-MSG-REF-INFO
016440        PERFORM 0260-1000-GENERATE-MESSAGE
016440           THRU 0260-1000-GENERATE-MESSAGE-X
016440        SET WS-ERROR-FOUND       TO TRUE
016440     END-IF.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               SET WS-ERROR-FOUND      TO TRUE
016309         PERFORM  POL-3000-UNLOCK
016309             THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WGLOB-PROCESS-DATE     TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         SET WS-ERROR-FOUND      TO TRUE
016108         SET WGLOB-RETURN-ERROR  TO TRUE
016108         PERFORM  POL-3000-UNLOCK
016108             THRU POL-3000-UNLOCK-X
016108         GO TO 2000-UPDATE-X
016108     END-IF.

           MOVE WS-CVG-NUM             TO I.

           PERFORM  2200-MOVE-MIR-TO-WORK-AREA
               THRU 2200-MOVE-MIR-TO-WORK-AREA-X.
      *
      *  BUILD GENERAL PARM AREA
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  2300-COVERAGE-UPDATE
               THRU 2300-COVERAGE-UPDATE-X.

           IF WS-UPDATE-REQUIRED
016503* UPDATE NEXT ACTIVITY INFORMATION
016503         PERFORM  0289-1000-INIT-PARM-INFO
016503             THRU 0289-1000-INIT-PARM-INFO-X
016503         PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503             THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503         IF L0289-RETRN-OK
016503            MOVE L0289-NXT-ACTV-TYP-CD
016503                        TO RPOL-NXT-ACTV-TYP-CD
016503            MOVE L0289-NXT-ACTV-DT
016503                        TO RPOL-POL-NXT-ACTV-DT
016503         ELSE
016503            MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503            MOVE WGLOB-PROCESS-DATE
016503                        TO RPOL-POL-NXT-ACTV-DT
016503         END-IF
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X

014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X

               IF RPOL-POL-CVG-REC-CTR-N > ZERO
                   PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                      THRU  CVGR-1000-REWRITE-CVGS-ARRAY-X
               END-IF
016309     ELSE
016309         PERFORM  POL-3000-UNLOCK
016309             THRU POL-3000-UNLOCK-X
           END-IF.

018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.

       2000-UPDATE-X.
           EXIT.
      /
      *--------------------------
       2100-INITIAL-SYSTEM-EDITS.
      *--------------------------

      *
      * READ THE POLICY
      *

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 2100-INITIAL-SYSTEM-EDITS-X
014221     END-IF.

           IF WPOL-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND       TO TRUE
               GO TO 2100-INITIAL-SYSTEM-EDITS-X
           END-IF.

016440*    IF  RPOL-POL-SUSPENDED
016440*    AND RPOL-POL-APPL-CTL-ADMIN
016440*MSG:    POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
016440*        MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        IF  WGLOB-MSG-SEVRTY-FATAL
016440*            GO TO 2100-INITIAL-SYSTEM-EDITS-X
016440*        END-IF
016440*    END-IF.
      *
      *  POLICY CONTROL CHECK
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
              THRU  5400-1000-BUILD-PARM-INFO-X.

016440     SET L5400-POL-XFER-UPDATE   TO TRUE.

           PERFORM  5400-1000-POL-CHK
              THRU  5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
           OR  NOT L5400-RETRN-OK
               SET WS-ERROR-FOUND       TO TRUE
               GO TO 2100-INITIAL-SYSTEM-EDITS-X
           END-IF.

           IF RPOL-POL-CVG-REC-CTR < MIR-CVG-NUM
      *MSG: COVERAGE RECORD MUST EXIST. RE-ENTER.
               MOVE 'CS00000021'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND       TO TRUE
               GO TO 2100-INITIAL-SYSTEM-EDITS-X
           END-IF.

           MOVE WS-CVG-NUM             TO I.

       2100-INITIAL-SYSTEM-EDITS-X.
           EXIT.
      /
      *-----------------------------
       2200-MOVE-MIR-TO-WORK-AREA.
      *-----------------------------

           MOVE MIR-PLAN-ID                 TO L0570-PLAN-ID.
           MOVE MIR-CVG-SMKR-CD             TO L0570-SMKR-CD.
           MOVE MIR-CVG-PAR-CD              TO L0570-PAR-CD.
           MOVE MIR-CVG-SEX-CD              TO L0570-SEX-CD.
           MOVE MIR-CVG-RT-AGE              TO L0570-RT-AGE.
           MOVE MIR-CVG-STBL-1-CD           TO L0570-STBL-1-CD.
           MOVE MIR-CVG-STBL-2-CD           TO L0570-STBL-2-CD.
           MOVE MIR-CVG-STBL-3-CD           TO L0570-STBL-3-CD.
           MOVE MIR-CVG-STBL-4-CD           TO L0570-STBL-4-CD.
           MOVE MIR-CVG-FACE-AMT            TO L0570-FACE-AMT.
           MOVE MIR-CVG-AD-FACE-AMT         TO L0570-AD-FACE-AMT.
           MOVE MIR-CVG-WP-MULT-FCT         TO L0570-WP-MULT-FCT.
           MOVE MIR-CVG-AD-MULT-FCT         TO L0570-AD-MULT-FCT.
           MOVE MIR-CVG-SUM-INS-AMT         TO L0570-SUM-INS-AMT.
           MOVE MIR-CVG-ENHC-TYP-CD         TO L0570-CVG-ENHC-TYP-CD.
           MOVE MIR-CVG-ORIG-FACE-AMT       TO L0570-CVG-ORIG-FACE-AMT.
           MOVE MIR-REDC-EP-SELCT-IND       TO L0570-REDC-EP-SELCT-IND.
           MOVE MIR-OWN-OCCP-SELCT-IND      TO L0570-OWN-OCCP-SELCT-IND.
           MOVE MIR-CVG-LTA-SELCT-IND       TO L0570-CVG-LTA-SELCT-IND.
           MOVE MIR-CVG-LTB-SELCT-IND       TO L0570-CVG-LTB-SELCT-IND.
           MOVE MIR-PDISAB-SELCT-IND        TO L0570-PDISAB-SELCT-IND.
           MOVE MIR-CVG-COLA-SELCT-CD       TO L0570-CVG-COLA-TYP-CD.
           MOVE MIR-REL-CVG-NUM             TO L0570-REL-CVG-NUM.
           MOVE MIR-ULT-PREM-RT-CD          TO L0570-ULT-PREM-RT-CD.
           MOVE MIR-ULT-PREM-RT-AGE         TO L0570-ULT-PREM-RT-AGE.
           MOVE MIR-POL-APP-NUM             TO L0570-APP-NUM.
           MOVE MIR-CVG-APP-RECV-DT         TO L0570-APP-RECV-DT.
           MOVE MIR-CVG-ISS-EFF-DT          TO L0570-CVG-ISSUE-DT.
           MOVE MIR-CVG-MAT-XPRY-DT         TO L0570-MAT-XPRY-DT.
018905*    MOVE MIR-CVG-MAT-XPRY-AGE        TO L0570-MAT-XPRY-AGE.
018905*    MOVE MIR-CVG-MAT-XPRY-DUR        TO L0570-MAT-XPRY-DUR.
           MOVE MIR-CVG-PREM-CHNG-DT        TO L0570-PREM-CHNG-DT.
           MOVE MIR-CVG-CNVR-XPRY-DT        TO L0570-CNVR-XPRY-DT.
           MOVE MIR-CVG-NOTI-DT             TO L0570-NOTI-DT.
           MOVE MIR-CVG-NOTI-REASN-CD       TO L0570-NOTI-REASN-CD.
           MOVE MIR-CVG-NOTI-DEPT-ID        TO L0570-NOTI-DEPT-ID.
           MOVE MIR-CVG-UNIT-VALU-AMT       TO L0570-UNIT-VALU-AMT.
           MOVE MIR-CVG-JNT-LIFE-CD         TO L0570-JNT-LIFE-CD.
           MOVE MIR-INSRD-CLI-ID-T (01)     TO L0570-CLI-ID (01).
           MOVE MIR-INSRD-CLI-ID-T (02)     TO L0570-CLI-ID (02).
           MOVE MIR-INSRD-CLI-ID-T (03)     TO L0570-CLI-ID (03).
           MOVE MIR-INSRD-CLI-ID-T (04)     TO L0570-CLI-ID (04).
           MOVE MIR-INSRD-CLI-ID-T (05)     TO L0570-CLI-ID (05).
025388*    MOVE MIR-CVG-LIVES-INSRD-CD      TO L0570-LIVES-INSRD-CD.
025388     MOVE MIR-LIVES-INSRD-QTY         TO L0570-LIVES-INSRD-QTY.
           MOVE MIR-CVG-WP-PREM-AMT         TO L0570-WP-PREM-AMT.
           MOVE MIR-CVG-RESTR-PREM-IND      TO L0570-RESTR-PREM-IND.
           MOVE MIR-CVG-FE-PREM-AMT         TO L0570-FE-PREM-AMT.
           MOVE MIR-CVG-FE-UPREM-AMT        TO L0570-FE-UPREM-AMT.
           MOVE MIR-CVG-FE-DUR              TO L0570-FE-DUR.
           MOVE MIR-CVG-FE-REASN-CD         TO L0570-FE-REASN-CD.
           MOVE MIR-CVG-MPREM-AMT           TO L0570-MPREM-AMT.
           MOVE MIR-CVG-BASIC-PREM-AMT      TO L0570-BASIC-PREM-AMT.
012522
012522     MOVE 'Y'                         TO L0280-SIGN-IND.
012522     MOVE 11                          TO L0280-LENGTH.
012522     MOVE 02                          TO L0280-PRECISION.
012522     MOVE MIR-CVG-MPREM-AMT           TO L0280-INPUT-DATA.
012522     PERFORM  0280-1000-NUMERIC-EDIT
012522         THRU 0280-1000-NUMERIC-EDIT-X.
012522     MOVE L0280-OUTPUT-V02            TO WS-MPREM-AMT.
012522
012522     IF  WS-MPREM-AMT NOT = RCVG-CVG-MPREM-AMT
012522         SET L0570-MODE-PREM-ENTERED  TO TRUE
012522     ELSE
012522         SET L0570-MODE-PREM-NOT-ENTERED TO TRUE
012522     END-IF.
012522
           MOVE MIR-CVG-PFEE-AMT            TO L0570-PFEE-AMT.
           MOVE MIR-CVG-AD-PREM-AMT         TO L0570-AD-PREM-AMT.
           MOVE MIR-CVG-ME-PREM-AMT         TO L0570-ME-PREM-AMT.
           MOVE MIR-CVG-ME-FCT              TO L0570-ME-FCT.
           MOVE MIR-CVG-ME-RAT-CD           TO L0570-ME-RAT-CD.
           MOVE MIR-CVG-ME-DUR              TO L0570-ME-DUR.
           MOVE MIR-CVG-ME-REASN-CD         TO L0570-ME-REASN-CD.
016440*    MOVE MIR-CVG-MISC-RAT-1-CD       TO L0570-MISC-RAT-1-CD.
016440*    MOVE MIR-CVG-MISC-RAT-2-CD       TO L0570-MISC-RAT-2-CD.
           MOVE MIR-AGE-RAT-REASN-CD        TO L0570-AGE-RAT-REASN-CD.
           MOVE MIR-REDC-EP-PREM-AMT        TO L0570-REDC-EP-PREM-AMT.
           MOVE MIR-OWN-OCCP-PREM-AMT       TO L0570-OWN-OCCP-PREM-AMT.
           MOVE MIR-CVG-LTA-PREM-AMT        TO L0570-CVG-LTA-PREM-AMT.
           MOVE MIR-CVG-LTB-PREM-AMT        TO L0570-CVG-LTB-PREM-AMT.
           MOVE MIR-PDISAB-PREM-AMT         TO L0570-PDISAB-PREM-AMT.
           MOVE MIR-CVG-COLA-PREM-AMT       TO L0570-CVG-COLA-PREM-AMT.

           MOVE MIR-AGT-ID-T (01)           TO L0570-AGT-ID (01).
           MOVE MIR-CVG-AGT-SHR-PCT-T (01)  TO L0570-AGT-SHR-PCT (01).
           MOVE MIR-CPREM-CALC-CD-T (01)    TO L0570-CPREM-CALC-CD (01).
           MOVE MIR-FYR-COMM-CALC-CD-T (01) TO
                                            L0570-FYR-COMM-CALC-CD (01).
           MOVE MIR-RENW-COMM-CALC-CD-T (01) TO
                                          L0570-RENW-COMM-CALC-CD (01).
           MOVE MIR-COMM-RT-TBAC-ID-T (01)  TO
                                          L0570-COMM-RT-TBAC-ID (01).
           MOVE MIR-OVRID-BASE-AGT-ID-T (01) TO
                                          L0570-OVRID-BASE-AGT-ID (01).
           MOVE MIR-OVRID-ID-T (01)         TO L0570-OVRID-ID (01).
           MOVE MIR-ADDL-FYR-COMM-RT-T (01) TO
                                          L0570-ADDL-FYR-COMM-RT (01).
           MOVE MIR-CVG-AGT-CPREM-AMT-T (01) TO
                                          L0570-CPREM-AMT (01).
028786     MOVE MIR-CPREM-MODE-CALC-CD-T (1) TO
028786                                    L0570-CPREM-MODE-CALC-CD (1).

           MOVE MIR-AGT-ID-T (02)           TO L0570-AGT-ID (02).
           MOVE MIR-CVG-AGT-SHR-PCT-T (02)  TO L0570-AGT-SHR-PCT (02).
           MOVE MIR-CPREM-CALC-CD-T (02)    TO L0570-CPREM-CALC-CD (02).
           MOVE MIR-FYR-COMM-CALC-CD-T (02) TO
                                          L0570-FYR-COMM-CALC-CD (02).
           MOVE MIR-RENW-COMM-CALC-CD-T (02) TO
                                          L0570-RENW-COMM-CALC-CD (02).
           MOVE MIR-COMM-RT-TBAC-ID-T (02)  TO
                                          L0570-COMM-RT-TBAC-ID (02).
           MOVE MIR-OVRID-ID-T (02)         TO L0570-OVRID-ID (02).
           MOVE MIR-OVRID-BASE-AGT-ID-T (02) TO
                                          L0570-OVRID-BASE-AGT-ID (02).
           MOVE MIR-ADDL-FYR-COMM-RT-T (02) TO
                                          L0570-ADDL-FYR-COMM-RT (02).
           MOVE MIR-CVG-AGT-CPREM-AMT-T (02) TO L0570-CPREM-AMT (02).
028786     MOVE MIR-CPREM-MODE-CALC-CD-T (2) TO
028786                                    L0570-CPREM-MODE-CALC-CD (2).

           MOVE MIR-AGT-ID-T (03)           TO L0570-AGT-ID (03).
           MOVE MIR-CVG-AGT-SHR-PCT-T (03)  TO L0570-AGT-SHR-PCT (03).
           MOVE MIR-CPREM-CALC-CD-T (03)    TO L0570-CPREM-CALC-CD (03).
           MOVE MIR-FYR-COMM-CALC-CD-T (03) TO
                                          L0570-FYR-COMM-CALC-CD (03).
           MOVE MIR-RENW-COMM-CALC-CD-T (03) TO
                                          L0570-RENW-COMM-CALC-CD (03).
           MOVE MIR-COMM-RT-TBAC-ID-T (03)  TO
                                          L0570-COMM-RT-TBAC-ID (03).
           MOVE MIR-OVRID-ID-T (03)         TO L0570-OVRID-ID (03).
           MOVE MIR-OVRID-BASE-AGT-ID-T (03) TO
                                          L0570-OVRID-BASE-AGT-ID (03).
           MOVE MIR-ADDL-FYR-COMM-RT-T (03) TO
                                          L0570-ADDL-FYR-COMM-RT (03).
           MOVE MIR-CVG-AGT-CPREM-AMT-T (03) TO L0570-CPREM-AMT (03).
028786     MOVE MIR-CPREM-MODE-CALC-CD-T (3) TO
028786                                    L0570-CPREM-MODE-CALC-CD (3).

           MOVE MIR-DPOS-TRM-MO-DUR         TO L0570-DPOS-TRM-DUR-MO.
           MOVE MIR-DPOS-TRM-DY-DUR         TO L0570-DPOS-TRM-DUR-DY.
           MOVE MIR-CVG-WTHDR-ORDR-CD       TO L0570-WTHDR-ORDR-CD.
           MOVE MIR-CVG-INT-PAYO-CD         TO L0570-INT-PAYO-CD.
           MOVE MIR-CONN-POL-ID             TO L0570-CONN-POL-ID.
           MOVE MIR-CONN-CVG-NUM            TO L0570-CONN-CVG-NUM.
           MOVE MIR-CVG-CONN-REASN-CD       TO L0570-CONN-REASN-CD.
           MOVE MIR-IA-QUOT-NUM             TO L0570-IA-QUOT-NUM.
           MOVE MIR-OUT-ALLOC-AMT-PCT       TO L0570-OUT-ALLOC-AMT-PCT.
           MOVE MIR-CVG-OUT-ALLOC-CD        TO L0570-OUT-ALLOC-CD.
           MOVE MIR-DIA-SWP-THRSHD-AMT      TO L0570-DIA-SWP-THRSHD-AMT.
           MOVE MIR-DIA-SWP-THRSHD-CD       TO L0570-DIA-SWP-THRSHD-CD.
           MOVE MIR-MNPMT-TRG-LTD-AMT       TO L0570-MNPMT-TRG-LTD-AMT.
           MOVE MIR-COMM-TRG-CALC-CD        TO L0570-COMM-TRG-CALC-CD.
           MOVE MIR-PMT-LOAD-TRG-CD         TO L0570-PMT-LOAD-TRG-CD.
           MOVE MIR-GIR-SEND-LTR-IND        TO L0570-GIR-SND-LTR-IND.
           MOVE MIR-GIR-OPT-REMN-QTY        TO L0570-GIR-OPT-REMN-QTY.
           MOVE MIR-GIR-OPT-REMN-AMT        TO L0570-GIR-OPT-REMN-AMT.
           MOVE MIR-CVG-GUAR-INT-CD         TO L0570-GUAR-INT-CD.
           MOVE MIR-GUAR-INT-PERI-DUR       TO L0570-GUAR-INT-PERI-DUR.
           MOVE MIR-GUAR-INT-STRT-DT        TO L0570-GUAR-INT-STRT-DT.
           MOVE MIR-GUAR-INT-END-DT         TO L0570-GUAR-INT-END-DT.
           MOVE MIR-CVG-GUAR-INT-PCT        TO L0570-GUAR-INT-PCT.
           MOVE MIR-GUAR-IMPRD-INT-PCT      TO L0570-GUAR-IMPRD-INT-PCT.
           MOVE MIR-CVG-ORIG-CD             TO L0570-ORIG-CD.
           MOVE MIR-CVG-ROLOVR-DT-IND       TO L0570-CVG-ROLOVR-DT-IND.
           MOVE MIR-PREV-RENW-RT-CD         TO L0570-PREV-RENW-RT-CD.
           MOVE MIR-CVG-NXT-RENW-RT-CD      TO L0570-CVG-NXT-RENW-RT-CD.
           MOVE MIR-CVG-PREV-CPI-FCT        TO L0570-CVG-PREV-CPI-FCT.
           MOVE MIR-CVG-NXT-CPI-FCT         TO L0570-CVG-NXT-CPI-FCT.
           MOVE MIR-CVG-PREV-FACE-AMT       TO L0570-PREV-FACE-AMT.

           MOVE MIR-CVG-UWG-AMT             TO L0570-UWG-AMT.
           MOVE MIR-UWG-AMT-REASN-CD        TO L0570-UWG-AMT-REASN-CD.
           MOVE MIR-CVG-WP-IND              TO L0570-WP-IND.

           MOVE MIR-MAT-XPRY-DT-IND         TO L0570-MAT-XPRY-DT-IND.

012525     MOVE MIR-CVG-MAT-XPRY-AGE        TO L0570-CVG-MAT-XPRY-AGE.
012525     MOVE MIR-CVG-MAT-XPRY-DUR        TO L0570-CVG-MAT-XPRY-DUR.

           MOVE MIR-CVG-WP-XPRY-DT          TO L0570-WP-XPRY-DT.
           MOVE MIR-CVG-AD-XPRY-DT          TO L0570-AD-XPRY-DT.
           MOVE MIR-CVG-COMIT-RT-IND        TO L0570-COMIT-RT-IND.
           MOVE MIR-COMIT-RT-EFF-DT         TO L0570-COMIT-RT-EFF-DT.
           MOVE MIR-COMIT-RT-END-DT         TO L0570-COMIT-RT-END-DT.
           MOVE MIR-CVG-MAX-COMIT-AMT       TO L0570-MAC-COMIT-AMT.
           MOVE MIR-CVG-COMIT-PCT           TO L0570-COMIT-PCT.
           MOVE MIR-COMM-CHNG-CD-T (01)     TO L0570-COMM-CHNG-CD (01).
           MOVE MIR-COMM-CHNG-CD-T (02)     TO L0570-COMM-CHNG-CD (02).
           MOVE MIR-COMM-CHNG-CD-T (03)     TO L0570-COMM-CHNG-CD (03).

018633*    MOVE WS-OLD-CVG-CLI-INFO         TO L0570-HOLD-CLI-INFO.
018633*    MOVE WS-OLD-CVG-AGT-INFO         TO L0570-HOLD-AGT-COMM-INFO.
018633     MOVE LCOMM-CVG-CLI-INFO          TO L0570-HOLD-CLI-INFO.
018633     MOVE LCOMM-CVG-AGT-INFO          TO L0570-HOLD-AGT-COMM-INFO.

           IF MIR-AGT-ID-T (01) = SPACES
               MOVE SPACES TO  L0570-AGT-COMM-INFO (01)
           END-IF.

           IF MIR-AGT-ID-T (02) = SPACES
               MOVE SPACES TO  L0570-AGT-COMM-INFO (02)
           END-IF.

           IF MIR-AGT-ID-T (03) = SPACES
               MOVE SPACES TO  L0570-AGT-COMM-INFO (03)
           END-IF.

016440*    MOVE MIR-UW-USER-ID              TO L0580-UW-USER-ID.
016440*    MOVE MIR-UWG-REQIR-ESTB-IND      TO L0580-UWG-REQIR-ESTB-IND.
016440*    MOVE MIR-CVG-NMED-CD             TO L0580-CVG-NMED-CD.
016440*    MOVE MIR-CVG-PMED-CD             TO L0580-CVG-PMED-CD.
016440*    MOVE MIR-CVG-PHYS-EXAM-CD        TO L0580-CVG-PHYS-EXAM-CD.
016440*    MOVE MIR-CVG-INTRNL-EXAM-CD      TO L0580-CVG-INTRNL-EXAM-CD.
016440*    MOVE MIR-CVG-EKG-CD              TO L0580-CVG-EKG-CD.
016440*    MOVE MIR-CVG-XRAY-CD             TO L0580-CVG-XRAY-CD.
016440*    MOVE MIR-CVG-HO-SPCMN-CD         TO L0580-CVG-HO-SPCMN-CD.
016440*    MOVE MIR-CVG-STRS-EKG-CD         TO L0580-CVG-STRS-EKG-CD.
016440*    MOVE MIR-CVG-INSPC-RPT-CD        TO L0580-CVG-INSPC-RPT-CD.
016440*    MOVE MIR-CVG-APS-CD              TO L0580-CVG-APS-CD.
016440*    MOVE MIR-UWG-USER-DEFN-1-CD      TO L0580-UWG-USER-DEFN-1-CD.
016440*    MOVE MIR-UWG-USER-DEFN-2-CD      TO L0580-UWG-USER-DEFN-2-CD.
016440*    MOVE MIR-UWG-USER-DEFN-3-CD      TO L0580-UWG-USER-DEFN-3-CD.
016440*    MOVE MIR-UWG-USER-DEFN-4-CD      TO L0580-UWG-USER-DEFN-4-CD.
016440*    MOVE MIR-UWG-USER-DEFN-5-CD      TO L0580-UWG-USER-DEFN-5-CD.
016440*    MOVE MIR-CVG-OCCP-CLAS-CD        TO L0580-CVG-OCCP-CLAS-CD.
016440*    MOVE MIR-CVG-SALE-SRC-CD         TO L0580-CVG-SALE-SRC-CD.
016440*    MOVE MIR-CVG-INCM-BRCKT-CD       TO L0580-CVG-INCM-BRCKT-CD.
016440*    MOVE MIR-CVG-PRST-RAT-PCT        TO L0580-CVG-PRST-RAT-PCT.
016440*    MOVE MIR-MORT-ASSESS-PCT         TO WS-DISPLAY-999.
016440*    MOVE WS-DISPLAY-999              TO L0580-MORT-ASSESS-PCT.
016440*    MOVE MIR-CVG-UWGDECN-CD          TO L0580-CVG-UWGDECN-CD.
016440*    MOVE MIR-CVG-UWGDECN-SUB-CD      TO L0580-CVG-UWGDECN-SUB-CD.
016440*    MOVE MIR-CVG-UWG-EXCL-1-CD-T (1) TO
016440*                                   L0580-CVG-UWG-EXCL-CD-T (1).
016440*    MOVE MIR-CVG-UWG-EXCL-1-CD-T (2) TO
016440*                                   L0580-CVG-UWG-EXCL-CD-T (2).
016440*    MOVE MIR-CVG-UWG-EXCL-1-CD-T (3) TO
016440*                                   L0580-CVG-UWG-EXCL-CD-T (3).
016440*    MOVE MIR-SNGL-CASE-AGRE-IND      TO L0580-SNGL-CASE-AGRE-IND.
016440*    MOVE MIR-CVG-NMED-PRVLG-IND      TO L0580-CVG-NMED-PRVLG-IND.

           PERFORM 2210-SET-CVG-COMM-TRG-AMT
              THRU 2210-SET-CVG-COMM-TRG-AMT-X.

           IF MIR-CVG-COMM-TRG-AMT = WS-CVG-COMM-TRG-AMT
              MOVE SPACES                   TO L0570-COMM-TRG-AMT
           ELSE
              MOVE MIR-CVG-COMM-TRG-AMT     TO L0570-COMM-TRG-AMT
           END-IF.

           PERFORM 2220-SET-PMT-LOAD-TRG-AMT
              THRU 2220-SET-PMT-LOAD-TRG-AMT-X.

           IF MIR-PMT-LOAD-TRG-AMT = WS-PMT-LOAD-TRG-AMT
              MOVE SPACES                   TO L0570-PMT-LOAD-TRG-AMT
           ELSE
              MOVE MIR-PMT-LOAD-TRG-AMT     TO L0570-PMT-LOAD-TRG-AMT
           END-IF.

016440*    IF MIR-CVG-UWGDECN-CD = WCVGS-CVG-UWGDECN-CD (I)
016440*       SET WS-CVG-UWGDECN-CHG-NO      TO TRUE
016440*    ELSE
016440*       SET WS-CVG-UWGDECN-CHG-YES     TO TRUE
016440*    END-IF.

016306     MOVE MIR-ANN-MTG-INT-PCT       TO L0570-ANN-MTG-INT-PCT.
018763*    MOVE MIR-CVG-INT-CMPND-CD      TO L0570-CVG-INT-CMPND-CD.
018763     MOVE MIR-INT-CMPND-FREQ-CD     TO L0570-INT-CMPND-FREQ-CD.
016306     MOVE MIR-CVG-MTG-REPAY-AMT     TO L0570-CVG-MTG-REPAY-AMT.
016306     MOVE MIR-MTG-REPAY-FREQ-CD     TO L0570-MTG-REPAY-FREQ-CD.
016306     MOVE MIR-PREV-SUM-INS-AMT      TO L0570-PREV-SUM-INS-AMT.
018846     MOVE MIR-PLAN-FND-TYP-CD       TO L0570-PLAN-FND-TYP-CD.

       2200-MOVE-MIR-TO-WORK-AREA-X.
           EXIT.


      *-------------------------
       2210-SET-CVG-COMM-TRG-AMT.
      *-------------------------

020874*    MOVE ZEROES                       TO L0290-INPUT-NUMBER.
020874     MOVE ZEROES                       TO L0290-INPUT-V00.
           MOVE 0                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-COMM-TRG-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO WS-CVG-COMM-TRG-AMT.
      *
           IF RPOL-POL-INS-TYP-UL
023137         PERFORM  6090-0000-INIT-PARM-INFO
023137             THRU 6090-0000-INIT-PARM-INFO-X
               MOVE I                      TO L6090-CVG-NUM
016328*        IF NOT L0570-NB-STAT-SETTLED
016328*        AND    L0570-CVG-ISSUE-DT = HIGH-VALUES
016328*            MOVE WGLOB-PROCESS-DATE TO L6090-EFF-DT
016328*        ELSE
016328*            MOVE WCVGS-CVG-ISS-EFF-DT (I) TO L6090-EFF-DT
016328*        END-IF
016328         IF  WCVGS-CVG-STAT-BEFORE-SETL (L6090-CVG-NUM)
016328             MOVE WCVGS-CVG-ISS-EFF-DT  (L6090-CVG-NUM)
016328                                           TO L6090-EFF-DT
016328         ELSE
016328             MOVE WGLOB-PROCESS-DATE       TO L6090-EFF-DT
016328         END-IF
023137*        PERFORM  6090-1000-COMPUTE-COMM-TARG
023137*            THRU 6090-1000-COMPUTE-COMM-TARG-X
023137         PERFORM  6090-2000-CALC-COMM-TARG-CVG
023137             THRU 6090-2000-CALC-COMM-TARG-CVG-X
               IF  L6090-RETRN-OK
020874*            MOVE L6090-COMM-TRG-AMT   TO L0290-INPUT-NUMBER
023137*            MOVE L6090-COMM-TRG-AMT   TO L0290-INPUT-V00
023137             MOVE L6090-COMM-TRG-AMT (I) TO L0290-INPUT-V00
                   MOVE 0                    TO L0290-PRECISION
                   MOVE LENGTH OF MIR-CVG-COMM-TRG-AMT
                                             TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA    TO WS-CVG-COMM-TRG-AMT
               END-IF
           END-IF.

       2210-SET-CVG-COMM-TRG-AMT-X.
           EXIT.


      *-------------------------
       2220-SET-PMT-LOAD-TRG-AMT.
      *-------------------------

020874*    MOVE ZEROES                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROES                        TO L0290-INPUT-V00.
           MOVE 0                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PMT-LOAD-TRG-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO WS-PMT-LOAD-TRG-AMT.
      *
           IF RPOL-POL-INS-TYP-UL
023137         PERFORM  6100-0000-INIT-PARM-INFO
023137             THRU 6100-0000-INIT-PARM-INFO-X
               MOVE I                      TO L6100-CVG-NUM
016328*        IF NOT L0570-NB-STAT-SETTLED
016328*        AND    L0570-CVG-ISSUE-DT = HIGH-VALUES
016328*            MOVE WGLOB-PROCESS-DATE TO L6100-EFF-DT
016328*        ELSE
016328*            MOVE WCVGS-CVG-ISS-EFF-DT (I) TO L6100-EFF-DT
016328*        END-IF
016328         IF  WCVGS-CVG-STAT-BEFORE-SETL (L6090-CVG-NUM)
016328             MOVE WCVGS-CVG-ISS-EFF-DT  (L6090-CVG-NUM)
016328                                           TO L6100-EFF-DT
016328         ELSE
016328             MOVE WGLOB-PROCESS-DATE       TO L6100-EFF-DT
016328         END-IF
023137*        PERFORM  6100-1000-COMPUTE-FEL-TARG
023137*            THRU 6100-1000-COMPUTE-FEL-TARG-X
023137         PERFORM  6100-2000-CALC-FEL-TARG-CVG
023137             THRU 6100-2000-CALC-FEL-TARG-CVG-X
               IF  L6100-RETRN-OK
020874*            MOVE L6100-PMT-LOAD-TRG-AMT TO L0290-INPUT-NUMBER
023137*            MOVE L6100-PMT-LOAD-TRG-AMT TO L0290-INPUT-V00
023137             MOVE L6100-PMT-LOAD-TRG-AMT (I) TO L0290-INPUT-V00
                   MOVE 0                      TO L0290-PRECISION
                   MOVE LENGTH OF MIR-PMT-LOAD-TRG-AMT TO
                                                  L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA   TO WS-PMT-LOAD-TRG-AMT
               END-IF
           END-IF.

       2220-SET-PMT-LOAD-TRG-AMT-X.
           EXIT.
      /
      *---------------------
       2300-COVERAGE-UPDATE.
      *---------------------


           SET WS-UPDATE-NOT-REQUIRED TO TRUE.
      *
      *  POLICY CHECK (FOR ISSUE LOCATION / ISSUE DATE) FOR UPDATED
      *
           EVALUATE TRUE

                WHEN  RPOL-POL-ISS-EFF-DT = SPACES
                WHEN  RPOL-POL-ISS-EFF-DT = WWKDT-ZERO-DT
      *MSG: COVERAGE CANNOT BE MAINTAINED WITH NO POLICY ISSUE DATE
                   MOVE 'CS80220001'       TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    PERFORM  POL-3000-UNLOCK
                        THRU POL-3000-UNLOCK-X
                    MOVE SPACES              TO MIR-PLAN-ID
                    GO TO 2300-COVERAGE-UPDATE-X

                WHEN  RPOL-POL-ISS-LOC-CD = SPACES
                   MOVE 'CS80220002'       TO WGLOB-MSG-REF-INFO
      *MSG: COVERAGE CANNOT BE MAINTAINED WITH NO POLICY ISSUE LOCATION
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    PERFORM  POL-3000-UNLOCK
                        THRU POL-3000-UNLOCK-X
                    MOVE SPACES              TO MIR-PLAN-ID
                    GO TO 2300-COVERAGE-UPDATE-X

           END-EVALUATE.
           MOVE WS-CVG-NUM TO I.

           IF  WCVGS-PLAN-ID (I) = SPACES
               PERFORM  PH-1000-CREATE
                   THRU PH-1000-CREATE-X
           ELSE
025692*        MOVE WCVGS-PLAN-ID (I)       TO WPH-PLAN-ID
035251*        IF  WCVGS-PLAN-ID-BASE-3-5  (I) = 'RPU'
035251*        OR  WCVGS-PLAN-ID-BASE-3-5  (I) = 'ETI'
035251*            MOVE WCVGS-ORIG-PLAN-ID (I) TO WPH-PLAN-ID
035251*        ELSE
035251*            MOVE WCVGS-PLAN-ID      (I) TO WPH-PLAN-ID
035251*        END-IF
035251         MOVE WCVGS-PLAN-ID      (I)  TO WPH-PLAN-ID
               PERFORM  PH-1000-READ
                   THRU PH-1000-READ-X
               IF WPH-IO-OK
                   SET WS-PLAN-ERROR-NOT-FOUND TO TRUE
               ELSE
                   MOVE WPH-KEY             TO WGLOB-MSG-PARM (1)
                   SET WS-PLAN-ERROR-FOUND TO TRUE
      *MSG: PLAN @1 NOT FOUND
                   MOVE 'CS80220003'        TO WGLOB-MSG-REF-INFO
                   MOVE WPH-PLAN-ID         TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  WS-PLAN-ERROR-FOUND
               MOVE L0570-PLAN-ID           TO MIR-PLAN-ID
               GO TO 2300-COVERAGE-UPDATE-X
           END-IF.

      *
      * UPDATE COVERAGE
      *
           SET WS-UPDATE-REQUIRED TO TRUE.
           MOVE WS-CVG-NUM TO L0570-CVG-NUM.
           PERFORM  0570-1000-MAINTAIN-COVERAGE
               THRU 0570-1000-MAINTAIN-COVERAGE-X.


016440*    IF WS-CVG-UWGDECN-CHG-NO
016440*       MOVE WCVGS-CVG-UWGDECN-CD (I)   TO L0580-CVG-UWGDECN-CD
016440*       MOVE WCVGS-CVG-UWGDECN-CD (I)   TO MIR-CVG-UWGDECN-CD
016440*    END-IF.

016440*    MOVE WS-CVG-NUM TO L0580-CVG-NUM.
016440*    PERFORM  0580-1000-MAINTAIN-COVERAGE
016440*        THRU 0580-1000-MAINTAIN-COVERAGE-X.

      *
      * CHECK FOR GUIDELINE PREMIUM VIOLATION
      *
           MOVE L0570-CVG-NUM TO I.

029059*    IF  RPOL-POL-TAX-TYP-GDLN-RT
029059*    OR  RPOL-POL-TAX-TYP-GDLN-FORMULA
029059*    OR  RPOL-POL-TAX-TYP-GDLN-PROJ
029059*        PERFORM  0578-1000-BUILD-PARM-INFO
029059*            THRU 0578-1000-BUILD-PARM-INFO-X
029059*        SET L0578-CVG-CHNG-OCCURRED (I)   TO TRUE
029059*        IF  L0570-CVG-ISSUE-DT      = HIGH-VALUES
029059*            MOVE WGLOB-PROCESS-DATE       TO L0578-EFF-DT
029059*        ELSE
029059*            MOVE WCVGS-CVG-ISS-EFF-DT (I) TO L0578-EFF-DT
029059*        END-IF
029059*        PERFORM  0578-1000-CALC-TEST-GDLN
029059*            THRU 0578-1000-CALC-TEST-GDLN-X
029059*    END-IF.

           PERFORM  7500-MOVE-CVG-TO-MIR
               THRU 7500-MOVE-CVG-TO-MIR-X.

           PERFORM  8000-MOVE-POL-TO-MIR
               THRU 8000-MOVE-POL-TO-MIR-X.

           PERFORM  5230-UPDATE-IMBEDDED-BEN
               THRU 5230-UPDATE-IMBEDDED-BEN-X.

016503*    IF  WCVGS-CVG-STAT-IN-FORCE (I)
016503*        MOVE WWKDT-ZERO-DT     TO RPOL-POL-NXT-ACTV-DT
016503*        IF RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*            MOVE 'RSH'         TO RPOL-NXT-ACTV-TYP-CD
016503*        END-IF
016503*    END-IF.

       2300-COVERAGE-UPDATE-X.
           EXIT.
      /
      *----------------------
       2500-MOVE-EDIT-TO-MIR.
      *----------------------

           IF  L0570-FACE-AMT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE L0570-FACE-AMT     TO MIR-CVG-FACE-AMT
           END-IF.

           IF  L0570-AD-FACE-AMT = HIGH-VALUES
              CONTINUE
           ELSE
               MOVE L0570-AD-FACE-AMT  TO MIR-CVG-AD-FACE-AMT
           END-IF.

           IF  L0570-WP-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE L0570-WP-IND       TO MIR-CVG-WP-IND
           END-IF.

       2500-MOVE-EDIT-TO-MIR-X.
           EXIT.

      *-------------------------
       5230-UPDATE-IMBEDDED-BEN.
      *-------------------------

      ***************************************************************
      *    UPDATE IMBEDDED BENEFIT INDICATORS - THE IMBEDDED BENEFIT
      *    INDICATORS ON A GIR COVERAGE ARE DEPENDENT ON THOSE ON THE
      *    RELATED CVG.  THE BENEFITS DISPLAYED FOR THE GIR COVERAGE
      *    MAY HAVE TO BE REDISPLAYED IF THEY ARE CHANGED AFTER THE
      *    IMBEDDED BENEFITS ON THE GIR COVERAGE HAVE BEEN EDITTED
      ***************************************************************

           MOVE WS-CVG-NUM                 TO I.

015951*    IF NOT A HEALTH POLICY, CHECK FOR DI COVERAGES
015951     SET WS-HEALTH-POL-CVG-NOT-FOUND TO TRUE.
015951     IF RPOL-POL-INS-TYP-HEALTH
015951        SET WS-HEALTH-POL-CVG-FOUND  TO TRUE
015951     ELSE
015951        PERFORM 5235-CHECK-FOR-DI-CVG
015951           THRU 5235-CHECK-FOR-DI-CVG-X
015951           VARYING I FROM 1 BY 1
015951             UNTIL I > RPOL-POL-CVG-REC-CTR-N
015951                OR WS-HEALTH-POL-CVG-FOUND
015951     END-IF.

015951*    IF NOT RPOL-POL-INS-TYP-HEALTH
015951     IF NOT WS-HEALTH-POL-CVG-FOUND
               GO TO 5230-UPDATE-IMBEDDED-BEN-X
           END-IF.

           IF WCVGS-CVG-SUPP-BNFT-GIR (I)
               GO TO 5230-UPDATE-IMBEDDED-BEN-X
           END-IF.

           MOVE WCVGS-CVG-STBL-1-CD (I)      TO  MIR-CVG-STBL-1-CD.

           MOVE WCVGS-CVG-STBL-2-CD (I)      TO  MIR-CVG-STBL-2-CD.

           MOVE WCVGS-CVG-STBL-3-CD (I)      TO  MIR-CVG-STBL-3-CD.

           MOVE WCVGS-CVG-STBL-4-CD (I)      TO  MIR-CVG-STBL-4-CD.

           MOVE WCVGS-CVG-COLA-SELCT-CD (I)  TO MIR-CVG-COLA-SELCT-CD.

           MOVE WCVGS-REDC-EP-SELCT-IND (I)  TO MIR-REDC-EP-SELCT-IND.

           MOVE WCVGS-OWN-OCCP-SELCT-IND (I) TO MIR-OWN-OCCP-SELCT-IND.

           MOVE WCVGS-CVG-LTA-SELCT-IND (I)  TO MIR-CVG-LTA-SELCT-IND.

           MOVE WCVGS-CVG-LTB-SELCT-IND (I)  TO MIR-CVG-LTB-SELCT-IND.

           MOVE WCVGS-PDISAB-SELCT-IND (I)   TO MIR-PDISAB-SELCT-IND.

       5230-UPDATE-IMBEDDED-BEN-X.
           EXIT.

015951*----------------------
015951 5235-CHECK-FOR-DI-CVG.
015951*----------------------
015951
015951     IF  WCVGS-CVG-INS-TYP-HEALTH (I)
015951     AND WCVGS-CVG-STAT-IN-FORCE (I)
015951         SET WS-HEALTH-POL-CVG-FOUND TO TRUE
015951     END-IF.
015951
015951 5235-CHECK-FOR-DI-CVG-X.
015951     EXIT.

      *------------------------
       7500-MOVE-CVG-TO-MIR.
      *------------------------

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-3100-GET-PRIM-INSRD
               THRU 2430-3100-GET-PRIM-INSRD-X.

           IF  NOT  L2430-RELATIONSHIP-FOUND
               MOVE SPACES                  TO MIR-DV-INSRD-CLI-NM
           ELSE

               INITIALIZE L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                  MOVE L2430-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
               ELSE
                  MOVE L2430-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
                  MOVE L2430-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
                  MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
                  MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD

               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X

               MOVE L0620-SCREEN-NAME        TO MIR-DV-INSRD-CLI-NM

           END-IF.

           IF L0570-CF-REC-CTR = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-CSN-REC-CTR-N (I) TO MIR-CVG-CSN-REC-CTR
           END-IF.

           IF L0570-CSTAT-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-CSTAT-CD (I)   TO MIR-CVG-CSTAT-CD
           END-IF.

           IF L0570-PLAN-ID = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-PLAN-ID (I)        TO MIR-PLAN-ID
           END-IF.

           IF L0570-SMKR-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-SMKR-CD (I)    TO MIR-CVG-SMKR-CD
           END-IF.

           IF L0570-PAR-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-PAR-CD (I)     TO MIR-CVG-PAR-CD
           END-IF.

           IF L0570-SEX-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-SEX-CD (I)     TO MIR-CVG-SEX-CD
           END-IF.
      *
           IF L0570-RT-AGE = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-RT-AGE (I)     TO MIR-CVG-RT-AGE
           END-IF.
      *
           IF L0570-STBL-1-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-STBL-1-CD (I)  TO MIR-CVG-STBL-1-CD
           END-IF.
      *
           IF L0570-STBL-2-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-STBL-2-CD (I)  TO MIR-CVG-STBL-2-CD
           END-IF.
      *
           IF L0570-STBL-3-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-STBL-3-CD (I)  TO MIR-CVG-STBL-3-CD
           END-IF.
      *
           IF L0570-STBL-4-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-STBL-4-CD (I)  TO MIR-CVG-STBL-4-CD
           END-IF.
      *
           IF L0570-FACE-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-FACE-AMT (I) * 100
020874         MOVE WCVGS-CVG-FACE-AMT (I)   TO L0290-INPUT-V02
               MOVE 2                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-FACE-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-FACE-AMT
           END-IF.
      *
           IF L0570-AD-FACE-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-AD-FACE-AMT (I)
020874*                                                            * 100
020874         MOVE WCVGS-CVG-AD-FACE-AMT (I)       TO L0290-INPUT-V02
               MOVE 2                               TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-AD-FACE-AMT   TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA            TO MIR-CVG-AD-FACE-AMT
           END-IF.
      *
           IF L0570-AD-MULT-FCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        MOVE WCVGS-CVG-AD-MULT-FCT (I) TO WS-INPUT-1-2
020874*        MOVE WS-INPUT-1-2             TO MIR-CVG-AD-MULT-FCT
020874         MOVE WCVGS-CVG-AD-MULT-FCT (I) TO L0290-INPUT-V02
020874         MOVE 2                         TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-AD-MULT-FCT
020874                                        TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA         TO MIR-CVG-AD-MULT-FCT
           END-IF.
      *
           IF L0570-WP-MULT-FCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        MOVE WCVGS-CVG-WP-MULT-FCT (I) TO WS-INPUT-1-2
020874*        MOVE WS-INPUT-1-2             TO MIR-CVG-WP-MULT-FCT
020874         MOVE WCVGS-CVG-WP-MULT-FCT (I)  TO L0290-INPUT-V02
020874         MOVE 2                          TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-WP-MULT-FCT
020874                                         TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA          TO MIR-CVG-WP-MULT-FCT
           END-IF.
      *
           IF L0570-SUM-INS-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-SUM-INS-AMT (I)
020874*                                                            * 100
020874         MOVE WCVGS-CVG-SUM-INS-AMT (I) TO L0290-INPUT-V02
               MOVE 2                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-SUM-INS-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-SUM-INS-AMT
           END-IF.
      *
           IF L0570-CVG-ORIG-FACE-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                              = WCVGS-CVG-ORIG-FACE-AMT (I) * 100
020874         MOVE WCVGS-CVG-ORIG-FACE-AMT (I) TO L0290-INPUT-V02
               MOVE 2                           TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-ORIG-FACE-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-ORIG-FACE-AMT
           END-IF.
      *
           IF L0570-CVG-ENHC-TYP-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-ENHC-TYP-CD (I) TO MIR-CVG-ENHC-TYP-CD
           END-IF.
      *
           IF L0570-REDC-EP-SELCT-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-REDC-EP-SELCT-IND (I) TO MIR-REDC-EP-SELCT-IND
           END-IF.
      *
           IF L0570-OWN-OCCP-SELCT-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-OWN-OCCP-SELCT-IND (I)
                                               TO MIR-OWN-OCCP-SELCT-IND
           END-IF.
      *
           IF L0570-CVG-LTA-SELCT-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-LTA-SELCT-IND (I) TO MIR-CVG-LTA-SELCT-IND
           END-IF.
      *
           IF L0570-CVG-LTB-SELCT-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-LTB-SELCT-IND (I) TO MIR-CVG-LTB-SELCT-IND
           END-IF.
      *
           IF L0570-PDISAB-SELCT-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-PDISAB-SELCT-IND (I) TO MIR-PDISAB-SELCT-IND
           END-IF.
      *
           IF L0570-CVG-COLA-TYP-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-COLA-SELCT-CD (I) TO MIR-CVG-COLA-SELCT-CD
           END-IF.
      *
           IF L0570-REL-CVG-NUM = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-REL-CVG-NUM (I)    TO MIR-REL-CVG-NUM
           END-IF.
      *
           IF L0570-ULT-PREM-RT-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-ULT-PREM-RT-CD (I) TO MIR-ULT-PREM-RT-CD
           END-IF.
      *
           IF L0570-ULT-PREM-RT-AGE = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-ULT-PREM-RT-AGE-N (I) TO MIR-ULT-PREM-RT-AGE
           END-IF.
      *
           IF L0570-APP-NUM = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-POL-APP-NUM (I)    TO MIR-POL-APP-NUM
           END-IF.
      *
           IF L0570-APP-RECV-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-APP-RECV-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-CVG-APP-RECV-DT
           END-IF.
      *
           IF L0570-CVG-ISSUE-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-ISS-EFF-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-CVG-ISS-EFF-DT
           END-IF.
      *
           IF L0570-MAT-XPRY-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-MAT-XPRY-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-CVG-MAT-XPRY-DT
           END-IF.
      *
018905*    IF L0570-MAT-XPRY-AGE = HIGH-VALUES
018905*        CONTINUE
018905*    ELSE
018905*        MOVE WCVGS-CVG-MAT-XPRY-AGE (I)
018905*          TO MIR-CVG-MAT-XPRY-AGE
018905*    END-IF.
018905*
018905*    IF L0570-MAT-XPRY-DUR = HIGH-VALUES
018905*        CONTINUE
018905*    ELSE
018905*        MOVE WCVGS-CVG-MAT-XPRY-DUR (I)
018905*          TO MIR-CVG-MAT-XPRY-DUR
018905*    END-IF.

           IF L0570-PREM-CHNG-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-PREM-CHNG-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-CVG-PREM-CHNG-DT
           END-IF.
      *
           IF L0570-CNVR-XPRY-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-CNVR-XPRY-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-CVG-CNVR-XPRY-DT
           END-IF.
      *
           IF L0570-NOTI-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-NOTI-DT (I)    TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-CVG-NOTI-DT
           END-IF.
      *
           IF L0570-NOTI-REASN-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-NOTI-REASN-CD (I) TO MIR-CVG-NOTI-REASN-CD
           END-IF.
      *
           IF L0570-NOTI-DEPT-ID = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-NOTI-DEPT-ID (I) TO MIR-CVG-NOTI-DEPT-ID
           END-IF.
      *
           IF L0570-UNIT-VALU-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-UNIT-VALU-AMT (I)
020874         MOVE WCVGS-CVG-UNIT-VALU-AMT (I) TO L0290-INPUT-V00
               MOVE ZERO                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-UNIT-VALU-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-UNIT-VALU-AMT
           END-IF.
      *
           PERFORM  7510-SET-UP-INSURED-LINE
               THRU 7510-SET-UP-INSURED-LINE-X.
      *
           IF L0570-JNT-LIFE-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-JNT-LIFE-CD (I) TO MIR-CVG-JNT-LIFE-CD
           END-IF.
      *
025388*    IF L0570-LIVES-INSRD-CD = HIGH-VALUES
025388     IF L0570-LIVES-INSRD-QTY = HIGH-VALUES
               CONTINUE
           ELSE
025388*        MOVE WCVGS-CVG-LIVES-INSRD-CD (I)
025388*                                        TO MIR-CVG-LIVES-INSRD-CD
025388         MOVE WCVGS-LIVES-INSRD-QTY (I)
025388                                       TO MIR-LIVES-INSRD-QTY
           END-IF.
      *
           IF L0570-WP-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                               = WCVGS-CVG-WP-PREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-WP-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-WP-PREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-WP-PREM-AMT
           END-IF.
      *
           IF L0570-RESTR-PREM-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-RESTR-PREM-IND(I)
                                               TO MIR-CVG-RESTR-PREM-IND
           END-IF.
      *
           IF L0570-FE-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                                = WCVGS-CVG-FE-PREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-FE-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-FE-PREM-AMT TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY        TO TRUE
               SET  L0290-SIGN-POS-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-FE-PREM-AMT
           END-IF.
      *
           IF L0570-FE-UPREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                               = WCVGS-CVG-FE-UPREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-FE-UPREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                          TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-FE-UPREM-AMT TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY         TO TRUE
               SET  L0290-SIGN-POS-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-FE-UPREM-AMT
           END-IF.
      *
           IF L0570-FE-DUR = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-FE-DUR   (I) TO MIR-CVG-FE-DUR
           END-IF.
      *
           IF L0570-FE-REASN-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-FE-REASN-CD (I) TO MIR-CVG-FE-REASN-CD
           END-IF.
      *
           IF L0570-MPREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                                  = WCVGS-CVG-MPREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-MPREM-AMT (I)  TO L0290-INPUT-V02
               MOVE 2                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-MPREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-MPREM-AMT
           END-IF.
      *
           IF L0570-BASIC-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                             = WCVGS-CVG-BASIC-PREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-BASIC-PREM-AMT (I)  TO L0290-INPUT-V02
               MOVE 2                             TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-BASIC-PREM-AMT
                                                  TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-BASIC-PREM-AMT
           END-IF.
      *
           IF L0570-PFEE-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-PFEE-AMT (I) * 100
020874         MOVE WCVGS-CVG-PFEE-AMT (I)   TO L0290-INPUT-V02
               MOVE 2                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-PFEE-AMT TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY       TO TRUE
               SET  L0290-SIGN-POS-DISPLAY   TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-PFEE-AMT
           END-IF.
      *
           IF L0570-AD-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                                = WCVGS-CVG-AD-PREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-AD-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-AD-PREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-AD-PREM-AMT
           END-IF.
      *
           IF L0570-ME-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                                = WCVGS-CVG-ME-PREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-ME-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-ME-PREM-AMT TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-DISPLAY        TO TRUE
               SET  L0290-SIGN-POS-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-ME-PREM-AMT
           END-IF.
      *
           IF L0570-ME-FCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                WCVGS-CVG-ME-FCT (I) * 100
020874         MOVE WCVGS-CVG-ME-FCT (I)     TO L0290-INPUT-V02
016641         MOVE 2                        TO L0290-PRECISION
016641         MOVE LENGTH OF MIR-CVG-ME-FCT TO L0290-MAX-OUT-LEN
016641         SET L0290-SIGN-SUPPRESS       TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016641         MOVE L0290-OUTPUT-DATA        TO MIR-CVG-ME-FCT
016641*        MOVE WCVGS-CVG-ME-FCT(WS-CVG) TO EDIT-NUMBER-SIGN-1-2.
016641*        MOVE EDIT-NUMBER-SIGN-1-2     TO MIR-CVG-ME-FCT.
016641*        MOVE WCVGS-CVG-ME-FCT (I)     TO WS-INPUT-1-2-S
016641*        MOVE WS-INPUT-1-2-S           TO MIR-CVG-ME-FCT
           END-IF.
      *
           IF L0570-ME-RAT-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-ME-RAT-CD (I) TO MIR-CVG-ME-RAT-CD
           END-IF.
      *
           IF L0570-ME-DUR = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-ME-DUR (I) TO MIR-CVG-ME-DUR
           END-IF.
      *
           IF L0570-ME-REASN-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-ME-REASN-CD  (I) TO MIR-CVG-ME-REASN-CD
           END-IF.
      *
016440*    IF L0570-MISC-RAT-1-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-MISC-RAT-1-CD (I) TO MIR-CVG-MISC-RAT-1-CD
016440*    END-IF.
      *
016440*    IF L0570-MISC-RAT-2-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-MISC-RAT-2-CD (I) TO MIR-CVG-MISC-RAT-2-CD
016440*    END-IF.
      *

016440     MOVE WCVGS-CVG-PRT-DT (I)       TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
016440     MOVE L1640-EXTERNAL-DATE            TO MIR-CVG-PRT-DT.

           IF L0570-AGE-RAT-REASN-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-AGE-RAT-REASN-CD (I) TO MIR-AGE-RAT-REASN-CD
           END-IF.
      *
           IF L0570-REDC-EP-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                               = WCVGS-REDC-EP-PREM-AMT (I) * 100
020874         MOVE WCVGS-REDC-EP-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                          TO L0290-PRECISION
               MOVE LENGTH OF MIR-REDC-EP-PREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-REDC-EP-PREM-AMT
           END-IF.
      *
           IF L0570-OWN-OCCP-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                              = WCVGS-OWN-OCCP-PREM-AMT (I) * 100
020874         MOVE WCVGS-OWN-OCCP-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-OWN-OCCP-PREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-OWN-OCCP-PREM-AMT
           END-IF.
      *
           IF L0570-CVG-LTA-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                              = WCVGS-CVG-LTA-PREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-LTA-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                          TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-LTA-PREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-LTA-PREM-AMT
           END-IF.
      *
           IF L0570-CVG-LTB-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                               = WCVGS-CVG-LTB-PREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-LTB-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                          TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-LTB-PREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-LTB-PREM-AMT
           END-IF.
      *
           IF L0570-PDISAB-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                                = WCVGS-PDISAB-PREM-AMT (I) * 100
020874         MOVE WCVGS-PDISAB-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-PDISAB-PREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-PDISAB-PREM-AMT
           END-IF.
      *
           IF L0570-CVG-COLA-PREM-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                              = WCVGS-CVG-COLA-PREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-COLA-PREM-AMT (I) TO L0290-INPUT-V02
               MOVE 2                           TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-COLA-PREM-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CVG-COLA-PREM-AMT
           END-IF.
      *
      * SET UP AGENT INFORMATION
      *
           PERFORM  7530-SET-UP-AGENT-INFO
               THRU 7530-SET-UP-AGENT-INFO-X.
      *
           IF L0570-DPOS-TRM-DUR-MO = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-DPOS-TRM-MO-DUR (I) TO MIR-DPOS-TRM-MO-DUR
           END-IF.
      *
           IF L0570-DPOS-TRM-DUR-DY = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-DPOS-TRM-DY-DUR (I) TO MIR-DPOS-TRM-DY-DUR
           END-IF.
      *
           IF L0570-WTHDR-ORDR-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-WTHDR-ORDR-CD (I) TO MIR-CVG-WTHDR-ORDR-CD
           END-IF.
      *
           IF L0570-INT-PAYO-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-INT-PAYO-CD (I) TO MIR-CVG-INT-PAYO-CD
           END-IF.
      *
           IF L0570-CONN-POL-ID = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CONN-POL-ID (I) TO MIR-CONN-POL-ID
           END-IF.
      *
           IF L0570-CONN-CVG-NUM = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CONN-CVG-NUM (I) TO MIR-CONN-CVG-NUM
           END-IF.
      *
           IF L0570-CONN-REASN-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-CONN-REASN-CD (I) TO MIR-CVG-CONN-REASN-CD
           END-IF.
      *
           IF L0570-IA-QUOT-NUM = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-IA-QUOT-NUM   (I) TO MIR-IA-QUOT-NUM
           END-IF.
      *
           IF L0570-OUT-ALLOC-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-OUT-ALLOC-CD (I) TO MIR-CVG-OUT-ALLOC-CD
           END-IF.
      *
           IF L0570-OUT-ALLOC-AMT-PCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                             = WCVGS-OUT-ALLOC-AMT-PCT (I) * 1000
020874         MOVE WCVGS-OUT-ALLOC-AMT-PCT (I) TO  L0290-INPUT-V03
               MOVE 3                           TO  L0290-PRECISION
               MOVE LENGTH OF MIR-OUT-ALLOC-AMT-PCT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-OUT-ALLOC-AMT-PCT
           END-IF.
      *
           IF L0570-DIA-SWP-THRSHD-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                             = WCVGS-DIA-SWP-THRSHD-AMT (I) * 100
020874         MOVE WCVGS-DIA-SWP-THRSHD-AMT (I) TO L0290-INPUT-V02
               MOVE 2                            TO L0290-PRECISION
               MOVE LENGTH OF MIR-DIA-SWP-THRSHD-AMT
                                                    TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-DIA-SWP-THRSHD-AMT
           END-IF.
      *
           IF L0570-DIA-SWP-THRSHD-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-DIA-SWP-THRSHD-CD (I) TO MIR-DIA-SWP-THRSHD-CD
           END-IF.
      *
           IF L0570-MNPMT-TRG-LTD-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        MOVE WCVGS-MNPMT-TRG-LTD-AMT (I) TO L0290-INPUT-NUMBER
020874         MOVE WCVGS-MNPMT-TRG-LTD-AMT (I) TO L0290-INPUT-V00
               MOVE 0                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-MNPMT-TRG-LTD-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-MNPMT-TRG-LTD-AMT
           END-IF.
      *

           IF L0570-COMM-TRG-AMT = HIGH-VALUES
               CONTINUE
           ELSE
              PERFORM 7550-SET-CVG-COMM-TRG-AMT
                 THRU 7550-SET-CVG-COMM-TRG-AMT-X
              MOVE WS-CVG-COMM-TRG-AMT      TO MIR-CVG-COMM-TRG-AMT
           END-IF.


           IF L0570-PMT-LOAD-TRG-AMT = HIGH-VALUES
               CONTINUE
           ELSE
               PERFORM 7560-SET-PMT-LOAD-TRG-AMT
                  THRU 7560-SET-PMT-LOAD-TRG-AMT-X
               MOVE WS-PMT-LOAD-TRG-AMT     TO MIR-PMT-LOAD-TRG-AMT
           END-IF.


           IF L0570-COMM-TRG-CALC-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-COMM-TRG-CALC-CD (I) TO MIR-COMM-TRG-CALC-CD
           END-IF.
      *
           IF L0570-PMT-LOAD-TRG-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-PMT-LOAD-TRG-CD (I) TO MIR-PMT-LOAD-TRG-CD
           END-IF.
      *
           IF L0570-GIR-SND-LTR-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-GIR-SEND-LTR-IND (I) TO MIR-GIR-SEND-LTR-IND
           END-IF.
      *
           IF L0570-GIR-OPT-REMN-QTY = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-GIR-OPT-REMN-QTY (I) TO MIR-GIR-OPT-REMN-QTY
           END-IF.
      *
           IF L0570-GIR-OPT-REMN-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                               = WCVGS-GIR-OPT-REMN-AMT (I) * 100
020874         MOVE WCVGS-GIR-OPT-REMN-AMT (I) TO L0290-INPUT-V02
               MOVE 2                          TO L0290-PRECISION
               MOVE LENGTH OF MIR-GIR-OPT-REMN-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA       TO MIR-GIR-OPT-REMN-AMT
           END-IF.
      *
           IF L0570-GUAR-INT-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-GUAR-INT-CD (I) TO MIR-CVG-GUAR-INT-CD
           END-IF.
      *
           IF L0570-GUAR-INT-PERI-DUR = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-GUAR-INT-PERI-DUR (I) TO MIR-GUAR-INT-PERI-DUR
           END-IF.
      *
           IF L0570-GUAR-INT-STRT-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-GUAR-INT-STRT-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE         TO MIR-GUAR-INT-STRT-DT
           END-IF.
      *
           IF L0570-GUAR-INT-END-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-GUAR-INT-END-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE         TO MIR-GUAR-INT-END-DT
           END-IF.
      *
           IF L0570-GUAR-INT-PCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        MOVE WCVGS-CVG-GUAR-INT-PCT (I) TO WS-INPUT-3-6
020874*        MOVE WS-INPUT-3-6            TO MIR-CVG-GUAR-INT-PCT
020874         MOVE WCVGS-CVG-GUAR-INT-PCT (I) TO L0290-INPUT-V06
020874         MOVE 6                          TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-GUAR-INT-PCT
020874                                         TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA          TO MIR-CVG-GUAR-INT-PCT
           END-IF.
      *
           IF L0570-GUAR-IMPRD-INT-PCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        MOVE WCVGS-GUAR-IMPRD-INT-PCT (I) TO WS-INPUT-3-6
020874*        MOVE WS-INPUT-3-6            TO MIR-GUAR-IMPRD-INT-PCT
020874         MOVE WCVGS-GUAR-IMPRD-INT-PCT (I) TO L0290-INPUT-V06
020874         MOVE 6                            TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-GUAR-IMPRD-INT-PCT
020874                                           TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA        TO MIR-GUAR-IMPRD-INT-PCT
           END-IF.
      *
           IF L0570-ORIG-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-ORIG-CD (I) TO MIR-CVG-ORIG-CD
           END-IF.
      *
           IF L0570-CVG-ROLOVR-DT-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-ROLOVR-DT-IND (I) TO MIR-CVG-ROLOVR-DT-IND
           END-IF.
      *
           IF L0570-PREV-RENW-RT-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-PREV-RENW-RT-CD (I) TO MIR-PREV-RENW-RT-CD
           END-IF.
      *
           IF L0570-CVG-NXT-RENW-RT-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-NXT-RENW-RT-CD (I)
                                               TO MIR-CVG-NXT-RENW-RT-CD
           END-IF.
      *
           IF L0570-CVG-PREV-CPI-FCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        MOVE WCVGS-CVG-PREV-CPI-FCT (I) TO WS-INPUT-2-3
020874*        MOVE WS-INPUT-2-3             TO MIR-CVG-PREV-CPI-FCT
020874         MOVE WCVGS-CVG-PREV-CPI-FCT (I) TO L0290-INPUT-V03
020874         MOVE 3                          TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-PREV-CPI-FCT
020874                                         TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA          TO MIR-CVG-PREV-CPI-FCT
           END-IF.
      *
           IF L0570-CVG-NXT-CPI-FCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        MOVE WCVGS-CVG-NXT-CPI-FCT (I) TO WS-INPUT-2-3
020874*        MOVE WS-INPUT-2-3             TO MIR-CVG-NXT-CPI-FCT
020874         MOVE WCVGS-CVG-NXT-CPI-FCT (I) TO L0290-INPUT-V03
020874         MOVE 3                         TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NXT-CPI-FCT
020874                                        TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA         TO MIR-CVG-NXT-CPI-FCT
           END-IF.
      *
           IF L0570-PREV-FACE-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                              = WCVGS-CVG-PREV-FACE-AMT (I) * 100
020874         MOVE WCVGS-CVG-PREV-FACE-AMT (I) TO L0290-INPUT-V02
               MOVE 2                           TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-PREV-FACE-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA       TO MIR-CVG-PREV-FACE-AMT
           END-IF.
      *
017100*    IF L0570-MORT-XPNS-CHG-DT = HIGH-VALUES
017100     IF L0570-MORT-XPNS-CHNG-DT = HIGH-VALUES
               CONTINUE
           ELSE
017100*        MOVE WCVGS-MORT-XPNS-CHG-DT (I) TO L1640-INTERNAL-DATE
017100         MOVE WCVGS-MORT-XPNS-CHNG-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
017100*        MOVE L1640-EXTERNAL-DATE     TO MIR-MORT-XPNS-CHG-DT
017100         MOVE L1640-EXTERNAL-DATE     TO MIR-MORT-XPNS-CHNG-DT
           END-IF.
      *
           IF L0570-UWG-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-UWG-AMT (I) * 100
020874         MOVE WCVGS-CVG-UWG-AMT (I)   TO L0290-INPUT-V02
               MOVE 2                       TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-UWG-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA       TO MIR-CVG-UWG-AMT
           END-IF.
      *
           IF L0570-UWG-AMT-REASN-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-UWG-AMT-REASN-CD (I) TO MIR-UWG-AMT-REASN-CD
           END-IF.
      *
           IF L0570-WP-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-WP-IND (I) TO MIR-CVG-WP-IND
           END-IF.
      *
           IF L0570-CSTAT-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-SPND-CSTAT-CD (I) TO MIR-CVG-SPND-CSTAT-CD
           END-IF.
      *
           IF L0570-MAT-XPRY-DT-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-MAT-XPRY-DT-IND (I) TO MIR-MAT-XPRY-DT-IND
           END-IF.
      *
018905*    IF L0570-CVG-MAT-XPRY-AGE = HIGH-VALUES
018905* FOLLOWING TWO LINES ADDED TO DISPLAY PREVIOUS XPRY-AGE
018905*        MOVE  WCVGS-CVG-MAT-XPRY-AGE (I)
018905*                                     TO MIR-CVG-MAT-XPRY-AGE
018905*    ELSE
018905*        MOVE WCVGS-CVG-MAT-XPRY-AGE (I) TO MIR-CVG-MAT-XPRY-AGE
018905*    END-IF.
      *
020874*    COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-MAT-XPRY-AGE (I)
020874     MOVE WCVGS-CVG-MAT-XPRY-AGE (I) TO L0290-INPUT-V00
018905     MOVE ZERO                       TO L0290-PRECISION
018905     MOVE LENGTH OF MIR-CVG-MAT-XPRY-AGE TO L0290-MAX-OUT-LEN
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X
018905     MOVE L0290-OUTPUT-DATA       TO MIR-CVG-MAT-XPRY-AGE

018905*    IF L0570-CVG-MAT-XPRY-DUR = HIGH-VALUES
018905* FOLLOWING TWO LINES ADDED TO DISPLAY PREVIOUS XPRY-DUR
018905*        MOVE  WCVGS-CVG-MAT-XPRY-DUR (I)
018905*                                     TO MIR-CVG-MAT-XPRY-DUR
018905*    ELSE
018905*        MOVE WCVGS-CVG-MAT-XPRY-DUR (I) TO MIR-CVG-MAT-XPRY-DUR
018905*    END-IF.
018905*
020874*    COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-MAT-XPRY-DUR (I).
020874     MOVE WCVGS-CVG-MAT-XPRY-DUR (I) TO L0290-INPUT-V00.
018905     MOVE ZERO                       TO L0290-PRECISION.
018905     MOVE LENGTH OF MIR-CVG-MAT-XPRY-DUR TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018905     MOVE L0290-OUTPUT-DATA       TO MIR-CVG-MAT-XPRY-DUR.

           IF L0570-WP-XPRY-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-WP-XPRY-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE       TO MIR-CVG-WP-XPRY-DT
           END-IF.
      *
           IF L0570-AD-XPRY-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-AD-XPRY-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE         TO MIR-CVG-AD-XPRY-DT
           END-IF.
      *
           IF L0570-COMIT-RT-IND = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-COMIT-RT-IND (I) TO MIR-CVG-COMIT-RT-IND
           END-IF.
      *
           IF L0570-COMIT-RT-EFF-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-COMIT-RT-EFF-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE         TO MIR-COMIT-RT-EFF-DT
           END-IF.
      *
           IF L0570-COMIT-RT-END-DT = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-COMIT-RT-END-DT (I) TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE        TO MIR-COMIT-RT-END-DT
           END-IF.
      *
           IF L0570-MAC-COMIT-AMT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                                WCVGS-CVG-MAX-COMIT-AMT (I) * 100
020874         MOVE WCVGS-CVG-MAX-COMIT-AMT (I) TO L0290-INPUT-V02
               MOVE 2                       TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-MAX-COMIT-AMT TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA       TO MIR-CVG-MAX-COMIT-AMT
           END-IF.
      *
           IF L0570-COMIT-PCT = HIGH-VALUES
               CONTINUE
           ELSE
020874*        MOVE WCVGS-CVG-COMIT-PCT (I) TO WS-INPUT-2-3
020874*        MOVE WS-INPUT-2-3            TO MIR-CVG-COMIT-PCT
020874         MOVE WCVGS-CVG-COMIT-PCT (I) TO L0290-INPUT-V03
020874         MOVE 3                       TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-COMIT-PCT
020874                                      TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA       TO MIR-CVG-COMIT-PCT
           END-IF.
      *
           IF L0570-INS-TYP-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-INS-TYP-CD (I) TO MIR-CVG-INS-TYP-CD
           END-IF.
      *
           IF L0570-ACCT-TYP-CD = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE WCVGS-CVG-ACCT-TYP-CD (I) TO MIR-CVG-ACCT-TYP-CD
           END-IF.
      *

016440*    IF L0580-UW-USER-ID = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440     MOVE WCVGS-UW-USER-ID (I)    TO MIR-UW-USER-ID.
016440*    END-IF.

016440*    IF L0580-UWG-REQIR-ESTB-IND = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-UWG-REQIR-ESTB-IND (I)
016440*                                     TO MIR-UWG-REQIR-ESTB-IND
016440*    END-IF.

016440*
016440*    IF L0580-UWG-REQIR-ESTB-IND = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-UWG-REQIR-ESTB-IND (I)
016440*                                     TO MIR-UWG-REQIR-ESTB-IND
016440*    END-IF.
016440*
016440*    IF L0580-CVG-NMED-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-NMED-CD (I)   TO MIR-CVG-NMED-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-PHYS-EXAM-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-PHYS-EXAM-CD (I)
016440*                                     TO MIR-CVG-PHYS-EXAM-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-INTRNL-EXAM-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-INTRNL-EXAM-CD (I)
016440*                                     TO MIR-CVG-INTRNL-EXAM-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-EKG-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-EKG-CD (I)    TO MIR-CVG-EKG-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-XRAY-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-XRAY-CD (I)   TO MIR-CVG-XRAY-CD
016440*    END-IF.
016440*
016440*
016440*    IF L0580-CVG-HO-SPCMN-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-HO-SPCMN-CD (I)
016440*                                     TO MIR-CVG-HO-SPCMN-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-STRS-EKG-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-STRS-EKG-CD (I)
016440*                                     TO MIR-CVG-STRS-EKG-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-INSPC-RPT-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-INSPC-RPT-CD (I)
016440*                                     TO MIR-CVG-INSPC-RPT-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-APS-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-APS-CD (I)    TO MIR-CVG-APS-CD
016440*    END-IF.
016440*
016440*
016440*    IF L0580-UWG-USER-DEFN-1-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-UWG-USER-DEFN-1-CD (I)
016440*                                     TO MIR-UWG-USER-DEFN-1-CD
016440*    END-IF.
016440*
016440*    IF L0580-UWG-USER-DEFN-2-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-UWG-USER-DEFN-2-CD (I)
016440*                                     TO MIR-UWG-USER-DEFN-2-CD
016440*    END-IF.
016440*
016440*    IF L0580-UWG-USER-DEFN-3-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-UWG-USER-DEFN-3-CD (I)
016440*                                     TO MIR-UWG-USER-DEFN-3-CD
016440*    END-IF.
016440*
016440*    IF L0580-UWG-USER-DEFN-4-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-UWG-USER-DEFN-4-CD (I)
016440*                                     TO MIR-UWG-USER-DEFN-4-CD
016440*    END-IF.
016440*
016440*    IF L0580-UWG-USER-DEFN-5-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-UWG-USER-DEFN-5-CD (I)
016440*                                     TO MIR-UWG-USER-DEFN-5-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-OCCP-CLAS-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-OCCP-CLAS-CD (I)
016440*                                     TO MIR-CVG-OCCP-CLAS-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-SALE-SRC-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-SALE-SRC-CD (I)
016440*                                     TO MIR-CVG-SALE-SRC-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-INCM-BRCKT-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-INCM-BRCKT-CD (I)
016440*                                     TO MIR-CVG-INCM-BRCKT-CD
016440*    END-IF.
016440*
016440*    IF L0580-CVG-PRST-RAT-PCT = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-PRST-RAT-PCT-N (I)
016440*                                    TO MIR-CVG-PRST-RAT-PCT
016440*    END-IF.
016440*
016440*    IF L0580-MORT-ASSESS-PCT = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-MORT-ASSESS-PCT (I) TO WS-DISPLAY-999
016440*        MOVE WS-DISPLAY-999         TO MIR-MORT-ASSESS-PCT
016440*    END-IF.
016440*
016440*    IF L0580-CVG-UWGDECN-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
           MOVE WCVGS-CVG-UWGDECN-CD (I) TO MIR-CVG-UWGDECN-CD.
016440*    END-IF.
016440*
016440*
016440*    IF L0580-CVG-UWGDECN-SUB-CD = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
               MOVE WCVGS-CVG-UWGDECN-SUB-CD (I)
                                             TO MIR-CVG-UWGDECN-SUB-CD.
016440*    END-IF.
016440*
016440*    IF L0580-CVG-UWG-EXCL-CD-T (1) = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
               MOVE WCVGS-CVG-UWG-EXCL-CD (I, 1)
                                       TO MIR-CVG-UWG-EXCL-1-CD-T (1).
016440*    END-IF.
016440*
016440*    IF L0580-CVG-UWG-EXCL-CD-T (2) = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
               MOVE WCVGS-CVG-UWG-EXCL-CD (I, 2)
                                       TO MIR-CVG-UWG-EXCL-1-CD-T (2).
016440*    END-IF.

016440*    IF L0580-CVG-UWG-EXCL-CD-T (3) = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
               MOVE WCVGS-CVG-UWG-EXCL-CD (I, 3)
                                       TO MIR-CVG-UWG-EXCL-1-CD-T (3).
016440*    END-IF.


016440*    IF L0580-SNGL-CASE-AGRE-IND = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-SNGL-CASE-AGRE-IND (I)
016440*                                    TO MIR-SNGL-CASE-AGRE-IND
016440*    END-IF.
016440*
016440*    IF L0580-CVG-NMED-PRVLG-IND = HIGH-VALUES
016440*        CONTINUE
016440*    ELSE
016440*        MOVE WCVGS-CVG-NMED-PRVLG-IND (I)
016440*                                    TO MIR-CVG-NMED-PRVLG-IND
016440*    END-IF.
016440*

016306     IF L0570-ANN-MTG-INT-PCT = HIGH-VALUES
016306         CONTINUE
016306     ELSE
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                 WCVGS-ANN-MTG-INT-PCT (I) * 10000
020874         MOVE WCVGS-ANN-MTG-INT-PCT (I)  TO L0290-INPUT-V04
016306         MOVE 4                          TO L0290-PRECISION
016306         MOVE LENGTH OF MIR-ANN-MTG-INT-PCT
016306                                         TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016306         MOVE L0290-OUTPUT-DATA          TO MIR-ANN-MTG-INT-PCT
016306     END-IF.
016306
018763*    IF L0570-CVG-INT-CMPND-CD = HIGH-VALUES
018763     IF L0570-INT-CMPND-FREQ-CD = HIGH-VALUES
016306         CONTINUE
016306     ELSE
018763*        MOVE WCVGS-CVG-INT-CMPND-CD (I)
018763*                                        TO MIR-CVG-INT-CMPND-CD
018763         MOVE WCVGS-INT-CMPND-FREQ-CD (I)
018763                                         TO MIR-INT-CMPND-FREQ-CD
016306     END-IF.
016306
016306     IF L0570-CVG-MTG-REPAY-AMT = HIGH-VALUES
016306         CONTINUE
016306     ELSE
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                          WCVGS-CVG-MTG-REPAY-AMT (I) * 100
020874         MOVE WCVGS-CVG-MTG-REPAY-AMT (I) TO L0290-INPUT-V02
016306         MOVE 2                           TO L0290-PRECISION
016306         MOVE LENGTH OF MIR-CVG-MTG-REPAY-AMT
016306                                          TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016306         MOVE L0290-OUTPUT-DATA          TO MIR-CVG-MTG-REPAY-AMT
016306     END-IF.
016306
016306     IF L0570-MTG-REPAY-FREQ-CD = HIGH-VALUES
016306         CONTINUE
016306     ELSE
016306         MOVE WCVGS-MTG-REPAY-FREQ-CD (I)
016306                                         TO MIR-MTG-REPAY-FREQ-CD
016306     END-IF.
016306
018846     MOVE WCVGS-PLAN-FND-TYP-CD (I)      TO MIR-PLAN-FND-TYP-CD.
018846
020475     MOVE WCVGS-CVG-DBG-INCL-IND (I)     TO MIR-CVG-DBG-INCL-IND.

016306     IF L0570-PREV-SUM-INS-AMT = HIGH-VALUES
016306         CONTINUE
016306     ELSE
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                          WCVGS-PREV-SUM-INS-AMT (I) * 100
020874         MOVE WCVGS-PREV-SUM-INS-AMT (I) TO L0290-INPUT-V02
016306         MOVE 2                          TO L0290-PRECISION
016306         MOVE LENGTH OF MIR-PREV-SUM-INS-AMT
016306                                         TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016306         MOVE L0290-OUTPUT-DATA          TO MIR-PREV-SUM-INS-AMT
016306     END-IF.

       7500-MOVE-CVG-TO-MIR-X.
           EXIT.
      /
      *-------------------------
       7510-SET-UP-INSURED-LINE.
      *-------------------------

           MOVE  SPACES        TO  MIR-INSRD-CLI-ID-G.
           MOVE  SPACES        TO  MIR-DV-INSRD-CLI-NM-G.
           MOVE  SPACES        TO  MIR-CLI-SEX-CD-G.
           MOVE  SPACES        TO  MIR-CLI-SMKR-CD-G.
           MOVE  SPACES        TO  MIR-CVG-CLI-ISS-AGE-G.
           MOVE  SPACES        TO  MIR-CVG-CLI-ADJ-AGE-G.
018633*    MOVE  SPACES        TO  WS-OLD-CVG-CLI-INFO.
018633     MOVE  SPACES        TO  LCOMM-CVG-CLI-INFO.
           INITIALIZE WS-CVG-CLI-AGE-FLDS.

           MOVE  SPACES        TO  WCVGC-KEY.
           MOVE  RPOL-POL-ID   TO  WCVGC-POL-ID.
           MOVE  I             TO  WCVGC-CVG-NUM-N.

           MOVE  WCVGC-KEY     TO  WCVGC-ENDBR-KEY.
           MOVE  HIGH-VALUES   TO  WCVGC-ENDBR-CVG-CLI-REL-TYP-CD.

           PERFORM  CVGC-1000-BROWSE
               THRU CVGC-1000-BROWSE-X.

           IF  WCVGC-IO-EOF
               GO TO  7510-SET-UP-INSURED-LINE-X
           END-IF.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.
      *
      *  MOVE EACH INSURED TO THE MIR
      *
           MOVE  2  TO  J.
           PERFORM  7520-SET-UP-EACH-INSURED
               THRU 7520-SET-UP-EACH-INSURED-X
               UNTIL  WCVGC-IO-EOF.

           PERFORM  CVGC-3000-END-BROWSE
               THRU CVGC-3000-END-BROWSE-X.

018633*    MOVE  MIR-INSRD-CLI-ID-G  TO  WS-OLD-CVG-CLI-INFO.
018633     MOVE  MIR-INSRD-CLI-ID-G  TO  LCOMM-CVG-CLI-INFO.

       7510-SET-UP-INSURED-LINE-X.
           EXIT.

      *-------------------------
       7520-SET-UP-EACH-INSURED.
      *-------------------------

           MOVE J                      TO WS-HOLD-CLI-SUB.
           IF  RCVGC-CVG-CLI-REL-TYP-CD = 'P'
               MOVE +1                 TO J
           END-IF.

           IF  J < +6
               MOVE RCVGC-INSRD-CLI-ID     TO MIR-INSRD-CLI-ID-T (J)
               MOVE RCVGC-INSRD-CLI-ID     TO WS-CVG-CLI-CLI-ID  (J)
               MOVE RCVGC-CVG-CLI-ISS-AGE  TO WS-CVG-CLI-ISS-AGE (J)
               MOVE RCVGC-CVG-CLI-ADJ-AGE  TO WS-CVG-CLI-ADJ-AGE (J)
               PERFORM  7521-LOAD-CLIENT-DATA
                   THRU 7521-LOAD-CLIENT-DATA-X
           END-IF.

           MOVE WS-HOLD-CLI-SUB        TO J.
           ADD +1                      TO J.
           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       7520-SET-UP-EACH-INSURED-X.
           EXIT.


      /
      *----------------------
       7521-LOAD-CLIENT-DATA.
      *----------------------

           IF  MIR-INSRD-CLI-ID-T (J) = SPACE
               GO TO 7521-LOAD-CLIENT-DATA-X
           END-IF.

           MOVE MIR-INSRD-CLI-ID-T (J)  TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  L2437-RETRN-OK
               MOVE L2437-CLI-SEX-CD   TO MIR-CLI-SEX-CD-T (J)
               MOVE L2437-CLI-SMKR-CD  TO MIR-CLI-SMKR-CD-T (J)
               IF  L2437-CLI-SEX-CD = 'C'
                   MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2437-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO
                                  MIR-DV-INSRD-CLI-NM-T (J)
           ELSE
               MOVE SPACES             TO MIR-CLI-SEX-CD-T (J)
               MOVE SPACES             TO MIR-CLI-SMKR-CD-T (J)
           END-IF.

           PERFORM
               VARYING WS-INS-SUB FROM 1 BY 1
                 UNTIL WS-INS-SUB > 5
                    OR WS-CVG-CLI-CLI-ID (WS-INS-SUB)
                                       = MIR-INSRD-CLI-ID-T (J)
015543         CONTINUE
           END-PERFORM.
           IF  WCVGS-CVG-SEX-CD (I) = 'J'
               AND WS-INS-SUB <= 5
               AND J <= 2
020874*           MOVE WS-CVG-CLI-ISS-AGE (WS-INS-SUB)
020874*                                  TO WS-DISPLAY-3
020874*           MOVE WS-DISPLAY-3      TO MIR-CVG-CLI-ISS-AGE-T (J)
020874            MOVE WS-CVG-CLI-ISS-AGE (WS-INS-SUB)
020874                                             TO L0290-INPUT-V00
020874            MOVE 0                           TO L0290-PRECISION
020874            MOVE LENGTH OF MIR-CVG-CLI-ISS-AGE-T (J)
020874                                             TO L0290-MAX-OUT-LEN
020874            PERFORM 0290-2000-FORMAT-FOR-MIR
020874               THRU 0290-2000-FORMAT-FOR-MIR-X
020874            MOVE L0290-OUTPUT-DATA   TO MIR-CVG-CLI-ISS-AGE-T (J)
020874*           MOVE WS-CVG-CLI-ADJ-AGE (WS-INS-SUB)
020874*                                  TO WS-DISPLAY-3
020874*           MOVE WS-DISPLAY-3      TO MIR-CVG-CLI-ADJ-AGE-T (J)
020874            MOVE WS-CVG-CLI-ADJ-AGE (WS-INS-SUB)
020874                                             TO L0290-INPUT-V00
020874            MOVE 0                           TO L0290-PRECISION
020874            MOVE LENGTH OF MIR-CVG-CLI-ADJ-AGE-T (J)
020874                                             TO L0290-MAX-OUT-LEN
020874            PERFORM 0290-2000-FORMAT-FOR-MIR
020874               THRU 0290-2000-FORMAT-FOR-MIR-X
020874            MOVE L0290-OUTPUT-DATA   TO MIR-CVG-CLI-ADJ-AGE-T (J)
           ELSE
               MOVE SPACES            TO MIR-CVG-CLI-ISS-AGE-T (J)
               MOVE SPACES            TO MIR-CVG-CLI-ADJ-AGE-T (J)
           END-IF.

       7521-LOAD-CLIENT-DATA-X.
           EXIT.

      /
      *-----------------------
       7530-SET-UP-AGENT-INFO.
      *-----------------------

           MOVE  SPACES        TO  MIR-AGT-ID-G.
           MOVE  SPACES        TO  MIR-CPREM-CALC-CD-G.
           MOVE  SPACES        TO  MIR-FYR-COMM-CALC-CD-G.
           MOVE  SPACES        TO  MIR-RENW-COMM-CALC-CD-G.
           MOVE  SPACES        TO  MIR-COMM-RT-TBAC-ID-G.
           MOVE  SPACES        TO  MIR-OVRID-BASE-AGT-ID-G.
           MOVE  SPACES        TO  MIR-OVRID-ID-G.
           MOVE  SPACES        TO  MIR-ADDL-FYR-COMM-RT-G.
           MOVE  SPACES        TO  MIR-CVG-AGT-SHR-PCT-G.
           MOVE  SPACES        TO  MIR-CVG-AGT-CPREM-AMT-G.
           MOVE  SPACES        TO  MIR-COMM-CHNG-CD-G.
018633*    MOVE  SPACES        TO  WS-OLD-CVG-AGT-INFO.
018633     MOVE  SPACES        TO  LCOMM-CVG-AGT-INFO.
028786     MOVE  SPACES        TO  MIR-CPREM-MODE-CALC-CD-G.

           PERFORM  2450-1000-BUILD-PARM-INFO
               THRU 2450-1000-BUILD-PARM-INFO-X.
           PERFORM  2450-2000-READ-CVG-AGENTS
               THRU 2450-2000-READ-CVG-AGENTS-X.

028789     PERFORM  0083-0000-INIT-PARM-INFO
028789         THRU 0083-0000-INIT-PARM-INFO-X.
028789
028789     SET L0083-AGENT-NAME-REQD  TO TRUE.
028789     PERFORM
028789         VARYING J FROM 1 BY 1
028789           UNTIL J > 3
028789         IF   L2450-AGT-ID (I, J) NOT = SPACES
028789              MOVE L2450-AGT-ID (I, J) TO L0083-AGT-ID (J)
028789         END-IF
028789     END-PERFORM.
028789     PERFORM  0083-1000-RETRIEVE-AGT-INFO
028789         THRU 0083-1000-RETRIEVE-AGT-INFO-X.

           PERFORM  7540-SET-UP-EACH-AGENT
               THRU 7540-SET-UP-EACH-AGENT-X
                   VARYING J FROM 1 BY 1
                   UNTIL J > 3.

018633*    MOVE  MIR-AGT-ID-G    TO  WS-OLD-CVG-AGT-INFO.
018633     MOVE  MIR-AGT-ID-G    TO  LCOMM-CVG-AGT-INFO.

       7530-SET-UP-AGENT-INFO-X.
           EXIT.
      /
      *-----------------------
       7540-SET-UP-EACH-AGENT.
      *-----------------------

           IF L2450-AGT-ID (I, J) = SPACES
               MOVE SPACES      TO MIR-DV-AGT-CLI-NM-T (J)
               GO TO 7540-SET-UP-EACH-AGENT-X
           END-IF.

           MOVE SPACES                          TO MIR-AGT-ID-T (J).
           MOVE L2450-AGT-ID (I, J)             TO MIR-AGT-ID-T (J).
           MOVE L2450-CPREM-CALC-CD (I, J)
             TO MIR-CPREM-CALC-CD-T (J).
           MOVE L2450-FYR-COMM-CALC-CD (I, J)
             TO MIR-FYR-COMM-CALC-CD-T (J).
           MOVE L2450-RENW-COMM-CALC-CD (I, J)
             TO MIR-RENW-COMM-CALC-CD-T (J).
           MOVE L2450-COMM-RT-TBAC-ID (I, J)
             TO MIR-COMM-RT-TBAC-ID-T (J).
           MOVE L2450-OVRID-BASE-AGT-ID (I, J)
             TO MIR-OVRID-BASE-AGT-ID-T (J).
           MOVE L2450-OVRID-ID (I, J)
             TO MIR-OVRID-ID-T (J).

016641*    COMPUTE WS-INPUT-2-3-S
016641*          = L2450-ADDL-FYR-COMM-RT (I, J)  *  100.
016641*    MOVE WS-INPUT-2-3-S
016641*      TO MIR-ADDL-FYR-COMM-RT-T (J).
020874*    COMPUTE L0290-INPUT-NUMBER
020874*         = L2450-ADDL-FYR-COMM-RT (I, J) * 100000.
020874     MOVE L2450-ADDL-FYR-COMM-RT (I, J) TO L0290-INPUT-V05.
016641     MOVE 3                      TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-ADDL-FYR-COMM-RT-T (J)
016641                                 TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA      TO MIR-ADDL-FYR-COMM-RT-T (J).
016641

016641*    MOVE L2450-CVG-AGT-SHR-PCT (I, J)
016641*      TO WS-INPUT-3-2.
016641*    MOVE WS-INPUT-3-2
016641*      TO MIR-CVG-AGT-SHR-PCT-T (J).
020874*    COMPUTE L0290-INPUT-NUMBER
020874*       = L2450-CVG-AGT-SHR-PCT (I, J) * 100.
020874     MOVE L2450-CVG-AGT-SHR-PCT (I, J) TO L0290-INPUT-V02.
016641     MOVE 2                      TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-CVG-AGT-SHR-PCT-T (J)
016641                                 TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA      TO MIR-CVG-AGT-SHR-PCT-T (J).
016641
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = L2450-CVG-AGT-CPREM-AMT (I, J) * 100.
020874     MOVE L2450-CVG-AGT-CPREM-AMT (I, J) TO L0290-INPUT-V02.
           MOVE 2          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-AGT-CPREM-AMT-T (J)
             TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-CVG-AGT-CPREM-AMT-T (J).

028789*    PERFORM 0083-0000-INIT-PARM-INFO
028789*       THRU 0083-0000-INIT-PARM-INFO-X
028789*
028789*    MOVE L2450-AGT-ID (I, J)       TO L0083-AGENT-ID.
028789*    SET L0083-AGENT-NAME-REQD      TO TRUE.
028789*
028789*    PERFORM 0083-1000-RETRIEVE-AGT-INFO
028789*       THRU 0083-1000-RETRIEVE-AGT-INFO-X.

           IF  L0083-RETRN-OK
028789     AND L0083-AGT-FOUND (J)
017207         INITIALIZE L0620-INPUT-PARM-INFO
028789*        MOVE L0083-AGENT-GIV-NM    TO L0620-CLI-GIV-NM
028789*        MOVE L0083-AGENT-SUR-NM    TO L0620-CLI-SUR-NM
028789*        MOVE L0083-AGENT-MID-INIT  TO L0620-CLI-MID-INIT-NM
028789*        MOVE L0083-CLI-SFX-NM      TO L0620-CLI-SFX-NM
028789         MOVE L0083-AGENT-GIV-NM (J)   TO L0620-CLI-GIV-NM
028789         MOVE L0083-AGENT-SUR-NM (J)   TO L0620-CLI-SUR-NM
028789         MOVE L0083-AGENT-MID-INIT (J)  TO L0620-CLI-MID-INIT-NM
028789         MOVE L0083-CLI-SFX-NM (J)     TO L0620-CLI-SFX-NM
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME     TO MIR-DV-AGT-CLI-NM-T (J)
           END-IF.

           MOVE L2450-COMM-CHNG-CD (I, J)
             TO MIR-COMM-CHNG-CD-T (J).
028789     MOVE L0083-AGT-SYS-IND         TO MIR-DV-XTRNL-AGT-INQ-IND.
028786     MOVE L2450-CPREM-MODE-CALC-CD (I, J)
028786                                    TO MIR-CPREM-MODE-CALC-CD-T
028786                                       (J).

       7540-SET-UP-EACH-AGENT-X.
           EXIT.
      /

016328*-------------------------
016328 7550-SET-CVG-COMM-TRG-AMT.
016328*-------------------------
016328
020874*    MOVE ZEROES                       TO L0290-INPUT-NUMBER.
020874     MOVE ZEROES                       TO L0290-INPUT-V00.
016328     MOVE 0                            TO L0290-PRECISION.
016328     MOVE LENGTH OF MIR-CVG-COMM-TRG-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016328     MOVE L0290-OUTPUT-DATA            TO WS-CVG-COMM-TRG-AMT.
016328*
016328     IF RPOL-POL-INS-TYP-UL
023137         PERFORM  6090-0000-INIT-PARM-INFO
023137             THRU 6090-0000-INIT-PARM-INFO-X
016328         MOVE I                      TO L6090-CVG-NUM
016328         IF  WCVGS-CVG-STAT-BEFORE-SETL (L6090-CVG-NUM)
016736*        AND L0570-CVG-ISSUE-DT      = HIGH-VALUES
016736*            MOVE WGLOB-PROCESS-DATE       TO L6090-EFF-DT
016736             MOVE WCVGS-CVG-ISS-EFF-DT (L6090-CVG-NUM)
016736                                           TO L6090-EFF-DT
016328         ELSE
016736*            MOVE WCVGS-CVG-ISS-EFF-DT  (L6090-CVG-NUM)
016736             MOVE WGLOB-PROCESS-DATE
016328                                           TO L6090-EFF-DT
016328         END-IF
023137*        PERFORM  6090-1000-COMPUTE-COMM-TARG
023137*            THRU 6090-1000-COMPUTE-COMM-TARG-X
023137         PERFORM  6090-2000-CALC-COMM-TARG-CVG
023137             THRU 6090-2000-CALC-COMM-TARG-CVG-X
016328         IF  L6090-RETRN-OK
020874*            MOVE L6090-COMM-TRG-AMT   TO L0290-INPUT-NUMBER
023137*            MOVE L6090-COMM-TRG-AMT   TO L0290-INPUT-V00
023137             MOVE L6090-COMM-TRG-AMT (I) TO L0290-INPUT-V00
016328             MOVE 0                    TO L0290-PRECISION
016328             MOVE LENGTH OF MIR-CVG-COMM-TRG-AMT
016328                                       TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
016328             MOVE L0290-OUTPUT-DATA    TO WS-CVG-COMM-TRG-AMT
016328         END-IF
016328     END-IF.
016328
016328 7550-SET-CVG-COMM-TRG-AMT-X.
016328     EXIT.
016328
016328
016328*-------------------------
016328 7560-SET-PMT-LOAD-TRG-AMT.
016328*-------------------------
016328
020874*    MOVE ZEROES                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROES                        TO L0290-INPUT-V00.
016328     MOVE 0                             TO L0290-PRECISION.
016328     MOVE LENGTH OF MIR-PMT-LOAD-TRG-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016328     MOVE L0290-OUTPUT-DATA            TO WS-PMT-LOAD-TRG-AMT.
016328
016328     IF RPOL-POL-INS-TYP-UL
023137         PERFORM  6100-0000-INIT-PARM-INFO
023137             THRU 6100-0000-INIT-PARM-INFO-X
016328         MOVE I                            TO L6100-CVG-NUM
016328         IF  WCVGS-CVG-STAT-BEFORE-SETL (L6100-CVG-NUM)
016736*        AND L0570-CVG-ISSUE-DT            = HIGH-VALUES
016736*            MOVE WGLOB-PROCESS-DATE       TO L6100-EFF-DT
016736             MOVE WCVGS-CVG-ISS-EFF-DT (L6100-CVG-NUM)
016736                                           TO L6100-EFF-DT
016328         ELSE
016736*            MOVE WCVGS-CVG-ISS-EFF-DT  (L6100-CVG-NUM)
016736             MOVE WGLOB-PROCESS-DATE
016328                                           TO L6100-EFF-DT
016328         END-IF
023137*        PERFORM  6100-1000-COMPUTE-FEL-TARG
023137*            THRU 6100-1000-COMPUTE-FEL-TARG-X
023137         PERFORM  6100-2000-CALC-FEL-TARG-CVG
023137             THRU 6100-2000-CALC-FEL-TARG-CVG-X
016328         IF  L6100-RETRN-OK
020874*            MOVE L6100-PMT-LOAD-TRG-AMT TO L0290-INPUT-NUMBER
020874             MOVE L6100-PMT-LOAD-TRG-AMT (I) TO L0290-INPUT-V00
016328             MOVE 0                      TO L0290-PRECISION
016328             MOVE LENGTH OF MIR-PMT-LOAD-TRG-AMT TO
016328                                            L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
016328             MOVE L0290-OUTPUT-DATA   TO WS-PMT-LOAD-TRG-AMT
016328         END-IF
016328     END-IF.
016328
016328 7560-SET-PMT-LOAD-TRG-AMT-X.
016328     EXIT.
016328/
      *-------------------------
       7700-CONNECTED-CVG-EDITS.
      *-------------------------

           IF WCVGS-REL-CVG-NUM (I) NOT = SPACES
      *MSG: THIS COVERAGE IS CONNECTED TO COVERAGE @1
               MOVE 'CS80220004'          TO WGLOB-MSG-REF-INFO
               MOVE WCVGS-REL-CVG-NUM (I) TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  7710-CHK-FOR-CONN-CVGS
                   THRU 7710-CHK-FOR-CONN-CVGS-X
                   VARYING J FROM 1 BY 1
                   UNTIL   J > RPOL-POL-CVG-REC-CTR-N
           END-IF.

       7700-CONNECTED-CVG-EDITS-X.
           EXIT.

      *-----------------------
       7710-CHK-FOR-CONN-CVGS.
      *-----------------------

           IF WCVGS-REL-CVG-NUM (J) NOT = SPACES
               IF WCVGS-REL-CVG-NUM-N (J) = I
      *MSG: THIS COVERAGE HAS COVERAGE @1 CONNECTED TO IT
                   MOVE 'CS80220005'        TO WGLOB-MSG-REF-INFO
                   MOVE J                   TO WS-DISPLAY-CVG-NUM
                   MOVE WS-DISPLAY-CVG-NUM  TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       7710-CHK-FOR-CONN-CVGS-X.
           EXIT.


      *------------------------
       8000-MOVE-POL-TO-MIR.
      *------------------------

           MOVE RPOL-POL-BILL-MODE-CD         TO MIR-POL-BILL-MODE-CD.
           MOVE RPOL-POL-BILL-TYP-CD          TO MIR-POL-BILL-TYP-CD.
           MOVE RPOL-POL-CSTAT-CD             TO MIR-POL-CSTAT-CD.
           MOVE RPOL-POL-CVG-REC-CTR          TO MIR-POL-CVG-REC-CTR.

020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-GRS-APREM-AMT * 100.
020874     MOVE RPOL-POL-GRS-APREM-AMT        TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-GRS-APREM-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-POL-GRS-APREM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-MPREM-AMT * 100.
020874     MOVE RPOL-POL-MPREM-AMT            TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-MPREM-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-POL-MPREM-AMT.

           MOVE RPOL-POL-PD-TO-DT-NUM         TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE           TO MIR-POL-PD-TO-DT-NUM.

020874*    MOVE RPOL-POL-PREM-DSCNT-PCT       TO WS-INPUT-2-3.
020874*    MOVE WS-INPUT-2-3                  TO MIR-POL-PREM-DSCNT-PCT.
020874     MOVE RPOL-POL-PREM-DSCNT-PCT       TO L0290-INPUT-V03.
020874     MOVE 3                             TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-PREM-DSCNT-PCT
020874                                        TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA             TO MIR-POL-PREM-DSCNT-PCT.

           MOVE RPOL-POL-REINS-CD             TO MIR-POL-REINS-CD.
           MOVE RPOL-SBSDRY-CO-ID             TO MIR-SBSDRY-CO-ID.
           MOVE RPOL-POL-OPTL-CD              TO MIR-POL-OPTL-CD.
           MOVE RPOL-SERV-AGT-ID              TO MIR-SERV-AGT-ID.

020874*    COMPUTE L0290-INPUT-NUMBER =  RPOL-PLAN-PERI-PREM-AMT * 100.
020874     MOVE RPOL-PLAN-PERI-PREM-AMT  TO L0290-INPUT-V02.
018461     MOVE 2                        TO L0290-PRECISION.
018461     MOVE LENGTH OF MIR-PLAN-PERI-PREM-AMT
018461                                   TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018461     MOVE L0290-OUTPUT-DATA        TO MIR-PLAN-PERI-PREM-AMT.
025605
025605     MOVE RPOL-POL-BASE-CVG-NUM    TO L0290-INPUT-V00.
025605     MOVE ZERO                     TO L0290-PRECISION.
025605     MOVE LENGTH OF MIR-POL-BASE-CVG-NUM
025605                                   TO L0290-MAX-OUT-LEN.
025605     PERFORM 0290-2000-FORMAT-FOR-MIR
025605        THRU 0290-2000-FORMAT-FOR-MIR-X.
025605     MOVE L0290-OUTPUT-DATA        TO MIR-POL-BASE-CVG-NUM.

       8000-MOVE-POL-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
027183*     MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-NUMBER.
027183      MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.
            MOVE MIR-CVG-NUM           TO WGLOB-REF-COVERAGE-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0083-0000-INIT-PARM-INFO
025970         THRU 0083-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0570-0000-INIT-PARM-INFO
025970         THRU 0570-0000-INIT-PARM-INFO-X.
025970
029059*    PERFORM  0578-0000-INIT-PARM-INFO
029059*        THRU 0578-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2450-0000-INIT-PARM-INFO
025970         THRU 2450-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6090-0000-INIT-PARM-INFO
025970         THRU 6090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6100-0000-INIT-PARM-INFO
025970         THRU 6100-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WS-NUMERIC-EDIT-FIELDS.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     MOVE SPACES                 TO WWKDT-WORK-FIELDS.
025970       
025970     MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
018633*--------------------
018633*9500-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*    MOVE WS-TWRK-KEY               TO  L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                     TO  L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM          TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*----------------
018633*9800-WRITE-TWRK.
018633*----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    MOVE 300              TO  L8090-AREA-LEN.
018633*    MOVE WS-WORK-AREA     TO  L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9900-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGR.
       COPY NCPPCVGS.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
020478 COPY CCPPFPCK.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY CCCL0083.
018764 COPY CCPL0083.
       COPY CCPS0083.
      /
025970 COPY XCPS0280.
012522 COPY XCPL0280.
012522/
       COPY XCPL0290.
       COPY XCPS0290.
      /
018764*COPY CCCL0570.
018764 COPY CCPL0570.
       COPY CCPS0570.
      /
018764*COPY CCCL0578.
029059*COPY CCPL0578.
029059*COPY CCPS0578.
      /
016440*COPY CCCL0580.
016440*COPY CCPS0580.
      /
018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS0289.
      /
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108 COPY CCPS0985.
016108/
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.
      /
018764*COPY CCCL6090.
023137 COPY CCPS6090.
018764 COPY CCPL6090.
      /
018764*COPY CCCL6100.
023137 COPY CCPS6100.
018764 COPY CCPL6100.
      /
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      /
016537*COPY CCCL2470.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      /
       COPY CCPSPGA.
      /
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
       COPY CCPS2450.
018764*COPY CCCL2450.
018764 COPY CCPL2450.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
014221 COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNCVG.
      /
       COPY CCPUCVG.
      /
       COPY CCPBCVGC.
      /
       COPY CCPNPH.
      /
       COPY CCPCPH.
025970 COPY CCPS0620.
       COPY CCPL0620.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM8022                     **
      *****************************************************************
