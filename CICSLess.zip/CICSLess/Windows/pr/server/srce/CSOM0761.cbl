      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0761.

       COPY XCWWCRHT.
      *****************************************************************
      **  MEMBER :  CSOM0761                                         **
      **  REMARKS:  THIS MODULE SUPPORTS ANNUITY SURRENDERS AND      **
      **            REVERSALS.  THE USER MAY ALSO INQUIRE ON A       **
      **            SPECIFIC CASHFLOW RECORD.  WHEN PROCESSING A     **
      **            SURRENDER, IF THE USER HAS SUFFICIENT SECURITY,  **
      **            THE INTEREST RATE, SURRENDER CHARGE OR           **
      **            MONTHIVERSARY ADJUSTMENT INFORMATION MAY BE      **
      **            OVERRIDDEN.  THE PROCESSING WILL SUPPORT A       **
      **            PARTIAL SURRENDER, FULL SURRENDER OF A SPECIFIC  **
      **            GIA DEPOSIT, PARTIAL SURRENDER OF A SPECIFIC     **
      **            GIA DEPOSIT, PARTIAL SURRENDER WITH AMOUNTS      **
      **            SPECIFIED BY COVERAGE, PARTIAL SURRENDER WITH    **
      **            NUMBER OF UNITS SPECIFIED BY COVERAGE, AND       **
      **            SURRENDER REVERSAL.                              **
      **                                                             **
      **  DOMAIN :  CM                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       ENHANCEMENT TO INGENIUM SCHEDULER                **
557660**  5.5       CODE CLEANUP: FIELDS COMMON TO ALL MAPS          **
557660**            NOW HANDLED BY ALIAS IN FDPARMS                  **
557691**  5.5       ADD TAX YEAR FIELD                               **
557701**  5.5       CREATE PHSTS ON EQUITY PRODUCTS                  **
557708**  5.5       NEW ABEND HANDLING ROUTINE                       **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZING FOR INT'L SUPPORT            **
558976**  5.5       CHECK CFAG RETURN CODE                           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       PUT WORK DATES THRU THE DATE ROUTINE TO GET      **
005409**            VALID DATE PRIOR TO MOVING TO DB2 TABLES         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010211**  5.6       FIX PROBLEM OF 'CHG' RESPONSE                    **
010650**  5.6       VARIATIONS BY LOCATION - PLAN RULES              **
011026**  5.6       MINIMUM CONTRACT VALUE CALCULATION               **
012034**  5.6       FIX TAX WITHHELD AND SURRENDER AMOUNT            **
012034**            PROBLEMS WHEN PROCESSING SURRENDERS WITH         **
012034**            AMOUNTS SPECIFIED BY COVERAGE                    **
012588**  5.6       SAVE COVERAGES WHEN AT LEAST ONE OF THE          **
012588**            SURRENDERS IN A ASUR-A WAS PROCESSED             **
012137**  5.6V      CHANGE ASUR TO SUPPORT NEW SUPPRESS              **
012137**            CONFIRMATION SCREEN FIELD                        **
012143**  5.6V      CREATE CDSA ROW FOR SURRENDER IN PROCESS,        **
012143**            CREATE ONE CDSD PER COVERAGE AFFECTED,           **
012143**            CALCULATE DEPOSIT BASED SURRENDER CHARGES        **
012145**  5.6V      ADD NEW EDITS TO PREVENT A COVERAGE              **
012145**            DESIGNATED AS AN LCF FROM BEING PROCESSED        **
012624**  6.0       GLOBAL SECURITY CHANGES                          **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
011097**  6.1       OVERRIDING THE SURRENDER CHARGE                  **
011099**  6.1       PARTIAL SURR - CHECK FOR INCOMPLETE ENTRY        **
005193**  6.2       INCREASE FIELD LENGTH FOR CF-UNIT-QTY            **
013693**  6.2       LOCATION INCOME TAX WITHHOLD                     **
014221**  6.2       UPDATE CFLW AND CFAG WORKING STORAGE             **
015794**  6.2       REVERSAL OF SURRENDER (CDSA)                     **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016812**  6.2       FIX FOR SURRENDER REVERSAL ON GIA                **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
017150**  6.3       CURRENCY SCALING (6.1.2J)                        **
017868**  6.3       ASUR NOT ACCEPTING CHANGE.                       **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
019912**  6.3       ONLY REINSTATE OLD CFLW VALUES ON CHANGE PASS    **
018691**  6.4       99 COVERAGES                                     **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020818**  6.4       PRORATE LOCATION TAX AS DEFAULT                  **
013131**  6.4       INTEREST RATE CHANGE                             **
021311**  6.4       MULTI-PLATFORM SUPPORT                           **
020463**  6.4       INVESTOR PROFILES                                **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
014719**  6.5       SURRENDER REVERSAL WITH AUTO FACE REDUCTION      **
015753**  6.5       RESTRICT LOAN COLLATERAL FUND                    **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023122**  6.5       FIX TO CALC LOCATION TAX WITHHELD USING % OR FLAT**
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023444**  6.5       QUOTE INCOME ON WITHDRAWALS                      **
024787**  6.5       GIA SURRENDER WITH AUTO REDO                     **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
027105**  6.6       99 COVERAGES HANDLING                            **
026766**  6.6       PERFORMANCE MONITORING                           **
025325**  6.6       NEW FIELD TO STORE TAX DISP AMOUNT ON CDSA       **
028788**  6.7       EXTERNAL AGENCY INTEGRATION - POLICY EVENTS      **
028789**  6.7       EXTERNAL AGENCY INTEGRATION - REAL TIME INFO.    **
029747**  6.7       99 COVERAGES HANDLING                            **
031034**  7.0       TAX COMPONENTIZATION                             **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
031357**  7.0       COVERAGE NUMBER EDIT ERROR                       **
032329**  7.0       99 COVERAGES AND 98 FUNDS HANDLING               **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.

       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0761'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.


       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
007766 COPY XCWWCVGM.

014221 COPY CCWWLOCK.
023437 COPY XCWEBLCH.

       01  WS-PGM-WORK-AREA.
025970     05  WS-TRANSACTION-NAME             PIC X(4).
025970         88  WS-TRANSACTION-NAME-DEFAULT VALUE 'ASUR'.
025970*    05  WS-TRANSACTION-NAME          PIC X(4) VALUE 'ASUR'.

      *****************************************************************
      *   COMMON COPYBOOKS
      *****************************************************************

       COPY XCWWWKDT.
       COPY CCWE0761.
       COPY CCWW0761.
      *
026057 COPY CCWWIHSD.
       COPY CCWWCFCS.
       COPY CCWWINDX.
023437 COPY CCWWBTAX.
      *
       01  WS-WORK-AREAS.
016548*    05  WS-LINE                   PIC S9(4) COMP.
016548     05  WS-LINE                   PIC S9(4) BINARY.
           05  WS-MAP-FINALIZED-IND      PIC X.
               88  WS-MAP-FINALIZED     VALUE 'Y'.
               88  WS-MAP-FINALIZED-NO  VALUE 'N'.
           05  WS-UNITS-ENTERED-IND      PIC X.
               88  WS-UNITS-ENTERED     VALUE 'Y'.
               88  WS-UNITS-NOT-ENTERED VALUE 'N'.
           05  WS-FUND-PRCES-SW          PIC 9.
               88  WS-NO-FUND-PRCES     VALUE 0.
               88  WS-FUND-PRCES        VALUE 1.
010211     05  WS-UPDATE-SW              PIC X.
010211         88  WS-UPDATE-NO         VALUE 'N'.
010211         88  WS-UPDATE-REQUIRED   VALUE 'Y'.
012588     05  WS-UPDT-CVGS-SW           PIC X.
012588         88  WS-UPDT-CVGS-NO       VALUE 'N'.
012588         88  WS-UPDT-CVGS-REQUIRED VALUE 'Y'.
013131     05  WS-INT-RATE-CHG-SW        PIC X(01).
013131         88  WS-INT-RATE-CHG       VALUE 'Y'.
013131         88  WS-INT-RATE-CHG-NO    VALUE 'N'.
013131     05  WS-CF-INT-PCT-X           PIC X(8).
           05  WS-VER-CHG-SW             PIC 9.
               88  WS-VER-CHG-ALLOWED      VALUE 0.
               88  WS-VER-CHG-NO-SECURITY  VALUE 1.
016503     05  WS-REDO-SW                PIC X(01).
016503         88  WS-REDO-OK              VALUE 'Y'.
016503         88  WS-REDO-NOT-OK          VALUE 'N'.
           05  WS-OUTPUT-INX             PIC 9(1).
           05  WS-OUTPUT-INX2            PIC 9(2).
           05  WS-EDIT-3V2               PIC 9(3).99.
           05  WS-EDIT-3V4               PIC 9(3).9999.
           05  WS-WORK-7V2               PIC 9(7)V99.
557973     05  WS-WORK-13V2              PIC 9(13)V99.
           05  WS-WORK-7V2S              PIC S9(7)V99.
557973     05  WS-WORK-13V2S             PIC S9(13)V99.
           05  WS-EDIT-8V5S              PIC +9(8).99999.
005193     05  WS-EDIT-12V5S             PIC +9(12).99999.
           05  WS-WORK-8V5S              PIC S9(8)V9(5).
557691     05  WS-EDIT-4                 PIC 9(4).
           05  WS-EDIT-5                 PIC 9(5).
           05  WS-EDIT-3A                PIC 9(3).
           05  WS-EDIT-3S                PIC +999.
557973     05  WS-TOTAL-AMOUNT           PIC S9(13)V9(5) COMP-3.
023437*    05  WS-TOTAL-WITHHELD         PIC S9(13)V99   COMP-3.
557973     05  WS-HOLD-AMOUNT            PIC S9(13)V9(5) COMP-3.
           05  WS-HOLD-UNITS             PIC S9(8)V9(5)  COMP-3.
023437*    05  WS-HOLD-WITHHELD          PIC S9(13)V99   COMP-3.
557973     05  WS-HOLD-PROV-WITHHELD     PIC S9(13)V99   COMP-3.
557973     05  WS-HOLD-MTHV-ADJ-AMT      PIC S9(13)V99   COMP-3.
012143     05  WS-HOLD-FREE-WTHDR-QTY    PIC S9(03)      COMP-3.
012143     05  WS-HOLD-FREE-WTHDR-TOT-AMT
012143                                   PIC S9(13)V99   COMP-3.
012143     05  WS-DBSC-TOT-SURR-AMT      PIC S9(13)V99   COMP-3.
012143     05  WS-DBSC-TOT-CHRG-AMT      PIC S9(13)V99   COMP-3.
012143     05  WS-DBSC-TOT-FREE-AMT      PIC S9(13)V99   COMP-3.
012143     05  WS-DBSC-ASS-SURR-AMT      PIC S9(13)V99   COMP-3.
012143     05  WS-DBSC-ASS-CHRG-AMT      PIC S9(13)V99   COMP-3.
012143     05  WS-DBSC-ASS-FREE-AMT      PIC S9(13)V99   COMP-3.
012143     05  WS-DBSC-APPLICABLE-IND    PIC X(01).
012143         88  WS-DBSC-APPLICABLE       VALUE 'Y'.
012143         88  WS-DBSC-APPLICABLE-NO    VALUE 'N'.
031034**   05  WS-LTAX-LOOP-IND          PIC X(01).
031034**       88  WS-LTAX-LOOP-START       VALUE 'S'.
031034**       88  WS-LTAX-LOOP-END         VALUE 'E'.
031034**   05  WS-IDX                    PIC S9(3)       COMP-3.
031034**   05  WS-LTAXWH-INFO.
031034**       10  WS-HOLD-LTAXWH-PCT    PIC 9(05)V9(02).
023437*        10  WS-HOLD-CF-LTAXWH-AMT
023437*                                  PIC S9(11)V9(02) COMP-3.
031034**       10  WS-HOLD-LOC-AMT       PIC S9(13)V9(05) COMP-3.
031034**       10  WS-TOTAL-LOC-AMT      PIC S9(13)V9(05) COMP-3.
023437*        10  WS-TOTAL-CF-LTAXWH-AMT
023437*                                  PIC S9(13)V9(05) COMP-3.

           05  WS-BUS-FCN-ID                   PIC X(04).
               88  WS-BUS-FCN-RETRIEVE         VALUE '0630'.
               88  WS-BUS-FCN-SURR             VALUE
                   '0631' '0632' '0633' '0634' '0636'.
               88  WS-BUS-FCN-SURR-FND-BY-FND  VALUE '0633' '0634'.
018846         88  WS-BUS-FCN-SURR-FND-BY-CVG  VALUE '0631'
018846                                               '0632'
018846                                               '0636'.
               88  WS-BUS-FCN-GIA-SURR         VALUE '0631' '0632'.
               88  WS-BUS-FCN-SURR-NON-SPEC    VALUE '0636'.
               88  WS-BUS-FCN-FULL-GIA-SURR    VALUE '0631'.
               88  WS-BUS-FCN-PARTL-GIA-SURR   VALUE '0632'.
               88  WS-BUS-FCN-SURR-FND-BY-AMT  VALUE '0633'.
               88  WS-BUS-FCN-SURR-FND-BY-UNIT VALUE '0634'.
               88  WS-BUS-FCN-REVRS            VALUE '0635'.
               88  WS-BUS-FCN-VALID            VALUE
                   '0630' '0631' '0632' '0633' '0634' '0635' '0636'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0630'.
           05  WS-PRCES-STATE-CD            PIC X(01).
               88  WS-PRCES-STATE-RETRIEVE  VALUE '1'.
               88  WS-PRCES-STATE-EDIT      VALUE '2'.
               88  WS-PRCES-STATE-PRCES     VALUE '3'.
               88  WS-PRCES-STATE-CHNG      VALUE '4'.
           05  WS-HOLD-POLICY.
               10  FILLER                   PIC X(9).
               10  WS-HOLD-SUFFIX           PIC X.
           05  WS-HOLD-NAME                 PIC X(4).
016548*    05  WS-HOLD-LINE-NO              PIC S9(4)      COMP.
016548     05  WS-HOLD-LINE-NO              PIC S9(4)      BINARY.
           05  WS-HOLD-ERR                  PIC X(3).
               88  WS-HOLD-ERR-NONE         VALUE SPACES.
               88  WS-HOLD-VERIFY           VALUE 'VER'.
               88  WS-HOLD-ERROR            VALUE 'ERR'.
               88  WS-HOLD-PRCES            VALUE 'PRO'.
016548*    05  WS-MAX-FUND-LINES            PIC S9(4) COMP VALUE +25.
025970*    05  WS-MAX-FUND-LINES            PIC S9(4) BINARY VALUE +25.
           05  WS-HOLD-AMT-BY-COV-AREA.
029747*        10  WS-H-AMT-BY-COV      OCCURS 25 TIMES.
032329*        10  WS-H-AMT-BY-COV      OCCURS 20 TIMES.
032329         10  WS-H-AMT-BY-COV      OCCURS 99 TIMES.
                   15  WS-H-ACOV            PIC X(02).
008455             15  WS-H-AFVAL           PIC X(19).
018763*            15  WS-H-AMNT            PIC X(17).
018763             15  WS-H-AMNT            PIC X(18).
008455             15  WS-H-ACHRG           PIC X(17).
008455             15  WS-H-AMADJ           PIC X(17).
023437*            15  WS-H-ATAXW           PIC X(14).
023437*            15  WS-H-ATAXO           PIC X(01).
                   15  WS-H-AERR            PIC X(03).
           05  WS-HOLD-UNT-BY-COV-AREA REDEFINES
                                        WS-HOLD-AMT-BY-COV-AREA.
029747*        10  WS-H-UNT-BY-COV      OCCURS 25 TIMES.
032329*        10  WS-H-UNT-BY-COV      OCCURS 20 TIMES.
032329         10  WS-H-UNT-BY-COV      OCCURS 99 TIMES.
                   15  WS-H-UCOV            PIC X(02).
005193             15  WS-H-UFVAL           PIC X(19).
005193*            15  WS-H-UFVAL           PIC X(15).
005193*            15  WS-H-UNIT            PIC X(14).
005193             15  WS-H-UNIT            PIC X(18).
008455             15  WS-H-UCHRG           PIC X(17).
018763             15  WS-H-UMADJ           PIC X(17).
023437*            15  WS-H-UTAXW           PIC X(14).
023437*            15  WS-H-UTAXO           PIC X(01).
                   15  WS-H-UERR            PIC X(03).
018846     05  WS-POL-TOT-SURR-AMT          PIC S9(13)V9(02) COMP-3.
018846     05  WS-SIDFND-TOT-SURR-AMT       PIC S9(13)V9(02) COMP-3.
018846     05  WS-POL-TOT-SURR-UNTS         PIC S9(13)V9(05) COMP-3.
018846     05  WS-SIDFND-TOT-SURR-UNTS      PIC S9(13)V9(05) COMP-3.
018846     05  WS-SIDFND-EQTY-UNIT-QTY      PIC S9(13)V9(05) COMP-3.
           05  WS-COV-NUM                PIC 9(02).
           05  WS-COV-NUM-X              REDEFINES
               WS-COV-NUM                PIC X(02).
016548*    05  WS-CVG-NUM                PIC S9(04) COMP.
016548     05  WS-CVG-NUM                PIC S9(04) BINARY.
           05  WS-CF-REC-DATE            PIC X(10).
           05  WS-CF-SEQ-NUM             PIC X(03).
029747*    05  WS-SURR-AMT-AREA         OCCURS 25 TIMES.
032329*    05  WS-SURR-AMT-AREA         OCCURS 20 TIMES.
032329     05  WS-SURR-AMT-AREA         OCCURS 99 TIMES.
017868         10  WS-SURR-AMT           PIC S9(15)V9(02).
015290     05  WS-SUB                    PIC S9(04)  BINARY.
031034**   05  WS-HOLD-PLAR-PRCES-SW     PIC X(01).
031034**   05  WS-HOLD-PGAL-ALLOC-SW     PIC X(01).
031034**   05  WS-HOLD-PGAL-TABLE.
031034**       10  WS-HOLD-PGAL-ALLOC-INFO  OCCURS 9 TIMES.
031034**           15  WS-HOLD-PGAL-ALLOC-TYP-CD
031034**                                 PIC X(01).
031034**           15  WS-HOLD-PGAL-OPN-PRIN-AMT
031034**                                 PIC S9(13)V99 COMP-3.
031034**           15  WS-HOLD-PGAL-OPN-GAIN-AMT
031034**                                 PIC S9(13)V99 COMP-3.
031034**           15  WS-HOLD-PGAL-TRXN-PRIN-AMT
031034**                                 PIC S9(13)V99 COMP-3.
031034**           15  WS-HOLD-PGAL-TRXN-GAIN-AMT
031034**                                 PIC S9(13)V99 COMP-3.
031034**           15  WS-HOLD-PGAL-SURR-CHRG-AMT
031034**                                 PIC S9(13)V99 COMP-3.
031034**           15  WS-HOLD-PGAL-WTHDR-SEQ-NUM
031034**                                     PIC X(01).
031034**           15  WS-HOLD-PGAL-WTHDR-ORDR-CD
031034**                                     PIC X(01).
031034**           15  WS-HOLD-PGAL-DPOS-DFLT-IND   PIC X(01).
031034**           15  WS-HOLD-PGAL-XFER-ONLY-IND   PIC X(01).
015290     05  WS-CDSA-INFO.
015290         10  WS-POL-PAYO-NUM           PIC S9(05) COMP-3.
023437*        10  WS-CDA-TYP-CD             PIC X(01).
023437         10  WS-CDA-TYP-CD             PIC X(02).
015290         10  WS-CDA-EFF-IDT-NUM        PIC X(07).
015290         10  WS-CDA-SEQ-NUM            PIC S9(03) COMP-3.
020475     05  WS-POL-DBG-ACUM-AMT           PIC S9(13)V99 COMP-3.
020475     05  WS-CVG-TRXN-AMT               PIC S9(13)V99 COMP-3.
024787     05  WS-AUTO-REDO-SW               PIC X(01).
024787         88  WS-AUTO-REDO-DONE         VALUE 'Y'.
024787         88  WS-AUTO-REDO-NONE         VALUE 'N'.

023437     05  WS-TOT-POL-FND-AMT        PIC S9(13)V9(02) COMP-3.
023437     05  WS-TOT-POL-CLI-AMT        PIC S9(13)V9(02) COMP-3.
023437     05  WS-TOT-POL-CF-FND-AMT     PIC S9(13)V9(02) COMP-3.
023437     05  WS-TOT-POL-CF-CLI-AMT     PIC S9(13)V9(02) COMP-3.
023437     05  WS-TOT-SIDFND-FND-AMT     PIC S9(13)V9(02) COMP-3.
023437     05  WS-TOT-SIDFND-CLI-AMT     PIC S9(13)V9(02) COMP-3.
023437     05  WS-TRXN-FEE-AMT           PIC S9(13)V9(02) COMP-3.
031034*    05  WS-PGAL-TRXN-FEE-AMT      PIC S9(13)V9(02) COMP-3.
023437     05  WS-POL-ACUM-VALU-AMT      PIC S9(13)V9(02) COMP-3.
023437     05  WS-CFLW-ACUM-AMT          PIC S9(13)V9(02) COMP-3.
023437     05  WS-SEG-FND-ACUM-AMT       PIC S9(13)V9(02) COMP-3.
023437     05  WS-SIDFND-AMT             PIC S9(13)V9(02) COMP-3.
023437     05  WS-CF-SURR-CHRG-AMT       PIC S9(13)V9(02) COMP-3.
023437     05  WS-CF-MKTVAL-ADJ-AMT      PIC S9(13)V9(02) COMP-3.
023437     05  WS-WORK-AMT               PIC S9(13)V9(02) COMP-3.
023437     05  WS-LTAXWH-CALC-CD         PIC X(01).
023437         88 WS-LTAXWH-CALC-VALID   VALUE  'S' 'C' 'B'.
023437         88 WS-LTAXWH-CALC-S       VALUE  'S'.
023437         88 WS-LTAXWH-CALC-C       VALUE  'C'.
023437         88 WS-LTAXHW-CALC-B       VALUE  'B'.
023437     05  WS-LTAXWH-FLAT-AMT        PIC S9(11)V9(02) COMP-3.
023437     05  WS-LTAXWH-PCT             PIC S9(03)V9(02) COMP-3.
031034**   05  WS-FED-TAXWH-AMT          PIC S9(13)V9(02) COMP-3.
031034**   05  WS-TAX-ACB-AMT            PIC S9(13)V9(02) COMP-3.
031034**   05  WS-TAXBL-PORTN-AMT        PIC S9(13)V9(02) COMP-3.
031034**   05  WS-FED-TAXWH-CALC-CD      PIC X(01).
031034**   05  WS-FED-TAXWH-RQST-AMT     PIC S9(13)V99    COMP-3.
031034**   05  WS-FED-TAXWH-RQST-PCT     PIC S9(03)V9(02) COMP-3.
031034**   05  WS-FED-TAX-WTHLD-AMT      PIC S9(13)V9(02) COMP-3.
029747     05  WS-MAX-FUND-LINES         PIC S9(4) BINARY.

018691 01  WS-TMP-CF-REC.
018691     05  WS-TMP-REC-START          PIC S9(08) BINARY.
018691     05  WS-TMP-REC-LEN            PIC S9(08) BINARY.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '0630'.
029747*    05  WS-MAX-FUND-LINES            PIC S9(4) BINARY.
029747*        88  WS-MAX-FUND-LINES-DEFAULT VALUE +25.
029747*        88  WS-MAX-FUND-LINES-DEFAULT VALUE +20.

015290 COPY CCWLPGAL.
       COPY CCWWTSCF.
021930*COPY CCWWBTAX.
023437 COPY CCWLTAXC.
023437 COPY XCWL0316.
      *
      *****************************************************************
      *   I/O COPYBOOKS
      *****************************************************************
       COPY CCFWCFAG.
       COPY CCFRCFAG.
      *
       COPY CCFWCFCO.
       COPY CCFRCFCO.
      *
       COPY CCFWCFLW.
       COPY CCFRCFLW.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
020475 COPY CCFRDBGA.
020475*
       COPY CCFHPOL.
       COPY CCFWPOL.
      *
012143 COPY CCFWPH.
012143 COPY CCFRPH.
      *
      ******************************************************************
      * CALLED MODULE PARAMETER
      ******************************************************************
020478 COPY CCWL2626.
023437 COPY CCWLACCT.
       COPY XCWLDTLK.
       COPY XCWL0280.
017150 COPY XCWL0279.
       COPY XCWL1640.
015290 COPY XCWL1660.
005409 COPY XCWL1670.
005409 COPY XCWL1680.
008455 COPY XCWL0290.
       COPY CCWL0182.
021930*COPY CCWL0187.
031034*COPY CCWL0187.
016503 COPY CCWL0201.
016503 COPY CCWL0289.
       COPY CCWL0620.
       COPY CCWL0753.
016108 COPY CCWL0985.
       COPY CCWL1010.
031034*COPY CCWL1146.
023437 COPY CCWL2090.
028789 COPY CCWL2110.
       COPY CCWL2430.
012143 COPY CCWL2600.
020463 COPY CCWL2735.
       COPY CCWL4750.
016503 COPY CCWL4780.
031034 COPY CCWL5382.
       COPY CCWL5400.
012143 COPY CCWL6860.
020475 COPY CCWL7305.
020475 COPY CCWL7306.
031034*COPY CCWL7800.
012143 COPY FCWL2760.
012143 COPY FCWL2770.
       COPY XCWL8090.
       01  WS-CASH-FLOW-INFO.
014221*        10  WS-CFLW-REC-INFO   OCCURS 25  PIC X(500).
029747*        10  WS-CFLW-REC-INFO   OCCURS 25  PIC X(538).
029747*        10  WS-CFCO-REC-AREA   OCCURS 25  PIC X(606).
032329*        10  WS-CFLW-REC-INFO   OCCURS 20  PIC X(538).
032329         10  WS-CFLW-REC-INFO   OCCURS 99  PIC X(538).
032329*        10  WS-CFCO-REC-AREA   OCCURS 20  PIC X(606).
032329         10  WS-CFCO-REC-AREA   OCCURS 99  PIC X(2976).
014221*        10  WS-CFAG-REC-INFO              PIC X(65).
014221         10  WS-CFAG-REC-INFO              PIC X(99).
012143         10  WS-SURR-CHRG-OVRIDE-IND       PIC X(01).
012143             88  WS-SURR-CHRG-OVRIDDEN       VALUE 'Y'.
013131         10  WS-SAVE-INT-RATE-CHG-SW       PIC X(01).
013131             88  WS-SAVE-INT-RATE-CHG        VALUE 'Y'.
013131             88  WS-SAVE-INT-RATE-CHG-NO     VALUE 'N'.
      *
      *****************************************************************
      *   INPUT PARAMETER INFORMATION
      *****************************************************************

       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *

       LINKAGE SECTION.

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0761.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

021311     PERFORM  9990-INIT-WORKING-STORAGE
021311         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
008455
008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  0200-PROCESS-REQUEST
               THRU 0200-PROCESS-REQUEST-X

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *---------------------
       0200-PROCESS-REQUEST.
      *---------------------

      ******************************************************************
      **                                                              **
      **              I N I T I A L I Z A T I O N                     **
      **                                                              **
      ******************************************************************
      *
      * STORE ESSENTIAL MIR FIELDS
      *
           MOVE MIR-DV-PRCES-STATE-CD      TO WS-PRCES-STATE-CD.
025970*    MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
021311*    MOVE MIR-POL-ID-BASE            TO WS-HOLD-POLICY.
021311*    MOVE MIR-POL-ID-SFX             TO WS-HOLD-SUFFIX.
021311*    INITIALIZE                      WS-HOLD-PLAR-PRCES-SW.
021311*    INITIALIZE                      WS-HOLD-PGAL-ALLOC-SW.
021311*    INITIALIZE                      WS-HOLD-PGAL-TABLE.
021311*    INITIALIZE                      WS-CDSA-INFO.
021311*    SET WS-INT-RATE-CHG-NO          TO TRUE.
021311*    SET WS-SAVE-INT-RATE-CHG-NO     TO TRUE.

012137* VALIDATE INITIAL SCREEN INPUT
012137
012137     IF NOT WS-BUS-FCN-VALID
012137*MSG: INVALID ENTRY. VALID VALUES I,S,F,P,A,U,R,Z
012137         MOVE 'CS07610050'     TO WGLOB-MSG-REF-INFO
012137         PERFORM  0260-1000-GENERATE-MESSAGE
012137             THRU 0260-1000-GENERATE-MESSAGE-X
012137         SET WGLOB-RETURN-ERROR TO TRUE
012137         GO TO 0200-PROCESS-REQUEST-X
012137     END-IF.

      *
      * INITIALIZE THE REFERENCE FIELDS FOR MESSAGES
      *
           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.
      *
      * RETRIEVE ANY PREVIOUSLY STORED INFORMATION FROM THE
      * TEMPORARY STORAGE
      *
           PERFORM  8090-1000-BUILD-PARM-INFO
               THRU 8090-1000-BUILD-PARM-INFO-X.

031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
015290
           SET L8090-TEMP-WRK-TYP-CF-SUR  TO TRUE.
018691*    MOVE LENGTH OF WS-CASH-FLOW-INFO TO L8090-AREA-LEN.
018691*
018691*    PERFORM  8090-2000-RETRIEVE-TWRK
018691*        THRU 8090-2000-RETRIEVE-TWRK-X.
018691     COMPUTE WS-TMP-REC-LEN = LENGTH OF WS-CASH-FLOW-INFO.
018691     MOVE +1                        TO WS-TMP-REC-START.
018691     SET L8090-RETRN-OK             TO TRUE.
018691     MOVE +1                        TO L8090-TEMP-WRK-SEQ-NUM.
018691
018691     PERFORM
018691         UNTIL WS-TMP-REC-START > LENGTH OF WS-CASH-FLOW-INFO
018691         OR NOT L8090-RETRN-OK
018691
018691         IF  WS-TMP-REC-LEN > LENGTH OF L8090-AREA-INFO-TEXT
018691             COMPUTE WS-TMP-REC-LEN =
018691                   LENGTH OF L8090-AREA-INFO-TEXT
018691         END-IF
018691
018691         MOVE WS-TMP-REC-LEN          TO L8090-AREA-LEN
018691         PERFORM  8090-2000-RETRIEVE-TWRK
018691             THRU 8090-2000-RETRIEVE-TWRK-X
018691
018691         IF  L8090-RETRN-OK
018691             MOVE L8090-AREA-INFO-TEXT
018691          TO  WS-CASH-FLOW-INFO (WS-TMP-REC-START:WS-TMP-REC-LEN)
018691             PERFORM  8090-3000-DELETE-TWRK
018691                 THRU 8090-3000-DELETE-TWRK-X
018691             COMPUTE WS-TMP-REC-START = WS-TMP-REC-START
018691                                      + WS-TMP-REC-LEN
018691             COMPUTE WS-TMP-REC-LEN = LENGTH OF WS-CASH-FLOW-INFO
018691                                    - WS-TMP-REC-START
018691                                    + 1
018691             ADD L8090-TWRK-REC-CNT TO L8090-TEMP-WRK-SEQ-NUM
018691         END-IF
018691
018691     END-PERFORM.
018691
           IF  L8090-RETRN-OK
018691*        MOVE L8090-AREA-INFO-TEXT  TO WS-CASH-FLOW-INFO
               MOVE WS-CFLW-REC-INFO (1)  TO RCFLW-REC-INFO
               MOVE WS-CFCO-REC-AREA (1)  TO WCFCS-WORK-AREA
               MOVE WS-CFAG-REC-INFO      TO RCFAG-REC-INFO
013131         MOVE WS-SAVE-INT-RATE-CHG-SW TO WS-INT-RATE-CHG-SW
013131         SET WS-SAVE-INT-RATE-CHG-NO  TO TRUE
018691*        PERFORM  8090-3000-DELETE-TWRK
018691*            THRU 8090-3000-DELETE-TWRK-X
012143     ELSE
012143         MOVE SPACE             TO WS-SURR-CHRG-OVRIDE-IND
           END-IF.

      * VALIDATE KEYED INPUT FIELDS

           MOVE SPACES                TO E0761-WORK-AREA.
018846     MOVE ZERO                  TO WS-POL-TOT-SURR-AMT.
018846     MOVE ZERO                  TO WS-SIDFND-TOT-SURR-UNTS.
018846     MOVE ZERO                  TO WS-SIDFND-TOT-SURR-AMT.
018846     MOVE ZERO                  TO WS-SIDFND-EQTY-UNIT-QTY.
018846     MOVE ZERO                  TO WS-POL-TOT-SURR-UNTS.
028789     PERFORM  2110-0000-INIT-PARM-INFO
028789         THRU 2110-0000-INIT-PARM-INFO-X.
028789     PERFORM  2110-3000-LOCATE-AGT-PMT
028789         THRU 2110-3000-LOCATE-AGT-PMT-X.
028789     MOVE L2110-AGT-COMM-SYS-IND  TO MIR-DV-XTRNL-AGT-INQ-IND.

           PERFORM  8000-VALIDATE-KEY-FIELDS
               THRU 8000-VALIDATE-KEY-FIELDS-X.

           IF WGLOB-RETURN-ERROR
               PERFORM  0240-INITIALIZE-SCREEN-FLDS
                   THRU 0240-INITIALIZE-SCREEN-FLDS-X
               GO TO 0200-PROCESS-REQUEST-X
           END-IF.


      * HOLD THE USER'S KEYED INPUT IN A WORK AREA

           PERFORM  5000-BUILD-KEY-INPUT-AREA
               THRU 5000-BUILD-KEY-INPUT-AREA-X.

      * HOLD THE USER'S KEYED INPUT FOR FUND BY AMOUNT
      * OR FUND BY UNIT TRANSACTIONS

           EVALUATE TRUE

               WHEN WS-BUS-FCN-SURR-FND-BY-AMT
                    PERFORM  0220-MOVE-AMT-BY-COV-FIELDS
                        THRU 0220-MOVE-AMT-BY-COV-FIELDS-X
                        VARYING WS-LINE FROM 1 BY 1
                        UNTIL WS-LINE > WS-MAX-FUND-LINES

               WHEN WS-BUS-FCN-SURR-FND-BY-UNIT
                    PERFORM  0230-MOVE-UNT-BY-COV-FIELDS
                        THRU 0230-MOVE-UNT-BY-COV-FIELDS-X
                        VARYING WS-LINE FROM 1 BY 1
                        UNTIL WS-LINE > WS-MAX-FUND-LINES

           END-EVALUATE.

           PERFORM  0240-INITIALIZE-SCREEN-FLDS
               THRU 0240-INITIALIZE-SCREEN-FLDS-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE-TRANS
                        THRU 3000-PROCESS-RETRIEVE-TRANS-X

               WHEN WS-BUS-FCN-SURR
               WHEN WS-BUS-FCN-REVRS
                    PERFORM  4000-PROCESS-SURR-TRANS
                        THRU 4000-PROCESS-SURR-TRANS-X

           END-EVALUATE.

       0200-PROCESS-REQUEST-X.
           EXIT.
      *
      *----------------------------
       0220-MOVE-AMT-BY-COV-FIELDS.
      *----------------------------

           MOVE MIR-CVG-NUM-T (WS-LINE)
                                      TO WS-H-ACOV (WS-LINE).
           MOVE MIR-DV-POL-CSV-AMT-T (WS-LINE)
                                      TO WS-H-AFVAL (WS-LINE).
           MOVE MIR-CF-TOT-SURR-AMT-T (WS-LINE)
                                      TO WS-H-AMNT (WS-LINE).
           MOVE MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
                                      TO WS-H-ACHRG (WS-LINE).
           MOVE MIR-CF-MKTVAL-ADJ-AMT-T (WS-LINE)
                                      TO WS-H-AMADJ (WS-LINE).
015290*    MOVE MIR-CF-FED-TAXWH-AMT-T (WS-LINE)
015290*                               TO WS-H-ATAXW (WS-LINE).
023437*    IF  MIR-DV-TAX-OVRID-IND-T (WS-LINE) = 'Y'
023437*        MOVE MIR-CF-FED-TAXWH-AMT-T (WS-LINE)
023437*                               TO WS-H-ATAXW (WS-LINE)
023437*    ELSE
023437*        MOVE ZERO              TO WS-H-ATAXW (WS-LINE)
023437*    END-IF.

023437*    MOVE MIR-DV-TAX-OVRID-IND-T (WS-LINE)
023437*                               TO WS-H-ATAXO (WS-LINE).
           MOVE MIR-DV-DISPLAY-CD-T (WS-LINE)
                                      TO WS-H-AERR (WS-LINE).

       0220-MOVE-AMT-BY-COV-FIELDS-X.
           EXIT.
      *
      *----------------------------
       0230-MOVE-UNT-BY-COV-FIELDS.
      *----------------------------

           MOVE MIR-CVG-NUM-T (WS-LINE)
                                      TO WS-H-UCOV (WS-LINE).
           MOVE MIR-CF-UNIT-QTY-T (WS-LINE)
                                      TO WS-H-UFVAL (WS-LINE).
           MOVE MIR-DV-CF-UNIT-QTY-T (WS-LINE)
                                      TO WS-H-UNIT (WS-LINE).
           MOVE MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
                                      TO WS-H-UCHRG (WS-LINE).
015290*    MOVE MIR-CF-FED-TAXWH-AMT-T (WS-LINE)
015290*                               TO WS-H-UTAXW (WS-LINE).
023437*    IF  MIR-DV-TAX-OVRID-IND-T (WS-LINE) = 'Y'
023437*        MOVE MIR-CF-FED-TAXWH-AMT-T (WS-LINE)
023437*                               TO WS-H-UTAXW (WS-LINE)
023437*    ELSE
023437*        MOVE ZERO              TO WS-H-UTAXW (WS-LINE)
023437*    END-IF.
023437*
023437*    MOVE MIR-DV-TAX-OVRID-IND-T (WS-LINE)
023437*                               TO WS-H-UTAXO (WS-LINE).
           MOVE MIR-DV-DISPLAY-CD-T (WS-LINE)
                                      TO WS-H-UERR (WS-LINE).

       0230-MOVE-UNT-BY-COV-FIELDS-X.
           EXIT.
      *
      *----------------------------
       0240-INITIALIZE-SCREEN-FLDS.
      *----------------------------

           EVALUATE TRUE

               WHEN WS-BUS-FCN-SURR-FND-BY-AMT
                    MOVE SPACES       TO MIR-CVG-NUM-G
                    MOVE SPACES       TO MIR-DV-POL-CSV-AMT-G
                    MOVE SPACES       TO MIR-CF-TOT-SURR-AMT-G
                    MOVE SPACES       TO MIR-CF-SURR-CHRG-AMT-G
                    MOVE SPACES       TO MIR-CF-MKTVAL-ADJ-AMT-G
023437*             MOVE SPACES       TO MIR-CF-FED-TAXWH-AMT-G
023437*             MOVE SPACES       TO MIR-DV-TAX-OVRID-IND-G
                    MOVE SPACES       TO MIR-DV-DISPLAY-CD-G

               WHEN WS-BUS-FCN-SURR-FND-BY-UNIT
                    MOVE SPACES       TO MIR-CVG-NUM-G
                    MOVE SPACES       TO MIR-CF-UNIT-QTY-G
                    MOVE SPACES       TO MIR-CF-UNIT-QTY-G
                    MOVE SPACES       TO MIR-CF-SURR-CHRG-AMT-G
023437*             MOVE SPACES       TO MIR-CF-FED-TAXWH-AMT-G
023437*             MOVE SPACES       TO MIR-DV-TAX-OVRID-IND-G
                    MOVE SPACES       TO MIR-DV-DISPLAY-CD-G

               WHEN OTHER
                    PERFORM 0245-INIT-AMOUNT-FIELDS
                       THRU 0245-INIT-AMOUNT-FIELDS-X
                    MOVE SPACES       TO MIR-CF-STAT-CD
                    MOVE SPACES       TO MIR-CF-TRXN-CD
                    MOVE SPACES       TO MIR-CF-REASN-CD
025388*             MOVE SPACES       TO MIR-CF-REG-FND-SRC-CD
025388              SET  MIR-CF-REG-FND-REG-CONTRB      TO TRUE
                    MOVE SPACES       TO MIR-CF-INT-PCT
                    MOVE SPACES       TO MIR-CF-EFF-DT
                    MOVE SPACES       TO MIR-CF-PRCES-DT
                    MOVE SPACES       TO MIR-CF-REVRS-PRCES-DT
                    MOVE SPACES       TO MIR-CF-ORIG-LF-DT
                    MOVE SPACES       TO MIR-PAYO-CLUST-CF-DT
                    MOVE SPACES       TO MIR-CLUST-CF-SEQ-NUM
                    MOVE SPACES       TO MIR-NXT-CF-DT
                    MOVE SPACES       TO MIR-NXT-CF-SEQ-NUM
                    MOVE SPACES       TO MIR-PREV-CF-DT
                    MOVE SPACES       TO MIR-PREV-CF-SEQ-NUM
                    MOVE SPACES       TO MIR-CF-INT-PAYO-DT
                    MOVE SPACES       TO MIR-ROLOVR-CF-DT
                    MOVE SPACES       TO MIR-XFER-CF-SEQ-NUM
                    MOVE SPACES       TO MIR-XFER-CVG-NUM
023112              MOVE SPACES       TO MIR-CF-ROLOVR-PAYO-NUM
                    MOVE SPACES       TO MIR-DEST-CDA-SEQ-NUM
                    MOVE SPACES       TO MIR-SRC-CVG-NUM
                    MOVE SPACES       TO MIR-SRC-CDA-SEQ-NUM
                    MOVE SPACES       TO MIR-CF-DPOS-TRM-MO-DUR
                    MOVE SPACES       TO MIR-CF-DPOS-TRM-DY-DUR
                    MOVE SPACES       TO MIR-NXT-LF-CF-DT
                    MOVE SPACES       TO MIR-NXT-LF-CF-SEQ-NUM
                    MOVE SPACES       TO MIR-CF-TAX-YR
                    MOVE SPACES       TO MIR-CF-UNIT-QTY
                    MOVE SPACES       TO MIR-UNIT-PRIC-ESTB-IND
                    MOVE SPACES       TO MIR-CF-EQTY-GLA-IND
                    MOVE SPACES       TO MIR-CONN-CF-SEQ-NUM
                    MOVE SPACES       TO MIR-AGT-1-ID-T (1)
                    MOVE SPACES       TO MIR-COMM-RT-TBAC-1-ID-T (1)
                    MOVE SPACES       TO MIR-OVRID-1-ID-T (1)
                    MOVE SPACES       TO MIR-CFAGT-SHR-1-PCT-T (1)
                    MOVE SPACES       TO MIR-LOAN-IMPRD-INT-RT
                    MOVE SPACES       TO MIR-CF-7702-DECR-DT
                    MOVE SPACES       TO MIR-AGT-1-ID-T (2)
                    MOVE SPACES       TO MIR-COMM-RT-TBAC-1-ID-T (2)
                    MOVE SPACES       TO MIR-OVRID-1-ID-T (2)
                    MOVE SPACES       TO MIR-CFAGT-SHR-1-PCT-T (2)
                    MOVE SPACES       TO MIR-AGT-1-ID-T (3)
                    MOVE SPACES       TO MIR-COMM-RT-TBAC-1-ID-T (3)
                    MOVE SPACES       TO MIR-OVRID-1-ID-T (3)
                    MOVE SPACES       TO MIR-CFAGT-SHR-1-PCT-T (3)

           END-EVALUATE.

       0240-INITIALIZE-SCREEN-FLDS-X.
           EXIT.
008455
      *------------------------
008455 0245-INIT-AMOUNT-FIELDS.
      *------------------------
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-CLI-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-CLI-TRXN-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-FND-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-FND-TRXN-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-FND-BAL-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-FND-BAL-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-INT-TO-NXT-CF-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-INT-TO-NXT-CF-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-ACUM-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-ACUM-INT-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-TAX-GAIN-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-TAX-GAIN-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-SURR-CHRG-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-SURR-CHRG-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-MKTVAL-ADJ-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-MKTVAL-ADJ-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-TOT-SURR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-TOT-SURR-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-CPREM-1-AMT-T (01)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-CPREM-1-AMT-T (01).
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-LOAN-IMPRD-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.

008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-LOAN-IMPRD-AMT.
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-CPREM-1-AMT-T (02)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-CPREM-1-AMT-T (02).
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-CPREM-1-AMT-T (03)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-CPREM-1-AMT-T (03).
008455
020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
023122*    MOVE ZERO                  TO L0290-INPUT-V02.
023122*    MOVE 2                     TO L0290-PRECISION.
023122*    MOVE LENGTH OF MIR-CF-LTAXWH-AMT
023122*                               TO L0290-MAX-OUT-LEN.
023122*    SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023122*    PERFORM  0290-2000-FORMAT-FOR-MIR
023122*        THRU 0290-2000-FORMAT-FOR-MIR-X.
023122*    MOVE L0290-OUTPUT-DATA     TO MIR-CF-LTAXWH-AMT.

020874*    MOVE ZERO                  TO L0290-INPUT-NUMBER.
023122*    MOVE ZERO                  TO L0290-INPUT-V02.
023122*    MOVE 2                     TO L0290-PRECISION.
023122*    MOVE LENGTH OF MIR-LTAXWH-PCT
023122*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023122*    PERFORM  0290-2000-FORMAT-FOR-MIR
023122*        THRU 0290-2000-FORMAT-FOR-MIR-X.
023122*    MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-PCT.

008455 0245-INIT-AMOUNT-FIELDS-X.
008455     EXIT.
      *
      *----------------------------
       3000-PROCESS-RETRIEVE-TRANS.
      *----------------------------

023437* READ IN THE COVERAGES
023437*
023437*    PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
023437*        THRU CVGS-1000-LOAD-CVGS-ARRAY-X
023437*
023437*    IF WCVGS-CVG-COLFND (WS-CVG-NUM)
012145* GENERATE MESSAGE:'USE OF LCF NOT VALID'
023437*        MOVE 'CS07610043'      TO WGLOB-MSG-REF-INFO
023437*        PERFORM  0260-1000-GENERATE-MESSAGE
023437*            THRU 0260-1000-GENERATE-MESSAGE-X
023437*        GO TO 3000-PROCESS-RETRIEVE-TRANS-X
023437*    END-IF.

      * SET UP THE KEY AND RETRIEVE THE DESIRED CASH FLOW

           INITIALIZE WCFLW-KEY.
           MOVE RPOL-POL-ID           TO WCFLW-POL-ID.
           MOVE E0761-CVG-NUM         TO WCFLW-CVG-NUM.
005409     MOVE E0761-CF-DT           TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WCFLW-CF-EFF-DT.
           MOVE WCVGS-CVG-CF-TYP-CD (E0761-CVG-NUM)
                                      TO WCFLW-CF-TYP-CD.
           MOVE E0761-SEQ-NUM         TO WCFLW-CF-SEQ-NUM.

           PERFORM  CFCA-1000-CF-AND-CA-IN
               THRU CFCA-1000-CF-AND-CA-IN-X.
           IF WCFLW-IO-OK
      *        MSG: NEXT TRANSACTION PLEASE
               MOVE 'CS07610010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *        MSG: CASH FLOW RECORD NOT FOUND
               MOVE 'CS07610042'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-TRANS-X
           END-IF.

558976     IF RCFLW-CFAGT-SEQ-NUM > ZERO
558976     AND NOT WCFAG-IO-OK
558976* MSG:  CASH FLOW AGENT RECORD NOT IN FILE
558976         MOVE 'CS07610020'      TO WGLOB-MSG-REF-INFO
558976         PERFORM  0260-1000-GENERATE-MESSAGE
558976             THRU 0260-1000-GENERATE-MESSAGE-X
558976         GO TO 3000-PROCESS-RETRIEVE-TRANS-X
558976     END-IF.

      * RESET THE SCREEN FOR INQUIRY

           MOVE SPACES                TO MIR-DV-CF-REASN-CD.
           MOVE SPACES                TO MIR-DV-SURR-EFF-DT.
023437*    MOVE 'N'                   TO MIR-DV-TAX-OVRID-IND.
           MOVE 'N'                   TO MIR-DV-REDC-FACE-IND.
023437*    MOVE 'C'                   TO MIR-LTAXWH-CALC-CD.
023437     MOVE 'C'                   TO WS-LTAXWH-CALC-CD.
           PERFORM  8300-FINALIZE-MAP
               THRU 8300-FINALIZE-MAP-X.

       3000-PROCESS-RETRIEVE-TRANS-X.
           EXIT.
      *
      *------------------------
       4000-PROCESS-SURR-TRANS.
      *------------------------

      * READ THE POLICY

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221*    IF NOT WPOL-IO-OK
014221*        MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
014221*        PERFORM  0260-1000-GENERATE-MESSAGE
014221*            THRU 0260-1000-GENERATE-MESSAGE-X
014221*        GO TO 4000-PROCESS-SURR-TRANS-X
014221*    END-IF.

023437* READ IN THE COVERAGES
023437*
023437*    PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
023437*        THRU CVGS-1000-LOAD-CVGS-ARRAY-X
023437*
023437*    IF  WS-BUS-FCN-SURR-FND-BY-FND
023437*        NEXT SENTENCE
023437*    ELSE
023437*        IF WCVGS-CVG-COLFND (WS-CVG-NUM)
012145* GENERATE MESSAGE:'USE OF LCF NOT VALID'
023437*            MOVE 'CS07610043'      TO WGLOB-MSG-REF-INFO
023437*            PERFORM  0260-1000-GENERATE-MESSAGE
023437*                THRU 0260-1000-GENERATE-MESSAGE-X
023437*
016108*  SINCE POL TABLE IS NOT READ THE UNLOCK IS CAUSING SQL -0000501
023437*
016108*014221      PERFORM  POL-3000-UNLOCK
016108*014221          THRU POL-3000-UNLOCK-X
023437*             GO TO 4000-PROCESS-SURR-TRANS-X
023437*        END-IF
023437*    END-IF.

      * EDIT THE INPUT FIELDS FOR CORRECT VALUES

           PERFORM  4100-EDIT-INPUT-FIELDS
               THRU 4100-EDIT-INPUT-FIELDS-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF WGLOB-RETURN-ERROR
016108*014221 IF  WS-PRCES-STATE-PRCES
016108*014221 OR  WS-PRCES-STATE-CHNG
016108*014221      PERFORM  POL-3000-UNLOCK
016108*014221          THRU POL-3000-UNLOCK-X
016108*014221  END-IF
014221*        PERFORM  POL-3000-UNLOCK
014221*            THRU POL-3000-UNLOCK-X
               GO TO 4000-PROCESS-SURR-TRANS-X
           END-IF.

016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WS-CF-REC-DATE        TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108*        PERFORM  POL-3000-UNLOCK
016108*            THRU POL-3000-UNLOCK-X
016108         SET WGLOB-RETURN-ERROR TO TRUE
016108         GO TO 4000-PROCESS-SURR-TRANS-X
016108     END-IF.

      * INITIALIZE ALL WS- FIELDS THAT WILL BE USED IN PROCESSING

           SET WS-UPDATE-NO            TO TRUE.
012588     SET WS-UPDT-CVGS-NO         TO TRUE.
           MOVE ZERO                   TO L0182-POL-MTHV-ADJ-AMT.

      * BUILD THE GENERAL PARAMETER AREA

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

      * SET UP FIELDS THAT WILL EVENTUALLY BE PASSED TO CSLF1010

           PERFORM  1010-1000-BUILD-PARM-INFO
               THRU 1010-1000-BUILD-PARM-INFO-X.

012137     MOVE MIR-SUPRES-CNFRM-IND  TO L1010-SUPPRESS-CONFIRM-IND.
016503     SET L1010-REDO-WARNING     TO TRUE.
           PERFORM  8100-INIT-PARM-AREA
               THRU 8100-INIT-PARM-AREA-X.

      * CALCULATE CASH VALUES AND DISPLAY ON THE SCREEN IF APPROPRIATE

           IF  WS-BUS-FCN-SURR
021311*    AND NOT WS-PRCES-STATE-PRCES
               PERFORM  4300-GET-CASH-VALUES
                   THRU 4300-GET-CASH-VALUES-X
           END-IF.

018846     IF  WS-BUS-FCN-SURR
018846     AND WGLOB-GOOD-RETURN
018846     AND (WS-PRCES-STATE-EDIT
018846       OR WS-PRCES-STATE-PRCES)
018846         PERFORM  4050-CROSS-EDIT-AMOUNTS
018846             THRU 4050-CROSS-EDIT-AMOUNTS-X
031034**       PERFORM  4053-CROSS-EDIT-LTAXWH
031034**           THRU 4053-CROSS-EDIT-LTAXWH-X
018846     END-IF.
018846
012143     IF WS-BUS-FCN-SURR
           AND WS-PRCES-STATE-PRCES
012143     AND WGLOB-GOOD-RETURN
012143         PERFORM 4600-CREATE-SURR-CDSA
012143            THRU 4600-CREATE-SURR-CDSA-X
012143         MOVE L2600-POL-PAYO-NUM   TO RCFLW-DEST-POL-PAYO-NUM
012143         MOVE L2600-CDA-SEQ-NUM TO RCFLW-DEST-CDA-SEQ-NUM
015290         MOVE L2600-CDA-TYP-CD      TO WS-CDA-TYP-CD
015290         MOVE L2600-POL-PAYO-NUM    TO WS-POL-PAYO-NUM
015290         MOVE L2600-CDA-EFF-DT      TO L1660-INTERNAL-DATE
015290         PERFORM  1660-2000-CONVERT-INT-TO-INV
015290             THRU 1660-2000-CONVERT-INT-TO-INV-X
015290         MOVE L1660-INVERTED-DATE   TO WS-CDA-EFF-IDT-NUM
015290         MOVE L2600-CDA-SEQ-NUM     TO WS-CDA-SEQ-NUM
012143     END-IF.
012143
012143     IF WS-BUS-FCN-SURR
024787         SET  WS-AUTO-REDO-NONE     TO TRUE
012143         PERFORM 4700-DPOS-BASED-SURR-CHRG
012143            THRU 4700-DPOS-BASED-SURR-CHRG-X
031034*        PERFORM  4800-GET-PGAL-INFO
031034*            THRU 4800-GET-PGAL-INFO-X
023437         PERFORM  7400-INIT-DBG-DATA
023437             THRU 7400-INIT-DBG-DATA-X
012143     END-IF.

      * PERFORM SPECIFIC ROUTINES FOR THE REQUEST TYPE AND FORCE CODE

023437     MOVE ZEROS                 TO WS-TOT-POL-FND-AMT.
023437     MOVE ZEROS                 TO WS-TOT-POL-CLI-AMT.
023437     MOVE ZEROS                 TO WS-TOT-POL-CF-FND-AMT.
023437     MOVE ZEROS                 TO WS-TOT-POL-CF-CLI-AMT.
023437     MOVE ZEROS                 TO WS-TOT-SIDFND-FND-AMT.
023437     MOVE ZEROS                 TO WS-TOT-SIDFND-CLI-AMT.
023437     MOVE ZEROS                 TO WS-TRXN-FEE-AMT.
031034*    MOVE ZEROS                 TO WS-PGAL-TRXN-FEE-AMT.
023437*    MOVE ZEROES                TO WS-TOTAL-WITHHELD.
023437*    MOVE ZEROES                TO WS-TOTAL-CF-LTAXWH-AMT.
016503     SET  WS-REDO-OK            TO TRUE.
024787     SET  WS-AUTO-REDO-NONE     TO TRUE.

           EVALUATE TRUE

               WHEN WS-PRCES-STATE-RETRIEVE
                    PERFORM  7000-FINALIZE-SURR-TRANS
                        THRU 7000-FINALIZE-SURR-TRANS-X

023437         WHEN WS-PRCES-STATE-PRCES
023437              PERFORM  7250-PRCES-UNDO-REDO
023437                  THRU 7250-PRCES-UNDO-REDO-X

               WHEN WS-BUS-FCN-SURR-FND-BY-FND
                    PERFORM  6000-FUND-BY-FUND-TRANS
                        THRU 6000-FUND-BY-FUND-TRANS-X
023437              PERFORM  6800-TAX-PROCESSING
023437                  THRU 6800-TAX-PROCESSING-X

               WHEN OTHER
                    PERFORM  7000-FINALIZE-SURR-TRANS
                        THRU 7000-FINALIZE-SURR-TRANS-X
023437              IF NOT WS-BUS-FCN-REVRS
023437                 PERFORM  6800-TAX-PROCESSING
023437                     THRU 6800-TAX-PROCESSING-X
023437              END-IF

           END-EVALUATE.

016503     IF  WS-REDO-NOT-OK
016503         GO TO 4000-PROCESS-SURR-TRANS-X
016503     END-IF.

023437     IF  WS-PRCES-STATE-PRCES
023437     AND WS-BUS-FCN-REVRS
023437         PERFORM  7000-FINALIZE-SURR-TRANS
023437             THRU 7000-FINALIZE-SURR-TRANS-X
023437     END-IF.

023437     IF  WS-PRCES-STATE-PRCES
023437     AND NOT WS-BUS-FCN-REVRS
024787
024787         SET  WS-AUTO-REDO-DONE     TO TRUE
024787
024787         PERFORM  1010-1000-BUILD-PARM-INFO
024787             THRU 1010-1000-BUILD-PARM-INFO-X
024787
024787         MOVE MIR-SUPRES-CNFRM-IND  TO L1010-SUPPRESS-CONFIRM-IND
024787         SET L1010-REDO-WARNING     TO TRUE
024787         PERFORM  8100-INIT-PARM-AREA
024787             THRU 8100-INIT-PARM-AREA-X
024787
024787         PERFORM  4300-GET-CASH-VALUES
024787             THRU 4300-GET-CASH-VALUES-X
024787
024787         PERFORM  4050-CROSS-EDIT-AMOUNTS
024787             THRU 4050-CROSS-EDIT-AMOUNTS-X
024787
024787         PERFORM  4700-DPOS-BASED-SURR-CHRG
024787             THRU 4700-DPOS-BASED-SURR-CHRG-X
031034*        PERFORM  4800-GET-PGAL-INFO
031034*            THRU 4800-GET-PGAL-INFO-X
023437         PERFORM  7400-INIT-DBG-DATA
023437             THRU 7400-INIT-DBG-DATA-X
024787
024787         SET WS-PRCES-STATE-EDIT    TO TRUE
023437
023437         MOVE ZEROS                 TO WS-TOT-POL-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CLI-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CF-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CF-CLI-AMT
023437         MOVE ZEROS                 TO WS-TOT-SIDFND-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-SIDFND-CLI-AMT
023437         MOVE ZEROS                 TO WS-TRXN-FEE-AMT
031034*        MOVE ZEROS                 TO WS-PGAL-TRXN-FEE-AMT
023437         IF  WS-BUS-FCN-SURR-FND-BY-FND
023437              PERFORM  6000-FUND-BY-FUND-TRANS
023437                  THRU 6000-FUND-BY-FUND-TRANS-X
023437         ELSE
023437              PERFORM  7000-FINALIZE-SURR-TRANS
023437                  THRU 7000-FINALIZE-SURR-TRANS-X
023437         END-IF
023437         PERFORM  6800-TAX-PROCESSING
023437             THRU 6800-TAX-PROCESSING-X
024787         PERFORM  1010-1000-BUILD-PARM-INFO
024787             THRU 1010-1000-BUILD-PARM-INFO-X
024787
024787         MOVE MIR-SUPRES-CNFRM-IND  TO L1010-SUPPRESS-CONFIRM-IND
024787         SET L1010-REDO-WARNING     TO TRUE
024787         PERFORM  8100-INIT-PARM-AREA
024787             THRU 8100-INIT-PARM-AREA-X
023437
024787         IF  WS-BUS-FCN-FULL-GIA-SURR
024787             MOVE ZERO              TO L1010-AMOUNT
024787         END-IF

024787         SET WS-PRCES-STATE-CHNG    TO TRUE
023437         MOVE ZEROS                 TO WS-TOT-POL-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CLI-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CF-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CF-CLI-AMT
023437         MOVE ZEROS                 TO WS-TOT-SIDFND-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-SIDFND-CLI-AMT
023437         MOVE ZEROS                 TO WS-TRXN-FEE-AMT
031034*        MOVE ZEROS                 TO WS-PGAL-TRXN-FEE-AMT
023437         IF  WS-BUS-FCN-SURR-FND-BY-FND
023437              PERFORM  6000-FUND-BY-FUND-TRANS
023437                  THRU 6000-FUND-BY-FUND-TRANS-X
023437         ELSE
023437              PERFORM  7000-FINALIZE-SURR-TRANS
023437                  THRU 7000-FINALIZE-SURR-TRANS-X
023437         END-IF
023437         PERFORM  6800-TAX-PROCESSING
023437             THRU 6800-TAX-PROCESSING-X
024787         PERFORM  1010-1000-BUILD-PARM-INFO
024787             THRU 1010-1000-BUILD-PARM-INFO-X
024787
024787         MOVE MIR-SUPRES-CNFRM-IND  TO L1010-SUPPRESS-CONFIRM-IND
024787         SET L1010-REDO-WARNING     TO TRUE
024787         PERFORM  8100-INIT-PARM-AREA
024787             THRU 8100-INIT-PARM-AREA-X

024787         PERFORM  4050-CROSS-EDIT-AMOUNTS
024787             THRU 4050-CROSS-EDIT-AMOUNTS-X

024787         MOVE WS-POL-PAYO-NUM       TO RCFLW-DEST-POL-PAYO-NUM
024787         MOVE WS-CDA-SEQ-NUM        TO RCFLW-DEST-CDA-SEQ-NUM

024787         SET WS-PRCES-STATE-PRCES TO TRUE
024787         SET  WS-REDO-OK            TO TRUE
023437         MOVE ZEROS                 TO WS-TOT-POL-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CLI-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CF-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-POL-CF-CLI-AMT
023437         MOVE ZEROS                 TO WS-TOT-SIDFND-FND-AMT
023437         MOVE ZEROS                 TO WS-TOT-SIDFND-CLI-AMT
023437         MOVE ZEROS                 TO WS-TRXN-FEE-AMT
031034*        MOVE ZEROS                 TO WS-PGAL-TRXN-FEE-AMT

023437         IF  WS-BUS-FCN-SURR-FND-BY-FND
023437              PERFORM  6000-FUND-BY-FUND-TRANS
023437                  THRU 6000-FUND-BY-FUND-TRANS-X
023437         ELSE
023437              PERFORM  7000-FINALIZE-SURR-TRANS
023437                  THRU 7000-FINALIZE-SURR-TRANS-X
023437         END-IF

023437         PERFORM  6800-TAX-PROCESSING
023437             THRU 6800-TAX-PROCESSING-X
024787     END-IF.

      * AFTER THE CHANGES HAVE PROCESSED, SEND A MESSAGE TO THE USER
      * TO INDICATE THE CHANGE TRANSACTION HAS BEEN PROCESSED

           IF  WS-PRCES-STATE-CHNG
           AND WGLOB-GOOD-RETURN
               MOVE 'CS07610012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      * IF IT IS NOT THE FINAL PASS, SET UP AND WRITE THE CASH
      * FLOW RECORDS TO THE TEMPORARY STORAGE QUEUE

           IF L1010-PRCES-TYP-EDIT-ONLY
           OR WGLOB-RETURN-ERROR
               PERFORM  4200-WRITE-TSQ
                   THRU 4200-WRITE-TSQ-X
012143     ELSE
012143         IF WS-BUS-FCN-SURR
012143             PERFORM 4650-UPDATE-SURR-CDSA
012143                THRU 4650-UPDATE-SURR-CDSA-X
023437             PERFORM  7410-WRITE-DBGA-REC
023437                 THRU 7410-WRITE-DBGA-REC-X
012143         END-IF
           END-IF.

014221     IF  WS-PRCES-STATE-RETRIEVE
014221     OR  WS-PRCES-STATE-EDIT
014221     OR  NOT WGLOB-GOOD-RETURN
014221         PERFORM  8300-FINALIZE-MAP
014221             THRU 8300-FINALIZE-MAP-X
014221         GO TO 4000-PROCESS-SURR-TRANS-X
014221     END-IF.

      * IF UPDATE IS NECESSARY, REWRITE THE POLICY AND COVERAGES

014221*    IF (  (   L1010-PRCES-TYP-VER-ONLY
014221*          OR  WS-UPDATE-REQUIRED)
014221*       AND WGLOB-GOOD-RETURN)
014221*    OR  WS-UPDT-CVGS-REQUIRED
016503*        MOVE WWKDT-ZERO-DT     TO RPOL-POL-NXT-ACTV-DT
016503*        IF RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*            MOVE 'RSH'         TO RPOL-NXT-ACTV-TYP-CD
016503*        END-IF
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     MOVE L1010-EFF-DT             TO L0289-LO-PAC-DT.
020467     MOVE L1010-EFF-DT             TO L0289-LO-DD2-DT.
016503     MOVE L1010-EFF-DT             TO L0289-LO-CRC-DT.
016503     MOVE L1010-EFF-DT             TO L0289-PROC-EFF-DT.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.
014221*    END-IF.

           PERFORM  8300-FINALIZE-MAP
               THRU 8300-FINALIZE-MAP-X.

       4000-PROCESS-SURR-TRANS-X.
           EXIT.

018846*---------------------------
018846 4050-CROSS-EDIT-AMOUNTS.
018846*---------------------------
018846
018846     IF  WS-BUS-FCN-SURR-FND-BY-CVG
018846         IF  NOT WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846         AND L0182-SIDFND-AFV-AMT > ZERO
018846             PERFORM  4055-MSG-SIDFND-EXISTS
018846                 THRU 4055-MSG-SIDFND-EXISTS-X
018846         END-IF
018846     END-IF.
018846
018846     IF  WGLOB-MSG-SEVRTY-FATAL
018846         GO TO 4050-CROSS-EDIT-AMOUNTS-X
018846     END-IF.
018846
018846     EVALUATE TRUE
018846
018846         WHEN WS-BUS-FCN-SURR-NON-SPEC
018846         WHEN WS-BUS-FCN-PARTL-GIA-SURR
018846              IF  WCVGS-PLAN-FND-TYP-SIDE (E0761-CVG-NUM)
018846                  MOVE E0761-AMOUNT   TO WS-SIDFND-TOT-SURR-AMT
018846              ELSE
018846                  MOVE E0761-AMOUNT   TO WS-POL-TOT-SURR-AMT
018846              END-IF
018846              GO TO 4050-CROSS-EDIT-AMOUNTS-X
018846
018846         WHEN WS-BUS-FCN-SURR-FND-BY-AMT
018846         WHEN WS-BUS-FCN-SURR-FND-BY-UNIT
018846              CONTINUE
018846
018846         WHEN OTHER
018846              GO TO 4050-CROSS-EDIT-AMOUNTS-X
018846
018846     END-EVALUATE.
018846
018846     PERFORM
018846         VARYING WS-LINE FROM 1 BY 1
018846         UNTIL   WS-LINE > WS-MAX-FUND-LINES
018846
018846         IF  WS-BUS-FCN-SURR-FND-BY-AMT
018846             PERFORM  4051-SUM-SIF-TOT-SURR-AMT
018846                 THRU 4051-SUM-SIF-TOT-SURR-AMT-X
018846         ELSE
018846             PERFORM  4052-SUM-SIF-TOT-SURR-UNTS
018846                 THRU 4052-SUM-SIF-TOT-SURR-UNTS-X
018846         END-IF
018846
018846     END-PERFORM.
018846
018846     EVALUATE TRUE
018846
018846         WHEN WS-BUS-FCN-SURR-FND-BY-AMT
018846              IF  WS-POL-TOT-SURR-AMT > ZERO
018846              AND WS-SIDFND-TOT-SURR-AMT < WS-POL-TOT-SURR-AMT
018846              AND L0182-SIDFND-AFV-AMT > ZERO
018846                  PERFORM  4055-MSG-SIDFND-EXISTS
018846                      THRU 4055-MSG-SIDFND-EXISTS-X
018846              END-IF
018846
018846         WHEN WS-BUS-FCN-SURR-FND-BY-UNIT
018846              IF  WS-POL-TOT-SURR-UNTS > ZERO
018846              AND WS-SIDFND-TOT-SURR-UNTS
018846                              < WS-POL-TOT-SURR-UNTS
018846              AND L0182-SIDFND-AFV-AMT > ZERO
018846                  PERFORM  4055-MSG-SIDFND-EXISTS
018846                      THRU 4055-MSG-SIDFND-EXISTS-X
018846              END-IF
018846
018846     END-EVALUATE.
018846
018846 4050-CROSS-EDIT-AMOUNTS-X.
018846     EXIT.
018846
018846*---------------------------
018846 4051-SUM-SIF-TOT-SURR-AMT.
018846*---------------------------
018846
018846     IF  WS-H-ACOV (WS-LINE) = '00'
018846     OR  WS-H-ACOV (WS-LINE) = SPACES
018846         GO TO 4051-SUM-SIF-TOT-SURR-AMT-X
018846     END-IF.
018846
018846     MOVE 'N'                   TO L0280-SIGN-IND.
018846     MOVE ZERO                  TO L0280-PRECISION.
018846     MOVE 2                     TO L0280-LENGTH.
018846     MOVE WS-H-ACOV (WS-LINE)   TO L0280-INPUT-DATA.
018846     PERFORM  0280-1000-NUMERIC-EDIT
018846         THRU 0280-1000-NUMERIC-EDIT-X.
018846     IF  L0280-OK
018846         MOVE L0280-OUTPUT      TO WS-CVG-NUM
018846     ELSE
031357         MOVE 'CS07610031'      TO WGLOB-MSG-REF-INFO
031357         PERFORM  0260-1000-GENERATE-MESSAGE
031357             THRU 0260-1000-GENERATE-MESSAGE-X
031357         SET WGLOB-RETURN-ERROR       TO TRUE
018846         GO TO 4051-SUM-SIF-TOT-SURR-AMT-X
018846     END-IF.
018846
031357     IF  WS-CVG-NUM > RPOL-POL-CVG-REC-CTR-N
031357         MOVE 'CS07610031'      TO WGLOB-MSG-REF-INFO
031357         PERFORM  0260-1000-GENERATE-MESSAGE
031357             THRU 0260-1000-GENERATE-MESSAGE-X
031357         SET WGLOB-RETURN-ERROR       TO TRUE
031357         GO TO 4051-SUM-SIF-TOT-SURR-AMT-X
031357     END-IF.
031357
018846     MOVE 'N'                   TO L0280-SIGN-IND.
018846     MOVE 2                     TO L0280-PRECISION.
018846     MOVE LENGTH OF WS-H-AMNT (WS-LINE)
018846                                TO L0280-INPUT-SIZE.
018846     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
018846                            L0280-PRECISION - 1.
018846     MOVE WS-H-AMNT (WS-LINE)   TO L0280-INPUT-DATA.
018846     PERFORM  0280-1000-NUMERIC-EDIT
018846         THRU 0280-1000-NUMERIC-EDIT-X.
018846     IF  NOT L0280-OK
018846         GO TO 4051-SUM-SIF-TOT-SURR-AMT-X
018846     END-IF.
018846
018846     IF  WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846         EVALUATE TRUE
018846
018846             WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846                  ADD L0280-OUTPUT-DOLLAR
018846                   TO WS-SIDFND-TOT-SURR-AMT
018846
018846         END-EVALUATE
018846     ELSE
018846         ADD L0280-OUTPUT-DOLLAR
018846          TO WS-POL-TOT-SURR-AMT
018846     END-IF.
018846
018846 4051-SUM-SIF-TOT-SURR-AMT-X.
018846     EXIT.
018846
018846*---------------------------
018846 4052-SUM-SIF-TOT-SURR-UNTS.
018846*---------------------------
018846
018846     IF  WS-H-UCOV (WS-LINE) = '00'
018846     OR  WS-H-UCOV (WS-LINE) = SPACES
018846         GO TO 4052-SUM-SIF-TOT-SURR-UNTS-X
018846     END-IF.
018846
018846     MOVE 'N'                   TO L0280-SIGN-IND.
018846     MOVE ZERO                  TO L0280-PRECISION.
018846     MOVE 2                     TO L0280-LENGTH.
018846     MOVE WS-H-ACOV (WS-LINE)   TO L0280-INPUT-DATA.
018846     PERFORM  0280-1000-NUMERIC-EDIT
018846         THRU 0280-1000-NUMERIC-EDIT-X.
018846     IF  L0280-OK
018846         MOVE L0280-OUTPUT      TO WS-CVG-NUM
018846     ELSE
018846         GO TO 4052-SUM-SIF-TOT-SURR-UNTS-X
018846     END-IF.
018846
018846     MOVE 'N'                   TO L0280-SIGN-IND.
018846     MOVE 5                     TO L0280-PRECISION.
018846     MOVE 12                    TO L0280-LENGTH.
018846     MOVE 18                    TO L0280-INPUT-SIZE.
018846     MOVE WS-H-UNIT (WS-LINE)   TO L0280-INPUT-DATA.
018846     PERFORM  0280-1000-NUMERIC-EDIT
018846         THRU 0280-1000-NUMERIC-EDIT-X
018846     IF  NOT L0280-OK
018846         GO TO 4052-SUM-SIF-TOT-SURR-UNTS-X
018846     END-IF.
018846
018846     IF  WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
018846         EVALUATE TRUE
018846
018846             WHEN WCVGS-PLAN-FND-TYP-SIDE (WS-CVG-NUM)
018846                  ADD L0280-OUTPUT-V05 TO WS-SIDFND-TOT-SURR-UNTS
018846
018846         END-EVALUATE
018846     ELSE
018846         ADD L0280-OUTPUT-V05   TO WS-POL-TOT-SURR-UNTS
018846     END-IF.
018846
018846 4052-SUM-SIF-TOT-SURR-UNTS-X.
018846     EXIT.
018846
018846*----------------------------
031034*4053-CROSS-EDIT-LTAXWH.
018846*----------------------------
031034
031034**   IF  WS-BUS-FCN-PARTL-GIA-SURR
031034**   OR  WS-BUS-FCN-SURR-FND-BY-UNIT
031034**   OR  WS-BUS-FCN-FULL-GIA-SURR
031034**       CONTINUE
031034**   ELSE
031034**       IF  E0761-CF-LTAXWH-AMT > WS-POL-TOT-SURR-AMT
031034*MSG: LOCATION AMOUNT CAN NOT BE MORE THAT GROSS DISTRIBUTION
031034**           MOVE 'CS07610055'            TO WGLOB-MSG-REF-INFO
031034**           PERFORM  0260-1000-GENERATE-MESSAGE
031034**               THRU 0260-1000-GENERATE-MESSAGE-X
031034**           SET WGLOB-RETURN-ERROR       TO TRUE
031034**       END-IF
031034**   END-IF.
031034**
031034*4053-CROSS-EDIT-LTAXWH-X.
031034**   EXIT.
018846*---------------------------
018846 4055-MSG-SIDFND-EXISTS.
018846*---------------------------
018846
018846*MSG: WITHDRAWAL FROM NON-SIDE FUND COVERAGE.
018846*     SIDE FUIND VALUE > 0.00
018846     MOVE 'CS07610056'           TO WGLOB-MSG-REF-INFO.
018846     PERFORM  0260-1000-GENERATE-MESSAGE
018846         THRU 0260-1000-GENERATE-MESSAGE-X.
018846
018846     IF  WGLOB-MSG-SEVRTY-FATAL
018846         SET WGLOB-RETURN-ERROR  TO TRUE
018846     END-IF.
018846
018846 4055-MSG-SIDFND-EXISTS-X.
018846     EXIT.
018846
      *-----------------------
       4100-EDIT-INPUT-FIELDS.
      *-----------------------

      * EDIT THE COVERAGE NUMBER TO MAKE SURE IT IS VALID

           IF  E0761-CVG-NUM = ZERO
           AND NOT WS-BUS-FCN-SURR-FND-BY-FND
                MOVE 'CS00000021'     TO WGLOB-MSG-REF-INFO
031357          MOVE E0761-CVG-NUM-R     TO WGLOB-MSG-PARM (01)
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      * CHECK THE VALIDITY OF THE GIA SURRENDER EFFECTIVE DATE

           IF  E0761-GIA-SUR-DT  NOT = SPACES
           AND E0761-GIA-SUR-DT  NOT = WWKDT-ZERO-DT
               IF  NOT E0761-GIA-SURRENDER
                   MOVE WWKDT-ZERO-DT TO E0761-GIA-SUR-DT
      * MSG:  GIA SURR EFF DATE NOT VALID WITH ENTER CODE
                   MOVE 'CS07610001'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

023437* CHECK THE VALID VALUES FOR OVERRIDE
023437*
023437*    IF NOT E0761-OVERRIDE-VALID
023437*        MOVE 'CS07610003'      TO WGLOB-MSG-REF-INFO
023437*        PERFORM  0260-1000-GENERATE-MESSAGE
023437*             THRU 0260-1000-GENERATE-MESSAGE-X
023437*    END-IF.

      * CHECK THE VALID VALUES FOR AUTO FACE REDUCTION

           IF NOT E0761-AFR-THRSHD-VALID
               MOVE 'CS07610004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4100-EDIT-INPUT-FIELDS-X.
           EXIT.
      *
      *---------------
       4200-WRITE-TSQ.
      *---------------

      * WRITE OUT THE CFLW AND CFAG RECORDS TO TEMPORARY STORAGE
      * FOR RETRIEVAL UPON RE-ENTRY TO THIS PROGRAM

           IF NOT WS-BUS-FCN-SURR-FND-BY-FND
               MOVE WCFCS-WORK-AREA   TO WS-CFCO-REC-AREA (1)
               MOVE RCFLW-REC-INFO    TO WS-CFLW-REC-INFO (1)
               MOVE RCFAG-REC-INFO    TO WS-CFAG-REC-INFO
           END-IF.

           PERFORM  8090-1000-BUILD-PARM-INFO
               THRU 8090-1000-BUILD-PARM-INFO-X.

           SET L8090-TEMP-WRK-TYP-CF-SUR    TO TRUE.
018691*    MOVE LENGTH OF WS-CASH-FLOW-INFO TO L8090-AREA-LEN.
018691*    MOVE WS-CASH-FLOW-INFO           TO L8090-AREA-INFO-TEXT.
018691*
018691*    PERFORM  8090-1000-WRITE-TWRK
018691*        THRU 8090-1000-WRITE-TWRK-X.
018691*
018691*    IF  NOT L8090-RETRN-OK
018691*        MOVE 'XS00000092'      TO WGLOB-MSG-REF-INFO
018691*        PERFORM  0260-1000-GENERATE-MESSAGE
018691*            THRU 0260-1000-GENERATE-MESSAGE-X
018691*    END-IF.
018691
018691     COMPUTE WS-TMP-REC-LEN = LENGTH OF WS-CASH-FLOW-INFO.
018691     MOVE +1                          TO WS-TMP-REC-START.
018691     SET L8090-RETRN-OK               TO TRUE.
018691
018691     PERFORM
018691         UNTIL WS-TMP-REC-START > LENGTH OF WS-CASH-FLOW-INFO
018691         OR NOT L8090-RETRN-OK
018691
018691         IF  WS-TMP-REC-LEN > LENGTH OF L8090-AREA-INFO-TEXT
018691             COMPUTE WS-TMP-REC-LEN =
018691                    LENGTH OF L8090-AREA-INFO-TEXT
018691         END-IF
018691
018691         MOVE WS-TMP-REC-LEN          TO L8090-AREA-LEN
018691         MOVE WS-CASH-FLOW-INFO (WS-TMP-REC-START:WS-TMP-REC-LEN)
018691                                      TO L8090-AREA-INFO-TEXT
018691         PERFORM  8090-1000-WRITE-TWRK
018691             THRU 8090-1000-WRITE-TWRK-X
018691
018691         IF  NOT L8090-RETRN-OK
018691             MOVE 'XS00000092'      TO WGLOB-MSG-REF-INFO
018691             PERFORM  0260-1000-GENERATE-MESSAGE
018691                 THRU 0260-1000-GENERATE-MESSAGE-X
018691         END-IF
018691
018691         COMPUTE WS-TMP-REC-START = WS-TMP-REC-START
018691                                  + WS-TMP-REC-LEN
018691         COMPUTE WS-TMP-REC-LEN = LENGTH OF WS-CASH-FLOW-INFO
018691                                - WS-TMP-REC-START
018691                                + 1
018691
018691     END-PERFORM.
018691

       4200-WRITE-TSQ-X.
           EXIT.

      *---------------------
       4300-GET-CASH-VALUES.
      *---------------------

      * RETRIEVE CASH VALUES TO DISPLAY ON THE SCREEN

           PERFORM  0182-1000-BUILD-PARM-INFO
               THRU 0182-1000-BUILD-PARM-INFO-X.
           MOVE L1010-EFF-DT          TO L0182-EFF-DT.
           SET L0182-SURR-CHRG-TYP-PARTL    TO TRUE.
           PERFORM  0182-1000-CALC-CSV-POL
               THRU 0182-1000-CALC-CSV-POL-X.
           IF WS-BUS-FCN-SURR-FND-BY-FND
021311     AND NOT WS-PRCES-STATE-PRCES
               PERFORM  4350-INIT-F-BY-F-MAP
                   THRU 4350-INIT-F-BY-F-MAP-X
           END-IF.

018846     MOVE ZERO                  TO WS-SIDFND-EQTY-UNIT-QTY.
018846     PERFORM
018846         VARYING I FROM 1 BY 1
018846         UNTIL I > RPOL-POL-CVG-REC-CTR-N
018846
018846         IF  WCVGS-PLAN-FND-TYP-SIDE (I)
018846             ADD L0182-EQTY-UNIT-QTY (I)
018846              TO WS-SIDFND-EQTY-UNIT-QTY
018846         END-IF
018846
018846     END-PERFORM.
018846
       4300-GET-CASH-VALUES-X.
           EXIT.

      *---------------------
       4350-INIT-F-BY-F-MAP.
      *---------------------
      * INITIALIZE THE MAP BASED ON THE FORCE CODE

           MOVE ZERO                  TO WS-LINE.

           EVALUATE TRUE

               WHEN WS-PRCES-STATE-RETRIEVE
                   PERFORM  4360-INIT-F-MAP-PASS-1
                       THRU 4360-INIT-F-MAP-PASS-1-X
                   VARYING I FROM 1 BY 1
                   UNTIL   I  > WS-MAX-FUND-LINES
                   OR      I  > RPOL-POL-CVG-REC-CTR-N
                   OR WS-LINE = WS-MAX-FUND-LINES

               WHEN OTHER
                   PERFORM  4370-INIT-F-MAP-PASS-2
                       THRU 4370-INIT-F-MAP-PASS-2-X
                   VARYING I FROM 1 BY 1
                   UNTIL   I  > WS-MAX-FUND-LINES
                   OR WS-LINE = WS-MAX-FUND-LINES

           END-EVALUATE.

       4350-INIT-F-BY-F-MAP-X.
           EXIT.

      *-----------------------
       4360-INIT-F-MAP-PASS-1.
      *-----------------------
015753
015753     IF  WCVGS-CVG-COLFND (I)
015753         GO TO 4360-INIT-F-MAP-PASS-1-X
015753     END-IF.
015753
           IF WCVGS-CVG-INS-TYP-FPA         (I)
           OR WCVGS-CVG-INS-TYP-UL-INS-ANTY (I)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               GO TO 4360-INIT-F-MAP-PASS-1-X
           END-IF.

           ADD 1                                TO WS-LINE.

           IF WS-BUS-FCN-SURR-FND-BY-AMT
020874*        MOVE I                 TO WS-OUTPUT-INX2
020874*        MOVE WS-OUTPUT-INX2    TO MIR-CVG-NUM-T (WS-LINE)
020874         MOVE I                     TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NUM-T (WS-LINE)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM-T (WS-LINE)
023437*        MOVE E0761-OVERRIDE   TO MIR-DV-TAX-OVRID-IND-T (WS-LINE)
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CF-TOT-SURR-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CF-TOT-SURR-AMT-T (WS-LINE)
008455
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                     TO MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
008455
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CF-MKTVAL-ADJ-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                    TO MIR-CF-MKTVAL-ADJ-AMT-T (WS-LINE)
008455
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
023437*        MOVE ZERO              TO L0290-INPUT-V02
023437*        MOVE 2                 TO L0290-PRECISION
023437*        MOVE LENGTH OF MIR-CF-FED-TAXWH-AMT-T (WS-LINE)
023437*                               TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
023437*        PERFORM  0290-2000-FORMAT-FOR-MIR
023437*            THRU 0290-2000-FORMAT-FOR-MIR-X
023437*        MOVE L0290-OUTPUT-DATA
023437*                              TO MIR-CF-FED-TAXWH-AMT-T (WS-LINE)

020874*        MOVE 0                TO L0290-INPUT-NUMBER
023437*        MOVE ZERO              TO L0290-INPUT-V02
023437*        MOVE 2                TO L0290-PRECISION
023437*        MOVE LENGTH OF MIR-CF-LTAXWH-AMT-T (WS-LINE)
023437*                              TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
023437*        PERFORM  0290-2000-FORMAT-FOR-MIR
023437*            THRU 0290-2000-FORMAT-FOR-MIR-X
023437*        MOVE L0290-OUTPUT-DATA
023437*                              TO MIR-CF-LTAXWH-AMT-T (WS-LINE)
023437*
               IF E0761-REASON = 'NET'
008455*            COMPUTE WS-EDIT-9V2S = L0182-CVG-CSV-AMT (I)
008455*                                 - L0182-POL-MTHV-ADJ-AMT
008455*            MOVE WS-EDIT-9V2S   TO MIR-DV-POL-CSV-AMT-T (WS-LINE)
018846*            COMPUTE WS-WORK-13V2S   = L0182-CVG-CSV-AMT (I)
018846*                                    - L0182-POL-MTHV-ADJ-AMT
018846             IF  WCVGS-PLAN-FND-TYP-NONE (I)
018846                 COMPUTE WS-WORK-13V2S   = L0182-CVG-CSV-AMT (I)
018846                                         - L0182-POL-MTHV-ADJ-AMT
018846             ELSE
018846                 COMPUTE WS-WORK-13V2S   = L0182-CVG-CSV-AMT (I)
018846             END-IF
018846
020874*            COMPUTE L0290-INPUT-NUMBER = WS-WORK-13V2S * 100
020874             MOVE WS-WORK-13V2S TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-POL-CSV-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
008455             SET L0290-SIGN-DISPLAY  TO TRUE
008455             SET L0290-SIGN-POS-DISPLAY
008455                                TO TRUE
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM  0290-2000-FORMAT-FOR-MIR
020874                 THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-POL-CSV-AMT-T (WS-LINE)
008455
               ELSE
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                                    L0182-CVG-ACUM-VALU-AMT (I)
020874*                                    * 100
020874             MOVE L0182-CVG-ACUM-VALU-AMT (I) TO L0290-INPUT-V02
008455             MOVE 2                           TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-POL-CSV-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
008455             SET L0290-SIGN-DISPLAY  TO TRUE
008455             SET L0290-SIGN-POS-DISPLAY
008455                                TO TRUE
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM  0290-2000-FORMAT-FOR-MIR
020874                 THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-POL-CSV-AMT-T (WS-LINE)
008455
               END-IF
               GO TO 4360-INIT-F-MAP-PASS-1-X
           END-IF.

           IF WS-BUS-FCN-SURR-FND-BY-UNIT
020874*        MOVE I                 TO WS-OUTPUT-INX2
020874*        MOVE WS-OUTPUT-INX2    TO MIR-CVG-NUM-T (WS-LINE)
020874         MOVE I                     TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NUM-T (WS-LINE)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM-T (WS-LINE)
023437*        MOVE E0761-OVERRIDE   TO MIR-DV-TAX-OVRID-IND-T (WS-LINE)
               MOVE L0182-EQTY-UNIT-QTY (I)
005193*                               TO WS-EDIT-8V5S
005193                                TO WS-EDIT-12V5S
005193*        MOVE WS-EDIT-8V5S      TO MIR-CF-UNIT-QTY-T (WS-LINE)
005193         MOVE WS-EDIT-12V5S     TO MIR-CF-UNIT-QTY-T (WS-LINE)
005193*        MOVE '00000000.00000'  TO MIR-DV-CF-UNIT-QTY-T (WS-LINE)
005193         MOVE '000000000000.00000'
005193                                TO MIR-DV-CF-UNIT-QTY-T (WS-LINE)
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                     TO MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
008455
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
023437*        MOVE ZERO              TO L0290-INPUT-V02
023437*        MOVE 2                 TO L0290-PRECISION
023437*        MOVE LENGTH OF MIR-CF-FED-TAXWH-AMT-T (WS-LINE)
023437*                               TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
023437*        PERFORM  0290-2000-FORMAT-FOR-MIR
023437*            THRU 0290-2000-FORMAT-FOR-MIR-X
023437*        MOVE L0290-OUTPUT-DATA
023437*                              TO MIR-CF-FED-TAXWH-AMT-T (WS-LINE)

020874*        MOVE 0                TO L0290-INPUT-NUMBER
023437*        MOVE ZERO             TO L0290-INPUT-V02
023437*        MOVE 2                TO L0290-PRECISION
023437*        MOVE LENGTH OF MIR-CF-LTAXWH-AMT-T (WS-LINE)
023437*                              TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
023437*        PERFORM  0290-2000-FORMAT-FOR-MIR
023437*            THRU 0290-2000-FORMAT-FOR-MIR-X
023437*        MOVE L0290-OUTPUT-DATA
023437*                              TO MIR-CF-LTAXWH-AMT-T (WS-LINE)
008455
           END-IF.

       4360-INIT-F-MAP-PASS-1-X.
           EXIT.

      *-----------------------
       4370-INIT-F-MAP-PASS-2.
      *-----------------------

      * FIRST SET UP THE COVERAGE NUMBER.  IF NOT VALID, EXIT.

           IF WS-BUS-FCN-SURR-FND-BY-AMT
               MOVE WS-H-ACOV (I)     TO WS-COV-NUM-X
           ELSE
               MOVE WS-H-UCOV (I)     TO WS-COV-NUM-X
           END-IF.

           IF  WS-COV-NUM-X NUMERIC
           AND WS-COV-NUM > ZERO
           AND WS-COV-NUM <= RPOL-POL-CVG-REC-CTR-N
               CONTINUE
           ELSE
               GO TO 4370-INIT-F-MAP-PASS-2-X
           END-IF.

015753     IF  WS-BUS-FCN-SURR-FND-BY-FND
015753         IF  WCVGS-CVG-COLFND (WS-COV-NUM)
015753*MSG: USE OF LCF NOT VALID
015753             MOVE 'CS07610043'   TO WGLOB-MSG-REF-INFO
015753             PERFORM  0260-1000-GENERATE-MESSAGE
015753                 THRU 0260-1000-GENERATE-MESSAGE-X
015753         END-IF
015753     END-IF.
015753
      * SET UP THE CASH VALUE AVAILABLE FROM THE FUND

           IF WS-BUS-FCN-SURR-FND-BY-AMT
               IF E0761-REASON = 'NET'
018846*            COMPUTE L0290-INPUT-NUMBER =
018846*                    (L0182-CVG-CSV-AMT (WS-COV-NUM) -
018846*                     L0182-POL-MTHV-ADJ-AMT) * 100
018846             IF  WCVGS-PLAN-FND-TYP-NONE (WS-COV-NUM)
020874*                COMPUTE L0290-INPUT-NUMBER =
020874*                    (L0182-CVG-CSV-AMT (WS-COV-NUM) -
020874*                     L0182-POL-MTHV-ADJ-AMT) * 100
020874                 COMPUTE L0290-INPUT-V02 =
020874                     (L0182-CVG-CSV-AMT (WS-COV-NUM) -
020874                      L0182-POL-MTHV-ADJ-AMT)
018846             ELSE
020874*                COMPUTE L0290-INPUT-NUMBER =
020874*                      L0182-CVG-CSV-AMT (WS-COV-NUM)
020874*                    * 100
020874                 MOVE  L0182-CVG-CSV-AMT (WS-COV-NUM)
020874                       TO L0290-INPUT-V02
018846             END-IF
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-POL-CSV-AMT-T (I)
008455                                TO L0290-MAX-OUT-LEN
008455             SET L0290-SIGN-DISPLAY  TO TRUE
008455             SET L0290-SIGN-POS-DISPLAY
008455                                TO TRUE
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM  0290-2000-FORMAT-FOR-MIR
020874                 THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-POL-CSV-AMT-T (I)
008455                                        WS-H-AFVAL (I)
008455
               ELSE
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    L0182-CVG-ACUM-VALU-AMT (WS-COV-NUM) * 100
020874             MOVE L0182-CVG-ACUM-VALU-AMT (WS-COV-NUM)
020874                     TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-POL-CSV-AMT-T (I)
008455                                TO L0290-MAX-OUT-LEN
008455             SET L0290-SIGN-DISPLAY  TO TRUE
008455             SET L0290-SIGN-POS-DISPLAY
008455                                TO TRUE
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM  0290-2000-FORMAT-FOR-MIR
020874                 THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-POL-CSV-AMT-T (I)
008455                                        WS-H-AFVAL (I)
008455
               END-IF
           END-IF.


      * SET UP THE NUMBER OF UNITS AVAILABLE FROM THE FUND

           IF WS-BUS-FCN-SURR-FND-BY-UNIT
               MOVE L0182-EQTY-UNIT-QTY (WS-COV-NUM)
005193*                               TO WS-EDIT-8V5S
005193                                TO WS-EDIT-12V5S
005193*        MOVE WS-EDIT-8V5S      TO MIR-CF-UNIT-QTY-T (I)
005193*        MOVE WS-EDIT-8V5S      TO WS-H-UFVAL (I)
005193         MOVE WS-EDIT-12V5S     TO MIR-CF-UNIT-QTY-T (I)
005193         MOVE WS-EDIT-12V5S     TO WS-H-UFVAL (I)
           END-IF.

       4370-INIT-F-MAP-PASS-2-X.
           EXIT.

      *---------------------
       4500-CHK-VER-PROCESS.
      *---------------------

           IF W0761-VER-CONTINUE
               PERFORM  4200-WRITE-TSQ
                   THRU 4200-WRITE-TSQ-X
           END-IF.

557660     IF  WS-BUS-FCN-SURR-FND-BY-FND
           AND W0761-VER-CONTINUE
           AND WGLOB-GOOD-RETURN
               EVALUATE TRUE
                   WHEN  WS-BUS-FCN-SURR-FND-BY-AMT
                       PERFORM  6600-MOVE-F-BY-A-CARDS
                           THRU 6600-MOVE-F-BY-A-CARDS-X
                           VARYING WS-LINE FROM 1 BY 1
                           UNTIL WS-LINE > WS-MAX-FUND-LINES

                   WHEN WS-BUS-FCN-SURR-FND-BY-UNIT
                       PERFORM  6700-MOVE-F-BY-U-CARDS
                           THRU 6700-MOVE-F-BY-U-CARDS-X
                           VARYING WS-LINE FROM 1 BY 1
                           UNTIL WS-LINE > WS-MAX-FUND-LINES
               END-EVALUATE
           END-IF.

           PERFORM  8300-FINALIZE-MAP
               THRU 8300-FINALIZE-MAP-X.

       4500-CHK-VER-PROCESS-X.
           EXIT.

012143*----------------------
012143 4600-CREATE-SURR-CDSA.
012143*----------------------
012143*
012143* CALL CSLU2600 TO WRITE CDSA FOR THE WITHDRAWAL
012143*
012143     PERFORM 2600-1000-BUILD-PARM-INFO
012143        THRU 2600-1000-BUILD-PARM-INFO-X.
012143
012143     MOVE RPOL-POL-ID           TO L2600-POL-ID.
023437*    SET  L2600-CDA-TYP-WITHDRAWAL TO TRUE.
023437     SET  L2600-CDA-TYP-WTHDR   TO TRUE.
016812*    MOVE E0761-CF-DT           TO L2600-CDA-EFF-DT.
016812     IF  WS-BUS-FCN-GIA-SURR
016812         MOVE E0761-GIA-SUR-DT      TO L2600-CDA-EFF-DT
016812     ELSE
016812         MOVE E0761-CF-DT           TO L2600-CDA-EFF-DT
012143     END-IF.
012143     SET  L2600-CDA-STAT-ACTIVE    TO TRUE.
023112*    SET  L2600-CDA-CREAT-BY-SYSTEM
023112*                               TO TRUE.
012143     MOVE E0761-AMOUNT          TO L2600-CDA-TOT-TRXN-AMT.
012143     IF  E0761-REASON = 'NET'
012143         SET L2600-WTHDR-CHRG-INCL-NET
012143                                TO TRUE
012143     ELSE
012143         SET L2600-WTHDR-CHRG-INCL-GRS
012143                                TO TRUE
012143     END-IF.
012143
012143     IF  WS-SURR-CHRG-OVRIDDEN
012143         SET L2600-WTHDR-OVRID-YES TO TRUE
012143     END-IF.
012143
012143     PERFORM 2600-1000-WRITE-CDSA
012143        THRU 2600-1000-WRITE-CDSA-X.
012143
012143 4600-CREATE-SURR-CDSA-X.
012143     EXIT.
012143
012143*----------------------
012143 4650-UPDATE-SURR-CDSA.
012143*----------------------
012143*
023437*    IF  WS-POL-TOT-SURR-AMT = ZERO
023437*        GO TO 4650-UPDATE-SURR-CDSA-X
023437*    END-IF.
023437*
023437     IF  E0761-UNIT-SURRENDER
023437     OR  E0761-FULL-GIA-SURRENDER
023437         COMPUTE L2600-CDA-TOT-TRXN-AMT = L1010-GRS-SURR-TOTAL
023437                                        * -1
023437     ELSE
023437         IF  WS-POL-TOT-SURR-AMT = ZERO
023437             GO TO 4650-UPDATE-SURR-CDSA-X
023437         END-IF
023437     END-IF.
023437
012143* CALL CSLU2600 TO UPDATE CDSA FOR THE WITHDRAWAL
012143*
012143     IF  NOT WS-BUS-FCN-SURR-FND-BY-FND
012143         MOVE WS-DBSC-TOT-SURR-AMT
012143                                TO WS-DBSC-ASS-SURR-AMT
018846*        MOVE WS-DBSC-TOT-CHRG-AMT
018846*                               TO WS-DBSC-ASS-CHRG-AMT
012143     END-IF.
012143
018846     MOVE WS-DBSC-TOT-CHRG-AMT  TO WS-DBSC-ASS-CHRG-AMT.
018846*    MOVE WS-DBSC-ASS-SURR-AMT  TO L2600-CDA-TOT-TRXN-AMT.
012143     MOVE WS-DBSC-ASS-CHRG-AMT  TO L2600-CDA-TOT-DWCHRG-AMT.
012143
012143     PERFORM 2600-6000-UPDATE-CDSA
012143        THRU 2600-6000-UPDATE-CDSA-X.
012143
012143     IF  WS-DBSC-APPLICABLE
012143     AND WS-DBSC-ASS-FREE-AMT > ZERO
012143         MOVE WS-HOLD-FREE-WTHDR-TOT-AMT
012143                                TO RPOL-FREE-WTHDR-TOT-AMT
012143         ADD  WS-DBSC-ASS-FREE-AMT TO RPOL-FREE-WTHDR-TOT-AMT
012143         MOVE WS-HOLD-FREE-WTHDR-QTY
012143                                TO RPOL-FREE-WTHDR-QTY
012143         IF  RPOL-FREE-WTHDR-QTY NOT = 99
012143             SUBTRACT +1         FROM RPOL-FREE-WTHDR-QTY
012143         END-IF
012143     END-IF.
012143
012143 4650-UPDATE-SURR-CDSA-X.
012143     EXIT.
012143
012143*----------------------
012143 4670-CREATE-SURR-CDSD.
012143*----------------------
012143*
012143* CALL CSLU2600 TO WRITE CDSD FOR THE WITHDRAWAL
012143*
023437     IF  E0761-UNIT-SURRENDER
023437     OR  E0761-FULL-GIA-SURRENDER
023437         COMPUTE L2600-CDAD-TRXN-AMT = L1010-GRS-SURR-TOTAL
023437                                     * -1
023437     ELSE
023437         COMPUTE L2600-CDAD-TRXN-AMT = L1010-AMOUNT
023437                                     * -1
023437     END-IF.
023437*    MOVE L1010-AMOUNT          TO L2600-CDAD-TRXN-AMT.
012143     MOVE L1010-CVG             TO L2600-CVG-NUM-N.
012143     MOVE RCFLW-CF-SEQ-NUM-N    TO L2600-CDAD-CF-FA-SEQ-NUM.
020475     MOVE RCFLW-CF-FND-TRXN-AMT TO WS-CVG-TRXN-AMT.
012143     PERFORM 2600-2000-WRITE-CDSD
012143        THRU 2600-2000-WRITE-CDSD-X.
012143
012143 4670-CREATE-SURR-CDSD-X.
012143     EXIT.
012143
031034*----------------------------
031034*4675-WRITE-PGAL-REC.
031034*4675-DISB-SURR-AMT.
031034*----------------------------
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE MIR-POL-ID              TO L7800-POL-ID.
031034*    MOVE L1010-EFF-DT            TO L7800-EFF-DT.
031034*    MOVE E0761-CF-DT             TO L7800-EFF-DT.
031034*    MOVE WS-CDA-TYP-CD           TO L7800-CDA-TYP-CD.
031034*    IF  E0761-UNIT-SURRENDER
031034*    OR  E0761-FULL-GIA-SURRENDER
031034*        MOVE L1010-GRS-SURR-TOTAL TO L2600-CDAD-TRXN-AMT
031034*    ELSE
031034*        MOVE L1010-AMOUNT         TO L2600-CDAD-TRXN-AMT
031034*    END-IF.
031034*    MOVE WS-POL-PAYO-NUM         TO L7800-POL-PAYO-NUM.
031034*    MOVE WS-CDA-EFF-IDT-NUM      TO L7800-CDA-EFF-IDT-NUM.
031034*    MOVE WS-CDA-SEQ-NUM          TO L7800-CDA-SEQ-NUM.
031034*    MOVE L0182-CV-TAX            TO L7800-CV-TAX.
023437*    COMPUTE L7800-SURR-CHRG-AMT = (RCFLW-CF-SURR-CHRG-AMT
023437*                                  - RCFLW-CF-MKTVAL-ADJ-AMT).
023437*    COMPUTE L7800-TOT-SURR-AMT = RCFLW-CF-CLI-TRXN-AMT * -1.
031034*    MOVE WS-TOT-POL-CF-CLI-AMT   TO L7800-TOT-SURR-AMT.
031034*    MOVE WS-PGAL-TRXN-FEE-AMT    TO L7800-SURR-CHRG-AMT.
031034*    SET L7800-CALC-CV-NOT-REQ    TO TRUE
031034*    SET L7800-ORIGIN-POL-ENTRY   TO TRUE.
031034*    SET L7800-TRXN-WTHDR         TO TRUE.
031034*    SET L7800-PRCES-NORMAL       TO TRUE.
031034*
031034*    PERFORM  7700-HOLD-TO-L7800
031034*        THRU 7700-HOLD-TO-L7800-X.
031034*
031034*    PERFORM  7800-3000-DISB-TRXN-AMT
031034*        THRU 7800-3000-DISB-TRXN-AMT-X.
031034*
031034*    PERFORM  7500-L7800-TO-LPGAL
031034*        THRU 7500-L7800-TO-LPGAL-X.
031034*    PERFORM  7600-L7800-TO-HOLD
031034*        THRU 7600-L7800-TO-HOLD-X.
031034*
031034*    IF NOT L7800-RETRN-OK
031034*       SET WGLOB-RETURN-ERROR       TO TRUE
023437*       GO TO 4675-WRITE-PGAL-REC-X
031034*    END-IF.
031034*
023437*    PERFORM  7800-4000-PGAL-PRCES
023437*        THRU 7800-4000-PGAL-PRCES-X.
023437*
023437*    IF NOT L7800-RETRN-OK
023437*       SET WGLOB-RETURN-ERROR       TO TRUE
023437*    END-IF.
031034*
031034*4675-WRITE-PGAL-REC-X.
031034*4675-DISB-SURR-AMT-X.
031034*    EXIT.
015290
012143*--------------------------
012143 4700-DPOS-BASED-SURR-CHRG.
012143*--------------------------
012143
018846*    MOVE E0761-AMOUNT          TO WS-DBSC-TOT-SURR-AMT.
018846     MOVE WS-POL-TOT-SURR-AMT   TO WS-DBSC-TOT-SURR-AMT.
012143     MOVE ZEROS                 TO WS-DBSC-TOT-CHRG-AMT.
012143     MOVE ZEROS                 TO WS-DBSC-TOT-FREE-AMT.
012143     MOVE ZEROS                 TO WS-DBSC-ASS-SURR-AMT.
012143     MOVE ZEROS                 TO WS-DBSC-ASS-CHRG-AMT.
012143     MOVE ZEROS                 TO WS-DBSC-ASS-FREE-AMT.
012143*
012143* CHECK IF DEPOSIT BASED SURRENDER CHARGES APPLY
012143*
012143     PERFORM 2760-1000-BUILD-PARM-INFO
012143        THRU 2760-1000-BUILD-PARM-INFO-X.
012143*
012143* READ PLAN CORRESPONDING TO COVERAGE 1
012143*
012143     MOVE 1                     TO I.
012143
012143     PERFORM PLIN-1000-PLAN-HEADER-IN
012143        THRU PLIN-1000-PLAN-HEADER-IN-X.
012143
012143     IF  NOT WPH-IO-OK
012143*        MSG: PLAN NOT FOUND
012143         MOVE 'CS07610052'      TO WGLOB-MSG-REF-INFO
012143         PERFORM 0260-1000-GENERATE-MESSAGE
012143            THRU 0260-1000-GENERATE-MESSAGE-X
012143         GO TO 4700-DPOS-BASED-SURR-CHRG-X
012143     END-IF.
012143
012143     IF  NOT RPH-PLAN-SURR-CHRG-DPOS-BASED
012143         SET WS-DBSC-APPLICABLE-NO TO TRUE
012143         GO TO 4700-DPOS-BASED-SURR-CHRG-X
012143     END-IF.
012143*
012143* CALL DEPOSIT BASED SURRENDER CHARGE CALCULATION ROUTINE
012143*
012143     SET  WS-DBSC-APPLICABLE       TO TRUE.
012143     MOVE RPOL-FREE-WTHDR-QTY   TO WS-HOLD-FREE-WTHDR-QTY.
012143     MOVE RPOL-FREE-WTHDR-TOT-AMT
                                      TO WS-HOLD-FREE-WTHDR-TOT-AMT.
012143
           IF  WS-PRCES-STATE-PRCES
012143     AND WGLOB-GOOD-RETURN
024787     AND WS-AUTO-REDO-DONE
012143         SET  L2760-PRCES-TYP-VER-ONLY
012143                                TO TRUE
012143         MOVE L2600-POL-PAYO-NUM TO L2760-POL-PAYO-NUM
012143         MOVE L2600-CDA-SEQ-NUM TO L2760-CDA-SEQ-NUM
012143     ELSE
012143         SET  L2760-PRCES-TYP-EDIT-ONLY
012143                                TO TRUE
012143     END-IF.
012143
012143     IF  E0761-REASON = 'NET'
012143         SET L2760-SURR-CHRG-TYP-PARTL-NET TO TRUE
012143     ELSE
012143         SET L2760-SURR-CHRG-TYP-PARTL-GRS TO TRUE
012143     END-IF.
012143
016812*    MOVE E0761-CF-DT           TO L2760-EFF-DT.
016812     IF  WS-BUS-FCN-GIA-SURR
016812         MOVE E0761-GIA-SUR-DT  TO L2760-EFF-DT
016812     ELSE
016812         MOVE E0761-CF-DT       TO L2760-EFF-DT
016812     END-IF.
016812
018846*    MOVE E0761-AMOUNT          TO L2760-SURR-AMT.
018846     MOVE WS-POL-TOT-SURR-AMT   TO L2760-SURR-AMT.
012143
012143* GET MAX FREE AMOUNT
016812*    MOVE E0761-CF-DT           TO L6860-EFF-DT.
016812     IF  WS-BUS-FCN-GIA-SURR
016812         MOVE E0761-GIA-SUR-DT  TO L6860-EFF-DT
016812     ELSE
016812         MOVE E0761-CF-DT       TO L6860-EFF-DT
016812     END-IF.
012143     PERFORM 6860-1000-CALC-MAX-FREE-PULL
012143        THRU 6860-1000-CALC-MAX-FREE-PULL-X.
012143     IF  NOT L6860-RETRN-OK
012143*        MSG: ERROR FOUND WHILE CALCULATING MAX FREE WITHDRAWAL
012143         MOVE 'CS07610053'      TO WGLOB-MSG-REF-INFO
012143         PERFORM 0260-1000-GENERATE-MESSAGE
012143            THRU 0260-1000-GENERATE-MESSAGE-X
012143         GO TO 4700-DPOS-BASED-SURR-CHRG-X
012143     END-IF.
012143
012143     MOVE L6860-MAX-FREE-WITHDRAWAL
012143                                TO L2760-MAX-FREE-AMT.
012143     PERFORM 2760-1000-CALC-SURR-CHRG
012143        THRU 2760-1000-CALC-SURR-CHRG-X.
012143
012143     IF  NOT L2760-RETRN-OK
012143         GO TO 4700-DPOS-BASED-SURR-CHRG-X
012143     END-IF.
012143
012143     MOVE L2760-SURR-CHRG-AMT   TO WS-DBSC-TOT-CHRG-AMT.
012143     IF  L2760-MAX-FREE-AMT > L2760-REM-FREE-AMT
012143         COMPUTE WS-DBSC-TOT-FREE-AMT
012143               = L2760-MAX-FREE-AMT
012143               - L2760-REM-FREE-AMT
012143     END-IF.
012143
012143 4700-DPOS-BASED-SURR-CHRG-X.
012143     EXIT.
      /
031034*----------------------------
031034*4800-GET-PGAL-INFO.
031034*----------------------------
031034*
031034*    PERFORM  0182-1000-BUILD-PARM-INFO
031034*        THRU 0182-1000-BUILD-PARM-INFO-X.
031034*    MOVE L1010-EFF-DT          TO L0182-EFF-DT.
031034*    SET L0182-SURR-CHRG-TYP-PARTL    TO TRUE.
031034*    PERFORM  0182-1000-CALC-CSV-POL
031034*        THRU 0182-1000-CALC-CSV-POL-X.
031034*
031034*    MOVE ZERO                  TO WS-SIDFND-EQTY-UNIT-QTY.
031034*    PERFORM
031034*        VARYING I FROM 1 BY 1
031034*        UNTIL I > RPOL-POL-CVG-REC-CTR-N
031034*
031034*        IF  WCVGS-PLAN-FND-TYP-SIDE (I)
031034*            ADD L0182-EQTY-UNIT-QTY (I)
031034*             TO WS-SIDFND-EQTY-UNIT-QTY
031034*        END-IF
031034*
031034*    END-PERFORM.
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE MIR-POL-ID              TO L7800-POL-ID.
031034*    MOVE L1010-EFF-DT            TO L7800-EFF-DT.
031034*    MOVE L0182-CV-TAX            TO L7800-CV-TAX.
031034*    SET L7800-TRXN-WTHDR         TO TRUE.
031034*    SET L7800-GET-PLAR-REQ       TO TRUE.
031034*    SET L7800-CALC-CV-NOT-REQ    TO TRUE.
031034*
031034*    PERFORM  7800-5000-PGAL-OPEN-BAL
031034*        THRU 7800-5000-PGAL-OPEN-BAL-X.
031034*
031034*    IF NOT L7800-RETRN-OK
031034*       SET WGLOB-RETURN-ERROR   TO TRUE
031034*       GO TO 4800-GET-PGAL-INFO-X
031034*    END-IF.
031034*
031034*    PERFORM  7500-L7800-TO-LPGAL
031034*        THRU 7500-L7800-TO-LPGAL-X.
031034*
031034*    PERFORM  7600-L7800-TO-HOLD
031034*        THRU 7600-L7800-TO-HOLD-X.
031034*
031034*4800-GET-PGAL-INFO-X.
031034*    EXIT.
031034*


      *--------------------------
       5000-BUILD-KEY-INPUT-AREA.
      *--------------------------

      * MOVE THE FIELDS FROM THE SCREEN TO A WORK AREA

           MOVE WS-HOLD-POLICY        TO E0761-POL-ID.
           MOVE MIR-CVG-NUM           TO E0761-CVG-NUM-R.
557660     IF  MIR-DV-CF-EFF-DT NOT = SPACES
               MOVE MIR-DV-CF-EFF-DT  TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               MOVE L1640-INTERNAL-DATE
                                      TO E0761-CF-DT
           ELSE
               MOVE WWKDT-ZERO-DT     TO E0761-CF-DT
           END-IF.
           MOVE E0761-CF-DT           TO WS-CF-REC-DATE.
           MOVE MIR-CF-SEQ-NUM        TO E0761-SEQ-NUM-R.

023118     IF MIR-DV-CF-REASN-CD = EBLCH-BLANK-FIELD-CHAR
023118        MOVE SPACES             TO MIR-DV-CF-REASN-CD
023118     END-IF.

           MOVE MIR-DV-CF-REASN-CD    TO E0761-REASON.
           MOVE MIR-DV-CF-CLI-TRXN-AMT TO E0761-AMOUNT-R.
008455     MOVE 'N'                   TO L0280-SIGN-IND
008455     MOVE 2                     TO L0280-PRECISION
008455     MOVE LENGTH OF MIR-DV-CF-CLI-TRXN-AMT
                                      TO L0280-INPUT-SIZE
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1
008455     MOVE MIR-DV-CF-CLI-TRXN-AMT   TO L0280-INPUT-DATA
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X
008455     IF  L0280-OK
008455         MOVE L0280-OUTPUT-DOLLAR
                                      TO E0761-AMOUNT
008455     END-IF

           MOVE MIR-DV-CF-UNIT-QTY    TO E0761-UNITS-R.
557660     IF  MIR-DV-SURR-EFF-DT NOT = SPACES
               MOVE MIR-DV-SURR-EFF-DT     TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               MOVE L1640-INTERNAL-DATE
                                      TO E0761-GIA-SUR-DT
           ELSE
               MOVE WWKDT-ZERO-DT     TO E0761-GIA-SUR-DT
           END-IF.
023437*    MOVE MIR-CF-FED-TAXWH-AMT  TO E0761-WITHHELD-R.
031034**   MOVE MIR-FED-TAXWH-RQST-AMT TO E0761-WITHHELD-R.
031034**   MOVE 'N'                   TO L0280-SIGN-IND
031034**   MOVE 2                     TO L0280-PRECISION
023437*    MOVE LENGTH OF MIR-CF-FED-TAXWH-AMT
023437*                               TO L0280-INPUT-SIZE
031034**   MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
031034**                              TO L0280-INPUT-SIZE
031034**   COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
031034**                          L0280-PRECISION - 1
023437*    MOVE MIR-CF-FED-TAXWH-AMT  TO L0280-INPUT-DATA
031034**   MOVE MIR-FED-TAXWH-RQST-AMT TO L0280-INPUT-DATA
031034**   PERFORM  0280-1000-NUMERIC-EDIT
031034**       THRU 0280-1000-NUMERIC-EDIT-X
031034**   IF  L0280-OK
031034**       MOVE L0280-OUTPUT-DOLLAR
031034**                              TO E0761-WITHHELD
031034**   END-IF
008455
013693*    MOVE MIR-CF-PROV-TAXWH-AMT TO E0761-PROV-WITHHELD-R.
013693*    MOVE 'N'                   TO L0280-SIGN-IND
013693*    MOVE 2                     TO L0280-PRECISION
013693*    MOVE LENGTH OF MIR-CF-PROV-TAXWH-AMT
013693*                               TO L0280-INPUT-SIZE
013693*    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
013693*                           L0280-PRECISION - 1
013693*    MOVE MIR-CF-PROV-TAXWH-AMT TO L0280-INPUT-DATA
013693*    PERFORM  0280-1000-NUMERIC-EDIT
013693*        THRU 0280-1000-NUMERIC-EDIT-X
013693*    IF  L0280-OK
013693*        MOVE L0280-OUTPUT-DOLLAR
013693*                               TO E0761-PROV-WITHHELD
013693*    END-IF.

031034**   MOVE MIR-LTAXWH-FLAT-AMT   TO E0761-CF-LTAXWH-AMT-R.
031034**   MOVE 'N'                   TO L0280-SIGN-IND.
031034**   MOVE 2                     TO L0280-PRECISION.
031034**   MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT TO L0280-INPUT-SIZE.
031034**   COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
031034**                        - L0280-PRECISION
031034**                        - 1.
031034**   MOVE MIR-LTAXWH-FLAT-AMT   TO L0280-INPUT-DATA.
031034**   PERFORM  0280-1000-NUMERIC-EDIT
031034**       THRU 0280-1000-NUMERIC-EDIT-X.
031034**   IF  L0280-OK
031034**       MOVE L0280-OUTPUT-DOLLAR
031034**                             TO E0761-CF-LTAXWH-AMT
031034**       MOVE L0280-OUTPUT-DOLLAR TO WS-LTAXWH-FLAT-AMT
031034**   END-IF.

031034**   MOVE MIR-LTAXWH-PCT            TO L0280-INPUT-DATA.
031034**   SET L0280-SIGN-NOT-PERMITTED TO TRUE.
031034**   MOVE 2                    TO L0280-PRECISION.
031034**   MOVE LENGTH OF MIR-LTAXWH-PCT TO L0280-INPUT-SIZE.
031034**   COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
031034**                        - L0280-PRECISION
031034**                        - 1.
031034**   PERFORM  0280-1000-NUMERIC-EDIT
031034**       THRU 0280-1000-NUMERIC-EDIT-X.

031034**   IF  L0280-OK
031034**       MOVE L0280-OUTPUT-DOLLAR  TO E0761-LTAXWH-PCT
031034**       MOVE L0280-OUTPUT-DOLLAR  TO WS-LTAXWH-PCT
031034**   END-IF.

031034**   MOVE  MIR-LTAXWH-CALC-CD      TO E0761-LTAXWH-CALC-CD.
029060*    MOVE  MIR-LTAXWH-CALC-CD      TO WS-LTAXWH-CALC-CD.
029060     MOVE  MIR-LTAXWH-RQST-CD      TO WS-LTAXWH-CALC-CD.

008455
023437*    IF  MIR-DV-TAX-OVRID-IND = SPACES
023437*        MOVE 'N'               TO MIR-DV-TAX-OVRID-IND
023437*    END-IF.
023437*
023437*    MOVE MIR-DV-TAX-OVRID-IND  TO E0761-OVERRIDE.

           IF  MIR-DV-REDC-FACE-IND = SPACES
               MOVE 'N'               TO MIR-DV-REDC-FACE-IND
           END-IF.

           MOVE MIR-DV-REDC-FACE-IND  TO E0761-AFR-THRSHD-IND.
           MOVE MIR-CF-INT-PCT        TO E0761-INT-RATE.
           MOVE MIR-CF-SURR-CHRG-AMT  TO E0761-SUR-CHARGE.
           MOVE MIR-CF-MKTVAL-ADJ-AMT TO E0761-MV-ADJ.

           IF  (WS-BUS-FCN-SURR-NON-SPEC
               AND WS-HOLD-UNITS NOT = ZEROS)
           OR WS-BUS-FCN-SURR-FND-BY-UNIT
               SET WS-UNITS-ENTERED TO TRUE
               MOVE WS-HOLD-UNITS     TO WS-HOLD-AMOUNT
               MOVE ZEROS             TO WS-HOLD-UNITS
           ELSE
               SET WS-UNITS-NOT-ENTERED TO TRUE
           END-IF.

      * SET UP THE TRANSACTION TYPE ACCORDING TO THE SCREEN ENTER CODE

           EVALUATE TRUE

               WHEN (WS-BUS-FCN-SURR-NON-SPEC
                 AND WS-UNITS-ENTERED)
                    SET E0761-UNIT-SURRENDER     TO TRUE

               WHEN (WS-BUS-FCN-SURR-NON-SPEC
                  OR WS-BUS-FCN-SURR-FND-BY-AMT)
                    SET E0761-AMOUNT-SURRENDER    TO TRUE

               WHEN WS-BUS-FCN-FULL-GIA-SURR
                    SET E0761-FULL-GIA-SURRENDER  TO TRUE

               WHEN WS-BUS-FCN-PARTL-GIA-SURR
                    SET E0761-PARTL-GIA-SURRENDER TO TRUE

               WHEN WS-BUS-FCN-SURR-FND-BY-UNIT
                    SET E0761-UNIT-SURRENDER      TO TRUE

               WHEN WS-BUS-FCN-REVRS
                    SET E0761-SURRENDER-REVERSAL  TO TRUE

               WHEN OTHER
                    SET E0761-INQUIRE-TRANS       TO TRUE

           END-EVALUATE.

      *
       5000-BUILD-KEY-INPUT-AREA-X.
           EXIT.

      *------------------------
       6000-FUND-BY-FUND-TRANS.
      *------------------------

      * FOR A FUND BY FUND SURRENDER TRANSACTION, DETERMINE THE LAST
      * FUND COVERAGE FROM WHICH A SURRENDER AMOUNT IS REQUESTED,
      * FROM THE ARRAY OF FUND COVERAGES.  THIS INFORMATION WILL BE
      * PASSED TO CSLF1010 TO DO THE FINAL EDITS FOR PROCESSING WHEN
      * THE ENTIRE TRANSACTION HAS PROCESSED.

           MOVE ZERO                  TO W0761-FRST-FND-CVG.
           MOVE ZERO                  TO W0761-LST-FND-CVG.
           MOVE ZERO                  TO WS-TOTAL-AMOUNT.
023437*    MOVE ZERO                  TO WS-TOTAL-WITHHELD.
031034**   MOVE ZERO                  TO WS-TOTAL-LOC-AMT.
023437*    MOVE ZERO                  TO WS-TOTAL-CF-LTAXWH-AMT.
           PERFORM  6100-PRCES-SCRN-LVL-EDIT
               THRU 6100-PRCES-SCRN-LVL-EDIT-X
               VARYING WS-LINE FROM 1 BY 1
               UNTIL   WS-LINE > WS-MAX-FUND-LINES.

011099     IF  WS-HOLD-AMOUNT NOT = WS-TOTAL-AMOUNT
023437*    OR  (WS-HOLD-WITHHELD NOT = WS-TOTAL-WITHHELD
023437*    AND  WS-HOLD-WITHHELD NOT = ZERO)
011099         MOVE 'CS07610019'      TO WGLOB-MSG-REF-INFO
011099         PERFORM  0260-1000-GENERATE-MESSAGE
011099             THRU 0260-1000-GENERATE-MESSAGE-X
011099     END-IF.
023437*    MOVE ZERO                   TO WS-TOTAL-WITHHELD.
013693
023437*    IF  WS-HOLD-CF-LTAXWH-AMT = WS-TOTAL-CF-LTAXWH-AMT
023437*        CONTINUE
023437*    ELSE
013693*MSG: LOCATION TAX WITHHOLD AMOUNT DO NOT ADD TO ENTRY ENTRY
023437*        MOVE 'CS07610022'           TO WGLOB-MSG-REF-INFO
023437*        PERFORM  0260-1000-GENERATE-MESSAGE
023437*            THRU 0260-1000-GENERATE-MESSAGE-X
023437*    END-IF.
023437*
023437*    MOVE ZERO                   TO WS-TOTAL-CF-LTAXWH-AMT.
023437*
           IF WGLOB-MSG-ERROR-SW > 0
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

      * PROCESS EACH FUND SURRENDER TRANSACTION SEPARATELY

           IF WGLOB-GOOD-RETURN
               PERFORM  6200-PRCES-FND-BY-FND-TRANS
                   THRU 6200-PRCES-FND-BY-FND-TRANS-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL   WS-LINE > WS-MAX-FUND-LINES
011099     ELSE
011099         GO TO 6000-FUND-BY-FUND-TRANS-X
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-TOTAL-WITHHELD * 100.
023437*    MOVE WS-TOTAL-WITHHELD     TO L0290-INPUT-V02.
023437*    MOVE 2                     TO L0290-PRECISION.
023437*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
023437*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023437*    PERFORM  0290-2000-FORMAT-FOR-MIR
023437*        THRU 0290-2000-FORMAT-FOR-MIR-X.
023437*    MOVE L0290-OUTPUT-DATA     TO MIR-CDA-FED-TAXWH-AMT.
023437*
023437*    IF  WS-HOLD-WITHHELD = ZERO
023437*        MOVE WS-TOTAL-WITHHELD TO WS-HOLD-WITHHELD
023437*    END-IF.

      * IF THE RESULTING AMOUNTS ARE UNEQUAL TO THE REQUESTED AMOUNTS,
      * OR THE RESULTING SURRENDER AMOUNT IS ZERO, THAT IS AN ERROR.

           IF  WS-HOLD-AMOUNT     = WS-TOTAL-AMOUNT
023437*    AND WS-HOLD-WITHHELD   = WS-TOTAL-WITHHELD
               IF WS-TOTAL-AMOUNT = ZERO
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           ELSE
               MOVE 'CS07610019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > 0
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-TOTAL-CF-LTAXWH-AMT * 100.
023437*    MOVE WS-TOTAL-CF-LTAXWH-AMT TO L0290-INPUT-V02.
023437*    MOVE 2                      TO L0290-PRECISION.
023437*    MOVE LENGTH OF MIR-CF-LTAXWH-AMT
023437*                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023437*    PERFORM  0290-2000-FORMAT-FOR-MIR
023437*        THRU 0290-2000-FORMAT-FOR-MIR-X.
023437*    MOVE L0290-OUTPUT-DATA      TO MIR-CF-LTAXWH-AMT.
013693
023437*    IF  WS-HOLD-CF-LTAXWH-AMT = ZERO
023437*        MOVE WS-TOTAL-CF-LTAXWH-AMT TO WS-HOLD-CF-LTAXWH-AMT
023437*    END-IF.
023437*
023437*    IF  WS-TOTAL-CF-LTAXWH-AMT = ZERO
023437*        MOVE WS-HOLD-CF-LTAXWH-AMT TO WS-TOTAL-CF-LTAXWH-AMT
023437*    END-IF.

013693*
013693*   IF THE RESULTING AMOUNTS ARE UNEQUAL TO THE REQUESTED AMOUNTS
013693*

023437*    IF  WS-HOLD-CF-LTAXWH-AMT = WS-TOTAL-CF-LTAXWH-AMT
023437*        CONTINUE
023437*    ELSE
013693*MSG: LOCATION TAX WITHHOLD AMOUNT DO NOT ADD TO ENTRY ENTRY
023437*        MOVE 'CS07610022'           TO WGLOB-MSG-REF-INFO
023437*        PERFORM  0260-1000-GENERATE-MESSAGE
023437*            THRU 0260-1000-GENERATE-MESSAGE-X
023437*    END-IF.

013693     IF WGLOB-MSG-ERROR-SW > 0
013693         SET WGLOB-RETURN-ERROR  TO TRUE
013693     END-IF.

       6000-FUND-BY-FUND-TRANS-X.
           EXIT.
      *
      *-------------------------
       6100-PRCES-SCRN-LVL-EDIT.
      *-------------------------

           IF WS-BUS-FCN-SURR-FND-BY-AMT
557660         IF WS-H-ACOV (WS-LINE) = '00'
               OR WS-H-ACOV (WS-LINE) = SPACES
                   GO TO 6100-PRCES-SCRN-LVL-EDIT-X
               END-IF
           END-IF.

           IF WS-BUS-FCN-SURR-FND-BY-UNIT
557660         IF WS-H-UCOV (WS-LINE) = '00'
               OR WS-H-UCOV (WS-LINE) = SPACES
                   GO TO 6100-PRCES-SCRN-LVL-EDIT-X
               END-IF
           END-IF.

      * EDIT INPUT FOR TRANSACTIONS 'ASR' AND 'USR'

           MOVE WS-CFLW-REC-INFO (WS-LINE)
                                      TO RCFLW-REC-INFO.
           MOVE WS-CFCO-REC-AREA (WS-LINE)
                                      TO WCFCS-WORK-AREA.

           PERFORM  6300-EDIT-FUND-INPUT
               THRU 6300-EDIT-FUND-INPUT-X.

           IF WS-BUS-FCN-SURR-FND-BY-AMT
               PERFORM  6600-MOVE-F-BY-A-CARDS
                   THRU 6600-MOVE-F-BY-A-CARDS-X
           ELSE
               PERFORM  6700-MOVE-F-BY-U-CARDS
                   THRU 6700-MOVE-F-BY-U-CARDS-X
           END-IF.

           IF WS-BUS-FCN-SURR-FND-BY-AMT
               IF E0761-AMOUNT = W0761-CONST-AMT
                   GO TO 6100-PRCES-SCRN-LVL-EDIT-X
               END-IF
               IF W0761-FRST-FND-CVG = ZERO
                   MOVE WS-LINE       TO W0761-FRST-FND-CVG
               END-IF
               MOVE WS-LINE           TO W0761-LST-FND-CVG
           END-IF.

           IF WS-BUS-FCN-SURR-FND-BY-UNIT
               IF E0761-UNITS = W0761-CONST-UNT
                   GO TO 6100-PRCES-SCRN-LVL-EDIT-X
               END-IF
               IF W0761-FRST-FND-CVG = ZERO
                   MOVE WS-LINE       TO W0761-FRST-FND-CVG
               END-IF
               MOVE WS-LINE           TO W0761-LST-FND-CVG
           END-IF.

       6100-PRCES-SCRN-LVL-EDIT-X.
           EXIT.
      *
      *----------------------------
       6200-PRCES-FND-BY-FND-TRANS.
      *----------------------------

      * BUILD THE ASUR INPUT FOR A FUND BY FUND TRANSACTION
      * IF THERE IS NO COVERAGE ON THIS LINE, EXIT.

           SET WS-FUND-PRCES       TO TRUE.
           IF  WS-BUS-FCN-SURR-FND-BY-AMT
               IF  WS-H-ACOV (WS-LINE) = '00'
               OR  WS-H-ACOV (WS-LINE) = SPACES
                   GO TO 6200-PRCES-FND-BY-FND-TRANS-X
               END-IF
           END-IF.

           IF  WS-BUS-FCN-SURR-FND-BY-UNIT
               IF  WS-H-UCOV (WS-LINE) = '00'
               OR  WS-H-UCOV (WS-LINE) = SPACES
                   GO TO 6200-PRCES-FND-BY-FND-TRANS-X
               END-IF
           END-IF.

           MOVE WS-CFLW-REC-INFO (WS-LINE)
                                      TO RCFLW-REC-INFO.
           MOVE WS-CFCO-REC-AREA (WS-LINE)
                                      TO WCFCS-WORK-AREA.

           IF WS-BUS-FCN-SURR-FND-BY-AMT
               MOVE WS-H-ACOV  (WS-LINE)
                                      TO E0761-CVG-NUM
               MOVE WS-H-AMNT  (WS-LINE)
                                      TO E0761-AMOUNT-R
012034         MOVE E0761-AMOUNT-R    TO L0280-INPUT-DATA
012034         MOVE 2                 TO L0280-PRECISION
012034         MOVE LENGTH OF E0761-AMOUNT-R
012034                                TO L0280-INPUT-SIZE
012034         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
012034                                L0280-PRECISION - 1
012034         PERFORM  0280-1000-NUMERIC-EDIT
012034             THRU 0280-1000-NUMERIC-EDIT-X
012034         MOVE L0280-OUTPUT-DOLLAR
                                      TO E0761-AMOUNT
023437*        MOVE WS-H-ATAXW (WS-LINE)
023437*                               TO E0761-WITHHELD-R
031034*        MOVE E0761-WITHHELD-R  TO L0280-INPUT-DATA
029060*        MOVE MIR-CDA-FED-TAXWH-AMT TO L0280-INPUT-DATA
029060*        MOVE 2                 TO L0280-PRECISION
031034**       MOVE LENGTH OF E0761-WITHHELD-R
029060*        MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                               TO L0280-INPUT-SIZE
029060*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
029060*                               L0280-PRECISION - 1
029060*        PERFORM  0280-1000-NUMERIC-EDIT
029060*            THRU 0280-1000-NUMERIC-EDIT-X
029060*        MOVE L0280-OUTPUT-DOLLAR
031034**                              TO E0761-WITHHELD
029060*                               TO LTAXC-FED-TAXWH-RQST-AMT
023437*        MOVE MIR-CF-LTAXWH-AMT-T (WS-LINE)
023437*                               TO E0761-CF-LTAXWH-AMT-R
023437*        MOVE E0761-CF-LTAXWH-AMT-R
023437*                               TO L0280-INPUT-DATA
023437*        MOVE 2                 TO L0280-PRECISION
023437*        MOVE LENGTH OF E0761-CF-LTAXWH-AMT-R
023437*                               TO L0280-INPUT-SIZE
023437*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
023437*                             - L0280-PRECISION
023437*                             - 1
023437*        PERFORM  0280-1000-NUMERIC-EDIT
023437*            THRU 0280-1000-NUMERIC-EDIT-X
023437*        MOVE L0280-OUTPUT-DOLLAR
023437*                               TO E0761-CF-LTAXWH-AMT
008455*        MOVE WS-H-ACHRG (WS-LINE) TO E0761-SUR-CHRG-AMT
008455*        MOVE W0761-CONST-SIGN     TO E0761-SUR-CHRG-SIGN
008455         MOVE WS-H-ACHRG (WS-LINE)
                                      TO E0761-SUR-CHRG-AMT
023437*        MOVE WS-H-ATAXO (WS-LINE)
023437*                               TO E0761-OVERRIDE
           ELSE
               MOVE WS-H-UCOV  (WS-LINE)
                                      TO E0761-CVG-NUM
               MOVE WS-H-UNIT  (WS-LINE)
                                      TO E0761-UNITS-R
023437*        MOVE WS-H-UTAXW (WS-LINE)
023437*                               TO E0761-WITHHELD-R
031034**       MOVE E0761-WITHHELD-R  TO L0280-INPUT-DATA
029060*        MOVE MIR-CDA-FED-TAXWH-AMT TO L0280-INPUT-DATA
029060*        MOVE 2                 TO L0280-PRECISION
031034**       MOVE LENGTH OF E0761-WITHHELD-R
029060*        MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                               TO L0280-INPUT-SIZE
029060*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
029060*                               L0280-PRECISION - 1
029060*        PERFORM  0280-1000-NUMERIC-EDIT
029060*            THRU 0280-1000-NUMERIC-EDIT-X
029060*        MOVE L0280-OUTPUT-DOLLAR
031034**                              TO E0761-WITHHELD
029060*                               TO LTAXC-FED-TAXWH-RQST-AMT
023437*        MOVE MIR-CF-LTAXWH-AMT-T (WS-LINE)
023437*                               TO E0761-CF-LTAXWH-AMT-R
023437*        MOVE E0761-CF-LTAXWH-AMT-R
023437*                               TO L0280-INPUT-DATA
023437*        MOVE 2                 TO L0280-PRECISION
023437*        MOVE LENGTH OF E0761-CF-LTAXWH-AMT-R
023437*                               TO L0280-INPUT-SIZE
023437*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
023437*                             - L0280-PRECISION
023437*                             - 1
023437*        PERFORM  0280-1000-NUMERIC-EDIT
023437*            THRU 0280-1000-NUMERIC-EDIT-X
023437*        MOVE L0280-OUTPUT-DOLLAR
023437*                               TO E0761-CF-LTAXWH-AMT
008455         MOVE WS-H-UCHRG (WS-LINE)
                                      TO E0761-SUR-CHRG-AMT
023437*        MOVE WS-H-UTAXO (WS-LINE)
023437*                               TO E0761-OVERRIDE
           END-IF.
      *
      * EXIT ROUTINE IF WITHDRAWAL AMOUNT FROM COVERAGE IS NOT
      * REQUESTED
      *
           IF (WS-BUS-FCN-SURR-FND-BY-AMT
               AND E0761-AMOUNT = W0761-CONST-AMT)
           OR (WS-BUS-FCN-SURR-FND-BY-UNIT
               AND E0761-UNITS = W0761-CONST-UNT)
                   SET WS-NO-FUND-PRCES    TO TRUE
           ELSE
               PERFORM  8100-INIT-PARM-AREA
                   THRU 8100-INIT-PARM-AREA-X
               PERFORM  7000-FINALIZE-SURR-TRANS
                   THRU 7000-FINALIZE-SURR-TRANS-X
           END-IF.

016503     IF  WS-REDO-NOT-OK
016503         MOVE WS-MAX-FUND-LINES   TO WS-LINE
016503         GO TO 6200-PRCES-FND-BY-FND-TRANS-X
016503     END-IF.


      * IF NO ERRORS ARE ENCOUNTERED UPTO THIS POINT CONTINUE
      * PROCESSING
      * SET UP THE TEXT FOR THIS LINE ON THE SCREEN - IT MAY BE
      * VERIFY, PROCESSED OR ERROR

           EVALUATE TRUE

               WHEN WS-NO-FUND-PRCES
                    SET WS-HOLD-ERR-NONE   TO TRUE

               WHEN (WS-PRCES-STATE-EDIT AND L1010-RETRN-OK) OR
                    (WS-PRCES-STATE-CHNG)
                    SET WS-HOLD-VERIFY     TO TRUE

               WHEN L1010-RETRN-OK
                    SET WS-HOLD-PRCES      TO TRUE
012588              SET WS-UPDT-CVGS-REQUIRED  TO TRUE
               WHEN OTHER
                    SET WS-HOLD-ERROR      TO TRUE

           END-EVALUATE.

      * NOW MOVE THE TEXT TO THE SCREEN

           IF WS-BUS-FCN-SURR-FND-BY-AMT
               MOVE WS-HOLD-ERR       TO MIR-DV-DISPLAY-CD-T (WS-LINE)
           ELSE
               MOVE WS-HOLD-ERR       TO MIR-DV-DISPLAY-CD-T (WS-LINE)
           END-IF.

021311*    IF  RCFLW-CF-SURR-CHRG-AMT NUMERIC
021311*        IF RCFLW-CF-SURR-CHRG-AMT = ZEROES
021311*            COMPUTE RCFLW-CF-SURR-CHRG-AMT =
021311*                WS-SURR-AMT (WS-LINE) / 100
021311*        END-IF
021311*    END-IF.
021311
021311     EVALUATE TRUE
021311
021311         WHEN WS-PRCES-STATE-CHNG
021311
021311            IF  RCFLW-CF-SURR-CHRG-AMT NUMERIC
021311                IF RCFLW-CF-SURR-CHRG-AMT = ZEROES
021311                   COMPUTE RCFLW-CF-SURR-CHRG-AMT =
021311                    WS-SURR-AMT (WS-LINE) / 100
021311                END-IF
021311            END-IF
021311
021311     END-EVALUATE.


           MOVE RCFLW-REC-INFO        TO WS-CFLW-REC-INFO (WS-LINE).
           MOVE WCFCS-WORK-AREA       TO WS-CFCO-REC-AREA (WS-LINE).

       6200-PRCES-FND-BY-FND-TRANS-X.
           EXIT.

      *---------------------
       6300-EDIT-FUND-INPUT.
      *---------------------
      *
      *  EDIT COVERAGE NUMBER
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           IF WS-BUS-FCN-SURR-FND-BY-AMT
               MOVE WS-H-ACOV (WS-LINE)
                                      TO L0280-INPUT-DATA
           ELSE
               MOVE WS-H-UCOV (WS-LINE)
                                      TO L0280-INPUT-DATA
           END-IF.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-OUTPUT-INX2
018846         MOVE L0280-OUTPUT      TO WS-CVG-NUM
           ELSE
               MOVE 'CS07610031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
           IF L0280-OK
               IF  WS-BUS-FCN-SURR-FND-BY-AMT
                   MOVE WS-OUTPUT-INX2 TO WS-H-ACOV (WS-LINE)
               ELSE
                   MOVE WS-OUTPUT-INX2 TO WS-H-UCOV (WS-LINE)
               END-IF

               IF WS-OUTPUT-INX2 > RPOL-POL-CVG-REC-CTR-N
                   MOVE 'CS00000021'  TO WGLOB-MSG-REF-INFO
031357             MOVE WS-OUTPUT-INX2 TO WGLOB-MSG-PARM (01)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
012034         END-IF
           END-IF.

      *
      *  EDIT SURRENDER AMOUNT (FOR SCREEN 'A')
      *
           IF WS-BUS-FCN-SURR-FND-BY-AMT
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
008455         MOVE LENGTH OF WS-H-AMNT (WS-LINE)
008455                                TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               MOVE WS-H-AMNT (WS-LINE)
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO E0761-AMOUNT
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF WS-H-AMNT (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM  0290-2000-FORMAT-FOR-MIR
020874                 THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO WS-H-AMNT (WS-LINE)
008455                                         E0761-AMOUNT-R
                   ADD L0280-OUTPUT-DOLLAR  TO WS-TOTAL-AMOUNT
               ELSE
                   MOVE 'CS07610037'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
      *  EDIT TAX WITHHELD FIELD
      *
023437*    MOVE 'N'                   TO L0280-SIGN-IND.
023437*    MOVE 2                     TO L0280-PRECISION.
023437*    IF WS-BUS-FCN-SURR-FND-BY-AMT
023437*        MOVE WS-H-ATAXW (WS-LINE)
023437*                               TO L0280-INPUT-DATA
023437*        MOVE LENGTH OF WS-H-ATAXW (WS-LINE)
023437*                               TO L0280-INPUT-SIZE
023437*    ELSE
023437*        MOVE WS-H-UTAXW (WS-LINE)
023437*                               TO L0280-INPUT-DATA
023437*        MOVE LENGTH OF WS-H-UTAXW (WS-LINE)
023437*                               TO L0280-INPUT-SIZE
023437*    END-IF.
023437*    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
023437*                           L0280-PRECISION - 1
023437*
023437*    PERFORM  0280-1000-NUMERIC-EDIT
023437*        THRU 0280-1000-NUMERIC-EDIT-X.
023437*    IF  L0280-OK
023437*        MOVE L0280-OUTPUT-DOLLAR
023437*                               TO E0761-WITHHELD
023437*        ADD E0761-WITHHELD     TO WS-TOTAL-WITHHELD
023437*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
023437*        MOVE 2                 TO L0290-PRECISION
023437*        MOVE LENGTH OF E0761-WITHHELD-R
023437*                               TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
023437*        PERFORM  0290-2000-FORMAT-FOR-MIR
023437*            THRU 0290-2000-FORMAT-FOR-MIR-X
023437*        MOVE L0290-OUTPUT-DATA TO E0761-WITHHELD-R
023437*    ELSE
023437*        MOVE 'CS07610038'      TO WGLOB-MSG-REF-INFO
023437*        PERFORM  0260-1000-GENERATE-MESSAGE
023437*            THRU 0260-1000-GENERATE-MESSAGE-X
023437*    END-IF.
023437*
023437*    IF L0280-OK
023437*       IF WS-BUS-FCN-SURR-FND-BY-AMT
023437*            MOVE E0761-WITHHELD-R
023437*                               TO WS-H-ATAXW (WS-LINE)
023437*        ELSE
023437*            MOVE E0761-WITHHELD-R
023437*                               TO WS-H-UTAXW (WS-LINE)
023437*        END-IF
023437*    END-IF.

013693*   EDIT LOCATION TAX WTIHHELD FIELD

023437*    MOVE 'N'                   TO L0280-SIGN-IND.
023437*    MOVE 2                     TO L0280-PRECISION.
023437*    MOVE MIR-CF-LTAXWH-AMT-T (WS-LINE)
023437*             TO  L0280-INPUT-DATA.
023437*    MOVE LENGTH OF MIR-CF-LTAXWH-AMT-T (WS-LINE)
023437*             TO L0280-INPUT-SIZE.
023437*    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
023437*                         - L0280-PRECISION
023437*                         - 1.
023437*    PERFORM  0280-1000-NUMERIC-EDIT
023437*        THRU 0280-1000-NUMERIC-EDIT-X.
023437*
023437*    IF  L0280-OK
023437*        MOVE L0280-OUTPUT-DOLLAR    TO E0761-CF-LTAXWH-AMT
023437*        ADD  E0761-CF-LTAXWH-AMT    TO WS-TOTAL-CF-LTAXWH-AMT
023437*        MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
023437*        MOVE 2                      TO L0290-PRECISION
023437*        MOVE LENGTH OF E0761-CF-LTAXWH-AMT-R
023437*                                    TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
023437*        PERFORM  0290-2000-FORMAT-FOR-MIR
023437*            THRU 0290-2000-FORMAT-FOR-MIR-X
023437*        MOVE L0290-OUTPUT-DATA      TO E0761-CF-LTAXWH-AMT-R
023437*        MOVE E0761-CF-LTAXWH-AMT-R
023437*                      TO MIR-CF-LTAXWH-AMT-T (WS-LINE)
023437*    ELSE
013693*MSG:  LOCATION TAX WITHHELD MUST BE NUMERIC
023437*        MOVE 'CS07610041'           TO WGLOB-MSG-REF-INFO
023437*        PERFORM  0260-1000-GENERATE-MESSAGE
023437*            THRU 0260-1000-GENERATE-MESSAGE-X
023437*    END-IF.
023437*
      *
      *
      *  EDIT THE NUMBER OF UNITS (FOR SCREEN 'U')
      *
           IF WS-BUS-FCN-SURR-FND-BY-UNIT
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 5                 TO L0280-PRECISION
005193*        MOVE 8                 TO L0280-LENGTH
005193*        MOVE 14                TO L0280-INPUT-SIZE
005193         MOVE 12                TO L0280-LENGTH
005193         MOVE 18                TO L0280-INPUT-SIZE
               MOVE WS-H-UNIT (WS-LINE)
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT-V05
                                      TO E0761-UNITS
                   ADD L0280-OUTPUT-V05           TO WS-TOTAL-AMOUNT
                   MOVE E0761-UNITS   TO WS-H-UNIT (WS-LINE)
               ELSE
                   MOVE 'CS07610039'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
      *  EDIT SURRENDER CHARGE ON VERIFY = 'CHG'
      *
           IF WS-BUS-FCN-SURR-FND-BY-AMT
               MOVE WS-H-ACHRG (WS-LINE)
                                      TO E0761-SUR-CHRG-AMT
           ELSE
               MOVE WS-H-UCHRG (WS-LINE)
                                      TO E0761-SUR-CHRG-AMT
           END-IF.

           IF NOT WS-PRCES-STATE-CHNG
           OR E0761-SUR-CHARGE = SPACES
               GO TO 6300-EDIT-FUND-INPUT-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455     MOVE LENGTH OF E0761-SUR-CHRG-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1
           MOVE E0761-SUR-CHRG-AMT    TO L0280-INPUT-DATA
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
017868         MOVE L0280-OUTPUT      TO WS-SURR-AMT(WS-LINE)

               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF WS-H-ACHRG (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
           ELSE
               MOVE 'CS07610040'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF L0280-OK
               IF WS-BUS-FCN-SURR-FND-BY-AMT
008455             MOVE L0290-OUTPUT-DATA
                                      TO WS-H-ACHRG (WS-LINE)
               ELSE
008455             MOVE L0290-OUTPUT-DATA
                                      TO WS-H-UCHRG (WS-LINE)
               END-IF
           END-IF.

       6300-EDIT-FUND-INPUT-X.
           EXIT.
      *
      *-----------------------
       6600-MOVE-F-BY-A-CARDS.
      *-----------------------
      *
           MOVE WS-H-ACOV (WS-LINE)  TO MIR-CVG-NUM-T (WS-LINE).
           MOVE WS-H-AMNT (WS-LINE)  TO MIR-CF-TOT-SURR-AMT-T (WS-LINE).
           MOVE WS-H-AFVAL (WS-LINE) TO MIR-DV-POL-CSV-AMT-T (WS-LINE).
023437*    MOVE WS-H-ATAXW (WS-LINE)
023437*                            TO MIR-CF-FED-TAXWH-AMT-T (WS-LINE).
023437*    MOVE WS-H-ATAXO (WS-LINE)
023437*                            TO MIR-DV-TAX-OVRID-IND-T (WS-LINE).


           IF WS-H-ACHRG (WS-LINE) NOT = SPACES
               MOVE WS-H-ACHRG (WS-LINE)
                                   TO MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
           END-IF.

       6600-MOVE-F-BY-A-CARDS-X.
           EXIT.
      *
      *-----------------------
       6700-MOVE-F-BY-U-CARDS.
      *-----------------------

           MOVE WS-H-UCOV (WS-LINE)   TO MIR-CVG-NUM-T (WS-LINE).
           MOVE WS-H-UNIT (WS-LINE)   TO MIR-DV-CF-UNIT-QTY-T (WS-LINE).
           MOVE WS-H-UFVAL (WS-LINE)  TO MIR-CF-UNIT-QTY-T (WS-LINE).
023437*    MOVE WS-H-UTAXW (WS-LINE)
023437*                            TO MIR-CF-FED-TAXWH-AMT-T (WS-LINE).
023437*    MOVE WS-H-UTAXO (WS-LINE)
023437*                            TO MIR-DV-TAX-OVRID-IND-T (WS-LINE).


           IF WS-H-UCHRG (WS-LINE) NOT = SPACES
               MOVE WS-H-UCHRG (WS-LINE)
                                     TO MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
           END-IF.

       6700-MOVE-F-BY-U-CARDS-X.
           EXIT.

023437*-------------------
023437 6800-TAX-PROCESSING.
023437*-------------------
023437*
023437* CALL CSLS0187 TO EDIT THE TAX INFORMATION AND DETERMINE THE
023437* TAX WITHHOLDING REQUIREMENTS
023437*
031034*    PERFORM  0187-1000-BUILD-PARM-INFO
031034*        THRU 0187-1000-BUILD-PARM-INFO-X.
031034*
031034* VERIFY AGE FOR PREMATURE DISTRIBUTION
031034*
031034*    IF  RPOL-POL-CTRY-US
031034*    AND NOT RPOL-POL-PNSN-QUALF-DEFR-PLAN
031034*        PERFORM  1146-1000-BUILD-PARM-INFO
031034*            THRU 1146-1000-BUILD-PARM-INFO-X
031034*        MOVE RPOL-POL-ID            TO L1146-POL-ID
031034*        MOVE E0761-CF-DT            TO L1146-EFF-DT
031034*        PERFORM  1146-1000-PREM-DISTRB-CALC
031034*            THRU 1146-1000-PREM-DISTRB-CALC-X
031034*        IF L1146-PREM-DISTRB
031034*            SET L0187-PREM-DISTRB   TO TRUE
031034*        END-IF
031034*    END-IF.
023437*
031034*    SET L0187-EVNT-PARTL-FND-WTHDR  TO TRUE.
031034*    SET L0187-PFW-REASN-SURRENDER   TO TRUE.
023437*
031034*    IF  E0761-REASON = 'NET'
031034*        SET L0187-REASON-NET        TO TRUE
031034*    ELSE
031034*        SET L0187-REASON-NET-NO     TO TRUE
031034*    END-IF.
023437*
031034*    IF WS-BUS-FCN-GIA-SURR
031034*        MOVE E0761-GIA-SUR-DT  TO L0187-EFF-DT
031034*    ELSE
031034*        MOVE E0761-CF-DT       TO L0187-EFF-DT
031034*    END-IF.
023437*
031034*    IF RPOL-POL-CTRY-CDN
031034*    AND (RPOL-POL-INS-TYP-SEG-FUND
031034*      OR RPOL-POL-INS-TYP-FPA)
031034*    AND NOT RPOL-POL-REG
031034*        MOVE WS-TOT-POL-CF-CLI-AMT  TO L0187-TRMN-AMT
031034*    ELSE
031034*        MOVE WS-TOT-POL-CLI-AMT     TO L0187-TRMN-AMT
031034*    END-IF.
023437*
031034*    MOVE WS-TOT-SIDFND-CLI-AMT      TO L0187-TRMN-SIDFND-AMT.
031034*    SET L0187-CSV-INFO-PROVIDED     TO TRUE.
023437
023437     MOVE ZERO                       TO WS-CFLW-ACUM-AMT.
023437     MOVE ZERO                       TO WS-SEG-FND-ACUM-AMT.
023437     MOVE ZERO                       TO WS-SIDFND-AMT.
023437
029060*    IF  RPOL-POL-CTRY-CDN
029060     IF  NOT RPOL-POL-CTRY-US
023437     AND NOT RPOL-POL-REG
023437         PERFORM
023437             VARYING J FROM 1 BY 1
023437               UNTIL J > RPOL-POL-CVG-REC-CTR-N
023437
023437                  EVALUATE  TRUE
023437
023437                      WHEN  WCVGS-PLAN-FND-TYP-SIDE    (J)
023437
023437                      COMPUTE  WS-SIDFND-AMT
023437                            =  WS-SIDFND-AMT
023437                            +  L0182-CVG-ACUM-VALU-AMT (J)
023437
023437                      WHEN  WCVGS-CVG-CF-TYP-NONE      (J)
023437
023437                      COMPUTE  WS-SEG-FND-ACUM-AMT
023437                            =  WS-SEG-FND-ACUM-AMT
023437                            +  L0182-CVG-ACUM-VALU-AMT (J)
023437
023437                      WHEN  OTHER
023437
023437                      COMPUTE  WS-CFLW-ACUM-AMT
023437                            =  WS-CFLW-ACUM-AMT
023437                            +  L0182-CVG-ACUM-VALU-AMT (J)
023437
023437                  END-EVALUATE
023437
023437         END-PERFORM
023437
023437         MOVE WS-CFLW-ACUM-AMT        TO WS-POL-ACUM-VALU-AMT
023437     ELSE
023437         MOVE L0182-POL-ACUM-VALU-AMT TO WS-POL-ACUM-VALU-AMT
023437     END-IF.
023437
031034*    MOVE WS-POL-ACUM-VALU-AMT       TO L0187-TAX-AF.
023437*
031034*    MOVE WS-CDA-TYP-CD              TO L0187-CDA-TYP-CD.
031034*    MOVE WS-CDA-SEQ-NUM             TO L0187-CDA-SEQ-NUM.
031034*    MOVE WS-POL-PAYO-NUM            TO L0187-POL-PAYO-NUM.
031034*
031034*    IF WS-PRCES-STATE-EDIT
031034*    OR WS-PRCES-STATE-CHNG
031034*        SET L0187-PRCES-TYP-EDIT-ONLY TO TRUE
031034*    END-IF.
031034*
031034*    IF  LPGAL-PGAL-ALLOC-REQ
031034*        MOVE L0182-CV-TAX           TO L0187-CASH-VALUE
031034*        PERFORM  7900-PROCESS-PGAL
031034*            THRU 7900-PROCESS-PGAL-X
031034*        MOVE LPGAL-PLAR-PRCES-SW    TO L0187-PLAR-PRCES-SW
031034*        MOVE LPGAL-PGAL-ALLOC-SW    TO L0187-PGAL-ALLOC-SW
031034*        PERFORM
031034*           VARYING  LPGAL-SUB FROM +1 BY +1
031034*              UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*              MOVE  LPGAL-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*                TO  L0187-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*              MOVE  LPGAL-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*                TO  L0187-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*              MOVE  LPGAL-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*                TO  L0187-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*              MOVE  LPGAL-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*                TO  L0187-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*              MOVE  LPGAL-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*                TO  L0187-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*              MOVE  LPGAL-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*                TO  L0187-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*              MOVE  LPGAL-PGAL-WTHDR-SEQ-NUM  (LPGAL-SUB)
031034*                TO  L0187-PGAL-WTHDR-SEQ-NUM  (LPGAL-SUB)
031034*              MOVE  LPGAL-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*                TO  L0187-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*        END-PERFORM
031034*    ELSE
031034*        COMPUTE L0187-CASH-VALUE = L0182-CV-TAX
031034*                                 - L0182-LOAN-CSV-AMT
031034*    END-IF.
023437*
031034*    MOVE WS-TRXN-FEE-AMT          TO L0187-CHRG-AMT.
031034*    IF  NOT L0187-EVNT-NOT-USED
031034*        PERFORM  0187-8500-VALU-TRMN
031034*            THRU 0187-8500-VALU-TRMN-X
031034*        IF  NOT L0187-RETRN-OK
031034*        OR  L0187-EDIT-ERROR
031034*            SET WGLOB-RETURN-ERROR   TO TRUE
031034*        END-IF
031034*        MOVE L0187-FED-TAXWH-CALC-CD
031034*                                    TO L2600-FED-TAXWH-CALC-CD
031034*        MOVE L0187-FED-TAXWH-RQST-PCT
031034*                                    TO L2600-FED-TAXWH-RQST-PCT
031034*        MOVE L0187-LTAXWH-FLAT-AMT  TO L2600-CDA-LTAXWH-AMT
031034*        MOVE L0187-FED-TAXWH-AMT    TO L2600-CDA-FED-TAXWH-AMT
031034*        MOVE L0187-GAIN-AMT         TO L2600-CDA-DISP-TAX-AMT
031034*        MOVE L0187-GAIN-AMT         TO L2600-CDA-TAX-GAIN-AMT
031034*        MOVE L0187-TAXBL-PORTN-AMT  TO L2600-CDA-DISP-TAX-AMT
031034*        MOVE L0187-TAXBL-PORTN-AMT  TO WS-TAXBL-PORTN-AMT
031034*        MOVE L0187-TAX-ACB          TO WS-TAX-ACB-AMT
031034*        MOVE L0187-LTAXWH-FLAT-AMT  TO WS-LTAXWH-FLAT-AMT
031034*        MOVE L0187-LTAXWH-CALC-CD   TO WS-LTAXWH-CALC-CD
031034*        MOVE L0187-LTAXWH-PCT       TO WS-LTAXWH-PCT
031034*        MOVE L0187-FED-TAXWH-AMT    TO WS-FED-TAXWH-AMT
031034*        MOVE L0187-FED-TAXWH-CALC-CD  TO WS-FED-TAXWH-CALC-CD
031034*        MOVE L0187-FED-TAXWH-RQST-AMT TO WS-FED-TAXWH-RQST-AMT
031034*        MOVE L0187-FED-TAXWH-RQST-PCT TO WS-FED-TAXWH-RQST-PCT
031034*        IF L0187-PRCES-TYP-EDIT-ONLY
031034*           IF  WS-LTAXWH-CALC-C
031034*           AND WS-LTAXWH-FLAT-AMT > ZERO
031034*               SET WS-LTAXWH-CALC-S   TO TRUE
031034*           END-IF
031034*        ELSE
031034*            PERFORM 6810-OFFSET-TAXWH-ACCT
031034*               THRU 6810-OFFSET-TAXWH-ACCT-X
031034*        END-IF
031034*    END-IF.
023437*
031034*  SET UP BASIC PARAMETERS
031034
031034     PERFORM  5382-0000-INIT-PARM-INFO
031034         THRU 5382-0000-INIT-PARM-INFO-X.
031034     PERFORM  5382-1000-BUILD-PARM-INFO
031034         THRU 5382-1000-BUILD-PARM-INFO-X.
031034     MOVE WBTAX-BYPASS-TAX-IND     TO L5382-WBTAX-BYPASS-TAX-IND.
031034     MOVE WBTAX-BYPASS-LTAX-IND    TO L5382-WBTAX-BYPASS-LTAX-IND.
031034     SET  L5382-WTHDR-POL-LVL      TO TRUE.
031034     SET  L5382-0182-INFO-PROVIDED TO TRUE.
031034
031034     EVALUATE  TRUE
031034
031034        WHEN  WS-PRCES-STATE-RETRIEVE
031034        WHEN  WS-PRCES-STATE-EDIT
031034        WHEN  WS-PRCES-STATE-CHNG
031034              SET  L5382-PRCES-TYP-EDIT-ONLY  TO TRUE
031034        WHEN  OTHER
031034              SET  L5382-PRCES-TYP-ALL        TO TRUE
031034
031034     END-EVALUATE.
031034
031034
031034     IF WS-BUS-FCN-GIA-SURR
031034         MOVE E0761-GIA-SUR-DT       TO L5382-EFF-DT
031034     ELSE
031034         MOVE E0761-CF-DT            TO L5382-EFF-DT
031034     END-IF.
031034
029060     MOVE L5382-EFF-DT               TO L1660-INTERNAL-DATE.
029060
029060     PERFORM  1660-2000-CONVERT-INT-TO-INV
029060         THRU 1660-2000-CONVERT-INT-TO-INV-X.
029060
029060     MOVE L1660-INVERTED-DATE        TO L5382-PCHST-EFF-IDT-NUM
029060                                        L5382-CDA-EFF-IDT-NUM.
029060     MOVE WGLOB-CREAT-PCHST-SEQ-NUM  TO L5382-POLT-PCHST-SEQ-NUM.
029060
031034     MOVE E0761-REASON                TO L5382-FND-REASN-CD.
031034     MOVE WS-TOT-SIDFND-CLI-AMT       TO L5382-SIDFND-AMT.
031034     MOVE WS-POL-ACUM-VALU-AMT        TO L5382-TAX-AF-AMT.
031034     MOVE WS-CDA-TYP-CD               TO L5382-CDA-TYP-CD.
031034     MOVE WS-CDA-SEQ-NUM              TO L5382-CDA-SEQ-NUM.
031034     MOVE WS-POL-PAYO-NUM             TO L5382-POL-PAYO-NUM.
031034     MOVE WS-CDA-EFF-IDT-NUM          TO L5382-CDA-EFF-IDT-NUM.
031034     SET L5382-TRXN-WTHDR             TO TRUE.
031034     SET L5382-SURR-FOR-NONE          TO TRUE.
031034
031034     IF  WS-PRCES-STATE-EDIT
031034     OR  WS-PRCES-STATE-CHNG
031034         IF  E0761-UNIT-SURRENDER
031034         OR  E0761-FULL-GIA-SURRENDER
031034             MOVE L1010-GRS-SURR-TOTAL TO L2600-CDAD-TRXN-AMT
031034         ELSE
031034             MOVE L1010-AMOUNT        TO L2600-CDAD-TRXN-AMT
031034         END-IF
031034     END-IF.
031034
031034     MOVE WS-TOT-POL-CF-CLI-AMT       TO L5382-TRXN-AMT.
031034     MOVE WS-TOT-POL-CF-FND-AMT       TO L5382-REGFND-AMT.
031034     MOVE WS-TOT-POL-CF-CLI-AMT       TO L5382-CFLW-AMT.
031034     MOVE E0761-CVG-NUM               TO L5382-CVG-NUM.
031034     MOVE WS-TRXN-FEE-AMT             TO L5382-CHRG-AMT.
031034
031034     PERFORM  5382-2000-WTHDR-TAX-PRCES
031034         THRU 5382-2000-WTHDR-TAX-PRCES-X.
031034
031034     IF  NOT L5382-RETRN-OK
031034         SET  WGLOB-RETURN-ERROR      TO TRUE
031034         GO TO 6800-TAX-PROCESSING-X
031034     END-IF.
031034
029060*    MOVE L5382-FED-TAXWH-CALC-CD     TO L2600-FED-TAXWH-CALC-CD.
029060*    MOVE L5382-FED-TAXWH-RQST-PCT    TO L2600-FED-TAXWH-RQST-PCT.
029060*    MOVE L5382-LTAXWH-FLAT-AMT       TO L2600-CDA-LTAXWH-AMT.
029060*    MOVE L5382-FED-TAXWH-AMT         TO L2600-CDA-FED-TAXWH-AMT.
029060*    MOVE L5382-GAIN-AMT              TO L2600-CDA-TAX-GAIN-AMT.
029060*    MOVE L5382-TAXBL-PORTN-AMT       TO L2600-CDA-DISP-TAX-AMT.
029060*    MOVE L5382-LTAXWH-FLAT-AMT       TO WS-LTAXWH-FLAT-AMT.
029060*    MOVE L5382-LTAXWH-AMT            TO WS-LTAXWH-FLAT-AMT.
029060*    MOVE L5382-LTAXWH-CALC-CD        TO WS-LTAXWH-CALC-CD.
029060*    MOVE L5382-LTAXWH-PCT            TO WS-LTAXWH-PCT.
031034
031034     IF  L5382-PRCES-TYP-EDIT-ONLY
029060         CONTINUE
029060*        IF  MIR-LTAXWH-CALC-CD = 'C'
029060*        AND L5382-LTAXWH-FLAT-AMT > ZERO
029060*            MOVE 'S'                 TO WS-LTAXWH-CALC-CD
029060*        END-IF
031034     ELSE
031034         PERFORM 6810-OFFSET-TAXWH-ACCT
031034            THRU 6810-OFFSET-TAXWH-ACCT-X
031034     END-IF.
031034
023437 6800-TAX-PROCESSING-X.
023437     EXIT.

023437*-----------------------
023437 6810-OFFSET-TAXWH-ACCT.
023437*-----------------------
023437*
029060*    IF (L2600-CDA-LTAXWH-AMT +
029060*        L2600-CDA-FED-TAXWH-AMT) = ZERO
029060*        GO TO 6810-OFFSET-TAXWH-ACCT-X
029060*    END-IF.
029060
029060     IF (L5382-LTAXWH-AMT +
029060         L5382-FTAXWH-AMT) = ZERO
029060         GO TO 6810-OFFSET-TAXWH-ACCT-X
029060     END-IF.
023437*
023437     PERFORM ACCT-1000-BUILD-PARM-INFO
023437        THRU ACCT-1000-BUILD-PARM-INFO-X.
023437*
023437     PERFORM  2090-1000-BUILD-PARM-INFO
023437         THRU 2090-1000-BUILD-PARM-INFO-X.
023437     SET L2090-OS-DISB-TYPE-SURRENDERS  TO TRUE.
031034**   COMPUTE L2090-OS-DISB-CHG-AMT = (WS-LTAXWH-FLAT-AMT
031034**                                 +  WS-FED-TAXWH-AMT)
029060*    COMPUTE L2090-OS-DISB-CHG-AMT = (L5382-LTAXWH-FLAT-AMT
029060     COMPUTE L2090-OS-DISB-CHG-AMT = (L5382-LTAXWH-AMT
029060*                                  +  L5382-FED-TAXWH-AMT)
029060                                   +  L5382-FTAXWH-AMT)
023437                                   * -1.
023437     PERFORM  2090-1000-GEN-DISB-ACCT
023437         THRU 2090-1000-GEN-DISB-ACCT-X.
023437*
023437     IF  L2090-RETRN-OK
023437         PERFORM  2090-2000-UPDT-POL-DISB-AREA
023437             THRU 2090-2000-UPDT-POL-DISB-AREA-X
023437     ELSE
023437         SET WGLOB-RETURN-ERROR     TO TRUE
023437     END-IF.
023437*
023437 6810-OFFSET-TAXWH-ACCT-X.
023437     EXIT.

      *
      *-------------------------
       7000-FINALIZE-SURR-TRANS.
      *-------------------------
      *
      * IF THE USER IS OVERRIDING FIELDS ON THE CASHFLOW, EDIT THEM
      * BY CALLING THE CHANGE FUNCTION DRIVER
      *
           IF WS-PRCES-STATE-CHNG
               PERFORM  7100-OVERRIDE-CASHFLOW
                   THRU 7100-OVERRIDE-CASHFLOW-X
               SET L1010-PRCES-TYP-EDIT-ONLY TO TRUE
011097         SET L1010-OVRID-SURR-CHRG     TO TRUE
011097*        GO TO 7000-FINALIZE-SURR-TRANS-X
           END-IF.

023437*    SET WS-REDO-OK                TO TRUE.
023437*    IF  WS-PRCES-STATE-PRCES
023437*    AND WGLOB-GOOD-RETURN
023437*        PERFORM  7150-INVOKE-REDO
023437*            THRU 7150-INVOKE-REDO-X
023437*        IF  WS-REDO-NOT-OK
023437*            GO TO 7000-FINALIZE-SURR-TRANS-X
023437*        END-IF
023437*    END-IF.
023437*
023437* IF THIS IS THE FINAL PASS, INVOKE UNDO TO REVERSE ACTIVITIES
023437* DATED LATER THAN THE EFFECTIVE DATE OF THIS TRANSACTION
023437*
023437*    IF WS-PRCES-STATE-PRCES
023437*    AND WGLOB-GOOD-RETURN
023437*        PERFORM  7200-INVOKE-UNDO
023437*            THRU 7200-INVOKE-UNDO-X
023437*    END-IF.

      * SET UP ALL THE PARAMETERS REQUIRED TO CALL THE FUNCTION DRIVER
      * TO PERFORM EDITING AGAINST THE POLICY AND CASH FLOW, AND TO
      * PROCESS IF THIS IS THE FINAL PASS.

           MOVE L0182-POL-MTHV-ADJ-AMT       TO L1010-HOLD-MTHV-ADJ-AMT.
           MOVE WS-HOLD-AMOUNT        TO L1010-HOLD-AMOUNT.
           IF WS-HOLD-AMOUNT > ZERO
               IF WS-BUS-FCN-SURR-FND-BY-UNIT
017150*            COMPUTE L1010-MTHV-ADJ-AMT ROUNDED =
017150             COMPUTE L0279-CRCY-AMT             =
                                L0182-POL-MTHV-ADJ-AMT
                              * L1010-UNITS
                              / WS-HOLD-AMOUNT
017150             PERFORM  0279-1000-CRCY-RND
017150                 THRU 0279-1000-CRCY-RND-X
017150             MOVE L0279-CRCY-AMT TO L1010-MTHV-ADJ-AMT
               ELSE
017150*            COMPUTE L1010-MTHV-ADJ-AMT ROUNDED =
017150             COMPUTE L0279-CRCY-AMT             =
                                L0182-POL-MTHV-ADJ-AMT
                              * L1010-AMOUNT
                              / WS-HOLD-AMOUNT
017150             PERFORM  0279-1000-CRCY-RND
017150                 THRU 0279-1000-CRCY-RND-X
017150             MOVE L0279-CRCY-AMT TO L1010-MTHV-ADJ-AMT
               END-IF
           END-IF.

           IF WS-BUS-FCN-FULL-GIA-SURR
017150*        COMPUTE L1010-MTHV-ADJ-AMT ROUNDED
017150*                                   = L0182-POL-MTHV-ADJ-AMT
017150         COMPUTE L1010-MTHV-ADJ-AMT = L0182-POL-MTHV-ADJ-AMT
           END-IF.

012143* SET UP DEPOSIT BASED SURRENDER CHARGES INFO
012143     IF WS-BUS-FCN-SURR
               IF  WS-PRCES-STATE-PRCES
012143         AND WGLOB-GOOD-RETURN
012143             MOVE L2600-POL-PAYO-NUM
                                      TO L1010-PAYOUT-NUM-N
012143             MOVE L2600-CDA-SEQ-NUM
                                      TO L1010-CDA-SEQ-NUM
015794             MOVE L2600-CDA-SEQ-NUM
015794                                TO RCFLW-DEST-CDA-SEQ-NUM
023437             MOVE L2600-CDA-TYP-CD
023437                                TO L1010-CDA-TYP-CD
012143         ELSE
012143             MOVE ZERO          TO L1010-PAYOUT-NUM-N
012143             MOVE ZERO          TO L1010-CDA-SEQ-NUM
012143         END-IF
012143
012143         MOVE WS-DBSC-TOT-SURR-AMT
                                      TO L1010-DBSC-TOT-SURR-AMT
012143         MOVE WS-DBSC-TOT-CHRG-AMT
                                      TO L1010-DBSC-TOT-CHRG-AMT
012143         MOVE WS-DBSC-TOT-FREE-AMT
                                      TO L1010-DBSC-TOT-FREE-AMT
012143         MOVE WS-DBSC-ASS-SURR-AMT
                                      TO L1010-DBSC-ASS-SURR-AMT
012143         MOVE WS-DBSC-ASS-CHRG-AMT
                                      TO L1010-DBSC-ASS-CHRG-AMT
012143         MOVE WS-DBSC-ASS-FREE-AMT
                                      TO L1010-DBSC-ASS-FREE-AMT
012143         MOVE WS-DBSC-APPLICABLE-IND
                                      TO L1010-DBSC-APPLICABLE-IND
012143
012143         IF  E0761-SUR-CHARGE NOT = SPACES
012143             SET WS-SURR-CHRG-OVRIDDEN
012143                                TO TRUE
012143         END-IF
012143     END-IF.

023437*    PERFORM  4800-GET-PGAL-INFO
023437*        THRU 4800-GET-PGAL-INFO-X.
023437*
023437*    PERFORM  7400-INIT-DBG-DATA
023437*        THRU 7400-INIT-DBG-DATA-X.
023437*
      * IF THIS IS THE FINAL PASS, REQUEST VERIFY;
      * OTHERWISE, REQUEST EDIT ONLY

           IF  WS-PRCES-STATE-PRCES
           AND WGLOB-GOOD-RETURN
               SET L1010-PRCES-TYP-VER-ONLY TO TRUE
           ELSE
               SET L1010-PRCES-TYP-EDIT-ONLY TO TRUE
           END-IF.

      * IF THIS IS A FUND BY FUND TRANSACTION, SET UP ADDITIONAL
      * DIRECTIONS FOR THE FUNCTION DRIVER

           IF WS-BUS-FCN-SURR-FND-BY-FND
               PERFORM  7010-SETUP-FUND-PARMS
                   THRU 7010-SETUP-FUND-PARMS-X
           END-IF.
019912
023437*    IF NOT WS-PRCES-STATE-CHNG
023437     IF WS-PRCES-STATE-CHNG
023437        PERFORM  7950-ADD-CHARGES
023437            THRU 7950-ADD-CHARGES-X
023444     ELSE
              IF WS-BUS-FCN-SURR
028788            SET  L1010-AGT-COMM-RQST      TO TRUE
031034            SET L1010-TAXWH-ACTV-PRCES-NO TO TRUE
                  PERFORM  1010-1000-ANNTY-SURRENDER
                      THRU 1010-1000-ANNTY-SURRENDER-X
012143            IF  NOT L1010-RETRN-OK
012143                SET WGLOB-RETURN-ERROR    TO TRUE
012143            END-IF
023437            PERFORM  7950-ADD-CHARGES
023437                THRU 7950-ADD-CHARGES-X
              ELSE
012143            PERFORM 7300-INVOKE-REVERSAL
012143               THRU 7300-INVOKE-REVERSAL-X
012143            IF  NOT L2770-RETRN-OK
012143                SET WGLOB-RETURN-ERROR    TO TRUE
012143            END-IF
              END-IF
019912     END-IF.

      * IF THERE HAVE BEEN ERRORS TO THIS POINT, IT IS NOT POSSIBLE
      * TO CONTINUE.

012143*    IF NOT L1010-RETRN-OK
012143*        SET WGLOB-RETURN-ERROR  TO TRUE
012143*    END-IF.

023437*    PERFORM  7020-FINALIZE-LOC
023437*        THRU 7020-FINALIZE-LOC-X.

      * IF THIS IS THE FIRST PASS OF A REVERSAL, INVITE THE USER TO
      * VERIFY, AND EXIT THIS ROUTINE.

           IF  WS-PRCES-STATE-EDIT
           AND WS-BUS-FCN-REVRS
               IF  WGLOB-GOOD-RETURN
                   MOVE 'CS07610011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
               GO TO 7000-FINALIZE-SURR-TRANS-X
           END-IF.

      *
      * EXIT ROUTINE IF INITIAL SCREEN ON FUND BY FUND TRANS
      *
           IF WS-PRCES-STATE-RETRIEVE
               GO TO 7000-FINALIZE-SURR-TRANS-X
           END-IF.

012143     IF  WS-BUS-FCN-SURR
           AND WS-PRCES-STATE-PRCES
012143     AND WGLOB-GOOD-RETURN
012143         PERFORM 4670-CREATE-SURR-CDSD
012143            THRU 4670-CREATE-SURR-CDSD-X
023437*        IF WCVGS-PLAN-FND-TYP-XTRNL (E0761-CVG-NUM)
023437*            CONTINUE
023437*        ELSE
023437*            IF  LPGAL-PGAL-ALLOC-REQ
023437*                PERFORM  4675-WRITE-PGAL-REC
023437*                    THRU 4675-WRITE-PGAL-REC-X
023437*            END-IF
023437*        END-IF
023437*        PERFORM  7410-WRITE-DBGA-REC
023437*            THRU 7410-WRITE-DBGA-REC-X
012143     END-IF.
012143
012143     MOVE L1010-DBSC-ASS-SURR-AMT  TO WS-DBSC-ASS-SURR-AMT.
012143     MOVE L1010-DBSC-ASS-CHRG-AMT  TO WS-DBSC-ASS-CHRG-AMT.
012143     MOVE L1010-DBSC-ASS-FREE-AMT  TO WS-DBSC-ASS-FREE-AMT.


      * UPDATE THE MIR FIELDS AND WORK FIELDS ACCORDING TO VALUES
      * RETURNED FROM CSLF1010

023437*    IF  L1010-TAX-WITHHELD          = ZEROES
013693*    AND L1010-PROV-TAX-WITHHELD     = ZEROES
023437*    AND L1010-LTAXWH-FLAT-AMT       = ZEROES
023437*        GO TO 7000-FINALIZE-SURR-TRANS-X
023437*    END-IF.

023437*    ADD  L1010-TAX-WITHHELD        TO WS-TOTAL-WITHHELD.
020874*    COMPUTE L0290-INPUT-NUMBER = L1010-TAX-WITHHELD * 100.
023437*    MOVE L1010-TAX-WITHHELD    TO L0290-INPUT-V02.
023437*    MOVE 2                     TO L0290-PRECISION.
023437*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
023437*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023437*    PERFORM  0290-2000-FORMAT-FOR-MIR
023437*        THRU 0290-2000-FORMAT-FOR-MIR-X.
023437*    MOVE L0290-OUTPUT-DATA     TO MIR-CDA-FED-TAXWH-AMT.

013693*    COMPUTE L0290-INPUT-NUMBER = L1010-PROV-TAX-WITHHELD * 100.
013693*    MOVE 2                     TO L0290-PRECISION.
013693*    MOVE LENGTH OF MIR-CF-PROV-TAXWH-AMT
013693*                               TO L0290-MAX-OUT-LEN.
013693*    PERFORM  0290-1000-NUMERIC-FORMAT
013693*        THRU 0290-1000-NUMERIC-FORMAT-X.
013693*    MOVE L0290-OUTPUT-DATA     TO MIR-CF-PROV-TAXWH-AMT.

015290*    MOVE L1010-TAX-OVERRIDE    TO MIR-DV-TAX-OVRID-IND.
023437*    IF  E0761-OVERRIDE = 'Y'
023437*        MOVE L1010-TAX-OVERRIDE
023437*                               TO MIR-DV-TAX-OVRID-IND
023437*    END-IF.

013693*    IF WS-BUS-FCN-SURR-FND-BY-FND
013693*    AND L1010-PROV-TAX-WITHHELD > ZERO
013693*        MOVE 'CS07610005'      TO WGLOB-MSG-REF-INFO
013693*    MSG: PROVINCIAL TAX WITHHOLDING NOT SUPPORTED ON "A" OR "U"
013693*        PERFORM  0260-1000-GENERATE-MESSAGE
013693*            THRU 0260-1000-GENERATE-MESSAGE-X
013693*    END-IF.

023437*    IF WS-BUS-FCN-SURR-FND-BY-AMT
023437*       MOVE MIR-CF-FED-TAXWH-AMT
023437*                              TO MIR-CF-FED-TAXWH-AMT-T (WS-LINE)
023437*       IF  L1010-TAX-WITHHELD > ZEROS
023437*       AND MIR-CF-FED-TAXWH-AMT  NOT = E0761-WITHHELD-R
023437*       AND MIR-CDA-FED-TAXWH-AMT  NOT = E0761-WITHHELD-R
023437*       AND E0761-OVERRIDE = 'Y'
023437*           MOVE 'Y'           TO MIR-DV-TAX-OVRID-IND-T (WS-LINE)
023437*       END-IF
023437*    END-IF.
023437*
023437*    IF WS-BUS-FCN-SURR-FND-BY-UNIT
023437*       MOVE MIR-CF-FED-TAXWH-AMT
023437*                              TO MIR-CF-FED-TAXWH-AMT-T (WS-LINE)
023437*       IF  L1010-TAX-WITHHELD > ZEROS
023437*       AND MIR-CF-FED-TAXWH-AMT  NOT = E0761-WITHHELD-R
023437*       AND MIR-CDA-FED-TAXWH-AMT  NOT = E0761-WITHHELD-R
023437*       AND E0761-OVERRIDE = 'Y'
023437*           MOVE 'Y'           TO MIR-DV-TAX-OVRID-IND-T (WS-LINE)
023437*       END-IF
023437*    END-IF.

012137     IF MIR-SUPRES-CNFRM-IND = 'Y'
012137       SET L1010-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

       7000-FINALIZE-SURR-TRANS-X.
           EXIT.
      *
      *----------------------
       7010-SETUP-FUND-PARMS.
      *----------------------

           IF WS-PRCES-STATE-RETRIEVE
               SET L1010-FRST-PASS-FND-BY-FND TO TRUE
               GO TO 7010-SETUP-FUND-PARMS-X
           END-IF.

           IF WS-LINE > W0761-FRST-FND-CVG
               SET L1010-FRST-CALC-NO         TO TRUE
           END-IF.

           IF WS-LINE = W0761-LST-FND-CVG
               SET L1010-POLICY-LVL-EDIT      TO TRUE
           ELSE
               MOVE 'N'               TO L1010-POLICY-LVL-EDIT-IND
           END-IF.

       7010-SETUP-FUND-PARMS-X.
           EXIT.
      *
023437*-----------------
023437*7020-FINALIZE-LOC.
023437*-----------------

013693**  MOVE LOCATION TAX INFROMATION TO THE SCREEN

023437*    ADD L1010-LTAXWH-FLAT-AMT      TO WS-TOTAL-CF-LTAXWH-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L1010-LTAXWH-FLAT-AMT * 100.
023437*    MOVE L1010-LTAXWH-FLAT-AMT     TO L0290-INPUT-V02.
023437*    MOVE 2                         TO L0290-PRECISION.
023437*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT  TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023437*    PERFORM  0290-2000-FORMAT-FOR-MIR
023437*        THRU 0290-2000-FORMAT-FOR-MIR-X.
023437*    MOVE L0290-OUTPUT-DATA         TO MIR-LTAXWH-FLAT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L1010-LTAXWH-PCT * 100.
023437*    MOVE L1010-LTAXWH-PCT          TO L0290-INPUT-V02.
023437*    MOVE 2                         TO L0290-PRECISION.
023437*    MOVE LENGTH OF MIR-LTAXWH-PCT
023437*                                   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023437*    PERFORM  0290-2000-FORMAT-FOR-MIR
023437*        THRU 0290-2000-FORMAT-FOR-MIR-X.
023437*    MOVE L0290-OUTPUT-DATA      TO MIR-LTAXWH-PCT.

023437*    MOVE L1010-LTAXWH-CALC-CD      TO MIR-LTAXWH-CALC-CD.
020818*    IF  WS-LINE > ZERO
020818*    AND WS-LINE <= WS-MAX-FUND-LINES
020818*        IF  WS-BUS-FCN-SURR-FND-BY-AMT
020818*        OR  WS-BUS-FCN-SURR-FND-BY-UNIT
020818*            MOVE MIR-CF-LTAXWH-AMT TO MIR-CF-LTAXWH-AMT-T
020818*                                     (WS-LINE)
020818*        END-IF
020818*    END-IF.
023437*    IF  WS-BUS-FCN-SURR-FND-BY-AMT
023437*    OR  WS-BUS-FCN-SURR-FND-BY-UNIT
023437*        SET WS-LTAX-LOOP-START     TO TRUE
023437*        PERFORM  7030-DEFAULT-LTAX-ALLOC
023437*            THRU 7030-DEFAULT-LTAX-ALLOC-X
023437*            VARYING WS-IDX FROM 1 BY 1
023437*            UNTIL   WS-IDX > WS-MAX-FUND-LINES
023437*            OR      WS-LTAX-LOOP-END
023437*        PERFORM  7040-ALLOC-TO-FIRST
023437*            THRU 7040-ALLOC-TO-FIRST-X
023437*            VARYING WS-IDX FROM 1 BY 1
023437*            UNTIL   WS-IDX > WS-MAX-FUND-LINES
023437*            OR      WS-LTAX-LOOP-END
023437*    END-IF.

023437*    IF  MIR-SUPRES-CNFRM-IND = 'Y'
023437*        SET L1010-SUPPRESS-CONFIRM      TO TRUE
023437*    END-IF.

023437*7020-FINALIZE-LOC-X.
023437*    EXIT.
      *
023437*------------------------
023437*7030-DEFAULT-LTAX-ALLOC.
023437*------------------------
023437*
023437*    MOVE 'N'                   TO L0280-SIGN-IND
023437*    MOVE 2                     TO L0280-PRECISION
023437*    MOVE LENGTH OF MIR-DV-POL-CSV-AMT-T (WS-IDX)
023437*                               TO L0280-INPUT-SIZE
023437*    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
023437*                           L0280-PRECISION - 1
023437*    MOVE MIR-DV-POL-CSV-AMT-T (WS-IDX) TO L0280-INPUT-DATA
023437*    PERFORM  0280-1000-NUMERIC-EDIT
023437*        THRU 0280-1000-NUMERIC-EDIT-X
023437*    IF  L0280-OK
023437*    AND L0280-OUTPUT-DOLLAR >= L1010-LTAXWH-FLAT-AMT
023437*        MOVE MIR-CF-LTAXWH-AMT TO MIR-CF-LTAXWH-AMT-T
023437*                                  (WS-IDX)
023437*        SET WS-LTAX-LOOP-END   TO TRUE
023437*    END-IF.
023437*
023437*7030-DEFAULT-LTAX-ALLOC-X.
023437*    EXIT.
023437*
023437*---------------------
023437*7040-ALLOC-TO-FIRST.
023437*---------------------
023437*
023437*    MOVE 'N'                   TO L0280-SIGN-IND
023437*    MOVE 2                     TO L0280-PRECISION
023437*    MOVE LENGTH OF MIR-DV-POL-CSV-AMT-T (WS-IDX)
023437*                               TO L0280-INPUT-SIZE
023437*    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
023437*                           L0280-PRECISION - 1
023437*    MOVE MIR-DV-POL-CSV-AMT-T (WS-IDX) TO L0280-INPUT-DATA
023437*    PERFORM  0280-1000-NUMERIC-EDIT
023437*        THRU 0280-1000-NUMERIC-EDIT-X
023437*    IF  L0280-OK
023437*    AND L0280-OUTPUT-DOLLAR > ZERO
023437*        MOVE MIR-CF-LTAXWH-AMT TO MIR-CF-LTAXWH-AMT-T
023437*                                  (WS-IDX)
023437*        SET WS-LTAX-LOOP-END   TO TRUE
023437*    END-IF.
023437*
023437*7040-ALLOC-TO-FIRST-X.
023437*    EXIT.
023437*
      *-----------------------
       7100-OVERRIDE-CASHFLOW.
      *-----------------------

           PERFORM  0753-1000-BUILD-PARM-INFO
               THRU 0753-1000-BUILD-PARM-INFO-X.

      * MOVE MIR FIELDS TO L0753- PARM AREA.

           MOVE L1010-EFF-DT          TO L0753-EFF-DT.
           MOVE E0761-CVG-NUM         TO L0753-R-CVG-NUM.
           MOVE E0761-SUR-CHARGE      TO L0753-SUR-CHARGE.

           IF NOT WS-BUS-FCN-SURR-FND-BY-FND
               MOVE E0761-INT-RATE    TO L0753-INT-RATE
               MOVE E0761-MV-ADJ      TO L0753-MV-ADJ
013131         MOVE RCFLW-CF-INT-PCT  TO WS-EDIT-3V4
013131         MOVE WS-EDIT-3V4       TO WS-CF-INT-PCT-X
013131         IF  (E0761-INT-RATE NOT = ZEROS AND
013131              E0761-INT-RATE NOT = SPACES)
013131         AND (E0761-INT-RATE NOT = WS-CF-INT-PCT-X)
013131            SET WS-SAVE-INT-RATE-CHG TO TRUE
013131         END-IF
           END-IF.

013131     IF  RCFLW-CF-TYP-EIA
013131     AND WS-SAVE-INT-RATE-CHG
013131         SET WS-SAVE-INT-RATE-CHG-NO TO TRUE
013131* MSG: INTEREST RATE CHANGE NOT VALID FOR EIA PRODUCT
013131         MOVE 'CS07610057'      TO WGLOB-MSG-REF-INFO
013131         PERFORM  0260-1000-GENERATE-MESSAGE
013131             THRU 0260-1000-GENERATE-MESSAGE-X
013131     END-IF.
013131
      * CALL CSLF0753 FOR EDIT ONLY

           PERFORM  0753-1000-VALIDATE-INPUT
               THRU 0753-1000-VALIDATE-INPUT-X.

      * CHECK RETURN CODE AND CONTINUE IF INPUT IS VALID.  PROCESSING
      * THIS CHANGE WILL ONLY AFFECT THE CASHFLOW BEING PASSED IN
      * LINKAGE SECTION.  IT HAS NOT YET BEEN WRITTEN TO THE DATABASE.


           IF L0753-RETRN-OK
               SET L0753-ASUR-EDITS-REQD TO TRUE
               PERFORM  0753-2000-PROCESS-CHANGE
                   THRU 0753-2000-PROCESS-CHANGE-X
               MOVE L0753-UPDATE-IND  TO WS-UPDATE-SW
           END-IF.

012143* SAVE INDICATION THAT SURRENDER CHARGE IS BEING OVERRIDEN
012143     IF  E0761-SUR-CHARGE NOT = SPACES
012143         SET WS-SURR-CHRG-OVRIDDEN TO TRUE
012143     END-IF.
012143
       7100-OVERRIDE-CASHFLOW-X.
           EXIT.
      *
016503*----------------
016503 7150-INVOKE-REDO.
016503*----------------

016503     IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503         GO TO 7150-INVOKE-REDO-X
016503     END-IF.

016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503         GO TO 7150-INVOKE-REDO-X
016503     END-IF.

016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     MOVE L1010-EFF-DT                  TO L4780-EFF-DT.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
016503     SET L4780-PRCES-INCLUSIVE          TO TRUE.

016503     PERFORM  4780-1000-GET-NEXT-ACT-DT
016503         THRU 4780-1000-GET-NEXT-ACT-DT-X.

016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              SET WS-REDO-NOT-OK           TO TRUE
016503              PERFORM  POL-3000-UNLOCK
016503                  THRU POL-3000-UNLOCK-X
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503             PERFORM  POL-3000-UNLOCK
016503                 THRU POL-3000-UNLOCK-X
016503             MOVE L1010-EFF-DT        TO L0201-EFF-DT
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X
016503             PERFORM  0289-1000-INIT-PARM-INFO
016503                 THRU 0289-1000-INIT-PARM-INFO-X
016503             MOVE L1010-EFF-DT    TO L0289-LO-PAC-DT
020467             MOVE L1010-EFF-DT    TO L0289-LO-DD2-DT
016503             MOVE L1010-EFF-DT    TO L0289-LO-CRC-DT
016503             MOVE L1010-EFF-DT    TO L0289-PROC-EFF-DT
016503             PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503                 THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503             IF  L0289-RETRN-OK
016503                 MOVE L0289-NXT-ACTV-TYP-CD
016503                      TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE L0289-NXT-ACTV-DT
016503                      TO RPOL-POL-NXT-ACTV-DT
016503             ELSE
016503                 MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503                 MOVE WGLOB-PROCESS-DATE
016503                           TO RPOL-POL-NXT-ACTV-DT
016503             END-IF
016503             MOVE RPOL-REC-INFO           TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503             MOVE HPOL-REC-INFO           TO RPOL-REC-INFO
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
016503                 PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016503                     THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
016503             IF  L0201-RETRN-OK
016503                 PERFORM  POL-1000-READ-FOR-UPDATE
016503                     THRU POL-1000-READ-FOR-UPDATE-X
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503             END-IF
016503     END-EVALUATE.

016503 7150-INVOKE-REDO-X.
016503     EXIT.
      *
      *-----------------
       7200-INVOKE-UNDO.
      *-----------------

      * DETERMINE IF THERE ARE ANY ACTIVITIES THAT SHOULD BE UNDONE
      * PRIOR TO APPLYING THE SURRENDER TRANSACTION

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.
           SET L4750-FCN-DRVR-SECONDARY  TO TRUE.
012137     MOVE MIR-SUPRES-CNFRM-IND  TO L4750-SUPP-CONF-CD.

           IF WS-BUS-FCN-GIA-SURR
               MOVE E0761-GIA-SUR-DT  TO L4750-EFF-DT
           ELSE
               MOVE E0761-CF-DT       TO L4750-EFF-DT
           END-IF.
           MOVE E0761-CVG-NUM         TO L4750-CVG-NUM.
           IF WS-BUS-FCN-REVRS
               SET L4750-PRCES-CF-REVERSAL TO TRUE
               MOVE E0761-SEQ-NUM-R   TO L4750-CF-SEQ-NUM
           ELSE
               SET L4750-PRCES-EXCLUSIVE TO TRUE
               MOVE SPACES            TO L4750-CF-SEQ-NUM
           END-IF.

      *
      *  UNLOCK POLICY RECORD (THIS ALLOWS FOR POLICY UPDATES
      *  IN CSLS0065 WHICH CAN BE CALLED FROM CSLF4700).
      *
           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.
           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.
      *
      *    LOCK POLICY AGAIN IN ORDER TO DO UPDATES
      *    SAVE POLICY INFO TO RESTORE AFTER READ FOR UPDATE
           MOVE  RPOL-REC-INFO        TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY             TO  WPOL-KEY.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.
      *
      * IF THE UNDO PROCESS WAS SUCCESSFUL, CONTINUE PROCESSING.
      * OTHERWISE, REWRITE THE POLICY AND COVERAGES ANYWAY BECAUSE
      * RECORDS ON OTHER TABLES MAY HAVE BEEN UPDATED DURING UNDO.
      *
           IF L4750-RETRN-OK
               GO TO 7200-INVOKE-UNDO-X
           END-IF.

016503      PERFORM  0289-1000-INIT-PARM-INFO
016503          THRU 0289-1000-INIT-PARM-INFO-X.

016503      MOVE L1010-EFF-DT             TO L0289-LO-PAC-DT.
020467      MOVE L1010-EFF-DT             TO L0289-LO-DD2-DT.
016503      MOVE L1010-EFF-DT             TO L0289-LO-CRC-DT.
016503      MOVE L1010-EFF-DT             TO L0289-PROC-EFF-DT.

016503      PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503          THRU 0289-1000-OBTAIN-NXT-ACTV-X.

016503      IF  L0289-RETRN-OK
016503          MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503      ELSE
016503          MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503      END-IF.

           SET WGLOB-RETURN-ERROR TO TRUE.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.


       7200-INVOKE-UNDO-X.
           EXIT.

023437*--------------------
023437 7250-PRCES-UNDO-REDO.
023437*--------------------
023437
023437     PERFORM  7150-INVOKE-REDO
023437         THRU 7150-INVOKE-REDO-X.
023437
023437     IF  WS-REDO-NOT-OK
023437         GO TO 7250-PRCES-UNDO-REDO-X
023437     END-IF.
023437
023437
023437* INVOKE UNDO TO REVERSE ACTIVITIES
023437* DATED LATER THAN THE EFFECTIVE DATE OF THIS TRANSACTION
023437
023437     PERFORM  7200-INVOKE-UNDO
023437         THRU 7200-INVOKE-UNDO-X.
023437
023437 7250-PRCES-UNDO-REDO-X.
023437     EXIT.

      *
012143*---------------------
012143 7300-INVOKE-REVERSAL.
012143*---------------------
012143* INITIALIZE L2770 PARM AREA
012143     PERFORM 2770-1000-BUILD-PARM-INFO
012143        THRU 2770-1000-BUILD-PARM-INFO-X.
012143
012143* BUILD THE LINKAGE AREA
012143*
012143     MOVE L1010-PRCES-TYP-CD    TO L2770-PRCES-TYP-CD.
012143     MOVE L1010-CVG             TO L2770-CVG-NUM.
012143     MOVE L1010-REASON          TO L2770-REASON.
012143     MOVE L1010-AMOUNT          TO L2770-AMOUNT.
012137     MOVE L1010-SUPPRESS-CONFIRM-IND
                                      TO L2770-SUPR-CONF-IND.
014719     SET L2770-FCN-DRVR-SECONDARY  TO TRUE.
012143
012143*  SET UP THE KEY AND RETRIEVE THE DESIRED CASHFLOW.
012143     INITIALIZE WCFLW-KEY.
012143     MOVE RPOL-POL-ID           TO WCFLW-POL-ID.
012143     MOVE E0761-CVG-NUM         TO WCFLW-CVG-NUM.
012143     MOVE E0761-CF-DT           TO L1680-INTERNAL-1.
012143     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
012143     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
012143     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
012143     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
012143         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
012143     MOVE L1680-INTERNAL-2      TO WCFLW-CF-EFF-DT.
012143     MOVE WCVGS-CVG-CF-TYP-CD (E0761-CVG-NUM)
012143                                TO WCFLW-CF-TYP-CD.
012143     MOVE E0761-SEQ-NUM         TO WCFLW-CF-SEQ-NUM.
012143     PERFORM  CFCA-1000-CF-AND-CA-IN
012143         THRU CFCA-1000-CF-AND-CA-IN-X.
012143     IF NOT WCFLW-IO-OK
012143*        MSG: CASH FLOW RECORD NOT FOUND
012143         MOVE 'CS07610042'      TO WGLOB-MSG-REF-INFO
012143         PERFORM  0260-1000-GENERATE-MESSAGE
012143             THRU 0260-1000-GENERATE-MESSAGE-X
012143         SET WGLOB-RETURN-ERROR TO TRUE
012143         GO TO 7300-INVOKE-REVERSAL-X
012143     END-IF.
012143
012143     IF  RCFLW-CFAGT-SEQ-NUM > 0
012143     AND NOT WCFAG-IO-OK
012143* MSG:  CASH FLOW AGENT RECORD NOT IN FILE
012143         MOVE 'CS07610020'      TO WGLOB-MSG-REF-INFO
012143         PERFORM  0260-1000-GENERATE-MESSAGE
012143             THRU 0260-1000-GENERATE-MESSAGE-X
012143         SET WGLOB-RETURN-ERROR TO TRUE
012143         GO TO 7300-INVOKE-REVERSAL-X
012143     END-IF.
012143
031036     IF  RCFLW-CF-REASN-XEMP-MGMT-PREV
031036     OR  RCFLW-CF-REASN-XEMP-MGMT-CRNT
031036* MSG: WITHDRAWAL THAT RESULTED FROM EXEMPT STATUS MANAGEMENT
031036*      CANNOT BE REVERSED
031036         MOVE 'CS07610064'      TO WGLOB-MSG-REF-INFO
031036         PERFORM  0260-1000-GENERATE-MESSAGE
031036             THRU 0260-1000-GENERATE-MESSAGE-X
031036         SET WGLOB-RETURN-ERROR TO TRUE
031036         GO TO 7300-INVOKE-REVERSAL-X
031036     END-IF.
031036
012143     MOVE RCFLW-REC-INFO        TO WTSCF-CFLW-REC-INFO.
012143     MOVE WCFCS-WORK-AREA       TO WTSCF-CFCO-WORK-AREA.
012143     MOVE RCFAG-REC-INFO        TO WTSCF-CFAG-REC-INFO.
           MOVE WTSCF-CASH-FLOW-INFO  TO L2770-CASHFLOW-SEGFUND-AREA.
012143*
012143* CALL FSLF2770 TO REVERSE ALL RELATED SURRENDER ALLOCATIONS
012143*
012143     PERFORM 2770-1000-SURRENDER-REVERSAL
012143        THRU 2770-1000-SURRENDER-REVERSAL-X.
012143
012143     MOVE L2770-CASHFLOW-SEGFUND-AREA
             TO WTSCF-CASH-FLOW-INFO.
012143     MOVE WTSCF-CFLW-REC-INFO   TO RCFLW-REC-INFO.
012143     MOVE WTSCF-CFCO-WORK-AREA  TO WCFCS-WORK-AREA.
012143     MOVE WTSCF-CFAG-REC-INFO   TO RCFAG-REC-INFO.
012143
012143 7300-INVOKE-REVERSAL-X.
012143     EXIT.

020475*------------------
020475 7400-INIT-DBG-DATA.
020475*------------------
020475
020475     IF RPOL-POL-DBG-NO
020475     OR WCVGS-CVG-DBG-INCL-NO (WS-CVG-NUM)
020475         GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.
020475
020475     PERFORM  7306-1000-BUILD-PARM-INFO
020475         THRU 7306-1000-BUILD-PARM-INFO-X.
020475     MOVE RPOL-POL-ID        TO L7306-POL-ID.
020475
020475     PERFORM  7306-1000-GET-DBG-INFO
020475         THRU 7306-1000-GET-DBG-INFO-X.
020475
020475     IF L7306-POL-DBG-BASIC-CSV
020475         GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.
020475
020475     IF NOT WS-PRCES-STATE-PRCES
020475         GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.
020475*
020475* READ CURRENT DBGA
020475*
020475     PERFORM  7305-1000-BUILD-PARM-INFO
020475         THRU 7305-1000-BUILD-PARM-INFO-X.
020475
020475     MOVE L1010-EFF-DT             TO L7305-EFF-DT.
020475
020475     PERFORM  7305-1000-GET-CURR-DBGA
020475         THRU 7305-1000-GET-CURR-DBGA-X.
020475
020475     IF NOT L7305-RETRN-OK
020475         SET WGLOB-RETURN-ERROR    TO TRUE
020475         GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.
020475
020475     PERFORM  0182-1000-BUILD-PARM-INFO
020475         THRU 0182-1000-BUILD-PARM-INFO-X.
020475
020475     SET  L0182-CALC-DBG-AFV-YES    TO TRUE.
020475     MOVE L1010-EFF-DT              TO L0182-EFF-DT.
020475
020475     PERFORM  0182-1000-CALC-CSV-POL
020475         THRU 0182-1000-CALC-CSV-POL-X
020475
020475     IF NOT L0182-RETRN-OK
020475         SET WGLOB-RETURN-ERROR    TO TRUE
020475         GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.
020475
020475     MOVE L0182-POL-ACUM-VALU-AMT  TO WS-POL-DBG-ACUM-AMT.
020475     ADD  L0182-SIDFND-AFV-AMT     TO WS-POL-DBG-ACUM-AMT.
020475     IF  RPOL-POL-DBG-LOAN
020475         SUBTRACT L0182-LOAN-AMT (1) FROM WS-POL-DBG-ACUM-AMT
020475         SUBTRACT L0182-LOAN-ACRU-INT-AMT (1)
020475                                  FROM WS-POL-DBG-ACUM-AMT
020475     END-IF.
020475
020475 7400-INIT-DBG-DATA-X.
020475     EXIT.


020475*--------------------
020475 7410-WRITE-DBGA-REC.
020475*--------------------
020475
020475     IF RPOL-POL-DBG-NO
020475     OR L7306-POL-DBG-BASIC-CSV
020475     OR WCVGS-CVG-DBG-INCL-NO (WS-CVG-NUM)
020475     OR WS-CVG-TRXN-AMT = ZERO
020475         GO TO 7410-WRITE-DBGA-REC-X
020475     END-IF.
020475
020475     SET  RDBGA-DBGA-TYP-WTHDR   TO TRUE.
020475     MOVE L1010-EFF-DT           TO L7305-EFF-DT.
020475     MOVE WS-CVG-TRXN-AMT        TO RDBGA-DBGA-TRXN-AMT.
020475     MOVE WS-POL-DBG-ACUM-AMT    TO RDBGA-DBGA-ACUM-AMT.
020475     MOVE WS-CDA-TYP-CD          TO RDBGA-CDA-TYP-CD.
020475     MOVE WS-POL-PAYO-NUM        TO RDBGA-POL-PAYO-NUM.
020475     MOVE WS-CDA-SEQ-NUM         TO RDBGA-CDA-SEQ-NUM.
020475
020475     PERFORM  7305-2000-CREATE-DBGA
020475         THRU 7305-2000-CREATE-DBGA-X.
020475
020475     IF NOT L7305-RETRN-OK
020475         SET WGLOB-RETURN-ERROR    TO TRUE
020475     END-IF.
020475
020475 7410-WRITE-DBGA-REC-X.
020475     EXIT.
020475
031034*----------------------------
031034*7500-L7800-TO-LPGAL.
031034*----------------------------
031034*
031034*    MOVE L7800-PLAR-PRCES-SW     TO LPGAL-PLAR-PRCES-SW,
031034*    MOVE L7800-PGAL-ALLOC-SW     TO LPGAL-PGAL-ALLOC-SW.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE L7800-PGAL-ALLOC-TYP-CD    (LPGAL-SUB)
031034*          TO LPGAL-PGAL-ALLOC-TYP-CD    (LPGAL-SUB)
031034*        MOVE L7800-PGAL-DPOS-DFLT-IND   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-DPOS-DFLT-IND   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-XFER-ONLY-IND   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-XFER-ONLY-IND   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-PRIN-AMT    (LPGAL-SUB)
031034*          TO LPGAL-PGAL-OPN-PRIN-AMT    (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-GAIN-AMT    (LPGAL-SUB)
031034*          TO LPGAL-PGAL-OPN-GAIN-AMT    (LPGAL-SUB)
031034*        MOVE L7800-PGAL-TRXN-PRIN-AMT   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-TRXN-PRIN-AMT   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-TRXN-GAIN-AMT   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-TRXN-GAIN-AMT   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-SURR-CHRG-AMT   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-SURR-CHRG-AMT   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-SEQ-NUM   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-WTHDR-SEQ-NUM   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-ORDR-CD   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-WTHDR-ORDR-CD   (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*7500-L7800-TO-LPGAL-X.
031034*    EXIT.
031034*
031034*----------------------------
031034*7600-L7800-TO-HOLD.
031034*----------------------------
031034*
031034*    MOVE L7800-PLAR-PRCES-SW TO WS-HOLD-PLAR-PRCES-SW.
031034*    MOVE L7800-PGAL-ALLOC-SW TO WS-HOLD-PGAL-ALLOC-SW.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE L7800-PGAL-ALLOC-TYP-CD    (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-PRIN-AMT    (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-OPN-PRIN-AMT  (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-GAIN-AMT    (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-OPN-GAIN-AMT  (LPGAL-SUB)
031034*        MOVE L7800-PGAL-TRXN-PRIN-AMT   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*        MOVE L7800-PGAL-TRXN-GAIN-AMT   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*        MOVE L7800-PGAL-SURR-CHRG-AMT   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*        MOVE L7800-PGAL-DPOS-DFLT-IND   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-DPOS-DFLT-IND (LPGAL-SUB)
031034*        MOVE L7800-PGAL-XFER-ONLY-IND   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-XFER-ONLY-IND (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-SEQ-NUM   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-ORDR-CD   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*7600-L7800-TO-HOLD-X.
031034*    EXIT.
031034*
031034*----------------------------
031034*7700-HOLD-TO-L7800.
031034*----------------------------
031034*
031034*    MOVE WS-HOLD-PLAR-PRCES-SW      TO L7800-PLAR-PRCES-SW.
031034*    MOVE WS-HOLD-PGAL-ALLOC-SW      TO L7800-PGAL-ALLOC-SW.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE WS-HOLD-PGAL-ALLOC-TYP-CD        (LPGAL-SUB)
031034*          TO L7800-PGAL-ALLOC-TYP-CD          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-OPN-PRIN-AMT        (LPGAL-SUB)
031034*          TO L7800-PGAL-OPN-PRIN-AMT          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-OPN-GAIN-AMT        (LPGAL-SUB)
031034*          TO L7800-PGAL-OPN-GAIN-AMT          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-WTHDR-SEQ-NUM       (LPGAL-SUB)
031034*          TO L7800-PGAL-WTHDR-SEQ-NUM         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-WTHDR-ORDR-CD       (LPGAL-SUB)
031034*          TO L7800-PGAL-WTHDR-ORDR-CD         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-TRXN-PRIN-AMT       (LPGAL-SUB)
031034*          TO L7800-PGAL-TRXN-PRIN-AMT         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-TRXN-GAIN-AMT       (LPGAL-SUB)
031034*          TO L7800-PGAL-TRXN-GAIN-AMT         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-SURR-CHRG-AMT       (LPGAL-SUB)
031034*          TO L7800-PGAL-SURR-CHRG-AMT         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-DPOS-DFLT-IND       (LPGAL-SUB)
031034*          TO L7800-PGAL-DPOS-DFLT-IND         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-XFER-ONLY-IND       (LPGAL-SUB)
031034*          TO L7800-PGAL-XFER-ONLY-IND         (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*7700-HOLD-TO-L7800-X.
031034*    EXIT.
031034*
031034*
031034*-------------------
031034*7800-HOLD-TO-LPGAL.
031034*-------------------
031034*
031034*     PERFORM
031034*        VARYING  LPGAL-SUB FROM +1 BY +1
031034*           UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE WS-HOLD-PGAL-ALLOC-TYP-CD        (LPGAL-SUB)
031034*          TO LPGAL-PGAL-ALLOC-TYP-CD          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-OPN-PRIN-AMT        (LPGAL-SUB)
031034*          TO LPGAL-PGAL-OPN-PRIN-AMT          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-OPN-GAIN-AMT        (LPGAL-SUB)
031034*          TO LPGAL-PGAL-OPN-GAIN-AMT          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-WTHDR-SEQ-NUM       (LPGAL-SUB)
031034*          TO LPGAL-PGAL-WTHDR-SEQ-NUM         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-WTHDR-ORDR-CD       (LPGAL-SUB)
031034*          TO LPGAL-PGAL-WTHDR-ORDR-CD         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-TRXN-PRIN-AMT       (LPGAL-SUB)
031034*          TO LPGAL-PGAL-TRXN-PRIN-AMT         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-TRXN-GAIN-AMT       (LPGAL-SUB)
031034*          TO LPGAL-PGAL-TRXN-GAIN-AMT         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-SURR-CHRG-AMT       (LPGAL-SUB)
031034*          TO LPGAL-PGAL-SURR-CHRG-AMT         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-DPOS-DFLT-IND       (LPGAL-SUB)
031034*          TO LPGAL-PGAL-DPOS-DFLT-IND         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-XFER-ONLY-IND       (LPGAL-SUB)
031034*          TO LPGAL-PGAL-XFER-ONLY-IND         (LPGAL-SUB)
031034*     END-PERFORM.
031034*
031034*7800-HOLD-TO-LPGAL-X.
031034*    EXIT.


023437*---------------------
031034*7900-PROCESS-PGAL.
023437*---------------------
023437*
031034*    IF WS-PRCES-STATE-EDIT
031034*    OR WS-PRCES-STATE-CHNG
031034*       PERFORM  4675-DISB-SURR-AMT
031034*           THRU 4675-DISB-SURR-AMT-X
031034*       GO TO 7900-PROCESS-PGAL-X
031034*    END-IF.
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE RPOL-POL-ID             TO L7800-POL-ID.
031034*    MOVE E0761-CF-DT             TO L7800-EFF-DT.
031034*    MOVE L0182-CV-TAX            TO L7800-CV-TAX.
031034*    MOVE WS-CDA-TYP-CD           TO L7800-CDA-TYP-CD.
031034*    MOVE WS-POL-PAYO-NUM         TO L7800-POL-PAYO-NUM.
031034*    MOVE WS-CDA-EFF-IDT-NUM      TO L7800-CDA-EFF-IDT-NUM.
031034*    MOVE WS-CDA-SEQ-NUM          TO L7800-CDA-SEQ-NUM.
031034*    SET L7800-CALC-CV-NOT-REQ    TO TRUE.
031034*    SET L7800-TRXN-WTHDR         TO TRUE.
031034*    COMPUTE  L7800-SURR-CHRG-AMT =  WS-PGAL-TRXN-FEE-AMT.
031034*    SET L7800-PRCES-NORMAL       TO TRUE.
031034*    SET L7800-PLAR-PRCES         TO TRUE.
031034*    SET L7800-PGAL-ALLOC-REQ     TO TRUE.
031034*
031034*
031034*    PERFORM  7700-HOLD-TO-L7800
031034*        THRU 7700-HOLD-TO-L7800-X.
031034*
031034*    PERFORM  7800-4000-PGAL-PRCES
031034*        THRU 7800-4000-PGAL-PRCES-X.
031034*
031034*    PERFORM  7500-L7800-TO-LPGAL
031034*        THRU 7500-L7800-TO-LPGAL-X.
031034*
031034*    PERFORM  7600-L7800-TO-HOLD
031034*        THRU 7600-L7800-TO-HOLD-X.
031034*
031034*    IF  NOT L7800-RETRN-OK
031034*        SET WGLOB-RETURN-ERROR    TO TRUE
031034*    END-IF.
031034*
031034*7900-PROCESS-PGAL-X.
031034*    EXIT.


023437*-----------------
023437 7950-ADD-CHARGES.
023437*-----------------
023437
023437     IF  WS-PRCES-STATE-RETRIEVE
023437         GO TO 7950-ADD-CHARGES-X
023437     END-IF.
023437
023437     IF  RCFLW-CF-SURR-CHRG-AMT > 0
023437         COMPUTE WS-CF-SURR-CHRG-AMT = RCFLW-CF-SURR-CHRG-AMT
023437     ELSE
023437         COMPUTE WS-CF-SURR-CHRG-AMT = RCFLW-CF-SURR-CHRG-AMT
023437                                     * -1
023437     END-IF.
023437
023437     IF  RCFLW-CF-MKTVAL-ADJ-AMT > 0
023437         COMPUTE WS-CF-MKTVAL-ADJ-AMT
023437               = RCFLW-CF-MKTVAL-ADJ-AMT
023437     ELSE
023437         COMPUTE WS-CF-MKTVAL-ADJ-AMT
023437               = RCFLW-CF-MKTVAL-ADJ-AMT
023437               * -1
023437     END-IF.
023437
023437     COMPUTE  WS-TRXN-FEE-AMT
023437           =  WS-TRXN-FEE-AMT
023437           +  WS-CF-SURR-CHRG-AMT
023437           +  WS-CF-MKTVAL-ADJ-AMT.
023437
031034*    COMPUTE  WS-PGAL-TRXN-FEE-AMT
031034*          =  WS-PGAL-TRXN-FEE-AMT
031034*          +  WS-CF-SURR-CHRG-AMT
031034*          +  WS-CF-MKTVAL-ADJ-AMT.
023437
023437*    THE CFLW AMOUNTS ARE NEGATIVE, BUT WE NEED TO PASS POSITIVE
023437*    AMOUNTS TO THE TAX MODULE
023437*
023437     IF WCVGS-PLAN-FND-TYP-SIDE (L1010-CVG)
023437         SUBTRACT RCFLW-CF-FND-TRXN-AMT FROM WS-TOT-SIDFND-FND-AMT
023437         SUBTRACT RCFLW-CF-CLI-TRXN-AMT FROM WS-TOT-SIDFND-CLI-AMT
023437     ELSE
023437         SUBTRACT RCFLW-CF-FND-TRXN-AMT FROM WS-TOT-POL-FND-AMT
023437         SUBTRACT RCFLW-CF-CLI-TRXN-AMT FROM WS-TOT-POL-CLI-AMT
023437         SUBTRACT RCFLW-CF-FND-TRXN-AMT FROM WS-TOT-POL-CF-FND-AMT
023437         SUBTRACT RCFLW-CF-CLI-TRXN-AMT FROM WS-TOT-POL-CF-CLI-AMT
023437     END-IF.
023437
023437 7950-ADD-CHARGES-X.
023437     EXIT.

      *-------------------------
       8000-VALIDATE-KEY-FIELDS.
      *-------------------------
      *
      *  EDIT POLICY NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

014221     IF  WS-BUS-FCN-RETRIEVE
014221     OR  WS-PRCES-STATE-RETRIEVE
014221     OR  WS-PRCES-STATE-EDIT
014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
014221     ELSE
014221         PERFORM  POL-2000-UPDATE-TWRK-TS
014221             THRU POL-2000-UPDATE-TWRK-TS-X
014221         IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221             MOVE 'XS00000303'        TO WGLOB-MSG-REF-INFO
014221             MOVE 'POL'               TO WGLOB-MSG-PARM (01)
014221             MOVE WPOL-KEY            TO WGLOB-MSG-PARM (02)
014221             PERFORM  0260-1000-GENERATE-MESSAGE
014221                 THRU 0260-1000-GENERATE-MESSAGE-X
014221            SET WGLOB-RETURN-ERROR       TO TRUE
014221            GO TO 8000-VALIDATE-KEY-FIELDS-X
014221         END-IF
014221     END-IF.
014221

           IF WPOL-IO-OK
               CONTINUE
           ELSE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR       TO TRUE
               GO TO 8000-VALIDATE-KEY-FIELDS-X
           END-IF.

020463* CHECK FOR INVESTOR PROFILE
020463     IF  WS-BUS-FCN-SURR
020463         PERFORM  2735-1000-BUILD-PARM-INFO
020463             THRU 2735-1000-BUILD-PARM-INFO-X
020463         MOVE  RPOL-POL-ID   TO L2735-POL-ID
020463         PERFORM  2735-1000-GET-PRFL
020463             THRU 2735-1000-GET-PRFL-X
020463         IF L2735-RETRN-PRFL-FND
020463*MSG: THIS POLICY CONTAINS AN INVESTOR PROFILE. THE
020463*     ALLOCATIONS ENTERED FOR THIS ACTIVITY MAY NOT MATCH
020463*     THE ALLOCATIONS DEFINED FOR THE PROFILE.
020463            MOVE 'CS07610058'      TO WGLOB-MSG-REF-INFO
020463            PERFORM  0260-1000-GENERATE-MESSAGE
020463               THRU  0260-1000-GENERATE-MESSAGE-X
020463
020463             IF  WGLOB-MSG-SEVRTY-FATAL
020463                 SET WGLOB-RETURN-ERROR  TO TRUE
020463                 GO TO 8000-VALIDATE-KEY-FIELDS-X
020463             END-IF
020463
020463         END-IF
020463     END-IF.
020463

      * GET OWNER'S NAME

           MOVE ZERO                  TO I.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE  L0620-INPUT-PARM-INFO
               MOVE L2430-CLI-ENTR-CO-NM      TO L0620-CLI-CO-NM
               MOVE L2430-CLI-ENTR-GIV-NM     TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM     TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM     TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM          TO L0620-CLI-SFX-NM
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
           END-IF.

023437     IF  RPOL-POL-CTRY-US
023437     AND (MIR-DV-PRCES-STATE-CD = '1'
023437     OR MIR-DV-PRCES-STATE-CD = '2')
023437*    IF MIR-DV-PRCES-STATE-CD = '1'
023437*    OR MIR-DV-PRCES-STATE-CD = '2'
029060*       IF  (MIR-LTAXWH-CALC-CD  = 'B'
029060        IF  (MIR-LTAXWH-RQST-CD  = 'B'
029060*       OR  MIR-LTAXWH-CALC-CD   = 'S')
029060        OR  MIR-LTAXWH-RQST-CD   = 'S')
013693        AND (L2430-CLI-TXEMP-CD  = 'D'
013693        OR   L2430-CLI-TXEMP-CD  = 'M'
013693        OR   L2430-CLI-TXEMP-CD  = 'N'
013693        OR   L2430-CLI-TXEMP-CD  = 'S')
013693*MSG: (F) 'CLIENT HAS B-NOTICE CALCUATION ONLY ALLOWED'
013693           MOVE 'CS07610054'        TO  WGLOB-MSG-REF-INFO
013693           PERFORM  0260-1000-GENERATE-MESSAGE
013693               THRU 0260-1000-GENERATE-MESSAGE-X
013693        END-IF
013693     END-IF.
013693
      *
      *  EDIT COVERAGE NUMBER
      *
           IF  MIR-CVG-NUM = SPACES
               MOVE ZEROS             TO MIR-CVG-NUM
           END-IF.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
           AND (L0280-OUTPUT NOT > RPOL-POL-CVG-REC-CTR-N)
               MOVE L0280-OUTPUT      TO E0761-CVG-NUM
               MOVE E0761-CVG-NUM     TO MIR-CVG-NUM
012145         MOVE E0761-CVG-NUM     TO WS-CVG-NUM
           ELSE
               MOVE 'CS07610031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR       TO TRUE
031357         GO TO 8000-VALIDATE-KEY-FIELDS-X
           END-IF.
      *
           IF  MIR-CVG-NUM = ZEROS
           AND NOT WS-BUS-FCN-SURR-FND-BY-FND
               MOVE 'CS07610007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR       TO TRUE
031357         GO TO 8000-VALIDATE-KEY-FIELDS-X
           END-IF.

023437* READ IN THE COVERAGES
023437
023437     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
023437         THRU CVGS-1000-LOAD-CVGS-ARRAY-X
023437
023437     IF  WS-BUS-FCN-SURR-FND-BY-FND
034802*        NEXT SENTENCE
034802         CONTINUE
023437     ELSE
023437         IF WCVGS-CVG-COLFND (WS-CVG-NUM)
023437* GENERATE MESSAGE:'USE OF LCF NOT VALID'
023437             MOVE 'CS07610043'      TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437             GO TO 8000-VALIDATE-KEY-FIELDS-X
023437         END-IF
023437     END-IF.
023437
      *  EDIT EFFECTIVE DATE
      *
           IF MIR-DV-CF-EFF-DT = SPACES
               MOVE WGLOB-PROCESS-DATE TO L1640-INTERNAL-DATE
026057         MOVE L1640-INTERNAL-DATE TO WS-CF-REC-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-DV-CF-EFF-DT
           ELSE
               MOVE MIR-DV-CF-EFF-DT     TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF L1640-NOT-VALID
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-DV-CF-EFF-DT TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR       TO TRUE
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO WS-CF-REC-DATE
               END-IF
           END-IF.

           PERFORM  8010-EDIT-SEQ-NUM
               THRU 8010-EDIT-SEQ-NUM-X.

           PERFORM  8020-EDIT-AMOUNT
               THRU 8020-EDIT-AMOUNT-X.

           PERFORM  8030-EDIT-UNIT
               THRU 8030-EDIT-UNIT-X.

           PERFORM  8040-EDIT-SURR-EFF-DT
               THRU 8040-EDIT-SURR-EFF-DT-X.

031034**   PERFORM  8050-EDIT-F-TAX-AMT
031034**       THRU 8050-EDIT-F-TAX-AMT-X.
031034     PERFORM  8050-EDIT-TAXWH-FIELDS
031034         THRU 8050-EDIT-TAXWH-FIELDS-X.

013693*    PERFORM  8060-EDIT-P-TAX-AMT
013693*        THRU 8060-EDIT-P-TAX-AMT-X.

           PERFORM  8070-EDIT-SUPPRES-CNFRM
               THRU 8070-EDIT-SUPPRES-CNFRM-X.

031034**   PERFORM  8080-EDIT-LOCATION-TAX
031034**       THRU 8080-EDIT-LOCATION-TAX-X.
023437
031034**   PERFORM  8090-EDIT-FED-TAXWH-RQST
031034**       THRU 8090-EDIT-FED-TAXWH-RQST-X.

      *
      * CHECK IF THE POLICY CAN BE ACCESSED FOR THIS TRANSACTION
      *
           PERFORM  8900-CHECK-ACCESS
               THRU 8900-CHECK-ACCESS-X.

014221     IF  WS-BUS-FCN-RETRIEVE
014221     OR  WS-PRCES-STATE-RETRIEVE
014221     OR  WS-PRCES-STATE-EDIT
014221         CONTINUE
014221     ELSE
014221         IF  WGLOB-RETURN-ERROR
014221             PERFORM  POL-3000-UNLOCK
014221                 THRU POL-3000-UNLOCK-X
014221         END-IF
014221     END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CF-REC-DATE       TO WIHSD-EFF-DT.
026057     IF  WS-BUS-FCN-RETRIEVE
026057         PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057             THRU IHSD-1000-CHK-IHSD-INQUIRY-X
026057     ELSE
026057         PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057             THRU IHSD-2000-CHK-IHSD-PROCESS-X
026057     END-IF.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WGLOB-RETURN-ERROR     TO TRUE
026057     END-IF.

       8000-VALIDATE-KEY-FIELDS-X.
           EXIT.

      *------------------
       8010-EDIT-SEQ-NUM.
      *------------------
      *
      * EDIT SEQUENCE NUMBER
      *

           IF  MIR-CF-SEQ-NUM = SPACE
020874*        MOVE ZERO              TO WS-EDIT-3A
020874*        MOVE WS-EDIT-3A        TO MIR-CF-SEQ-NUM
020874         MOVE ZERO                  TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CF-SEQ-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CF-SEQ-NUM
               MOVE MIR-CF-SEQ-NUM    TO E0761-SEQ-NUM
               MOVE MIR-CF-SEQ-NUM    TO WS-CF-SEQ-NUM
               GO TO 8010-EDIT-SEQ-NUM-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-CF-SEQ-NUM        TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-EDIT-3A
020874*        MOVE WS-EDIT-3A        TO MIR-CF-SEQ-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CF-SEQ-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CF-SEQ-NUM
               MOVE MIR-CF-SEQ-NUM    TO E0761-SEQ-NUM
               MOVE MIR-CF-SEQ-NUM    TO WS-CF-SEQ-NUM
           ELSE
               MOVE 'CS07610032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       8010-EDIT-SEQ-NUM-X.
           EXIT.

      *-----------------
       8020-EDIT-AMOUNT.
      *-----------------
      *
      *  EDIT THE AMOUNT ENTERED
      *

           IF  MIR-DV-CF-CLI-TRXN-AMT = SPACE
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
               MOVE 2                 TO L0290-PRECISION
               MOVE LENGTH OF MIR-DV-CF-CLI-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-DV-CF-CLI-TRXN-AMT
               MOVE L0290-OUTPUT-DATA TO E0761-AMOUNT-R
               MOVE ZERO              TO E0761-AMOUNT
018846         MOVE ZERO              TO WS-POL-TOT-SURR-AMT
               MOVE E0761-AMOUNT      TO WS-HOLD-AMOUNT
               GO TO 8020-EDIT-AMOUNT-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-DV-CF-CLI-TRXN-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                  L0280-PRECISION - 1.
           MOVE MIR-DV-CF-CLI-TRXN-AMT TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO E0761-AMOUNT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
               MOVE 2                 TO L0290-PRECISION
               MOVE LENGTH OF MIR-DV-CF-CLI-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-DV-CF-CLI-TRXN-AMT
               MOVE L0290-OUTPUT-DATA TO E0761-AMOUNT-R
               MOVE E0761-AMOUNT      TO WS-HOLD-AMOUNT
           ELSE
      *MSG: AMOUNT MUST BE NUMERIC
               MOVE 'CS07610006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       8020-EDIT-AMOUNT-X.
           EXIT.

      *---------------
       8030-EDIT-UNIT.
      *---------------
      *
      *  EDIT THE NUMBER OF UNITS
      *

           IF  MIR-DV-CF-UNIT-QTY = SPACE
               MOVE ZERO              TO E0761-UNITS
               MOVE E0761-UNITS       TO MIR-DV-CF-UNIT-QTY
               MOVE E0761-UNITS       TO WS-HOLD-UNITS
               GO TO 8030-EDIT-UNIT-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 5                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-DV-CF-UNIT-QTY
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                  L0280-PRECISION - 1.
           MOVE MIR-DV-CF-UNIT-QTY       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-V05  TO E0761-UNITS
               MOVE E0761-UNITS       TO MIR-DV-CF-UNIT-QTY
               MOVE E0761-UNITS       TO WS-HOLD-UNITS
           ELSE
      *MSG: UNITS MUST BE NUMERIC
               MOVE 'CS07610033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       8030-EDIT-UNIT-X.
           EXIT.

      *----------------------
       8040-EDIT-SURR-EFF-DT.
      *----------------------
      *
      *  EDIT GIA SURRENDER DATE
      *

           IF MIR-DV-SURR-EFF-DT = SPACES
               GO TO 8040-EDIT-SURR-EFF-DT-X
           END-IF.

           MOVE MIR-DV-SURR-EFF-DT      TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
               MOVE 'XS00000036'        TO WGLOB-MSG-REF-INFO
               MOVE MIR-DV-SURR-EFF-DT  TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE TO E0761-GIA-SUR-DT
           END-IF.

       8040-EDIT-SURR-EFF-DT-X.
           EXIT.

031034*-----------------------
031034 8050-EDIT-TAXWH-FIELDS.
031034*-----------------------
031034*
029060*    IF MIR-FED-TAXWH-CALC-CD = SPACES
029060*    OR MIR-FED-TAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
029060*        MOVE 'C'               TO MIR-FED-TAXWH-CALC-CD
029060*    END-IF.
029060
029060     IF MIR-FTAXWH-RQST-CD = SPACES
029060     OR MIR-FTAXWH-RQST-CD = EBLCH-BLANK-FIELD-CHAR
029060         MOVE 'C'               TO MIR-FTAXWH-RQST-CD
029060     END-IF.
031034
029060*    IF MIR-FED-TAXWH-RQST-AMT = SPACES
029060*        MOVE ZERO              TO MIR-FED-TAXWH-RQST-AMT
029060*    END-IF.
029060
029060     IF MIR-FTAXWH-RQST-AMT = SPACES
029060         MOVE ZERO              TO MIR-FTAXWH-RQST-AMT
029060     END-IF.
031034
029060*    IF MIR-FED-TAXWH-RQST-PCT = SPACES
029060*        MOVE ZERO              TO MIR-FED-TAXWH-RQST-PCT
029060*    END-IF.
029060
029060     IF MIR-FTAXWH-RQST-PCT = SPACES
029060         MOVE ZERO              TO MIR-FTAXWH-RQST-PCT
029060     END-IF.
031034
029060*    IF  MIR-LTAXWH-CALC-CD = SPACES
029060     IF  MIR-LTAXWH-RQST-CD = SPACES
029060*    OR  MIR-LTAXWH-CALC-CD = '*'
029060     OR  MIR-LTAXWH-RQST-CD = '*'
029060*        MOVE 'C'               TO  MIR-LTAXWH-CALC-CD
029060         MOVE 'C'               TO  MIR-LTAXWH-RQST-CD
031034     END-IF.
031034
029060*    IF  MIR-LTAXWH-FLAT-AMT = SPACE
029060     IF  MIR-LTAXWH-RQST-AMT = SPACE
029060*        MOVE ZEROES            TO MIR-LTAXWH-FLAT-AMT
029060         MOVE ZEROES            TO MIR-LTAXWH-RQST-AMT
031034     END-IF.
031034
029060*    IF  MIR-LTAXWH-PCT = SPACE
029060     IF  MIR-LTAXWH-RQST-PCT = SPACE
029060*         MOVE ZEROES           TO MIR-LTAXWH-PCT
029060          MOVE ZEROES           TO MIR-LTAXWH-RQST-PCT
031034     END-IF.
031034
031034* ENSURE FIELDS ARE NUMERIC THEN
031034* CALL THE TAX EDIT REGIONAL EXIT FOR EDITS
031034*
031034     SET LTAXC-RGN-EXIT-TAXWH-CLI-EDITS TO TRUE.
031034     PERFORM  0316-1000-BUILD-PARM-INFO
031034         THRU 0316-1000-BUILD-PARM-INFO-X.
031034     SET L0316-RGN-EXIT-TAXWH-CLI-EDITS TO TRUE.
031034     MOVE RPOL-POL-CTRY-CD            TO L0316-CTRY-CD.
031034     PERFORM  0316-1000-GET-RGN-EXIT-PGM
031034         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
031034*
031034     IF  NOT L0316-RETRN-OK
031034     OR  L0316-RGN-EXIT-STAT-INACTV
031034*MSG: NO WITHHOLDING REQUEST EDIT REGIONAL EXIT FOUND FOR COUNTRY
031034         MOVE 'CS07610063'            TO WGLOB-MSG-REF-INFO
031034         MOVE L0316-CTRY-CD           TO WGLOB-MSG-PARM (1)
031034         PERFORM  0260-1000-GENERATE-MESSAGE
031034             THRU 0260-1000-GENERATE-MESSAGE-X
031034         SET WGLOB-RETURN-ERROR       TO TRUE
031034         GO TO 8050-EDIT-TAXWH-FIELDS-X
031034     END-IF.
031034*
031034* AN ACTIVE REGION EXIT IS HELD. THIS MUST BE PERFORMED FIRST TO
031034* CARRY OUT EDITS FOR TAX WITHHOLDING DATA.
031034*
031034     PERFORM  TAXC-1000-BUILD-PARM-INFO
031034         THRU TAXC-1000-BUILD-PARM-INFO-X.
031034*
031034* EDIT FEDERAL WITHHOLDING AMOUNT
031034*
031034     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
031034     MOVE 2                           TO L0280-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
031034                                      TO L0280-INPUT-SIZE.
031034     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
031034                            L0280-PRECISION - 1.
029060*    MOVE MIR-FED-TAXWH-RQST-AMT      TO L0280-INPUT-DATA.
029060     MOVE MIR-FTAXWH-RQST-AMT         TO L0280-INPUT-DATA.
031034*
031034     PERFORM  0280-1000-NUMERIC-EDIT
031034         THRU 0280-1000-NUMERIC-EDIT-X.
031034*
031034     IF  L0280-OK
029060*        MOVE L0280-OUTPUT-DOLLAR     TO LTAXC-FED-TAXWH-RQST-AMT
029060         MOVE L0280-OUTPUT-DOLLAR     TO LTAXC-FTAXWH-RQST-AMT
031034         MOVE L0280-OUTPUT            TO L0290-INPUT-NUMBER
031034         MOVE 2                       TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
031034                                      TO L0290-MAX-OUT-LEN
031034         PERFORM  0290-2000-FORMAT-FOR-MIR
031034             THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA       TO MIR-FED-TAXWH-RQST-AMT
029060         MOVE L0290-OUTPUT-DATA       TO MIR-FTAXWH-RQST-AMT
031034     ELSE
031034*MSG: FEDERAL TAX WITHHELD MUST BE NUMERIC
031034         MOVE 'CS07610034'            TO WGLOB-MSG-REF-INFO
031034         PERFORM  0260-1000-GENERATE-MESSAGE
031034             THRU 0260-1000-GENERATE-MESSAGE-X
031034         SET WGLOB-RETURN-ERROR       TO TRUE
031034     END-IF.
031034*
031034* EDIT FEDERAL WITHHOLDING PERCENT
031034*
029060*    MOVE MIR-FED-TAXWH-RQST-PCT      TO L0280-INPUT-DATA.
029060     MOVE MIR-FTAXWH-RQST-PCT         TO L0280-INPUT-DATA.
031034     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-PCT TO L0280-INPUT-SIZE.
031034     MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
031034     MOVE 2                           TO L0280-PRECISION.
031034     PERFORM  0280-1000-NUMERIC-EDIT
031034         THRU 0280-1000-NUMERIC-EDIT-X.
031034*
031034     IF L0280-OK
029060*        MOVE L0280-OUTPUT-DOLLAR     TO LTAXC-FED-TAXWH-RQST-PCT
029060         MOVE L0280-OUTPUT-DOLLAR     TO LTAXC-FTAXWH-RQST-PCT
031034         MOVE L0280-OUTPUT            TO L0290-INPUT-NUMBER
031034         MOVE  2                      TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
031034                                      TO L0290-MAX-OUT-LEN
031034         PERFORM 0290-2000-FORMAT-FOR-MIR
031034            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA       TO MIR-FED-TAXWH-RQST-PCT
029060         MOVE L0290-OUTPUT-DATA       TO MIR-FTAXWH-RQST-PCT
031034         IF L0280-OUTPUT-V02 > 100
031034         OR L0280-OUTPUT-V02 < ZERO
031034* MESSAGE - INVALID FEDERAL TAX REQUEST %
031034             MOVE 'CS07610062'        TO WGLOB-MSG-REF-INFO
031034             PERFORM  0260-1000-GENERATE-MESSAGE
031034                 THRU 0260-1000-GENERATE-MESSAGE-X
031034             SET WGLOB-RETURN-ERROR   TO TRUE
031034         END-IF
031034     ELSE
031034* MESSAGE - INVALID FEDERAL TAX REQUEST % - REENTER
031034         MOVE 'CS07610062'      TO WGLOB-MSG-REF-INFO
031034         PERFORM  0260-1000-GENERATE-MESSAGE
031034             THRU 0260-1000-GENERATE-MESSAGE-X
031034         SET WGLOB-RETURN-ERROR       TO TRUE
031034     END-IF.
031034*
031034* EDIT LOCATION WITHHOLDING AMOUNT
031034*
031034     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
031034     MOVE 2                           TO L0280-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
031034                                      TO L0280-INPUT-SIZE.
031034     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
031034                             L0280-PRECISION - 1.
029060*    MOVE MIR-LTAXWH-FLAT-AMT         TO L0280-INPUT-DATA.
029060     MOVE MIR-LTAXWH-RQST-AMT         TO L0280-INPUT-DATA.
031034*
031034     PERFORM  0280-1000-NUMERIC-EDIT
031034         THRU 0280-1000-NUMERIC-EDIT-X.
031034*
031034     IF  L0280-OK
029060*        MOVE L0280-OUTPUT-DOLLAR     TO LTAXC-LTAXWH-FLAT-AMT
029060         MOVE L0280-OUTPUT-DOLLAR     TO LTAXC-LTAXWH-RQST-AMT
031034         MOVE L0280-OUTPUT            TO L0290-INPUT-NUMBER
031034         MOVE 2                       TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
031034                                      TO L0290-MAX-OUT-LEN
031034         PERFORM  0290-2000-FORMAT-FOR-MIR
031034             THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA       TO MIR-LTAXWH-FLAT-AMT
029060         MOVE L0290-OUTPUT-DATA       TO MIR-LTAXWH-RQST-AMT
031034     ELSE
031034*MSG: LOCATION TAX WITHHELD MUST BE NUMERIC
031034         MOVE 'CS07610041'            TO WGLOB-MSG-REF-INFO
031034         PERFORM  0260-1000-GENERATE-MESSAGE
031034             THRU 0260-1000-GENERATE-MESSAGE-X
031034         SET WGLOB-RETURN-ERROR       TO TRUE
031034     END-IF.
031034*
031034* EDIT LOCATION WITHHOLDING PERCENT
031034*
029060*    MOVE MIR-LTAXWH-PCT              TO L0280-INPUT-DATA.
029060     MOVE MIR-LTAXWH-RQST-PCT         TO L0280-INPUT-DATA.
031034     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT    TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT 
029060                                      TO L0280-INPUT-SIZE.
031034     MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
031034     MOVE 2                           TO L0280-PRECISION.
031034     PERFORM  0280-1000-NUMERIC-EDIT
031034         THRU 0280-1000-NUMERIC-EDIT-X.
031034*
031034     IF L0280-OK
029060*        MOVE L0280-OUTPUT-DOLLAR     TO LTAXC-LTAXWH-PCT
029060         MOVE L0280-OUTPUT-DOLLAR     TO LTAXC-LTAXWH-RQST-PCT
031034         MOVE L0280-OUTPUT            TO L0290-INPUT-NUMBER
031034         MOVE  2                      TO L0290-PRECISION
029060*       MOVE LENGTH OF MIR-LTAXWH-PCT TO L0290-MAX-OUT-LEN
029060        MOVE LENGTH OF MIR-LTAXWH-RQST-PCT 
029060                                      TO L0290-MAX-OUT-LEN
031034         PERFORM 0290-2000-FORMAT-FOR-MIR
031034            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA       TO MIR-LTAXWH-PCT
029060         MOVE L0290-OUTPUT-DATA       TO MIR-LTAXWH-RQST-PCT
031034         IF L0280-OUTPUT-V02 > 100
031034         OR L0280-OUTPUT-V02 < ZERO
031034* MESSAGE - INVALID LOCATION TAX REQUEST %
031034             MOVE 'CS07610044'        TO WGLOB-MSG-REF-INFO
031034             PERFORM  0260-1000-GENERATE-MESSAGE
031034                 THRU 0260-1000-GENERATE-MESSAGE-X
031034             SET WGLOB-RETURN-ERROR   TO TRUE
031034         END-IF
031034     ELSE
031034* MESSAGE - INVALID LOCATION TAX REQUEST % - REENTER
031034         MOVE 'CS07610044'            TO WGLOB-MSG-REF-INFO
031034         PERFORM  0260-1000-GENERATE-MESSAGE
031034             THRU 0260-1000-GENERATE-MESSAGE-X
031034         SET WGLOB-RETURN-ERROR       TO TRUE
031034     END-IF.
031034*
031034     MOVE WS-CF-REC-DATE              TO LTAXC-EFF-DT.
031034     MOVE MIR-POL-ID                  TO LTAXC-POL-ID.
029060*    MOVE MIR-FED-TAXWH-CALC-CD       TO LTAXC-FED-TAXWH-CALC-CD.
029060     MOVE MIR-FTAXWH-RQST-CD          TO LTAXC-FTAXWH-RQST-CD.
029060*    MOVE MIR-LTAXWH-CALC-CD          TO LTAXC-LTAXWH-CALC-CD.
029060     MOVE MIR-LTAXWH-RQST-CD          TO LTAXC-LTAXWH-RQST-CD.
031034     SET  LTAXC-LTAXWH-EDIT-REQT      TO TRUE.
031034*
031034     PERFORM  TAXC-1000-TAXWH-CLI-EDIT
031034         THRU TAXC-1000-TAXWH-CLI-EDIT-X.
031034*
031034     IF  LTAXC-EDIT-ERROR
031034     OR  NOT LTAXC-RETRN-OK
031034         SET WGLOB-RETURN-ERROR       TO TRUE
031034     END-IF.
031034
029060*    MOVE LTAXC-LTAXWH-CALC-CD        TO WS-LTAXWH-CALC-CD.
029060     MOVE LTAXC-LTAXWH-RQST-CD        TO WS-LTAXWH-CALC-CD.
029060*    MOVE LTAXC-LTAXWH-FLAT-AMT       TO WS-LTAXWH-FLAT-AMT.
029060     MOVE LTAXC-LTAXWH-RQST-AMT       TO WS-LTAXWH-FLAT-AMT.
029060*    MOVE LTAXC-LTAXWH-PCT            TO WS-LTAXWH-PCT.
029060     MOVE LTAXC-LTAXWH-RQST-PCT       TO WS-LTAXWH-PCT.
031034*
031034 8050-EDIT-TAXWH-FIELDS-X.
031034     EXIT.
031034
      *--------------------
031034*8050-EDIT-F-TAX-AMT.
      *--------------------
      *
      *  EDIT FEDERAL TAX WITHHELD FIELD
      *

023437*    IF  MIR-CF-FED-TAXWH-AMT = SPACE
031034**   IF  MIR-CDA-FED-TAXWH-AMT = SPACE
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
031034**       MOVE ZERO              TO L0290-INPUT-V02
031034**       MOVE 2                 TO L0290-PRECISION
031034**       MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
031034**                              TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
031034**       PERFORM  0290-2000-FORMAT-FOR-MIR
031034**           THRU 0290-2000-FORMAT-FOR-MIR-X
031034**       MOVE L0290-OUTPUT-DATA TO MIR-CDA-FED-TAXWH-AMT
031034**       MOVE L0290-OUTPUT-DATA TO E0761-WITHHELD-R
031034**       MOVE ZERO              TO E0761-WITHHELD
031034**       GO TO 8050-EDIT-F-TAX-AMT-X
031034**   END-IF.

023437*    IF  MIR-DV-TAX-OVRID-IND = 'N'
023437*        MOVE ZERO              TO MIR-CF-FED-TAXWH-AMT
023437*    END-IF.

031034**   MOVE 'N'                   TO L0280-SIGN-IND.
031034**   MOVE 2                     TO L0280-PRECISION.
031034**   MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
031034**                              TO L0280-INPUT-SIZE.
031034**   COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
031034**                          L0280-PRECISION - 1.
023437*    MOVE MIR-CF-FED-TAXWH-AMT  TO L0280-INPUT-DATA.
031034**   MOVE MIR-CDA-FED-TAXWH-AMT TO L0280-INPUT-DATA.

031034**   PERFORM  0280-1000-NUMERIC-EDIT
031034**       THRU 0280-1000-NUMERIC-EDIT-X.
031034**   IF  L0280-OK
031034**       MOVE L0280-OUTPUT-DOLLAR
031034**                              TO E0761-WITHHELD
023437*        MOVE L0280-OUTPUT-DOLLAR
023437*                               TO WS-HOLD-WITHHELD
031034**       MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
031034**       MOVE 2                 TO L0290-PRECISION
031034**       MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
031034**                              TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
031034**       PERFORM  0290-2000-FORMAT-FOR-MIR
031034**           THRU 0290-2000-FORMAT-FOR-MIR-X
031034**       MOVE L0290-OUTPUT-DATA TO MIR-CDA-FED-TAXWH-AMT
031034**       MOVE L0290-OUTPUT-DATA TO E0761-WITHHELD-R
031034**   ELSE
      *MSG: FEDERAL TAX WITHHELD MUST BE NUMERIC
031034**       MOVE 'CS07610034'      TO WGLOB-MSG-REF-INFO
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR       TO TRUE
031034**   END-IF.

031034*8050-EDIT-F-TAX-AMT-X.
031034**   EXIT.

013693*--------------------
013693*8060-EDIT-P-TAX-AMT.
013693*--------------------
013693*
013693*  EDIT PROVINCIAL TAX WITHHELD FIELD
013693*
013693*
013693*    IF  MIR-CF-PROV-TAXWH-AMT = SPACE
013693*        MOVE ZERO              TO L0290-INPUT-NUMBER
013693*        MOVE 2                 TO L0290-PRECISION
013693*        MOVE LENGTH OF MIR-CF-PROV-TAXWH-AMT
013693*                               TO L0290-MAX-OUT-LEN
013693*        PERFORM  0290-1000-NUMERIC-FORMAT
013693*            THRU 0290-1000-NUMERIC-FORMAT-X
013693*        MOVE L0290-OUTPUT-DATA TO MIR-CF-PROV-TAXWH-AMT
013693*        MOVE L0290-OUTPUT-DATA TO E0761-PROV-WITHHELD-R
013693*        MOVE ZERO              TO E0761-PROV-WITHHELD
013693*        MOVE ZERO              TO WS-HOLD-PROV-WITHHELD
013693*        GO TO 8060-EDIT-P-TAX-AMT-X
013693*    END-IF.
013693*
013693*    MOVE 'N'                   TO L0280-SIGN-IND.
013693*    MOVE 2                     TO L0280-PRECISION.
013693*    MOVE LENGTH OF MIR-CF-PROV-TAXWH-AMT
013693*                               TO L0280-INPUT-SIZE.
013693*    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
013693*                           L0280-PRECISION - 1.
013693*    MOVE MIR-CF-PROV-TAXWH-AMT TO L0280-INPUT-DATA.
013693*
013693*    PERFORM  0280-1000-NUMERIC-EDIT
013693*        THRU 0280-1000-NUMERIC-EDIT-X.
013693*    IF  L0280-OK
013693*        MOVE L0280-OUTPUT-DOLLAR
013693*                               TO E0761-PROV-WITHHELD
013693*        MOVE L0280-OUTPUT-DOLLAR
013693*                               TO WS-HOLD-PROV-WITHHELD
013693*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
013693*        MOVE 2                 TO L0290-PRECISION
013693*        MOVE LENGTH OF MIR-CF-PROV-TAXWH-AMT
013693*                               TO L0290-MAX-OUT-LEN
013693*        PERFORM  0290-1000-NUMERIC-FORMAT
013693*            THRU 0290-1000-NUMERIC-FORMAT-X
013693*        MOVE L0290-OUTPUT-DATA TO MIR-CF-PROV-TAXWH-AMT
013693*        MOVE L0290-OUTPUT-DATA TO E0761-PROV-WITHHELD-R
013693*    ELSE
013693*MSG: PROVINCIAL TAX WITHHELD MUST BE NUMERIC
013693*        MOVE 'CS07610035'      TO WGLOB-MSG-REF-INFO
013693*        PERFORM  0260-1000-GENERATE-MESSAGE
013693*            THRU 0260-1000-GENERATE-MESSAGE-X
013693*        SET WGLOB-RETURN-ERROR TO TRUE
013693*    END-IF.
013693*
013693*8060-EDIT-P-TAX-AMT-X.
013693*    EXIT.

      *------------------------
       8070-EDIT-SUPPRES-CNFRM.
      *------------------------
      *
      * CHECK FOR VALID ENTRY FOR SUPPRESS CONFIRMATION.
      *

           IF  MIR-SUPRES-CNFRM-IND = SPACES
               MOVE 'N'               TO MIR-SUPRES-CNFRM-IND
               GO TO 8070-EDIT-SUPPRES-CNFRM-X
           END-IF.

           IF MIR-SUPRES-CNFRM-IND NOT = 'Y'
           AND MIR-SUPRES-CNFRM-IND NOT = 'N'
      *MSG: SUPPRESS CONFIRMATION NOT VALID. ENTER 'Y' OR 'N'
               MOVE 'CS07610051'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       8070-EDIT-SUPPRES-CNFRM-X.
           EXIT.

013693*---------------------
031034*8080-EDIT-LOCATION-TAX.
013693*-----------------------
013693
031034**   IF  MIR-LTAXWH-CALC-CD = SPACES
031034**   OR  MIR-LTAXWH-CALC-CD = '*'
031034**       MOVE 'C'               TO  MIR-LTAXWH-CALC-CD
031034**   END-IF.

031034**   MOVE MIR-LTAXWH-CALC-CD    TO  E0761-LTAXWH-CALC-CD.
031034**   MOVE MIR-LTAXWH-CALC-CD    TO  WS-LTAXWH-CALC-CD.

031034**   IF  NOT E0761-LTAXWH-CALC-VALID
013693* MSG:  INVALID TAX WITHHOLD CALCULATION CODE
031034**       MOVE 'CS07610048'       TO WGLOB-MSG-REF-INFO
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR  TO TRUE
031034**       GO TO 8080-EDIT-LOCATION-TAX-X
031034**   END-IF.
013693
031034**   IF  MIR-LTAXWH-FLAT-AMT = SPACE
031034**       MOVE ZEROES            TO MIR-LTAXWH-FLAT-AMT
031034**   END-IF.
013693
031034**   IF  MIR-LTAXWH-PCT = SPACE
031034**        MOVE ZEROES           TO MIR-LTAXWH-PCT
031034**   END-IF.
013693
031034**   MOVE 'N'               TO L0280-SIGN-IND.
031034**   MOVE 2                 TO L0280-PRECISION.
031034**   MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
031034**                          TO L0280-INPUT-SIZE.
031034**   COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
031034**                           L0280-PRECISION - 1.
031034**   MOVE MIR-LTAXWH-FLAT-AMT  TO L0280-INPUT-DATA.
031034**   PERFORM  0280-1000-NUMERIC-EDIT
031034**       THRU 0280-1000-NUMERIC-EDIT-X.
031034**   IF  L0280-OK
031034**       MOVE L0280-OUTPUT-DOLLAR
031034**                          TO E0761-CF-LTAXWH-AMT
023437*        MOVE L0280-OUTPUT-DOLLAR
023437*                           TO WS-HOLD-CF-LTAXWH-AMT
031034**       MOVE L0280-OUTPUT      TO WS-LTAXWH-FLAT-AMT
031034**       MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
031034**       MOVE 2                 TO L0290-PRECISION
031034**       MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
031034**                              TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
031034**       PERFORM  0290-2000-FORMAT-FOR-MIR
031034**           THRU 0290-2000-FORMAT-FOR-MIR-X
031034**       MOVE L0290-OUTPUT-DATA TO MIR-LTAXWH-FLAT-AMT
031034**   ELSE
013693*MSG: LOCATION TAX WITHHELD MUST BE NUMERIC
031034**       MOVE 'CS07610041'      TO WGLOB-MSG-REF-INFO
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR       TO TRUE
031034**       MOVE ZERO          TO E0761-CF-LTAXWH-AMT
023437*        MOVE ZERO          TO WS-HOLD-CF-LTAXWH-AMT
031034**   END-IF.
013693
031034**   MOVE 'N'                   TO L0280-SIGN-IND.
031034**   MOVE 2                     TO L0280-PRECISION.
031034**   MOVE LENGTH OF MIR-LTAXWH-PCT
031034**                              TO L0280-INPUT-SIZE.
031034**   COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
031034**                          L0280-PRECISION - 1.
031034**   MOVE MIR-LTAXWH-PCT TO L0280-INPUT-DATA.
031034**   PERFORM  0280-1000-NUMERIC-EDIT
031034**       THRU 0280-1000-NUMERIC-EDIT-X.
031034**   IF  L0280-OK
031034**   AND L0280-OUTPUT <= 10000
031034**       MOVE L0280-OUTPUT-DOLLAR  TO E0761-LTAXWH-PCT
031034**       MOVE L0280-OUTPUT-DOLLAR  TO WS-LTAXWH-PCT
031034**       MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
031034**       MOVE 2                 TO L0290-PRECISION
031034**       MOVE LENGTH OF MIR-LTAXWH-PCT
031034**                              TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
031034**       PERFORM  0290-2000-FORMAT-FOR-MIR
031034**           THRU 0290-2000-FORMAT-FOR-MIR-X
031034**       MOVE L0290-OUTPUT-DATA TO MIR-LTAXWH-PCT
031034**   ELSE
013693*MSG: LOCATION TAX % MUST BE NUMERIC
031034**       MOVE 'CS07610044'      TO WGLOB-MSG-REF-INFO
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR       TO TRUE
031034**       MOVE ZERO                    TO E0761-LTAXWH-PCT
031034**   END-IF.
013693
031034**   IF  E0761-CF-LTAXWH-AMT NOT = ZEROS
031034**   AND E0761-LTAXWH-PCT    NOT = ZEROS
013693*MSG: LOCATION AMOUNT AND LOCATION PERCENT CANNOT BE BOTH ENTERED
031034**       MOVE 'CS07610045'                TO WGLOB-MSG-REF-INFO
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR           TO TRUE
031034**   END-IF.
013693
031034**   IF  MIR-LTAXWH-CALC-CD = 'C'
031034**   OR  MIR-LTAXWH-CALC-CD = SPACES
031034**   OR  MIR-LTAXWH-CALC-CD = 'B'
031034**       IF  E0761-CF-LTAXWH-AMT NOT = ZEROS
031034**       OR  E0761-LTAXWH-PCT    NOT = ZEROS
013693*MSG: LOCATION AMOUNT OR PERCENT CANNOT BE FILLED IF OVERRIDE
013693*     INDICATOR IS OFF
031034**           MOVE 'CS07610046'            TO WGLOB-MSG-REF-INFO
031034**           PERFORM  0260-1000-GENERATE-MESSAGE
031034**               THRU 0260-1000-GENERATE-MESSAGE-X
031034**           SET WGLOB-RETURN-ERROR       TO TRUE
031034**      END-IF
031034**   END-IF.
013693
031034**   IF  MIR-LTAXWH-CALC-CD = 'S'
031034**   AND MIR-DV-PRCES-STATE-CD = '1'
031034**       IF E0761-LTAXWH-PCT    NOT = ZERO
031034**       OR E0761-CF-LTAXWH-AMT NOT = ZERO
031034**          CONTINUE
013693*MSG: LOCATION AMOUNT OR % NEED TO FILL IF OVERRIDE INDICATOR
031034**       ELSE
031034**           MOVE 'CS07610047'            TO WGLOB-MSG-REF-INFO
031034**           PERFORM  0260-1000-GENERATE-MESSAGE
031034**               THRU 0260-1000-GENERATE-MESSAGE-X
031034**           SET WGLOB-RETURN-ERROR       TO TRUE
031034**       END-IF
031034**   END-IF.
013693
031034**   IF  MIR-LTAXWH-CALC-CD = 'S'
031034**   AND MIR-DV-PRCES-STATE-CD = '2'
031034**   AND (WS-BUS-FCN-SURR-NON-SPEC
031034**   OR  WS-BUS-FCN-FULL-GIA-SURR
031034**   OR  WS-BUS-FCN-PARTL-GIA-SURR)
031034**       IF E0761-LTAXWH-PCT    NOT = ZERO
031034**       OR E0761-CF-LTAXWH-AMT NOT = ZERO
031034**          CONTINUE
013693*MSG: LOCATION AMOUNT OR % NEED TO FILL IF OVERRIDE INDICATOR
031034**       ELSE
031034**           MOVE 'CS07610047'            TO WGLOB-MSG-REF-INFO
031034**           PERFORM  0260-1000-GENERATE-MESSAGE
031034**               THRU 0260-1000-GENERATE-MESSAGE-X
031034**           SET WGLOB-RETURN-ERROR       TO TRUE
031034**       END-IF
031034**   END-IF.
013693
018846*    IF  WS-BUS-FCN-PARTL-GIA-SURR
018846*    OR  WS-BUS-FCN-SURR-FND-BY-UNIT
018846*    OR  WS-BUS-FCN-FULL-GIA-SURR
018846*         CONTINUE
018846*    ELSE
018846*        IF  E0761-CF-LTAXWH-AMT > E0761-AMOUNT
018846*MSG: LOCATION AMOUNT CAN NOT BE MORE THAT GROSS DISTRIBUTION
018846*            MOVE 'CS07610055'            TO WGLOB-MSG-REF-INFO
018846*            PERFORM  0260-1000-GENERATE-MESSAGE
018846*                THRU 0260-1000-GENERATE-MESSAGE-X
018846*            SET WGLOB-RETURN-ERROR       TO TRUE
018846*        END-IF
018846*    END-IF.
018846*
031034*8080-EDIT-LOCATION-TAX-X.
031034**   EXIT.
023437
031034*8090-EDIT-FED-TAXWH-RQST.
023437
031034**   IF MIR-FED-TAXWH-CALC-CD = SPACES
031034**   OR MIR-FED-TAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
031034**       MOVE 'C'               TO MIR-FED-TAXWH-CALC-CD
031034**   END-IF.
023437
031034**   MOVE MIR-FED-TAXWH-CALC-CD TO E0761-FED-TAXWH-CALC-CD.
031034**   MOVE MIR-FED-TAXWH-CALC-CD TO WS-FED-TAXWH-CALC-CD.
023437
031034**   IF E0761-LTAXWH-CALC-VALID
031034**       CONTINUE
031034**   ELSE
023437* MSG FEDERAL TAX CALC OPTION MUST CONTAIN VALUES 'B', 'C' OR 'S'
031034**       MOVE 'CS07610060'      TO WGLOB-MSG-REF-INFO
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR       TO TRUE
031034**   END-IF.
023437
031034**   IF MIR-FED-TAXWH-RQST-AMT = SPACES
031034**       MOVE ZERO              TO MIR-FED-TAXWH-RQST-AMT
031034**   END-IF.
023437
031034**   MOVE MIR-FED-TAXWH-RQST-AMT  TO L0280-INPUT-DATA.
031034**   SET L0280-SIGN-NOT-PERMITTED TO TRUE.
031034**   MOVE 13                    TO L0280-LENGTH.
031034**   MOVE 2                     TO L0280-PRECISION.
031034**   MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT  TO L0280-INPUT-SIZE.
031034**   PERFORM  0280-1000-NUMERIC-EDIT
031034**       THRU 0280-1000-NUMERIC-EDIT-X.
023437
031034**   IF L0280-OK
031034**       MOVE L0280-OUTPUT-V02  TO E0761-FED-TAXWH-RQST-AMT
031034**       MOVE L0280-OUTPUT-V02  TO WS-FED-TAXWH-RQST-AMT
031034**       MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
031034**       MOVE  2                TO L0290-PRECISION
031034**       MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
031034**                              TO L0290-MAX-OUT-LEN
031034**       PERFORM 0290-2000-FORMAT-FOR-MIR
031034**          THRU 0290-2000-FORMAT-FOR-MIR-X
031034**       MOVE L0290-OUTPUT-DATA TO MIR-FED-TAXWH-RQST-AMT
031034**   ELSE
023437* MESSAGE - INVALID FEDERAL TAX REQUEST AMOUNT
031034**       MOVE 'CS07610061'      TO WGLOB-MSG-REF-INFO
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR       TO TRUE
031034**   END-IF.
023437
031034**   IF MIR-FED-TAXWH-RQST-PCT = SPACES
031034**       MOVE ZERO              TO MIR-FED-TAXWH-RQST-PCT
031034**   END-IF.
023437
031034**   MOVE MIR-FED-TAXWH-RQST-PCT       TO L0280-INPUT-DATA.
031034**   SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
031034**   MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT TO L0280-INPUT-SIZE.
031034**   MOVE L0280-INPUT-SIZE             TO L0280-LENGTH.
031034**   MOVE 2                            TO L0280-PRECISION.
031034**   PERFORM  0280-1000-NUMERIC-EDIT
031034**       THRU 0280-1000-NUMERIC-EDIT-X.
031034**   IF L0280-OK
031034**       MOVE L0280-OUTPUT-V02         TO E0761-FED-TAXWH-RQST-PCT
031034**       MOVE L0280-OUTPUT-V02         TO WS-FED-TAXWH-RQST-PCT
031034**       MOVE L0280-OUTPUT-V02         TO L0290-INPUT-V02
031034**       MOVE  2                       TO L0290-PRECISION
031034**       MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
031034**                                     TO L0290-MAX-OUT-LEN
031034**       PERFORM 0290-2000-FORMAT-FOR-MIR
031034**          THRU 0290-2000-FORMAT-FOR-MIR-X
031034**       MOVE L0290-OUTPUT-DATA     TO MIR-FED-TAXWH-RQST-PCT
031034**       IF E0761-FED-TAXWH-RQST-PCT > 100
031034**       OR E0761-FED-TAXWH-RQST-PCT < ZERO
023437* MESSAGE - INVALID FEDERAL TAX REQUEST %
031034**           MOVE 'CS07610062'        TO WGLOB-MSG-REF-INFO
031034**           PERFORM  0260-1000-GENERATE-MESSAGE
031034**               THRU 0260-1000-GENERATE-MESSAGE-X
031034**           SET WGLOB-RETURN-ERROR       TO TRUE
031034**       END-IF
031034**   ELSE
023437* MESSAGE - INVALID FEDERAL TAX REQUEST % - REENTER
031034**       MOVE 'CS07610062'      TO WGLOB-MSG-REF-INFO
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR       TO TRUE
031034**   END-IF.
023437*
023437* CALL THE FEDERAL TAX EDIT REGIONAL EXIT FOR EDITS
023437*
031034**   PERFORM  0316-1000-BUILD-PARM-INFO
031034**       THRU 0316-1000-BUILD-PARM-INFO-X.
023437
031034**   SET L0316-RGN-EXIT-TAXWH-CLI-EDITS   TO TRUE.
023437
031034**   MOVE RPOL-POL-CTRY-CD      TO L0316-CTRY-CD.
023437
031034**   PERFORM  0316-1000-GET-RGN-EXIT-PGM
031034**       THRU 0316-1000-GET-RGN-EXIT-PGM-X.
023437
031034**   IF  NOT L0316-RETRN-OK
031034**   OR  L0316-RGN-EXIT-STAT-INACTV
023437*MSG: 'NO FEDERAL TAX EXIT REGIONAL EXIT FOUND FOR COUNTRY @1'
031034**       MOVE 'CS07610063'       TO WGLOB-MSG-REF-INFO
031034**       MOVE L0316-CTRY-CD      TO WGLOB-MSG-PARM (1)
031034**       PERFORM  0260-1000-GENERATE-MESSAGE
031034**           THRU 0260-1000-GENERATE-MESSAGE-X
031034**       SET WGLOB-RETURN-ERROR       TO TRUE
031034**       GO TO 8090-EDIT-FED-TAXWH-RQST-X
031034**   END-IF.
023437
023437* AN ACTIVE REGION EXIT IS HELD. THIS MUST BE PERFORMED FIRST TO
023437* CARRY OUT EDITS FOR FEDERAL TAX WITHHOLDING DATA.
023437
031034**   PERFORM  TAXC-1000-BUILD-PARM-INFO
031034**       THRU TAXC-1000-BUILD-PARM-INFO-X.
023437
031034**   SET LTAXC-RGN-EXIT-TAXWH-CLI-EDITS   TO TRUE.
023437
031034**   MOVE WS-CF-REC-DATE           TO LTAXC-EFF-DT.
031034**   MOVE MIR-POL-ID               TO LTAXC-POL-ID.
031034**   MOVE E0761-FED-TAXWH-CALC-CD  TO LTAXC-FED-TAXWH-CALC-CD.
031034**   MOVE E0761-FED-TAXWH-RQST-AMT TO LTAXC-FED-TAXWH-RQST-AMT.
031034**   MOVE E0761-FED-TAXWH-RQST-PCT TO LTAXC-FED-TAXWH-RQST-PCT.
031034**   MOVE E0761-LTAXWH-CALC-CD     TO LTAXC-LTAXWH-CALC-CD.
031034**   MOVE E0761-CF-LTAXWH-AMT      TO LTAXC-LTAXWH-FLAT-AMT.
031034**   MOVE E0761-LTAXWH-PCT         TO LTAXC-LTAXWH-PCT.
023437
031034**   PERFORM  TAXC-1000-TAXWH-CLI-EDIT
031034**       THRU TAXC-1000-TAXWH-CLI-EDIT-X.
023437
031034**   IF  LTAXC-EDIT-ERROR
031034**   OR  NOT LTAXC-RETRN-OK
031034**       SET WGLOB-RETURN-ERROR       TO TRUE
031034**       GO TO 8090-EDIT-FED-TAXWH-RQST-X
031034**   END-IF.
023437
031034*8090-EDIT-FED-TAXWH-RQST-X.
031034**   EXIT.
      *
      *--------------------
       8100-INIT-PARM-AREA.
      *--------------------
      *
      * SET UP THE INPUT PARAMETERS FOR CSLF1010 USING THE
      * E0761 WORK AREA
      *
           MOVE E0761-CVG-NUM         TO L1010-CVG.
           IF WS-BUS-FCN-GIA-SURR
               MOVE E0761-GIA-SUR-DT  TO L1010-EFF-DT
           ELSE
               MOVE E0761-CF-DT       TO L1010-EFF-DT
           END-IF.
           MOVE E0761-SEQ-NUM         TO L1010-SEQ.
           MOVE E0761-TRANS           TO L1010-TRANS.
           MOVE E0761-REASON          TO L1010-REASON.
           IF E0761-AMOUNT-R NOT = SPACES
               MOVE E0761-AMOUNT      TO L1010-AMOUNT
           END-IF.
           IF E0761-UNITS-R NOT = SPACES
               MOVE E0761-UNITS       TO L1010-UNITS
           END-IF.
           MOVE E0761-CF-DT           TO L1010-CF-REC-DATE.
023437*    IF E0761-WITHHELD-R NOT = SPACES
023437*        MOVE E0761-WITHHELD    TO L1010-TAX-WITHHELD
023437*    END-IF.
013693*    IF E0761-PROV-WITHHELD-R NOT = SPACES
013693*        MOVE E0761-PROV-WITHHELD
013693*                               TO L1010-PROV-TAX-WITHHELD
013693*    END-IF.
023437*    MOVE E0761-OVERRIDE        TO L1010-TAX-OVERRIDE.
           MOVE E0761-AFR-THRSHD-IND  TO L1010-FA-REDN-IND.
           MOVE WGLOB-USER-ID         TO L1010-INIT-HOLDER.
           MOVE 'Y'                   TO L1010-DISPLAY-SEQ-SW.
           MOVE 'Y'                   TO L1010-BAL-ACCTG-SW.
           MOVE 'N'                   TO L1010-DEPOSIT-MODE.
023437*    SET L1010-PRCES-PLGR-EDITS-YES TO TRUE.
013131     MOVE WS-INT-RATE-CHG-SW    TO L1010-INT-RATE-CHG-SW.

023437*    IF  E0761-CF-LTAXWH-AMT-R NOT = SPACES
023437*        MOVE E0761-CF-LTAXWH-AMT   TO L1010-LTAXWH-FLAT-AMT
023437*    END-IF.

023437*    MOVE E0761-LTAXWH-CALC-CD        TO L1010-LTAXWH-CALC-CD.
023437*    SET  L1010-LTAXWH-DISB-NONP      TO TRUE.
023437*    IF E0761-LTAXWH-PCT-R NOT = SPACES
023437*       MOVE E0761-LTAXWH-PCT          TO L1010-LTAXWH-PCT
023437*    END-IF.

015290     SET L1010-TRXN-WTHDR              TO TRUE.
023437     SET L1010-TAXWH-ACTV-PRCES-NO     TO TRUE.

       8100-INIT-PARM-AREA-X.
           EXIT.
      *
      *-----------------------
       8200-MOVE-CF-TO-SCREEN.
      *-----------------------

           IF WS-BUS-FCN-GIA-SURR
               MOVE WS-CF-REC-DATE TO L1640-INTERNAL-DATE
           ELSE
557659         MOVE RCFLW-CF-EFF-DT   TO L1640-INTERNAL-DATE
           END-IF.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DV-CF-EFF-DT.

           IF WS-BUS-FCN-SURR-NON-SPEC
               MOVE ZEROS             TO WS-EDIT-3A
           ELSE
               IF WS-BUS-FCN-GIA-SURR
020874*            MOVE WS-CF-SEQ-NUM
020874*                               TO WS-EDIT-3A
020874             MOVE WS-CF-SEQ-NUM TO L0290-INPUT-V00
               ELSE
020874*            MOVE RCFLW-CF-SEQ-NUM-N
020874*                               TO WS-EDIT-3A
020874             MOVE RCFLW-CF-SEQ-NUM-N TO L0290-INPUT-V00
               END-IF
           END-IF.
020874*    MOVE WS-EDIT-3A            TO MIR-CF-SEQ-NUM.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CF-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CF-SEQ-NUM.
      *LINE 1
           MOVE RCFLW-CF-STAT-CD      TO MIR-CF-STAT-CD.
           MOVE RCFLW-CF-TRXN-CD      TO MIR-CF-TRXN-CD.
           MOVE RCFLW-CF-REASN-CD     TO MIR-CF-REASN-CD.
           MOVE RCFLW-CF-REG-FND-SRC-CD
                                      TO MIR-CF-REG-FND-SRC-CD.
020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-CLI-TRXN-AMT * 100.
020874     MOVE RCFLW-CF-CLI-TRXN-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-CLI-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-CLI-TRXN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-FND-TRXN-AMT * 100.
020874     MOVE RCFLW-CF-FND-TRXN-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-FND-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-FND-TRXN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-FND-BAL-AMT * 100.
020874     MOVE RCFLW-CF-FND-BAL-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-FND-BAL-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-FND-BAL-AMT.

020874*    MOVE RCFLW-CF-INT-PCT      TO WS-EDIT-3V4.
020874*    MOVE WS-EDIT-3V4           TO MIR-CF-INT-PCT.
020874     MOVE RCFLW-CF-INT-PCT      TO L0290-INPUT-V04.
020874     MOVE 4                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CF-INT-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CF-INT-PCT.
           MOVE RCFLW-CF-EFF-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CF-EFF-DT.
      *LINE 2
           MOVE RCFLW-CF-PRCES-DT     TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CF-PRCES-DT.
           MOVE RCFLW-CF-REVRS-PRCES-DT
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CF-REVRS-PRCES-DT.
           MOVE RCFLW-CF-ORIG-LF-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CF-ORIG-LF-DT.
           MOVE RCFLW-PAYO-CLUST-CF-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-PAYO-CLUST-CF-DT.
020874*    MOVE RCFLW-CLUST-CF-SEQ-NUM-N
020874*                               TO WS-EDIT-3A.
020874*    MOVE WS-EDIT-3A            TO MIR-CLUST-CF-SEQ-NUM.
020874     MOVE RCFLW-CLUST-CF-SEQ-NUM-N  TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLUST-CF-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CLUST-CF-SEQ-NUM.
           MOVE RCFLW-NXT-CF-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-NXT-CF-DT.
020874*    MOVE RCFLW-NXT-CF-SEQ-NUM-N TO WS-EDIT-3A.
020874*    MOVE WS-EDIT-3A            TO MIR-NXT-CF-SEQ-NUM.
020874     MOVE RCFLW-NXT-CF-SEQ-NUM-N TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-NXT-CF-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-NXT-CF-SEQ-NUM.
           MOVE RCFLW-PREV-CF-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-CF-DT.
020874*    MOVE RCFLW-PREV-CF-SEQ-NUM-N
020874*                               TO WS-EDIT-3A.
020874*    MOVE WS-EDIT-3A            TO MIR-PREV-CF-SEQ-NUM.
020874     MOVE RCFLW-PREV-CF-SEQ-NUM-N TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-PREV-CF-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-PREV-CF-SEQ-NUM.
      *LINE 3
017150*    COMPUTE WS-WORK-13V2S ROUNDED = RCFLW-INT-TO-NXT-CF-AMT.
017150     COMPUTE L0279-CRCY-AMT = RCFLW-INT-TO-NXT-CF-AMT.
017150     PERFORM  0279-1000-CRCY-RND
017150         THRU 0279-1000-CRCY-RND-X.
017150     MOVE L0279-CRCY-AMT  TO WS-WORK-13V2S.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-WORK-13V2S * 100.
020874     MOVE WS-WORK-13V2S         TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-INT-TO-NXT-CF-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-INT-TO-NXT-CF-AMT.

017150*    COMPUTE WS-WORK-13V2S ROUNDED = RCFLW-CF-ACUM-INT-AMT.
017150     COMPUTE L0279-CRCY-AMT = RCFLW-CF-ACUM-INT-AMT.
017150     PERFORM  0279-1000-CRCY-RND
017150         THRU 0279-1000-CRCY-RND-X.
017150     MOVE L0279-CRCY-AMT  TO WS-WORK-13V2S.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-WORK-13V2S * 100.
020874     MOVE WS-WORK-13V2S         TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-ACUM-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-ACUM-INT-AMT.

           MOVE RCFLW-CF-INT-PAYO-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CF-INT-PAYO-DT.
           MOVE RCFLW-ROLOVR-CF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-ROLOVR-CF-DT.
020874*    MOVE RCFLW-XFER-CF-SEQ-NUM-N
020874*                               TO WS-EDIT-3A.
020874*    MOVE WS-EDIT-3A            TO MIR-XFER-CF-SEQ-NUM.
020874     MOVE RCFLW-XFER-CF-SEQ-NUM-N TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-XFER-CF-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-XFER-CF-SEQ-NUM.
           MOVE RCFLW-XFER-CVG-NUM-N  TO MIR-XFER-CVG-NUM.
023112
023112     COMPUTE L0290-INPUT-V00    =  100000
023112                                -  RCFLW-CF-ROLOVR-PAYO-NUM.
023112     MOVE ZERO                  TO L0290-PRECISION.
023112     MOVE LENGTH OF MIR-CF-ROLOVR-PAYO-NUM
023112                                TO L0290-MAX-OUT-LEN.
023112     PERFORM 0290-2000-FORMAT-FOR-MIR
023112        THRU 0290-2000-FORMAT-FOR-MIR-X.
023112     MOVE L0290-OUTPUT-DATA     TO MIR-CF-ROLOVR-PAYO-NUM.
023112
020874*    SUBTRACT RCFLW-SRC-CDA-SEQ-NUM FROM 1000 GIVING WS-EDIT-3A.
020874*    MOVE WS-EDIT-3A            TO MIR-SRC-CDA-SEQ-NUM.
020874     COMPUTE L0290-INPUT-V00  = 1000 -  RCFLW-SRC-CDA-SEQ-NUM.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-SRC-CDA-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-SRC-CDA-SEQ-NUM.
           MOVE RCFLW-SRC-CVG-NUM     TO MIR-SRC-CVG-NUM.
020874*    SUBTRACT RCFLW-DEST-CDA-SEQ-NUM FROM 1000 GIVING WS-EDIT-3A.
020874*    MOVE WS-EDIT-3A            TO MIR-DEST-CDA-SEQ-NUM.
020874     COMPUTE L0290-INPUT-V00  = 1000  - RCFLW-DEST-CDA-SEQ-NUM.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-DEST-CDA-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-DEST-CDA-SEQ-NUM.
           MOVE RCFLW-CF-DPOS-TRM-MO-DUR-N
                                      TO MIR-CF-DPOS-TRM-MO-DUR.
           MOVE RCFLW-CF-DPOS-TRM-DY-DUR-N
                                      TO MIR-CF-DPOS-TRM-DY-DUR.
           MOVE RCFLW-NXT-LF-CF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-NXT-LF-CF-DT.
020874*    MOVE RCFLW-NXT-LF-CF-SEQ-NUM-N
020874*                               TO WS-EDIT-3A.
020874*    MOVE WS-EDIT-3A            TO MIR-NXT-LF-CF-SEQ-NUM.
020874     MOVE RCFLW-NXT-LF-CF-SEQ-NUM-N  TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-NXT-LF-CF-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-NXT-LF-CF-SEQ-NUM.
020874*    MOVE RCFLW-CF-TAX-YR       TO WS-EDIT-4.
020874*    MOVE WS-EDIT-4             TO MIR-CF-TAX-YR.
020874     MOVE RCFLW-CF-TAX-YR       TO L0290-INPUT-V00.
020874     MOVE 4                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CF-TAX-YR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CF-TAX-YR.
      *LINE 4
005193*    MOVE RCFLW-CF-UNIT-QTY     TO WS-EDIT-8V5S.
005193     MOVE RCFLW-CF-UNIT-QTY     TO WS-EDIT-12V5S.
005193*    MOVE WS-EDIT-8V5S          TO MIR-CF-UNIT-QTY.
005193     MOVE WS-EDIT-12V5S         TO MIR-CF-UNIT-QTY.
           MOVE RCFLW-UNIT-PRIC-ESTB-IND
                                      TO MIR-UNIT-PRIC-ESTB-IND.
           MOVE RCFLW-CF-EQTY-GLA-IND TO MIR-CF-EQTY-GLA-IND.
020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-TAX-GAIN-AMT * 100.
020874     MOVE RCFLW-CF-TAX-GAIN-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-TAX-GAIN-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-TAX-GAIN-AMT.

017150*    COMPUTE WS-WORK-13V2S ROUNDED = RCFLW-CF-SURR-CHRG-AMT.
017150     COMPUTE WS-WORK-13V2S         = RCFLW-CF-SURR-CHRG-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-WORK-13V2S * 100.
020874     MOVE WS-WORK-13V2S         TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-SURR-CHRG-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-SURR-CHRG-AMT.

017150*    COMPUTE WS-WORK-13V2S ROUNDED = RCFLW-CF-MKTVAL-ADJ-AMT.
017150     COMPUTE WS-WORK-13V2S         = RCFLW-CF-MKTVAL-ADJ-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-WORK-13V2S * 100.
020874     MOVE WS-WORK-13V2S         TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-MKTVAL-ADJ-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY         TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-MKTVAL-ADJ-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-TOT-SURR-AMT * 100.
020874     MOVE RCFLW-CF-TOT-SURR-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-TOT-SURR-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY         TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-TOT-SURR-AMT.

020874*    MOVE RCFLW-CONN-CF-SEQ-NUM-N
020874*                               TO WS-EDIT-3A.
020874*    MOVE WS-EDIT-3A            TO MIR-CONN-CF-SEQ-NUM.
020874     MOVE RCFLW-CONN-CF-SEQ-NUM-N  TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CONN-CF-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CONN-CF-SEQ-NUM.
      *LINE 5
           MOVE RCFAG-AGT-ID (1)      TO MIR-AGT-1-ID-T (1).
           MOVE RCFAG-COMM-RT-TBAC-ID (1)
                                      TO MIR-COMM-RT-TBAC-1-ID-T (1).
           MOVE RCFAG-OVRID-ID  (1)   TO MIR-OVRID-1-ID-T (1).
020874*    MOVE RCFAG-CFAGT-SHR-PCT (1)
020874*                               TO WS-EDIT-3V2.
020874*    MOVE WS-EDIT-3V2           TO MIR-CFAGT-SHR-1-PCT-T (1).
020874     MOVE RCFAG-CFAGT-SHR-PCT (1) TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CFAGT-SHR-1-PCT-T (1)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CFAGT-SHR-1-PCT-T (1).
020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-CPREM-AMT (1) * 100.
020874     MOVE RCFLW-CF-CPREM-AMT (1) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-CPREM-1-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY         TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-CPREM-1-AMT-T (1).

020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-LOAN-IMPRD-AMT * 100.
020874     MOVE RCFLW-CF-LOAN-IMPRD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-LOAN-IMPRD-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY         TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-LOAN-IMPRD-AMT.

           COMPUTE WS-EDIT-3V4 = RCFLW-LOAN-IMPRD-INT-RT * 100.
           MOVE WS-EDIT-3V4           TO MIR-LOAN-IMPRD-INT-RT.
           MOVE RCFLW-CF-7702-DECR-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CF-7702-DECR-DT.
      *LINE 6
           MOVE RCFAG-AGT-ID (2)      TO MIR-AGT-1-ID-T (2).
           MOVE RCFAG-COMM-RT-TBAC-ID (2)
                                      TO MIR-COMM-RT-TBAC-1-ID-T (2).
           MOVE RCFAG-OVRID-ID  (2)   TO MIR-OVRID-1-ID-T (2).
020874*    MOVE RCFAG-CFAGT-SHR-PCT (2)
020874*                               TO WS-EDIT-3V2.
020874*    MOVE WS-EDIT-3V2           TO MIR-CFAGT-SHR-1-PCT-T (2).
020874     MOVE RCFAG-CFAGT-SHR-PCT (2) TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CFAGT-SHR-1-PCT-T (2)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CFAGT-SHR-1-PCT-T (2).
020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-CPREM-AMT (2) * 100.
020874     MOVE RCFLW-CF-CPREM-AMT (2) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-CPREM-1-AMT-T (2)
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY         TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-CPREM-1-AMT-T (2).

      *LINE 7
           MOVE RCFAG-AGT-ID (3)      TO MIR-AGT-1-ID-T (3).
           MOVE RCFAG-COMM-RT-TBAC-ID (3)
                                      TO MIR-COMM-RT-TBAC-1-ID-T (3).
           MOVE RCFAG-OVRID-ID  (3)   TO MIR-OVRID-1-ID-T (3).
020874*    MOVE RCFAG-CFAGT-SHR-PCT (3)
020874*                               TO WS-EDIT-3V2.
020874*    MOVE WS-EDIT-3V2           TO MIR-CFAGT-SHR-1-PCT-T (3).
020874     MOVE RCFAG-CFAGT-SHR-PCT (3)  TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CFAGT-SHR-1-PCT-T (3)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CFAGT-SHR-1-PCT-T (3).
020874*    COMPUTE L0290-INPUT-NUMBER = RCFLW-CF-CPREM-AMT (3) * 100.
020874     MOVE RCFLW-CF-CPREM-AMT (3) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CF-CPREM-1-AMT-T (3)
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY         TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CF-CPREM-1-AMT-T (3).

       8200-MOVE-CF-TO-SCREEN-X.
           EXIT.
      *
      *------------------
       8300-FINALIZE-MAP.
      *------------------
      *
      * FINALIZE THE MAP
      *
           IF WS-BUS-FCN-SURR-FND-BY-FND
               SET WS-MAP-FINALIZED-NO TO TRUE
               PERFORM  8800-FINALIZE-FUND-MAP
                   THRU 8800-FINALIZE-FUND-MAP-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL   WS-LINE > WS-MAX-FUND-LINES
                   OR      WS-MAP-FINALIZED
           ELSE
               PERFORM  8200-MOVE-CF-TO-SCREEN
                   THRU 8200-MOVE-CF-TO-SCREEN-X
           END-IF.

031034**   MOVE WS-FED-TAXWH-CALC-CD  TO MIR-FED-TAXWH-CALC-CD.
029060*    MOVE LTAXC-FED-TAXWH-CALC-CD TO MIR-FED-TAXWH-CALC-CD.
029060     MOVE LTAXC-FTAXWH-RQST-CD    TO MIR-FTAXWH-RQST-CD.
023437
031034**   MOVE WS-FED-TAXWH-RQST-AMT TO L0290-INPUT-V02.
029060*    MOVE LTAXC-FED-TAXWH-RQST-AMT TO L0290-INPUT-V02.
029060     MOVE LTAXC-FTAXWH-RQST-AMT    TO L0290-INPUT-V02.
023437     MOVE 2                     TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-AMT    TO L0290-MAX-OUT-LEN.
023437     PERFORM  0290-2000-FORMAT-FOR-MIR
023437         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA     TO MIR-FED-TAXWH-RQST-AMT.
029060     MOVE L0290-OUTPUT-DATA     TO MIR-FTAXWH-RQST-AMT.
023437
031034**   MOVE WS-FED-TAXWH-RQST-PCT TO L0290-INPUT-V02.
029060*    MOVE LTAXC-FED-TAXWH-RQST-PCT TO L0290-INPUT-V02.
029060     MOVE LTAXC-FTAXWH-RQST-PCT    TO L0290-INPUT-V02.
023437     MOVE 2                     TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-PCT    TO L0290-MAX-OUT-LEN.
023437     PERFORM  0290-2000-FORMAT-FOR-MIR
023437         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA     TO MIR-FED-TAXWH-RQST-PCT.
029060     MOVE L0290-OUTPUT-DATA     TO MIR-FTAXWH-RQST-PCT.
023437
029060*    MOVE WS-LTAXWH-CALC-CD     TO MIR-LTAXWH-CALC-CD.
029060     MOVE WS-LTAXWH-CALC-CD     TO MIR-LTAXWH-RQST-CD.
023437
023437     MOVE WS-LTAXWH-PCT         TO L0290-INPUT-V02.
023437     MOVE 2                     TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT 
029060                                TO L0290-MAX-OUT-LEN.
023437     PERFORM  0290-2000-FORMAT-FOR-MIR
023437         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-PCT.
029060     MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-RQST-PCT.
023437
023437     MOVE WS-LTAXWH-FLAT-AMT    TO L0290-INPUT-V02.
023437     MOVE 2                     TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT  TO L0290-MAX-OUT-LEN.
023437     PERFORM  0290-2000-FORMAT-FOR-MIR
023437         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-FLAT-AMT.
029060     MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-RQST-AMT.
023437
031034**   MOVE WS-FED-TAXWH-AMT      TO L0290-INPUT-V02.
029060*    MOVE L5382-FED-TAXWH-AMT   TO L0290-INPUT-V02.
029060     MOVE L5382-FTAXWH-AMT      TO L0290-INPUT-V02.
023437     MOVE 2                     TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060     MOVE LENGTH OF MIR-FTAXWH-AMT
023437                                TO L0290-MAX-OUT-LEN.
023437     PERFORM  0290-2000-FORMAT-FOR-MIR
023437         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA     TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE L0290-OUTPUT-DATA     TO MIR-FTAXWH-AMT.

031034**   MOVE WS-TAX-ACB-AMT        TO L0290-INPUT-V02.
031034     MOVE L5382-TAX-ACB-AMT     TO L0290-INPUT-V02.
023444     MOVE 2                     TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
023444                                TO L0290-MAX-OUT-LEN.
023444     PERFORM  0290-2000-FORMAT-FOR-MIR
023444         THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-TAX-ACB-AMT.
023444
031034**   MOVE WS-TAXBL-PORTN-AMT    TO L0290-INPUT-V02.
031034     MOVE L5382-TAXBL-PORTN-AMT TO L0290-INPUT-V02.
023444     MOVE 2                     TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
023444                                TO L0290-MAX-OUT-LEN.
023444     PERFORM  0290-2000-FORMAT-FOR-MIR
023444         THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TAXBL-GRS-DSTRB-AMT.
023444
023444     COMPUTE WS-WORK-AMT = WS-TOT-POL-CLI-AMT
023444                         + WS-TOT-SIDFND-CLI-AMT.
023444     MOVE WS-WORK-AMT           TO L0290-INPUT-V02.
023444     MOVE 2                     TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
023444                                TO L0290-MAX-OUT-LEN.
023444     PERFORM  0290-2000-FORMAT-FOR-MIR
023444         THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA     TO MIR-DV-GRS-DSTRB-AMT.
029060
029060     MOVE L5382-LTAXWH-AMT      TO L0290-INPUT-V02.
029060     MOVE 2                     TO L0290-PRECISION.
029060     MOVE LENGTH OF MIR-LTAXWH-AMT
029060                                TO L0290-MAX-OUT-LEN.
029060     PERFORM  0290-2000-FORMAT-FOR-MIR
029060         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060     MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-AMT.
029060
       8300-FINALIZE-MAP-X.
           EXIT.
      *
      *-----------------------
       8800-FINALIZE-FUND-MAP.
      *-----------------------

           MOVE WS-CFLW-REC-INFO (WS-LINE) TO RCFLW-REC-INFO.
           MOVE WS-CFCO-REC-AREA (WS-LINE) TO WCFCS-WORK-AREA.

           PERFORM 8810-MOVE-CF-TO-FUND-SCREEN
              THRU 8810-MOVE-CF-TO-FUND-SCREEN-X.

       8800-FINALIZE-FUND-MAP-X.
           EXIT.
      *
      *----------------------------
       8810-MOVE-CF-TO-FUND-SCREEN.
      *----------------------------

      * SET UP FOR FUND BY AMOUNT

           IF WS-BUS-FCN-SURR-FND-BY-AMT
               IF WS-H-ACOV (WS-LINE) = '00'
               OR WS-H-ACOV (WS-LINE) = SPACES
                   MOVE ZERO          TO RCFLW-CF-SURR-CHRG-AMT
                   MOVE ZERO          TO RCFLW-CF-MKTVAL-ADJ-AMT
               END-IF
           END-IF.

      * SET UP FOR FUND BY UNITS

           IF WS-BUS-FCN-SURR-FND-BY-UNIT
               IF WS-H-UCOV (WS-LINE) = '00'
               OR WS-H-UCOV (WS-LINE) = SPACES
                   MOVE ZERO          TO RCFLW-CF-SURR-CHRG-AMT
                   MOVE ZERO          TO RCFLW-CF-MKTVAL-ADJ-AMT
               END-IF
           END-IF.

           IF RCFLW-CF-SURR-CHRG-AMT NOT NUMERIC
               MOVE ZERO              TO RCFLW-CF-SURR-CHRG-AMT
           END-IF.
           IF RCFLW-CF-MKTVAL-ADJ-AMT NOT NUMERIC
               MOVE ZERO              TO RCFLW-CF-MKTVAL-ADJ-AMT
           END-IF.
017150*    COMPUTE WS-WORK-13V2 ROUNDED = RCFLW-CF-SURR-CHRG-AMT.
017150     COMPUTE WS-WORK-13V2         = RCFLW-CF-SURR-CHRG-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-WORK-13V2 * 100.
020874     MOVE WS-WORK-13V2          TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.

           IF WS-BUS-FCN-SURR-FND-BY-AMT
008455         MOVE LENGTH OF MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                     TO MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
           ELSE
008455         MOVE LENGTH OF MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                     TO MIR-CF-SURR-CHRG-AMT-T (WS-LINE)
           END-IF.

           IF WS-BUS-FCN-SURR-FND-BY-AMT
017150*        COMPUTE WS-WORK-13V2 ROUNDED = RCFLW-CF-MKTVAL-ADJ-AMT
017150         COMPUTE WS-WORK-13V2         = RCFLW-CF-MKTVAL-ADJ-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = WS-WORK-13V2 * 100
020874         MOVE WS-WORK-13V2      TO L0290-INPUT-V02
008455         MOVE LENGTH OF MIR-CF-MKTVAL-ADJ-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                    TO MIR-CF-MKTVAL-ADJ-AMT-T (WS-LINE)
           END-IF.

       8810-MOVE-CF-TO-FUND-SCREEN-X.
           EXIT.
      *
      *------------------
       8900-CHECK-ACCESS.
      *------------------
      * DETERMINE IF THIS POLICY CAN BE ACCESSED FOR THIS TRANSACTION
      * BY CALLING CSLC5400

           SET W0761-CONTINUE                 TO TRUE.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET L5400-STAT-MSG-NOT-REQD        TO TRUE.
           SET L5400-CRCY-MSG-REQD            TO TRUE.
016440     SET L5400-POL-XFER-UPDATE          TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-CRCY-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
016440     OR L5400-XFER-ACCS-RESTRICTED
               SET W0761-DO-NOT-CONTINUE    TO TRUE
               SET WGLOB-RETURN-ERROR       TO TRUE
           END-IF.

       8900-CHECK-ACCESS-X.
           EXIT.
      *
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.
            MOVE MIR-CVG-NUM          TO WGLOB-REF-COVERAGE-NUMBER.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
      *
021311*--------------------------
021311 9990-INIT-WORKING-STORAGE.
021311*--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
021311
025970     PERFORM  0182-0000-INIT-PARM-INFO
025970         THRU 0182-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  0187-0000-INIT-PARM-INFO
031034*        THRU 0187-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0279-0000-INIT-PARM-INFO
025970         THRU 0279-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0316-0000-INIT-PARM-INFO
025970         THRU 0316-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0753-0000-INIT-PARM-INFO
025970         THRU 0753-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1010-0000-INIT-PARM-INFO
025970         THRU 1010-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  1146-0000-INIT-PARM-INFO
031034*        THRU 1146-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2090-0000-INIT-PARM-INFO
025970         THRU 2090-0000-INIT-PARM-INFO-X.
028789
028789     PERFORM  2110-0000-INIT-PARM-INFO
028789         THRU 2110-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2600-0000-INIT-PARM-INFO
025970         THRU 2600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2760-0000-INIT-PARM-INFO
025970         THRU 2760-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2770-0000-INIT-PARM-INFO
025970         THRU 2770-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
031034     PERFORM  5382-0000-INIT-PARM-INFO
031034         THRU 5382-0000-INIT-PARM-INFO-X.
031034
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6860-0000-INIT-PARM-INFO
025970         THRU 6860-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7305-0000-INIT-PARM-INFO
025970         THRU 7305-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7306-0000-INIT-PARM-INFO
025970         THRU 7306-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  TAXC-0000-INIT-PARM-INFO
025970         THRU TAXC-0000-INIT-PARM-INFO-X.
025970
023118     INITIALIZE                      WS-WORK-AREAS.
025970     INITIALIZE WS-TMP-CF-REC.
025970     INITIALIZE WS-CASH-FLOW-INFO.
025970     INITIALIZE WTSCF-CASH-FLOW-INFO.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970*    MOVE '0630'                     TO WS-TWRK-KEY.
025970*    MOVE 25                         TO WS-MAX-FUND-LINES.
025970     INITIALIZE WBTAX-WORK-INFO.
025970     SET WS-TRANSACTION-NAME-DEFAULT TO TRUE.
025970     SET WBTAX-BYPASS-TAX-NO         TO TRUE.
025970     SET WBTAX-PRCES-LOAN-TAX        TO TRUE.
025970     SET WBTAX-BYPASS-LTAX-NO        TO TRUE.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
021311     MOVE MIR-POL-ID-BASE            TO WS-HOLD-POLICY.
021311     MOVE MIR-POL-ID-SFX             TO WS-HOLD-SUFFIX.
021311
023118*    INITIALIZE                      WS-HOLD-PLAR-PRCES-SW.
023118*    INITIALIZE                      WS-HOLD-PGAL-ALLOC-SW.
023118*    INITIALIZE                      WS-HOLD-PGAL-TABLE.
023118*    INITIALIZE                      WS-CDSA-INFO.
021311     SET WS-INT-RATE-CHG-NO          TO TRUE.
021311     SET WS-SAVE-INT-RATE-CHG-NO     TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
029747*    SET WS-MAX-FUND-LINES-DEFAULT   TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.
027105     MOVE WCVGM-MAX-WCVGS-NUM         TO WCFCS-MAX-ROWS.
029747
029747     COMPUTE WS-MAX-FUND-LINES = LENGTH OF MIR-CVG-NUM-G
029747                               / LENGTH OF MIR-CVG-NUM-T (1).
021311
021311 9990-INIT-WORKING-STORAGE-X.
021311     EXIT.
021311*
      *********************************
      * PROCESSING COPYBOOKS
      *********************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.
025970 COPY XCPS1670.
       COPY CCPSPGA.
       COPY CCPPCFCA.
       COPY CCPPCFCS.
012143 COPY CCPPPLIN.
023437 COPY CCPSACCT.
       COPY NCPPCVGS.
       COPY NCPPCVGR.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      *
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      *
      *********************************
      *  LINKAGE COPYBOOKS
      *********************************

       COPY CCPS0182.
018764*COPY CCCL0182.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY CCPL0182.
      *
021930*COPY CCPS0187.
018764*COPY CCCL0187.
021930*COPY CCPL0187.
031034*COPY CCPS0187.
031034*COPY CCPL0187.
      *
018764*COPY CCCL0201.
025970 COPY CCPS0201.
018764 COPY CCPL0201.
      *
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
      *
025970 COPY CCPS0620.
       COPY CCPL0620.
      *
       COPY CCPS0753.
018764*COPY CCCL0753.
018764 COPY CCPL0753.
      *
016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108*
       COPY CCPS1010.
018764*COPY CCCL1010.
018764 COPY CCPL1010.
      *
031034*COPY CCPS1146.
031034*COPY CCPL1146.
023437 COPY CCPS2090.
023437 COPY CCPL2090.
028789
028789 COPY CCPS2110.
028789 COPY CCPL2110.
028789
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
012143 COPY CCPS2600.
018764*COPY CCCL2600.
018764 COPY CCPL2600.
012143*
020463 COPY CCPS2735.
020463 COPY CCPL2735.
020463/
       COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.
      *
016503 COPY CCPS4780.
018764*COPY CCCL4780.
018764 COPY CCPL4780.
      *
031034 COPY CCPS5382.
031034 COPY CCPL5382.
031034
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
018764*COPY CCCL6860.
025970 COPY CCPS6860.
018764 COPY CCPL6860.
      *
015290 COPY CCPSPGAL.
015290
020475 COPY CCPS7305.
020475 COPY CCPL7305.
020475 COPY CCPS7306.
020475 COPY CCPL7306.
020475/
031034*COPY CCPS7800.
031034*COPY CCPL7800.
015290
023437 COPY CCPSTAXC.
023437 COPY CCPLTAXC.
023437
012143 COPY FCPS2760.
018764*COPY FCCL2760.
018764 COPY FCPL2760.
012143*
012143 COPY FCPS2770.
018764*COPY FCCL2770.
018764 COPY FCPL2770.
012143*
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS0279.
017150 COPY XCPL0279.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
015290 COPY XCPL1660.
025970 COPY XCPS1680.
005409 COPY XCPL1680.
      *
008455 COPY XCPS0290.
008455 COPY XCPL0290.
      *
023437 COPY XCPS0316.
023437 COPY XCPL0316.
023437
       COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      **********************************
      *  FILE I/O COPYBOOKS
      **********************************
      *
       COPY CCPCCFAG.
       COPY CCPNCFAG.
      *
       COPY CCPACFCO.
       COPY CCPBCFCO.
       COPY CCPCCFCO.
       COPY CCPUCFCO.
       COPY CCPXCFCO.
      *
       COPY CCPCCFLW.
       COPY CCPNCFLW.
      *
       COPY CCPNCVG.
       COPY CCPUCVG.
      *
       COPY CCPNPOL.
       COPY CCPUPOL.
      *
012143 COPY CCPNPH.
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                     **
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM0761                     **
      *****************************************************************
