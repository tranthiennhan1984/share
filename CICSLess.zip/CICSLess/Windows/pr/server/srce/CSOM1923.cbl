      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1923.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1923                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE CLNM TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015508**  6.0       NAME ENHANCEMENTS                                **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016548**  6.2       CHANGE COMP TO BINARY                            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1923'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
020478 COPY XCWWWKDT.

       COPY SQLCA.

014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-DELETE         VALUE '1923'.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1920'.
016548*    05  WS-GR                         PIC 9(04) COMP SYNC.
016548     05  WS-GR                         PIC 9(04) BINARY SYNC.
016548*    05  WS-MAX-GR        VALUE 2      PIC 9(04) COMP SYNC.
018732*    05  WS-MAX-GR        VALUE 2      PIC 9(04) BINARY SYNC.
025970*    05  WS-MAX-GR        VALUE 3      PIC 9(04) BINARY SYNC.
           05  WS-PIC-999                    PIC 9(3).
               88  WS-PIC-001-003            VALUE 0 THRU 3.
           05  WS-PREV-NAME-EXISTS-IND       PIC X(01).
               88  WS-PREV-NAME-EXISTS-NO    VALUE 'N'.
               88  WS-PREV-NAME-EXISTS       VALUE 'Y'.
018732     05  WS-CLNM-COUNT                 PIC 9(04) BINARY SYNC.
020478     05  WS-CURR-CLNM-EFF-DT           PIC X(10).
020478     05  WS-EFF-DT                     PIC X(10).

025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1920'.
025970     05  WS-MAX-GR                     PIC 9(04) BINARY SYNC.
025970         88  WS-MAX-GR-DEFAULT         VALUE 3.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCLI.
       COPY CCFRCLI.
      /
       COPY CCFWCLNM.
       COPY CCFRCLNM.
      /
020478 COPY CCFWCLRQ.
020478 COPY CCFRCLRQ.
020478/
020478*COPY CCFWCLNP.
018732/
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
020478 COPY CCWL2435.
028298 COPY CCWL2626.
       COPY XCWL0280.
020874 COPY XCWL0290.
020478 COPY XCWL1640.
014221/
014221 COPY XCWL8090.
014221/
018764*COPY XCWLPTR.
020478 COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1923.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1923'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-DELETE.
      *--------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221         GO TO 2000-DELETE-X
014221     END-IF.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

      *
      *  EDIT AND DELETE THE RECORDS
      *
018732     MOVE ZERO                  TO WS-CLNM-COUNT.
           PERFORM  2200-EDIT-DELETE
               THRU 2200-EDIT-DELETE-X
            VARYING WS-GR FROM 1 BY 1
              UNTIL WS-GR > WS-MAX-GR.

018732     IF  WS-CLNM-COUNT = ZERO
018732*MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
018732         MOVE WCLNM-KEY
018732           TO WGLOB-MSG-PARM (1)
018732         MOVE 'TBPFS'
018732           TO WGLOB-MSG-PARM (2)
018732         MOVE 'XS00000010'
018732           TO WGLOB-MSG-REF-INFO
018732         PERFORM  0260-1000-GENERATE-MESSAGE
018732             THRU 0260-1000-GENERATE-MESSAGE-X
018732         SET MIR-RETRN-RQST-FAILED
018732           TO TRUE
018732         GO TO 2000-DELETE-X
018732     END-IF.
      *
      *  UPDATE THE CLIENT RECORD
      *
           SET  WS-PREV-NAME-EXISTS-NO TO TRUE.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

018732*    SET  WCLNM-CLI-INDV-NM-TYP-PREV TO TRUE.
018732*    MOVE MIR-CLI-INDV-SEQ-NUM       TO WCLNM-CLI-INDV-SEQ-NUM.
018732*
018732*    MOVE +1                    TO WCLNM-CLI-INDV-SEQ-NUM.
018732*    MOVE WCLNM-KEY             TO WCLNM-ENDBR-KEY.
018732*    MOVE +999                  TO WCLNM-ENDBR-CLI-INDV-SEQ-NUM.
018732*
018732*    PERFORM  CLNM-1000-BROWSE
018732*        THRU CLNM-1000-BROWSE-X.
018732*
018732*    IF  WCLNM-IO-OK
018732*        PERFORM  CLNM-2000-READ-NEXT
018732*            THRU CLNM-2000-READ-NEXT-X
018732*        IF  WCLNM-IO-OK
018732*            SET  WS-PREV-NAME-EXISTS TO TRUE
018732*        END-IF
018732*        PERFORM  CLNM-3000-END-BROWSE
018732*            THRU CLNM-3000-END-BROWSE-X
018732*    END-IF.

020478*    MOVE LOW-VALUES                 TO WCLNP-KEY.
020478*    MOVE WCLNM-CLI-ID               TO WCLNP-CLI-ID.
020478*    MOVE WCLNM-CLI-INDV-NM-TYP-CD   TO WCLNP-CLI-INDV-NM-TYP-CD.
020478*
020478*    MOVE +1                    TO WCLNP-CLI-INDV-SEQ-NUM.
020478*    MOVE WCLNP-KEY             TO WCLNP-ENDBR-KEY.
020478*    MOVE +999                  TO WCLNP-ENDBR-CLI-INDV-SEQ-NUM.
020478*    MOVE HIGH-VALUE            TO WCLNP-ENDBR-CLI-INDV-GR-CD.
020478*
020478*    PERFORM  CLNP-1000-BROWSE
020478*        THRU CLNP-1000-BROWSE-X.
020478*
020478*    PERFORM  CLNP-2000-READ-NEXT
020478*        THRU CLNP-2000-READ-NEXT-X.
020478*    IF  WCLNP-IO-OK
020478*        SET  WS-PREV-NAME-EXISTS TO TRUE
020478*    END-IF
020478*    PERFORM  CLNP-3000-END-BROWSE
020478*        THRU CLNP-3000-END-BROWSE-X.

020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478     MOVE MIR-CLI-ID                TO L2435-CLI-ID.
020478     MOVE WS-CURR-CLNM-EFF-DT       TO L2435-EFF-DT.
020478     PERFORM  2435-3000-PREV-CLI-NAME
020478         THRU 2435-3000-PREV-CLI-NAME-X.
020478     IF  L2435-RETRN-OK
020478         SET  WS-PREV-NAME-EXISTS   TO TRUE
020478     END-IF.
020478
020478*    IF  WS-PREV-NAME-EXISTS-NO
020478*
020478*        EVALUATE TRUE
020478*
020478*            WHEN RCLI-PREV-INFO-NAME-ONLY
020478*                 SET  RCLI-PREV-INFO-NO-NAAD-INFO  TO TRUE
020478*
020478*            WHEN RCLI-PREV-INFO-NAME-AND-ADDR
020478*                 SET  RCLI-PREV-INFO-ADDR-ONLY     TO TRUE
020478*
020478*        END-EVALUATE
020478*
020478*    END-IF.

           PERFORM  CLI-2000-REWRITE
               THRU CLI-2000-REWRITE-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

       2000-DELETE-X.
           EXIT.
      /

      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

020478*    IF MIR-CLI-INDV-SEQ-NUM = '000'
020478*    OR MIR-CLI-INDV-SEQ-NUM = SPACES
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*        MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*        MOVE 'CS19230001'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        GO TO 2100-VALIDATE-KEYS-X
020478*    END-IF.
020478*
020478*    IF MIR-CLI-INDV-SEQ-NUM NOT = SPACES
020478*        MOVE 'Y'               TO L0280-SPACE-PERMITTED-IND
020478*        MOVE 'N'               TO L0280-SIGN-IND
020478*        MOVE 0                 TO L0280-PRECISION
020478*        MOVE 3                 TO L0280-LENGTH
020478*        MOVE 3                 TO L0280-INPUT-SIZE
020478*        MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO L0280-INPUT-DATA
020478*        PERFORM  0280-1000-NUMERIC-EDIT
020478*            THRU 0280-1000-NUMERIC-EDIT-X
020478*
020478*        IF L0280-OK
020478*            CONTINUE
020478*        ELSE
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*            MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*            MOVE 'CS19230001'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*            GO TO 2100-VALIDATE-KEYS-X
020478*        END-IF
020478*
020478*        MOVE L0280-OUTPUT  TO WS-PIC-999
020478*        MOVE L0280-OUTPUT  TO L0290-INPUT-V00
020478*
020478*        IF  WS-PIC-001-003
020874*            MOVE WS-PIC-999    TO MIR-CLI-INDV-SEQ-NUM
020478*            MOVE ZERO          TO L0290-PRECISION
020478*            MOVE LENGTH OF MIR-CLI-INDV-SEQ-NUM
020478*                               TO L0290-MAX-OUT-LEN
020478*            PERFORM 0290-2000-FORMAT-FOR-MIR
020478*               THRU 0290-2000-FORMAT-FOR-MIR-X
020478*            MOVE L0290-OUTPUT-DATA TO MIR-CLI-INDV-SEQ-NUM
020478*        ELSE
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*            MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*            MOVE 'CS19230001'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*            GO TO 2100-VALIDATE-KEYS-X
020478*        END-IF
020478*
020478*    END-IF.
014221*
014221*    VALIDATE THE CLIENT EXISTS, AND LOCK FOR UPDATE OF PREV INFO
014221*
014221*    MOVE MIR-CLI-ID             TO WCLI-CLI-ID.
014221*
014221*    PERFORM  CLI-1000-READ-FOR-UPDATE
014221*        THRU CLI-1000-READ-FOR-UPDATE-X.
014221*
014221*    IF  NOT WCLI-IO-OK
014221*MSG:  CLIENT (@1) DOES NOT EXIST
014221*        MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (1)
014221*        MOVE 'XS00000076'       TO WGLOB-MSG-REF-INFO
014221*        PERFORM  0260-1000-GENERATE-MESSAGE
014221*            THRU 0260-1000-GENERATE-MESSAGE-X
014221*    END-IF.
020478
020478     MOVE MIR-CLI-INDV-EFF-DT
020478                                   TO L1640-EXTERNAL-DATE
020478     PERFORM  1640-7000-MIR-TO-INT
020478         THRU 1640-7000-MIR-TO-INT-X
020478
020478     IF  L1640-NOT-VALID
020478*MSG : INVALID NAME EFFECTIVE DATE
020478         MOVE 'CS19230002'         TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478         GO TO 2100-VALIDATE-KEYS-X
020478     ELSE
020478         MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
020478     END-IF.
020478
020478     MOVE WS-EFF-DT                TO L1640-INTERNAL-DATE.
020478     PERFORM  1640-8000-INTERNAL-TO-MIR
020478         THRU 1640-8000-INTERNAL-TO-MIR-X.
020478     MOVE L1640-EXTERNAL-DATE      TO MIR-CLI-INDV-EFF-DT.

020478* CHECK IF THIS IS THE CURRENT NAME

020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478     MOVE MIR-CLI-ID               TO L2435-CLI-ID.
020478     PERFORM  2435-2000-CRNT-CLI-NAME
020478         THRU 2435-2000-CRNT-CLI-NAME-X.
020478     IF  L2435-RETRN-OK
020478         MOVE L2435-CLI-INDV-EFF-DT
020478                                   TO WS-CURR-CLNM-EFF-DT
020478     END-IF.

014221     MOVE MIR-CLI-ID             TO WCLI-CLI-ID.
014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  WCLI-IO-NOT-FOUND
014221*MSG:  CLIENT (@1) DOES NOT EXIST
014221         MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'XS00000076'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2100-VALIDATE-KEYS-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'              TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2100-VALIDATE-KEYS-X
014221     END-IF.

020478     IF  WS-EFF-DT <= WGLOB-PROCESS-DATE
020478         PERFORM  2110-EDIT-PREV-NAME
020478             THRU 2110-EDIT-PREV-NAME-X
020478     END-IF.

       2100-VALIDATE-KEYS-X.
           EXIT.

020478*--------------------
020478 2110-EDIT-PREV-NAME.
020478*--------------------
020478
020478     IF  WS-EFF-DT NOT = WS-CURR-CLNM-EFF-DT
020478         GO TO 2110-EDIT-PREV-NAME-X
020478     END-IF.
020478
020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478
020478     MOVE MIR-CLI-ID         TO L2435-CLI-ID.
020478     MOVE WS-EFF-DT          TO L2435-EFF-DT.
020478
020478     PERFORM  2435-3000-PREV-CLI-NAME
020478         THRU 2435-3000-PREV-CLI-NAME-X.
020478
020478     IF  NOT L2435-RETRN-OK
020478*MSG: CANNOT DELETE LAST REMAINING NAME
020478         MOVE 'CS19230003'       TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478         GO TO 2110-EDIT-PREV-NAME-X
020478     END-IF.
020478
020478 2110-EDIT-PREV-NAME-X.
020478     EXIT.
      /

      *-----------------
       2200-EDIT-DELETE.
      *-----------------
      *
      *  THE RECORD MUST EXIST ON A DELETE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

018732*    IF  WS-GR > 1
018732*
018732*        IF  WGLOB-COUNTRY-JAPAN
018732*            CONTINUE
018732*        ELSE
018732*            GO TO 2200-EDIT-DELETE-X
018732*        END-IF
018732*
018732*        SET  WCLNM-CLI-INDV-GR-KANJI    TO TRUE
018732*
018732*    END-IF.

018732     EVALUATE  WS-GR
018732         WHEN  1
018732             SET WCLNM-CLI-INDV-GR-ALPHA TO TRUE
018732         WHEN  2
018732             SET WCLNM-CLI-INDV-GR-KANJI TO TRUE
018732         WHEN  3
018732             SET WCLNM-CLI-INDV-GR-KATAKANA TO TRUE
018732     END-EVALUATE.

           PERFORM  CLNM-1000-READ-FOR-UPDATE
               THRU CLNM-1000-READ-FOR-UPDATE-X.

           IF  WCLNM-IO-NOT-FOUND
018732*MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
018732*        MOVE WCLNM-KEY
018732*          TO WGLOB-MSG-PARM (1)
018732*        MOVE 'TBPFS'
018732*          TO WGLOB-MSG-PARM (2)
018732*        MOVE 'XS00000010'
018732*          TO WGLOB-MSG-REF-INFO
018732*        PERFORM  0260-1000-GENERATE-MESSAGE
018732*            THRU 0260-1000-GENERATE-MESSAGE-X
018732*        SET MIR-RETRN-RQST-FAILED
018732*          TO TRUE
               GO TO 2200-EDIT-DELETE-X
           END-IF.

020478     IF  RCLNM-CLI-RQST-CREAT-TS NOT = WWKDT-ZERO-TS
020478         MOVE RCLNM-CLI-ID       TO WCLRQ-CLI-ID
020478         MOVE RCLNM-CLI-RQST-CREAT-TS
020478                                 TO WCLRQ-CLI-RQST-CREAT-TS
020478         PERFORM  CLRQ-1000-READ-FOR-UPDATE
020478             THRU CLRQ-1000-READ-FOR-UPDATE-X
020478         IF  WCLRQ-IO-OK
020478             PERFORM  CLRQ-1000-DELETE
020478                 THRU CLRQ-1000-DELETE-X
020478         END-IF
020478     END-IF.
      *
      *  DELETE THE RECORD
      *
           PERFORM  CLNM-1000-DELETE
               THRU CLNM-1000-DELETE-X.
018732     ADD 1                TO  WS-CLNM-COUNT.

       2200-EDIT-DELETE-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES                 TO WCLNM-KEY.
           MOVE MIR-CLI-ID                 TO WCLNM-CLI-ID.

018732*    EVALUATE TRUE
018732*
018732*        WHEN WGLOB-COUNTRY-JAPAN
018732*             SET  WCLNM-CLI-INDV-GR-KATAKANA
018732*               TO TRUE
018732*
018732*        WHEN OTHER
018732*             SET  WCLNM-CLI-INDV-GR-ALPHA
018732*               TO TRUE
018732*
018732*    END-EVALUATE.

020478*    SET  WCLNM-CLI-INDV-NM-TYP-PREV TO TRUE.
020478*    MOVE MIR-CLI-INDV-SEQ-NUM       TO WCLNM-CLI-INDV-SEQ-NUM.
020478     MOVE WS-EFF-DT                  TO WCLNM-CLI-INDV-EFF-DT.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT
             TO TRUE.
           MOVE MIR-CLI-ID
             TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
025970
025970     INITIALIZE  WLOCK-TWRK-OTHER-INFO.
025970     SET  WS-MAX-GR-DEFAULT              TO TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT            TO TRUE.
025970     MOVE SPACES                         TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
025970 COPY XCPS8090.
020478 COPY CCPS2435.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
020478 COPY CCPL2435.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
025970 COPY XCPS1640.
020478 COPY XCPL1640.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
014221 COPY CCPNCLI.
       COPY CCPUCLI.
021930*COPY CCPBCLNM.
       COPY CCPUCLNM.
       COPY CCPXCLNM.
020478*COPY CCPBCLNP.
020478 COPY CCPUCLRQ.
020478 COPY CCPXCLRQ.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM1923                     **
      *****************************************************************
