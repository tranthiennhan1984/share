      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2204.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2204                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE AGENT CLIENT SEARCH     **
      **            FUNCTION.                                        **
      **                                                             **
      **  DOMAIN :  AG                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015522**  6.0       AGENT CLIENT SEARCH                              **
016548**  6.2       CHANGE COMP TO BINARY                            **
016103**  6.3       JAPANESE SEARCH ENHANCEMENTS (6.1.2J)            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028789**  6.7       EXTERNAL AGENCY INTEGRATION - REAL TIME INFO.    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2204'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                        PIC X(04).
               88  WS-BUS-FCN-AGT-SRCH              VALUE '2204'.
016548*    05  WS-MAX-SRCH-QTY                      PIC S9(04) COMP
016548     05  WS-MAX-SRCH-QTY                      PIC S9(04) BINARY
                                                    VALUE +50.
016548*    05  WS-SUB                               PIC S9(04) COMP.
016548     05  WS-SUB                               PIC S9(04) BINARY.
016548*    05  WS-OUT-CTR                           PIC S9(04) COMP.
016548     05  WS-OUT-CTR                           PIC S9(04) BINARY.
           05  WS-LIST-FULL-IND                     PIC X(01) VALUE 'N'.
               88  WS-LIST-FULL                     VALUE 'Y'.
           05  WS-DISPLAY-PIC-99                    PIC 9(02).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************

018764*COPY XCWLPTR.
014590*COPY XCWL0030.

      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************

028789*COPY CCFWAG.
028789*COPY CCFRAG.

       COPY CCFWAGCL.
       COPY CCFRAGTC.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028789 COPY CCWL0083.
       COPY NCWL5700.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2204.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           SET MIR-RETRN-OK             TO TRUE.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *   VALIDATE FUNCTION REQUESTED
      *
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-AGT-SRCH
                    PERFORM  2000-PROCESS-AGT-SRCH
                        THRU 2000-PROCESS-AGT-SRCH-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------
       2000-PROCESS-AGT-SRCH.
      *----------------------

           MOVE ZERO                     TO WS-OUT-CTR.

020460     IF  MIR-CLI-TAX-ID  = SPACES
020460     AND MIR-ENTR-SUR-NM = SPACES
020460*MSG:  SURNAME IS A MANDATORY FIELD
020460         MOVE 'CS22040004'         TO WGLOB-MSG-REF-INFO
020460         PERFORM  0260-1000-GENERATE-MESSAGE
020460             THRU 0260-1000-GENERATE-MESSAGE-X
020460         GO TO 2000-PROCESS-AGT-SRCH-X
020460     END-IF.

           INITIALIZE L5700-PARM-INFO.
           SET L5700-PHONETIC-SEARCH     TO TRUE.
           SET L5700-GIVNM-PHNT-SEARCH   TO TRUE.

           MOVE MIR-ENTR-GIV-NM          TO L5700-CLI-GIV-NM.
           MOVE MIR-ENTR-SUR-NM          TO L5700-CLI-SUR-NM.
           MOVE WS-MAX-SRCH-QTY          TO L5700-MAX-CLI-SRCH-QTY.
018732     MOVE MIR-CLI-INDV-GR-CD       TO L5700-SRCH-GR-CD.

020460     IF  MIR-CLI-TAX-ID = SPACES
020460         CONTINUE
020460     ELSE
020460         MOVE MIR-CLI-TAX-ID       TO L5700-CLI-TAX-ID
020460     END-IF.

020460     IF  MIR-CLI-INDV-GR-CD = SPACES
020460         SET L5700-SRCH-GR-ALPHA   TO TRUE
020460     ELSE
020460         MOVE MIR-CLI-INDV-GR-CD       TO L5700-SRCH-GR-CD
020460     END-IF.

018732*    IF NOT WGLOB-COUNTRY-JAPAN
018732*        SET MIR-DV-SRCH-GR-ALPHA     TO TRUE
018732*    ELSE
018732*        SET L5700-EXACT-SEARCH       TO TRUE
018732*        SET L5700-GIVNM-EXCT-SEARCH  TO TRUE
018732*        IF  MIR-DV-SRCH-GR-ALPHA
018732*            SET MIR-DV-SRCH-GR-KANJI TO TRUE
018732*        END-IF
018732*    END-IF.
016103
016103*    MOVE MIR-DV-SRCH-GR-CD   TO L5700-SRCH-GR-CD.

018732     IF MIR-CLI-INDV-GR-KATAKANA
018732     OR MIR-CLI-INDV-GR-KANJI
018732        SET L5700-EXACT-SEARCH       TO TRUE
018732        SET L5700-GIVNM-EXCT-SEARCH  TO TRUE
018732     END-IF.
           INITIALIZE MIR-OUTPUT-AREA.

      *
      *   GET LIST OF CLIENTS BASED ON SEARCH CRITERIA
      *
           PERFORM  5700-1000-PROCESS-SEARCH
               THRU 5700-1000-PROCESS-SEARCH-X.

           IF  NOT L5700-RETRN-OK
           AND NOT L5700-RETRN-NONE-FOUND
               IF  L5700-RETRN-EDIT-ERROR
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
               ELSE
                   SET MIR-RETRN-RQST-FAILED TO TRUE
               END-IF
               GO TO 2000-PROCESS-AGT-SRCH-X
           ELSE
               IF  L5700-RETRN-OK
                   PERFORM  3000-PROCESS-CLIENTS
                       THRU 3000-PROCESS-CLIENTS-X
                       VARYING WS-SUB FROM 1 BY 1
                       UNTIL WS-SUB > L5700-LAST-REC-SEQ-NUM
                       OR    WS-LIST-FULL
                       OR    NOT MIR-RETRN-OK
               END-IF
           END-IF.

           IF NOT MIR-RETRN-OK
               GO TO 2000-PROCESS-AGT-SRCH-X
           END-IF.

      *
      *   SWITCH THE FIRST AND LAST NAMES AND
      *   SEARCH AGAIN
      *
           IF  MIR-ENTR-GIV-NM NOT = SPACES
           AND NOT WS-LIST-FULL
               INITIALIZE L5700-OUTPUT-PARM-INFO
               MOVE MIR-ENTR-GIV-NM      TO L5700-CLI-SUR-NM
               MOVE MIR-ENTR-SUR-NM      TO L5700-CLI-GIV-NM
               PERFORM  5700-1000-PROCESS-SEARCH
                   THRU 5700-1000-PROCESS-SEARCH-X
               IF  L5700-RETRN-OK
                   PERFORM  3000-PROCESS-CLIENTS
                       THRU 3000-PROCESS-CLIENTS-X
                       VARYING WS-SUB FROM 1 BY 1
                       UNTIL WS-SUB > L5700-LAST-REC-SEQ-NUM
                       OR    WS-LIST-FULL
                       OR    NOT MIR-RETRN-OK
               END-IF
           END-IF.

           IF WS-OUT-CTR = ZERO
      *MSG:    NO POSSIBLE MATCHES FOUND
               MOVE 'CS22040001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-AGT-SRCH-X
           END-IF.

           IF  WS-LIST-FULL
      *MSG:    THERE ARE MORE THAN @1 MATCHES, @1 ARE DISPLAYED
               MOVE WS-MAX-SRCH-QTY      TO WS-DISPLAY-PIC-99
               MOVE WS-DISPLAY-PIC-99    TO WGLOB-MSG-PARM (1)
               MOVE 'CS22040002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2000-PROCESS-AGT-SRCH-X.
           EXIT.

      *---------------------
       3000-PROCESS-CLIENTS.
      *---------------------
      *
      *  FOR EACH CLIENT FOUND, LOOK FOR AGENT RELATIONSHIP
      *

           MOVE L5700-CLI-ID-T (WS-SUB)  TO WAGCL-CLI-ID.
           MOVE 'R'                      TO WAGCL-AGT-CLI-REL-TYP-CD.
           MOVE LOW-VALUES               TO WAGCL-AGT-ID.
           MOVE WAGCL-KEY                TO WAGCL-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WAGCL-ENDBR-AGT-ID.

           PERFORM  AGCL-1000-BROWSE
               THRU AGCL-1000-BROWSE-X.

           IF  WAGCL-IO-OK
               PERFORM  AGCL-2000-READ-NEXT
                   THRU AGCL-2000-READ-NEXT-X
               PERFORM  3100-PROCESS-LIST
                   THRU 3100-PROCESS-LIST-X
                   UNTIL NOT WAGCL-IO-OK
                   OR    WS-LIST-FULL
                   OR    NOT MIR-RETRN-OK
               PERFORM  AGCL-3000-END-BROWSE
                   THRU AGCL-3000-END-BROWSE-X
           END-IF.



       3000-PROCESS-CLIENTS-X.
           EXIT.

      *------------------
       3100-PROCESS-LIST.
      *------------------
      *
      *  DISPLAY ROWS MATCHING SEARCH CRITERIA
      *

028789*    MOVE RAGTC-AGT-ID     TO WAG-AGT-ID.
028789     PERFORM  0083-0000-INIT-PARM-INFO
028789        THRU  0083-0000-INIT-PARM-INFO-X.
028789     MOVE RAGTC-AGT-ID     TO L0083-AGT-ID (1)

028789*    PERFORM  AG-1000-READ
028789*        THRU AG-1000-READ-X.
028789     PERFORM  0083-1000-RETRIEVE-AGT-INFO
028789         THRU 0083-1000-RETRIEVE-AGT-INFO-X.

028789*    IF  NOT WAG-IO-OK
028789     IF  NOT L0083-AGT-FOUND (1)
               SET MIR-RETRN-RQST-FAILED TO TRUE
      *MSG:    AGENT (@1) NOT FOUND FOR AGTC ROW (@2)
028789*        MOVE WAG-AGT-ID           TO WGLOB-MSG-PARM (1)
028789         MOVE L0083-AGT-ID (1)     TO WGLOB-MSG-PARM (1)
               MOVE RAGTC-KEY            TO WGLOB-MSG-PARM (2)
               MOVE 'CS22040003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3100-PROCESS-LIST-X
           END-IF.

           IF  WS-OUT-CTR = WS-MAX-SRCH-QTY
               SET WS-LIST-FULL  TO TRUE
               GO TO 3100-PROCESS-LIST-X
           END-IF.

           ADD +1    TO WS-OUT-CTR.

028789*    MOVE RAG-AGT-ID
028789     MOVE L0083-AGT-ID (1)
             TO MIR-AGT-ID-T (WS-OUT-CTR).
028789*    MOVE RAG-BR-ID
028789     MOVE L0083-AGT-BR-ID (1)
             TO MIR-BR-ID-T (WS-OUT-CTR).
028789*    MOVE RAG-AGT-STAT-CD
028789     MOVE L0083-AGT-STAT-CD (1)
             TO MIR-AGT-STAT-CD-T (WS-OUT-CTR).
028789*    MOVE RAG-AGT-CMPNST-SCHD-CD
028789     MOVE L0083-AGT-CMPNST-SCHED-CD (1)
             TO MIR-AGT-CMPNST-SCHD-CD-T (WS-OUT-CTR).
028789*    MOVE RAG-AGT-CLAS-LIC-CD
028789     MOVE L0083-AGT-CLAS-LIC-CD (1)
             TO MIR-AGT-CLAS-LIC-CD-T (WS-OUT-CTR).
028789*    MOVE RAG-AGT-LOC-LIC-CD
028789     MOVE L0083-AGT-LOC-LIC-CD (1)
             TO MIR-AGT-LOC-LIC-CD-T (WS-OUT-CTR).

           MOVE L5700-CLI-ENTR-NM-T (WS-SUB)
             TO MIR-DV-SRCH-CLI-NM-T (WS-OUT-CTR).

           PERFORM  AGCL-2000-READ-NEXT
               THRU AGCL-2000-READ-NEXT-X.

       3100-PROCESS-LIST-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
028789     PERFORM  0083-0000-INIT-PARM-INFO
028789         THRU 0083-0000-INIT-PARM-INFO-X.
028789
025970     PERFORM  5700-0000-INIT-PARM-INFO
025970         THRU 5700-0000-INIT-PARM-INFO-X.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY NCCL5700.
028789 COPY CCPS0083.
028789 COPY CCPL0083.
025970 COPY NCPS5700.
018764 COPY NCPL5700.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
028789*COPY CCPNAG.
       COPY CCPBAGCL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2204                     **
      *****************************************************************
