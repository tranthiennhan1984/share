      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0291.

       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  CSOM0291                                         **
      **  REMARKS:  MOVEMENT EXTRACT MAINTENANCE                     **
      **                                                             **
      **            THIS MODULE IS USED TO MANUALLY GENERATE POLICY  **
      **            AND COVERAGE MOVEMENT EXTRACTS.  ONLY ELEMENTARY **
      **            FIELD LEVEL VALIDATION IS PERFORMED, FOR         **
      **            NUMERIC FORMAT AND TABLE ENTRIES.                **
      **                                                             **
      **  DOMAIN :  AT                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEAN UP                                    **
557668**  5.5       NEW NAME FORMATTING                              **
557699**  5.5       NEW AUDIT MODULE                                 **
557708**  5.5       ABEND HANDLING                                   **
557973**  5.5       AMOUNT FIELD SIZING FOR INT'L SUPPORT            **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEANUP AND STANDARDIZATION                 **
010418**  5.6       ADD SUB-COMPANY CODE                             **
006002**  6.0       NEW COUNTRY LOCATION TABLE                       **
012624**  6.0       ADD DISPLAY FIELDS TO UPDATE                     **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016440**  6.2       POL ACCESS CHECK                                 **
016457**  6.2       TRAN '99' MOVED TO MVTX                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017323**  6.3       FIX TO CHECK FOR VALID COVERAGE NUMBER           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
015705**  6.4       NAME FORMATTING                                  **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023060**  6.5       MOVEMENT DETAILS HISTORY - MOVEMENT FIELDS       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034433**  7.0       COUNT DISPLAY                                    **
029612**  7.1       MOVEMENT SCREEN DEFAULT                          **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0291'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

007766 COPY XCWWCVGM.

       01  WS-PGM-WORK-AREA.
016537*    03  TRANSACTION-NAME         PIC X(04)   VALUE 'MVMT'.
           03  WS-ERROR-FLAG            PIC X(01).
               88  WS-ERROR-OCCURED                 VALUE 'Y'.
           03  WS-BUS-FCN-ID            PIC X(04).
               88  WS-BUS-FCN-VALID     VALUE '1300' '1302'.
               88  WS-BUS-FCN-RETRIEVE  VALUE '1300'.
               88  WS-BUS-FCN-UPDATE    VALUE '1302'.
           03  HOLD-COV-NO              PIC 99.
           03  R-HOLD-COV-NO            REDEFINES
               HOLD-COV-NO              PIC XX.
016548*    03  I                        PIC 99 COMP.
016548     03  I                        PIC 99 BINARY.
016548*    03  N4                       PIC 99 COMP.
016548     03  N4                       PIC 99 BINARY.
016548*    03  N8                       PIC 99 COMP.
016548     03  N8                       PIC 99 BINARY.
           03  POLICY-HOLD.
               05  POLICY-FIRST         PIC X.
               05  POLICY-MID           PIC X(8).
               05  POLICY-LAST          PIC X.

       01  W0291-WORK-AREA.
           05  W0291-SCREEN-FORMAT.
014591*        10  W0291-PLAN-ID.
014591*            15  W0291-PLANCD         PIC X(05).
014591*            15  W0291-RTSCAL         PIC X(01).
014591         10  W0291-PLAN-ID            PIC X(06).
               10  W0291-PARCD              PIC X(01).
               10  W0291-REI                PIC X(01).
               10  W0291-BRANCH             PIC X(05).
               10  W0291-REG                PIC X(01).
               10  W0291-TYPEINS            PIC X(01).
016537             88  W0291-TYPEINS-VALID  VALUE 'A' 'M' 'N' '1'
016537                    '2' '3' '5' '6' '7' '8' '9' 'C' 'D' 'I'
016537                    'K' 'S' 'F'.

               10  W0291-LINE               PIC X(03).
               10  W0291-COUNT.
                   15  W0291-COUNT-SG       PIC X(01).
                   15  W0291-COUNT-NO       PIC 9(01).
               10  W0291-R-COUNT            REDEFINES
                   W0291-COUNT.
                   15  W0291-R-COUNT-SG     PIC X(01).
                   15  W0291-R-COUNT-NO     PIC X(01).
008455         10  W0291-SUMINS             PIC X(16).
               10  W0291-POLSW.
                   15  W0291-POLSW-SG       PIC X(01).
                   15  W0291-POLSW-NO       PIC 9(01).
               10  W0291-R-POLSW            REDEFINES
                   W0291-POLSW.
                   15  W0291-R-POLSW-SG     PIC X(01).
                   15  W0291-R-POLSW-NO     PIC X(01).
               10  W0291-COVSW.
                   15  W0291-COVSW-SG       PIC X(01).
                   15  W0291-COVSW-NO       PIC 9(01).
               10  W0291-R-COVSW            REDEFINES
                   W0291-COVSW.
                   15  W0291-R-COVSW-SG     PIC X(01).
                   15  W0291-R-COVSW-NO     PIC X(01).
               10  W0291-BENIND             PIC X(01).
               10  W0291-CURR               PIC X(02).
               10  W0291-ISSLOC             PIC X(02).
               10  W0291-CURLOC             PIC X(02).
      /
      *****************************************************************
      ** COMMON COPYBOOKS
      *****************************************************************

016537*COPY XCWWWKDT.
       COPY CCWTLINE.

      *****************************************************************
      ** CALLED MODULE PARAMETER INFORMATION
      *****************************************************************

028298 COPY CCWL2626.
008455 COPY XCWL0280.
008455 COPY XCWL0290.
557668 COPY CCWL0620.
       COPY CCWL2430.
       COPY CCWL5299.
       COPY CCWL5400.
557699 COPY CCWL7830.
      /
      *****************************************************************
      ** I/O COPYBOOKS
      *****************************************************************

       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
016537*COPY CCFWEDIT.
016537*COPY CCFREDIT.
      /
       COPY CCFWBRCH.
       COPY CCFRBRCH.
      /
       COPY CCFWPOL.
      /
008455 COPY XCFWCRCY.
008455 COPY XCFRCRCY.
      /
006002 COPY XCFWCTLC.
006002 COPY XCFRCTLC.
006002/
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *****************************************************************
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0291.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
           SET MIR-RETRN-OK           TO TRUE.
           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.

029612     IF  MIR-CVG-NUM = SPACES
029612     OR  MIR-CVG-NUM = '00'
029612         MOVE '01'               TO MIR-CVG-NUM
029612     END-IF.

017323     SET L0280-SIGN-NOT-PERMITTED TO TRUE.
017323     MOVE ZERO                    TO L0280-PRECISION.
017323     MOVE LENGTH OF MIR-CVG-NUM   TO L0280-INPUT-SIZE.
017323     MOVE L0280-INPUT-SIZE        TO L0280-LENGTH.
017323     MOVE MIR-CVG-NUM             TO L0280-INPUT-DATA.
017323
017323     PERFORM  0280-1000-NUMERIC-EDIT
017323         THRU 0280-1000-NUMERIC-EDIT-X.
017323
017323     IF  L0280-OK
020874*        MOVE L0280-OUTPUT        TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT        TO L0290-INPUT-V00
017323         MOVE ZERO                TO L0290-PRECISION
017323         MOVE LENGTH OF MIR-CVG-NUM
017323                                  TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
017323         MOVE L0290-OUTPUT-DATA   TO MIR-CVG-NUM
017323     ELSE
017323*MSG: COVERAGE @1 MUST BE NUMERIC; VALID VALUES ARE 01 - @2
017323         MOVE 'XS00000079'        TO WGLOB-MSG-REF-INFO
017323         MOVE MIR-CVG-NUM         TO WGLOB-MSG-PARM (1)
017323         MOVE WCVGM-MAX-WCVGS-NUM TO WGLOB-MSG-PARM (2)
017323         PERFORM  0260-1000-GENERATE-MESSAGE
017323             THRU 0260-1000-GENERATE-MESSAGE-X
017323         GO TO 2000-PROCESS-REQUEST-X
017323     END-IF.

           IF  MIR-CVG-NUM < '01'
007766     OR  MIR-CVG-NUM > WCVGM-MAX-WCVGS-NUM
      *MSG: COVERAGE NUMBER MUST BE 01 TO @1.  RE-ENTER
               MOVE 'CS02910003'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           MOVE MIR-POL-ID-BASE            TO POLICY-HOLD.
           MOVE MIR-POL-ID-SFX            TO POLICY-LAST.
           MOVE POLICY-HOLD           TO WPOL-POL-ID.
           MOVE MIR-CVG-NUM           TO R-HOLD-COV-NO.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST
                                      TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  3020-READ-POL-AND-CVG
               THRU 3020-READ-POL-AND-CVG-X.

           IF  WS-ERROR-OCCURED
              GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           IF  WPOL-IO-OK
               PERFORM  5400-1000-BUILD-PARM-INFO
                   THRU 5400-1000-BUILD-PARM-INFO-X
012624*        SET L5400-SYS-APPL-CTL-ADMIN
012624*                               TO TRUE
               SET L5400-CRCY-MSG-REQD
                                      TO TRUE
               PERFORM  5400-1000-POL-CHK
                   THRU 5400-1000-POL-CHK-X
               IF  L5400-CNFD-ACCS-RESTRICTED
               OR  L5400-CRCY-ACCS-RESTRICTED
               OR  L5400-BRCH-ACCS-RESTRICTED
016440         OR  L5400-XFER-ACCS-RESTRICTED
                   GO TO 3000-PROCESS-RETRIEVE-X
               END-IF

               PERFORM  3040-INITIALIZE-MVMT
                   THRU 3040-INITIALIZE-MVMT-X
               PERFORM  3060-SET-UP-LINE0
                   THRU 3060-SET-UP-LINE0-X
               PERFORM  3080-SET-UP-LINE1
                   THRU 3080-SET-UP-LINE1-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *------------------------------
       3020-READ-POL-AND-CVG.
      *------------------------------
      *
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
           AND POLICY-FIRST NOT = SPACES
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-OCCURED   TO TRUE
               GO TO 3020-READ-POL-AND-CVG-X
557660     END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           MOVE HOLD-COV-NO           TO I.
           MOVE WPOL-KEY              TO WCVG-KEY.
           MOVE I                     TO WCVG-CVG-NUM-N.
           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.
           IF  WCVG-IO-OK
               MOVE RCVG-CVG-INFO     TO WCVGS-CVG-INFO (I)
               MOVE RCVG-CVG-NUM      TO WCVGS-CVG-SEQ-NUM (I)
           ELSE
               MOVE I                 TO N8
               PERFORM  CVG-1000-CREATE
                   THRU CVG-1000-CREATE-X
               MOVE RCVG-CVG-INFO     TO WCVGS-CVG-INFO (I)
               IF  POLICY-FIRST NOT = SPACES
                   MOVE 'CS00000021'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-ERROR-OCCURED
                                      TO TRUE
                   GO TO 3020-READ-POL-AND-CVG-X
557660         END-IF
557660     END-IF.

       3020-READ-POL-AND-CVG-X.
           EXIT.
      /
      *---------------------
       3040-INITIALIZE-MVMT.
      *---------------------

           PERFORM  5299-1000-BUILD-PARM-INFO
               THRU 5299-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-CRCY-CD      TO L5299-POL-CRCY-CD.
           MOVE RPOL-POL-ID           TO L5299-POL-ID.
010418     MOVE RPOL-SBSDRY-CO-ID     TO L5299-SBSDRY-CO-ID.
           MOVE RPOL-POL-ISS-LOC-CD   TO L5299-POL-ISS-LOC-CD.
           MOVE RPOL-CLI-CRNT-LOC-CD  TO L5299-POL-CRNT-LOC-CD.
           MOVE RPOL-POL-REG-CD       TO L5299-POL-REG-CD.
557659*    MOVE RPOL-POL-REINS-IND    TO L5299-POL-REINS-IND.
557659     MOVE RPOL-POL-REINS-CD     TO L5299-POL-REINS-CD.
           MOVE RPOL-SERV-BR-ID       TO L5299-POL-SERV-BR-ID.
016457*    MOVE 'C'                   TO L5299-CVG-IND.
012624*    MOVE 'MVMT'                TO L5299-TRXN-ID.
016537*    MOVE 'MVMT'                TO L5299-BUS-FCN-ID.
016537     MOVE MIR-BUS-FCN-ID        TO L5299-BUS-FCN-ID.
           MOVE ZEROES                TO L5299-LN-NUM.
           MOVE WCVGS-CVG-SUPP-BNFT-CD (I)
                                      TO L5299-CVG-SUPP-BNFT-CD.
           MOVE WCVGS-CVG-INS-TYP-CD (I)
                                      TO L5299-CVG-INS-TYP-CD.
           MOVE WCVGS-PLAN-ID (I)     TO L5299-CVG-PLAN-ID.
           MOVE I                     TO L5299-CVG-NUM.
           MOVE WCVGS-CVG-SUM-INS-AMT (I)
                                      TO L5299-CVG-SUM-INS-AMT.
           MOVE WCVGS-CVG-PAR-CD (I)  TO L5299-CVG-PAR-CD.
           MOVE WCVGS-CVG-ISS-EFF-DT (I)
                                      TO L5299-CVG-ISS-EFF-DT.
           MOVE WCVGS-CVG-STAT-CD (I) TO L5299-CVG-STAT-CD.

       3040-INITIALIZE-MVMT-X.
           EXIT.
      /
      *------------------
       3060-SET-UP-LINE0.
      *------------------

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

557668*    MOVE L2430-CLI-NM-COMPRESSED   TO MIR-DV-CLI-NM.

557668     INITIALIZE L0620-INPUT-PARM-INFO.
557668     IF L2430-CLI-SEX-COMPANY
557668         MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668     ELSE
557668         MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668         MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
015705         MOVE L2430-CLI-MID-INIT-NM   TO
015705                                L0620-CLI-MID-INIT-NM
015705         MOVE L2430-CLI-SFX-NM  TO L0620-CLI-SFX-NM

557668     END-IF.
557668     MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.

557668     PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668         THRU 0620-1000-FORMAT-SCREEN-NAME-X.

557668     MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.

           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
012624*    MOVE WCVGS-CVG-CSTAT-CD (I)
012624     MOVE WCVGS-CVG-CSTAT-CD (HOLD-COV-NO)
                                      TO MIR-CVG-CSTAT-CD.

       3060-SET-UP-LINE0-X.
           EXIT.
      /
      *------------------
       3080-SET-UP-LINE1.
      *------------------
      *
016457*    MOVE L5299-CVG-PLAN-ID     TO MIR-PLAN-ID.
016457     MOVE L5299-CVG-PLAN-ID     TO MIR-CVG-PLAN-ID.
           MOVE L5299-CVG-PAR-CD      TO MIR-CVG-PAR-CD.
           MOVE L5299-POL-REINS-CD    TO MIR-POL-REINS-CD.
           MOVE L5299-POL-SERV-BR-ID  TO MIR-SERV-BR-ID.
           MOVE L5299-POL-REG-CD      TO MIR-POL-REG-CD.
           MOVE L5299-CVG-INS-TYP-CD  TO MIR-CVG-INS-TYP-CD.
016457*    MOVE L5299-LN-NUM          TO MIR-DV-MVT-LN-CD.
016457     MOVE L5299-LN-NUM          TO MIR-MVT-TRXN-LN-NUM.
016457*    MOVE L5299-ON-OFF-IND      TO MIR-DV-MVT-CD.
020874*    COMPUTE L0290-INPUT-NUMBER = L5299-ON-OFF-IND.
020874     MOVE L5299-ON-OFF-IND         TO L0290-INPUT-V00.
016457     MOVE ZERO                     TO L0290-PRECISION.
016457     MOVE LENGTH OF MIR-MVT-TRXN-FCT
016457                                   TO L0290-MAX-OUT-LEN.
016457     SET L0290-SIGN-DISPLAY        TO TRUE.
016457     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
016457     SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
034433*    PERFORM  0290-2000-FORMAT-FOR-MIR
034433*        THRU 0290-2000-FORMAT-FOR-MIR-X.
034433     PERFORM  0290-1000-NUMERIC-FORMAT
034433         THRU 0290-1000-NUMERIC-FORMAT-X.
016457     MOVE L0290-OUTPUT-DATA
016457     TO MIR-MVT-TRXN-FCT.

020874*    COMPUTE L0290-INPUT-NUMBER = L5299-CVG-SUM-INS-AMT * 100.
020874     MOVE L5299-CVG-SUM-INS-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-SUM-INS-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-SUM-INS-AMT.

016457*    MOVE L5299-POL-COUNT-CD    TO MIR-DV-POL-MVT-CD.
016457*    MOVE L5299-CVG-COUNT-CD    TO MIR-DV-CVG-MVT-CD.
016457
020874*    COMPUTE L0290-INPUT-NUMBER = L5299-POL-COUNT-CD.
020874     MOVE L5299-POL-COUNT-CD       TO L0290-INPUT-V00.
016457     MOVE ZERO                     TO L0290-PRECISION.
016457     MOVE LENGTH OF MIR-MVT-TRXN-POL-QTY
016457                                   TO L0290-MAX-OUT-LEN.
016457     SET L0290-SIGN-DISPLAY        TO TRUE.
016457     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
023060*    SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
023060     SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
023060     PERFORM  0290-1000-NUMERIC-FORMAT
023060         THRU 0290-1000-NUMERIC-FORMAT-X.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023060*    PERFORM  0290-2000-FORMAT-FOR-MIR
023060*        THRU 0290-2000-FORMAT-FOR-MIR-X.
016457     MOVE L0290-OUTPUT-DATA
016457     TO MIR-MVT-TRXN-POL-QTY.
016457
020874*    COMPUTE L0290-INPUT-NUMBER = L5299-CVG-COUNT-CD.
020874     MOVE L5299-CVG-COUNT-CD       TO L0290-INPUT-V00.
016457     MOVE ZERO                     TO L0290-PRECISION.
016457     MOVE LENGTH OF MIR-MVT-TRXN-CVG-QTY
016457                                   TO L0290-MAX-OUT-LEN.
016457     SET L0290-SIGN-DISPLAY        TO TRUE.
016457     SET L0290-SIGN-POS-DISPLAY    TO TRUE.
023060*    SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
023060     SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
023060     PERFORM  0290-1000-NUMERIC-FORMAT
023060         THRU 0290-1000-NUMERIC-FORMAT-X.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023060*    PERFORM  0290-2000-FORMAT-FOR-MIR
023060*        THRU 0290-2000-FORMAT-FOR-MIR-X.
016457     MOVE L0290-OUTPUT-DATA
016457     TO MIR-MVT-TRXN-CVG-QTY.
016457
           MOVE L5299-CVG-SUPP-BNFT-CD
                                      TO MIR-CVG-SUPP-BNFT-CD.
           MOVE L5299-POL-CRCY-CD     TO MIR-POL-CRCY-CD.
           MOVE L5299-POL-ISS-LOC-CD  TO MIR-POL-ISS-LOC-CD.
           MOVE L5299-POL-CRNT-LOC-CD TO MIR-CLI-CRNT-LOC-CD.

       3080-SET-UP-LINE1-X.
           EXIT.

      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM  3020-READ-POL-AND-CVG
               THRU 3020-READ-POL-AND-CVG-X.

012624     PERFORM  3060-SET-UP-LINE0
012624         THRU 3060-SET-UP-LINE0-X.
012624
016457*    MOVE MIR-PLAN-ID           TO W0291-PLAN-ID.
016457     MOVE MIR-CVG-PLAN-ID       TO W0291-PLAN-ID.
           MOVE MIR-CVG-PAR-CD        TO W0291-PARCD.
           MOVE MIR-POL-REINS-CD      TO W0291-REI.
           MOVE MIR-SERV-BR-ID        TO W0291-BRANCH.
           MOVE MIR-POL-REG-CD        TO W0291-REG.
           MOVE MIR-CVG-INS-TYP-CD    TO W0291-TYPEINS.
016457*    MOVE MIR-DV-MVT-LN-CD      TO W0291-LINE.
016457     MOVE MIR-MVT-TRXN-LN-NUM   TO W0291-LINE.
016457*    MOVE MIR-DV-MVT-CD         TO W0291-COUNT.
016457     MOVE MIR-MVT-TRXN-FCT      TO W0291-COUNT.
           MOVE MIR-CVG-SUM-INS-AMT   TO W0291-SUMINS.
016457*    MOVE MIR-DV-POL-MVT-CD     TO W0291-POLSW.
029612*    MOVE MIR-MVT-TRXN-POL-QTY  TO W0291-POLSW.
016457*    MOVE MIR-DV-CVG-MVT-CD     TO W0291-COVSW.
029612*    MOVE MIR-MVT-TRXN-CVG-QTY  TO W0291-COVSW.
           MOVE MIR-CVG-SUPP-BNFT-CD  TO W0291-BENIND.
           MOVE MIR-POL-CRCY-CD       TO W0291-CURR.
           MOVE MIR-POL-ISS-LOC-CD    TO W0291-ISSLOC.
           MOVE MIR-CLI-CRNT-LOC-CD   TO W0291-CURLOC.

029612     IF  MIR-MVT-TRXN-POL-QTY = SPACES
029612         MOVE '+0'                     TO W0291-R-POLSW
029612         MOVE '+0'                     TO MIR-MVT-TRXN-POL-QTY
029612     ELSE
029612         MOVE MIR-MVT-TRXN-POL-QTY     TO W0291-R-POLSW
029612     END-IF.
029612
029612     IF  MIR-MVT-TRXN-CVG-QTY = SPACES
029612         MOVE '+0'                     TO W0291-R-COVSW
029612         MOVE '+0'                     TO MIR-MVT-TRXN-CVG-QTY
029612     ELSE
029612         MOVE MIR-MVT-TRXN-CVG-QTY     TO W0291-R-COVSW
029612     END-IF.
           PERFORM  5020-EDIT-CARD-C20
               THRU 5020-EDIT-CARD-C20-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
              GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  5040-PROCESS-CARD-C20
               THRU 5040-PROCESS-CARD-C20-X.

           MOVE HOLD-COV-NO           TO I.

           PERFORM  5060-MVMT-EDITS
               THRU 5060-MVMT-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

013578     IF  MIR-DV-PRCES-STATE-CD NOT = '3'
013578         MOVE 'CS02910002'      TO WGLOB-MSG-REF-INFO
013578         PERFORM  0260-1000-GENERATE-MESSAGE
013578             THRU 0260-1000-GENERATE-MESSAGE-X
013578         GO TO 5000-PROCESS-UPDATE-X
013578     END-IF.
013578
           MOVE WGLOB-COMPANY-CODE    TO L5299-CO-ID.
           MOVE RPOL-POL-ID           TO L5299-POL-ID.
010418     MOVE RPOL-SBSDRY-CO-ID     TO L5299-SBSDRY-CO-ID.
           MOVE I                     TO L5299-CVG-NUM.
           MOVE WCVGS-CVG-ISS-EFF-DT (I)
                                      TO L5299-CVG-ISS-EFF-DT.
           MOVE WGLOB-PROCESS-DATE    TO L5299-PRCES-DT.
           MOVE WCVGS-CVG-STAT-CD (I) TO L5299-CVG-STAT-CD.
012624*    MOVE 'MVMT'                TO L5299-TRXN-ID.
016537*    MOVE 'MVMT'                TO L5299-BUS-FCN-ID.
016537     MOVE MIR-BUS-FCN-ID        TO L5299-BUS-FCN-ID.
           PERFORM  5299-1000-WRITE-MVMT
               THRU 5299-1000-WRITE-MVMT-X.

557699     IF WGLOB-AUDIT-REQUESTED
025970*       PERFORM  7830-0000-INIT-PARM-INFO
025970        PERFORM  7830-0050-BUILD-PARM-INFO
025970*           THRU 7830-0000-INIT-PARM-INFO-X
025970            THRU 7830-0050-BUILD-PARM-INFO-X
557699        PERFORM  7830-1000-CALL-AUDIT
557699            THRU 7830-1000-CALL-AUDIT-X
557699     END-IF.

013578     MOVE 'CS02910005'          TO WGLOB-MSG-REF-INFO.
013578     PERFORM  0260-1000-GENERATE-MESSAGE
013578         THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *-------------------
       5020-EDIT-CARD-C20.
      *-------------------

           IF  W0291-PLAN-ID NOT = SPACES
               MOVE  W0291-PLAN-ID    TO WPH-PLAN-ID
               PERFORM  PH-1000-READ
                   THRU PH-1000-READ-X
               IF  NOT WPH-IO-OK
                   MOVE 'CS02910001'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-PLAN-ID
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-PARCD NOT = SPACES
               IF  W0291-PARCD NOT EQUAL 'N'
               AND W0291-PARCD NOT EQUAL 'P'
                   MOVE 'CS02910017'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-PARCD
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

557659*    IF  W0291-REI NOT = SPACES
               IF  W0291-REI NOT EQUAL 'A'
               AND W0291-REI NOT EQUAL 'Y'
557659         AND W0291-REI NOT EQUAL 'N'
                   MOVE 'CS02910018'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-REI
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF.
557659*    END-IF.

           IF  W0291-BRANCH NOT = SPACES
               MOVE W0291-BRANCH      TO WBRCH-BR-ID
               PERFORM  BRCH-1000-READ
                   THRU BRCH-1000-READ-X
               IF  NOT WBRCH-IO-OK
                   MOVE 'CS02910019'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-BRANCH
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-REG NOT = SPACES
               IF  W0291-REG NOT EQUAL 'B'
               AND W0291-REG NOT EQUAL 'F'
557659         AND W0291-REG NOT EQUAL 'N'
557659*        AND W0291-REG NOT EQUAL 'D'
557659*        AND W0291-REG NOT EQUAL 'P'
                   MOVE 'CS02910020'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-REG
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-TYPEINS NOT = SPACES
016537         IF  NOT W0291-TYPEINS-VALID
010311*        IF  W0291-TYPEINS NOT NUMERIC
016537*        IF  W0291-TYPEINS NOT EQUAL 'A' AND 'M' AND 'N'
010311*        AND W0291-TYPEINS NOT EQUAL 'A' AND 'E' AND 'M' AND 'N'
010311*                              AND 'R' AND 'U' AND 'L' AND 'T'
016537*                              AND '1' AND '2' AND '3' AND '5'
016537*                              AND '6' AND '7' AND '8' AND '9'
016537*                              AND 'C' AND 'D' AND 'I' AND 'K'
016537*                              AND 'S' AND 'F'
                   MOVE 'CS02910021'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-TYPEINS
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-LINE NOT = SPACES
               MOVE W0291-LINE        TO LINE-FIND-CODE
               PERFORM  LINE-1000-FIND
                   THRU LINE-1000-FIND-X
               IF  NOT LINE-DATA-VALID
                   MOVE 'CS02910007'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-LINE
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-R-COUNT NOT = SPACES
               IF  W0291-R-COUNT-NO NOT EQUAL '1' OR
016537*            NOT (W0291-R-COUNT-SG EQUAL '+' OR '-' OR ' ')
016537             NOT (W0291-R-COUNT-SG = '+' OR
016537                  W0291-R-COUNT-SG = '-' OR
016537                  W0291-R-COUNT-SG = ' ')
                   MOVE 'CS02910008'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-R-COUNT
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

008455*    IF  W0291-R-SUMINS NOT = SPACES
008455*        IF  W0291-R-SUMINS-NO NOT NUMERIC   OR
008455*            W0291-R-SUMINS-PT NOT EQUAL '.' OR
008455*            W0291-R-SUMINS-DC NOT NUMERIC
008455     IF  W0291-SUMINS NOT = SPACES
008455         MOVE W0291-SUMINS      TO L0280-INPUT-DATA
008455         MOVE 'N'               TO L0280-SIGN-IND
008455         MOVE 2                 TO L0280-PRECISION
008455         MOVE LENGTH OF MIR-CVG-SUM-INS-AMT
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
008455         PERFORM 0280-1000-NUMERIC-EDIT
008455            THRU 0280-1000-NUMERIC-EDIT-X
008455         IF  NOT L0280-OK
                   MOVE 'CS02910009'  TO WGLOB-MSG-REF-INFO
008455*            MOVE SPACE         TO W0291-R-SUMINS
008455             MOVE SPACE         TO W0291-SUMINS
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-R-POLSW NOT = SPACES
016537*        IF  W0291-R-POLSW-NO NOT EQUAL '0' AND '1'
016537         IF  (W0291-R-POLSW-NO NOT EQUAL '0'
016537         AND  W0291-R-POLSW-NO NOT EQUAL '1')
016537*        OR NOT (W0291-R-POLSW-SG EQUAL '+' OR '-' OR ' ')
016537         OR NOT (W0291-R-POLSW-SG EQUAL '+'
016537              OR W0291-R-POLSW-SG EQUAL '-'
016537              OR W0291-R-POLSW-SG EQUAL ' ')
                   MOVE 'CS02910010'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-R-POLSW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-R-COVSW NOT = SPACES
557660         IF  W0291-R-COVSW-NO NOT EQUAL '0'
               AND W0291-R-COVSW-NO NOT EQUAL '1'
016537*        OR NOT (W0291-R-COVSW-SG EQUAL '+' OR '-' OR ' ')
016537         OR NOT (W0291-R-COVSW-SG EQUAL '+'
016537              OR W0291-R-COVSW-SG EQUAL '-'
016537              OR W0291-R-COVSW-SG EQUAL ' ')
                   MOVE 'CS02910011'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-R-COVSW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-BENIND NOT = SPACES
557660         IF  W0291-BENIND NOT EQUAL 'Y'
               AND W0291-BENIND NOT EQUAL 'N'
               AND W0291-BENIND NOT EQUAL 'A'
               AND W0291-BENIND NOT EQUAL 'W'
               AND W0291-BENIND NOT EQUAL 'G'
                   MOVE 'CS02910012'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-BENIND
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-CURR NOT = SPACES
008455*        MOVE W0291-CURR        TO WEDIT-ETBL-VALU-ID
008455*        PERFORM  CURR-1000-EDIT-CURRENCY
008455*            THRU CURR-1000-EDIT-CURRENCY-X

008455         MOVE WGLOB-COMPANY-CODE
                                      TO WCRCY-CO-ID
008455         MOVE W0291-CURR        TO WCRCY-CRCY-CD
008455         PERFORM  CRCY-1000-READ
008455             THRU CRCY-1000-READ-X

008455*        IF  NOT WEDIT-IO-OK
008455         IF  NOT WCRCY-IO-OK
                   MOVE 'CS02910014'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-CURR
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-ISSLOC NOT = SPACES
006002*        MOVE W0291-ISSLOC      TO WEDIT-ETBL-VALU-ID
006002*        PERFORM  ILOC-1000-EDIT-ISSU-LOCATION
006002*            THRU ILOC-1000-EDIT-ISSU-LOCATION-X
006002*        IF  NOT WEDIT-IO-OK

006002         MOVE W0291-ISSLOC             TO WCTLC-CTRY-LOC-CD
029612         IF  RPOL-POL-CTRY-CD = SPACES
029612             MOVE WGLOB-COUNTRY-CODE   TO WCTLC-CTRY-CD
029612         ELSE
029612             MOVE RPOL-POL-CTRY-CD     TO WCTLC-CTRY-CD
029612         END-IF
029612*        MOVE RPOL-POL-CTRY-CD         TO WCTLC-CTRY-CD
006002         MOVE WGLOB-COMPANY-CODE       TO WCTLC-CO-ID
006002         SET WCTLC-CTRY-LOC-TYP-ISSUE  TO TRUE
006002         PERFORM  CTLC-1000-READ
006002             THRU CTLC-1000-READ-X
006002         IF  NOT WCTLC-IO-OK
                   MOVE 'CS02910015'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-ISSLOC
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  W0291-CURLOC NOT = SPACES
006002*        MOVE W0291-CURLOC      TO WEDIT-ETBL-VALU-ID
006002*        PERFORM  CLOC-1000-EDIT-CURR-LOCATION
006002*            THRU CLOC-1000-EDIT-CURR-LOCATION-X
006002*        IF  NOT WEDIT-IO-OK

006002         MOVE W0291-CURLOC              TO WCTLC-CTRY-LOC-CD
029612         IF  RPOL-POL-CTRY-CD = SPACES
029612             MOVE WGLOB-COUNTRY-CODE   TO WCTLC-CTRY-CD
029612         ELSE
029612             MOVE RPOL-POL-CTRY-CD     TO WCTLC-CTRY-CD
029612         END-IF
029612*        MOVE RPOL-POL-CTRY-CD          TO WCTLC-CTRY-CD
006002         MOVE WGLOB-COMPANY-CODE        TO WCTLC-CO-ID
006002         SET WCTLC-CTRY-LOC-TYP-CURRENT TO TRUE
006002         PERFORM  CTLC-1000-READ
006002             THRU CTLC-1000-READ-X
006002         IF  NOT WCTLC-IO-OK
                   MOVE 'CS02910016'  TO WGLOB-MSG-REF-INFO
                   MOVE SPACE         TO W0291-CURLOC
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

       5020-EDIT-CARD-C20-X.
           EXIT.
      /
      *----------------------
       5040-PROCESS-CARD-C20.
      *----------------------

           MOVE SPACES                TO L5299-PARM-INFO.

           IF  W0291-PLAN-ID NOT = SPACES
               MOVE W0291-PLAN-ID     TO L5299-CVG-PLAN-ID
           END-IF.

           IF  W0291-PARCD NOT = SPACES
              MOVE W0291-PARCD        TO L5299-CVG-PAR-CD
557660     END-IF.

           IF  W0291-REI NOT = SPACES
557659*        MOVE W0291-REI         TO L5299-POL-REINS-IND
557659         MOVE W0291-REI         TO L5299-POL-REINS-CD
557660     END-IF.

           IF  W0291-BRANCH NOT = SPACES
               MOVE W0291-BRANCH      TO L5299-POL-SERV-BR-ID
557660     END-IF.

           IF  W0291-REG NOT = SPACES
               MOVE W0291-REG         TO L5299-POL-REG-CD
557660     END-IF.

           IF  W0291-TYPEINS NOT = SPACES
               MOVE W0291-TYPEINS     TO L5299-CVG-INS-TYP-CD
557660     END-IF.

           IF  W0291-LINE NOT = SPACES
               MOVE W0291-LINE        TO L5299-LN-NUM
557660     END-IF.

           IF  W0291-COUNT NOT = SPACES
               MOVE W0291-COUNT-NO    TO L5299-ON-OFF-IND
               IF  W0291-COUNT-SG = '-'
                   MULTIPLY -1 BY L5299-ON-OFF-IND
557660         END-IF
557660     END-IF.

008455*    IF  W0291-R-SUMINS NOT = SPACES
008455*        COMPUTE L5299-CVG-SUM-INS-AMT
008455*              = W0291-SUMINS-NO + W0291-SUMINS-DC
008455     IF  W0291-SUMINS   NOT = SPACES
008455         MOVE W0291-SUMINS      TO L0280-INPUT-DATA
008455         MOVE 'N'               TO L0280-SIGN-IND
008455         MOVE 2                 TO L0280-PRECISION
008455         MOVE LENGTH OF MIR-CVG-SUM-INS-AMT
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
008455         PERFORM 0280-1000-NUMERIC-EDIT
008455            THRU 0280-1000-NUMERIC-EDIT-X
008455         MOVE L0280-OUTPUT-DOLLAR
                                      TO L5299-CVG-SUM-INS-AMT
557660     END-IF.

           IF  W0291-POLSW NOT = SPACES
               MOVE W0291-POLSW-NO    TO L5299-POL-COUNT-CD
               IF  W0291-POLSW-SG = '-'
                   MULTIPLY -1 BY L5299-POL-COUNT-CD
557660         END-IF
557660     END-IF.

           IF  W0291-COVSW NOT = SPACES
               MOVE W0291-COVSW-NO    TO L5299-CVG-COUNT-CD
               IF  W0291-COVSW-SG = '-'
                   MULTIPLY -1 BY L5299-CVG-COUNT-CD
557660         END-IF
557660     END-IF.

           IF  W0291-BENIND NOT = SPACES
               MOVE W0291-BENIND      TO L5299-CVG-SUPP-BNFT-CD
557660     END-IF.

           IF  W0291-CURR NOT = SPACES
               MOVE W0291-CURR        TO L5299-POL-CRCY-CD
557660     END-IF.

           IF  W0291-ISSLOC NOT = SPACES
               MOVE W0291-ISSLOC      TO L5299-POL-ISS-LOC-CD
557660     END-IF.

           IF  W0291-CURLOC NOT = SPACES
               MOVE W0291-CURLOC      TO L5299-POL-CRNT-LOC-CD
557660     END-IF.

       5040-PROCESS-CARD-C20-X.
           EXIT.
      /
      *----------------
       5060-MVMT-EDITS.
      *----------------

      ****************************************************************
      *  THIS PARAGRAPH WAS COPIED FROM CCPP99XE COPYBOOK.
      ****************************************************************

           IF  L5299-CVG-PLAN-ID = SPACES
      *MSG:    'PLAN CODE AND RATE SCALE MUST BE ENTERED'
               MOVE 'CS02910022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L5299-CVG-PAR-CD = SPACES
      *MSG:    'PAR CODE MUST BE ENTERED'
               MOVE 'CS02910023'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L5299-POL-SERV-BR-ID = SPACES
      *MSG:    'BRANCE MUST BE ENTERED'
               MOVE 'CS02910024'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L5299-CVG-INS-TYP-CD = SPACES
      *MSG:    'TYPE INSURANCE MUST BE ENTERED'
               MOVE 'CS02910025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L5299-POL-ISS-LOC-CD = SPACES
      *MSG:    'ISSUE LOCATION MUST BE ENTERED.'
               MOVE 'CS02910029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L5299-POL-CRNT-LOC-CD = SPACES
      *MSG:    'CURRENT LOCATION MUST BE ENTERED'
               MOVE 'CS02910030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L5299-LN-NUM   = ZEROES
      *MSG:    'LINE NUMBER MUST BE ENTERED'
               MOVE 'CS02910026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L5299-ON-OFF-IND = ZEROES
      *MSG:    'COUNT MUST BE ENTERED'
               MOVE 'CS02910027'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L5299-POL-COUNT-CD = 1
           AND L5299-CVG-COUNT-CD = 1
      *MSG:    'MUST ENTER EITHER POL OR COV - NOT BOTH'
               MOVE 'CS02910028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5060-MVMT-EDITS-X.
           EXIT.
      /
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE           TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
            MOVE MIR-CVG-NUM          TO WGLOB-REF-COVERAGE-NUMBER.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  5299-0000-INIT-PARM-INFO
025970         THRU 5299-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7830-0000-INIT-PARM-INFO
025970         THRU 7830-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-PGM-WORK-AREA.
025970     INITIALIZE  W0291-WORK-AREA.
025970     INITIALIZE  LINE-INX.
025970     INITIALIZE  LINE-FIND-CODE.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      * PROCESSING MODULES
      *****************************************************************

028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
012624*COPY XCPPMEXT.
      /
      *****************************************************************
      * LINKAGE PROCESSING MODULES
      *****************************************************************


       COPY CCPSPGA.
008455/
025970 COPY XCPS0280.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
008455 COPY XCPL0280.
008455/
008455 COPY XCPS0290.
008455 COPY XCPL0290.
      /
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      /
       COPY CCPS5299.
018764*COPY CCCL5299.
018764 COPY CCPL5299.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
557699 COPY CCPS7830.
018764*COPY CCCL7830.
018764 COPY CCPL7830.
      /
      *****************************************************************
      * EDIT ACCESS MODULES
      *****************************************************************

006002*COPY CCPEILOC.
006002*COPY CCPECLOC.
008455*COPY CCPECURR.
       COPY CCPELINE.
      /
      *****************************************************************
      * FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNBRCH.
      /
008455 COPY XCPNCRCY.
      /
       COPY CCPCCVG.
       COPY CCPNCVG.
      /
016537*COPY CCPNEDIT.
      /
       COPY CCPNPH.
      /
       COPY CCPNPOL.
006002 COPY XCPNCTLC.
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      /
      *****************************************************************
      * ERROR HANDLING ROUTINES
      *****************************************************************

026070*COPY XCCPABND.
026070 COPY XCCPERR.
557708*COPY XCCPHNDL.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0291                     **
      *****************************************************************


