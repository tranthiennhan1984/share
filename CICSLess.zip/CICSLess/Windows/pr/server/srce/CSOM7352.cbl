      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7352.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7352                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE UPDATE FUNCTION   **
      **            FOR THE PDCL AND PDCB TABLE                      **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7352'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-UPDATE            VALUE '7352'.
           05  WS-WORK-CTR.
               10  WS-SUB                       PIC S9(04) BINARY.
               10  WS-ROLE                      PIC S9(04) BINARY.
               10  WS-MIR-SUB                   PIC S9(04) BINARY.
               10  WS-ADJ-BENE                  PIC S9(04) BINARY.
           05  WS-TOTAL-DCBNFY-PCT              PIC S9(03)V9(02) COMP-3.
           05  WS-TOTAL-DCBNFY-PCT-SW           PIC X(01).
               88  WS-TOTAL-DCBNFY-PCT-NO       VALUE 'N'.
           05  WS-PDCL-INFO.
               10  WS-PDCL-DTHCLM-SEQ-NUM       PIC S9(04) BINARY.
               10  WS-PDCL-DTHCLM-INT-STRT-DT   PIC X(10).
           05  WS-PDCB-INFO.
               10  WS-PDCB-SUB                  PIC S9(04) BINARY.
               10  WS-PDCB-TOT-CTR              PIC S9(04) BINARY.
               10  WS-PDCB-TOT-PEND-CTR         PIC S9(04) BINARY.
           05  WS-DTHCLM-OVRID-IND              PIC X(01).
               88  WS-DTHCLM-OVRID              VALUE 'Y'.
               88  WS-DTHCLM-OVRID-NO           VALUE 'N'.
           05  WS-PDCL-DISPLAY-KEY.
               10  WS-COMPANY-ID                      PIC X(02).
               10  WS-POLICY-ID                       PIC X(10).
               10  WS-SEQ-NUM                         PIC 9(04).
           05  WS-TOT-DCBNFY-PD-AMT             PIC S9(13)V9(02) COMP-3.
           05  WS-DIFF-DCBNFY-PD-AMT            PIC S9(13)V9(02) COMP-3.

       01  WS-PDCB-DCBNFY-AREA.
           05  WS-PDCB-DCBNFY-INFO              OCCURS 99 TIMES.
               10  WS-DCBNFY-CLI-ID             PIC X(10).
               10  WS-DCBNFY-PD-AMT             PIC S9(11)V9(02) COMP-3.
               10  WS-DCBNFY-PCT                PIC S9(03)V9(02) COMP-3.
               10  WS-DCBNFY-INT-PD-AMT         PIC S9(11)V9(02) COMP-3.
               10  WS-DCBNFY-PD-DT              PIC X(10).
               10  WS-DCBNFY-REVRS-DT           PIC X(10).
               10  WS-DCBNFY-PAYO-CD            PIC X(01).
               10  WS-DCBNFY-FED-CALC-CD        PIC X(01).
               10  WS-FED-TAXWH-AMT             PIC S9(11)V9(02) COMP-3.
               10  WS-DCBNFY-BPSS-IND           PIC X(01).
               10  WS-DCBNFY-STAT-CD            PIC X(01).
                   88 WS-DCBNFY-STAT-PEND       VALUE '1'.
                   88 WS-DCBNFY-STAT-TOT-PD     VALUE '2'.
                   88 WS-DCBNFY-STAT-INT-PD     VALUE '3'.
                   88 WS-DCBNFY-STAT-DTH-CLM-PD VALUE '4'.

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                            PIC X(04).
               88 WS-TWRK-KEY-DEFAULT                 VALUE '7350'.
           05  WS-MAX-PDCB-CTR                        PIC S9(04).
               88  WS-MAX-PDCB-CTR-DEFAULT            VALUE 99.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
       COPY CCWWINDX.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.

       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFRPH.
       COPY CCFWPH.

       COPY CCFWPDCL.
       COPY CCFRPDCL.

       COPY CCFWPDCB.
       COPY CCFRPDCB.

       COPY CCFWCDSA.
       COPY CCFRCDSA.

       COPY CCWWCVGS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY CCWL2435.
028298 COPY CCWL2626.
       COPY CCWL3330.
       COPY CCWL5120.
029060 COPY CCWL5382. 
029060 COPY CCWL0182.       
       COPY CCWLDCIN.
       COPY CCWLPGA.

       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL0317.
       COPY XCWL1640.
       COPY XCWL2510.
       COPY XCWL8090.
       COPY XCWL8960.
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7352.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7352'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-UPDATE.
      *------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

      * VALIDATE KEY INFO

           PERFORM  8000-EDIT-INFO
               THRU 8000-EDIT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-UPDATE-X
           END-IF.

      * GET LOCATION GROUP

            PERFORM  6000-GET-LOCATION-GROUP
                THRU 6000-GET-LOCATION-GROUP-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

      * READ PDCL

           MOVE LOW-VALUES              TO WPDCL-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCL-CO-ID.
           MOVE RPOL-POL-ID             TO WPDCL-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM  TO WPDCL-DTHCLM-SEQ-NUM.

           PERFORM  PDCL-1000-READ-FOR-UPDATE
               THRU PDCL-1000-READ-FOR-UPDATE-X.

           IF  NOT WPDCL-IO-OK
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'        TO WGLOB-MSG-REF-INFO
               MOVE WPDCL-KEY             TO WS-PDCL-DISPLAY-KEY
               MOVE 0                     TO L0290-PRECISION
               MOVE LENGTH OF WS-SEQ-NUM  TO L0290-MAX-OUT-LEN
               MOVE WPDCL-DTHCLM-SEQ-NUM  TO L0290-INPUT-NUMBER
               PERFORM  0290-1000-NUMERIC-FORMAT
                   THRU 0290-1000-NUMERIC-FORMAT-X
               MOVE L0290-OUTPUT-DATA     TO WS-SEQ-NUM
               MOVE WS-PDCL-DISPLAY-KEY   TO WGLOB-MSG-PARM (1)
                     PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

      * EDIT PDCL

           PERFORM  2100-EDIT-PDCL
               THRU 2100-EDIT-PDCL-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  PDCL-3000-UNLOCK
                   THRU PDCL-3000-UNLOCK-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

      * EDIT PDCB

           PERFORM  3000-EDIT-PDCB
               THRU 3000-EDIT-PDCB-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

      * BLANK OUTPUT FIELDS

           PERFORM  8100-BLANK-DATA-FIELDS
               THRU 8100-BLANK-DATA-FIELDS-X.

           INITIALIZE WS-PDCB-DCBNFY-AREA.

      * CALL PRODUCTXPRESS TO CALCULATE DEATH CLAIM AMT AND INTEREST
      * AND DISPLAY PDCB

           PERFORM  8300-BUILD-PDCB-INFO
               THRU 8300-BUILD-PDCB-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

      * CROSS EDIT PDCL

           PERFORM  2200-CROSS-EDIT-PDCL
               THRU 2200-CROSS-EDIT-PDCL-X.

           PERFORM  PDCL-2000-REWRITE
               THRU PDCL-2000-REWRITE-X.

      * DISPLAY PDCL INFO

           PERFORM  8200-MOVE-PDCL-TO-MIR
               THRU 8200-MOVE-PDCL-TO-MIR-X.

      * REWRITE POLICY TABLE

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
      *MSG:    'RECORD UPDATED'
               MOVE 'XS00000008'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-UPDATE-X
           ELSE
      *MSG:    'MAINTENANCE COMPLETED - CONTINUE'
               MOVE 'XS00000007'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2000-UPDATE-X.
           EXIT.

      *---------------
       2100-EDIT-PDCL.
      *---------------

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
           OR  RPDCL-DTHCLM-STAT-PARTL-PD
               CONTINUE
           ELSE
      *MSG: STATUS OF PENDING INTEREST ON DEATH CLAIM IS PAID OR
      *     REVERSED, UPDATE NOT ALLOWED
               MOVE 'CS73520001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-EDIT-PDCL-X
           END-IF.

           PERFORM  2110-EDIT-DTHCLM-AMT
               THRU 2110-EDIT-DTHCLM-AMT-X.

           PERFORM  2120-EDIT-DTHCLM-ADDL-AMT
               THRU 2120-EDIT-DTHCLM-ADDL-AMT-X.

           PERFORM  2130-EDIT-DTHCLM-INT-STRT-DT
               THRU 2130-EDIT-DTHCLM-INT-STRT-DT-X.

           PERFORM  2140-GET-DTHCLM-INT-PCT
               THRU 2140-GET-DTHCLM-INT-PCT-X.

           PERFORM  2150-EDIT-DTHCLM-OVRID-IND
               THRU 2150-EDIT-DTHCLM-OVRID-IND-X.

      * WRITE COMMENT TEXT

           MOVE MIR-DTHCLM-COMNT-INFO
             TO RPDCL-DTHCLM-COMNT-INFO-TXT.

           MOVE LENGTH OF MIR-DTHCLM-COMNT-INFO
             TO RPDCL-DTHCLM-COMNT-INFO-LEN.

       2100-EDIT-PDCL-X.
           EXIT.

      *---------------------
       2110-EDIT-DTHCLM-AMT.
      *---------------------

      * DEFAULT FROM CDSA IF OVERRIDE IS NOT ALLOWED

           MOVE MIR-DTHCLM-OVRID-IND    TO WS-DTHCLM-OVRID-IND.

           IF  WS-DTHCLM-OVRID-NO
               PERFORM  2112-GET-DTHCLM-AMT
                   THRU 2112-GET-DTHCLM-AMT-X
               GO TO 2110-EDIT-DTHCLM-AMT-X
           END-IF.

      * EDIT CLAIM AMOUNT

           MOVE MIR-DTHCLM-AMT          TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DTHCLM-AMT
                                        TO L0280-INPUT-SIZE.
           MOVE +2                      TO L0280-PRECISION.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      * MSG: 'INVALID CLAIM AMOUNT (@1)'
               MOVE 'CS73520002'        TO WGLOB-MSG-REF-INFO
               MOVE  MIR-DTHCLM-AMT     TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V02     TO RPDCL-DTHCLM-AMT
           END-IF.

       2110-EDIT-DTHCLM-AMT-X.
           EXIT.

      *--------------------
       2112-GET-DTHCLM-AMT.
      *--------------------

      * DEFAULT BENEFICIARY CLAIM AMOUNT FROM CDSA

           MOVE ZERO                  TO RPDCL-DTHCLM-AMT.

      * POLICY DEATH TERMINATION

           IF  RPDCL-CVG-NUM = ZERO
           AND RPOL-POL-STAT-DEATH
               PERFORM  2114-GET-POL-DTHCLM-AMT
                   THRU 2114-GET-POL-DTHCLM-AMT-X
               GO TO 2112-GET-DTHCLM-AMT-X
           END-IF.

      * COVERAGE DEATH TERMINATION

           IF  RPDCL-CVG-NUM > ZERO
           AND WCVGS-CVG-STAT-DEATH (RPDCL-CVG-NUM-N)
               PERFORM  2116-GET-CVG-DTHCLM-AMT
                   THRU 2116-GET-CVG-DTHCLM-AMT-X
               GO TO 2112-GET-DTHCLM-AMT-X
           END-IF.

       2112-GET-DTHCLM-AMT-X.
           EXIT.

      *------------------------
       2114-GET-POL-DTHCLM-AMT.
      *------------------------

      * GET RCDSA-CDA-TOT-TRXN-AMT FOR POL TERMINATION,
      * DEFAULT TO CLAIM AMOUNT

           INITIALIZE WCDSA-KEY.
           MOVE RPOL-POL-ID           TO WCDSA-POL-ID.
           SET WCDSA-CDA-TYP-DTH-TRMN TO TRUE.
           MOVE ZERO                  TO WCDSA-POL-PAYO-NUM.
           MOVE LOW-VALUES            TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE ZERO                  TO WCDSA-CDA-SEQ-NUM.

           MOVE WCDSA-KEY             TO WCDSA-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCDSA-ENDBR-CDA-EFF-IDT-NUM.
           MOVE +999                  TO WCDSA-ENDBR-CDA-SEQ-NUM.

           PERFORM  CDSA-1000-BROWSE
               THRU CDSA-1000-BROWSE-X.

           PERFORM  CDSA-2000-READ-NEXT
               THRU CDSA-2000-READ-NEXT-X
               UNTIL NOT WCDSA-IO-OK
               OR    RCDSA-CDA-STAT-ACTIVE.

           IF  NOT WCDSA-IO-OK
               PERFORM  CDSA-3000-END-BROWSE
                   THRU CDSA-3000-END-BROWSE-X
               GO TO 2114-GET-POL-DTHCLM-AMT-X
           END-IF.

           PERFORM  CDSA-3000-END-BROWSE
               THRU CDSA-3000-END-BROWSE-X.

029060     PERFORM  5382-1000-BUILD-PARM-INFO
029060         THRU 5382-1000-BUILD-PARM-INFO-X.
029060
029060     SET L5382-GET-TAX-TYP-CDSA     TO TRUE.
029060     MOVE RCDSA-CDA-TYP-CD          TO L5382-CDA-TYP-CD.
029060     MOVE RCDSA-CDA-SEQ-NUM         TO L5382-CDA-SEQ-NUM.
029060     MOVE RCDSA-POL-PAYO-NUM        TO L5382-POL-PAYO-NUM.
029060     MOVE RCDSA-CDA-EFF-IDT-NUM     TO L5382-CDA-EFF-IDT-NUM.
029060     MOVE WWKDT-HIGH-DT             TO L5382-TAX-EFF-DT.
029060     MOVE 99999                     TO L5382-POLT-SEQ-NUM.
029060
029060     PERFORM  5382-7500-PRCES-READ-TAX
029060         THRU 5382-7500-PRCES-READ-TAX-X.
029060
029060*    COMPUTE RPDCL-DTHCLM-AMT = RCDSA-CDA-TOT-TRXN-AMT
029060*                             - RCDSA-CDA-FED-TAXWH-AMT
029060*                             - RCDSA-CDA-LTAXWH-AMT.
029060
029060     COMPUTE RPDCL-DTHCLM-AMT = RCDSA-CDA-TOT-TRXN-AMT
029060                              - L5382-FTAXWH-AMT
029060                              - L5382-LTAXWH-AMT.

       2114-GET-POL-DTHCLM-AMT-X.
           EXIT.

      *------------------------
       2116-GET-CVG-DTHCLM-AMT.
      *------------------------

      * GET RCDSA-CDA-TOT-TRXN-AMT FOR CVG TERMINATION,
      * DEFAULT TO CLAIM AMOUNT

           INITIALIZE WCDSA-KEY.
           MOVE RPOL-POL-ID           TO WCDSA-POL-ID.
           SET WCDSA-CDA-TYP-WTHDR    TO TRUE.
           MOVE ZERO                  TO WCDSA-POL-PAYO-NUM.
           MOVE LOW-VALUES            TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE ZERO                  TO WCDSA-CDA-SEQ-NUM.

           MOVE WCDSA-KEY             TO WCDSA-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCDSA-ENDBR-CDA-EFF-IDT-NUM.
           MOVE +999                  TO WCDSA-ENDBR-CDA-SEQ-NUM.

           PERFORM  CDSA-1000-BROWSE
               THRU CDSA-1000-BROWSE-X.

           PERFORM  CDSA-2000-READ-NEXT
               THRU CDSA-2000-READ-NEXT-X
               UNTIL NOT WCDSA-IO-OK
               OR   (RCDSA-CDA-STAT-ACTIVE
               AND   RCDSA-CVG-NUM-N = RPDCL-CVG-NUM-N).

           IF  NOT WCDSA-IO-OK
               PERFORM  CDSA-3000-END-BROWSE
                   THRU CDSA-3000-END-BROWSE-X
               GO TO 2116-GET-CVG-DTHCLM-AMT-X
           END-IF.

           PERFORM  CDSA-3000-END-BROWSE
               THRU CDSA-3000-END-BROWSE-X.

029060     PERFORM  5382-1000-BUILD-PARM-INFO
029060         THRU 5382-1000-BUILD-PARM-INFO-X.
029060
029060     SET L5382-GET-TAX-TYP-CDSA     TO TRUE.
029060     MOVE RCDSA-CDA-TYP-CD          TO L5382-CDA-TYP-CD.
029060     MOVE RCDSA-CDA-SEQ-NUM         TO L5382-CDA-SEQ-NUM.
029060     MOVE RCDSA-POL-PAYO-NUM        TO L5382-POL-PAYO-NUM.
029060     MOVE RCDSA-CDA-EFF-IDT-NUM     TO L5382-CDA-EFF-IDT-NUM.
029060     MOVE WWKDT-HIGH-DT             TO L5382-TAX-EFF-DT.
029060     MOVE 99999                     TO L5382-POLT-SEQ-NUM.
029060
029060     PERFORM  5382-7500-PRCES-READ-TAX
029060         THRU 5382-7500-PRCES-READ-TAX-X.
029060
029060*    COMPUTE RPDCL-DTHCLM-AMT = RCDSA-CDA-TOT-TRXN-AMT
029060*                             - RCDSA-CDA-FED-TAXWH-AMT
029060*                             - RCDSA-CDA-LTAXWH-AMT.
029060
029060     COMPUTE RPDCL-DTHCLM-AMT = RCDSA-CDA-TOT-TRXN-AMT
029060                              - L5382-FTAXWH-AMT
029060                              - L5382-LTAXWH-AMT.

       2116-GET-CVG-DTHCLM-AMT-X.
           EXIT.

      *--------------------------
       2120-EDIT-DTHCLM-ADDL-AMT.
      *--------------------------

      * EDIT ADDITIONAL CLAIM AMOUNT

           MOVE MIR-DTHCLM-ADDL-AMT     TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DTHCLM-ADDL-AMT
                                        TO L0280-INPUT-SIZE.
           MOVE +2                      TO L0280-PRECISION.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      * MSG: 'INVALID ADDITIONAL CLAIM AMOUNT (@1)'
               MOVE 'CS73520003'         TO WGLOB-MSG-REF-INFO
               MOVE  MIR-DTHCLM-ADDL-AMT TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V02     TO RPDCL-DTHCLM-ADDL-AMT
           END-IF.

       2120-EDIT-DTHCLM-ADDL-AMT-X.
           EXIT.

      *-----------------------------
       2130-EDIT-DTHCLM-INT-STRT-DT.
      *-----------------------------

           IF  MIR-DTHCLM-INT-STRT-DT = SPACES
               MOVE WWKDT-ZERO-DT       TO RPDCL-DTHCLM-INT-STRT-DT
               GO TO 2130-EDIT-DTHCLM-INT-STRT-DT-X
           END-IF.

           MOVE MIR-DTHCLM-INT-STRT-DT  TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      * MSG: 'INTEREST START DATE (@1) INVALID
               MOVE 'CS73520004'           TO WGLOB-MSG-REF-INFO
               MOVE MIR-DTHCLM-INT-STRT-DT TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2130-EDIT-DTHCLM-INT-STRT-DT-X
           END-IF.

           IF  L1640-INTERNAL-DATE > WGLOB-SYSTEM-DATE-INT
      * MSG: 'INTEREST START DATE (@1) GREATER THAN SYSTEM DATE
               MOVE 'CS73520015'           TO WGLOB-MSG-REF-INFO
               MOVE MIR-DTHCLM-INT-STRT-DT TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2130-EDIT-DTHCLM-INT-STRT-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE     TO WS-PDCL-DTHCLM-INT-STRT-DT.

           MOVE L1640-INTERNAL-DATE     TO RPDCL-DTHCLM-INT-STRT-DT.

       2130-EDIT-DTHCLM-INT-STRT-DT-X.
           EXIT.

      *-----------------------
       2140-GET-DTHCLM-INT-PCT.
      *-----------------------

      * IF INTEREST START DATE = SPACES, THEN INTEREST RATE = ZERO

           IF  MIR-DTHCLM-INT-STRT-DT = SPACES
               MOVE ZERO                   TO RPDCL-DTHCLM-INT-PCT
               GO TO 2140-GET-DTHCLM-INT-PCT-X
           END-IF.

      * EXIT IF PDCL STATUS NOT = PENDING, ERROR AND PARTIALLY PAID

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
           OR  RPDCL-DTHCLM-STAT-PARTL-PD
               CONTINUE
           ELSE
               GO TO 2140-GET-DTHCLM-INT-PCT-X
           END-IF.

      * CALL PRODUCTXPRESS TO OBTAIN INTEREST RATE BY PASSING INTEREST
      * START DATE AND LOCATION GROUP.

           PERFORM  9500-PCALC-EXIT-DCIN
               THRU 9500-PCALC-EXIT-DCIN-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2140-GET-DTHCLM-INT-PCT-X
           END-IF.

           PERFORM  DCIN-1000-BUILD-PARM-INFO
               THRU DCIN-1000-BUILD-PARM-INFO-X.

           MOVE RPDCL-CVG-NUM              TO LDCIN-CVG-NUM.
           MOVE WS-PDCL-DTHCLM-INT-STRT-DT TO LDCIN-DTHCLM-INT-STRT-DT.
           MOVE L3330-LOC-GR-ID            TO LDCIN-LOC-GR-ID.

           PERFORM  DCIN-1000-CALC-DCBNFY-INT
               THRU DCIN-1000-CALC-DCBNFY-INT-X.

           IF  NOT LDCIN-RETRN-OK
               GO TO 2140-GET-DTHCLM-INT-PCT-X
           END-IF.

           MOVE LDCIN-DTHCLM-INT-PCT       TO RPDCL-DTHCLM-INT-PCT.

       2140-GET-DTHCLM-INT-PCT-X.
           EXIT.

      *---------------------------
       2150-EDIT-DTHCLM-OVRID-IND.
      *---------------------------

           PERFORM  2510-1000-BUILD-PARM-INFO
               THRU 2510-1000-BUILD-PARM-INFO-X.

           MOVE MIR-DTHCLM-OVRID-IND      TO L2510-RESPONSE-TXT.
           SET L2510-VALUE-LENGTH-SHORT   TO TRUE.

           PERFORM  2510-1000-VALIDATE-RESPONSE
               THRU 2510-1000-VALIDATE-RESPONSE-X.

           IF  L2510-RESPONSE-INVALID
      *MSG:     'INVALID DEATH CLAIM AMOUNT OVERRIDE'
               MOVE 'CS73520015'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2150-EDIT-DTHCLM-OVRID-IND-X
           END-IF.

           MOVE MIR-DTHCLM-OVRID-IND       TO RPDCL-DTHCLM-OVRID-IND.

       2150-EDIT-DTHCLM-OVRID-IND-X.
           EXIT.

      *---------------------
       2200-CROSS-EDIT-PDCL.
      *---------------------

      * SET THE STATUS OF THE PENDING INTEREST ON DEATH CLAIM RECORD

           IF  RPDCL-DTHCLM-INT-DT-DT-OF-DTH
           OR  RPDCL-DTHCLM-INT-DT-PROOF-DTH
           OR  RPDCL-DTHCLM-INT-DT-USER-DT
               IF  RPDCL-DTHCLM-INT-STRT-DT = WWKDT-ZERO-DT
               OR  RPDCL-DTHCLM-INT-PCT = ZERO
                   SET RPDCL-DTHCLM-STAT-ERROR   TO TRUE
                   GO TO 2200-CROSS-EDIT-PDCL-X
               END-IF
           END-IF.

      * UPDATE PDCL STATUS TO PENDING IF PDCL STATUS = ERROR

           IF  RPDCL-DTHCLM-STAT-ERROR
           AND WS-PDCB-TOT-PEND-CTR > ZERO
               SET RPDCL-DTHCLM-STAT-PEND    TO TRUE
           END-IF.

      * UPDATE PDCL STATUS TO ERROR IF TOTAL BENEFICIARY PCT NOT = 100
      * IF PDCL STATUS NOT = PARTIALLY PAID

           IF  WS-TOTAL-DCBNFY-PCT-NO
           AND NOT RPDCL-DTHCLM-STAT-PARTL-PD
               SET RPDCL-DTHCLM-STAT-ERROR   TO TRUE
           END-IF.

       2200-CROSS-EDIT-PDCL-X.
           EXIT.

      *---------------
       3000-EDIT-PDCB.
      *---------------

      * LOAD PDCB INFO TO WORKING STORAGE

           PERFORM  3100-MOVE-PDCB-TO-WS
               THRU 3100-MOVE-PDCB-TO-WS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-EDIT-PDCB-X
           END-IF.

      * EDIT MIR PDCB INFO

           MOVE ZERO                      TO WS-TOTAL-DCBNFY-PCT.
           MOVE SPACE                     TO WS-TOTAL-DCBNFY-PCT-SW.

           PERFORM  3200-EDIT-PDCB-INFO
               THRU 3200-EDIT-PDCB-INFO-X
               VARYING WS-MIR-SUB FROM 1 BY +1
               UNTIL   WS-MIR-SUB > WS-MAX-PDCB-CTR
               OR      WGLOB-MSG-ERROR-SW > ZERO.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-EDIT-PDCB-X
           END-IF.

      * BENEFICIARY PERCENTAGE MUST TOTAL 100%

           IF  WS-TOTAL-DCBNFY-PCT NOT = 100
               SET WS-TOTAL-DCBNFY-PCT-NO  TO TRUE
      *MSG:   'BENEIFICARY PERCENTAGE MUST TOTAL 100%'
               MOVE 'CS73520005'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 3000-EDIT-PDCB-X
               END-IF
           END-IF.

      * DELETE PDCB RECORDS

            PERFORM  3300-DELETE-PDCB
                THRU 3300-DELETE-PDCB-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-EDIT-PDCB-X
           END-IF.

      * WRITE PDCB RECORDS FROM MIR

           PERFORM  3400-WRITE-PDCB
               THRU 3400-WRITE-PDCB-X
               VARYING WS-MIR-SUB FROM 1 BY +1
               UNTIL   WS-MIR-SUB > WS-MAX-PDCB-CTR
               OR      WGLOB-MSG-ERROR-SW > ZERO.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-EDIT-PDCB-X
           END-IF.

       3000-EDIT-PDCB-X.
           EXIT.

      *---------------------
       3100-MOVE-PDCB-TO-WS.
      *---------------------

           PERFORM  9000-BUILD-PDCB-BROWSE-KEY
               THRU 9000-BUILD-PDCB-BROWSE-KEY-X.

           PERFORM  PDCB-1000-BROWSE
               THRU PDCB-1000-BROWSE-X.

           PERFORM  PDCB-2000-READ-NEXT
               THRU PDCB-2000-READ-NEXT-X.

           IF  WPDCB-IO-EOF
               PERFORM  PDCB-3000-END-BROWSE
                   THRU PDCB-3000-END-BROWSE-X
               GO TO 3100-MOVE-PDCB-TO-WS-X
           END-IF.

           PERFORM  3110-LOAD-PDCB-LOOP
               THRU 3110-LOAD-PDCB-LOOP-X
               VARYING WS-PDCB-SUB FROM 1 BY +1
               UNTIL   WS-PDCB-SUB > WS-MAX-PDCB-CTR
               OR      WPDCB-IO-EOF
               OR      WGLOB-MSG-ERROR-SW > ZERO.

           IF  WPDCB-IO-EOF
           OR  WGLOB-MSG-ERROR-SW > ZERO
               MOVE WS-PDCB-SUB          TO WS-PDCB-TOT-CTR
           ELSE
      *MSG:   'BENEIFICARY RECORD EXCEEDS MAXIMUM'
               MOVE 'CS73520006'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDCB-3000-END-BROWSE
               THRU PDCB-3000-END-BROWSE-X.

       3100-MOVE-PDCB-TO-WS-X.
           EXIT.

      *--------------------
       3110-LOAD-PDCB-LOOP.
      *--------------------

           MOVE RPDCB-CLI-ID         TO WS-DCBNFY-CLI-ID (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-PD-AMT  TO WS-DCBNFY-PD-AMT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-PCT     TO WS-DCBNFY-PCT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-INT-PD-AMT
                                 TO WS-DCBNFY-INT-PD-AMT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-PD-DT   TO WS-DCBNFY-PD-DT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-REVRS-DT TO
                                       WS-DCBNFY-REVRS-DT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-PAYO-CD TO WS-DCBNFY-PAYO-CD (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-FED-CALC-CD TO
                                    WS-DCBNFY-FED-CALC-CD (WS-PDCB-SUB).
029060*    MOVE RPDCB-FED-TAXWH-AMT   TO WS-FED-TAXWH-AMT (WS-PDCB-SUB).
029060     MOVE RPDCB-FTAXWH-AMT      TO WS-FED-TAXWH-AMT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-BPSS-IND TO
                                       WS-DCBNFY-BPSS-IND (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-STAT-CD TO WS-DCBNFY-STAT-CD (WS-PDCB-SUB).

      * READ NEXT RECORD

           PERFORM  PDCB-2000-READ-NEXT
               THRU PDCB-2000-READ-NEXT-X.

       3110-LOAD-PDCB-LOOP-X.
           EXIT.

      *--------------------
       3200-EDIT-PDCB-INFO.
      *--------------------

      * NO EDIT IF CLIENT ID = SPACES

           IF  MIR-CLI-ID-T (WS-MIR-SUB) = SPACES
               GO TO 3200-EDIT-PDCB-INFO-X
           END-IF.

      * EDIT CLIENT ID

           PERFORM  3210-EDIT-CLI-ID
               THRU 3210-EDIT-CLI-ID-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3200-EDIT-PDCB-INFO-X
           END-IF.

      * EDIT BENEFICIARY PERCENTAGE

           PERFORM  3220-EDIT-DCBNFY-PCT
               THRU 3220-EDIT-DCBNFY-PCT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3200-EDIT-PDCB-INFO-X
           END-IF.

      * EDIT PAYOUT METHOD

           PERFORM  3230-EDIT-DCBNFY-PAYO-CD
               THRU 3230-EDIT-DCBNFY-PAYO-CD-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3200-EDIT-PDCB-INFO-X
           END-IF.

      * EDIT FEDERAL CALC CODE

           PERFORM  3240-EDIT-DCBNFY-FED-CALC-CD
               THRU 3240-EDIT-DCBNFY-FED-CALC-CD-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3200-EDIT-PDCB-INFO-X
           END-IF.

      * EDIT BYPASS TAX REPORTING INDICATOR

           PERFORM  3250-EDIT-DCBNFY-BPSS-IND
               THRU 3250-EDIT-DCBNFY-BPSS-IND-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3200-EDIT-PDCB-INFO-X
           END-IF.

       3200-EDIT-PDCB-INFO-X.
           EXIT.

      *-----------------
       3210-EDIT-CLI-ID.
      *-----------------

      * EDIT CLIENT ID

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID-T (WS-MIR-SUB)    TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  L2435-RETRN-CLI-NOT-FOUND
      *MSG:   'BENEFICIARY CLIENT (@1) NUMBER DOES NOT EXIST'
               MOVE 'CS73520007'           TO WGLOB-MSG-REF-INFO
               MOVE L2435-CLI-ID           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3210-EDIT-CLI-ID-X
           END-IF.

      * CHECK WHETHER DUPLICATE MIR CLIENT ID EXISTS

           PERFORM  3212-CHECK-DUPLICATE-CLI
               THRU 3212-CHECK-DUPLICATE-CLI-X
               VARYING WS-SUB FROM 1 BY +1
                 UNTIL WS-SUB > WS-MAX-PDCB-CTR
                    OR WGLOB-MSG-ERROR-SW > ZERO.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3210-EDIT-CLI-ID-X
           END-IF.

       3210-EDIT-CLI-ID-X.
           EXIT.

      *-------------------------
       3212-CHECK-DUPLICATE-CLI.
      *-------------------------

           IF  WS-SUB = WS-MIR-SUB
               GO TO 3212-CHECK-DUPLICATE-CLI-X
           END-IF.

           IF  MIR-CLI-ID-T (WS-SUB) = MIR-CLI-ID-T (WS-MIR-SUB)
      *MSG:   'DUPLICATE BENEFICIARY CLIENT NUMBER (@1)'
               MOVE 'CS73520008'           TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID-T (WS-SUB)  TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3212-CHECK-DUPLICATE-CLI-X
           END-IF.

       3212-CHECK-DUPLICATE-CLI-X.
           EXIT.

      *---------------------
       3220-EDIT-DCBNFY-PCT.
      *---------------------

           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE 2                          TO L0280-PRECISION.
           MOVE 6                          TO L0280-LENGTH.
           MOVE 6                          TO L0280-INPUT-SIZE.
           MOVE MIR-DCBNFY-PCT-T (WS-MIR-SUB) TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'BENEFICIARY PERCENT NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS73520009'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3220-EDIT-DCBNFY-PCT-X
           END-IF.

           ADD L0280-OUTPUT-V02            TO WS-TOTAL-DCBNFY-PCT.

       3220-EDIT-DCBNFY-PCT-X.
           EXIT.

      *-------------------------
       3230-EDIT-DCBNFY-PAYO-CD.
      *-------------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'DCBNFY-PAYO-CD'         TO L8960-AV-TBL-CD.
           MOVE MIR-DCBNFY-PAYO-CD-T (WS-MIR-SUB)
                                         TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  NOT L8960-RETRN-OK
      *MSG:     'INVALID PAY OUT METHOD ON BENEFICIARY (@1)'
               MOVE 'CS73520010'              TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID-T (WS-MIR-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3230-EDIT-DCBNFY-PAYO-CD-X
           END-IF.

       3230-EDIT-DCBNFY-PAYO-CD-X.
           EXIT.

      *-----------------------------
       3240-EDIT-DCBNFY-FED-CALC-CD.
      *-----------------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'DCBNFY-FED-CALC-CD'     TO L8960-AV-TBL-CD.
           MOVE MIR-DCBNFY-FED-CALC-CD-T (WS-MIR-SUB)
                                         TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  NOT L8960-RETRN-OK
      *MSG:     'INVALID FEDERAL TAX WITHHOLDING CALCULATION ON
      *          BENEFICIARY (@1)'
               MOVE 'CS73520013'           TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID-T (WS-MIR-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3240-EDIT-DCBNFY-FED-CALC-CD-X
           END-IF.

       3240-EDIT-DCBNFY-FED-CALC-CD-X.
           EXIT.

      *--------------------------
       3250-EDIT-DCBNFY-BPSS-IND.
      *--------------------------

           PERFORM  2510-1000-BUILD-PARM-INFO
               THRU 2510-1000-BUILD-PARM-INFO-X.

           MOVE MIR-DCBNFY-BPSS-IND-T (WS-MIR-SUB)
                                          TO L2510-RESPONSE-TXT.
           SET L2510-VALUE-LENGTH-SHORT   TO TRUE.

           PERFORM  2510-1000-VALIDATE-RESPONSE
               THRU 2510-1000-VALIDATE-RESPONSE-X.

           IF  L2510-RESPONSE-INVALID
      *MSG:     'INVALID BYPASS TAX REPORTING INDICATOR ON
      *          BENEFICIARY (@1)'
               MOVE 'CS73520014'           TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID-T (WS-MIR-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3250-EDIT-DCBNFY-BPSS-IND-X
           END-IF.

       3250-EDIT-DCBNFY-BPSS-IND-X.
           EXIT.

      *-----------------
       3300-DELETE-PDCB.
      *-----------------

           MOVE LOW-VALUES               TO WPDCB-KEY.
           MOVE WGLOB-COMPANY-CODE       TO WPDCB-CO-ID.
           MOVE RPOL-POL-ID              TO WPDCB-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM   TO WPDCB-DTHCLM-SEQ-NUM.

           MOVE WPDCB-KEY                TO WPDCB-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WPDCB-ENDBR-CLI-ID.

           PERFORM  PDCB-1000-DELETE-KEY-RANGE
              THRU  PDCB-1000-DELETE-KEY-RANGE-X.

       3300-DELETE-PDCB-X.
           EXIT.

      *----------------
       3400-WRITE-PDCB.
      *----------------

      * EXIT IF MIR CLIENT ID = SPACES

           IF  MIR-CLI-ID-T (WS-MIR-SUB) = SPACES
               GO TO 3400-WRITE-PDCB-X
           END-IF.

      * MATCH MIR PDCB RECORD WITH WORKING STORAGE

           PERFORM
               VARYING WS-PDCB-SUB FROM 1 BY +1
                 UNTIL WS-DCBNFY-CLI-ID (WS-PDCB-SUB) =
                       MIR-CLI-ID-T (WS-MIR-SUB)
                    OR WS-PDCB-SUB > WS-PDCB-TOT-CTR
                    CONTINUE
           END-PERFORM.

      * NEW CLIENT ID ENTERED IF WS-PDCB-SUB > WS-PDCB-TOT-CTR

           IF  WS-PDCB-SUB > WS-PDCB-TOT-CTR
               PERFORM  3410-WRITE-NEW-PDCB
                   THRU 3410-WRITE-NEW-PDCB-X
           ELSE
               PERFORM  3420-WRITE-EXIST-PDCB
                   THRU 3420-WRITE-EXIST-PDCB-X
           END-IF.

       3400-WRITE-PDCB-X.
           EXIT.

      *--------------------
       3410-WRITE-NEW-PDCB.
      *--------------------

      * CREATE AND WRITE PDCB RECORD

           MOVE LOW-VALUES                 TO WPDCB-KEY.
           MOVE WGLOB-COMPANY-CODE         TO WPDCB-CO-ID.
           MOVE RPOL-POL-ID                TO WPDCB-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM     TO WPDCB-DTHCLM-SEQ-NUM.
           MOVE MIR-CLI-ID-T (WS-MIR-SUB)  TO WPDCB-CLI-ID.

           PERFORM  PDCB-1000-CREATE
               THRU PDCB-1000-CREATE-X.

      * WRITE RPDCB-DCBNFY-STAT-CD = PENDING

           SET RPDCB-DCBNFY-STAT-PEND      TO TRUE.

      * WRITE RPDCB-DCBNFY-PCT

           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE 2                          TO L0280-PRECISION.
           MOVE 6                          TO L0280-LENGTH.
           MOVE 6                          TO L0280-INPUT-SIZE.
           MOVE MIR-DCBNFY-PCT-T (WS-MIR-SUB) TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
               GO TO 3410-WRITE-NEW-PDCB-X
           END-IF.

           MOVE L0280-OUTPUT-V02            TO RPDCB-DCBNFY-PCT.

      * WRITE RPDCB-DCBNFY-PAYO-CD

           MOVE MIR-DCBNFY-PAYO-CD-T (WS-MIR-SUB)
                                            TO RPDCB-DCBNFY-PAYO-CD.

      * WRITE RPDCB-DCBNFY-FED-CALC-CD

           MOVE MIR-DCBNFY-FED-CALC-CD-T (WS-MIR-SUB)
                                            TO RPDCB-DCBNFY-FED-CALC-CD.

      * WRITE RPDCB-DCBNFY-BPSS-IND

           MOVE MIR-DCBNFY-BPSS-IND-T (WS-MIR-SUB)
                                            TO RPDCB-DCBNFY-BPSS-IND.

      * IF BYPASS TAX REPORTING, FED-CALC-CD = BYPASS

           IF  RPDCB-DCBNFY-BPSS
               SET RPDCB-DCBNFY-FED-CALC-BPSS TO TRUE
           END-IF.

      * WRITE PDCB

           PERFORM  PDCB-1000-WRITE
               THRU PDCB-1000-WRITE-X.

       3410-WRITE-NEW-PDCB-X.
           EXIT.

      *----------------------
       3420-WRITE-EXIST-PDCB.
      *----------------------

           MOVE LOW-VALUES                 TO WPDCB-KEY.
           MOVE WGLOB-COMPANY-CODE         TO WPDCB-CO-ID.
           MOVE RPOL-POL-ID                TO WPDCB-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM     TO WPDCB-DTHCLM-SEQ-NUM.
           MOVE MIR-CLI-ID-T (WS-MIR-SUB)  TO WPDCB-CLI-ID.

           PERFORM  PDCB-1000-CREATE
               THRU PDCB-1000-CREATE-X.

      * MOVE MIR INFO TO PDCB TABLE IF STATUS = PENDING ONLY

           PERFORM  3422-MOVE-MIR-TO-PDCB
               THRU 3422-MOVE-MIR-TO-PDCB-X.

      * MOVE WORKING STORAGE INFO TO PDCB

           MOVE WS-DCBNFY-PD-AMT (WS-PDCB-SUB)
             TO RPDCB-DCBNFY-PD-AMT.
           MOVE WS-DCBNFY-INT-PD-AMT (WS-PDCB-SUB)
             TO RPDCB-DCBNFY-INT-PD-AMT.
           MOVE WS-DCBNFY-PD-DT (WS-PDCB-SUB)
             TO RPDCB-DCBNFY-PD-DT.
           MOVE WS-DCBNFY-REVRS-DT (WS-PDCB-SUB)
             TO RPDCB-DCBNFY-REVRS-DT.
           MOVE WS-FED-TAXWH-AMT (WS-PDCB-SUB)
029060*      TO RPDCB-FED-TAXWH-AMT.
029060       TO RPDCB-FTAXWH-AMT.
           MOVE WS-DCBNFY-STAT-CD (WS-PDCB-SUB)
             TO RPDCB-DCBNFY-STAT-CD.

      * IF BYPASS TAX REPORTING, FED-CALC-CD = BYPASS

           IF  RPDCB-DCBNFY-BPSS
               SET RPDCB-DCBNFY-FED-CALC-BPSS TO TRUE
           END-IF.

      * WRITE PDCB

           PERFORM  PDCB-1000-WRITE
               THRU PDCB-1000-WRITE-X.

       3420-WRITE-EXIST-PDCB-X.
           EXIT.

      *----------------------
       3422-MOVE-MIR-TO-PDCB.
      *----------------------

      * WRITE RPDCB-DCBNFY-PCT

           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE 2                          TO L0280-PRECISION.
           MOVE 6                          TO L0280-LENGTH.
           MOVE 6                          TO L0280-INPUT-SIZE.
           MOVE MIR-DCBNFY-PCT-T (WS-MIR-SUB) TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
               GO TO 3422-MOVE-MIR-TO-PDCB-X
           END-IF.

           MOVE L0280-OUTPUT-V02           TO RPDCB-DCBNFY-PCT.

      * WRITE RPDCB-DCBNFY-PAYO-CD

           MOVE MIR-DCBNFY-PAYO-CD-T (WS-MIR-SUB)
                                           TO RPDCB-DCBNFY-PAYO-CD.

      * WRITE RPDCB-DCBNFY-FED-CALC-CD

           MOVE MIR-DCBNFY-FED-CALC-CD-T (WS-MIR-SUB)
                                            TO RPDCB-DCBNFY-FED-CALC-CD.

      * WRITE RPDCB-DCBNFY-BPSS-IND

           MOVE MIR-DCBNFY-BPSS-IND-T (WS-MIR-SUB)
                                            TO RPDCB-DCBNFY-BPSS-IND.

       3422-MOVE-MIR-TO-PDCB-X.
           EXIT.

      *------------------------
       6000-GET-LOCATION-GROUP.
      *------------------------

           MOVE RPOL-POL-BASE-CVG-NUM  TO  I.

           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.

           PERFORM  3330-1000-BUILD-PARM-INFO
               THRU 3330-1000-BUILD-PARM-INFO-X.

           SET L3330-LOC-GR-TYP-DCIDT   TO TRUE.

           PERFORM  3330-1000-GET-LOC-GROUP
               THRU 3330-1000-GET-LOC-GROUP-X.

           IF  NOT L3330-RETRN-OK
      * MSG: 'LOCATION GROUP NOT FOUND FOR @1,TYPE '@2' BY PGM @3'
               MOVE 'CS00000064'        TO WGLOB-MSG-REF-INFO
               MOVE RPH-LOC-GR-COLCT-ID TO WGLOB-MSG-PARM (1)
               MOVE L3330-LOC-GR-TYP-CD TO WGLOB-MSG-PARM (2)
               MOVE WPGWS-CRNT-PGM-ID   TO WGLOB-MSG-PARM (3)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-GET-LOCATION-GROUP-X
           END-IF.

       6000-GET-LOCATION-GROUP-X.
           EXIT.

      *---------------
       8000-EDIT-INFO.
      *---------------

      * VALIDATE KEY INFOMATION

            PERFORM  8010-EDIT-KEY-INFO
                THRU 8010-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

      * LOAD WCVGS ARRAY

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 8000-EDIT-INFO-X
           END-IF.

       8000-EDIT-INFO-X.
           EXIT.

      *-------------------
       8010-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
               MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
               MOVE 'POL'             TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      * VALID PDCL SEQ NUM
      *
           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE ZERO                       TO L0280-PRECISION.
           MOVE 4                          TO L0280-LENGTH.
           MOVE 4                          TO L0280-INPUT-SIZE.
           MOVE MIR-DTHCLM-SEQ-NUM         TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'SEQUENCE NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS73520011'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 8010-EDIT-KEY-INFO-X
           ELSE
               MOVE L0280-OUTPUT           TO WS-PDCL-DTHCLM-SEQ-NUM
           END-IF.

       8010-EDIT-KEY-INFO-X.
           EXIT.

      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-IO-AREA.
           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.

      *----------------------
       8200-MOVE-PDCL-TO-MIR.
      *----------------------

           MOVE RPDCL-DTHCLM-AMT         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-AMT TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-AMT.

           MOVE RPDCL-DTHCLM-ADDL-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-ADDL-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-ADDL-AMT.

           MOVE RPDCL-DTHCLM-INT-DT-CD   TO MIR-DTHCLM-INT-DT-CD.

           MOVE RPDCL-DTHCLM-INT-STRT-DT TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-DTHCLM-INT-STRT-DT.

           MOVE RPDCL-DTHCLM-INT-PCT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-INT-PCT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-INT-PCT.

           MOVE RPDCL-DTHCLM-STAT-CD     TO MIR-DTHCLM-STAT-CD.

           MOVE RPDCL-DTHCLM-CREAT-DT    TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-DTHCLM-CREAT-DT.

           MOVE RPDCL-DTHCLM-OVRID-IND   TO MIR-DTHCLM-OVRID-IND.

           MOVE RPDCL-DTHCLM-COMNT-INFO-TXT
                                         TO MIR-DTHCLM-COMNT-INFO.

       8200-MOVE-PDCL-TO-MIR-X.
           EXIT.

      *---------------------
       8300-BUILD-PDCB-INFO.
      *---------------------

      * INITIALIZE PX CALCULATION PARAMETERS

           PERFORM  8302-INIT-PCALC-EXIT-DCIN
               THRU 8302-INIT-PCALC-EXIT-DCIN-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8300-BUILD-PDCB-INFO-X
           END-IF.

      * BROWSE PDCB

           PERFORM  9000-BUILD-PDCB-BROWSE-KEY
               THRU 9000-BUILD-PDCB-BROWSE-KEY-X.

           PERFORM  PDCB-1000-BROWSE
               THRU PDCB-1000-BROWSE-X.

           PERFORM  PDCB-2000-READ-NEXT
               THRU PDCB-2000-READ-NEXT-X.

           IF  WPDCB-IO-EOF
               PERFORM  PDCB-3000-END-BROWSE
                   THRU PDCB-3000-END-BROWSE-X
               GO TO 8300-BUILD-PDCB-INFO-X
           END-IF.

           MOVE ZERO                     TO WS-PDCB-TOT-CTR.
           MOVE ZERO                     TO WS-PDCB-TOT-PEND-CTR.

           PERFORM  8310-BROWSE-PDCB
               THRU 8310-BROWSE-PDCB-X
               VARYING WS-MIR-SUB FROM 1 BY +1
               UNTIL   WS-MIR-SUB > WS-MAX-PDCB-CTR
               OR      WPDCB-IO-EOF
               OR      WGLOB-MSG-ERROR-SW > ZERO.

           IF  WPDCB-IO-EOF
           OR  WGLOB-MSG-ERROR-SW > ZERO
               CONTINUE
           ELSE
      *MSG:   'BENEIFICARY RECORED EXCEEDS MAXIMUM'
               MOVE 'CS73520006'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDCB-3000-END-BROWSE
               THRU PDCB-3000-END-BROWSE-X.

      * CALL PRODUCTXPRESS TO CALCULATE DEATH CLAIM AMT AND INTEREST

           PERFORM  8330-PX-CALC-DCIN
               THRU 8330-PX-CALC-DCIN-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8300-BUILD-PDCB-INFO-X
           END-IF.

      * ADJUST PD ROUND OFF IF TOTAL BENEFICIARY PCT = 100%

           IF  WS-TOTAL-DCBNFY-PCT-NO
               CONTINUE
           ELSE
               PERFORM  8340-ADJUST-PD-ROUND-OFF
                   THRU 8340-ADJUST-PD-ROUND-OFF-X
               IF  WGLOB-MSG-ERROR-SW > ZERO
                   GO TO 8300-BUILD-PDCB-INFO-X
               END-IF
           END-IF.

       8300-BUILD-PDCB-INFO-X.
           EXIT.

      *--------------------------
       8302-INIT-PCALC-EXIT-DCIN.
      *--------------------------

      * EXIT IF PDCL STATUS NOT = PENDING, ERROR AND PARTIALLY PAID

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
           OR  RPDCL-DTHCLM-STAT-PARTL-PD
               CONTINUE
           ELSE
               GO TO 8302-INIT-PCALC-EXIT-DCIN-X
           END-IF.

           PERFORM  9500-PCALC-EXIT-DCIN
               THRU 9500-PCALC-EXIT-DCIN-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8302-INIT-PCALC-EXIT-DCIN-X
           END-IF.

           PERFORM  DCIN-1000-BUILD-PARM-INFO
               THRU DCIN-1000-BUILD-PARM-INFO-X.

           MOVE RPDCL-CVG-NUM            TO LDCIN-CVG-NUM.
           MOVE RPDCL-DTHCLM-AMT         TO LDCIN-DTHCLM-AMT.
           MOVE RPDCL-DTHCLM-ADDL-AMT    TO LDCIN-DTHCLM-ADDL-AMT.
           MOVE RPDCL-DTHCLM-INT-STRT-DT TO LDCIN-DTHCLM-INT-STRT-DT.
           MOVE L3330-LOC-GR-ID          TO LDCIN-LOC-GR-ID.

       8302-INIT-PCALC-EXIT-DCIN-X.
           EXIT.

      *-----------------
       8310-BROWSE-PDCB.
      *-----------------

      * COUNT TOTAL PDCB

           ADD +1                    TO WS-PDCB-TOT-CTR.

           PERFORM  8320-MOVE-PDCB-TO-MIR
               THRU 8320-MOVE-PDCB-TO-MIR-X.

           PERFORM  8322-MOVE-PDCB-TO-WS
               THRU 8322-MOVE-PDCB-TO-WS-X.

      * COUNT TOTAL PDCB WITH STATUS NOT = TOTAL PAID

           IF  NOT RPDCB-DCBNFY-STAT-TOT-PD
               ADD +1                TO WS-PDCB-TOT-PEND-CTR
           END-IF.

      * BUILD PX BENEFICIARY INPUT IF NOT PAID

           IF  RPDCB-DCBNFY-PD-DT = WWKDT-ZERO-DT
               CONTINUE
           ELSE
               PERFORM  PDCB-2000-READ-NEXT
                   THRU PDCB-2000-READ-NEXT-X
               GO TO 8310-BROWSE-PDCB-X
           END-IF.

      * COUNT TOTAL PX ROLES

           ADD +1                    TO LDCIN-ROLE-CTR.

      * MOVE PDCB INFO TO DCIN LINKAGE AREA

           MOVE RPDCB-CLI-ID
             TO LDCIN-CLI-ID (LDCIN-ROLE-CTR).
           MOVE RPDCB-DCBNFY-PCT
             TO LDCIN-DCBNFY-PCT (LDCIN-ROLE-CTR).
           MOVE RPDCB-DCBNFY-STAT-CD
             TO LDCIN-DCBNFY-STAT-CD (LDCIN-ROLE-CTR).

      * READ NEXT PDCB

           PERFORM  PDCB-2000-READ-NEXT
               THRU PDCB-2000-READ-NEXT-X.

       8310-BROWSE-PDCB-X.
           EXIT.

      *----------------------
       8320-MOVE-PDCB-TO-MIR.
      *----------------------

           MOVE RPDCB-CLI-ID         TO MIR-CLI-ID-T (WS-MIR-SUB).

           MOVE RPDCB-CLI-ID         TO L5120-CLI-ID.
           PERFORM  5120-1000-CLI-NAME-UPDATE
               THRU 5120-1000-CLI-NAME-UPDATE-X.
           MOVE L5120-CLI-NAME       TO MIR-DV-CLI-NM-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-PCT     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PCT-T (WS-MIR-SUB)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DCBNFY-PCT-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-PD-AMT  TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PD-AMT-T (WS-MIR-SUB)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO MIR-DCBNFY-PD-AMT-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-INT-PD-AMT
                                     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-INT-PD-AMT-T (WS-MIR-SUB)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO
                                  MIR-DCBNFY-INT-PD-AMT-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-PD-DT   TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO
                                   MIR-DCBNFY-PD-DT-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-REVRS-DT  TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO
                                    MIR-DCBNFY-REVRS-DT-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-PAYO-CD TO
                                     MIR-DCBNFY-PAYO-CD-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-FED-CALC-CD TO
                                 MIR-DCBNFY-FED-CALC-CD-T (WS-MIR-SUB).

029060*    MOVE RPDCB-FED-TAXWH-AMT  TO L0290-INPUT-V02.
029060     MOVE RPDCB-FTAXWH-AMT     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-AMT-T (WS-MIR-SUB)
029060     MOVE LENGTH OF MIR-FTAXWH-AMT-T (WS-MIR-SUB)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO
029060*                           MIR-FED-TAXWH-AMT-T (WS-MIR-SUB).
029060                            MIR-FTAXWH-AMT-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-STAT-CD TO
                                  MIR-DCBNFY-STAT-CD-T (WS-MIR-SUB).

           MOVE RPDCB-DCBNFY-BPSS-IND TO
                                  MIR-DCBNFY-BPSS-IND-T (WS-MIR-SUB).

       8320-MOVE-PDCB-TO-MIR-X.
           EXIT.

      *---------------------
       8322-MOVE-PDCB-TO-WS.
      *---------------------

           MOVE RPDCB-CLI-ID         TO WS-DCBNFY-CLI-ID (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-PD-AMT  TO WS-DCBNFY-PD-AMT (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-PCT     TO WS-DCBNFY-PCT (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-INT-PD-AMT
                                 TO WS-DCBNFY-INT-PD-AMT (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-PD-DT   TO WS-DCBNFY-PD-DT (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-REVRS-DT TO
                                       WS-DCBNFY-REVRS-DT (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-PAYO-CD TO WS-DCBNFY-PAYO-CD (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-FED-CALC-CD TO
                                    WS-DCBNFY-FED-CALC-CD (WS-MIR-SUB).
029060*    MOVE RPDCB-FED-TAXWH-AMT   TO WS-FED-TAXWH-AMT (WS-MIR-SUB).
029060     MOVE RPDCB-FTAXWH-AMT      TO WS-FED-TAXWH-AMT (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-BPSS-IND TO
                                       WS-DCBNFY-BPSS-IND (WS-MIR-SUB).
           MOVE RPDCB-DCBNFY-STAT-CD TO WS-DCBNFY-STAT-CD (WS-MIR-SUB).

       8322-MOVE-PDCB-TO-WS-X.
           EXIT.

      *------------------
       8330-PX-CALC-DCIN.
      *------------------

      * EXIT IF PDCL STATUS NOT = PENDING, ERROR AND PARTIALLY PAID

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
           OR  RPDCL-DTHCLM-STAT-PARTL-PD
               CONTINUE
           ELSE
               GO TO 8330-PX-CALC-DCIN-X
           END-IF.

      * CALL DCIN CALC EXIT PROGRAM

           PERFORM  DCIN-1000-CALC-DCBNFY-INT
               THRU DCIN-1000-CALC-DCBNFY-INT-X.

           IF  NOT LDCIN-RETRN-OK
               GO TO 8330-PX-CALC-DCIN-X
           END-IF.

      * RETURN OUTPUTS AND UPDATE PDCB

           PERFORM  8332-RETRN-PX-DCBNFY
               THRU 8332-RETRN-PX-DCBNFY-X
               VARYING WS-MIR-SUB FROM +1 BY +1
               UNTIL   WS-MIR-SUB > WS-PDCB-TOT-CTR
               OR      WGLOB-MSG-ERROR-SW > ZERO.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8330-PX-CALC-DCIN-X
           END-IF.

       8330-PX-CALC-DCIN-X.
           EXIT.

      *---------------------
       8332-RETRN-PX-DCBNFY.
      *---------------------

      * MATCH MIR CLIENT ID WITH LDCIN CLIENT ID

           PERFORM
               VARYING WS-ROLE FROM 1 BY +1
                 UNTIL LDCIN-CLI-ID (WS-ROLE) =
                       MIR-CLI-ID-T (WS-MIR-SUB)
                    OR WS-ROLE > LDCIN-ROLE-CTR
                    CONTINUE
           END-PERFORM.

           IF  WS-ROLE > LDCIN-ROLE-CTR
               GO TO 8332-RETRN-PX-DCBNFY-X
           END-IF.

      * RETURN OUTPUT AND UPDATE DEATH CLAIM AMT AND INTEREST PAID
      * AMT DEPENDS ON BENEFICIARY STATUS

           EVALUATE TRUE

                WHEN LDCIN-DCBNFY-STAT-PEND (WS-ROLE)
                     PERFORM  8334-UPDT-DCBNFY-PD-AMT
                         THRU 8334-UPDT-DCBNFY-PD-AMT-X
                     IF  WGLOB-MSG-ERROR-SW > ZERO
                         GO TO 8332-RETRN-PX-DCBNFY-X
                     END-IF
                     PERFORM  8336-UPDT-DCBNFY-INT-PD-AMT
                         THRU 8336-UPDT-DCBNFY-INT-PD-AMT-X
                     IF  WGLOB-MSG-ERROR-SW > ZERO
                         GO TO 8332-RETRN-PX-DCBNFY-X
                     END-IF

                WHEN LDCIN-DCBNFY-STAT-INT-PD (WS-ROLE)
                     PERFORM  8334-UPDT-DCBNFY-PD-AMT
                         THRU 8334-UPDT-DCBNFY-PD-AMT-X
                     IF  WGLOB-MSG-ERROR-SW > ZERO
                         GO TO 8332-RETRN-PX-DCBNFY-X
                     END-IF

                WHEN LDCIN-DCBNFY-STAT-DTH-CLM-PD (WS-ROLE)
                     PERFORM  8336-UPDT-DCBNFY-INT-PD-AMT
                         THRU 8336-UPDT-DCBNFY-INT-PD-AMT-X
                     IF  WGLOB-MSG-ERROR-SW > ZERO
                         GO TO 8332-RETRN-PX-DCBNFY-X
                     END-IF

           END-EVALUATE.

       8332-RETRN-PX-DCBNFY-X.
           EXIT.

      *------------------------
       8334-UPDT-DCBNFY-PD-AMT.
      *------------------------

      * MOVE CLAIM AMOUNT TO MIR

           MOVE LDCIN-DCBNFY-PD-AMT (WS-ROLE)
                                        TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PD-AMT-T (WS-MIR-SUB)
                                        TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO
                                   MIR-DCBNFY-PD-AMT-T (WS-MIR-SUB).

      * MOVE CLAIM AMOUNT TO WS

           MOVE LDCIN-DCBNFY-PD-AMT (WS-ROLE)
                                   TO WS-DCBNFY-PD-AMT (WS-MIR-SUB).

       8334-UPDT-DCBNFY-PD-AMT-X.
           EXIT.

      *----------------------------
       8336-UPDT-DCBNFY-INT-PD-AMT.
      *----------------------------

      * MOVE INTEREST PAID AMOUNT TO MIR

           MOVE LDCIN-DCBNFY-INT-PD-AMT (WS-ROLE)
                                        TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-INT-PD-AMT-T (WS-MIR-SUB)
                                        TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO
                                MIR-DCBNFY-INT-PD-AMT-T (WS-MIR-SUB).

      * MOVE INTEREST PAID AMOUNT TO WS

           MOVE LDCIN-DCBNFY-INT-PD-AMT (WS-ROLE)
                                TO WS-DCBNFY-INT-PD-AMT (WS-MIR-SUB).

       8336-UPDT-DCBNFY-INT-PD-AMT-X.
           EXIT.

      *-------------------------
       8340-ADJUST-PD-ROUND-OFF.
      *-------------------------

           MOVE ZERO                TO WS-TOT-DCBNFY-PD-AMT.
           MOVE ZERO                TO WS-ADJ-BENE.

           PERFORM
               VARYING WS-MIR-SUB FROM 1 BY +1
                 UNTIL WS-MIR-SUB > WS-PDCB-TOT-CTR

                 ADD WS-DCBNFY-PD-AMT (WS-MIR-SUB)
                  TO WS-TOT-DCBNFY-PD-AMT

                 IF  WS-DCBNFY-STAT-PEND (WS-MIR-SUB)
                     MOVE WS-MIR-SUB   TO WS-ADJ-BENE
                 END-IF

           END-PERFORM.

           IF  WS-ADJ-BENE = ZERO
               GO TO 8340-ADJUST-PD-ROUND-OFF-X
           END-IF.

           COMPUTE WS-DIFF-DCBNFY-PD-AMT = RPDCL-DTHCLM-AMT
                                         + RPDCL-DTHCLM-ADDL-AMT
                                         - WS-TOT-DCBNFY-PD-AMT.

           IF  WS-DIFF-DCBNFY-PD-AMT > 1.00
           OR  WS-DIFF-DCBNFY-PD-AMT < -1.00
      *MSG: SUM OF DEATH CLAIM AMOUNT NOT MATCH TOTAL BENEFICIARY CLAIM
      *     AMOUNT.
               MOVE 'CS73520016'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8340-ADJUST-PD-ROUND-OFF-X
           END-IF.

           COMPUTE WS-DCBNFY-PD-AMT (WS-ADJ-BENE) =
                          WS-DCBNFY-PD-AMT (WS-ADJ-BENE)
                        + WS-DIFF-DCBNFY-PD-AMT.

           MOVE WS-DCBNFY-PD-AMT (WS-ADJ-BENE)
                                        TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PD-AMT-T (WS-ADJ-BENE)
                                        TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO
                                   MIR-DCBNFY-PD-AMT-T (WS-ADJ-BENE).

       8340-ADJUST-PD-ROUND-OFF-X.
           EXIT.

      *---------------------------
       9000-BUILD-PDCB-BROWSE-KEY.
      *---------------------------

           MOVE LOW-VALUES               TO WPDCB-KEY.
           MOVE WGLOB-COMPANY-CODE       TO WPDCB-CO-ID.
           MOVE RPOL-POL-ID              TO WPDCB-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM   TO WPDCB-DTHCLM-SEQ-NUM.

           MOVE WPDCB-KEY                TO WPDCB-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WPDCB-ENDBR-CLI-ID.

       9000-BUILD-PDCB-BROWSE-KEY-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *---------------------
       9500-PCALC-EXIT-DCIN.
      *---------------------

           PERFORM  0317-1000-BUILD-PARM-INFO
               THRU 0317-1000-BUILD-PARM-INFO-X.

           SET  L0317-PCALC-EXIT-DTH-CLM-INT  TO TRUE.

           MOVE RPOL-POL-BASE-CVG-NUM   TO I.

           MOVE WCVGS-PLAN-ID (I)       TO L0317-PLAN-ID.

035251*    IF  WCVGS-PLAN-ID-BASE-3-5 (I) = 'RPU'
035251*    OR  WCVGS-PLAN-ID-BASE-3-5 (I) = 'ETI'
035251*        MOVE WCVGS-ORIG-PLAN-ID (I)
035251*                                 TO L0317-PLAN-ID
035251*    END-IF.

           PERFORM  0317-1000-GET-PCALC-EXIT-PGM
               THRU 0317-1000-GET-PCALC-EXIT-PGM-X.

           EVALUATE TRUE

               WHEN L0317-RETRN-NOT-FOUND
               WHEN L0317-RETRN-PX-DISABLE
                    GO TO 9500-PCALC-EXIT-DCIN-X

               WHEN L0317-PCALC-EXIT-STAT-INTRNL
      * MSG: INTERNAL CALCULATION DOES NOT EXIST
                    MOVE 'CS73520012'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    GO TO 9500-PCALC-EXIT-DCIN-X

               WHEN L0317-PCALC-EXIT-STAT-XTRNL
                    CONTINUE

           END-EVALUATE.

       9500-PCALC-EXIT-DCIN-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0317-0000-INIT-PARM-INFO
               THRU 0317-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2435-0000-INIT-PARM-INFO
               THRU 2435-0000-INIT-PARM-INFO-X.

           PERFORM  2510-0000-INIT-PARM-INFO
               THRU 2510-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           PERFORM  3330-0000-INIT-PARM-INFO
               THRU 3330-0000-INIT-PARM-INFO-X.

           PERFORM  5120-0000-INIT-PARM-INFO
               THRU 5120-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           PERFORM  8960-0000-INIT-PARM-INFO
               THRU 8960-0000-INIT-PARM-INFO-X.

           PERFORM  DCIN-0000-INIT-PARM-INFO
               THRU DCIN-0000-INIT-PARM-INFO-X.
029060
029060     PERFORM  5382-0000-INIT-PARM-INFO
029060         THRU 5382-0000-INIT-PARM-INFO-X.
029060
029060     PERFORM  0182-0000-INIT-PARM-INFO
029060         THRU 0182-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WS-PDCB-DCBNFY-AREA.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           INITIALIZE FREQUENTLY-USED-INDICES.

           SET WS-TWRK-KEY-DEFAULT      TO TRUE.
           SET WS-MAX-PDCB-CTR-DEFAULT  TO TRUE.
           SET MIR-RETRN-OK             TO TRUE.

           MOVE SPACES               TO WWKDT-WORK-FIELDS.
           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
       COPY CCPPPLIN.
       COPY CCPPMIDT.
       COPY NCPPCVGS.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY CCPS2435.
029060 COPY CCPS0182.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2435.

       COPY CCPS3330.
       COPY CCPL3330.

       COPY CCPS5120.
       COPY CCPL5120.

       COPY CCPSDCIN.
       COPY CCPLDCIN.

       COPY XCPS0317.
       COPY XCPL0317.

       COPY XCPL0260.

       COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPL0290.
       COPY XCPS0290.

       COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPS2510.
       COPY XCPL2510.

       COPY XCPS8960.
       COPY XCPL8960.

       COPY XCPL8090.
029060
029060 COPY CCPS5382.
029060 COPY CCPL5382.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNCVG.

       COPY CCPNPH.

       COPY CCPUPDCL.

       COPY CCPAPDCB.
       COPY CCPCPDCB.
       COPY CCPBPDCB.
       COPY CCPGPDCB.
       COPY CCPUPDCB.

       COPY CCPBCDSA.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7352                     **
      *****************************************************************
