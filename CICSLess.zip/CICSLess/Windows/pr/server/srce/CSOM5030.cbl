      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5030.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5030                                         **
      **  REMARKS:  PROCESS DRIVER FOR BRCH TRANSACTION              **
      **            EACH BRANCH ID REPRESENTS A BRANCH OR GENERAL    **
      **            AGENCY OFFICE. EACH BRANCH SHOULD BE ASSOCIATED  **
      **            WITH A CLIENT ID WHICH SUPPLIES INFORMATION SUCH **
      **            AS THE NAME, ADDRESS AND LANGUAGE OF THAT BRANCH.**
      **            FOR UPDATE FUNCTIONS THIS PROGRAM CHECKS FOR THE **
      **            EXISTENCE OF A VALID CLIENT.                     **
      **                                                             **
      **  DOMAIN :  AG                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CHANGE TO STANDARD                               **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEANUP AND STANDARDIZATION                 **
010950**  5.6       ADDR TYPE EDIT AGAINST EDIT TABLE                **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
015508**  6.0       CLIENT ENHANCEMENT FOR JAPAN                     **
014221**  6.2       LOGICAL LOCKING                                  **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      /
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5030'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4)  BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT         VALUE +12.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                 VALUE '0980'.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-COVNO                     PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-COVNO                     PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
016548*                                     BINARY.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970*                                     BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '0990' '0991'
                                                  '0992' '0993'
                                                  '0994'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0990'.
               88  WS-BUS-FCN-CREATE        VALUE '0991'.
               88  WS-BUS-FCN-UPDATE        VALUE '0992'.
               88  WS-BUS-FCN-DELETE        VALUE '0993'.
               88  WS-BUS-FCN-LIST          VALUE '0994'.
014221*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0990'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0990'.
           05  WS-PIC-CHANGE.
               10  WS-PIC-SIGN              PIC X.
               10  WS-PIC-NUM               PIC XX.

      ***************************************************************
      * COMMON COPYBOOKS
      ***************************************************************
      /
014221 COPY CCWWLOCK.
      /
      ***************************************************************
      * BRANCH WORK AREA
      ***************************************************************
       COPY CCFRBRCH.
       COPY CCFWBRCH.
010950/
010950***************************************************************
010950* I/O COPYBOOKS
010950***************************************************************
010950 COPY CCFREDIT.
010950 COPY CCFWEDIT.
      /
      ***************************************************************
      * LINKAGE TO NAME FORMATTING ROUTINE
      ***************************************************************
       COPY CCWL0620.
028298 COPY CCWL2626.
      /
014221 COPY XCWL8090.
      /
       COPY CCWL2435.
       COPY CCWL2440.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM5030.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ****************
       0000-MAINLINE.
      ****************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           SET MIR-RETRN-OK          TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.

      *********************
       2000-PROCESS-REQUEST.
      *********************

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-RETRIEVE
           OR WS-BUS-FCN-UPDATE
           OR WS-BUS-FCN-DELETE
              PERFORM 2110-CHECK-BRANCH
                 THRU 2110-CHECK-BRANCH-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                   PERFORM  3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

           WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'         TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID       TO  WGLOB-MSG-PARM (1)
                   MOVE 'CSOM5030'           TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST     TO  TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /

      *****************************************************************
      *   CHECK BRANCH:
      *   ENSURE THAT THE BRANCH EXISTS.
      *****************************************************************
      ******************
       2110-CHECK-BRANCH.
      ******************

           IF  MIR-BR-ID = SPACES
      *MSG:    BRANCH NUMBER IS REQUIRED
               MOVE 'CS50300001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO  TO  2110-CHECK-BRANCH-X
           END-IF.

           MOVE MIR-BR-ID             TO WBRCH-BR-ID.

           PERFORM  8100-READ-BRANCH-INFO
               THRU 8100-READ-BRANCH-INFO-X.

           IF  WGLOB-MSG-ERROR-SW     >  ZERO
               GO  TO  2110-CHECK-BRANCH-X
           END-IF.

           IF  RBRCH-CLI-ID > SPACES
               PERFORM  2435-1000-BUILD-PARM-INFO
                   THRU 2435-1000-BUILD-PARM-INFO-X
               MOVE RBRCH-CLI-ID      TO L2435-CLI-ID
               PERFORM  2435-1000-OBTAIN-CLI-INFO
                   THRU 2435-1000-OBTAIN-CLI-INFO-X
           END-IF.

       2110-CHECK-BRANCH-X.
           EXIT.
      /
      **********************
       3000-PROCESS-RETRIEVE.
      **********************

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      ******************
       3500-PROCESS-LIST.
      ******************

           MOVE SPACES                TO MIR-BR-ID-G.
           MOVE SPACES                TO MIR-CLI-ID-G.
           MOVE SPACES                TO MIR-CLI-ADDR-TYP-CD-G.

           MOVE LOW-VALUES            TO WBRCH-KEY.
           MOVE HIGH-VALUES           TO WBRCH-ENDBR-KEY.

           IF MIR-BR-ID NOT = SPACES
              MOVE MIR-BR-ID          TO WBRCH-BR-ID
           END-IF.

           PERFORM  BRCH-1000-BROWSE
               THRU BRCH-1000-BROWSE-X.

           IF WBRCH-IO-OK
               PERFORM  BRCH-2000-READ-NEXT
                   THRU BRCH-2000-READ-NEXT-X
           END-IF.

           IF NOT WBRCH-IO-OK
           OR WBRCH-IO-EOF
      *MSG:  'NO RECORDS FOUND TO DISPLAY'
              MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  BRCH-3000-END-BROWSE
                  THRU BRCH-3000-END-BROWSE-X
              GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WBRCH-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  BRCH-3000-END-BROWSE
               THRU BRCH-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /

      ********************
       4000-PROCESS-CREATE.
      ********************

557660     MOVE SPACES                TO MIR-DV-CLI-NM.
557660     MOVE SPACES                TO MIR-CLI-ID.
557660     MOVE SPACES                TO MIR-CLI-ADDR-TYP-CD.
557660
           MOVE MIR-BR-ID             TO WBRCH-BR-ID.

           PERFORM  BRCH-1000-READ
               THRU BRCH-1000-READ-X.

           IF  WBRCH-IO-OK
               MOVE WBRCH-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  BRACH KEY EDITS.
      *
           IF MIR-BR-ID = SPACES
      *MSG:    BRANCH NUMBER IS REQUIRED
               MOVE 'CS50300001'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-BR-ID         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM  BRCH-1000-CREATE
               THRU BRCH-1000-CREATE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  BRCH-1000-WRITE
               THRU BRCH-1000-WRITE-X.

014221     PERFORM  BRCH-1000-READ-TWRK-TS
014221         THRU BRCH-1000-READ-TWRK-TS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.

      /
      ********************
       5000-PROCESS-UPDATE.
      ********************
      *
014221*    PERFORM  BRCH-1000-READ-FOR-UPDATE
014221*        THRU BRCH-1000-READ-FOR-UPDATE-X.

014221     PERFORM  BRCH-2000-UPDATE-TWRK-TS
014221         THRU BRCH-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'BRCH'                TO WGLOB-MSG-PARM (01)
014221        MOVE WBRCH-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF  NOT WBRCH-IO-OK
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  5300-EDIT-BRCH-SCREEN-DATA
               THRU 5300-EDIT-BRCH-SCREEN-DATA-X.

           PERFORM  BRCH-2000-REWRITE
               THRU BRCH-2000-REWRITE-X.
014221     PERFORM  BRCH-1000-READ-TWRK-TS
014221         THRU BRCH-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW = 0
      *MSG:    MAINTENANCE COMPLETE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
010311*        PERFORM  0260-1000-GENERATE-MESSAGE
010311*            THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
010311*MSG:    RECORD UPDATED
010311         MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
           END-IF.

010311     PERFORM  0260-1000-GENERATE-MESSAGE
010311         THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.

      /
      ****************************
       5300-EDIT-BRCH-SCREEN-DATA.
      ****************************


           PERFORM  5310-EDIT-CLI-NUM
               THRU 5310-EDIT-CLI-NUM-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  5320-EDIT-ADDR-TYP
                   THRU 5320-EDIT-ADDR-TYP-X
           END-IF.

       5300-EDIT-BRCH-SCREEN-DATA-X.
           EXIT.

      /
      *******************
       5310-EDIT-CLI-NUM.
      *******************

           IF MIR-CLI-ID = SPACES
               MOVE RBRCH-CLI-ID      TO MIR-CLI-ID
           END-IF.

           IF MIR-CLI-ID = SPACES
               MOVE SPACES            TO RBRCH-CLI-ADDR-TYP-CD
      *MSG:    'MOVE MESSAGE CLIENT NUMBER MUST BE FILED IN'
               MOVE 'CS50300002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5310-EDIT-CLI-NUM-X
           END-IF.

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  NOT L2435-RETRN-OK
      *MSG:    "CLIENT (@1) MUST EXIST IN BIOP"
               MOVE 'CS50300003'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5310-EDIT-CLI-NUM-X
           END-IF.

           MOVE MIR-CLI-ID            TO RBRCH-CLI-ID.

015508     INITIALIZE                 L0620-INPUT-PARM-INFO.
557698*    MOVE L2435-CLI-GIV-NM      TO L0620-CLI-GIV-NM.
557698*    MOVE L2435-CLI-SUR-NM      TO L0620-CLI-SUR-NM.
           MOVE L2435-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
557698*    MOVE L2435-CLI-FULL-NAME         TO L0620-CLI-CO-NM.
557698     MOVE L2435-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM.
557698     MOVE L2435-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM.
557698     MOVE L2435-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM.
015508     MOVE L2435-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM.
015508     MOVE L2435-CLI-SFX-NM      TO L0620-CLI-SFX-NM.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-CLI-NM.

       5310-EDIT-CLI-NUM-X.
           EXIT.

      *******************
       5320-EDIT-ADDR-TYP.
      *******************

           IF MIR-CLI-ADDR-TYP-CD = SPACES
               MOVE RBRCH-CLI-ADDR-TYP-CD
                                      TO MIR-CLI-ADDR-TYP-CD
           END-IF.

           IF  MIR-CLI-ID = SPACES
           AND MIR-CLI-ADDR-TYP-CD = SPACES
               GO TO 5320-EDIT-ADDR-TYP-X
           END-IF.
      *
      * DEFAULT PR IF NOTHING HAS BEEN ENTERED INTO THE ADDRESS TYPE
      * FIELD
      *
           IF MIR-CLI-ADDR-TYP-CD = SPACES
               MOVE 'PR'              TO MIR-CLI-ADDR-TYP-CD
               MOVE 'XS00000214'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
010950     ELSE
010950         MOVE MIR-CLI-ADDR-TYP-CD
                                      TO WEDIT-ETBL-VALU-ID
010950         PERFORM  ADDR-1000-EDIT
010950             THRU ADDR-1000-EDIT-X
010950         IF  WEDIT-IO-OK
010950             CONTINUE
010950         ELSE
010950             MOVE 'CS50300004'  TO WGLOB-MSG-REF-INFO
010950             MOVE 'PR'          TO MIR-CLI-ADDR-TYP-CD
010950             PERFORM  0260-1000-GENERATE-MESSAGE
010950                 THRU 0260-1000-GENERATE-MESSAGE-X
010950         END-IF
           END-IF.

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.
           MOVE MIR-CLI-ID            TO L2440-CLI-ID.
           MOVE MIR-CLI-ADDR-TYP-CD   TO L2440-CLI-ADDR-TYP-CD.

           IF MIR-CLI-ADDR-TYP-CD = 'PR'
               PERFORM  2440-1000-PRIMARY-ADDRESS
                   THRU 2440-1000-PRIMARY-ADDRESS-X
           ELSE

               PERFORM  2440-2000-OTHER-ADDRESS
                   THRU 2440-2000-OTHER-ADDRESS-X
           END-IF.
      *
      ****IF OTHER ADDRESS NOT FOUND DEFAULT PRIMARY
      *
010311* ONLY DO IT AGAIN IF ADDRESS IS NOT ALREADY PR
010311     IF (L2440-RETRN-NO-ADDRESS
010311     AND MIR-CLI-ADDR-TYP-CD NOT = 'PR')
010950     OR  L2440-RETRN-PRIMARY-DEFAULTED
               MOVE 'PR'              TO MIR-CLI-ADDR-TYP-CD
               MOVE 'XS00000214'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF L2440-ADDR-STAT-ERROR
                MOVE L2440-CLI-ID     TO WGLOB-MSG-PARM (1)
                MOVE 'XS00000211'     TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-CLI-ADDR-TYP-CD   TO RBRCH-CLI-ADDR-TYP-CD.

       5320-EDIT-ADDR-TYP-X.
           EXIT.

      /
      ********************
       6000-PROCESS-DELETE.
      ********************

           IF WGLOB-MSG-ERROR-SW > 0
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

           PERFORM  8050-BUILD-BRCH-KEY
               THRU 8050-BUILD-BRCH-KEY-X.

014221*    PERFORM  BRCH-1000-READ-FOR-UPDATE
014221*        THRU BRCH-1000-READ-FOR-UPDATE-X

014221     PERFORM  BRCH-2000-UPDATE-TWRK-TS
014221         THRU BRCH-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'BRCH'                TO WGLOB-MSG-PARM (01)
014221        MOVE WBRCH-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WBRCH-IO-OK
               PERFORM  BRCH-1000-DELETE
                   THRU BRCH-1000-DELETE-X
               IF WBRCH-IO-OK
      *MSG:       DELETE COMPLETED MESSAGE
                  MOVE 'XS00000011'   TO WGLOB-MSG-REF-INFO
               ELSE
      *MSG:       RECORD (@1) LOST IN DELETE
                  MOVE WBRCH-KEY      TO WGLOB-MSG-PARM (1)
                  MOVE 'XS00000010'   TO WGLOB-MSG-REF-INFO
               END-IF
           ELSE
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WBRCH-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      /
      ********************
       8050-BUILD-BRCH-KEY.
      ********************

           MOVE MIR-BR-ID             TO WBRCH-BR-ID.
           MOVE WBRCH-KEY             TO WBRCH-ENDBR-KEY.

       8050-BUILD-BRCH-KEY-X.
           EXIT.
      /
      ***********************
       8100-READ-BRANCH-INFO.
      ***********************

           IF RBRCH-BR-ID = WBRCH-BR-ID
               GO TO 8100-READ-BRANCH-INFO-X
           END-IF.

014221*    PERFORM  BRCH-1000-READ
014221*        THRU BRCH-1000-READ-X.

014221     IF  WS-BUS-FCN-RETRIEVE
014221         PERFORM  BRCH-1000-READ-TWRK-TS
014221             THRU BRCH-1000-READ-TWRK-TS-X
014221     ELSE
014221         PERFORM  BRCH-1000-READ
014221             THRU BRCH-1000-READ-X
014221     END-IF.

           IF WBRCH-IO-NOT-FOUND
      *MSG:    "RECORD NOT FOUND"
               MOVE MIR-BR-ID         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8100-READ-BRANCH-INFO-X.
           EXIT.

      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      ***********************
       9100-BLANK-DATA-FIELDS.
      ***********************

           IF WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-BR-ID-G
               MOVE SPACES            TO MIR-CLI-ID-G
               MOVE SPACES            TO MIR-CLI-ADDR-TYP-CD-G
           ELSE
               MOVE SPACES            TO MIR-CLI-ID
               MOVE SPACES            TO MIR-CLI-ADDR-TYP-CD
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      ***************************
       9200-MOVE-RECORD-TO-SCREEN.
      ***************************

           IF WS-BUS-FCN-LIST
               PERFORM  9210-MOVE-BRCH-TO-LIST
                  THRU 9210-MOVE-BRCH-TO-LIST-X
                VARYING I FROM 1 BY 1
                  UNTIL I > WS-MAX-BROWSE-LINES
                     OR WBRCH-IO-EOF

               IF NOT WBRCH-IO-EOF
                  MOVE RBRCH-BR-ID    TO MIR-BR-ID
               END-IF

               IF WBRCH-IO-EOF
               AND MIR-BR-ID-T (1) NOT = SPACES
                   MOVE MIR-BR-ID-T (1)
                                      TO MIR-BR-ID
               END-IF
010311     END-IF.
010311*    ELSE

010311     IF NOT WS-BUS-FCN-LIST
               MOVE RBRCH-BR-ID       TO MIR-BR-ID
               MOVE RBRCH-CLI-ID      TO MIR-CLI-ID
               MOVE RBRCH-CLI-ADDR-TYP-CD
                                      TO MIR-CLI-ADDR-TYP-CD
557660         IF WS-BUS-FCN-CREATE
010311         OR RBRCH-CLI-ID = SPACE
557660            MOVE SPACES         TO MIR-DV-CLI-NM
557660         ELSE
015508            INITIALIZE                   L0620-INPUT-PARM-INFO
557698*           MOVE L2435-CLI-GIV-NM        TO L0620-CLI-GIV-NM
557698*           MOVE L2435-CLI-SUR-NM        TO L0620-CLI-SUR-NM
                  MOVE L2435-CLI-SEX-CD
                                      TO L0620-CLI-SEX-CD
557698*           MOVE L2435-CLI-FULL-NAME     TO L0620-CLI-CO-NM
557698            MOVE L2435-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557698            MOVE L2435-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
557698            MOVE L2435-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
015508            MOVE L2435-CLI-MID-INIT-NM
015508                                TO L0620-CLI-MID-INIT-NM
015508            MOVE L2435-CLI-SFX-NM  TO  L0620-CLI-SFX-NM
                  PERFORM  0620-1000-FORMAT-SCREEN-NAME
                      THRU 0620-1000-FORMAT-SCREEN-NAME-X
                  MOVE L0620-SCREEN-NAME
                                      TO MIR-DV-CLI-NM
557660         END-IF
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      /
      ***********************
       9210-MOVE-BRCH-TO-LIST.
      ***********************

           MOVE RBRCH-BR-ID           TO MIR-BR-ID-T (I).
           MOVE RBRCH-CLI-ID          TO MIR-CLI-ID-T (I).
           MOVE RBRCH-CLI-ADDR-TYP-CD TO MIR-CLI-ADDR-TYP-CD-T (I).

           PERFORM  BRCH-2000-READ-NEXT
               THRU BRCH-2000-READ-NEXT-X.

       9210-MOVE-BRCH-TO-LIST-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      **************************
       9300-SETUP-MSIN-REFERENCE.
      **************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
010950 COPY CCPEADDR.
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY BRCH
014221                         '$VAR2' BY 'BRCH'.

      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY CCPS0620.
       COPY CCPL0620.

018764*COPY CCCL2435.
018764 COPY CCPL2435.
       COPY CCPS2435.

021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.

018764*COPY CCCL2440.
018764 COPY CCPL2440.
020478 COPY CCPS2440.
      /
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY CCPABRCH.
       COPY CCPNBRCH.
       COPY CCPBBRCH.
       COPY CCPCBRCH.
010950 COPY CCPNEDIT.
       COPY CCPUBRCH.
       COPY CCPXBRCH.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM CSOM5030                       *
      ******************************************************************
