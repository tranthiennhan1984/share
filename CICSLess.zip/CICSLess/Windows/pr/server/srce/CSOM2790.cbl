      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM2790.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2790                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE BANK ACCOUNT HISTORY (BNAC)  TABLE       **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023440**  6.5       UPDATE EFT BANK CHANGES AUTOMATICALLY            **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2790'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST              VALUE '2790'.

           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-NO                  VALUE 'N'.
               88  WS-ERROR-YES                 VALUE 'Y'.

           05  WS-SUB                       PIC S9(04) BINARY.
           05  WS-MAX-LIST-LINES            PIC S9(04) BINARY
                                                VALUE 20.
           05  WS-BACHNG-TS.
               10  WS-BACHNG-DATE         PIC X(10).
               10  WS-BACHNG-FILL         PIC X(01).
               10  WS-BACHNG-TIME         PIC X(15).


      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
036742 COPY XCWWCNST.
036742/
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFRBNKA.
       COPY CCFWBNKA.
      /
       COPY CCFRBNAC.
       COPY CCFWBNAC.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2790.
      /
CVMQ71*PROCEDURE DIVISION   USING   WGLOB-GLOBAL-AREA
CVMQ71*                             MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION   USING DFHEIBLK
CVMQ71                              DFHCOMMAREA
CVMQ71                              WGLOB-GLOBAL-AREA
CVMQ71                              MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID     TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2790'         TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'       TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'       TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST 
                                            TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

      *  
      *  VERIFY ENTERED KEY DATA ON BNKA TABLE
      *
           SET  WS-ERROR-NO                 TO TRUE.
           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.
    
           IF  WS-ERROR-YES
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  BNAC-1000-BROWSE-PREV
               THRU BNAC-1000-BROWSE-PREV-X.

           PERFORM  BNAC-2000-READ-PREV
               THRU BNAC-2000-READ-PREV-X.

           IF  WBNAC-IO-EOF
               PERFORM  BNAC-3000-END-BROWSE-PREV
                   THRU BNAC-3000-END-BROWSE-PREV-X
      *MSG: 'NO HISTORY RECORDS FOUND TO DISPLAY'
               MOVE 'CS27900002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2010-GET-BANK-ACCOUNT-REC
               THRU 2010-GET-BANK-ACCOUNT-REC-X
               VARYING WS-SUB FROM 2 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WBNAC-IO-EOF.

           IF  WBNAC-IO-EOF
      *MSG: 'END OF LIST'
               MOVE 'XS00000015'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE RBNAC-BNK-ID            TO MIR-BNK-ID
               MOVE RBNAC-BNK-BR-ID         TO MIR-BNK-BR-ID
               MOVE RBNAC-BNK-ACCT-ID       TO MIR-BNK-ACCT-ID
036742*        MOVE RBNAC-BACHNG-TS         TO MIR-DV-BACHNG-TS
036742         MOVE RBNAC-BACHNG-GEN-ID     TO MIR-BACHNG-GEN-ID
           END-IF.

           PERFORM  BNAC-3000-END-BROWSE-PREV
               THRU BNAC-3000-END-BROWSE-PREV-X.

       2000-LIST-X.
           EXIT.


      *--------------------------
       2010-GET-BANK-ACCOUNT-REC.
      *--------------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  BNAC-2000-READ-PREV
               THRU BNAC-2000-READ-PREV-X.

       2010-GET-BANK-ACCOUNT-REC-X.
           EXIT.
      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------
      *
      *  READ THE CLIENT FILE, FOR VALIDATE AND GET BACK NAME
      *
           MOVE MIR-BNK-ID                  TO WBNKA-BNK-ID.
           MOVE MIR-BNK-BR-ID               TO WBNKA-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID             TO WBNKA-BNK-ACCT-ID.

           PERFORM  BNKA-1000-READ
               THRU BNKA-1000-READ-X.

           IF  NOT WBNKA-IO-OK
      *MSG: ACCOUNT RECORD (@1) DOES NOT EXIST
               MOVE 'CS27900001'            TO WGLOB-MSG-REF-INFO
               MOVE WBNKA-KEY               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WS-ERROR-YES            TO TRUE
               GO TO  2100-VALIDATE-KEYS-X
           END-IF.
           
           MOVE RBNKA-PREV-UPDT-TS          TO WS-BACHNG-TS.
           
           MOVE WS-BACHNG-DATE              TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE         TO 
                                             MIR-DV-BACHNG-DT-T (1).
                                            
           MOVE WS-BACHNG-TIME              TO 
                                             MIR-DV-BACHNG-TIME-T (1).
                                           
           MOVE RBNKA-BNK-ACCT-HLDR-NM      TO
                                         MIR-BNK-ACCT-HLDR-NM-T (1).
                                     
           MOVE RBNKA-BNK-ACCT-TYP-CD       TO
                                          MIR-BNK-ACCT-TYP-CD-T (1).
       
           MOVE RBNKA-BNK-ACCT-MICR-IND     TO
                                        MIR-BNK-ACCT-MICR-IND-T (1).
       
           
       2100-VALIDATE-KEYS-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
           MOVE MIR-BNK-ID                  TO WBNAC-BNK-ID.
           MOVE MIR-BNK-BR-ID               TO WBNAC-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID             TO WBNAC-BNK-ACCT-ID.
036742*    MOVE WWKDT-HIGH-TS               TO WBNAC-BACHNG-TS.
036742     MOVE WCNST-MAX-BACHNG-GEN-ID-N   TO WBNAC-BACHNG-GEN-ID.
                                      
           MOVE WBNAC-KEY                   TO WBNAC-ENDBR-KEY.
036742*    MOVE WWKDT-LOW-TS                TO WBNAC-ENDBR-BACHNG-TS.
036742     MOVE ZEROES                  TO WBNAC-ENDBR-BACHNG-GEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                      TO MIR-DV-BACHNG-DT-G.
           MOVE SPACES                      TO MIR-DV-BACHNG-TIME-G.
           MOVE SPACES                      TO MIR-BNK-ACCT-HLDR-NM-G.
           MOVE SPACES                      TO MIR-BNK-ACCT-TYP-CD-G.
           MOVE SPACES                      TO MIR-BNK-ACCT-MICR-IND-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RBNAC-BACHNG-TS             TO WS-BACHNG-TS.
           
           MOVE WS-BACHNG-DATE              TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE         TO 
                                         MIR-DV-BACHNG-DT-T (WS-SUB).
                                            
           MOVE WS-BACHNG-TIME              TO 
                                         MIR-DV-BACHNG-TIME-T (WS-SUB).
                                           
           MOVE RBNAC-BNK-ACCT-HLDR-NM      TO
                                     MIR-BNK-ACCT-HLDR-NM-T (WS-SUB).
                                     
           MOVE RBNAC-BNK-ACCT-TYP-CD       TO
                                      MIR-BNK-ACCT-TYP-CD-T (WS-SUB).
       
           MOVE RBNAC-BNK-ACCT-MICR-IND     TO
                                    MIR-BNK-ACCT-MICR-IND-T (WS-SUB).
       
           MOVE RBNAC-BACHNG-REASN-CD       TO
                                    MIR-BACHNG-REASN-CD-T (WS-SUB).
           
           MOVE RBNAC-USER-ID               TO
                                    MIR-USER-ID-T (WS-SUB).
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                      TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE          TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT            TO TRUE.
      *    MOVE MIR-CLI-ID                  TO WGLOB-REF-CLIENT-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE                          WS-WORKING-STORAGE.
025970*    MOVE 20                          TO WS-MAX-LIST-LINES.
025970     COMPUTE WS-MAX-LIST-LINES = LENGTH OF MIR-DV-BACHNG-DT-G /
025970                                 LENGTH OF MIR-DV-BACHNG-DT-T (1).
025970
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
025970     MOVE SPACES TO  WWKDT-WORK-FIELDS.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNBNKA.
      /
       COPY CCPVBNAC.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2790
      *****************************************************************

