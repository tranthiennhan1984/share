      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0665.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0665                                         **
      **  REMARKS:  SELECTION OF FUNDS FOR MONTHIVERSARY PROCESSING  **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557669**  5.5       ORIGINAL                                         **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       PUT WORK DATES THRU THE DATE ROUTINE TO GET      **
005409**            VALID DATE PRIOR TO MOVING TO DB2 TABLES         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012066**  5.6       CHANGES REQUIRED FOR AS/400                      **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017074**  6.2       UL M/V FUND INFO. BEFORE ISSUE DATE HANDLING     **
012522**  6.3       MONTHIVERSARY PROCESSING FOR INVESTMENTS (6.1.1E)**
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020463**  6.4       INVESTOR PROFILES                                **
021778**  6.4       CLONE OF TRADITIONAL PRODUCT                     **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
027105**  6.6       99 COVERAGES HANDLING                            **
026766**  6.6       PERFORMANCE MONITORING                           **
029747**  6.7       99 COVERAGES HANDLING                            **
032329**  7.0       99 COVERAGES AND 98 FUNDS HANDLING               **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0665'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

007766 COPY XCWWCVGM.
014221 COPY CCWWLOCK.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 WS-SUB-DEFAULT            VALUE ZERO.
016548*    05  WS-SUB1                      PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB1                      PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 WS-SUB1-DEFAULT            VALUE ZERO.
016548*    05  WS-SUB2                      PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB2                      PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 WS-SUB2-DEFAULT            VALUE ZERO.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +10  COMP.
016548     05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +10
016548                                      BINARY.
025970         88 WS-MAX-BROWSE-LINES-DEFAULT            VALUE +10.
016548*    05  WS-MAX-NUMBER-COV            PIC S9(4)  VALUE +20  COMP.
027105*    05  WS-MAX-NUMBER-COV            PIC S9(4)  VALUE +20
027105*                                     BINARY.
027105     05  WS-MAX-NUMBER-COV            PIC S9(4)  BINARY.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-ID-VALID            VALUES ARE
                   '0510' '0511' '0512' '0513' '0514' '0515'.
               88  WS-BUS-FCN-RETRIEVE            VALUE '0510'.
               88  WS-BUS-FCN-CREATE              VALUE '0511'.
               88  WS-BUS-FCN-UPDATE              VALUE '0512'.
               88  WS-BUS-FCN-DELETE              VALUE '0513'.
               88  WS-BUS-FCN-LIST                VALUE '0514'.
               88  WS-BUS-FCN-KLON                VALUE '0515'.
014221     05  WS-TWRK-KEY                  PIC X(04) VALUE '0510'.
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '0510'.
           05  WS-LAST-BR-ENTCD             PIC 9(02).
029747     05  WS-CVG-NUM-DISPLAY           PIC Z9.
           05  WS-HOLD-LAST-MFSD-KEY        PIC X(23).
           05  WS-HOLD-COMPANY-CODE         PIC X(02).
           05  WS-HOLD-COV                  PIC X(02).
           05  WS-HOLD-COV-R REDEFINES WS-HOLD-COV
                                            PIC 9(02).
           05  WS-EFF-IDT-NUM               PIC X(07).
           05  WS-EFF-IDT-NUM-R REDEFINES WS-EFF-IDT-NUM
                                            PIC 9(07).
           05  WS-EFF-INTERNAL-DT           PIC X(10).
           05  WS-AMT-TYPE-CD               PIC X(01).
               88  WS-AMT-TYPE-VALID        VALUE 'P' 'A'.
               88  WS-AMT-TYPE-AMOUNT       VALUE 'A'.
               88  WS-AMT-TYPE-PERCENT      VALUE 'P'.
           05  WS-POL-ID.
               10  WS-POL-ID-1-9            PIC X(09).
               10  WS-POL-ID-10             PIC X(01).
           05  WS-TOTAL-PERCENT             PIC S9(08)V9(03).
           05  WS-PERCENT-SW                PIC X(01).
               88  WS-PERCENT-FOUND         VALUE 'Y'.
               88  WS-PERCENT-NOT-FOUND     VALUE 'N'.
           05  WS-ENTRY-EMPTY-SW            PIC X(01).
               88  WS-ENTRY-FILLED          VALUE 'N'.
               88  WS-ENTRY-EMPTY           VALUE 'Y'.
008455*    05  WS-PIC9-8-3                  PIC Z(07)9.999.
           05  WS-PIC9-99                   PIC 9(02).
           05  WS-PIC9-999                  PIC 9(03).
           05  WS-SAVED-SEQ                 PIC X(03).
           05  WS-KLON-NEW-INFO.
               10  WS-KLON-NEW-POL-ID       PIC X(10).
               10  WS-KLON-NEW-IDT-NUM      PIC X(07).
008455     05  WS-BLANK-AMT                 PIC X(29).
           05  WS-INPUT-TABLE.
032329*        10  WS-INPUT-ENTRIES         OCCURS 20 TIMES.
032329         10  WS-INPUT-ENTRIES         OCCURS 99 TIMES.
                   15  WS-INPUT-SEQ         PIC X(03).
                   15  WS-INPUT-COV         PIC X(02).
                   15  WS-INPUT-CD          PIC X(01).
008455*            15  WS-INPUT-AMT-PCT     PIC S9(08)V9(03) COMP-3.
008455             15  WS-INPUT-AMT-PCT     PIC S9(13)V9(03) COMP-3.
016440     05  WS-ERROR-SW                  PIC X.
016440         88  WS-ERROR-FOUND           VALUE 'Y'.

      ****************************************************************
      * COMMON COPYBOOKS
      ****************************************************************
026057 COPY CCWWIHSD.
026057 COPY XCWWWKDT.
016537*COPY XCWWWKDT.
       COPY XCWEBLCH.

      ****************************************************************
      * I/O COPYBOOKS
      ****************************************************************
       COPY CCFWMFSL.
       COPY CCFRMFSL.

       COPY CCFWMFSD.
       COPY CCFRMFSD.

       COPY CCFWPOL.
       COPY CCFRPOL.

       COPY CCFRCVG.
       COPY CCFWCVG.
      *
      ****************************************************************
      * CALLED MODULE PARAMTER INFORMATION
      ****************************************************************
020478 COPY CCWL2626.
020463 COPY CCWL2735.
016440 COPY CCWL5400.
       COPY XCWL0280.
008455 COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWL1670.
       COPY XCWL1680.
014221 COPY XCWL8090.
       COPY XCWLDTLK.

      ****************************************************************
      * INPUT PARAMETER INFORMATION
      ****************************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0665.
      *

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
008455*
008455*    SETUP WORKING STORAGE FIELD WITH AMOUNT ZERO IN
008455*    APPROPRIATE FORMATTING
008455*
020874*    MOVE 0                     TO  L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO  L0290-INPUT-V03.
008455     MOVE 3                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
008455                                TO  L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  WS-BLANK-AMT.
008455
016440     MOVE 'N'                   TO WS-ERROR-SW.
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
      *
      *    EDIT KEY VALUES
      *
           PERFORM  8000-KEY-EDITS
               THRU 8000-KEY-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
016440     OR WS-ERROR-FOUND
              IF WS-BUS-FCN-LIST
                 PERFORM  9180-BLANK-BROWSE-LINES
                     THRU 9180-BLANK-BROWSE-LINES-X
              ELSE
                 PERFORM  9100-BLANK-INQUIRE-LINES
                     THRU 9100-BLANK-INQUIRE-LINES-X
025388*          MOVE 'E'             TO  MIR-MTHV-FND-STAT-CD
025388           SET  MIR-MTHV-FND-STAT-ERR  TO TRUE
              END-IF
              IF WS-BUS-FCN-KLON
                 MOVE ' '             TO  MIR-MTHV-FND-STAT-CD
      *MSG: RECORD NOT KLON
                 MOVE 'CS06650021'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                   PERFORM  3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

                WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN WS-BUS-FCN-KLON
                   PERFORM  7000-PROCESS-KLON
                       THRU 7000-PROCESS-KLON-X

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *---------------------
       3000-PROCESS-RETRIEVE.
      *---------------------

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  8100-BUILD-MFSL-KEY
               THRU 8100-BUILD-MFSL-KEY-X.

           PERFORM  MFSL-1000-READ
               THRU MFSL-1000-READ-X.

           IF NOT WMFSL-IO-OK
      *MSG: RECORD NOT FOUND
              MOVE 'CS00000026'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3000-PROCESS-RETRIEVE-X
           ELSE
              MOVE RMFSL-MTHV-FND-STAT-CD
                                      TO  MIR-MTHV-FND-STAT-CD
           END-IF.

           PERFORM  8400-BUILD-MFSD-BR-KEY
               THRU 8400-BUILD-MFSD-BR-KEY-X

           PERFORM  MFSD-1000-BROWSE
               THRU MFSD-1000-BROWSE-X

           IF WMFSD-IO-OK
              PERFORM  MFSD-2000-READ-NEXT
                  THRU MFSD-2000-READ-NEXT-X
              IF WMFSD-IO-EOF
      *MSG: END OF FILE REACHED
                 MOVE 'XS00000025'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 PERFORM  9100-BLANK-INQUIRE-LINES
                     THRU 9100-BLANK-INQUIRE-LINES-X
                 PERFORM  MFSD-3000-END-BROWSE
                     THRU MFSD-3000-END-BROWSE-X
              ELSE
                 PERFORM  8600-DISPLAY-DATA-LINES
                     THRU 8600-DISPLAY-DATA-LINES-X
                     VARYING WS-SUB FROM +1 BY +1
                     UNTIL   WS-SUB > WS-MAX-NUMBER-COV
                        OR   WMFSD-IO-EOF
                 PERFORM  MFSD-3000-END-BROWSE
                     THRU MFSD-3000-END-BROWSE-X
              END-IF
           ELSE
               PERFORM  9100-BLANK-INQUIRE-LINES
                   THRU 9100-BLANK-INQUIRE-LINES-X
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *--------------------
       3500-PROCESS-LIST.
      *--------------------

           PERFORM  9180-BLANK-BROWSE-LINES
               THRU 9180-BLANK-BROWSE-LINES-X.

           PERFORM  8300-BUILD-MFSL-BR-KEY
               THRU 8300-BUILD-MFSL-BR-KEY-X.

           PERFORM  MFSL-1000-BROWSE
               THRU MFSL-1000-BROWSE-X.

           IF WMFSL-IO-EOF
              MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3500-PROCESS-LIST-X
           ELSE
              PERFORM  MFSL-2000-READ-NEXT
                  THRU MFSL-2000-READ-NEXT-X
              IF WMFSL-IO-EOF
                 MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 PERFORM  MFSL-3000-END-BROWSE
                     THRU MFSL-3000-END-BROWSE-X
                 GO TO 3500-PROCESS-LIST-X
               END-IF
           END-IF.

           PERFORM  3510-PROCESS-LIST-READ
               THRU 3510-PROCESS-LIST-READ-X
               VARYING WS-SUB FROM +1 BY +1
               UNTIL   WS-SUB > WS-MAX-BROWSE-LINES
                  OR   WMFSL-IO-EOF.

           IF WS-SUB > WS-MAX-BROWSE-LINES  AND
              NOT WMFSL-IO-EOF
              MOVE MIR-MTHV-FND-EFF-DT-T (WS-MAX-BROWSE-LINES)
                                      TO  MIR-MTHV-FND-EFF-DT
           END-IF.

           IF WMFSL-IO-EOF
              MOVE 'XS00000025'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:  TO VIEW MORE DATA, PRESS ENTER
              MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
              SET WGLOB-MORE-DATA-EXISTS TO TRUE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  MFSL-3000-END-BROWSE
               THRU MFSL-3000-END-BROWSE-X.


       3500-PROCESS-LIST-X.
           EXIT.
      *
      *-------------------------
       3510-PROCESS-LIST-READ.
      *-------------------------

           MOVE RMFSL-MTHV-FND-IDT-NUM          TO  L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE   TO  L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X
           MOVE L1640-EXTERNAL-DATE
                                  TO  MIR-MTHV-FND-EFF-DT-T    (WS-SUB).
           MOVE RMFSL-MTHV-FND-STAT-CD
                                  TO  MIR-MTHV-FND-STAT-CD-T   (WS-SUB).

           PERFORM  MFSL-2000-READ-NEXT
               THRU MFSL-2000-READ-NEXT-X.

       3510-PROCESS-LIST-READ-X.
           EXIT.
      *
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      *
           IF MIR-DV-PRCES-STATE-CD = '1'
               PERFORM  4100-CREATE
                   THRU 4100-CREATE-X
           ELSE
               PERFORM  4200-CREATE
                   THRU 4200-CREATE-X
           END-IF.

       4000-PROCESS-CREATE-X.
           EXIT.
      *
      *------------
       4100-CREATE.
      *------------

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  8025-COMPARE-DATE
               THRU 8025-COMPARE-DATE-X.

           IF WGLOB-MSG-ERROR-SW > ZEROS
025388*        MOVE 'E'               TO  MIR-MTHV-FND-STAT-CD
025388         SET  MIR-MTHV-FND-STAT-ERR    TO TRUE
               PERFORM  9100-BLANK-INQUIRE-LINES
                   THRU 9100-BLANK-INQUIRE-LINES-X
               GO TO 4100-CREATE-X
           END-IF.

           PERFORM  8100-BUILD-MFSL-KEY
               THRU 8100-BUILD-MFSL-KEY-X.

           PERFORM  MFSL-1000-READ
               THRU MFSL-1000-READ-X.

           IF WMFSL-IO-OK
      * MSG: 'HEADER RECORD @1 HAS ALREADY EXISTED
               MOVE 'CS06650009'      TO  WGLOB-MSG-REF-INFO
               MOVE WMFSL-POL-ID      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
025388*        MOVE 'E'               TO  MIR-MTHV-FND-STAT-CD
025388         SET MIR-MTHV-FND-STAT-ERR  TO TRUE
               PERFORM  8400-BUILD-MFSD-BR-KEY
                   THRU 8400-BUILD-MFSD-BR-KEY-X

               PERFORM  MFSD-1000-BROWSE
                   THRU MFSD-1000-BROWSE-X

               IF WMFSD-IO-OK
                  PERFORM  MFSD-2000-READ-NEXT
                      THRU MFSD-2000-READ-NEXT-X
               END-IF
               IF NOT WMFSD-IO-EOF
                  PERFORM  8600-DISPLAY-DATA-LINES
                      THRU 8600-DISPLAY-DATA-LINES-X
                      VARYING WS-SUB FROM +1 BY +1
                      UNTIL   WS-SUB > WS-MAX-NUMBER-COV
                         OR   WMFSD-IO-EOF
               END-IF
               PERFORM  MFSD-3000-END-BROWSE
                   THRU MFSD-3000-END-BROWSE-X
               GO TO 4100-CREATE-X
           END-IF.

012522*    IF RPOL-POL-INS-TYP-CD = 'C'
012522*    OR RPOL-POL-INS-TYP-CD = 'D'
012522     IF  RPOL-POL-MTHV-PRCES
012522     AND (RPOL-POL-INS-TYP-FLEXIBLE
012522      OR  RPOL-POL-INS-TYP-SEG-FUND)
              CONTINUE
           ELSE
      * MSG: SELECTION ONLY AVAILABLE FOR UL TYPE (C, D)
               MOVE 'CS06650026'      TO  WGLOB-MSG-REF-INFO
               MOVE WMFSL-POL-ID      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-INQUIRE-LINES
                   THRU 9100-BLANK-INQUIRE-LINES-X
025388*        MOVE 'E'               TO  MIR-MTHV-FND-STAT-CD
025388         SET MIR-MTHV-FND-STAT-ERR     TO TRUE
               GO TO 4100-CREATE-X
           END-IF.

           PERFORM  9120-BLANK-DATA-LINES
               THRU 9120-BLANK-DATA-LINES-X.

025388*    MOVE 'E'                TO MIR-MTHV-FND-STAT-CD.
025388     SET MIR-MTHV-FND-STAT-ERR   TO TRUE
      *MSG: CREATE DETAILS
           MOVE 'CS06650020'       TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4100-CREATE-X.
           EXIT.
      *
      *------------
       4200-CREATE.
      *------------

           MOVE MIR-POL-ID-BASE           TO  WS-POL-ID-1-9.
           MOVE MIR-POL-ID-SFX            TO  WS-POL-ID-10.
           MOVE WS-POL-ID                 TO  WPOL-POL-ID.
014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 4200-CREATE-X
014221     END-IF.

           PERFORM  8025-COMPARE-DATE
               THRU 8025-COMPARE-DATE-X.

           IF WGLOB-MSG-ERROR-SW > ZEROS
025388*        MOVE 'E'                   TO  MIR-MTHV-FND-STAT-CD
025388         SET MIR-MTHV-FND-STAT-ERR TO TRUE
               PERFORM  9100-BLANK-INQUIRE-LINES
                   THRU 9100-BLANK-INQUIRE-LINES-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 4200-CREATE-X
           END-IF.

           INITIALIZE                     WS-INPUT-TABLE.
025388*    MOVE 'I'                       TO  MIR-MTHV-FND-STAT-CD.
025388     SET  MIR-MTHV-FND-STAT-INACTV  TO TRUE.

           PERFORM  8030-DATA-EDITS
               THRU 8030-DATA-EDITS-X.

           IF WGLOB-MSG-ERROR-SW = ZEROS

              PERFORM  8100-BUILD-MFSL-KEY
                  THRU 8100-BUILD-MFSL-KEY-X
025388*       MOVE 'A'                    TO  RMFSL-MTHV-FND-STAT-CD
025388        SET  RMFSL-MTHV-FND-STAT-ACTV TO TRUE
005409*       MOVE WS-EFF-INTERNAL-DT     TO  RMFSL-MTHV-FND-EFF-DT
005409        MOVE WS-EFF-INTERNAL-DT     TO L1680-INTERNAL-1
005409        MOVE ZERO                   TO L1680-NUMBER-OF-YEARS
005409        MOVE ZERO                   TO L1680-NUMBER-OF-MONTHS
005409        MOVE ZERO                   TO L1680-NUMBER-OF-DAYS
005409        PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409            THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
005409        MOVE L1680-INTERNAL-2       TO RMFSL-MTHV-FND-EFF-DT
              PERFORM  MFSL-1000-WRITE
                  THRU MFSL-1000-WRITE-X
              PERFORM  MFSL-1000-READ-FOR-UPDATE
                  THRU MFSL-1000-READ-FOR-UPDATE-X
              PERFORM  8400-BUILD-MFSD-BR-KEY
                  THRU 8400-BUILD-MFSD-BR-KEY-X
              PERFORM  8500-SAVE-MFSD-RECORDS
                  THRU 8500-SAVE-MFSD-RECORDS-X
                  VARYING WS-SUB FROM +1 BY +1
                  UNTIL   WS-SUB > WS-MAX-NUMBER-COV
              PERFORM  MFSL-3000-UNLOCK
                  THRU MFSL-3000-UNLOCK-X

           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
      *MSG:  ALL ERRORS MUST BE CORRECTED BEFORE RECORD CAN BE
      *      WRITTEN
              MOVE 'CS06650019'        TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
025388*       MOVE 'E'                 TO  MIR-MTHV-FND-STAT-CD
025388        SET  MIR-MTHV-FND-STAT-ERR  TO TRUE
           ELSE
              MOVE 'XS00000007'        TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
025388*       MOVE 'A'                 TO  MIR-MTHV-FND-STAT-CD
025388        SET MIR-MTHV-FND-STAT-ACTV TO TRUE
           END-IF.

014221*    PERFORM  POL-3000-UNLOCK
014221*        THRU POL-3000-UNLOCK-X.

014221     PERFORM  POL-2000-REWRITE
014221         THRU POL-2000-REWRITE-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       4200-CREATE-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           MOVE MIR-POL-ID-BASE       TO  WS-POL-ID-1-9.
           MOVE MIR-POL-ID-SFX        TO  WS-POL-ID-10.
           MOVE WS-POL-ID             TO  WPOL-POL-ID.
014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  8100-BUILD-MFSL-KEY
               THRU 8100-BUILD-MFSL-KEY-X.

           PERFORM  MFSL-1000-READ-FOR-UPDATE
               THRU MFSL-1000-READ-FOR-UPDATE-X.

           IF WMFSL-IO-NOT-FOUND
              PERFORM  9100-BLANK-INQUIRE-LINES
                  THRU 9100-BLANK-INQUIRE-LINES-X
              MOVE WMFSL-KEY          TO  WGLOB-MSG-PARM (1)
              MOVE 'XS00000006'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  POL-3000-UNLOCK
                  THRU POL-3000-UNLOCK-X
              GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           MOVE RPOL-POL-UL-PRCES-DT  TO  L1680-INTERNAL-1.
           MOVE ZEROS                 TO  L1680-NUMBER-OF-YEARS.
           MOVE 1                     TO  L1680-NUMBER-OF-MONTHS.
           MOVE ZEROS                 TO  L1680-NUMBER-OF-DAYS.
           PERFORM  1680-4000-SUB-YMD-FROM-DATE
               THRU 1680-4000-SUB-YMD-FROM-DATE-X
           IF WS-EFF-INTERNAL-DT < L1680-INTERNAL-2
           OR WS-EFF-INTERNAL-DT = L1680-INTERNAL-2
              IF MIR-MTHV-FND-STAT-CD = SPACES
                 MOVE  RMFSL-MTHV-FND-STAT-CD
                                      TO  MIR-MTHV-FND-STAT-CD
              END-IF
025388*       IF MIR-MTHV-FND-STAT-CD NOT = 'I' AND
025388        IF NOT MIR-MTHV-FND-STAT-INACTV AND
                 MIR-MTHV-FND-STAT-CD NOT = RMFSL-MTHV-FND-STAT-CD
      *MSG: SELECT STATUS CAN ONLY BE MAINTAIN WITH 'I'
                 MOVE 'CS06650024'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 PERFORM  MFSL-3000-UNLOCK
                     THRU MFSL-3000-UNLOCK-X
              ELSE
                 MOVE MIR-MTHV-FND-STAT-CD
                                      TO  RMFSL-MTHV-FND-STAT-CD
                 PERFORM  MFSL-2000-REWRITE
                     THRU MFSL-2000-REWRITE-X
      *MSG: MONTHIVERSARY PROCESSING ON @1 HAS BEEN PROCESSED
                 MOVE 'CS06650029'    TO  WGLOB-MSG-REF-INFO
                 MOVE MIR-MTHV-FND-EFF-DT
                                      TO  WGLOB-MSG-PARM (1)
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
      *MSG: STATUS UPDATED, OTHER DATA KEEP THE SAME
                 MOVE 'CS06650030'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
014221*       PERFORM  POL-3000-UNLOCK
014221*           THRU POL-3000-UNLOCK-X
014221        PERFORM  POL-2000-REWRITE
014221            THRU POL-2000-REWRITE-X
014221        PERFORM  POL-1000-READ-TWRK-TS
014221            THRU POL-1000-READ-TWRK-TS-X
              GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           INITIALIZE                     WS-INPUT-TABLE.

           PERFORM  8030-DATA-EDITS
               THRU 8030-DATA-EDITS-X.

           IF WGLOB-MSG-ERROR-SW = ZERO

              PERFORM  8400-BUILD-MFSD-BR-KEY
                  THRU 8400-BUILD-MFSD-BR-KEY-X
              PERFORM  MFSD-1000-DELETE-KEY-RANGE
                  THRU MFSD-1000-DELETE-KEY-RANGE-X
              PERFORM  8500-SAVE-MFSD-RECORDS
                  THRU 8500-SAVE-MFSD-RECORDS-X
                  VARYING WS-SUB FROM +1 BY +1
                  UNTIL   WS-SUB > WS-MAX-NUMBER-COV
              PERFORM  8100-BUILD-MFSL-KEY
                  THRU 8100-BUILD-MFSL-KEY-X
025388*       IF MIR-MTHV-FND-STAT-CD = 'I'
025388        IF MIR-MTHV-FND-STAT-INACTV
025388*          MOVE 'I'             TO  RMFSL-MTHV-FND-STAT-CD
025388           SET RMFSL-MTHV-FND-STAT-INACTV  TO TRUE
              ELSE
025388*          MOVE 'A'             TO  RMFSL-MTHV-FND-STAT-CD
025388           SET RMFSL-MTHV-FND-STAT-ACTV    TO TRUE
              END-IF
              PERFORM  MFSL-2000-REWRITE
                  THRU MFSL-2000-REWRITE-X

           ELSE
              PERFORM  MFSL-3000-UNLOCK
                  THRU MFSL-3000-UNLOCK-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
      *MSG:  ALL ERRORS MUST BE CORRECTED BEFORE RECORD CAN BE
      *      WRITTEN
              MOVE 'CS06650019'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
025388*       MOVE 'E'                TO  MIR-MTHV-FND-STAT-CD
025388        SET  MIR-MTHV-FND-STAT-ERR   TO TRUE
           ELSE
              MOVE 'XS00000007'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              MOVE RMFSL-MTHV-FND-STAT-CD
                                      TO  MIR-MTHV-FND-STAT-CD
           END-IF.

014221*    PERFORM  POL-3000-UNLOCK
014221*        THRU POL-3000-UNLOCK-X.

014221     PERFORM  POL-2000-REWRITE
014221         THRU POL-2000-REWRITE-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      *
      *-------------------
       6000-PROCESS-DELETE.
      *-------------------

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  8025-COMPARE-DATE
               THRU 8025-COMPARE-DATE-X.

           IF WGLOB-MSG-ERROR-SW > ZEROS
025388*        MOVE 'E'               TO  MIR-MTHV-FND-STAT-CD
025388         SET MIR-MTHV-FND-STAT-ERR   TO TRUE
               PERFORM  9100-BLANK-INQUIRE-LINES
                   THRU 9100-BLANK-INQUIRE-LINES-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

           PERFORM  8100-BUILD-MFSL-KEY
               THRU 8100-BUILD-MFSL-KEY-X.

           PERFORM  MFSL-1000-READ-FOR-UPDATE
               THRU MFSL-1000-READ-FOR-UPDATE-X.

           IF WMFSL-IO-OK
              PERFORM  8400-BUILD-MFSD-BR-KEY
                  THRU 8400-BUILD-MFSD-BR-KEY-X
              PERFORM  MFSD-1000-DELETE-KEY-RANGE
                  THRU MFSD-1000-DELETE-KEY-RANGE-X
              PERFORM  MFSL-1000-DELETE
                  THRU MFSL-1000-DELETE-X
      *MSG:  DELETE COMPLETED
              MOVE 'XS00000011'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-2000-REWRITE
014221             THRU POL-2000-REWRITE-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
            ELSE
               MOVE WMFSL-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:  HEADER RECORD NOT FOUND
               MOVE 'XS00000013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
           END-IF.

           PERFORM  9100-BLANK-INQUIRE-LINES
               THRU 9100-BLANK-INQUIRE-LINES-X.

       6000-PROCESS-DELETE-X.
           EXIT.

      *-----------------
       7000-PROCESS-KLON.
      *-----------------

           IF MIR-DV-PRCES-STATE-CD = '1'
               PERFORM  7100-KLON
                   THRU 7100-KLON-X
           ELSE
               PERFORM  7200-KLON
                   THRU 7200-KLON-X
           END-IF.

       7000-PROCESS-KLON-X.
           EXIT.

      *----------
       7100-KLON.
      *----------
      *
      *---- SET DEFAULT KLON SCREEN ENVIRONMENT
      *
           PERFORM  9120-BLANK-DATA-LINES
               THRU 9120-BLANK-DATA-LINES-X.
      *
      *---- VALIDATION
      *
           PERFORM  7110-KLON-EDITS
               THRU 7110-KLON-EDITS-X.
           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 7100-KLON-X
           END-IF.
      *
      *---- STORE KLON SOURCE IN WORK AREA AND GIVE INSTRUCTION
      *

           MOVE RMFSL-MTHV-FND-STAT-CD  TO MIR-MTHV-FND-STAT-CD.

           PERFORM  8400-BUILD-MFSD-BR-KEY
               THRU 8400-BUILD-MFSD-BR-KEY-X.

           PERFORM  MFSD-1000-BROWSE
               THRU MFSD-1000-BROWSE-X.

           IF WMFSD-IO-OK
              PERFORM  MFSD-2000-READ-NEXT
                  THRU MFSD-2000-READ-NEXT-X
              IF WMFSD-IO-EOF
                 CONTINUE
              ELSE
                 PERFORM  8600-DISPLAY-DATA-LINES
                     THRU 8600-DISPLAY-DATA-LINES-X
                     VARYING WS-SUB FROM +1 BY +1
                     UNTIL   WS-SUB > WS-MAX-NUMBER-COV
                        OR   WMFSD-IO-EOF
              END-IF
           END-IF.

           PERFORM  MFSD-3000-END-BROWSE
               THRU MFSD-3000-END-BROWSE-X.

      * MSG: 'ENTER POLICY NUMBER/ EFFECTIVE DATE OF KLON DESTINATION'
           MOVE 'CS06650015'            TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       7100-KLON-X.
           EXIT.

      *----------------
       7110-KLON-EDITS.
      *----------------
      *
      *---- CHECK KLON SOURCE DOES OR NOT
      *
           PERFORM  8100-BUILD-MFSL-KEY
               THRU 8100-BUILD-MFSL-KEY-X.

           PERFORM  MFSL-1000-READ
               THRU MFSL-1000-READ-X.

           IF WMFSL-IO-NOT-FOUND
      *MSG:  CLONE SOURCE INFORMATION DOES NOT EXIST
              MOVE 'CS06650016'            TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 7110-KLON-EDITS-X
           END-IF.

       7110-KLON-EDITS-X.
           EXIT.

      *----------
       7200-KLON.
      *----------

           MOVE MIR-POL-ID-BASE        TO  WS-POL-ID-1-9.
           MOVE MIR-POL-ID-SFX         TO  WS-POL-ID-10.
           MOVE WS-POL-ID              TO  WPOL-POL-ID.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           PERFORM  8025-COMPARE-DATE
               THRU 8025-COMPARE-DATE-X.

           IF WGLOB-MSG-ERROR-SW > ZEROS
               PERFORM  9100-BLANK-INQUIRE-LINES
                   THRU 9100-BLANK-INQUIRE-LINES-X
               MOVE SPACES                TO  MIR-MTHV-FND-WTHDR-NUM-G
               MOVE SPACES                TO  MIR-MTHV-FND-WTHDR-AMT-G
025388*        MOVE 'E'                   TO  MIR-MTHV-FND-STAT-CD
025388         SET MIR-MTHV-FND-STAT-ERR  TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 7200-KLON-X
           END-IF.

           PERFORM  7220-KLON-2ND-EDITS
               THRU 7220-KLON-2ND-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW > ZEROS
               PERFORM  9100-BLANK-INQUIRE-LINES
                   THRU 9100-BLANK-INQUIRE-LINES-X
      *MSG: RECORD NOT KLON
               MOVE 'CS06650021'          TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 7200-KLON-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW = ZEROS

              PERFORM  8100-BUILD-MFSL-KEY
                  THRU 8100-BUILD-MFSL-KEY-X
025388*       MOVE 'A'                    TO  RMFSL-MTHV-FND-STAT-CD
025388        SET RMFSL-MTHV-FND-STAT-ACTV TO TRUE
005409*       MOVE WS-EFF-INTERNAL-DT     TO  RMFSL-MTHV-FND-EFF-DT
005409        MOVE WS-EFF-INTERNAL-DT     TO  L1680-INTERNAL-1
005409        MOVE ZERO                   TO  L1680-NUMBER-OF-YEARS
005409        MOVE ZERO                   TO  L1680-NUMBER-OF-MONTHS
005409        MOVE ZERO                   TO  L1680-NUMBER-OF-DAYS
005409        PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409            THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
005409        MOVE L1680-INTERNAL-2       TO RMFSL-MTHV-FND-EFF-DT
              PERFORM  MFSL-1000-WRITE
                  THRU MFSL-1000-WRITE-X
              PERFORM  MFSL-1000-READ-FOR-UPDATE
                  THRU MFSL-1000-READ-FOR-UPDATE-X
              PERFORM  8400-BUILD-MFSD-BR-KEY
                  THRU 8400-BUILD-MFSD-BR-KEY-X
              PERFORM  8500-SAVE-MFSD-RECORDS
                  THRU 8500-SAVE-MFSD-RECORDS-X
                  VARYING WS-SUB FROM +1 BY +1
                  UNTIL   WS-SUB > WS-MAX-NUMBER-COV
              PERFORM  MFSL-3000-UNLOCK
                  THRU MFSL-3000-UNLOCK-X

           END-IF.

      *MSG: SFML/SFMD RECORD CLONED
           MOVE 'CS06650022'              TO  WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9100-BLANK-INQUIRE-LINES
               THRU 9100-BLANK-INQUIRE-LINES-X.

           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.

       7200-KLON-X.
           EXIT.

      /
      *-------------------
       7220-KLON-2ND-EDITS.
      *-------------------

021778*
021778*---- CHECK AND MADE SURE THE DESTINATION POLICY
021778*---- IS A UL POLICY
021778*
021778     IF  RPOL-POL-MTHV-PRCES
021778     AND (RPOL-POL-INS-TYP-FLEXIBLE
021778     OR  RPOL-POL-INS-TYP-SEG-FUND)
021778        CONTINUE
021778     ELSE
021778* MSG: SELECTION ONLY AVAILABLE FOR UL TYPE (C, D)
021778         MOVE 'CS06650026'      TO  WGLOB-MSG-REF-INFO
021778         MOVE RPOL-POL-ID       TO  WGLOB-MSG-PARM (1)
021778         PERFORM  0260-1000-GENERATE-MESSAGE
021778             THRU 0260-1000-GENERATE-MESSAGE-X
021778         PERFORM  9100-BLANK-INQUIRE-LINES
021778             THRU 9100-BLANK-INQUIRE-LINES-X
021778         SET WGLOB-RETURN-ERROR           TO TRUE
021778         GO TO 7220-KLON-2ND-EDITS-X
021778     END-IF.

      *
      *---- CHECK CLONE SOURCE MUST NOT EXIST IN MFSL
      *
           PERFORM  8100-BUILD-MFSL-KEY
               THRU 8100-BUILD-MFSL-KEY-X.

           PERFORM  MFSL-1000-READ
               THRU MFSL-1000-READ-X.

           IF  WMFSL-IO-NOT-FOUND
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG:  CLONE DESTINATION DOES ALREADY EXIST
              MOVE 'CS06650018'            TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 7220-KLON-2ND-EDITS-X
           END-IF.

           PERFORM  8400-BUILD-MFSD-BR-KEY
               THRU 8400-BUILD-MFSD-BR-KEY-X.

012066     MOVE WMFSL-POL-ID         TO WMFSD-POL-ID.
012066     MOVE WMFSL-POL-ID         TO WMFSD-ENDBR-POL-ID.

           PERFORM  MFSD-1000-BROWSE
               THRU MFSD-1000-BROWSE-X.

           IF WMFSD-IO-EOF
034802*       NEXT SENTENCE
034802        CONTINUE
           ELSE
              PERFORM  MFSD-2000-READ-NEXT
                  THRU MFSD-2000-READ-NEXT-X
              IF WMFSD-IO-EOF
                 CONTINUE
              ELSE
      *MSG:  CLONE DESTINATION DOES ALREADY EXIST
                 MOVE 'CS06650018'        TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

           PERFORM  MFSD-3000-END-BROWSE
               THRU MFSD-3000-END-BROWSE-X.

           PERFORM  8030-DATA-EDITS
               THRU 8030-DATA-EDITS-X.

       7220-KLON-2ND-EDITS-X.
           EXIT.
      *
      *--------------
       8000-KEY-EDITS.
      *-------------

           PERFORM  8010-EDIT-POLICY
               THRU 8010-EDIT-POLICY-X.

           MOVE SPACES                TO  WS-EFF-IDT-NUM.

           PERFORM  8020-EDIT-EFF-DATE
               THRU 8020-EDIT-EFF-DATE-X.

       8000-KEY-EDITS-X.
           EXIT.
      *
      *----------------
       8010-EDIT-POLICY.
      *----------------

           IF MIR-POL-ID-BASE = SPACES
      *MSG: POLICY NUMBER CANNOT BE BLANK
              MOVE 'CS06650001'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8010-EDIT-POLICY-X
           END-IF.

           MOVE MIR-POL-ID-BASE       TO  WS-POL-ID-1-9.
           MOVE MIR-POL-ID-SFX        TO  WS-POL-ID-10.
           MOVE WS-POL-ID             TO  WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X

           IF WPOL-IO-NOT-FOUND
              MOVE 'XS00000070'       TO  WGLOB-MSG-REF-INFO
              MOVE WPOL-POL-ID        TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8010-EDIT-POLICY-X
           END-IF.

016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.
016440
016440     SET L5400-POL-XFER-INQ     TO  TRUE.
016440     IF  WS-BUS-FCN-CREATE
016440     OR  WS-BUS-FCN-UPDATE
016440     OR  WS-BUS-FCN-DELETE
016440         SET L5400-POL-XFER-UPDATE TO TRUE
016440     END-IF.
016440
016440     IF  WS-BUS-FCN-KLON
016440     AND (MIR-DV-PRCES-STATE-CD NOT = '1')
016440         SET L5400-POL-XFER-UPDATE TO TRUE
016440     END-IF.
016440
016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.
016440
016440     IF  L5400-XFER-ACCS-RESTRICTED
016440         SET WS-ERROR-FOUND      TO TRUE
016440     END-IF.


020463     IF  WS-BUS-FCN-CREATE
020463     OR  WS-BUS-FCN-UPDATE
020463     OR  WS-BUS-FCN-KLON
020463         PERFORM  2735-1000-BUILD-PARM-INFO
020463             THRU 2735-1000-BUILD-PARM-INFO-X
020463         MOVE  RPOL-POL-ID   TO L2735-POL-ID
020463         PERFORM  2735-1000-GET-PRFL
020463             THRU 2735-1000-GET-PRFL-X
020463         IF L2735-RETRN-PRFL-FND
020463*MSG: THE UL MV INSTRUCTIONS ENTERED MAY NOT MATCH THE
020463*     ALLOCATIONS DEFINED FOR THE INVESTOR PROFILE.
020463            MOVE 'CS06650032'      TO WGLOB-MSG-REF-INFO
020463            PERFORM  0260-1000-GENERATE-MESSAGE
020463               THRU  0260-1000-GENERATE-MESSAGE-X
020463
020463             IF  WGLOB-MSG-SEVRTY-FATAL
020463                 SET WGLOB-RETURN-ERROR  TO TRUE
020463                 GO TO 8010-EDIT-POLICY-X
020463             END-IF
020463
020463         END-IF
020463     END-IF.
020463
       8010-EDIT-POLICY-X.
           EXIT.
      *
      *------------------
       8020-EDIT-EFF-DATE.
      *------------------

           IF MIR-MTHV-FND-EFF-DT = SPACES
              IF WS-BUS-FCN-LIST
                 GO TO 8020-EDIT-EFF-DATE-X
              ELSE
      *MSG: DATE CANNOT BE BLANK FOR INQUIRE, CREATE, MAINTAIN,
      *     DELETE OR KLON
                 MOVE 'CS06650003'    TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 GO TO 8020-EDIT-EFF-DATE-X
              END-IF
           END-IF.

017074*  ALLOW DISPLAY/DELETE/KLON EVEN IF < ISSUE EFFECTIVE DATE

           MOVE MIR-MTHV-FND-EFF-DT   TO  L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
      *MSG: INVALID DATE
              MOVE 'XS00000036'       TO  WGLOB-MSG-REF-INFO
              MOVE MIR-MTHV-FND-EFF-DT            TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8020-EDIT-EFF-DATE-X
           ELSE
              IF L1640-INTERNAL-DATE < RPOL-POL-ISS-EFF-DT
017074        AND (WS-BUS-FCN-UPDATE OR WS-BUS-FCN-CREATE)
      *MSG: DATE CANNOT BE BEFORE THE ISSUE-DATE.
                 MOVE 'CS06650025'    TO  WGLOB-MSG-REF-INFO
                 MOVE MIR-MTHV-FND-EFF-DT
                                      TO  WGLOB-MSG-PARM (1)
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 GO TO 8020-EDIT-EFF-DATE-X
              END-IF
           END-IF.

026057     IF  WGLOB-RETURN-ERROR
026057     OR  WGLOB-MSG-ERROR-SW > ZERO
026057        GO TO 8020-EDIT-EFF-DATE-X
026057     END-IF.
026057
026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE L1640-INTERNAL-DATE         TO WIHSD-EFF-DT.
026057     IF  WS-BUS-FCN-RETRIEVE
026057     OR  WS-BUS-FCN-LIST
026057         PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057             THRU IHSD-1000-CHK-IHSD-INQUIRY-X
026057     ELSE
026057         PERFORM  IHSD-3000-CHK-IHSD-INSTR
026057             THRU IHSD-3000-CHK-IHSD-INSTR-X
026057     END-IF.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WGLOB-RETURN-ERROR     TO TRUE
026057        GO TO 8020-EDIT-EFF-DATE-X
026057     END-IF.

           MOVE L1640-INTERNAL-DATE   TO  L1660-INTERNAL-DATE.
           MOVE L1640-INTERNAL-DATE   TO  WS-EFF-INTERNAL-DT.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE   TO  WS-EFF-IDT-NUM.

       8020-EDIT-EFF-DATE-X.
           EXIT.
      *
      *-----------------
       8025-COMPARE-DATE.
      *-----------------

           MOVE RPOL-POL-UL-PRCES-DT  TO  L1680-INTERNAL-1.
           MOVE ZEROS                 TO  L1680-NUMBER-OF-YEARS.
           MOVE 1                     TO  L1680-NUMBER-OF-MONTHS.
           MOVE ZEROS                 TO  L1680-NUMBER-OF-DAYS.
           PERFORM  1680-4000-SUB-YMD-FROM-DATE
               THRU 1680-4000-SUB-YMD-FROM-DATE-X
           IF WS-EFF-INTERNAL-DT < L1680-INTERNAL-2
           OR WS-EFF-INTERNAL-DT = L1680-INTERNAL-2
      *MSG: MONTHIVERSARY PROCESSING ON @1 HAS BEEN PROCESSED
              MOVE 'CS06650029'       TO  WGLOB-MSG-REF-INFO
              MOVE MIR-MTHV-FND-EFF-DT            TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8025-COMPARE-DATE-X.
           EXIT.
      *
      *---------------
       8030-DATA-EDITS.
      *---------------

           IF MIR-MTHV-FND-STAT-CD = SPACE
              CONTINUE
           ELSE
025388*       IF MIR-MTHV-FND-STAT-CD NOT = 'I' AND
025388        IF NOT MIR-MTHV-FND-STAT-INACTV AND
                 MIR-MTHV-FND-STAT-CD NOT = RMFSL-MTHV-FND-STAT-CD
      *MSG: SELECT STATUS CAN ONLY BE MAINTAIN WITH 'I'
                 MOVE 'CS06650024'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 MOVE WS-MAX-NUMBER-COV
                                      TO  WS-SUB
                 GO TO 8030-DATA-EDITS-X
              END-IF
           END-IF.

           IF WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  8032-DATA-FIELD-EDITS
                   THRU 8032-DATA-FIELD-EDITS-X
                   VARYING WS-SUB FROM +1 BY +1
                   UNTIL   WS-SUB > WS-MAX-NUMBER-COV
           END-IF.

           IF WGLOB-MSG-ERROR-SW = ZERO
              PERFORM  8050-CROSS-FIELD-EDITS
                  THRU 8050-CROSS-FIELD-EDITS-X
           END-IF.

       8030-DATA-EDITS-X.
           EXIT.
      *
      *---------------------
       8032-DATA-FIELD-EDITS.
      *---------------------

008455     MOVE 'N'                   TO  L0280-SIGN-IND.
008455     MOVE 3                     TO  L0280-PRECISION.
008455     MOVE LENGTH OF MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
008455                                TO  L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
008455     MOVE MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
                                      TO  L0280-INPUT-DATA.
008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF NOT L0280-OK
008455        MOVE 1                  TO  L0280-OUTPUT
008455     END-IF.
           IF (MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB) = SPACES OR
               MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB) = '000') AND
              MIR-CVG-NUM-T (WS-SUB) = SPACES AND
              MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB) = SPACES AND
008455*       MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB) = (SPACES OR
008455*                                           '00000000.000')
008455        (MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB) = SPACES OR
008455         L0280-OUTPUT = 0)
              PERFORM  9150-BLANK-DATA-LINES
                  THRU 9150-BLANK-DATA-LINES-X
              GO TO 8032-DATA-FIELD-EDITS-X
           END-IF.

           IF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB) =
                                          EBLCH-BLANK-FIELD-GROUP
              MOVE SPACES             TO  WS-INPUT-SEQ (WS-SUB)
              MOVE SPACES             TO  WS-INPUT-COV (WS-SUB)
              MOVE SPACES             TO  WS-INPUT-CD  (WS-SUB)
              MOVE ZEROS              TO  WS-INPUT-AMT-PCT (WS-SUB)
              PERFORM  9150-BLANK-DATA-LINES
                  THRU 9150-BLANK-DATA-LINES-X
                GO TO 8032-DATA-FIELD-EDITS-X
           END-IF.

           PERFORM  8041-EDIT-SEQ
               THRU 8041-EDIT-SEQ-X.

           PERFORM  8042-EDIT-COV
               THRU 8042-EDIT-COV-X.

           PERFORM  8043-EDIT-AMT-TYPE-CD
               THRU 8043-EDIT-AMT-TYPE-CD-X.

           PERFORM  8044-EDIT-AMT
               THRU 8044-EDIT-AMT-X.

       8032-DATA-FIELD-EDITS-X.
           EXIT.
      *
      *-------------
       8041-EDIT-SEQ.
      *-------------

           IF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB) =
                                          EBLCH-BLANK-FIELD-GROUP
              MOVE SPACES             TO  WS-INPUT-SEQ (WS-SUB)
              MOVE SPACES             TO  WS-INPUT-COV (WS-SUB)
              MOVE SPACES             TO  WS-INPUT-CD  (WS-SUB)
              MOVE ZEROS              TO  WS-INPUT-AMT-PCT (WS-SUB)
              MOVE SPACES          TO  MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
              MOVE SPACES             TO  MIR-CVG-NUM-T (WS-SUB)
              MOVE SPACES          TO  MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB)
              MOVE SPACES          TO  MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
              GO TO 8041-EDIT-SEQ-X
           END-IF.

           IF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACES             TO  WS-INPUT-SEQ (WS-SUB)
              MOVE SPACES          TO  MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
              GO TO 8041-EDIT-SEQ-X
           END-IF.

           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE ZERO                  TO  L0280-PRECISION.
           MOVE 3                     TO  L0280-LENGTH.
           MOVE MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
                                      TO  L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
020874*       MOVE L0280-OUTPUT       TO  WS-PIC9-999
020874*       MOVE WS-PIC9-999     TO  MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
020874        MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874        MOVE ZERO                  TO L0290-PRECISION
020874        MOVE LENGTH OF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
020874                                   TO L0290-MAX-OUT-LEN
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
020874        MOVE L0290-OUTPUT-DATA
020874                          TO MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
              MOVE MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
                                      TO  WS-INPUT-SEQ (WS-SUB)
           ELSE
      *MSG: SEQ MUST BE NUMERIC
              MOVE 'CS06650004'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8041-EDIT-SEQ-X.
           EXIT.

      *-------------
       8042-EDIT-COV.
      *-------------

           IF MIR-CVG-NUM-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACES             TO  WS-INPUT-COV (WS-SUB)
              MOVE SPACES             TO  MIR-CVG-NUM-T (WS-SUB)
              GO TO 8042-EDIT-COV-X
           END-IF.

           IF MIR-CVG-NUM-T (WS-SUB) = SPACES
              GO TO 8042-EDIT-COV-X
           END-IF.

013578***  MOVE MIR-CVG-NUM-T (WS-SUB)                  TO  WS-HOLD-COV.
013578***  IF WS-HOLD-COV NOT NUMERIC OR
013578***     WS-HOLD-COV-R < 1 OR
007766*       WS-HOLD-COV-R > 20
013578***     WS-HOLD-COV-R > WCVGM-MAX-WCVGS-NUM
007766*MSG: COV NUMBER IS OUT OF RANGE (1 - 20)
007766*MSG: COV @1 IS OUT OF RANGE (1 - @2)
013578***     MOVE 'CS06650005'       TO  WGLOB-MSG-REF-INFO
013578***     MOVE MIR-CVG-NUM-T (WS-SUB)
013578***                             TO  WGLOB-MSG-PARM (1)
013578***     MOVE WCVGM-MAX-WCVGS-NUM            TO  WGLOB-MSG-PARM (2)
013578***     PERFORM  0260-1000-GENERATE-MESSAGE
013578***         THRU 0260-1000-GENERATE-MESSAGE-X
013578***     GO TO 8042-EDIT-COV-X
013578***  END-IF.


           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE ZERO                  TO  L0280-PRECISION.
           MOVE 2                     TO  L0280-LENGTH.
           MOVE MIR-CVG-NUM-T (WS-SUB)             TO  L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
013578     AND L0280-OUTPUT > ZERO
013578     AND L0280-OUTPUT <= RPOL-POL-CVG-REC-CTR-N
020874*       MOVE L0280-OUTPUT       TO  WS-PIC9-99
020874*       MOVE WS-PIC9-99         TO  MIR-CVG-NUM-T (WS-SUB)
020874        MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874        MOVE ZERO                     TO L0290-PRECISION
020874        MOVE LENGTH OF MIR-CVG-NUM-T (WS-SUB)
020874                                   TO L0290-MAX-OUT-LEN
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
020874        MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM-T (WS-SUB)
              MOVE MIR-CVG-NUM-T (WS-SUB)
                                      TO  WS-INPUT-COV (WS-SUB)
           ELSE
007766*MSG: COV NUMBER IS OUT OF RANGE (1 - 20)
007766*MSG: COV @1 IS OUT OF RANGE (1 - @2)
              MOVE 'CS06650005'       TO  WGLOB-MSG-REF-INFO
              MOVE MIR-CVG-NUM-T (WS-SUB)
                                      TO  WGLOB-MSG-PARM (1)
029747*       MOVE WCVGM-MAX-WCVGS-NUM            TO  WGLOB-MSG-PARM (2)
029747        MOVE RPOL-POL-CVG-REC-CTR-N         TO  WS-CVG-NUM-DISPLAY
029747        MOVE WS-CVG-NUM-DISPLAY             TO  WGLOB-MSG-PARM (2)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8042-EDIT-COV-X
           END-IF.

           MOVE MIR-POL-ID-BASE            TO  WCVG-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WCVG-POL-ID-SFX.
           MOVE MIR-CVG-NUM-T (WS-SUB)                 TO  WCVG-CVG-NUM.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF WCVG-IO-NOT-FOUND
      *MSG: COV (@1) DOES NOT EXIST IN THE POLICY
              MOVE 'CS06650006'       TO  WGLOB-MSG-REF-INFO
              MOVE MIR-CVG-NUM-T (WS-SUB)
                                      TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8042-EDIT-COV-X
           END-IF.

           IF RCVG-CVG-INS-TYP-CD  = 'D'
           OR RCVG-CVG-INS-TYP-CD  = 'N'
           OR RCVG-CVG-INS-TYP-CD  = 'F'
              CONTINUE
           ELSE
      *MSG: COV (@1) MUST BE INSURANCE TYPE D OR N OR F
              MOVE 'CS06650027'       TO  WGLOB-MSG-REF-INFO
              MOVE MIR-CVG-NUM-T (WS-SUB)
                                      TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8042-EDIT-COV-X
           END-IF.

           IF  RCVG-CVG-STAT-PENDING
            OR RCVG-CVG-STAT-IN-FORCE
              CONTINUE
           ELSE
      *MSG: COV (@1) MUST BE INFORCE OR PENDING
              MOVE 'CS06650028'       TO  WGLOB-MSG-REF-INFO
              MOVE MIR-CVG-NUM-T (WS-SUB)
                                      TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8042-EDIT-COV-X
           END-IF.

018846     IF  RCVG-PLAN-FND-TYP-XTRNL
018846*MSG: EXTERNAL COVERAGE (@1) CAN'T BE INCLUDED IN THE SELECTION
018846         MOVE 'CS06650031'       TO  WGLOB-MSG-REF-INFO
018846         MOVE MIR-CVG-NUM-T (WS-SUB)
018846                                TO  WGLOB-MSG-PARM (1)
018846         PERFORM  0260-1000-GENERATE-MESSAGE
018846             THRU 0260-1000-GENERATE-MESSAGE-X
018846         GO TO 8042-EDIT-COV-X
018846     END-IF.
018846
       8042-EDIT-COV-X.
           EXIT.

      *---------------------
       8043-EDIT-AMT-TYPE-CD.
      *---------------------

           IF MIR-MTHV-FND-WTHDR-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACES             TO  WS-INPUT-CD (WS-SUB)
              MOVE SPACES           TO  MIR-MTHV-FND-WTHDR-CD-T (WS-SUB)
              GO TO 8043-EDIT-AMT-TYPE-CD-X
           END-IF.

           IF MIR-MTHV-FND-WTHDR-CD-T (WS-SUB) = SPACES
              GO TO 8043-EDIT-AMT-TYPE-CD-X
           END-IF.

           MOVE MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB)
                                      TO  WS-AMT-TYPE-CD.

           IF WS-AMT-TYPE-VALID
              MOVE MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB)
                                      TO  WS-INPUT-CD  (WS-SUB)
           ELSE
      *MSG:  VALUE OF CD SHOULD BE A OR P
              MOVE 'CS06650007'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8043-EDIT-AMT-TYPE-CD-X.
           EXIT.

      *-------------
       8044-EDIT-AMT.
      *-------------

           IF MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              MOVE ZEROS              TO  WS-INPUT-CD (WS-SUB)
              MOVE SPACES           TO  MIR-MTHV-FND-WTHDR-CD-T (WS-SUB)
              GO TO 8044-EDIT-AMT-X
           END-IF.

           IF MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB) = SPACES
008455*    OR MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB) = '00000000.000'
              GO TO 8044-EDIT-AMT-X
           END-IF.

           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE 3                     TO  L0280-PRECISION.
008455*    MOVE 8                         TO  L0280-LENGTH.
008455*    MOVE 12                        TO  L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
008455                                TO  L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
           MOVE MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
                                      TO  L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF NOT L0280-OK
      *MSG AMOUNT/PCT MUST BE NUMERIC
              MOVE 'CS06650008'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8044-EDIT-AMT-X
           ELSE
              MOVE L0280-OUTPUT-V03   TO  WS-INPUT-AMT-PCT (WS-SUB)
008455*       MOVE L0280-OUTPUT-V03       TO  WS-PIC9-8-3
008455*       MOVE WS-PIC9-8-3     TO  MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
              MOVE L0280-OUTPUT       TO  L0290-INPUT-NUMBER
008455        PERFORM  9350-FORMAT-AMT-T
008455            THRU 9350-FORMAT-AMT-T-X
           END-IF.

           IF WS-AMT-TYPE-PERCENT
              IF WS-INPUT-AMT-PCT (WS-SUB) > +100
      *MSG:  ALLOCATION PERCENT GREATER THAN 100 %
                 MOVE 'CS06650010'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

       8044-EDIT-AMT-X.
           EXIT.
      *
      *----------------------
       8050-CROSS-FIELD-EDITS.
      *----------------------

           SET WS-ENTRY-EMPTY            TO  TRUE.

           PERFORM
               VARYING WS-SUB2 FROM +1 BY +1
027105*        UNTIL   WS-SUB2 > +20
027105         UNTIL   WS-SUB2 > WS-MAX-NUMBER-COV
                  OR   WS-ENTRY-FILLED
              IF (MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2) = SPACES OR
                  MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2) = '000') AND
                 MIR-CVG-NUM-T (WS-SUB2) = SPACES AND
                 MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB2) = SPACES AND
008455*          MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB2) = (SPACES OR
008455*                                              '00000000.000')
008455           (MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB2) = SPACES OR
008455            WS-INPUT-AMT-PCT (WS-SUB2) = 0)
                 CONTINUE
              ELSE
                 SET WS-ENTRY-FILLED         TO  TRUE
              END-IF
           END-PERFORM.

           IF WS-ENTRY-EMPTY
      *MSG:  DISTRIBUTED INFORMATION NOT COMPLETELY FILLED
              MOVE 'CS06650014'       TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8050-CROSS-FIELD-EDITS-X
           END-IF.

           PERFORM  8051-CROSS-EDIT-COV-NUM
               THRU 8051-CROSS-EDIT-COV-NUM-X
               VARYING WS-SUB2 FROM +1 BY +1
               UNTIL   WS-SUB2 > WS-MAX-NUMBER-COV.

           SET WS-PERCENT-NOT-FOUND       TO  TRUE.
           PERFORM  8052-CROSS-EDIT-SEQ-COV-PCT
               THRU 8052-CROSS-EDIT-SEQ-COV-PCT-X
               VARYING WS-SUB2 FROM +1 BY +1
               UNTIL   WS-SUB2 > WS-MAX-NUMBER-COV.

           IF WGLOB-MSG-ERROR-SW = ZERO
              PERFORM  8053-CROSS-EDIT-ALLOC-PCT
                  THRU 8053-CROSS-EDIT-ALLOC-PCT-X
                  VARYING WS-SUB2 FROM +1 BY +1
                  UNTIL   WS-SUB2 > WS-MAX-NUMBER-COV
           END-IF.

           IF WGLOB-MSG-ERROR-SW = ZERO
              PERFORM  8054-CROSS-EDIT-ALL-FIELDS
                  THRU 8054-CROSS-EDIT-ALL-FIELDS-X
                  VARYING WS-SUB2 FROM +1 BY +1
                  UNTIL   WS-SUB2 > WS-MAX-NUMBER-COV
           END-IF.

       8050-CROSS-FIELD-EDITS-X.
           EXIT.
      *
      *-----------------------
       8051-CROSS-EDIT-COV-NUM.
      *-----------------------

           IF MIR-CVG-NUM-T (WS-SUB2) = SPACES
              GO TO 8051-CROSS-EDIT-COV-NUM-X
           END-IF.

           PERFORM
               VARYING WS-SUB1 FROM +1 BY +1
               UNTIL   WS-SUB1 > WS-MAX-NUMBER-COV

              IF WS-SUB2 = WS-SUB1
                 CONTINUE
              ELSE
                 IF MIR-CVG-NUM-T (WS-SUB2) = WS-INPUT-COV (WS-SUB1)
      *MSG:  EACH COVERAGE CAN ONLY BE ENTERED ONCE
                    MOVE 'CS06650011' TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    MOVE WS-MAX-NUMBER-COV
                                      TO  WS-SUB2
                    MOVE WS-MAX-NUMBER-COV
                                      TO  WS-SUB1
                 END-IF
              END-IF

           END-PERFORM.

       8051-CROSS-EDIT-COV-NUM-X.
           EXIT.
      *
      *---------------------------
       8052-CROSS-EDIT-SEQ-COV-PCT.
      *---------------------------

           IF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2) = SPACES
           OR MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2) = '000'
              GO TO 8052-CROSS-EDIT-SEQ-COV-PCT-X
           END-IF.

           SET WS-PERCENT-NOT-FOUND       TO  TRUE.

           PERFORM
               VARYING WS-SUB1 FROM +1 BY +1
               UNTIL   WS-SUB1  > WS-MAX-NUMBER-COV
                  OR   WS-PERCENT-FOUND
              IF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2) =
                 MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB1)
025388*          IF MIR-MTHV-FND-WTHDR-CD-T ( WS-SUB1) = 'P'
025388           IF MIR-MTHV-FND-WTHDR-PERCENT-T ( WS-SUB1)
                    SET WS-PERCENT-FOUND   TO  TRUE
                 END-IF
              END-IF
           END-PERFORM.

           IF WS-PERCENT-NOT-FOUND
      *MSG:  MUST HAVE AT LEAST ONE PERCENTAGE DESTINATION CODE FOR
      *      SEQ @1
              MOVE 'CS06650012'       TO  WGLOB-MSG-REF-INFO
              MOVE MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2)
                                      TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              MOVE WS-MAX-NUMBER-COV  TO  WS-SUB2
           END-IF.


       8052-CROSS-EDIT-SEQ-COV-PCT-X.
           EXIT.
      *
      *-------------------------
       8053-CROSS-EDIT-ALLOC-PCT.
      *-------------------------

           MOVE ZEROS                 TO  WS-TOTAL-PERCENT.


           IF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2) = SPACES OR
              MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB2) = SPACES OR
008455*       MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB2) = (SPACES OR
008455*                                            '00000000.000')
008455       (MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB2) = SPACES OR
008455        WS-INPUT-AMT-PCT (WS-SUB2) = 0)
              GO TO 8053-CROSS-EDIT-ALLOC-PCT-X
           END-IF.

           PERFORM
               VARYING WS-SUB1 FROM +1 BY +1
               UNTIL   WS-SUB1 > WS-MAX-NUMBER-COV
              IF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2) =
                 MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB1)
025388*          IF MIR-MTHV-FND-WTHDR-CD-T (WS-SUB1) = 'P'
025388           IF MIR-MTHV-FND-WTHDR-PERCENT-T (WS-SUB1)
                    ADD WS-INPUT-AMT-PCT  (WS-SUB1) TO WS-TOTAL-PERCENT
                 END-IF
              END-IF
           END-PERFORM.

           IF WS-TOTAL-PERCENT NOT = 100
      *MSG:  ALLOCATION PERCENT DOSE NOT TOTAL TO 100 %  - SEQ @1
              MOVE 'CS06650013'       TO  WGLOB-MSG-REF-INFO
              MOVE MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB2)
                                      TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              MOVE WS-MAX-NUMBER-COV  TO  WS-SUB2
           END-IF.


       8053-CROSS-EDIT-ALLOC-PCT-X.
           EXIT.
      *
      *--------------------------
       8054-CROSS-EDIT-ALL-FIELDS.
      *--------------------------

           IF  ( MIR-MTHV-FND-WTHDR-NUM-T    (WS-SUB2) = SPACES
             OR  MIR-MTHV-FND-WTHDR-NUM-T    (WS-SUB2) = '000'  )
           AND   MIR-CVG-NUM-T    (WS-SUB2) = SPACES
           AND   MIR-MTHV-FND-WTHDR-CD-T     (WS-SUB2) = SPACES
           AND ( MIR-MTHV-FND-WTHDR-AMT-T    (WS-SUB2) = WS-BLANK-AMT
008455*      OR  MIR-MTHV-FND-WTHDR-AMT-T    (WS-SUB2) = '00000000.000')
008455       OR  WS-INPUT-AMT-PCT (WS-SUB2) = 0)
              GO TO 8054-CROSS-EDIT-ALL-FIELDS-X
           END-IF.

           IF  MIR-MTHV-FND-WTHDR-NUM-T    (WS-SUB2) = SPACES
           OR  MIR-MTHV-FND-WTHDR-NUM-T    (WS-SUB2) = '000'
           OR  MIR-CVG-NUM-T    (WS-SUB2) = SPACES
           OR  MIR-MTHV-FND-WTHDR-CD-T     (WS-SUB2) = SPACES
           OR  MIR-MTHV-FND-WTHDR-AMT-T    (WS-SUB2) = WS-BLANK-AMT
008455*    OR  MIR-MTHV-FND-WTHDR-AMT-T    (WS-SUB2) = '00000000.000'
008455     OR  WS-INPUT-AMT-PCT (WS-SUB2) = 0
      *MSG:  DISTRIBUTED INFORMATION NOT COMPLETELY FILLED
                 MOVE 'CS06650014'    TO  WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 MOVE WS-MAX-NUMBER-COV
                                      TO  WS-SUB
           END-IF.

       8054-CROSS-EDIT-ALL-FIELDS-X.
           EXIT.
      *
      *-------------------
       8100-BUILD-MFSL-KEY.
      *-------------------

           MOVE MIR-POL-ID-BASE       TO  WS-POL-ID-1-9.
           MOVE MIR-POL-ID-SFX        TO  WS-POL-ID-10.
           MOVE WS-POL-ID             TO  WMFSL-POL-ID.
           MOVE WS-EFF-IDT-NUM        TO  WMFSL-MTHV-FND-IDT-NUM.

       8100-BUILD-MFSL-KEY-X.
           EXIT.
      *
      *-------------------
       8200-BUILD-MFSD-KEY.
      *-------------------

           MOVE RMFSL-POL-ID          TO  WMFSD-POL-ID.
           MOVE RMFSL-MTHV-FND-IDT-NUM       TO  WMFSD-MTHV-FND-IDT-NUM.
           MOVE HIGH-VALUES           TO  WMFSD-ENDBR-KEY.
           MOVE WMFSD-POL-ID          TO  WMFSD-ENDBR-POL-ID.
           MOVE WMFSD-MTHV-FND-IDT-NUM  TO WMFSD-ENDBR-MTHV-FND-IDT-NUM.

       8200-BUILD-MFSD-KEY-X.
           EXIT.
      *
      *----------------------
       8300-BUILD-MFSL-BR-KEY.
      *----------------------

           MOVE LOW-VALUES            TO  WMFSL-KEY.
           MOVE MIR-POL-ID-BASE            TO  WS-POL-ID-1-9.
           MOVE MIR-POL-ID-SFX            TO  WS-POL-ID-10.
           MOVE WS-POL-ID             TO  WMFSL-POL-ID.
           MOVE HIGH-VALUES           TO  WMFSL-ENDBR-KEY.
           MOVE WMFSL-POL-ID          TO  WMFSL-ENDBR-POL-ID.

           IF WS-EFF-IDT-NUM = SPACES
              CONTINUE
           ELSE
              MOVE WS-EFF-IDT-NUM     TO  WMFSL-MTHV-FND-IDT-NUM
           END-IF.

       8300-BUILD-MFSL-BR-KEY-X.
           EXIT.
      *
      *----------------------
       8400-BUILD-MFSD-BR-KEY.
      *----------------------

           MOVE LOW-VALUES            TO  WMFSD-KEY.
           MOVE RMFSL-POL-ID          TO  WMFSD-POL-ID.
           MOVE RMFSL-MTHV-FND-IDT-NUM       TO  WMFSD-MTHV-FND-IDT-NUM.
           MOVE 1                     TO  WMFSD-MTHV-FND-WTHDR-NUM.
           MOVE HIGH-VALUES           TO  WMFSD-ENDBR-KEY.
           MOVE WMFSD-POL-ID          TO  WMFSD-ENDBR-POL-ID.
           MOVE WMFSD-MTHV-FND-IDT-NUM  TO WMFSD-ENDBR-MTHV-FND-IDT-NUM.
           MOVE 999                   TO WMFSD-ENDBR-MTHV-FND-WTHDR-NUM.

       8400-BUILD-MFSD-BR-KEY-X.
           EXIT.
      *
      *----------------------
       8500-SAVE-MFSD-RECORDS.
      *----------------------

           IF MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB) = SPACES OR
              MIR-CVG-NUM-T (WS-SUB) = SPACES OR
              MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB) = SPACES OR
              MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB) = SPACES
              MOVE SPACES           TO MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
              MOVE SPACES             TO MIR-CVG-NUM-T (WS-SUB)
              MOVE SPACES           TO MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB)
              MOVE SPACES           TO MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
              GO TO 8500-SAVE-MFSD-RECORDS-X
           END-IF.

           INITIALIZE                     WMFSD-KEY.
      *    MOVE MIR-POL-ID-BASE                 TO  WMFSD-POL-ID.
           MOVE WS-POL-ID             TO  WMFSD-POL-ID.
           MOVE WS-EFF-IDT-NUM        TO  WMFSD-MTHV-FND-IDT-NUM.
           MOVE MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
                                      TO  WMFSD-MTHV-FND-WTHDR-NUM.
           MOVE MIR-CVG-NUM-T (WS-SUB)                TO  WMFSD-CVG-NUM.
           MOVE MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB)
                                      TO  RMFSD-MTHV-FND-WTHDR-CD.
           MOVE MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB)
                                      TO  WS-AMT-TYPE-CD.
           IF WS-AMT-TYPE-AMOUNT
              MOVE WS-INPUT-AMT-PCT (WS-SUB)
                                      TO  RMFSD-MTHV-FND-WTHDR-AMT
              MOVE ZEROS              TO  RMFSD-MTHV-FND-WTHDR-PCT
           ELSE
              MOVE WS-INPUT-AMT-PCT (WS-SUB)
                                      TO  RMFSD-MTHV-FND-WTHDR-PCT
              MOVE ZEROS              TO  RMFSD-MTHV-FND-WTHDR-AMT
           END-IF.
005409*    MOVE WS-EFF-INTERNAL-DT        TO  RMFSD-MTHV-FND-EFF-DT.
005409     MOVE WS-EFF-INTERNAL-DT    TO  L1680-INTERNAL-1.
005409     MOVE ZERO                  TO  L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO  L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO  L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO  RMFSD-MTHV-FND-EFF-DT.

           PERFORM  MFSD-1000-WRITE
               THRU MFSD-1000-WRITE-X.

       8500-SAVE-MFSD-RECORDS-X.
           EXIT.
      *
      *-----------------------
       8600-DISPLAY-DATA-LINES.
      *-----------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X

           PERFORM  MFSD-2000-READ-NEXT
               THRU MFSD-2000-READ-NEXT-X.

       8600-DISPLAY-DATA-LINES-X.
           EXIT.
      *
      *-----------------------
       8700-WRITE-KLON-MFSD-REC.
      *-----------------------
      *
      *   END BROWSE BEFORE WRITE REC
      *
           MOVE WMFSD-KEY             TO  WS-HOLD-LAST-MFSD-KEY.

           PERFORM  MFSD-3000-END-BROWSE
               THRU MFSD-3000-END-BROWSE-X.

           PERFORM  8100-BUILD-MFSL-KEY
               THRU 8100-BUILD-MFSL-KEY-X.

           MOVE WMFSL-POL-ID          TO  WMFSD-POL-ID.
           MOVE WMFSL-POL-ID          TO  RMFSD-POL-ID.
           MOVE WS-EFF-IDT-NUM        TO  WMFSD-MTHV-FND-IDT-NUM.
           MOVE WS-EFF-IDT-NUM        TO  RMFSD-MTHV-FND-IDT-NUM.

           PERFORM  MFSD-1000-WRITE
               THRU MFSD-1000-WRITE-X.

           MOVE WS-HOLD-LAST-MFSD-KEY TO  WMFSD-KEY.
           MOVE HIGH-VALUES           TO  WMFSD-ENDBR-KEY.
           MOVE WMFSD-POL-ID          TO  WMFSD-ENDBR-POL-ID.
           MOVE WMFSD-MTHV-FND-IDT-NUM  TO WMFSD-ENDBR-MTHV-FND-IDT-NUM.

           PERFORM  MFSD-1000-BROWSE
               THRU MFSD-1000-BROWSE-X.
           PERFORM  MFSD-2000-READ-NEXT
               THRU MFSD-2000-READ-NEXT-X.
           PERFORM  MFSD-2000-READ-NEXT
               THRU MFSD-2000-READ-NEXT-X.

       8700-WRITE-KLON-MFSD-REC-X.
           EXIT.
      *
      *------------------------
       9100-BLANK-INQUIRE-LINES.
      *------------------------

           MOVE SPACES                TO  MIR-CVG-NUM-G.
           MOVE SPACES                TO  MIR-MTHV-FND-WTHDR-CD-G.
           MOVE SPACES                TO  MIR-MTHV-FND-STAT-CD.

           MOVE SPACES                TO  MIR-MTHV-FND-WTHDR-NUM-G.
           MOVE SPACES                TO  MIR-MTHV-FND-WTHDR-AMT-G.

       9100-BLANK-INQUIRE-LINES-X.
           EXIT.
      *
      *----------------------
       9120-BLANK-DATA-LINES.
      *----------------------

           MOVE SPACES                TO  MIR-CVG-NUM-G.
           MOVE SPACES                TO  MIR-MTHV-FND-WTHDR-CD-G.
           MOVE SPACES                TO  MIR-MTHV-FND-STAT-CD.

           PERFORM
               VARYING WS-SUB FROM +1 BY +1
027105*        UNTIL   WS-SUB > +20
027105         UNTIL   WS-SUB > WS-MAX-NUMBER-COV
               MOVE '000'          TO  MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
008455*        MOVE '00000000.000'  TO MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
020874*        MOVE 0                 TO  L0290-INPUT-NUMBER
020874         MOVE ZERO              TO  L0290-INPUT-V03
008455         PERFORM  9350-FORMAT-AMT-T
008455             THRU 9350-FORMAT-AMT-T-X
           END-PERFORM.

       9120-BLANK-DATA-LINES-X.
           EXIT.
      *
      *----------------------
       9150-BLANK-DATA-LINES.
      *----------------------

           MOVE SPACES                TO  MIR-CVG-NUM-T (WS-SUB).
           MOVE SPACES            TO  MIR-MTHV-FND-WTHDR-CD-T  (WS-SUB).

           IF MIR-BUS-FCN-ID = '0510'
              MOVE SPACES          TO  MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
              MOVE SPACES          TO  MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
           ELSE
008455*       MOVE '00000000.000'  TO  MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
020874*       MOVE 0                  TO  L0290-INPUT-NUMBER
020874        MOVE ZERO               TO  L0290-INPUT-V03
008455        PERFORM  9350-FORMAT-AMT-T
008455            THRU 9350-FORMAT-AMT-T-X
              MOVE '000'           TO  MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB)
           END-IF.

       9150-BLANK-DATA-LINES-X.
           EXIT.
      *
      *-----------------------
       9180-BLANK-BROWSE-LINES.
      *-----------------------

           MOVE SPACES                TO  MIR-MTHV-FND-EFF-DT-G.
           MOVE SPACES                TO  MIR-MTHV-FND-STAT-CD-G.

       9180-BLANK-BROWSE-LINES-X.
           EXIT.
      *
      *--------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *--------------------------

           MOVE RMFSD-MTHV-FND-WTHDR-NUM
                                  TO  MIR-MTHV-FND-WTHDR-NUM-T (WS-SUB).
           MOVE RMFSD-CVG-NUM     TO  MIR-CVG-NUM-T (WS-SUB).
           MOVE RMFSD-MTHV-FND-WTHDR-CD
                                  TO  MIR-MTHV-FND-WTHDR-CD-T (WS-SUB).
           MOVE RMFSD-MTHV-FND-WTHDR-CD
                                      TO  WS-AMT-TYPE-CD.

           IF WS-AMT-TYPE-AMOUNT
008455*       MOVE RMFSD-MTHV-FND-WTHDR-AMT
008455*                                   TO  WS-PIC9-8-3
020874*       COMPUTE L0290-INPUT-NUMBER = RMFSD-MTHV-FND-WTHDR-AMT
020874*                                    * 1000
020874        MOVE RMFSD-MTHV-FND-WTHDR-AMT   TO  L0290-INPUT-V03
           ELSE
008455*       MOVE RMFSD-MTHV-FND-WTHDR-PCT
008455*                                   TO  WS-PIC9-8-3
020874*       COMPUTE L0290-INPUT-NUMBER = RMFSD-MTHV-FND-WTHDR-PCT
020874*                                    * 1000
020874        MOVE RMFSD-MTHV-FND-WTHDR-PCT  TO  L0290-INPUT-V03
           END-IF.
008455*    MOVE WS-PIC9-8-3        TO MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB).
008455     PERFORM  9350-FORMAT-AMT-T
008455         THRU 9350-FORMAT-AMT-T-X.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *-------------------------
       9300-SETUP-MSIN-REFERENCE.
      *-------------------------

           MOVE SPACES                TO  WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO  WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      *
008455*------------------
008455 9350-FORMAT-AMT-T.
008455*------------------

008455     MOVE 3                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB)
008455                                TO  L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO  MIR-MTHV-FND-WTHDR-AMT-T (WS-SUB).

008455 9350-FORMAT-AMT-T-X.
008455     EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-SUB-DEFAULT TO TRUE.
025970     SET WS-SUB1-DEFAULT TO TRUE.
025970     SET WS-SUB2-DEFAULT TO TRUE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
027105
027105     COMPUTE WS-MAX-NUMBER-COV
027105             = LENGTH OF MIR-CVG-NUM-G
027105             / LENGTH OF MIR-CVG-NUM-T (1).
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
008455*

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.
018764*COPY CCCL5400.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
020463 COPY CCPS2735.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
020463 COPY CCPL2735.
018764 COPY CCPL5400.
016440 COPY CCPS5400.
025970 COPY XCPS0280.
       COPY XCPL0280.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
016537*COPY XCPL1670.
025970 COPY XCPS1680.
       COPY XCPL1680.
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPAMFSL.
       COPY CCPBMFSL.
016537*COPY CCPCMFSL.
       COPY CCPNMFSL.
       COPY CCPUMFSL.
       COPY CCPXMFSL.

       COPY CCPAMFSD.
       COPY CCPBMFSD.
       COPY CCPGMFSD.
016537*COPY CCPUMFSD.
016537*COPY CCPCMFSD.
016537*COPY CCPXMFSD.

       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNCVG.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0665                     **
      *****************************************************************


