      *****************************************************************
      **  MEMBER :  XSOM0066                                         **
      **  REMARKS:  SIGN-IN FOR SINGLE P-STEP PROCESS                **
      **                                                             **
      **            A SESSION RECORD WILL NOT BE CREATED FOR THIS    **
      **            TYPE OF SIGN-IN.  CURRENCY AND COUNTRY WILL BE   **
      **            DEFAULTED FROM MAST, ALL OTHER SESSION DATA WILL **
      **            BE INITIALIZED DURING VALIDATION OF USER ID      **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE  DESCRIPTION                                       **
      **                                                             **
018764**  6.3      LINKAGE AREA MODIFICATIONS                        **
019474**  6.3      PATHFINDER 1.3 UPGRADE                            **
019804**  6.3.1    PATHFINDER 2.0 UPGRADE                            **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM0066.

       COPY XCWWCRHT.

      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------
      *
      *--------------
       DATA DIVISION.
      *--------------
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM0066'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID          VALUE '0066'.
               88  WS-BUS-FCN-SIGN-IN        VALUE '0066'.

           05  WS-CTRY-SUB                  PIC S9(04) BINARY.
           05  WS-CRCY-SUB                  PIC S9(04) BINARY.
           05  WS-PASS-EXP-DAYS             PIC S9(7)  COMP-3.
           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-ERROR-NO              VALUE 'N'.
           05  WS-VALID-PSWD-IND            PIC X(01).
               88  WS-VALID-PSWD-OK         VALUE 'Y'.
               88  WS-VALID-PSWD-EXPIRED    VALUE 'N'.
           05  WS-PROCESS-DATE              PIC X(10).
      /
           05  WS-DV-APPL-STAT-CD           PIC X(01).
               88  WS-DV-APPL-STAT-ACTIVE   VALUE '1'.
               88  WS-DV-APPL-STAT-STOPPED  VALUE '2'.
               88  WS-DV-APPL-STAT-INACTIVE VALUE '3'.
               88  WS-DV-APPL-STAT-UNKNOWN  VALUE '9'.

019804*    05  WS-USER-SESN-CTRY-CD         PIC X(02).
019804*    05  WS-USER-SESN-CRCY-CD         PIC X(02).
019804*    05  WS-USER-SESN-PRCES-DT        PIC X(10).
      /
021930*COPY XCWL1640.
021930*
       COPY XCWL0020.
      /
       COPY CCFWMAST.
       COPY CCFRMAST.
      /
       COPY XCFWASCL.
       COPY XCFRASCL.
      /
       COPY XCFWUSCL.
       COPY XCFRUSCL.
      /
       COPY XCFWUSEC.
       COPY XCFRUSEC.
      /
       COPY XCFWXTAB.
       COPY XCFRXTAB.
      /
021930*COPY XCWWPASS.
021930*
       COPY XCWLDTLK.
      /
       COPY XCWL1670.
      /
       COPY XCWL1680.
      /
       COPY XCWWWKDT.
      /
       COPY XCWL2490.
      /
      *---------------
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *---------------

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM0066.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *-------------
       0000-MAINLINE.
      *-------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

           IF NOT MIR-RETRN-OK
               SET WGLOB-RETURN-ERROR        TO TRUE
           END-IF

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

025970*           PERFORM  9300-SETUP-MSIN-REFERENCE
025970*               THRU 9300-SETUP-MSIN-REFERENCE-X.
025970*
025970*           MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
025970*           SET MIR-RETRN-OK                    TO TRUE.
025970*           SET WS-VALID-PSWD-OK                TO TRUE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-SIGN-IN
                    PERFORM  2000-PROCESS-SIGN-IN
                        THRU 2000-PROCESS-SIGN-IN-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM0066'            TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

      *
      * CLEAR THE PASSWORD FIELD SO THAT IT DOES NOT RETURN TO THE USER
      *
           MOVE SPACES                     TO MIR-USER-PSWD-TXT.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       2000-PROCESS-SIGN-IN.
      *------------------
      *  THIS FUNCTION REQUIRES A VALIDATION OF THE USER-ID,
      *  PASSWORD AND COMPANY CODE.  ALL THREE MUST BE
      *  SUCCESSFULLY VALIDATED IN ORDER TO PROCEED.  A FAILURE
      *  ON ANY OF THEM WILL RESULT IN A BAD RETURN CODE AND
      *  AN IMMEDIATE RETURN TO THE CALLING PROGRAM.
      *
           SET WS-ERROR-NO                     TO TRUE.

           PERFORM  7000-SIGN-IN-EDITS
               THRU 7000-SIGN-IN-EDITS-X.

           IF WS-ERROR-FOUND
               SET MIR-RETRN-EDIT-ERROR    TO TRUE
               GO TO 2000-PROCESS-SIGN-IN-X
           END-IF.
      *
      *  THE PASSWORD MUST NOT HAVE EXPIRED.  AN EXPIRED PASSWORD WILL
      *  BE FLAGGED WITH A CORRESPONDING RETURN CODE, AND THE PROGRAM
      *  WILL TERMINATE IMMEDIATELY AS A RESULT.
      *
           PERFORM  9000-COMPUTE-PASS-EXP-DAYS
               THRU 9000-COMPUTE-PASS-EXP-DAYS-X.
           IF  WS-VALID-PSWD-EXPIRED
               SET MIR-RETRN-PSWD-EXPIRED  TO TRUE
               GO TO 2000-PROCESS-SIGN-IN-X
           END-IF.
      *
           PERFORM  2020-UPDATE-GLOB
               THRU 2020-UPDATE-GLOB-X.

      *  RETRIEVE MAST INFORMATION.
      *
           PERFORM  9100-RETRIEVE-APPL-INFO
               THRU 9100-RETRIEVE-APPL-INFO-X.

      *
      *  IF THE APPLICATION IS NOT UP AND RUNNING, OUTPUT AN ERROR
      *  MESSAGE INDICATING THAT THE SYSTEM IS NOT AVAILABLE AND THE
      *  USER COULD NOT BE SIGNED ON.
      *
           IF  NOT WS-DV-APPL-STAT-ACTIVE
               SET MIR-RETRN-EDIT-ERROR    TO TRUE
               GO TO 2000-PROCESS-SIGN-IN-X
           END-IF.

       2000-PROCESS-SIGN-IN-X.
           EXIT.

      *----------------
       2020-UPDATE-GLOB.
      *----------------

           MOVE WGLOB-PRCES-ID             TO WGLOB-USER-SESN-ID.
           MOVE 99999                      TO WGLOB-USER-SESN-BTCH-NUM.
           MOVE RUSCL-SECUR-CNFD-ACCS-CD   TO WGLOB-SECUR-CNFD-ACCS-CD.
           MOVE RUSCL-SECUR-LVL-CD         TO WGLOB-SECUR-LVL-CD.
           MOVE RUSEC-SECUR-CLAS-ID        TO WGLOB-SECUR-CLAS-ID.
           MOVE RUSEC-BR-ID                TO WGLOB-USER-BRANCH-CODE.
           MOVE RUSEC-USER-RPT-DSTRB-CD    TO WGLOB-USER-RPT-DSTRB-CD.

           PERFORM  2490-1000-BUILD-PARM-INFO
               THRU 2490-1000-BUILD-PARM-INFO-X.

           MOVE 'XSDU1640'                TO L2490-TXT-SRC-ID.
           MOVE '00001'                   TO L2490-TXT-SRC-REF-ID.

           PERFORM  2490-1000-RETRIEVE-TEXT
               THRU 2490-1000-RETRIEVE-TEXT-X.

           IF L2490-RETRN-OK
               MOVE L2490-TXT-STR-TXT     TO WGLOB-MOS-ABBR-TXT
           ELSE
               MOVE 'JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC'
                                          TO WGLOB-MOS-ABBR-TXT
           END-IF.

       2020-UPDATE-GLOB-X.
           EXIT.

      *----------------
       7000-SIGN-IN-EDITS.
      *----------------

           PERFORM  7510-EDIT-USER-ID
               THRU 7510-EDIT-USER-ID-X.
           PERFORM  7520-EDIT-PASSWORD
               THRU 7520-EDIT-PASSWORD-X.
           PERFORM  7530-EDIT-CO-ID
               THRU 7530-EDIT-CO-ID-X.

           IF  WS-ERROR-FOUND
               GO TO 7000-SIGN-IN-EDITS-X
           END-IF.

           PERFORM  7540-EDIT-ASCL
               THRU 7540-EDIT-ASCL-X.

           PERFORM  7550-EDIT-USER-SESN-CTRY-CD
               THRU 7550-EDIT-USER-SESN-CTRY-CD-X.
           PERFORM  7560-EDIT-USER-SESN-CRCY-CD
               THRU 7560-EDIT-USER-SESN-CRCY-CD-X.

       7000-SIGN-IN-EDITS-X.
           EXIT.

      *-----------------
       7510-EDIT-USER-ID.
      *-----------------
           IF MIR-USER-ID NOT > SPACES
      *MSG:  USER-ID REQUIRED FOR SIGN-IN
               MOVE 'XS00660007'                TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND               TO TRUE
               GO TO 7510-EDIT-USER-ID-X
           END-IF.

           MOVE MIR-USER-ID                    TO WGLOB-USER-ID.
           MOVE MIR-USER-ID                    TO WUSEC-USER-ID.
           PERFORM  USEC-1000-READ
               THRU USEC-1000-READ-X.

           IF NOT WUSEC-IO-OK
      *MSG: USERID (@1) NOT FOUND. RE-ENTER VALID USERID
               MOVE WUSEC-USER-ID               TO WGLOB-MSG-PARM (1)
               MOVE 'XS00660001'                TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND               TO TRUE
               GO TO 7510-EDIT-USER-ID-X
           END-IF.

           MOVE RUSEC-SECUR-CLAS-ID            TO WUSCL-SECUR-CLAS-ID.
           PERFORM  USCL-1000-READ
               THRU USCL-1000-READ-X.

           IF NOT WUSCL-IO-OK
               MOVE WUSCL-KEY                   TO WGLOB-MSG-PARM (1)
      *MSG: SECURITY CLASS RECORD (@1) NOT FOUND
               MOVE 'XS00660008'                TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND               TO TRUE
               GO TO 7510-EDIT-USER-ID-X
           END-IF.

           MOVE RUSEC-SECUR-CLAS-ID             TO WGLOB-SECUR-CLAS-ID.

       7510-EDIT-USER-ID-X.
           EXIT.


      *------------------
       7520-EDIT-PASSWORD.
      *------------------

           IF NOT WUSEC-IO-OK
               GO TO 7520-EDIT-PASSWORD-X
           END-IF.

           IF MIR-USER-PSWD-TXT = RUSEC-USER-PSWD-TXT
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG: PASSWORD NOT AUTHORIZED FOR USERID. RE-ENTER
               MOVE 'XS00660003'                TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND               TO TRUE
               GO TO 7520-EDIT-PASSWORD-X
           END-IF.


       7520-EDIT-PASSWORD-X.
           EXIT.

      *---------------
       7530-EDIT-CO-ID.
      *---------------

           IF MIR-CO-ID = SPACES
      *MSG: COMPANY CODE IS REQUIRED.
               MOVE 'XS00660011'               TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND              TO TRUE
               GO TO 7530-EDIT-CO-ID-X
           END-IF.

           MOVE MIR-CO-ID                      TO WXTAB-ETBL-VALU-ID.
           PERFORM  COMP-1000-EDIT-COMPANY
               THRU COMP-1000-EDIT-COMPANY-X.

           IF WXTAB-IO-OK
               MOVE MIR-CO-ID                  TO WGLOB-COMPANY-CODE
           ELSE
      *MSG: INVALID COMPANY CODE ENTERED. RE-ENTER
               MOVE 'XS00660002'               TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND              TO TRUE
               GO TO 7530-EDIT-CO-ID-X
           END-IF.

       7530-EDIT-CO-ID-X.
           EXIT.
      /
      *---------------
       7540-EDIT-ASCL.
      *---------------

           MOVE WGLOB-SECUR-CLAS-ID            TO WASCL-SECUR-CLAS-ID.
           MOVE WGLOB-COMPANY-CODE             TO WASCL-CO-ID.

           PERFORM ASCL-1000-READ
              THRU ASCL-1000-READ-X.

           IF WASCL-IO-NOT-FOUND
      *MSG: APPLICATION SECURITY CLASS RECORD NOT FOUND FOR COMPANY (@1)
      *     AND SECURITY CLASS (@2)
               MOVE WASCL-CO-ID                TO WGLOB-MSG-PARM (1)
               MOVE WASCL-SECUR-CLAS-ID        TO WGLOB-MSG-PARM (2)
               MOVE 'XS00660012'               TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND              TO TRUE
           END-IF.

       7540-EDIT-ASCL-X.
           EXIT.
      /
      *----------------------------
       7550-EDIT-USER-SESN-CTRY-CD.
      *----------------------------

           IF  MIR-USER-SESN-CTRY-CD = SPACES
               PERFORM  7551-DEFAULT-CTRY-CD
                   THRU 7551-DEFAULT-CTRY-CD-X
           END-IF.

           PERFORM
           VARYING WS-CTRY-SUB FROM +1 BY +1
             UNTIL WS-CTRY-SUB = +5
                OR RASCL-ASCL-CTRY-CD (WS-CTRY-SUB) =
                   MIR-USER-SESN-CTRY-CD
               CONTINUE
           END-PERFORM.

           IF RASCL-ASCL-CTRY-CD (WS-CTRY-SUB) = MIR-USER-SESN-CTRY-CD
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND        TO TRUE
      *MSG: NOT AUTHORIZED FOR REQUESTED COUNTRY. RE-ENTER
               MOVE 'XS00660013'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7550-EDIT-USER-SESN-CTRY-CD-X.
           EXIT.

      *---------------------
       7551-DEFAULT-CTRY-CD.
      *---------------------

           IF RMAST-CO-ID NOT = WGLOB-COMPANY-CODE
               PERFORM  MAST-1000-READ
                   THRU MAST-1000-READ-X
           END-IF.

           IF WMAST-IO-OK
               MOVE RMAST-APPL-CTL-CTRY-CD TO MIR-USER-SESN-CTRY-CD
      *MSG: COUNTRY NOT ENTERED ON MIR.  COUNTRY DEFAULTED TO (@1).
               MOVE RMAST-APPL-CTL-CTRY-CD TO WGLOB-MSG-PARM (1)
               MOVE 'XS00660014'           TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7551-DEFAULT-CTRY-CD-X.
           EXIT.
      /
      *----------------------------
       7560-EDIT-USER-SESN-CRCY-CD.
      *----------------------------

           IF  MIR-USER-SESN-CRCY-CD = SPACES
               PERFORM  7561-DEFAULT-CRCY-CD
                   THRU 7561-DEFAULT-CRCY-CD-X
           END-IF.

           PERFORM
           VARYING WS-CRCY-SUB FROM +1 BY +1
             UNTIL WS-CRCY-SUB = +5
                OR RASCL-ASCL-CRCY-CD (WS-CTRY-SUB, WS-CRCY-SUB) =
                   MIR-USER-SESN-CRCY-CD
              CONTINUE
           END-PERFORM.

           IF RASCL-ASCL-CRCY-CD (WS-CTRY-SUB, WS-CRCY-SUB) =
              MIR-USER-SESN-CRCY-CD
               CONTINUE
           ELSE
      *MSG: NOT AUTHORIZED FOR REQUESTED CURRENCY. RE-ENTER
               MOVE 'XS00660015'   TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7560-EDIT-USER-SESN-CRCY-CD-X.
           EXIT.

      *---------------------
       7561-DEFAULT-CRCY-CD.
      *---------------------

           IF RMAST-CO-ID NOT = WGLOB-COMPANY-CODE
               PERFORM  MAST-1000-READ
                   THRU MAST-1000-READ-X
           END-IF.

           IF WMAST-IO-OK
               MOVE RMAST-APPL-CTL-CRCY-CD TO MIR-USER-SESN-CRCY-CD
      *MSG: CURRENCY NOT ENTERED ON MIR.  CURRENCY DEFAULTED TO (@1).
               MOVE RMAST-APPL-CTL-CRCY-CD TO WGLOB-MSG-PARM (1)
               MOVE 'XS00660016'           TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7561-DEFAULT-CRCY-CD-X.
           EXIT.
      *--------------------------
       9000-COMPUTE-PASS-EXP-DAYS.
      *--------------------------

           MOVE +9999                   TO WS-PASS-EXP-DAYS.

           MOVE RUSEC-USER-PSWD-CHNG-DT TO L1680-INTERNAL-1.
           MOVE WGLOB-SYSTEM-DATE-INT   TO L1680-INTERNAL-2.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.

           IF L1680-VALID
           AND L1680-TOTAL-DAYS NOT < ZERO
              MOVE L1680-TOTAL-DAYS     TO WS-PASS-EXP-DAYS
           END-IF.

           IF WS-PASS-EXP-DAYS > RUSEC-USER-PSWD-XPRY-DUR
           OR WS-PASS-EXP-DAYS = RUSEC-USER-PSWD-XPRY-DUR
      *MSG: YOUR PASSWORD HAS EXPIRED. PLEASE ENTER A NEW PASSWORD
              MOVE 'XS00660004'            TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET WS-VALID-PSWD-EXPIRED    TO TRUE
           END-IF.

       9000-COMPUTE-PASS-EXP-DAYS-X.
           EXIT.
      *----------------------
       9100-RETRIEVE-APPL-INFO.
      *----------------------

           PERFORM  9200-SETUP-L0020-AREA
               THRU 9200-SETUP-L0020-AREA-X.
      *
      *    REQUEST APPLICATION STATUS FROM EXIT
      *
           SET L0020-REQ-APPL-STATUS           TO TRUE.
           PERFORM  0020-1000-LINK-TO-APPL
               THRU 0020-1000-LINK-TO-APPL-X.

           PERFORM  9400-FORMAT-RESPONSE
               THRU 9400-FORMAT-RESPONSE-X.

           IF L0020-RES-DATA-ERROR
           OR L0020-RES-DISCONNECT
           OR L0020-RES-LOGOFF
               GO TO 9100-RETRIEVE-APPL-INFO-X
           END-IF.

           IF L0020-RES-CLOSE-APPL
      *MSG: SYSTEM UNAVAILABLE
               MOVE 'XS00660005'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 9100-RETRIEVE-APPL-INFO-X
           END-IF.

       9100-RETRIEVE-APPL-INFO-X.
           EXIT.
      /
      *---------------------
       9200-SETUP-L0020-AREA.
      *---------------------

           MOVE MIR-CO-ID                     TO L0020-CO-ID.
           MOVE SPACES                        TO L0020-ONLN-PRCES-DT.
019804*    MOVE SPACES                        TO L0020-COUNTRY-CODE.
019804*    MOVE SPACES                        TO L0020-CURRENCY-CODE.
019804     MOVE MIR-USER-SESN-CRCY-CD         TO L0020-CURRENCY-CODE.
019804     MOVE MIR-USER-SESN-CTRY-CD         TO L0020-COUNTRY-CODE.

           MOVE SPACES                        TO L0020-EXIT-RESPONSE.
           MOVE MIR-USER-ID                   TO L0020-USER-ID.
           MOVE WGLOB-USER-SESN-ID            TO L0020-USER-SESN-ID.
           MOVE ZERO                          TO L0020-BATCH-NUMBER.

       9200-SETUP-L0020-AREA-X.
           EXIT.
      /
      *-------------------------
       9300-SETUP-MSIN-REFERENCE.
      *-------------------------

           MOVE SPACES                        TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE            TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------
       9400-FORMAT-RESPONSE.
      *--------------------

           SET WS-DV-APPL-STAT-UNKNOWN         TO TRUE.

           EVALUATE TRUE
               WHEN L0020-RES-CLOSE-APPL
                 SET WS-DV-APPL-STAT-INACTIVE  TO TRUE
019804*          MOVE WWKDT-ZERO-DT            TO WS-PROCESS-DATE
019804           MOVE WWKDT-ZERO-DT            TO WGLOB-PROCESS-DATE

               WHEN L0020-RES-INIT-APPL
               WHEN L0020-RES-SIGN-ON
                 SET WS-DV-APPL-STAT-ACTIVE    TO TRUE
019804           MOVE L0020-COUNTRY-CODE       TO WGLOB-COUNTRY-CODE
019804           MOVE L0020-CURRENCY-CODE      TO WGLOB-CURRENCY-CODE
019804           MOVE L0020-ONLN-PRCES-DT      TO WGLOB-PROCESS-DATE
019804*          MOVE L0020-ONLN-PRCES-DT-DISP TO WS-USER-SESN-PRCES-DT
019804*          MOVE L0020-COUNTRY-CODE       TO WS-USER-SESN-CTRY-CD
019804*          MOVE L0020-CURRENCY-CODE      TO WS-USER-SESN-CRCY-CD
019804*          MOVE L0020-ONLN-PRCES-DT      TO WS-PROCESS-DATE

               WHEN L0020-RES-PROHIBIT-ACCESS
                 SET WS-DV-APPL-STAT-STOPPED   TO TRUE
019804           MOVE L0020-COUNTRY-CODE       TO WGLOB-COUNTRY-CODE
019804           MOVE L0020-CURRENCY-CODE      TO WGLOB-CURRENCY-CODE
019804           MOVE L0020-ONLN-PRCES-DT      TO WGLOB-PROCESS-DATE
019804*          MOVE L0020-ONLN-PRCES-DT-DISP TO WS-USER-SESN-PRCES-DT
019804*          MOVE L0020-COUNTRY-CODE       TO WS-USER-SESN-CTRY-CD

019804*          MOVE L0020-CURRENCY-CODE      TO WS-USER-SESN-CRCY-CD
019804*          MOVE L0020-ONLN-PRCES-DT      TO WS-PROCESS-DATE

               WHEN L0020-RES-DISCONNECT
               WHEN L0020-RES-LOGOFF
               WHEN L0020-RES-DATA-ERROR
      *MSG: SESSION FILE AND USER FILE OUT OF SYNC - CONTACT
      *       SYSTEMS
                 MOVE 'XS00660010'             TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN OTHER
                 SET WS-DV-APPL-STAT-UNKNOWN   TO TRUE
      *MSG: SYSTEM STATUS IS UNKNOWN.  CONTACT SYSTEMS
                   SET MIR-RETRN-EDIT-ERROR    TO TRUE
                   MOVE 'XS00660006'           TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

       9400-FORMAT-RESPONSE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0020-0000-INIT-PARM-INFO
025970         THRU 0020-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2490-0000-INIT-PARM-INFO
025970         THRU 2490-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  9300-SETUP-MSIN-REFERENCE
025970*    CONTINUE.
025970         THRU 9300-SETUP-MSIN-REFERENCE-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.

025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK                    TO TRUE.
025970     SET WS-VALID-PSWD-OK                TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
021930*COPY XCPPINIT.
021930*
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      /
018764*COPY XCCL0020.
025970 COPY XCPS1670.
025970 COPY XCPS0020.
018764 COPY XCPL0020.
      /
       COPY XCPECOMP.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
021930*COPY XCPL1640.
021930*
025970 COPY XCPS1680.
       COPY XCPL1680.
      /
       COPY XCCP0030.
      /
       COPY XCPS2490.
      /
018764*COPY XCCL2490.
018764 COPY XCPL2490.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNMAST.
       COPY XCPNASCL.
       COPY XCPNUSCL.
      /
       COPY XCPNUSEC.
021930*COPY XCPUUSEC.
      /
       COPY XCPNXTAB.
      *****************************************************************
      **                 END OF PROGRAM XSOM0066                     **
      *****************************************************************
