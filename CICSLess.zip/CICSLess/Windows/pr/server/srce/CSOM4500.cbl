      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4500.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4500                                         **
      **  REMARKS:  UTAB: MAINTAIN UNDO/REDO ACTIVITY TABLE          **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE UNDO/REDO ACTIVITY.            **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CHANGE TO STANDARD                               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
018763**  6.3       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020913**  6.4       ELIMINATION OF PROCESSING COPYBOOKS              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4500'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
           05  WS-AUTO-CD                   PIC X(01).
               88  WS-AUTO-CD-VALID         VALUE 'B' 'N' 'U'.
           05  WS-REDO-CD                   PIC X(04).
               88  WS-REDO-CD-VALID         VALUE
                   'SREG' 'NREG' 'SCHE' 'SCF' 'NCF'.
               88  WS-REDO-CD-NCF           VALUE 'NCF'.
               88  WS-REDO-CD-NREG          VALUE 'NREG'.
               88  WS-REDO-CD-SREG          VALUE 'SREG'.
               88  WS-REDO-CD-SCF           VALUE 'SCF'.
               88  WS-REDO-CD-SCHE          VALUE 'SCHE'.
013578*    05  WS-ENTER-CODE                PIC X(01).
013578*        88  WS-ENTER-CODE-VALID      VALUE 'B' 'C' 'M' 'D'.
013578*        88  WS-ENTER-CODE-BROWSE     VALUE 'B'.
013578*        88  WS-ENTER-CODE-CREATE     VALUE 'C'.
013578*        88  WS-ENTER-CODE-MAINTAIN   VALUE 'M'.
013578*        88  WS-ENTER-CODE-DELETE     VALUE 'D'.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-VALID         VALUE '0960' '0961'
013578                                     '0962' '0963' '0964'.
013578         88  WS-BUS-FCN-RETRIEVE      VALUE '0960'.
013578         88  WS-BUS-FCN-CREATE        VALUE '0961'.
013578         88  WS-BUS-FCN-UPDATE        VALUE '0962'.
013578         88  WS-BUS-FCN-DELETE        VALUE '0963'.
013578         88  WS-BUS-FCN-LIST          VALUE '0964'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '0960'.
           05  WS-EDIT-ERROR-SW             PIC X(01).
               88  WS-EDIT-ERRORS           VALUE 'Y'.
               88  WS-NO-EDIT-ERRORS        VALUE 'N'.
025970*    05  WS-NO-DISPLAY-LINES          PIC S9(3)  COMP-3
025970*                                                VALUE +12.
           05  WS-LINES                     PIC S9(3)  COMP-3.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '0960'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '0960'.
025970     05  WS-NO-DISPLAY-LINES          PIC S9(3)  COMP-3
025970                                                 VALUE +12.
025970         88  WS-NO-DISPLAY-LINES-DEFAULT         VALUE +12.
025970
014588*COPY CCWCCOMM.
014588*COPY CCWC4500.
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
       COPY CCFWPTAB.
       COPY CCFRPTAB.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
014221 COPY XCWL8090.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM4500.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      **********************
       2000-PROCESS-REQUEST.
      **********************
      *
      * NORMAL PROCESSING: CHECK SECURITY PERMISSION & DISTRIBUTE
      * CONTROL TO APPROPRIATE PROCESSING ROUTINE
      *

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.

      * CHECK ENTER CODE FOR FUNCTION REQUESTED

013578     IF  WS-BUS-FCN-RETRIEVE
013578         PERFORM  3000-PROCESS-RETRIEVE
013578             THRU 3000-PROCESS-RETRIEVE-X
013578         GO TO 2000-PROCESS-REQUEST-X
013578     END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  3500-PROCESS-LIST
                   THRU 3500-PROCESS-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  5000-MAINTENANCE
                   THRU 5000-MAINTENANCE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-DELETE
               PERFORM  6000-PROCESS-DELETE
                   THRU 6000-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.

      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************
      *
      *   BUILD CONTROL FIELDS.
      *
           MOVE MIR-POL-ACTV-TYP-ID   TO WPTAB-POL-ACTV-TYP-ID.
      *
      *   CHECK IF RECORD EXISTS.
      *
014221*    PERFORM  PTAB-1000-READ
014221*        THRU PTAB-1000-READ-X.

014221     PERFORM  PTAB-1000-READ-TWRK-TS
014221         THRU PTAB-1000-READ-TWRK-TS-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  WPTAB-IO-NOT-FOUND
      *MSG: 'ACTIVITY @1 NOT FOUND (S)'
               MOVE 'CS45000002'      TO WGLOB-MSG-REF-INFO
               MOVE WPTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE +1                TO WS-LINES
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE 'XS00000016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
      *
      * SAVE CURRENT ENTER CODE TO SET UP ATTRIBUTES CORRECTLY
      *
014588*        MOVE MIR-ENTER         TO C4500-ENTER-CODE
557660     END-IF.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.

      *******************
       3500-PROCESS-LIST.
      *******************
      *
      * INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE AND
      * LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL
      *
      *  SET UP BROWSE KEY LIMITS
      *
           MOVE MIR-POL-ACTV-TYP-ID   TO WPTAB-POL-ACTV-TYP-ID.
           MOVE HIGH-VALUES           TO WPTAB-ENDBR-KEY.
           MOVE SPACES                TO MIR-POL-ACTV-TYP-ID-G.
           MOVE SPACES                TO MIR-POL-ACTV-PRCES-CD-G.
           MOVE SPACES                TO MIR-ETBL-VALU-ID-G.
           MOVE SPACES                TO MIR-ETBL-DESC-TXT-G.
           MOVE SPACES                TO MIR-POL-ACTV-REDO-CD-G.
      *
      * POSITION AT AND READ FIRST RECORD
      *
           PERFORM  PTAB-1000-BROWSE
               THRU PTAB-1000-BROWSE-X.

           IF  WPTAB-IO-OK
               PERFORM  PTAB-2000-READ-NEXT
                   THRU PTAB-2000-READ-NEXT-X
           ELSE
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WPTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
                   VARYING WS-LINES FROM 1 BY 1
                   UNTIL WS-LINES > WS-NO-DISPLAY-LINES
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.
      *
      * LOAD SCREEN DATA ARRAY
      *
           IF  WPTAB-IO-OK
               MOVE 1                TO WS-LINES
557660         PERFORM  3600-DISPLAY-RECORD
557660             THRU 3600-DISPLAY-RECORD-X
                   UNTIL (WS-LINES >  WS-NO-DISPLAY-LINES)
                      OR (WPTAB-IO-EOF)
      *
      * COMPLETION MESSAGE
      *
               IF  WPTAB-IO-EOF
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE RPTAB-POL-ACTV-TYP-ID
                                      TO MIR-POL-ACTV-TYP-ID
               END-IF
           ELSE
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PTAB-3000-END-BROWSE
               THRU PTAB-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.

      *********************
557660 3600-DISPLAY-RECORD.
      *********************
      *
      * INQUIRY DISPLAY PROCESSING:INPUT: WS-LINES
      * DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE GIVEN
      * BY WS-LINES AND RETRIEVE THE NEXT RECORD
      *

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PTAB-2000-READ-NEXT
               THRU PTAB-2000-READ-NEXT-X.

557660 3600-DISPLAY-RECORD-X.
           EXIT.

      *********************
       4000-PROCESS-CREATE.
      *********************
      *
      * CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, INIT NEW
      * RECORD AND ALLOW USER TO MODIFY
      *
      * VALIDATE CONTROL FIELDS
      *
           PERFORM  7000-VALIDATE-PTAB-KEY
               THRU 7000-VALIDATE-PTAB-KEY-X.
           IF  WGLOB-MSG-SEVRTY-FATAL
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      *   BUILD CONTROL FIELDS.
      *
           MOVE MIR-POL-ACTV-TYP-ID   TO WPTAB-POL-ACTV-TYP-ID.
      *
      *   CHECK IF RECORD EXISTS.
      *
           PERFORM  PTAB-1000-READ
               THRU PTAB-1000-READ-X.

           IF  WPTAB-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WPTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      *   CREATE NEW RECORD
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
           PERFORM  PTAB-1000-CREATE
               THRU PTAB-1000-CREATE-X.
           PERFORM  PTAB-1000-WRITE
               THRU PTAB-1000-WRITE-X.

014221     PERFORM  PTAB-1000-READ-TWRK-TS
014221         THRU PTAB-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE +1                    TO WS-LINES.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
      * SAVE CURRENT ENTER CODE TO SET UP ATTRIBUTES CORRECTLY
      *
014588*    MOVE MIR-ENTER             TO C4500-ENTER-CODE.

       4000-PROCESS-CREATE-X.
           EXIT.

      ******************
       5000-MAINTENANCE.
      ******************

           PERFORM  5200-PROCESS-UPDATE
               THRU 5200-PROCESS-UPDATE-X.

       5000-MAINTENANCE-X.
           EXIT.

      *********************
       5200-PROCESS-UPDATE.
      *********************
      *
      * MAINTAIN PROCESSING: GET RECORD, EDIT DATA FIELDS, AND
      * UPDATE IF EDIT ERRORS, ELSE UNLOCK
      *
      * BUILD CONTROL FIELDS
      *
           MOVE MIR-POL-ACTV-TYP-ID   TO WPTAB-POL-ACTV-TYP-ID.
      *
      * READ RECORD FOR UPDATE
      *
014221*    PERFORM  PTAB-1000-READ-FOR-UPDATE
014221*        THRU PTAB-1000-READ-FOR-UPDATE-X.
014221     PERFORM  PTAB-2000-UPDATE-TWRK-TS
014221         THRU PTAB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PTAB'             TO WGLOB-MSG-PARM (01)
014221         MOVE WPTAB-KEY          TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5200-PROCESS-UPDATE-X
014221     END-IF.

           IF  WPTAB-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WPTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5200-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  5210-EDIT-DATA-FIELDS
               THRU 5210-EDIT-DATA-FIELDS-X.

           IF  WS-EDIT-ERRORS
               CONTINUE
           ELSE
               PERFORM  5220-CROSS-EDITS
                   THRU 5220-CROSS-EDITS-X
557660     END-IF.

           PERFORM  PTAB-2000-REWRITE
               THRU PTAB-2000-REWRITE-X.

014221     PERFORM  PTAB-1000-READ-TWRK-TS
014221         THRU PTAB-1000-READ-TWRK-TS-X.

           IF  WS-NO-EDIT-ERRORS
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5200-PROCESS-UPDATE-X.
           EXIT.

      ***********************
       5210-EDIT-DATA-FIELDS.
      ***********************

           MOVE 'N'                   TO WS-EDIT-ERROR-SW.

           PERFORM  5211-EDIT-AUTCD
               THRU 5211-EDIT-AUTCD-X.

           PERFORM  5212-EDIT-REDCD
               THRU 5212-EDIT-REDCD-X.

       5210-EDIT-DATA-FIELDS-X.
           EXIT.

      *****************
       5211-EDIT-AUTCD.
      *****************
      *
      * EDIT AUTO UNDO REDO CODE
      *

           IF  MIR-POL-ACTV-PRCES-CD-T (1) = SPACES
               MOVE RPTAB-POL-ACTV-PRCES-CD
                                      TO MIR-POL-ACTV-PRCES-CD-T (1)
557660     END-IF.

           MOVE MIR-POL-ACTV-PRCES-CD-T (1)
                                      TO WS-AUTO-CD.
           IF  WS-AUTO-CD-VALID
               MOVE MIR-POL-ACTV-PRCES-CD-T (1)
                                      TO RPTAB-POL-ACTV-PRCES-CD
           ELSE
      *MSG: '@1 INVALID AUTO UNDO/REDO CODE (S)'
               MOVE 'CS45000004'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ACTV-PRCES-CD-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-EDIT-ERROR-SW
557660     END-IF.

       5211-EDIT-AUTCD-X.
           EXIT.

      *****************
       5212-EDIT-REDCD.
      *****************
      *
      * EDIT REDO CODE
      *

           IF  MIR-POL-ACTV-REDO-CD-T (1) = SPACES
               MOVE RPTAB-POL-ACTV-REDO-CD
                                      TO MIR-POL-ACTV-REDO-CD-T (1)
557660     END-IF.

           MOVE MIR-POL-ACTV-REDO-CD-T (1)
                                      TO WS-REDO-CD.
           IF  WS-REDO-CD-VALID
               MOVE MIR-POL-ACTV-REDO-CD-T (1)
                                      TO RPTAB-POL-ACTV-REDO-CD
           ELSE
      *MSG: '@1 INVALID REDO CODE (S)'
               MOVE 'CS45000005'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ACTV-REDO-CD-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-EDIT-ERROR-SW
557660     END-IF.

       5212-EDIT-REDCD-X.
           EXIT.

      ******************
       5220-CROSS-EDITS.
      ******************

           IF  (RPTAB-POL-ACTV-REDO-NONSUP-CF OR
                RPTAB-POL-ACTV-REDO-NONSUP-REG)
           AND  RPTAB-POL-ACTV-PRCES-BOTH
      *MSG: 'B NOT ALLOWED; REDO NOT SUPPORTED (S)'
               MOVE 'CS45000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-EDIT-ERROR-SW
557660     END-IF.

           IF  RPTAB-POL-ACTV-REDO-SCHEDULED
           AND RPTAB-POL-ACTV-PRCES-UNDO-ONLY
      *MSG: 'U NOT ALLOWED FOR A SCHEDULED ACTIVITY (S)'
               MOVE 'CS45000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-EDIT-ERROR-SW
557660     END-IF.

       5220-CROSS-EDITS-X.
           EXIT.

      *********************
       6000-PROCESS-DELETE.
      *********************

           PERFORM  6200-PROCESS-DELETE
               THRU 6200-PROCESS-DELETE-X.

       6000-PROCESS-DELETE-X.
           EXIT.

      *********************
       6200-PROCESS-DELETE.
      *********************
      *
      * BUILD CONTROL FIELDS
      *
           MOVE MIR-POL-ACTV-TYP-ID   TO WPTAB-POL-ACTV-TYP-ID.
      *
      * READ RECORD FOR UPDATE
      *
014221*    PERFORM  PTAB-1000-READ-FOR-UPDATE
014221*        THRU PTAB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  PTAB-2000-UPDATE-TWRK-TS
014221         THRU PTAB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PTAB'             TO WGLOB-MSG-PARM (01)
014221         MOVE WPTAB-KEY          TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6200-PROCESS-DELETE-X
014221     END-IF.

           IF  WPTAB-IO-NOT-FOUND
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WPTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  PTAB-1000-DELETE
                   THRU PTAB-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       6200-PROCESS-DELETE-X.
           EXIT.

      ************************
       7000-VALIDATE-PTAB-KEY.
      ************************
      *
      * VALIDATE ACTIVITY NUMBER AGAINST THE MSGM CC2404 MSG-REF-NUM
      *

018763*    MOVE 'CC2400'              TO WGLOB-MSG-REF-ID.
020913*    MOVE 'CC2404'              TO WGLOB-MSG-REF-ID.
020913     MOVE 'CS2404'              TO WGLOB-MSG-REF-ID.
           MOVE MIR-POL-ACTV-TYP-ID   TO WGLOB-MSG-REF-NUM.
           MOVE '@1'                  TO WGLOB-MSG-PARM (1).
           MOVE '@2'                  TO WGLOB-MSG-PARM (2).
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
      *
      * IF THE MESSAGE SEVERITY RETURNED IS FATAL THE
      * CC2404 MESSAGE WITH THE ACTIVITY NUMBER WAS NOT FOUND
      *
           IF  WGLOB-MSG-SEVRTY-FATAL
      *MSG: '@1 ACTIVITY NOT ALLOWED (S)'
               MOVE 'CS45000001'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ACTV-TYP-ID
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       7000-VALIDATE-PTAB-KEY-X.
           EXIT.

      ************************
       9100-BLANK-DATA-FIELDS.
      ************************
      *
      * SET EACH NON-KEY FIELD TO SPACES
      *

           MOVE SPACES                TO MIR-POL-ACTV-TYP-ID-G.
           MOVE SPACES                TO MIR-POL-ACTV-PRCES-CD-G.
           MOVE SPACES                TO MIR-ETBL-VALU-ID-G.
           MOVE SPACES                TO MIR-ETBL-DESC-TXT-G.
           MOVE SPACES                TO MIR-POL-ACTV-REDO-CD-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************

           MOVE RPTAB-POL-ACTV-TYP-ID
             TO MIR-POL-ACTV-TYP-ID-T (WS-LINES).
           MOVE RPTAB-POL-ACTV-PRCES-CD
             TO MIR-POL-ACTV-PRCES-CD-T (WS-LINES).
           MOVE RPTAB-POL-ACTV-TYP-ID TO WEDIT-ETBL-VALU-ID.
           PERFORM  PHST-2000-DESC
               THRU PHST-2000-DESC-X.
           IF  WEDIT-IO-NOT-FOUND
      *MSG: 'ACTIVITY CODE FOR @1 NOT FOUND ON EDIT TYPE PHSTA (I)'
               MOVE 'CS45000008'      TO WGLOB-MSG-REF-INFO
               MOVE RPTAB-POL-ACTV-TYP-ID
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO MIR-ETBL-VALU-ID-T (WS-LINES)
           ELSE
               MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-ETBL-VALU-ID-T (WS-LINES)
557660     END-IF.

018763*    MOVE 'CC2400'              TO WGLOB-MSG-REF-ID.
020913*    MOVE 'CC2404'              TO WGLOB-MSG-REF-ID.
020913     MOVE 'CS2404'              TO WGLOB-MSG-REF-ID.
           MOVE RPTAB-POL-ACTV-TYP-ID TO WGLOB-MSG-REF-NUM.
           MOVE '@1'                  TO WGLOB-MSG-PARM (1).
           MOVE '@2'                  TO WGLOB-MSG-PARM (2).
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
      *
      * IF THE MESSAGE SEVERITY RETURNED IS FATAL THE
      * CC2404 MESSAGE WITH THE ACTIVITY NUMBER WAS NOT FOUND
      *
           IF  WGLOB-MSG-SEVRTY-FATAL
      *MSG: 'ACTIVITY @1 DESCRIPTION NOT FOUND ON MSGM (I)'
               MOVE 'CS45000003'      TO WGLOB-MSG-REF-INFO
               MOVE RPTAB-POL-ACTV-TYP-ID
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE WGLOB-MSG-TXT     TO MIR-ETBL-DESC-TXT-T (WS-LINES)
557660     END-IF.

           MOVE RPTAB-POL-ACTV-REDO-CD
             TO MIR-POL-ACTV-REDO-CD-T (WS-LINES).

           ADD +1 TO WS-LINES.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************
      *
      * MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      * TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET  WS-NO-DISPLAY-LINES-DEFAULT TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PTAB
014221                         '$VAR2' BY 'PTAB'.
       COPY CCPEPHST.
      *
       COPY XCPPEXIT.
      *
       COPY XCPPINIT.
      *
014660*COPY XCPPMEXT.
      *
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPAPTAB.
       COPY CCPBPTAB.
       COPY CCPCPTAB.
       COPY CCPNPTAB.
       COPY CCPUPTAB.
       COPY CCPXPTAB.
      *
       COPY CCPNEDIT.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4500                     **
      *****************************************************************
