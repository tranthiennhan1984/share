      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7822.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7822                                         **
      **  REMARKS:  THIS MODULE PERFORMS                             **
      **            FINANCIAL ACTIVITY - ACTIVITY LIST               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018839**  6.3       FINANCIAL BALANCES FLOW                          **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020452**  6.4       FOREIGN CONTENT FOR RRSP PRODUCTS                **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
020463**  6.4       INVESTOR PROFILES                                **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
021657**  6.6       CORRECT FIELD NAMES IN MIR COPYBOOKS             **
025970*   6.6       WORKING STORAGE INITIALISATION                   **
025999*   6.6       MESSAGE CORRECTION                               **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
026206**  6.7       FINANCIAL BALANCE ENQUIRY ON ASSEST REBALANCE    **
027315**  6.7       TRANSFER DOESNOT SHOW UP ON POLICY ACTIVITY LIST **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
033899**  7.0       M&E TRANSFER MISSING FROM POLICY ACTIVITY LIST   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7822'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970*01  WS-WORKING-STORAGE.
025970*    05  WS-MAX-LINE                      PIC 999 VALUE 50.
025970
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LINE                      PIC 999.
025970         88 WS-MAX-LINE-DEFAULT           VALUE 50.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-RETRIEVE          VALUE '7822'.
           05  WS-CVG                           PIC 99.
           05  WS-SEQ                           PIC X(20).
           05  FILLER                REDEFINES  WS-SEQ.
               10  WS-SEQ-NUM                   PIC 999.
               10  FILLER                       PIC X(17).
           05  FILLER                        REDEFINES WS-SEQ.
               10  WS-CDSA-NUM               PIC 99999.
               10  FILLER                    PIC X(15).
           05  WS-FA-SEQ-NUM                    PIC 999.
           05  WS-CDA-NUM                    PIC 99999.
           05  WS-SUB                           PIC 999.
           05  WS-CDSD-COUNT                    PIC S99.
           05  WS-WEALTH-ACCUM-IND              PIC X.
               88  WS-WEALTH-ACCUM-YES          VALUE 'Y'.
               88  WS-WEALTH-ACCUM-NO           VALUE 'N'.
           05  WS-COLLATERAL-FUND-IND           PIC X.
               88  WS-COLLATERAL-FUND-YES       VALUE 'Y'.
               88  WS-COLLATERAL-FUND-NO        VALUE 'N'.
           05  WS-SAVE-PHST-DATA.
030054*        10  WS-SAVE-PCHST-EFF-IDT-NUM    PIC X(007).
030054*        10  WS-SAVE-PCHST-SEQ-NUM        PIC 9(003).
030054*        10  WS-SAVE-PCHST-STAT-CD        PIC X(001).
030054*        10  WS-SAVE-POL-ACTV-TYP-ID      PIC X(004).
030054*        10  WS-SAVE-PCHST-EFF-DT         PIC X(010).
020460         10  WS-SAVE-PCHST-PAAFLD-IND     PIC X(001).
020460             88  WS-SAVE-PCHST-PAAFLD-YES VALUE 'Y'.
020460             88  WS-SAVE-PCHST-PAAFLD-NO  VALUE 'N'.
           05  WS-SAVE-UH-EFF-DT                PIC X(010).
           05  WS-SAVE-UH-EFF-DT-R REDEFINES WS-SAVE-UH-EFF-DT.
               10  WS-SAVE-UH-EFF-DT-YR         PIC 9(004).
               10  FILLER                       PIC X(001).
               10  WS-SAVE-UH-EFF-DT-MT         PIC 9(002).
               10  FILLER                       PIC X(001).
               10  WS-SAVE-UH-EFF-DT-DY         PIC 9(002).
           05  WS-SAVE-LAST-LOAN-DT             PIC X(010).
           05  WS-SAVE-EFF-IDT-NUM              PIC X(007).
           05  WS-SAVE-EFF-DT                   PIC X(010).
030054*    05  WS-SAVE-SEQ-NUM                  PIC 9(003).
030054     05  WS-SAVE-SEQ-NUM                  PIC 9(005).
           05  WS-SAVE-CDSA-KEY.
               10  WS-CDSA-CO-ID                PIC X(02).
               10  WS-CDSA-POL-ID               PIC X(10).
023437*        10  WS-CDSA-TYP-CD               PIC X(01).
023437         10  WS-CDSA-TYP-CD               PIC X(02).
               10  WS-CDSA-POL-PAYO-NUM         PIC S9(05)  COMP-3.
               10  WS-CDSA-CDA-EFF-IDT-NUM      PIC X(07).
               10  WS-CDSA-CDA-EFF-IDT-NUM-N    REDEFINES
                   WS-CDSA-CDA-EFF-IDT-NUM      PIC 9(07).
               10  WS-CDSA-CDA-SEQ-NUM          PIC S9(03)  COMP-3.
           05  WS-TOTAL-DR                      PIC S9(13)V99.
           05  WS-TOTAL-CR                      PIC S9(13)V99.
           05  WS-TRANSFER-TOTAL                PIC S9(13)V99.
           05  WS-CLI-TRXN-AMT                  PIC S9(13)V9(02).
           05  WS-OUTPUT-DATA.
               10  WS-TRXN-EFF-DT               PIC X(010).
               10  WS-TRXN-TYP-CD               PIC X(003).
                   88  WS-TRXN-TYP-SDP          VALUE 'SDP'.
                   88  WS-TRXN-TYP-DEP          VALUE 'DEP'.
                   88  WS-TRXN-TYP-IPD          VALUE 'IPD'.
                   88  WS-TRXN-TYP-IPT          VALUE 'IPT'.
                   88  WS-TRXN-TYP-SUR          VALUE 'SUR'.
                   88  WS-TRXN-TYP-PSR          VALUE 'PSR'.
                   88  WS-TRXN-TYP-AFR          VALUE 'AFR'.
                   88  WS-TRXN-TYP-ADM          VALUE 'ADM'.
                   88  WS-TRXN-TYP-CDM          VALUE 'CDM'.
                   88  WS-TRXN-TYP-AMF          VALUE 'AMF'.
                   88  WS-TRXN-TYP-AFO          VALUE 'AFO'.
                   88  WS-TRXN-TYP-TAF          VALUE 'TAF'.
                   88  WS-TRXN-TYP-MTH          VALUE 'MTH'.
                   88  WS-TRXN-TYP-LON          VALUE 'LON'.
                   88  WS-TRXN-TYP-RLN          VALUE 'RLN'.
                   88  WS-TRXN-TYP-CSW          VALUE 'CSW'.
                   88  WS-TRXN-TYP-FLT          VALUE 'FLT'.
                   88  WS-TRXN-TYP-INT          VALUE 'INT'.
                   88  WS-TRXN-TYP-TRF          VALUE 'TRF'.
                   88  WS-TRXN-TYP-SWP          VALUE 'SWP'.
                   88  WS-TRXN-TYP-ASR          VALUE 'ASR'.
                   88  WS-TRXN-TYP-DCA          VALUE 'DCA'.
                   88  WS-TRXN-TYP-MEX          VALUE 'MEX'.
                   88  WS-TRXN-TYP-PUP          VALUE 'PUP'.
023112             88  WS-TRXN-TYP-ROL          VALUE 'ROL'.
               10  WS-TRXN-STAT-CD              PIC X(001).
                   88  WS-TRXN-STAT-ACTIVE      VALUE 'A'.
                   88  WS-TRXN-STAT-REVERSED    VALUE 'R'.
               10  WS-TRXN-GRS-AMT              PIC S9(13)V99.
030054*        10  WS-FIRST-SEQ-NUM             PIC 9(003).
030054         10  WS-FIRST-SEQ-NUM             PIC 9(005).
           05  WS-SKIP-PHST-READ-IND            PIC X(001).
               88  WS-SKIP-PHST-READ-NO         VALUE 'N'.
               88  WS-SKIP-PHST-READ-YES        VALUE 'Y'.
           05  WS-ACT-PHST-REC-IND              PIC X(001).
               88  WS-ACT-PHST-FOUND-NO         VALUE 'N'.
               88  WS-ACT-PHST-FOUND-YES        VALUE 'Y'.
           05  WS-UH-REC-IND                    PIC X(001).
               88  WS-UH-REC-FOUND-NO           VALUE 'N'.
               88  WS-UH-REC-FOUND-YES          VALUE 'Y'.
               88  WS-UH-REC-NO-MORE            VALUE 'E'.
           05  WS-GROUP-END-IND                 PIC X.
               88  WS-GROUP-END-YES             VALUE 'Y'.
               88  WS-GROUP-END-NO              VALUE 'N'.
           05  WS-PROCESS-END-IND               PIC X(001).
               88  WS-PROCESS-END-NO            VALUE 'N'.
               88  WS-PROCESS-END-YES           VALUE 'Y'.
           05  WS-CDSA-REC-IND                  PIC X(01).
               88  WS-CDSA-REC-FOUND            VALUE 'Y'.
               88  WS-CDSA-REC-NOT-FOUND        VALUE 'N'.

           05  WS-ACTIVITY-TYPE-ID              PIC X(4).
               88  WS-ACTIVITY-TYPE-VALID VALUE '4009' '4012' '4013'
                                                '5000' '5022' '4001'
                                                '4003' '4005'
                                                '5005' '5006' '5008'
                                                '4007' '4008' '4014'
                                                '5002' '5003' '5004'
                                                '4019' '5019' '5021'
                                                '4006' '4011' '4017'
                                                '4021' '5001' '5007'
020463*                                         '5009' '5100' '5010'
033899*                                         '7030' '5100' '5010'
033899                                          '7030' '5100' '5011'
023436                                          '7020' '4002'
027315                                          '7029'
031036*                                         '4018' '4022'.
031036                                          '4018' '4022' '7061'
031036                                          '7062' '7063' '7064'.
               88  WS-ACTIVITY-TYPE-DEP   VALUE '4009' '4012' '4013'
031036*                                         '5000'.
031036                                          '5000' '7061' '7062'.
               88  WS-ACTIVITY-TYPE-WTH   VALUE '4001' '4003' '4005'
                                                '4022' '5005' '5006'
031036*                                         '5022'.
031036                                          '5022' '7063' '7064'.
               88  WS-ACTIVITY-TYPE-ADMIN VALUE '4007' '4008' '4014'
                                                '5002' '5003' '5004'
                                                '5100'.
023436*        88  WS-ACTIVITY-TYPE-LOANS VALUE '4019' '5019'.
023436         88  WS-ACTIVITY-TYPE-LOANS VALUE '4019' '5019' '7020'.
               88  WS-ACTIVITY-TYPE-TRXNS VALUE '4006' '4011' '4017'
                                                '4021' '5001' '5007'
033899*                                         '5010' '5021' '4002'.
033899                                          '5011' '5021' '4002'.
023436*                                         '5010' '5021'.
027315         88  WS-ACTIVITY-TYPE-INTR  VALUE '7029'.
020463*        88  WS-ACTIVITY-TYPE-AR    VALUE '5009'.
020463         88  WS-ACTIVITY-TYPE-AR    VALUE '7030'.
               88  WS-ACTIVITY-TYPE-DCA   VALUE '4018' '5008'.
               88  WS-ACTIVITY-TYPE-REVRS VALUE '4001' '4002' '4003'
                                                '4006' '4007' '4008'
                                                '4011' '4012' '4013'
                                                '4014' '4015' '4017'
                                                '4018' '5002' '5003'
                                                '5004' '5005' '5006'
033899*                                         '5007' '5010' '5100'
033899                                          '5007' '5011' '5100'
031036*                                         '5022' '4022'.
031036                                          '5022' '4022' '7061'
031036                                          '7062' '7063' '7064'.
020460     05  WS-PRCES-PHST-SW                 PIC X(01).
020460         88  WS-PRCES-PHST                VALUE 'Y'.
020460         88  WS-PRCES-PHST-NO             VALUE 'N'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
       COPY CCWWINDX.
       COPY CCWWLOCK.
030054 COPY XCWWCNST.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY SCFWFA.
       COPY SCFRFA.
       COPY SCFWFD.
       COPY SCFRFD.
       COPY CCFWCFLW.
       COPY CCFRCFLW.
       COPY CCFWCDSA.
       COPY CCFRCDSA.
021930*COPY CCFWCDSD.
021930*COPY CCFRCDSD.
       COPY CCFWPHST.
       COPY CCFRPHST.
030054 COPY CCFHPHST.
020460 COPY CCFWPAAS.
020460 COPY CCFRPAAR.
       COPY CCFWLHST.
       COPY CCFRLHST.
       COPY CCFWUH.
       COPY CCFRUH.
       COPY CCFWUHCO.
       COPY CCFRUHCO.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7822.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    INITIALIZE                   WS-WORK-AREA.
025970*    MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
           SET  MIR-RETRN-OK         TO TRUE.
           MOVE SPACES               TO MIR-OUTPUT-AREA.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7822'     TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-RETRIEVE.
      *--------------

           MOVE MIR-POL-ID             TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WPOL-KEY    TO WGLOB-MSG-PARM (1)
               MOVE 'POL'       TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           SET WS-WEALTH-ACCUM-NO       TO TRUE.
           SET WS-COLLATERAL-FUND-NO    TO TRUE.

           PERFORM  2010-INS-TYPE-CHECK
               THRU 2010-INS-TYPE-CHECK-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > RPOL-POL-CVG-REC-CTR-N.

           IF WS-WEALTH-ACCUM-NO
      * MSG: FINANCIAL ACTIVITY IS NOT AVAILABLE FOR THIS TYPE OF POLICY
               MOVE 'CS78220002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-RETRIEVE-X
           END-IF.

021657*    MOVE MIR-DV-START-DT           TO L1640-EXTERNAL-DATE.
021657     MOVE MIR-DV-STRT-DT            TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
026057     IF  L1640-NOT-VALID
026057*MSG:    'DATE @1 INVALID'
026057         MOVE 'CS78220003'      TO WGLOB-MSG-REF-INFO
026057         MOVE MIR-DV-STRT-DT    TO WGLOB-MSG-PARM (1)
026057         PERFORM  0260-1000-GENERATE-MESSAGE
026057             THRU 0260-1000-GENERATE-MESSAGE-X
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 2000-RETRIEVE-X
026057     END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE L1640-INTERNAL-DATE   TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 2000-RETRIEVE-X
026057     END-IF.

           MOVE L1640-INTERNAL-DATE       TO L1660-INTERNAL-DATE.
           MOVE L1640-INTERNAL-DATE       TO WS-SAVE-EFF-DT.

           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE       TO WS-SAVE-EFF-IDT-NUM.

021657*    MOVE MIR-DV-START-SEQ-NUM      TO L0280-INPUT-DATA.
021657     MOVE MIR-DV-STRT-SEQ-NUM       TO L0280-INPUT-DATA.
021657*    MOVE LENGTH OF MIR-DV-START-SEQ-NUM TO L0280-INPUT-SIZE.
021657     MOVE LENGTH OF MIR-DV-STRT-SEQ-NUM TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE          TO L0280-LENGTH.
           MOVE ZERO                      TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT              TO WS-SAVE-SEQ-NUM.


           PERFORM  3000-POL-ACTIVITY-LIST
               THRU 3000-POL-ACTIVITY-LIST-X.

       2000-RETRIEVE-X.
           EXIT.


      *--------------------
       2010-INS-TYPE-CHECK.
      *--------------------

           IF  WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-SUB)
           OR  WCVGS-CVG-INS-TYP-SEG-FUND    (WS-SUB)
           OR  WCVGS-CVG-INS-TYP-FPA         (WS-SUB)
               SET WS-WEALTH-ACCUM-YES         TO TRUE
           END-IF.

           IF  WCVGS-CVG-COLFND (WS-SUB)
               SET WS-COLLATERAL-FUND-YES      TO TRUE
           END-IF.

       2010-INS-TYPE-CHECK-X.
           EXIT.

      /
      *-----------------------
       3000-POL-ACTIVITY-LIST.
      *-----------------------

           MOVE SPACES                  TO WS-SAVE-LAST-LOAN-DT.
           SET WS-SKIP-PHST-READ-NO     TO TRUE.
      *
      * GET FIRST UH
      *
           MOVE WS-SAVE-EFF-DT          TO WS-SAVE-UH-EFF-DT.
           MOVE RPOL-POL-ISS-EFF-DT-DY  TO WS-SAVE-UH-EFF-DT-DY.

           IF  WS-SAVE-UH-EFF-DT > WS-SAVE-EFF-DT
               PERFORM  3110-SET-NEXT-UH-DATE
                   THRU 3110-SET-NEXT-UH-DATE-X
           END-IF.

           SET  WS-UH-REC-FOUND-NO      TO TRUE.
           PERFORM  3100-GET-NEXT-UH-REC
               THRU 3100-GET-NEXT-UH-REC-X
               UNTIL WS-UH-REC-FOUND-YES
               OR   WS-UH-REC-NO-MORE.

      *
      * GET FIRST ADM PHST
      *
           MOVE RPOL-POL-ID         TO WPHST-POL-ID.
           MOVE WPHST-KEY           TO WPHST-ENDBR-KEY.
           MOVE WS-SAVE-EFF-IDT-NUM TO WPHST-PCHST-EFF-IDT-NUM.
           MOVE WS-SAVE-SEQ-NUM     TO WPHST-PCHST-SEQ-NUM.
           MOVE HIGH-VALUES         TO WPHST-ENDBR-PCHST-EFF-IDT-NUM.
030054*    MOVE +999                TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                              TO WPHST-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-BROWSE
               THRU PHST-1000-BROWSE-X.

           SET WS-ACT-PHST-FOUND-NO TO TRUE.
           PERFORM  3200-READ-ACT-PHST
               THRU 3200-READ-ACT-PHST-X
               UNTIL WS-ACT-PHST-FOUND-YES
                  OR WPHST-IO-EOF.


           IF  WS-ACT-PHST-FOUND-NO
           AND WS-UH-REC-NO-MORE
      * MSG: NO FINANCIAL ACTIVITY TO DISPLAY
               MOVE 'CS78220001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PHST-3000-END-BROWSE
                   THRU PHST-3000-END-BROWSE-X
               GO TO 3000-POL-ACTIVITY-LIST-X
           END-IF.


           MOVE 1                  TO WS-SUB.
           SET WS-PROCESS-END-NO   TO TRUE.
           PERFORM  3300-ACTIVITY-LOOP
               THRU 3300-ACTIVITY-LOOP-X
               UNTIL  WS-SUB > WS-MAX-LINE
               OR     WS-PROCESS-END-YES.


           IF WS-PROCESS-END-YES
      * MSG: ** END OF LIST **
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
           ELSE
      * MSG: INQUIRE COMPLETE - CONTINUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE

               PERFORM  3010-SET-MORE-KEY
                   THRU 3010-SET-MORE-KEY-X
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  PHST-3000-END-BROWSE
               THRU PHST-3000-END-BROWSE-X.

       3000-POL-ACTIVITY-LIST-X.
           EXIT.


      *-----------------
       3010-SET-MORE-KEY.
      *-----------------


030054*    IF  WS-SAVE-UH-EFF-DT NOT < WS-SAVE-PCHST-EFF-DT
030054     IF  WS-SAVE-UH-EFF-DT NOT < HPHST-PCHST-EFF-DT
               MOVE WS-SAVE-UH-EFF-DT     TO WS-SAVE-EFF-DT
               MOVE ZERO                  TO WS-SAVE-SEQ-NUM
           ELSE
030054*        MOVE WS-SAVE-PCHST-EFF-DT  TO WS-SAVE-EFF-DT
030054*        MOVE WS-SAVE-PCHST-SEQ-NUM TO WS-SAVE-SEQ-NUM
030054         MOVE HPHST-PCHST-EFF-DT    TO WS-SAVE-EFF-DT
030054         MOVE HPHST-PCHST-SEQ-NUM   TO WS-SAVE-SEQ-NUM
           END-IF.

           MOVE WS-SAVE-EFF-DT            TO  L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
021657*    MOVE L1640-EXTERNAL-DATE       TO  MIR-DV-START-DT.
021657     MOVE L1640-EXTERNAL-DATE       TO  MIR-DV-STRT-DT.

020874*    MOVE WS-SAVE-SEQ-NUM           TO L0290-INPUT-NUMBER.
020874     MOVE WS-SAVE-SEQ-NUM           TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION.
021657*    MOVE LENGTH OF MIR-DV-START-SEQ-NUM
021657     MOVE LENGTH OF MIR-DV-STRT-SEQ-NUM
                                          TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS  TO TRUE.
           SET L0290-SIGN-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
021657*    MOVE L0290-OUTPUT-DATA         TO  MIR-DV-START-SEQ-NUM.
021657     MOVE L0290-OUTPUT-DATA         TO  MIR-DV-STRT-SEQ-NUM.

       3010-SET-MORE-KEY-X.
           EXIT.


      *---------------------
       3100-GET-NEXT-UH-REC.
      *---------------------

           IF  WS-SAVE-UH-EFF-DT < RPOL-POL-ISS-EFF-DT
               SET WS-UH-REC-NO-MORE    TO TRUE
               MOVE SPACES              TO WS-SAVE-UH-EFF-DT
               GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           MOVE RPOL-POL-ID              TO WUH-POL-ID.
           MOVE WS-SAVE-UH-EFF-DT       TO WUH-MTHV-EFF-DT-NUM.
           MOVE ZERO                    TO WUH-MTHV-EFF-DT-NUM-DY.

           PERFORM  UH-1000-READ
               THRU UH-1000-READ-X.

           IF NOT WUH-IO-OK
              PERFORM  3110-SET-NEXT-UH-DATE
                  THRU 3110-SET-NEXT-UH-DATE-X
              GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           IF  RUH-POL-TOT-DED-AMT < ZERO
               PERFORM  3110-SET-NEXT-UH-DATE
                   THRU 3110-SET-NEXT-UH-DATE-X
               GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           SET WS-UH-REC-FOUND-YES      TO TRUE.

       3100-GET-NEXT-UH-REC-X.
           EXIT.


      *---------------------
       3110-SET-NEXT-UH-DATE.
      *---------------------

           SUBTRACT 1            FROM WS-SAVE-UH-EFF-DT-MT.

           IF  WS-SAVE-UH-EFF-DT-MT = 0
               MOVE 12             TO WS-SAVE-UH-EFF-DT-MT
               SUBTRACT 1        FROM WS-SAVE-UH-EFF-DT-YR
           END-IF.

       3110-SET-NEXT-UH-DATE-X.
           EXIT.


      *-------------------
       3200-READ-ACT-PHST.
      *-------------------

           IF  WS-SKIP-PHST-READ-YES
               SET WS-SKIP-PHST-READ-NO    TO TRUE
           ELSE
               PERFORM  PHST-2000-READ-NEXT
                   THRU PHST-2000-READ-NEXT-X
           END-IF.

           IF WPHST-IO-EOF
030054*       MOVE SPACES              TO WS-SAVE-PCHST-EFF-DT
030054        MOVE SPACES              TO HPHST-PCHST-EFF-DT
              GO TO 3200-READ-ACT-PHST-X
           END-IF.

           IF RPHST-PCHST-STAT-ACTIVE
           OR RPHST-PCHST-STAT-REVERSED
               CONTINUE
           ELSE
               GO TO 3200-READ-ACT-PHST-X
           END-IF.

           MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTIVITY-TYPE-ID.
           IF NOT WS-ACTIVITY-TYPE-VALID
               GO TO 3200-READ-ACT-PHST-X
           END-IF.

           IF  WS-ACTIVITY-TYPE-LOANS
           AND WS-COLLATERAL-FUND-NO
               GO TO 3200-READ-ACT-PHST-X
           END-IF.

           IF  WS-ACTIVITY-TYPE-LOANS
           AND RPHST-PCHST-EFF-DT = WS-SAVE-LAST-LOAN-DT
               GO TO 3200-READ-ACT-PHST-X
           END-IF.

           SET WS-ACT-PHST-FOUND-YES    TO TRUE.
030054*    MOVE RPHST-PCHST-EFF-IDT-NUM TO WS-SAVE-PCHST-EFF-IDT-NUM.
030054*    MOVE RPHST-PCHST-SEQ-NUM     TO WS-SAVE-PCHST-SEQ-NUM.
030054*    MOVE RPHST-PCHST-EFF-DT      TO WS-SAVE-PCHST-EFF-DT.
030054*    MOVE RPHST-PCHST-STAT-CD     TO WS-SAVE-PCHST-STAT-CD.
030054     MOVE RPHST-PCHST-EFF-IDT-NUM TO HPHST-PCHST-EFF-IDT-NUM.
030054     MOVE RPHST-PCHST-SEQ-NUM     TO HPHST-PCHST-SEQ-NUM.
030054     MOVE RPHST-PCHST-EFF-DT      TO HPHST-PCHST-EFF-DT.
030054     MOVE RPHST-PCHST-STAT-CD     TO HPHST-PCHST-STAT-CD.
030054*    MOVE RPHST-POL-ACTV-TYP-ID   TO WS-SAVE-POL-ACTV-TYP-ID.
030054     MOVE RPHST-POL-ACTV-TYP-ID   TO HPHST-POL-ACTV-TYP-ID.

020460     SET WS-SAVE-PCHST-PAAFLD-NO TO TRUE.
020460
020460     MOVE RPHST-POL-ID           TO WPAAS-POL-ID.
020460     MOVE WWKDT-LOW-TS           TO WPAAS-PAAFLD-GR-TS.
030054*    MOVE WS-SAVE-PCHST-EFF-IDT-NUM
030054     MOVE HPHST-PCHST-EFF-IDT-NUM
020460                                 TO WPAAS-PCHST-EFF-IDT-NUM.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM  TO WPAAS-PCHST-SEQ-NUM.
030054     MOVE HPHST-PCHST-SEQ-NUM    TO WPAAS-PCHST-SEQ-NUM.
020460
020460     MOVE WPAAS-KEY              TO WPAAS-ENDBR-KEY.
020460     MOVE WWKDT-HIGH-TS          TO WPAAS-ENDBR-PAAFLD-GR-TS
020460
020460     PERFORM  PAAS-1000-BROWSE
020460         THRU PAAS-1000-BROWSE-X.
020460
020460     PERFORM  PAAS-2000-READ-NEXT
020460         THRU PAAS-2000-READ-NEXT-X.
020460
020460     IF  WPAAS-IO-OK
020460         SET WS-SAVE-PCHST-PAAFLD-YES  TO TRUE
020460     END-IF.
020460
020460     PERFORM  PAAS-3000-END-BROWSE
020460         THRU PAAS-3000-END-BROWSE-X.

       3200-READ-ACT-PHST-X.
           EXIT.


      *------------------
       3300-ACTIVITY-LOOP.
      *------------------

020460     SET WS-PRCES-PHST-NO             TO TRUE.

           EVALUATE TRUE

030054*        WHEN WS-SAVE-UH-EFF-DT NOT < WS-SAVE-PCHST-EFF-DT
030054         WHEN WS-SAVE-UH-EFF-DT NOT < HPHST-PCHST-EFF-DT
                    PERFORM  3800-PROCESS-UH
                        THRU 3800-PROCESS-UH-X

030054*        WHEN WS-SAVE-PCHST-EFF-DT > SPACE
030054         WHEN HPHST-PCHST-EFF-DT > SPACE
020460              SET WS-PRCES-PHST         TO TRUE
                    PERFORM  3400-PROCESS-PHST
                        THRU 3400-PROCESS-PHST-X

           END-EVALUATE.

           IF  WS-SAVE-UH-EFF-DT = SPACES
030054*    AND WS-SAVE-PCHST-EFF-DT = SPACES
030054     AND HPHST-PCHST-EFF-DT = SPACES
               SET WS-PROCESS-END-YES   TO TRUE
           END-IF.

       3300-ACTIVITY-LOOP-X.
           EXIT.


      *------------------
       3400-PROCESS-PHST.
      *------------------

030054*    MOVE WS-SAVE-POL-ACTV-TYP-ID TO WS-ACTIVITY-TYPE-ID.
030054     MOVE HPHST-POL-ACTV-TYP-ID   TO WS-ACTIVITY-TYPE-ID.

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
               WHEN WS-ACTIVITY-TYPE-WTH
                    PERFORM  4000-PROCESS-DEP-WTH
                        THRU 4000-PROCESS-DEP-WTH-X

               WHEN WS-ACTIVITY-TYPE-ADMIN
                    PERFORM  4200-PROCESS-ADMIN
                        THRU 4200-PROCESS-ADMIN-X

               WHEN WS-ACTIVITY-TYPE-LOANS
                    PERFORM  4400-PROCESS-LOANS
                        THRU 4400-PROCESS-LOANS-X

               WHEN WS-ACTIVITY-TYPE-TRXNS
                    PERFORM  4600-PROCESS-TRANSFER
                        THRU 4600-PROCESS-TRANSFER-X


               WHEN WS-ACTIVITY-TYPE-AR
                    PERFORM  4800-PROCESS-AR
                        THRU 4800-PROCESS-AR-X

               WHEN WS-ACTIVITY-TYPE-DCA
                    PERFORM  4900-PROCESS-DCA
                        THRU 4900-PROCESS-DCA-X

027315         WHEN WS-ACTIVITY-TYPE-INTR
027315              PERFORM  5000-PROCESS-INTR
027315                  THRU 5000-PROCESS-INTR-X

           END-EVALUATE.


           SET WS-ACT-PHST-FOUND-NO TO TRUE.
           PERFORM  3200-READ-ACT-PHST
               THRU 3200-READ-ACT-PHST-X
               UNTIL WS-ACT-PHST-FOUND-YES
                  OR WPHST-IO-EOF.

       3400-PROCESS-PHST-X.
           EXIT.

      *----------------
       3800-PROCESS-UH.
      *----------------

           SET  WS-TRXN-STAT-ACTIVE    TO TRUE.
           PERFORM  3810-CHECK-UH-STATUS
               THRU 3810-CHECK-UH-STATUS-X.

           MOVE WS-SAVE-UH-EFF-DT      TO WS-TRXN-EFF-DT.
           MOVE RUH-POL-TOT-DED-AMT    TO WS-TRXN-GRS-AMT.
           SET  WS-TRXN-TYP-MTH        TO TRUE
           MOVE ZERO                   TO WS-FIRST-SEQ-NUM.

           PERFORM  9100-MOVE-TO-MIR
               THRU 9100-MOVE-TO-MIR-X.

           PERFORM  3110-SET-NEXT-UH-DATE
               THRU 3110-SET-NEXT-UH-DATE-X.

           IF  WS-SAVE-UH-EFF-DT < RPOL-POL-ISS-EFF-DT
               SET WS-UH-REC-NO-MORE    TO TRUE
               MOVE SPACES              TO WS-SAVE-UH-EFF-DT
               GO TO 3800-PROCESS-UH-X
           END-IF.

           SET  WS-UH-REC-FOUND-NO      TO TRUE.
           PERFORM  3100-GET-NEXT-UH-REC
               THRU 3100-GET-NEXT-UH-REC-X
               UNTIL WS-UH-REC-FOUND-YES
               OR   WS-UH-REC-NO-MORE.

       3800-PROCESS-UH-X.
           EXIT.

      *---------------------
       3810-CHECK-UH-STATUS.
      *---------------------

           MOVE RUH-KEY                 TO WUHCO-KEY.
           MOVE WUHCO-KEY               TO WUHCO-ENDBR-KEY.
           MOVE LOW-VALUE               TO WUHCO-CVG-NUM.
           MOVE HIGH-VALUE              TO WUHCO-ENDBR-CVG-NUM.

           PERFORM  UHCO-1000-BROWSE
               THRU UHCO-1000-BROWSE-X.

           PERFORM  UHCO-2000-READ-NEXT
               THRU UHCO-2000-READ-NEXT-X.

           IF WUHCO-IO-EOF
              SET WS-TRXN-STAT-REVERSED  TO TRUE
           END-IF.

           PERFORM  UHCO-3000-END-BROWSE
               THRU UHCO-3000-END-BROWSE-X.

       3810-CHECK-UH-STATUS-X.
           EXIT.

      *---------------------
       4000-PROCESS-DEP-WTH.
      *---------------------

           MOVE RPHST-CVG-NUM                TO WS-CVG.
           SET WS-CDSA-REC-NOT-FOUND         TO TRUE.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  4020-DEP-WTH-FA
                        THRU 4020-DEP-WTH-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  4050-DEP-WTH-CFLW
                        THRU 4050-DEP-WTH-CFLW-X

           END-EVALUATE.

           IF  WS-CDSA-REC-NOT-FOUND
               GO TO 4000-PROCESS-DEP-WTH-X
           END-IF.

           IF  RCDSA-KEY NOT = WS-SAVE-CDSA-KEY
               MOVE RCDSA-CDA-EFF-DT         TO WS-TRXN-EFF-DT
               MOVE RCDSA-CDA-TOT-TRXN-AMT   TO WS-TRXN-GRS-AMT
               PERFORM  4090-DEP-WTH-TO-MIR
                   THRU 4090-DEP-WTH-TO-MIR-X
               MOVE RCDSA-KEY                TO WS-SAVE-CDSA-KEY
           END-IF.

       4000-PROCESS-DEP-WTH-X.
           EXIT.

      *----------------
       4020-DEP-WTH-FA.
      *----------------

           MOVE RPHST-POL-ID             TO WFA-POL-ID.
           MOVE RPHST-CVG-NUM            TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.

           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF NOT WFA-IO-OK
               GO TO 4020-DEP-WTH-FA-X
           END-IF.

           MOVE RPHST-POL-ID            TO WCDSA-POL-ID.

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    IF  WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
                        SET WCDSA-CDA-TYP-SIDFND TO TRUE
                    ELSE
                        SET WCDSA-CDA-TYP-DPOS   TO TRUE
                    END-IF

               WHEN WS-ACTIVITY-TYPE-WTH
                    SET  WCDSA-CDA-TYP-WTHDR     TO TRUE

           END-EVALUATE.

           MOVE RFA-POL-PAYO-NUM        TO WCDSA-POL-PAYO-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE RFA-CDA-SEQ-NUM         TO WCDSA-CDA-SEQ-NUM.

           IF  WCDSA-KEY = WS-SAVE-CDSA-KEY
               SET WS-CDSA-REC-FOUND    TO TRUE
               GO TO 4020-DEP-WTH-FA-X
           END-IF.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.

           IF  NOT WCDSA-IO-OK
               PERFORM  4025-FA-TO-MIR
                   THRU 4025-FA-TO-MIR-X
               GO TO 4020-DEP-WTH-FA-X
           END-IF.

           SET WS-CDSA-REC-FOUND        TO TRUE.

       4020-DEP-WTH-FA-X.
           EXIT.

      *---------------
       4025-FA-TO-MIR.
      *---------------

           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE RFA-FRST-FIA-FND-ID    TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           MOVE ZERO                   TO WS-CLI-TRXN-AMT.

           PERFORM  4026-READ-FD
               THRU 4026-READ-FD-X
               UNTIL WFD-FND-ID = SPACE.

           MOVE RFA-CIA-EFF-DT         TO WS-TRXN-EFF-DT.
           MOVE WS-CLI-TRXN-AMT        TO WS-TRXN-GRS-AMT.

           PERFORM  4090-DEP-WTH-TO-MIR
               THRU 4090-DEP-WTH-TO-MIR-X.

       4025-FA-TO-MIR-X.
           EXIT.

      *-------------
       4026-READ-FD.
      *-------------

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF  NOT WFD-IO-OK
               MOVE SPACES             TO WFD-FND-ID
               GO TO 4026-READ-FD-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    COMPUTE WS-CLI-TRXN-AMT = WS-CLI-TRXN-AMT
020469*                                     + RFD-FIA-FND-TRXN-AMT
020469*                                     + RFD-FIA-LOAD-AMT
020469                                      + RFD-FIA-ORIG-TRXN-AMT
020469                                      + RFD-FIA-ORIG-LOAD-AMT

               WHEN WS-ACTIVITY-TYPE-WTH
                    IF  RFA-CIA-REVRS-PRCES-DT = WWKDT-ZERO-DT
                        COMPUTE WS-CLI-TRXN-AMT = WS-CLI-TRXN-AMT
020469*                                         + RFD-FIA-FND-TRXN-AMT
020469                                          + RFD-FIA-ORIG-TRXN-AMT
                    ELSE
                        MOVE ZERO      TO WS-CLI-TRXN-AMT
                    END-IF

           END-EVALUATE.

           MOVE RFD-NXT-FIA-FND-ID     TO WFD-FND-ID.

       4026-READ-FD-X.
           EXIT.
      *
      *-----------------
       4050-DEP-WTH-CFLW.
      *-----------------

           MOVE RPHST-POL-ID                 TO WCFLW-POL-ID.
           MOVE RPHST-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT TO WS-SEQ
           END-IF.

           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF NOT WCFLW-IO-OK
               GO TO 4050-DEP-WTH-CFLW-X
           END-IF.

023437*    IF  WS-ACTIVITY-TYPE-WTH
023437*    AND RCFLW-CF-SEQ-NUM-N > 1
023437*    AND RCFLW-CF-TYP-OMNM
023437*        GO TO 4050-DEP-WTH-CFLW-X
023437*    END-IF.


           MOVE RPHST-POL-ID             TO WCDSA-POL-ID.

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    IF  WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
                        SET WCDSA-CDA-TYP-SIDFND TO TRUE
                    ELSE
                        SET WCDSA-CDA-TYP-DPOS   TO TRUE
                    END-IF
                    MOVE RCFLW-SRC-CDA-SEQ-NUM   TO WCDSA-CDA-SEQ-NUM
                    MOVE RCFLW-SRC-POL-PAYO-NUM  TO WCDSA-POL-PAYO-NUM

               WHEN WS-ACTIVITY-TYPE-WTH
                    SET  WCDSA-CDA-TYP-WTHDR     TO TRUE
                    MOVE RCFLW-DEST-CDA-SEQ-NUM  TO WCDSA-CDA-SEQ-NUM
                    MOVE RCFLW-DEST-POL-PAYO-NUM TO WCDSA-POL-PAYO-NUM

           END-EVALUATE.

           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WCDSA-CDA-EFF-IDT-NUM.

           IF  WCDSA-KEY = WS-SAVE-CDSA-KEY
               SET WS-CDSA-REC-FOUND             TO TRUE
               GO TO 4050-DEP-WTH-CFLW-X
           END-IF.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.

           IF  NOT WCDSA-IO-OK
               PERFORM  4055-CFLW-TO-MIR
                   THRU 4055-CFLW-TO-MIR-X
               GO TO 4050-DEP-WTH-CFLW-X
           END-IF.

           SET WS-CDSA-REC-FOUND                 TO TRUE.

       4050-DEP-WTH-CFLW-X.
           EXIT.

      *-----------------
       4055-CFLW-TO-MIR.
      *-----------------

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    IF  RCFLW-CF-REVRS-PRCES-DT = WWKDT-ZERO-DT
                        MOVE RCFLW-CF-CLI-TRXN-AMT TO WS-CLI-TRXN-AMT
                    ELSE
                        COMPUTE WS-CLI-TRXN-AMT = RCFLW-CF-CLI-TRXN-AMT
                                                * -1
                    END-IF

               WHEN WS-ACTIVITY-TYPE-WTH
                    IF  RCFLW-CF-REVRS-PRCES-DT = WWKDT-ZERO-DT
                        MOVE RCFLW-CF-CLI-TRXN-AMT TO WS-CLI-TRXN-AMT
                    ELSE
                        MOVE ZERO      TO WS-CLI-TRXN-AMT
                    END-IF

           END-EVALUATE.

           MOVE RCFLW-CF-EFF-DT        TO WS-TRXN-EFF-DT.
           MOVE WS-CLI-TRXN-AMT        TO WS-TRXN-GRS-AMT.

           PERFORM  4090-DEP-WTH-TO-MIR
               THRU 4090-DEP-WTH-TO-MIR-X.

       4055-CFLW-TO-MIR-X.
           EXIT.

      *--------------------
       4090-DEP-WTH-TO-MIR.
      *--------------------

           EVALUATE TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4009'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5000'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4009'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5000'
031036         WHEN HPHST-POL-ACTV-TYP-ID = '7061'
031036         WHEN HPHST-POL-ACTV-TYP-ID = '7062'
                    IF WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
                       SET WS-TRXN-TYP-SDP    TO TRUE
                    ELSE
                       SET WS-TRXN-TYP-DEP    TO TRUE
                    END-IF

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4012'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4013'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4012'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4013'
                    SET WS-TRXN-TYP-IPD       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4003'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4003'
                    SET WS-TRXN-TYP-IPT       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4001'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5005'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4001'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5005'
031036         WHEN HPHST-POL-ACTV-TYP-ID = '7063'
031036         WHEN HPHST-POL-ACTV-TYP-ID = '7064'
                    SET WS-TRXN-TYP-SUR       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4005'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5006'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4005'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5006'
                    SET WS-TRXN-TYP-PSR       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4022'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5022'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4022'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5022'
                    SET WS-TRXN-TYP-AFR       TO TRUE

           END-EVALUATE.

030054*    MOVE WS-SAVE-PCHST-STAT-CD    TO WS-TRXN-STAT-CD.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO WS-FIRST-SEQ-NUM.
030054     MOVE HPHST-PCHST-STAT-CD      TO WS-TRXN-STAT-CD.
030054     MOVE HPHST-PCHST-SEQ-NUM      TO WS-FIRST-SEQ-NUM.


           PERFORM  9100-MOVE-TO-MIR
               THRU 9100-MOVE-TO-MIR-X.

       4090-DEP-WTH-TO-MIR-X.
           EXIT.

      *-------------------
       4200-PROCESS-ADMIN.
      *-------------------

           MOVE RPHST-CVG-NUM                TO WS-CVG.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  4220-ADM-FA
                        THRU 4220-ADM-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  4250-ADM-CFLW
                        THRU 4250-ADM-CFLW-X

           END-EVALUATE.

       4200-PROCESS-ADMIN-X.
           EXIT.
      *
      *------------
       4220-ADM-FA.
      *------------

           MOVE RPHST-POL-ID             TO WFA-POL-ID.
           MOVE RPHST-CVG-NUM            TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.
           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF NOT WFA-IO-OK
               GO TO 4220-ADM-FA-X
           END-IF.

           IF  RFA-CIA-TYP-ADMIN
           AND NOT RFA-CIA-REASN-MORT-CHRG
               CONTINUE
           ELSE
               GO TO 4220-ADM-FA-X
           END-IF.

           MOVE RFA-CIA-CLI-TRXN-AMT        TO WS-TRXN-GRS-AMT.
           PERFORM  4290-ADM-TO-MIR
               THRU 4290-ADM-TO-MIR-X.

       4220-ADM-FA-X.
           EXIT.
      *
      *--------------
       4250-ADM-CFLW.
      *--------------

           MOVE RPHST-POL-ID                 TO WCFLW-POL-ID.
           MOVE RPHST-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF NOT WCFLW-IO-OK
               GO TO 4250-ADM-CFLW-X
           END-IF.

           IF (RCFLW-CF-TRXN-ADMIN-FEE
           OR  RCFLW-CF-TRXN-ADMIN-FEE-REVRS)
           AND NOT RCFLW-CF-REASN-MORTALITY
               CONTINUE
           ELSE
               GO TO 4250-ADM-CFLW-X
           END-IF.

           MOVE RCFLW-CF-CLI-TRXN-AMT        TO WS-TRXN-GRS-AMT.
           PERFORM  4290-ADM-TO-MIR
               THRU 4290-ADM-TO-MIR-X.

       4250-ADM-CFLW-X.
           EXIT.

      *----------------
       4290-ADM-TO-MIR.
      *----------------

           EVALUATE TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4007'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4007'
                    SET WS-TRXN-TYP-ADM    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4008'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5004'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4008'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5004'
                    SET WS-TRXN-TYP-CDM    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5002'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5002'
                    SET WS-TRXN-TYP-AMF    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5003'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5003'
                    SET WS-TRXN-TYP-AFO    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4014'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4014'
                    SET WS-TRXN-TYP-TAF    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5100'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5100'
                    SET WS-TRXN-TYP-PUP    TO TRUE

           END-EVALUATE.

030054*    MOVE WS-SAVE-PCHST-EFF-DT     TO WS-TRXN-EFF-DT.
030054*    MOVE WS-SAVE-PCHST-STAT-CD    TO WS-TRXN-STAT-CD.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO WS-FIRST-SEQ-NUM.
030054     MOVE HPHST-PCHST-EFF-DT       TO WS-TRXN-EFF-DT.
030054     MOVE HPHST-PCHST-STAT-CD      TO WS-TRXN-STAT-CD.
030054     MOVE HPHST-PCHST-SEQ-NUM      TO WS-FIRST-SEQ-NUM.

           PERFORM  9100-MOVE-TO-MIR
               THRU 9100-MOVE-TO-MIR-X.

       4290-ADM-TO-MIR-X.
           EXIT.

      *-------------------
       4400-PROCESS-LOANS.
      *-------------------
      *
           MOVE RPOL-POL-ID        TO WLHST-POL-ID.
           MOVE 'C'                TO WLHST-POL-LOAN-ID.
           MOVE RPHST-PCHST-EFF-DT TO WLHST-POL-LOAN-EFF-DT.
           MOVE WLHST-KEY          TO WLHST-ENDBR-KEY.
           MOVE +000               TO WLHST-POL-LOAN-SEQ-NUM.
           MOVE +999               TO WLHST-ENDBR-POL-LOAN-SEQ-NUM.
           MOVE RPHST-PCHST-EFF-DT TO WS-SAVE-LAST-LOAN-DT.

           PERFORM  LHST-1000-BROWSE
               THRU LHST-1000-BROWSE-X.

           PERFORM  LHST-2000-READ-NEXT
               THRU LHST-2000-READ-NEXT-X.

           IF NOT WLHST-IO-OK
               PERFORM  LHST-3000-END-BROWSE
                   THRU LHST-3000-END-BROWSE-X
               GO TO 4400-PROCESS-LOANS-X
           END-IF.

           PERFORM  4450-LHST-TO-MIR
               THRU 4450-LHST-TO-MIR-X.

           PERFORM  LHST-3000-END-BROWSE
               THRU LHST-3000-END-BROWSE-X.

       4400-PROCESS-LOANS-X.
           EXIT.

      *
      *-----------------
       4450-LHST-TO-MIR.
      *-----------------


           EVALUATE TRUE

               WHEN RLHST-POL-LOAN-TRXN-LOAN
                    SET WS-TRXN-TYP-LON       TO TRUE

               WHEN RLHST-POL-LOAN-TRXN-REPAY-CSH
               WHEN RLHST-POL-LOAN-TRXN-REPAY-TRMN
               WHEN RLHST-POL-LOAN-TRXN-CNTRCT
                    SET WS-TRXN-TYP-RLN       TO TRUE

           END-EVALUATE.

           MOVE RLHST-POL-LOAN-EFF-DT    TO WS-TRXN-EFF-DT.
030054*    MOVE WS-SAVE-PCHST-STAT-CD    TO WS-TRXN-STAT-CD.
030054     MOVE HPHST-PCHST-STAT-CD      TO WS-TRXN-STAT-CD.
           MOVE RLHST-POL-LOAN-TRXN-AMT  TO WS-TRXN-GRS-AMT.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO WS-FIRST-SEQ-NUM.
030054     MOVE HPHST-PCHST-SEQ-NUM      TO WS-FIRST-SEQ-NUM.

           PERFORM  9100-MOVE-TO-MIR
               THRU 9100-MOVE-TO-MIR-X.

       4450-LHST-TO-MIR-X.
           EXIT.


      *----------------------
       4600-PROCESS-TRANSFER.
      *----------------------

           MOVE ZERO                   TO WS-TOTAL-CR.
           MOVE ZERO                   TO WS-TOTAL-DR.

           PERFORM  4650-TRANSFER
               THRU 4650-TRANSFER-X.

           COMPUTE WS-TRANSFER-TOTAL = WS-TOTAL-DR
                                     + WS-TOTAL-CR.
           IF WS-TRANSFER-TOTAL = ZERO
              PERFORM  4690-TRANSFER-TO-MIR
                  THRU 4690-TRANSFER-TO-MIR-X
              GO TO 4600-PROCESS-TRANSFER-X
           END-IF.

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.
           SET WS-SKIP-PHST-READ-YES    TO TRUE.

           IF NOT WPHST-IO-OK
               GO TO 4600-PROCESS-TRANSFER-X
           END-IF.

           SET WS-GROUP-END-NO           TO TRUE.
           PERFORM  4700-TRANSFER-LOOP
               THRU 4700-TRANSFER-LOOP-X
               UNTIL WS-GROUP-END-YES.

           PERFORM  4690-TRANSFER-TO-MIR
               THRU 4690-TRANSFER-TO-MIR-X.

       4600-PROCESS-TRANSFER-X.
           EXIT.


      *--------------
       4650-TRANSFER.
      *--------------

           SET WS-SKIP-PHST-READ-NO       TO TRUE.
           MOVE RPHST-CVG-NUM             TO WS-CVG.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  4670-TRANSFER-FA
                        THRU 4670-TRANSFER-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  4680-TRANSFER-CFLW
                        THRU 4680-TRANSFER-CFLW-X

           END-EVALUATE.

       4650-TRANSFER-X.
           EXIT.


      *----------------
       4670-TRANSFER-FA.
      *----------------

           MOVE RPOL-POL-ID              TO WFA-POL-ID.
           MOVE RPHST-CVG-NUM            TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.
           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF NOT WFA-IO-OK
               GO TO 4670-TRANSFER-FA-X
           END-IF.

           IF  RFA-CIA-TYP-XFER
           OR  RFA-CIA-TYP-INTRNL-XFER
020452     OR  RFA-CIA-TYP-XFER-FRGN
               CONTINUE
           ELSE
               GO TO 4670-TRANSFER-FA-X
           END-IF.

           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE RFA-FRST-FIA-FND-ID    TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           PERFORM  4675-TRANSFER-READ-FD
               THRU 4675-TRANSFER-READ-FD-X
               UNTIL WFD-FND-ID = SPACE.

       4670-TRANSFER-FA-X.
           EXIT.

      *----------------------
       4675-TRANSFER-READ-FD.
      *----------------------

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF NOT WFD-IO-OK
              MOVE SPACES             TO WFD-FND-ID
              GO TO 4675-TRANSFER-READ-FD-X
           END-IF.


020469*    IF RFD-FIA-FND-TRXN-AMT  > ZERO
020469*       ADD RFD-FIA-FND-TRXN-AMT   TO WS-TOTAL-DR
020469*       ADD RFD-FIA-LOAD-AMT       TO WS-TOTAL-DR
020469*    ELSE
020469*       ADD RFD-FIA-FND-TRXN-AMT   TO WS-TOTAL-CR
020469*       ADD RFD-FIA-LOAD-AMT       TO WS-TOTAL-CR
020469*    END-IF.
020469
020469     IF RFD-FIA-ORIG-TRXN-AMT  > ZERO
020469        ADD RFD-FIA-ORIG-TRXN-AMT  TO WS-TOTAL-DR
020469        ADD RFD-FIA-ORIG-LOAD-AMT  TO WS-TOTAL-DR
020469     ELSE
020469        ADD RFD-FIA-ORIG-TRXN-AMT  TO WS-TOTAL-CR
020469        ADD RFD-FIA-ORIG-LOAD-AMT  TO WS-TOTAL-CR
020469     END-IF.

           MOVE RFD-NXT-FIA-FND-ID    TO WFD-FND-ID.

       4675-TRANSFER-READ-FD-X.
           EXIT.


      *-------------------
       4680-TRANSFER-CFLW.
      *-------------------

           MOVE RPOL-POL-ID                  TO WCFLW-POL-ID.
           MOVE RPHST-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF NOT WCFLW-IO-OK
               GO TO 4680-TRANSFER-CFLW-X
           END-IF.

           MOVE RCFLW-CF-CLI-TRXN-AMT     TO WS-CLI-TRXN-AMT.
           IF RCFLW-CF-REVRS-PRCES-DT NOT = WWKDT-ZERO-DT
              COMPUTE WS-CLI-TRXN-AMT = -1 * WS-CLI-TRXN-AMT
           END-IF.

           IF WS-CLI-TRXN-AMT  > ZERO
              ADD WS-CLI-TRXN-AMT      TO WS-TOTAL-DR
           ELSE
              ADD WS-CLI-TRXN-AMT      TO WS-TOTAL-CR
           END-IF.


       4680-TRANSFER-CFLW-X.
           EXIT.

      *---------------------
       4690-TRANSFER-TO-MIR.
      *---------------------

           EVALUATE TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4011'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4011'
                    SET WS-TRXN-TYP-CSW    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4017'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5007'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4017'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5007'
                    SET WS-TRXN-TYP-FLT    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4021'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4021'
                    SET WS-TRXN-TYP-INT    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5021'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5001'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5021'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5001'
                    SET WS-TRXN-TYP-TRF    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4006'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4006'
                    SET WS-TRXN-TYP-SWP    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5010'
033899*        WHEN HPHST-POL-ACTV-TYP-ID = '5010'
033899         WHEN HPHST-POL-ACTV-TYP-ID = '5011'
                    SET WS-TRXN-TYP-MEX    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4002'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4002'
023112              SET WS-TRXN-TYP-ROL    TO TRUE
023112
           END-EVALUATE.

           MOVE WS-TOTAL-DR              TO WS-TRXN-GRS-AMT.
030054*    MOVE WS-SAVE-PCHST-EFF-DT     TO WS-TRXN-EFF-DT.
030054*    MOVE WS-SAVE-PCHST-STAT-CD    TO WS-TRXN-STAT-CD.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO WS-FIRST-SEQ-NUM.
030054     MOVE HPHST-PCHST-EFF-DT       TO WS-TRXN-EFF-DT.
030054     MOVE HPHST-PCHST-STAT-CD      TO WS-TRXN-STAT-CD.
030054     MOVE HPHST-PCHST-SEQ-NUM      TO WS-FIRST-SEQ-NUM.

           PERFORM  9100-MOVE-TO-MIR
               THRU 9100-MOVE-TO-MIR-X.

       4690-TRANSFER-TO-MIR-X.
           EXIT.

      *------------------
       4700-TRANSFER-LOOP.
      *------------------

           IF  NOT RPHST-PCHST-STAT-ACTIVE
           AND NOT RPHST-PCHST-STAT-REVERSED
               SET WS-GROUP-END-YES     TO TRUE
               GO TO 4700-TRANSFER-LOOP-X
           END-IF.

           MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTIVITY-TYPE-ID.
           IF  NOT WS-ACTIVITY-TYPE-TRXNS
               SET WS-GROUP-END-YES     TO TRUE
               GO TO 4700-TRANSFER-LOOP-X
           END-IF.

030054*    IF RPHST-PCHST-STAT-CD NOT = WS-SAVE-PCHST-STAT-CD
030054     IF RPHST-PCHST-STAT-CD NOT = HPHST-PCHST-STAT-CD
               SET WS-GROUP-END-YES     TO TRUE
               GO TO 4700-TRANSFER-LOOP-X
           END-IF.

           PERFORM  4650-TRANSFER
               THRU 4650-TRANSFER-X.

           COMPUTE WS-TRANSFER-TOTAL = WS-TOTAL-DR
                                     + WS-TOTAL-CR.
           IF WS-TRANSFER-TOTAL = ZERO
               SET WS-GROUP-END-YES        TO TRUE
               GO TO 4700-TRANSFER-LOOP-X
           END-IF

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.
           SET WS-SKIP-PHST-READ-YES      TO TRUE.

           IF NOT WPHST-IO-OK
               SET WS-GROUP-END-YES     TO TRUE
               GO TO 4700-TRANSFER-LOOP-X
           END-IF.

       4700-TRANSFER-LOOP-X.
           EXIT.


      *----------------
       4800-PROCESS-AR.
      *----------------

           MOVE RPOL-POL-ID               TO WCDSA-POL-ID.
           SET  WCDSA-CDA-TYP-ASSET-REBAL TO TRUE.

           MOVE RPHST-PCHST-OLD-VALU-TXT  TO WS-SEQ.
           COMPUTE WS-CDA-NUM = 100000 - WS-CDSA-NUM.
           MOVE WS-CDA-NUM                TO WCDSA-POL-PAYO-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM   TO WCDSA-CDA-EFF-IDT-NUM.
026206*    MOVE +999                      TO WCDSA-CDA-SEQ-NUM.
026206     MOVE +0                        TO WCDSA-CDA-SEQ-NUM.

026206     MOVE WCDSA-KEY                 TO WCDSA-ENDBR-KEY.
026206     MOVE +999                   TO WCDSA-ENDBR-CDA-SEQ-NUM.

026206*    PERFORM  CDSA-1000-READ
026206*        THRU CDSA-1000-READ-X.

026206     PERFORM  CDSA-1000-BROWSE
026206         THRU CDSA-1000-BROWSE-X.

026206     PERFORM  CDSA-2000-READ-NEXT
026206         THRU CDSA-2000-READ-NEXT-X.

026206     PERFORM
026206        UNTIL  RCDSA-CDA-STAT-ACTIVE
026206           OR  NOT WCDSA-IO-OK
026206               PERFORM  CDSA-2000-READ-NEXT
026206                   THRU CDSA-2000-READ-NEXT-X
026206     END-PERFORM.

           IF NOT WCDSA-IO-OK
026206        PERFORM  CDSA-3000-END-BROWSE
026206            THRU CDSA-3000-END-BROWSE-X
              GO TO 4800-PROCESS-AR-X
           END-IF.

026206     PERFORM  CDSA-3000-END-BROWSE
026206         THRU CDSA-3000-END-BROWSE-X.

           SET  WS-TRXN-TYP-ASR          TO TRUE
           MOVE RCDSA-CDA-TOT-TRXN-AMT   TO WS-TRXN-GRS-AMT.
030054*    MOVE WS-SAVE-PCHST-EFF-DT     TO WS-TRXN-EFF-DT.
030054*    MOVE WS-SAVE-PCHST-STAT-CD    TO WS-TRXN-STAT-CD.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO WS-FIRST-SEQ-NUM.
030054     MOVE HPHST-PCHST-EFF-DT       TO WS-TRXN-EFF-DT.
030054     MOVE HPHST-PCHST-STAT-CD      TO WS-TRXN-STAT-CD.
030054     MOVE HPHST-PCHST-SEQ-NUM      TO WS-FIRST-SEQ-NUM.

           PERFORM  9100-MOVE-TO-MIR
               THRU 9100-MOVE-TO-MIR-X.

       4800-PROCESS-AR-X.
           EXIT.


      *----------------
       4900-PROCESS-DCA.
      *----------------

           MOVE RPHST-CVG-NUM                TO WS-CVG.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  4920-DCA-FA
                        THRU 4920-DCA-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  4950-DCA-CFLW
                        THRU 4950-DCA-CFLW-X

           END-EVALUATE.

       4900-PROCESS-DCA-X.
           EXIT.
      *
      *------------
       4920-DCA-FA.
      *------------

           MOVE RPHST-POL-ID             TO WFA-POL-ID.
           MOVE RPHST-CVG-NUM            TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.
           MOVE RPHST-PCHST-NEW-VALU-TXT TO WS-SEQ.
           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.
           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF NOT WFA-IO-OK
               GO TO 4920-DCA-FA-X
           END-IF.

           IF  RFA-CIA-TYP-INTRNL-XFER
020452     OR  RFA-CIA-TYP-XFER-FRGN
               CONTINUE
           ELSE
               GO TO 4920-DCA-FA-X
           END-IF.

           MOVE RFA-CIA-CLI-TRXN-AMT        TO WS-TRXN-GRS-AMT.
           PERFORM  4990-DCA-TO-MIR
               THRU 4990-DCA-TO-MIR-X.

       4920-DCA-FA-X.
           EXIT.
      *
      *--------------
       4950-DCA-CFLW.
      *--------------

           MOVE RPHST-POL-ID                 TO WCFLW-POL-ID.
           MOVE RPHST-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.
           MOVE RPHST-PCHST-NEW-VALU-TXT     TO WS-SEQ.
           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF NOT WCFLW-IO-OK
               GO TO 4950-DCA-CFLW-X
           END-IF.

           IF  RCFLW-CF-TRXN-INTRNL-XFER
           OR  RCFLW-CF-TRXN-XFER-REVRS
               CONTINUE
           ELSE
               GO TO 4950-DCA-CFLW-X
           END-IF.

           MOVE RCFLW-CF-CLI-TRXN-AMT        TO WS-TRXN-GRS-AMT.
           PERFORM  4990-DCA-TO-MIR
               THRU 4990-DCA-TO-MIR-X.

       4950-DCA-CFLW-X.
           EXIT.

      *----------------
       4990-DCA-TO-MIR.
      *----------------

           SET WS-TRXN-TYP-DCA           TO TRUE
           COMPUTE WS-TRXN-GRS-AMT = -1 * WS-TRXN-GRS-AMT.
030054*    MOVE WS-SAVE-PCHST-EFF-DT     TO WS-TRXN-EFF-DT.
030054*    MOVE WS-SAVE-PCHST-STAT-CD    TO WS-TRXN-STAT-CD.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO WS-FIRST-SEQ-NUM.
030054     MOVE HPHST-PCHST-EFF-DT       TO WS-TRXN-EFF-DT.
030054     MOVE HPHST-PCHST-STAT-CD      TO WS-TRXN-STAT-CD.
030054     MOVE HPHST-PCHST-SEQ-NUM      TO WS-FIRST-SEQ-NUM.

           PERFORM  9100-MOVE-TO-MIR
               THRU 9100-MOVE-TO-MIR-X.

       4990-DCA-TO-MIR-X.
           EXIT.

027315*-----------------
027315 5000-PROCESS-INTR.
027315*-----------------
027315
027315     MOVE RPOL-POL-ID               TO WCDSA-POL-ID.
027315     SET  WCDSA-CDA-TYP-XFER        TO TRUE
027315
027315     MOVE +0                        TO WCDSA-POL-PAYO-NUM.
027315     MOVE RPHST-PCHST-EFF-IDT-NUM   TO WCDSA-CDA-EFF-IDT-NUM.
027315     MOVE RPHST-PCHST-OLD-VALU-TXT  TO WS-SEQ.
027315     COMPUTE WS-CDA-NUM = 1000 - WS-SEQ-NUM.
027315     MOVE WS-CDA-NUM                TO WCDSA-CDA-SEQ-NUM.
027315
027315
027315     PERFORM  CDSA-1000-READ
027315         THRU CDSA-1000-READ-X.
027315
027315     IF NOT WCDSA-IO-OK
027315        GO TO 5000-PROCESS-INTR-X
027315     END-IF.
027315
027315     SET  WS-TRXN-TYP-INT          TO TRUE
027315     MOVE RCDSA-CDA-TOT-TRXN-AMT   TO WS-TRXN-GRS-AMT.
030054*    MOVE WS-SAVE-PCHST-EFF-DT     TO WS-TRXN-EFF-DT.
030054*    MOVE WS-SAVE-PCHST-STAT-CD    TO WS-TRXN-STAT-CD.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO WS-FIRST-SEQ-NUM.
030054     MOVE HPHST-PCHST-EFF-DT       TO WS-TRXN-EFF-DT.
030054     MOVE HPHST-PCHST-STAT-CD      TO WS-TRXN-STAT-CD.
030054     MOVE HPHST-PCHST-SEQ-NUM      TO WS-FIRST-SEQ-NUM.
027315
027315     PERFORM  9100-MOVE-TO-MIR
027315         THRU 9100-MOVE-TO-MIR-X.
027315
027315 5000-PROCESS-INTR-X.
027315     EXIT.

      *-----------------
       9100-MOVE-TO-MIR.
      *-----------------

           MOVE WS-TRXN-EFF-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                 TO MIR-DV-FIN-TRXN-EFF-DT-T (WS-SUB).

           MOVE WS-TRXN-TYP-CD   TO MIR-DV-FIN-TRXN-TYP-CD-T (WS-SUB).
           MOVE WS-TRXN-TYP-CD   TO MIR-DV-PRCES-TRXN-TYP-CD-T (WS-SUB).
           MOVE WS-TRXN-STAT-CD  TO MIR-DV-FIN-TRXN-STAT-CD-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = WS-TRXN-GRS-AMT * 100.
020874     MOVE WS-TRXN-GRS-AMT          TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                                 TO MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = WS-FIRST-SEQ-NUM.
020874     MOVE WS-FIRST-SEQ-NUM         TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
021657*    MOVE LENGTH OF MIR-DV-FIRST-SEQ-NUM-T (WS-SUB)
021657     MOVE LENGTH OF MIR-DV-FIN-TRXN-SEQ-NUM-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
021657*    MOVE L0290-OUTPUT-DATA  TO MIR-DV-FIRST-SEQ-NUM-T (WS-SUB).
021657     MOVE L0290-OUTPUT-DATA TO MIR-DV-FIN-TRXN-SEQ-NUM-T (WS-SUB).

020460     IF  WS-PRCES-PHST
020460     AND WS-SAVE-PCHST-PAAFLD-YES
020460           MOVE WS-SAVE-PCHST-PAAFLD-IND
020460                          TO MIR-DV-PCHST-PAAFLD-IND-T (WS-SUB)
020460           SET WS-SAVE-PCHST-PAAFLD-NO     TO TRUE
020460     END-IF.
020460
           ADD +1                       TO WS-SUB.

       9100-MOVE-TO-MIR-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY   TO TRUE.
           MOVE MIR-POL-ID         TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-MAX-LINE-DEFAULT TO TRUE.
025970
025970     MOVE SPACES             TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNCVG.
       COPY CCPNCFLW.
       COPY SCPNFA.
       COPY SCPNFD.
026206 COPY CCPBCDSA.
       COPY CCPNCDSA.
021930*COPY CCPBCDSD.
       COPY CCPBPHST.
020460 COPY CCPBPAAS.
       COPY CCPBLHST.
       COPY CCPNUH.
       COPY CCPBUHCO.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **              END OF PROGRAM CSOM7822                        **
      *****************************************************************
