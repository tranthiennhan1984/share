      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2236.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2236                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE CLNC TABLE - NO MATCH CRITERIA           **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015510**  6.0       CLIENT ENHANCEMENTS                              **
016548**  6.2       CHANGE COMP TO BINARY                            **
016103**  6.3       JAPANESE SEARCH ENHANCEMENTS (6.1.2J)            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020701**  6.3       DISPLAY COMPANY LIST BY PHONETIC                 **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2236'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.
014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '2236'.
016548*    05  WS-SUB                       PIC S9(4) VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4) VALUE ZERO BINARY.
025970         88 WS-SUB-DEFAULT            VALUE ZERO.
016548*    05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 50   COMP.
016548     05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 50   BINARY.
025970         88 WS-MAX-LIST-LINES-DEFAULT            VALUE 50.
020701     05  WS-CLI-INDV-GR-CD            PIC X(02).
020701         88  WS-CLI-INDV-GR-CD-AL     VALUE 'AL'.
020701         88  WS-CLI-INDV-GR-CD-KA     VALUE 'KA'.
020701         88  WS-CLI-INDV-GR-CD-KJ     VALUE 'KJ'.
020701     05  WS-CLI-CO-NM-PHNT-TXT        PIC X(50).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCLND.
       COPY CCFRCLNC.
020701 COPY CCFWCLNE.
028298 COPY CCWL2626.
020701 COPY CCWL2810.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2236.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2236'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

018732*    IF NOT WGLOB-COUNTRY-JAPAN
018732*        SET MIR-DV-SRCH-GR-ALPHA     TO TRUE
018732*    ELSE
018732*        IF  MIR-DV-SRCH-GR-ALPHA
018732*            SET MIR-DV-SRCH-GR-KANJI TO TRUE
018732*        END-IF
018732*    END-IF.

020701     MOVE MIR-CLI-INDV-GR-CD          TO WS-CLI-INDV-GR-CD.

020701     IF WS-CLI-INDV-GR-CD-AL
020701     OR WS-CLI-INDV-GR-CD-KJ
020701        PERFORM  2030-AL-LIST
020701            THRU 2030-AL-LIST-X
020701     ELSE
020701        PERFORM  2040-KA-LIST
020701            THRU 2040-KA-LIST-X
020701     END-IF.

020701*    PERFORM  7000-BUILD-KEYS
020701*        THRU 7000-BUILD-KEYS-X.

020701*    PERFORM  CLND-1000-BROWSE
020701*        THRU CLND-1000-BROWSE-X.

020701*    PERFORM  CLND-2000-READ-NEXT
020701*        THRU CLND-2000-READ-NEXT-X.

020701*    IF  WCLND-IO-EOF
020701*        PERFORM  CLND-3000-END-BROWSE
020701*            THRU CLND-3000-END-BROWSE-X
020701*MSG: 'NO RECORDS FOUND TO DISPLAY'
020701*        MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
020701*        PERFORM  0260-1000-GENERATE-MESSAGE
020701*            THRU 0260-1000-GENERATE-MESSAGE-X
020701*        SET MIR-RETRN-RQST-FAILED
020701*          TO TRUE
020701*        GO TO 2000-LIST-X
020701*    END-IF.

020701*    PERFORM  2010-BROWSE-CLND
020701*        THRU 2010-BROWSE-CLND-X
020701*        VARYING WS-SUB FROM 1 BY 1
020701*        UNTIL   WS-SUB > WS-MAX-LIST-LINES
020701*        OR      WCLND-IO-EOF.

020701*    IF  WCLND-IO-EOF
020701*        CONTINUE
020701*    ELSE
020701*        SET WGLOB-MORE-DATA-EXISTS
020701*          TO TRUE
020701*        MOVE RCLNC-CLI-CO-NM
020701*          TO MIR-CLI-CO-NM
020701*        MOVE RCLNC-CLI-ID
020701*          TO MIR-CLI-ID
020701*    END-IF.

020701*    PERFORM  CLND-3000-END-BROWSE
020701*        THRU CLND-3000-END-BRO020701*

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-CLND.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  CLND-2000-READ-NEXT
               THRU CLND-2000-READ-NEXT-X.

       2010-BROWSE-CLND-X.
           EXIT.
      /
020701*-----------------
020701 2020-BROWSE-CLNE.
020701*-----------------

020701     PERFORM  9200-MOVE-RECORD-TO-SCREEN
020701         THRU 9200-MOVE-RECORD-TO-SCREEN-X.

020701     PERFORM  CLNE-2000-READ-NEXT
020701         THRU CLNE-2000-READ-NEXT-X.

       2020-BROWSE-CLNE-X.
           EXIT.
      /
020701*------------
020701 2030-AL-LIST.
020701*------------

020701     PERFORM  7000-BUILD-KEYS
020701         THRU 7000-BUILD-KEYS-X.

020701     PERFORM  CLND-1000-BROWSE
020701         THRU CLND-1000-BROWSE-X.

020701     PERFORM  CLND-2000-READ-NEXT
020701         THRU CLND-2000-READ-NEXT-X.

020701     IF  WCLND-IO-EOF
020701         PERFORM  CLND-3000-END-BROWSE
020701             THRU CLND-3000-END-BROWSE-X
020701*MSG: 'NO RECORDS FOUND TO DISPLAY'
020701         MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
020701         PERFORM  0260-1000-GENERATE-MESSAGE
020701             THRU 0260-1000-GENERATE-MESSAGE-X
020701         SET MIR-RETRN-RQST-FAILED
020701           TO TRUE
020701         GO TO 2030-AL-LIST-X
020701     END-IF.

020701     PERFORM  2010-BROWSE-CLND
020701         THRU 2010-BROWSE-CLND-X
020701         VARYING WS-SUB FROM 1 BY 1
020701         UNTIL   WS-SUB > WS-MAX-LIST-LINES
020701         OR      WCLND-IO-EOF.

020701     IF  WCLND-IO-EOF
020701         CONTINUE
020701     ELSE
020701         SET WGLOB-MORE-DATA-EXISTS
020701           TO TRUE
020701         MOVE RCLNC-CLI-CO-NM
020701           TO MIR-CLI-CO-NM
020701         MOVE RCLNC-CLI-ID
020701           TO MIR-CLI-ID
020701     END-IF.

020701     PERFORM  CLND-3000-END-BROWSE
020701         THRU CLND-3000-END-BROWSE-X.

020701 2030-AL-LIST-X.
020701     EXIT.
020701/
020701*------------
020701 2040-KA-LIST.
020701*------------

020701     PERFORM  7100-BUILD-KEYS
020701         THRU 7100-BUILD-KEYS-X.

020701     PERFORM  CLNE-1000-BROWSE
020701         THRU CLNE-1000-BROWSE-X.

020701     PERFORM  CLNE-2000-READ-NEXT
020701         THRU CLNE-2000-READ-NEXT-X.

020701     IF  WCLNE-IO-EOF
020701         PERFORM  CLNE-3000-END-BROWSE
020701             THRU CLNE-3000-END-BROWSE-X
020701*MSG: 'NO RECORDS FOUND TO DISPLAY'
020701         MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
020701         PERFORM  0260-1000-GENERATE-MESSAGE
020701             THRU 0260-1000-GENERATE-MESSAGE-X
020701         SET MIR-RETRN-RQST-FAILED
020701           TO TRUE
020701         GO TO 2040-KA-LIST-X
020701     END-IF.

020701     PERFORM  2020-BROWSE-CLNE
020701         THRU 2020-BROWSE-CLNE-X
020701         VARYING WS-SUB FROM 1 BY 1
020701         UNTIL   WS-SUB > WS-MAX-LIST-LINES
020701         OR      WCLNE-IO-EOF.

020701     IF  WCLNE-IO-EOF
020701         CONTINUE
020701     ELSE
020701         SET WGLOB-MORE-DATA-EXISTS
020701           TO TRUE
020701         MOVE RCLNC-CLI-CO-NM
020701           TO MIR-CLI-CO-NM
020701         MOVE RCLNC-CLI-ID
020701           TO MIR-CLI-ID
020701     END-IF.

020701     PERFORM  CLNE-3000-END-BROWSE
020701         THRU CLNE-3000-END-BROWSE-X.

020701 2040-KA-LIST-X.
020701     EXIT.
020701/
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WCLND-KEY.

018732*    EVALUATE TRUE

016103*        WHEN WGLOB-COUNTRY-JAPAN
018732*        WHEN MIR-DV-SRCH-GR-KANJI
016103*             SET  WCLND-CLI-CO-GR-KATAKANA
018732*             SET  WCLND-CLI-CO-GR-KANJI
018732*                TO TRUE
018732*        WHEN MIR-DV-SRCH-GR-KATAKANA
018732*             SET  WCLND-CLI-CO-GR-KATAKANA
018732*                TO TRUE

016103*        WHEN OTHER
018732*        WHEN MIR-DV-SRCH-GR-ALPHA
018732*             SET  WCLND-CLI-CO-GR-ALPHA
018732*                TO TRUE

018732*    END-EVALUATE.
018732     MOVE MIR-CLI-INDV-GR-CD     TO WCLND-CLI-CO-GR-CD.
           SET  WCLND-CLI-CO-NM-TYP-CLI   TO TRUE.
           MOVE MIR-CLI-CO-NM          TO WCLND-CLI-CO-NM.
           MOVE MIR-CLI-ID             TO WCLND-CLI-ID.

           MOVE WCLND-KEY              TO WCLND-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WCLND-ENDBR-CLI-CO-NM.
           MOVE HIGH-VALUES            TO WCLND-ENDBR-CLI-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      /
020701*----------------
020701 7100-BUILD-KEYS.
020701*----------------

020701     SET  L2810-SRCH-GR-KATAKANA TO TRUE
020701     MOVE SPACES                TO WS-CLI-CO-NM-PHNT-TXT
020701     MOVE MIR-CLI-CO-NM         TO L2810-INPUT-NAME
020701         PERFORM  2810-1000-CONAM-ENCODE
020701             THRU 2810-1000-CONAM-ENCODE-X
020701         IF  L2810-RETRN-OK
020701             MOVE L2810-PHONETIC-NAME
020701                                 TO WS-CLI-CO-NM-PHNT-TXT
020701         END-IF

020701     MOVE LOW-VALUES            TO WCLNE-KEY.

020701     MOVE MIR-CLI-INDV-GR-CD    TO WCLNE-CLI-CO-GR-CD.
020701     SET  WCLNE-CLI-CO-NM-TYP-CLI   TO TRUE.
020701     MOVE WS-CLI-CO-NM-PHNT-TXT TO WCLNE-CLI-CO-NM-PHNT-TXT.

020701     MOVE WCLNE-KEY             TO WCLNE-ENDBR-KEY.
020701     MOVE HIGH-VALUES           TO WCLNE-ENDBR-CLI-CO-NM-PHNT-TXT.
020701     MOVE HIGH-VALUES           TO WCLNE-ENDBR-CLI-ID.

020701 7100-BUILD-KEYS-X.
020701     EXIT.
020701/

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES
             TO MIR-CLI-CO-NM-G.
           MOVE SPACES
             TO MIR-CLI-ID-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RCLNC-CLI-CO-NM
             TO MIR-CLI-CO-NM-T (WS-SUB).

           MOVE RCLNC-CLI-ID
             TO MIR-CLI-ID-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT
             TO TRUE.
           MOVE MIR-CLI-ID
             TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  2810-0000-INIT-PARM-INFO
025970         THRU 2810-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-SUB-DEFAULT TO TRUE.
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
025970 COPY CCPS2810.
020701 COPY CCPL2810.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBCLND.
020701 COPY CCPBCLNE.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2236                     **
      *****************************************************************
