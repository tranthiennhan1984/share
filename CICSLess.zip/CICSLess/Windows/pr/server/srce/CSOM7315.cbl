      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM7315.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7315                                         **
      **  REMARKS:  DEATH BENEFIT GUARANTEE QUOTE                    **
      **            THIS MODULE PERFORMS ON-LINE DEATH QUOTE FUNCTION**
      **            FOR DEATH BENEFIT                                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
023805**  6.5       CONVERSION OF PX CALCULATION AND EXIT PROGRAM    **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023444**  6.5       QUOTE INCOME ON WITHDRAWALS                      **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
027445**  6.6       INCORRECT RETURN CODE                            **
025051**  6.6       UNABLE TO SPECIFY TAX WITHHOLDING                **
027096**  6.7       MESSAGE ON CLIENT STATUS NOT DEFINFED AS DEAD    **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
031034**  7.0       TAX COMPONENTIZATION                             **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7315'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID                 PIC X(04).
                   88  WS-BUS-FCN-DTH-QUOTE      VALUE '7315'.
               10  WS-EFF-DT                     PIC X(10).
               10  WS-CVG-NUM                    PIC 99.
               10  WS-DTH-QUOT-IND               PIC X.
                   88  WS-DTH-QUOT-YES           VALUE 'Y'.
                   88  WS-DTH-QUOT-NO            VALUE 'N'.
               10  WS-DBG-AMT-T.
                   15  WS-DBG-BASIC-AMT          PIC S9(13)V99.
                   15  WS-LOCK-RESET-AMT         PIC S9(13)V99.
                   15  WS-ANNV-VALU-AMT          PIC S9(13)V99.
                   15  WS-MAV-AMT                PIC S9(13)V99.
                   15  WS-ROLLUP-AMT             PIC S9(13)V99.
               10  FILLER REDEFINES WS-DBG-AMT-T.
                   15  WS-DBG-AMT       OCCURS 5 PIC S9(13)V99.
               10  WS-DBG-BASIC-CSV-AMT          PIC S9(13)V99.
               10  WS-DBG-ACUM-AMT               PIC S9(13)V99.
               10  WS-POL-DTH-AMT                PIC S9(13)V99.
               10  WS-POL-CSH-LOAN-AMT           PIC S9(13)V99.
               10  WS-POL-MISC-SUSP-AMT          PIC S9(13)V99.
               10  WS-POL-PREM-SUSP-AMT          PIC S9(13)V99.
               10  WS-POL-OS-DISB-AMT            PIC S9(13)V99.
               10  WS-POL-PDF-AMT                PIC S9(13)V99.
               10  WS-POL-SIDFND-AFV-AMT         PIC S9(13)V99.
               10  WS-POL-OTHR-BAL-AMT           PIC S9(13)V99.
               10  WS-POL-NET-DTH-AMT            PIC S9(13)V99.
               10  WS-CVG-LINE                   OCCURS 99.
                   15  WS-CVG-NUM-T              PIC 9(02).
                   15  WS-PLAN-ID                PIC X(06).
                   15  WS-CVG-DTH-AMT            PIC S9(13)V99.
025970*        10  WS-SUB                        PIC S9(3) COMP.
025970*        10  WS-CVG-CTR                    PIC S9(3) COMP.
025970         10  WS-SUB                        PIC S9(3) BINARY.
025970         10  WS-CVG-CTR                    PIC S9(3) BINARY.
               10  WS-SEG-FND-GUAR-VALU-AMT      PIC S9(13)V99.
031034*        10  WS-POL-SURR-CHRG-AMT          PIC S9(13)V99.
023444         10  WS-DV-POL-TAX-ACB-AMT         PIC S9(13)V99.
023444         10  WS-DV-GRS-DSTRB-AMT           PIC S9(13)V99.
023444         10  WS-DV-TAXBL-GRS-DSTRB-AMT     PIC S9(13)V99.
023444         10  WS-CDA-FED-TAXWH-AMT          PIC S9(13)V99.
023444         10  WS-LTAXWH-FLAT-AMT            PIC S9(13)V99.
023444         10  WS-TRXN-CV-AMT                PIC S9(13)V99.
023444         10  WS-TRXN-MCV-OFFSET            PIC S9(13)V99.
023444         10  WS-BENEFIT-AMOUNT             PIC S9(13)V99.
023437         10  WS-TOT-TRMN-AMT               PIC S9(13)V99.
023444         10  WS-LIFE-IND                   PIC X(01).
023444             88  WS-PRCES-LIFE             VALUE 'Y'.
023444             88  WS-PRCES-NTRAD            VALUE 'N'.
031034*        10  WS-PLAR-REC-SW                PIC X(01).
031034*            88  WS-PLAR-REC-FOUND         VALUE 'Y'.
031034*            88  WS-PLAR-REC-NOT-FOUND     VALUE 'N'.
023437     05  WS-FLEX-INS-TYP-SW                PIC X(01).
023437         88  WS-FLEX-INS-NO                VALUE 'N'.
023437         88  WS-FLEX-INS                   VALUE 'Y'.
025051     05  WS-FED-TAXWH-RQST-AMT             PIC S9(11)V9(02).
025051     05  WS-FED-TAXWH-RQST-PCT             PIC S9(03)V9(02).
025051     05  WS-LTAXWH-PCT                     PIC S9(03)V9(02).
029060     05  WS-LTAXWH-AMT                     PIC S9(11)V9(02).


      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
       COPY XCWWWKDT.
       COPY CCWWINDX.
       COPY CCWWLOCK.
023437 COPY CCWWBTAX.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
      *
       COPY CCFWPOL.
       COPY CCFRPOL.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOLS.
       COPY CCFRPOLP.
      *
       COPY SCFWFX.
       COPY SCFRFX.
      *
023444 COPY CCFWPH.
023444 COPY CCFRPH.
      *
       COPY SCFWFA.
       COPY SCFRFA.
      *
       COPY CCWWCVGS.
      *
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************

028298 COPY CCWL2626.
       COPY CCWLPGA.
       COPY XCWLDTLK.
       COPY XCWL0279.
       COPY XCWL0280.
       COPY XCWL0290.
025051 COPY XCWL0316.
       COPY XCWL0317.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWL8090.
       COPY CCWL0182.
031034*COPY CCWL0187.
031034*COPY CCWLPGAL.
       COPY CCWL0620.
       COPY CCWL2430.
027096 COPY CCWL2435.
       COPY CCWL4750.
       COPY CCWL4780.
031034 COPY CCWL5382.
       COPY CCWL7306.
031034*COPY CCWL7800.
       COPY CCWLDGBA.
       COPY CCWLDGLK.
       COPY CCWLDGRS.
       COPY CCWLDGMV.
       COPY CCWLDGRU.
025051 COPY CCWLTAXC.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7315.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.


      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.
           SET L0290-SIGN-DISPLAY        TO TRUE.

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID                    TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DTH-QUOTE
                    PERFORM  3000-DTH-QUOTE
                        THRU 3000-DTH-QUOTE-X

               WHEN OTHER
      *MSG: INVALID FUNCTION ID - PROCESSING STOPPED
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7315'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.


      *--------------
       3000-DTH-QUOTE.
      *--------------

           PERFORM  8100-BLANK-DATA-FIELDS
               THRU 8100-BLANK-DATA-FIELDS-X.

           MOVE MIR-POL-ID           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WPOL-POL-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'POL'            TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3000-DTH-QUOTE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.


           PERFORM  7306-1000-BUILD-PARM-INFO
               THRU 7306-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID       TO L7306-POL-ID.

           PERFORM  7306-1000-GET-DBG-INFO
               THRU 7306-1000-GET-DBG-INFO-X.


           MOVE MIR-DV-EFF-DT          TO L1640-EXTERNAL-DATE.
           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE    TO WS-EFF-DT.


           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.
           MOVE +2                    TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-CVG-NUM
           ELSE
      *MSG: COVERAGE NUMBER INVALID
               MOVE 'CS73150007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3000-DTH-QUOTE-X
           END-IF.

           IF WS-CVG-NUM > RPOL-POL-CVG-REC-CTR-N
      *MSG: COVERAGE NUMBER INVALID
               MOVE 'CS73150007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3000-DTH-QUOTE-X
           END-IF.


025051     PERFORM  5050-EDIT-LTAXWH-RQST
025051         THRU 5050-EDIT-LTAXWH-RQST-X.
025051
025051     PERFORM  5060-EDIT-TAXWH-RQST
025051         THRU 5060-EDIT-TAXWH-RQST-X.
025051
025051     IF  WGLOB-RETURN-ERROR
025051         SET MIR-RETRN-RQST-FAILED  TO TRUE
025051         GO TO 3000-DTH-QUOTE-X
025051     END-IF.

           PERFORM  5100-GET-CLI-NM
               THRU 5100-GET-CLI-NM-X.

           MOVE RPOL-POL-INS-TYP-CD   TO MIR-POL-INS-TYP-CD.

           IF RPOL-POL-INS-TYP-SEG-FUND
           OR RPOL-POL-INS-TYP-FPA
              PERFORM  3100-PROCESS-DTH-QUOTE
                  THRU 3100-PROCESS-DTH-QUOTE-X
           END-IF.


       3000-DTH-QUOTE-X.
           EXIT.



      *----------------------
       3100-PROCESS-DTH-QUOTE.
      *----------------------

           IF  WS-CVG-NUM NOT = 0
               MOVE SPACE        TO MIR-POL-INS-TYP-CD
               IF  RPOL-POL-DBG
               AND WCVGS-CVG-DBG-INCL (WS-CVG-NUM)
      *MSG: COVERAGE IS INCLUDED IN DEATH BENEFIT GUARANTEE, CANNOT
      *     PROCESS DEATH QUOTE
                   MOVE 'CS73150008'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-RQST-FAILED  TO TRUE
               END-IF
               GO TO 3100-PROCESS-DTH-QUOTE-X
           END-IF.

027096     PERFORM  3205-CHK-CLI-DEATH-INFO
027096         THRU 3205-CHK-CLI-DEATH-INFO-X.
027096
           PERFORM  3200-CHK-ACTIVITY
               THRU 3200-CHK-ACTIVITY-X.


           PERFORM  3300-CAL-DBG
               THRU 3300-CAL-DBG-X.


           PERFORM  3400-CAL-CVG
               THRU 3400-CAL-CVG-X.


           PERFORM  3500-CAL-OTH-FINBAL
               THRU 3500-CAL-OTH-FINBAL-X.

023437     PERFORM  3600-CALC-TAX
023437         THRU 3600-CALC-TAX-X.
023437
           MOVE WS-POL-DTH-AMT        TO WS-POL-NET-DTH-AMT.
           ADD  WS-POL-OTHR-BAL-AMT   TO WS-POL-NET-DTH-AMT.

           IF RPOL-POL-DBG
              SET  WS-DTH-QUOT-YES    TO TRUE
           ELSE
              SET  WS-DTH-QUOT-NO     TO TRUE
           END-IF.

           PERFORM  8200-MOVE-OUTPUT-FIELDS
               THRU 8200-MOVE-OUTPUT-FIELDS-X.

       3100-PROCESS-DTH-QUOTE-X.
           EXIT.



      *------------------
       3200-CHK-ACTIVITY.
      *------------------

           IF  NOT RPOL-POL-STAT-IN-FORCE
      *MSG: POLICY IS NOT IN-FORCE
               MOVE 'CS73150001'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3200-CHK-ACTIVITY-X
           END-IF.

           IF  WS-EFF-DT < RPOL-POL-ISS-EFF-DT
      *MSG: QUOTE EFFECTIVE DATE MUST BE AFTER POLICY ISSUE DATE
               MOVE 'CS73150006'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3200-CHK-ACTIVITY-X
           END-IF.


           PERFORM  3210-CHK-DEFER-ACTV
               THRU 3210-CHK-DEFER-ACTV-X.

           PERFORM  3220-CHK-UNDO-ACTV
               THRU 3220-CHK-UNDO-ACTV-X.

           PERFORM  3230-CHK-REDO-ACTV
               THRU 3230-CHK-REDO-ACTV-X.


       3200-CHK-ACTIVITY-X.
           EXIT.


027096*----------------------
027096 3205-CHK-CLI-DEATH-INFO.
027096*----------------------
027096
027096     MOVE WS-CVG-NUM                   TO I.
027096
027096     PERFORM  2430-1000-BUILD-PARM-INFO
027096         THRU 2430-1000-BUILD-PARM-INFO-X.
027096
027096     PERFORM  2430-3100-GET-PRIM-INSRD
027096         THRU 2430-3100-GET-PRIM-INSRD-X.
027096
027096     IF  NOT L2430-RELATIONSHIP-FOUND
027096         GO TO 3205-CHK-CLI-DEATH-INFO-X
027096     END-IF.
027096
027096     PERFORM  2435-1000-BUILD-PARM-INFO
027096         THRU 2435-1000-BUILD-PARM-INFO-X.
027096
027096     MOVE L2430-CLI-ID                  TO L2435-CLI-ID.
027096
027096     PERFORM  2435-1000-OBTAIN-CLI-INFO
027096         THRU 2435-1000-OBTAIN-CLI-INFO-X.
027096
027096     IF  L2435-CLI-DTH-DT = WWKDT-ZERO-DT
027096*MSG: CLIENT STATUS NOT DEFINED AS DEAD'
027096         MOVE 'CS73150014'              TO WGLOB-MSG-REF-INFO
027096         PERFORM  0260-1000-GENERATE-MESSAGE
027096             THRU 0260-1000-GENERATE-MESSAGE-X
027096         GO TO 3205-CHK-CLI-DEATH-INFO-X
027096     END-IF.
027096
027096     IF  L2435-CLI-DTH-DT NOT = WS-EFF-DT
027096*MSG: CLIENT DATE OF DEATH DATE IS DIFFERENT FROM THE
027096*     TERMINATION DATE
027096         MOVE 'CS73150015'              TO WGLOB-MSG-REF-INFO
027096         PERFORM  0260-1000-GENERATE-MESSAGE
027096             THRU 0260-1000-GENERATE-MESSAGE-X
027096         GO TO 3205-CHK-CLI-DEATH-INFO-X
027096     END-IF.
027096
027096 3205-CHK-CLI-DEATH-INFO-X.
027096     EXIT.
027096
027096
      *-------------------
       3210-CHK-DEFER-ACTV.
      *-------------------

           MOVE RPOL-POL-ID              TO WPOLS-POL-ID.
           MOVE 'D'                      TO WPOLS-POL-PAYO-STAT-CD.
           MOVE WWKDT-LOW-DT             TO WPOLS-POL-PAYO-NXT-DT.
           MOVE ZERO                     TO WPOLS-POL-PAYO-NUM.
           MOVE WPOLS-KEY                TO WPOLS-ENDBR-KEY.
           MOVE WS-EFF-DT                TO WPOLS-ENDBR-POL-PAYO-NXT-DT.
           MOVE +99999                   TO WPOLS-ENDBR-POL-PAYO-NUM.

           PERFORM POLS-1000-READ-MIN
              THRU POLS-1000-READ-MIN-X

           IF WPOLS-IO-NOT-FOUND
              GO TO 3210-CHK-DEFER-ACTV-X
           END-IF.


      *MSG: DEFERRED ACTIVITY EXISTS ON OR PRIOR TO EFFECTIVE DATE OF
      *     QUOTE. QUOTE VALUES DON'T INCLUDE DEFERRED ACTIVITY
           MOVE 'CS73150002'     TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3210-CHK-DEFER-ACTV-X.
           EXIT.



      *-------------------
       3220-CHK-UNDO-ACTV.
      *-------------------

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                 TO L4750-EFF-DT.
           SET  L4750-PRCES-EXCLUSIVE     TO TRUE.
           SET  L4750-FCN-DRVR-SECONDARY  TO TRUE.

           PERFORM  4750-2000-DTRMN-UNDO-PRCES
               THRU 4750-2000-DTRMN-UNDO-PRCES-X.


       3220-CHK-UNDO-ACTV-X.
           EXIT.


      *-------------------
       3230-CHK-REDO-ACTV.
      *-------------------

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.

           SET L4780-REDO-WARNING             TO TRUE.
           SET L4780-MSG-SUPPRESS             TO TRUE.
           MOVE WS-EFF-DT                     TO L4780-EFF-DT.
           MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE          TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           IF  L4780-RETRN-OK
           AND L4780-ACTIVITY-DUE
      *MSG: ACTIVITY DUE ON OR BEFORE EFFECTIVE DATE OF QUOTE. THIS IS
      *     NOT REFLECTED ON THE QUOTE
               MOVE 'CS73150003'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       3230-CHK-REDO-ACTV-X.
           EXIT.



      *------------
       3300-CAL-DBG.
      *------------

           IF  MIR-RETRN-RQST-FAILED
           OR  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3300-CAL-DBG-X
           END-IF.

           IF  RPOL-POL-DBG-NO
           OR  L7306-POL-DBG-BASIC-CSV
               PERFORM  3370-CAL-DBG-CSV
                   THRU 3370-CAL-DBG-CSV-X
               GO TO 3300-CAL-DBG-X
           END-IF.

           PERFORM  3390-CAL-ACUM-VALU
               THRU 3390-CAL-ACUM-VALU-X.

           PERFORM  3310-CAL-DBG-BASIC
               THRU 3310-CAL-DBG-BASIC-X.

           PERFORM  3320-CAL-DBG-LOCKIN-RESET
               THRU 3320-CAL-DBG-LOCKIN-RESET-X.

           PERFORM  3330-CAL-DBG-ANNV-VALU
               THRU 3330-CAL-DBG-ANNV-VALU-X.

           PERFORM  3340-CAL-DBG-MAV
               THRU 3340-CAL-DBG-MAV-X.

           PERFORM  3350-CAL-DBG-ROLLUP
               THRU 3350-CAL-DBG-ROLLUP-X.

           PERFORM  3360-CAL-DBG-AMT
               THRU 3360-CAL-DBG-AMT-X.

           PERFORM  3395-CAL-POL-CSV
               THRU 3395-CAL-POL-CSV-X.

       3300-CAL-DBG-X.
           EXIT.



      *------------------
       3310-CAL-DBG-BASIC.
      *------------------

           IF L7306-POL-DBG-BASIC-NONE
           OR L7306-POL-DBG-BASIC-CSV
              GO TO 3310-CAL-DBG-BASIC-X
           END-IF.

           PERFORM  0317-1000-BUILD-PARM-INFO
               THRU 0317-1000-BUILD-PARM-INFO-X.

           SET  L0317-PCALC-EXIT-DBG-RETRN TO TRUE.
023805*    MOVE RPOL-PLAN-ID               TO L0317-PLAN-ID.
023805     MOVE WCVGS-PLAN-ID (RPOL-POL-BASE-CVG-NUM)
023805                                     TO L0317-PLAN-ID.

           PERFORM  0317-1000-GET-PCALC-EXIT-PGM
               THRU 0317-1000-GET-PCALC-EXIT-PGM-X.

           EVALUATE TRUE

               WHEN L0317-RETRN-NOT-FOUND
               WHEN L0317-RETRN-PX-DISABLE
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3310-CAL-DBG-BASIC-X

               WHEN L0317-PCALC-EXIT-STAT-INTRNL
      * MSG: INTERNAL CALCULATION DOESNOT EXIST
                    MOVE 'CS73150005'           TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3310-CAL-DBG-BASIC-X

               WHEN L0317-PCALC-EXIT-STAT-XTRNL
                    CONTINUE

           END-EVALUATE.

           PERFORM  DGBA-1000-BUILD-PARM-INFO
               THRU DGBA-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT            TO LDGBA-EFF-DT.
023805     MOVE WS-DBG-ACUM-AMT      TO LDGBA-DBG-ACUM-VALU-AMT.
           PERFORM  DGBA-1000-CALC-DBG-VALU
               THRU DGBA-1000-CALC-DBG-VALU-X.

           IF LDGBA-RETRN-OK
              MOVE LDGBA-DBG-GUAR-VALU-AMT TO WS-DBG-BASIC-AMT
           ELSE
               SET MIR-RETRN-RQST-FAILED  TO TRUE
           END-IF.

       3310-CAL-DBG-BASIC-X.
           EXIT.


      *-------------------------
       3320-CAL-DBG-LOCKIN-RESET.
      *-------------------------

           IF  L7306-POL-DBG-RESET-NONE
               GO TO 3320-CAL-DBG-LOCKIN-RESET-X
           END-IF.


           PERFORM  0317-1000-BUILD-PARM-INFO
               THRU 0317-1000-BUILD-PARM-INFO-X.

           SET  L0317-PCALC-EXIT-DBG-LOCK  TO TRUE.
023805*    MOVE RPOL-PLAN-ID               TO L0317-PLAN-ID.
023805     MOVE WCVGS-PLAN-ID (RPOL-POL-BASE-CVG-NUM)
023805                                     TO L0317-PLAN-ID.

           PERFORM  0317-1000-GET-PCALC-EXIT-PGM
               THRU 0317-1000-GET-PCALC-EXIT-PGM-X.

           EVALUATE TRUE

               WHEN L0317-RETRN-NOT-FOUND
               WHEN L0317-RETRN-PX-DISABLE
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3320-CAL-DBG-LOCKIN-RESET-X

               WHEN L0317-PCALC-EXIT-STAT-INTRNL
      * MSG: INTERNAL CALCULATION DOESNOT EXIST
                    MOVE 'CS73150005'           TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3320-CAL-DBG-LOCKIN-RESET-X

               WHEN L0317-PCALC-EXIT-STAT-XTRNL
                    CONTINUE

           END-EVALUATE.

           PERFORM  DGLK-1000-BUILD-PARM-INFO
               THRU DGLK-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT            TO LDGLK-EFF-DT.
023805     MOVE WS-DBG-ACUM-AMT      TO LDGLK-DBG-ACUM-VALU-AMT.

           PERFORM  DGLK-1000-CALC-DBG-VALU
               THRU DGLK-1000-CALC-DBG-VALU-X.

027445*    IF LDGRS-RETRN-OK
027445     IF LDGLK-RETRN-OK
              MOVE LDGLK-DBG-GUAR-VALU-AMT TO WS-LOCK-RESET-AMT
           ELSE
               SET MIR-RETRN-RQST-FAILED  TO TRUE
           END-IF.

       3320-CAL-DBG-LOCKIN-RESET-X.
           EXIT.


      *----------------------
       3330-CAL-DBG-ANNV-VALU.
      *----------------------

           IF  L7306-POL-DBG-ANNV-VALU-NONE
               GO TO 3330-CAL-DBG-ANNV-VALU-X
           END-IF.


           PERFORM  0317-1000-BUILD-PARM-INFO
               THRU 0317-1000-BUILD-PARM-INFO-X.

           SET  L0317-PCALC-EXIT-DBG-ANNV-VALU TO TRUE.
023805*    MOVE RPOL-PLAN-ID               TO L0317-PLAN-ID.
023805     MOVE WCVGS-PLAN-ID (RPOL-POL-BASE-CVG-NUM)
023805                                     TO L0317-PLAN-ID.

           PERFORM  0317-1000-GET-PCALC-EXIT-PGM
               THRU 0317-1000-GET-PCALC-EXIT-PGM-X.

           EVALUATE TRUE

               WHEN L0317-RETRN-NOT-FOUND
               WHEN L0317-RETRN-PX-DISABLE
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3330-CAL-DBG-ANNV-VALU-X

               WHEN L0317-PCALC-EXIT-STAT-INTRNL
      * MSG: INTERNAL CALCULATION DOESNOT EXIST
                    MOVE 'CS73150005'           TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3330-CAL-DBG-ANNV-VALU-X

               WHEN L0317-PCALC-EXIT-STAT-XTRNL
                    CONTINUE

           END-EVALUATE.

           PERFORM  DGRS-1000-BUILD-PARM-INFO
               THRU DGRS-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT             TO LDGRS-EFF-DT.
023805     MOVE WS-DBG-ACUM-AMT       TO LDGRS-DBG-ACUM-VALU-AMT.

           PERFORM  DGRS-1000-CALC-DBG-VALU
               THRU DGRS-1000-CALC-DBG-VALU-X.

           IF LDGRS-RETRN-OK
              MOVE LDGRS-DBG-GUAR-VALU-AMT TO WS-ANNV-VALU-AMT
           ELSE
               SET MIR-RETRN-RQST-FAILED  TO TRUE
           END-IF.

       3330-CAL-DBG-ANNV-VALU-X.
           EXIT.


      *----------------
       3340-CAL-DBG-MAV.
      *----------------

           IF  L7306-POL-DBG-MAV-NONE
               GO TO 3340-CAL-DBG-MAV-X
           END-IF.


           PERFORM  0317-1000-BUILD-PARM-INFO
               THRU 0317-1000-BUILD-PARM-INFO-X.

           SET  L0317-PCALC-EXIT-DBG-MAV   TO TRUE.
023805*    MOVE RPOL-PLAN-ID               TO L0317-PLAN-ID.
023805     MOVE WCVGS-PLAN-ID (RPOL-POL-BASE-CVG-NUM)
023805                                     TO L0317-PLAN-ID.

           PERFORM  0317-1000-GET-PCALC-EXIT-PGM
               THRU 0317-1000-GET-PCALC-EXIT-PGM-X.

           EVALUATE TRUE

               WHEN L0317-RETRN-NOT-FOUND
               WHEN L0317-RETRN-PX-DISABLE
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3340-CAL-DBG-MAV-X

               WHEN L0317-PCALC-EXIT-STAT-INTRNL
      * MSG: INTERNAL CALCULATION DOESNOT EXIST
                    MOVE 'CS73150005'           TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3340-CAL-DBG-MAV-X

               WHEN L0317-PCALC-EXIT-STAT-XTRNL
                    CONTINUE

           END-EVALUATE.

           PERFORM  DGMV-1000-BUILD-PARM-INFO
               THRU DGMV-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT            TO LDGMV-EFF-DT.
023805     MOVE WS-DBG-ACUM-AMT      TO LDGMV-DBG-ACUM-VALU-AMT.

           PERFORM  DGMV-1000-CALC-DBG-VALU
               THRU DGMV-1000-CALC-DBG-VALU-X.

           IF LDGMV-RETRN-OK
              MOVE LDGMV-DBG-GUAR-VALU-AMT TO WS-MAV-AMT
           ELSE
               SET MIR-RETRN-RQST-FAILED  TO TRUE
           END-IF.

       3340-CAL-DBG-MAV-X.
           EXIT.


      *-------------------
       3350-CAL-DBG-ROLLUP.
      *-------------------

           IF  L7306-POL-DBG-ROLU-NONE
               GO TO 3350-CAL-DBG-ROLLUP-X
           END-IF.


           PERFORM  0317-1000-BUILD-PARM-INFO
               THRU 0317-1000-BUILD-PARM-INFO-X.

           SET  L0317-PCALC-EXIT-DBG-ROLU  TO TRUE.
023805*    MOVE RPOL-PLAN-ID               TO L0317-PLAN-ID.
023805     MOVE WCVGS-PLAN-ID (RPOL-POL-BASE-CVG-NUM)
023805                                     TO L0317-PLAN-ID.

           PERFORM  0317-1000-GET-PCALC-EXIT-PGM
               THRU 0317-1000-GET-PCALC-EXIT-PGM-X.

           EVALUATE TRUE

               WHEN L0317-RETRN-NOT-FOUND
               WHEN L0317-RETRN-PX-DISABLE
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3350-CAL-DBG-ROLLUP-X

               WHEN L0317-PCALC-EXIT-STAT-INTRNL
      * MSG: INTERNAL CALCULATION DOESNOT EXIST
                    MOVE 'CS73150005'           TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-RQST-FAILED  TO TRUE
                    GO TO 3350-CAL-DBG-ROLLUP-X

               WHEN L0317-PCALC-EXIT-STAT-XTRNL
                    CONTINUE

           END-EVALUATE.

           PERFORM  DGRU-1000-BUILD-PARM-INFO
               THRU DGRU-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT              TO LDGRU-EFF-DT.
023805     MOVE WS-DBG-ACUM-AMT        TO LDGRU-DBG-ACUM-VALU-AMT.

           PERFORM  DGRU-1000-CALC-DBG-VALU
               THRU DGRU-1000-CALC-DBG-VALU-X.

           IF LDGRU-RETRN-OK
              MOVE LDGRU-DBG-GUAR-VALU-AMT TO WS-ROLLUP-AMT
           ELSE
               SET MIR-RETRN-RQST-FAILED  TO TRUE
           END-IF.

       3350-CAL-DBG-ROLLUP-X.
           EXIT.


      *----------------
       3360-CAL-DBG-AMT.
      *----------------

           MOVE ZERO               TO WS-POL-DTH-AMT.

           PERFORM
                 VARYING WS-SUB FROM 1 BY 1
                   UNTIL   WS-SUB > 5

               IF  WS-DBG-AMT (WS-SUB) > WS-POL-DTH-AMT
                   MOVE WS-DBG-AMT (WS-SUB) TO WS-POL-DTH-AMT
               END-IF

           END-PERFORM.


           IF WS-DBG-ACUM-AMT > WS-POL-DTH-AMT
              MOVE WS-DBG-ACUM-AMT TO WS-POL-DTH-AMT
023444        COMPUTE WS-BENEFIT-AMOUNT = WS-BENEFIT-AMOUNT
023444                                  + WS-DBG-ACUM-AMT
023444                                  - WS-POL-DTH-AMT
           END-IF.


       3360-CAL-DBG-AMT-X.
           EXIT.



      *----------------
       3370-CAL-DBG-CSV.
      *----------------

           PERFORM  3395-CAL-POL-CSV
               THRU 3395-CAL-POL-CSV-X.

           MOVE L0182-POL-ACUM-VALU-AMT  TO WS-DBG-ACUM-AMT.
           ADD  L0182-SIDFND-AFV-AMT     TO WS-DBG-ACUM-AMT.

           IF L7306-POL-DBG-BASIC-CSV
              MOVE L0182-POL-CSV-AMT     TO WS-POL-DTH-AMT
              ADD  L0182-SIDFND-AFV-AMT  TO WS-POL-DTH-AMT
              SUBTRACT L0182-SIDFND-SURR-CHRG-AMT
                                         FROM WS-POL-DTH-AMT
              MOVE WS-POL-DTH-AMT        TO WS-DBG-BASIC-CSV-AMT
           END-IF.

       3370-CAL-DBG-CSV-X.
           EXIT.


      *------------------
       3390-CAL-ACUM-VALU.
      *------------------

           PERFORM  0182-1000-BUILD-PARM-INFO
               THRU 0182-1000-BUILD-PARM-INFO-X.

           SET  L0182-CALC-DBG-AFV-YES TO TRUE.
           MOVE WS-EFF-DT              TO L0182-EFF-DT.

           PERFORM  0182-1000-CALC-CSV-POL
               THRU 0182-1000-CALC-CSV-POL-X

           IF  NOT L0182-RETRN-OK
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3390-CAL-ACUM-VALU-X
           END-IF.

           MOVE L0182-POL-ACUM-VALU-AMT  TO WS-DBG-ACUM-AMT.
           ADD  L0182-SIDFND-AFV-AMT     TO WS-DBG-ACUM-AMT.
           IF  RPOL-POL-DBG-LOAN
               SUBTRACT L0182-LOAN-AMT(1) FROM WS-DBG-ACUM-AMT
               SUBTRACT L0182-LOAN-ACRU-INT-AMT (1)
                                          FROM WS-DBG-ACUM-AMT
           END-IF.

       3390-CAL-ACUM-VALU-X.
           EXIT.



      *----------------
       3395-CAL-POL-CSV.
      *----------------

           PERFORM  0182-1000-BUILD-PARM-INFO
               THRU 0182-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT            TO L0182-EFF-DT.
           SET L0182-CALC-LOAN-CSV   TO TRUE.
           SET L0182-CALC-POLI       TO TRUE.

           PERFORM  0182-1000-CALC-CSV-POL
               THRU 0182-1000-CALC-CSV-POL-X.

           IF  NOT L0182-RETRN-OK
               SET MIR-RETRN-RQST-FAILED  TO TRUE
           END-IF.

       3395-CAL-POL-CSV-X.
           EXIT.


      *------------
       3400-CAL-CVG.
      *------------

           IF  MIR-RETRN-RQST-FAILED
           OR  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3400-CAL-CVG-X
           END-IF.

           IF  RPOL-POL-DBG
           AND L7306-POL-DBG-BASIC-CSV
               GO TO 3400-CAL-CVG-X
           END-IF.


           MOVE ZERO              TO WS-SUB.

           PERFORM  3410-CAL-CVG-VALU
               THRU 3410-CAL-CVG-VALU-X
               VARYING I FROM 1 BY 1
               UNTIL   I > RPOL-POL-CVG-REC-CTR-N.

           MOVE WS-SUB            TO WS-CVG-CTR.

           PERFORM
                 VARYING I FROM 1 BY 1
                   UNTIL   I > WS-CVG-CTR

                   ADD WS-CVG-DTH-AMT (I) TO WS-POL-DTH-AMT

           END-PERFORM.


       3400-CAL-CVG-X.
           EXIT.



      *-----------------
       3410-CAL-CVG-VALU.
      *-----------------

           IF  RPOL-POL-DBG
           AND WCVGS-CVG-DBG-INCL (I)
               GO TO 3410-CAL-CVG-VALU-X
           END-IF.


           ADD  1                       TO WS-SUB.
           MOVE I                       TO WS-CVG-NUM-T (WS-SUB).
           MOVE WCVGS-PLAN-ID (I)       TO WS-PLAN-ID (WS-SUB).
           MOVE L0182-CVG-ACUM-VALU-AMT (I) TO WS-CVG-DTH-AMT (WS-SUB).


           PERFORM  3420-CHECK-MCV
               THRU 3420-CHECK-MCV-X.


           PERFORM  3430-CHECK-GUAR-VALU
               THRU 3430-CHECK-GUAR-VALU-X.


       3410-CAL-CVG-VALU-X.
           EXIT.


      *--------------
       3420-CHECK-MCV.
      *--------------
      *
      * CHECK FOR MCV
      *

           IF  NOT L0182-MCV-CALC-REQIR (I)
               GO TO 3420-CHECK-MCV-X
           END-IF.

           IF  L0182-CVG-ACUM-MCV-AMT (I) > ZERO
           AND L0182-POL-MAX-MCV-ACUM-AMT NOT = L0182-POL-ACUM-VALU-AMT
               MOVE L0182-CVG-ACUM-MCV-AMT (I)
                                        TO WS-CVG-DTH-AMT (WS-SUB)
           END-IF.

       3420-CHECK-MCV-X.
           EXIT.


      *--------------------
       3430-CHECK-GUAR-VALU.
      *--------------------

           IF NOT WCVGS-CVG-INS-TYP-SEG-FUND (I)
               GO TO 3430-CHECK-GUAR-VALU-X
           END-IF.

      *
      * CHECK FOR SEG FUND GUARANTEE VALUE
      *
           MOVE WCVGS-PLAN-ID (I)      TO WFX-PLAN-ID.
           PERFORM  FX-1000-READ
               THRU FX-1000-READ-X.
           IF NOT WFX-IO-OK
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WFX-PLAN-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'FX'             TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3430-CHECK-GUAR-VALU-X
           END-IF.


           IF RFX-GUAR-VALU-CALC-CD = 'N'
              GO TO 3430-CHECK-GUAR-VALU-X
           END-IF.

      *
      * READ MOST RECENT FA FOR LTD PAYMENT AND SURRENDER TOTAL
      *
           MOVE RPOL-POL-ID               TO WFA-POL-ID.
           MOVE I                         TO WFA-CVG-NUM-N.
           MOVE WS-EFF-DT                 TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE       TO WFA-CIA-IDT-NUM-N.
           MOVE ZEROS                     TO WFA-CIA-SEQ-NUM.
           MOVE WFA-KEY                   TO WFA-ENDBR-KEY.
           MOVE HIGH-VALUES               TO WFA-ENDBR-CIA-IDT-NUM.
           MOVE +999                      TO WFA-ENDBR-CIA-SEQ-NUM.

           PERFORM FA-1000-BROWSE
              THRU FA-1000-BROWSE-X.

           PERFORM FA-2000-READ-NEXT
              THRU FA-2000-READ-NEXT-X.

           IF NOT WFA-IO-OK
               PERFORM  FA-3000-END-BROWSE
                   THRU FA-3000-END-BROWSE-X
               GO TO 3430-CHECK-GUAR-VALU-X
           END-IF.

           PERFORM  FA-3000-END-BROWSE
               THRU FA-3000-END-BROWSE-X.


           MOVE ZERO                 TO L0279-CRCY-AMT.

           EVALUATE RFX-GUAR-VALU-CALC-CD

               WHEN 'A'
                    COMPUTE L0279-CRCY-AMT =
                                       (RFA-CVG-PMT-LTD-AMT -
                                        RFA-CVG-SURR-LTD-AMT) *
                                        RFX-DTH-GUAR-VALU-PCT / 100

               WHEN 'B'
                    COMPUTE L0279-CRCY-AMT =
                                        RFA-CVG-PMT-LTD-AMT *
                                        RFX-DTH-GUAR-VALU-PCT / 100 -
                                        RFA-CVG-SURR-LTD-AMT

               WHEN 'C'
                    COMPUTE L0279-CRCY-AMT =
                                        RFA-CVG-GUAR-VALU-AMT *
                                        RFX-DTH-GUAR-VALU-PCT / 100

           END-EVALUATE.

           PERFORM  0279-1000-CRCY-RND
               THRU 0279-1000-CRCY-RND-X.

           MOVE L0279-CRCY-AMT     TO WS-SEG-FND-GUAR-VALU-AMT.


           IF WS-SEG-FND-GUAR-VALU-AMT > WS-CVG-DTH-AMT (WS-SUB)
              MOVE WS-SEG-FND-GUAR-VALU-AMT TO WS-CVG-DTH-AMT (WS-SUB)
           END-IF.


       3430-CHECK-GUAR-VALU-X.
           EXIT.



      *-------------------
       3500-CAL-OTH-FINBAL.
      *-------------------

           IF  MIR-RETRN-RQST-FAILED
           OR  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3500-CAL-OTH-FINBAL-X
           END-IF.

           MOVE L0182-POL-TOT-CASH-LOAN-AMT
                                         TO WS-POL-CSH-LOAN-AMT.
           MOVE L0182-SIDFND-AFV-AMT     TO WS-POL-SIDFND-AFV-AMT.

           MOVE RPOL-POL-MISC-SUSP-AMT   TO WS-POL-MISC-SUSP-AMT.
           MOVE RPOL-POL-PREM-SUSP-AMT   TO WS-POL-PREM-SUSP-AMT.
           MOVE RPOL-POL-OS-DISB-AMT     TO WS-POL-OS-DISB-AMT.
           MOVE RPOL-POL-PDF-AMT         TO WS-POL-PDF-AMT.
           ADD  L0182-POL-PDF-ACRU-INT-AMT TO WS-POL-PDF-AMT.

           COMPUTE WS-POL-OTHR-BAL-AMT = WS-POL-MISC-SUSP-AMT
                                       + WS-POL-PREM-SUSP-AMT
                                       + WS-POL-OS-DISB-AMT
                                       + WS-POL-PDF-AMT.

           IF  RPOL-POL-DBG
           AND RPOL-POL-DBG-LOAN
               CONTINUE
           ELSE
               COMPUTE WS-POL-OTHR-BAL-AMT = WS-POL-OTHR-BAL-AMT
                                           - WS-POL-CSH-LOAN-AMT
           END-IF.


           IF  RPOL-POL-DBG
           AND L7306-POL-DBG-BASIC-CSV
               COMPUTE WS-POL-OTHR-BAL-AMT = WS-POL-MISC-SUSP-AMT
                                           + WS-POL-PREM-SUSP-AMT
                                           + WS-POL-OS-DISB-AMT
           END-IF.


       3500-CAL-OTH-FINBAL-X.
           EXIT.


023437*----------------------------
023437 3600-CALC-TAX.
023437*----------------------------
023437
023444     PERFORM  0182-1000-BUILD-PARM-INFO
023444         THRU 0182-1000-BUILD-PARM-INFO-X.
023444     MOVE WS-EFF-DT           TO L0182-EFF-DT.
023444     SET  L0182-CALC-SUM-INS  TO TRUE.
023444     SET  L0182-CALC-RESERVE  TO TRUE.
031034*    SET  L0182-INTRM-DTH-CALC   TO TRUE.
023444
023444
023444     MOVE 'N' TO L0182-TRMNL-DIV-CALC-IND.
023444
023444     PERFORM  0182-1000-CALC-CSV-POL
023444         THRU 0182-1000-CALC-CSV-POL-X.
023444
023444     IF  NOT L0182-RETRN-OK
023444         SET MIR-RETRN-RQST-FAILED  TO TRUE
023444         GO TO 3600-CALC-TAX-X
023444     END-IF.
023444
023444     IF WS-CVG-NUM = ZEROS
031034*       MOVE L0182-POL-SURR-CHRG-AMT  TO WS-POL-SURR-CHRG-AMT
023437         SET WS-FLEX-INS-NO      TO TRUE
023437         PERFORM
023437             VARYING JJ FROM RPOL-POL-CVG-REC-CTR-N BY -1
023437             UNTIL JJ < 1
023437             IF  WCVGS-CVG-INS-TYP-FLEXIBLE (JJ)
023437                 SET WS-FLEX-INS         TO TRUE
023437             END-IF
023437         END-PERFORM
031034*    ELSE
031034*       MOVE L0182-CVG-SURR-CHRG-AMT (WS-CVG-NUM)
031034*                                     TO WS-POL-SURR-CHRG-AMT
023444     END-IF.
023444
023444     IF  WS-CVG-NUM = ZEROS
023437         IF  WS-FLEX-INS
023437             PERFORM  3610-CALC-MCV-AMT
023437                 THRU 3610-CALC-MCV-AMT-X
023437             IF L0182-POL-MAX-MCV-BASE-AMT <
023437                L0182-POL-ACUM-VALU-AMT
023437                MOVE ZEROS          TO WS-TRXN-MCV-OFFSET
023437             END-IF
023437         END-IF
023437     ELSE
023437         IF  WCVGS-CVG-INS-TYP-FLEXIBLE (WS-CVG-NUM)
023437             PERFORM  3610-CALC-MCV-AMT
023437                 THRU 3610-CALC-MCV-AMT-X
023437             IF (L0182-CVG-ACUM-MCV-AMT (WS-CVG-NUM)  <
023437                 L0182-CVG-ACUM-VALU-AMT (WS-CVG-NUM))
023437                MOVE ZEROS              TO WS-TRXN-MCV-OFFSET
023437             END-IF
023437         END-IF
023437     END-IF.
023444
023444     MOVE ZERO                      TO WS-BENEFIT-AMOUNT.
023444     IF  WS-CVG-NUM = ZEROS
023444         PERFORM  3620-DEATH-BENEFIT
023444             THRU 3620-DEATH-BENEFIT-X
023444             VARYING I FROM RPOL-POL-CVG-REC-CTR-N BY -1
023444             UNTIL I < 1
023444     ELSE
023444         MOVE WS-CVG-NUM          TO I
023444         PERFORM  3620-DEATH-BENEFIT
023444             THRU 3620-DEATH-BENEFIT-X
023444     END-IF.
023444
023444     IF  WS-CVG-NUM = ZEROS
023444          COMPUTE WS-DV-GRS-DSTRB-AMT = WS-BENEFIT-AMOUNT
023444                                      + L0182-POL-MPREM-RFND-AMT
023444                                      + RPOL-PUA-LTD-FACE-AMT
023444     ELSE
023444          COMPUTE WS-DV-GRS-DSTRB-AMT = WS-BENEFIT-AMOUNT
023444                                      + L0182-POL-MPREM-RFND-AMT
023444     END-IF.
023444
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE RPOL-POL-ID                 TO  L7800-POL-ID.
031034*    MOVE WS-EFF-DT                   TO  L7800-EFF-DT.
031034*    SET  L7800-GET-PLAR-REQ          TO  TRUE.
031034*    SET L7800-PRCES-NORMAL           TO  TRUE.
031034*    SET L7800-TRXN-POL-TRMN          TO  TRUE.
031034*
031034*    PERFORM  7800-1000-GET-PLAR-INFO
031034*        THRU 7800-1000-GET-PLAR-INFO-X.
031034*
031034*    IF  NOT L7800-RETRN-OK
031034*        SET MIR-RETRN-RQST-FAILED        TO  TRUE
031034*        GO TO 3600-CALC-TAX-X
031034*    ELSE
031034*        MOVE L7800-PLAR-REC-SW       TO  WS-PLAR-REC-SW
031034*        PERFORM
031034*           VARYING  JJ FROM +1 BY +1
031034*           UNTIL JJ > LPGAL-MAX-ALLOC-TYP
031034*           MOVE L7800-PGAL-ALLOC-TYP-CD (JJ)
031034*             TO LPGAL-PGAL-ALLOC-TYP-CD (JJ)
031034*        END-PERFORM
031034*    END-IF.
031034*
031034*    IF  WS-CVG-NUM = ZEROS
031034*    AND WS-PLAR-REC-FOUND
031034*        PERFORM  8400-CALC-OPEN-BAL
031034*            THRU 8400-CALC-OPEN-BAL-X
031034*        PERFORM  8600-DISB-TRMN-AMT
031034*            THRU 8600-DISB-TRMN-AMT-X
031034*    END-IF.
031034*
031034*    PERFORM  0187-1000-BUILD-PARM-INFO
031034*        THRU 0187-1000-BUILD-PARM-INFO-X.
031034*
031034*    SET L0187-PRCES-TYP-EDIT-ONLY  TO TRUE.
031034*    SET L0187-EVNT-TRMN-DEATH      TO TRUE.
031034*    MOVE WS-EFF-DT                 TO L0187-EFF-DT.
031034*    MOVE MIR-CVG-NUM               TO I.
031034*    MOVE I                         TO WS-CVG-NUM.
031034*
031034*    PERFORM  3640-SETUP-0187-PGAL
031034*        THRU 3640-SETUP-0187-PGAL-X.
031034*
031034*    IF  WS-PRCES-LIFE
031034*        IF  WS-CVG-NUM = ZEROS
031034*            COMPUTE  L0187-TRMN-AMT = WS-DV-GRS-DSTRB-AMT
031034*                                    - WS-BENEFIT-AMOUNT
031034*                                    + L0182-POL-BASE-CV-AMT
031034*                                    - L0182-POL-MPREM-RFND-AMT
031034*        ELSE
031034*            MOVE MIR-CVG-NUM        TO WS-CVG-NUM
031034*            COMPUTE  L0187-TRMN-AMT = WS-DV-GRS-DSTRB-AMT
031034*                                    - WS-BENEFIT-AMOUNT
031034*                                    + L0182-CVG-CV-AMT
031034*                                      (WS-CVG-NUM)
031034*                                    - L0182-POL-MPREM-RFND-AMT
031034*        END-IF
031034*    ELSE
031034*        MOVE WS-DV-GRS-DSTRB-AMT    TO L0187-TRMN-AMT
031034*    END-IF.
031034*
031034*    IF L0187-TRMN-AMT < 0
031034*       MOVE ZERO                    TO L0187-TRMN-AMT
031034*    END-IF
031034*
031034*    IF  WS-CVG-NUM = ZEROS
031034*        MOVE L0182-POL-SURR-CHRG-AMT   TO L0187-CHRG-AMT
031034*        PERFORM  0187-7500-POL-TRMN
031034*            THRU 0187-7500-POL-TRMN-X
031034*    ELSE
031034*        MOVE L0182-CVG-SURR-CHRG-AMT (WS-CVG-NUM)
031034*          TO L0187-CHRG-AMT
031034*        MOVE WCVGS-CVG-FACE-AMT (L0187-CVG) TO L0187-FACE-AMT
031034*        PERFORM  0187-8000-CVG-TRMN
031034*            THRU 0187-8000-CVG-TRMN-X
031034*    END-IF.
031034*
031034*    MOVE L0187-TAX-ACB           TO WS-DV-POL-TAX-ACB-AMT.
031034*    MOVE L0187-TAXBL-PORTN-AMT   TO WS-DV-TAXBL-GRS-DSTRB-AMT.
031034*    MOVE L0187-FED-TAXWH-AMT     TO WS-CDA-FED-TAXWH-AMT.
031034*    MOVE L0187-LTAXWH-FLAT-AMT   TO WS-LTAXWH-FLAT-AMT.
031034
031034     PERFORM  5382-1000-BUILD-PARM-INFO
031034         THRU 5382-1000-BUILD-PARM-INFO-X.
031034
031034     MOVE WBTAX-BYPASS-TAX-IND    TO L5382-WBTAX-BYPASS-TAX-IND.
031034     MOVE WBTAX-BYPASS-LTAX-IND   TO L5382-WBTAX-BYPASS-LTAX-IND.
031034     SET L5382-TERM-TYP-DEATH-QUOT  TO TRUE.
031034     SET L5382-PRCES-TYP-EDIT-ONLY  TO TRUE.
031034     SET L5382-0182-INFO-PROVIDED   TO TRUE.
031034     MOVE WS-EFF-DT                 TO L5382-EFF-DT.
031034     MOVE WS-CVG-NUM                TO L5382-CVG-NUM.
031034     IF  WS-CVG-NUM = ZEROS
031034         SET L5382-PRCES-LEVEL-POLICY   TO TRUE
031034     ELSE
031034         SET L5382-PRCES-LEVEL-CVG      TO TRUE
031034     END-IF.
031034     MOVE WS-DV-GRS-DSTRB-AMT       TO L5382-GRS-DSTRB-AMT.
031034     MOVE WS-BENEFIT-AMOUNT         TO L5382-BENEFIT-AMT.
031034     MOVE WS-LIFE-IND               TO L5382-PRCES-LIFE-IND.
031034
031034
031034     PERFORM  5382-3000-TERMINATE-PRCES
031034         THRU 5382-3000-TERMINATE-PRCES-X.
031034
031034     IF NOT L5382-RETRN-OK
031034        SET MIR-RETRN-RQST-FAILED   TO TRUE
031034     END-IF.
031034
031034     MOVE L5382-TAXBL-PORTN-AMT     TO WS-DV-TAXBL-GRS-DSTRB-AMT.
031034     MOVE L5382-TAX-ACB-AMT         TO WS-DV-POL-TAX-ACB-AMT.
029060*    MOVE L5382-FED-TAXWH-AMT       TO WS-CDA-FED-TAXWH-AMT.
029060*    MOVE L5382-LTAXWH-FLAT-AMT     TO WS-LTAXWH-FLAT-AMT.
029060     MOVE L5382-FTAXWH-AMT          TO WS-CDA-FED-TAXWH-AMT.
029060     MOVE L5382-LTAXWH-AMT          TO WS-LTAXWH-AMT.
023437
023437 3600-CALC-TAX-X.
023437     EXIT.
023437
023437*---------------------------
023437 3610-CALC-MCV-AMT.
023437*---------------------------
023437
023437     MOVE ZEROS              TO WS-TRXN-CV-AMT.
023437
023437     IF  WS-CVG-NUM = ZEROS
023437         IF (L0182-POL-MAX-MCV-BASE-AMT
023437          = (L0182-POL-BASE-CV-AMT
023437          -  L0182-POL-MTHV-ADJ-AMT))
023437             MOVE ZEROS            TO WS-TRXN-MCV-OFFSET
023437             GO TO 3610-CALC-MCV-AMT-X
023437         END-IF
023437         PERFORM
023437           VARYING JJ FROM +1 BY +1
023437           UNTIL JJ > RPOL-POL-CVG-REC-CTR-N
023437           IF  WCVGS-PLAN-FND-TYP-XTRNL (JJ)
023437               CONTINUE
023437           ELSE
023437               COMPUTE  WS-TRXN-CV-AMT
023437                     =  WS-TRXN-CV-AMT
023437                     +  L0182-CVG-CV-AMT (JJ)
023437           END-IF
023437         END-PERFORM
023437         IF  L0182-POL-MAX-MCV-BASE-AMT
023437         >  (WS-TRXN-CV-AMT
023437         +  L0182-POL-MTHV-ADJ-AMT)
023437             COMPUTE WS-TRXN-MCV-OFFSET
023437                   = L0182-POL-MAX-MCV-BASE-AMT
023437                   - WS-TRXN-CV-AMT
023437                   - L0182-POL-MTHV-ADJ-AMT
023437         ELSE
023437             MOVE ZEROS             TO WS-TRXN-CV-AMT
023437             MOVE ZEROS             TO WS-TRXN-MCV-OFFSET
023437         END-IF
023437     END-IF.
023437
023437     IF  WS-CVG-NUM NOT = ZEROS
023437           IF (L0182-POL-MAX-MCV-BASE-AMT
023437            = (L0182-POL-BASE-CV-AMT
023437            -  L0182-POL-MTHV-ADJ-AMT))
023437           OR  WCVGS-PLAN-FND-TYP-XTRNL (WS-CVG-NUM)
023437               MOVE ZEROS             TO WS-TRXN-MCV-OFFSET
023437           ELSE
023437               COMPUTE  WS-TRXN-CV-AMT
023437                     =  WS-TRXN-CV-AMT
023437                     +  L0182-CVG-CV-AMT (WS-CVG-NUM)
023437           END-IF
023437           IF  L0182-CVG-ACUM-MCV-AMT (WS-CVG-NUM)
023437            >  (WS-TRXN-CV-AMT
023437            +  L0182-POL-MTHV-ADJ-AMT)
023437               COMPUTE WS-TRXN-MCV-OFFSET
023437                   = L0182-CVG-ACUM-MCV-AMT (WS-CVG-NUM)
023437                   - WS-TRXN-CV-AMT
023437                   - L0182-POL-MTHV-ADJ-AMT
023437           ELSE
023437               MOVE ZEROS             TO WS-TRXN-CV-AMT
023437               MOVE ZEROS             TO WS-TRXN-MCV-OFFSET
023437           END-IF
023437     END-IF.
023437
023437 3610-CALC-MCV-AMT-X.
023437     EXIT.
023437
023444*-----------------------
023444 3620-DEATH-BENEFIT.
023444*-----------------------
023444
023444     PERFORM  PLIN-1000-PLAN-HEADER-IN
023444         THRU PLIN-1000-PLAN-HEADER-IN-X.
023444
023444     IF  NOT WCVGS-CVG-INS-TYP-SEG-FUND (I)
023444     AND NOT RPH-DB-CALC-NONE
023444     AND WCVGS-PLAN-FND-TYP-NONE (I)
023444
023444         EVALUATE TRUE
023444
023444             WHEN WCVGS-CVG-INS-TYP-FPA (I)
023444             WHEN WCVGS-CVG-INS-TYP-RRIF (I)
023444
023444                  IF  L0182-POL-MAX-MCV-ACUM-AMT
023444                    = L0182-POL-ACUM-VALU-AMT
023444                  OR  NOT L0182-MCV-CALC-REQIR (I)
023444                      ADD  L0182-CVG-ACUM-VALU-AMT (I)
023444                        TO WS-BENEFIT-AMOUNT
023444                  ELSE
023444                      ADD  L0182-CVG-ACUM-MCV-AMT (I)
023444                        TO WS-BENEFIT-AMOUNT
023444                  END-IF
023444                  IF  RPOL-POL-DBG
023444                  AND WCVGS-CVG-DBG-INCL (I)
023444                      ADD  L0182-CVG-ACUM-VALU-AMT (I)
023444                        TO WS-BENEFIT-AMOUNT
023444                  END-IF
023444
023444
023444             WHEN WCVGS-CVG-INS-TYP-DEFR-ANTY (I)
023444                  IF  L0182-POL-MAX-MCV-BASE-AMT
023444                    = L0182-POL-BASE-CV-AMT
023444                    - L0182-POL-MTHV-ADJ-AMT
023444                  OR  NOT L0182-MCV-CALC-REQIR (I)
023444                      ADD  L0182-CVG-CV-AMT (I)
023444                        TO WS-BENEFIT-AMOUNT
023444                  ELSE
023444                      ADD  L0182-CVG-ACUM-MCV-AMT (I)
023444                        TO WS-BENEFIT-AMOUNT
023444                  END-IF
023444                  IF  RPOL-POL-DBG
023444                  AND WCVGS-CVG-DBG-INCL (I)
023444                      ADD  L0182-CVG-CV-AMT (I)
023444                        TO WS-BENEFIT-AMOUNT
023444                  END-IF
023444
023444             WHEN OTHER
023444                  SET WS-PRCES-LIFE         TO TRUE
023444                  ADD  L0182-CVG-SUM-INS-AMT (I)   TO
023444                       WS-BENEFIT-AMOUNT
023444
023444         END-EVALUATE
023444
023444         GO TO 3620-DEATH-BENEFIT-X
023444
023444     END-IF.
023444
023444     IF  WCVGS-CVG-INS-TYP-SEG-FUND (I)
023444     AND NOT RPH-DB-CALC-NONE
023444     AND WCVGS-PLAN-FND-TYP-NONE (I)
023444         ADD L0182-CVG-ACUM-VALU-AMT (I)
023444          TO WS-BENEFIT-AMOUNT
023444         GO TO 3620-DEATH-BENEFIT-X
023444     END-IF.
023444
023444     IF  NOT WCVGS-CVG-INS-TYP-SEG-FUND (I)
023444     AND NOT WCVGS-CVG-INS-TYP-UL-INS-ANTY (I)
023444     AND NOT WCVGS-CVG-INS-TYP-FPA (I)
023444     AND WCVGS-PLAN-FND-TYP-XTRNL (I)
023444
023444         EVALUATE TRUE
023444
023444             WHEN WCVGS-CVG-INS-TYP-RRIF (I)
023444
023444                  ADD  L0182-CVG-ACUM-VALU-AMT (I)
023444                    TO WS-BENEFIT-AMOUNT
023444
023444             WHEN WCVGS-CVG-INS-TYP-DEFR-ANTY (I)
023444                  ADD  L0182-CVG-CV-AMT (I)
023444                    TO WS-BENEFIT-AMOUNT
023444
023444         END-EVALUATE
023444
023444         GO TO 3620-DEATH-BENEFIT-X
023444
023444     END-IF.
023444
023444 3620-DEATH-BENEFIT-X.
023444     EXIT.
023437/
031034*----------------------------
031034*3640-SETUP-0187-PGAL.
031034*----------------------------
031034*
031034*    MOVE LPGAL-PLAR-PRCES-SW            TO L0187-PLAR-PRCES-SW.
031034*    MOVE LPGAL-PGAL-ALLOC-SW            TO L0187-PGAL-ALLOC-SW.
031034*
031034*    IF  NOT LPGAL-PGAL-ALLOC-REQ
031034*        GO TO 3640-SETUP-0187-PGAL-X
031034*    END-IF.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM 1 BY 1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*            MOVE LPGAL-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*              TO L0187-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*            MOVE LPGAL-PGAL-OPN-PRIN-AMT  (LPGAL-SUB)
031034*              TO L0187-PGAL-OPN-PRIN-AMT  (LPGAL-SUB)
031034*            MOVE LPGAL-PGAL-OPN-GAIN-AMT  (LPGAL-SUB)
031034*              TO L0187-PGAL-OPN-GAIN-AMT  (LPGAL-SUB)
031034*            MOVE LPGAL-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*              TO L0187-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*            MOVE LPGAL-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*              TO L0187-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*            MOVE LPGAL-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*              TO L0187-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*            MOVE LPGAL-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*              TO L0187-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*            MOVE LPGAL-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*              TO L0187-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*3640-SETUP-0187-PGAL-X.
031034*    EXIT.
023437


025051*----------------------------
025051 5050-EDIT-LTAXWH-RQST.
025051*----------------------------
025051*
025051* LOCATION TAX WITHHOLDING DATA
025051*
025051
029060*   IF  MIR-LTAXWH-FLAT-AMT = SPACES
029060
029060     IF  MIR-LTAXWH-RQST-AMT = SPACES
025051         MOVE ZERO              TO WS-LTAXWH-FLAT-AMT
025051     ELSE
029060*        MOVE MIR-LTAXWH-FLAT-AMT
029060*                               TO L0280-INPUT-DATA
029060         MOVE MIR-LTAXWH-RQST-AMT
029060                                TO L0280-INPUT-DATA
025051         SET L0280-SIGN-NOT-PERMITTED
025051                                TO TRUE
025051         MOVE 13                TO L0280-LENGTH
025051         MOVE 2                 TO L0280-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                               TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                TO L0280-INPUT-SIZE
025051         PERFORM  0280-1000-NUMERIC-EDIT
025051             THRU 0280-1000-NUMERIC-EDIT-X
025051
025051         IF  L0280-OK
025051             MOVE L0280-OUTPUT-V02
025051                                TO WS-LTAXWH-FLAT-AMT
025051         ELSE
025051*MSG: INVALID LOCATION TAX REQUEST AMOUNT
025051             MOVE 'CS73150009'  TO WGLOB-MSG-REF-INFO
025051             PERFORM  0260-1000-GENERATE-MESSAGE
025051                 THRU 0260-1000-GENERATE-MESSAGE-X
025051             SET WGLOB-RETURN-ERROR
025051                                TO TRUE
025051         END-IF
025051     END-IF.
025051
029060*    IF  MIR-LTAXWH-PCT = SPACES
029060
029060     IF  MIR-LTAXWH-RQST-PCT = SPACES
025051         MOVE ZERO               TO WS-LTAXWH-PCT
025051     ELSE
029060*        MOVE MIR-LTAXWH-PCT     TO L0280-INPUT-DATA
029060         MOVE MIR-LTAXWH-RQST-PCT
029060                                 TO L0280-INPUT-DATA
025051         SET L0280-SIGN-NOT-PERMITTED
025051                                 TO TRUE
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                                TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                 TO L0280-INPUT-SIZE
025051         MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
025051         MOVE 2                  TO L0280-PRECISION
025051         PERFORM  0280-1000-NUMERIC-EDIT
025051             THRU 0280-1000-NUMERIC-EDIT-X
025051         IF  L0280-OK
025051             MOVE L0280-OUTPUT-V02
025051                                 TO WS-LTAXWH-PCT
025051         ELSE
025051*MSG: INVALID LOCATION TAX REQUEST PERCENT
025051             MOVE 'CS73150010'   TO WGLOB-MSG-REF-INFO
025051             PERFORM  0260-1000-GENERATE-MESSAGE
025051                 THRU 0260-1000-GENERATE-MESSAGE-X
025051             SET WGLOB-RETURN-ERROR
025051                                 TO TRUE
025051         END-IF
025051     END-IF.
025051
025051 5050-EDIT-LTAXWH-RQST-X.
025051     EXIT.
025051
025051*----------------------------
025051 5060-EDIT-TAXWH-RQST.
025051*----------------------------
025051*
025051* FEDERAL TAX REQUEST DATA
025051*
029060*    IF  MIR-FED-TAXWH-RQST-AMT = SPACES
029060
029060     IF  MIR-FTAXWH-RQST-AMT = SPACES
025051         MOVE ZERO               TO WS-FED-TAXWH-RQST-AMT
025051     ELSE
029060*        MOVE MIR-FED-TAXWH-RQST-AMT
029060*                                TO L0280-INPUT-DATA
029060         MOVE MIR-FTAXWH-RQST-AMT
029060                                 TO L0280-INPUT-DATA
025051         SET L0280-SIGN-NOT-PERMITTED
025051                                 TO TRUE
025051         MOVE 13                 TO L0280-LENGTH
025051         MOVE 2                  TO L0280-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                 TO L0280-INPUT-SIZE
025051         PERFORM  0280-1000-NUMERIC-EDIT
025051             THRU 0280-1000-NUMERIC-EDIT-X
025051
025051         IF  L0280-OK
025051             MOVE L0280-OUTPUT-V02
025051                                 TO WS-FED-TAXWH-RQST-AMT
025051         ELSE
025051*MSG: INVALID FEDERAL TAX REQUEST AMOUNT
025051             MOVE 'CS73150011'   TO WGLOB-MSG-REF-INFO
025051             PERFORM  0260-1000-GENERATE-MESSAGE
025051                 THRU 0260-1000-GENERATE-MESSAGE-X
025051             SET WGLOB-RETURN-ERROR
025051                                 TO TRUE
025051         END-IF
025051     END-IF.
025051
029060*   IF  MIR-FED-TAXWH-RQST-PCT = SPACES
029060
029060     IF  MIR-FTAXWH-RQST-PCT = SPACES
025051         MOVE ZERO               TO WS-FED-TAXWH-RQST-PCT
025051     ELSE
029060*        MOVE MIR-FED-TAXWH-RQST-PCT
029060*                                TO L0280-INPUT-DATA
029060         MOVE MIR-FTAXWH-RQST-PCT
029060                                 TO L0280-INPUT-DATA
025051         SET L0280-SIGN-NOT-PERMITTED
025051                                 TO TRUE
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                TO L0280-INPUT-SIZE
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                 TO L0280-INPUT-SIZE
025051         MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
025051         MOVE 2                  TO L0280-PRECISION
025051         PERFORM  0280-1000-NUMERIC-EDIT
025051             THRU 0280-1000-NUMERIC-EDIT-X
025051         IF  L0280-OK
025051             MOVE L0280-OUTPUT-V02
025051                                 TO WS-FED-TAXWH-RQST-PCT
025051         ELSE
025051*MSG: INVALID FEDERAL TAX REQUEST PERCENT
025051             MOVE 'CS73150012'   TO WGLOB-MSG-REF-INFO
025051             PERFORM  0260-1000-GENERATE-MESSAGE
025051                 THRU 0260-1000-GENERATE-MESSAGE-X
025051             SET WGLOB-RETURN-ERROR
025051                                 TO TRUE
025051         END-IF
025051     END-IF.
025051*
025051* CALL THE FEDERAL TAX EDIT REGIONAL EXIT FOR EDITS
025051*
025051     PERFORM  0316-1000-BUILD-PARM-INFO
025051         THRU 0316-1000-BUILD-PARM-INFO-X.
025051
025051     SET L0316-RGN-EXIT-TAXWH-CLI-EDITS
025051                                 TO TRUE.
025051
025051     MOVE RPOL-POL-CTRY-CD       TO L0316-CTRY-CD.
025051
025051     PERFORM  0316-1000-GET-RGN-EXIT-PGM
025051         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
025051
025051     IF  NOT L0316-RETRN-OK
025051     OR  L0316-RGN-EXIT-STAT-INACTV
025051*MSG: NO FEDERAL TAX REGIONAL EXIT FOUND FOR COUNTRY @1
025051         MOVE 'CS73150013'       TO WGLOB-MSG-REF-INFO
025051         MOVE L0316-CTRY-CD      TO WGLOB-MSG-PARM (1)
025051         PERFORM  0260-1000-GENERATE-MESSAGE
025051             THRU 0260-1000-GENERATE-MESSAGE-X
025051         MOVE +1                 TO  WGLOB-MSG-ERROR-SW
025051         GO TO 5060-EDIT-TAXWH-RQST-X
025051     END-IF
025051
025051* AN ACTIVE REGION EXIT IS HELD. THIS MUST BE PERFORMED FIRST TO
025051* CARRY OUT EDITS FOR FEDERAL TAX WITHHOLDING DATA.
025051
025051     PERFORM  TAXC-1000-BUILD-PARM-INFO
025051         THRU TAXC-1000-BUILD-PARM-INFO-X.
025051
025051     SET LTAXC-RGN-EXIT-TAXWH-CLI-EDITS   TO TRUE.
025051     SET LTAXC-LTAXWH-EDIT-REQT           TO TRUE.
025051
025051     MOVE MIR-POL-ID               TO LTAXC-POL-ID.
025051     MOVE WS-EFF-DT                TO LTAXC-EFF-DT.
029060*    MOVE MIR-FED-TAXWH-CALC-CD    TO LTAXC-FED-TAXWH-CALC-CD.
029060*    MOVE WS-FED-TAXWH-RQST-AMT    TO LTAXC-FED-TAXWH-RQST-AMT.
029060*    MOVE WS-FED-TAXWH-RQST-PCT    TO LTAXC-FED-TAXWH-RQST-PCT.
025051
029060*    MOVE MIR-LTAXWH-CALC-CD       TO LTAXC-LTAXWH-CALC-CD.
029060*    MOVE WS-LTAXWH-FLAT-AMT       TO LTAXC-LTAXWH-FLAT-AMT.
029060*    MOVE WS-LTAXWH-PCT            TO LTAXC-LTAXWH-PCT.
029060     MOVE MIR-FTAXWH-RQST-CD       TO LTAXC-FTAXWH-RQST-CD.
029060     MOVE WS-FED-TAXWH-RQST-AMT    TO LTAXC-FTAXWH-RQST-AMT.
029060     MOVE WS-FED-TAXWH-RQST-PCT    TO LTAXC-FTAXWH-RQST-PCT.
029060     MOVE MIR-LTAXWH-RQST-CD       TO LTAXC-LTAXWH-RQST-CD.
029060     MOVE WS-LTAXWH-FLAT-AMT       TO LTAXC-LTAXWH-RQST-AMT.
029060     MOVE WS-LTAXWH-PCT            TO LTAXC-LTAXWH-RQST-PCT.
025051
025051     PERFORM  TAXC-1000-TAXWH-CLI-EDIT
025051         THRU TAXC-1000-TAXWH-CLI-EDIT-X.
025051
025051     IF  LTAXC-EDIT-ERROR
025051     OR  NOT LTAXC-RETRN-OK
025051         SET WGLOB-RETURN-ERROR    TO TRUE
025051     END-IF.
025051
025051 5060-EDIT-TAXWH-RQST-X.
025051     EXIT.


      *----------------
       5100-GET-CLI-NM.
      *----------------

           MOVE ZERO               TO  I.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           INITIALIZE L0620-INPUT-PARM-INFO.

           IF  L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
           END-IF.

           MOVE L2430-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME          TO MIR-DV-OWN-CLI-NM.

       5100-GET-CLI-NM-X.
           EXIT.
      /
      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.



      *-----------------------
       8200-MOVE-OUTPUT-FIELDS.
      *-----------------------

           MOVE WS-DTH-QUOT-IND          TO MIR-DV-POL-DTH-QUOT-IND.

           MOVE WS-DBG-BASIC-AMT         TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-DBG-BASIC-RETRN-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-DBG-BASIC-RETRN-AMT.


           MOVE WS-LOCK-RESET-AMT        TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-DBG-RESET-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-DBG-RESET-AMT.


           MOVE WS-ANNV-VALU-AMT         TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-DBG-ANNV-VALU-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-DBG-ANNV-VALU-AMT.


           MOVE WS-MAV-AMT               TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-DBG-MAV-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-DBG-MAV-AMT.


           MOVE WS-ROLLUP-AMT            TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-DBG-ROLU-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-DBG-ROLU-AMT.


           MOVE WS-DBG-BASIC-CSV-AMT     TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-DBG-BASIC-CSV-AMT TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-DBG-BASIC-CSV-AMT.


           MOVE WS-DBG-ACUM-AMT          TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-DBG-ACUM-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-DBG-ACUM-AMT.


           MOVE WS-POL-DTH-AMT           TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-DTH-AMT TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-DTH-AMT.


           MOVE WS-POL-CSH-LOAN-AMT      TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-CSH-LOAN-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-DV-POL-CSH-LOAN-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE WS-POL-MISC-SUSP-AMT     TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-POL-MISC-SUSP-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE WS-POL-PREM-SUSP-AMT     TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-POL-PREM-SUSP-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE WS-POL-OS-DISB-AMT       TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-POL-OS-DISB-AMT TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-POL-OS-DISB-AMT.


           MOVE WS-POL-PDF-AMT           TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-TOT-PDF-AMT TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-TOT-PDF-AMT.


           MOVE WS-POL-SIDFND-AFV-AMT    TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-SIDFND-AFV-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-SIDFND-AFV-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE WS-POL-OTHR-BAL-AMT      TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-OTHR-BAL-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-OTHR-BAL-AMT.


           SET L0290-SIGN-DISPLAY        TO TRUE.
           MOVE WS-POL-NET-DTH-AMT       TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-NET-DTH-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-NET-DTH-AMT.

023444     SET L0290-SIGN-DISPLAY        TO TRUE.
023444     MOVE WS-DV-POL-TAX-ACB-AMT    TO L0290-INPUT-V02.
023444     MOVE +2                       TO L0290-PRECISION
023444     MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
023444                                   TO L0290-MAX-OUT-LEN.
023444     PERFORM 0290-2000-FORMAT-FOR-MIR
023444        THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-TAX-ACB-AMT.
023444
023444     SET L0290-SIGN-DISPLAY        TO TRUE.
023444     MOVE WS-DV-GRS-DSTRB-AMT      TO L0290-INPUT-V02.
023444     MOVE +2                       TO L0290-PRECISION
023444     MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
023444                                   TO L0290-MAX-OUT-LEN.
023444     PERFORM 0290-2000-FORMAT-FOR-MIR
023444        THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA        TO MIR-DV-GRS-DSTRB-AMT.
023444
023444     SET L0290-SIGN-DISPLAY         TO TRUE.
023444     MOVE WS-DV-TAXBL-GRS-DSTRB-AMT TO L0290-INPUT-V02.
023444     MOVE +2                        TO L0290-PRECISION
023444     MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
023444                                    TO L0290-MAX-OUT-LEN.
023444     PERFORM 0290-2000-FORMAT-FOR-MIR
023444        THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA         TO MIR-DV-TAXBL-GRS-DSTRB-AMT.
023444
023437     MOVE WS-CDA-FED-TAXWH-AMT     TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-FTAXWH-AMT.
023437
023437     MOVE WS-LTAXWH-FLAT-AMT       TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                   TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-LTAXWH-FLAT-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-LTAXWH-RQST-AMT.
023437
023437     IF  WS-LTAXWH-FLAT-AMT > 0
023437         MOVE ZEROS                TO L0290-INPUT-V02
023437         MOVE 2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                   TO L0290-MAX-OUT-LEN
023437         PERFORM 0290-2000-FORMAT-FOR-MIR
023437            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE  L0290-OUTPUT-DATA   TO MIR-LTAXWH-PCT
029060         MOVE  L0290-OUTPUT-DATA   TO MIR-LTAXWH-RQST-PCT
023437     END-IF.
029060 
029060     MOVE WS-LTAXWH-AMT            TO L0290-INPUT-V02.
029060     MOVE 2                        TO L0290-PRECISION.
029060     MOVE LENGTH OF MIR-LTAXWH-AMT TO L0290-MAX-OUT-LEN.
029060
029060     PERFORM 0290-2000-FORMAT-FOR-MIR
029060        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-LTAXWH-AMT.

           PERFORM  8210-MOVE-CVG-MIR
               THRU 8210-MOVE-CVG-MIR-X
               VARYING I FROM 1 BY 1
               UNTIL   I > WS-CVG-CTR.


       8200-MOVE-OUTPUT-FIELDS-X.
           EXIT.


      *-----------------
       8210-MOVE-CVG-MIR.
      *-----------------

           MOVE WS-CVG-NUM-T (I)           TO L0290-INPUT-V00.
           MOVE ZERO                     TO L0290-PRECISION
           MOVE LENGTH OF MIR-CVG-NUM-T (I)
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CVG-NUM-T (I).


           MOVE WS-CVG-DTH-AMT (I)       TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-CVG-DTH-AMT-T (I)
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-CVG-DTH-AMT-T (I).


           MOVE WS-PLAN-ID (I)           TO MIR-PLAN-ID-T (I).


       8210-MOVE-CVG-MIR-X.
           EXIT.

031034*------------------------
031034*8400-CALC-OPEN-BAL.
031034*------------------------
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    SET L7800-RQST-CALC-OPEN-BAL TO TRUE.
031034*    MOVE RPOL-POL-ID             TO L7800-POL-ID.
031034*    MOVE WS-EFF-DT               TO L7800-EFF-DT.
031034*    MOVE L0182-CV-TAX            TO L7800-CV-TAX.
031034*    SET L7800-CALC-CV-NOT-REQ    TO TRUE.
031034*    SET L7800-GET-PLAR-NOT-REQ   TO TRUE.
031034*
031034*    SET L7800-PRCES-NORMAL   TO TRUE.
031034*    SET L7800-TRXN-POL-TRMN  TO TRUE.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE LPGAL-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*          TO L7800-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*    PERFORM  7800-2000-CALC-OPEN-BAL
031034*        THRU 7800-2000-CALC-OPEN-BAL-X.
031034*
031034*    IF  L7800-RETRN-ERROR
031034*        SET MIR-RETRN-RQST-FAILED TO TRUE
031034*        GO TO 8400-CALC-OPEN-BAL-X
031034*    END-IF.
031034*
031034*    SET LPGAL-PLAR-PRCES         TO TRUE.
031034*    SET LPGAL-PGAL-ALLOC-REQ     TO TRUE.
031034*    MOVE ZEROS                   TO WS-TOT-TRMN-AMT.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE L7800-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*          TO LPGAL-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*          TO LPGAL-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*          TO LPGAL-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*          TO LPGAL-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*
031034*        COMPUTE  WS-TOT-TRMN-AMT
031034*              =  WS-TOT-TRMN-AMT
031034*              +  LPGAL-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*              +  LPGAL-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*8400-CALC-OPEN-BAL-X.
031034*    EXIT.
031034*
031034*------------------------
031034*8600-DISB-TRMN-AMT.
031034*------------------------
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE RPOL-POL-ID             TO L7800-POL-ID.
031034*    MOVE WS-EFF-DT               TO L7800-EFF-DT.
031034*    MOVE L0182-CV-TAX            TO L7800-CV-TAX.
031034*    MOVE WS-TOT-TRMN-AMT         TO L7800-TOT-SURR-AMT.
031034*    COMPUTE L7800-SURR-CHRG-AMT = WS-POL-SURR-CHRG-AMT.
031034*    SET L7800-CALC-CV-NOT-REQ    TO TRUE.
031034*    SET L7800-GET-PLAR-NOT-REQ   TO TRUE.
031034*
031034*    MOVE LPGAL-PLAR-PRCES-SW   TO L7800-PLAR-PRCES-SW.
031034*    MOVE LPGAL-PGAL-ALLOC-SW   TO L7800-PGAL-ALLOC-SW.
031034*
031034*    SET L7800-PRCES-NORMAL   TO TRUE.
031034*    SET L7800-TRXN-POL-TRMN  TO TRUE.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE LPGAL-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*          TO L7800-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*        MOVE LPGAL-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*          TO L7800-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*        MOVE LPGAL-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*          TO L7800-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*        MOVE LPGAL-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*          TO L7800-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*        MOVE LPGAL-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*          TO L7800-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*    PERFORM  7800-3000-DISB-TRXN-AMT
031034*        THRU 7800-3000-DISB-TRXN-AMT-X.
031034*
031034*    IF  L7800-RETRN-ERROR
031034*        SET MIR-RETRN-RQST-FAILED  TO TRUE
031034*        GO TO 8600-DISB-TRMN-AMT-X
031034*    END-IF.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE L7800-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*          TO LPGAL-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*        MOVE L7800-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*          TO LPGAL-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*        MOVE L7800-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*          TO LPGAL-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*8600-DISB-TRMN-AMT-X.
031034*    EXIT.

      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *-------------------------
       9990-INIT-WORKING-STORAGE.
      *-------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970*    INITIALIZE WS-WORK-FIELDS.
025970     PERFORM  0182-0000-INIT-PARM-INFO
025970         THRU 0182-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  0187-0000-INIT-PARM-INFO
031034*        THRU 0187-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0279-0000-INIT-PARM-INFO
025970         THRU 0279-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025051     PERFORM  0316-0000-INIT-PARM-INFO
025051         THRU 0316-0000-INIT-PARM-INFO-X.
025051
025970     PERFORM  0317-0000-INIT-PARM-INFO
025970         THRU 0317-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
027096     PERFORM  2435-0000-INIT-PARM-INFO
027096         THRU 2435-0000-INIT-PARM-INFO-X.
027096
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
031034     PERFORM  5382-0000-INIT-PARM-INFO
031034         THRU 5382-0000-INIT-PARM-INFO-X.
031034
025970     PERFORM  7306-0000-INIT-PARM-INFO
025970         THRU 7306-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  DGBA-0000-INIT-PARM-INFO
025970         THRU DGBA-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  DGLK-0000-INIT-PARM-INFO
025970         THRU DGLK-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  DGMV-0000-INIT-PARM-INFO
025970         THRU DGMV-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  DGRS-0000-INIT-PARM-INFO
025970         THRU DGRS-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  DGRU-0000-INIT-PARM-INFO
025970         THRU DGRU-0000-INIT-PARM-INFO-X.

025051     PERFORM  TAXC-0000-INIT-PARM-INFO
025051         THRU TAXC-0000-INIT-PARM-INFO-X.
025051
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                     TO WWKDT-WORK-FIELDS.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
023444 COPY CCPPPLIN.
      *
       COPY NCPPCVGS.
      *
025970 COPY XCPS8090.
031034*COPY CCPSPGAL.
023437
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      *
      *****************************************************************
      *  LINKAGE COPYBOOKS
      ************************************S*****************************

       COPY CCPSPGA.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
      *
025970 COPY XCPS0279.
       COPY XCPL0279.
025970 COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPS0290.
       COPY XCPL0290.
      *
025051 COPY XCPS0316.
025051 COPY XCPL0316.

       COPY XCPS0317.
       COPY XCPL0317.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      *
       COPY XCPL8090.
      *
       COPY CCPS0182.
       COPY CCPL0182.
      *
031034*COPY CCPS0187.
031034*COPY CCPL0187.
023437
025970 COPY CCPS0620.
       COPY CCPL0620.
      *
       COPY CCPS2430.
       COPY CCPL2430.
      *
027096 COPY CCPS2435.
027096 COPY CCPL2435.
027096*
       COPY CCPS4750.
       COPY CCPL4750.
      *
       COPY CCPS4780.
       COPY CCPL4780.
      *
031034 COPY CCPS5382.
031034 COPY CCPL5382.
      *
       COPY CCPS7306.
       COPY CCPL7306.

031034*COPY CCPS7800.
031034*COPY CCPL7800.
023437
       COPY CCPSDGBA.
       COPY CCPLDGBA.
      *
       COPY CCPSDGLK.
       COPY CCPLDGLK.
      *
       COPY CCPSDGRS.
       COPY CCPLDGRS.
      *
       COPY CCPSDGMV.
       COPY CCPLDGMV.
      *
       COPY CCPSDGRU.
       COPY CCPLDGRU.
      *
025051 COPY CCPSTAXC.
025051 COPY CCPLTAXC.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNPH.

       COPY CCPNCVG.
       COPY SCPNFX.
       COPY SCPBFA.
       COPY CCPFPOLS.

      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM7315                     **
      *****************************************************************
