      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0571.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0571                                         **
      **  REMARKS:  DCCP-DISABILITY CLAIMS CLIENT PROCESSING MODULE. **
      **            THIS PROGRAM ALLOWS THE USER TO INITIATE THE     **
      **            CLAIMS PROCESS FOR A CLIENT WHO HAS REPORTED A   **
      **            DISABILITY.  THIS TRANSACTION IS USED TO OPEN A  **
      **            DISABILITY CLAIM (WILL ASSIGN A CLAIM NUMBER TO  **
      **            EACH OCCURRENCE OF DISABILITY FOR A CLIENT).     **
      **            THE SYSTEM AUTOMATICALLY CREATES CLAIM DETAIL    **
      **            RECORDS FOR EACH POLICY ON WHICH THE CLIENT IS   **
      **            AN INSURED.  THIS TRANSACTION IS ALSO USED TO    **
      **            CLOSE A CLAIM , RE-OPEN A CLAIM OR DELETE A      **
      **            CLAIM.  A BROWSE FUNCTION IS ALSO AVAILABLE FOR  **
      **            VIEWING EITHER ALL CLAIMS ON FILE OR ALL CLAIMS  **
      **            FOR A PARTICULALR CLIENT.                        **
      **  DOMAIN :  CM                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557668**  5.5       POPULATE CLIENT AND POL ON OTHER SCREEN          **
557708**  5.5       NEW ABEND HANDLING ROUTINE                       **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
008445**  5.5.2     GENERATE MIR FROM TADB                           **
010450**  5.5.2     USE CURSOR TO DETERMINE MENU OPTION              **
005409**  5.6       MODIFICATIONS FOR LEAP YEAR                      **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES,              **
013578**            INCREASE LIST TO 100 OCCURENCES                  **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
016387**  6.2       REMOVE FUSE SUPPORT                              **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
025736**  6.7       FIELD LABEL ON DI CLAIM CLOSURE                  **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0571'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           05  TRANSACTION-NAME             PIC X(4)   VALUE 'DCCP'.
025970         88 TRANSACTION-NAME-DEFAULT  VALUE 'DCCP'.
016548*    05  WS-LINE                      PIC S9(4)  COMP SYNC.
016548     05  WS-LINE                      PIC S9(4)  BINARY SYNC.
013578*    05  WS-MAX-SCREEN-LINES          PIC S9(4)  COMP VALUE +10.
016548*    05  WS-MAX-SCREEN-LINES          PIC S9(4)  COMP VALUE +100.
016548     05  WS-MAX-SCREEN-LINES          PIC S9(4)
016548                                      BINARY VALUE +100.
025970         88 WS-MAX-SCREEN-LINES-DEFAULT  VALUE +100.
557756*    05  WS-QUERY-VALUES.
557756*        10  FILLER                   PIC X(07)
557756*                                     VALUE 'VERIFY:'.
557756*        10  FILLER                   PIC X(07)
557756*                                     VALUE '  CONF:'.
557756*        10  FILLER                   PIC X(07)
557756*                                     VALUE ' VERIF:'.
557756*    05  FILLER REDEFINES WS-QUERY-VALUES OCCURS 3 TIMES.
557756*        10  WS-VERIFY-VERIF          PIC X(07).

           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID             VALUE '0410' '0411'
                                                      '0412' '0413'
                                                      '0414' '0415'.
               88  WS-BUS-FCN-CLAIM             VALUE '0410' '0411'
                                                      '0412' '0413'.
               88  WS-BUS-FCN-LIST              VALUE '0414' '0415'.
               88  WS-BUS-FCN-CLAIM-OPEN        VALUE '0410'.
               88  WS-BUS-FCN-CLAIM-CLOSE       VALUE '0411'.
               88  WS-BUS-FCN-CLAIM-REOPEN      VALUE '0412'.
               88  WS-BUS-FCN-CLAIM-DELETE      VALUE '0413'.
               88  WS-BUS-FCN-LIST-BY-CLAIM     VALUE '0414'.
               88  WS-BUS-FCN-LIST-BY-CLIENT    VALUE '0415'.

           05  WS-EFF-DATE                     PIC X(10).
           05  WS-INSURED-SW                   PIC X.
               88  WS-INSURED-NOT-FOUND         VALUE 'N'.
               88  WS-INSURED-FOUND             VALUE 'Y'.

       01  WS-SWITCHES.
           05  WS-PRINT-ERROR-SW               PIC 9.
               88  WS-PRINT-ERROR               VALUE 1.
               88  WS-PRINT-NO-ERROR            VALUE 0.
           05  WS-PRINT-OFF-SW                 PIC 9.
               88  WS-PRINT-OFF                 VALUE 1.
               88  WS-PRINT-ON                  VALUE 0.
      /
       01  WS-HOLD-FIELDS.
           05  WS-HOLD-LINE-NO                 PIC S9(4).
           05  WS-HOLD-COL-NO                  PIC S9(2).
           05  WS-HOLD-CODE                    PIC X(2).
           05  WS-HOLD-RSN                     PIC X(2).
      /

      *****************************************************************
      *  COMMON COPYBOOKS
      *****************************************************************
      /
       COPY XCWWWKDT.
      /
557756*COPY CCWTYSNO.
      /
016537*COPY CCWWINDX.
      /
557668 COPY CCWL0620.
016108 COPY CCWL0985.
028298 COPY CCWL2626.
      /
      *****************************************************************
      *  I/O    COPYBOOKS
      *****************************************************************

       COPY CCFWDCL.
       COPY CCFWDCL1.
       COPY CCFRDCL.
016108 COPY CCFRPOL.
016108 COPY CCWWCVGS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER
      *****************************************************************

       COPY XCWL1640.
      /
       COPY XCWLDTLK.
      /
016537*COPY XCWL0280.
      /
       COPY CCWL0572.
      /
       COPY CCWL0576.
      /
       COPY CCWL2435.
      /
016387*COPY CCWL5600.
      /
      *****************************************************************
      *  INPUT PARAMETER
      *****************************************************************
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0571.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ****************
015543*0000-MAIN-LINE.
015543 0000-MAINLINE.
      ****************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

013578     INITIALIZE LPGA-PARM-INFO.
013578
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

015543*0000-MAIN-LINE-X.
015543 0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
      * 1. RECEIVE THE APPROPRIATE MAP
      * 2. SAVE THE INPUT/ INITIALIZE THE OUTPUT MAP
      * 3. INITIALIZE SWITCHES
      * 4. HANDLE VERIFY RESPONSE IF SECOND PASS THROUGH PROGRAM
      * 5. GET AND VERIFY THE TRANSACTION CODE
      * 6. VALIDATE USER ACCESS AGAIN
      * 7. IF NO ERROR, PROCESS
      * 8. UPDATE TERMINAL RECORD IF REQUIRED
      *
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
           SET  MIR-RETRN-OK          TO TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           MOVE MIR-DISAB-REASN-CD    TO WS-HOLD-RSN.

           EVALUATE TRUE
               WHEN WS-BUS-FCN-CLAIM-OPEN
                   MOVE 'OC'          TO WS-HOLD-CODE
                   MOVE MIR-DISAB-REASN-CD TO WS-HOLD-RSN
               WHEN WS-BUS-FCN-CLAIM-CLOSE
                   MOVE 'CC'          TO WS-HOLD-CODE
                   MOVE MIR-CLM-CLOS-REASN-CD TO WS-HOLD-RSN
               WHEN WS-BUS-FCN-CLAIM-REOPEN
                   MOVE 'RC'          TO WS-HOLD-CODE
               WHEN WS-BUS-FCN-CLAIM-DELETE
                   MOVE 'DC'          TO WS-HOLD-CODE
               WHEN WS-BUS-FCN-LIST-BY-CLAIM
                   MOVE 'BC'          TO WS-HOLD-CODE
               WHEN WS-BUS-FCN-LIST-BY-CLIENT
                   MOVE 'BI'          TO WS-HOLD-CODE
           END-EVALUATE.

           SET WGLOB-GOOD-RETURN             TO TRUE.
           SET WS-PRINT-OFF                  TO TRUE.


           SET WS-PRINT-ON                   TO TRUE.

016108     PERFORM  2200-VAL-DATE-OF-DTH
016108         THRU 2200-VAL-DATE-OF-DTH-X.

           IF  WGLOB-GOOD-RETURN
               SET WS-PRINT-ERROR            TO TRUE
           END-IF.

           IF  WGLOB-GOOD-RETURN
           AND WS-BUS-FCN-CLAIM
               PERFORM  2500-DCCP-PROCESSING
                   THRU 2500-DCCP-PROCESSING-X
           ELSE
               IF  WGLOB-GOOD-RETURN
               AND WS-BUS-FCN-LIST
                   PERFORM  5000-WS-CLAIM-BROWSE
                       THRU 5000-WS-CLAIM-BROWSE-X
               END-IF
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------
       2100-EDIT-INPUT.
      *----------------

025736*    MOVE MIR-INSRD-DISAB-DT    TO L1640-EXTERNAL-DATE.

025736     IF  WS-BUS-FCN-CLAIM-CLOSE
025736         MOVE MIR-DI-CLM-CLOS-DT  TO L1640-EXTERNAL-DATE
025736     ELSE
025736         MOVE MIR-INSRD-DISAB-DT  TO L1640-EXTERNAL-DATE
025736     END-IF.

005409*    SET  L1640-DO-NOT-USE-LEAP-YEAR   TO TRUE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO WS-EFF-DATE.

       2100-EDIT-INPUT-X.
           EXIT.
      /
016108*---------------------
016108 2200-VAL-DATE-OF-DTH.
016108*---------------------
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     IF  NOT WS-BUS-FCN-CLAIM-OPEN
016108     AND NOT WS-BUS-FCN-CLAIM-CLOSE
016108     AND NOT WS-BUS-FCN-CLAIM-REOPEN
016108         GO TO 2200-VAL-DATE-OF-DTH-X
016108     END-IF.
016108
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE MIR-CLI-ID              TO L0985-CLI-ID.
016108     MOVE WS-EFF-DATE             TO L0985-EFF-DT.
016108
016108     PERFORM  0985-3000-VAL-CLI-DT-OF-DTH
016108         THRU 0985-3000-VAL-CLI-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         SET WGLOB-RETURN-ERROR   TO TRUE
016108     END-IF.
016108
016108 2200-VAL-DATE-OF-DTH-X.
016108     EXIT.
016108/
      *---------------------
       2500-DCCP-PROCESSING.
      *---------------------

           PERFORM  3000-TRANS-GENERAL-EDITS
               THRU 3000-TRANS-GENERAL-EDITS-X

           IF  WGLOB-RETURN-ERROR
               GO TO 2500-DCCP-PROCESSING-X
           END-IF.

           PERFORM  3100-TRANS-SPECIFIC-EDITS
               THRU 3100-TRANS-SPECIFIC-EDITS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2500-DCCP-PROCESSING-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD = '2'
               PERFORM  3900-VERIFY-TRAN
                   THRU 3900-VERIFY-TRAN-X
           ELSE
               PERFORM  4000-PROCESS-TRAN
                   THRU 4000-PROCESS-TRAN-X
           END-IF.

       2500-DCCP-PROCESSING-X.
           EXIT.
      /
      *-------------------------
       3000-TRANS-GENERAL-EDITS.
      *-------------------------

           IF  MIR-CLI-ID = SPACES
               MOVE 'CS05713000'      TO WGLOB-MSG-REF-INFO
      * MSG: CLIENT NUMBER OF INSURED REQUIRED TO PROCESS CLAIM
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 3000-TRANS-GENERAL-EDITS-X
           END-IF.

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L2435-CLI-ID.
           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.
           IF L2435-RETRN-CLI-NOT-FOUND
               MOVE 'CS05713001'      TO WGLOB-MSG-REF-INFO
               MOVE L2435-CLI-ID      TO WGLOB-MSG-PARM (1)
      * MSG: CLIENT RECORD (@1) NOT ON FILE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 3000-TRANS-GENERAL-EDITS-X
           END-IF.

557668*    MOVE L2435-CLI-NM-COMPRESSED      TO MIR-DV-INSRD-CLI-NM.
557668     INITIALIZE L0620-INPUT-PARM-INFO.
557668     IF L2435-CLI-SEX-CD = 'C'
557668        MOVE L2435-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668     ELSE
557668        MOVE L2435-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668        MOVE L2435-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
              MOVE L2435-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
              MOVE L2435-CLI-SFX-NM   TO L0620-CLI-SFX-NM
557668     END-IF.
557668     MOVE L2435-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
557668
557668     PERFORM 0620-1000-FORMAT-SCREEN-NAME
557668        THRU 0620-1000-FORMAT-SCREEN-NAME-X.
557668     MOVE L0620-SCREEN-NAME     TO MIR-DV-INSRD-CLI-NM.

016387*
016387* VERIFY CLIENT FOR CONSOLIDATION
016387*
016387*    PERFORM  5600-1000-BUILD-PARM-INFO
016387*        THRU 5600-1000-BUILD-PARM-INFO-X.
016387*    MOVE MIR-CLI-ID            TO L5600-CLI-ID.
016387*    SET  L5600-GEN-CNSLDT-MSG-WARN    TO TRUE.
016387*    PERFORM  5600-1000-CLI-CHK
016387*        THRU 5600-1000-CLI-CHK-X
016387*    IF NOT L5600-RETRN-OK
016387*        MOVE '1'               TO WGLOB-RETURN-CODE
016387*    END-IF.
016387*
       3000-TRANS-GENERAL-EDITS-X.
           EXIT.
      /
      *--------------------------
       3100-TRANS-SPECIFIC-EDITS.
      *--------------------------

           IF WS-BUS-FCN-CLAIM-DELETE
               PERFORM  3140-DELETE-CLAIM-EDITS
                   THRU 3140-DELETE-CLAIM-EDITS-X
               GO TO 3100-TRANS-SPECIFIC-EDITS-X
           END-IF.

           PERFORM  3200-EFF-DATE-EDITS
               THRU 3200-EFF-DATE-EDITS-X.

           PERFORM  0572-1000-BUILD-PARM-INFO
               THRU 0572-1000-BUILD-PARM-INFO-X.

           MOVE WS-HOLD-CODE          TO L0572-RQST-CD.
           MOVE MIR-CLI-ID            TO L0572-CLI-ID.
           MOVE WS-EFF-DATE           TO L0572-EFF-DT.
           MOVE MIR-DI-CLM-ID         TO L0572-CLM-ID.
           MOVE WS-HOLD-RSN           TO L0572-REASN-CD.

           SET L0572-PRCES-TYP-EDIT-ONLY     TO TRUE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CLAIM-OPEN
                   PERFORM  0572-1000-OPEN-CLAIM
                       THRU 0572-1000-OPEN-CLAIM-X

               WHEN WS-BUS-FCN-CLAIM-CLOSE
                   PERFORM  0572-2000-CLOSE-CLAIM
                       THRU 0572-2000-CLOSE-CLAIM-X

               WHEN WS-BUS-FCN-CLAIM-REOPEN
                   PERFORM  0572-3000-REOPEN-CLAIM
                       THRU 0572-3000-REOPEN-CLAIM-X

           END-EVALUATE.

           MOVE L0572-CLM-ID          TO MIR-DI-CLM-ID.

           IF  NOT L0572-RETRN-OK
               MOVE '1'               TO WGLOB-RETURN-CODE
           END-IF.

       3100-TRANS-SPECIFIC-EDITS-X.
           EXIT.
      /
      *------------------------
       3140-DELETE-CLAIM-EDITS.
      *------------------------

           PERFORM  0576-1000-BUILD-PARM-INFO
               THRU 0576-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CLI-ID            TO L0576-CLI-ID.
           MOVE MIR-DI-CLM-ID         TO L0576-CLM-ID.

           SET L0576-PRCES-TYP-EDIT-ONLY     TO TRUE.

           PERFORM  0576-1000-DELETE-CLAIM
               THRU 0576-1000-DELETE-CLAIM-X.

           IF  NOT L0576-RETRN-OK
               MOVE '1'               TO WGLOB-RETURN-CODE
           END-IF.


       3140-DELETE-CLAIM-EDITS-X.
           EXIT.
      /
      *--------------------
       3200-EFF-DATE-EDITS.
      *--------------------

           IF WS-EFF-DATE = WWKDT-ZERO-DT
               MOVE 'CS00000054'      TO WGLOB-MSG-REF-INFO
      * MSG: DATE MUST BE ENTERED IN VALID FORMAT ... DDMMMYYYY
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WGLOB-RETURN-CODE
           ELSE
               IF WS-EFF-DATE GREATER THAN WGLOB-PROCESS-DATE
                   MOVE 'CS05713002'  TO WGLOB-MSG-REF-INFO
      * MSG: EFFECTIVE DATE CANNOT BE IN THE FUTURE
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

       3200-EFF-DATE-EDITS-X.
           EXIT.
      /
      *-----------------
       3900-VERIFY-TRAN.
      *-----------------

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CLAIM-OPEN
                   MOVE 'CS05712200'  TO WGLOB-MSG-REF-INFO
      * MSG: YOU ARE OPENING A CLAIM
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN WS-BUS-FCN-CLAIM-CLOSE
                   MOVE 'CS05712201'  TO WGLOB-MSG-REF-INFO
      * MSG: YOU ARE CLOSING A CLAIM
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN WS-BUS-FCN-CLAIM-REOPEN
                   MOVE 'CS05712202'  TO WGLOB-MSG-REF-INFO
      * MSG: YOU ARE RE-OPENING A CLAIM
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN WS-BUS-FCN-CLAIM-DELETE
                   MOVE 'CS05712203'  TO WGLOB-MSG-REF-INFO
      * MSG: YOU ARE DELETING A CLAIM
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

           MOVE 'CS05712210'          TO WGLOB-MSG-REF-INFO.
      * MSG: PLEASE CONFIRM OR CANCEL THIS PROCESS
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3900-VERIFY-TRAN-X.
           EXIT.
      /
      *------------------
       4000-PROCESS-TRAN.
      *------------------

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CLAIM-OPEN
                   PERFORM  4110-PROCESS-OPEN-CLAIM
                       THRU 4110-PROCESS-OPEN-CLAIM-X

               WHEN WS-BUS-FCN-CLAIM-CLOSE
                   PERFORM  4120-PROCESS-CLOSE-CLAIM
                       THRU 4120-PROCESS-CLOSE-CLAIM-X

               WHEN WS-BUS-FCN-CLAIM-REOPEN
                   PERFORM  4130-PROCESS-REOPEN-CLAIM
                       THRU 4130-PROCESS-REOPEN-CLAIM-X

               WHEN WS-BUS-FCN-CLAIM-DELETE
                   PERFORM  4140-PROCESS-DELETE-CLAIM
                       THRU 4140-PROCESS-DELETE-CLAIM-X

           END-EVALUATE.

       4000-PROCESS-TRAN-X.
           EXIT.
      /
      *------------------------
       4110-PROCESS-OPEN-CLAIM.
      *------------------------

           PERFORM  0572-1000-BUILD-PARM-INFO
               THRU 0572-1000-BUILD-PARM-INFO-X.

           MOVE MIR-DI-CLM-ID         TO L0572-CLM-ID.
           MOVE MIR-CLI-ID            TO L0572-CLI-ID.
           MOVE WS-EFF-DATE           TO L0572-EFF-DT.
           MOVE WS-HOLD-RSN           TO L0572-REASN-CD.
           PERFORM  0572-1000-OPEN-CLAIM
               THRU 0572-1000-OPEN-CLAIM-X.

           IF L0572-RETRN-OK
               MOVE 'CS05714100'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DI-CLM-ID     TO WGLOB-MSG-PARM (1)
      * MSG: CLAIM @1 OPENED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE '1'               TO WGLOB-RETURN-CODE
               MOVE 'CS05714101'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DI-CLM-ID     TO WGLOB-MSG-PARM (1)
      * MSG: CLAIM @1 NOT OPENED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       4110-PROCESS-OPEN-CLAIM-X.
           EXIT.
      /
      *-------------------------
       4120-PROCESS-CLOSE-CLAIM.
      *-------------------------

           PERFORM 0572-1000-BUILD-PARM-INFO
               THRU 0572-1000-BUILD-PARM-INFO-X.

           MOVE MIR-DI-CLM-ID         TO L0572-CLM-ID.
           MOVE MIR-CLI-ID            TO L0572-CLI-ID.
           MOVE WS-EFF-DATE           TO L0572-EFF-DT.
           MOVE WS-HOLD-RSN           TO L0572-REASN-CD.
           PERFORM  0572-2000-CLOSE-CLAIM
               THRU 0572-2000-CLOSE-CLAIM-X.

           IF L0572-RETRN-OK
               MOVE 'CS05714102'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DI-CLM-ID     TO WGLOB-MSG-PARM (1)
      * MSG: CLAIM @1 CLOSED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE '1'               TO WGLOB-RETURN-CODE
               MOVE 'CS05714103'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DI-CLM-ID     TO WGLOB-MSG-PARM (1)
      * MSG: CLAIM @1 NOT CLOSED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4120-PROCESS-CLOSE-CLAIM-X.
           EXIT.
      /
      *--------------------------
       4130-PROCESS-REOPEN-CLAIM.
      *--------------------------

           PERFORM 0572-1000-BUILD-PARM-INFO
               THRU 0572-1000-BUILD-PARM-INFO-X.

           MOVE MIR-DI-CLM-ID         TO L0572-CLM-ID.
           MOVE MIR-CLI-ID            TO L0572-CLI-ID.
           MOVE WS-EFF-DATE           TO L0572-EFF-DT.
           MOVE WS-HOLD-RSN           TO L0572-REASN-CD.
           PERFORM  0572-3000-REOPEN-CLAIM
               THRU 0572-3000-REOPEN-CLAIM-X.

           IF L0572-RETRN-OK
               MOVE 'CS05714104'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DI-CLM-ID     TO WGLOB-MSG-PARM (1)
      * MSG: CLAIM @1 RE-OPENED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE '1'               TO WGLOB-RETURN-CODE
               MOVE 'CS05714105'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DI-CLM-ID     TO WGLOB-MSG-PARM (1)
      * MSG: CLAIM @1 NOT RE-OPENED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4130-PROCESS-REOPEN-CLAIM-X.
           EXIT.
      /
      *--------------------------
       4140-PROCESS-DELETE-CLAIM.
      *--------------------------

           PERFORM  0576-1000-BUILD-PARM-INFO
               THRU 0576-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L0576-CLI-ID.
           MOVE MIR-DI-CLM-ID         TO L0576-CLM-ID.
           PERFORM  0576-1000-DELETE-CLAIM
               THRU 0576-1000-DELETE-CLAIM-X.

           IF L0576-RETRN-OK
               MOVE 'CS05714106'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DI-CLM-ID     TO WGLOB-MSG-PARM (1)
      * MSG: CLAIM @1 DELETED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE '1'               TO WGLOB-RETURN-CODE
               MOVE 'CS05714107'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DI-CLM-ID     TO WGLOB-MSG-PARM (1)
      * MSG: CLAIM @1 NOT DELETED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4140-PROCESS-DELETE-CLAIM-X.
           EXIT.
      /
      *---------------------
       5000-WS-CLAIM-BROWSE.
      *---------------------

           PERFORM  9100-BLANK-SCREEN-2
               THRU 9100-BLANK-SCREEN-2-X.


           IF  WS-BUS-FCN-LIST-BY-CLAIM
               MOVE LOW-VALUES        TO WDCL-KEY
               MOVE MIR-DI-CLM-ID     TO WDCL-DI-CLM-ID
               MOVE HIGH-VALUES       TO WDCL-ENDBR-KEY
               PERFORM  DCL-1000-BROWSE
                   THRU DCL-1000-BROWSE-X
           ELSE
               MOVE LOW-VALUES        TO WDCL1-KEY
               MOVE MIR-CLI-ID        TO WDCL1-CLI-ID
               MOVE MIR-DI-CLM-ID     TO WDCL1-DI-CLM-ID
               MOVE HIGH-VALUES       TO WDCL1-ENDBR-KEY
               PERFORM  DCL1-1000-BROWSE
                   THRU DCL1-1000-BROWSE-X
           END-IF.

           IF  WS-BUS-FCN-LIST-BY-CLIENT
               MOVE WDCL1-IO-STATUS   TO WDCL-IO-STATUS
           END-IF.

           IF NOT WDCL-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
      * MSG: END OF FILE FOUND ON INITIAL BROWSE
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-WS-CLAIM-BROWSE-X
           END-IF.

           IF  WS-BUS-FCN-LIST-BY-CLAIM
               PERFORM  DCL-2000-READ-NEXT
                   THRU DCL-2000-READ-NEXT-X
           ELSE
               PERFORM  DCL1-2000-READ-NEXT
                   THRU DCL1-2000-READ-NEXT-X
           END-IF.

           IF  WS-BUS-FCN-LIST-BY-CLIENT
               MOVE WDCL1-IO-STATUS   TO WDCL-IO-STATUS
           END-IF.

557660*    MOVE RDCL-DI-CLM-ID               TO MIR-DI-CLM-ID.
557660*    MOVE RDCL-CLI-ID                  TO MIR-CLI-ID.
           IF WDCL-IO-EOF
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
      * MSG: NO RECORDS FOUND TO DISPLAYR
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
557660         MOVE RDCL-DI-CLM-ID    TO MIR-DI-CLM-ID
557660         MOVE RDCL-CLI-ID       TO MIR-CLI-ID
               PERFORM  5010-DISPLAY-RECORD
                   THRU 5010-DISPLAY-RECORD-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL WS-LINE > WS-MAX-SCREEN-LINES
                   OR NOT WDCL-IO-OK

               IF WDCL-IO-OK
                   SET WGLOB-MORE-DATA-EXISTS  TO TRUE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
      * MSG: TO VIEW MORE DATA, PRESS ENTER
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE RDCL-DI-CLM-ID         TO MIR-DI-CLM-ID
                   MOVE RDCL-CLI-ID   TO MIR-CLI-ID
               ELSE
                   MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
      * MSG: INQUIRE COMPLETE - CONTINUE
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  WS-BUS-FCN-LIST-BY-CLAIM
               PERFORM  DCL-3000-END-BROWSE
                   THRU DCL-3000-END-BROWSE-X
           ELSE
               PERFORM  DCL1-3000-END-BROWSE
                   THRU DCL1-3000-END-BROWSE-X
           END-IF.

       5000-WS-CLAIM-BROWSE-X.
           EXIT.
      /
      *--------------------
       5010-DISPLAY-RECORD.
      *--------------------

           MOVE RDCL-DI-CLM-ID        TO MIR-DI-CLM-ID-T (WS-LINE).
           MOVE RDCL-CLI-ID           TO MIR-CLI-ID-T (WS-LINE).
           MOVE RDCL-CLM-CRNT-STAT-CD
                                    TO MIR-CLM-CRNT-STAT-CD-T (WS-LINE).

           MOVE RDCL-INSRD-DISAB-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-INSRD-DISAB-DT-T (WS-LINE).

           MOVE RDCL-DISAB-REASN-CD   TO MIR-DISAB-REASN-CD-T (WS-LINE).
           MOVE RDCL-INSRD-DISAB-TYP-CD
                                  TO MIR-INSRD-DISAB-TYP-CD-T (WS-LINE).

           MOVE RDCL-DI-CLM-CLOS-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DI-CLM-CLOS-DT-T (WS-LINE).

           MOVE RDCL-CLM-CLOS-REASN-CD
                                   TO MIR-CLM-CLOS-REASN-CD-T (WS-LINE).

           IF  WS-BUS-FCN-LIST-BY-CLAIM
               PERFORM  DCL-2000-READ-NEXT
                   THRU DCL-2000-READ-NEXT-X
           ELSE
               PERFORM  DCL1-2000-READ-NEXT
                   THRU DCL1-2000-READ-NEXT-X
           END-IF.

           IF  WS-BUS-FCN-LIST-BY-CLIENT
              MOVE WDCL1-IO-STATUS    TO WDCL-IO-STATUS
557660     END-IF.

       5010-DISPLAY-RECORD-X.
           EXIT.
      /
      *--------------------
       9100-BLANK-SCREEN-2.
      *--------------------

           MOVE SPACE                 TO MIR-DISAB-REASN-CD.
           MOVE SPACE                 TO MIR-CLM-CLOS-REASN-CD.

           MOVE SPACES                TO MIR-DI-CLM-ID-G.
           MOVE SPACES                TO MIR-CLI-ID-G.
           MOVE SPACES                TO MIR-CLM-CRNT-STAT-CD-G.
           MOVE SPACES                TO MIR-INSRD-DISAB-DT-G.
           MOVE SPACES                TO MIR-DISAB-REASN-CD-G.
           MOVE SPACES                TO MIR-INSRD-DISAB-TYP-CD-G.
           MOVE SPACES                TO MIR-DI-CLM-CLOS-DT-G.
           MOVE SPACES                TO MIR-CLM-CLOS-REASN-CD-G.

       9100-BLANK-SCREEN-2-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0572-0000-INIT-PARM-INFO
025970         THRU 0572-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0576-0000-INIT-PARM-INFO
025970         THRU 0576-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-SWITCHES.
025970     INITIALIZE WS-HOLD-FIELDS.
025970     SET TRANSACTION-NAME-DEFAULT TO TRUE.
025970     SET WS-MAX-SCREEN-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      * PROCESSING COPYBOOKS
      ******************************************************************

028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      ******************************************************************
      * LINKAGE PROCESSING COPYBOOKS
      ******************************************************************

018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY CCPS0572.
018764*COPY CCCL0572.
018764 COPY CCPL0572.
      /
       COPY CCPS0576.
018764*COPY CCCL0576.
018764 COPY CCPL0576.
      /
016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108/
       COPY CCPS2435.
018764*COPY CCCL2435.
018764 COPY CCPL2435.
      /
016387*COPY CCPS5600.
016387*COPY CCCL5600.
      /
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      /
      *****************************************************************
      * FILE I/O PROCESSING MODULES
      *****************************************************************

       COPY CCPBDCL.
       COPY CCPBDCL1.
      /
      *****************************************************************
      * ERROR HANDLING ROUTINES
      *****************************************************************

557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0571                     **
      *****************************************************************
