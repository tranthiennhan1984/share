      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0391.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0391                                         **
      **  REMARKS:  PROCESS DRIVER FOR THE TREATY FILE MAINTANANCE   **
      **            TRANSACTION - TRTY.  FUNCTIONS SUPPORTED ARE     **
      **            CREATE, MAINTAIN, DELETE, INQUIRE, AND BROWSE.   **
      **                                                             **
      **  DOMAIN :  RI                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURE                **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       ABEND HANDLING WAS ADDED                         **
557973**  5.5       AMOUNT FIELD SIZING FOR INTERNATIONAL            **
557973**            SUPPORT                                          **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       ADD SUB-CO TO KEY OF TT TABLE                    **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
023744**  6.7       REINSURANCE TREATY UPDATE CUTS OUT PLAN(PH)      ** 
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0391'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
008455*    05  WS-EDIT-9                     PIC 9(09).
       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

010418 COPY CCFWSCOM.
010418 COPY CCFRSCOM.

       01  WS-CONSTANTS.
016548*    05  WS-MAX-SCREEN-LINES          PIC S9(04) COMP VALUE +12.
016548     05  WS-MAX-SCREEN-LINES          PIC S9(04) BINARY VALUE +12.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1340'.

       01  WS-COUNTERS.
016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.

       01  WS-SWITCHES.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-ID-VALID       VALUE
                   '1340' '1341' '1342' '1343' '1344'.
               88  WS-BUS-FCN-RETRIEVE       VALUE '1340'.
               88  WS-BUS-FCN-CREATE         VALUE '1341'.
               88  WS-BUS-FCN-UPDATE         VALUE '1342'.
               88  WS-BUS-FCN-DELETE         VALUE '1343'.
               88  WS-BUS-FCN-LIST           VALUE '1344'.
025970*    05  WS-TWRK-KEY                   PIC X(04)  VALUE '1340'.
           05  WS-DATA-VALID-SW              PIC X(01).
               88  WS-DATA-VALID             VALUE 'Y'.
               88  WS-DATA-VALID-NO          VALUE 'N'.
           05  WS-SMOKER-CODE                PIC X(01).
               88  WS-SMOKER-CODE-VALID      VALUE 'S' 'N' 'U' 'C'.
           05  WS-TREATY-TYPE                PIC X(01).
               88  WS-TREATY-TYPE-VALID      VALUE 'A' 'F'.
           05  WS-REINSURANCE-TYPE           PIC X(01).
               88  WS-REINSURANCE-TYPE-VALID VALUE 'Y' 'C' 'B'.
           05  WS-RECAPTURE-TYPE             PIC X(01).
               88  WS-RECAPTURE-TYPE-VALID   VALUE 'A' 'B' 'C'.

       01  WS-WORK-AREA.
           05  WS-PIC-2-0                    PIC 9(02).
016548*    05  WS-SUB                        PIC S9(04) COMP VALUE +0.
016548     05  WS-SUB                        PIC S9(04) BINARY VALUE +0.
      /
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY XCWEBLCH.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWCC.
       COPY CCFRCC.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWPH.
       COPY CCFRPH.
023744 COPY CCFHPH.
      /
       COPY CCFWTT.
       COPY CCFRTT.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
557698 COPY XCWL0005.
       COPY XCWL0280.
008455 COPY XCWL0290.
       COPY XCWLDTLK.
       COPY XCWL1640.
014221 COPY XCWL8090.
      /
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0391.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*       THRU  ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0391'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           PERFORM  8000-BUILD-TRTY-KEY
               THRU 8000-BUILD-TRTY-KEY-X.

           PERFORM  TT-1000-READ
               THRU TT-1000-READ-X.

           IF NOT WTT-IO-OK
      *MSG:  (S) TREATY RECORD NOT IN FILE
               MOVE 'CS03910022'      TO WGLOB-MSG-REF-INFO
               PERFORM  9100-BLANK-DATA-FIELDS
                  THRU  9100-BLANK-DATA-FIELDS-X
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *MSG:  (I) INQUIRE COMPLETE - CONTINUE
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

           PERFORM  9100-BLANK-DATA-FIELDS
              THRU  9100-BLANK-DATA-FIELDS-X.

      *
      *    CHECK THE KEY FIELDS HERE
      *
           MOVE LOW-VALUES            TO WTT-KEY
           MOVE HIGH-VALUES           TO WTT-ENDBR-KEY

           IF MIR-PLAN-ID NOT =  SPACES
               MOVE MIR-PLAN-ID       TO WTT-PLAN-ID
557660     END-IF.

           IF MIR-TRTY-SMKR-CD NOT = SPACES
               MOVE MIR-TRTY-SMKR-CD  TO WTT-TRTY-SMKR-CD
557660     END-IF.

010418     IF MIR-SBSDRY-CO-ID NOT = SPACES
010418         MOVE MIR-SBSDRY-CO-ID  TO WTT-SBSDRY-CO-ID
010418     END-IF.

           IF MIR-TRTY-ASSUM-CO-ID NOT =  SPACES
               MOVE MIR-TRTY-ASSUM-CO-ID
                                      TO WTT-TRTY-ASSUM-CO-ID
557660     END-IF.

           PERFORM  TT-1000-BROWSE
               THRU TT-1000-BROWSE-X.

           IF WTT-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           ELSE
               PERFORM  TT-2000-READ-NEXT
                   THRU TT-2000-READ-NEXT-X
               IF WTT-IO-EOF
                  PERFORM TT-3000-END-BROWSE
                      THRU TT-3000-END-BROWSE-X
                  MOVE 'XS00000034'   TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                  GO TO 3500-PROCESS-LIST-X
557660         END-IF
557660     END-IF.

           PERFORM  3510-PROCESS-BROWSE-READ
               THRU 3510-PROCESS-BROWSE-READ-X
                    VARYING WS-SUB FROM +1 BY +1
                      UNTIL WS-SUB > WS-MAX-SCREEN-LINES
                         OR WTT-IO-EOF.

           IF WTT-IO-EOF
               MOVE MIR-PLAN-ID-T (1) TO MIR-PLAN-ID
010418         MOVE MIR-SBSDRY-CO-ID-T     (1)
                                      TO MIR-SBSDRY-CO-ID
               MOVE MIR-TRTY-SMKR-CD-T    (1)
                                      TO MIR-TRTY-SMKR-CD
               MOVE MIR-TRTY-ASSUM-CO-ID-T    (1)
                                      TO MIR-TRTY-ASSUM-CO-ID
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  TT-3000-END-BROWSE
               THRU TT-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------------
       3510-PROCESS-BROWSE-READ.
      *-------------------------

           MOVE RTT-PLAN-ID           TO MIR-PLAN-ID-T (WS-SUB).
010418     MOVE RTT-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID-T     (WS-SUB).
           MOVE RTT-TRTY-SMKR-CD      TO MIR-TRTY-SMKR-CD-T    (WS-SUB).
           MOVE RTT-TRTY-ASSUM-CO-ID
                                  TO MIR-TRTY-ASSUM-CO-ID-T    (WS-SUB).
           MOVE RTT-TRTY-CSN-PLAN-ID TO MIR-TRTY-CSN-PLAN-ID-T (WS-SUB).
           MOVE RTT-TRTY-TYP-CD       TO MIR-TRTY-TYP-CD-T    (WS-SUB).
           MOVE RTT-TRTY-REINS-TYP-CD
                                 TO MIR-TRTY-REINS-TYP-CD-T    (WS-SUB).

           PERFORM  TT-2000-READ-NEXT
               THRU TT-2000-READ-NEXT-X.

           IF WS-SUB = WS-MAX-SCREEN-LINES
              MOVE RTT-PLAN-ID        TO MIR-PLAN-ID
010418        MOVE RTT-SBSDRY-CO-ID   TO MIR-SBSDRY-CO-ID
              MOVE RTT-TRTY-SMKR-CD   TO MIR-TRTY-SMKR-CD
              MOVE RTT-TRTY-ASSUM-CO-ID
                                      TO MIR-TRTY-ASSUM-CO-ID
557660     END-IF.


       3510-PROCESS-BROWSE-READ-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------

           PERFORM  8000-BUILD-TRTY-KEY
               THRU 8000-BUILD-TRTY-KEY-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  TT-1000-READ
               THRU TT-1000-READ-X.

           IF WTT-IO-OK
      *MSG:   (I) TREATY RECORD ALREADY EXISTS
               MOVE 'CS03910023'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           PERFORM 4100-EDIT-KEY-FIELDS
              THRU 4100-EDIT-KEY-FIELDS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  TT-1000-CREATE
               THRU TT-1000-CREATE-X.

           PERFORM  TT-1000-WRITE
               THRU TT-1000-WRITE-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *MSG:   (I) TREATY RECORD CREATED - CONTINUE
           MOVE 'CS03910006'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *---------------------
       4100-EDIT-KEY-FIELDS.
      *---------------------

           PERFORM 4110-EDIT-PLAN-RS
               THRU 4110-EDIT-PLAN-RS-X.

010418     PERFORM 4115-EDIT-SBSDRY-CO-ID
010418        THRU 4115-EDIT-SBSDRY-CO-ID-X.

           PERFORM 4120-EDIT-SMOKER-CODE
               THRU 4120-EDIT-SMOKER-CODE-X.

           PERFORM 4130-EDIT-REIN-COMPANY
               THRU 4130-EDIT-REIN-COMPANY-X.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *------------------
       4110-EDIT-PLAN-RS.
      *------------------

           MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF NOT WPH-IO-OK
      *MSG:   (S) PLAN/RS NOT FOUND ON PHDR
               MOVE 'CS03910019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4110-EDIT-PLAN-RS-X.
           EXIT.
      /
010418*-------------------------
010418 4115-EDIT-SBSDRY-CO-ID.
010418*-------------------------
010418
010418     MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.

010418     PERFORM  SCOM-1000-READ
010418         THRU SCOM-1000-READ-X.

010418     IF NOT WSCOM-IO-OK
010418*MSG:   (S) SUB-COMPANY CODE NOT FOUND ON SCOM TABLE
010418         MOVE 'CS03910024'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418     END-IF.

010418 4115-EDIT-SBSDRY-CO-ID-X.
010418     EXIT.
      /
      *----------------------
       4120-EDIT-SMOKER-CODE.
      *----------------------

           MOVE MIR-TRTY-SMKR-CD      TO WS-SMOKER-CODE.

           IF NOT WS-SMOKER-CODE-VALID
      *MSG:   (S) SMOKER CODE MUST BE S, N, C OR U
               MOVE 'CS03910020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4120-EDIT-SMOKER-CODE-X.
           EXIT.
      /
      *-----------------------
       4130-EDIT-REIN-COMPANY.
      *-----------------------

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WEDIT-ETBL-VALU-ID.

           PERFORM  REIN-1000-EDIT
               THRU REIN-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
      *MSG:   (S) COMPANY CODE MUST BE ON ETAB TYPE 'REIN'
               MOVE 'CS03910012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4130-EDIT-REIN-COMPANY-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

014221     PERFORM  PH-2000-UPDATE-TWRK-TS
014221         THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF WPH-IO-NOT-FOUND
014221*MSG: 'PLAN (@1) NOT FOUND'
014221         SET WS-DATA-VALID-NO   TO TRUE
014221         MOVE 'XS00000049'      TO WGLOB-MSG-REF-INFO
014221         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE'
014221         SET WS-DATA-VALID-NO   TO TRUE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'              TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  8000-BUILD-TRTY-KEY
               THRU 8000-BUILD-TRTY-KEY-X.

           PERFORM  TT-1000-READ-FOR-UPDATE
               THRU TT-1000-READ-FOR-UPDATE-X.

           IF NOT WTT-IO-OK
      *MSG:   (S) RECORD LOST IN MAINTAIN - CONTACT SYSTEMS
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WTT-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           PERFORM  TT-2000-REWRITE
               THRU TT-2000-REWRITE-X.
014221     PERFORM  PH-2000-REWRITE
014221         THRU PH-2000-REWRITE-X.
014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           IF WS-DATA-VALID
      *MSG:   (I) MAINTAIN COMPLETED - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:   (I) RECORD UPDATED
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *----------------------
       5300-EDIT-DATA-FIELDS.
      *----------------------

           MOVE 'Y'                   TO WS-DATA-VALID-SW.

           PERFORM 5310-EDIT-SCRN-01
               THRU 5310-EDIT-SCRN-01-X

           PERFORM 5320-EDIT-SCRN-02
               THRU 5320-EDIT-SCRN-02-X

           PERFORM 5330-EDIT-SCRN-03
               THRU 5330-EDIT-SCRN-03-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *------------------
       5310-EDIT-SCRN-01.
      *------------------

           MOVE +1                    TO WS-LINE.
           PERFORM 5400-EDIT-PLAN-RS
               THRU 5400-EDIT-PLAN-RS-X.
           MOVE +2                    TO WS-LINE.
           PERFORM 5405-EDIT-TREATY-TYPE
               THRU 5405-EDIT-TREATY-TYPE-X.
           MOVE +3                    TO WS-LINE.
           PERFORM 5410-EDIT-REIN-TYPE
               THRU 5410-EDIT-REIN-TYPE-X.
           MOVE +4                    TO WS-LINE.
           PERFORM 5415-EDIT-BASE-TREATY
               THRU 5415-EDIT-BASE-TREATY-X.
           MOVE +5                    TO WS-LINE.
           PERFORM 5420-EDIT-WP-TREATY
               THRU 5420-EDIT-WP-TREATY-X.
           MOVE +6                    TO WS-LINE.
           PERFORM 5425-EDIT-AD-TREATY
               THRU 5425-EDIT-AD-TREATY-X.
           MOVE +7                    TO WS-LINE.
           PERFORM 5430-EDIT-FE-TREATY
               THRU 5430-EDIT-FE-TREATY-X.
           MOVE +8                    TO WS-LINE.
           PERFORM 5435-EDIT-MULT-TREATY
               THRU 5435-EDIT-MULT-TREATY-X.

       5310-EDIT-SCRN-01-X.
           EXIT.

      *------------------
       5320-EDIT-SCRN-02.
      *------------------

           MOVE +1                    TO WS-LINE.
           PERFORM 5440-EDIT-HOSP-TREATY
               THRU 5440-EDIT-HOSP-TREATY-X.
           MOVE +2                    TO WS-LINE.
           PERFORM 5445-EDIT-OCC-TREATY
               THRU 5445-EDIT-OCC-TREATY-X.
           MOVE +3                    TO WS-LINE.
           PERFORM 5450-EDIT-LTA-TREATY
               THRU 5450-EDIT-LTA-TREATY-X.
           MOVE +4                    TO WS-LINE.
           PERFORM 5455-EDIT-LTB-TREATY
               THRU 5455-EDIT-LTB-TREATY-X.
           MOVE +5                    TO WS-LINE.
           PERFORM 5460-EDIT-PDIS-TREATY
               THRU 5460-EDIT-PDIS-TREATY-X.
           MOVE +6                    TO WS-LINE.
           PERFORM 5465-EDIT-COLA-TREATY
               THRU 5465-EDIT-COLA-TREATY-X.

       5320-EDIT-SCRN-02-X.
           EXIT.

      *------------------
       5330-EDIT-SCRN-03.
      *------------------

           MOVE +1                    TO WS-LINE.
           PERFORM 5470-EDIT-EFF-DATE
               THRU 5470-EDIT-EFF-DATE-X.
           MOVE +2                    TO WS-LINE.
           PERFORM 5475-EDIT-TERM-DATE
               THRU 5475-EDIT-TERM-DATE-X.
           MOVE +3                    TO WS-LINE.
           PERFORM 5480-EDIT-MIN-CESSION
               THRU 5480-EDIT-MIN-CESSION-X.
           MOVE +4                    TO WS-LINE.
           PERFORM 5485-EDIT-MAX-CESSION
               THRU 5485-EDIT-MAX-CESSION-X.
           MOVE +5                    TO WS-LINE.
           PERFORM 5490-EDIT-1ST-LETTER
               THRU 5490-EDIT-1ST-LETTER-X.
           MOVE +6                    TO WS-LINE.
           PERFORM 5495-EDIT-2ND-LETTER
               THRU 5495-EDIT-2ND-LETTER-X.
           MOVE +7                    TO WS-LINE.
           PERFORM 5500-EDIT-1ST-COMPANY
               THRU 5500-EDIT-1ST-COMPANY-X.
           MOVE +8                    TO WS-LINE.
           PERFORM 5505-EDIT-2ND-COMPANY
               THRU 5505-EDIT-2ND-COMPANY-X.
           MOVE +9                    TO WS-LINE.
           PERFORM 5510-EDIT-3RD-COMPANY
               THRU 5510-EDIT-3RD-COMPANY-X.
           MOVE +10                   TO WS-LINE.
           PERFORM 5515-EDIT-RECAP-TYPE
               THRU 5515-EDIT-RECAP-TYPE-X.
           MOVE +11                   TO WS-LINE.
           PERFORM 5520-EDIT-RECAP-YEARS
               THRU 5520-EDIT-RECAP-YEARS-X.

           PERFORM 5920-XEDIT-SCRN-03
               THRU 5920-XEDIT-SCRN-03-X.

       5330-EDIT-SCRN-03-X.
           EXIT.
      /
      *------------------
       5400-EDIT-PLAN-RS.
      *------------------

           IF MIR-TRTY-CSN-PLAN-ID = SPACES
               MOVE RTT-TRTY-CSN-PLAN-ID
                                      TO MIR-TRTY-CSN-PLAN-ID
               GO TO 5400-EDIT-PLAN-RS-X
557660     END-IF.

           IF MIR-TRTY-CSN-PLAN-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-CSN-PLAN-ID
557660     END-IF.

023744* SAVE CURRENT PLAN HEADER THAT IS READ-FOR-UPDATE
023744     MOVE RPH-REC-INFO          TO HPH-REC-INFO.
           MOVE MIR-TRTY-CSN-PLAN-ID  TO WPH-PLAN-ID.

           PERFORM PH-1000-READ
              THRU PH-1000-READ-X.

023744* RESTORE PLAN HEADER FOR RE-WRITE
023744     MOVE HPH-REC-INFO          TO RPH-REC-INFO.
023744     MOVE RPH-KEY               TO WPH-KEY.

           IF NOT WPH-IO-OK
      *MSG:   (S) PLAN CODE/RS NOT FOUND ON PHDR
               MOVE 'CS03910019'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-CSN-PLAN-ID
                                      TO RTT-TRTY-CSN-PLAN-ID
557660     END-IF.

       5400-EDIT-PLAN-RS-X.
           EXIT.
      /
      *----------------------
       5405-EDIT-TREATY-TYPE.
      *----------------------

           IF MIR-TRTY-TYP-CD = SPACES
               MOVE RTT-TRTY-TYP-CD   TO MIR-TRTY-TYP-CD
               GO TO 5405-EDIT-TREATY-TYPE-X
557660     END-IF.

           IF MIR-TRTY-TYP-CD  = EBLCH-BLANK-FIELD-CHAR
               MOVE 'A'               TO MIR-TRTY-TYP-CD
               MOVE 'A'               TO RTT-TRTY-TYP-CD
               GO TO 5405-EDIT-TREATY-TYPE-X
557660     END-IF.

           MOVE MIR-TRTY-TYP-CD       TO WS-TREATY-TYPE.

           IF NOT WS-TREATY-TYPE-VALID
      *MSG:   (S) TREATY TYPE MUST BE A OR F
               MOVE 'CS03910004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-TYP-CD   TO RTT-TRTY-TYP-CD
557660     END-IF.

       5405-EDIT-TREATY-TYPE-X.
           EXIT.
      /
      *--------------------
       5410-EDIT-REIN-TYPE.
      *--------------------

           IF MIR-TRTY-REINS-TYP-CD = SPACES
               MOVE RTT-TRTY-REINS-TYP-CD
                                      TO MIR-TRTY-REINS-TYP-CD
               GO TO 5410-EDIT-REIN-TYPE-X
557660     END-IF.

           IF MIR-TRTY-REINS-TYP-CD  = EBLCH-BLANK-FIELD-CHAR
               MOVE 'Y'               TO MIR-TRTY-REINS-TYP-CD
               MOVE 'Y'               TO RTT-TRTY-REINS-TYP-CD
               GO TO 5410-EDIT-REIN-TYPE-X
557660     END-IF.

           MOVE MIR-TRTY-REINS-TYP-CD TO WS-REINSURANCE-TYPE.

           IF NOT WS-REINSURANCE-TYPE-VALID
      *MSG:   (S) REINSURANCE TYPE MUST BE Y, C OR B
               MOVE 'CS03910005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-REINS-TYP-CD
                                      TO RTT-TRTY-REINS-TYP-CD
557660     END-IF.

       5410-EDIT-REIN-TYPE-X.
           EXIT.
      /
      *----------------------
       5415-EDIT-BASE-TREATY.
      *----------------------

           IF MIR-TRTY-LIFE-ALLOW-ID   = SPACES
               MOVE RTT-TRTY-LIFE-ALLOW-ID
                                      TO MIR-TRTY-LIFE-ALLOW-ID
               GO TO 5415-EDIT-BASE-TREATY-X
557660     END-IF.

           IF MIR-TRTY-LIFE-ALLOW-ID  = '999'
               MOVE MIR-TRTY-LIFE-ALLOW-ID
                                      TO RTT-TRTY-LIFE-ALLOW-ID
               GO TO 5415-EDIT-BASE-TREATY-X
557660     END-IF.

           IF MIR-TRTY-LIFE-ALLOW-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-LIFE-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-TRTY-LIFE-ALLOW-ID              TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-LIFE-ALLOW-ID
                                      TO RTT-TRTY-LIFE-ALLOW-ID
557660     END-IF.

       5415-EDIT-BASE-TREATY-X.
           EXIT.
      /
      *--------------------
       5420-EDIT-WP-TREATY.
      *--------------------

           IF MIR-TRTY-WP-ALLOW-ID   = SPACES
               MOVE RTT-TRTY-WP-ALLOW-ID
                                      TO MIR-TRTY-WP-ALLOW-ID
               GO TO 5420-EDIT-WP-TREATY-X
557660     END-IF.

           IF MIR-TRTY-WP-ALLOW-ID  = '999'
               MOVE MIR-TRTY-WP-ALLOW-ID
                                      TO RTT-TRTY-WP-ALLOW-ID
               GO TO 5420-EDIT-WP-TREATY-X
557660     END-IF.

           IF MIR-TRTY-WP-ALLOW-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-WP-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-TRTY-WP-ALLOW-ID  TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-WP-ALLOW-ID
                                      TO RTT-TRTY-WP-ALLOW-ID
557660     END-IF.

       5420-EDIT-WP-TREATY-X.
           EXIT.
      /
      *--------------------
       5425-EDIT-AD-TREATY.
      *--------------------

           IF MIR-TRTY-AD-ALLOW-ID  = SPACES
               MOVE RTT-TRTY-AD-ALLOW-ID
                                      TO MIR-TRTY-AD-ALLOW-ID
               GO TO 5425-EDIT-AD-TREATY-X
557660     END-IF.

           IF MIR-TRTY-AD-ALLOW-ID = '999'
               MOVE MIR-TRTY-AD-ALLOW-ID
                                      TO RTT-TRTY-AD-ALLOW-ID
               GO TO 5425-EDIT-AD-TREATY-X
557660     END-IF.

           IF MIR-TRTY-AD-ALLOW-ID    = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-AD-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-TRTY-AD-ALLOW-ID  TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-AD-ALLOW-ID
                                      TO RTT-TRTY-AD-ALLOW-ID
557660     END-IF.

       5425-EDIT-AD-TREATY-X.
           EXIT.
      /
      *--------------------
       5430-EDIT-FE-TREATY.
      *--------------------

           IF MIR-TRTY-FE-ALLOW-ID  = SPACES
               MOVE RTT-TRTY-FE-ALLOW-ID
                                      TO MIR-TRTY-FE-ALLOW-ID
               GO TO 5430-EDIT-FE-TREATY-X
557660     END-IF.

           IF MIR-TRTY-FE-ALLOW-ID  = '999'
               MOVE MIR-TRTY-FE-ALLOW-ID
                                      TO RTT-TRTY-FE-ALLOW-ID
               GO TO 5430-EDIT-FE-TREATY-X
557660     END-IF.

           IF MIR-TRTY-FE-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-FE-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-TRTY-FE-ALLOW-ID  TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-FE-ALLOW-ID
                                      TO RTT-TRTY-FE-ALLOW-ID
557660     END-IF.

       5430-EDIT-FE-TREATY-X.
           EXIT.
      /
      *----------------------
       5435-EDIT-MULT-TREATY.
      *----------------------

           IF MIR-TRTY-ME-ALLOW-ID  = SPACES
               MOVE RTT-TRTY-ME-ALLOW-ID
                                      TO MIR-TRTY-ME-ALLOW-ID
               GO TO 5435-EDIT-MULT-TREATY-X
557660     END-IF.

           IF MIR-TRTY-ME-ALLOW-ID  = '999'
               MOVE MIR-TRTY-ME-ALLOW-ID
                                      TO RTT-TRTY-ME-ALLOW-ID
               GO TO 5435-EDIT-MULT-TREATY-X
557660     END-IF.

           IF MIR-TRTY-ME-ALLOW-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-ME-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-TRTY-ME-ALLOW-ID  TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-ME-ALLOW-ID
                                      TO RTT-TRTY-ME-ALLOW-ID
557660     END-IF.

       5435-EDIT-MULT-TREATY-X.
           EXIT.
      /
      *----------------------
       5440-EDIT-HOSP-TREATY.
      *----------------------

           IF MIR-REDC-EP-ALLOW-ID = SPACES
               MOVE RTT-REDC-EP-ALLOW-ID
                                      TO MIR-REDC-EP-ALLOW-ID
               GO TO 5440-EDIT-HOSP-TREATY-X
557660     END-IF.

           IF MIR-REDC-EP-ALLOW-ID = '999'
               MOVE MIR-REDC-EP-ALLOW-ID
                                      TO RTT-REDC-EP-ALLOW-ID
               GO TO 5440-EDIT-HOSP-TREATY-X
557660     END-IF.

           IF MIR-REDC-EP-ALLOW-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-REDC-EP-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-REDC-EP-ALLOW-ID  TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-REDC-EP-ALLOW-ID
                                      TO RTT-REDC-EP-ALLOW-ID
557660     END-IF.

       5440-EDIT-HOSP-TREATY-X.
           EXIT.
      /
      *---------------------
       5445-EDIT-OCC-TREATY.
      *---------------------

           IF MIR-OWN-OCCP-ALLOW-ID = SPACES
               MOVE RTT-OWN-OCCP-ALLOW-ID
                                      TO MIR-OWN-OCCP-ALLOW-ID
               GO TO 5445-EDIT-OCC-TREATY-X
557660     END-IF.

           IF MIR-OWN-OCCP-ALLOW-ID = '999'
               MOVE MIR-OWN-OCCP-ALLOW-ID
                                      TO RTT-OWN-OCCP-ALLOW-ID
               GO TO 5445-EDIT-OCC-TREATY-X
557660     END-IF.

           IF MIR-OWN-OCCP-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-OWN-OCCP-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-OWN-OCCP-ALLOW-ID TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-OWN-OCCP-ALLOW-ID
                                      TO RTT-OWN-OCCP-ALLOW-ID
557660     END-IF.

       5445-EDIT-OCC-TREATY-X.
           EXIT.
      /
      *---------------------
       5450-EDIT-LTA-TREATY.
      *---------------------

           IF MIR-TRTY-LTA-ALLOW-ID  = SPACES
               MOVE RTT-TRTY-LTA-ALLOW-ID
                                      TO MIR-TRTY-LTA-ALLOW-ID
               GO TO 5450-EDIT-LTA-TREATY-X
557660     END-IF.

           IF MIR-TRTY-LTA-ALLOW-ID  = '999'
               MOVE MIR-TRTY-LTA-ALLOW-ID
                                      TO RTT-TRTY-LTA-ALLOW-ID
               GO TO 5450-EDIT-LTA-TREATY-X
557660     END-IF.

           IF MIR-TRTY-LTA-ALLOW-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-LTA-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-TRTY-LTA-ALLOW-ID TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-LTA-ALLOW-ID
                                      TO RTT-TRTY-LTA-ALLOW-ID
557660     END-IF.

       5450-EDIT-LTA-TREATY-X.
           EXIT.
      /
      *---------------------
       5455-EDIT-LTB-TREATY.
      *---------------------

           IF MIR-TRTY-LTB-ALLOW-ID = SPACES
               MOVE RTT-TRTY-LTB-ALLOW-ID
                                      TO MIR-TRTY-LTB-ALLOW-ID
               GO TO 5455-EDIT-LTB-TREATY-X
557660     END-IF.

           IF MIR-TRTY-LTB-ALLOW-ID  = '999'
               MOVE MIR-TRTY-LTB-ALLOW-ID
                                      TO RTT-TRTY-LTB-ALLOW-ID
               GO TO 5455-EDIT-LTB-TREATY-X
557660     END-IF.

           IF MIR-TRTY-LTB-ALLOW-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-LTB-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-TRTY-LTB-ALLOW-ID TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-LTB-ALLOW-ID
                                      TO RTT-TRTY-LTB-ALLOW-ID
557660     END-IF.

       5455-EDIT-LTB-TREATY-X.
           EXIT.
      /
      *----------------------
       5460-EDIT-PDIS-TREATY.
      *----------------------

           IF MIR-PDISAB-ALLOW-ID  = SPACES
               MOVE RTT-PDISAB-ALLOW-ID
                                      TO MIR-PDISAB-ALLOW-ID
               GO TO 5460-EDIT-PDIS-TREATY-X
557660     END-IF.

           IF MIR-PDISAB-ALLOW-ID = '999'
               MOVE MIR-PDISAB-ALLOW-ID
                                      TO RTT-PDISAB-ALLOW-ID
               GO TO 5460-EDIT-PDIS-TREATY-X
557660     END-IF.

           IF MIR-PDISAB-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PDISAB-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-PDISAB-ALLOW-ID   TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-PDISAB-ALLOW-ID
                                      TO RTT-PDISAB-ALLOW-ID
557660     END-IF.

       5460-EDIT-PDIS-TREATY-X.
           EXIT.
      /
      *----------------------
       5465-EDIT-COLA-TREATY.
      *----------------------

           IF MIR-TRTY-COLA-ALLOW-ID  = SPACES
               MOVE RTT-TRTY-COLA-ALLOW-ID
                                      TO MIR-TRTY-COLA-ALLOW-ID
               GO TO 5465-EDIT-COLA-TREATY-X
557660     END-IF.

           IF MIR-TRTY-COLA-ALLOW-ID  = '999'
               MOVE MIR-TRTY-COLA-ALLOW-ID
                                      TO RTT-TRTY-COLA-ALLOW-ID
               GO TO 5465-EDIT-COLA-TREATY-X
557660     END-IF.

           IF MIR-TRTY-COLA-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-COLA-ALLOW-ID
557660     END-IF.

           MOVE MIR-TRTY-ASSUM-CO-ID  TO WCC-RTBL2-ID-1-2.
           MOVE MIR-TRTY-COLA-ALLOW-ID              TO WCC-RTBL2-ID-3-5.

           PERFORM CC-1000-READ
               THRU CC-1000-READ-X.

           IF NOT WCC-IO-OK
      *MSG:   (S) TREATY NOT FOUND IN PCNT
               MOVE 'CS03910016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-TRTY-COLA-ALLOW-ID
                                      TO RTT-TRTY-COLA-ALLOW-ID
557660     END-IF.

       5465-EDIT-COLA-TREATY-X.
           EXIT.
      /
      *-------------------
       5470-EDIT-EFF-DATE.
      *-------------------

           IF MIR-TRTY-EFF-DT  = SPACES
               MOVE RTT-TRTY-EFF-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-TRTY-EFF-DT
               GO TO 5470-EDIT-EFF-DATE-X
557660     END-IF.

           IF MIR-TRTY-EFF-DT  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-EFF-DT
               MOVE WWKDT-ZERO-DT     TO RTT-TRTY-EFF-DT
               GO TO 5470-EDIT-EFF-DATE-X
557660     END-IF.

           MOVE MIR-TRTY-EFF-DT       TO L1640-EXTERNAL-DATE
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
      *MSG:   (S) DATE MUST BE VALID IN DDMMMYYYY FORMAT
               MOVE 'CS03910014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO RTT-TRTY-EFF-DT
557660     END-IF.

       5470-EDIT-EFF-DATE-X.
           EXIT.
      /
      *--------------------
       5475-EDIT-TERM-DATE.
      *--------------------

           IF MIR-TRTY-TRMN-DT  = SPACES
               MOVE RTT-TRTY-TRMN-DT  TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-TRTY-TRMN-DT
               GO TO 5475-EDIT-TERM-DATE-X
557660     END-IF.

           IF MIR-TRTY-TRMN-DT  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TRTY-TRMN-DT
               MOVE WWKDT-ZERO-DT     TO RTT-TRTY-TRMN-DT
               GO TO 5475-EDIT-TERM-DATE-X
557660     END-IF.

           MOVE MIR-TRTY-TRMN-DT      TO L1640-EXTERNAL-DATE
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
      *MSG:   (S) DATE MUST BE VALID IN DDMMMYYYY FORMAT
               MOVE 'CS03910014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO RTT-TRTY-TRMN-DT
557660     END-IF.

       5475-EDIT-TERM-DATE-X.
           EXIT.
      /
      *----------------------
       5480-EDIT-MIN-CESSION.
      *----------------------

           IF MIR-TRTY-RSK-MIN-AMT = SPACES
557973*        MOVE RTT-TRTY-RSK-MIN-AMT-N TO MIR-TRTY-RSK-MIN-AMT
008455*        MOVE RTT-TRTY-RSK-MIN-AMT   TO WS-EDIT-9
008455*        MOVE WS-EDIT-9              TO MIR-TRTY-RSK-MIN-AMT
008455         MOVE RTT-TRTY-RSK-MIN-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-TRTY-RSK-MIN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-TRTY-RSK-MIN-AMT
               GO TO 5480-EDIT-MIN-CESSION-X
557660     END-IF.

           IF MIR-TRTY-RSK-MIN-AMT = EBLCH-BLANK-FIELD-CHAR
557973*        MOVE ZEROS                  TO RTT-TRTY-RSK-MIN-AMT-N
557973*        MOVE RTT-TRTY-RSK-MIN-AMT-N TO MIR-TRTY-RSK-MIN-AMT
557973         MOVE ZEROS             TO RTT-TRTY-RSK-MIN-AMT
008455*        MOVE RTT-TRTY-RSK-MIN-AMT   TO MIR-TRTY-RSK-MIN-AMT
008455         MOVE ZEROS             TO MIR-TRTY-RSK-MIN-AMT
               GO TO 5480-EDIT-MIN-CESSION-X
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
008455*    MOVE 9                         TO L0280-LENGTH.
008455*    MOVE 9                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-TRTY-RSK-MIN-AMT
                                      TO L0280-INPUT-SIZE
008455                                       L0280-LENGTH.
           MOVE MIR-TRTY-RSK-MIN-AMT  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
557973*        MOVE L0280-OUTPUT          TO RTT-TRTY-RSK-MIN-AMT-N
557973*        MOVE RTT-TRTY-RSK-MIN-AMT-N TO MIR-TRTY-RSK-MIN-AMT
557973         MOVE L0280-OUTPUT      TO RTT-TRTY-RSK-MIN-AMT
008455*        MOVE RTT-TRTY-RSK-MIN-AMT  TO WS-EDIT-9
008455*        MOVE WS-EDIT-9             TO MIR-TRTY-RSK-MIN-AMT
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-TRTY-RSK-MIN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-TRTY-RSK-MIN-AMT
           ELSE
      *MSG:   (S) DATA MUST BE NUMERIC
               MOVE 'CS00000032'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557973         MOVE 'N'               TO WS-DATA-VALID-SW
557660     END-IF.

       5480-EDIT-MIN-CESSION-X.
           EXIT.
      /
      *----------------------
       5485-EDIT-MAX-CESSION.
      *----------------------

           IF MIR-TRTY-RSK-MAX-AMT = SPACES
557973*        MOVE RTT-TRTY-RSK-MAX-AMT-N TO MIR-TRTY-RSK-MAX-AMT
008455*        MOVE RTT-TRTY-RSK-MAX-AMT  TO WS-EDIT-9
008455*        MOVE WS-EDIT-9             TO MIR-TRTY-RSK-MAX-AMT
008455         MOVE RTT-TRTY-RSK-MAX-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-TRTY-RSK-MAX-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-TRTY-RSK-MAX-AMT
               GO TO 5485-EDIT-MAX-CESSION-X
557660     END-IF.

           IF MIR-TRTY-RSK-MAX-AMT = EBLCH-BLANK-FIELD-CHAR
557973*        MOVE ZEROS                 TO RTT-TRTY-RSK-MAX-AMT-N
557973*        MOVE RTT-TRTY-RSK-MAX-AMT-N TO MIR-TRTY-RSK-MAX-AMT
557973         MOVE ZEROS             TO RTT-TRTY-RSK-MAX-AMT
008455*        MOVE RTT-TRTY-RSK-MAX-AMT  TO MIR-TRTY-RSK-MAX-AMT
008455         MOVE ZEROS             TO MIR-TRTY-RSK-MAX-AMT
               GO TO 5485-EDIT-MAX-CESSION-X
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
008455*    MOVE 9                         TO L0280-LENGTH.
008455*    MOVE 9                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-TRTY-RSK-MAX-AMT
                                      TO L0280-INPUT-SIZE
008455                                       L0280-LENGTH.
           MOVE MIR-TRTY-RSK-MAX-AMT  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
557973*        MOVE L0280-OUTPUT          TO RTT-TRTY-RSK-MAX-AMT-N
557973         MOVE L0280-OUTPUT      TO RTT-TRTY-RSK-MAX-AMT
557973*        MOVE RTT-TRTY-RSK-MAX-AMT-N TO MIR-TRTY-RSK-MAX-AMT
008455*        MOVE RTT-TRTY-RSK-MAX-AMT  TO WS-EDIT-9
008455*        MOVE WS-EDIT-9             TO MIR-TRTY-RSK-MAX-AMT
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-TRTY-RSK-MAX-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-TRTY-RSK-MAX-AMT
           ELSE
      *MSG:   (S) DATA MUST BE NUMERIC
               MOVE 'CS00000032'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557973         MOVE 'N'               TO WS-DATA-VALID-SW
557660     END-IF.

       5485-EDIT-MAX-CESSION-X.
           EXIT.
      /
      *---------------------
       5490-EDIT-1ST-LETTER.
      *---------------------

           IF MIR-ALPHA-SPLT-1-TXT  = SPACES
               MOVE RTT-ALPHA-SPLT-1-TXT
                                      TO MIR-ALPHA-SPLT-1-TXT
               GO TO 5490-EDIT-1ST-LETTER-X
557660     END-IF.

           IF MIR-ALPHA-SPLT-1-TXT  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO RTT-ALPHA-SPLT-1-TXT
               MOVE SPACE             TO MIR-ALPHA-SPLT-1-TXT
               GO TO 5490-EDIT-1ST-LETTER-X
557660     END-IF.

557698     PERFORM 0005-1000-BUILD-PARM-INFO
557698        THRU 0005-1000-BUILD-PARM-INFO-X.
557698     MOVE MIR-ALPHA-SPLT-1-TXT  TO L0005-INPUT-STRING.
557698     PERFORM 0005-2000-CONVERT-NO-ACCENTS
557698        THRU 0005-2000-CONVERT-NO-ACCENTS-X.
557698     IF L0005-RETRN-OK
557698         MOVE L0005-OUTPUT-STRING
                                      TO MIR-ALPHA-SPLT-1-TXT
557698     END-IF.

           IF MIR-ALPHA-SPLT-1-TXT  ALPHABETIC
               MOVE MIR-ALPHA-SPLT-1-TXT
                                      TO RTT-ALPHA-SPLT-1-TXT
               MOVE RTT-ALPHA-SPLT-1-TXT
                                      TO MIR-ALPHA-SPLT-1-TXT
           ELSE
      *MSG:   (S) VALUE MUST BE A LETTER
               MOVE 'CS03910010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
557660     END-IF.

       5490-EDIT-1ST-LETTER-X.
           EXIT.
      /
      *---------------------
       5495-EDIT-2ND-LETTER.
      *---------------------

           IF MIR-ALPHA-SPLT-2-TXT  = SPACES
               MOVE RTT-ALPHA-SPLT-2-TXT
                                      TO MIR-ALPHA-SPLT-2-TXT
               GO TO 5495-EDIT-2ND-LETTER-X
557660     END-IF.

           IF MIR-ALPHA-SPLT-2-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO RTT-ALPHA-SPLT-2-TXT
               MOVE SPACE             TO MIR-ALPHA-SPLT-2-TXT
               GO TO 5495-EDIT-2ND-LETTER-X
557660     END-IF.

557698     PERFORM 0005-1000-BUILD-PARM-INFO
557698        THRU 0005-1000-BUILD-PARM-INFO-X.
557698     MOVE MIR-ALPHA-SPLT-2-TXT  TO L0005-INPUT-STRING.
557698     PERFORM 0005-2000-CONVERT-NO-ACCENTS
557698        THRU 0005-2000-CONVERT-NO-ACCENTS-X.
557698     IF L0005-RETRN-OK
557698         MOVE L0005-OUTPUT-STRING
                                      TO MIR-ALPHA-SPLT-2-TXT
557698     END-IF.

           IF MIR-ALPHA-SPLT-2-TXT  ALPHABETIC
               MOVE MIR-ALPHA-SPLT-2-TXT
                                      TO RTT-ALPHA-SPLT-2-TXT
               MOVE RTT-ALPHA-SPLT-2-TXT
                                      TO MIR-ALPHA-SPLT-2-TXT
           ELSE
      *MSG:   (S) VALUE MUST BE A LETTER
               MOVE 'CS03910010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
557660     END-IF.

       5495-EDIT-2ND-LETTER-X.
           EXIT.
      /
      *----------------------
       5500-EDIT-1ST-COMPANY.
      *----------------------

           IF MIR-ALPHA-SPLT-1-CO-ID  = SPACES
               MOVE RTT-ALPHA-SPLT-1-CO-ID
                                      TO MIR-ALPHA-SPLT-1-CO-ID
               GO TO 5500-EDIT-1ST-COMPANY-X
557660     END-IF.

           IF MIR-ALPHA-SPLT-1-CO-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE MIR-TRTY-ASSUM-CO-ID
                                      TO RTT-ALPHA-SPLT-1-CO-ID
               MOVE MIR-TRTY-ASSUM-CO-ID
                                      TO MIR-ALPHA-SPLT-1-CO-ID
               GO TO 5500-EDIT-1ST-COMPANY-X
557660     END-IF.

           MOVE MIR-ALPHA-SPLT-1-CO-ID            TO WEDIT-ETBL-VALU-ID.
           PERFORM REIN-1000-EDIT
               THRU REIN-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
      *MSG:   (S) COMPANY MUST BE ON ETAB TYPE 'REIN'
               MOVE 'CS03910012'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-ALPHA-SPLT-1-CO-ID
                                      TO RTT-ALPHA-SPLT-1-CO-ID
557660     END-IF.

       5500-EDIT-1ST-COMPANY-X.
           EXIT.
      /
      *----------------------
       5505-EDIT-2ND-COMPANY.
      *----------------------

           IF MIR-ALPHA-SPLT-2-CO-ID   = SPACES
               MOVE RTT-ALPHA-SPLT-2-CO-ID
                                      TO MIR-ALPHA-SPLT-2-CO-ID
               GO TO 5505-EDIT-2ND-COMPANY-X
557660     END-IF.

           IF MIR-ALPHA-SPLT-2-CO-ID = 'XX'
               MOVE MIR-ALPHA-SPLT-2-CO-ID
                                      TO RTT-ALPHA-SPLT-2-CO-ID
               GO TO 5505-EDIT-2ND-COMPANY-X
557660     END-IF.

           IF MIR-ALPHA-SPLT-2-CO-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE 'XX'              TO RTT-ALPHA-SPLT-2-CO-ID
               MOVE RTT-ALPHA-SPLT-2-CO-ID
                                      TO MIR-ALPHA-SPLT-2-CO-ID
               GO TO 5505-EDIT-2ND-COMPANY-X
557660     END-IF.

           MOVE MIR-ALPHA-SPLT-2-CO-ID            TO WEDIT-ETBL-VALU-ID.
           PERFORM REIN-1000-EDIT
              THRU REIN-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
      *MSG:   (S) COMPANY MUST BE XX OR ON ETAB TYPE 'REIN'
               MOVE 'CS03910021'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-ALPHA-SPLT-2-CO-ID
                                      TO RTT-ALPHA-SPLT-2-CO-ID
557660     END-IF.

       5505-EDIT-2ND-COMPANY-X.
           EXIT.
      /
      *----------------------
       5510-EDIT-3RD-COMPANY.
      *----------------------

           IF MIR-ALPHA-SPLT-3-CO-ID  = SPACES
               MOVE RTT-ALPHA-SPLT-3-CO-ID
                                      TO MIR-ALPHA-SPLT-3-CO-ID
               GO TO 5510-EDIT-3RD-COMPANY-X
557660     END-IF.

           IF MIR-ALPHA-SPLT-3-CO-ID  = 'XX'
               MOVE MIR-ALPHA-SPLT-3-CO-ID
                                      TO RTT-ALPHA-SPLT-3-CO-ID
               GO TO 5510-EDIT-3RD-COMPANY-X
557660     END-IF.

           IF MIR-ALPHA-SPLT-3-CO-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE 'XX'              TO RTT-ALPHA-SPLT-3-CO-ID
               MOVE RTT-ALPHA-SPLT-3-CO-ID
                                      TO MIR-ALPHA-SPLT-3-CO-ID
               GO TO 5510-EDIT-3RD-COMPANY-X
557660     END-IF.

           MOVE MIR-ALPHA-SPLT-3-CO-ID            TO WEDIT-ETBL-VALU-ID.
           PERFORM REIN-1000-EDIT
              THRU REIN-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
      *MSG:   (S) COMPANY MUST BE XX OR ON ETAB TYPE 'REIN'
               MOVE 'CS03910021'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
           ELSE
               MOVE MIR-ALPHA-SPLT-3-CO-ID
                                      TO RTT-ALPHA-SPLT-3-CO-ID
557660     END-IF.

       5510-EDIT-3RD-COMPANY-X.
           EXIT.
      /
      *---------------------
       5515-EDIT-RECAP-TYPE.
      *---------------------

           IF MIR-TRTY-RECAP-TYP-CD  = SPACES
               MOVE RTT-TRTY-RECAP-TYP-CD
                                      TO MIR-TRTY-RECAP-TYP-CD
               GO TO 5515-EDIT-RECAP-TYPE-X
557660     END-IF.

           IF MIR-TRTY-RECAP-TYP-CD  = EBLCH-BLANK-FIELD-CHAR
               MOVE 'B'               TO RTT-TRTY-RECAP-TYP-CD
               MOVE RTT-TRTY-RECAP-TYP-CD
                                      TO MIR-TRTY-RECAP-TYP-CD
               GO TO 5515-EDIT-RECAP-TYPE-X
557660     END-IF.

           MOVE MIR-TRTY-RECAP-TYP-CD TO WS-RECAPTURE-TYPE.

           IF WS-RECAPTURE-TYPE-VALID
               MOVE MIR-TRTY-RECAP-TYP-CD
                                      TO RTT-TRTY-RECAP-TYP-CD
           ELSE
      *MSG:   (S) RECAP TYPE MUST BE A, B OR C
               MOVE 'CS03910011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
557660     END-IF.

       5515-EDIT-RECAP-TYPE-X.
           EXIT.
      /
      *----------------------
       5520-EDIT-RECAP-YEARS.
      *----------------------

           IF MIR-TRTY-RECAP-AGE-DUR  = SPACES
               MOVE RTT-TRTY-RECAP-AGE-DUR-N
                                      TO MIR-TRTY-RECAP-AGE-DUR
               GO TO 5520-EDIT-RECAP-YEARS-X
557660     END-IF.

           IF MIR-TRTY-RECAP-AGE-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO RTT-TRTY-RECAP-AGE-DUR-N
               MOVE RTT-TRTY-RECAP-AGE-DUR-N
                                      TO MIR-TRTY-RECAP-AGE-DUR
               GO TO 5520-EDIT-RECAP-YEARS-X
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-TRTY-RECAP-AGE-DUR              TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO RTT-TRTY-RECAP-AGE-DUR-N
               MOVE RTT-TRTY-RECAP-AGE-DUR-N
                                      TO MIR-TRTY-RECAP-AGE-DUR
           ELSE
      *MSG:   (S) DATA MUST BE NUMERIC
               MOVE 'CS00000032'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-VALID-SW
557660     END-IF.

       5520-EDIT-RECAP-YEARS-X.
           EXIT.
      /
      *-------------------
       5920-XEDIT-SCRN-03.
      *-------------------

           IF RTT-TRTY-TRMN-DT    NOT = WWKDT-ZERO-DT
               IF RTT-TRTY-TRMN-DT    < RTT-TRTY-EFF-DT
      *MSG:   (S) TERMINATION DATE IS BEFORE EFFECTIVE DATE
                   MOVE 'CS03910017'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

557973*    IF RTT-TRTY-RSK-MIN-AMT-N > RTT-TRTY-RSK-MAX-AMT-N
557973     IF RTT-TRTY-RSK-MIN-AMT > RTT-TRTY-RSK-MAX-AMT
      *MSG:   (S) TRIVIAL IS GREATER THAN MAXIMUM
               MOVE 'CS03910018'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557973         MOVE 'N'               TO WS-DATA-VALID-SW
557660     END-IF.

           IF RTT-ALPHA-SPLT-2-TXT < RTT-ALPHA-SPLT-1-TXT
               MOVE 'Z'               TO RTT-ALPHA-SPLT-2-TXT
               MOVE RTT-ALPHA-SPLT-2-TXT
                                      TO MIR-ALPHA-SPLT-2-TXT
      *MSG:   (S) SPLIT 2 MUST COME AFTER SPLIT 1
               MOVE 'CS03910013'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557973         MOVE 'N'               TO WS-DATA-VALID-SW
557660     END-IF.

           IF RTT-ALPHA-SPLT-1-TXT NOT = 'Z'
           AND RTT-ALPHA-SPLT-2-CO-ID = 'XX'
      *MSG:   (S) COMPANY (@1) SHOULD BE ENTERED FOR SPLIT
               MOVE 'CS03910001'      TO WGLOB-MSG-REF-INFO
               MOVE '2'               TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF RTT-ALPHA-SPLT-1-TXT = 'Z'
               AND RTT-ALPHA-SPLT-2-CO-ID NOT = 'XX'
      *MSG:   (S) NO SPLIT .... COMPANY (@1) SHOULD NOT BE ENTERED
                   MOVE 'CS03910007'  TO WGLOB-MSG-REF-INFO
                   MOVE '2'           TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF RTT-ALPHA-SPLT-2-TXT NOT = 'Z'
           AND RTT-ALPHA-SPLT-3-CO-ID = 'XX'
      *MSG:   (S) COMPANY (@1) SHOULD BE ENTERED FOR SPLIT
               MOVE 'CS03910001'      TO WGLOB-MSG-REF-INFO
               MOVE '3'               TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF RTT-ALPHA-SPLT-2-TXT = 'Z'
               AND RTT-ALPHA-SPLT-3-CO-ID NOT = 'XX'
      *MSG:   (S) NO SPLIT .... COMPANY (@1) SHOULD NOT BE ENTERED
                   MOVE 'CS03910007'  TO WGLOB-MSG-REF-INFO
                   MOVE '3'           TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

       5920-XEDIT-SCRN-03-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

014221     PERFORM  PH-2000-UPDATE-TWRK-TS
014221         THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF WPH-IO-NOT-FOUND
014221*MSG: 'PLAN (@1) NOT FOUND'
014221         SET WS-DATA-VALID-NO   TO TRUE
014221         MOVE 'XS00000049'      TO WGLOB-MSG-REF-INFO
014221         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE'
014221         SET WS-DATA-VALID-NO   TO TRUE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'              TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  8000-BUILD-TRTY-KEY
               THRU 8000-BUILD-TRTY-KEY-X.

           PERFORM  TT-1000-READ-FOR-UPDATE
               THRU TT-1000-READ-FOR-UPDATE-X.

           IF NOT WTT-IO-OK
      *MSG:   (S) RECORD (@1) LOST IN MAINTAIN - CONTACT SYSTEMS
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WTT-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
           ELSE
      *MSG:   (I) TREATY RECORD DELETED
               MOVE 'CS03910008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  TT-1000-DELETE
                   THRU TT-1000-DELETE-X
014221         PERFORM  PH-2000-REWRITE
014221             THRU PH-2000-REWRITE-X
014221         PERFORM  PH-1000-READ-TWRK-TS
014221             THRU PH-1000-READ-TWRK-TS-X
557660     END-IF.


       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *--------------------
       8000-BUILD-TRTY-KEY.
      *--------------------

           MOVE MIR-PLAN-ID           TO WTT-PLAN-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WTT-SBSDRY-CO-ID.
           MOVE MIR-TRTY-SMKR-CD      TO WTT-TRTY-SMKR-CD.
           MOVE MIR-TRTY-ASSUM-CO-ID  TO WTT-TRTY-ASSUM-CO-ID.

       8000-BUILD-TRTY-KEY-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO  MIR-PLAN-ID-G.
010418     MOVE SPACES                TO  MIR-SBSDRY-CO-ID-G.
           MOVE SPACES                TO  MIR-TRTY-SMKR-CD-G.
           MOVE SPACES                TO  MIR-TRTY-ASSUM-CO-ID-G.
           MOVE SPACES                TO  MIR-TRTY-CSN-PLAN-ID-G.
           MOVE SPACES                TO  MIR-TRTY-TYP-CD-G.
           MOVE SPACES                TO  MIR-TRTY-REINS-TYP-CD-G.
           MOVE SPACES                TO  MIR-TRTY-CSN-PLAN-ID.
           MOVE SPACES                TO  MIR-TRTY-EFF-DT.
           MOVE SPACES                TO  MIR-TRTY-TYP-CD.
           MOVE SPACES                TO  MIR-TRTY-TRMN-DT.
           MOVE SPACES                TO  MIR-TRTY-REINS-TYP-CD.
           MOVE SPACES                TO  MIR-TRTY-RSK-MIN-AMT.
           MOVE SPACES                TO  MIR-TRTY-RSK-MAX-AMT.
           MOVE SPACES                TO  MIR-TRTY-LIFE-ALLOW-ID.
           MOVE SPACES                TO  MIR-REDC-EP-ALLOW-ID.
           MOVE SPACES                TO  MIR-TRTY-WP-ALLOW-ID.
           MOVE SPACES                TO  MIR-OWN-OCCP-ALLOW-ID.
           MOVE SPACES                TO  MIR-TRTY-AD-ALLOW-ID.
           MOVE SPACES                TO  MIR-TRTY-LTA-ALLOW-ID.
           MOVE SPACES                TO  MIR-TRTY-FE-ALLOW-ID.
           MOVE SPACES                TO  MIR-TRTY-LTB-ALLOW-ID.
           MOVE SPACES                TO  MIR-TRTY-ME-ALLOW-ID.
           MOVE SPACES                TO  MIR-PDISAB-ALLOW-ID.
           MOVE SPACES                TO  MIR-TRTY-COLA-ALLOW-ID.
           MOVE SPACES                TO  MIR-ALPHA-SPLT-1-TXT.
           MOVE SPACES                TO  MIR-ALPHA-SPLT-1-CO-ID.
           MOVE SPACES                TO  MIR-ALPHA-SPLT-2-TXT.
           MOVE SPACES                TO  MIR-ALPHA-SPLT-2-CO-ID.
           MOVE SPACES                TO  MIR-ALPHA-SPLT-3-CO-ID.
           MOVE SPACES                TO  MIR-TRTY-RECAP-TYP-CD.
           MOVE SPACES                TO  MIR-TRTY-RECAP-AGE-DUR.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RTT-TRTY-CSN-PLAN-ID  TO  MIR-TRTY-CSN-PLAN-ID.
           MOVE RTT-TRTY-EFF-DT       TO  L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO  MIR-TRTY-EFF-DT.
           MOVE RTT-TRTY-TYP-CD       TO  MIR-TRTY-TYP-CD.
           MOVE RTT-TRTY-TRMN-DT      TO  L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO  MIR-TRTY-TRMN-DT.
           MOVE RTT-TRTY-REINS-TYP-CD TO  MIR-TRTY-REINS-TYP-CD.
557973*    MOVE RTT-TRTY-RSK-MIN-AMT-N       TO  MIR-TRTY-RSK-MIN-AMT.
557973*    MOVE RTT-TRTY-RSK-MAX-AMT-N       TO  MIR-TRTY-RSK-MAX-AMT.
008455*    MOVE RTT-TRTY-RSK-MIN-AMT         TO  WS-EDIT-9.
008455*    MOVE WS-EDIT-9                    TO  MIR-TRTY-RSK-MIN-AMT.
020874*    MOVE RTT-TRTY-RSK-MIN-AMT  TO  L0290-INPUT-NUMBER.
020874     MOVE RTT-TRTY-RSK-MIN-AMT  TO  L0290-INPUT-V00.
008455     MOVE 0                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TRTY-RSK-MIN-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-TRTY-RSK-MIN-AMT.
008455
008455*    MOVE RTT-TRTY-RSK-MAX-AMT         TO  WS-EDIT-9.
008455*    MOVE WS-EDIT-9                    TO  MIR-TRTY-RSK-MAX-AMT.
020874*    MOVE RTT-TRTY-RSK-MAX-AMT  TO  L0290-INPUT-NUMBER.
020874     MOVE RTT-TRTY-RSK-MAX-AMT  TO  L0290-INPUT-V00.
008455     MOVE 0                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TRTY-RSK-MAX-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-TRTY-RSK-MAX-AMT.
008455
           MOVE RTT-TRTY-LIFE-ALLOW-ID       TO  MIR-TRTY-LIFE-ALLOW-ID.
           MOVE RTT-REDC-EP-ALLOW-ID  TO  MIR-REDC-EP-ALLOW-ID.
           MOVE RTT-TRTY-WP-ALLOW-ID  TO  MIR-TRTY-WP-ALLOW-ID.
           MOVE RTT-OWN-OCCP-ALLOW-ID TO  MIR-OWN-OCCP-ALLOW-ID.
           MOVE RTT-TRTY-AD-ALLOW-ID  TO  MIR-TRTY-AD-ALLOW-ID.
           MOVE RTT-TRTY-LTA-ALLOW-ID TO  MIR-TRTY-LTA-ALLOW-ID.
           MOVE RTT-TRTY-FE-ALLOW-ID  TO  MIR-TRTY-FE-ALLOW-ID.
           MOVE RTT-TRTY-LTB-ALLOW-ID TO  MIR-TRTY-LTB-ALLOW-ID.
           MOVE RTT-TRTY-ME-ALLOW-ID  TO  MIR-TRTY-ME-ALLOW-ID.
           MOVE RTT-PDISAB-ALLOW-ID   TO  MIR-PDISAB-ALLOW-ID.
           MOVE RTT-TRTY-COLA-ALLOW-ID       TO  MIR-TRTY-COLA-ALLOW-ID.
           MOVE RTT-ALPHA-SPLT-1-TXT  TO  MIR-ALPHA-SPLT-1-TXT.
           MOVE RTT-ALPHA-SPLT-1-CO-ID       TO  MIR-ALPHA-SPLT-1-CO-ID.
           MOVE RTT-ALPHA-SPLT-2-TXT  TO  MIR-ALPHA-SPLT-2-TXT.
           MOVE RTT-ALPHA-SPLT-2-CO-ID       TO  MIR-ALPHA-SPLT-2-CO-ID.
           MOVE RTT-ALPHA-SPLT-3-CO-ID       TO  MIR-ALPHA-SPLT-3-CO-ID.
           MOVE RTT-TRTY-RECAP-TYP-CD TO  MIR-TRTY-RECAP-TYP-CD.
           MOVE RTT-TRTY-RECAP-AGE-DUR-N
                                      TO  MIR-TRTY-RECAP-AGE-DUR.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0005-0000-INIT-PARM-INFO
025970         THRU 0005-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-COUNTERS.
025970     INITIALIZE WS-SWITCHES.
025970     INITIALIZE WS-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     SET WS-TWRK-KEY-DEFAULT    TO TRUE.
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.

025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPEREIN.
      /
025970 COPY XCPS8090.
557698 COPY XCPS0005.
557698 COPY XCPL0005.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.
      ****************************************************************
      * LINKAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************

018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
008455/
008455 COPY XCPS0290.
008455 COPY XCPL0290.
008455/
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      ****************************************************************
      * FILE  I/O PROCESS MODULES                                    *
      ****************************************************************
       COPY CCPNCC.
      /
       COPY CCPNEDIT.
      /
       COPY CCPNPH.
014221 COPY CCPUPH.
      /
       COPY CCPATT.
       COPY CCPBTT.
       COPY CCPNTT.
       COPY CCPUTT.
       COPY CCPXTT.
       COPY CCPCTT.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
010418 COPY CCPNSCOM.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM0391                     **
      *****************************************************************
