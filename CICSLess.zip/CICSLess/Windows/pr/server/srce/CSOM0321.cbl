      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0321.

       COPY XCWWCRHT.
      *****************************************************************
      **  MEMBER :  CSOM0321                                         **
      **  REMARKS:  PRNT - PROCESS RRSP/T4RSP RECEIPT REQUEST        **
      **            THIS MODULE WILL CONTROL GENERATION OF RRSP/T4RSP**
      **            RECEIPTS REQUESTED ON PRNT SCREEN.  THE PROCESS  **
      **            WILL VALIDATE THAT THE APPROPRATE RECEIPT AMOUNTS**
      **            EXIST FOR THE REGULAR RECEIPTS PRIOR TO THE      **
      **            EXTRACT GENERATION.  IF DUPLICATE RECEIPTS ARE   **
      **            REQUESTED, THE HISTORY FILES WILL BE READ TO     **
      **            ENSURE THE ORIGINAL RECEIPTS HAD BEEN GENERATED. **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       MODIFICATIONS FOR MAINTAINABILITY                **
557708**  5.5       HANDLING OF CICS ABENDS                          **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
008455**  5.5.2     AMOUNT FIELD SIZING FOR INTERNATIONAL SUPPORT    **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEAN UP                                    **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016440**  6.2       COMBINE NBS AND ADMIN - ONLINE REQUIREMENTS      **
016537**  6.2       CODE CLEAN UP                                    **
016736**  6.3       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0321'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
013578*    05  WS-ENTER-CODE                PIC X(02).
013578*        88  WS-ENTER-CODE-VALID           VALUE 'RR' 'DR'
013578*                                                'TR' 'DT'.
013578*        88  WS-RRSP-RECEIPT               VALUE 'RR'.
013578*        88  WS-DUP-RRSP-RECEIPT           VALUE 'DR'.
013578*        88  WS-T4RSP-RECEIPT              VALUE 'TR'.
013578*        88  WS-DUP-T4RSP-RECEIPT          VALUE 'DT'.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-RRSP               VALUE '2020'.
013578         88  WS-BUS-FCN-DUP-RRSP           VALUE '2021'.
013578         88  WS-BUS-FCN-T4RSP              VALUE '2022'.
013578         88  WS-BUS-FCN-DUP-T4RSP          VALUE '2023'.
           05  WS-ENTER-TYPE                PIC X(01).
013578*        88  WS-ENTER-TYPE-VALID           VALUE ' ' 'A' 'S'.
013578*        88  WS-BOTH-RECEIPTS              VALUE ' '.
013578         88  WS-ENTER-TYPE-VALID           VALUE 'B' 'A' 'S'.
013578         88  WS-BOTH-RECEIPTS              VALUE 'B'.
               88  WS-ANNUITANT-RECEIPT          VALUE 'A'.
               88  WS-SPOUSAL-RECEIPT            VALUE 'S'.
           05  WS-SEQ-NUMBER                PIC 9(03)
                                                 VALUE 0.
           05  WS-CLI-ADDR-TYP-CD           PIC X(02).
           05  WS-CLI-LANG-CD               PIC X(01).
           05  WS-EDIT-PRCES-IND            PIC X(01).
               88  WS-EDIT-ONLY                  VALUE 'Y'.
           05  WS-HOLD-LINE-NO              PIC S9(04).
           05  WS-HOLD-COL-NO               PIC S9(02).
           05  WS-HOLD-INPUT-DATE.
               10  WS-HOLD-INPUT-YEAR       PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-HOLD-INPUT-MONTH      PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-HOLD-INPUT-DAY        PIC 9(02).

      *
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      *
021930*COPY CCWWINDX.
008455*
008455*COPY CCWWTR51.
008455*
008455*COPY CCWWTR15.
      *
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
016537*COPY CCFWCVG.
       COPY CCFWPOL.
      *
016537*COPY CCFRTRAN.
      *
016537*COPY CCFWTRAN.
      *
016537*COPY CCFRCVG.
      *
016537*COPY CCFRCLIA.
      *
557756*COPY CCWTYSNO.
      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
016440 COPY CCWL5400.
       COPY CCWL7050.
       COPY CCWL7055.
021930*COPY CCWL2430.
016736*COPY CCWL0620.
       COPY XCWLDTLK.
       COPY XCWL1640.
016537*COPY XCWL1670.
016537*COPY XCWL1680.
016537*COPY XCWL2510.
      *
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      *
014588*COPY CCWCCOMM.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.

       COPY CCFRPOL.

       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0321.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

      *****************************************************************
      *  THIS ROUTINE IS THE BASIC MAIN LINE FOR THE PRNT TRANSACTION*
      *-------------------------------------------------------------
      *  1. RECEIVE THE APPROPRIATE MAP
      *  2. SAVE THE INPUT/ INITIALIZE THE OUTPUT MAP
      *  3. INITIALIZE SWITCHES
      *  4. HANDLE RESPONSE IF SECOND PASS THROUGH PROGRAM
      *  5. IF NO ERROR, PROCESS
      *  6. UPDATE ANY RECORDS IF REQUIRED
      *****************************************************************

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF  WS-BUS-FCN-RRSP
           OR  WS-BUS-FCN-DUP-RRSP
               MOVE MIR-RRSP-RHST-DT  TO L1640-EXTERNAL-DATE
           ELSE
               MOVE MIR-T4RSP-RHST-DT TO L1640-EXTERNAL-DATE
           END-IF.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           MOVE L1640-INTERNAL-DATE   TO WS-HOLD-INPUT-DATE.

           IF  WGLOB-MSG-ERROR-SW = 1
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2100-PRNT-PROCESSING
               THRU 2100-PRNT-PROCESSING-X.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *---------------------
       2100-PRNT-PROCESSING.
      *---------------------

           PERFORM  3000-TRANS-GENERAL-EDITS
               THRU 3000-TRANS-GENERAL-EDITS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2100-PRNT-PROCESSING-X
           END-IF.

013578     PERFORM  PGA-1000-BUILD-PARMS
013578         THRU PGA-1000-BUILD-PARMS-X.
013578
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RRSP
                    PERFORM  4000-RRSP-RCPT
                        THRU 4000-RRSP-RCPT-X

               WHEN WS-BUS-FCN-DUP-RRSP
                    PERFORM  4100-RRSP-DUP
                        THRU 4100-RRSP-DUP-X

               WHEN WS-BUS-FCN-T4RSP
                    PERFORM  4200-T4RSP-RCPT
                        THRU 4200-T4RSP-RCPT-X

               WHEN WS-BUS-FCN-DUP-T4RSP
                    PERFORM  4300-T4RSP-DUP
                        THRU 4300-T4RSP-DUP-X

           END-EVALUATE.

       2100-PRNT-PROCESSING-X.

           EXIT.

      *-------------------------
       3000-TRANS-GENERAL-EDITS.
      *-------------------------

           IF  WS-HOLD-INPUT-DATE = WWKDT-ZERO-DT
      *MSG: EFFECTIVE DATE MUST BE ENTERED IN VALID FORMAT.. DDMMMYY
               MOVE 'CS00000054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF  WS-HOLD-INPUT-DATE > WGLOB-PROCESS-DATE
      *MSG:  EFFECTIVE DATE MUST BE GREATER THAN PROCESS DATE
               MOVE 'CS03210004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF  WS-BUS-FCN-RRSP
               MOVE MIR-RRSP-RHST-TYP-CD  TO WS-ENTER-TYPE
               IF  NOT WS-ENTER-TYPE-VALID
      *MSG: VALID TYPES ARE A (ANNUITANT), S (SPOUSAL) OR (B)BOTH
                   MOVE 'CS03210016'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           END-IF.

           EVALUATE TRUE
               WHEN WS-BUS-FCN-DUP-RRSP
                    IF  MIR-RRSP-RHST-SEQ-NUM NOT NUMERIC
      *MSG: SEQUENCE NUMBER MUST BE NUMERIC
                        MOVE 'CS03210019'  TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                        SET WGLOB-RETURN-ERROR TO TRUE
                    END-IF
               WHEN WS-BUS-FCN-DUP-T4RSP
                    IF  MIR-T4RSP-RHST-SEQ-NUM NOT NUMERIC
      *MSG: SEQUENCE NUMBER MUST BE NUMERIC
                        MOVE 'CS03210019'  TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                        SET WGLOB-RETURN-ERROR TO TRUE
                    END-IF
               WHEN OTHER
                    MOVE SPACES            TO MIR-RRSP-RHST-SEQ-NUM
           END-EVALUATE.

      * CHECK TO SEE IF THE POLICY IS VALID.

013578*    MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID.
013578     MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
013578     MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.
           IF  NOT WPOL-IO-OK
013578*    AND WGLOB-RETURN-ERROR
               MOVE MIR-POL-ID-BASE        TO WGLOB-MSG-PARM (1)
               MOVE MIR-POL-ID-SFX         TO WGLOB-MSG-PARM (2)
               MOVE 'CS03210005'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.

016440     SET L5400-POL-XFER-UPDATE       TO  TRUE.

016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.

016440     IF  L5400-XFER-ACCS-RESTRICTED
016440         SET WGLOB-RETURN-ERROR      TO TRUE
016440     END-IF.

       3000-TRANS-GENERAL-EDITS-X.
           EXIT.

      *---------------
       4000-RRSP-RCPT.
      *---------------
      *
      *  SET UP PARAMETERS TO CALL MODULE CSLF7050 FOR EDIT
      *  PROCESSING LOGIC.
      *
           PERFORM  7050-1000-BUILD-PARM-INFO
               THRU 7050-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID-BASE       TO L7050-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO L7050-POL-ID-SFX.
           MOVE MIR-RRSP-RHST-TYP-CD  TO L7050-RCPT-RQST-TYP-CD.
           MOVE WS-HOLD-INPUT-DATE    TO L7050-INPUT-DT.

557660     IF  MIR-RRSP-RHST-SEQ-NUM = SPACES
557660         MOVE ZEROES            TO L7050-SEQ-NUM
557660     ELSE
557660         MOVE MIR-RRSP-RHST-SEQ-NUM
                                      TO L7050-SEQ-NUM
557660     END-IF.

           EVALUATE MIR-DV-PRCES-STATE-CD

               WHEN '2'
                    PERFORM  4010-RRSP-RCPT-1
                        THRU 4010-RRSP-RCPT-1-X

               WHEN '3'
                    PERFORM  4020-RRSP-RCPT-2
                        THRU 4020-RRSP-RCPT-2-X

           END-EVALUATE.

           MOVE L7050-CLI-NM          TO MIR-DV-ANUTNT-CLI-NM.

       4000-RRSP-RCPT-X.
           EXIT.

      *-----------------
       4010-RRSP-RCPT-1.
      *-----------------
      *
      *  EDIT PROCESSING
      *
           SET L7050-PRCES-TYP-EDIT-ONLY TO TRUE.

           PERFORM  7050-1000-RRSP-RCPT
               THRU 7050-1000-RRSP-RCPT-X.

           IF  L7050-RETRN-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 4010-RRSP-RCPT-1-X
           END-IF.

      *MSG:  YOU ARE REQUESTING A RECEIPT
           MOVE 'CS03210012'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *MSG:  PLEASE CONFIRM OR CANCEL THIS PROCESS
           MOVE 'CS03210008'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4010-RRSP-RCPT-1-X.
           EXIT.

      *-----------------
       4020-RRSP-RCPT-2.
      *-----------------

           MOVE MIR-DV-ANUTNT-CLI-NM TO L7050-CLI-NM.

           PERFORM  7050-1000-RRSP-RCPT
               THRU 7050-1000-RRSP-RCPT-X.

           IF  L7050-RETRN-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           MOVE SPACES                TO MIR-RRSP-RHST-TYP-CD.
           MOVE SPACES                TO MIR-RRSP-RHST-SEQ-NUM.

       4020-RRSP-RCPT-2-X.
           EXIT.

      *--------------
       4100-RRSP-DUP.
      *--------------
      *
      *  SET UP PARAMETERS TO CALL MODULE CSLF7050 FOR EDIT
      *  PROCESSING LOGIC.
      *
           PERFORM  7050-1000-BUILD-PARM-INFO
               THRU 7050-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID-BASE       TO L7050-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO L7050-POL-ID-SFX.
           MOVE SPACES                TO L7050-RCPT-RQST-TYP-CD.
           MOVE WS-HOLD-INPUT-DATE    TO L7050-INPUT-DT.

557660     IF  MIR-RRSP-RHST-SEQ-NUM = SPACES
557660         MOVE ZEROES            TO L7050-SEQ-NUM
557660     ELSE
557660         MOVE MIR-RRSP-RHST-SEQ-NUM
                                      TO L7050-SEQ-NUM
557660     END-IF.

           EVALUATE MIR-DV-PRCES-STATE-CD

               WHEN '2'
                    PERFORM  4110-RRSP-DUP-1
                        THRU 4110-RRSP-DUP-1-X

               WHEN '3'
                    PERFORM  4120-RRSP-DUP-2
                        THRU 4120-RRSP-DUP-2-X

           END-EVALUATE.

           MOVE L7050-CLI-NM          TO MIR-DV-ANUTNT-CLI-NM.

       4100-RRSP-DUP-X.
           EXIT.

      *----------------
       4110-RRSP-DUP-1.
      *----------------
      *
      *  EDIT PROCESSING
      *
           SET L7050-PRCES-TYP-EDIT-ONLY TO TRUE.

           PERFORM  7050-2000-RRSP-DUP
               THRU 7050-2000-RRSP-DUP-X.

           IF  L7050-RETRN-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 4110-RRSP-DUP-1-X
           END-IF.

      *MSG:  YOU ARE REQUESTING A DUPLICATE RRSP RECEIPT
           MOVE 'CS03210013'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *MSG:  PLEASE CONFIRM OR CANCEL THIS PROCESS
           MOVE 'CS03210008'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       4110-RRSP-DUP-1-X.
           EXIT.

      *----------------
       4120-RRSP-DUP-2.
      *----------------

           MOVE MIR-DV-ANUTNT-CLI-NM  TO L7050-CLI-NM.

           PERFORM  7050-2000-RRSP-DUP
               THRU 7050-2000-RRSP-DUP-X.

           IF  L7050-RETRN-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           MOVE SPACES                TO MIR-RRSP-RHST-TYP-CD.
           MOVE SPACES                TO MIR-RRSP-RHST-SEQ-NUM.

       4120-RRSP-DUP-2-X.
           EXIT.

      *----------------
       4200-T4RSP-RCPT.
      *----------------
      *
      *  SET UP PARAMETERS TO CALL MODULE CSLF7050 FOR EDIT
      *  PROCESSING LOGIC.
      *
           PERFORM  7055-1000-BUILD-PARM-INFO
               THRU 7055-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID-BASE       TO L7055-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO L7055-POL-ID-SFX.
           MOVE WS-HOLD-INPUT-DATE    TO L7055-INPUT-DT.

557660     IF  MIR-T4RSP-RHST-SEQ-NUM = SPACES
557660         MOVE ZEROES            TO L7055-SEQ-NUM
557660     ELSE
557660         MOVE MIR-T4RSP-RHST-SEQ-NUM
                                      TO L7055-SEQ-NUM
557660     END-IF.

           EVALUATE MIR-DV-PRCES-STATE-CD

               WHEN '2'
                    PERFORM  4210-T4RSP-RCPT-1
                        THRU 4210-T4RSP-RCPT-1-X

               WHEN '3'
                    PERFORM  4220-T4RSP-RCPT-2
                        THRU 4220-T4RSP-RCPT-2-X

           END-EVALUATE.

557660     MOVE L7055-CLI-NM          TO MIR-DV-ANUTNT-CLI-NM.

       4200-T4RSP-RCPT-X.
           EXIT.

      *------------------
       4210-T4RSP-RCPT-1.
      *------------------
      *
      *  EDIT PROCESSING
      *
           PERFORM  4400-EDIT-PRCES-T4RSP
               THRU 4400-EDIT-PRCES-T4RSP-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 4210-T4RSP-RCPT-1-X
           END-IF.

      *MSG:  YOU ARE REQUESTING A T4SP RECEIPT
           MOVE 'CS03210014'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *MSG:  PLEASE CONFIRM OR CANCEL THIS PROCESS
           MOVE 'CS03210008'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4210-T4RSP-RCPT-1-X.
           EXIT.

      *------------------
       4220-T4RSP-RCPT-2.
      *------------------

           MOVE MIR-DV-ANUTNT-CLI-NM TO L7055-CLI-NM.

           PERFORM  7055-1000-T4RSP-RCPT
               THRU 7055-1000-T4RSP-RCPT-X.

557660     IF  L7055-RETRN-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           MOVE SPACES                TO MIR-T4RSP-RHST-SEQ-NUM.

       4220-T4RSP-RCPT-2-X.
           EXIT.

      *---------------
       4300-T4RSP-DUP.
      *---------------
      *
      *  SET UP PARAMETERS TO CALL MODULE CSLF7050 FOR EDIT
      *  PROCESSING LOGIC.
      *
           PERFORM  7055-1000-BUILD-PARM-INFO
               THRU 7055-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID-BASE       TO L7055-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO L7055-POL-ID-SFX.
           MOVE WS-HOLD-INPUT-DATE    TO L7055-INPUT-DT.

557660     IF  MIR-T4RSP-RHST-SEQ-NUM = SPACES
557660         MOVE ZEROES            TO L7055-SEQ-NUM
557660     ELSE
557660        MOVE MIR-T4RSP-RHST-SEQ-NUM
                                      TO L7055-SEQ-NUM
557660     END-IF.

           EVALUATE MIR-DV-PRCES-STATE-CD

               WHEN '2'
                    PERFORM  4310-T4RSP-DUP-1
                        THRU 4310-T4RSP-DUP-1-X

               WHEN '3'
                    PERFORM  4320-T4RSP-DUP-2
                        THRU 4320-T4RSP-DUP-2-X

           END-EVALUATE.

           MOVE L7055-CLI-NM          TO MIR-DV-ANUTNT-CLI-NM.

       4300-T4RSP-DUP-X.
           EXIT.

      *-----------------
       4310-T4RSP-DUP-1.
      *-----------------
      *
      *  EDIT PROCESSING
      *
           PERFORM  4400-EDIT-PRCES-T4RSP
               THRU 4400-EDIT-PRCES-T4RSP-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 4310-T4RSP-DUP-1-X
           END-IF.

      *MSG:  YOU ARE REQUESTING A T4SP RECEIPT
           MOVE 'CS03210015'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *MSG:  PLEASE CONFIRM OR CANCEL THIS PROCESS
           MOVE 'CS03210008'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4310-T4RSP-DUP-1-X.
           EXIT.

      *-----------------
       4320-T4RSP-DUP-2.
      *-----------------

           MOVE MIR-DV-ANUTNT-CLI-NM  TO L7055-CLI-NM.

           PERFORM  7055-2000-T4RSP-DUP
               THRU 7055-2000-T4RSP-DUP-X.

557660     IF  L7055-RETRN-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           MOVE SPACES                TO MIR-T4RSP-RHST-SEQ-NUM.

       4320-T4RSP-DUP-2-X.
           EXIT.

      *----------------------
       4400-EDIT-PRCES-T4RSP.
      *----------------------
      *
      *  EDIT AND GENERATE THE T4RSP/T4RSP DUPLICATE RECEIPT
      *
           IF  MIR-DV-PRCES-STATE-CD = '2'
               SET L7055-PRCES-TYP-EDIT-ONLY TO TRUE
               SET WS-EDIT-ONLY TO TRUE
           END-IF.

           MOVE MIR-POL-ID-BASE       TO L7055-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO L7055-POL-ID-SFX.
           MOVE WS-HOLD-INPUT-DATE    TO L7055-INPUT-DT.

557660     IF  MIR-T4RSP-RHST-SEQ-NUM = SPACES
557660         MOVE ZEROES            TO L7055-SEQ-NUM
557660     ELSE
557660         MOVE MIR-T4RSP-RHST-SEQ-NUM
                                      TO L7055-SEQ-NUM
557660     END-IF.

           IF  WS-BUS-FCN-T4RSP
               PERFORM  7055-1000-T4RSP-RCPT
                   THRU 7055-1000-T4RSP-RCPT-X
           ELSE
               PERFORM  7055-2000-T4RSP-DUP
                   THRU 7055-2000-T4RSP-DUP-X
           END-IF.

           IF  NOT L7055-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 4400-EDIT-PRCES-T4RSP-X
           END-IF.

           MOVE L7055-CLI-NM         TO MIR-DV-ANUTNT-CLI-NM.

       4400-EDIT-PRCES-T4RSP-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7050-0000-INIT-PARM-INFO
025970         THRU 7050-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7055-0000-INIT-PARM-INFO
025970         THRU 7055-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     MOVE SPACES               TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      *
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS1640.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL1640.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
016537*COPY CCPL0620.
      *
      ****************************************************************
      * LINKAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440 COPY CCPS5400.
016440*
018764*COPY CCCL7050.
018764 COPY CCPL7050.
       COPY CCPS7050.
      *
018764*COPY CCCL7055.
018764 COPY CCPL7055.
       COPY CCPS7055.
      *
016537*COPY CCPS2430.
016537*COPY CCCL2430.
      *
013578 COPY CCPSPGA.
013578
      ****************************************************************
      * FILE  I/O PROCESS MODULES                                    *
      ****************************************************************
      *
       COPY CCPNPOL.
      *
      ****************************************************************
      * ERROR HANDLING ROUTINES                                      *
      ****************************************************************
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      *                  END OF PROGRAM CSOM0321                     **
      *****************************************************************
