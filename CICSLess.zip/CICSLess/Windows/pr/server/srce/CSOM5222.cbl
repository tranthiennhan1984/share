      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5222.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5222                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE CRCD TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014221**  6.2       LOGIGAL LOCKING                                  **
016395**  6.2       CREDIT CARD BILLING                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5222'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                 VALUE '5220'.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '5222'.
025970*    05  WS-TWRK-KEY                   PIC X(04) VALUE '5220'.

      /
018764*COPY XCWLPTR.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCRCD.
       COPY CCFRCRCD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL0280.
       COPY XCWL0290.
014221 COPY XCWL8090.
       COPY CCWL5227.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5222.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5222'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------
      *
      *  THE RECORD MUST EXIST ON A MAINTAIN
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

014221*    PERFORM  CRCD-1000-READ-FOR-UPDATE
014221*        THRU CRCD-1000-READ-FOR-UPDATE-X.

014221     PERFORM  CRCD-2000-UPDATE-TWRK-TS
014221         THRU CRCD-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CRCD'                TO WGLOB-MSG-PARM (01)
014221        MOVE WCRCD-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 2000-UPDATE-X
014221     END-IF.

           IF  WCRCD-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WCRCD-CRC-ID
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

      *
      *  EDIT THE DATA ENTERED FOR THE RECORD AND AUDIT CHANGES
      *

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM 9200-MOVE-RECORD-TO-MIR
                  THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               SET MIR-RETRN-EDIT-ERROR
                TO TRUE
           END-IF.

           PERFORM  CRCD-2000-REWRITE
               THRU CRCD-2000-REWRITE-X.

           IF WCRCD-IO-OK
      *MSG  CREDIT CARD RECORD UPDATED
               MOVE 'CS52220004'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

014221     PERFORM  CRCD-1000-READ-TWRK-TS
014221         THRU CRCD-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WCRCD-KEY.
           MOVE MIR-CRC-TYP-CD         TO WCRCD-CRC-TYP-CD.
           MOVE MIR-CRC-ID             TO WCRCD-CRC-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------
       8000-EDITS.
      *-----------

           PERFORM  5227-1000-INIT-PARM-INFO
               THRU 5227-1000-INIT-PARM-INFO-X.

           PERFORM  8100-MOVE-MIR-TO-EDIT
               THRU 8100-MOVE-MIR-TO-EDIT-X.

           PERFORM  5227-1000-DATA-EDIT
               THRU 5227-1000-DATA-EDIT-X.

           PERFORM  8200-MOVE-EDIT-TO-MIR
               THRU 8200-MOVE-EDIT-TO-MIR-X.

       8000-EDITS-X.
           EXIT.
      /
      *----------------------
       8100-MOVE-MIR-TO-EDIT.
      *----------------------

           MOVE MIR-CRC-HLDR-NM TO L5227-CRC-HLDR-NM.

           MOVE MIR-CRC-XPRY-MO TO L5227-CRC-XPRY-MO.

           MOVE MIR-CRC-XPRY-YR TO L5227-CRC-XPRY-YR.

       8100-MOVE-MIR-TO-EDIT-X.
           EXIT.
      /
      *----------------------
       8200-MOVE-EDIT-TO-MIR.
      *----------------------

           IF  L5227-CRC-HLDR-NM = HIGH-VALUES
               CONTINUE
           ELSE
               MOVE L5227-CRC-HLDR-NM TO MIR-CRC-HLDR-NM
               MOVE L5227-CRC-HLDR-NM TO RCRCD-CRC-HLDR-NM
           END-IF.

           IF  L5227-CRC-XPRY-MO =  HIGH-VALUES
               CONTINUE
           ELSE
               MOVE L5227-CRC-XPRY-MO TO MIR-CRC-XPRY-MO
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE ZEROS             TO L0280-PRECISION
               MOVE LENGTH OF L5227-CRC-XPRY-MO
                                      TO L0280-LENGTH
               MOVE LENGTH OF L5227-CRC-XPRY-MO
                                      TO L0280-INPUT-SIZE
               MOVE L5227-CRC-XPRY-MO TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               MOVE L0280-OUTPUT-V00  TO RCRCD-CRC-XPRY-MO
           END-IF.

           IF  L5227-CRC-XPRY-YR =  HIGH-VALUES
               CONTINUE
           ELSE
               MOVE L5227-CRC-XPRY-YR TO MIR-CRC-XPRY-YR
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE ZEROS             TO L0280-PRECISION
               MOVE LENGTH OF L5227-CRC-XPRY-YR
                                      TO L0280-LENGTH
               MOVE LENGTH OF L5227-CRC-XPRY-YR
                                      TO L0280-INPUT-SIZE
               MOVE L5227-CRC-XPRY-YR TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               MOVE L0280-OUTPUT-V00  TO RCRCD-CRC-XPRY-YR
           END-IF.

       8200-MOVE-EDIT-TO-MIR-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES
             TO MIR-CRC-HLDR-NM.
           MOVE SPACES
             TO MIR-CRC-XPRY-MO.
           MOVE SPACES
             TO MIR-CRC-XPRY-YR.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE RCRCD-CRC-HLDR-NM
             TO MIR-CRC-HLDR-NM.

020874*    MOVE RCRCD-CRC-XPRY-MO         TO L0290-INPUT-NUMBER.
020874     MOVE RCRCD-CRC-XPRY-MO         TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-XPRY-MO TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA         TO MIR-CRC-XPRY-MO.

020874*    MOVE RCRCD-CRC-XPRY-YR         TO L0290-INPUT-NUMBER.
020874     MOVE RCRCD-CRC-XPRY-YR         TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-XPRY-YR TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA         TO MIR-CRC-XPRY-YR.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5227-0000-INIT-PARM-INFO
025970         THRU 5227-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CRCD
014221                         '$VAR2' BY 'CRCD'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
018764*COPY CCCL5227.
018764 COPY CCPL5227.
       COPY CCPS5227.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
014221 COPY CCPNCRCD.
       COPY CCPUCRCD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM5222                     **
      *****************************************************************

