      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7833.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7833                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE FUTURE DATED POLICY REQUEST TABLE        **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7833'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-CONSTANT-FIELDS.
           05  WS-TWRK-KEY                   PIC X(04).
               88  WS-TWRK-KEY-DEFAULT       VALUE '7830'.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-DELETE         VALUE '7833'.
           05  WS-EFF-DT                     PIC X(10).
036742     05  WS-GEN-ID                     PIC 9(10).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.
       COPY CCWWCVGS.

       COPY CCFWPOL.
       COPY CCFRPOL.

           EXEC SQL INCLUDE CCFWPORQ END-EXEC.
           EXEC SQL INCLUDE CCFRPORQ END-EXEC.

       COPY CCFWPBRQ.
       COPY CCFRPBRQ.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWLPGA.

       COPY CCWL0183.

       COPY CCWL0289.

       COPY CCWL2625.
036742
036742 COPY XCWLDTLK.
036742
036742 COPY XCWL0280.
036742
036742 COPY XCWL1640.
036742
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7833.
      /
      ********************
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ********************

      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7833'          TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000000'        TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                             TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *--------------
       2000-DELETE.
      *--------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PORQ-1000-READ-FOR-UPDATE
               THRU PORQ-1000-READ-FOR-UPDATE-X.

           IF  WPORQ-IO-NOT-FOUND
      *MSG:  FUTURE DATED POLICY REQUEST (@1) DOES NOT EXIST
               MOVE WPORQ-KEY                TO WGLOB-MSG-PARM (1)
               MOVE 'CS78330001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

           IF  RPORQ-POL-RQST-STAT-PEND
           OR  RPORQ-POL-RQST-STAT-CNCL
               CONTINUE
           ELSE
      *MSG:  DELETE IS ONLY ALLOWED ON RECORDS WITH STATUS = PENDING
      *      OR CANCELLED
               MOVE 'CS78330002'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               PERFORM  PORQ-3000-UNLOCK
                   THRU PORQ-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

           IF  RPORQ-POL-RQST-TYP-BILL-MTHD
           OR  RPORQ-POL-RQST-TYP-OFFANNV
               PERFORM  2200-CHECK-PENDING-PBRQ
                   THRU 2200-CHECK-PENDING-PBRQ-X
               PERFORM  2400-RECALC-PREM
                   THRU 2400-RECALC-PREM-X
           END-IF.

           PERFORM  PORQ-1000-DELETE
               THRU PORQ-1000-DELETE-X.

           PERFORM  2300-SET-POL-NXT-ACTV
               THRU 2300-SET-POL-NXT-ACTV-X.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

      *MSG:  FUTURE DATED ACTIVITY DELETED
           MOVE 'CS78330003'                 TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2000-DELETE-X.
           EXIT.

      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           IF  MIR-POL-ID = SPACES
      *MSG: POLICY ID MUST BE ENTERED
               MOVE 'CS00000048'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           MOVE MIR-POL-ID                   TO WPOL-POL-ID.
           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG:  POLICY (@1) DOES NOT EXIST
               MOVE WPOL-POL-ID              TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000076'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
      *     PROCESS NOT COMPLETE
               MOVE 'XS00000303'             TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                    TO WGLOB-MSG-PARM (01)
               MOVE WPOL-POL-ID              TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
036742
036742     MOVE MIR-POL-RQST-EFF-DT          TO L1640-EXTERNAL-DATE.
036742     PERFORM 1640-7000-MIR-TO-INT
036742        THRU 1640-7000-MIR-TO-INT-X.
036742     IF  NOT L1640-RETRN-OK
036742*MSG: EFFECTIVE DATE MUST BE IN VALID FORMAT
036742         MOVE 'CS00000054'             TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742         GO TO 2100-VALIDATE-KEYS-X
036742     END-IF.
036742     MOVE L1640-INTERNAL-DATE          TO WS-EFF-DT.
036742
036742     MOVE MIR-POL-RQST-GEN-ID          TO L0280-INPUT-DATA.
036742     MOVE LENGTH OF MIR-POL-RQST-GEN-ID
036742                                       TO L0280-INPUT-SIZE.
036742     MOVE L0280-INPUT-SIZE             TO L0280-LENGTH.
036742     MOVE ZERO                         TO L0280-PRECISION.
036742     SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
036742     SET L0280-SPACES-PERMITTED        TO TRUE.
036742
036742     PERFORM  0280-1000-NUMERIC-EDIT
036742         THRU 0280-1000-NUMERIC-EDIT-X.
036742
036742     IF  L0280-OK
036742         MOVE L0280-OUTPUT-V00         TO WS-GEN-ID
036742     ELSE
036742         MOVE ZERO                     TO WS-GEN-ID
036742*MSG: INVALID NUMERIC
036742         MOVE 'XS00000018'             TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742         GO TO 2100-VALIDATE-KEYS-X
036742     END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-------------------------
       2200-CHECK-PENDING-PBRQ.
      *-------------------------

           IF  RPOL-POL-BILL-TO-DT-NUM NOT =
                                     RPORQ-POL-RQST-EFF-DT
      *MSG:  AMOUNT ON BILLING NOTICE HAS CHANGED.  RE-SEND BILLING
      *      NOTICE TO REFLECT CORRECT AMOUNT.
               MOVE 'CS78330004'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  2625-0000-INIT-PARM-INFO
               THRU 2625-0000-INIT-PARM-INFO-X.

           MOVE RPORQ-POL-ID                 TO WPBRQ-POL-ID.
036742*    MOVE RPORQ-POL-RQST-CREAT-TS      TO WPBRQ-POL-RQST-CREAT-TS.
036742     MOVE RPORQ-POL-RQST-EFF-DT        TO WPBRQ-PBRQST-EFF-DT.
036742     MOVE RPORQ-POL-RQST-GEN-ID        TO WPBRQ-PBRQST-GEN-ID.
           PERFORM  PBRQ-1000-READ-FOR-UPDATE
               THRU PBRQ-1000-READ-FOR-UPDATE-X.

           IF  WPBRQ-IO-OK
               PERFORM  PBRQ-1000-DELETE
                   THRU PBRQ-1000-DELETE-X
           END-IF.

           SET L2625-RETRIEVE-RELOAD         TO TRUE.
           PERFORM  2625-1000-BILL-CHNG-RETRIEVE
               THRU 2625-1000-BILL-CHNG-RETRIEVE-X.

       2200-CHECK-PENDING-PBRQ-X.
           EXIT.

      *-----------------------
       2300-SET-POL-NXT-ACTV.
      *-----------------------

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X
           MOVE WGLOB-PROCESS-DATE           TO L0289-LO-PAC-DT
           MOVE WGLOB-PROCESS-DATE           TO L0289-LO-CRC-DT
           MOVE WGLOB-PROCESS-DATE           TO L0289-LO-DD2-DT.
           MOVE WGLOB-PROCESS-DATE           TO L0289-PROC-EFF-DT
           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X
           IF  L0289-RETRN-OK
                MOVE L0289-NXT-ACTV-TYP-CD   TO RPOL-NXT-ACTV-TYP-CD
                MOVE L0289-NXT-ACTV-DT       TO RPOL-POL-NXT-ACTV-DT
            ELSE
                MOVE 'RSH'                   TO RPOL-NXT-ACTV-TYP-CD
                MOVE WGLOB-PROCESS-DATE      TO RPOL-POL-NXT-ACTV-DT
            END-IF.

       2300-SET-POL-NXT-ACTV-X.
           EXIT.

      *------------------
       2400-RECALC-PREM.
      *------------------

           PERFORM  0183-0000-INIT-PARM-INFO
               THRU 0183-0000-INIT-PARM-INFO-X.

           PERFORM  0183-1000-BUILD-PARM-INFO
               THRU 0183-1000-BUILD-PARM-INFO-X.

           SET L0183-RECALC-PREM-FORCED TO TRUE.
           MOVE 1                       TO L0183-OFF-ANNV-SAVE-SIDE.

           PERFORM  0183-1000-CALC-NXT-PREM
               THRU 0183-1000-CALC-NXT-PREM-X.

           IF  NOT L0183-RETRN-OK
      *MSG: PREMIUM CAN NOT BE RE-CALCULATED.
               MOVE 'CS78330005'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           SET L0183-RECALC-PREM-IF-REQD
                                        TO TRUE.
           MOVE ZERO                    TO L0183-OFF-ANNV-SAVE-SIDE.
           SET L0183-PMT-REVRS-REVERSAL TO TRUE.

           PERFORM  0183-2000-CALC-PREV-PREM
               THRU 0183-2000-CALC-PREV-PREM-X.

           MOVE L0183-POL-MPREM-AMT     TO RPOL-POL-PREV-MPREM-AMT.

           IF  NOT L0183-RETRN-OK
      *MSG: PREMIUM CAN NOT BE RE-CALCULATED.
               MOVE 'CS78330005'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2400-RECALC-PREM-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-POL-ID              TO WPORQ-POL-ID.
036742*    MOVE MIR-POL-RQST-CREAT-TS   TO WPORQ-POL-RQST-CREAT-TS.
036742     MOVE WS-EFF-DT               TO WPORQ-POL-RQST-EFF-DT.
036742     MOVE WS-GEN-ID               TO WPORQ-POL-RQST-GEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.


      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                     TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE         TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX          TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0183-0000-INIT-PARM-INFO
               THRU 0183-0000-INIT-PARM-INFO-X.
036742
036742     PERFORM  0280-0000-INIT-PARM-INFO
036742         THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0289-0000-INIT-PARM-INFO
               THRU 0289-0000-INIT-PARM-INFO-X.
036742
036742     PERFORM  1640-0000-INIT-PARM-INFO
036742         THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2625-0000-INIT-PARM-INFO
               THRU 2625-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE  WLOCK-TWRK-OTHER-INFO.
           INITIALIZE  WS-WORKING-STORAGE.
           SET  WS-TWRK-KEY-DEFAULT          TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY NCPPCVGS.

       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
       COPY XCPPEXIT.

       COPY XCPPINIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0183.
       COPY CCPS0183.

       COPY CCPL0289.
       COPY CCPS0289.

       COPY CCPS2625.
       COPY CCPL2625.

       COPY XCPL0260.
036742
036742 COPY XCPS0280.
036742 COPY XCPL0280.
036742
036742 COPY XCPS1640.
036742 COPY XCPL1640.

       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.

       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPUPORQ.
       COPY CCPXPORQ.

       COPY CCPUPBRQ.
       COPY CCPXPBRQ.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7833                     **
      *****************************************************************
