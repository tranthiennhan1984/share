      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0232.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0232                                         **
      **  REMARKS:  THIS MODULE PERFORMS UPDATE FUNCTION             **
      **            FOR THE CHTX TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016457**  6.2       NEW                                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0232'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-UPDATE                   VALUE '0232'.
           05  WS-CHQ-DT                               PIC X(10).
           05  WS-CHQ-PRCES-DT                         PIC X(10).
           05  WS-CHQ-AMT                              PIC S9(13)V9(02)
                                                       BINARY.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
021930*COPY CCWLPGA.
       COPY XCWLDTLK.
       COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFRCHTX.
       COPY CCFWCHTX.
       COPY CCFWCHTD.
      /
       COPY CCFWSCOM.
       COPY CCFRSCOM.
      /
       COPY XCFWCRCY.
       COPY XCFRCRCY.
      /
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
018764*COPY XCWLPTR.
      /
       COPY XCWL1640.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0232.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0232'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *---------------
       2000-UPDATE.
      *---------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2100-EDIT-KEYS
               THRU 2100-EDIT-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  CHTX-1000-READ-FOR-UPDATE
               THRU CHTX-1000-READ-FOR-UPDATE-X.

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  9100-MOVE-EDIT-TO-RECORD
                   THRU 9100-MOVE-EDIT-TO-RECORD-X
               SET RCHTX-CHQ-STAT-OS      TO TRUE
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               SET MIR-RETRN-EDIT-ERROR
                 TO TRUE
               PERFORM  9300-MOVE-DISPLAY-TO-MIR
                   THRU 9300-MOVE-DISPLAY-TO-MIR-X
           END-IF.

           PERFORM  CHTX-2000-REWRITE
               THRU CHTX-2000-REWRITE-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
      *MSG: YOUR TRANSACTION HAS BEEN PROCESSED
               MOVE 'CS00000011'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2000-UPDATE-X.
           EXIT.
      /
      *----------------
       2100-EDIT-KEYS.
      *----------------

           PERFORM  2110-EDIT-SBSDRY-CO-ID
               THRU 2110-EDIT-SBSDRY-CO-ID-X.

           PERFORM  2120-EDIT-CHQ-DT
               THRU 2120-EDIT-CHQ-DT-X.

       2100-EDIT-KEYS-X.
           EXIT.

      *-----------------------
       2110-EDIT-SBSDRY-CO-ID.
      *-----------------------

           MOVE MIR-SBSDRY-CO-ID            TO WSCOM-SBSDRY-CO-ID.
           PERFORM  SCOM-1000-READ
               THRU SCOM-1000-READ-X.
           IF  NOT WSCOM-IO-OK
      *MSG: SUB CO DOES NOT EXIST
               MOVE 'CS02320102'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-SBSDRY-CO-ID-X.
           EXIT.

      *-------------------------
       2120-EDIT-CHQ-DT.
      *-------------------------

           MOVE MIR-CHQ-DT               TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      *MSG: INVALID CHEQUE DATE
               MOVE 'CS02320103'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WWKDT-ZERO-DT        TO WS-CHQ-DT
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-CHQ-DT
           END-IF.


       2120-EDIT-CHQ-DT-X.
           EXIT.

      *---------------------------
       7000-BUILD-KEYS.
      *---------------------------

           MOVE MIR-CHQ-ID                  TO WCHTD-CHQ-ID.
           MOVE MIR-SBSDRY-CO-ID            TO WCHTD-SBSDRY-CO-ID.
           MOVE WS-CHQ-DT                   TO WCHTD-CHQ-DT.

           PERFORM  CHTD-1000-READ
               THRU CHTD-1000-READ-X.

           IF  NOT WCHTD-IO-OK
      *MSG: CHEQUE MUST EXIST
               MOVE 'CS02320101'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           MOVE RCHTX-CHQ-PART-NUM          TO WCHTX-CHQ-PART-NUM.
036742*    MOVE RCHTX-USER-ID               TO WCHTX-USER-ID.
036742*    MOVE RCHTX-CHQ-INSTC-ID          TO WCHTX-CHQ-INSTC-ID.
036742*    MOVE RCHTX-CHQ-TS                TO WCHTX-CHQ-TS.
036742     MOVE RCHTX-CHQ-GEN-ID            TO WCHTX-CHQ-GEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      *---------------------------
       8000-EDITS.
      *---------------------------

           PERFORM  8010-EDIT-CHQ-MICR-NUM
               THRU 8010-EDIT-CHQ-MICR-NUM-X.

           PERFORM  8020-EDIT-CHQ-PRCES-DT
               THRU 8020-EDIT-CHQ-PRCES-DT-X.

           PERFORM  8030-EDIT-CHQ-AMT
               THRU 8030-EDIT-CHQ-AMT-X.

           PERFORM  8040-EDIT-CHQ-CRCY-CD
               THRU 8040-EDIT-CHQ-CRCY-CD-X.

           PERFORM  8050-EDIT-CHQ-PAYE
               THRU 8050-EDIT-CHQ-PAYE-X.

       8000-EDITS-X.
           EXIT.

      *-----------------------
       8010-EDIT-CHQ-MICR-NUM.
      *-----------------------

           IF  MIR-CHQ-MICR-NUM = SPACE
               GO TO 8010-EDIT-CHQ-MICR-NUM-X
           END-IF.

           MOVE MIR-CHQ-MICR-NUM        TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CHQ-MICR-NUM
                                        TO L0280-INPUT-SIZE.
           MOVE +8                      TO L0280-LENGTH.
           MOVE +0                      TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           SET L0280-SPACES-PERMITTED   TO TRUE.
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               CONTINUE
           ELSE
      ****MSG: MICR NUMBER MUST BE NUMERIC
               MOVE 'CS02320104'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-CHQ-MICR-NUM-X
           END-IF.

       8010-EDIT-CHQ-MICR-NUM-X.
           EXIT.


      *-------------------------
       8020-EDIT-CHQ-PRCES-DT.
      *-------------------------

           IF  MIR-CHQ-PRCES-DT = EBLCH-BLANK-FIELD-CHAR
           OR  MIR-CHQ-PRCES-DT = SPACE
               MOVE SPACES                  TO MIR-CHQ-PRCES-DT
               MOVE WWKDT-ZERO-DT           TO WS-CHQ-PRCES-DT
               GO TO 8020-EDIT-CHQ-PRCES-DT-X
           ELSE
               MOVE MIR-CHQ-PRCES-DT        TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
      *MSG: INVALID PROCESS DATE
                   MOVE 'CS02320105'        TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE WWKDT-ZERO-DT       TO WS-CHQ-PRCES-DT
                   GO TO 8020-EDIT-CHQ-PRCES-DT-X
               ELSE
                   MOVE L1640-INTERNAL-DATE TO WS-CHQ-PRCES-DT
               END-IF
           END-IF.

           EVALUATE TRUE

               WHEN WS-CHQ-PRCES-DT > WGLOB-PROCESS-DATE
      *MSG: DATE IN FUTURE.  RE-ENTER
                    MOVE 'CS00000037'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN WS-CHQ-PRCES-DT < RCHTX-CHQ-DT
      *MSG: DATE ENTERED IS BEFORE CHEQUE DATE.  RE-ENTER
                    MOVE 'CS02320106'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.


       8020-EDIT-CHQ-PRCES-DT-X.
           EXIT.

      *--------------------
       8030-EDIT-CHQ-AMT.
      *--------------------

           EVALUATE MIR-CHQ-AMT

               WHEN SPACES
                    MOVE RCHTX-CHQ-AMT      TO WS-CHQ-AMT

               WHEN EBLCH-BLANK-FIELD-CHAR
                    MOVE ZEROS              TO WS-CHQ-AMT

           END-EVALUATE.

           MOVE MIR-CHQ-AMT                 TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CHQ-AMT       TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE +2                          TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO WS-CHQ-AMT
           ELSE
      *MSG: AMOUNT MUST BE A VALID NUMERIC. RE-ENTER
               MOVE 'CS02320107'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8030-EDIT-CHQ-AMT-X
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-CHQ-AMT * 100.
020874     MOVE WS-CHQ-AMT                  TO L0290-INPUT-V02.
           MOVE +2                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CHQ-AMT       TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY           TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-CHQ-AMT.

           IF  WS-CHQ-AMT <= 0
      *MSG: AMOUNT MUST BE GREATER THAN ZERO. RE-ENTER.
               MOVE 'CS02320108'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8030-EDIT-CHQ-AMT-X.
           EXIT.

      *-----------------------
       8040-EDIT-CHQ-CRCY-CD.
      *-----------------------

           EVALUATE MIR-CHQ-CRCY-CD

               WHEN SPACES
                    MOVE RCHTX-CHQ-CRCY-CD  TO MIR-CHQ-CRCY-CD

               WHEN EBLCH-BLANK-FIELD-CHAR
                    MOVE SPACES             TO MIR-CHQ-CRCY-CD

           END-EVALUATE.

           MOVE WGLOB-COMPANY-CODE          TO WCRCY-CO-ID.
           MOVE MIR-CHQ-CRCY-CD             TO WCRCY-CRCY-CD.
           PERFORM  CRCY-1000-READ
               THRU CRCY-1000-READ-X.
           IF  NOT WCRCY-IO-OK
      *MSG: CURRENCY NOT FOUND IN CURRENCY TABLE.  RE-ENTER
               MOVE 'CS02320109'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8040-EDIT-CHQ-CRCY-CD-X.
           EXIT.

      *--------------------
       8050-EDIT-CHQ-PAYE.
      *--------------------

           EVALUATE MIR-CHQ-PAYE-1-TXT

               WHEN SPACES
                    MOVE RCHTX-CHQ-PAYE-1-TXT TO MIR-CHQ-PAYE-1-TXT

               WHEN EBLCH-BLANK-FIELD-CHAR
                    MOVE SPACE                TO MIR-CHQ-PAYE-1-TXT

           END-EVALUATE.

           EVALUATE MIR-CHQ-PAYE-2-TXT

               WHEN SPACES
                    MOVE RCHTX-CHQ-PAYE-2-TXT TO MIR-CHQ-PAYE-2-TXT

               WHEN EBLCH-BLANK-FIELD-CHAR
                    MOVE SPACE                TO MIR-CHQ-PAYE-2-TXT

           END-EVALUATE.

           IF  MIR-CHQ-PAYE-1-TXT = SPACES
           AND MIR-CHQ-PAYE-2-TXT = SPACES
      *MSG: A NAME MUST BE ENTERED FOR PAYEE.  RE-ENTER
               MOVE 'CS02320110'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8050-EDIT-CHQ-PAYE-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *---------------------------
       9100-MOVE-EDIT-TO-RECORD.
      *---------------------------

           MOVE MIR-SBSDRY-CO-ID        TO RCHTX-SBSDRY-CO-ID.
           MOVE WS-CHQ-DT               TO RCHTX-CHQ-DT.
           MOVE MIR-CHQ-MICR-NUM        TO RCHTX-CHQ-MICR-NUM.
           MOVE WS-CHQ-PRCES-DT         TO RCHTX-CHQ-PRCES-DT.
           MOVE WS-CHQ-AMT              TO RCHTX-CHQ-AMT.
           MOVE MIR-CHQ-CRCY-CD         TO RCHTX-CHQ-CRCY-CD.
           MOVE MIR-CHQ-PAYE-1-TXT      TO RCHTX-CHQ-PAYE-1-TXT.
           MOVE MIR-CHQ-PAYE-2-TXT      TO RCHTX-CHQ-PAYE-2-TXT.

       9100-MOVE-EDIT-TO-RECORD-X.
           EXIT.

      *---------------------------
       9200-MOVE-RECORD-TO-MIR.
      *---------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE RCHTX-CHQ-ID             TO MIR-CHQ-ID.
           MOVE RCHTX-SBSDRY-CO-ID       TO MIR-SBSDRY-CO-ID.

           MOVE RCHTX-CHQ-DT             TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CHQ-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CHQ-DT
           END-IF.

           MOVE RCHTX-CHQ-MICR-NUM       TO MIR-CHQ-MICR-NUM.

020874*    COMPUTE L0290-INPUT-NUMBER = RCHTX-CHQ-AMT * 100.
020874     MOVE RCHTX-CHQ-AMT            TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CHQ-AMT    TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CHQ-AMT.

           MOVE RCHTX-CHQ-CRCY-CD        TO MIR-CHQ-CRCY-CD.
           MOVE RCHTX-CHQ-PAYE-1-TXT     TO MIR-CHQ-PAYE-1-TXT.
           MOVE RCHTX-CHQ-PAYE-2-TXT     TO MIR-CHQ-PAYE-2-TXT.

           PERFORM  9300-MOVE-DISPLAY-TO-MIR
               THRU 9300-MOVE-DISPLAY-TO-MIR-X.


       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.

      *---------------------------
       9300-MOVE-DISPLAY-TO-MIR.
      *---------------------------

           MOVE RCHTX-CHQ-PRCES-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CHQ-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CHQ-PRCES-DT
           END-IF.

           MOVE RCHTX-CHQ-TYP-CD         TO MIR-CHQ-TYP-CD.
           MOVE RCHTX-CHQ-STAT-CD        TO MIR-CHQ-STAT-CD.


       9300-MOVE-DISPLAY-TO-MIR-X.
           EXIT.

      /
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-WORKING-STORAGE.
025970
025970     MOVE SPACES TO  WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPUCHTX.
       COPY CCPNCHTD.
      /
       COPY CCPNSCOM.
      /
       COPY XCPNCRCY.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0232
      *****************************************************************
