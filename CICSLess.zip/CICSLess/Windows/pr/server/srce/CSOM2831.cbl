      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2831.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2831                                         **
      **  REMARKS:  REVERSES DIVIDEND (PUA) WITHDRAWAL               **
      **            THIS MODULE REVERSES A DIVIDEND (PUA) WITHDRAWAL **
      **            ALL RELEVANT ACCOUNTING ENTRIES WILL BE GENERATED**
      **            IF THE POLICY WAS UPDATED A STATUS PRINT IS      **
      **            REQUESTED.                                       **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2831'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORK-FIELDS.
           05  WS-BUS-FCN-ID             PIC X(04).
               88  WS-BUS-FCN-REV-DIV-PUA    VALUE '2831'.
           05  WS-DIV-IDT-NUM            PIC X(07).
           05  WS-EFF-DT                 PIC X(10).
           05  WS-POL-LOCK-IND           PIC X(01).
               88  WS-POL-LOCKED             VALUE 'Y'.
               88  WS-POL-LOCKED-NO          VALUE 'N'.
           05  WS-VALU-EDIT-SEQ-NUM-A         PIC X(20).
           05  FILLER REDEFINES WS-VALU-EDIT-SEQ-NUM-A.
               10  WS-VALU-EDIT-SEQ-NUM       PIC 9(03).
               10  FILLER                     PIC X(17).
           05  WS-BNDV-SEQ-NUM                PIC S9(4).

       01  WS-CONSTANT-FIELDS.
025970     05  WS-TWRK-KEY                    PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT        VALUE '2831'.
025970     05  WS-ACTV-DIV-SURR-PUA           PIC X(04).
025970         88  WS-ACTV-DIV-SURR-PUA-DEFAULT VALUE '7033'.
025970*    05  WS-TWRK-KEY                    PIC X(04) VALUE '2831'.
025970*    05  WS-ACTV-DIV-SURR-PUA           PIC X(04) VALUE '7033'.

      /
      ***********************************************************
      * COMMON COPYBOOKS
      ***********************************************************
       COPY XCWWWKDT.
030054 COPY XCWWCNST.
      /
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
      /
      ***************************************************************
      * I/O COPYBOOKS
      ***************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFHPOL.
       COPY CCFWPOL.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWBNDD.
       COPY CCFRBNDV.
      /
       COPY CCFRPHST.
       COPY CCFWPHST.
      /
      ***************************************************************
      * CALLED MODULE PARAMETER INFORMATION
      ***************************************************************
       COPY CCWL0289.
020478 COPY CCWL2626.
      /
       COPY CCWL0620.
      /
       COPY CCWL0985.
      /
       COPY CCWL2430.
      /
       COPY CCWL5208.
      /
       COPY CCWL5400.
      /
       COPY CCWL0186.
      /
       COPY CCWL5750.
      /
       COPY CCWL4750.
      /
       COPY CCWL4780.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL0290.
      /
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
       COPY XCWL8090.
       COPY CCWWLOCK.
      /
      ***********************************************************
      * INPUT PARAMETER INFORMATION
      ***********************************************************
      /
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2831.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           EVALUATE TRUE

               WHEN  WS-BUS-FCN-REV-DIV-PUA

                     PERFORM  1000-PROCESS-REQUEST
                         THRU 1000-PROCESS-REQUEST-X

               WHEN  OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   SET MIR-RETRN-INVALD-RQST
                                           TO TRUE
                   MOVE MIR-BUS-FCN-ID     TO WGLOB-MSG-PARM (1)
                   MOVE 'CSOM2831'         TO WGLOB-MSG-PARM (2)
                   MOVE 'XS00000237'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.
      *
      *  EDIT SCREEN FIELDS AND SAVE THE INPUT
      *
           PERFORM  1100-SCREEN-EDITS
               THRU 1100-SCREEN-EDITS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.
      *
      *  PERFORM THE DIVIDEND PROCESSING
      *
           PERFORM  2000-DIVP-PROCESSING
               THRU 2000-DIVP-PROCESSING-X.

           IF  WS-POL-LOCKED
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               SET WS-POL-LOCKED-NO         TO TRUE
           END-IF.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       1100-SCREEN-EDITS.
      *------------------
      *
      * THIS ROUTINE SAVES THE INPUT FROM THE SCREEN AND BUILDS THE
      * DIVP EDIT/AUDIT CARD
      *
           IF  MIR-POL-ID-BASE = SPACES
           AND MIR-POL-ID-SFX  = SPACES
      *MSG:    POLICY ID MUST BE ENTERED
               MOVE 'CS28310001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 1100-SCREEN-EDITS-X
           END-IF.

      * VALIDATE EFFECTIVE DATE

           IF  MIR-DV-EFF-DT = WWKDT-ZERO-DT
           OR  MIR-DV-EFF-DT = SPACES
      *MSG:    EFFECTIVE DATE MUST BE ENTERED
               MOVE 'CS28310002'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR      TO TRUE
               GO TO 1100-SCREEN-EDITS-X
           END-IF.

           MOVE MIR-DV-EFF-DT              TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  NOT L1640-RETRN-OK
      *MSG:    EFFECTIVE DATE MUST BE VALID
               MOVE 'CS28310003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR      TO TRUE
               GO TO 1100-SCREEN-EDITS-X
           END-IF.

           MOVE L1640-INTERNAL-DATE        TO WS-EFF-DT.
           MOVE L1640-INTERNAL-DATE        TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE        TO  WS-DIV-IDT-NUM.

      * GET OWNER'S NAME

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID                 TO L2430-POL-ID.
           MOVE ZERO                       TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE                        L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD       TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME      TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                 TO MIR-DV-OWN-CLI-NM
           END-IF.

       1100-SCREEN-EDITS-X.
           EXIT.
      /
      *---------------------
       2000-DIVP-PROCESSING.
      *---------------------
      *
      *  ACCESS POLICY
      *
           MOVE MIR-POL-ID                 TO WPOL-POL-ID.

           IF  MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  POL-2000-UPDATE-TWRK-TS
                   THRU POL-2000-UPDATE-TWRK-TS-X
               SET WS-POL-LOCKED           TO TRUE

               IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
                   MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
                   MOVE 'POL'              TO WGLOB-MSG-PARM (01)
                   MOVE WPOL-KEY           TO WGLOB-MSG-PARM (02)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-DIVP-PROCESSING-X
               END-IF
           ELSE
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
               SET WS-POL-LOCKED-NO       TO TRUE
           END-IF.

           IF  NOT WPOL-IO-OK
      * MSG:  POLICY NOT FOUND IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2000-DIVP-PROCESSING-X
           END-IF.

           IF RPOL-POL-SUSPENDED
      *MSG: POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000240'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                  SET WGLOB-RETURN-ERROR       TO TRUE
                  GO TO 2000-DIVP-PROCESSING-X
               END-IF
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-EFF-DT                TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057         THRU IHSD-2000-CHK-IHSD-PROCESS-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WGLOB-RETURN-ERROR     TO TRUE
026057        GO TO 2000-DIVP-PROCESSING-X
026057     END-IF.
      *
      * VERIFY THAT POLICY ACCESS IS ALLOWED
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD      TO TRUE.
           SET L5400-POL-XFER-UPDATE    TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-DIVP-PROCESSING-X
           END-IF.
      *
      *  LOAD THE COVERAGES INTO THE WORK AREA
      *
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  RPOL-POL-STAT-BEFORE-SETL
      * MSG: POLICY NOT IN FORCE - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000238'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR TO TRUE
                   GO TO 2000-DIVP-PROCESSING-X
               END-IF
           END-IF.
      *
      * VALIDATE CLIENTS DATE OF DEATH FIELDS
      *
           PERFORM  0985-1000-BUILD-PARM-INFO
               THRU 0985-1000-BUILD-PARM-INFO-X

           MOVE WS-EFF-DT          TO L0985-EFF-DT

           PERFORM  0985-1000-VAL-POL-DT-OF-DTH
               THRU 0985-1000-VAL-POL-DT-OF-DTH-X

           IF  NOT L0985-RETRN-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 2000-DIVP-PROCESSING-X
           END-IF.
      *
      *  BUILD THE GENERAL PARAMETER AREA
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.
      *
      * CHECK PROCESS-STATUS CODE AND PROCESS THE TRANSACTION
      *
           PERFORM  3000-PROCESS-SURR-REV
               THRU 3000-PROCESS-SURR-REV-X

           IF  MIR-DV-PRCES-STATE-CD = '3'
           AND NOT WGLOB-RETURN-ERROR
               PERFORM  4000-VERIFY-SURR-REV
                   THRU 4000-VERIFY-SURR-REV-X
           END-IF.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-DIVP-PROCESSING-X
           END-IF.

       2000-DIVP-PROCESSING-X.
           EXIT.

      *----------------------
       3000-PROCESS-SURR-REV.
      *----------------------
      *
      *  VERIFY PLAN PARTICIPATING
      *
           PERFORM  3100-CHECK-DIV-RATE
               THRU 3100-CHECK-DIV-RATE-X.

           IF  WGLOB-RETURN-ERROR
      * MSG: PUA SURRENDER REVERSAL PROCESSING TERMINATED
               MOVE 'CS28310005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-SURR-REV-X
           END-IF.

           PERFORM  3200-CHECK-DIV-VEST-INFO
               THRU 3200-CHECK-DIV-VEST-INFO-X.

           IF  WGLOB-RETURN-ERROR
      * MSG: PUA SURRENDER REVERSAL PROCESSING TERMINATED
               MOVE 'CS28310005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-SURR-REV-X
           END-IF.
      *
      * CHECK FOR ANY OUTSTANDING ACTIVITY
      *

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               PERFORM  8500-CHECK-OS-ACTV
                   THRU 8500-CHECK-OS-ACTV-X

               IF  L4780-ACTIVITY-DUE
      *MSG: OUSTANDING ACTIVITY HAS NOT BEEN PROCESSED
                   MOVE 'CS28310006'          TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *
      * GET BNDV SURRENDER RECORD TO REVERSE
      *
           PERFORM  3300-GET-SURR-BNDV
               THRU 3300-GET-SURR-BNDV-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 3000-PROCESS-SURR-REV-X
           END-IF.

           PERFORM  3400-GET-DIV-PHST
               THRU 3400-GET-DIV-PHST-X.

       3000-PROCESS-SURR-REV-X.
           EXIT.

      /
      *-------------------
       3100-CHECK-DIV-RATE.
      *-------------------

           MOVE RPOL-POL-PAR-CVG-NUM  TO I.

           IF  WCVGS-CVG-NON-PARTICIPATING (I)
           OR  WCVGS-CVG-UNIT-VALU-AMT     (I) = ZERO
               GO TO 3100-CHECK-DIV-RATE-X
           END-IF.

           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.

           IF  WCVGS-CVG-STAT-PREM-PAYING (I)
               SET L0186-PLAN-RT-TYP-PPDVR TO TRUE
           ELSE
               SET L0186-PLAN-RT-TYP-PUDVR TO TRUE
           END-IF.

           PERFORM  0186-1000-BUILD-PARM-INFO
               THRU 0186-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                  TO L0186-EFF-DT.
           MOVE '000'                      TO L0186-ALT-AGE-2.

035251*    IF WCVGS-PLAN-ID-BASE-3-5 (I) = 'RPU'
035251*    OR 'ETI'
035251*        MOVE WCVGS-ORIG-PLAN-ID (I)  TO L0186-PLAN-ID
035251*    END-IF.

           PERFORM 0186-3000-GET-PLRT
              THRU 0186-3000-GET-PLRT-X.

      * AS WE ARE ONLY CHECKING TO SEE IF A PLRT EXISTS FOR THE
      * 'UV' RATE TYPE, WE DO NOT PASS A AGE-DURATION TO 0186 SO
      * THE RLTB LOOKUP WILL AWLAYS FAIL BUT THE FACT THAT IT HAS TRIED
      * TO ACCESS ONE PROVES THAT THE PLRT WAS FOUND
           IF L0186-RETRN-OK
           OR L0186-RETRN-BAD-RLTB-ACCESS
034802*       NEXT SENTENCE
034802        CONTINUE
           ELSE
      *MSG: THIS PLAN DOES NOT ALLOW DIVIDEND PROCESSING
               MOVE 'CS28310007'       TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO  TRUE
           END-IF.

       3100-CHECK-DIV-RATE-X.
           EXIT.

      /
      *------------------------
       3200-CHECK-DIV-VEST-INFO.
      *------------------------

           PERFORM  5750-1000-INIT-PARM-INFO
               THRU 5750-1000-INIT-PARM-INFO-X.

           MOVE RPOL-POL-PAR-CVG-NUM  TO  L5750-CVG-NUM.
           MOVE WS-EFF-DT             TO  L5750-EFF-DT.

           PERFORM  5750-2000-DIV-VEST
               THRU 5750-2000-DIV-VEST-X.

           IF NOT L5750-RETRN-OK
              SET WGLOB-RETURN-ERROR    TO  TRUE
           END-IF.

       3200-CHECK-DIV-VEST-INFO-X.
           EXIT.

      /
      *-------------------
       3300-GET-SURR-BNDV.
      *-------------------

           INITIALIZE                   RBNDV-REC-INFO.
           MOVE RPOL-POL-ID          TO WBNDD-POL-ID.
           MOVE RPOL-POL-PAR-CVG-NUM TO WBNDD-CVG-NUM-N.
           MOVE 'D'                  TO WBNDD-BON-DIV-TYP-CD.
           MOVE LOW-VALUES           TO WBNDD-BON-DIV-IDT-NUM.
           MOVE ZEROS                TO WBNDD-BON-DIV-SEQ-NUM.

           MOVE WBNDD-KEY            TO  WBNDD-ENDBR-KEY.
           MOVE WS-DIV-IDT-NUM       TO  WBNDD-ENDBR-BON-DIV-IDT-NUM.
           MOVE 999                  TO  WBNDD-ENDBR-BON-DIV-SEQ-NUM.

           PERFORM  BNDD-1000-BROWSE
               THRU BNDD-1000-BROWSE-X.

           PERFORM  BNDD-2000-READ-NEXT
               THRU BNDD-2000-READ-NEXT-X
               UNTIL  NOT WBNDD-IO-OK
               OR  (RBNDV-BON-DIV-STAT-ACTIVE
               AND  RBNDV-BON-DIV-TRXN-SURR ).
      *
           EVALUATE TRUE

               WHEN NOT WBNDD-IO-OK
      *MSG: DIVIDEND HISTORY RECORD NOT FOUND
                    MOVE 'CS28310008'       TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET WGLOB-RETURN-ERROR TO TRUE

               WHEN WS-DIV-IDT-NUM > RBNDV-BON-DIV-IDT-NUM
      *MSG: SUBSEQUENT DIVIDEND HSITORY RECORD FOUND - REVERSE IT FIRST
                    MOVE 'CS28310010'       TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET WGLOB-RETURN-ERROR TO TRUE

           END-EVALUATE.

           PERFORM  BNDD-3000-END-BROWSE
               THRU BNDD-3000-END-BROWSE-X.

           IF WGLOB-RETURN-ERROR
              GO TO 3300-GET-SURR-BNDV-X
           END-IF.

           IF  RBNDV-EFF-IDT-NUM     NOT = WS-DIV-IDT-NUM
      * MSG: CANNOT REVERSE DIVIDEND WITHDRAWAL - DIVIDEND HISTORY
      *      RECORD NOT MATCHED
               MOVE 'CS28310011'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 3300-GET-SURR-BNDV-X
           END-IF.


           MOVE RBNDV-BON-DIV-TRXN-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-BON-DIV-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-BON-DIV-TRXN-AMT.

       3300-GET-SURR-BNDV-X.
           EXIT.
      /
      *------------------
       3400-GET-DIV-PHST.
      *------------------
      *
      * FIND PHST RECORD
      *
           INITIALIZE                 RPHST-REC-INFO.
           MOVE RPOL-POL-ID           TO WPHST-POL-ID.
           MOVE WS-DIV-IDT-NUM        TO WPHST-PCHST-EFF-IDT-NUM.
           MOVE ZEROS                 TO WPHST-PCHST-SEQ-NUM.

           MOVE WPHST-KEY             TO WPHST-ENDBR-KEY.
030054*    MOVE 999                   TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                                TO WPHST-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-BROWSE
               THRU PHST-1000-BROWSE-X.

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.
      *
      *  IF PHST READ NOT OK THERE IS A PROBLEM WITH
      *  THE PHST FILE (LAP DATE IS INCORRECTLY SET)
      *
           IF  NOT WPHST-IO-OK
               MOVE WS-EFF-DT              TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (1)
      *  MSG: NO PHST ACTIVITIES FOUND TO UNDO FOR DATE @1
               MOVE 'CS28310009'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PHST-3000-END-BROWSE
                   THRU PHST-3000-END-BROWSE-X
               SET WGLOB-RETURN-ERROR      TO  TRUE
               GO  TO 3400-GET-DIV-PHST-X
           END-IF.
      *
      *  FIND THE ACTIVE PUA-SURR PHST RECORD
      *
           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X
               UNTIL WPHST-IO-EOF
               OR  (RPHST-POL-ACTV-TYP-ID = WS-ACTV-DIV-SURR-PUA
               AND RPHST-PCHST-STAT-ACTIVE)

           IF  WPHST-IO-EOF
               MOVE WS-EFF-DT              TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (1)
      *  MSG: NO PHST ACTIVITIES FOUND TO UNDO FOR DATE @1
               MOVE 'CS28310009'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR      TO  TRUE
           END-IF.

           PERFORM  PHST-3000-END-BROWSE
               THRU PHST-3000-END-BROWSE-X.

           MOVE RPHST-PCHST-NEW-VALU-TXT   TO WS-VALU-EDIT-SEQ-NUM-A.
           MOVE WS-VALU-EDIT-SEQ-NUM       TO WS-BNDV-SEQ-NUM.
           COMPUTE WS-BNDV-SEQ-NUM = 1000 - WS-BNDV-SEQ-NUM.

           IF  RBNDV-BON-DIV-SEQ-NUM NOT = WS-BNDV-SEQ-NUM
      * MSG: CANNOT REVERSE DIVIDEND WITHDRAWAL - DIVIDEND HISTORY
      *      RECORD NOT MATCHED
               MOVE 'CS28310011'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3400-GET-DIV-PHST-X
           END-IF.

       3400-GET-DIV-PHST-X.
           EXIT.

      *---------------------
       4000-VERIFY-SURR-REV.
      *---------------------

           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.
           SET WS-POL-LOCKED-NO    TO TRUE.


           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.

           MOVE RPHST-PCHST-EFF-DT      TO L4750-EFF-DT
           MOVE RPHST-PCHST-SEQ-NUM     TO L4750-PCHST-SEQ-NUM
           SET L4750-PRCES-INCLUSIVE    TO TRUE.
           SET L4750-PRCES-INCLUSIVE    TO TRUE.
           SET L4750-UNDO-PCHST-SEQ-YES TO TRUE.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR      TO TRUE
           ELSE
               MOVE RPOL-REC-INFO       TO HPOL-REC-INFO
               PERFORM  POL-1000-READ-FOR-UPDATE
                   THRU POL-1000-READ-FOR-UPDATE-X
               MOVE HPOL-REC-INFO       TO RPOL-REC-INFO
               SET WS-POL-LOCKED        TO TRUE
           END-IF.

           IF WGLOB-RETURN-ERROR
              GO TO 4000-VERIFY-SURR-REV-X
           END-IF.
      *
      *  GENERATE STATUS PRINT
      *
           PERFORM  5208-1000-BUILD-PARM-INFO
               THRU 5208-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                TO L5208-EFF-DT.

           PERFORM  5208-1000-WRITE-STATUS-PRT
               THRU 5208-1000-WRITE-STATUS-PRT-X.

           IF  NOT L5208-RETRN-OK
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 4000-VERIFY-SURR-REV-X
           END-IF.
      *
      *  UPDATE POLICY AND COVERAGES
      *
           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.

           MOVE WS-EFF-DT                 TO L0289-PROC-EFF-DT.
           MOVE WS-EFF-DT                 TO L0289-LO-PAC-DT.
           MOVE WS-EFF-DT                 TO L0289-LO-CRC-DT.

           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.

           IF  L0289-RETRN-OK
               MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
               MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
           ELSE
               MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
               MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
           END-IF.

           IF WGLOB-RETURN-ERROR
              GO TO 4000-VERIFY-SURR-REV-X
           END-IF.

           MOVE WGLOB-PROCESS-DATE    TO RPOL-PREV-FILE-MAINT-DT.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           SET WS-POL-LOCKED-NO    TO TRUE.

           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

      * MSG: DIVIDEND SURRENDER REVERSAL PROCESSING COMPLETED
           MOVE 'CS28310004'  TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-VERIFY-SURR-REV-X.
           EXIT.
      /
      *-------------------
       8500-CHECK-OS-ACTV.
      *-------------------

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 8500-CHECK-OS-ACTV-X
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT                   TO L4780-EFF-DT.
           SET L4780-REDO-WARNING           TO TRUE.
           MOVE RPOL-PREV-BTCH-PRCES-DT     TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE        TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

       8500-CHECK-OS-ACTV-X.
           EXIT.
      /
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

      *
      * MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      * TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0186-0000-INIT-PARM-INFO
025970         THRU 0186-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5208-0000-INIT-PARM-INFO
025970         THRU 5208-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5750-0000-INIT-PARM-INFO
025970         THRU 5750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-FIELDS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
025970     SET WS-ACTV-DIV-SURR-PUA-DEFAULT TO TRUE.
           SET  MIR-RETRN-OK               TO TRUE.
           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      ** PROCESSING COPYBOOKS
      *****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
       COPY NCPPCVGS.
      /
       COPY NCPPCVGR.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPPLIN.
      /
       COPY CCPPMIDT.
      /
026057 COPY CCPPIHSD.
      *****************************************************************
      ** LINKAGE PROCESSING COPYBOOKS
      *****************************************************************

025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
020478 COPY CCPS2626.
020478 COPY CCPL2626.
       COPY CCPL0289.
       COPY CCPS0289.
      /
025970 COPY CCPS0620.
       COPY CCPL0620.
      /
       COPY CCPS0985.
       COPY CCPL0985.
      /
       COPY CCPS2430.
       COPY CCPL2430.
      /
       COPY CCPS5208.
       COPY CCPL5208.
      /
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY CCPS0186.
       COPY CCPL0186.
      /
       COPY CCPS5750.
       COPY CCPL5750.
      /
       COPY CCPS4750.
       COPY CCPL4750.
      /
       COPY CCPS4780.
       COPY CCPL4780.
      /
       COPY XCPL0260.
      /
       COPY XCPL0290.
       COPY XCPS0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY XCPL8090.
      /
      *****************************************************************
      ** FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNPH.
      /
       COPY CCPBBNDD.
      /
       COPY CCPBPHST.
      /
      *****************************************************************
      ** ERROR HANDLING ROUTINES
      *****************************************************************

026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2831                     **
      *****************************************************************
