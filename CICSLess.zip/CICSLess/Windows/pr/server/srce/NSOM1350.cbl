
      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM1350.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM1350                                         **
      **  REMARKS:  PPRO - POLICY ISSUE, SETTLE, AND REJECT          **
      **                   PROCESSING                                **
      **                                                             **
      **            THIS MODULE CALLS THREE FUNCTION DRIVERS. ONE    **
      **            FUNCTION DRIVER WILL ISSUE POLICIES, ANOTHER     **
      **            WILL SETTLE POLICIES, AND THE THIRD FUNCTION     **
      **            DRIVER WILL TERMINATE POLICIES REJECTED BY THE   **
      **            UNDERWRITER OR POLICY OWNER AND ALSO REINSTATE   **
      **            REJECTED POLICIES. AN INQUIRY ON A POLICY IS     **
      **            ALSO PERFORMED BY THIS MODULE.                   **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557698**  5.5       MIXED CASE SUPPORT                               **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTI-LANGUAGE SUPPORT                  **
557767**  5.5       JOINT-AGE-CALCULATION                            **
010495**  5.5.2     ISSUE POLICY WHEN VERIFY IS SET AS 'C'           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       ADD SUB-COMPANY-CODE FIELD                       **
012148**  5.6V      TRAIL COMMISSION                                 **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
012624**  6.0       SECURITY                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       GLOBAL MESSAGING                                 **
014221**  6.2       LOGICAL LOCKING                                  **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016548**  6.2       CHANGE COMP TO BINARY                            **
018326**  6.2       PCR - MULTIPLE ISSUE PROCESSING CAUSING ERRORS   **
018731**  6.3       EFT ENHANCEMENTS                                 **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019982**  6.3       PCR FOR IIAB PLATFORM                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
027105**  6.6       99 COVERAGES HANDLING                            **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM1350'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'PPRO'.
           05  WS-LAST-NAME-FIRST-FOUR      PIC X(04).
016548*    05  WS-MAX-LINES-PER-SCREEN      PIC S9(04) COMP  VALUE +20.
025970*    05  WS-MAX-LINES-PER-SCREEN      PIC S9(04)
025970*                                     BINARY  VALUE +20.
027105     05  WS-MAX-LINES-PER-SCREEN      PIC S9(04) BINARY.
           05  WS-HOLD-POLICY               PIC X(10).
           05  WS-HOLD-POLICY-STATUS        PIC X(04).
           05  WS-CLIENT-TABLE.
               10  WS-CLIENT-NUMBER         PIC X(10) OCCURS 120 TIMES.
016548*    05  WS-MAX-NUM-OF-CLIENTS        PIC S9(04) COMP VALUE +120.
025970*    05  WS-MAX-NUM-OF-CLIENTS        PIC S9(04)
025970*                                     BINARY VALUE +120.
016548*    05  WS-CLI                       PIC S9(04) COMP.
016548     05  WS-CLI                       PIC S9(04) BINARY.
           05  WS-REASSIGN-FINISHED-SW      PIC X(01).
               88  WS-REASSIGN-FINISHED     VALUE 'Y'.
               88  WS-REASSIGN-NOT-FINISHED VALUE 'N'.
016548*    05  WS-LINE                      PIC S9(4) COMP.
016548     05  WS-LINE                      PIC S9(4) BINARY.
027105*    05  WS-CVG-X.
027105*        10  WS-CVG                   PIC 99.
027105     05  WS-CVG                       PIC 9(03).
016548*    05  WS-MAX-CLIENTS               PIC S9(4) COMP.
016548     05  WS-MAX-CLIENTS               PIC S9(4) BINARY.
016548*    05  I                            PIC S9(04) COMP.
016548     05  I                            PIC S9(04) BINARY.
016548*    05  J                            PIC S9(04) COMP.
016548     05  J                            PIC S9(04) BINARY.
016548*    05  K                            PIC S9(04) COMP.
016548     05  K                            PIC S9(04) BINARY.
           05  WS-EFF-DATE                  PIC X(10).
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1350', '1351',
                                            '1352', '1353', '1354'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1350'.
               88  WS-BUS-FCN-REINST        VALUE '1351'.
               88  WS-BUS-FCN-REJECT        VALUE '1352'.
               88  WS-BUS-FCN-SETTLE        VALUE '1353'.
               88  WS-BUS-FCN-ISSUE         VALUE '1354'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1350'.
           05  WS-VALIDATE-OK-SW            PIC X(01).
               88  WS-VALIDATE-FAILED       VALUE 'N'.
           05  WS-CONFIRM-REQD-SW           PIC X(01).
               88  WS-CONFIRM-REQD          VALUE 'Y'.
           05  WS-STOP-DISPLAY-SW           PIC X(01).
               88  WS-STOP-DISPLAY          VALUE 'Y'.
018326     05  WS-POLICY-ISSUED-IND         PIC X(01).
018326         88  WS-POLICY-ISSUED         VALUE 'Y'.
           05  WS-RETRN-CD                  PIC 9999.
      *
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'PPRO'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '1350'.
025970     05  WS-MAX-NUM-OF-CLIENTS        PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-NUM-OF-CLIENTS       VALUE +120.
      *
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
026057 COPY CCWWIHSD.
      *
014035*COPY CCFHPOL.
557756*COPY CCWTYSNO.
      *
      ****     FILE LAYOUT AND WORK AREAS           *****
       COPY CCFWPOL.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWCVGC.
       COPY CCFRCVGC.
      *
014035*COPY CCFWEDIT.
014035*COPY CCFREDIT.
      *
      ****     WORKING STORAGE PARAMETER AREA       *****
013578 COPY CCWL0620.
028298 COPY CCWL2626.
      *
016440 COPY CCWL2222.
      *
016503 COPY CCWL0289.
      *
       COPY CCWL1100.
      *
       COPY CCWL2430.
      *
       COPY CCWL5400.
      *
       COPY CCWL5600.
      *
       COPY CCWL6400.
012148*
012148 COPY CCWL8240.
      *
       COPY NCWL0700.
      *
021930*COPY NCWLBGND.
       COPY NCWL0710.
      *
       COPY NCWL2437.
      *
       COPY XCWL1640.
014035*COPY XCWL1670.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
014221 COPY XCWL8090.
       COPY XCWLDTLK.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM1350.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
      *
019982     INITIALIZE L2222-PARM-INFO.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      ***************************************************************
      *   INITIALIZE SCREEN FIELDS AND SET ATTRIBUTES TO ALLOW ENTRY
      *   OF KEY AND CONTROL FIELDS
      ***************************************************************
      ********************

      *
      *
      ***************************************************************
      *   NORMAL PROCESSING: CHECK SECURITY PERMISSION & DISTRIBUTE
      *   CONTROL TO APPRPORIATE PROCESSING ROUTINE.
      ***************************************************************
      ***************************
       2000-PROCESS-REQUEST.
      ***************************

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.


            PERFORM  9300-SETUP-MSIN-REFERENCE
                THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

      *     VALIDATE KEY AND CONTROL FIELDS
013578      IF MIR-DV-PRCES-STATE-CD  = '3'
013578      OR MIR-DV-PRCES-STATE-CD  = '4'
013578         PERFORM  2200-EDIT-CONTROL-FIELDS-2
013578             THRU 2200-EDIT-CONTROL-FIELDS-2-X
013578      ELSE
013578         PERFORM  2100-EDIT-CONTROL-FIELDS-1
013578             THRU 2100-EDIT-CONTROL-FIELDS-1-X
013578      END-IF.

            IF WS-VALIDATE-FAILED
                GO TO 2000-PROCESS-REQUEST-X
557660      END-IF.


            EVALUATE TRUE

              WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

              WHEN WS-BUS-FCN-ISSUE
                   PERFORM  4000-PROCESS-ISSUE
                       THRU 4000-PROCESS-ISSUE-X

              WHEN WS-BUS-FCN-SETTLE
                   PERFORM  5000-PROCESS-SETTLE
                       THRU 5000-PROCESS-SETTLE-X



              WHEN WS-BUS-FCN-REJECT
                   IF MIR-DV-PRCES-STATE-CD  = '2'
                     AND RPOL-POL-SUSPENDED
                         MOVE 'NS13500058' TO WGLOB-MSG-REF-INFO
                         PERFORM  0260-1000-GENERATE-MESSAGE
                             THRU 0260-1000-GENERATE-MESSAGE-X
                         PERFORM  3000-PROCESS-RETRIEVE
                             THRU 3000-PROCESS-RETRIEVE-X
                         GO TO 2000-PROCESS-REQUEST-X
557660             END-IF

                   PERFORM  6000-PROCESS-REJECT
                       THRU 6000-PROCESS-REJECT-X

              WHEN WS-BUS-FCN-REINST
                   IF MIR-DV-PRCES-STATE-CD  = '2'
                     AND RPOL-POL-SUSPENDED
                         MOVE 'NS13500058' TO WGLOB-MSG-REF-INFO
                         PERFORM  0260-1000-GENERATE-MESSAGE
                             THRU 0260-1000-GENERATE-MESSAGE-X
                         PERFORM  3000-PROCESS-RETRIEVE
                             THRU 3000-PROCESS-RETRIEVE-X
                         GO TO 2000-PROCESS-REQUEST-X
557660             END-IF
                   PERFORM  7000-PROCESS-REINSTATE
                       THRU 7000-PROCESS-REINSTATE-X

              WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM1350'
                                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

            END-EVALUATE.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *---------------------------------------------------------------
      *    DO ALL VALIDITY CHECKS ON KEY AND CONTROL FIELDS THAT ARE N
      *    FUNCTION SPECIFIC FOR INITIAL SCREEN (FORCE = 1)
      *---------------------------------------------------------------
       2100-EDIT-CONTROL-FIELDS-1.


            MOVE 'Y'                  TO WS-VALIDATE-OK-SW.

            IF WGLOB-MSG-ERROR-SW NOT = ZERO
                MOVE 'N'              TO WS-VALIDATE-OK-SW
                GO TO 2100-EDIT-CONTROL-FIELDS-1-X
557660      END-IF.

            PERFORM  2300-BUILD-POLICY-KEY
                THRU 2300-BUILD-POLICY-KEY-X.

014221*     PERFORM  POL-1000-READ
014221*         THRU POL-1000-READ-X.
014221      PERFORM  POL-1000-READ-TWRK-TS
014221          THRU POL-1000-READ-TWRK-TS-X.

           IF NOT WPOL-IO-OK
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALIDATE-OK-SW
               GO TO 2100-EDIT-CONTROL-FIELDS-1-X
557660     END-IF.

016440* CALL ROUTINE FOR INFORCE POLICIES TO DETERMINE IF ANY
016440* PENDING COVERAGES EXIST.

016440     IF  RPOL-POL-STAT-IN-FORCE
016440         PERFORM  2222-1000-BUILD-PARM-INFO
016440             THRU 2222-1000-BUILD-PARM-INFO-X
016440         MOVE RPOL-POL-ID       TO L2222-POL-ID
016440         PERFORM  2222-1000-FIND-PEND-CVG
016440             THRU 2222-1000-FIND-PEND-CVG-X
016440     END-IF.

016440     IF  (WS-BUS-FCN-SETTLE
016440     OR  MIR-DV-AUTO-SETL-CD = 'S')
016440     AND (RPOL-POL-STAT-IN-FORCE
016440     AND L2222-INFORCE-POL-INFORCE-CVG)
016440         MOVE  WPOL-KEY             TO WGLOB-MSG-PARM (1)
016440* MSG: SETTLE FAILED, NO PENDING COVERAGES EXIST
016440         MOVE 'NS13500001'          TO WGLOB-MSG-REF-INFO
016440         PERFORM  0260-1000-GENERATE-MESSAGE
016440             THRU 0260-1000-GENERATE-MESSAGE-X
016440         MOVE 'N'                   TO WS-VALIDATE-OK-SW
016440         GO TO 2100-EDIT-CONTROL-FIELDS-1-X
016440     END-IF.

012148     PERFORM  8240-1000-BUILD-PARM-INFO
012148         THRU 8240-1000-BUILD-PARM-INFO-X.
012148     MOVE WPOL-POL-ID           TO L8240-POL-ID.
012148     PERFORM  8240-1000-RETRIEVE-POLW
012148         THRU 8240-1000-RETRIEVE-POLW-X.
012148
           IF MIR-POL-ISS-DT-TYP-CD = 'C'
           OR MIR-POL-ISS-DT-TYP-CD = 'E'
               MOVE MIR-POL-ISS-DT-TYP-CD
                                      TO RPOL-POL-ISS-DT-TYP-CD
           ELSE
               IF MIR-POL-ISS-DT-TYP-CD = SPACE
                   MOVE RPOL-POL-ISS-DT-TYP-CD
                                      TO MIR-POL-ISS-DT-TYP-CD
               END-IF
           END-IF.


           PERFORM 5400-1000-BUILD-PARM-INFO
              THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.
012624*    IF WS-BUS-FCN-RETRIEVE
012624*        SET L5400-CTL-MSG-NOT-REQD TO TRUE
012624*    END-IF.

           SET L5400-STAT-MSG-NOT-REQD    TO TRUE.
           SET L5400-CRCY-MSG-REQD        TO TRUE.

016440*    IF RPOL-POL-APPL-CTL-CD = 'AD'
016440*MSG    ADMIN  POLICY - CANNOT MAINTAIN OR PROCESS
016440*       MOVE 'XS00000239'       TO WGLOB-MSG-REF-INFO
016440*       PERFORM 0260-1000-GENERATE-MESSAGE
016440*          THRU 0260-1000-GENERATE-MESSAGE-X
016440*       MOVE 'N'                TO WS-VALIDATE-OK-SW
016440*       GO TO 2100-EDIT-CONTROL-FIELDS-1-X
016440*    END-IF.


           PERFORM 5400-1000-POL-CHK
              THRU 5400-1000-POL-CHK-X.


           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-CRCY-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
               MOVE 'N'               TO WS-VALIDATE-OK-SW
               GO TO 2100-EDIT-CONTROL-FIELDS-1-X
           END-IF.

           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.

010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
      **
      **WHEN CURRENT, ALWAYS USE CURRENT PROCESSING DATE AS EFF DATE.
      **IF EFFECTIVE AND NO DATE ENTERED THEN USE POL ISS EFF DATE.
      **OTHERWISE, EDIT EFF DATE THAT WAS KEYED AND USE AS ISS EFF DATE.
      **
           EVALUATE RPOL-POL-ISS-DT-TYP-CD
               WHEN 'C'
                   MOVE WGLOB-PROCESS-DATE
                                      TO L1640-INTERNAL-DATE
               WHEN 'E'
016440*            IF MIR-POL-ISS-EFF-DT = SPACES
016440             IF MIR-DV-ISS-EFF-DT = SPACES
016440                IF L2222-INFORCE-POL-PEND-CVG
016440                   MOVE L2222-PEND-CVG-ISS-EFF-DT
016440                                TO L1640-INTERNAL-DATE
016440                ELSE
                          MOVE RPOL-POL-ISS-EFF-DT
                                      TO L1640-INTERNAL-DATE
016440                END-IF
                   ELSE
                       PERFORM  9920-EDIT-EFF-DATE
                           THRU 9920-EDIT-EFF-DATE-X
                       MOVE WS-EFF-DATE
                                      TO
                            L1640-INTERNAL-DATE
                   END-IF
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.

026057     MOVE L1640-INTERNAL-DATE      TO WIHSD-EFF-DT.
026057     PERFORM  2400-EDIT-INV-HIST-STRT-DT
026057         THRU 2400-EDIT-INV-HIST-STRT-DT-X.

016440*    IF  MIR-POL-ISS-EFF-DT = SPACES
016440     IF  MIR-DV-ISS-EFF-DT = SPACES
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
016440*                               TO MIR-POL-ISS-EFF-DT
016440                                TO MIR-DV-ISS-EFF-DT
               GO TO 2100-EDIT-CONTROL-FIELDS-1-X
557660     END-IF.

       2100-EDIT-CONTROL-FIELDS-1-X.
            EXIT.
      *
013578 2200-EDIT-CONTROL-FIELDS-2.


            MOVE 'Y'                  TO WS-VALIDATE-OK-SW.

            IF WGLOB-MSG-ERROR-SW NOT = ZERO
                MOVE 'N'              TO WS-VALIDATE-OK-SW
                GO TO 2200-EDIT-CONTROL-FIELDS-2-X
            END-IF.

            PERFORM  2300-BUILD-POLICY-KEY
                THRU 2300-BUILD-POLICY-KEY-X.

014221*     PERFORM  POL-1000-READ
014221*         THRU POL-1000-READ-X.
014221      PERFORM  POL-1000-READ-TWRK-TS
014221          THRU POL-1000-READ-TWRK-TS-X.

           IF NOT WPOL-IO-OK
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALIDATE-OK-SW
               GO TO 2200-EDIT-CONTROL-FIELDS-2-X
           END-IF.


016440* CALL ROUTINE FOR INFORCE POLICIES TO DETERMINE IF ANY
016440* PENDING COVERAGES EXIST.

016440     IF  RPOL-POL-STAT-IN-FORCE
016440         PERFORM  2222-1000-BUILD-PARM-INFO
016440             THRU 2222-1000-BUILD-PARM-INFO-X
016440         MOVE RPOL-POL-ID       TO L2222-POL-ID
016440         PERFORM  2222-1000-FIND-PEND-CVG
016440             THRU 2222-1000-FIND-PEND-CVG-X
016440     END-IF.


           IF MIR-POL-ISS-DT-TYP-CD = 'C'
           OR MIR-POL-ISS-DT-TYP-CD = 'E'
               MOVE MIR-POL-ISS-DT-TYP-CD
                                      TO RPOL-POL-ISS-DT-TYP-CD
           ELSE
               IF MIR-POL-ISS-DT-TYP-CD = SPACE
                   MOVE RPOL-POL-ISS-DT-TYP-CD
                                      TO MIR-POL-ISS-DT-TYP-CD
               END-IF
           END-IF.


       2200-EDIT-CONTROL-FIELDS-2-X.
013578      EXIT.
      *
       2300-BUILD-POLICY-KEY.

           MOVE MIR-POL-ID-BASE           TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO WPOL-POL-ID-SFX.

       2300-BUILD-POLICY-KEY-X.
           EXIT.

026057*---------------------------
026057 2400-EDIT-INV-HIST-STRT-DT.
026057*---------------------------
026057
026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     IF  WS-BUS-FCN-RETRIEVE
026057         PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057             THRU IHSD-1000-CHK-IHSD-INQUIRY-X
026057     ELSE
026057         PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057             THRU IHSD-2000-CHK-IHSD-PROCESS-X
026057     END-IF.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WS-VALIDATE-FAILED     TO TRUE
026057        SET WGLOB-RETURN-ERROR     TO TRUE
026057     END-IF.
026057
026057 2400-EDIT-INV-HIST-STRT-DT-X.
026057     EXIT.
      *
      *----------------------------------------------------------------
      *   INQUIRY PROCESSING: RETRIEVE COVERAGES AND DISPLAY.
      *----------------------------------------------------------------
       3000-PROCESS-RETRIEVE.


013578*    MOVE SPACE                 TO MIR-DV-CLI-NM.
013578     MOVE SPACE                 TO MIR-DV-OWN-CLI-NM.
           MOVE SPACE                 TO MIR-DV-POL-FUT-DT-CD.
018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD.

013578     PERFORM  9900-EDIT-OWNER-NAME
013578         THRU 9900-EDIT-OWNER-NAME-X.

           PERFORM  9600-DISPLAY-COVERAGES
               THRU 9600-DISPLAY-COVERAGES-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.

      *    MESSAGE (I) 'INQUIRE COMPLETE - CONTINUE'
           MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   ISSUE PROCESSING:
      *----------------------------------------------------------------
       4000-PROCESS-ISSUE.

           IF MIR-DV-PRCES-STATE-CD  = '3'
           OR MIR-DV-PRCES-STATE-CD  = '4'
               PERFORM  4200-ISSUE-2
                   THRU 4200-ISSUE-2-X
           ELSE
               PERFORM  4100-ISSUE-1
                   THRU 4100-ISSUE-1-X
557660     END-IF.

       4000-PROCESS-ISSUE-X.
           EXIT.
      *----------------------------------------------------------------
      *   FIRST STEP OF ISSUE PROCESSING: PERFORM EDITS AND DISPLAY COV
      *----------------------------------------------------------------
       4100-ISSUE-1.

      *    *** ISSUE SPECIFIC EDITS
           PERFORM  9900-EDIT-OWNER-NAME
               THRU 9900-EDIT-OWNER-NAME-X.

           PERFORM  9920-EDIT-EFF-DATE
               THRU 9920-EDIT-EFF-DATE-X.

           IF WS-VALIDATE-FAILED
               GO TO 4100-ISSUE-1-X
557660     END-IF.

           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
           PERFORM 4210-BUILD-0700-INFO
              THRU 4210-BUILD-0700-INFO-X.
           SET L0700-PRCES-TYP-EDIT-ONLY TO TRUE.
012148
012148     MOVE L8240-AGT-ID (1)      TO L0700-POLW-AGT-ID (1).
012148     MOVE L8240-AGT-ID (2)      TO L0700-POLW-AGT-ID (2).
012148     MOVE L8240-AGT-ID (3)      TO L0700-POLW-AGT-ID (3).
012148
           PERFORM 0700-1000-ISSUE-POLICY
              THRU 0700-1000-ISSUE-POLICY-X.


           IF  NOT L0700-RETRN-OK
           AND NOT L0700-RETRN-SETTLE-ERROR
               GO TO 4100-ISSUE-1-X
           END-IF.

           IF  NOT L0700-RETRN-OK
               GO TO 4100-ISSUE-1-X
           END-IF.

018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD.

           PERFORM  9600-DISPLAY-COVERAGES
               THRU 9600-DISPLAY-COVERAGES-X.


      *    MESSAGE (I) 'PRESS ENTER TO CONFIRM ISSUE'.
           MOVE 'NS13500005'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       4100-ISSUE-1-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   SECOND STEP OF ISSUE PROCESSING: PERFORM ISSUE PROCESSING
      *----------------------------------------------------------------
       4200-ISSUE-2.

      *    ***GET POLICY (FOR UPDATE) AND ALL COVERAGES (NO UPDATE)

           PERFORM  9900-EDIT-OWNER-NAME
               THRU 9900-EDIT-OWNER-NAME-X.

           PERFORM  2300-BUILD-POLICY-KEY
               THRU 2300-BUILD-POLICY-KEY-X.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        MOVE 'N'                   TO WS-VALIDATE-OK-SW
014221     END-IF.

           IF NOT WPOL-IO-OK
      *        MESSAGE (S) 'POLICY RECORD LOST DURING ISSUE'
               MOVE 'NS13500006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALIDATE-OK-SW
           ELSE
               MOVE RPOL-POL-ID       TO LPGA-POLICY-NUMBER
557660     END-IF.

           IF MIR-POL-ISS-DT-TYP-CD = 'C'
           OR MIR-POL-ISS-DT-TYP-CD = 'E'
               MOVE MIR-POL-ISS-DT-TYP-CD
                                      TO RPOL-POL-ISS-DT-TYP-CD
           END-IF.

           IF NOT WS-VALIDATE-FAILED
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE 'N'               TO WS-VALIDATE-OK-SW
557660     END-IF.

           IF WS-VALIDATE-FAILED
013578*        MOVE SPACE             TO MIR-DV-CLI-NM
013578         MOVE SPACE             TO MIR-DV-OWN-CLI-NM
               MOVE SPACE             TO MIR-DV-AUTO-SETL-CD
               GO TO 4200-ISSUE-2-X
557660     END-IF.

      *  COMPARE EFFECTIVE DATE ON SCREEN WITH EFFECTIVE DATE ON POLICY
      *
           PERFORM  9920-EDIT-EFF-DATE
               THRU 9920-EDIT-EFF-DATE-X.
026057     IF WS-VALIDATE-FAILED
026057         MOVE SPACE             TO MIR-DV-OWN-CLI-NM
026057         MOVE SPACE             TO MIR-DV-AUTO-SETL-CD
026057         GO TO 4200-ISSUE-2-X
026057     END-IF.

      **
      ** IF MIR-DV-PRCES-STATE-CD
      ** IS 3, THE USER HAS ALREADY CONFIRMED THE
      ** SECOND VERIFY AND CAN PROCEED DIRECTLY TO THAT LOGIC.
      ** AS WELL, IF THERE IS NO CHANGE TO THE EFFECTIVE DATE
      ** THEN THERE ARE NO UPDATES, SO THE USER CAN AGAIN PROCEED WITH
      ** ISSUE LOGIC.
      **
018326     INITIALIZE WS-POLICY-ISSUED-IND.

           IF  WS-EFF-DATE = RPOL-POL-ISS-EFF-DT
           OR  MIR-DV-PRCES-STATE-CD = '4'
               PERFORM  4300-ISSUE-3
                   THRU 4300-ISSUE-3-X
               GO TO 4200-ISSUE-2-X
557660     END-IF.

           PERFORM 4210-BUILD-0700-INFO
              THRU 4210-BUILD-0700-INFO-X.
           SET L0700-CHECK-RATE-AGE TO TRUE.
012148
012148     MOVE L8240-AGT-ID (1)      TO L0700-POLW-AGT-ID (1).
012148     MOVE L8240-AGT-ID (2)      TO L0700-POLW-AGT-ID (2).
012148     MOVE L8240-AGT-ID (3)      TO L0700-POLW-AGT-ID (3).
012148

           PERFORM 0700-1000-ISSUE-POLICY
              THRU 0700-1000-ISSUE-POLICY-X.

018326     SET WS-POLICY-ISSUED       TO TRUE.

           IF L0700-ISSUE-CONFIRM-REQD
               PERFORM 4220-CONFIRM-AGE-CHANGE
                  THRU 4220-CONFIRM-AGE-CHANGE-X
               PERFORM POL-3000-UNLOCK
                  THRU POL-3000-UNLOCK-X
           ELSE
               PERFORM 4300-ISSUE-3
                  THRU 4300-ISSUE-3-X
           END-IF.

013578     MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.

       4200-ISSUE-2-X.
           EXIT.

       4210-BUILD-0700-INFO.

           PERFORM 0700-1000-BUILD-PARM-INFO
              THRU 0700-1000-BUILD-PARM-INFO-X.
013578*    MOVE MIR-DV-CLI-NM         TO L0700-CLI-SUR-NM-1-4.
013578*    MOVE MIR-DV-OWN-CLI-NM     TO L0700-CLI-SUR-NM-1-4.
           MOVE WS-EFF-DATE           TO L0700-EFF-DT.
           MOVE MIR-POL-ISS-DT-TYP-CD TO L0700-ISSUE-IND.
           IF MIR-DV-AUTO-SETL-CD = 'S'
               SET L0700-ATTEMPT-SETTLE-REQD TO TRUE
           END-IF.
           SET L0700-CHNG-RATE-AGE           TO TRUE.

016440     IF L2222-INFORCE-POL-PEND-CVG
016440        SET  L0700-CVG-PROCESS  TO TRUE
016440        MOVE L2222-PEND-CVG-ISS-EFF-DT
016440                                TO L0700-CVG-ISS-EFF-DT
016440        MOVE L2222-CVG-UWGDECN-COMPLETE-IND
016440                      TO L0700-CVG-UWGDECN-COMPLETE-IND
016440     END-IF.

       4210-BUILD-0700-INFO-X.
           EXIT.


       4220-CONFIRM-AGE-CHANGE.

018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD.

           PERFORM  9600-DISPLAY-COVERAGES
               THRU 9600-DISPLAY-COVERAGES-X.

      * NEW MESSAGE (I) 'ENTER 'C' IN VERIFY FIELD TO CONTINUE'
           MOVE 'NS13500054'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

013578     SET MIR-RETRN-VERFY-REQD   TO TRUE.

           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

       4220-CONFIRM-AGE-CHANGE-X.
           EXIT.

       4300-ISSUE-3.
      *
      * CALL NSLF0700 IF NOT ALREADY DONE
      *
           IF  WS-EFF-DATE = RPOL-POL-ISS-EFF-DT
           OR  MIR-DV-PRCES-STATE-CD = '4'
018326         IF NOT WS-POLICY-ISSUED

                  PERFORM 4210-BUILD-0700-INFO
                     THRU 4210-BUILD-0700-INFO-X
012148
012148            MOVE L8240-AGT-ID (1)  TO L0700-POLW-AGT-ID (1)
012148            MOVE L8240-AGT-ID (2)  TO L0700-POLW-AGT-ID (2)
012148            MOVE L8240-AGT-ID (3)  TO L0700-POLW-AGT-ID (3)
012148
                  PERFORM 0700-1000-ISSUE-POLICY
                     THRU 0700-1000-ISSUE-POLICY-X
018326         ELSE
018326            CONTINUE
018326         END-IF
           END-IF.

016503* GET NEXT ACTIVITY DATE AND TYPE
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.

016503     MOVE WS-EFF-DATE             TO  L0289-LO-PAC-DT.
020467     MOVE WS-EFF-DATE             TO  L0289-LO-DD2-DT.
016503     MOVE WS-EFF-DATE             TO  L0289-LO-CRC-DT.
016503     MOVE WS-EFF-DATE             TO  L0289-PROC-EFF-DT.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.


           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X

           EVALUATE TRUE
               WHEN L0700-EFF-DT-ERROR
      *MSG: POLICY NOT ISSUED DUE TO CURRENT DATING ERRORS
                   MOVE 'NS13500014'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               WHEN L0700-ISSUE-IND-ERROR
      *MSG: POLICY ISSUE FAILED
                   MOVE 'NS13500043'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               WHEN L0700-POL-ID-ERROR
      *MSG: POLICY ID ERROR
                   MOVE 'NS13500065'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               WHEN OTHER
                   CONTINUE
           END-EVALUATE

           EVALUATE TRUE
               WHEN L0700-RETRN-OK
               WHEN L0700-RETRN-SETTLE-ERROR
      *MSG: 'POLICY ISSUE COMPLETE'
                   MOVE 'NS13500033'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
016440         WHEN L0710-RETRN-ERROR
016440* UNLOCK POLICY
016440              PERFORM  POL-3000-UNLOCK
016440                  THRU POL-3000-UNLOCK-X
               WHEN OTHER
      *MSG:'POLICY ISSUE FAILED DUE TO PROCESSING ERROR'
                   SET WGLOB-RETURN-ERROR  TO TRUE
                   MOVE 'NS13500066'  TO WGLOB-MSG-REF-INFO
                   MOVE L0700-RETRN-CD                    TO WS-RETRN-CD
                   MOVE WS-RETRN-CD   TO WGLOB-MSG-PARM (1)
                   SET  WGLOB-RETURN-ERROR TO TRUE
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
           END-EVALUATE

           PERFORM  9600-DISPLAY-COVERAGES
               THRU 9600-DISPLAY-COVERAGES-X.

013578*    MOVE SPACE                 TO MIR-DV-CLI-NM.
013578*    MOVE SPACE                 TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
           MOVE SPACE                 TO MIR-DV-AUTO-SETL-CD.
018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD.


       4300-ISSUE-3-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   SETTLE PROCESSING:
      *----------------------------------------------------------------
       5000-PROCESS-SETTLE.

           IF MIR-DV-PRCES-STATE-CD  = '3'
               PERFORM  5200-SETTLE-2
                   THRU 5200-SETTLE-2-X
           ELSE
               PERFORM  5100-SETTLE-1
                   THRU 5100-SETTLE-1-X
557660     END-IF.

       5000-PROCESS-SETTLE-X.
           EXIT.
      *----------------------------------------------------------------
      *   FIRST STEP OF SETTLE PROCESSING: PERFORM EDITS AND DISPLAY CO
      *----------------------------------------------------------------
       5100-SETTLE-1.

      *    *** SETTLE SPECIFIC EDITS
           PERFORM  9900-EDIT-OWNER-NAME
               THRU 9900-EDIT-OWNER-NAME-X.

           PERFORM  9920-EDIT-EFF-DATE
               THRU 9920-EDIT-EFF-DATE-X.

           IF WS-VALIDATE-FAILED
               GO TO 5100-SETTLE-1-X
557660     END-IF.

           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

      *
      * CALL CSLF1100 TO PERFORM ADDITIONAL EDITS
      *
           PERFORM 1100-1000-BUILD-PARM-INFO
              THRU 1100-1000-BUILD-PARM-INFO-X.
           SET L1100-PRCES-TYP-EDIT-ONLY TO TRUE.
013578*    MOVE MIR-DV-CLI-NM         TO L1100-CLI-SUR-NM-1-4.
013578*    MOVE MIR-DV-OWN-CLI-NM     TO L1100-CLI-SUR-NM-1-4.
           MOVE WS-EFF-DATE           TO L1100-EFF-DT.
           MOVE MIR-POL-ISS-DT-TYP-CD TO L1100-ISSUE-IND.
           MOVE MIR-DV-POL-FUT-DT-CD  TO L1100-SUB-CODE.
012148
012148     MOVE L8240-AGT-ID (1)      TO L1100-POLW-AGT-ID (1).
012148     MOVE L8240-AGT-ID (2)      TO L1100-POLW-AGT-ID (2).
012148     MOVE L8240-AGT-ID (3)      TO L1100-POLW-AGT-ID (3).
016440*    PERFORM 1100-1000-SETTLE-POLICY
016440*       THRU 1100-1000-SETTLE-POLICY-X.

016440*
016440* SETTLE ALL PENDING COVERAGES ON INFORCE POLICY
016440* OR SETTLE PENDING POLICY
016440*

016440     IF L2222-INFORCE-POL-PEND-CVG
016440        PERFORM 5150-SETTLE-CVG-EDIT
016440           THRU 5150-SETTLE-CVG-EDIT-X
016440           VARYING WS-CVG FROM 1 BY 1
016440           UNTIL WS-CVG > RPOL-POL-CVG-REC-CTR-N
016440     ELSE
016440         PERFORM  1100-1000-SETTLE-POLICY
016440             THRU 1100-1000-SETTLE-POLICY-X
016440     END-IF.

           IF L1100-RETRN-OK
               MOVE L1100-EFF-DT      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
016440*                               TO MIR-POL-ISS-EFF-DT
016440                                TO MIR-DV-ISS-EFF-DT
               MOVE L1100-ISSUE-IND   TO MIR-POL-ISS-DT-TYP-CD
           END-IF.


           IF  L1100-EFF-DT-ERROR
016440         IF L2222-INFORCE-POL-PEND-CVG
016440            MOVE L2222-PEND-CVG-ISS-EFF-DT
016440                                TO L1640-INTERNAL-DATE
016440         ELSE
                  MOVE RPOL-POL-ISS-EFF-DT
                                      TO L1640-INTERNAL-DATE
016440         END-IF
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
016440*                               TO MIR-POL-ISS-EFF-DT
016440                                TO MIR-DV-ISS-EFF-DT
           END-IF.

           IF NOT L1100-RETRN-OK
               IF  L1100-POL-ID-ERROR
               OR  L1100-ISSUE-IND-ERROR
               OR  L1100-EFF-DT-ERROR
                   CONTINUE
               END-IF
               GO TO 5100-SETTLE-1-X
           END-IF.

018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD.


           PERFORM  9600-DISPLAY-COVERAGES
               THRU 9600-DISPLAY-COVERAGES-X.


      *    MESSAGE (I) 'PRESS ENTER TO CONFIRM SETTLE'.
           MOVE 'NS13500041'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       5100-SETTLE-1-X.
           EXIT.
      *
016440*---------------------
016440 5150-SETTLE-CVG-EDIT.
016440*---------------------
016440
016440     IF NOT WCVGS-CVG-STAT-PENDING (WS-CVG)
016440        GO TO 5150-SETTLE-CVG-EDIT-X
016440     END-IF.
016440
016440     MOVE WCVGS-CVG-SEQ-NUM (WS-CVG)    TO L1100-CVG-NUM.
016440     MOVE WS-EFF-DATE                   TO L1100-EFF-DT.
016440     PERFORM  1100-2000-SETTLE-CVG
016440         THRU 1100-2000-SETTLE-CVG-X.
016440
016440 5150-SETTLE-CVG-EDIT-X.
016440     EXIT.

      *
      *----------------------------------------------------------------
      *  SECOND STEP OF SETTLE PROCESSING:  PERFORM SETTLE PROCESSING
      *----------------------------------------------------------------
       5200-SETTLE-2.


           PERFORM  9920-EDIT-EFF-DATE
               THRU 9920-EDIT-EFF-DATE-X.

      *    ***GET POLICY (NO UPDATE) AND ALL COVERAGES (NO UPDATE)
           PERFORM  2300-BUILD-POLICY-KEY
               THRU 2300-BUILD-POLICY-KEY-X.
      *
016440* SETTLE CHANGING FROM A BACKGROUND PROCESS TO A FOREGROUND
016440* PROCESS THEREFORE POLICY AND COVERAGE REWRITE MUST BE PERFORMED
016440* IN THE PROCESS DRIVER
      *

016440*    PERFORM  POL-1000-READ
016440*        THRU POL-1000-READ-X.
014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        MOVE 'N'                   TO WS-VALIDATE-OK-SW
014221     END-IF.

           IF NOT WPOL-IO-OK
      *        MESSAGE (S) 'POLICY RECORD LOST DURING SETTLE'
               MOVE 'NS13500007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALIDATE-OK-SW
           ELSE
               MOVE RPOL-POL-ID       TO LPGA-POLICY-NUMBER
557660     END-IF.

012148     PERFORM  8240-1000-BUILD-PARM-INFO
012148         THRU 8240-1000-BUILD-PARM-INFO-X.
012148     MOVE WPOL-POL-ID           TO L8240-POL-ID.
012148     PERFORM  8240-1000-RETRIEVE-POLW
012148         THRU 8240-1000-RETRIEVE-POLW-X.
012148
           IF NOT WS-VALIDATE-FAILED
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE 'N'               TO WS-VALIDATE-OK-SW
           END-IF.

           IF WS-VALIDATE-FAILED
013578*        MOVE SPACE             TO MIR-DV-CLI-NM
013578         MOVE SPACE             TO MIR-DV-OWN-CLI-NM
               MOVE SPACE             TO MIR-DV-POL-FUT-DT-CD
               GO TO 5200-SETTLE-2-X
557660     END-IF.

           PERFORM 0710-1000-BUILD-PARM-INFO
              THRU 0710-1000-BUILD-PARM-INFO-X.
013578*    MOVE MIR-DV-CLI-NM         TO L0710-CLI-SUR-NM-1-4.
           MOVE WS-EFF-DATE           TO L0710-EFF-DT.
           MOVE MIR-POL-ISS-DT-TYP-CD TO L0710-ISSUE-IND.
           IF MIR-DV-POL-FUT-DT-CD = 'FD'
016440     AND NOT L2222-INFORCE-POL-PEND-CVG
               SET L0710-FUTURE-DT TO TRUE
           END-IF.

016440*    PERFORM  0710-1000-POLICY-SETTLE
016440*        THRU 0710-1000-POLICY-SETTLE-X.

016440*
016440* SETTLE ALL PENDING COVERAGES ON INFORCE POLICY
016440* OR SETTLE PENDING POLICY
016440*
016440     IF L2222-INFORCE-POL-PEND-CVG
016440        PERFORM  5250-SETTLE-CVG-UPDATE
016440            THRU 5250-SETTLE-CVG-UPDATE-X
016440            VARYING WS-CVG FROM 1 BY 1
016440            UNTIL WS-CVG > RPOL-POL-CVG-REC-CTR-N
016440     ELSE
016440         PERFORM  0710-1000-POLICY-SETTLE
016440             THRU 0710-1000-POLICY-SETTLE-X
016440     END-IF


      *    *** DO NOT DISPLAY POLICY STATUS IF SETTLE IS BEING ATTEMPTED
           IF WGLOB-RETURN-CODE = ZEROS
               MOVE SPACE             TO MIR-POL-CSTAT-CD
           ELSE
               MOVE RPOL-POL-CSTAT-CD TO MIR-POL-CSTAT-CD
557660     END-IF.

016440* SETTLE PROCESSING NOW A FOREGROUND TASK

016440*    MESSAGE (I) 'POLICY SETTLE PROCESSING INITIATED'
016440*    MOVE 'NS13500034'          TO WGLOB-MSG-REF-INFO.
016440*    PERFORM  0260-1000-GENERATE-MESSAGE
016440*        THRU 0260-1000-GENERATE-MESSAGE-X.

016503* GET NEXT ACTIVITY DATE AND TYPE
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     MOVE WS-EFF-DATE             TO  L0289-LO-PAC-DT.
020467     MOVE WS-EFF-DATE             TO  L0289-LO-DD2-DT.
016503     MOVE WS-EFF-DATE             TO  L0289-LO-CRC-DT.
016503     MOVE WS-EFF-DATE             TO  L0289-PROC-EFF-DT.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

016440     PERFORM  POL-2000-REWRITE
016440         THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

016440     PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016440         THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

013578*    MOVE SPACE                 TO MIR-DV-CLI-NM.
013578*    MOVE SPACE                 TO MIR-DV-OWN-CLI-NM.
           MOVE SPACE                 TO MIR-DV-POL-FUT-DT-CD.
018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD.


       5200-SETTLE-2-X.
           EXIT.

016440*-----------------------
016440 5250-SETTLE-CVG-UPDATE.
016440*-----------------------
016440
016440     IF NOT WCVGS-CVG-STAT-PENDING (WS-CVG)
016440        GO TO 5250-SETTLE-CVG-UPDATE-X
016440     END-IF.
016440
016440     MOVE WCVGS-CVG-SEQ-NUM (WS-CVG)    TO L0710-CVG-NUM.
016440     MOVE WS-EFF-DATE                   TO L0710-CVG-ISS-EFF-DT.
016440     SET L0710-RQST-SETTLE-CVG          TO TRUE.
016440
016440     PERFORM  0710-2000-CVG-SETTLE
016440         THRU 0710-2000-CVG-SETTLE-X.
016440
016440 5250-SETTLE-CVG-UPDATE-X.
016440     EXIT.
      *
      *----------------------------------------------------------------
      *   REJECT PROCESSING:
      *----------------------------------------------------------------
       6000-PROCESS-REJECT.

           IF MIR-DV-PRCES-STATE-CD  = '3'
               PERFORM  6200-REJECT-2
                   THRU 6200-REJECT-2-X
           ELSE
               PERFORM  6100-REJECT-1
                   THRU 6100-REJECT-1-X
557660     END-IF.

       6000-PROCESS-REJECT-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   FIRST STEP OF REJECT PROCESSING: PERFORM EDITS AND DISPLAY CO
      *----------------------------------------------------------------
       6100-REJECT-1.

      *    *** REJECT SPECIFIC EDITS

           PERFORM  9900-EDIT-OWNER-NAME
               THRU 9900-EDIT-OWNER-NAME-X.

           PERFORM  9920-EDIT-EFF-DATE
               THRU 9920-EDIT-EFF-DATE-X.

           IF WS-EFF-DATE NOT = RPOL-POL-ISS-EFF-DT
      * MESSAGE (W) 'EFFECTIVE DATE NOT EQUAL POLICY EFFECTIVE DATE
      * MSG (I) 'NOT ISSUE PROCESS - EFF-DATE IGNORED POLICY
               MOVE 'NS13500010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPOL-POL-ISS-EFF-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
016440*                               TO MIR-POL-ISS-EFF-DT
016440                                TO MIR-DV-ISS-EFF-DT
557660     END-IF.

018731*    IF MIR-DV-CHQ-CREAT-IND = 'Y'
018731*    OR MIR-DV-CHQ-CREAT-IND = 'N'
018731     IF  MIR-DV-SELCT-PAYO-MTHD-CD = 'U'
018731     OR  MIR-DV-SELCT-PAYO-MTHD-CD = 'C'
018731     OR  MIR-DV-SELCT-PAYO-MTHD-CD = 'E'
034802*       NEXT SENTENCE
034802        CONTINUE
           ELSE
018731*        MESSAGE (F) 'INVALID CHEQUE REQUEST, VALID VALUES ARE ..'
018731* MESSAGE INVALID PAYOUT METHOD
               MOVE 'NS13500019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-VALIDATE-OK-SW
557660         END-IF
557660     END-IF.

           IF NOT WS-VALIDATE-FAILED
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE 'N'               TO WS-VALIDATE-OK-SW
557660     END-IF.

018731     IF  MIR-DV-SELCT-PAYO-MTHD-CD = 'C'
018731         IF  MIR-CLI-ID           NOT = SPACES
018731         OR  MIR-CLI-BNK-ACCT-NUM NOT = SPACES
018731*MSG: BANK DETAILS ARE ONLY VALID FOR EFT PAYOUT
018731             MOVE 'NS13500067'  TO WGLOB-MSG-REF-INFO
018731             PERFORM  0260-1000-GENERATE-MESSAGE
018731                 THRU 0260-1000-GENERATE-MESSAGE-X
018731             MOVE SPACES        TO  MIR-CLI-ID
018731             MOVE SPACES        TO  MIR-CLI-BNK-ACCT-NUM
018731             MOVE 'N'           TO  WS-VALIDATE-OK-SW
018731         END-IF
018731     END-IF.

           IF WS-VALIDATE-FAILED
               GO TO 6100-REJECT-1-X
557660     END-IF.

           PERFORM 6400-1000-BUILD-PARM-INFO
              THRU 6400-1000-BUILD-PARM-INFO-X.
           SET L6400-FCN-DRVR-SECONDARY  TO TRUE.
           SET L6400-PRCES-TYP-EDIT-ONLY TO TRUE.
013578*    MOVE MIR-DV-CLI-NM         TO L6400-CLI-SUR-NM-1-4.
013578*    MOVE MIR-DV-OWN-CLI-NM     TO L6400-CLI-SUR-NM-1-4.
           MOVE WS-EFF-DATE           TO L6400-EFF-DT.
           MOVE MIR-POL-REJ-REASN-CD  TO L6400-REJ-REASN-CD.
018731*    MOVE MIR-DV-CHQ-CREAT-IND  TO L6400-CHQ-IND.
018731     MOVE MIR-DV-SELCT-PAYO-MTHD-CD
018731                                TO L6400-PAYO-MTHD-CD.
018731
018731     IF  MIR-DV-SELCT-PAYO-MTHD-CD = 'E'
018731         MOVE MIR-CLI-ID            TO L6400-CLI-ID
018731         MOVE MIR-CLI-BNK-ACCT-NUM  TO L6400-CLI-BNK-ACCT-NUM
018731     END-IF.


           PERFORM 6400-1000-REJECT-POLICY
              THRU 6400-1000-REJECT-POLICY-X.


           IF L6400-RETRN-ERROR
               GO TO 6100-REJECT-1-X
           END-IF.


           PERFORM  9600-DISPLAY-COVERAGES
               THRU 9600-DISPLAY-COVERAGES-X.


      *    MESSAGE (I) 'PRESS ENTER TO CONFIRM POLICY REJECT'
           MOVE 'NS13500018'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       6100-REJECT-1-X.
           EXIT.

      *
      *----------------------------------------------------------------
      *  SECOND STEP OF REJECT PROCESSING:  PERFORM REJECT PROCESSING
      *----------------------------------------------------------------
       6200-REJECT-2.


013578     PERFORM  9900-EDIT-OWNER-NAME
013578         THRU 9900-EDIT-OWNER-NAME-X.

           PERFORM  9920-EDIT-EFF-DATE
               THRU 9920-EDIT-EFF-DATE-X.

      *    ***GET POLICY AND ALL COVERAGES
           PERFORM  2300-BUILD-POLICY-KEY
               THRU 2300-BUILD-POLICY-KEY-X.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        MOVE 'N'                   TO WS-VALIDATE-OK-SW
014221     END-IF.

           IF NOT WPOL-IO-OK
      *        MESSAGE (S) 'POLICY RECORD LOST DURING REJECT'
               MOVE 'NS13500026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALIDATE-OK-SW
           ELSE
               MOVE RPOL-POL-ID       TO LPGA-POLICY-NUMBER
557660     END-IF.

           IF NOT WS-VALIDATE-FAILED
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE 'N'               TO WS-VALIDATE-OK-SW
557660     END-IF.

           IF WS-VALIDATE-FAILED
013578*        MOVE SPACE             TO MIR-DV-CLI-NM
013578         MOVE SPACE             TO MIR-DV-OWN-CLI-NM
               MOVE SPACE             TO MIR-POL-REJ-REASN-CD
018731*        MOVE 'N'               TO MIR-DV-CHQ-CREAT-IND
018731         MOVE 'U'               TO MIR-DV-SELCT-PAYO-MTHD-CD
018731         MOVE SPACE             TO MIR-CLI-ID
018731         MOVE SPACE             TO MIR-CLI-BNK-ACCT-NUM
               GO TO 6200-REJECT-2-X
557660     END-IF.

           PERFORM 6400-1000-BUILD-PARM-INFO
              THRU 6400-1000-BUILD-PARM-INFO-X.
           SET L6400-FCN-DRVR-SECONDARY TO TRUE.
013578*    MOVE MIR-DV-CLI-NM         TO L6400-CLI-SUR-NM-1-4.
013578*    MOVE MIR-DV-OWN-CLI-NM     TO L6400-CLI-SUR-NM-1-4.
           MOVE WS-EFF-DATE           TO L6400-EFF-DT.
           MOVE MIR-POL-REJ-REASN-CD  TO L6400-REJ-REASN-CD.
018731*    MOVE MIR-DV-CHQ-CREAT-IND  TO L6400-CHQ-IND.
018731     MOVE MIR-DV-SELCT-PAYO-MTHD-CD
018731                                TO L6400-PAYO-MTHD-CD.
018731     MOVE MIR-CLI-ID            TO L6400-CLI-ID.
018731     MOVE MIR-CLI-BNK-ACCT-NUM  TO L6400-CLI-BNK-ACCT-NUM.
           PERFORM 6400-1000-REJECT-POLICY
              THRU 6400-1000-REJECT-POLICY-X.
           IF NOT L6400-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.

           MOVE RPOL-POL-ID           TO WS-HOLD-POLICY.
           MOVE RPOL-POL-CSTAT-CD     TO WS-HOLD-POLICY-STATUS.

016503* GET NEXT ACTIVITY DATE AND TYPE
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     MOVE WS-EFF-DATE             TO  L0289-LO-PAC-DT.
020467     MOVE WS-EFF-DATE             TO  L0289-LO-DD2-DT.
016503     MOVE WS-EFF-DATE             TO  L0289-LO-CRC-DT.
016503     MOVE WS-EFF-DATE             TO  L0289-PROC-EFF-DT.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM CVGR-1000-REWRITE-CVGS-ARRAY
              THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

013578*    MOVE SPACE                 TO MIR-DV-CLI-NM.
013578*    MOVE SPACE                 TO MIR-DV-OWN-CLI-NM.
           MOVE SPACE                 TO MIR-POL-REJ-REASN-CD.
018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD.
018731     MOVE SPACE                 TO MIR-CLI-ID.
018731     MOVE SPACE                 TO MIR-CLI-BNK-ACCT-NUM.

       6200-REJECT-2-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   REINSTATE PROCESSING:
      *----------------------------------------------------------------
       7000-PROCESS-REINSTATE.

           IF MIR-DV-PRCES-STATE-CD  = '3'
               PERFORM  7200-REINSTATE-2
                   THRU 7200-REINSTATE-2-X
           ELSE
               PERFORM  7100-REINSTATE-1
                   THRU 7100-REINSTATE-1-X
557660     END-IF.

       7000-PROCESS-REINSTATE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   FIRST STEP OF REINSTATE PROCESS: PERFORM EDITS AND DISPLAY CO
      *----------------------------------------------------------------
       7100-REINSTATE-1.

      *    *** REJECT SPECIFIC EDITS

           PERFORM  9900-EDIT-OWNER-NAME
               THRU 9900-EDIT-OWNER-NAME-X.

           PERFORM  9920-EDIT-EFF-DATE
               THRU 9920-EDIT-EFF-DATE-X.

           IF WS-EFF-DATE NOT = RPOL-POL-ISS-EFF-DT
      * MESSAGE (W) 'EFFECTIVE DATE NOT EQUAL POLICY EFFECTIVE DATE
      * MSG (I) 'NOT ISSUE PROCESS - EFF-DATE IGNORED POLICY
               MOVE 'NS13500010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPOL-POL-ISS-EFF-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
016440*                               TO MIR-POL-ISS-EFF-DT
016440                                TO MIR-DV-ISS-EFF-DT
557660     END-IF.

           IF WS-VALIDATE-FAILED
               GO TO 7100-REINSTATE-1-X
557660     END-IF.

           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
           PERFORM 6400-1000-BUILD-PARM-INFO
              THRU 6400-1000-BUILD-PARM-INFO-X.
           SET L6400-FCN-DRVR-SECONDARY  TO TRUE.
           SET L6400-PRCES-TYP-EDIT-ONLY TO TRUE.
013578*    MOVE MIR-DV-CLI-NM         TO L6400-CLI-SUR-NM-1-4.
013578*    MOVE MIR-DV-OWN-CLI-NM     TO L6400-CLI-SUR-NM-1-4.
           MOVE WS-EFF-DATE           TO L6400-EFF-DT.
           PERFORM 6400-3000-REINST-POLICY
              THRU 6400-3000-REINST-POLICY-X.


           IF L6400-RETRN-ERROR
               GO TO 7100-REINSTATE-1-X
           END-IF.


           PERFORM 9600-DISPLAY-COVERAGES
              THRU 9600-DISPLAY-COVERAGES-X.


      *    MESSAGE (I) 'PRESS ENTER TO CONFIRM POLICY REINSTATE'
           MOVE 'NS13500036'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       7100-REINSTATE-1-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *  SECOND STEP OF REJECT PROCESSING:  PERFORM REJECT PROCESSING
      *----------------------------------------------------------------
       7200-REINSTATE-2.


013578     PERFORM  9900-EDIT-OWNER-NAME
013578         THRU 9900-EDIT-OWNER-NAME-X.

           PERFORM  9920-EDIT-EFF-DATE
               THRU 9920-EDIT-EFF-DATE-X.

      *    ***GET POLICY AND ALL COVERAGES
           PERFORM  2300-BUILD-POLICY-KEY
               THRU 2300-BUILD-POLICY-KEY-X.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        MOVE 'N'                   TO WS-VALIDATE-OK-SW
014221     END-IF.

           IF NOT WPOL-IO-OK
      *        MESSAGE (S) 'POLICY RECORD LOST DURING REINSTATE'
               MOVE 'NS13500037'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALIDATE-OK-SW
           ELSE
               MOVE RPOL-POL-ID       TO LPGA-POLICY-NUMBER
557660     END-IF.

           IF NOT WS-VALIDATE-FAILED
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE 'N'               TO WS-VALIDATE-OK-SW
557660     END-IF.

           IF WS-VALIDATE-FAILED
013578*        MOVE SPACE             TO MIR-DV-CLI-NM
013578         MOVE SPACE             TO MIR-DV-OWN-CLI-NM
               MOVE SPACE             TO MIR-POL-REJ-REASN-CD
018731*        MOVE 'N'               TO MIR-DV-CHQ-CREAT-IND
018731         MOVE 'U'               TO MIR-DV-SELCT-PAYO-MTHD-CD
               GO TO 7200-REINSTATE-2-X
557660     END-IF.

           PERFORM 6400-1000-BUILD-PARM-INFO
              THRU 6400-1000-BUILD-PARM-INFO-X.
           SET L6400-FCN-DRVR-SECONDARY  TO TRUE.
013578*    MOVE MIR-DV-CLI-NM         TO L6400-CLI-SUR-NM-1-4.
013578*    MOVE MIR-DV-OWN-CLI-NM     TO L6400-CLI-SUR-NM-1-4.
           MOVE WS-EFF-DATE           TO L6400-EFF-DT.
           PERFORM 6400-3000-REINST-POLICY
              THRU 6400-3000-REINST-POLICY-X.
           IF NOT L6400-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.

016503* GET NEXT ACTIVITY DATE AND TYPE
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     MOVE WS-EFF-DATE             TO  L0289-LO-PAC-DT.
020467     MOVE WS-EFF-DATE             TO  L0289-LO-DD2-DT.
016503     MOVE WS-EFF-DATE             TO  L0289-LO-CRC-DT.
016503     MOVE WS-EFF-DATE             TO  L0289-PROC-EFF-DT.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM CVGR-1000-REWRITE-CVGS-ARRAY
              THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

013578*    MOVE SPACE                 TO MIR-DV-CLI-NM.
013578*    MOVE SPACE                 TO MIR-DV-OWN-CLI-NM.
           MOVE SPACE                 TO MIR-POL-REJ-REASN-CD.
018731*    MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.
018731     MOVE 'U'                   TO MIR-DV-SELCT-PAYO-MTHD-CD.


       7200-REINSTATE-2-X.
           EXIT.
      *
      *
      *----------------------------------------------------------------
      *   SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS
      *   WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *----------------------------------------------------------------
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE            TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   DISPLAY A SCREEN OF COVERAGES
      *----------------------------------------------------------------
       9600-DISPLAY-COVERAGES.

           IF RPOL-POL-CVG-REC-CTR-N = ZERO
               MOVE 8                 TO WCVG-IO-STATUS
      *        MESSAGE (I) 'NO COVERAGES TO DISPLAY'
               MOVE 'XS00000095'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 9600-DISPLAY-COVERAGES-X
557660     END-IF.

           PERFORM  9610-DISPLAY-SCREEN-FORWARD
               THRU 9610-DISPLAY-SCREEN-FORWARD-X.

       9600-DISPLAY-COVERAGES-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   DISPLAY COVERAGES FORWARD, STARTING AT FIRST COVERAGE
      *----------------------------------------------------------------
       9610-DISPLAY-SCREEN-FORWARD.

           MOVE MIR-POL-ID-BASE            TO WCVG-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO WCVG-POL-ID-SFX.
           MOVE '01'                  TO WCVG-CVG-NUM.

           MOVE WCVG-KEY              TO WCVG-ENDBR-KEY.
           MOVE RPOL-POL-CVG-REC-CTR  TO WCVG-ENDBR-CVG-NUM.

           PERFORM  CVG-1000-BROWSE
               THRU CVG-1000-BROWSE-X.

           IF NOT WCVG-IO-OK
               MOVE '1'               TO WGLOB-MSG-ERROR-SW
      *        MESSAGE (S) 'POLICY/COVERAGE FILES ARE OUT OF SYNC-CALL S
               MOVE 'XS00000084'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 9610-DISPLAY-SCREEN-FORWARD-X
557660     END-IF.


           PERFORM  CVG-2000-READ-NEXT
               THRU CVG-2000-READ-NEXT-X.

           IF WCVG-IO-EOF
               MOVE '1'               TO WGLOB-MSG-ERROR-SW
      *        MESSAGE (S) 'POLICY/COVERAGE FILES ARE OUT OF SYNC-CALL S
               MOVE 'XS00000084'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  CVG-3000-END-BROWSE
                   THRU CVG-3000-END-BROWSE-X
               GO TO 9610-DISPLAY-SCREEN-FORWARD-X
557660     END-IF.

           MOVE +1                    TO I.
           MOVE 'N'                   TO WS-STOP-DISPLAY-SW.

           PERFORM  9611-DISPLAY-CVG-FORWARD
               THRU 9611-DISPLAY-CVG-FORWARD-X
               UNTIL I > WS-MAX-LINES-PER-SCREEN
                 OR   WS-STOP-DISPLAY
                 OR   WCVG-IO-EOF.

           PERFORM  CVG-3000-END-BROWSE
               THRU CVG-3000-END-BROWSE-X.

       9610-DISPLAY-SCREEN-FORWARD-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   DISPLAY A COVERAGE AND READ THE NEXT COVERAGE
      *----------------------------------------------------------------
       9611-DISPLAY-CVG-FORWARD.

      *    *** ONLY DISPLAY COVERAGE IF CAN FIT ON ALL INSUREDS
557767*    IF RCVG-CVG-LIVES-INSRD-CD-N  > ZERO
025388*    IF RCVG-CVG-LIVES-INSRD-CD  > ZERO
025388     IF RCVG-LIVES-INSRD-QTY > ZERO
557767*        IF I + RCVG-CVG-LIVES-INSRD-CD-N  - 1 >
025388*        IF I + RCVG-CVG-LIVES-INSRD-CD  - 1 >
025388         IF I + RCVG-LIVES-INSRD-QTY  - 1 >
                      WS-MAX-LINES-PER-SCREEN
                   MOVE 'Y'           TO WS-STOP-DISPLAY-SW
                   GO TO 9611-DISPLAY-CVG-FORWARD-X
557660         END-IF
557660     END-IF.

           PERFORM  9700-DISPLAY-COVERAGE
               THRU 9700-DISPLAY-COVERAGE-X.

           PERFORM  CVG-2000-READ-NEXT
               THRU CVG-2000-READ-NEXT-X.

       9611-DISPLAY-CVG-FORWARD-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   MOVE COVERAGE RECORD TO THE SCREEN
      *----------------------------------------------------------------
       9700-DISPLAY-COVERAGE.

           MOVE RCVG-CVG-NUM          TO MIR-CVG-NUM-T (I).
           MOVE RCVG-CVG-UWGDECN-CD   TO MIR-CVG-UWGDECN-CD-T (I).
           MOVE RCVG-CVG-UWGDECN-SUB-CD
                                      TO MIR-CVG-UWGDECN-SUB-CD-T (I).
           MOVE RCVG-CVG-CSTAT-CD     TO MIR-CVG-CSTAT-CD-T (I).

557767*    IF RCVG-CVG-LIVES-INSRD-CD-N  > ZERO
025388*    IF RCVG-CVG-LIVES-INSRD-CD    > ZERO
025388     IF RCVG-LIVES-INSRD-QTY   > ZERO
               MOVE  LOW-VALUES       TO WCVGC-KEY
               MOVE RPOL-POL-ID       TO WCVGC-POL-ID
               MOVE RCVG-CVG-NUM      TO WCVGC-CVG-NUM
               MOVE WCVGC-KEY         TO WCVGC-ENDBR-KEY
               MOVE HIGH-VALUES       TO WCVGC-ENDBR-CVG-CLI-REL-TYP-CD
               MOVE HIGH-VALUES       TO WCVGC-ENDBR-INSRD-CLI-ID
               PERFORM  CVGC-1000-BROWSE
                   THRU CVGC-1000-BROWSE-X
               IF WCVGC-IO-OK
                   PERFORM  CVGC-2000-READ-NEXT
                       THRU CVGC-2000-READ-NEXT-X
                   PERFORM  9710-DISPLAY-INSURED
                       THRU 9710-DISPLAY-INSURED-X
                      UNTIL WCVGC-IO-EOF
                      OR I > WS-MAX-LINES-PER-SCREEN
                   PERFORM  CVGC-3000-END-BROWSE
                       THRU CVGC-3000-END-BROWSE-X
               ELSE
                   COMPUTE I = I + 1
557660         END-IF
           ELSE
               COMPUTE I = I + 1
557660     END-IF.

       9700-DISPLAY-COVERAGE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   DISPLAY EACH INSURED ON THE COVERAGE ON A NEW LINE
      *----------------------------------------------------------------
       9710-DISPLAY-INSURED.

           MOVE RCVGC-INSRD-CLI-ID    TO MIR-INSRD-CLI-ID-T (I).

           PERFORM 5600-1000-BUILD-PARM-INFO
              THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE RCVGC-INSRD-CLI-ID    TO L5600-CLI-ID.
           PERFORM 5600-1000-CLI-CHK
              THRU 5600-1000-CLI-CHK-X.
           IF L5600-RETRN-CLI-NOT-FOUND
           OR L5600-CNFD-ACCS-RESTRICTED
               COMPUTE I = I + 1
               PERFORM  CVGC-2000-READ-NEXT
                   THRU CVGC-2000-READ-NEXT-X
               GO TO 9710-DISPLAY-INSURED-X
           END-IF.

           MOVE RCVGC-INSRD-CLI-ID    TO L2437-CLI-ID.
           PERFORM 2437-1000-OBTAIN-CLI-INFO
              THRU 2437-1000-OBTAIN-CLI-INFO-X.
           IF L2437-RETRN-OK
557698*        MOVE L2437-CLI-SUR-NM         TO MIR-CLI-SUR-NM-T (I)
557698         MOVE L2437-CLI-ENTR-SUR-NM
015904*                               TO MIR-CLI-SUR-NM-T (I)
015904                                TO MIR-CLI-INDV-SUR-NM-T (I)
               MOVE L2437-CLI-UWGDECN-CD
                                      TO MIR-CLI-UWGDECN-CD-T (I)
               MOVE L2437-CLI-UWGDECN-TYP-CD
                                      TO MIR-CLI-UWGDECN-TYP-CD-T (I)
           END-IF.

           COMPUTE I = I + 1.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       9710-DISPLAY-INSURED-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   EDIT FIRST FOUR CHARS OF OWNER NAME
      *----------------------------------------------------------------
       9900-EDIT-OWNER-NAME.

013578*    PERFORM 2430-1000-BUILD-PARM-INFO
013578*       THRU 2430-1000-BUILD-PARM-INFO-X.
013578*    MOVE MIR-DV-OWN-CLI-NM         TO L2430-OWNER-NAME-1-4.
013578*    PERFORM  2430-5000-VALIDATE-OWNER-NM
013578*        THRU 2430-5000-VALIDATE-OWNER-NM-X.
013578*
013578*    IF L2430-RETRN-OWNER-NM-MISMATCH
013578* MSG: FIRST FOUR CHARS OF PRIMARY OWNER NAME INCORRECT
013578*        MOVE 'NS13500015'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        IF WGLOB-MSG-SEVRTY-FATAL
013578*            MOVE 'N'           TO WS-VALIDATE-OK-SW
013578*        END-IF
013578*    END-IF.

013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE RPOL-POL-ID                   TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.

       9900-EDIT-OWNER-NAME-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   EDIT EFFECTIVE DATE OF TRANSACTION
      *----------------------------------------------------------------
       9920-EDIT-EFF-DATE.

016440*    MOVE MIR-POL-ISS-EFF-DT    TO L1640-EXTERNAL-DATE.
016440     MOVE MIR-DV-ISS-EFF-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
      *        MESSAGE (S) 'INVALID EFFECTIVE DATE (@1) - FORMAT MUST
      *                     BE DDMMMYYYY'
016440*        MOVE MIR-POL-ISS-EFF-DT             TO WGLOB-MSG-PARM (1)
016440         MOVE MIR-DV-ISS-EFF-DT              TO WGLOB-MSG-PARM (1)
               MOVE 'NS13500017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALIDATE-OK-SW
026057         GO TO 9920-EDIT-EFF-DATE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WS-EFF-DATE
557660     END-IF.

026057     MOVE L1640-INTERNAL-DATE      TO WIHSD-EFF-DT.
026057     PERFORM  2400-EDIT-INV-HIST-STRT-DT
026057         THRU 2400-EDIT-INV-HIST-STRT-DT-X.

       9920-EDIT-EFF-DATE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0700-0000-INIT-PARM-INFO
025970         THRU 0700-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0710-0000-INIT-PARM-INFO
025970         THRU 0710-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1100-0000-INIT-PARM-INFO
025970         THRU 1100-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2222-0000-INIT-PARM-INFO
025970         THRU 2222-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6400-0000-INIT-PARM-INFO
025970         THRU 6400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8240-0000-INIT-PARM-INFO
025970         THRU 8240-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-MAX-NUM-OF-CLIENTS  TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970     MOVE SPACES                       TO WWKDT-WORK-FIELDS.
027105
027105     COMPUTE WS-MAX-LINES-PER-SCREEN
027105           = LENGTH OF MIR-CVG-NUM-G
027105           / LENGTH OF MIR-CVG-NUM-T (1).
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPSPGA.
       COPY CCPS1100.
       COPY CCPS2430.
       COPY CCPS5400.
       COPY CCPS5600.
       COPY CCPS6400.
       COPY NCPPCVGR.
       COPY NCPPCVGS.
       COPY NCPS0700.
       COPY NCPS0710.
018764*COPY XCCL8090.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL8090.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
025970 COPY XCPS1640.
       COPY XCPL1640.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
      ****************************************************************
      * LINK COPYBOOKS                                               *
      ****************************************************************
025970 COPY CCPS0620.
013578 COPY CCPL0620.
      *
018764*COPY CCCL1100.
018764 COPY CCPL1100.
      *
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      *
018764*COPY CCCL6400.
018764 COPY CCPL6400.
      *
018764*COPY CCCL2222.
018764 COPY CCPL2222.
016440 COPY CCPS2222.
      *
018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS0289.
012148*
018764*COPY CCCL8240.
018764 COPY CCPL8240.
012148 COPY CCPS8240.
      *
018764*COPY NCCL0700.
018764 COPY NCPL0700.
      *
018764*COPY NCCL0710.
018764 COPY NCPL0710.
      *
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      *
      *
      ****************************************************************
      * MESSAGE COPYBOOKS                                            *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPBCVG.
       COPY CCPNCVG.
       COPY CCPUCVG.
      *
       COPY CCPBCVGC.
      *
       COPY CCPNPOL.
       COPY CCPUPOL.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM1350                     **
      *****************************************************************
