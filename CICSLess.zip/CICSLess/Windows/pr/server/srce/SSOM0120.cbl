      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM0120.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM0120                                         **
      **  REMARKS:  FHDR: MAINTAIN FUND HEADER TABLE.                **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE FUND HEADER TABLE.             **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
557756**  5.5       ENHANCEMENTS FOR MULTI-LANGUAGE SUPPORT          **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010314**  5.6       NEW FIELD TO FH TABLE/FHDR SCREEN                **
012146**  5.6V      CHANGING FROM FND-UNIT-TYP-QTY                   **
012146**            TO FND-UNIT-TYP-CD                               **
012624**  6.0       SECURITY                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017261**  6.2       ADD CURRENT STATUS DERIVED FIELD & RELATED CODE  **
016016**  6.3       FUND BONUS (6.1.1E)                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
017364**  6.4       REMOVE VERSION COUNTERS FROM SEGFUND TABLES      **
021239**  6.4       FUND UNIT VALUE                                  **
020452**  6.4       FOREIGN CONTENT FOR RRSP PRODUCTS                **
023309**  6.5       LOCK CONTENTION ON FH TABLE                      **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026545**  6.6       MISSING MESSAGES IN THE TMSGS                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0120'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.


       COPY SQLCA.
018764*COPY XCWLPTR.
014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'FHDR'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1820' THRU '1823'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1820'.
               88  WS-BUS-FCN-CREATE        VALUE '1821'.
               88  WS-BUS-FCN-UPDATE        VALUE '1822'.
               88  WS-BUS-FCN-DELETE        VALUE '1823'.
               88  WS-BUS-FCN-LIST          VALUE '1824'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1820'.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.
               88  WS-DATA-EDITS-FAILED     VALUE 'N'.
           05  WS-CROSS-EDITS               PIC X(01).
               88  WS-CROSS-EDITS-OK        VALUE 'Y'.
               88  WS-CROSS-EDITS-FAILED    VALUE 'N'.
           05  WS-FV-SW                     PIC 9.
               88  WS-NO-FV-RECORDS         VALUE 0.
               88  WS-FV-RECORDS-FOUND      VALUE 1.
           05  WS-CREATE-DATE-CHANGED-IND   PIC X.
               88  WS-CREATE-DATE-CHANGED   VALUE 'Y'.
025970*    05  WS-OK                        PIC X(01)  VALUE 'Y'.
025970*    05  WS-FAILED                    PIC X(01)  VALUE 'N'.
           05  WS-OUT-NUMBER-1              PIC 9.
           05  WS-OUT-9-9999                PIC 9.9999.
           05  WS-OUT-99                    PIC 99.
           05  WS-OUT-999                   PIC 999.
016548*    05  WS-MAX-LIST-LINES            PIC S9(04) COMP
025970*    05  WS-MAX-LIST-LINES            PIC S9(04) BINARY
025970*                                     VALUE +100.
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
008455*    05  WS-OUT-FMT-11-7.
008455*        10  WS-OUT-FMT-11            PIC 9(11).
008455*        10  FILLER                   PIC X(01)  VALUE '.'.
008455*        10  WS-OUT-FMT-V7            PIC V9(7).
008455*    05  WS-OUT-FMT-7-9.
008455*        10  WS-OUT-FMT-7             PIC 9(07).
008455*        10  FILLER                   PIC X(01)  VALUE '.'.
008455*        10  WS-OUT-FMT-V9            PIC V9(9).
           05  WS-OUT-NUM-18                PIC 9(18).
008455*    05  FILLER                       REDEFINES
008455*        WS-OUT-NUM-18.
008455*        10  FILLER                   PIC 9(02).
008455*        10  WS-OUT-NUM-7             PIC 9(07).
008455*        10  WS-OUT-NUM-V9            PIC V9(9).
           05  FILLER                       REDEFINES
               WS-OUT-NUM-18.
               10  FILLER                   PIC 9(13).
               10  WS-OUT-NUM-1V4           PIC 9V9(4).
017261     05  WS-DV-FND-CRNT-STAT-CD       PIC X(01).
017261         88  WS-DV-FND-CRNT-STAT-2B-CREATED      VALUE '1'.
017261         88  WS-DV-FND-CRNT-STAT-2B-OPENED       VALUE '2'.
017261         88  WS-DV-FND-CRNT-STAT-CLOSED          VALUE '3'.
017261         88  WS-DV-FND-CRNT-STAT-CLOSED-4NB      VALUE '4'.
017261         88  WS-DV-FND-CRNT-STAT-OPEN            VALUE '5'.
           05  WS-ETAB-NAME-ACCESS.
557756*        10  WS-ETAB-LANG             PIC X(01).
557756*        10  WS-ETAB-LANG-NUM REDEFINES WS-ETAB-LANG PIC 9(01).
               10  WS-ETAB-FUND             PIC X(05).
023309     05  WS-FND-PREV-VALN-DT          PIC X(10).
      *
      *    EDIT VALUES
      *
           05  WS-TEST-STATUS               PIC X(01).
               88  WS-STATUS-OK             VALUE 'O' 'N' 'C'.
               88  WS-STATUS-OPEN           VALUE 'O'.
               88  WS-STATUS-CLOSED-NB      VALUE 'N'.
               88  WS-STATUS-CLOSED         VALUE 'C'.
021239*    05  WS-TEST-FTYPE                PIC X(01).
021239*        88  WS-VALID-FTYPE           VALUE 'F' 'I'.
021239*    05  WS-TEST-GENERAL-VAL-DIR      PIC X(01).
021239*        88  WS-GENERAL-VAL-DIR-OK    VALUE 'F' 'B'.
021239*    05  WS-TEST-NUM-OF-UNIT-TYPES    PIC X(01).
021239*        88  WS-NUM-OF-UNIT-TYPES-OK  VALUE '1' '2'.
021239*    05  WS-TEST-PRICING-STRUCTURE    PIC X(01).
021239*        88  WS-PRICING-STRUCTURE-OK  VALUE 'D' 'S'.
021239*    05  WS-TEST-UNIT-ROUNDING        PIC X(01).
021239*        88  WS-UNIT-ROUNDING-OK      VALUE 'D' 'U' 'N'.
           05  WS-TEST-GAIN-LOSS-IND        PIC X(01).
               88  WS-GAIN-LOSS-IND-OK      VALUE 'N' 'F' 'G'
                                                  'D' 'P' 'S'.
               88  WS-GAIN-LOSS-ZERO        VALUE 'N' 'F' 'G'.
               88  WS-GAIN-LOSS-NON-ZERO    VALUE 'D' 'P' 'S'.
           05  WS-TEST-GAIN-LOSS-CALC-REV   PIC X(01).
               88  WS-GAIN-LOSS-CALC-REV-OK VALUE 'U' 'R'.
           05  WS-TEST-UNIT-ACCURACY        PIC X(01).
           05  WS-TEST-UNIT-ACCURACY-N      REDEFINES
               WS-TEST-UNIT-ACCURACY        PIC 9(01).
           05  WS-TEST-PRICE-ACCURACY       PIC X(01).
           05  WS-TEST-PRICE-ACCURACY-N     REDEFINES
               WS-TEST-PRICE-ACCURACY       PIC 9(01).
016016     05  WS-TEST-BONUS-CALC-CD        PIC X(01).
018763*        88  WS-BONUS-CALC-CD-OK      VALUES '1' '2' ' '.
018763         88  WS-BONUS-CALC-CD-OK      VALUES '1' '2' 'N'.

025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT    VALUE 'FHDR'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1820'.
025970     05  WS-OK                        PIC X(01).
025970         88  WS-OK-DEFAULT            VALUE 'Y'.
025970     05  WS-FAILED                    PIC X(01).
025970         88  WS-FAILED-DEFAULT        VALUE 'N'.
025970     05  WS-MAX-LIST-LINES            PIC S9(04) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT    VALUE +100.
      *
014221 COPY CCWWLOCK.
       COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
008455/
014221 COPY XCWL8090.
014221/
021239 COPY XCWL8960.
021239
       COPY XCWL1640.
       COPY XCWLDTLK.
008455/
008455 COPY XCFWCRCY.
008455 COPY XCFRCRCY.
      /
023309 COPY SCFWFDUP.
023309 COPY SCFRFDUT.
023309
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
020452 COPY XCFWCTRY.
020452 COPY XCFRCTRY.
      /
       COPY SCFWFH.
       COPY SCFRFH.
      /
021239*COPY SCFWFV.
021239 COPY SCFWFVAA.
       COPY SCFRFV.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0120.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      ***************
       0000-MAINLINE.
      ***************
      *
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
      *
           PERFORM  2000-PROCESS-TRANSACTIONS
               THRU 2000-PROCESS-TRANSACTIONS-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
      *
026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.
      *
       0000-MAINLINE-X.
           EXIT.
      /
      ***************************
       2000-PROCESS-TRANSACTIONS.
      ***************************
      *
008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

021239     PERFORM  8960-1000-BUILD-PARM-INFO
021239         THRU 8960-1000-BUILD-PARM-INFO-X.
021239
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST
                                      TO TRUE

           END-EVALUATE.

       2000-PROCESS-TRANSACTIONS-X.
           EXIT.
      /
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      *
           PERFORM  7100-BUILD-FHDR-KEY
               THRU 7100-BUILD-FHDR-KEY-X.
      *
      *    READ RECORD.
      *
014221*    PERFORM  FH-1000-READ
014221*        THRU FH-1000-READ-X.
014221     PERFORM  FH-1000-READ-TWRK-TS
014221         THRU FH-1000-READ-TWRK-TS-X.
      *
           IF WFH-IO-OK
              PERFORM  9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE WFH-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
557660     END-IF.
      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       3500-PROCESS-LIST.
      *--------------------

           PERFORM  9000-BLANK-LIST-FIELDS
               THRU 9000-BLANK-LIST-FIELDS-X.

           PERFORM  7000-BUILD-LIST-KEYS
               THRU 7000-BUILD-LIST-KEYS-X.

           PERFORM  FH-1000-BROWSE
               THRU FH-1000-BROWSE-X.

           PERFORM  FH-2000-READ-NEXT
               THRU FH-2000-READ-NEXT-X.

           IF  WFH-IO-EOF
               PERFORM  FH-3000-END-BROWSE
                   THRU FH-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  3510-BROWSE-FH
               THRU 3510-BROWSE-FH-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB >  WS-MAX-LIST-LINES
               OR      WFH-IO-EOF.

           IF  WFH-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                                      TO TRUE
               MOVE RFH-FND-ID        TO MIR-FND-ID
           END-IF.

           PERFORM  FH-3000-END-BROWSE
               THRU FH-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-----------------
       3510-BROWSE-FH.
      *-----------------

           PERFORM  9930-MOVE-RECORD-TO-LIST
               THRU 9930-MOVE-RECORD-TO-LIST-X.

           PERFORM  FH-2000-READ-NEXT
               THRU FH-2000-READ-NEXT-X.

       3510-BROWSE-FH-X.
           EXIT.

      /
      *********************
       4000-PROCESS-CREATE.
      *********************
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      *    VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
      *
           PERFORM  7500-EDIT-KEY-FIELDS
               THRU 7500-EDIT-KEY-FIELDS-X.
           IF WS-DATA-EDITS-FAILED
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      *    BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-FHDR-KEY
               THRU 7100-BUILD-FHDR-KEY-X.

           PERFORM  FH-1000-READ
               THRU FH-1000-READ-X.

           IF WFH-IO-OK
      *MSG: 'RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WFH-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      *    CREATE NEW RECORD.
      *
           PERFORM  FH-1000-CREATE
               THRU FH-1000-CREATE-X.
021239*    PERFORM  9900-DEFAULT-FH-VALUES
021239*        THRU 9900-DEFAULT-FH-VALUES-X.
021239     MOVE WGLOB-PROCESS-DATE    TO RFH-FND-CREAT-DT.
021239     MOVE WGLOB-PROCESS-DATE    TO RFH-FND-NXT-VALN-DT.
      *
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *
      *    CREATE FUND HEADER RECORD
      *
           PERFORM  FH-1000-WRITE
               THRU FH-1000-WRITE-X.
      *
      *MSG: 'RECORD CREATED - CONTINUE'
      *
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

014221     PERFORM  FH-1000-READ-TWRK-TS
014221         THRU FH-1000-READ-TWRK-TS-X.
      *
       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *********************
       5000-PROCESS-UPDATE.
      *********************

           MOVE MIR-FND-ID            TO WS-ETAB-FUND.
557756*    MOVE WGLOB-LANG-SUB      TO WS-ETAB-LANG-NUM.
           MOVE WS-ETAB-FUND          TO WEDIT-ETBL-VALU-ID.
           PERFORM  SGFD-1000-EDIT
              THRU  SGFD-1000-EDIT-X.
      *
           IF WEDIT-IO-NOT-FOUND
      *MSG: 'FUND NOT ON ETAB'
               MOVE 'SS01200008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   GO TO 5000-PROCESS-UPDATE-X
557660         END-IF
557660     END-IF.

           PERFORM  7100-BUILD-FHDR-KEY
               THRU 7100-BUILD-FHDR-KEY-X.

014221*    PERFORM  FH-1000-READ-FOR-UPDATE
014221*        THRU FH-1000-READ-FOR-UPDATE-X.
014221     PERFORM FH-2000-UPDATE-TWRK-TS
014221        THRU FH-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'FH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WFH-FND-ID         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF WFH-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WFH-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  7300-DATA-EDITS
               THRU 7300-DATA-EDITS-X.
      *
           PERFORM  7400-CROSS-EDITS
               THRU 7400-CROSS-EDITS-X.

021239     IF WS-DATA-EDITS-FAILED
021239     OR WS-CROSS-EDITS-FAILED
021239         GO TO 5000-PROCESS-UPDATE-X
021239     END-IF.

      *
      *    REWRITE FUND HEADER RECORD
      *
           PERFORM  FH-2000-REWRITE
               THRU FH-2000-REWRITE-X.

014221     PERFORM  FH-1000-READ-TWRK-TS
014221         THRU FH-1000-READ-TWRK-TS-X.

017261     PERFORM  9800-GET-CURRENT-STATUS
017261         THRU 9800-GET-CURRENT-STATUS-X.

           IF WS-DATA-EDITS-OK
           AND WS-CROSS-EDITS-OK
      *MSG: MAINTENANCE COMPLETED - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG: RECORD UPDATED
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
557660     END-IF.
      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *********************
       6000-PROCESS-DELETE.
      *********************
      *
           PERFORM  7100-BUILD-FHDR-KEY
               THRU 7100-BUILD-FHDR-KEY-X.

           PERFORM  FH-1000-READ
               THRU FH-1000-READ-X.

           IF WFH-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WFH-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
557660     END-IF.
      *
      *    CHECK IF FUND IS ACTIVE
      *
023309*    IF RFH-FND-PREV-VALN-DT NOT = WWKDT-ZERO-DT
023309     IF  WS-FND-PREV-VALN-DT NOT = WWKDT-ZERO-DT
      *MSG: FUND IS ACTIVE - HEADER RECORD CANNOT BE DELETED
               MOVE 'SS01200005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
557660     END-IF.
      *
      *    DO NOT DELETE IF THERE ARE ANY FV RECORDS FOR THIS FUND.
      *
           PERFORM  6110-CHECK-FV-FILE
               THRU 6110-CHECK-FV-FILE-X.
      *
           IF WS-FV-RECORDS-FOUND
      *MSG: MUST DELETE UNIT PRICES BEFORE DELETING FUND
               MOVE 'SS01200007'      TO WGLOB-MSG-REF-INFO
               MOVE WFH-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
557660     END-IF.

           PERFORM  7100-BUILD-FHDR-KEY
               THRU 7100-BUILD-FHDR-KEY-X.

014221*    PERFORM  FH-1000-READ-FOR-UPDATE
014221*        THRU FH-1000-READ-FOR-UPDATE-X
014221     PERFORM FH-2000-UPDATE-TWRK-TS
014221        THRU FH-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'FH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WFH-FND-ID         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WFH-IO-NOT-FOUND
      *MSG: RECORD (@1) LOST IN DELETE - CONTACT SYSTEMS
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WFH-KEY           TO WGLOB-MSG-PARM (1)
           ELSE
      *MSG: DELETE COMPLETED - CONTINUE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  FH-1000-DELETE
                   THRU FH-1000-DELETE-X
557660     END-IF.
      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      *
      ********************
       6110-CHECK-FV-FILE.
      ********************

021239*    MOVE ZERO                  TO WS-FV-SW.
021239*    MOVE ZEROES                TO WFV-FNDVL-IDT-NUM-N.
021239*    MOVE MIR-FND-ID            TO WFV-FND-ID.
021239*    MOVE WFV-KEY               TO WFV-ENDBR-KEY.
021239*    MOVE HIGH-VALUES           TO WFV-ENDBR-FNDVL-IDT-NUM.
021239*    PERFORM  FV-1000-BROWSE
021239*        THRU FV-1000-BROWSE-X.
021239*    IF WFV-IO-EOF
021239*        NOTHING IN THE FILE WITH THIS KEY OR GREATER
021239*        NEXT SENTENCE
021239*    ELSE
021239*        PERFORM  FV-2000-READ-NEXT
021239*            THRU FV-2000-READ-NEXT-X
021239*        IF NOT WFV-IO-OK
021239*            NOTHING IN THE FILE WITH THIS KEY
021239*            PERFORM  FV-3000-END-BROWSE
021239*                THRU FV-3000-END-BROWSE-X
021239*        ELSE
021239*                THERE IS SOMETHING IN THE FILE WITH THIS KEY
021239*            MOVE 1             TO WS-FV-SW
021239*            PERFORM  FV-3000-END-BROWSE
021239*                THRU FV-3000-END-BROWSE-X
021239*        END-IF
021239*    END-IF.
021239
021239     SET WS-NO-FV-RECORDS        TO TRUE.
021239
021239     MOVE LOW-VALUES             TO WFVAA-KEY.
021239
021239     MOVE MIR-FND-ID             TO WFVAA-FND-ID.
021239     MOVE ZEROES                 TO WFVAA-FNDVL-IDT-NUM-N.
021239
021239     MOVE WFVAA-KEY              TO WFVAA-ENDBR-KEY.
021239     MOVE HIGH-VALUES            TO WFVAA-ENDBR-FNDVL-IDT-NUM.
021239     MOVE HIGH-VALUES            TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.
021239
021239     PERFORM  FVAA-1000-BROWSE
021239         THRU FVAA-1000-BROWSE-X.
021239
021239     PERFORM  FVAA-2000-READ-NEXT
021239         THRU FVAA-2000-READ-NEXT-X.
021239
021239     IF  WFVAA-IO-OK
021239         SET WS-FV-RECORDS-FOUND TO TRUE
021239     END-IF.
021239
021239     PERFORM  FVAA-3000-END-BROWSE
021239         THRU FVAA-3000-END-BROWSE-X.
021239
       6110-CHECK-FV-FILE-X.
           EXIT.
      *
      *----------------
       7000-BUILD-LIST-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WFH-KEY.
           MOVE MIR-FND-ID             TO WFH-FND-ID.

           MOVE WFH-KEY                TO WFH-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WFH-ENDBR-FND-ID.

       7000-BUILD-LIST-KEYS-X.
           EXIT.

      /

      *****************************************************************
      *  BUILD FHDR KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       7100-BUILD-FHDR-KEY.
      *********************
      *
           MOVE MIR-FND-ID            TO WFH-FND-ID.
      *
       7100-BUILD-FHDR-KEY-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       7300-DATA-EDITS.
      *****************
      *
           MOVE WS-OK                 TO WS-DATA-EDITS.
      *
           PERFORM  7310-EDIT-FUND-COMPANY
               THRU 7310-EDIT-FUND-COMPANY-X.
           PERFORM  7311-EDIT-FUND-STATUS
               THRU 7311-EDIT-FUND-STATUS-X.
           PERFORM  7312-EDIT-CREATION-DATE
               THRU 7312-EDIT-CREATION-DATE-X.
           PERFORM  7313-EDIT-NB-CLOSE-DATE
               THRU 7313-EDIT-NB-CLOSE-DATE-X.
           PERFORM  7314-EDIT-CLOSE-DATE
               THRU 7314-EDIT-CLOSE-DATE-X.
           PERFORM  7315-EDIT-GEN-VAL-DIR
               THRU 7315-EDIT-GEN-VAL-DIR-X.
           PERFORM  6110-CHECK-FV-FILE
               THRU 6110-CHECK-FV-FILE-X.
021239*    PERFORM  7316-EDIT-NUM-UNIT-TYPES
021239*        THRU 7316-EDIT-NUM-UNIT-TYPES-X.
           PERFORM  7317-EDIT-PRICING-STRUCT
               THRU 7317-EDIT-PRICING-STRUCT-X.
           PERFORM  7318-EDIT-UNIT-ACCURACY
               THRU 7318-EDIT-UNIT-ACCURACY-X.
           PERFORM  7319-EDIT-UNIT-ROUNDING
               THRU 7319-EDIT-UNIT-ROUNDING-X.
           PERFORM  7320-EDIT-PRICE-ACCURACY
               THRU 7320-EDIT-PRICE-ACCURACY-X.
           PERFORM  7321-EDIT-MIN-VAL-MONTHS
               THRU 7321-EDIT-MIN-VAL-MONTHS-X.
           PERFORM  7322-EDIT-MIN-VAL-DAYS
               THRU 7322-EDIT-MIN-VAL-DAYS-X.
           PERFORM  7323-EDIT-MAX-VAL-MONTHS
               THRU 7323-EDIT-MAX-VAL-MONTHS-X.
           PERFORM  7324-EDIT-MAX-VAL-DAYS
               THRU 7324-EDIT-MAX-VAL-DAYS-X.
           PERFORM  7330-EDIT-LAST-SEED-DATE
               THRU 7330-EDIT-LAST-SEED-DATE-X.
           PERFORM  7331-EDIT-UNITS-FROM-SEED
               THRU 7331-EDIT-UNITS-FROM-SEED-X.
           PERFORM  7332-EDIT-GAIN-LOSS-IND
               THRU 7332-EDIT-GAIN-LOSS-IND-X.
           PERFORM  7333-EDIT-GAIN-LOSS-NUM
               THRU 7333-EDIT-GAIN-LOSS-NUM-X.
           PERFORM  7334-EDIT-GAIN-LOSS-REV
               THRU 7334-EDIT-GAIN-LOSS-REV-X.
           PERFORM  7335-EDIT-MANAGEMENT-CHARGE
               THRU 7335-EDIT-MANAGEMENT-CHARGE-X.
           PERFORM  7336-EDIT-EXP-PRICE-GROWTH
               THRU 7336-EDIT-EXP-PRICE-GROWTH-X.
010314     PERFORM  7337-EDIT-FUND-TYPE
010314         THRU 7337-EDIT-FUND-TYPE-X.
016016     PERFORM  7338-EDIT-RATE-HEADER-ID
016016         THRU 7338-EDIT-RATE-HEADER-ID-X.
016016     PERFORM  7339-EDIT-BONUS-CALC-CD
016016         THRU 7339-EDIT-BONUS-CALC-CD-X.
020452     PERFORM  7340-EDIT-ORIG-FND-CTRY-CD
020452         THRU 7340-EDIT-ORIG-FND-CTRY-CD-X.

      *
       7300-DATA-EDITS-X.
           EXIT.
      /
      ************************
       7310-EDIT-FUND-COMPANY.
      ************************
      *
           IF MIR-FND-CRCY-CD = SPACES
               MOVE RFH-FND-CRCY-CD   TO MIR-FND-CRCY-CD
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-CRCY-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-CRCY-CD
557660     END-IF.
      *
008455*    MOVE MIR-FND-CRCY-CD           TO WEDIT-ETBL-VALU-ID.
      *
008455*    PERFORM  CURR-1000-EDIT-CURRENCY
008455*        THRU CURR-1000-EDIT-CURRENCY-X.
      *
008455     MOVE WGLOB-COMPANY-CODE    TO WCRCY-CO-ID.
008455     MOVE MIR-FND-CRCY-CD       TO WCRCY-CRCY-CD.
008455     PERFORM  CRCY-1000-READ
008455         THRU CRCY-1000-READ-X.

008455*    IF WEDIT-IO-OK
008455     IF WCRCY-IO-OK
               MOVE MIR-FND-CRCY-CD   TO RFH-FND-CRCY-CD
           ELSE
      *MSG: CURRENCY CODE MUST BE IN CRCY TABLE
               MOVE 'SS01200020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7310-EDIT-FUND-COMPANY-X.
           EXIT.
      /
      ***********************
       7311-EDIT-FUND-STATUS.
      ***********************
      *
           IF MIR-FND-STAT-CD = SPACES
               MOVE RFH-FND-STAT-CD   TO MIR-FND-STAT-CD
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-STAT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-STAT-CD
557660     END-IF.
      *
           MOVE MIR-FND-STAT-CD       TO WS-TEST-STATUS.
      *
      *  IF STATUS CHANGED TO OPEN, CLEAR MIR-FND-NB-CLOS-DT
      *  AND MIR-FND-CLOS-DT
      *
           IF RFH-FND-STAT-CD NOT = MIR-FND-STAT-CD
           AND WS-STATUS-OPEN
               MOVE '*'               TO MIR-FND-NB-CLOS-DT
               MOVE '*'               TO MIR-FND-CLOS-DT
557660     END-IF.
      *
           IF RFH-FND-STAT-CD NOT = MIR-FND-STAT-CD
           AND WS-STATUS-CLOSED-NB
               MOVE '*'               TO MIR-FND-CLOS-DT
557660     END-IF.
      *
           IF WS-STATUS-OK
               MOVE MIR-FND-STAT-CD   TO RFH-FND-STAT-CD
           ELSE
               MOVE 'SS01200024'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7311-EDIT-FUND-STATUS-X.
           EXIT.
      /
      *************************
       7312-EDIT-CREATION-DATE.
      *************************
      *
           IF MIR-FND-CREAT-DT = SPACES
               MOVE 'N'               TO WS-CREATE-DATE-CHANGED-IND
               IF RFH-FND-CREAT-DT      = WWKDT-ZERO-DT
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE RFH-FND-CREAT-DT
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM  1640-8000-INTERNAL-TO-MIR
020462                 THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-FND-CREAT-DT
                   GO TO 7312-EDIT-CREATION-DATE-X
557660         END-IF
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-CREAT-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-CREAT-DT
      *MSG: 'MUST HAVE A CREATION DATE'
               MOVE 'SS01200025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7312-EDIT-CREATION-DATE-X
557660     END-IF.
      *
           MOVE MIR-FND-CREAT-DT      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               IF L1640-INTERNAL-DATE = RFH-FND-CREAT-DT
                   MOVE 'N'           TO WS-CREATE-DATE-CHANGED-IND
               ELSE
                   MOVE 'Y'           TO WS-CREATE-DATE-CHANGED-IND
557660         END-IF
           ELSE
               MOVE 'SS01200021'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FND-CREAT-DT  TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7312-EDIT-CREATION-DATE-X
557660     END-IF.
      *
           IF  WS-CREATE-DATE-CHANGED
           AND L1640-VALID
      ***      CHECK FOR UNIT PRICES.  MUST NOT EXIST IF CHANGING
      ***      CREATION DATE.
               PERFORM  6110-CHECK-FV-FILE
                   THRU 6110-CHECK-FV-FILE-X
               IF WS-FV-RECORDS-FOUND
                   MOVE 'SS01200027'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE WS-FAILED     TO WS-DATA-EDITS
               ELSE
                   MOVE MIR-FND-CREAT-DT
                                      TO MIR-FND-NXT-VALN-DT
                   MOVE L1640-INTERNAL-DATE
                                      TO RFH-FND-NXT-VALN-DT
                   MOVE L1640-INTERNAL-DATE
                                      TO RFH-FND-CREAT-DT
557660         END-IF
557660     END-IF.
      *
       7312-EDIT-CREATION-DATE-X.
           EXIT.
      /
      *************************
       7313-EDIT-NB-CLOSE-DATE.
      *************************
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-NB-CLOS-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-NB-CLOS-DT
               MOVE WWKDT-ZERO-DT     TO RFH-FND-NB-CLOS-DT
               GO TO 7313-EDIT-NB-CLOSE-DATE-X
557660     END-IF.
      *
           IF MIR-FND-NB-CLOS-DT = SPACES
               IF RFH-FND-NB-CLOS-DT    = WWKDT-ZERO-DT
                   GO TO 7313-EDIT-NB-CLOSE-DATE-X
               ELSE
                   MOVE RFH-FND-NB-CLOS-DT
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM  1640-8000-INTERNAL-TO-MIR
020462                 THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-FND-NB-CLOS-DT
                   GO TO 7313-EDIT-NB-CLOSE-DATE-X
557660         END-IF
557660     END-IF.
      *
           MOVE MIR-FND-NB-CLOS-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               IF L1640-INTERNAL-DATE = RFH-FND-NB-CLOS-DT
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO RFH-FND-NB-CLOS-DT
557660         END-IF
           ELSE
               MOVE 'SS01200022'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FND-NB-CLOS-DT             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7313-EDIT-NB-CLOSE-DATE-X
557660     END-IF.
      *
           IF RFH-FND-NB-CLOS-DT    NOT > WGLOB-PROCESS-DATE
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7313-EDIT-NB-CLOSE-DATE-X.
           EXIT.
      /
      **********************
       7314-EDIT-CLOSE-DATE.
      **********************
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-CLOS-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-CLOS-DT
               MOVE WWKDT-ZERO-DT     TO RFH-FND-CLOS-DT
               GO TO 7314-EDIT-CLOSE-DATE-X
557660     END-IF.
      *
           IF MIR-FND-CLOS-DT = SPACES
               IF RFH-FND-CLOS-DT    = WWKDT-ZERO-DT
                   GO TO 7314-EDIT-CLOSE-DATE-X
               ELSE
                   MOVE RFH-FND-CLOS-DT
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM  1640-8000-INTERNAL-TO-MIR
020462                 THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-FND-CLOS-DT
                   GO TO 7314-EDIT-CLOSE-DATE-X
557660         END-IF
557660     END-IF.
      *
           MOVE MIR-FND-CLOS-DT       TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               IF L1640-INTERNAL-DATE = RFH-FND-CLOS-DT
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO RFH-FND-CLOS-DT
557660         END-IF
           ELSE
               MOVE 'SS01200023'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FND-CLOS-DT   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7314-EDIT-CLOSE-DATE-X
557660     END-IF.
      *
           IF RFH-FND-CLOS-DT    NOT > WGLOB-PROCESS-DATE
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7314-EDIT-CLOSE-DATE-X.
           EXIT.
      /
      ***********************
       7315-EDIT-GEN-VAL-DIR.
      ***********************
      *
021239*    IF MIR-GNRL-VALN-DIR-CD = SPACES
021239*        MOVE RFH-GNRL-VALN-DIR-CD
021239*                               TO MIR-GNRL-VALN-DIR-CD
021239*    END-IF.
021239*
021239*  RESET FIELD TO BLANK VALUE
021239*
021239*    IF MIR-GNRL-VALN-DIR-CD = EBLCH-BLANK-FIELD-CHAR
021239*        MOVE SPACES            TO MIR-GNRL-VALN-DIR-CD
021239*    END-IF.
021239*
021239*    MOVE MIR-GNRL-VALN-DIR-CD  TO WS-TEST-GENERAL-VAL-DIR.
021239
021239     EVALUATE TRUE
021239
021239         WHEN MIR-GNRL-VALN-DIR-CD = SPACES
021239              MOVE RFH-GNRL-VALN-DIR-CD
021239                                 TO MIR-GNRL-VALN-DIR-CD
021239
021239         WHEN MIR-GNRL-VALN-DIR-CD = EBLCH-BLANK-FIELD-CHAR
021239              MOVE SPACES        TO MIR-GNRL-VALN-DIR-CD
021239
021239     END-EVALUATE.
021239
021239     MOVE 'GNRL-VALN-DIR-CD'    TO L8960-AV-TBL-CD.
021239     MOVE MIR-GNRL-VALN-DIR-CD  TO L8960-AV-CD.
021239     PERFORM  8960-1000-VALIDATE-CODE
021239         THRU 8960-1000-VALIDATE-CODE-X.
      *
021239*    IF WS-GENERAL-VAL-DIR-OK
021239     IF  L8960-RETRN-OK
               MOVE MIR-GNRL-VALN-DIR-CD
                                      TO RFH-GNRL-VALN-DIR-CD
           ELSE
               MOVE 'SS01200036'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7315-EDIT-GEN-VAL-DIR-X.
           EXIT.
      /
021239**************************
021239*7316-EDIT-NUM-UNIT-TYPES.
021239**************************
021239*
021239*    IF MIR-FND-UNIT-TYP-CD = SPACES
012146*        MOVE RFH-FND-UNIT-TYP-QTY  TO WS-OUT-NUMBER-1
021239*        MOVE RFH-FND-UNIT-TYP-CD
021239*                               TO WS-OUT-NUMBER-1
021239*        MOVE WS-OUT-NUMBER-1   TO MIR-FND-UNIT-TYP-CD
021239*        GO TO 7316-EDIT-NUM-UNIT-TYPES-X
021239*    END-IF.
021239*
021239*  RESET FIELD TO BLANK VALUE
021239*
021239*    IF MIR-FND-UNIT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
021239*        MOVE ZERO              TO MIR-FND-UNIT-TYP-CD
021239*    END-IF.
021239*
021239*  CHECK TO SEE IF VALUE HAS BEEN CHANGED ON SCREEN
021239*
021239*    MOVE MIR-FND-UNIT-TYP-CD   TO WS-TEST-NUM-OF-UNIT-TYPES.
021239*
021239*    IF WS-NUM-OF-UNIT-TYPES-OK
021239*        MOVE MIR-FND-UNIT-TYP-CD
021239*                               TO WS-OUT-NUMBER-1
021239*        IF WS-OUT-NUMBER-1 = RFH-FND-UNIT-TYP-QTY
021239*        IF WS-OUT-NUMBER-1 = RFH-FND-UNIT-TYP-CD
021239*            GO TO 7316-EDIT-NUM-UNIT-TYPES-X
021239*        END-IF
021239*    END-IF.
021239*
021239*  CHECK FOR UNIT PRICES. MUST NOT EXIST IF CHANGING NB-UNITS
021239*
021239*    IF WS-FV-RECORDS-FOUND
021239*        MOVE 'SS01200061'      TO WGLOB-MSG-REF-INFO
021239*        PERFORM  0260-1000-GENERATE-MESSAGE
021239*            THRU 0260-1000-GENERATE-MESSAGE-X
021239*        MOVE RFH-FND-UNIT-TYP-QTY  TO WS-OUT-NUMBER-1
021239*        MOVE RFH-FND-UNIT-TYP-CD
021239*                               TO WS-OUT-NUMBER-1
021239*        MOVE WS-OUT-NUMBER-1   TO MIR-FND-UNIT-TYP-CD
021239*        GO TO 7316-EDIT-NUM-UNIT-TYPES-X
021239*    END-IF.
021239*
021239*    MOVE MIR-FND-UNIT-TYP-CD   TO WS-TEST-NUM-OF-UNIT-TYPES.
021239*
021239*    IF WS-NUM-OF-UNIT-TYPES-OK
021239*        MOVE MIR-FND-UNIT-TYP-CD
021239*                               TO WS-OUT-NUMBER-1
021239*        MOVE WS-OUT-NUMBER-1       TO RFH-FND-UNIT-TYP-QTY
021239*        MOVE WS-OUT-NUMBER-1   TO RFH-FND-UNIT-TYP-CD
021239*    ELSE
021239*        MOVE 'SS01200037'      TO WGLOB-MSG-REF-INFO
021239*        PERFORM  0260-1000-GENERATE-MESSAGE
021239*            THRU 0260-1000-GENERATE-MESSAGE-X
021239*        MOVE WS-FAILED         TO WS-DATA-EDITS
021239*        SET WS-DATA-EDITS-FAILED   TO TRUE
021239*    END-IF.
021239*
021239*7316-EDIT-NUM-UNIT-TYPES-X.
021239*    EXIT.
021239*
      **************************
       7317-EDIT-PRICING-STRUCT.
      **************************
      *
           IF MIR-FND-PRIC-STRUCT-CD = SPACES
               MOVE RFH-FND-PRIC-STRUCT-CD
                                      TO MIR-FND-PRIC-STRUCT-CD
               GO TO 7317-EDIT-PRICING-STRUCT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-PRIC-STRUCT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-PRIC-STRUCT-CD
557660     END-IF.
      *
           IF MIR-FND-PRIC-STRUCT-CD = RFH-FND-PRIC-STRUCT-CD
               GO TO 7317-EDIT-PRICING-STRUCT-X
557660     END-IF.
      *
      *  CHECK FOR UNIT PRICES. MUST NOT EXIST IF CHANGING NB-UNITS
      *
           IF WS-FV-RECORDS-FOUND
               MOVE 'SS01200062'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RFH-FND-PRIC-STRUCT-CD
                                      TO MIR-FND-PRIC-STRUCT-CD
               GO TO 7317-EDIT-PRICING-STRUCT-X
557660     END-IF.
      *
021239*    MOVE MIR-FND-PRIC-STRUCT-CD     TO WS-TEST-PRICING-STRUCTURE.
021239     MOVE 'FND-PRIC-STRUCT-CD'    TO L8960-AV-TBL-CD.
021239     MOVE MIR-FND-PRIC-STRUCT-CD  TO L8960-AV-CD.
021239     PERFORM  8960-1000-VALIDATE-CODE
021239         THRU 8960-1000-VALIDATE-CODE-X.
      *
021239*    IF WS-PRICING-STRUCTURE-OK
021239     IF  L8960-RETRN-OK
               MOVE MIR-FND-PRIC-STRUCT-CD
                                      TO RFH-FND-PRIC-STRUCT-CD
           ELSE
               MOVE 'SS01200038'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7317-EDIT-PRICING-STRUCT-X.
           EXIT.
      /
      *************************
       7318-EDIT-UNIT-ACCURACY.
      *************************
      *
           IF MIR-FND-UNIT-ACCUR-QTY = SPACES
               MOVE RFH-FND-UNIT-ACCUR-QTY
                                      TO WS-OUT-NUMBER-1
               MOVE WS-OUT-NUMBER-1   TO MIR-FND-UNIT-ACCUR-QTY
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-UNIT-ACCUR-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO MIR-FND-UNIT-ACCUR-QTY
557660     END-IF.
      *
           MOVE MIR-FND-UNIT-ACCUR-QTY         TO WS-TEST-UNIT-ACCURACY.
      *
           IF WS-TEST-UNIT-ACCURACY-N NUMERIC
021239     AND WS-TEST-UNIT-ACCURACY-N < 7
               MOVE WS-TEST-UNIT-ACCURACY-N
                                      TO RFH-FND-UNIT-ACCUR-QTY
           ELSE
               MOVE 'SS01200039'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7318-EDIT-UNIT-ACCURACY-X.
           EXIT.
      /
      *************************
       7319-EDIT-UNIT-ROUNDING.
      *************************
      *
           IF MIR-FND-UNIT-RND-CD = SPACES
               MOVE RFH-FND-UNIT-RND-CD
                                      TO MIR-FND-UNIT-RND-CD
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-UNIT-RND-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-UNIT-RND-CD
557660     END-IF.
      *
021239     MOVE 'FND-UNIT-RND-CD'    TO L8960-AV-TBL-CD.
021239     MOVE MIR-FND-UNIT-RND-CD  TO L8960-AV-CD.
021239     PERFORM  8960-1000-VALIDATE-CODE
021239         THRU 8960-1000-VALIDATE-CODE-X.
      *
021239     IF  L8960-RETRN-OK
021239*    MOVE MIR-FND-UNIT-RND-CD   TO WS-TEST-UNIT-ROUNDING.
021239*
021239*    IF WS-UNIT-ROUNDING-OK
               MOVE MIR-FND-UNIT-RND-CD
                                      TO RFH-FND-UNIT-RND-CD
           ELSE
               MOVE 'SS01200040'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7319-EDIT-UNIT-ROUNDING-X.
           EXIT.
      /
      *************************
       7320-EDIT-PRICE-ACCURACY.
      *************************
      *
           IF MIR-FND-PRIC-ACCUR-QTY = SPACES
               MOVE RFH-FND-PRIC-ACCUR-QTY
                                      TO WS-OUT-NUMBER-1
               MOVE WS-OUT-NUMBER-1   TO MIR-FND-PRIC-ACCUR-QTY
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-PRIC-ACCUR-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO MIR-FND-PRIC-ACCUR-QTY
557660     END-IF.
      *
           MOVE MIR-FND-PRIC-ACCUR-QTY        TO WS-TEST-PRICE-ACCURACY.
      *
           IF WS-TEST-PRICE-ACCURACY-N NUMERIC
               MOVE WS-TEST-PRICE-ACCURACY-N
                                      TO RFH-FND-PRIC-ACCUR-QTY
           ELSE
               MOVE 'SS01200041'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7320-EDIT-PRICE-ACCURACY-X.
           EXIT.
      /
      **************************
       7321-EDIT-MIN-VAL-MONTHS.
      **************************
      *
           IF MIR-MIN-VALN-MO-DUR = SPACES
               MOVE RFH-MIN-VALN-MO-DUR-N
                                      TO WS-OUT-99
020874*        MOVE WS-OUT-99         TO MIR-MIN-VALN-MO-DUR
020874         MOVE RFH-MIN-VALN-MO-DUR-N TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MIN-VALN-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MIN-VALN-MO-DUR
               GO TO 7321-EDIT-MIN-VAL-MONTHS-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-VALN-MO-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-MIN-VALN-MO-DUR
               MOVE ZEROES            TO RFH-MIN-VALN-MO-DUR-N
               GO TO 7321-EDIT-MIN-VAL-MONTHS-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE MIR-MIN-VALN-MO-DUR   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-OUT-99
020874*        MOVE WS-OUT-99         TO MIR-MIN-VALN-MO-DUR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MIN-VALN-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MIN-VALN-MO-DUR
           ELSE
               MOVE 'SS01200042'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7321-EDIT-MIN-VAL-MONTHS-X
557660     END-IF.
      *
           IF WS-OUT-99 > 12
               MOVE 'SS01200042'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
               MOVE WS-OUT-99         TO RFH-MIN-VALN-MO-DUR-N
557660     END-IF.
      *
       7321-EDIT-MIN-VAL-MONTHS-X.
           EXIT.
      /
      ************************
       7322-EDIT-MIN-VAL-DAYS.
      ************************
      *
           IF MIR-MIN-VALN-DY-DUR = SPACES
               MOVE RFH-MIN-VALN-DY-DUR-N
                                      TO WS-OUT-99
020874*        MOVE WS-OUT-99         TO MIR-MIN-VALN-DY-DUR
020874         MOVE RFH-MIN-VALN-DY-DUR-N TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MIN-VALN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MIN-VALN-DY-DUR

               GO TO 7322-EDIT-MIN-VAL-DAYS-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-VALN-DY-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-MIN-VALN-DY-DUR
               MOVE ZEROES            TO RFH-MIN-VALN-DY-DUR-N
               GO TO 7322-EDIT-MIN-VAL-DAYS-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE MIR-MIN-VALN-DY-DUR   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT          TO WS-OUT-99
020874*        MOVE WS-OUT-99             TO MIR-MIN-VALN-DY-DUR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MIN-VALN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MIN-VALN-DY-DUR
           ELSE
               MOVE 'SS01200043'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7322-EDIT-MIN-VAL-DAYS-X
557660     END-IF.
      *
           IF WS-OUT-99 > 31
               MOVE 'SS01200043'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
               MOVE WS-OUT-99         TO RFH-MIN-VALN-DY-DUR-N
557660     END-IF.
      *
       7322-EDIT-MIN-VAL-DAYS-X.
           EXIT.
      /
      **************************
       7323-EDIT-MAX-VAL-MONTHS.
      **************************
      *
           IF MIR-MAX-VALN-MO-DUR = SPACES
               MOVE RFH-MAX-VALN-MO-DUR-N
                                      TO WS-OUT-99
020874*        MOVE WS-OUT-99         TO MIR-MAX-VALN-MO-DUR
020874         MOVE RFH-MAX-VALN-MO-DUR-N TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-VALN-MO-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-VALN-MO-DUR
               GO TO 7323-EDIT-MAX-VAL-MONTHS-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MAX-VALN-MO-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-MAX-VALN-MO-DUR
               MOVE ZEROES            TO RFH-MAX-VALN-MO-DUR-N
               GO TO 7323-EDIT-MAX-VAL-MONTHS-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE MIR-MAX-VALN-MO-DUR   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-OUT-99
020874*        MOVE WS-OUT-99         TO MIR-MAX-VALN-MO-DUR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-VALN-MO-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-VALN-MO-DUR
           ELSE
               MOVE 'SS01200044'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7323-EDIT-MAX-VAL-MONTHS-X
557660     END-IF.
      *
           IF WS-OUT-99 > 12
               MOVE 'SS01200044'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
               MOVE WS-OUT-99         TO RFH-MAX-VALN-MO-DUR-N
557660     END-IF.
      *
       7323-EDIT-MAX-VAL-MONTHS-X.
           EXIT.
      /
      ************************
       7324-EDIT-MAX-VAL-DAYS.
      ************************
      *
           IF MIR-MAX-VALN-DY-DUR = SPACES
               MOVE RFH-MAX-VALN-DY-DUR-N
                                      TO WS-OUT-99
020874*        MOVE WS-OUT-99         TO MIR-MAX-VALN-DY-DUR
020874         MOVE RFH-MAX-VALN-DY-DUR-N TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-VALN-DY-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-VALN-DY-DUR
               GO TO 7324-EDIT-MAX-VAL-DAYS-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MAX-VALN-DY-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-MAX-VALN-DY-DUR
               MOVE ZEROES            TO RFH-MAX-VALN-DY-DUR-N
               GO TO 7324-EDIT-MAX-VAL-DAYS-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE MIR-MAX-VALN-DY-DUR   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-OUT-99
020874*        MOVE WS-OUT-99         TO MIR-MAX-VALN-DY-DUR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-VALN-DY-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-VALN-DY-DUR
           ELSE
               MOVE 'SS01200045'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7324-EDIT-MAX-VAL-DAYS-X
557660     END-IF.
      *
           IF WS-OUT-99 > 31
               MOVE 'SS01200045'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
               MOVE WS-OUT-99         TO RFH-MAX-VALN-DY-DUR-N
557660     END-IF.
      *
       7324-EDIT-MAX-VAL-DAYS-X.
           EXIT.
      /
      **************************
       7330-EDIT-LAST-SEED-DATE.
      **************************
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-PREV-SEED-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-PREV-SEED-DT
               MOVE WWKDT-ZERO-DT     TO RFH-FND-PREV-SEED-DT
               GO TO 7330-EDIT-LAST-SEED-DATE-X
557660     END-IF.
      *
           IF MIR-FND-PREV-SEED-DT = SPACES
               IF RFH-FND-PREV-SEED-DT = WWKDT-ZERO-DT
                   GO TO 7330-EDIT-LAST-SEED-DATE-X
               ELSE
                   MOVE RFH-FND-PREV-SEED-DT
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM  1640-8000-INTERNAL-TO-MIR
020462                 THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-FND-PREV-SEED-DT
                   GO TO 7330-EDIT-LAST-SEED-DATE-X
557660         END-IF
557660     END-IF.
      *
           MOVE MIR-FND-PREV-SEED-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO RFH-FND-PREV-SEED-DT
           ELSE
               MOVE 'SS01200047'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FND-PREV-SEED-DT
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7330-EDIT-LAST-SEED-DATE-X.
           EXIT.
      /
      ***************************
       7331-EDIT-UNITS-FROM-SEED.
      ***************************
      *
021239*    IF MIR-INTG-SEED-UNIT-QTY = SPACES
021239     IF MIR-FND-SEED-UNIT-QTY = SPACES
008455*        MOVE RFH-INTG-SEED-UNIT-QTY   TO WS-OUT-FMT-7
008455*        MOVE RFH-DCML-SEED-UNIT-QTY   TO WS-OUT-FMT-V9
008455*        MOVE WS-OUT-FMT-7-9           TO MIR-INTG-SEED-UNIT-QTY
020874*        COMPUTE L0290-INPUT-NUMBER = ( RFH-DCML-SEED-UNIT-QTY +
020874*                                     RFH-INTG-SEED-UNIT-QTY ) *
020874*                                       1000000000
021239*        COMPUTE L0290-INPUT-V09    = ( RFH-DCML-SEED-UNIT-QTY +
021239*                                     RFH-INTG-SEED-UNIT-QTY )
021239         COMPUTE L0290-INPUT-V06    = RFH-FND-SEED-UNIT-QTY
008455         PERFORM  9920-FORMAT-FSDIS
008455             THRU 9920-FORMAT-FSDIS-X
               GO TO 7331-EDIT-UNITS-FROM-SEED-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
021239*    IF MIR-INTG-SEED-UNIT-QTY = EBLCH-BLANK-FIELD-CHAR
021239     IF MIR-FND-SEED-UNIT-QTY = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.000000000'      TO MIR-INTG-SEED-UNIT-QTY
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
021239*        MOVE ZEROS             TO L0290-INPUT-V09
021239         MOVE ZEROS             TO L0290-INPUT-V06
008455         PERFORM  9920-FORMAT-FSDIS
008455             THRU 9920-FORMAT-FSDIS-X
021239*        MOVE ZEROES            TO RFH-INTG-SEED-UNIT-QTY
021239*        MOVE ZEROES            TO RFH-DCML-SEED-UNIT-QTY
021239         MOVE ZEROES            TO RFH-FND-SEED-UNIT-QTY
               GO TO 7331-EDIT-UNITS-FROM-SEED-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
021239*    MOVE 9                     TO L0280-PRECISION.
021239     MOVE 6                     TO L0280-PRECISION.
008455*    MOVE 7                            TO L0280-LENGTH.
021239*    MOVE MIR-INTG-SEED-UNIT-QTY              TO L0280-INPUT-DATA.
021239     MOVE MIR-FND-SEED-UNIT-QTY TO L0280-INPUT-DATA.
021239*    MOVE LENGTH OF MIR-INTG-SEED-UNIT-QTY
021239     MOVE LENGTH OF MIR-FND-SEED-UNIT-QTY
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 2.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
008455*        MOVE L0280-OUTPUT             TO WS-OUT-NUM-18
008455*        MOVE WS-OUT-NUM-7             TO RFH-INTG-SEED-UNIT-QTY
008455*        MOVE WS-OUT-NUM-V9            TO RFH-DCML-SEED-UNIT-QTY
008455*        MOVE WS-OUT-NUM-7             TO WS-OUT-FMT-7
008455*        MOVE WS-OUT-NUM-V9            TO WS-OUT-FMT-V9
008455*        MOVE WS-OUT-FMT-7-9           TO MIR-INTG-SEED-UNIT-QTY
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         PERFORM  9920-FORMAT-FSDIS
008455             THRU 9920-FORMAT-FSDIS-X
021239*        MOVE L0280-OUTPUT-V09  TO RFH-INTG-SEED-UNIT-QTY
021239*        MOVE L0280-OUTPUT-V09  TO RFH-DCML-SEED-UNIT-QTY
021239         MOVE L0280-OUTPUT-V06  TO RFH-FND-SEED-UNIT-QTY
           ELSE
               MOVE 'SS01200049'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7331-EDIT-UNITS-FROM-SEED-X.
           EXIT.
      /
      *************************
       7332-EDIT-GAIN-LOSS-IND.
      *************************
      *
           IF MIR-FND-GLA-CD = SPACES
               MOVE RFH-FND-GLA-CD    TO MIR-FND-GLA-CD
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-GLA-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-GLA-CD
557660     END-IF.
      *
           MOVE MIR-FND-GLA-CD        TO WS-TEST-GAIN-LOSS-IND.
      *
           IF WS-GAIN-LOSS-IND-OK
               MOVE MIR-FND-GLA-CD    TO RFH-FND-GLA-CD
           ELSE
               MOVE 'SS01200052'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7332-EDIT-GAIN-LOSS-IND-X.
           EXIT.
      /
      *************************
       7333-EDIT-GAIN-LOSS-NUM.
      *************************
      *
           IF MIR-FND-GLA-DUR = SPACES
               MOVE RFH-FND-GLA-DUR   TO WS-OUT-999
               MOVE WS-OUT-999        TO MIR-FND-GLA-DUR
               GO TO 7333-EDIT-GAIN-LOSS-NUM-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-GLA-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-FND-GLA-DUR
               MOVE ZEROES            TO RFH-FND-GLA-DUR
               GO TO 7333-EDIT-GAIN-LOSS-NUM-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-FND-GLA-DUR       TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RFH-FND-GLA-DUR
               MOVE L0280-OUTPUT      TO WS-OUT-999
               MOVE WS-OUT-999        TO MIR-FND-GLA-DUR
           ELSE
               MOVE 'SS01200053'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7333-EDIT-GAIN-LOSS-NUM-X.
           EXIT.
      /
      *************************
       7334-EDIT-GAIN-LOSS-REV.
      *************************
      *
           IF MIR-FND-REVRS-GLA-CD = SPACES
               MOVE RFH-FND-REVRS-GLA-CD
                                      TO MIR-FND-REVRS-GLA-CD
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-REVRS-GLA-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FND-REVRS-GLA-CD
557660     END-IF.
      *
           MOVE MIR-FND-REVRS-GLA-CD  TO WS-TEST-GAIN-LOSS-CALC-REV.
      *
           IF WS-GAIN-LOSS-CALC-REV-OK
               MOVE MIR-FND-REVRS-GLA-CD
                                      TO RFH-FND-REVRS-GLA-CD
           ELSE
               MOVE 'SS01200056'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7334-EDIT-GAIN-LOSS-REV-X.
           EXIT.
      /
      *****************************
       7335-EDIT-MANAGEMENT-CHARGE.
      *****************************
      *
           IF MIR-FND-MGMT-CHRG-PCT = SPACES
               MOVE RFH-FND-MGMT-CHRG-PCT
                                   TO WS-OUT-9-9999
020874*        MOVE WS-OUT-9-9999     TO MIR-FND-MGMT-CHRG-PCT
020874         MOVE RFH-FND-MGMT-CHRG-PCT TO L0290-INPUT-NUMBER
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FND-MGMT-CHRG-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-FND-MGMT-CHRG-PCT

               GO TO 7335-EDIT-MANAGEMENT-CHARGE-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-MGMT-CHRG-PCT = EBLCH-BLANK-FIELD-CHAR
               MOVE '0.0000'          TO MIR-FND-MGMT-CHRG-PCT
               GO TO 7335-EDIT-MANAGEMENT-CHARGE-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 4                     TO L0280-PRECISION.
           MOVE 1                     TO L0280-LENGTH.
           MOVE MIR-FND-MGMT-CHRG-PCT TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-OUT-NUM-18
               MOVE WS-OUT-NUM-1V4    TO RFH-FND-MGMT-CHRG-PCT
020874*        MOVE WS-OUT-NUM-1V4    TO WS-OUT-9-9999
020874*        MOVE WS-OUT-9-9999     TO MIR-FND-MGMT-CHRG-PCT
020874         MOVE WS-OUT-NUM-1V4        TO L0290-INPUT-NUMBER
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FND-MGMT-CHRG-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-FND-MGMT-CHRG-PCT
           ELSE
               MOVE 'SS01200057'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7335-EDIT-MANAGEMENT-CHARGE-X.
           EXIT.
      /
      ****************************
       7336-EDIT-EXP-PRICE-GROWTH.
      ****************************
      *
           IF MIR-FND-XPCT-GRWTH-AMT = SPACES
               MOVE RFH-FND-XPCT-GRWTH-AMT
                                      TO WS-OUT-999
               MOVE WS-OUT-999        TO MIR-FND-XPCT-GRWTH-AMT
               GO TO 7336-EDIT-EXP-PRICE-GROWTH-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-FND-XPCT-GRWTH-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-FND-XPCT-GRWTH-AMT
               MOVE ZEROES            TO RFH-FND-XPCT-GRWTH-AMT
               GO TO 7336-EDIT-EXP-PRICE-GROWTH-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-FND-XPCT-GRWTH-AMT              TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RFH-FND-XPCT-GRWTH-AMT
               MOVE L0280-OUTPUT      TO WS-OUT-999
               MOVE WS-OUT-999        TO MIR-FND-XPCT-GRWTH-AMT
           ELSE
               MOVE 'SS01200058'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7336-EDIT-EXP-PRICE-GROWTH-X.
           EXIT.

010314*********************
010314 7337-EDIT-FUND-TYPE.
010314*********************

010314     IF MIR-FND-TYP-CD = SPACES
010314         MOVE RFH-FND-TYP-CD    TO MIR-FND-TYP-CD
010314     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
010314     IF MIR-FND-TYP-CD = EBLCH-BLANK-FIELD-CHAR
010314         MOVE SPACES            TO MIR-FND-TYP-CD
010314* MSG: INVALID FUND TYPE (ENTER F OR I)
010314         MOVE 'SS01200009'      TO WGLOB-MSG-REF-INFO
010314         PERFORM  0260-1000-GENERATE-MESSAGE
010314             THRU 0260-1000-GENERATE-MESSAGE-X
010314         MOVE WS-FAILED         TO WS-DATA-EDITS
010314         GO TO 7337-EDIT-FUND-TYPE-X
010314     END-IF.
      *

021239     MOVE 'FND-TYP-CD'          TO L8960-AV-TBL-CD.
021239     MOVE MIR-FND-TYP-CD        TO L8960-AV-CD.
021239     PERFORM  8960-1000-VALIDATE-CODE
021239         THRU 8960-1000-VALIDATE-CODE-X.
      *
021239     IF  L8960-RETRN-OK
021239*    MOVE MIR-FND-TYP-CD        TO WS-TEST-FTYPE.
021239*
021239*    IF WS-VALID-FTYPE
010314         MOVE MIR-FND-TYP-CD    TO RFH-FND-TYP-CD
010314     ELSE
010314* MSG: INVALID FUND TYPE (ENTER F OR I)
010314         MOVE 'SS01200009'      TO WGLOB-MSG-REF-INFO
010314         PERFORM  0260-1000-GENERATE-MESSAGE
010314             THRU 0260-1000-GENERATE-MESSAGE-X
010314         MOVE WS-FAILED         TO WS-DATA-EDITS
010314     END-IF.

010314 7337-EDIT-FUND-TYPE-X.
010314     EXIT.
      /
016016
016016**************************
016016 7338-EDIT-RATE-HEADER-ID.
016016**************************
016016
016016     IF MIR-FND-BON-RH-ID = SPACES
016016         MOVE RFH-FND-BON-RH-ID TO MIR-FND-BON-RH-ID
016016     ELSE
016016         MOVE MIR-FND-BON-RH-ID TO RFH-FND-BON-RH-ID
016016     END-IF.
016016
016016 7338-EDIT-RATE-HEADER-ID-X.
016016     EXIT.
016016/
016016
016016*************************
016016 7339-EDIT-BONUS-CALC-CD.
016016*************************
016016     IF MIR-FND-BON-CALC-CD = SPACES
016016         MOVE RFH-FND-BON-CALC-CD TO MIR-FND-BON-CALC-CD
016016     END-IF.
016016
016016     IF MIR-FND-BON-CALC-CD = EBLCH-BLANK-FIELD-CHAR
018763*        MOVE SPACES            TO MIR-FND-BON-CALC-CD
018763         MOVE 'N'               TO MIR-FND-BON-CALC-CD
016016     END-IF.
016016
016016     MOVE MIR-FND-BON-CALC-CD     TO WS-TEST-BONUS-CALC-CD.
016016
016016     IF WS-BONUS-CALC-CD-OK
016016         MOVE MIR-FND-BON-CALC-CD TO RFH-FND-BON-CALC-CD
016016     ELSE
016016* MSG: CALCULATION METHOD INVALID
016016         MOVE 'SS01200012'      TO WGLOB-MSG-REF-INFO
016016         PERFORM  0260-1000-GENERATE-MESSAGE
016016             THRU 0260-1000-GENERATE-MESSAGE-X
016016         MOVE WS-FAILED         TO WS-DATA-EDITS
016016     END-IF.
016016
016016 7339-EDIT-BONUS-CALC-CD-X.
016016     EXIT.
      /
020452*---------------------------
020452 7340-EDIT-ORIG-FND-CTRY-CD.
020452*---------------------------
020452
020452     IF MIR-FND-ORIG-CTRY-CD = SPACES
020452        MOVE RFH-FND-ORIG-CTRY-CD      TO MIR-FND-ORIG-CTRY-CD
020452     END-IF.
020452
020452     IF MIR-FND-ORIG-CTRY-CD = EBLCH-BLANK-FIELD-CHAR
020452     OR MIR-FND-ORIG-CTRY-CD = SPACES
020452*MSG:  FUND ORIGIN COUNTRY MUST BE FILLED
020452*       MOVE 'SS0120013'               TO WGLOB-MSG-REF-INFO
026545        MOVE 'SS01200013'              TO WGLOB-MSG-REF-INFO
020452        PERFORM  0260-1000-GENERATE-MESSAGE
020452            THRU 0260-1000-GENERATE-MESSAGE-X
020452         MOVE WS-FAILED         TO WS-DATA-EDITS
020452         GO TO 7340-EDIT-ORIG-FND-CTRY-CD-X
020452     END-IF.
020452
020452     MOVE WGLOB-COMPANY-CODE           TO WCTRY-CO-ID.
020452     MOVE MIR-FND-ORIG-CTRY-CD         TO WCTRY-CTRY-CD.
020452     PERFORM  CTRY-2000-READ-INDEX
020452         THRU CTRY-2000-READ-INDEX-X.
020452
020452     IF NOT WCTRY-IO-OK
020452*MSG: FUND ORIGIN COUNTRY CODE MUST BE IN CTRY TABLE
020452         MOVE 'SS01200014'             TO WGLOB-MSG-REF-INFO
020452         PERFORM  0260-1000-GENERATE-MESSAGE
020452             THRU 0260-1000-GENERATE-MESSAGE-X
020452         MOVE WS-FAILED                TO WS-DATA-EDITS
020452     ELSE
020452         MOVE MIR-FND-ORIG-CTRY-CD     TO RFH-FND-ORIG-CTRY-CD
020452     END-IF.
020452
020452 7340-EDIT-ORIG-FND-CTRY-CD-X.
020452     EXIT.
      /
      *****************************************************************
      *  CROSS EDITS:
      *****************************************************************
       7400-CROSS-EDITS.
      ******************
      *
           MOVE WS-OK                 TO WS-CROSS-EDITS.
           MOVE RFH-FND-STAT-CD       TO WS-TEST-STATUS.
           MOVE RFH-FND-GLA-CD        TO WS-TEST-GAIN-LOSS-IND.
      *
      *    PERFORM SCREEN 1 CROSS EDITS
      *
           PERFORM  7410-CROSS-EDITS-1
               THRU 7410-CROSS-EDITS-1-X.
      *
      *    PERFORM SCREEN 2 CROSS EDITS
      *
           PERFORM  7420-CROSS-EDITS-2
               THRU 7420-CROSS-EDITS-2-X.
      *
       7400-CROSS-EDITS-X.
           EXIT.
      *
      *****************************************************************
      *  CROSS EDITS: FOR SCREEN 1
      *****************************************************************
       7410-CROSS-EDITS-1.
      ********************
      *
           EVALUATE TRUE

               WHEN RFH-MIN-VALN-DUR-INFO = ZEROES
               WHEN RFH-MAX-VALN-DUR-INFO = ZEROES
                    MOVE WS-FAILED         TO WS-CROSS-EDITS
                    MOVE 'SS01200060'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RFH-MIN-VALN-DUR-INFO NOT < RFH-MAX-VALN-DUR-INFO
                    MOVE WS-FAILED         TO WS-CROSS-EDITS
                    MOVE 'SS01200046'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.
      *
           IF WS-CREATE-DATE-CHANGED
           AND NOT WS-STATUS-OPEN
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
010314*
010314     IF  RFH-FND-TYP-CD = 'I'
010314     AND NOT WS-STATUS-OPEN
010314*MSG: FUND STATUS MUST BE 'O' FOR INDEXED FUNDS
010314         MOVE WS-FAILED         TO WS-CROSS-EDITS
010314         MOVE 'SS01200010'      TO WGLOB-MSG-REF-INFO
010314         PERFORM  0260-1000-GENERATE-MESSAGE
010314             THRU 0260-1000-GENERATE-MESSAGE-X
010314     END-IF.
010314*
010314     IF RFH-FND-TYP-CD = 'I'
010314        IF RFH-FND-PRIC-STRUCT-CD = 'S'
010314           CONTINUE
010314        ELSE
010314*MSG: PRICE STRUCTURE MUST BE 'S' FOR INDEXED FUNDS
010314           MOVE WS-FAILED       TO WS-CROSS-EDITS
010314           MOVE 'SS01200011'    TO WGLOB-MSG-REF-INFO
010314           PERFORM  0260-1000-GENERATE-MESSAGE
010314               THRU 0260-1000-GENERATE-MESSAGE-X
010314        END-IF
010314     END-IF.

      *
           IF RFH-FND-NB-CLOS-DT    = WWKDT-ZERO-DT
           AND (WS-STATUS-OPEN
           OR WS-STATUS-CLOSED)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  7411-XEDIT-NB-CLOSE-DT
                   THRU 7411-XEDIT-NB-CLOSE-DT-X
557660     END-IF.
      *
           IF RFH-FND-CLOS-DT    = WWKDT-ZERO-DT
           AND (WS-STATUS-OPEN
           OR WS-STATUS-CLOSED-NB)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  7412-XEDIT-CLOSE-DT
                   THRU 7412-XEDIT-CLOSE-DT-X
557660     END-IF.
      *
       7410-CROSS-EDITS-1-X.
           EXIT.
      *
      ************************
       7411-XEDIT-NB-CLOSE-DT.
      ************************
      *
           IF WS-STATUS-OPEN
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RFH-FND-NB-CLOS-DT    = WWKDT-ZERO-DT
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7411-XEDIT-NB-CLOSE-DT-X
557660     END-IF.
      *
           IF RFH-FND-NB-CLOS-DT    NOT > RFH-FND-CREAT-DT
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RFH-FND-NB-CLOS-DT    > RFH-FND-CLOS-DT
           AND RFH-FND-CLOS-DT    NOT = WWKDT-ZERO-DT
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       7411-XEDIT-NB-CLOSE-DT-X.
           EXIT.
      /
      *********************
       7412-XEDIT-CLOSE-DT.
      *********************
      *
           IF NOT WS-STATUS-CLOSED
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7412-XEDIT-CLOSE-DT-X
557660     END-IF.
      *
           IF RFH-FND-CLOS-DT    = WWKDT-ZERO-DT
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7412-XEDIT-CLOSE-DT-X
557660     END-IF.
      *
           IF RFH-FND-CLOS-DT    NOT > RFH-FND-CREAT-DT
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RFH-FND-NB-CLOS-DT = WWKDT-ZERO-DT
               MOVE RFH-FND-CLOS-DT   TO RFH-FND-NB-CLOS-DT
               MOVE MIR-FND-CLOS-DT   TO MIR-FND-NB-CLOS-DT
557660     END-IF.
      *
           IF RFH-FND-CLOS-DT    < RFH-FND-NB-CLOS-DT
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200035'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       7412-XEDIT-CLOSE-DT-X.
           EXIT.
      /
      *****************************************************************
      *  CROSS EDITS: FOR SCREEN 2
      *****************************************************************
       7420-CROSS-EDITS-2.
      ********************
      *
           IF RFH-FND-PREV-SEED-DT NOT = WWKDT-ZERO-DT
021239*    AND RFH-INTG-SEED-UNIT-QTY = ZEROES
021239*    AND RFH-DCML-SEED-UNIT-QTY = ZEROES
021239     AND RFH-FND-SEED-UNIT-QTY = ZEROES
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200050'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RFH-FND-PREV-SEED-DT = WWKDT-ZERO-DT
021239*    AND (RFH-INTG-SEED-UNIT-QTY NOT = ZEROES
021239*         OR RFH-DCML-SEED-UNIT-QTY NOT = ZEROES)
021239     AND RFH-FND-SEED-UNIT-QTY NOT = ZEROES
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200051'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RFH-FND-PREV-SEED-DT NOT = WWKDT-ZERO-DT
           AND RFH-FND-PREV-SEED-DT NOT > RFH-FND-CREAT-DT
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200048'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF WS-GAIN-LOSS-ZERO
           AND RFH-FND-GLA-DUR  NOT = ZEROES
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF WS-GAIN-LOSS-NON-ZERO
           AND RFH-FND-GLA-DUR  NOT > ZEROES
               MOVE WS-FAILED         TO WS-CROSS-EDITS
               MOVE 'SS01200055'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       7420-CROSS-EDITS-2-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: ALL KEY FIELDS MUST BE EDITED FOR VALID
      *  VALUES BEFORE A CREATE WILL BE ALLOWED.
      *****************************************************************
       7500-EDIT-KEY-FIELDS.
      **********************
      *
           MOVE WS-OK                 TO WS-DATA-EDITS.
      *
           PERFORM  7510-EDIT-KEY1
               THRU 7510-EDIT-KEY1-X.
      *
       7500-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT KEY1: FUND CODE
      *****************************************************************
       7510-EDIT-KEY1.
      ****************
      *
           MOVE MIR-FND-ID            TO WS-ETAB-FUND.
557756*    MOVE WGLOB-LANG-SUB      TO WS-ETAB-LANG-NUM.
           MOVE WS-ETAB-FUND          TO WEDIT-ETBL-VALU-ID.
           PERFORM  SGFD-1000-EDIT
              THRU  SGFD-1000-EDIT-X.
      *
           IF NOT WEDIT-IO-OK
               MOVE 'SS01200003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7510-EDIT-KEY1-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-LIST-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-FND-ID-G.

       9000-BLANK-LIST-FIELDS-X.
           EXIT.

      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.

      *
      *    BLANK OUT DATA ON GIVEN SCREEN
      *
               PERFORM  9110-BLANK-DATA-FIELDS-1
                   THRU 9110-BLANK-DATA-FIELDS-1-X
               PERFORM  9120-BLANK-DATA-FIELDS-2
                   THRU 9120-BLANK-DATA-FIELDS-2-X.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 1
      *****************************************************************
       9110-BLANK-DATA-FIELDS-1.
      *
017261     MOVE SPACES                TO MIR-DV-FND-CRNT-STAT-CD.
           MOVE SPACES                TO MIR-FND-CRCY-CD.
           MOVE SPACES                TO MIR-FND-STAT-CD.
020452     MOVE SPACES                TO MIR-FND-ORIG-CTRY-CD.
           MOVE SPACES                TO MIR-GNRL-VALN-DIR-CD.
021239*    MOVE SPACES                TO MIR-FND-UNIT-TYP-CD.
           MOVE SPACES                TO MIR-FND-PRIC-STRUCT-CD.
           MOVE SPACES                TO MIR-FND-UNIT-ACCUR-QTY.
           MOVE SPACES                TO MIR-FND-UNIT-RND-CD.
           MOVE SPACES                TO MIR-FND-PRIC-ACCUR-QTY.
           MOVE SPACES                TO MIR-MIN-VALN-MO-DUR.
           MOVE SPACES                TO MIR-MIN-VALN-DY-DUR.
           MOVE SPACES                TO MIR-MAX-VALN-MO-DUR.
           MOVE SPACES                TO MIR-MAX-VALN-DY-DUR.
021239*    MOVE SPACES                TO MIR-INTG-UNIT-1-QTY.
021239*    MOVE SPACES                TO MIR-INTG-UNIT-2-QTY.
           MOVE SPACES                TO MIR-FND-CREAT-DT.
           MOVE SPACES                TO MIR-FND-NB-CLOS-DT.
           MOVE SPACES                TO MIR-FND-CLOS-DT.
           MOVE SPACES                TO MIR-FND-NXT-VALN-DT.
023309*    MOVE SPACES                TO MIR-FND-PREV-VALN-DT.
023309     MOVE SPACES                TO MIR-DV-FND-PREV-VALN-DT.
           MOVE SPACES                TO MIR-PREV-UNIT-ALLOC-DT.
016016     MOVE SPACES                TO MIR-FND-BON-RH-ID.
016016     MOVE SPACES                TO MIR-FND-BON-CALC-CD.

      *
       9110-BLANK-DATA-FIELDS-1-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 2
      *****************************************************************
       9120-BLANK-DATA-FIELDS-2.
      *
           MOVE SPACES                TO MIR-FND-GLA-CD.
           MOVE SPACES                TO MIR-FND-GLA-DUR.
           MOVE SPACES                TO MIR-FND-REVRS-GLA-CD.
           MOVE SPACES                TO MIR-FND-MGMT-CHRG-PCT.
           MOVE SPACES                TO MIR-FND-XPCT-GRWTH-AMT.
021239*    MOVE SPACES                TO MIR-INTG-SEED-UNIT-QTY.
021239     MOVE SPACES                TO MIR-FND-SEED-UNIT-QTY.
           MOVE SPACES                TO MIR-FND-PREV-SEED-DT.
           MOVE SPACES                TO MIR-FND-PREV-SPLT-DT.
      *
       9120-BLANK-DATA-FIELDS-2-X.
           EXIT.
      *
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.
      *
           PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
               THRU 9210-MOVE-RECORD-TO-SCREEN-1-X.
           PERFORM  9220-MOVE-RECORD-TO-SCREEN-2
               THRU 9220-MOVE-RECORD-TO-SCREEN-2-X.
      *
      *    MOVE DATA FOR GIVEN SCREEN
      *
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 1
      *****************************************************************
       9210-MOVE-RECORD-TO-SCREEN-1.
      *
017261     PERFORM  9800-GET-CURRENT-STATUS
017261         THRU 9800-GET-CURRENT-STATUS-X.
           MOVE RFH-FND-CRCY-CD       TO MIR-FND-CRCY-CD.
           MOVE RFH-FND-STAT-CD       TO MIR-FND-STAT-CD.
010314     MOVE RFH-FND-TYP-CD        TO MIR-FND-TYP-CD.
           MOVE RFH-GNRL-VALN-DIR-CD  TO MIR-GNRL-VALN-DIR-CD.
012146*    MOVE RFH-FND-UNIT-TYP-QTY     TO WS-OUT-NUMBER-1.
021239*    MOVE RFH-FND-UNIT-TYP-CD   TO WS-OUT-NUMBER-1.
021239*    MOVE WS-OUT-NUMBER-1       TO MIR-FND-UNIT-TYP-CD.
           MOVE RFH-FND-PRIC-STRUCT-CD        TO MIR-FND-PRIC-STRUCT-CD.
           MOVE RFH-FND-UNIT-ACCUR-QTY               TO WS-OUT-NUMBER-1.
           MOVE WS-OUT-NUMBER-1       TO MIR-FND-UNIT-ACCUR-QTY.
           MOVE RFH-FND-UNIT-RND-CD   TO MIR-FND-UNIT-RND-CD.
           MOVE RFH-FND-PRIC-ACCUR-QTY               TO WS-OUT-NUMBER-1.
           MOVE WS-OUT-NUMBER-1       TO MIR-FND-PRIC-ACCUR-QTY.
020874*    MOVE RFH-MIN-VALN-MO-DUR-N TO WS-OUT-99.
020874*    MOVE WS-OUT-99             TO MIR-MIN-VALN-MO-DUR.
020874     MOVE RFH-MIN-VALN-MO-DUR-N TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MIN-VALN-MO-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-VALN-MO-DUR.
020874*    MOVE RFH-MIN-VALN-DY-DUR-N TO WS-OUT-99.
020874*    MOVE WS-OUT-99             TO MIR-MIN-VALN-DY-DUR.
020874     MOVE RFH-MIN-VALN-DY-DUR-N TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MIN-VALN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-VALN-DY-DUR.
           MOVE RFH-MAX-VALN-MO-DUR-N TO WS-OUT-99.
020874*    MOVE WS-OUT-99             TO MIR-MAX-VALN-MO-DUR.
020874     MOVE RFH-MAX-VALN-MO-DUR-N TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MAX-VALN-MO-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-VALN-MO-DUR.
           MOVE RFH-MAX-VALN-DY-DUR-N TO WS-OUT-99.
020874*    MOVE WS-OUT-99             TO MIR-MAX-VALN-DY-DUR.
020874     MOVE RFH-MAX-VALN-DY-DUR-N TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MAX-VALN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-VALN-DY-DUR.
      * UNIT AMOUNTS
008455*    MOVE RFH-INTG-UNIT-QTY   (1)  TO WS-OUT-FMT-11.
008455*    MOVE RFH-DCML-UNIT-QTY   (1)  TO WS-OUT-FMT-V7.
008455*    MOVE WS-OUT-FMT-11-7          TO MIR-INTG-UNIT-1-QTY.
021239*    MOVE 9                     TO L0290-PRECISION.
021239*    MOVE LENGTH OF MIR-INTG-UNIT-1-QTY
021239*                               TO L0290-MAX-OUT-LEN.
020874*    COMPUTE L0290-INPUT-NUMBER = ( RFH-DCML-UNIT-QTY (1) +
020874*                                   RFH-INTG-UNIT-QTY (1) ) *
020874*                                   1000000000.
021239*    COMPUTE L0290-INPUT-V09    = ( RFH-DCML-UNIT-QTY (1) +
021239*                                   RFH-INTG-UNIT-QTY (1) ).
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
021239*    PERFORM 0290-2000-FORMAT-FOR-MIR
021239*       THRU 0290-2000-FORMAT-FOR-MIR-X.
021239*    MOVE L0290-OUTPUT-DATA     TO MIR-INTG-UNIT-1-QTY.
008455*    MOVE RFH-INTG-UNIT-QTY   (2)  TO WS-OUT-FMT-11.
008455*    MOVE RFH-DCML-UNIT-QTY   (2)  TO WS-OUT-FMT-V7.
008455*    MOVE WS-OUT-FMT-11-7          TO MIR-INTG-UNIT-2-QTY.
021239*    MOVE 9                     TO L0290-PRECISION.
021239*    MOVE LENGTH OF MIR-INTG-UNIT-2-QTY
021239*                               TO L0290-MAX-OUT-LEN.
020874*    COMPUTE L0290-INPUT-NUMBER = ( RFH-DCML-UNIT-QTY (2) +
020874*                                   RFH-INTG-UNIT-QTY (2) ) *
020874*                                   1000000000.
021239*    COMPUTE L0290-INPUT-V09    = ( RFH-DCML-UNIT-QTY (2) +
021239*                                   RFH-INTG-UNIT-QTY (2) ).
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
021239*    PERFORM 0290-2000-FORMAT-FOR-MIR
021239*       THRU 0290-2000-FORMAT-FOR-MIR-X.
021239*    MOVE L0290-OUTPUT-DATA     TO MIR-INTG-UNIT-2-QTY.
      * DATES
           MOVE RFH-FND-CREAT-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-FND-CREAT-DT.
      *
           MOVE RFH-FND-NB-CLOS-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-FND-NB-CLOS-DT.
      *
           MOVE RFH-FND-CLOS-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-FND-CLOS-DT.
      *
           MOVE RFH-FND-NXT-VALN-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-FND-NXT-VALN-DT.
      *
023309     MOVE LOW-VALUES               TO WFDUP-KEY.
023309     MOVE RFH-FND-ID               TO WFDUP-FND-ID.
023309     MOVE WWKDT-LOW-DT             TO WFDUP-FIA-UNIT-PRIC-DT.
023309
023309     MOVE WFDUP-KEY            TO WFDUP-ENDBR-KEY.
023309     MOVE WWKDT-HIGH-DT        TO WFDUP-ENDBR-FIA-UNIT-PRIC-DT.
023309
023309     PERFORM  FDUP-2000-READ-MAX
023309         THRU FDUP-2000-READ-MAX-X.
023309
023309     IF  WFDUP-IO-OK
023309         MOVE WFDUP-MAX-FIA-UNIT-PRIC-DT TO WS-FND-PREV-VALN-DT
023309     ELSE
023309         MOVE WWKDT-ZERO-DT              TO WS-FND-PREV-VALN-DT
023309     END-IF.
023309
023309*    MOVE RFH-FND-PREV-VALN-DT  TO L1640-INTERNAL-DATE.
023309     MOVE WS-FND-PREV-VALN-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
023309*    MOVE L1640-EXTERNAL-DATE   TO MIR-FND-PREV-VALN-DT.
023309     MOVE L1640-EXTERNAL-DATE   TO MIR-DV-FND-PREV-VALN-DT.
      *
           MOVE RFH-PREV-UNIT-ALLOC-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-UNIT-ALLOC-DT.
      *
016016     MOVE RFH-FND-BON-RH-ID     TO MIR-FND-BON-RH-ID.
016016     MOVE RFH-FND-BON-CALC-CD   TO MIR-FND-BON-CALC-CD.
016016*

020452     MOVE RFH-FND-ORIG-CTRY-CD  TO MIR-FND-ORIG-CTRY-CD.

       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 2
      *****************************************************************
       9220-MOVE-RECORD-TO-SCREEN-2.
      *
           MOVE RFH-FND-GLA-CD        TO MIR-FND-GLA-CD.
           MOVE RFH-FND-GLA-DUR       TO WS-OUT-999.
           MOVE WS-OUT-999            TO MIR-FND-GLA-DUR.
           MOVE RFH-FND-REVRS-GLA-CD  TO MIR-FND-REVRS-GLA-CD.
020874*    MOVE RFH-FND-MGMT-CHRG-PCT TO WS-OUT-9-9999.
020874*    MOVE WS-OUT-9-9999         TO MIR-FND-MGMT-CHRG-PCT.
020874     MOVE RFH-FND-MGMT-CHRG-PCT TO L0290-INPUT-NUMBER.
020874     MOVE 4                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-FND-MGMT-CHRG-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-FND-MGMT-CHRG-PCT.
           MOVE RFH-FND-XPCT-GRWTH-AMT TO WS-OUT-999.
           MOVE WS-OUT-999            TO MIR-FND-XPCT-GRWTH-AMT.
      * UNIT AMOUNTS
008455*    MOVE RFH-INTG-SEED-UNIT-QTY   TO WS-OUT-FMT-7.
008455*    MOVE RFH-DCML-SEED-UNIT-QTY   TO WS-OUT-FMT-V9.
008455*    MOVE WS-OUT-FMT-7-9           TO MIR-INTG-SEED-UNIT-QTY.
020874*    COMPUTE L0290-INPUT-NUMBER = ( RFH-DCML-SEED-UNIT-QTY +
020874*                                   RFH-INTG-SEED-UNIT-QTY ) *
020874*                                   1000000000.
021239*    COMPUTE L0290-INPUT-V09    = ( RFH-DCML-SEED-UNIT-QTY +
021239*                                   RFH-INTG-SEED-UNIT-QTY ).
021239     COMPUTE L0290-INPUT-V06    = RFH-FND-SEED-UNIT-QTY
008455     PERFORM  9920-FORMAT-FSDIS
008455         THRU 9920-FORMAT-FSDIS-X.
      * DATES
           MOVE RFH-FND-PREV-SEED-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-FND-PREV-SEED-DT.
      *
           MOVE RFH-FND-PREV-SPLT-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-FND-PREV-SPLT-DT.
      *
       9220-MOVE-RECORD-TO-SCREEN-2-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
017261*****************************************************************
017261*  GET THE VALUE FOR SEG FUND CURRENT STATUS.
017261*****************************************************************
017261*
017261 9800-GET-CURRENT-STATUS.
017261
018763*    IF  WS-BUS-FCN-CREATE
018763*        SET WS-DV-FND-CRNT-STAT-2B-CREATED            TO TRUE
018763*    ELSE
018763*        IF RFH-FND-CLOS-DT    NOT > WGLOB-PROCESS-DATE
018763*        AND RFH-FND-CLOS-DT    NOT = WWKDT-ZERO-DT
018763*            SET WS-DV-FND-CRNT-STAT-CLOSED            TO TRUE
018763*        ELSE
018763*            IF RFH-FND-NB-CLOS-DT    NOT > WGLOB-PROCESS-DATE
018763*            AND RFH-FND-NB-CLOS-DT    NOT = WWKDT-ZERO-DT
018763*                SET WS-DV-FND-CRNT-STAT-CLOSED-4NB    TO TRUE
018763*            ELSE
018763*                IF RFH-FND-CREAT-DT   NOT > WGLOB-PROCESS-DATE
018763*                AND RFH-FND-CREAT-DT  NOT = WWKDT-ZERO-DT
018763*                    SET WS-DV-FND-CRNT-STAT-OPEN      TO TRUE
018763*                ELSE
018763*                    SET WS-DV-FND-CRNT-STAT-2B-OPENED TO TRUE
018763*                END-IF
018763*            END-IF
018763*        END-IF
018763*    END-IF.
018763     EVALUATE TRUE
018763         WHEN  WS-BUS-FCN-CREATE
018763             SET WS-DV-FND-CRNT-STAT-2B-CREATED        TO TRUE
018763         WHEN  RFH-FND-CLOS-DT    NOT > WGLOB-PROCESS-DATE
018763           AND RFH-FND-CLOS-DT    NOT = WWKDT-ZERO-DT
018763             SET WS-DV-FND-CRNT-STAT-CLOSED            TO TRUE
018763         WHEN  RFH-FND-NB-CLOS-DT    NOT > WGLOB-PROCESS-DATE
018763           AND RFH-FND-NB-CLOS-DT    NOT = WWKDT-ZERO-DT
018763             SET WS-DV-FND-CRNT-STAT-CLOSED-4NB        TO TRUE
018763         WHEN  RFH-FND-CREAT-DT   NOT > WGLOB-PROCESS-DATE
018763           AND RFH-FND-CREAT-DT  NOT = WWKDT-ZERO-DT
018763             SET WS-DV-FND-CRNT-STAT-OPEN              TO TRUE
018763         WHEN OTHER
018763             SET WS-DV-FND-CRNT-STAT-2B-OPENED         TO TRUE
018763     END-EVALUATE.

017261*
017261     MOVE WS-DV-FND-CRNT-STAT-CD TO MIR-DV-FND-CRNT-STAT-CD.
017261*
017261 9800-GET-CURRENT-STATUS-X.
017261     EXIT.
      /
021239****************************************************************
021239* SET DEFAULT FUND HEADER VALUES FOR CREATE                    *
021239****************************************************************
021239*9900-DEFAULT-FH-VALUES.
021239*
017364*    MOVE ZERO                  TO RFH-FND-VERS-CTR.
021239*    MOVE SPACES                TO RFH-FND-CRCY-CD.
021239*    MOVE 'O'                   TO RFH-FND-STAT-CD.
021239*    MOVE WGLOB-PROCESS-DATE    TO RFH-FND-CREAT-DT.
021239*    MOVE WGLOB-PROCESS-DATE    TO RFH-FND-NXT-VALN-DT.
021239*    MOVE WWKDT-ZERO-DT         TO RFH-FND-CLOS-DT.
021239*    MOVE WWKDT-ZERO-DT         TO RFH-FND-PREV-VALN-DT.
021239*    MOVE WWKDT-ZERO-DT         TO RFH-PREV-UNIT-ALLOC-DT.
021239*    MOVE WWKDT-ZERO-DT         TO RFH-FND-PREV-SEED-DT.
021239*    MOVE WWKDT-ZERO-DT         TO RFH-FND-PREV-SPLT-DT.
021239*    MOVE ZERO                  TO RFH-FND-MGMT-CHRG-PCT.
021239*    MOVE +999                  TO RFH-FND-XPCT-GRWTH-AMT.
021239*    MOVE 'F'                   TO RFH-GNRL-VALN-DIR-CD.
012146*    MOVE +1                 TO RFH-FND-UNIT-TYP-QTY.
021239*    MOVE +1                    TO RFH-FND-UNIT-TYP-CD.
021239*    MOVE 'S'                   TO RFH-FND-PRIC-STRUCT-CD.
021239*    MOVE +6                    TO RFH-FND-UNIT-ACCUR-QTY.
021239*    MOVE 'N'                   TO RFH-FND-UNIT-RND-CD.
021239*    MOVE +2                    TO RFH-FND-PRIC-ACCUR-QTY.
021239*    MOVE ZERO                  TO RFH-INTG-UNIT-QTY   (1).
021239*    MOVE ZERO                  TO RFH-DCML-UNIT-QTY   (1).
021239*    MOVE ZERO                  TO RFH-INTG-UNIT-QTY   (2).
021239*    MOVE ZERO                  TO RFH-DCML-UNIT-QTY   (2).
021239*    MOVE ZERO                  TO RFH-MIN-VALN-MO-DUR-N.
021239*    MOVE 1                     TO RFH-MIN-VALN-DY-DUR-N.
021239*    MOVE ZERO                  TO RFH-MAX-VALN-MO-DUR-N.
021239*    MOVE 7                     TO RFH-MAX-VALN-DY-DUR-N.
021239*    MOVE ZERO                  TO RFH-INTG-SEED-UNIT-QTY.
021239*    MOVE ZERO                  TO RFH-DCML-SEED-UNIT-QTY.
021239*    MOVE 'G'                   TO RFH-FND-GLA-CD.
021239*    MOVE ZERO                  TO RFH-FND-GLA-DUR.
021239*    MOVE 'R'                   TO RFH-FND-REVRS-GLA-CD.
021239*    MOVE ZERO                  TO RFH-FND-INTG-GLA-QTY      (1).
021239*    MOVE ZERO                  TO RFH-FND-DCML-GLA-QTY      (1).
021239*    MOVE ZERO                  TO RFH-FND-INTG-GLA-QTY      (2).
021239*    MOVE ZERO                  TO RFH-FND-DCML-GLA-QTY      (2).
021239*
021239*9900-DEFAULT-FH-VALUES-X.
021239*    EXIT.
021239*
008455 9920-FORMAT-FSDIS.

021239*    MOVE 9                     TO L0290-PRECISION.
021239     MOVE 6                     TO L0290-PRECISION.
021239*    MOVE LENGTH OF MIR-INTG-SEED-UNIT-QTY
021239     MOVE LENGTH OF MIR-FND-SEED-UNIT-QTY
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
021239*    MOVE L0290-OUTPUT-DATA     TO MIR-INTG-SEED-UNIT-QTY.
021239     MOVE L0290-OUTPUT-DATA     TO MIR-FND-SEED-UNIT-QTY.

008455 9920-FORMAT-FSDIS-X.
008455     EXIT.

      *---------------------------
       9930-MOVE-RECORD-TO-LIST.
      *---------------------------

           MOVE RFH-FND-ID            TO MIR-FND-ID-T (WS-SUB).

       9930-MOVE-RECORD-TO-LIST-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     SET WS-TRANS-NAME-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT    TO TRUE.
025970     SET WS-OK-DEFAULT          TO TRUE.
025970     SET WS-FAILED-DEFAULT      TO TRUE.
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.

025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /


      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY FH
014221                         '$VAR2' BY 'FH'.
       COPY XCPPEXIT.
      /
      /
       COPY XCPPINIT.
      /
012624*COPY XCPPMEXT.
012624*
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
008455*COPY CCPECURR.
      /
       COPY CCPESGFD.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455/
025970 COPY XCPS1640.
       COPY XCPL1640.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
021239 COPY XCPS8960.
021239 COPY XCPL8960.
021239
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      * ADMIN FILE I/O
       COPY CCPNEDIT.
      /
008455 COPY XCPNCRCY.
      /
      * SEGFUND FILE I/O
       COPY SCPBFH.
      /
       COPY SCPCFH.
      /
       COPY SCPAFH.
      /
       COPY SCPNFH.
      /
       COPY SCPUFH.
      /
       COPY SCPXFH.
      /
023309 COPY SCPFFDUP.
023309
020452 COPY XCPNCTRY.
      /
021239*COPY SCPBFV.
021239 COPY SCPBFVAA.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM SSOM0120                     **
      *****************************************************************
