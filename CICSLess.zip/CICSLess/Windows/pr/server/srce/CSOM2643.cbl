      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2643.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2643                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE PBMF TABLE                               **
      **                                                             **
      **  DOMAIN :   PR                                              **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2643'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-DELETE            VALUE '2643'.
025970*    05  WS-TWRK-KEY                      PIC X(04)
025970*                                         VALUE '2643'.                                          
025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-TWRK-KEY                      PIC X(04).  
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '2643'. 
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
      /
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPBMF.
       COPY CCFRPBMF.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY XCWL8960.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2643.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
           SET MIR-RETRN-OK                   TO TRUE.

      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2643'           TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-DELETE.
      *--------------
      *
      *  THE RECORD MUST EXIST, AND HAVE A CURRENT TIMESTAMP
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED      TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  PBMF-1000-READ-FOR-UPDATE
               THRU PBMF-1000-READ-FOR-UPDATE-X.

           IF NOT WPBMF-IO-OK
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'              TO WGLOB-MSG-REF-INFO
               MOVE WPBMF-KEY                 TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED      TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

      *
      *  THE GROUP LEVEL RECORD MUST EXIST AND HAVE A CURRENT TIMESTAMP
      *
           MOVE MIR-PLAN-ID                   TO WPH-PLAN-ID.

           PERFORM  PH-2000-UPDATE-TWRK-TS
               THRU PH-2000-UPDATE-TWRK-TS-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED
               MOVE 'XS00000010'              TO WGLOB-MSG-REF-INFO
               MOVE WPH-KEY                   TO WGLOB-MSG-PARM (1)
               MOVE 'TPH'                     TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED      TO TRUE
               PERFORM  PBMF-3000-UNLOCK
                   THRU PBMF-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2
               MOVE 'XS00000303'              TO WGLOB-MSG-REF-INFO
               MOVE 'TPH'                     TO WGLOB-MSG-PARM (1)
               MOVE WPH-KEY                   TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED      TO TRUE
               PERFORM  PBMF-3000-UNLOCK
                   THRU PBMF-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

      *
      *  DELETE THE RECORD
      *
           PERFORM  PBMF-1000-DELETE
               THRU PBMF-1000-DELETE-X.

           PERFORM  PH-2000-REWRITE
               THRU PH-2000-REWRITE-X.

       2000-DELETE-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           PERFORM  7100-VALIDATE-KEYS
               THRU 7100-VALIDATE-KEYS-X.

           MOVE MIR-PLAN-ID                  TO WPBMF-PLAN-ID.
           MOVE MIR-PLAN-BMF-BILL-CD         TO WPBMF-PLAN-BMF-BILL-CD.
           MOVE MIR-PLAN-BMF-MODE-CD         TO WPBMF-PLAN-BMF-MODE-CD.
           MOVE MIR-PLAN-BMF-TYP-CD          TO WPBMF-PLAN-BMF-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.

      *--------------------
       7100-VALIDATE-KEYS.
      *--------------------

           PERFORM  7110-EDIT-PLAN-ID
               THRU 7110-EDIT-PLAN-ID-X.

           PERFORM  7120-EDIT-BMF-BILL-CD
               THRU 7120-EDIT-BMF-BILL-CD-X.

           PERFORM  7130-EDIT-BMF-MODE-CD
               THRU 7130-EDIT-BMF-MODE-CD-X.

           PERFORM  7140-EDIT-BMF-TYP-CD
               THRU 7140-EDIT-BMF-TYP-CD-X.

       7100-VALIDATE-KEYS-X.
           EXIT.

      *------------------
       7110-EDIT-PLAN-ID.
      *------------------

           IF  MIR-PLAN-ID =  SPACES
           OR  MIR-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG: PLAN CODE MUST NOT BE BLANK
               MOVE 'CS26430001'              TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                         TO WGLOB-MSG-ERROR-SW
               GO TO 7110-EDIT-PLAN-ID-X
           END-IF.

           MOVE MIR-PLAN-ID                   TO  WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
              MOVE WPH-PLAN-ID                TO WGLOB-MSG-PARM (1)
              MOVE 'PH'                       TO WGLOB-MSG-PARM (2)
              MOVE 'XS00000001'               TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
              MOVE 1                         TO WGLOB-MSG-ERROR-SW
              GO TO 7110-EDIT-PLAN-ID-X
           END-IF.

       7110-EDIT-PLAN-ID-X.
           EXIT.

      *---------------------
       7120-EDIT-BMF-BILL-CD.
      *---------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-BILL-TYP-CD'            TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-BMF-BILL-CD          TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID PLAN BILLING CODE @1
               MOVE 'CS26430002'              TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-BMF-BILL-CD      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                         TO WGLOB-MSG-ERROR-SW
               GO TO 7120-EDIT-BMF-BILL-CD-X
           END-IF.

       7120-EDIT-BMF-BILL-CD-X.
           EXIT.

      *---------------------
       7130-EDIT-BMF-MODE-CD.
      *---------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-BILL-MODE-CD'           TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-BMF-MODE-CD          TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID PLAN BILLING MODE @1
               MOVE 'CS26430003'              TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-BMF-MODE-CD      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                         TO WGLOB-MSG-ERROR-SW
               GO TO 7130-EDIT-BMF-MODE-CD-X
           END-IF.

       7130-EDIT-BMF-MODE-CD-X.
           EXIT.

      *---------------------
       7140-EDIT-BMF-TYP-CD.
      *---------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-BMF-TYP-CD'             TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-BMF-TYP-CD           TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID PLAN FACTOR TYPE @1
               MOVE 'CS26430004'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-BMF-TYP-CD      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                        TO WGLOB-MSG-ERROR-SW
               GO TO 7140-EDIT-BMF-TYP-CD-X
           END-IF.

       7140-EDIT-BMF-TYP-CD-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                       TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE           TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE    WS-WORKING-STORAGE.
025970*    CONTINUE.
025970     SET  WS-TWRK-KEY-DEFAULT            TO TRUE.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  PH
                                '$VAR2'   BY 'PH'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
025970 COPY XCPS8090.
       COPY XCPS8960.
       COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPUPBMF.
       COPY CCPXPBMF.
      /
       COPY CCPNPH.
       COPY CCPUPH.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2643                     **
      *****************************************************************
