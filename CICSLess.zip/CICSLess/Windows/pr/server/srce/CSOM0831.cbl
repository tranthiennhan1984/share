      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0831.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0831                                         **
      **  REMARKS:  RELA - MAINTAIN POLICY/CLIENT RELATIONSHIP -     **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE FUNCTIONS **
      **            FOR THE CLINET/POLICY RELATIONSHIP (RL) TABLE.   **
      **            SOME EXAMPLES OF RELATIONSHIPS ARE OWNER, PAYOR, **
      **            ASSIGNEE, AND AGENT.  THE TRANSACTION ENABLES A  **
      **            USER TO CREATE, MAINTAIN, DELETE, AND INQUIRE ON **
      **            RELATIONSHIPS FOR A CLIENT.                      **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       ABEND HANDLING                                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016387**  6.2       CLIENT CONSOLIDATION REMOVAL                     **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016548**  6.2       CHANGE COMP TO BINARY                            **
015796**  6.3       INCEASE NUMBER OF OCCURS FOR RELA                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0831'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
013578*    05  TRANSACTION-NAME         PIC X(04) VALUE  'RELA'.
016548*    05  WS-SUB                   PIC S9(4) COMP SYNC.
016548     05  WS-SUB                   PIC S9(4) BINARY SYNC.
016548*    05  WS-MAX-LINES             PIC S9(4) COMP VALUE +13.
015796*    05  WS-MAX-LINES             PIC S9(4) BINARY VALUE +13.
025970*    05  WS-MAX-LINES             PIC S9(4) BINARY VALUE +100.
           05  WS-OUTPUT-1-ATTR         PIC X(1).
           05  WS-OUTPUT-ATTR           PIC X(1).
           05  WS-DESC-ATTR             PIC X(1).
           05  WS-DESC-1-ATTR           PIC X(1).
           05  WS-KEYS-ATTR             PIC X(1).
           05  WS-VALIDATE-KEY          PIC X.
               88  WS-INVALID-KEY       VALUE '1'.
013578*    05  WS-ENTER-CODE            PIC X.
013578*        88  WS-ENTER-CODE-VALID  VALUE 'B' 'C' 'D' 'M'.
013578*        88  RELA-BROWSE          VALUE 'B'.
013578*        88  RELA-DELETE          VALUE 'D'.
013578*        88  RELA-CREATE          VALUE 'C'.
013578*        88  RELA-MAINTAIN        VALUE 'M'.
013578*        88  WS-LIMITED-FUNCTION  VALUE 'M' 'C' 'D'.
013578     05  WS-BUS-FCN-ID            PIC X(4).
013578         88  WS-BUS-FCN-VALID     VALUE '0690' '0691'
013578                                 '0692' '0693' '0694'.
013578         88  WS-BUS-FCN-RETRIEVE  VALUE '0690'.
013578         88  WS-BUS-FCN-CREATE    VALUE '0691'.
013578         88  WS-BUS-FCN-UPDATE    VALUE '0692'.
013578         88  WS-BUS-FCN-DELETE    VALUE '0693'.
013578         88  WS-BUS-FCN-LIST      VALUE '0694'.
025970*    05  WS-TWRK-KEY              PIC X(04)  VALUE '0690'.
           05  HOLD-KEY.
               10  HOLD-KEY-COMPANY     PIC X(02).
               10  HOLD-KEY-REST        PIC X(31).
               
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LINES             PIC S9(4) BINARY.
025970         88  WS-MAX-LINES-DEFAULT VALUE +100.
025970     05  WS-TWRK-KEY              PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT  VALUE '0690'.

      *
      *****************************************************************
      *  COMMON COPYBOOKS
      *****************************************************************
       COPY XCWEBLCH.
      *
      *****************************************************************
      *  I/O COPYBOOKS
      *****************************************************************
       COPY CCFREDIT.
       COPY CCFWEDIT.
      *
       COPY CCFRRL.
       COPY CCFWRL.
      *
014221 COPY CCFWCLI.
014221 COPY CCFRCLI.
      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION
      *****************************************************************
020478 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL1640.
014221 COPY XCWL8090.
016387*COPY CCWL5600.
      *
      *****************************************************************
      *  INPUT PARAMETER INFORMATION
      *****************************************************************
014588*COPY CCWCCOMM.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
014221 COPY CCWWLOCK.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0831.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FCCK-1000-CHECK-CLIENT
020478         THRU FCCK-1000-CHECK-CLIENT-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
557660     GOBACK.
       0000-MAINLINE-X.
557660     EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      * CHECK SECURITY
      *
025970*    MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

           PERFORM  8000-BUILD-RL-KEY
               THRU 8000-BUILD-RL-KEY-X.

           IF  WS-BUS-FCN-CREATE
               PERFORM  2300-PROCESS-CREATE
                   THRU 2300-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-DELETE
               PERFORM  2400-PROCESS-DELETE
                   THRU 2400-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  2500-PROCESS-LIST
                   THRU 2500-PROCESS-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  2600-PROCESS-UPDATE
                   THRU 2600-PROCESS-UPDATE-X
557660     END-IF.

013578     IF  WS-BUS-FCN-RETRIEVE
013578         PERFORM  2200-PROCESS-RETRIEVE
013578             THRU 2200-PROCESS-RETRIEVE-X
013578     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------
       2200-PROCESS-RETRIEVE.
      *----------------------

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM RL-1000-READ
              THRU RL-1000-READ-X.

           IF  NOT WRL-IO-OK
      *MSG:    RECORD NOT FOUND (@1)
               MOVE    'XS00000001'   TO   WGLOB-MSG-REF-INFO
               MOVE    WRL-KEY        TO   WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2200-PROCESS-RETRIEVE-X
557660     END-IF.

           PERFORM  2900-CHECK-SYSTEM-ID
               THRU 2900-CHECK-SYSTEM-ID-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 2200-PROCESS-RETRIEVE-X
557660     END-IF.

016387*    PERFORM  2800-CHECK-CONS-WARNING
016387*        THRU 2800-CHECK-CONS-WARNING-X.

           PERFORM  2310-FORMAT-SCREEN
               THRU 2310-FORMAT-SCREEN-X.

      *MSG: (DESC) MAINTAIN DETAILS
           MOVE   'XS00000016'        TO   WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2200-PROCESS-RETRIEVE-X.
           EXIT.

      *--------------------
       2300-PROCESS-CREATE.
      *--------------------

           PERFORM  2700-EDIT-KEY
               THRU 2700-EDIT-KEY-X.

           IF  WS-INVALID-KEY
               GO TO 2300-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  RL-1000-READ
               THRU RL-1000-READ-X.

           IF  WRL-IO-OK
      *MSG:    (RL) RECORD ALREADY EXISTS
               MOVE    'XS00000003'   TO   WGLOB-MSG-REF-INFO
               MOVE    WRL-KEY        TO   WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2300-PROCESS-CREATE-X
557660     END-IF.

           MOVE MIR-REL-SYS-ID        TO RRL-REL-SYS-ID.
           PERFORM  2900-CHECK-SYSTEM-ID
               THRU 2900-CHECK-SYSTEM-ID-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 2300-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  RL-1000-CREATE
               THRU RL-1000-CREATE-X.

014221*    MOVE WGLOB-PROCESS-DATE    TO RRL-REL-PREV-UPDT-DT.

016387*    PERFORM  2800-CHECK-CONS-WARNING
016387*        THRU 2800-CHECK-CONS-WARNING-X.

           PERFORM  RL-1000-WRITE
               THRU RL-1000-WRITE-X.

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  2310-FORMAT-SCREEN
               THRU 2310-FORMAT-SCREEN-X.

      *MSG: (RELA) RECORD CREATED - CONTINUE
           MOVE    'XS00000004'       TO   WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *MSG: (RELA) MAINTAIN DETAILS
           MOVE    'XS00000016'       TO   WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2300-PROCESS-CREATE-X.
           EXIT.

      *-------------------
       2310-FORMAT-SCREEN.
      *-------------------

           MOVE RRL-CLI-ID            TO MIR-CLI-ID.
           MOVE RRL-REL-SYS-ID        TO MIR-REL-SYS-ID.
013578*    MOVE RRL-REL-SYS-REF-POL-ID TO MIR-REL-SYS-REF-ID.
013578*    MOVE RRL-REL-SYS-REF-CVG-NUM
013578*                               TO MIR-COVNO.
013578     MOVE RRL-REL-SYS-REF-ID    TO MIR-REL-SYS-REF-ID.
           MOVE RRL-REL-TYP-CD        TO MIR-REL-TYP-CD.
           MOVE RRL-REL-SYS-ID        TO MIR-REL-SYS-ID-T (1).
013578*    MOVE RRL-REL-SYS-REF-POL-ID TO MIR-REL-SYS-REF-ID-T (1).
013578*    MOVE RRL-REL-SYS-REF-CVG-NUM
013578*                               TO MIR-COVN2-T (1).
013578     MOVE RRL-REL-SYS-REF-ID    TO MIR-REL-SYS-REF-ID-T (1).
           MOVE RRL-REL-TYP-CD        TO MIR-REL-TYP-CD-T (1).

           IF  RRL-REL-DESC-TXT IS EQUAL TO SPACES
               MOVE RRL-REL-TYP-CD    TO WEDIT-ETBL-VALU-ID
               MOVE SPACES            TO REDIT-ETBL-DESC-TXT
               PERFORM  RELA-2000-DESC
                   THRU RELA-2000-DESC-X
               IF  WEDIT-IO-OK
                   MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-REL-DESC-TXT-T (1)
               ELSE
      *MSG:        UNKNOWN
                   MOVE 'XS00000223'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-2000-GET-MESSAGE
                       THRU 0260-2000-GET-MESSAGE-X
                   MOVE WGLOB-MSG-TXT TO MIR-REL-DESC-TXT-T (1)
               END-IF
           ELSE
               MOVE RRL-REL-DESC-TXT  TO MIR-REL-DESC-TXT-T (1)
557660     END-IF.

014221*    MOVE RRL-REL-PREV-UPDT-DT  TO L1640-INTERNAL-DATE.
014221     MOVE RRL-PREV-UPDT-TS      TO L1640-INTERNAL-DATE.
           PERFORM  7000-CONVERT-DATE
               THRU 7000-CONVERT-DATE-X.
014221*    MOVE L1640-EXTERNAL-DATE   TO MIR-REL-PREV-UPDT-DT-T (1).
014221     MOVE L1640-EXTERNAL-DATE   TO MIR-DV-PREV-UPDT-DT-T (1).

       2310-FORMAT-SCREEN-X.
           EXIT.

      *--------------------
       2400-PROCESS-DELETE.
      *--------------------

           PERFORM  2420-PROCESS-DELETE
               THRU 2420-PROCESS-DELETE-X.

       2400-PROCESS-DELETE-X.
           EXIT.

      *--------------------
       2420-PROCESS-DELETE.
      *--------------------

014221     MOVE MIR-CLI-ID             TO WCLI-CLI-ID.

014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  WCLI-IO-NOT-FOUND
014221*MSG:  'CLIENT RECORD NOT FOUND'
014221         MOVE 'XS00000058'       TO WGLOB-MSG-REF-INFO
014221         MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2420-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'              TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2420-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  RL-1000-READ-FOR-UPDATE
               THRU RL-1000-READ-FOR-UPDATE-X.

           IF  NOT WRL-IO-OK
      *MSG:    LOST RECORD (RELA) IN DELETE - CONTACT SYSTEMS
               MOVE    'XS00000010'   TO   WGLOB-MSG-REF-INFO
               MOVE    WRL-KEY        TO   WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
           ELSE
               PERFORM  2900-CHECK-SYSTEM-ID
                   THRU 2900-CHECK-SYSTEM-ID-X

               IF  WGLOB-MSG-ERROR-SW > 0
                   GO TO 2420-PROCESS-DELETE-X
               END-IF

016387*        PERFORM  2800-CHECK-CONS-WARNING
016387*            THRU 2800-CHECK-CONS-WARNING-X

               PERFORM  RL-1000-DELETE
                   THRU RL-1000-DELETE-X
      *MSG:    (RELA) DELETE COMPLETED CONTINUE
               MOVE    'XS00000011'   TO   WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

014221         PERFORM  CLI-2000-REWRITE
014221             THRU CLI-2000-REWRITE-X
014221         PERFORM  CLI-1000-READ-TWRK-TS
014221             THRU CLI-1000-READ-TWRK-TS-X

557660     END-IF.

       2420-PROCESS-DELETE-X.
           EXIT.

      *------------------
       2500-PROCESS-LIST.
      *------------------

016387*    PERFORM  2800-CHECK-CONS-WARNING
016387*        THRU 2800-CHECK-CONS-WARNING-X.

           PERFORM  2510-INQ-START-BROWSE
               THRU 2510-INQ-START-BROWSE-X.

           IF  WRL-IO-EOF
      *MSG: RECORD (@1) NOT FOUND
               MOVE    'XS00000001'   TO   WGLOB-MSG-REF-INFO
               MOVE    WRL-CO-ID      TO   HOLD-KEY-COMPANY
               MOVE    HOLD-KEY       TO   WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2500-PROCESS-LIST-X
557660     END-IF.

           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

           PERFORM  2520-INQ-READ-NEXT
               THRU 2520-INQ-READ-NEXT-X
               VARYING WS-SUB FROM 1 BY 1
                 UNTIL WRL-IO-EOF OR
                     ( WS-SUB > WS-MAX-LINES ).

           PERFORM  2530-INQ-END-BROWSE
               THRU 2530-INQ-END-BROWSE-X.

       2500-PROCESS-LIST-X.
           EXIT.

      *----------------------
       2510-INQ-START-BROWSE.
      *----------------------

           MOVE WRL-KEY               TO HOLD-KEY.
           MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
           MOVE WRL-CLI-ID            TO WRL-ENDBR-CLI-ID.

           PERFORM  RL-1000-BROWSE
               THRU RL-1000-BROWSE-X.

       2510-INQ-START-BROWSE-X.
           EXIT.

      *-------------------
       2520-INQ-READ-NEXT.
      *-------------------

           MOVE RRL-REL-SYS-ID        TO MIR-REL-SYS-ID-T (WS-SUB).
013578*    MOVE RRL-REL-SYS-REF-POL-ID
013578     MOVE RRL-REL-SYS-REF-ID
                                   TO MIR-REL-SYS-REF-ID-T (WS-SUB).
013578*    MOVE RRL-REL-SYS-REF-CVG-NUM
013578*                               TO MIR-COVN2-T (WS-SUB).
           MOVE RRL-REL-TYP-CD        TO MIR-REL-TYP-CD-T (WS-SUB).

           IF  RRL-REL-DESC-TXT = SPACES
               MOVE RRL-REL-TYP-CD    TO WEDIT-ETBL-VALU-ID
               PERFORM  RELA-2000-DESC
                   THRU RELA-2000-DESC-X
               IF  WEDIT-IO-OK
                   MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-REL-DESC-TXT-T (WS-SUB)
               ELSE
      *MSG:        UNKNOWN
                   MOVE 'XS00000223'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-2000-GET-MESSAGE
                       THRU 0260-2000-GET-MESSAGE-X
                   MOVE WGLOB-MSG-TXT TO MIR-REL-DESC-TXT-T (WS-SUB)
              END-IF
           ELSE
              MOVE RRL-REL-DESC-TXT   TO MIR-REL-DESC-TXT-T (WS-SUB)
557660     END-IF.

014221*    MOVE RRL-REL-PREV-UPDT-DT  TO L1640-INTERNAL-DATE.
014221     MOVE RRL-PREV-UPDT-TS      TO L1640-INTERNAL-DATE.
           PERFORM  7000-CONVERT-DATE
               THRU 7000-CONVERT-DATE-X.
014221*    MOVE L1640-EXTERNAL-DATE  TO MIR-REL-PREV-UPDT-DT-T (WS-SUB).
014221     MOVE L1640-EXTERNAL-DATE  TO MIR-DV-PREV-UPDT-DT-T (WS-SUB).

           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

       2520-INQ-READ-NEXT-X.
           EXIT.

      *--------------------
       2530-INQ-END-BROWSE.
      *--------------------

           IF  RRL-CLI-ID       NOT = MIR-CLI-ID
               MOVE +8                TO WRL-IO-STATUS
557660     END-IF.

           IF  WS-SUB = +1
      *MSG:    NO RECORDS FOUND TO DISPLAY
               MOVE    'XS00000034'   TO   WGLOB-MSG-REF-INFO
               MOVE    WRL-CO-ID      TO   HOLD-KEY-COMPANY
               MOVE    HOLD-KEY       TO   WGLOB-MSG-PARM (1)
           ELSE
               IF  WRL-IO-EOF
               OR  (NOT WRL-IO-OK)
      *MSG:        ** END OF LIST **
                   MOVE    'XS00000015'
                                      TO   WGLOB-MSG-REF-INFO
                   PERFORM RL-3000-END-BROWSE
                      THRU RL-3000-END-BROWSE-X
               ELSE
                   SET WGLOB-MORE-DATA-EXISTS   TO TRUE
      *MSG:        TO VIEW MORE DATA PRESS ENTER
                   MOVE    'XS00000014'
                                      TO   WGLOB-MSG-REF-INFO
                   MOVE RRL-REL-SYS-ID                 TO MIR-REL-SYS-ID
013578*            MOVE RRL-REL-SYS-REF-POL-ID
013578             MOVE RRL-REL-SYS-REF-ID
                                      TO MIR-REL-SYS-REF-ID
013578*            MOVE RRL-REL-SYS-REF-CVG-NUM
013578*                               TO MIR-COVNO
                   MOVE RRL-REL-TYP-CD                 TO MIR-REL-TYP-CD
                   PERFORM  RL-3000-END-BROWSE
                       THRU RL-3000-END-BROWSE-X
557660         END-IF
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2530-INQ-END-BROWSE-X.
           EXIT.

      *--------------------
       2600-PROCESS-UPDATE.
      *--------------------

           PERFORM  2620-PROCESS-UPDATE
               THRU 2620-PROCESS-UPDATE-X.

       2600-PROCESS-UPDATE-X.
           EXIT.

      *--------------------
       2620-PROCESS-UPDATE.
      *--------------------

014221     MOVE MIR-CLI-ID             TO WCLI-CLI-ID.

014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  WCLI-IO-NOT-FOUND
014221*MSG:  'CLIENT RECORD NOT FOUND'
014221         MOVE 'XS00000058'       TO WGLOB-MSG-REF-INFO
014221         MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2620-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'              TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2620-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  RL-1000-READ-FOR-UPDATE
               THRU RL-1000-READ-FOR-UPDATE-X.

           IF  NOT WRL-IO-OK
      *MSG:    LOST RECORD IN MAINTAIN - CONTACT SYSTEMS
               MOVE    'XS00000006'   TO   WGLOB-MSG-REF-INFO
               MOVE    WRL-KEY        TO   WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
               GO TO  2620-PROCESS-UPDATE-X
557660     END-IF.

           IF  MIR-REL-DESC-TXT-T (1)  NOT =  SPACES
               IF  MIR-REL-DESC-TXT-T (1)  =  EBLCH-BLANK-FIELD-CHAR
                   MOVE  SPACES       TO  RRL-REL-DESC-TXT
               ELSE
                   MOVE  MIR-REL-DESC-TXT-T (1)
                                      TO  RRL-REL-DESC-TXT
               END-IF
557660     END-IF.

014221*    MOVE  WGLOB-PROCESS-DATE   TO RRL-REL-PREV-UPDT-DT.
           PERFORM  RL-2000-REWRITE
               THRU RL-2000-REWRITE-X.

014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

      *MSG: (RELA) MAINTENANCE COMPLETED - CONTINUE
           MOVE  'XS00000007'         TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
014221     PERFORM  RL-1000-READ
014221         THRU RL-1000-READ-X.
           PERFORM  2310-FORMAT-SCREEN
               THRU 2310-FORMAT-SCREEN-X.

       2620-PROCESS-UPDATE-X.
           EXIT.

      *--------------
       2700-EDIT-KEY.
      *--------------

           MOVE '0'                   TO WS-VALIDATE-KEY.

           MOVE MIR-REL-SYS-ID        TO WEDIT-ETBL-VALU-ID.
           PERFORM  SYST-1000-EDIT
               THRU SYST-1000-EDIT-X.

           IF  WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG:    SYSTEM (@1) NOT ON EDIT
               MOVE    'CS08310004'   TO   WGLOB-MSG-REF-INFO
               MOVE    MIR-REL-SYS-ID TO   WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE    '1'            TO   WS-VALIDATE-KEY
557660     END-IF.

           IF  MIR-REL-SYS-REF-ID = SPACES
013578*    AND MIR-COVNO = SPACES
      *MSG:    REFERENCE NUMBER MUST BE CODED. ENTER
               MOVE    'CS08310001'   TO   WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE    '1'            TO   WS-VALIDATE-KEY
557660     END-IF.

           IF  MIR-CLI-ID = SPACES
      *MSG:    CLIENT NUMBER CANNOT BE BLANK
               MOVE    'CS08310003'   TO   WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE    '1'            TO   WS-VALIDATE-KEY
557660     END-IF.

           MOVE MIR-REL-TYP-CD        TO WEDIT-ETBL-VALU-ID
           PERFORM  RELA-1000-EDIT
               THRU RELA-1000-EDIT-X.

           IF  WEDIT-IO-NOT-FOUND
      *MSG:    RELATIONSHIP CODE MUST BE A,B,I,L,M,O,P OR S. RE-ENT
               MOVE    'CS08310002'   TO   WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE    '1'            TO   WS-VALIDATE-KEY
557660     END-IF.

       2700-EDIT-KEY-X.
           EXIT.

016387*------------------------
016387*2800-CHECK-CONS-WARNING.
016387*------------------------
016387*
016387* CHECK CLIENT ACCESS
016387*
016387*
016387*    PERFORM  5600-0000-INIT-PARM-INFO
016387*        THRU 5600-0000-INIT-PARM-INFO-X.
016387*
016387*    PERFORM  5600-1000-BUILD-PARM-INFO
016387*        THRU 5600-1000-BUILD-PARM-INFO-X.
016387*
016387*    MOVE MIR-CLI-ID                TO L5600-CLI-ID.
016387*    SET  L5600-GEN-CNSLDT-MSG-WARN TO TRUE.
016387*    SET  L5600-CNFD-MSG-NOT-REQD   TO TRUE.
016387*
016387*    PERFORM  5600-1000-CLI-CHK
016387*        THRU 5600-1000-CLI-CHK-X.
016387*
016387*2800-CHECK-CONS-WARNING-X.
016387*    EXIT.

      *---------------------
       2900-CHECK-SYSTEM-ID.
      *---------------------

016440*    IF  RRL-REL-SYS-ID = 'NEWBUS  '
016440*    OR  RRL-REL-SYS-ID = 'ADMIN   '
016440     IF  RRL-REL-SYS-ID = WGLOB-SYS-CTL-ID
      *MSG: WARNING..THIS RELATIONSHIP SHOULD BE MAINTAINED BY SYSTEM
               MOVE    'CS08310005'   TO   WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2900-CHECK-SYSTEM-ID-X.
           EXIT.

      *------------------
       7000-CONVERT-DATE.
      *------------------

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

       7000-CONVERT-DATE-X.
           EXIT.

      *------------------
       8000-BUILD-RL-KEY.
      *------------------
      *
      * SET UP RL KEY
      *

           MOVE MIR-CLI-ID            TO WRL-CLI-ID.
           MOVE MIR-REL-SYS-ID        TO WRL-REL-SYS-ID.
013578*    MOVE MIR-REL-SYS-REF-ID    TO WRL-REL-SYS-REF-POL-ID.
013578     MOVE MIR-REL-SYS-REF-ID    TO WRL-REL-SYS-REF-ID.
013578*    MOVE MIR-COVNO             TO WRL-REL-SYS-REF-CVG-NUM.
           MOVE MIR-REL-TYP-CD        TO WRL-REL-TYP-CD.

       8000-BUILD-RL-KEY-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID            TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-MAX-LINES-DEFAULT  TO TRUE. 
025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.
025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK          TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPERELA.
      *
       COPY CCPESYST.
      *
016387*COPY CCPS5600.
      *
020478 COPY CCPPFCCK.

014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      *
       COPY XCPPEXIT.
      *
       COPY XCPPINIT.
      *
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS
      *****************************************************************
025970 COPY XCPS8090.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
016387*COPY CCCL5600.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
      *
       COPY CCPARL.
       COPY CCPBRL.
       COPY CCPCRL.
       COPY CCPNRL.
       COPY CCPURL.
       COPY CCPXRL.
      *
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
557708*COPY XCCPHNDL.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0831                     **
      *****************************************************************
