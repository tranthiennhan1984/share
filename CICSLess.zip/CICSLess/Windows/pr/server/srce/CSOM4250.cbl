      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. CSOM4250.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  CSOM4250                                         **
      **  REMARKS:  ANDD - PROCESS MAINTAINANCE ACTIVITIES FOR THE   **
      **            ANNUITY DESTINATION TABLES (CDSA, CDSD).         **
      **            THIS MODULE WILL PROCESS INQUIRES AND MAINTENANCE**
      **            AGAINST THE ANNUITY DESTINATION DETAILS HISTORY  **
      **            TABLES, CDSA AND CDSD.  THESE TABLES CONTAIN     **
      **            HISTORICAL DETAILS OF A GUARANTEED INTEREST      **
      **            ACCOUNT (GIA) ROLLOVER OR A DAILY INTEREST       **
      **            ACCOUNT (DIA) SWEEP.  IF REQUIRED, IT CAN ALSO   **
      **            BE USED TO MANUALLY CREATE AND UPDATE THESE      **
      **            RECORDS AND TO ENSURE THE CORRESPONDING CFLW     **
      **            DETAILS ARE CORRECT.                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       RENAME CFLW-CF-DT, CVG-DPOS-TRM-INFO             **
557660**  5.5       CHANGE TO STANDARD                               **
557708**  5.5       ADD NEW CICS ABEND PROCESSING                    **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007685**  5.6       ANNUAL STATEMENTS AND COST DISCLOSURES           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
009602**  5.6       RESET RCFLW-DEST-CDA-SEQ-NUM WHEN DELETE         **
010314**  5.6       MODIFICATIONS FOR EQUITY INDEXED ANNUITIES       **
010418**  5.6       ENHANCED MULTI-COMPANY PROCESSING                **
012696**  5.6V      CHANGES TO SUPPORT BROWSING CDSI/CDSD/CDSA       **
012696**            TABLES ON THE ALT INDX CONTAINING CVG NUM        **
014035**  5.6V      STANDARDS/CODE CLEANUP                           **
012624**  6.0       GLOBAL SECURITY CHANGES                          **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
016475**  6.1       REMOVE 9900-DELETE-TWRK LOGIC              **    **
014221**  6.2       LOGICAL LOCKING                                  **
016457**  6.2       ADD # OF COPIES AND REASON CODE                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020463**  6.4       INVESTOR PROFILES                                **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025357**  6.6       CANNOT PROCESS UNDO OF ROLLOVER TO ANOTHER CVG   **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028805**  7.0       CLEAN UP REMOVED BUSINESS FUNCTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************


      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4250'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
       COPY XCWL8090.
007766 COPY XCWWCVGM.

025970*01  WS-PGM-WORK-AREA.
025970 01  WS-CONSTANTS.
           05  WS-TRANSACTION-NAME      PIC X(04)  VALUE 'ANDD'.
025970         88  WS-TRANSACTION-NAME-DEFAULT     VALUE 'ANDD'.
025970     05  WS-MAX-LINES             PIC S9(04)
025970                                  BINARY VALUE +10.
025970         88  WS-MAX-LINES-DEFAULT        VALUE +10.
025970     05  WS-LOWEST-SEQ-NUM              PIC S9(05) COMP-3.
025970          88  WS-LOWEST-SEQ-NUM-DEFAULT VALUE +1000.

025970 01  WS-PGM-WORK-AREA.
           05  WS-SCREEN-NO             PIC X(01).
               88  WS-SCREEN-1          VALUE '1'.
               88  WS-SCREEN-2          VALUE '2'.

       01  WS-MISC-WORK-FIELDS.
016548*    05  I                        PIC S9(04)       COMP.
016548     05  I                        PIC S9(04)       BINARY.
016548*    05  WS-CVG-SUB               PIC S9(04)       COMP.
016548     05  WS-CVG-SUB               PIC S9(04)       BINARY.
           05  WS-CVG                   PIC 9(02).
           05  WS-FORMAT-SEQ            PIC 9(03).
           05  WS-HOLD-COVNO            PIC 9(02).
           05  WS-HOLD-COVNO-R          REDEFINES
               WS-HOLD-COVNO            PIC X(02).
012696     05  WS-POL-ID.
012696         10  WS-POL-ID-BASE       PIC X(09).
012696         10  WS-POL-ID-SFX        PIC X(01).

           05  WS-PIC-99                PIC 9(02).
           05  WS-PIC-999               PIC 9(03).
023112     05  WS-PIC-99999             PIC 9(05).
           05  WS-PIC-3-4               PIC 9(03).9999.
008455*    05  WS-PIC-9-2               PIC 9(09).99.
008455*    05  WS-N-9-2                 PIC S9(09)V99    COMP-3.
008455     05  WS-N-13-2                PIC S9(13)V99    COMP-3
008455                                                   VALUE ZEROES.
           05  WS-N-3-4                 PIC S9(03)V9999  COMP-3.
016548*    05  WS-MAX-LINES             PIC S9(04)       COMP VALUE +10.
025970*    05  WS-MAX-LINES             PIC S9(04)
025970*                                 BINARY VALUE +10.
008455*    05  WS-TOTAL-DEP-AMT         PIC S9(09)V99    COMP-3.
008455     05  WS-TOTAL-DEP-AMT         PIC S9(13)V99    COMP-3.
           05  WS-HIGHEST-ALLOC-NUM     PIC S9(03)       COMP-3
                                                         VALUE ZEROES.
025970*    05  WS-LOWEST-SEQ-NUM        PIC S9(05)       COMP-3
025970*                                                  VALUE +1000.
           05  WS-SEQ-NO                PIC S9(03)       COMP-3
                                                         VALUE ZEROES.
           05  WS-SEQ-NO2               PIC S9(03)       COMP-3
                                                         VALUE ZEROES.
023112     05  WS-SEQ-NO3               PIC S9(05)       COMP-3
023112                                                   VALUE ZEROES.
023112     05  WS-SEQ-NO4               PIC S9(05)       COMP-3
023112                                                   VALUE ZEROES.
           05  WS-INTERNAL-EFFDT        PIC X(10).
           05  WS-BUS-FCN-ID               PIC X(04).
028805*        88  WS-BUS-FCN-CREATE       VALUE '0931'.
               88  WS-BUS-FCN-RETRIEVE     VALUE '0930'.
028805*        88  WS-BUS-FCN-UPDATE       VALUE '0932'.
028805*        88  WS-BUS-FCN-DELETE       VALUE '0933'.
               88  WS-BUS-FCN-LIST         VALUE '0934'.
               88  WS-BUS-FCN-PRINT        VALUE '0935'.
           05  WS-PREV-COVNO            PIC X(02).
           05  WS-PREV-DATE             PIC X(07).
           05  WS-PREV-SEQNO            PIC S9(03)   COMP-3.
023112     05  WS-PREV-PAYO-NUM         PIC S9(05)   COMP-3.
           05  WS-HOLD-BROWSE-COVNO     PIC X(02).
           05  WS-HOLD-BROWSE-DATE      PIC X(07).
           05  WS-HOLD-BROWSE-SEQNO     PIC S9(03)   COMP-3.

       01  WS-SWITCHES.
           05  WS-LINE-EDIT-SW          PIC X(01)   OCCURS 10 TIMES.
               88  WS-EDIT-THIS-LINE                VALUE 'Y'.
               88  WS-NO-EDIT-THIS-LINE             VALUE 'N'.
           05  WS-DEST-CVG-VALID-SW     PIC X(01)   OCCURS 10 TIMES.
               88  WS-DEST-CVG-VALID                VALUE 'Y'.
               88  WS-DEST-CVG-NOT-VALID            VALUE 'N'.
           05  WS-DEP-TERM-VALID-SW     PIC X(01)   OCCURS 10 TIMES.
               88  WS-DEP-TERM-VALID                VALUE 'Y'.
               88  WS-DEP-TERM-NOT-VALID            VALUE 'N'.
           05  WS-SRCE-CF-SW            PIC X(01).
               88  WS-SRCE-CF-FOUND                 VALUE 'Y'.
               88  WS-SRCE-CF-NOT-FOUND             VALUE 'N'.
           05  WS-RENEWAL-SW            PIC X(01).
               88  WS-SEND-RENEWAL-MSG              VALUE 'Y'.
               88  WS-NO-RENEWAL-MSG                VALUE 'N'.
           05  WS-CDSA-ENDBR-SW         PIC X(01).
               88  WS-CDSA-ENDBR-NEEDED             VALUE 'Y'.
           05  WS-CDSD-ENDBR-SW         PIC X(01).
               88  WS-CDSD-ENDBR-NEEDED             VALUE 'Y'.

       01  WS-SUBSCRIPTS.
016548*    05  WS-SUB                   PIC S9(04)       COMP.
016548     05  WS-SUB                   PIC S9(04)       BINARY.
016548*    05  WS-LINE-SUB              PIC S9(04)       COMP.
016548     05  WS-LINE-SUB              PIC S9(04)       BINARY.

       01  WS-DEPOSIT-AMT-INFO.
           05  WS-AMT-DATA          OCCURS 10 TIMES.
008455*        10  WS-DEP-AMT           PIC S9(09)V99    COMP-3.
008455         10  WS-DEP-AMT           PIC S9(13)V99    COMP-3.
               10  WS-GTD-RT            PIC S9(3)V9999   COMP-3.

       01  WS-DEP-TERM.
           05  WS-DEPMN             PIC X(03).
           05  WS-DEPDY             PIC X(03).

018633*01  WS-TWRK-KEY                     PIC X(04)  VALUE '0930'.
018633*01  WS-WORK-AREA.
018633*    05  WS-OLD-STAT-CD             PIC X(01).
018633*    05  WS-CURNT-STAT-CD           PIC X(01).
018633*    05  WS-CDAD-SEQ-NUM            PIC S9(03)    COMP-3.
018633*    05  WS-SRC-CVG-ROL-TYP-CD      PIC X(01).
018633*        88  WS-SRC-CVG-GUAR-INT    VALUE 'G'.
018633*    05  WS-SCREEN-INFO OCCURS 10 TIMES.
018633*        10  WS-CDAD-ALLOC-NUM      PIC S9(03)    COMP-3.
018633*        10  WS-OLD-DEP-AMT         PIC S9(13)V99 COMP-3.
018633*        10  WS-OLD-MO-DUR          PIC X(03).
018633*        10  WS-OLD-DY-DUR          PIC X(03).
018633*    05  FILLER                     PIC X(135).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '0930'.
018633     15  LCOMM-OLD-STAT-CD          PIC X(01).
018633     15  LCOMM-CURNT-STAT-CD        PIC X(01).
018633     15  LCOMM-CDAD-SEQ-NUM         PIC S9(03)    COMP-3.
018633     15  LCOMM-SRC-CVG-ROL-TYP-CD   PIC X(01).
018633         88  LCOMM-SRC-CVG-GUAR-INT VALUE 'G'.
018633     15  LCOMM-SCREEN-INFO OCCURS 10 TIMES.
018633         20  LCOMM-CDAD-ALLOC-NUM   PIC S9(03)    COMP-3.
018633         20  LCOMM-OLD-DEP-AMT      PIC S9(13)V99 COMP-3.
018633         20  LCOMM-OLD-MO-DUR       PIC X(03).
018633         20  LCOMM-OLD-DY-DUR       PIC X(03).
018633
      /
014035*COPY CCWWTR08.
      /
014221 COPY CCWWLOCK.
026057 COPY CCWWIHSD.
      /
       COPY XCWEBLCH.
      /
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCDSA.
       COPY CCFWCDSA.

       COPY CCFRCDSD.
       COPY CCFWCDSD.

       COPY CCFRCFLW.
       COPY CCFWCFLW.

014035*COPY CCFWCLI.
014035*COPY CCFRCLI.

       COPY CCFRCVG.
       COPY CCFWCVG.

023447*COPY NCFRDOCM.
023447*COPY NCFWDOCM.
023447 COPY XCFRDOCM.
023447 COPY XCFWDOCM.

007685*COPY CCFREDIT.
007685*COPY CCFWEDIT.

       COPY CCFRPH.
       COPY CCFWPH.

       COPY CCFWPOL.

014035*COPY CCFRTRAN.
014035*COPY CCFWTRAN.

012696 COPY CCFWCDSC.

021930*COPY CCFWCDSE.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
007685*COPY CCWL5206.
007685 COPY NCWL0303.
      /
020463 COPY CCWL2735.
020463/
       COPY CCWL5400.
      /
       COPY CCWL6530.
      /
       COPY XCWLDTLK.
       COPY XCWL0280.
008455 COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY CCWLPGA.
      /
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM4250.

      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

       0000-MAINLINE.

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023118
023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
       1100-INIT-WS-WORK.

018633*    MOVE ZEROES                TO WS-CDAD-ALLOC-NUM (WS-SUB).
018633*    MOVE ZEROES                TO WS-OLD-DEP-AMT (WS-SUB).
018633*    MOVE SPACES                TO WS-OLD-MO-DUR (WS-SUB).
018633*    MOVE SPACES                TO WS-OLD-DY-DUR (WS-SUB).
018633     MOVE ZEROES                TO LCOMM-CDAD-ALLOC-NUM (WS-SUB).
018633     MOVE ZEROES                TO LCOMM-OLD-DEP-AMT (WS-SUB).
018633     MOVE SPACES                TO LCOMM-OLD-MO-DUR (WS-SUB).
018633     MOVE SPACES                TO LCOMM-OLD-DY-DUR (WS-SUB).

       1100-INIT-WS-WORK-X.
           EXIT.
      /
      *--------------------
       2000-PROCESS-REQUEST.
      *--------------------

023118*    SET  MIR-RETRN-OK      TO TRUE.
023118*    MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *  VALIDATE KEY FIELDS ENTERED, CHECK POLICY ACCESS
      *
           PERFORM  2100-VALIDATE-KEY-FIELDS
               THRU 2100-VALIDATE-KEY-FIELDS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

018633*    MOVE ZEROES                TO WS-CDAD-SEQ-NUM.
018633     MOVE ZEROES                TO LCOMM-CDAD-SEQ-NUM.
      *
      *  BUILD LPGA PARMS
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.


           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

023112*        WHEN WS-BUS-FCN-CREATE
023112*             PERFORM 4000-PROCESS-CREATE
023112*                THRU 4000-PROCESS-CREATE-X

023112*        WHEN WS-BUS-FCN-UPDATE
023112*             PERFORM 5000-PROCESS-UPDATE
023112*                THRU 5000-PROCESS-UPDATE-X

023112*        WHEN WS-BUS-FCN-DELETE
023112*             PERFORM 6000-PROCESS-DELETE
023112*                THRU 6000-PROCESS-DELETE-X

               WHEN WS-BUS-FCN-PRINT
                    PERFORM 3100-PROCESS-PRINT
                       THRU 3100-PROCESS-PRINT-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------------
       2100-VALIDATE-KEY-FIELDS.
      *-------------------------

      *
      *  CHECK POLICY EXISTS
      *
           PERFORM  7000-VALIDATE-POLICY
               THRU 7000-VALIDATE-POLICY-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

      *
      *  POLICY ACCESS VERIFICATION  (CONFIDENTIALITY, BRANCH)
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
012624*    SET L5400-CTL-MSG-NOT-REQD   TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD  TO TRUE.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  NOT L5400-RETRN-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

           PERFORM  7100-VALIDATE-CVG
               THRU 7100-VALIDATE-CVG-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

           PERFORM  7200-EDIT-EFF-DATE
               THRU 7200-EDIT-EFF-DATE-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

           PERFORM  7300-VALIDATE-SEQ-NUM
               THRU 7300-VALIDATE-SEQ-NUM-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2100-VALIDATE-KEY-FIELDS-X
           END-IF.

028805*    IF  WS-BUS-FCN-CREATE
028805*    OR  WS-BUS-FCN-UPDATE
028805*        PERFORM  2735-1000-BUILD-PARM-INFO
028805*            THRU 2735-1000-BUILD-PARM-INFO-X
028805*        MOVE  RPOL-POL-ID   TO L2735-POL-ID
028805*        PERFORM  2735-1000-GET-PRFL
028805*            THRU 2735-1000-GET-PRFL-X
028805*        IF L2735-RETRN-PRFL-FND
028805*MSG: THE DESTINATION DETAILS ENTERED MAY NOT MATCH THE
028805*     ALLOCATIONS DEFINED FOR THE INVESTOR PROFILE.
028805*           MOVE 'CS42500042'      TO WGLOB-MSG-REF-INFO
028805*           PERFORM  0260-1000-GENERATE-MESSAGE
028805*              THRU  0260-1000-GENERATE-MESSAGE-X
028805*
028805*            IF  WGLOB-MSG-SEVRTY-FATAL
028805*                SET WGLOB-RETURN-ERROR  TO TRUE
028805*                GO TO 2100-VALIDATE-KEY-FIELDS-X
028805*            END-IF
028805*
028805*        END-IF
028805*    END-IF.
028805*
       2100-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      *---------------------
       3000-PROCESS-RETRIEVE.
      *---------------------

014221     MOVE MIR-DEST-POL-ID-BASE  TO WPOL-POL-ID.
014221     MOVE MIR-DEST-POL-ID-SFX   TO WPOL-POL-ID-SFX.
014221
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  8000-BUILD-CDSA-KEY
               THRU 8000-BUILD-CDSA-KEY-X.

018633*    MOVE SPACES                TO WS-OLD-STAT-CD.
018633*    MOVE SPACES                TO WS-CURNT-STAT-CD.
018633     MOVE SPACES                TO LCOMM-OLD-STAT-CD.
018633     MOVE SPACES                TO LCOMM-CURNT-STAT-CD.

           PERFORM  1100-INIT-WS-WORK
               THRU 1100-INIT-WS-WORK-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-LINES.


           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.


           IF NOT WCDSA-IO-OK
      * MSG: RECORD NOT FOUND
               MOVE 'CS42500008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.

018633*    MOVE RCDSA-CDA-STAT-CD     TO WS-OLD-STAT-CD.
018633     MOVE RCDSA-CDA-STAT-CD     TO LCOMM-OLD-STAT-CD.

           PERFORM  9100-INIT-DATA-LINES
               THRU 9100-INIT-DATA-LINES-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-LINES

           PERFORM  8100-BUILD-CDSD-KEY
               THRU 8100-BUILD-CDSD-KEY-X.

           PERFORM  CDSD-1000-BROWSE
               THRU CDSD-1000-BROWSE-X.

           IF NOT WCDSD-IO-OK
      *
      * MOVE HEADER RECORD TO SCREEN ONLY
      *
               PERFORM  9200-MOVE-HDR-ONLY-TO-SCR
                   THRU 9200-MOVE-HDR-ONLY-TO-SCR-X
            ELSE
                PERFORM  CDSD-2000-READ-NEXT
                    THRU CDSD-2000-READ-NEXT-X
                PERFORM  9200-MOVE-HDR-ONLY-TO-SCR
                    THRU 9200-MOVE-HDR-ONLY-TO-SCR-X
                IF WCDSD-IO-EOF
                    PERFORM  CDSD-3000-END-BROWSE
                        THRU CDSD-3000-END-BROWSE-X
                ELSE
                     PERFORM  9230-MOVE-RECORDS-TO-SCREEN
                         THRU 9230-MOVE-RECORDS-TO-SCREEN-X
                         VARYING WS-SUB FROM 1 BY 1
                         UNTIL WS-SUB > WS-MAX-LINES
                         OR WCDSD-IO-EOF
                     PERFORM  CDSD-3000-END-BROWSE
                         THRU CDSD-3000-END-BROWSE-X
557660           END-IF
557660       END-IF.

013578*    IF RCDSA-CDA-STAT-HISTORY
013578* MSG:  CANNOT MAINTAIN HISTORY RECORDS
013578*        MOVE 'CS42500037'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        GO TO 3000-PROCESS-RETRIEVE-X
013578*    END-IF.

           IF RCDSA-CDA-STAT-ERROR
           OR RCDSA-CDA-STAT-REVERSED
           OR RCDSA-CDA-STAT-ACTIVE
               PERFORM  5130-CALC-ROLL-AMOUNT
                   THRU 5130-CALC-ROLL-AMOUNT-X
557660     END-IF.

           IF NOT WGLOB-GOOD-RETURN
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.


018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.


       3000-PROCESS-RETRIEVE-X.
           EXIT.

      /
      *-------------------
       3100-PROCESS-PRINT.
      *-------------------


016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           PERFORM  8000-BUILD-CDSA-KEY
               THRU 8000-BUILD-CDSA-KEY-X.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.
           IF NOT WCDSA-IO-OK
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3100-PROCESS-PRINT-X
           END-IF.

018633*    MOVE RCDSA-CDA-STAT-CD     TO WS-OLD-STAT-CD.
018633     MOVE RCDSA-CDA-STAT-CD     TO LCOMM-OLD-STAT-CD.

           PERFORM  5125-EDIT-DOCUMENT-ID
               THRU 5125-EDIT-DOCUMENT-ID-X.

           IF WGLOB-GOOD-RETURN
               PERFORM  5250-PROCESS-DOCUMENT-ID
                   THRU 5250-PROCESS-DOCUMENT-ID-X
           END-IF.

       3100-PROCESS-PRINT-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.


           PERFORM  8200-BUILD-BRWS-CDSA-KEY
               THRU 8200-BUILD-BRWS-CDSA-KEY-X.

           MOVE SPACES                TO MIR-DEST-SEQ-NUM.

           PERFORM  9150-INIT-BRWS-LINES
               THRU 9150-INIT-BRWS-LINES-X
               VARYING WS-LINE-SUB FROM 1 BY 1
               UNTIL WS-LINE-SUB > WS-MAX-LINES.

012696     PERFORM  CDSC-1000-BROWSE
012696         THRU CDSC-1000-BROWSE-X.

012696     IF WCDSC-IO-OK
012696         PERFORM  CDSC-2000-READ-NEXT
012696             THRU CDSC-2000-READ-NEXT-X
012696         IF WCDSC-IO-EOF
                   SET  WS-CDSA-ENDBR-NEEDED  TO TRUE
557660         END-IF
557660     END-IF.

012696     IF WCDSC-IO-OK
012696         PERFORM  CDSC-2000-READ-NEXT
012696             THRU CDSC-2000-READ-NEXT-X
023112*            UNTIL RCDSA-CDA-TYP-CD = 'A'
023112             UNTIL RCDSA-CDA-TYP-ROLOVR-PAYO
023112             OR RCDSA-CDA-TYP-ANTY
012696             OR WCDSC-IO-EOF
012696         IF WCDSC-IO-EOF
                   SET  WS-CDSA-ENDBR-NEEDED  TO TRUE
557660         END-IF
557660     END-IF.

012696*    IF NOT WCDSA-IO-OK
012696     IF NOT WCDSC-IO-OK
      * MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WS-CDSA-ENDBR-NEEDED
012696             PERFORM  CDSC-3000-END-BROWSE
012696                 THRU CDSC-3000-END-BROWSE-X
                   GO TO 3500-PROCESS-LIST-X
               ELSE
                   GO TO 3500-PROCESS-LIST-X
557660         END-IF
557660     END-IF.

           MOVE 1                     TO WS-LINE-SUB.
           MOVE SPACES                TO WS-PREV-DATE.
           MOVE SPACES                TO WS-PREV-COVNO.
           MOVE ZEROES                TO WS-PREV-SEQNO.
023112     MOVE ZEROES                TO WS-PREV-PAYO-NUM.

      *
      * HOLD FIRST RECORD VALUES TO DISPLAY IF < OR = MAX RECORDS
      *
           MOVE RCDSA-CVG-NUM         TO WS-HOLD-BROWSE-COVNO.
           MOVE RCDSA-CDA-EFF-IDT-NUM TO WS-HOLD-BROWSE-DATE.
           MOVE RCDSA-CDA-SEQ-NUM     TO WS-HOLD-BROWSE-SEQNO.

           PERFORM  3505-READ-UNTIL-NEW-REC
               THRU 3505-READ-UNTIL-NEW-REC-X
012696*        UNTIL NOT WCDSA-IO-OK
012696         UNTIL NOT WCDSC-IO-OK
               OR WS-LINE-SUB > WS-MAX-LINES.

012696*    IF WCDSA-IO-OK
012696     IF WCDSC-IO-OK
      * MSG:  TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RCDSA-CDA-EFF-IDT-NUM
                                      TO L1660-INVERTED-DATE
               PERFORM  1660-3000-CONVERT-INV-TO-INT
                   THRU 1660-3000-CONVERT-INV-TO-INT-X
               MOVE L1660-INTERNAL-DATE
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CDA-EFF-DT
020874*        COMPUTE WS-SEQ-NO2   =     1000 - RCDSA-CDA-SEQ-NUM
020874*        MOVE WS-SEQ-NO2            TO MIR-DEST-SEQ-NUM
020874         COMPUTE L0290-INPUT-V00  =  1000 - RCDSA-CDA-SEQ-NUM
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DEST-SEQ-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-DEST-SEQ-NUM
023112         COMPUTE L0290-INPUT-V00  =  100000 - RCDSA-POL-PAYO-NUM
023112         MOVE 0                     TO L0290-PRECISION
023112         MOVE LENGTH OF MIR-POL-PAYO-NUM
023112                                    TO L0290-MAX-OUT-LEN
023112         PERFORM 0290-2000-FORMAT-FOR-MIR
023112            THRU 0290-2000-FORMAT-FOR-MIR-X
023112         MOVE L0290-OUTPUT-DATA     TO MIR-POL-PAYO-NUM
               MOVE RCDSA-CVG-NUM         TO MIR-DEST-CVG-NUM
           ELSE
               IF WS-LINE-SUB > ZERO
                   MOVE WS-HOLD-BROWSE-DATE
                                      TO L1660-INVERTED-DATE
                   PERFORM  1660-3000-CONVERT-INV-TO-INT
                       THRU 1660-3000-CONVERT-INV-TO-INT-X
                   MOVE L1660-INTERNAL-DATE
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM  1640-8000-INTERNAL-TO-MIR
020462                 THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CDA-EFF-DT
020874*            COMPUTE WS-SEQ-NO2     = 1000 - WS-HOLD-BROWSE-SEQNO
020874*            MOVE WS-SEQ-NO2    TO MIR-DEST-SEQ-NUM
020874             COMPUTE L0290-INPUT-V00 = 1000 - WS-HOLD-BROWSE-SEQNO
020874             MOVE 0                     TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-DEST-SEQ-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-DEST-SEQ-NUM
                   MOVE WS-HOLD-BROWSE-COVNO
                                      TO MIR-DEST-CVG-NUM
      * MSG: END OF FILE
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

012696*    PERFORM  CDSA-3000-END-BROWSE
012696*        THRU CDSA-3000-END-BROWSE-X.
012696     PERFORM  CDSC-3000-END-BROWSE
012696         THRU CDSC-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.

      /
       3505-READ-UNTIL-NEW-REC.
      *
      * BROWSE UNTIL NEXT COV OR DATE OR SEQ
      *
           IF (RCDSA-CDA-SEQ-NUM         = WS-PREV-SEQNO
           AND RCDSA-CDA-EFF-IDT-NUM     = WS-PREV-DATE
023112     AND RCDSA-CVG-NUM             = WS-PREV-COVNO
023112     AND RCDSA-POL-PAYO-NUM        = WS-PREV-PAYO-NUM)
023112*    AND RCDSA-CVG-NUM             = WS-PREV-COVNO)
023112     OR (NOT RCDSA-CDA-TYP-ANTY
023112     AND NOT RCDSA-CDA-TYP-ROLOVR-PAYO)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  9250-MOVE-TO-BROWSE-SCREEN
                   THRU 9250-MOVE-TO-BROWSE-SCREEN-X
               MOVE RCDSA-CDA-SEQ-NUM TO WS-PREV-SEQNO
               MOVE RCDSA-CDA-EFF-IDT-NUM
                                      TO WS-PREV-DATE
               MOVE RCDSA-CVG-NUM     TO WS-PREV-COVNO
023112         MOVE RCDSA-POL-PAYO-NUM
023112                                TO WS-PREV-PAYO-NUM
               ADD 1                       TO WS-LINE-SUB
557660     END-IF.

           MOVE SPACES                TO RCDSA-CDA-TYP-CD.
012696*    PERFORM  CDSA-2000-READ-NEXT
012696     PERFORM  CDSC-2000-READ-NEXT
012696         THRU CDSC-2000-READ-NEXT-X
023112*        UNTIL RCDSA-CDA-TYP-CD = 'A'
023112         UNTIL RCDSA-CDA-TYP-ROLOVR-PAYO
023112         OR RCDSA-CDA-TYP-ANTY
012696         OR WCDSC-IO-EOF.

       3505-READ-UNTIL-NEW-REC-X.
           EXIT.
      /
      /
      *-------------------
028805*4000-PROCESS-CREATE.
      *-------------------
028805*
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
028805*    PERFORM  COMM-3000-DELETE-TWRK
028805*        THRU COMM-3000-DELETE-TWRK-X.
028805*
018633*    MOVE SPACES                TO WS-OLD-STAT-CD.
018633*    MOVE SPACES                TO WS-CURNT-STAT-CD.
028805*    MOVE SPACES                TO LCOMM-OLD-STAT-CD.
028805*    MOVE SPACES                TO LCOMM-CURNT-STAT-CD.
028805*
028805*    PERFORM  1100-INIT-WS-WORK
028805*        THRU 1100-INIT-WS-WORK-X
028805*        VARYING WS-SUB FROM 1 BY 1
028805*        UNTIL WS-SUB > WS-MAX-LINES.
028805*
028805*    PERFORM  4110-EDIT-KEY-FIELDS
028805*        THRU 4110-EDIT-KEY-FIELDS-X.
028805*
028805*    IF NOT WGLOB-GOOD-RETURN
028805*        GO TO 4000-PROCESS-CREATE-X
028805*    END-IF.
028805*
028805*    PERFORM  8000-BUILD-CDSA-KEY
028805*        THRU 8000-BUILD-CDSA-KEY-X.
028805*
028805*    PERFORM  CDSA-1000-BROWSE
028805*        THRU CDSA-1000-BROWSE-X.
      *
      *  FIND NEXT SEQUENCE NUMBER
      *
028805*    IF NOT WCDSA-IO-OK
028805*        MOVE +999              TO WCDSA-CDA-SEQ-NUM
018633*        MOVE +999              TO WS-CDAD-SEQ-NUM
028805*        MOVE +999              TO LCOMM-CDAD-SEQ-NUM
020874*        COMPUTE WS-SEQ-NO2     = 1000 - WCDSA-CDA-SEQ-NUM
020874*        MOVE WS-SEQ-NO2        TO MIR-DEST-SEQ-NUM
028805*        COMPUTE L0290-INPUT-V00 = 1000 - WCDSA-CDA-SEQ-NUM
028805*        MOVE 0                     TO L0290-PRECISION
028805*        MOVE LENGTH OF MIR-DEST-SEQ-NUM
028805*                                   TO L0290-MAX-OUT-LEN
028805*        PERFORM 0290-2000-FORMAT-FOR-MIR
028805*           THRU 0290-2000-FORMAT-FOR-MIR-X
028805*        MOVE L0290-OUTPUT-DATA     TO MIR-DEST-SEQ-NUM
028805*    ELSE
028805*        PERFORM  CDSA-2000-READ-NEXT
028805*            THRU CDSA-2000-READ-NEXT-X
028805*        IF WCDSA-IO-OK
028805*            PERFORM  4140-FIND-LOW-SEQ-NO
028805*                THRU 4140-FIND-LOW-SEQ-NO-X
028805*                UNTIL WCDSA-IO-EOF
028805*            PERFORM  CDSA-3000-END-BROWSE
028805*                THRU CDSA-3000-END-BROWSE-X
028805*            MOVE WCDSA-ENDBR-KEY
028805*                               TO WCDSA-KEY
028805*            COMPUTE WS-SEQ-NO      = WS-LOWEST-SEQ-NUM - 1
028805*            MOVE WS-SEQ-NO     TO WCDSA-CDA-SEQ-NUM
018633*            MOVE WS-SEQ-NO     TO WS-CDAD-SEQ-NUM
028805*            MOVE WS-SEQ-NO     TO LCOMM-CDAD-SEQ-NUM
020874*            COMPUTE WS-SEQ-NO2  = 1000 - WS-SEQ-NO
020874*            MOVE WS-SEQ-NO2    TO WS-PIC-999
020874*            MOVE WS-PIC-999    TO MIR-DEST-SEQ-NUM
028805*            COMPUTE L0290-INPUT-V00  =  1000 - WS-SEQ-NO
028805*            MOVE WS-SEQ-NO2            TO L0290-INPUT-V00
028805*            MOVE 0                     TO L0290-PRECISION
028805*            MOVE LENGTH OF MIR-DEST-SEQ-NUM
028805*                               TO L0290-MAX-OUT-LEN
028805*            PERFORM 0290-2000-FORMAT-FOR-MIR
028805*               THRU 0290-2000-FORMAT-FOR-MIR-X
028805*            MOVE L0290-OUTPUT-DATA     TO MIR-DEST-SEQ-NUM
028805*        ELSE
028805*            MOVE WCDSA-ENDBR-KEY
028805*                               TO WCDSA-KEY
028805*            MOVE +999          TO WCDSA-CDA-SEQ-NUM
018633*            MOVE +999          TO WS-CDAD-SEQ-NUM
028805*            MOVE +999          TO LCOMM-CDAD-SEQ-NUM
028805*            COMPUTE WS-SEQ-NO2     = 1000 - WCDSA-CDA-SEQ-NUM
028805*            MOVE WS-SEQ-NO2    TO MIR-DEST-SEQ-NUM
028805*            PERFORM  CDSA-3000-END-BROWSE
028805*                THRU CDSA-3000-END-BROWSE-X
028805*        END-IF
028805*    END-IF.
      *
      *  CDSA (HEADER RECORD) DOES NOT EXIST SO CREATE ONE
      *
028805*    PERFORM  CDSA-1000-CREATE
028805*        THRU CDSA-1000-CREATE-X.
      *
      *    READ CFLW FOR FIRST ACTIVE GIA WITH DATE SPECIFIED.
      *
028805*    SET  WS-SRCE-CF-NOT-FOUND  TO TRUE.
028805*
028805*    MOVE MIR-DEST-POL-ID-BASE  TO WCFLW-POL-ID-BASE.
028805*    MOVE MIR-DEST-POL-ID-SFX   TO WCFLW-POL-ID-SFX.
028805*    MOVE MIR-DEST-CVG-NUM      TO WCFLW-CVG-NUM.
028805*    MOVE WCVGS-CVG-CF-TYP-CD (WCFLW-CVG-NUM-N)
028805*                               TO WCFLW-CF-TYP-CD.
028805*    MOVE WCVGS-CVG-ISS-EFF-DT (WCFLW-CVG-NUM-N)
557659*                               TO WCFLW-CF-DT.
028805*                               TO WCFLW-CF-EFF-DT.
028805*    MOVE ZEROES                TO WCFLW-CF-SEQ-NUM-N.
028805*    MOVE WCFLW-KEY             TO WCFLW-ENDBR-KEY.
557659*    MOVE WWKDT-HIGH-DT         TO WCFLW-ENDBR-CF-DT.
028805*    MOVE WWKDT-HIGH-DT         TO WCFLW-ENDBR-CF-EFF-DT.
028805*    MOVE +999                  TO WCFLW-ENDBR-CF-SEQ-NUM.
028805*
028805*    PERFORM  CFLW-1000-BROWSE
028805*        THRU CFLW-1000-BROWSE-X.
028805*    IF  WCFLW-IO-OK
028805*        PERFORM  CFLW-2000-READ-NEXT
028805*            THRU CFLW-2000-READ-NEXT-X
028805*        PERFORM  4120-FIND-CFLW-GIA
028805*            THRU 4120-FIND-CFLW-GIA-X
028805*            UNTIL WS-SRCE-CF-FOUND
028805*            OR WCFLW-IO-EOF
028805*    ELSE
      * MSG: NO CFLW RECORD FOUND
028805*        MOVE 'CS42500001'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*    END-IF.
028805*
028805*    IF WS-SRCE-CF-NOT-FOUND
028805*        PERFORM  CFLW-3000-END-BROWSE
028805*            THRU CFLW-3000-END-BROWSE-X
      * MSG: NO CFLW RECORD FOUND
028805*        MOVE 'CS42500001'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        GO TO 4000-PROCESS-CREATE-X
028805*    END-IF.
028805*
028805*    SET  RCDSA-CDA-STAT-ERROR TO TRUE.
023112*    SET  RCDSA-CDA-CREAT-MANUALLY  TO TRUE.
028805*    MOVE L1640-INTERNAL-DATE   TO RCDSA-CDA-EFF-DT.
      *
      *  CALCULATE ROLL AMOUNT (TOT-TRX-AMT)
      *
028805*    PERFORM  5600-CALCULATE-ROLL-AMOUNT
028805*        THRU 5600-CALCULATE-ROLL-AMOUNT-X.
028805*
028805*    PERFORM  4160-CALC-ORG-LTR-AMT
028805*        THRU 4160-CALC-ORG-LTR-AMT-X.
028805*
028805*    PERFORM  CDSA-1000-WRITE
028805*        THRU CDSA-1000-WRITE-X.
028805*
028805*    MOVE MIR-DEST-POL-ID-BASE  TO WPOL-POL-ID.
028805*    MOVE MIR-DEST-POL-ID-SFX   TO WPOL-POL-ID-SFX.
028805*
028805*    PERFORM  POL-1000-READ-TWRK-TS
028805*        THRU POL-1000-READ-TWRK-TS-X.
028805*
028805*    PERFORM  9100-INIT-DATA-LINES
028805*        THRU 9100-INIT-DATA-LINES-X
028805*        VARYING WS-SUB FROM 1 BY 1
028805*        UNTIL WS-SUB > WS-MAX-LINES.
028805*
028805*    PERFORM  9200-MOVE-HDR-ONLY-TO-SCR
028805*        THRU 9200-MOVE-HDR-ONLY-TO-SCR-X.
028805*
028805*4000-PROCESS-CREATE-X.
028805*    EXIT.
      /
028805*
028805*4110-EDIT-KEY-FIELDS.
028805*
028805*    MOVE MIR-DEST-CVG-NUM      TO WS-CVG.
      *
      *  CREATE NOT ALLOWED ON DIA COVERAGE
      *
028805*    IF WCVGS-CVG-CF-TYP-DIA (WS-CVG)
      * MSG: CREATE NOT ALLOWED FOR DIA COVERAGE
028805*        MOVE 'CS42500002'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        MOVE 1                 TO WGLOB-RETURN-CODE
028805*        GO TO 4110-EDIT-KEY-FIELDS-X
028805*    END-IF.
      *
      *  EFFECTIVE DATE MUST BE EQUAL TO NEXT ROLLOVER DATE FOR THIS
      *  COVERAGE
      *  IF NEXT ROLLOVER DATE = ZERO DATE NO CASHFLOW EXISTS AND A
      *  CREATE IS NOT POSSIBLE
      *
028805*    IF WCVGS-CVG-NXT-ROLOVR-DT (WS-CVG)  = WWKDT-ZERO-DT
      * MSG:  NO CASHFLOWS EXIST FOR THIS COVERAGE
028805*        MOVE 'CS42500003'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        MOVE 1                 TO WGLOB-RETURN-CODE
028805*        GO TO 4110-EDIT-KEY-FIELDS-X
028805*    END-IF.
028805*
028805*    IF WS-INTERNAL-EFFDT NOT = WCVGS-CVG-NXT-ROLOVR-DT (WS-CVG)
      * MSG:  EFFECTIVE DATE MUST BE = TO ROLLOVER DATE
028805*        MOVE 'CS42500004'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        MOVE 1                 TO WGLOB-RETURN-CODE
028805*        GO TO 4110-EDIT-KEY-FIELDS-X
028805*    END-IF.
      *
      *  EDIT ROLLOVER CODE FOR SOURCE COVERAGE
      *  ALSO STORE THE ROLLOVER TYPE CODE TO DO
      *  GUARANTEED INT RATE INDICATOR FOR LATER TESTING
      *
028805*    MOVE WS-CVG                TO I.
028805*    PERFORM  PLIN-1000-PLAN-HEADER-IN
028805*        THRU PLIN-1000-PLAN-HEADER-IN-X.
028805*    IF WPH-IO-OK
028805*        MOVE RPH-PLAN-ROLOVR-TYP-CD
018633*                               TO WS-SRC-CVG-ROL-TYP-CD
028805*                               TO LCOMM-SRC-CVG-ROL-TYP-CD
028805*        IF RPH-PLAN-ROLOVR-TO-DIA
      * MSG:  CANNOT CREATE - PLAN ROLLOVER CODE = 'T'
028805*            MOVE 'CS42500005'  TO WGLOB-MSG-REF-INFO
028805*            PERFORM  0260-1000-GENERATE-MESSAGE
028805*                THRU 0260-1000-GENERATE-MESSAGE-X
028805*            MOVE 1             TO WGLOB-RETURN-CODE
028805*            GO TO 4110-EDIT-KEY-FIELDS-X
028805*        END-IF
557660*        ELSE
557660*            NEXT SENTENCE
028805*    ELSE
      * MSG: PLAN NOT FOUND
028805*        MOVE 'CS42500033'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        MOVE 1                 TO WGLOB-RETURN-CODE
028805*    END-IF.
      *
      *  ENTRY OF SEQUENCE NUMBER NOT ALLOWED ON CREATE
      *
028805*    IF MIR-DEST-SEQ-NUM > SPACES
      *        MSG: SEQUENCE NUMBER DEFAULTED FOR CREATE
028805*        MOVE 'CS42500006'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        MOVE '000'             TO MIR-DEST-SEQ-NUM
028805*    END-IF.
028805*
028805*4110-EDIT-KEY-FIELDS-X.
028805*    EXIT.
      /
028805*4120-FIND-CFLW-GIA.
028805*
028805*    IF (RCFLW-CF-STAT-ACTIVE
028805*    OR  RCFLW-CF-STAT-PARTL-SURR)
028805*        CONTINUE
028805*    ELSE
028805*        PERFORM  CFLW-2000-READ-NEXT
028805*            THRU CFLW-2000-READ-NEXT-X
028805*        GO TO 4120-FIND-CFLW-GIA-X
028805*    END-IF.
028805*
028805*    IF RCFLW-ROLOVR-CF-DT = WS-INTERNAL-EFFDT
028805*      IF RCFLW-DEST-CDA-SEQ-NUM = ZEROES
028805*          PERFORM  CFLW-3000-END-BROWSE
028805*              THRU CFLW-3000-END-BROWSE-X
028805*          PERFORM  CFLW-1000-READ-FOR-UPDATE
028805*              THRU CFLW-1000-READ-FOR-UPDATE-X
018633*          MOVE WS-CDAD-SEQ-NUM
028805*          MOVE LCOMM-CDAD-SEQ-NUM
028805*                               TO RCFLW-DEST-CDA-SEQ-NUM
028805*          PERFORM  CFLW-2000-REWRITE
028805*              THRU CFLW-2000-REWRITE-X
028805*          MOVE RCFLW-CVG-NUM   TO RCDSA-CVG-NUM
028805*          MOVE RCFLW-CF-TYP-CD TO RCDSA-SRC-CF-TYP-CD
028805*          MOVE 'A'             TO RCDSA-SRC-CF-TYP-CD
557659*          MOVE RCFLW-CF-DT            TO RCDSA-SRC-CF-EFF-DT
028805*          MOVE RCFLW-CF-EFF-DT TO RCDSA-SRC-CF-EFF-DT
028805*          MOVE RCFLW-CF-SEQ-NUM-N
028805*                               TO RCDSA-SRC-CF-SEQ-NUM
028805*          SET  WS-SRCE-CF-FOUND       TO TRUE
028805*          GO TO 4120-FIND-CFLW-GIA-X
028805*        END-IF
028805*    END-IF.
028805*
028805*    PERFORM  CFLW-2000-READ-NEXT
028805*        THRU CFLW-2000-READ-NEXT-X.
028805*
028805*4120-FIND-CFLW-GIA-X.
028805*    EXIT.
      /
028805*4140-FIND-LOW-SEQ-NO.
028805*
028805*    IF RCDSA-CDA-SEQ-NUM < WS-LOWEST-SEQ-NUM
028805*        MOVE RCDSA-CDA-SEQ-NUM TO WS-LOWEST-SEQ-NUM
028805*    END-IF.
028805*
028805*    PERFORM  CDSA-2000-READ-NEXT
028805*        THRU CDSA-2000-READ-NEXT-X.
028805*
028805*4140-FIND-LOW-SEQ-NO-X.
028805*    EXIT.
028805*
028805*4160-CALC-ORG-LTR-AMT.
      *
      *  GIA - USE TOTAL AMT; DIA - MAKE IT ZERO
      *
028805*    MOVE MIR-DEST-CVG-NUM      TO WS-CVG-SUB.
023112*    IF WCVGS-CVG-CF-TYP-DIA (WS-CVG-SUB)
023112*        MOVE ZEROES            TO MIR-CDA-ROLOVR-LTR-AMT
023112*    ELSE
023112*        MOVE RCDSA-CDA-TOT-TRXN-AMT
023112*                               TO
023112*                                     RCDSA-CDA-ROLOVR-LTR-AMT
008455*        MOVE RCDSA-CDA-TOT-TRXN-AMT    TO WS-N-9-2
008455*        MOVE WS-N-9-2                  TO WS-PIC-9-2
008455*        MOVE WS-PIC-9-2                TO MIR-CDA-ROLOVR-LTR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RCDSA-CDA-TOT-TRXN-AMT  * 100
023112*        MOVE RCDSA-CDA-TOT-TRXN-AMT    TO L0290-INPUT-V02
023112*        MOVE 2                 TO L0290-PRECISION
023112*        MOVE LENGTH OF MIR-CDA-ROLOVR-LTR-AMT
023112*                               TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
023112*        PERFORM 0290-2000-FORMAT-FOR-MIR
023112*           THRU 0290-2000-FORMAT-FOR-MIR-X
023112*        MOVE L0290-OUTPUT-DATA TO MIR-CDA-ROLOVR-LTR-AMT
023112*    END-IF.
028805*
028805*4160-CALC-ORG-LTR-AMT-X.
028805*    EXIT.
      /
      /
       4250-RESET-SCREEN.

           IF NOT WS-EDIT-THIS-LINE (WS-SUB)
                MOVE SPACES           TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                MOVE SPACES           TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                MOVE SPACES           TO MIR-CDAD-TRXN-AMT-T (WS-SUB)
023112*         MOVE SPACES         TO MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB)
557660      END-IF.

       4250-RESET-SCREEN-X.
           EXIT.
      /
      *--------------------
028805*5000-PROCESS-UPDATE.
      *---------------------
028805*
028805*    MOVE MIR-DEST-POL-ID-BASE  TO WPOL-POL-ID-BASE.
028805*    MOVE MIR-DEST-POL-ID-SFX   TO WPOL-POL-ID-SFX.
028805*
028805*    PERFORM  POL-2000-UPDATE-TWRK-TS
028805*        THRU POL-2000-UPDATE-TWRK-TS-X.
028805*
028805*    IF  WPOL-IO-NOT-FOUND
014221*MSG:  'POLICY NOT ON POLICY FILE'
028805*        MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
028805*        MOVE WPOL-POL-ID       TO WGLOB-MSG-PARM (01)
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        GO TO 5000-PROCESS-UPDATE-X
028805*    END-IF.
028805*
028805*    IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
028805*        MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
028805*        MOVE 'POL'             TO WGLOB-MSG-PARM (01)
028805*        MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        GO TO 5000-PROCESS-UPDATE-X
028805*    END-IF.
028805*
018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
028805*    PERFORM  COMM-1000-RETRIEVE-TWRK
028805*        THRU COMM-1000-RETRIEVE-TWRK-X.
028805*
018633*    IF  L8090-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT  TO WS-WORK-AREA
018633*    END-IF.
018633*
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
028805*    PERFORM  COMM-3000-DELETE-TWRK
028805*        THRU COMM-3000-DELETE-TWRK-X.
028805*
012696*    PERFORM  8000-BUILD-CDSA-KEY
012696*        THRU 8000-BUILD-CDSA-KEY-X.
028805*
028805*    PERFORM  8300-BUILD-ALT-CDSA-KEY
028805*        THRU 8300-BUILD-ALT-CDSA-KEY-X.
028805*
012696*    PERFORM  CDSA-1000-BROWSE
012696*        THRU CDSA-1000-BROWSE-X.
028805*
028805*    PERFORM  CDSC-1000-BROWSE
028805*        THRU CDSC-1000-BROWSE-X.
028805*
028805*
028805*    IF WCDSC-IO-OK
028805*        PERFORM  CDSC-2000-READ-NEXT
028805*            THRU CDSC-2000-READ-NEXT-X
028805*        IF WCDSC-IO-EOF
028805*            SET  WS-CDSA-ENDBR-NEEDED  TO TRUE
028805*        ELSE
028805*            PERFORM  CDSC-3000-END-BROWSE
028805*                THRU CDSC-3000-END-BROWSE-X
028805*        END-IF
028805*    END-IF.
028805*
012696*    IF NOT WCDSA-IO-OK
028805*    IF NOT WCDSC-IO-OK
      * MSG:  RECORD NOT FOUND
028805*        MOVE 'CS42500008'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        IF WS-CDSA-ENDBR-NEEDED
028805*            PERFORM  CDSC-3000-END-BROWSE
028805*                THRU CDSC-3000-END-BROWSE-X
028805*            PERFORM  POL-3000-UNLOCK
028805*                THRU POL-3000-UNLOCK-X
028805*            GO TO 5000-PROCESS-UPDATE-X
028805*        ELSE
028805*            PERFORM  POL-3000-UNLOCK
028805*                THRU POL-3000-UNLOCK-X
028805*            GO TO 5000-PROCESS-UPDATE-X
028805*        END-IF
028805*    END-IF.
028805*
028805*    IF RCDSA-CDA-STAT-HISTORY
013578* MSG:  CANNOT MAINTAIN HISTORY RECORDS
028805*        MOVE 'CS42500037'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        PERFORM  POL-3000-UNLOCK
028805*            THRU POL-3000-UNLOCK-X
028805*        GO TO 5000-PROCESS-UPDATE-X
028805*    END-IF.
028805*
028805*    PERFORM  9130-INIT-WS
028805*        THRU 9130-INIT-WS-X
028805*        VARYING WS-SUB FROM 1 BY 1
028805*        UNTIL WS-SUB > WS-MAX-LINES.
028805*
028805*    MOVE ZEROES                TO       WS-TOTAL-DEP-AMT.
028805*
028805*    IF NOT WGLOB-GOOD-RETURN
028805*        PERFORM  POL-3000-UNLOCK
028805*            THRU POL-3000-UNLOCK-X
028805*        GO TO 5000-PROCESS-UPDATE-X
028805*    END-IF.
028805*
028805*    PERFORM  5210-CHECK-EACH-LINE
028805*        THRU 5210-CHECK-EACH-LINE-X
028805*        VARYING WS-SUB FROM 1 BY 1
028805*        UNTIL  WS-SUB > WS-MAX-LINES.
028805*
028805*    PERFORM  5300-EDIT-SCREEN-DATA
028805*        THRU 5300-EDIT-SCREEN-DATA-X
028805*        VARYING WS-SUB FROM 1 BY 1
028805*        UNTIL WS-SUB > WS-MAX-LINES.
028805*
028805*    PERFORM  5225-CHECK-DEPOSIT-CHG
028805*        THRU 5225-CHECK-DEPOSIT-CHG-X
028805*        VARYING WS-SUB FROM 1 BY 1
028805*        UNTIL WS-SUB > WS-MAX-LINES.
028805*
028805*    IF WGLOB-GOOD-RETURN
028805*        PERFORM  5400-CROSS-EDITS
028805*            THRU 5400-CROSS-EDITS-X
028805*            VARYING WS-SUB FROM 1 BY 1
028805*            UNTIL WS-SUB > WS-MAX-LINES
028805*    END-IF.
028805*
028805*    PERFORM  5420-DEP-AMT-TOTAL-EDIT
028805*        THRU 5420-DEP-AMT-TOTAL-EDIT-X.
028805*
028805*    IF WGLOB-GOOD-RETURN
023112*        SET  RCDSA-CDA-CREAT-MANUALLY  TO TRUE
028805*        PERFORM  CDSA-2000-REWRITE
028805*            THRU CDSA-2000-REWRITE-X
028805*    END-IF.
      *
      * DETERMINE HIGHEST ALLOC-NUM
      *
028805*    PERFORM  5220-DETER-HIGH-ALLOC
028805*        THRU 5220-DETER-HIGH-ALLOC-X
028805*        VARYING WS-SUB FROM 1 BY 1
028805*        UNTIL WS-SUB > WS-MAX-LINES.
028805*
028805*    PERFORM  5210-CHECK-EACH-LINE
028805*        THRU 5210-CHECK-EACH-LINE-X
028805*        VARYING WS-SUB FROM 1 BY 1
028805*        UNTIL  WS-SUB > WS-MAX-LINES.
028805*
028805*    IF WGLOB-GOOD-RETURN
018633*        MOVE 'A'               TO WS-CURNT-STAT-CD
028805*        MOVE 'A'               TO LCOMM-CURNT-STAT-CD
028805*        PERFORM  5500-EDIT-FOR-WRITE-REWRITE
028805*            THRU 5500-EDIT-FOR-WRITE-REWRITE-X
028805*            VARYING WS-SUB FROM 1 BY 1
028805*            UNTIL WS-SUB > WS-MAX-LINES
028805*    END-IF.
028805*
028805*    IF WS-SEND-RENEWAL-MSG
      * MSG: VALUES CHANGED - A NEW RENEWAL LETTER MAY BE APPROPRIATE
028805*        MOVE 'CS42500032'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*    END-IF.
028805*
028805*    IF WGLOB-GOOD-RETURN
028805*        MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
      * MSG: MAINTENANCE COMPLETE
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        PERFORM  4250-RESET-SCREEN
028805*            THRU 4250-RESET-SCREEN-X
028805*            VARYING WS-SUB FROM 1 BY 1
028805*            UNTIL WS-SUB > WS-MAX-LINES
028805*        PERFORM  POL-2000-REWRITE
028805*            THRU POL-2000-REWRITE-X
028805*        PERFORM  POL-1000-READ-TWRK-TS
028805*            THRU POL-1000-READ-TWRK-TS-X
028805*    ELSE
      * MSG: ALL ERRORS MUST BE CORRECTED BEFORE RECORDS CAN BE WRITTEN
028805*        MOVE 'E'               TO MIR-CDA-STAT-CD
018633*        MOVE 'E'               TO WS-CURNT-STAT-CD
028805*        MOVE 'E'               TO LCOMM-CURNT-STAT-CD
028805*        MOVE 'CS42500007'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        PERFORM  POL-3000-UNLOCK
028805*            THRU POL-3000-UNLOCK-X
028805*    END-IF.
028805*
028805*    PERFORM  9200-MOVE-HDR-ONLY-TO-SCR
028805*        THRU 9200-MOVE-HDR-ONLY-TO-SCR-X.
028805*
018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
028805*    PERFORM  COMM-2000-WRITE-TWRK
028805*        THRU COMM-2000-WRITE-TWRK-X.
028805*
028805*
028805*5000-PROCESS-UPDATE-X.
028805*    EXIT.
028805*
      /
007685*5125-EDIT-LETTER-REASON.
007685 5125-EDIT-DOCUMENT-ID.

007685*    IF MIR-LETRSN = SPACES
007685*        GO TO 5125-EDIT-LETTER-REASON-X
007685     IF MIR-DOC-ID = SPACES
007685         GO TO 5125-EDIT-DOCUMENT-ID-X
557660     END-IF.

           IF NOT WS-BUS-FCN-PRINT
007685*        MOVE SPACES         TO MIR-LETRSN
007685* MSG: LETTER REQUEST ALLOWED FROM INQUIRE FUNCTION ONLY
007685         MOVE SPACES            TO MIR-DOC-ID
007685* MSG: LETTER DOCUMENT REQUEST ALLOWED FROM INQUIRE FUNCTION ONLY
               MOVE 'CS42500038'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
007685*        GO TO 5125-EDIT-LETTER-REASON-X
007685         GO TO 5125-EDIT-DOCUMENT-ID-X
557660     END-IF.

007685*    MOVE MIR-LETRSN           TO WEDIT-ETBL-VALU-ID.
007685*    PERFORM  FRMT-1000-EDIT
007685*        THRU FRMT-1000-EDIT-X.
007685*    IF NOT WEDIT-IO-OK
007685* MSG: LETTER RSN MUST BE ON EDIT PFFRM

007685     MOVE MIR-DOC-ID            TO WDOCM-DOC-ID.
023447*    MOVE WGLOB-EDIT-LANG       TO WDOCM-DOC-LANG-CD.
007685
007685     PERFORM  DOCM-1000-READ
007685         THRU DOCM-1000-READ-X.
007685
007685     IF NOT WDOCM-IO-OK
007685* MSG: DOCUMENT ID MUST EXIST ON DOCM
               MOVE 'CS42500009'      TO WGLOB-MSG-REF-INFO
007685*        MOVE TATRB-DATA-ERROR TO MIR-LETRSN-A
               MOVE 1                 TO WGLOB-RETURN-CODE
007685*        MOVE -1               TO MIR-LETRSN-L
               MOVE 'E'               TO MIR-CDA-STAT-CD
018633*        MOVE 'E'               TO WS-CURNT-STAT-CD
018633         MOVE 'E'               TO LCOMM-CURNT-STAT-CD
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
018633*        MOVE WS-OLD-STAT-CD TO MIR-CDA-STAT-CD
018633         MOVE LCOMM-OLD-STAT-CD TO MIR-CDA-STAT-CD
557660     END-IF.

007685*5125-EDIT-LETTER-REASON-X.
007685 5125-EDIT-DOCUMENT-ID-X.
           EXIT.
      /
       5130-CALC-ROLL-AMOUNT.

           PERFORM  5421-READ-ROLL-CASHFLOW
               THRU 5421-READ-ROLL-CASHFLOW-X
           IF NOT WGLOB-GOOD-RETURN
               GO TO 5130-CALC-ROLL-AMOUNT-X
           ELSE
               PERFORM  5600-CALCULATE-ROLL-AMOUNT
                   THRU 5600-CALCULATE-ROLL-AMOUNT-X
008455*        MOVE RCDSA-CDA-TOT-TRXN-AMT  TO WS-N-9-2
008455*        MOVE WS-N-9-2                TO WS-PIC-9-2
008455*        MOVE WS-PIC-9-2              TO MIR-CDA-TOT-TRXN-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RCDSA-CDA-TOT-TRXN-AMT  * 100
020874         MOVE RCDSA-CDA-TOT-TRXN-AMT  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CDA-TOT-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CDA-TOT-TRXN-AMT
               PERFORM  CDSA-3000-UNLOCK
                   THRU CDSA-3000-UNLOCK-X
557660     END-IF.

       5130-CALC-ROLL-AMOUNT-X.
           EXIT.
      /
       5210-CHECK-EACH-LINE.

008455     SET  L0280-SIGN-NOT-PERMITTED         TO TRUE.
008455     MOVE 2                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-CDAD-TRXN-AMT-T(WS-SUB)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
008455     MOVE MIR-CDAD-TRXN-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA.

008455     PERFORM  0280-1000-NUMERIC-EDIT
008455         THRU 0280-1000-NUMERIC-EDIT-X.

008455     IF  L0280-OK
008455         COMPUTE WS-N-13-2 = L0280-OUTPUT-DOLLAR  * 100
014035     END-IF.

           IF MIR-DEST-CVG-NUM-T (WS-SUB)  = SPACES AND
              MIR-DPOS-TRM-MO-DUR-T (WS-SUB)  = '000' AND
              MIR-DPOS-TRM-DY-DUR-T (WS-SUB)  = '000' AND
008455*       MIR-CDAD-TRXN-AMT-T (WS-SUB)  = '000000000.00' AND
023112       (L0280-OK AND WS-N-13-2 = ZERO)
023112*      (L0280-OK AND WS-N-13-2 = ZERO) AND
023112*       MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB)  = '000.0000'
               SET WS-NO-EDIT-THIS-LINE (WS-SUB) TO TRUE
           ELSE
               SET WS-EDIT-THIS-LINE(WS-SUB)     TO TRUE
           END-IF.

       5210-CHECK-EACH-LINE-X.
           EXIT.
      /
       5220-DETER-HIGH-ALLOC.

018633*    IF WS-CDAD-ALLOC-NUM (WS-SUB) > WS-HIGHEST-ALLOC-NUM
018633*        MOVE WS-CDAD-ALLOC-NUM (WS-SUB)
018633     IF LCOMM-CDAD-ALLOC-NUM (WS-SUB) > WS-HIGHEST-ALLOC-NUM
018633         MOVE LCOMM-CDAD-ALLOC-NUM (WS-SUB)
                                      TO WS-HIGHEST-ALLOC-NUM
557660     END-IF.
       5220-DETER-HIGH-ALLOC-X.
           EXIT.
      /
       5225-CHECK-DEPOSIT-CHG.

           IF WS-NO-EDIT-THIS-LINE (WS-SUB)
               GO TO 5225-CHECK-DEPOSIT-CHG-X
557660     END-IF.

018633*    IF WS-DEP-AMT (WS-SUB)     NOT = WS-OLD-DEP-AMT (WS-SUB)
018633     IF WS-DEP-AMT (WS-SUB)     NOT = LCOMM-OLD-DEP-AMT (WS-SUB)
           OR MIR-DPOS-TRM-MO-DUR-T (WS-SUB)  NOT =
018633*                                      WS-OLD-MO-DUR (WS-SUB)
018633                                       LCOMM-OLD-MO-DUR (WS-SUB)
           OR MIR-DPOS-TRM-DY-DUR-T (WS-SUB)  NOT =
018633*                                      WS-OLD-DY-DUR (WS-SUB)
018633                                       LCOMM-OLD-DY-DUR (WS-SUB)

      * MSG:  DEPOSIT AMT OR TERM CHG FOR (@1) - GTD RATE MAY
      * NEED CHANGE (INFORMATIONAL ONLY)
               MOVE 'CS42500039'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5225-CHECK-DEPOSIT-CHG-X.
           EXIT.
      /
007685*5250-PROCESS-LETTER-REASON.
007685 5250-PROCESS-DOCUMENT-ID.

007685*    IF MIR-LETRSN = SPACES
007685*        GO TO 5250-PROCESS-LETTER-REASON-X
007685     IF MIR-DOC-ID = SPACES
007685         GO TO 5250-PROCESS-DOCUMENT-ID-X
557660     END-IF.

007685*    PERFORM  5206-1000-BUILD-PARM-INFO
007685*        THRU 5206-1000-BUILD-PARM-INFO-X.
007685*    MOVE MIR-LETRSN                   TO L5206-LETTER-RSN-CD.
007685*    MOVE RCDSA-CVG-NUM                TO L5206-COVERAGE.
007685*    MOVE RCDSA-CDA-EFF-DT             TO L5206-EFF-DT.
007685*    MOVE RCDSA-CDA-SEQ-NUM            TO L5206-CF-SEQ-NUM.
007685*    PERFORM  5206-2000-WRITE-LETTER
007685*        THRU 5206-2000-WRITE-LETTER-X.

007685     PERFORM  0303-1000-BUILD-PARM-INFO
007685         THRU 0303-1000-BUILD-PARM-INFO-X.

007685     SET L0303-TRNXT-TYP-MISC-PRT TO TRUE.

007685     MOVE RPOL-POL-ID           TO L0303-POL-ID.
012624*    MOVE RPOL-POL-APPL-CTL-CD  TO L0303-APPL-ID.
010418     MOVE RPOL-SBSDRY-CO-ID     TO L0303-SBSDRY-CO-ID.

007685     MOVE MIR-DOC-ID            TO L0303-DOC-ID.
007685     MOVE RCDSA-CVG-NUM         TO L0303-CVG-NUM.
007685     MOVE RCDSA-CDA-EFF-DT      TO L0303-TRNXT-TRXN-EFF-DT.
007685     MOVE RCDSA-CDA-SEQ-NUM     TO L0303-TRNXT-TRXN-SEQ-NUM.
016457
023447*    MOVE +1                    TO L0303-TRNXT-DOC-CPY-QTY-N.
016457     SET L0303-TRNXT-PRT-REASN-RQST
016457                                TO TRUE.
023447     MOVE MIR-DV-RAPD-PRT-RQST-IND
023447                                TO L0303-DV-RAPD-PRT-RQST-IND.

007685     PERFORM  0303-1000-WRITE-PRTX-TRAN
007685         THRU 0303-1000-WRITE-PRTX-TRAN-X.

      * MSG: LETTER (@1) HAS BEEN REQUESTED
           MOVE 'CS42500010'          TO WGLOB-MSG-REF-INFO.
007685*    MOVE MIR-LETRSN           TO WGLOB-MSG-PARM (1).
007685     MOVE MIR-DOC-ID            TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
007685*    MOVE SPACES               TO MIR-LETRSN.
007685     MOVE SPACES                TO MIR-DOC-ID.

007685*5250-PROCESS-LETTER-REASON-X.
007685 5250-PROCESS-DOCUMENT-ID-X.
           EXIT.
      /
       5300-EDIT-SCREEN-DATA.

           IF WS-NO-EDIT-THIS-LINE (WS-SUB)
               GO TO 5300-EDIT-SCREEN-DATA-X
557660     END-IF.

           IF MIR-DEST-CVG-NUM-T (WS-SUB) = EBLCH-BLANK-FIELD-GROUP
028805*        IF WS-BUS-FCN-CREATE
028805*            SET WS-NO-EDIT-THIS-LINE (WS-SUB) TO TRUE
028805*            PERFORM  9400-BLANK-DATA-LINES
028805*                THRU 9400-BLANK-DATA-LINES-X
028805*            GO TO 5300-EDIT-SCREEN-DATA-X
028805*        ELSE
028805*            SET WS-NO-EDIT-THIS-LINE (WS-SUB) TO TRUE
028805*            GO TO 5300-EDIT-SCREEN-DATA-X
028805*        END-IF
028805         SET WS-NO-EDIT-THIS-LINE (WS-SUB) TO TRUE
028805         GO TO 5300-EDIT-SCREEN-DATA-X
557660     END-IF.

           PERFORM  5310-EDIT-DEST-CVG
               THRU 5310-EDIT-DEST-CVG-X.

           IF WS-DEST-CVG-NOT-VALID (WS-SUB)
               GO TO 5300-EDIT-SCREEN-DATA-X
557660     END-IF.

           PERFORM  5320-EDIT-DEP-MTH
               THRU 5320-EDIT-DEP-MTH-X.

           PERFORM  5330-EDIT-DEP-DAY
               THRU 5330-EDIT-DEP-DAY-X.

           PERFORM  5340-EDIT-DEP-TERM
               THRU 5340-EDIT-DEP-TERM-X.

           PERFORM  5350-EDIT-AMOUNT
               THRU 5350-EDIT-AMOUNT-X.

023112*    PERFORM  5360-EDIT-INT-RATE
023112*        THRU 5360-EDIT-INT-RATE-X.

       5300-EDIT-SCREEN-DATA-X.
           EXIT.
      /
       5310-EDIT-DEST-CVG.

           SET  WS-DEST-CVG-NOT-VALID (WS-SUB) TO TRUE.

           IF MIR-DEST-CVG-NUM-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
      * MSG: '*' NOT VALID IN DESTINATION COVERAGE FIELD
               MOVE 'CS42500011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5310-EDIT-DEST-CVG-X
557660     END-IF.

557660     IF MIR-DEST-CVG-NUM-T (WS-SUB) =  ZEROES
557660     OR MIR-DEST-CVG-NUM-T (WS-SUB) =  SPACES
      * MSG: DEST CVG NUMBER MUST BE > 0
               MOVE 'CS42500012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5310-EDIT-DEST-CVG-X
557660     END-IF.

           MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WS-HOLD-COVNO-R.
           IF WS-HOLD-COVNO-R NOT NUMERIC
           OR WS-HOLD-COVNO < 1
007766*    OR WS-HOLD-COVNO > 20
007766     OR WS-HOLD-COVNO > WCVGM-MAX-WCVGS-NUM
007766* MSG: COVERAGE NUMBER MUST BE 2 DIGITS FROM 01-20
007766* MSG: COVERAGE NUMBER MUST BE 2 DIGITS FROM 01-@1
               MOVE 'CS42500034'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5310-EDIT-DEST-CVG-X
557660     END-IF.

           MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WS-CVG.
      *
      *  MAKE SURE COVERAGE EXISTS
      *
           IF WS-HOLD-COVNO  > RPOL-POL-CVG-REC-CTR-N
      * MSG: CVG (@1) DOES NOT EXIST
               MOVE 'CS42500013'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5310-EDIT-DEST-CVG-X
557660     END-IF.

           IF WCVGS-CVG-STAT-IN-FORCE (WS-CVG)
           OR WCVGS-CVG-STAT-PENDING (WS-CVG)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      * MSG: DESTINATION COVERAGE (@1) MUST BE INFORCE OR PENDING
               MOVE 'CS42500014'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5310-EDIT-DEST-CVG-X
557660     END-IF.

           IF WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
           OR WCVGS-CVG-INS-TYP-FPA (WS-CVG)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      * MSG: DESTINATION COVERAGE (@1) MUST BE INSURANCE
      * TYPE D OR N
               MOVE 'CS42500015'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5310-EDIT-DEST-CVG-X
557660     END-IF.
      *
      *  READ PLAN HEADER FOR THIS COVERAGE FOR USE IN FOLLOWING EDITS
      *

           MOVE WS-CVG                TO I.
           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.
           IF NOT WPH-IO-OK
      * MSG: PLAN NOT FOUND
               MOVE 'CS42500033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5310-EDIT-DEST-CVG-X
557660     END-IF.

           SET  WS-DEST-CVG-VALID (WS-SUB)    TO TRUE.

       5310-EDIT-DEST-CVG-X.
           EXIT.
      /
       5320-EDIT-DEP-MTH.

           SET  WS-DEP-TERM-NOT-VALID (WS-SUB)  TO TRUE.

           IF MIR-DPOS-TRM-MO-DUR-T (WS-SUB) =  EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
               GO TO 5320-EDIT-DEP-MTH-X
557660     END-IF.

           SET  L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                                      TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
           ELSE
      * MSG: DEPOSIT TERM MUST BE VALID NUMERIC
               MOVE 'CS42500016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  1                TO WGLOB-RETURN-CODE
               GO TO 5320-EDIT-DEP-MTH-X
557660     END-IF.

           SET  WS-DEP-TERM-VALID (WS-SUB)      TO TRUE.

       5320-EDIT-DEP-MTH-X.
           EXIT.
      /
       5330-EDIT-DEP-DAY.

           IF MIR-DPOS-TRM-DY-DUR-T (WS-SUB) =  EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
               GO TO 5330-EDIT-DEP-DAY-X
557660     END-IF.

           SET  L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                      TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
           ELSE
      * MSG: DEPOSIT TERM MUST BE VALID NUMERIC
               MOVE 'CS42500016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WS-DEP-TERM-NOT-VALID (WS-SUB)  TO TRUE
               MOVE  1                TO WGLOB-RETURN-CODE
               GO TO 5330-EDIT-DEP-DAY-X
557660     END-IF.

       5330-EDIT-DEP-DAY-X.
           EXIT.
      /
       5340-EDIT-DEP-TERM.

           IF WS-DEP-TERM-NOT-VALID (WS-SUB)
               GO TO 5340-EDIT-DEP-TERM-X
557660     END-IF.

           MOVE MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                      TO WS-DEPDY.
           MOVE MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                                      TO WS-DEPMN.

           IF WS-DEP-TERM =  '000000'
557659*        MOVE WCVGS-CVG-DPOS-TRM-INFO (WS-CVG) TO WS-DEP-TERM
020874*        MOVE WCVGS-DPOS-TRM-MO-DUR (WS-CVG)
020874*                               TO WS-DEPMN
020874*        MOVE WCVGS-DPOS-TRM-DY-DUR (WS-CVG)
020874*                               TO WS-DEPDY
      * MSG:  DEPOSIT TERM DEFAULTED FROM COVERAGE RECORD FOR @1
               MOVE 'CS42500036'      TO WGLOB-MSG-REF-INFO
               MOVE WS-CVG            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
020874*        MOVE WS-DEPMN          TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
020874*        MOVE WS-DEPDY          TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
020874         MOVE WCVGS-DPOS-TRM-MO-DUR (WS-CVG)  TO L0290-INPUT-V00
020874         MOVE 0                               TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
020874         MOVE WCVGS-DPOS-TRM-DY-DUR (WS-CVG)  TO L0290-INPUT-V00
020874         MOVE 0                               TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
557660     END-IF.

           IF WS-DEP-TERM  > RPH-MAX-ROLOVR-DUR-INFO
      * MSG: DEP TERM FOR DEST-COV (@1) OUTSIDE PLAN RANGE
               MOVE 'CS42500017'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE  1            TO WGLOB-RETURN-CODE
                   MOVE  1            TO WGLOB-RETURN-CODE
557660         END-IF
557660     END-IF.

           IF WS-DEP-TERM < RPH-MIN-ROLOVR-DUR-INFO
      * MSG: DEP TERM FOR DEST-COV (@1) OUTSIDE PLAN RANGE
               MOVE 'CS42500017'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE  1            TO WGLOB-RETURN-CODE
557660         END-IF
557660     END-IF.

           IF  WS-DEPMN > '000'
           AND WS-DEPDY > '030'
               MOVE 'CS42500041'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  1                TO WGLOB-RETURN-CODE
557660     END-IF.


           IF WGLOB-GOOD-RETURN
      * SET INDICATOR FOR RENEWAL LETTER MSG
               SET WS-SEND-RENEWAL-MSG    TO TRUE
557660     END-IF.

       5340-EDIT-DEP-TERM-X.
           EXIT.
      /
       5350-EDIT-AMOUNT.

           IF MIR-CDAD-TRXN-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-CDAD-TRXN-AMT-T (WS-SUB)
557660     END-IF.

           SET  L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                             TO L0280-LENGTH.
008455*    MOVE 12                            TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CDAD-TRXN-AMT-T(WS-SUB)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-CDAD-TRXN-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
008455*        MOVE L0280-OUTPUT-DOLLAR       TO WS-N-9-2
008455*        MOVE WS-N-9-2                  TO WS-PIC-9-2
008455*        MOVE WS-PIC-9-2        TO MIR-CDAD-TRXN-AMT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L0280-OUTPUT-DOLLAR  * 100
020874         MOVE L0280-OUTPUT-DOLLAR       TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CDAD-TRXN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CDAD-TRXN-AMT-T (WS-SUB)
           ELSE
      * MSG: DEPOSIT AMOUNT MUST BE NUMERIC
               MOVE 'CS42500018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5350-EDIT-AMOUNT-X
557660     END-IF.

           MOVE L0280-OUTPUT-DOLLAR   TO WS-DEP-AMT (WS-SUB).

           IF WS-DEP-AMT (WS-SUB) NOT > ZERO
      * MSG: DEPOSIT AMOUNT MUST BE GREATER THAN ZERO
               MOVE 'CS42500040'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5350-EDIT-AMOUNT-X
557660     END-IF.

           IF WGLOB-GOOD-RETURN
      *
      * SET INDICATOR FOR RENEWAL LETTER MSG
      *
               SET WS-SEND-RENEWAL-MSG    TO TRUE
557660     END-IF.

       5350-EDIT-AMOUNT-X.
           EXIT.
      /
       5360-EDIT-INT-RATE.

023112*    IF MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB) =
023112*                                        EBLCH-BLANK-FIELD-CHAR
023112*        MOVE ZEROS           TO MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB)
023112*        GO TO 5360-EDIT-INT-RATE-X
023112*    END-IF.
023112*
023112*    SET  L0280-SIGN-NOT-PERMITTED      TO TRUE.
023112*    MOVE 4                     TO L0280-PRECISION.
023112*    MOVE 3                     TO L0280-LENGTH.
023112*    MOVE MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB)
023112*                               TO L0280-INPUT-DATA.
023112*
023112*    PERFORM  0280-1000-NUMERIC-EDIT
023112*        THRU 0280-1000-NUMERIC-EDIT-X.
023112*    IF L0280-OK
023112*        MOVE L0280-OUTPUT-V04  TO WS-N-3-4
023112*        MOVE WS-N-3-4          TO WS-PIC-3-4
023112*        MOVE WS-PIC-3-4      TO MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB)
023112*    ELSE
023112*    * MSG: INTEREST RATE MUST BE VALID NUMERIC
023112*        MOVE 'CS42500019'      TO WGLOB-MSG-REF-INFO
023112*        PERFORM  0260-1000-GENERATE-MESSAGE
023112*            THRU 0260-1000-GENERATE-MESSAGE-X
023112*        MOVE  1                TO WGLOB-RETURN-CODE
023112*        GO TO 5360-EDIT-INT-RATE-X
023112*    END-IF.
023112*
023112*    MOVE L0280-OUTPUT-V04      TO WS-GTD-RT (WS-SUB).
023112*
023112*    IF WS-GTD-RT (WS-SUB)   > ZERO
023112*    AND (WCVGS-CVG-CF-TYP-DIA (WS-CVG)
023112*    OR   WCVGS-CVG-CF-TYP-EQUITY (WS-CVG)
023112*    OR   WCVGS-CVG-CF-TYP-EIA (WS-CVG)
023112*    OR   WCVGS-CVG-CF-TYP-OMNM (WS-CVG))
023112*    * MSG: INTEREST RATE MUST BE ZERO FOR CF TYPE D, E, P OR M
023112*        MOVE 'CS42500020'      TO WGLOB-MSG-REF-INFO
023112*        PERFORM  0260-1000-GENERATE-MESSAGE
023112*            THRU 0260-1000-GENERATE-MESSAGE-X
023112*        MOVE 1                 TO WGLOB-RETURN-CODE
023112*        MOVE ZEROES            TO WS-GTD-RT (WS-SUB)
023112*        GO TO 5360-EDIT-INT-RATE-X
023112*    END-IF.

           MOVE MIR-DEST-CVG-NUM      TO I.
           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.
           IF NOT WPH-IO-OK
      * MSG: PLAN NOT FOUND
               MOVE 'CS42500033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5360-EDIT-INT-RATE-X
557660     END-IF.

018633*    MOVE RPH-PLAN-ROLOVR-TYP-CD       TO WS-SRC-CVG-ROL-TYP-CD
018633*    IF NOT WS-SRC-CVG-GUAR-INT
018633     MOVE RPH-PLAN-ROLOVR-TYP-CD       TO LCOMM-SRC-CVG-ROL-TYP-CD
018633     IF NOT LCOMM-SRC-CVG-GUAR-INT
           AND WS-GTD-RT (WS-SUB) > ZERO
023112*        MOVE '000.0000'      TO MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB)
               MOVE ZEROES            TO WS-GTD-RT (WS-SUB)
      * MSG:  PLAN DOES NOT SUPPORT GTD ROLL RATES
               MOVE 'CS42500021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
557660     END-IF.

           IF WGLOB-GOOD-RETURN
      *
      * SET INDICATOR FOR RENEWAL LETTER MSG
      *
               SET WS-SEND-RENEWAL-MSG    TO TRUE
557660     END-IF.

       5360-EDIT-INT-RATE-X.
           EXIT.
      /
       5400-CROSS-EDITS.

           IF NOT WS-EDIT-THIS-LINE (WS-SUB)
               GO TO 5400-CROSS-EDITS-X
557660     END-IF.

           PERFORM  5410-MIN-DEPOSIT-CROSS-EDIT
               THRU 5410-MIN-DEPOSIT-CROSS-EDIT-X.

       5400-CROSS-EDITS-X.
           EXIT.
      /
       5410-MIN-DEPOSIT-CROSS-EDIT.

           MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WS-CVG.
           MOVE WS-CVG                TO I.
           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.

           IF WS-DEP-AMT (WS-SUB) < RPH-DIR-DPOS-MIN-AMT
      * MSG: DEST CVG (@1) PROJECTED ROLL AMT < PLAN MIN
               MOVE 'CS42500022'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
                   GO TO 5410-MIN-DEPOSIT-CROSS-EDIT-X
557660         END-IF
557660     END-IF.

       5410-MIN-DEPOSIT-CROSS-EDIT-X.
           EXIT.
      /
       5420-DEP-AMT-TOTAL-EDIT.
      *
      *  READ CASHFLOW FOR ROLLOVER AMOUNT
      *
           PERFORM  5421-READ-ROLL-CASHFLOW
               THRU 5421-READ-ROLL-CASHFLOW-X.
           IF NOT WGLOB-GOOD-RETURN
               PERFORM  CDSA-3000-UNLOCK
                   THRU CDSA-3000-UNLOCK-X
               GO TO 5420-DEP-AMT-TOTAL-EDIT-X
557660     END-IF.
      *
      *  CALCULATE ROLL AMOUNT (TOT-TRXN-AMT)
      *
           PERFORM  5600-CALCULATE-ROLL-AMOUNT
               THRU 5600-CALCULATE-ROLL-AMOUNT-X.

008455*    MOVE RCDSA-CDA-TOT-TRXN-AMT    TO WS-N-9-2
008455*    MOVE WS-N-9-2                  TO WS-PIC-9-2
008455*    MOVE WS-PIC-9-2                TO MIR-CDA-TOT-TRXN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCDSA-CDA-TOT-TRXN-AMT  * 100
020874     MOVE RCDSA-CDA-TOT-TRXN-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CDA-TOT-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CDA-TOT-TRXN-AMT.

           PERFORM  5425-CALC-TOTAL-DEP-AMT
               THRU 5425-CALC-TOTAL-DEP-AMT-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-LINES.

           IF WS-TOTAL-DEP-AMT NOT = RCDSA-CDA-TOT-TRXN-AMT
      * MSG: SUM OF DEPOSIT AMOUNTS MUST EQUAL ROLLOVER AMT
               MOVE 'CS42500024'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
               GO TO 5420-DEP-AMT-TOTAL-EDIT-X
557660     END-IF.

       5420-DEP-AMT-TOTAL-EDIT-X.
           EXIT.
      /
       5421-READ-ROLL-CASHFLOW.

           PERFORM  8000-BUILD-CDSA-KEY
               THRU 8000-BUILD-CDSA-KEY-X.

           PERFORM  CDSA-1000-READ-FOR-UPDATE
               THRU CDSA-1000-READ-FOR-UPDATE-X.

           MOVE RCDSA-POL-ID          TO WCFLW-POL-ID.
           MOVE RCDSA-CVG-NUM         TO WCFLW-CVG-NUM.
025357*    IF WCVGS-CVG-CF-TYP-EIA  (WCFLW-CVG-NUM-N)
025357*       MOVE 'I'                TO WCFLW-CF-TYP-CD
025357*    ELSE
025357*       MOVE 'A'                TO WCFLW-CF-TYP-CD
025357*    END-IF.
010314*    MOVE RCDSA-CDA-TYP-CD     TO WCFLW-CF-TYP-CD.
025357     MOVE RCDSA-SRC-CF-TYP-CD  TO WCFLW-CF-TYP-CD.
557659*    MOVE RCDSA-SRC-CF-EFF-DT  TO WCFLW-CF-DT.
557659     MOVE RCDSA-SRC-CF-EFF-DT   TO WCFLW-CF-EFF-DT.
           MOVE RCDSA-SRC-CF-SEQ-NUM  TO WCFLW-CF-SEQ-NUM.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.
           IF NOT WCFLW-IO-OK
      * MSG: NO CASHFLOW RECORD FOR THIS POLICY/COVERAGE
               MOVE 'CS42500023'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-RETURN-CODE
           ELSE
               PERFORM  5422-READ-NEXT-CFLW
                   THRU 5422-READ-NEXT-CFLW-X
                   UNTIL  RCFLW-NXT-CF-DT = WWKDT-ZERO-DT
                   OR NOT WCFLW-IO-OK
557660     END-IF.

       5421-READ-ROLL-CASHFLOW-X.
           EXIT.
      /
       5422-READ-NEXT-CFLW.

557659*    MOVE RCFLW-NXT-CF-DT          TO WCFLW-CF-DT.
557659     MOVE RCFLW-NXT-CF-DT       TO WCFLW-CF-EFF-DT
           MOVE RCFLW-NXT-CF-SEQ-NUM-N            TO WCFLW-CF-SEQ-NUM-N.
           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

       5422-READ-NEXT-CFLW-X.
           EXIT.
      /
       5425-CALC-TOTAL-DEP-AMT.

           COMPUTE WS-TOTAL-DEP-AMT =
                   WS-TOTAL-DEP-AMT + WS-DEP-AMT (WS-SUB).

       5425-CALC-TOTAL-DEP-AMT-X.
           EXIT.
      /
       5500-EDIT-FOR-WRITE-REWRITE.
      *
      *  BUILD KEY FOR READ FOR UPDATE
      *
           IF NOT WS-EDIT-THIS-LINE (WS-SUB)
               GO TO 5500-EDIT-FOR-WRITE-REWRITE-X
557660     END-IF.

           IF MIR-DEST-CVG-NUM-T (WS-SUB) = EBLCH-BLANK-FIELD-GROUP
018633*        MOVE WS-CDAD-ALLOC-NUM (WS-SUB)
018633         MOVE LCOMM-CDAD-ALLOC-NUM (WS-SUB)
                                      TO WCDSD-CDAD-ALLOC-NUM
               MOVE MIR-DEST-POL-ID-BASE TO WCDSD-POL-ID-BASE
               MOVE MIR-DEST-POL-ID-SFX  TO WCDSD-POL-ID-SFX
012696*        MOVE MIR-DEST-CVG-NUM     TO WCDSD-CVG-NUM
               MOVE MIR-CDA-EFF-DT    TO L1640-EXTERNAL-DATE
               MOVE 'A'               TO WCDSD-CDA-TYP-CD
               MOVE +000              TO WCDSD-POL-PAYO-NUM
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE
                                      TO WCDSD-CDA-EFF-IDT-NUM-N
018633*        MOVE WS-CDAD-SEQ-NUM   TO WCDSD-CDA-SEQ-NUM
018633         MOVE LCOMM-CDAD-SEQ-NUM TO WCDSD-CDA-SEQ-NUM


               PERFORM  CDSD-1000-READ-FOR-UPDATE
                   THRU CDSD-1000-READ-FOR-UPDATE-X

               IF WCDSD-IO-OK
                   PERFORM  CDSD-1000-DELETE
                       THRU CDSD-1000-DELETE-X
                   MOVE SPACES        TO MIR-DEST-CVG-NUM-T (WS-SUB)
                   MOVE SPACES        TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                   MOVE SPACES        TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                   MOVE SPACES        TO MIR-CDAD-TRXN-AMT-T (WS-SUB)
023112*            MOVE SPACES      TO MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB)
                   GO TO 5500-EDIT-FOR-WRITE-REWRITE-X
               ELSE
      *
      * RECORD DIDN'T EXIST - DELETE REQUEST BEFORE CREATE
      *
                   PERFORM  9400-BLANK-DATA-LINES
                       THRU 9400-BLANK-DATA-LINES-X
                   GO TO 5500-EDIT-FOR-WRITE-REWRITE-X
557660         END-IF
557660     END-IF.

018633*    IF WS-CDAD-ALLOC-NUM (WS-SUB) NOT > ZERO
018633     IF LCOMM-CDAD-ALLOC-NUM (WS-SUB) NOT > ZERO
      *
      * NEED A NEW ALLOCATION NUMBER **
      *
               ADD 1 TO WS-HIGHEST-ALLOC-NUM
               MOVE WS-HIGHEST-ALLOC-NUM
                                      TO WCDSD-CDAD-ALLOC-NUM
           ELSE
018633*        MOVE WS-CDAD-ALLOC-NUM (WS-SUB)
018633         MOVE LCOMM-CDAD-ALLOC-NUM (WS-SUB)
                                      TO
                                  WCDSD-CDAD-ALLOC-NUM
557660     END-IF.

           MOVE MIR-DEST-POL-ID-BASE  TO WCDSD-POL-ID-BASE.
           MOVE MIR-DEST-POL-ID-SFX   TO WCDSD-POL-ID-SFX.
012696*    MOVE MIR-DEST-CVG-NUM                  TO WCDSD-CVG-NUM.
           MOVE MIR-CDA-EFF-DT        TO L1640-EXTERNAL-DATE.
           MOVE 'A'                   TO WCDSD-CDA-TYP-CD.
           MOVE +000                  TO WCDSD-POL-PAYO-NUM.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE   TO WCDSD-CDA-EFF-IDT-NUM-N.
018633*    MOVE WS-CDAD-SEQ-NUM    TO WCDSD-CDA-SEQ-NUM.
018633     MOVE LCOMM-CDAD-SEQ-NUM TO WCDSD-CDA-SEQ-NUM.

           PERFORM  CDSD-1000-READ-FOR-UPDATE
               THRU CDSD-1000-READ-FOR-UPDATE-X.

           IF WCDSD-IO-OK
               PERFORM  5540-MOVE-MIR-TO-RECORD
                   THRU 5540-MOVE-MIR-TO-RECORD-X
               PERFORM  CDSD-2000-REWRITE
                   THRU CDSD-2000-REWRITE-X
           ELSE
               PERFORM  CDSD-1000-CREATE
                   THRU CDSD-1000-CREATE-X
               PERFORM  5540-MOVE-MIR-TO-RECORD
                   THRU 5540-MOVE-MIR-TO-RECORD-X
               PERFORM  CDSD-1000-WRITE
                   THRU CDSD-1000-WRITE-X
557660     END-IF.

           PERFORM  8000-BUILD-CDSA-KEY
               THRU 8000-BUILD-CDSA-KEY-X.

           PERFORM  CDSA-1000-READ-FOR-UPDATE
               THRU CDSA-1000-READ-FOR-UPDATE-X.

           IF NOT WCDSA-IO-OK
      * MSG: CDSA RECORD NOT FOUND TO REWRITE
               MOVE 'CS42500026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5500-EDIT-FOR-WRITE-REWRITE-X
557660     END-IF.

018633*    IF WS-OLD-STAT-CD = SPACES
018633     IF LCOMM-OLD-STAT-CD = SPACES
               SET RCDSA-CDA-STAT-ACTIVE TO TRUE
           ELSE
018633*        IF WS-OLD-STAT-CD = 'E'
018633*            MOVE WS-CURNT-STAT-CD
018633         IF LCOMM-OLD-STAT-CD = 'E'
018633             MOVE LCOMM-CURNT-STAT-CD
                                      TO RCDSA-CDA-STAT-CD
               ELSE
018633*            MOVE WS-OLD-STAT-CD
018633             MOVE LCOMM-OLD-STAT-CD
                                      TO RCDSA-CDA-STAT-CD
557660         END-IF
557660     END-IF.

           MOVE RCDSA-CDA-STAT-CD     TO MIR-CDA-STAT-CD.

           PERFORM  CDSA-2000-REWRITE
               THRU CDSA-2000-REWRITE-X.

       5500-EDIT-FOR-WRITE-REWRITE-X.
           EXIT.
      /
       5540-MOVE-MIR-TO-RECORD.

012696*     MOVE MIR-DEST-CVG-NUM                 TO RCDSD-CVG-NUM.
            MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO RCDSD-DEST-CVG-NUM.
            MOVE L1640-INTERNAL-DATE  TO RCDSD-CDA-EFF-DT.
023112*     MOVE WS-GTD-RT (WS-SUB)   TO RCDSD-CDAD-ROLOVR-INT-RT.
            MOVE WS-DEP-AMT (WS-SUB)  TO RCDSD-CDAD-TRXN-AMT.
            MOVE MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                                      TO RCDSD-DPOS-TRM-MO-DUR.
            MOVE MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                      TO RCDSD-DPOS-TRM-DY-DUR.

       5540-MOVE-MIR-TO-RECORD-X.
           EXIT.
      /
       5600-CALCULATE-ROLL-AMOUNT.
      *
      *  CALULATE CASH VALUE AS OF ROLLOVER DATE
      *
           PERFORM  6530-1000-BUILD-PARM-INFO
               THRU 6530-1000-BUILD-PARM-INFO-X.
           MOVE WS-INTERNAL-EFFDT     TO L6530-EFF-DT.
557659*    MOVE RCFLW-CF-DT              TO L6530-CF-DT.
557659     MOVE RCFLW-CF-EFF-DT       TO L6530-CF-DT.
           MOVE RCFLW-CF-SEQ-NUM-N    TO L6530-CF-SEQ-NUM
           MOVE RCFLW-CVG-NUM-N       TO L6530-CVG.
           SET L6530-CALC-MKTVAL-ADJ-NOT-REQD TO TRUE.
           PERFORM  6530-3000-CALC-ACUM-VALU-CF
               THRU 6530-3000-CALC-ACUM-VALU-CF-X.

      *
      *  FOR COVERAGES WITH INTEREST INDICATOR OF 'CRA' THE
      *  ROLL AMOUNT (TOT-TRXN-AMT) IS THE DEPOSIT + INTEREST
      *  (CALCULATED IN CALL-CASH-VALUES)
      *  FOR COVERAGES WITH OTHER INTEREST INDICATORS THE
      *  INTEREST IS PAID OUT AND WE ASSUME THE TOT-TRXN-AMT IS
      *  EQUAL TO THE ORIGINAL DEPOSIT AMOUNT (LESS LOADS)
      *

           IF L6530-RETRN-OK
               IF WCVGS-CVG-INT-PAYO-CREDIT-ACCT (RCFLW-CVG-NUM-N)
                   MOVE L6530-CF-ACUM-VALU-AMT
                                      TO RCDSA-CDA-TOT-TRXN-AMT
               ELSE
                   MOVE RCFLW-CF-FND-BAL-AMT
                                      TO RCDSA-CDA-TOT-TRXN-AMT
               END-IF
010314         IF RCFLW-CF-TYP-EIA
010314         OR RCFLW-CF-TYP-GIA
010314            IF L6530-CF-ACUM-MCV-AMT > RCDSA-CDA-TOT-TRXN-AMT
010314               MOVE L6530-CF-ACUM-MCV-AMT
010314                                TO  RCDSA-CDA-TOT-TRXN-AMT
010314            END-IF
010314         END-IF
           END-IF.

       5600-CALCULATE-ROLL-AMOUNT-X.
           EXIT.
      /
028805*--------------------
028805*6000-PROCESS-DELETE.
028805*---------------------
028805*
028805*    MOVE MIR-DEST-POL-ID-BASE   TO WPOL-POL-ID-BASE.
028805*    MOVE MIR-DEST-POL-ID-SFX    TO WPOL-POL-ID-SFX.
028805*
028805*    PERFORM  POL-2000-UPDATE-TWRK-TS
028805*        THRU POL-2000-UPDATE-TWRK-TS-X.
028805*
028805*    IF  WPOL-IO-NOT-FOUND
028805*MSG:  'POLICY NOT ON POLICY FILE'
028805*        MOVE 'XS00000070'       TO WGLOB-MSG-REF-INFO
028805*        MOVE WPOL-POL-ID        TO WGLOB-MSG-PARM (01)
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        GO TO 6000-PROCESS-DELETE-X
028805*    END-IF.
028805*
028805*    IF  MIR-RETRN-TS-MISMATCH
028805*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
028805*     PROCESS NOT COMPLETE
028805*        MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
028805*        MOVE 'POL'              TO WGLOB-MSG-PARM (01)
028805*        MOVE WPOL-KEY           TO WGLOB-MSG-PARM (02)
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        GO TO 6000-PROCESS-DELETE-X
028805*    END-IF.
028805*
028805*    PERFORM  9900-DELETE-TWRK
028805*        THRU 9900-DELETE-TWRK-X.
028805*    PERFORM  COMM-3000-DELETE-TWRK
028805*        THRU COMM-3000-DELETE-TWRK-X.
028805*
028805*    PERFORM  8000-BUILD-CDSA-KEY
028805*        THRU 8000-BUILD-CDSA-KEY-X.
028805*
028805*    PERFORM  CDSA-1000-BROWSE
028805*        THRU CDSA-1000-BROWSE-X.
028805*
028805*    IF WCDSA-IO-OK
028805*        PERFORM  CDSA-2000-READ-NEXT
028805*            THRU CDSA-2000-READ-NEXT-X
028805*        IF WCDSA-IO-EOF
028805*            SET  WS-CDSA-ENDBR-NEEDED  TO TRUE
028805*        END-IF
028805*    END-IF.
028805*
028805*    IF NOT WCDSA-IO-OK
028805* MSG: RECORD NOT FOUND
028805*        MOVE 'CS42500008'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        IF WS-CDSA-ENDBR-NEEDED
028805*            PERFORM  CDSA-3000-END-BROWSE
028805*                THRU CDSA-3000-END-BROWSE-X
028805*            PERFORM  POL-3000-UNLOCK
028805*                THRU POL-3000-UNLOCK-X
028805*            GO TO 6000-PROCESS-DELETE-X
028805*        ELSE
028805*            PERFORM  POL-3000-UNLOCK
028805*                THRU POL-3000-UNLOCK-X
028805*            GO TO 6000-PROCESS-DELETE-X
028805*        END-IF
028805*    END-IF.
028805*
028805*    PERFORM  CDSA-3000-END-BROWSE
028805*        THRU CDSA-3000-END-BROWSE-X.
028805*
028805*    IF RCDSA-CDA-STAT-HISTORY
028805* MSG:  DELETE NOT ALLOWED ON STATUS H RECORD
028805*        MOVE 'CS42500027'      TO WGLOB-MSG-REF-INFO
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        PERFORM  POL-3000-UNLOCK
028805*            THRU POL-3000-UNLOCK-X
028805*        GO TO 6000-PROCESS-DELETE-X
028805*    END-IF.
028805*
028805*
028805*    PERFORM  8100-BUILD-CDSD-KEY
028805*        THRU 8100-BUILD-CDSD-KEY-X.
028805*
028805*    PERFORM  CDSD-1000-DELETE-KEY-RANGE
028805*        THRU CDSD-1000-DELETE-KEY-RANGE-X.
028805*
028805*    PERFORM  CDSA-1000-READ-FOR-UPDATE
028805*        THRU CDSA-1000-READ-FOR-UPDATE-X.
028805*
028805*    IF WCDSA-IO-OK
028805*        PERFORM  6210-UPDT-CFLW
028805*            THRU 6210-UPDT-CFLW-X
028805*        PERFORM  CDSA-1000-DELETE
028805*            THRU CDSA-1000-DELETE-X
028805*    END-IF.
028805*
028805*    IF WCDSA-IO-OK
028805*        MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
028805* MSG: (DELETE COMPLETED MESSAGE)
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        PERFORM  POL-2000-REWRITE
028805*            THRU POL-2000-REWRITE-X
028805*        PERFORM  POL-1000-READ-TWRK-TS
028805*            THRU POL-1000-READ-TWRK-TS-X
028805*    ELSE
028805*        MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
028805* MSG: (NO RECORDS FOUND TO DELETE)
028805*        PERFORM  0260-1000-GENERATE-MESSAGE
028805*            THRU 0260-1000-GENERATE-MESSAGE-X
028805*        PERFORM  POL-3000-UNLOCK
028805*            THRU POL-3000-UNLOCK-X
028805*    END-IF.
028805*
028805*6000-PROCESS-DELETE-X.
028805*    EXIT.
028805*
      /
028805*6210-UPDT-CFLW.
009602*
028805*    MOVE RCDSA-POL-ID          TO WCFLW-POL-ID.
028805*    MOVE RCDSA-CVG-NUM         TO WCFLW-CVG-NUM.
028805*    MOVE WCVGS-CVG-CF-TYP-CD  (WCFLW-CVG-NUM-N)
028805*                               TO WCFLW-CF-TYP-CD.
028805*    MOVE RCDSA-SRC-CF-EFF-DT   TO WCFLW-CF-EFF-DT.
028805*    MOVE RCDSA-SRC-CF-SEQ-NUM  TO WCFLW-CF-SEQ-NUM.
028805*
028805*    PERFORM  CFLW-1000-READ-FOR-UPDATE
028805*        THRU CFLW-1000-READ-FOR-UPDATE-X.
028805*    IF NOT WCFLW-IO-OK
028805*       GO TO 6210-UPDT-CFLW-X
028805*    END-IF.
028805*    MOVE ZEROES                TO RCFLW-DEST-CDA-SEQ-NUM.
028805*    PERFORM  CFLW-2000-REWRITE
028805*        THRU CFLW-2000-REWRITE-X.
028805*
028805*6210-UPDT-CFLW-X.
028805*    EXIT.
028805*
028805*
      /
       7000-VALIDATE-POLICY.

           MOVE MIR-DEST-POL-ID-BASE  TO WPOL-POL-ID.
           MOVE MIR-DEST-POL-ID-SFX   TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF WPOL-IO-OK
               CONTINUE
           ELSE
      * MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
557660     END-IF.

       7000-VALIDATE-POLICY-X.
           EXIT.
      /
       7100-VALIDATE-CVG.

557660     IF (WS-BUS-FCN-LIST
557660     AND MIR-DEST-CVG-NUM = SPACES)
               GO TO 7100-VALIDATE-CVG-X
557660     END-IF.

557660     IF MIR-DEST-CVG-NUM = SPACES OR
557660        MIR-DEST-CVG-NUM = ZEROES
      * MSG: COVERAGE NUMBER CANNOT = SPACES OR ZEROES
               MOVE 'CS42500028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO TRUE
               GO TO 7100-VALIDATE-CVG-X
557660     END-IF.

           MOVE MIR-DEST-CVG-NUM      TO WS-HOLD-COVNO-R.
           IF WS-HOLD-COVNO-R NOT NUMERIC
           OR WS-HOLD-COVNO < 1
007766*    OR WS-HOLD-COVNO > 20
007766     OR WS-HOLD-COVNO > WCVGM-MAX-WCVGS-NUM
007766* MSG: COVERAGE MUST BE 2 DIGITS FROM 01-20
007766* MSG: COVERAGE MUST BE 2 DIGITS FROM 01-@1
               MOVE 'CS42500034'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 7100-VALIDATE-CVG-X
557660     END-IF.

           IF RPOL-POL-CVG-REC-CTR-N < WS-HOLD-COVNO
      * MSG: COVERAGE NUMBER MUST EXIST. RE-ENTER
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 7100-VALIDATE-CVG-X
557660     END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

       7100-VALIDATE-CVG-X.
           EXIT.
      /
       7200-EDIT-EFF-DATE.

557660     IF  WS-BUS-FCN-LIST
557660     AND MIR-CDA-EFF-DT = SPACES
               GO TO 7200-EDIT-EFF-DATE-X
557660     END-IF.

           IF MIR-CDA-EFF-DT = SPACES
      * MSG: DATE CANNOT = SPACES
               MOVE 'CS42500030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO TRUE
               GO TO 7200-EDIT-EFF-DATE-X
           ELSE
               MOVE MIR-CDA-EFF-DT    TO  L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF L1640-NOT-VALID
      * MSG: INVALID DATE
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CDA-EFF-DT             TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR  TO TRUE
                   GO TO 7200-EDIT-EFF-DATE-X
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO WS-INTERNAL-EFFDT
557660         END-IF
557660     END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-INTERNAL-EFFDT      TO WIHSD-EFF-DT.
026057     IF  WS-BUS-FCN-RETRIEVE
026057     OR  WS-BUS-FCN-LIST
026057     OR  WS-BUS-FCN-PRINT
026057         PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057             THRU IHSD-1000-CHK-IHSD-INQUIRY-X
026057     ELSE
026057         PERFORM  IHSD-3000-CHK-IHSD-INSTR
026057             THRU IHSD-3000-CHK-IHSD-INSTR-X
026057     END-IF.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WGLOB-RETURN-ERROR     TO TRUE
026057     END-IF.

       7200-EDIT-EFF-DATE-X.
           EXIT.
      /
       7300-VALIDATE-SEQ-NUM.

           IF WS-BUS-FCN-LIST
               GO TO 7300-VALIDATE-SEQ-NUM-X
557660     END-IF.

028805*    IF  WS-BUS-FCN-CREATE
028805*        MOVE '000'             TO MIR-DEST-SEQ-NUM
028805*        GO TO 7300-VALIDATE-SEQ-NUM-X
028805*    END-IF.
028805*
557660     IF WS-BUS-FCN-RETRIEVE
028805*    OR WS-BUS-FCN-UPDATE
               IF MIR-DEST-SEQ-NUM = ZEROES
      * MSG: SEQNO MUST BE GREATER THAN ZERO
                   MOVE 'CS42500031'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR  TO TRUE
                   GO TO 7300-VALIDATE-SEQ-NUM-X
557660         END-IF
557660     END-IF.

           MOVE MIR-DEST-SEQ-NUM      TO L0280-INPUT-DATA.
           SET  L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-FORMAT-SEQ
020874*        MOVE WS-FORMAT-SEQ     TO MIR-DEST-SEQ-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DEST-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-DEST-SEQ-NUM
           ELSE
      * MSG: SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'CS42500035'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
557660     END-IF.

       7300-VALIDATE-SEQ-NUM-X.
           EXIT.
      /
       8000-BUILD-CDSA-KEY.

           MOVE LOW-VALUES            TO WCDSA-KEY.
           MOVE MIR-DEST-POL-ID-BASE  TO WCDSA-POL-ID-BASE.
           MOVE MIR-DEST-POL-ID-SFX   TO WCDSA-POL-ID-SFX.
012696*    MOVE MIR-DEST-CVG-NUM                 TO WCDSA-CVG-NUM.
023112*    MOVE 'A'                   TO WCDSA-CDA-TYP-CD.
023112     MOVE MIR-CDA-TYP-CD        TO WCDSA-CDA-TYP-CD.
023112*    MOVE +000                  TO WCDSA-POL-PAYO-NUM.
023112     MOVE MIR-POL-PAYO-NUM      TO WS-PIC-99999.
023112     MOVE WS-PIC-99999          TO WS-SEQ-NO3.
023112     COMPUTE WS-SEQ-NO4         = 100000 - WS-SEQ-NO3.
023112     MOVE WS-SEQ-NO4            TO WCDSA-POL-PAYO-NUM.
023112
           MOVE WS-INTERNAL-EFFDT     TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE   TO WCDSA-CDA-EFF-IDT-NUM-N.

           MOVE MIR-DEST-SEQ-NUM      TO WS-PIC-999.
           MOVE WS-PIC-999            TO WS-SEQ-NO.
           COMPUTE WS-SEQ-NO2             = 1000 - WS-SEQ-NO.
018633*    MOVE WS-SEQ-NO2            TO WS-CDAD-SEQ-NUM.
018633     MOVE WS-SEQ-NO2            TO LCOMM-CDAD-SEQ-NUM.

018633*    MOVE WS-CDAD-SEQ-NUM    TO WCDSA-CDA-SEQ-NUM.
018633     MOVE LCOMM-CDAD-SEQ-NUM TO WCDSA-CDA-SEQ-NUM.

           MOVE WCDSA-KEY             TO WCDSA-ENDBR-KEY.
           IF MIR-DEST-SEQ-NUM = ZEROES
               MOVE +999              TO WCDSA-ENDBR-CDA-SEQ-NUM
557660     END-IF.

       8000-BUILD-CDSA-KEY-X.
           EXIT.
      /
       8100-BUILD-CDSD-KEY.

           MOVE LOW-VALUES            TO WCDSD-KEY.
           MOVE MIR-DEST-POL-ID-BASE  TO WCDSD-POL-ID-BASE.
           MOVE MIR-DEST-POL-ID-SFX   TO WCDSD-POL-ID-SFX.
012696*    MOVE MIR-DEST-CVG-NUM                 TO WCDSD-CVG-NUM.
           MOVE WS-INTERNAL-EFFDT     TO L1660-INTERNAL-DATE
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X
           MOVE L1660-INVERTED-DATE   TO WCDSD-CDA-EFF-IDT-NUM-N.
023112*    MOVE 'A'                   TO WCDSD-CDA-TYP-CD.
023112     MOVE MIR-CDA-TYP-CD        TO WCDSD-CDA-TYP-CD.
023112*    MOVE +000                  TO WCDSD-POL-PAYO-NUM.
023112     MOVE MIR-POL-PAYO-NUM      TO WS-PIC-99999.
023112     MOVE WS-PIC-99999          TO WS-SEQ-NO3.
023112     COMPUTE WS-SEQ-NO4         = 100000 - WS-SEQ-NO3.
023112     MOVE WS-SEQ-NO4            TO WCDSD-POL-PAYO-NUM.
023112
018633*    MOVE WS-CDAD-SEQ-NUM       TO WCDSD-CDA-SEQ-NUM.
018633     MOVE LCOMM-CDAD-SEQ-NUM    TO WCDSD-CDA-SEQ-NUM.

           MOVE +001                  TO WCDSD-CDAD-ALLOC-NUM.

           MOVE HIGH-VALUES           TO WCDSD-ENDBR-KEY.
           MOVE WCDSD-KEY             TO WCDSD-ENDBR-KEY.

           MOVE +999                  TO WCDSD-ENDBR-CDAD-ALLOC-NUM.

       8100-BUILD-CDSD-KEY-X.
           EXIT.
      /
       8200-BUILD-BRWS-CDSA-KEY.

012696*    MOVE LOW-VALUES              TO WCDSA-KEY.
012696     MOVE LOW-VALUES            TO WCDSC-KEY.
012696*    MOVE MIR-DEST-POL-I1               TO WCDSA-POL-ID-BASE.
012696     MOVE MIR-DEST-POL-ID-BASE  TO WS-POL-ID-BASE.
012696*    MOVE MIR-DEST-POL-I2                TO WCDSA-POL-ID-SFX.
012696     MOVE MIR-DEST-POL-ID-SFX   TO WS-POL-ID-SFX.
012696     MOVE WS-POL-ID             TO WCDSC-POL-ID.
           IF MIR-DEST-CVG-NUM NOT = SPACES
012696*        MOVE MIR-DEST-CVG-NUM           TO WCDSA-CVG-NUM
012696         MOVE MIR-DEST-CVG-NUM  TO WCDSC-CVG-NUM
557660     END-IF.
023112*    MOVE 'A'                     TO WCDSA-CDA-TYP-CD.
023112     MOVE 'A'                     TO WCDSC-CDA-TYP-CD.
012696*    MOVE +000                    TO WCDSA-POL-PAYO-NUM.

           IF MIR-CDA-EFF-DT NOT = SPACES
               MOVE WS-INTERNAL-EFFDT TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
012696*        MOVE L1660-INVERTED-DATE TO WCDSA-CDA-EFF-IDT-NUM-N
012696         MOVE L1660-INVERTED-DATE
                                      TO WCDSC-CDA-EFF-IDT-NUM
012696*        MOVE L1660-INVERTED-DATE TO WCDSA-ENDBR-CDA-EFF-IDT-NUM
012696         MOVE L1660-INVERTED-DATE
                                      TO WCDSC-ENDBR-CDA-EFF-IDT-NUM
557660     END-IF.

           IF MIR-DEST-SEQ-NUM NOT = SPACES
               MOVE MIR-DEST-SEQ-NUM  TO WS-PIC-999
               MOVE WS-PIC-999        TO WS-SEQ-NO
               COMPUTE WS-SEQ-NO2       = 1000 - WS-SEQ-NO
018633*        MOVE WS-SEQ-NO2        TO WS-CDAD-SEQ-NUM
018633         MOVE WS-SEQ-NO2        TO LCOMM-CDAD-SEQ-NUM
012696*        MOVE WS-CDAD-SEQ-NUM   TO WCDSA-CDA-SEQ-NUM
018633*        MOVE WS-CDAD-SEQ-NUM   TO WCDSC-CDA-SEQ-NUM
018633         MOVE LCOMM-CDAD-SEQ-NUM TO WCDSC-CDA-SEQ-NUM
           ELSE
012696*        MOVE +001                TO WCDSA-CDA-SEQ-NUM
012696         MOVE +001              TO WCDSC-CDA-SEQ-NUM
557660     END-IF.

012696*    MOVE WCDSA-KEY               TO WCDSA-ENDBR-KEY.
012696     MOVE WCDSC-KEY             TO WCDSC-ENDBR-KEY.
023112     MOVE 'Q'                   TO WCDSC-ENDBR-CDA-TYP-CD.
           IF MIR-CDA-EFF-DT = SPACES
012696*        MOVE HIGH-VALUES         TO  WCDSA-ENDBR-CDA-EFF-IDT-NUM
012696         MOVE HIGH-VALUES       TO  WCDSC-ENDBR-CDA-EFF-IDT-NUM
557660     END-IF.
           IF MIR-DEST-CVG-NUM = SPACES
012696*        MOVE HIGH-VALUES         TO WCDSA-ENDBR-CVG-NUM
012696         MOVE HIGH-VALUES       TO WCDSC-ENDBR-CVG-NUM
557660     END-IF.

012696*    MOVE +999                    TO WCDSA-ENDBR-CDA-SEQ-NUM.
012696     MOVE +999                  TO WCDSC-ENDBR-CDA-SEQ-NUM.

       8200-BUILD-BRWS-CDSA-KEY-X.
           EXIT.
      /
012696 8300-BUILD-ALT-CDSA-KEY.

012696     MOVE LOW-VALUES            TO WCDSC-KEY.
012696     MOVE MIR-DEST-POL-ID-BASE  TO WS-POL-ID-BASE.
012696     MOVE MIR-DEST-POL-ID-SFX   TO WS-POL-ID-SFX.
012696     MOVE WS-POL-ID             TO WCDSC-POL-ID.
012696     MOVE MIR-DEST-CVG-NUM      TO WCDSC-CVG-NUM.
012696     MOVE 'A'                   TO WCDSC-CDA-TYP-CD.
012696     MOVE WS-INTERNAL-EFFDT     TO L1660-INTERNAL-DATE.
012696
012696     PERFORM  1660-2000-CONVERT-INT-TO-INV
012696         THRU 1660-2000-CONVERT-INT-TO-INV-X.
012696
012696     MOVE L1660-INVERTED-DATE   TO WCDSC-CDA-EFF-IDT-NUM.
012696
012696     MOVE MIR-DEST-SEQ-NUM      TO WS-PIC-999.
012696     MOVE WS-PIC-999            TO WS-SEQ-NO.
012696
012696     COMPUTE WS-SEQ-NO2 = 1000 - WS-SEQ-NO.
012696
018633*    MOVE WS-SEQ-NO2            TO WS-CDAD-SEQ-NUM.
018633*    MOVE WS-CDAD-SEQ-NUM       TO WCDSC-CDA-SEQ-NUM.
018633     MOVE WS-SEQ-NO2            TO LCOMM-CDAD-SEQ-NUM.
018633     MOVE LCOMM-CDAD-SEQ-NUM    TO WCDSC-CDA-SEQ-NUM.
012696     MOVE WCDSC-KEY             TO WCDSC-ENDBR-KEY.
012696
012696     IF MIR-DEST-SEQ-NUM = ZEROES
012696         MOVE +999              TO WCDSC-ENDBR-CDA-SEQ-NUM
012696     END-IF.
023112     MOVE 'Q'                   TO WCDSC-ENDBR-CDA-TYP-CD.
012696
012696 8300-BUILD-ALT-CDSA-KEY-X.
012696     EXIT.
      /
      /
       9100-INIT-DATA-LINES.

           MOVE SPACES                TO MIR-DEST-CVG-NUM-T (WS-SUB).
008455*    MOVE ZEROES                  TO WS-N-9-2.
008455*    MOVE WS-N-9-2                TO WS-PIC-9-2.
008455*    MOVE WS-PIC-9-2              TO MIR-CDAD-TRXN-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER = ZERO
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CDAD-TRXN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CDAD-TRXN-AMT-T (WS-SUB).

           MOVE ZEROES                TO WS-N-3-4.
           MOVE WS-N-3-4              TO WS-PIC-3-4.
023112*    MOVE WS-PIC-3-4         TO MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB).
           MOVE ZEROES                TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB).
           MOVE ZEROES                TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB).

       9100-INIT-DATA-LINES-X.
           EXIT.
      /
       9130-INIT-WS.

           MOVE ZEROES                TO WS-DEP-AMT (WS-SUB).

       9130-INIT-WS-X.
           EXIT.
      /
       9150-INIT-BRWS-LINES.

           MOVE SPACES                TO MIR-CVG-NUM-T (WS-LINE-SUB).
           MOVE SPACES                TO MIR-CDA-EFF-DT-T (WS-LINE-SUB).
           MOVE SPACES               TO MIR-CDA-SEQ-NUM-T (WS-LINE-SUB).
           MOVE SPACES               TO MIR-CDA-STAT-CD-T (WS-LINE-SUB).
           MOVE SPACES             TO MIR-SRC-CF-EFF-DT-T (WS-LINE-SUB).
           MOVE SPACES            TO MIR-SRC-CF-SEQ-NUM-T (WS-LINE-SUB).
023112     MOVE SPACES            TO MIR-CDA-TYP-CD-T (WS-LINE-SUB).
023112     MOVE SPACES            TO MIR-POL-PAYO-NUM-T (WS-LINE-SUB).

       9150-INIT-BRWS-LINES-X.
           EXIT.
      /
       9200-MOVE-HDR-ONLY-TO-SCR.

           MOVE RCDSA-SRC-CF-EFF-DT   TO L1640-INTERNAL-DATE
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X
           MOVE L1640-EXTERNAL-DATE   TO MIR-SRC-CF-EFF-DT.
           MOVE RCDSA-SRC-CF-SEQ-NUM  TO MIR-SRC-CF-SEQ-NUM.
008455*    MOVE RCDSA-CDA-TOT-TRXN-AMT   TO WS-N-9-2.
008455*    MOVE WS-N-9-2                 TO WS-PIC-9-2.
008455*    MOVE WS-PIC-9-2               TO MIR-CDA-TOT-TRXN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCDSA-CDA-TOT-TRXN-AMT   * 100.
020874     MOVE RCDSA-CDA-TOT-TRXN-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CDA-TOT-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CDA-TOT-TRXN-AMT.

008455*    MOVE RCDSA-CDA-ROLOVR-LTR-AMT TO WS-N-9-2.
008455*    MOVE WS-N-9-2                 TO WS-PIC-9-2.
008455*    MOVE WS-PIC-9-2               TO MIR-CDA-ROLOVR-LTR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCDSA-CDA-ROLOVR-LTR-AMT *  100.
023112*    MOVE RCDSA-CDA-ROLOVR-LTR-AMT  TO L0290-INPUT-V02.
023112*    MOVE 2                     TO L0290-PRECISION.
023112*    MOVE LENGTH OF MIR-CDA-ROLOVR-LTR-AMT
023112*                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
023112*    PERFORM 0290-2000-FORMAT-FOR-MIR
023112*       THRU 0290-2000-FORMAT-FOR-MIR-X.
023112*    MOVE L0290-OUTPUT-DATA     TO MIR-CDA-ROLOVR-LTR-AMT.

           MOVE RCDSA-CDA-STAT-CD     TO MIR-CDA-STAT-CD.

       9200-MOVE-HDR-ONLY-TO-SCR-X.
           EXIT.
      /
       9230-MOVE-RECORDS-TO-SCREEN.

           MOVE RCDSD-DEST-CVG-NUM    TO MIR-DEST-CVG-NUM-T (WS-SUB).
           MOVE RCDSD-DPOS-TRM-MO-DUR TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB).
           MOVE RCDSD-DPOS-TRM-DY-DUR TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB).

           IF RCDSD-CDAD-ALLOC-NUM > WS-HIGHEST-ALLOC-NUM
              MOVE RCDSD-CDAD-ALLOC-NUM
                                      TO WS-HIGHEST-ALLOC-NUM
557660     END-IF.

018633*    MOVE RCDSD-CDAD-ALLOC-NUM  TO WS-CDAD-ALLOC-NUM (WS-SUB).
018633*    MOVE RCDSD-CDAD-TRXN-AMT   TO WS-OLD-DEP-AMT (WS-SUB).
018633*    MOVE RCDSD-DPOS-TRM-MO-DUR TO WS-OLD-MO-DUR (WS-SUB).
018633*    MOVE RCDSD-DPOS-TRM-DY-DUR TO WS-OLD-DY-DUR (WS-SUB).
018633     MOVE RCDSD-CDAD-ALLOC-NUM  TO LCOMM-CDAD-ALLOC-NUM (WS-SUB).
018633     MOVE RCDSD-CDAD-TRXN-AMT   TO LCOMM-OLD-DEP-AMT (WS-SUB).
018633     MOVE RCDSD-DPOS-TRM-MO-DUR TO LCOMM-OLD-MO-DUR (WS-SUB).
018633     MOVE RCDSD-DPOS-TRM-DY-DUR TO LCOMM-OLD-DY-DUR (WS-SUB).

008455*    MOVE RCDSD-CDAD-TRXN-AMT      TO WS-N-9-2.
008455*    MOVE WS-N-9-2                 TO WS-PIC-9-2.
008455*    MOVE WS-PIC-9-2        TO MIR-CDAD-TRXN-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCDSD-CDAD-TRXN-AMT   * 100.
020874     MOVE RCDSD-CDAD-TRXN-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CDAD-TRXN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CDAD-TRXN-AMT-T (WS-SUB).

023112*    MOVE RCDSD-CDAD-ROLOVR-INT-RT
023112*                               TO WS-N-3-4.
023112*    MOVE WS-N-3-4              TO WS-PIC-3-4.
023112*    MOVE WS-PIC-3-4         TO MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB).

           PERFORM  CDSD-2000-READ-NEXT
               THRU CDSD-2000-READ-NEXT-X.

       9230-MOVE-RECORDS-TO-SCREEN-X.
           EXIT.
      /
       9250-MOVE-TO-BROWSE-SCREEN.

           MOVE RCDSA-CVG-NUM         TO MIR-CVG-NUM-T (WS-LINE-SUB).
           MOVE RCDSA-CDA-EFF-IDT-NUM TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE   TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE TO MIR-CDA-EFF-DT-T (WS-LINE-SUB).
020874*    MOVE RCDSA-CDA-SEQ-NUM     TO WS-PIC-999.
020874*    COMPUTE WS-SEQ-NO2             = 1000 - WS-PIC-999.
020874*    MOVE WS-SEQ-NO2           TO WS-PIC-999.
020874*    MOVE WS-PIC-999           TO MIR-CDA-SEQ-NUM-T (WS-LINE-SUB).
020874     MOVE RCDSA-CDA-SEQ-NUM     TO L0290-INPUT-V00.
020874     COMPUTE L0290-INPUT-V00  =  1000 - L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CDA-SEQ-NUM-T (WS-LINE-SUB)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-CDA-SEQ-NUM-T (WS-LINE-SUB).
           MOVE RCDSA-CDA-STAT-CD   TO MIR-CDA-STAT-CD-T (WS-LINE-SUB).
023112     MOVE RCDSA-CDA-TYP-CD    TO MIR-CDA-TYP-CD-T (WS-LINE-SUB).
           MOVE RCDSA-SRC-CF-EFF-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                   TO MIR-SRC-CF-EFF-DT-T (WS-LINE-SUB).
           MOVE RCDSA-SRC-CF-SEQ-NUM
                                  TO MIR-SRC-CF-SEQ-NUM-T (WS-LINE-SUB).
023112     MOVE RCDSA-POL-PAYO-NUM    TO L0290-INPUT-V00.
023112     COMPUTE L0290-INPUT-V00  =  100000 - L0290-INPUT-V00.
023112     MOVE 0                     TO L0290-PRECISION.
023112     MOVE LENGTH OF MIR-POL-PAYO-NUM-T (WS-LINE-SUB)
023112                                TO L0290-MAX-OUT-LEN.
023112     PERFORM 0290-2000-FORMAT-FOR-MIR
023112        THRU 0290-2000-FORMAT-FOR-MIR-X.
023112     MOVE L0290-OUTPUT-DATA   TO MIR-POL-PAYO-NUM-T (WS-LINE-SUB).

       9250-MOVE-TO-BROWSE-SCREEN-X.
           EXIT.
      /
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-DEST-POL-ID-BASE  TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-DEST-POL-ID-SFX   TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
       9400-BLANK-DATA-LINES.

           MOVE SPACES                TO MIR-DEST-CVG-NUM-T (WS-SUB).
           MOVE SPACES                TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB).
           MOVE SPACES                TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB).
           MOVE SPACES                TO MIR-CDAD-TRXN-AMT-T (WS-SUB).
023112*    MOVE SPACES             TO MIR-CDAD-ROLOVR-INT-RT-T (WS-SUB).

       9400-BLANK-DATA-LINES-X.
           EXIT.
      /
       9410-BLANK-HDR-FIELDS.

           MOVE SPACES                TO MIR-SRC-CF-EFF-DT.
           MOVE SPACES                TO MIR-SRC-CF-SEQ-NUM.
           MOVE SPACES                TO MIR-CDA-TOT-TRXN-AMT.
023112*    MOVE SPACES                TO MIR-CDA-ROLOVR-LTR-AMT.
           MOVE SPACES                TO MIR-CDA-STAT-CD.

       9410-BLANK-HDR-FIELDS-X.
           EXIT.
023118/
023118*--------------------------
023118 9990-INIT-WORKING-STORAGE.
023118*--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0303-0000-INIT-PARM-INFO
025970         THRU 0303-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6530-0000-INIT-PARM-INFO
025970         THRU 6530-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-MISC-WORK-FIELDS.
025970     INITIALIZE WS-SWITCHES.
025970     INITIALIZE WS-SUBSCRIPTS.
025970     INITIALIZE WS-DEPOSIT-AMT-INFO.
025970     INITIALIZE WS-DEP-TERM.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET  WS-TRANSACTION-NAME-DEFAULT TO TRUE.
025970     SET  WS-MAX-LINES-DEFAULT        TO TRUE.
025970     SET  WS-LOWEST-SEQ-NUM-DEFAULT   TO TRUE.
023118     SET  MIR-RETRN-OK                TO TRUE.
025970
025970     MOVE SPACES            TO  WWKDT-WORK-FIELDS.
023118     MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.
023118
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.
      /
018633*--------------------
018633*9500-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*    MOVE WS-TWRK-KEY               TO  L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                     TO  L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM          TO  TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*----------------
018633*9800-WRITE-TWRK.
018633*----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    MOVE 300              TO  L8090-AREA-LEN.
018633*    MOVE WS-WORK-AREA     TO  L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9900-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      ************************
      ** PROCESSING COPYBOOKS
      ************************

007685*COPY CCPEFRMT.
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY CCPPPLIN.
026057 COPY CCPPIHSD.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
025970 COPY XCPS1670.
       COPY CCPSPGA.
      /
       COPY NCPPCVGS.
      /
      ************************
      ** LINK COPYBOOKS
      ************************
007685*COPY CCCL5206.
007685*COPY CCPS5206.
020463 COPY CCPS2735.
020463 COPY CCPL2735.
018764*COPY NCCL0303.
018764 COPY NCPL0303.
007685 COPY NCPS0303.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
018764*COPY CCCL6530.
018764 COPY CCPL6530.
       COPY CCPS6530.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
      ***********************
      ** MESSAGE COPYBOOKS
      ***********************

018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
      *******************************
      *  FILE I/O PROCESSING MODULES
      *******************************

       COPY CCPACDSA.
       COPY CCPBCDSA.
       COPY CCPNCDSA.
       COPY CCPUCDSA.
       COPY CCPXCDSA.

       COPY CCPCCDSA.

       COPY CCPACDSD.
       COPY CCPBCDSD.
       COPY CCPGCDSD.
       COPY CCPUCDSD.
       COPY CCPXCDSD.
       COPY CCPCCDSD.
      /
       COPY CCPBCFLW.
       COPY CCPNCFLW.
       COPY CCPUCFLW.
      /
       COPY CCPNCVG.
      /
007685*COPY NCPEDOCM.
023447*COPY NCPNDOCM.
023447 COPY XCPNDOCM.
      /
007685*COPY CCPNEDIT.
      /
       COPY CCPNPOL.
014221 COPY CCPUPOL.
      /
       COPY CCPNPH.
      /
012696 COPY CCPBCDSC.
      /
016537*COPY CCPBCDSE.
      /
016537*COPY CCPVCDSE.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4250                     **
      *****************************************************************
