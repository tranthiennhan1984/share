      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM0310.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM0310                                         **
      **  REMARKS:  PROCESS DRIVER FOR UXIT TRANSACTION:             **
      **            MAINTAIN USER EXIT PROGRAM SCREEN.               **
      **            THIS PROGRAM ALLOWS THE USER TO RETRIEVE,LIST    *
      **            UPDATE, CREATE,AND DELETE POLCICY EXIT ROUTINES. *
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
011025**  5.6       INITIAL SYSTEM DESIGN                            **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       GLOBAL MESSAGING                                 **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016457**  6.2       SPLIT TRAN, ATRN                                 **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016686**  6.2       PROCESS DATE CHANGE FOR CONCURRENCY              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018770**  6.3       PCR - ALLOWABLE VALUE EDIT                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      /
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM0310'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970*                                     BINARY.
           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND                      VALUE 'Y'.
               88  WS-NO-ERROR                         VALUE 'N'.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-VALID                    VALUES ARE
                   '0310','0311','0312','0313','0314'.
               88  WS-BUS-FCN-RETRIEVE                   VALUE '0310'.
               88  WS-BUS-FCN-CREATE                     VALUE '0311'.
               88  WS-BUS-FCN-UPDATE                     VALUE '0312'.
               88  WS-BUS-FCN-DELETE                     VALUE '0313'.
               88  WS-BUS-FCN-LIST                       VALUE '0314'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0310'.
           05  WS-USER-EXIT-TYPE            PIC X(01).
               88  WS-VALID-USER-EXIT-TYPE  VALUES 'A' 'B' 'R' 'I'.
               88  WS-USER-EXIT-INACTIVE    VALUE  'I'.
               
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES             PIC S9(4) BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT VALUE +12.

025970     05  WS-TWRK-KEY                     PIC X(04).  
025970         88  WS-TWRK-KEY-DEFAULT         VALUE '3010'.
025970
018770*    05  WS-UXIT-POINTER              PIC X(04).
018770*        88  WS-VALID-UXIT-POINTER
018770*            VALUES ARE 'EIAC'
018770*                       'PIDA'
018770*                       'CIDA'
018770*                       'SETL'
018770*                       'CMPN'
018770*                       'MVPN'
018770*                       'CHPN'
018770*                       'ACPN'
018770*                       'OPDU'
018770*                       'BPDU'.
      /
      ***************************************************************
      * POLICY NUMBER ASSIGNMENT WORK AREA
      ***************************************************************
       COPY XCFRUXIT.
       COPY XCFWUXIT.
      /
014221 COPY XCWL8090.
018770 COPY XCWL8960.
014221 COPY CCWWLOCK.
      /
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
      /
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM0310.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ****************
       0000-MAINLINE.
      ****************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.


      ***************************
       2000-PROCESS-REQUEST.
      ***************************

025970*           PERFORM 9300-SETUP-MSIN-REFERENCE
025970*              THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *
025970*           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF WS-BUS-FCN-RETRIEVE
           OR WS-BUS-FCN-UPDATE
           OR WS-BUS-FCN-DELETE
              PERFORM 2110-CHECK-UXIT
                 THRU 2110-CHECK-UXIT-X
           END-IF.

           IF WS-ERROR-FOUND
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.


           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM0310'
                                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /

      *****************************************************************
      *   CHECK UXIT:
      *   ENSURE THAT THE USER EXIT ROW EXISTS
      *****************************************************************
      *****************
       2110-CHECK-UXIT.
      *****************

           SET WS-NO-ERROR                              TO  TRUE.

           IF  MIR-USER-EXIT-ID  = SPACES
      *MSG:    USER EXIT POINTER IS REQUIRED
               MOVE 'XS03100001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND                       TO  TRUE,
               GO  TO  2110-CHECK-UXIT-X
           END-IF.

           MOVE MIR-USER-EXIT-ID      TO WUXIT-USER-EXIT-ID.

           PERFORM 8100-READ-UXIT-INFO
              THRU 8100-READ-UXIT-INFO-X.

       2110-CHECK-UXIT-X.
           EXIT.
      /
      **************
       3000-PROCESS-RETRIEVE.
      **************

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *************
       3500-PROCESS-LIST.
      *************


           MOVE SPACES                TO MIR-USER-EXIT-ID-G.
018764*    MOVE SPACES                TO MIR-ONLN-PGM-ID-G.
018764*    MOVE SPACES                TO MIR-BTCH-PGM-ID-G.
018764     MOVE SPACES                TO MIR-USER-EXIT-PGM-ID-G.
           MOVE SPACES                TO MIR-USER-EXIT-INVOK-CD-G.


           MOVE LOW-VALUES            TO WUXIT-KEY.
           MOVE HIGH-VALUES           TO WUXIT-ENDBR-KEY.

           MOVE MIR-USER-EXIT-ID      TO WUXIT-USER-EXIT-ID.

           PERFORM UXIT-1000-BROWSE
              THRU UXIT-1000-BROWSE-X

           IF NOT WUXIT-IO-OK
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM UXIT-2000-READ-NEXT
              THRU UXIT-2000-READ-NEXT-X.

           IF NOT WUXIT-IO-OK
           OR WUXIT-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM UXIT-3000-END-BROWSE
                  THRU UXIT-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WUXIT-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM UXIT-3000-END-BROWSE
              THRU UXIT-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /

      *************
       4000-PROCESS-CREATE.
      *************

           MOVE MIR-USER-EXIT-ID      TO WUXIT-USER-EXIT-ID.

           PERFORM UXIT-1000-READ
              THRU UXIT-1000-READ-X.

           IF  WUXIT-IO-OK
               MOVE WUXIT-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  EDIT THE USER EXIT POINTER KEY FIELD.
      *
018770*    MOVE MIR-USER-EXIT-ID      TO WS-UXIT-POINTER.
018770*
018770*    IF  WS-VALID-UXIT-POINTER
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770
018770     MOVE 'USER-EXIT-ID'        TO L8960-AV-TBL-CD.
018770     MOVE MIR-USER-EXIT-ID      TO L8960-AV-CD.
018770
018770     PERFORM  8960-1000-VALIDATE-CODE
018770         THRU 8960-1000-VALIDATE-CODE-X.
018770
018770     IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG:    INVALID USER EXIT POINTER ENTERED
               MOVE 'XS03100002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM UXIT-1000-CREATE
              THRU UXIT-1000-CREATE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM UXIT-1000-WRITE
              THRU UXIT-1000-WRITE-X.

014221     PERFORM UXIT-1000-READ-TWRK-TS
014221        THRU UXIT-1000-READ-TWRK-TS-X

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /

      *************************
       5000-PROCESS-UPDATE.
      *************************
      *
      *   MAINTENANCE PROCESSING PART 2 INCLUDES EDITING THE
      *   DATA AND UPDATING, DELETING AND CREATING RECORDS.
      *
           MOVE MIR-USER-EXIT-ID      TO WUXIT-USER-EXIT-ID.

014221*    PERFORM UXIT-1000-READ-FOR-UPDATE
014221*       THRU UXIT-1000-READ-FOR-UPDATE-X.

014221     PERFORM UXIT-2000-UPDATE-TWRK-TS
014221        THRU UXIT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'UXIT'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WUXIT-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.
           IF  NOT WUXIT-IO-OK
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM 5300-EDIT-UXIT-SCREEN-DATA
              THRU 5300-EDIT-UXIT-SCREEN-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

018764*    MOVE MIR-ONLN-PGM-ID       TO RUXIT-ONLN-PGM-ID.
018764*    MOVE MIR-BTCH-PGM-ID       TO RUXIT-BTCH-PGM-ID.
018764     MOVE MIR-USER-EXIT-PGM-ID        TO RUXIT-USER-EXIT-PGM-ID.
           MOVE MIR-USER-EXIT-INVOK-CD      TO RUXIT-USER-EXIT-INVOK-CD.
           PERFORM UXIT-2000-REWRITE
              THRU UXIT-2000-REWRITE-X.

014221     PERFORM UXIT-1000-READ-TWRK-TS
014221        THRU UXIT-1000-READ-TWRK-TS-X

      *MSG:    MAINTENANCE COMPLETE
           MOVE 'XS00000007'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.

      /
      ****************************
       5300-EDIT-UXIT-SCREEN-DATA.
      ****************************

018764*    IF  MIR-ONLN-PGM-ID = SPACES
018764     IF  MIR-USER-EXIT-PGM-ID = SPACES
      *MSG:    'PROGRAM ID IS REQUIRED'
               MOVE 'XS03100004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

018764*    IF  MIR-BTCH-PGM-ID = SPACES
018764*MSG:    'PROGRAM ID IS REQUIRED'
018764*        MOVE 'XS03100004'      TO WGLOB-MSG-REF-INFO
018764*        PERFORM 0260-1000-GENERATE-MESSAGE
018764*           THRU 0260-1000-GENERATE-MESSAGE-X
018764*    END-IF.
018764*
           MOVE MIR-USER-EXIT-INVOK-CD             TO WS-USER-EXIT-TYPE.

           IF  WS-VALID-USER-EXIT-TYPE
               CONTINUE
           ELSE
      *MSG:    'VALID INVOCATION TYPES ARE A, B, R, I'
               MOVE 'XS03100003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5300-EDIT-UXIT-SCREEN-DATA-X.
           EXIT.

      /


      ********************
       6000-PROCESS-DELETE.
      ********************
      ***************************************************************
      * DELETE PROCESSING PART 2 CONSISTS OF DELETING THE
      * RECORD (BACKOUTS ARE HANDLED IN THE MAINLINE).
      *
      * BUILD UXIT KEY FROM KEY AREA ON SCREEN.
      ***************************************************************

           MOVE MIR-USER-EXIT-ID      TO WUXIT-USER-EXIT-ID.

014221*    PERFORM UXIT-1000-READ-FOR-UPDATE
014221*       THRU UXIT-1000-READ-FOR-UPDATE-X

014221     PERFORM UXIT-2000-UPDATE-TWRK-TS
014221        THRU UXIT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'UXIT'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WUXIT-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WUXIT-IO-OK
               PERFORM UXIT-1000-DELETE
                  THRU UXIT-1000-DELETE-X
               IF WUXIT-IO-OK
      *MSG:       DELETE COMPLETED MESSAGE
                  MOVE 'XS00000011'   TO WGLOB-MSG-REF-INFO
               ELSE
      *MSG:       RECORD (@1) LOST IN DELETE
                  MOVE WUXIT-KEY      TO WGLOB-MSG-PARM (1)
                  MOVE 'XS00000010'   TO WGLOB-MSG-REF-INFO
               END-IF
           ELSE
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WUXIT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.


       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *********************
       8100-READ-UXIT-INFO.
      *********************

           IF  RUXIT-USER-EXIT-ID = WUXIT-USER-EXIT-ID
               GO TO 8100-READ-UXIT-INFO-X
           END-IF.

014221*    PERFORM UXIT-1000-READ
014221*       THRU UXIT-1000-READ-X.

014221     IF WS-BUS-FCN-RETRIEVE
014221        PERFORM UXIT-1000-READ-TWRK-TS
014221           THRU UXIT-1000-READ-TWRK-TS-X
014221     ELSE
014221        PERFORM UXIT-1000-READ
014221           THRU UXIT-1000-READ-X
014221     END-IF.

           IF WUXIT-IO-NOT-FOUND
      *MSG:    "USER EXIT POINTER NOT FOUND"
               MOVE 'XS03100005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM 9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
               SET WS-ERROR-FOUND           TO TRUE
           END-IF.

       8100-READ-UXIT-INFO-X.
           EXIT.
      /

      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      ************************
       9100-BLANK-DATA-FIELDS.
      ************************

           IF  WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-USER-EXIT-ID-G
018764*        MOVE SPACES            TO MIR-ONLN-PGM-ID-G
018764*        MOVE SPACES            TO MIR-BTCH-PGM-ID-G
018764         MOVE SPACES            TO MIR-USER-EXIT-PGM-ID-G
               MOVE SPACES            TO MIR-USER-EXIT-INVOK-CD-G
           ELSE
018764*        MOVE SPACES            TO MIR-ONLN-PGM-ID
018764*        MOVE SPACES            TO MIR-BTCH-PGM-ID
018764         MOVE SPACES            TO MIR-USER-EXIT-PGM-ID
               MOVE SPACES            TO MIR-USER-EXIT-INVOK-CD
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************

           IF  WS-BUS-FCN-LIST
               PERFORM 9210-MOVE-UXIT-TO-SCRN-1
                  THRU 9210-MOVE-UXIT-TO-SCRN-1-X
                VARYING I FROM 1 BY 1
                  UNTIL I > WS-MAX-BROWSE-LINES
                     OR WUXIT-IO-EOF
           ELSE
018764*        MOVE RUXIT-ONLN-PGM-ID TO MIR-ONLN-PGM-ID
018764*        MOVE RUXIT-BTCH-PGM-ID TO MIR-BTCH-PGM-ID
018764         MOVE RUXIT-USER-EXIT-PGM-ID
018764                                TO MIR-USER-EXIT-PGM-ID
               MOVE RUXIT-USER-EXIT-INVOK-CD
                                      TO MIR-USER-EXIT-INVOK-CD
           END-IF.


           IF  WS-BUS-FCN-LIST
               IF WUXIT-IO-EOF
                  MOVE MIR-USER-EXIT-ID-T (1)
                                      TO MIR-USER-EXIT-ID
               ELSE
                  MOVE RUXIT-USER-EXIT-ID
                                      TO MIR-USER-EXIT-ID
               END-IF
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      /
      **************************
       9210-MOVE-UXIT-TO-SCRN-1.
      **************************

           MOVE RUXIT-USER-EXIT-ID    TO MIR-USER-EXIT-ID-T  (I).
018764*    MOVE RUXIT-ONLN-PGM-ID     TO MIR-ONLN-PGM-ID-T (I).
018764*    MOVE RUXIT-BTCH-PGM-ID     TO MIR-BTCH-PGM-ID-T (I).
018764     MOVE RUXIT-USER-EXIT-PGM-ID    TO MIR-USER-EXIT-PGM-ID-T (I).
           MOVE RUXIT-USER-EXIT-INVOK-CD
                                      TO MIR-USER-EXIT-INVOK-CD-T   (I).

           PERFORM UXIT-2000-READ-NEXT
              THRU UXIT-2000-READ-NEXT-X.

       9210-MOVE-UXIT-TO-SCRN-1-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.

025970     PERFORM 9300-SETUP-MSIN-REFERENCE
025970        THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970     SET  WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.

023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /


      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY UXIT
014221                         '$VAR2' BY 'UXIT'.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.

025970 COPY XCPS8090.
018770 COPY XCPS8960.
018770 COPY XCPL8960.

      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY XCPAUXIT.
       COPY XCPNUXIT.
       COPY XCPBUXIT.
       COPY XCPCUXIT.
       COPY XCPUUXIT.
       COPY XCPXUXIT.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM XSOM0310                       *
      ******************************************************************
