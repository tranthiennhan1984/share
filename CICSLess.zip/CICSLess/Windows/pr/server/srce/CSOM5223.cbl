      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5223.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5223                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE CRCD TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014221**  6.2       LOGICAL LOCKING                                  **
016395**  6.2       DELETE CREDIT CARD INFO.                         **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5223'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                    VALUE '5220'.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-DELETE            VALUE '5223'.
025970*    05  WS-TWRK-KEY                      PIC X(04) VALUE '5220'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
021930*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCRCD.
       COPY CCFWCLCR.
       COPY CCFRCLCR.
       COPY CCFRCRCD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
021930*COPY XCWLDTLK.
021930*COPY XCWL0280.
021930*COPY XCWL1640.
014221 COPY XCWL8090.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************

021930*COPY CCWL0620.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5223.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE-EDITS
                        THRU 2000-DELETE-EDITS-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5223'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------------
       2000-DELETE-EDITS.
      *------------------

      ***** THE ONLY REQUIREMENT FOR DELETING A CREDIT CARD RECORD
      ***** IS THAT IT NOT EXIST IN ANY CLCR RECORD.

           MOVE LOW-VALUES             TO WCLCR-KEY.
           MOVE MIR-CRC-TYP-CD         TO WCLCR-CRC-TYP-CD.
           MOVE MIR-CRC-ID             TO WCLCR-CRC-ID.
           MOVE WCLCR-KEY              TO WCLCR-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WCLCR-ENDBR-CLI-ID.

           PERFORM  CLCR-1000-BROWSE
               THRU CLCR-1000-BROWSE-X.
           IF NOT WCLCR-IO-EOF
               PERFORM  CLCR-2000-READ-NEXT
                   THRU CLCR-2000-READ-NEXT-X
           END-IF.
           IF WCLCR-IO-OK
      *MSG - CANNOT DELETE, CREDIT CARD IN USE BY @1.
               MOVE 'CS52230001' TO WGLOB-MSG-REF-INFO
               MOVE RCLCR-CLI-ID     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  CLCR-3000-END-BROWSE
                   THRU CLCR-3000-END-BROWSE-X
               GO TO 2000-DELETE-EDITS-X
           END-IF.

           PERFORM  CLCR-3000-END-BROWSE
               THRU CLCR-3000-END-BROWSE-X.

           PERFORM  2100-DELETE
               THRU 2100-DELETE-X.

       2000-DELETE-EDITS-X.
           EXIT.

      *--------------
       2100-DELETE.
      *--------------
      *
      *  THE RECORD MUST EXIST ON A DELETE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

014221*    PERFORM  CRCD-1000-READ-FOR-UPDATE
014221*        THRU CRCD-1000-READ-FOR-UPDATE-X.

014221     PERFORM  CRCD-2000-UPDATE-TWRK-TS
014221         THRU CRCD-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CRCD'                TO WGLOB-MSG-PARM (01)
014221        MOVE WCRCD-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 2100-DELETE-X
014221     END-IF.

           IF  WCRCD-IO-NOT-FOUND
      *MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
               MOVE WCRCD-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'TCRCD'
                 TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2100-DELETE-X
           END-IF.

      *
      *  DELETE THE RECORD AND AUDIT THE CHANGE
      *
           PERFORM  CRCD-1000-DELETE
               THRU CRCD-1000-DELETE-X.

       2100-DELETE-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WCRCD-KEY.
           MOVE MIR-CRC-TYP-CD         TO WCRCD-CRC-TYP-CD.
           MOVE MIR-CRC-ID             TO WCRCD-CRC-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CRCD
014221                         '$VAR2' BY 'CRCD'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************

021930*COPY CCPL0620.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
021930*COPY XCPL0280.
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
021930*COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
014221 COPY CCPNCRCD.
       COPY CCPUCRCD.
       COPY CCPBCLCR.
       COPY CCPXCRCD.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM5223               **
      *****************************************************************

