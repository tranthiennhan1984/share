      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2230.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2230                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE CLNM TABLE - NO MATCH CRITERIA           **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015510**  6.0       CLIENT ENHANCEMENTS                              **
016548**  6.2       CHANGE COMP TO BINARY                            **
016103**  6.3       JAPANESE SEARCH ENHANCEMENTS (6.1.2J)            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2230'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '2230'.
016548*    05  WS-SUB                       PIC S9(4) VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4) VALUE ZERO BINARY.
025970         88 WS-SUB-DEFAULT            VALUE ZERO.
016548*    05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 50   COMP.
016548     05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 50   BINARY.
025970         88 WS-MAX-LIST-LINES-DEFAULT            VALUE 50.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
020478 COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCLI.
       COPY CCFRCLI.
      /
       COPY CCFWCLNN.
       COPY CCFRCLNM.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
020478 COPY CCWL2435.
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2230.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2230'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  CLNN-1000-BROWSE
               THRU CLNN-1000-BROWSE-X.

           PERFORM  CLNN-2000-READ-NEXT
               THRU CLNN-2000-READ-NEXT-X.

           IF  WCLNN-IO-EOF
               PERFORM  CLNN-3000-END-BROWSE
                   THRU CLNN-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-LIST-X
           END-IF.

020478     MOVE ZERO                     TO WS-SUB.
           PERFORM  2010-BROWSE-CLNN
               THRU 2010-BROWSE-CLNN-X
020478*        VARYING WS-SUB FROM 1 BY 1
020478*        UNTIL   WS-SUB > WS-MAX-LIST-LINES
020478         UNTIL   WS-SUB >= WS-MAX-LIST-LINES
               OR      WCLNN-IO-EOF.

           IF  WCLNN-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE
               MOVE RCLNM-CLI-INDV-SUR-NM
                 TO MIR-CLI-INDV-SUR-NM
               MOVE RCLNM-CLI-INDV-GIV-NM
                 TO MIR-CLI-INDV-GIV-NM
               MOVE RCLNM-CLI-ID
                 TO MIR-CLI-ID
           END-IF.

           PERFORM  CLNN-3000-END-BROWSE
               THRU CLNN-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-CLNN.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  CLNN-2000-READ-NEXT
               THRU CLNN-2000-READ-NEXT-X.

       2010-BROWSE-CLNN-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

018732*    IF NOT WGLOB-COUNTRY-JAPAN
018732*        SET MIR-DV-SRCH-GR-ALPHA     TO TRUE
018732*    ELSE
018732*        IF  MIR-DV-SRCH-GR-ALPHA
018732*            SET MIR-DV-SRCH-GR-KANJI TO TRUE
018732*        END-IF
018732*    END-IF.

           MOVE LOW-VALUES               TO WCLNN-KEY.

018732*    EVALUATE TRUE

016103*        WHEN WGLOB-COUNTRY-JAPAN
018732*        WHEN MIR-DV-SRCH-GR-KATAKANA
018732*             SET  WCLNN-CLI-INDV-GR-KATAKANA
018732*               TO TRUE

018732*        WHEN MIR-DV-SRCH-GR-KANJI
018732*             SET  WCLNN-CLI-INDV-GR-KANJI
018732*               TO TRUE

016103*        WHEN OTHER
018732*        WHEN MIR-DV-SRCH-GR-ALPHA
018732*             SET  WCLNN-CLI-INDV-GR-ALPHA
018732*               TO TRUE
018732*
018732*    END-EVALUATE.

018732     MOVE MIR-CLI-INDV-GR-CD        TO WCLNN-CLI-INDV-GR-CD.

020478*    SET  WCLNN-CLI-INDV-NM-TYP-CRNT  TO TRUE.
           MOVE MIR-CLI-INDV-SUR-NM      TO WCLNN-CLI-INDV-SUR-NM.
           MOVE MIR-CLI-INDV-GIV-NM      TO WCLNN-CLI-INDV-GIV-NM.
           MOVE MIR-CLI-ID               TO WCLNN-CLI-ID.
020478     MOVE WWKDT-LOW-DT             TO WCLNN-CLI-INDV-EFF-DT.

           MOVE WCLNN-KEY                TO WCLNN-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WCLNN-ENDBR-CLI-INDV-SUR-NM.
           MOVE HIGH-VALUES              TO WCLNN-ENDBR-CLI-INDV-GIV-NM.
           MOVE HIGH-VALUES              TO WCLNN-ENDBR-CLI-ID.
020478     MOVE WWKDT-HIGH-DT            TO WCLNN-ENDBR-CLI-INDV-EFF-DT.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES
             TO MIR-CLI-INDV-SUR-NM-G.
           MOVE SPACES
             TO MIR-CLI-INDV-GIV-NM-G.
           MOVE SPACES
             TO MIR-CLI-ID-G.
           MOVE SPACES
             TO MIR-CLI-SEX-CD-G.
           MOVE SPACES
             TO MIR-CLI-LANG-CD-G.
           MOVE SPACES
             TO MIR-CLI-BTH-DT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

020478* CHECK IF IT IS A CURRENT NAME
020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478
020478     MOVE RCLNM-CLI-ID        TO L2435-CLI-ID.
020478
020478     PERFORM  2435-2000-CRNT-CLI-NAME
020478         THRU 2435-2000-CRNT-CLI-NAME-X.
020478
020478     IF  L2435-CLI-INDV-EFF-DT NOT = RCLNM-CLI-INDV-EFF-DT
020478         GO TO 9200-MOVE-RECORD-TO-SCREEN-X
020478     END-IF.

020478     ADD 1           TO WS-SUB.
           MOVE RCLNM-CLI-INDV-SUR-NM
             TO MIR-CLI-INDV-SUR-NM-T (WS-SUB).

           MOVE RCLNM-CLI-INDV-GIV-NM
             TO MIR-CLI-INDV-GIV-NM-T (WS-SUB).

           MOVE RCLNM-CLI-ID
             TO MIR-CLI-ID-T (WS-SUB).

           MOVE RCLNM-CLI-ID
             TO WCLI-CLI-ID.

           PERFORM  CLI-1000-READ
               THRU CLI-1000-READ-X.

           IF  NOT WCLI-IO-OK
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           MOVE RCLI-CLI-SEX-CD
             TO MIR-CLI-SEX-CD-T (WS-SUB).

           MOVE RCLI-CLI-LANG-CD
             TO MIR-CLI-LANG-CD-T (WS-SUB).

           MOVE RCLI-CLI-BTH-DT
             TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
             TO MIR-CLI-BTH-DT-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT
             TO TRUE.
           MOVE MIR-CLI-ID
             TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-SUB-DEFAULT TO TRUE.
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
020478 COPY CCPS2435.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
020478 COPY CCPL2435.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCLI.
       COPY CCPBCLNN.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2230                     **
      *****************************************************************
