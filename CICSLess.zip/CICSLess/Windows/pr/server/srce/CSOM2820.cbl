       IDENTIFICATION DIVISION.

       COPY XCWWCRHT.

       PROGRAM-ID. CSOM2820.

      *****************************************************************
      **  MEMBER : CSOM2820                                          **
      **  REMARKS: POLICY DIVIDEND OPTION INQUIRY                    **
      **           THIS ROUTINE RETRIEVE POLICY DIVIDEND OPTION CODE **
      **           AND EXCESS DIVIDEND OPTION.                       **
      **                                                             **
      **  DOMAIN : PO                                                **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      /
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2820'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       COPY XCWL8090.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-RETRIEVE               VALUE '2820'.

           05  WS-REDO-SWITCH                    PIC X(01).
               88  WS-REDO-OK                        VALUE 'Y'.
               88  WS-REDO-NOT-OK                    VALUE 'N'.
           05  WS-ISS-EFF-DT                     PIC X(10).
           05  WS-EFF-DT                         PIC X(10).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
      /
       COPY XCWWWKDT.
      /
       COPY CCWWLOCK.
026057 COPY CCWWIHSD.
      /
       COPY XCWEBLCH.
      /
      *****************************************************************
      * I/O    COPYBOOKS
      *****************************************************************

       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFHPOL.
       COPY CCFWPOL.
      /
       COPY CCFRPDBG.
       COPY CCFWPDBG.
      /
       COPY CCFRPH.
       COPY CCFWPH.

      *****************************************************************
      * LINKAGE PROCESSING COPYBOOKS
      *****************************************************************
020478 COPY CCWL2626.
       COPY CCWL0620.
       COPY CCWL0985.
       COPY CCWL2420.
       COPY CCWL2430.
       COPY CCWL5400.
       COPY XCWL0290.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWLDTLK.
      /
      *****************************************************************
      *  INPUT PARAMETER
      *****************************************************************
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2820.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  1000-RETRIEVE
                        THRU 1000-RETRIEVE-X

               WHEN OTHER
      *MSG: INVALID FUNCTION ID - PROCESSING STOPPED
                    MOVE 'XS00000237'      TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------------
       0100-PROCESS-TRANSACTIONS.
      *--------------------------

           IF  MIR-POL-ID-BASE = SPACES
           AND MIR-POL-ID-SFX  = SPACES
      *MSG:    POLICY ID MUST BE ENTERED
               MOVE 'CS28200001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 0100-PROCESS-TRANSACTIONS-X
           END-IF.


           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.
       0100-PROCESS-TRANSACTIONS-X.
           EXIT.
      /
      *-------------
       1000-RETRIEVE.
      *-------------
      *
      *  THE RECORD MUST EXIST ON AN INQUIRE
      *
           PERFORM  7100-BUILD-KEYS
               THRU 7100-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               GO TO 1000-RETRIEVE-X
           END-IF.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               GO TO 1000-RETRIEVE-X
           END-IF.

035251*    IF  RPOL-POL-STAT-PREM-PAYING
035251*    OR  RPOL-POL-STAT-PAID-UP-LIFE
035251*        CONTINUE
035251*    ELSE
035251*MSGS: INVALID POLICY STATUS FOR DIVIDEND MAINTAIN PROCESS
035251*        MOVE 'CS28200004'      TO WGLOB-MSG-REF-INFO
035251*        PERFORM  0260-1000-GENERATE-MESSAGE
035251*            THRU 0260-1000-GENERATE-MESSAGE-X
035251*        SET WGLOB-RETURN-ERROR TO TRUE
035251*        GO TO 1000-RETRIEVE-X
035251*    END-IF.
035251
035251     IF  RPOL-POL-STAT-PREM-PAYING
035251         CONTINUE
035251     ELSE
035251         PERFORM  2100-CHECK-PAID-UP-STAT
035251             THRU 2100-CHECK-PAID-UP-STAT-X
035251     END-IF.
035251
035251     IF  WGLOB-RETURN-ERROR
035251         GO TO 1000-RETRIEVE-X
035251     END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               GO TO 1000-RETRIEVE-X
           END-IF.
      *
      * EFFECTIVE DATE MUST BE ENTERED
      *
           IF  MIR-PCHST-EFF-IDT-NUM = WWKDT-ZERO-DT
           OR  MIR-PCHST-EFF-IDT-NUM = SPACES
      *MSG:    EFFECTIVE DATE MUST BE ENTERED
               MOVE 'CS28200002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 1000-RETRIEVE-X
           END-IF.


      *
      * EFFECTIVE DATE MUST BE A VALID DATE
      *
           MOVE MIR-PCHST-EFF-IDT-NUM        TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE TO WS-EFF-DT
           ELSE
      *MSGS: INVALID EFFECTIVE DATE IS ENTERED
               MOVE 'CS28200003'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-EFF-DT                TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WGLOB-RETURN-ERROR    TO TRUE
026057     END-IF.


      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           PERFORM  8200-MOVE-RECORD-TO-MIR
               THRU 8200-MOVE-RECORD-TO-MIR-X.

       1000-RETRIEVE-X.
           EXIT.
      /
035251*------------------------
035251 2100-CHECK-PAID-UP-STAT.
035251*------------------------
035251
035251*  CHECK NEW POLICY STATUS FOR PAID UP LIFE
035251
035251     IF  RPOL-POL-STAT-PAID-UP
035251     OR  RPOL-POL-STAT-RPU
035251         IF  RPOL-POL-INS-TYP-PAID-UP-LIFE
035251         OR  RPOL-POL-INS-TYP-WHOLE-LIFE
035251             CONTINUE
035251         ELSE
035251*MSGS: INVALID POLICY STATUS FOR DIVIDEND MAINTAIN PROCESS
035251             MOVE 'CS28200004'      TO WGLOB-MSG-REF-INFO
035251             PERFORM  0260-1000-GENERATE-MESSAGE
035251                 THRU 0260-1000-GENERATE-MESSAGE-X
035251             SET WGLOB-RETURN-ERROR TO TRUE
035251         END-IF
035251     ELSE
035251*MSGS: INVALID POLICY STATUS FOR DIVIDEND MAINTAIN PROCESS
035251         MOVE 'CS28200004'          TO WGLOB-MSG-REF-INFO
035251         PERFORM  0260-1000-GENERATE-MESSAGE
035251             THRU 0260-1000-GENERATE-MESSAGE-X
035251         SET WGLOB-RETURN-ERROR     TO TRUE
035251     END-IF.
035251
035251 2100-CHECK-PAID-UP-STAT-X.
035251     EXIT.
035251/      
      *----------------
       7100-BUILD-KEYS.
      *----------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE MIR-POL-ID-BASE     TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX      TO WPOL-POL-ID-SFX.

       7100-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES              TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       8200-MOVE-RECORD-TO-MIR.
      *--------------------------

           MOVE RPOL-POL-DIV-OPT-CD      TO MIR-POL-DIV-OPT-CD.
           MOVE RPOL-POL-DIV-XCES-CD     TO MIR-POL-DIV-XCES-CD.

      * DISPLAY CLIENT NAME

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID                   TO L2430-POL-ID.
           MOVE ZERO                          TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE                        L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
           END-IF.

       8200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2420-0000-INIT-PARM-INFO
025970         THRU 2420-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
           SET  MIR-RETRN-OK                 TO TRUE.

025970*    INITIALIZE FREQUENTLY-USED-INDICES.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      * PROCESSING COPYBOOKS
      *****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.

025970 COPY XCPS1670.
       COPY CCPSPGA.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
       COPY NCPPCVGR.
       COPY NCPPCVGS.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPPLIN.
       COPY CCPPMIDT.
      /
      *****************************************************************
      * LINKAGE PROCESSING COPYBOOKS
      *****************************************************************
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
       COPY CCPL0620.

       COPY CCPS0985.
       COPY CCPL0985.

       COPY CCPS2420.
       COPY CCPL2420.

       COPY CCPS2430.
       COPY CCPL2430.

       COPY CCPS5400.
       COPY CCPL5400.

       COPY XCPL0260.

       COPY XCPS0290.
       COPY XCPL0290.

025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.

       COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      * FILE I/O PROCESSING MODULES
      *****************************************************************

       COPY CCPNCVG.
       COPY CCPUCVG.

       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNPDBG.
       COPY CCPNPH.
      /
      *****************************************************************
      * ERROR HANDLING ROUTINES
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2820                     **
      *****************************************************************
