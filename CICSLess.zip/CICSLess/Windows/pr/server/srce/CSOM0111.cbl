      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0111.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0111                                         **
      **  REMARKS:  PLAN - MAINTAIN PLAN (PH AND PD) TABLES.         **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE FUNCTIONS **
      **            FOR THE PLAN HEADER (PH) AND PLAN DEFAULTS (PD)  **
      **            TABLES.  ALL OF THE PLAN EDITS ARE DONE IN       **
      **            MODULE CSLC0113.                                 **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
554712**  5.5       PLAN NAME TEXT NOW WILL BE TAKEN FROM THE        **
554712**            EDIT TABLE "PLAN" TYPE RECORD INSTEAD OF         **
554712**            THE PLAN HEADER RECORD.                          **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557690**  5.5       ADD TWO NEW RHDR POINTERS TO SCR-18 TO BE        **
557690**            USED BY THE TAX EXCLUSION RATIO CALCULATION      **
557690**            THE MAP NAMES ARE 'LIFEX' AND 'GUAREF'.          **
557690**            AND REMOVE MORTTX FIELD                          **
557691**  5.5       THE NEW FIELDS PENSION QUALIFIED INDICATOR,      **
557691**            DEPOSIT LIMIT POINTER AN COI POINTER ARE         **
557691**            DISPLAYED IN SCREEN 18.                          **
557693**  5.5       ADD NEW FIELDS PERIODIC CODE, DURATION -         **
557693**            DAYS AND DURATION - MONTHS TO PLAN-08.           **
557697**  5.5       ADD NEW FIELDS SPECIAL FREQ PREMIUM RULE &       **
557697**            SPECIAL FREQ NEG PREMIUM RULE IN PLAN-03.        **
557708**  5.5       CICS ABEND HANDLING                              **
557767**  5.5       THE NEW FIELDS ADJUSTED AGE POINTER AND          **
557767**            EQUIVALENT AGE POINTER ARE DISPLAYED             **
557767**            IN SCREEN 03.                                    **
557788**  5.5       REMOVE ANY REFERENCE TO SALE-TAX-BASE-RT.        **
557788**            IT HAS BEEN REMOVED FROM THE PLAN HEADER         **
557788**            DEFAULTS TABLE.                                  **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007685**  5.6       ANNUAL STATEMENTS & COST DISCLOSURES             **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010300**  5.6       MULTIPLE NOTICES                                 **
010302**  5.6       REMOVE ALL RATES HEADER, POINTER, CODES,         **
010302**            AND UNUSED FIELDS.                               **
010304**  5.6       REMOVE 2 FIELDS FROM AND ADD ANOTHER FIELDS      **
010304**            TO PH AND REMOVE 1 FIELD FROM PD.                **
010311**  5.6       VSAM TAGS REMOVED                                **
010314**  5.6       ADD NEW FIELD TO SCREEN 11.                      **
010648**  5.6       DIVIDEND OPTIONS BY LOCATION                     **
010650**  5.6       PLAN RULES BY LOCATION                           **
010651**  5.6       MIN/MAX ISSUE AGE AND FACE AMT BY LOCATION       **
011026**  5.6       6 NEW FIELD ADD TO SCREEN 06 IN ORDER TO         **
011026**            CLCULATE MVC & EIC.                              **
011526**  5.6       FILE PRINT ELIMINATION AND AUDIT REPORT          **
011526**            ENHANCEMENT                                      **
012136**  5.6V      CHANGES FOR NEW FREE LOOK PROCESSING             **
012138**  5.6V      SEC GUIDELINE ANNUAL PREMIUMS                    **
012139**  5.6V      SEC DUE AND DEFFERED LOADS                       **
012143**  5.6V      LIFO/FIFO CALCULATED SURRENDER CHARGES           **
012145**  5.6V      LOANS ON VARIABLE PRODUCTS                       **
012146**  5.6V      MORTALITY AND EXPENSE CHARGES                    **
012148**  5.6V      TRAIL COMMISSIONS                                **
014035**  5.6V      CLEAN-UP                                         **
013585**  5.6A      CONTRACTUAL PAYOUTS                              **
013924**  5.6A      ANNUAL BONUS                                     **
013930**  5.6A      TERMINAL BONUS                                   **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
016270**  6.1       CHECK IF NOTI-DT-CALC-CD UPDATED                 **
014221**  6.2       LOGICAL LOCKING                                  **
014591**  6.2       COMBINE PLAN BASE ID AND RATE SCALE              **
015919**  6.2       7-PAY (TAMRA) USING 1ST PRINCIPLES               **
016395**  6.2       CREDIT CARD BILLING                              **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016534**  6.2       REMOVE PLAN DURATION TYPE CODE                   **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
012522**  6.3       MONTHIVERSARY PROCESSING FOR INVESTMENTS (6.1.1E)**
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
016016**  6.3       FUND BONUS (6.1.1E)                              **
016307**  6.3       ADMIN CHARGES AS A PERCENT OF FUND VALUE (6.1.1E)**
016641**  6.3       EXTENSIVE NUMERIC FORMATTING                     **
017150**  6.3       CURRENCY SCALING (6.1.2J)                        **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
018905**  6.3       DURATION BASED MATURITY/EXPIRY AGE AND TERM      **
019135**  6.3       VALIDATE FACE AMOUNT (6.1.2J)                    **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
021239**  6.4       FUND UNIT VALUE                                  **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
022730**  6.5       MOVE UNIT VALUES TO RATE HEADER/RATE LOAD        **
023435**  6.5       OFF ANNIVERSARY PREMIUM                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028786**  6.7       EXTERNAL AGENCY INTEGRATION - COMPENSATION CALC. **
031035**  7.0       ANNIVERSARY INTEREST RATE LOCK-IN                **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
029059**  7.1       CASH VALUE ACCUMULATION TEST                     **
026643**  7.1       IA VALUATION  INTEREST RATE LENGTH CHANGE        **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0111'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

      /
       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
      /
       COPY CCWL0113.
      /
014035*COPY XCWEBLCH.
      /
021930*COPY XCWL0280.
008455/
008455 COPY XCWL0290.
      /
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'PLAN'.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
           05  WS-BUS-FCN-ID                PIC X(4).
               88  WS-BUS-FCN-ID-VALID      VALUES ARE
                   '1810', '1811', '1812', '1813', '1814'.
               88  WS-BUS-FCN-RETRIEVE      VALUE  '1810'.
               88  WS-BUS-FCN-CREATE        VALUE  '1811'.
               88  WS-BUS-FCN-UPDATE        VALUE  '1812'.
               88  WS-BUS-FCN-DELETE        VALUE  '1813'.
               88  WS-BUS-FCN-LIST          VALUE  '1814'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1810'.

025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88 WS-TRANS-PLAN             VALUE 'PLAN'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '1810'.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(02) BINARY.
025970         88 WS-MAX-BROWSE-LNS-DEFAULT VALUE +13. 
       01  WS-OUTPUT-DISPLAYS.
           05  WS-UNIT-VALUE                PIC 9(7).
008455*    05  WS-MINIMUM-ISSUE-AMOUNT      PIC 9(9).
008455*    05  WS-MAXIMUM-ISSUE-AMOUNT      PIC 9(9).
           05  WS-UW-MULTIPLIER             PIC 9.99.
008455*    05  WS-FACE-BAND                 PIC 9(9).
           05  WS-XXX-MODE                  PIC .9(7).
008455*    05  WS-MODE-CONSTANT             PIC 999.99.
008455*    05  WS-POLICY-FEE                PIC 999.99.
           05  WS-POL-FEE-XXX-MODE          PIC .9(7).
008455*    05  WS-IA-POLICY-FEE             PIC 9(5).99.
           05  WS-FYC-EXTRA                 PIC 9.9(4).
           05  WS-IA-COMM-RATE              PIC 999.99.
008455*    05  WS-IA-COMM-AMT               PIC 9(9).99.
008455*    05  WS-IA-MAX-COMM-PAY           PIC 9(5).99.
           05  WS-PREMIUM-REFUND-RATE       PIC 9.9(4).
557693     05  WS-PERI-STMT-DY-DUR          PIC 9(03).
557693     05  WS-PERI-STMT-MO-DUR          PIC 9(02).
010302     05  WS-LOAN-INTEREST-RATE        PIC .9(5).
012522     05  WS-PLAN-MIN-PU-AMT           PIC 9(7).99.
           05  WS-PCT-PREM-VAR              PIC .9(5).
008455*    05  WS-DEP-MIN                   PIC 9(5).99.
008455*    05  WS-MIN-CASUAL-PAYMENT        PIC 9(5).99.
008455*    05  WS-MIN-SWEEP-AMT             PIC 9(7).99.
           05  WS-GUAR-INT-RATE             PIC .9(5).
008455*    05  WS-ACCUM-BREAKPOINT          PIC 9(5).
008455*    05  WS-ADMIN-FEE                 PIC 9(5).99.
008455*    05  WS-ADMIN-FEE-WAIVER          PIC 9(7).99.
008455*    05  WS-FEL-FLAT                  PIC 9(5).99.
008455*    05  WS-SUR-CHARGE-FLAT           PIC 9(5).99.
008455*    05  WS-PAR-SUR-CHG-FLAT          PIC 9(5).99.
           05  WS-IMPAIRED-INT-RATE         PIC .9(5).
           05  WS-RISK-RATE-DIVISOR         PIC 9.9(8).
557788*    05  WS-SALES-TAX-BASE            PIC 9.9999.
           05  WS-SETBACK-YEARS             PIC X.
           05  WS-MTHV-ADJ-MONTHS           PIC 9(03).
010302*    05  WS-FREE-WTHDR-QTY            PIC 9(02).
013924     05  WS-BON-EFF-DY                PIC 9(02).
013924     05  WS-BON-EFF-MM                PIC 9(02).

016548*01  WS-MAX-BROWSE-LINES              PIC S9(02) COMP VALUE +13.
025970*01  WS-MAX-BROWSE-LINES              PIC S9(02) BINARY VALUE +13.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPD.
       COPY CCFRPD.
      /
021930*COPY CCFWEDIT.
021930*COPY CCFREDIT.
021930*
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
014221 COPY XCWL8090.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0111.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
      *
           IF WGLOB-MSG-ERROR-SW > 0
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
           IF  NOT WS-BUS-FCN-LIST
               PERFORM  2400-EDIT-PLAN-KEY
                   THRU 2400-EDIT-PLAN-KEY-X
           END-IF.
      *
           IF WGLOB-MSG-ERROR-SW > 0
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X
               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X
               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X
               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X
               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X
               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0100'        TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------
       2400-EDIT-PLAN-KEY.
      *-------------------
      *
      *  VERIFY THAT A VALID PLAN KEY HAS BEEN ENTERED
      *
           IF  MIR-PLAN-ID =  SPACES
      *MSG: 'PLAN CODE MUST NOT BE BLANK'
               MOVE 'CS01110003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2400-EDIT-PLAN-KEY-X
557660     END-IF.
      *
           PERFORM  2410-BUILD-PLAN-KEY
               THRU 2410-BUILD-PLAN-KEY-X.
      *
      *  LOGICAL PLAN READ
      *
           PERFORM PH-1000-READ
              THRU PH-1000-READ-X.
      *
           IF  WS-BUS-FCN-CREATE
               PERFORM  2420-EDIT-CREATE-PLAN-KEY
                   THRU 2420-EDIT-CREATE-PLAN-KEY-X
           ELSE
               PERFORM  2430-EDIT-OTHER-PLAN-KEY
                   THRU 2430-EDIT-OTHER-PLAN-KEY-X
557660     END-IF.
      *
       2400-EDIT-PLAN-KEY-X.
           EXIT.
      /
      *--------------------
       2410-BUILD-PLAN-KEY.
      *--------------------
      *
      *  SET UP LOGICAL PLAN HEADER I/O KEYS
           IF WPH-COMPANY-REQUIRED
              MOVE WGLOB-COMPANY-CODE TO  WPH-CO-ID
           ELSE
              MOVE SPACES             TO  WPH-CO-ID
557660     END-IF.

           MOVE MIR-PLAN-ID           TO  WPH-PLAN-ID.

       2410-BUILD-PLAN-KEY-X.
           EXIT.
      /
      *--------------------------
       2420-EDIT-CREATE-PLAN-KEY.
      *--------------------------
      *
           IF WPH-IO-OK
               MOVE WPH-KEY           TO WPD-KEY
               MOVE WPH-KEY           TO RPD-KEY
               PERFORM PD-1000-READ
                  THRU PD-1000-READ-X
               IF  WPD-IO-OK
      *MSG: 'RECORD ALREADY EXISTS (@1)'
                   MOVE 'XS00000003'  TO WGLOB-MSG-REF-INFO
                   MOVE WPH-KEY       TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: 'LOGICAL PLAN FILES ARE CORRUPT @1 -CALL SYSTEMS'
                   MOVE WPD-KEY       TO WGLOB-MSG-PARM (1)
                   MOVE 'XS00000029'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
       2420-EDIT-CREATE-PLAN-KEY-X.
           EXIT.
      /
      *-------------------------
       2430-EDIT-OTHER-PLAN-KEY.
      *-------------------------
      *
           IF WPH-IO-NOT-FOUND
      *MSG: 'RECORD NOT FOUND @1'
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WPH-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2430-EDIT-OTHER-PLAN-KEY-X
           END-IF.
      *
      *  PLAN DETAIL READ
      *
           MOVE WPH-KEY               TO WPD-KEY.
           MOVE WPH-KEY               TO RPD-KEY.
           PERFORM PD-1000-READ
              THRU PD-1000-READ-X.

           IF  WPD-IO-NOT-FOUND
      *MSG: 'LOGICAL PLAN FILE IS CORRUPT @1 -CALL SYSTEMS'
               MOVE WPD-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       2430-EDIT-OTHER-PLAN-KEY-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

014221     PERFORM 2410-BUILD-PLAN-KEY
014221         THRU 2410-BUILD-PLAN-KEY-X.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           PERFORM 7000-DISPLAY-FIELDS
              THRU 7000-DISPLAY-FIELDS-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.

      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           MOVE SPACES                TO MIR-PLAN-ID-G.
           MOVE SPACES                TO MIR-PLAN-EFF-DT-G.
           MOVE SPACES                TO MIR-PLAN-XPRY-DT-G.
           MOVE SPACES                TO MIR-PLAN-INS-TYP-CD-G.
           MOVE SPACES                TO MIR-APP-FORM-TYP-ID-G.
           MOVE SPACES                TO MIR-PLAN-UWG-IND-G.
010302     MOVE SPACES                TO MIR-LOC-GR-COLCT-ID-G.
           MOVE LOW-VALUES            TO WPH-KEY.
           MOVE HIGH-VALUES           TO WPH-ENDBR-KEY.

           IF MIR-PLAN-ID > SPACES
               MOVE MIR-PLAN-ID       TO WPH-PLAN-ID
           END-IF.

           PERFORM PH-1000-BROWSE
              THRU PH-1000-BROWSE-X.

           IF WPH-IO-EOF
              MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3500-PROCESS-LIST-X
           END-IF.

           IF WPH-IO-OK
               MOVE WPH-KEY           TO WPD-KEY
               MOVE WPH-KEY           TO RPD-KEY
               PERFORM PD-1000-READ
                  THRU PD-1000-READ-X
           END-IF.

           PERFORM  PH-2000-READ-NEXT
               THRU PH-2000-READ-NEXT-X.

           IF WPH-IO-OK
               MOVE WPH-KEY           TO WPD-KEY
               MOVE WPH-KEY           TO RPD-KEY
               PERFORM PD-1000-READ
                  THRU PD-1000-READ-X
           END-IF.

           IF WPH-IO-EOF
              MOVE MIR-PLAN-ID-T (1)  TO MIR-PLAN-ID
              MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3500-PROCESS-LIST-X
           END-IF.

           MOVE +1                    TO WS-SUB.
           PERFORM  3510-PROCESS-BROWSE-READ
               THRU 3510-PROCESS-BROWSE-READ-X
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR    WPH-IO-EOF.

           IF WPH-IO-EOF
              MOVE MIR-PLAN-ID-T (1)
                                      TO MIR-PLAN-ID
              MOVE 'XS00000025'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
              SET WGLOB-MORE-DATA-EXISTS  TO TRUE
              MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PH-3000-END-BROWSE
               THRU PH-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------------
       3510-PROCESS-BROWSE-READ.
      *-------------------------

           MOVE RPH-PLAN-ID           TO MIR-PLAN-ID-T  (WS-SUB).

           IF  RPH-PLAN-EFF-DT   NOT EQUAL TO WWKDT-ZERO-DT
               MOVE RPH-PLAN-EFF-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PLAN-EFF-DT-T (WS-SUB)
           ELSE
               MOVE SPACES            TO MIR-PLAN-EFF-DT-T (WS-SUB)
           END-IF.

           IF  RPH-PLAN-XPRY-DT  NOT EQUAL TO WWKDT-ZERO-DT
               MOVE RPH-PLAN-XPRY-DT  TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PLAN-XPRY-DT-T (WS-SUB)
           ELSE
               MOVE SPACES            TO MIR-PLAN-XPRY-DT-T (WS-SUB)
           END-IF.

           MOVE RPD-PLAN-INS-TYP-CD
                                  TO MIR-PLAN-INS-TYP-CD-T  (WS-SUB).
           MOVE RPH-APP-FORM-TYP-ID  TO MIR-APP-FORM-TYP-ID-T  (WS-SUB).
           MOVE RPD-PLAN-UWG-IND     TO MIR-PLAN-UWG-IND-T  (WS-SUB).
010302     MOVE RPH-LOC-GR-COLCT-ID  TO MIR-LOC-GR-COLCT-ID-T  (WS-SUB).
           ADD +1                          TO WS-SUB.

           PERFORM  PH-2000-READ-NEXT
               THRU PH-2000-READ-NEXT-X.

           IF WPH-IO-OK
               MOVE WPH-KEY           TO WPD-KEY
               MOVE WPH-KEY           TO RPD-KEY
               PERFORM PD-1000-READ
                  THRU PD-1000-READ-X
           END-IF.

           IF  WS-SUB > WS-MAX-BROWSE-LINES
           AND WPH-IO-OK
               MOVE WPH-PLAN-ID       TO MIR-PLAN-ID
           END-IF.

       3510-PROCESS-BROWSE-READ-X.
           EXIT.
      *
      /
      *---------------------------------------------------------------
      *   CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, INIT NEW
      *   RECORD AND ALLOW USER TO MODIFY.
      *----------------------------------------------------------------
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------

      *  UPDATE PLAN HEADER AND EXTENSION FILES
           PERFORM PH-1000-CREATE
              THRU PH-1000-CREATE-X.
           PERFORM PH-1000-WRITE
              THRU PH-1000-WRITE-X.
011526     IF WGLOB-AUDIT-REQUESTED
011526        PERFORM  PH-1000-CALL-AUDIT
011526            THRU PH-1000-CALL-AUDIT-X
011526     END-IF.
      *
      *  UPDATE PLAN DETAIL FILE
           MOVE WPH-KEY               TO WPD-KEY.
           MOVE WPH-KEY               TO RPD-KEY.
           PERFORM PD-1000-CREATE
              THRU PD-1000-CREATE-X.
           PERFORM PD-1000-WRITE
              THRU PD-1000-WRITE-X.
011526     IF WGLOB-AUDIT-REQUESTED
011526        PERFORM  PD-1000-CALL-AUDIT
011526            THRU PD-1000-CALL-AUDIT-X
011526     END-IF.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

013578*    PERFORM  7000-DISPLAY-FIELDS
013578*        THRU 7000-DISPLAY-FIELDS-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

      *
      *  LOGICAL PLAN HEADER READ FOR UPDATE.
      *

014221*    PERFORM  PH-1000-READ-FOR-UPDATE
014221*        THRU PH-1000-READ-FOR-UPDATE-X.

014221     PERFORM  PH-2000-UPDATE-TWRK-TS
014221         THRU PH-2000-UPDATE-TWRK-TS-X.

           IF  WPH-IO-OK
011526         IF WGLOB-AUDIT-REQUESTED
011526             PERFORM PH-1000-CALL-AUDIT
011526                THRU PH-1000-CALL-AUDIT-X
011526         END-IF
011526*        NEXT SENTENCE
           ELSE
014221         EVALUATE  TRUE
014221            WHEN MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221                MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221                MOVE 'PH'             TO WGLOB-MSG-PARM (01)
014221                MOVE WPH-KEY          TO WGLOB-MSG-PARM (02)
014221                PERFORM  0260-1000-GENERATE-MESSAGE
014221                    THRU 0260-1000-GENERATE-MESSAGE-X
014221                GO TO 5000-PROCESS-UPDATE-X
014221            WHEN OTHER
      *MSG: 'RECORD LOST IN MAINTAIN (@1) - CONTACT SYSTEMS'
                      MOVE WPH-KEY           TO WGLOB-MSG-PARM (1)
                      MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
                      PERFORM  0260-1000-GENERATE-MESSAGE
                          THRU 0260-1000-GENERATE-MESSAGE-X
                     IF  WGLOB-MSG-SEVRTY-WARNING
                     OR  WGLOB-MSG-SEVRTY-INFO
034802*                  NEXT SENTENCE
034802                   CONTINUE
                     ELSE
                         GO TO 5000-PROCESS-UPDATE-X
                     END-IF
014221         END-EVALUATE
           END-IF.

      *
      *  PLAN DETAIL HEADER READ FOR UPDATE.
      *

           MOVE WPH-KEY               TO WPD-KEY.
           MOVE WPH-KEY               TO RPD-KEY.
           PERFORM  PD-1000-READ-FOR-UPDATE
               THRU PD-1000-READ-FOR-UPDATE-X.
           IF  WPD-IO-NOT-FOUND
      *MSG: 'LOGICAL PLAN FILES ARE CORRUPT @1 -CALL SYSTEMS'
               MOVE WPD-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
557660         OR  WGLOB-MSG-SEVRTY-INFO
034802*            NEXT SENTENCE
034802             CONTINUE
                 ELSE
014221             PERFORM  PH-3000-UNLOCK
014221                 THRU PH-3000-UNLOCK-X
                   GO TO 5000-PROCESS-UPDATE-X
557660         END-IF
           ELSE
011526         IF WGLOB-AUDIT-REQUESTED
011526             PERFORM PD-1000-CALL-AUDIT
011526                THRU PD-1000-CALL-AUDIT-X
011526         END-IF
557660     END-IF.

           PERFORM  8000-EDIT-FIELDS
               THRU 8000-EDIT-FIELDS-X.

      *
      *  LOGICAL PLAN HEADER REWRITE
      *

           PERFORM  PH-2000-REWRITE
               THRU PH-2000-REWRITE-X.

011526     IF WGLOB-AUDIT-REQUESTED
011526         PERFORM PH-1000-CALL-AUDIT
011526            THRU PH-1000-CALL-AUDIT-X
011526     END-IF.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

      *
      *  PLAN HEADER DETAIL REWRITE
      *

           PERFORM PD-2000-REWRITE
              THRU PD-2000-REWRITE-X.
011526     IF WGLOB-AUDIT-REQUESTED
011526         PERFORM PD-1000-CALL-AUDIT
011526            THRU PD-1000-CALL-AUDIT-X
011526     END-IF.

           IF  WGLOB-GOOD-RETURN
      *MSG: 'MAINTENANCE COMPLETED - CONTINUE'
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG: 'RECORD UPDATED'
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660         IF  WGLOB-MSG-SEVRTY-WARNING
               OR  WGLOB-MSG-SEVRTY-INFO
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   GO TO 5000-PROCESS-UPDATE-X
               END-IF
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.

      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

      *  LOGICAL PLAN HEADER READ FOR UPDATE
014221*    PERFORM PH-1000-READ-FOR-UPDATE
014221*       THRU PH-1000-READ-FOR-UPDATE-X.

014221     PERFORM  PH-2000-UPDATE-TWRK-TS
014221         THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221          MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221          MOVE 'PH'             TO WGLOB-MSG-PARM (01)
014221          MOVE WPH-KEY          TO WGLOB-MSG-PARM (02)
014221          PERFORM  0260-1000-GENERATE-MESSAGE
014221              THRU 0260-1000-GENERATE-MESSAGE-X
014221          GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WPH-IO-NOT-FOUND
      *MSG: 'RECORD LOST IN DELETE (@1) - CONTACT SYSTEMS'
               MOVE WPH-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660         IF  WGLOB-MSG-SEVRTY-WARNING
               OR  WGLOB-MSG-SEVRTY-INFO
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   GO TO 6000-PROCESS-DELETE-X
557660         END-IF
011526     ELSE
011526         IF WGLOB-AUDIT-REQUESTED
011526             PERFORM PH-1000-CALL-AUDIT
011526                THRU PH-1000-CALL-AUDIT-X
011526         END-IF
557660     END-IF.
      *
      *  LOGICAL PLAN HEADER DETAIL READ FOR UPDATE
      *MSG: 'LOGICAL PLAN FILES ARE CORRUPT @1 -CALL SYSTEMS'
      *
      *  LOGICAL PLAN HEADER DELETE
           PERFORM PH-1000-DELETE
              THRU PH-1000-DELETE-X.
011526     IF WGLOB-AUDIT-REQUESTED
011526         PERFORM PH-1000-CALL-AUDIT
011526            THRU PH-1000-CALL-AUDIT-X
011526     END-IF.
      *
      *  PLAN HEADER DETAIL DELETE

010302*  PLAN RATES DELETE
010302*    PERFORM PLRT-1000-DELETE
010302*       THRU PLRT-1000-DELETE-X.

      *MSG: 'DELETE COMPLETED - CONTINUE'
           MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
              THRU  0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.


      *--------------------
       7000-DISPLAY-FIELDS.
      *--------------------

           MOVE RPD-PLAN-INS-TYP-CD   TO MIR-PLAN-INS-TYP-CD.
           MOVE RPH-MAJ-LN-SORT-CD    TO MIR-MAJ-LN-SORT-CD.
           MOVE RPH-APP-FORM-TYP-ID   TO MIR-APP-FORM-TYP-ID.
           MOVE RPD-PLAN-ACCT-TYP-CD  TO MIR-PLAN-ACCT-TYP-CD.
           MOVE RPD-PLAN-BUS-CLAS-CD  TO MIR-PLAN-BUS-CLAS-CD.
010302     MOVE RPH-LOC-GR-COLCT-ID   TO MIR-LOC-GR-COLCT-ID.
010304     MOVE RPH-ACTN-COLCT-ID     TO MIR-ACTN-COLCT-ID.
           MOVE RPH-BASIC-PLAN-IND    TO MIR-BASIC-PLAN-IND.

           MOVE RPD-PLAN-SUPP-BNFT-CD TO MIR-PLAN-SUPP-BNFT-CD.
012522     MOVE RPD-MTHV-PRCES-IND    TO MIR-MTHV-PRCES-IND.
           MOVE RPD-PLAN-UNIT-VALU-AMT   TO WS-UNIT-VALUE.
           MOVE WS-UNIT-VALUE         TO MIR-PLAN-UNIT-VALU-AMT.
           MOVE RPH-DB-CALC-TYP-CD    TO MIR-DB-CALC-TYP-CD.
           MOVE RPH-FACE-AMT-TYP-CD   TO MIR-FACE-AMT-TYP-CD.
016440*    MOVE RPH-APPL-ID           TO MIR-APPL-ID.
016440     MOVE RPH-PLAN-SYS-ID       TO MIR-PLAN-SYS-ID.
007685*    MOVE RPH-PLAN-FP-ID             TO MIR-FPKEY.
007685*    MOVE RPH-PLAN-PG-FRMT-ID        TO MIR-FPFKEY.
           MOVE RPH-CASM-ID           TO MIR-CASM-ID.
018846     MOVE RPD-PLAN-FND-TYP-CD   TO MIR-PLAN-FND-TYP-CD.
021239     MOVE RPD-PLAN-UNIT-TYP-CD  TO MIR-PLAN-UNIT-TYP-CD.
020469     MOVE RPD-PLAN-MULT-CRCY-IND TO MIR-PLAN-MULT-CRCY-IND.
020469     MOVE RPH-PLAN-CRCY-CD       TO MIR-PLAN-CRCY-CD.

           IF  RPH-PLAN-EFF-DT   NOT EQUAL TO WWKDT-ZERO-DT
               MOVE RPH-PLAN-EFF-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PLAN-EFF-DT
           ELSE
               MOVE SPACES            TO MIR-PLAN-EFF-DT
           END-IF.

           IF  RPH-PLAN-XPRY-DT  NOT EQUAL TO WWKDT-ZERO-DT
               MOVE RPH-PLAN-XPRY-DT  TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PLAN-XPRY-DT
           ELSE
               MOVE SPACES            TO MIR-PLAN-XPRY-DT
           END-IF.


010651*    MOVE RPH-PLAN-LOW-AGE           TO MIR-LWAGE.
008455*    MOVE RPD-MIN-ISS-FACE-AMT       TO WS-MINIMUM-ISSUE-AMOUNT.
008455*    MOVE WS-MINIMUM-ISSUE-AMOUNT    TO MIR-MINFA.
010302*    MOVE RPD-MIN-ISS-FACE-AMT       TO L0290-INPUT-NUMBER.
010302*    MOVE 0                          TO L0290-PRECISION.
010302*    MOVE LENGTH OF MIR-MINFA        TO L0290-MAX-OUT-LEN.
010302*    PERFORM 0290-1000-NUMERIC-FORMAT
010302*       THRU 0290-1000-NUMERIC-FORMAT-X.
010302*    MOVE L0290-OUTPUT-DATA          TO MIR-MINFA.
010651*    MOVE RPH-PLAN-HIGH-AGE          TO MIR-HIAGE.
008455*    MOVE RPD-MAX-ISS-FACE-AMT       TO WS-MAXIMUM-ISSUE-AMOUNT.
008455*    MOVE WS-MAXIMUM-ISSUE-AMOUNT    TO MIR-MAXFA.
010302*    MOVE RPD-MAX-ISS-FACE-AMT       TO L0290-INPUT-NUMBER.
010302*    MOVE 0                          TO L0290-PRECISION.
010302*    MOVE LENGTH OF MIR-MAXFA        TO L0290-MAX-OUT-LEN.
010302*    PERFORM 0290-1000-NUMERIC-FORMAT
010302*       THRU 0290-1000-NUMERIC-FORMAT-X.
010302*    MOVE L0290-OUTPUT-DATA          TO MIR-MAXFA.
           MOVE RPH-PLAN-MIN-MPREM-QTY     TO MIR-PLAN-MIN-MPREM-QTY.
010651*    MOVE RPH-MAX-ISS-AMT-RH-ID      TO MIR-MXFAPT.
           MOVE RPH-SUM-INS-CALC-CD   TO MIR-SUM-INS-CALC-CD.
010302*    MOVE RPH-MAX-ADB-AMT-RH-ID      TO MIR-MXADB.
           MOVE RPD-PLAN-LOC-LIC-CD   TO MIR-PLAN-LOC-LIC-CD.
557659     MOVE RPD-PLAN-ISS-DT-TYP-CD     TO MIR-PLAN-ISS-DT-TYP-CD.

           MOVE RPD-PLAN-UWG-IND      TO MIR-PLAN-UWG-IND.
           MOVE RPH-DFLT-REQIR-ID     TO MIR-DFLT-REQIR-ID.
016641*    MOVE RPD-UWG-FACE-AMT-FCT  TO WS-UW-MULTIPLIER.
016641*    MOVE WS-UW-MULTIPLIER      TO MIR-UWG-FACE-AMT-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-UWG-FACE-AMT-FCT * 100.
020874     MOVE RPD-UWG-FACE-AMT-FCT TO L0290-INPUT-V02.
016641     MOVE 2  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-UWG-FACE-AMT-FCT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-UWG-FACE-AMT-FCT.
016641
010302*    MOVE RPH-INCM-FCT-RH-ID         TO MIR-INCPTR.
           MOVE RPH-ALLOW-CCAS-IND    TO MIR-ALLOW-CCAS-IND.


           MOVE RPD-PREM-CALC-TYP-CD  TO MIR-PREM-CALC-TYP-CD.
           MOVE RPD-GIR-PREM-INCL-IND TO MIR-GIR-PREM-INCL-IND.
010302*    MOVE RPH-PREM-RT-TBAC-CD        TO MIR-RTTYP.
           MOVE RPD-CNTRCT-PREM-IND   TO MIR-CNTRCT-PREM-IND.
010302*    MOVE RPH-PREM-RT-TBAC-ID        TO MIR-PRMPTR.
010302*    MOVE RPH-ULT-PREM-RT-RH-ID      TO MIR-ULTPTR.
010302*    MOVE RPH-COLA-RH-ID             TO MIR-COLA.
010302*    MOVE RPH-ULT-COLA-RH-ID         TO MIR-ULTCOL.

           MOVE RPH-AGE-CALC-MTHD-CD  TO MIR-AGE-CALC-MTHD-CD.
           MOVE RPH-PLAN-AGE-STBCK-CD TO MIR-PLAN-AGE-STBCK-CD.
           MOVE RPH-PLAN-AGE-STBCK-QTY     TO MIR-PLAN-AGE-STBCK-QTY.
           MOVE RPH-AGE-STBCK-STRT-AGE-N
                                      TO MIR-AGE-STBCK-STRT-AGE.

010302*    MOVE RPH-SELCT-PERI-DUR-N       TO MIR-PRSDUR.
557767*    MOVE RPH-PLAN-ADJ-AGE-RH-ID     TO MIR-ADAGE.
010302*    MOVE RPH-PLAN-PREM-BAND-IND     TO MIR-PRBAND.
557767*    MOVE RPH-PLAN-EQ-AGE-RH-ID      TO MIR-EQAGE.
008455*    MOVE RPH-FACE-BAND-AMT(1)       TO WS-FACE-BAND.
008455*    MOVE WS-FACE-BAND               TO MIR-BMAX1.
010302*    MOVE RPH-FACE-BAND-AMT(1)       TO L0290-INPUT-NUMBER.
010302*    MOVE 0                          TO L0290-PRECISION.
010302*    MOVE LENGTH OF MIR-BMAX1        TO L0290-MAX-OUT-LEN.
010302*    PERFORM 0290-1000-NUMERIC-FORMAT
010302*       THRU 0290-1000-NUMERIC-FORMAT-X.
010302*    MOVE L0290-OUTPUT-DATA          TO MIR-BMAX1.
008455*    MOVE RPH-FACE-BAND-AMT(2)       TO WS-FACE-BAND.
008455*    MOVE WS-FACE-BAND               TO MIR-BMAX2.
010302*    MOVE RPH-FACE-BAND-AMT(2)       TO L0290-INPUT-NUMBER.
010302*    MOVE 0                          TO L0290-PRECISION.
010302*    MOVE LENGTH OF MIR-BMAX2        TO L0290-MAX-OUT-LEN.
010302*    PERFORM 0290-1000-NUMERIC-FORMAT
010302*       THRU 0290-1000-NUMERIC-FORMAT-X.
010302*    MOVE L0290-OUTPUT-DATA          TO MIR-BMAX2.
557697     MOVE RPD-SFB-NEG-SUSP-IND  TO MIR-SFB-NEG-SUSP-IND.
008455*    MOVE RPH-FACE-BAND-AMT(3)       TO WS-FACE-BAND.
008455*    MOVE WS-FACE-BAND               TO MIR-BMAX3.
010302*    MOVE RPH-FACE-BAND-AMT(3)       TO L0290-INPUT-NUMBER.
010302*    MOVE 0                          TO L0290-PRECISION.
010302*    MOVE LENGTH OF MIR-BMAX3        TO L0290-MAX-OUT-LEN.
010302*    PERFORM 0290-1000-NUMERIC-FORMAT
010302*       THRU 0290-1000-NUMERIC-FORMAT-X.
010302*    MOVE L0290-OUTPUT-DATA          TO MIR-BMAX3.
557697     MOVE RPD-SFB-NEG-SUSP-QTY  TO MIR-SFB-NEG-SUSP-QTY.
008455*    MOVE RPH-FACE-BAND-AMT(4)       TO WS-FACE-BAND.
008455*    MOVE WS-FACE-BAND               TO MIR-BMAX4.
010302*    MOVE RPH-FACE-BAND-AMT(4)       TO L0290-INPUT-NUMBER.
010302*    MOVE 0                          TO L0290-PRECISION.
010302*    MOVE LENGTH OF MIR-BMAX4        TO L0290-MAX-OUT-LEN.
010302*    PERFORM 0290-1000-NUMERIC-FORMAT
010302*       THRU 0290-1000-NUMERIC-FORMAT-X.
010302*    MOVE L0290-OUTPUT-DATA          TO MIR-BMAX4.
557697     MOVE RPD-SFB-NEG-SUSP-QTY  TO MIR-SFB-NEG-SUSP-QTY.
           MOVE RPH-PREM-RENW-RT-CD   TO MIR-PREM-RENW-RT-CD.


008455*    MOVE RPD-PLAN-PFEE-AMT          TO WS-POLICY-FEE.
008455*    MOVE WS-POLICY-FEE              TO MIR-PLAN-PFEE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPD-PLAN-PFEE-AMT * 100.
020874     MOVE RPD-PLAN-PFEE-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-PFEE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-PFEE-AMT.
008455*    MOVE RPH-PLAN-MODE-FEE-AMT      TO WS-MODE-CONSTANT.
008455*    MOVE WS-MODE-CONSTANT           TO MIR-PLAN-MODE-FEE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-PLAN-MODE-FEE-AMT * 100.
020874     MOVE RPH-PLAN-MODE-FEE-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-MODE-FEE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-MODE-FEE-AMT.
008455*    MOVE RPD-PLAN-CVG-PFEE-AMT      TO WS-POLICY-FEE.
008455*    MOVE WS-POLICY-FEE              TO MIR-PLAN-CVG-PFEE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPD-PLAN-CVG-PFEE-AMT * 100.
020874     MOVE RPD-PLAN-CVG-PFEE-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-CVG-PFEE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-CVG-PFEE-AMT.
008455*    MOVE RPH-PAC-MODE-FEE-AMT       TO WS-MODE-CONSTANT.
008455*    MOVE WS-MODE-CONSTANT           TO MIR-PAC-MODE-FEE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-PAC-MODE-FEE-AMT * 100.
020874     MOVE RPH-PAC-MODE-FEE-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PAC-MODE-FEE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-MODE-FEE-AMT.

020467     MOVE RPH-DD2-MODE-FEE-AMT  TO L0290-INPUT-V02.
020467     MOVE 2                     TO L0290-PRECISION.
020467     MOVE LENGTH OF MIR-DD2-MODE-FEE-AMT
020467                                TO L0290-MAX-OUT-LEN.
020467     PERFORM  0290-2000-FORMAT-FOR-MIR
020467         THRU 0290-2000-FORMAT-FOR-MIR-X.
020467     MOVE L0290-OUTPUT-DATA     TO MIR-DD2-MODE-FEE-AMT.
020467
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-CRC-MODE-FEE-AMT * 100.
020874     MOVE RPH-CRC-MODE-FEE-AMT  TO L0290-INPUT-V02.
016395     MOVE 2                     TO L0290-PRECISION.
016395     MOVE LENGTH OF MIR-CRC-MODE-FEE-AMT
016395                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016395     MOVE L0290-OUTPUT-DATA     TO MIR-CRC-MODE-FEE-AMT.

008455*    MOVE RPD-PLAN-IA-PFEE-AMT       TO WS-IA-POLICY-FEE.
008455*    MOVE WS-IA-POLICY-FEE           TO MIR-PLAN-IA-PFEE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPD-PLAN-IA-PFEE-AMT * 100.
020874     MOVE RPD-PLAN-IA-PFEE-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-IA-PFEE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-IA-PFEE-AMT.
008455*    MOVE RPH-LBILL-MODE-FEE-AMT     TO WS-MODE-CONSTANT.
008455*    MOVE WS-MODE-CONSTANT           TO MIR-LBILL-MODE-FEE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-LBILL-MODE-FEE-AMT * 100.
020874     MOVE RPH-LBILL-MODE-FEE-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-MODE-FEE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LBILL-MODE-FEE-AMT.

016641*    MOVE RPD-PLAN-SEMI-ANN-FCT TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE           TO MIR-PLAN-SEMI-ANN-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PLAN-SEMI-ANN-FCT * 10000000.
020467*    MOVE RPD-PLAN-SEMI-ANN-FCT TO L0290-INPUT-V07.
020467*    MOVE                    7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PLAN-SEMI-ANN-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PLAN-SEMI-ANN-FCT.
020467*
016641*    MOVE RPD-PLAN-QTR-FCT      TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE           TO MIR-PLAN-QTR-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PLAN-QTR-FCT * 10000000.
020467*    MOVE RPD-PLAN-QTR-FCT TO L0290-INPUT-V07.
020467*    MOVE 7                TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PLAN-QTR-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PLAN-QTR-FCT.
020467*
016641*    MOVE RPD-PLAN-MTHLY-FCT    TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE           TO MIR-PLAN-MTHLY-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PLAN-MTHLY-FCT * 10000000.
020467*    MOVE RPD-PLAN-MTHLY-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PLAN-MTHLY-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PLAN-MTHLY-FCT.
020467*
016641*    MOVE RPD-PAC-SEMI-ANN-FCT  TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE           TO MIR-PAC-SEMI-ANN-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PAC-SEMI-ANN-FCT * 10000000.
020467*    MOVE RPD-PAC-SEMI-ANN-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PAC-SEMI-ANN-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PAC-SEMI-ANN-FCT.
020467*
016641*    MOVE RPD-PLAN-PAC-QTR-FCT  TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE           TO MIR-PLAN-PAC-QTR-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PLAN-PAC-QTR-FCT * 10000000.
020467*    MOVE RPD-PLAN-PAC-QTR-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PLAN-PAC-QTR-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PLAN-PAC-QTR-FCT.
020467*
016641*    MOVE RPD-PLAN-PAC-MTHLY-FCT TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE            TO MIR-PLAN-PAC-MTHLY-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PLAN-PAC-MTHLY-FCT * 10000000.
020467*    MOVE RPD-PLAN-PAC-MTHLY-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PLAN-PAC-MTHLY-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PLAN-PAC-MTHLY-FCT.
020467*
016641*    MOVE RPD-CRC-SEMI-ANN-FCT  TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE           TO MIR-CRC-SEMI-ANN-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-CRC-SEMI-ANN-FCT * 10000000.
020467*    MOVE RPD-CRC-SEMI-ANN-FCT TO L0290-INPUT-V07.
020467*    MOVE 7                    TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-CRC-SEMI-ANN-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-CRC-SEMI-ANN-FCT.
020467*
016641*    MOVE RPD-PLAN-CRC-QTR-FCT  TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE           TO MIR-PLAN-CRC-QTR-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PLAN-CRC-QTR-FCT * 10000000.
020467*    MOVE RPD-PLAN-CRC-QTR-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-CRC-SEMI-ANN-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PLAN-CRC-QTR-FCT.
020467*
016641*    MOVE RPD-PLAN-CRC-MTHLY-FCT   TO WS-XXX-MODE.
016641*    MOVE WS-XXX-MODE           TO MIR-PLAN-CRC-MTHLY-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PLAN-CRC-MTHLY-FCT * 10000000.
020467*    MOVE RPD-PLAN-CRC-MTHLY-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-CRC-SEMI-ANN-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PLAN-CRC-MTHLY-FCT.
020467*
016641*    MOVE RPD-SEMI-ANN-PFEE-FCT TO WS-POL-FEE-XXX-MODE.
016641*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-SEMI-ANN-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-SEMI-ANN-PFEE-FCT * 10000000.
020467*    MOVE RPD-SEMI-ANN-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-SEMI-ANN-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-SEMI-ANN-PFEE-FCT.
020467*
016641*    MOVE RPD-PLAN-QTR-PFEE-FCT TO WS-POL-FEE-XXX-MODE.
016641*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-PLAN-QTR-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PLAN-QTR-PFEE-FCT * 10000000.
020467*    MOVE RPD-PLAN-QTR-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PLAN-QTR-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PLAN-QTR-PFEE-FCT.
020467*
016641*    MOVE RPD-MTHLY-PFEE-FCT    TO WS-POL-FEE-XXX-MODE.
016641*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-MTHLY-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-MTHLY-PFEE-FCT * 10000000.
020467*    MOVE RPD-MTHLY-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-MTHLY-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-MTHLY-PFEE-FCT.
020467*
016641*    MOVE RPD-PAC-SEMI-PFEE-FCT TO WS-POL-FEE-XXX-MODE.
016641*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-PAC-SEMI-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PAC-SEMI-PFEE-FCT * 10000000.
020467*    MOVE RPD-PAC-SEMI-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PAC-SEMI-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PAC-SEMI-PFEE-FCT.
020467*
016641*    MOVE RPD-PAC-QTR-PFEE-FCT  TO WS-POL-FEE-XXX-MODE.
016641*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-PAC-QTR-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PAC-QTR-PFEE-FCT * 10000000.
020467*    MOVE RPD-PAC-QTR-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PAC-QTR-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PAC-QTR-PFEE-FCT.
020467*
016641*    MOVE RPD-PAC-MTHLY-PFEE-FCT           TO WS-POL-FEE-XXX-MODE.
016641*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-PAC-MTHLY-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-PAC-MTHLY-PFEE-FCT * 10000000.
020467*    MOVE RPD-PAC-MTHLY-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-PAC-MTHLY-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-PAC-MTHLY-PFEE-FCT.

016641*    MOVE RPD-CRC-SEMI-PFEE-FCT TO WS-POL-FEE-XXX-MODE.
016641*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-CRC-SEMI-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-CRC-SEMI-PFEE-FCT * 10000000.
020467*    MOVE RPD-CRC-SEMI-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-CRC-SEMI-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-CRC-SEMI-PFEE-FCT.

016641*    MOVE RPD-CRC-QTR-PFEE-FCT  TO WS-POL-FEE-XXX-MODE.
016641*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-CRC-QTR-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-CRC-QTR-PFEE-FCT * 10000000.
020467*    MOVE RPD-CRC-QTR-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-CRC-QTR-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-CRC-QTR-PFEE-FCT.

016641*    MOVE RPD-CRC-MTHLY-PFEE-FCT   TO WS-POL-FEE-XXX-MODE.
020467*    MOVE WS-POL-FEE-XXX-MODE   TO MIR-CRC-MTHLY-PFEE-FCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-CRC-MTHLY-PFEE-FCT * 10000000.
020467*    MOVE RPD-CRC-MTHLY-PFEE-FCT TO L0290-INPUT-V07.
020467*    MOVE 7  TO L0290-PRECISION.
020467*    MOVE LENGTH OF MIR-CRC-MTHLY-PFEE-FCT
020467*                               TO L0290-MAX-OUT-LEN.
020467*    SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020467*    PERFORM  0290-2000-FORMAT-FOR-MIR
020467*        THRU 0290-2000-FORMAT-FOR-MIR-X.
020467*    MOVE L0290-OUTPUT-DATA TO MIR-CRC-MTHLY-PFEE-FCT.

           MOVE RPH-COMM-RT-TBAC-CD   TO MIR-COMM-RT-TBAC-CD.
           MOVE RPD-COMM-PLAN-TYP-CD  TO MIR-COMM-PLAN-TYP-CD.
           MOVE RPH-COMM-RH-SUB-CD    TO MIR-COMM-RH-SUB-CD.

           MOVE RPD-PLAN-CPREM-CALC-CD     TO MIR-PLAN-CPREM-CALC-CD.
           MOVE RPH-FYR-COMM-XTRA-RT  TO WS-FYC-EXTRA.
           MOVE WS-FYC-EXTRA          TO MIR-FYR-COMM-XTRA-RT.
           MOVE RPD-OVRID-FRST-DGT-CD TO MIR-OVRID-FRST-DGT-CD.
           MOVE RPH-PLAN-MDRT-CLAS-CD TO MIR-PLAN-MDRT-CLAS-CD.

      *    MOVE RPH-PLAN-FND-COMM-CD       TO MIR-FNDIND.
      *    MOVE RPH-PLAN-DED-COMM-CD       TO MIR-DRWIND.
      *    MOVE RPH-PLAN-FND-COMM-INFO     TO MIR-FNDPTR.
      *    MOVE RPH-PLAN-DED-COMM-INFO     TO MIR-DRWPTR.

           MOVE RPH-COMM-RT-LOOP-IND  TO MIR-COMM-RT-LOOP-IND.

012148     MOVE RPH-TRAIL-COMM-BEG-DUR        TO MIR-TRAIL-COMM-BEG-DUR.
012148     MOVE RPH-TRAIL-COMM-FREQ-CD        TO MIR-TRAIL-COMM-FREQ-CD.
012148     MOVE RPH-TRAIL-COMM-LAG-DUR        TO MIR-TRAIL-COMM-LAG-DUR.


           MOVE RPH-CSV-CALC-MTHD-CD  TO MIR-CSV-CALC-MTHD-CD.
022730*    MOVE RPH-PREM-PAY-UVAL-ID  TO MIR-PREM-PAY-UVAL-ID.
022730*    MOVE RPH-PU-UVAL-ID        TO MIR-PU-UVAL-ID.
           MOVE RPH-PLAN-CSV-DT-TYP-CD     TO MIR-PLAN-CSV-DT-TYP-CD.
016641*    MOVE RPH-TRM-PREM-RFND-RT  TO WS-PREMIUM-REFUND-RATE.
016641*    MOVE WS-PREMIUM-REFUND-RATE          TO MIR-TRM-PREM-RFND-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPH-TRM-PREM-RFND-RT * 10000.
020874     MOVE RPH-TRM-PREM-RFND-RT TO L0290-INPUT-V04.
016641     MOVE 4                    TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-TRM-PREM-RFND-RT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-TRM-PREM-RFND-RT.
016641

011026     MOVE RPH-MCV-CALC-REQIR-IND        TO MIR-MCV-CALC-REQIR-IND.
011026     MOVE RPH-MCV-INT-MTHD-CD   TO MIR-MCV-INT-MTHD-CD.
011026     MOVE RPH-MCV-PMT-LOAD-CD   TO MIR-MCV-PMT-LOAD-CD.
011026     MOVE RPH-PLAN-EIC-FREQ-CD  TO MIR-PLAN-EIC-FREQ-CD.
011026     MOVE RPH-EIC-INIT-YR-DUR   TO MIR-EIC-INIT-YR-DUR.
011026     MOVE RPH-EIC-SUBSEQ-YR-DUR TO MIR-EIC-SUBSEQ-YR-DUR.
031035     MOVE RPH-INT-RT-LK-UP-CD   TO MIR-INT-RT-LK-UP-CD.
                                                               
           MOVE RPH-PLAN-CF-TYP-CD    TO MIR-PLAN-CF-TYP-CD.
           MOVE RPD-PLAN-INT-PAYO-CD  TO MIR-PLAN-INT-PAYO-CD.
           MOVE RPD-PLAN-WTHDR-ORDR-CD     TO MIR-PLAN-WTHDR-ORDR-CD.
           MOVE RPH-CF-INT-MODE-CD    TO MIR-CF-INT-MODE-CD.
           MOVE RPH-CSV-INT-RT-ID     TO MIR-CSV-INT-RT-ID.
           MOVE RPH-CF-INT-CALC-TYP-CD        TO MIR-CF-INT-CALC-TYP-CD.
           MOVE RPH-PDF-INT-RT-ID     TO MIR-PDF-INT-RT-ID.
           MOVE RPH-INT-ADJ-MAX-DUR-N TO MIR-INT-ADJ-MAX-DUR.

           MOVE RPH-MIN-ROLOVR-DUR-INFO
                                      TO MIR-MIN-ROLOVR-DY-DUR.
016641*    MOVE RPH-PLAN-GUAR-INT-RT  TO WS-GUAR-INT-RATE.
016641*    MOVE WS-GUAR-INT-RATE      TO MIR-PLAN-GUAR-INT-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPH-PLAN-GUAR-INT-RT * 100000.
020874     MOVE RPH-PLAN-GUAR-INT-RT TO L0290-INPUT-V05.
016641     MOVE 5  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-PLAN-GUAR-INT-RT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-PLAN-GUAR-INT-RT.
016641
           MOVE RPH-MAX-ROLOVR-DUR-INFO
                                      TO MIR-MAX-ROLOVR-DY-DUR.
008455*    MOVE RPH-ACUM-BRKPT-AMT         TO WS-ACCUM-BREAKPOINT.
008455*    MOVE WS-ACCUM-BREAKPOINT        TO MIR-ACUM-BRKPT-AMT.
020874*    MOVE RPH-ACUM-BRKPT-AMT    TO L0290-INPUT-NUMBER.
020874     MOVE RPH-ACUM-BRKPT-AMT    TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-ACUM-BRKPT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-ACUM-BRKPT-AMT.
           MOVE RPH-PLAN-ROLOVR-TYP-CD     TO MIR-PLAN-ROLOVR-TYP-CD.
           MOVE RPD-DIA-SWP-THRSHD-CD TO MIR-DIA-SWP-THRSHD-CD.
           MOVE RPD-PLAN-ROLOVR-DT-IND     TO MIR-PLAN-ROLOVR-DT-IND.
008455*    MOVE RPD-DIA-SWP-THRSHD-AMT     TO WS-MIN-SWEEP-AMT.
008455*    MOVE WS-MIN-SWEEP-AMT           TO MIR-DIA-SWP-THRSHD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPD-DIA-SWP-THRSHD-AMT * 100.
020874     MOVE RPD-DIA-SWP-THRSHD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIA-SWP-THRSHD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DIA-SWP-THRSHD-AMT.


           MOVE RPH-PREM-CHNG-DT-CD   TO MIR-PREM-CHNG-DT-CD.
           MOVE RPH-XPRY-DT-CALC-CD   TO MIR-XPRY-DT-CALC-CD.
           MOVE RPH-PREM-CHNG-AGE-DUR-N
                                      TO MIR-PREM-CHNG-AGE-DUR.
           MOVE RPH-PLAN-BASE-XPRY-AGE-N
                                      TO MIR-PLAN-BASE-XPRY-AGE.
           MOVE RPH-INIT-PREM-CHNG-AGE-N
                                      TO MIR-INIT-PREM-CHNG-AGE.
           MOVE RPH-POL-XPRY-AGE-DUR-N          TO MIR-POL-XPRY-AGE-DUR.
           MOVE RPH-ULT-PREM-CHNG-AGE-N
                                      TO MIR-ULT-PREM-CHNG-AGE.
           MOVE RPH-PLAN-CVG-XPRY-AGE-N
                                      TO MIR-PLAN-CVG-XPRY-AGE.
           MOVE RPH-MAT-DT-CALC-CD    TO MIR-MAT-DT-CALC-CD.
           MOVE RPH-CVG-XPRY-AGE-DUR-N          TO MIR-CVG-XPRY-AGE-DUR.
           MOVE RPH-PLAN-MAT-AGE-N    TO MIR-PLAN-MAT-AGE.
           MOVE RPH-CNVR-XPRY-DT-CD   TO MIR-CNVR-XPRY-DT-CD.
           MOVE RPH-PLAN-MAT-AGE-DUR-N       TO MIR-PLAN-MAT-AGE-DUR.
           MOVE RPH-CNVR-XPRY-AGE-DUR TO MIR-CNVR-XPRY-AGE-DUR.
012146     MOVE RPH-MORT-XPNS-CALC-CD TO MIR-MORT-XPNS-CALC-CD.
012146     MOVE RPH-MORT-XPNS-CHRG-AGE        TO MIR-MORT-XPNS-CHRG-AGE.
012146     MOVE RPH-MORT-XPNS-CHRG-DUR        TO MIR-MORT-XPNS-CHRG-DUR.

           MOVE RPH-PLAN-WP-XPRY-AGE-N       TO MIR-PLAN-WP-XPRY-AGE.
           MOVE RPH-PLAN-WP-XPRY-CD   TO MIR-PLAN-WP-XPRY-CD.
016534*    MOVE RPH-PLAN-DUR-TYP-CD   TO MIR-PLAN-DUR-TYP-CD.
           MOVE RPH-PLAN-ADB-XPRY-AGE-N
                                      TO MIR-PLAN-ADB-XPRY-AGE.
           MOVE RPH-REDC-EP-XPRY-AGE-N          TO MIR-REDC-EP-XPRY-AGE.
           MOVE RPH-PLAN-LTA-XPRY-AGE-N
                                      TO MIR-PLAN-LTA-XPRY-AGE.
           MOVE RPH-OWN-OCCP-XPRY-AGE-N
                                      TO MIR-OWN-OCCP-XPRY-AGE.
           MOVE RPH-PLAN-LTB-XPRY-AGE-N
                                      TO MIR-PLAN-LTB-XPRY-AGE.
           MOVE RPH-PDISAB-XPRY-AGE-N TO MIR-PDISAB-XPRY-AGE.
           MOVE RPH-PLAN-COLA-XPRY-AGE-N
                                      TO MIR-PLAN-COLA-XPRY-AGE.

018905*    MOVE RPH-PLAN-MAT-MAX-AGE-N       TO MIR-PLAN-MAT-MAX-AGE.
018905*    MOVE RPH-PLAN-MAT-MAX-DUR-N       TO MIR-PLAN-MAT-MAX-DUR.
018905*    MOVE RPH-POL-XPRY-MAX-DUR-N       TO MIR-POL-XPRY-MAX-DUR.
018905*    MOVE RPH-BASE-XPRY-MAX-AGE-N      TO MIR-BASE-XPRY-MAX-AGE.
018905*    MOVE RPH-CVG-XPRY-MAX-DUR-N       TO MIR-CVG-XPRY-MAX-DUR.
018905*    MOVE RPH-CVG-XPRY-MAX-AGE-N       TO MIR-CVG-XPRY-MAX-AGE.

           MOVE RPH-NOTI-DT-CALC-CD   TO MIR-NOTI-DT-CALC-CD.
           MOVE RPH-NOTI-LOW-AGE-DUR-N          TO MIR-NOTI-LOW-AGE-DUR.
           MOVE RPH-NOTI-HIGH-AGE-DUR-N
                                      TO MIR-NOTI-HIGH-AGE-DUR.
           MOVE RPH-PLAN-NOTI-REASN-CD     TO MIR-PLAN-NOTI-REASN-CD.
           MOVE RPH-NOTI-DEPT-ID      TO MIR-NOTI-DEPT-ID.

557693     MOVE RPH-PERI-STMT-TYP-CD  TO MIR-PERI-STMT-TYP-CD.
557693     MOVE RPH-PERI-STMT-DY-DUR  TO WS-PERI-STMT-DY-DUR.
557693     MOVE WS-PERI-STMT-DY-DUR   TO MIR-PERI-STMT-DY-DUR.
557693     MOVE RPH-PERI-STMT-MO-DUR  TO WS-PERI-STMT-MO-DUR.
557693     MOVE WS-PERI-STMT-MO-DUR   TO MIR-PERI-STMT-MO-DUR.


           MOVE RPH-LOAN-INT-CALC-CD  TO MIR-LOAN-INT-CALC-CD.
012145     MOVE RPD-PLAN-COLFND-IND   TO MIR-PLAN-COLFND-IND.
012145     MOVE RPH-COLFND-REQIR-IND  TO MIR-COLFND-REQIR-IND.
           MOVE RPH-LOAN-INT-RT-ID    TO MIR-LOAN-INT-RT-ID.
           MOVE RPH-APL-INT-RT-ID     TO MIR-APL-INT-RT-ID.
           MOVE RPH-LOAN-INT-RT-TYP-CD        TO MIR-LOAN-INT-RT-TYP-CD.
016641*    MOVE RPH-PLAN-LOAN-INT-RT  TO WS-LOAN-INTEREST-RATE.
016641*    MOVE WS-LOAN-INTEREST-RATE TO MIR-PLAN-LOAN-INT-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPH-PLAN-LOAN-INT-RT * 100000.
020874     MOVE RPH-PLAN-LOAN-INT-RT TO L0290-INPUT-V05.
016641     MOVE 5  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-PLAN-LOAN-INT-RT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-PLAN-LOAN-INT-RT.
016641
010651*    MOVE RPH-LOAN-INT-MAX-RT        TO WS-LOAN-INTEREST-RATE.
010651*    MOVE WS-LOAN-INTEREST-RATE      TO MIR-VARIRT.
           MOVE RPH-PLAN-IMPRD-RT-CD  TO MIR-PLAN-IMPRD-RT-CD.
016641*    MOVE RPH-PLAN-IMPRD-INT-RT TO WS-IMPAIRED-INT-RATE.
016641*    MOVE WS-IMPAIRED-INT-RATE  TO MIR-PLAN-IMPRD-INT-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPH-PLAN-IMPRD-INT-RT * 100000.
020874     MOVE RPH-PLAN-IMPRD-INT-RT TO L0290-INPUT-V05.
016641     MOVE 5  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-PLAN-IMPRD-INT-RT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-PLAN-IMPRD-INT-RT.
016641

           MOVE RPH-PLAN-PAR-CD       TO MIR-PLAN-PAR-CD.
010648*    MOVE RPD-PLAN-DIV-OPT-CD        TO MIR-DIVOPT.
           MOVE RPH-DOD-INT-RT-ID     TO MIR-DOD-INT-RT-ID.
035251*    MOVE RPH-DIV-OYT-TBAC-ID   TO MIR-DIV-OYT-TBAC-ID.
557659*    MOVE RPH-DIV-PUA-TBAC-ID-1-2    TO MIR-DIV-PUA-TBAC-ID.
035251*    MOVE RPH-DIV-PUA-TBAC-ID   TO MIR-DIV-PUA-TBAC-ID.
016641*    MOVE RPH-PLAN-RPU-DIV-RT   TO WS-LOAN-INTEREST-RATE.
016641*    MOVE WS-LOAN-INTEREST-RATE TO MIR-PLAN-RPU-DIV-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPH-PLAN-RPU-DIV-RT * 100000.
020874     MOVE RPH-PLAN-RPU-DIV-RT TO L0290-INPUT-V05.
016641     MOVE 5  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-PLAN-RPU-DIV-RT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-PLAN-RPU-DIV-RT.
016641
020874*    MOVE RPH-PLAN-BON-EFF-MO   TO WS-BON-EFF-MM.
020874*    MOVE WS-BON-EFF-MM         TO MIR-PLAN-BON-EFF-MO.
020874     MOVE RPH-PLAN-BON-EFF-MO   TO L0290-INPUT-V00
020874     MOVE ZERO                  TO L0290-PRECISION
020874     MOVE LENGTH OF MIR-PLAN-BON-EFF-MO
020874                                TO L0290-MAX-OUT-LEN
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X
020874     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-BON-EFF-MO
020874*    MOVE RPH-PLAN-BON-EFF-DY   TO WS-BON-EFF-DY.
020874*    MOVE WS-BON-EFF-DY         TO MIR-PLAN-BON-EFF-DY.
020874     MOVE RPH-PLAN-BON-EFF-DY   TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-PLAN-BON-EFF-DY
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-BON-EFF-DY.
016016     MOVE RPH-PLAN-BON-CALC-CD  TO MIR-PLAN-BON-CALC-CD.
016016     MOVE RPH-PUA-DIV-CALC-CD   TO MIR-PUA-DIV-CALC-CD.
013585     MOVE RPH-PLAN-CVG-LOAN-IND TO MIR-PLAN-CVG-LOAN-IND.


010304*    MOVE RPD-PLAN-NFO-CD            TO MIR-NFO.
010300*    MOVE RPH-RMND-NOTI-DUR-INFO     TO MIR-RMND.
010650*    MOVE RPH-INIT-GRACE-DUR-INFO    TO MIR-ULIGRC.
010304*    MOVE RPH-LAPS-NOTI-DUR-INFO     TO MIR-LAPSE.
010650*    MOVE RPH-UL-NLAPS-GUAR-DUR-N    TO MIR-ULGUAR.
           MOVE RPH-NF-PRCES-DUR-INFO TO MIR-NF-PRCES-MO-DUR.
012522     MOVE RPH-PLAN-MIN-PU-AMT        TO WS-PLAN-MIN-PU-AMT.
012522     MOVE WS-PLAN-MIN-PU-AMT         TO MIR-PLAN-MIN-PU-AMT.
010650*    MOVE RPH-UL-NLAPS-DED-QTY-N     TO MIR-ULPERS.

035251*    MOVE RPH-RPU-TBAC-ID       TO MIR-RPU-TBAC-ID.
035251     MOVE RPH-RPU-PLAN-ID       TO MIR-RPU-PLAN-ID.
           MOVE RPH-ETI-FACE-CALC-CD  TO MIR-ETI-FACE-CALC-CD.
014591*    MOVE RPH-FPU-PLAN-ID       TO MIR-FPU-PLAN-BASE-ID.
035251*    MOVE RPH-ETI-TBAC-ID       TO MIR-ETI-TBAC-ID.
035251     MOVE RPH-ETI-PLAN-ID       TO MIR-ETI-PLAN-ID.
012136     MOVE RPH-FREE-LK-PRCES-IND TO MIR-FREE-LK-PRCES-IND.
031037*    MOVE RPH-FREE-LK-INCR-CD   TO MIR-FREE-LK-INCR-CD.
013930     MOVE RPH-PLAN-DIV-INT-RT-ID     TO MIR-PLAN-DIV-INT-RT-ID.
013930     MOVE RPH-PLAN-BON-INT-RT-ID     TO MIR-PLAN-BON-INT-RT-ID.


010302*    MOVE RPH-NEW-MONY-ADJ-CD        TO MIR-CVGADJ.
           MOVE RPH-PLAN-VPO-IND      TO MIR-PLAN-VPO-IND.
010302*    MOVE RPH-NEW-MONY-RS-ID         TO MIR-CVGRS.
010302*    MOVE RPH-NEW-MONY-TRM-DUR-N     TO MIR-CVGYRS.

           MOVE RPH-ISWL-FRST-CALC-DUR-N
                                      TO MIR-ISWL-FRST-CALC-DUR.
           MOVE RPH-ISWL-CALC-FREQ-DUR-N
                                      TO MIR-ISWL-CALC-FREQ-DUR.
           MOVE RPH-ISWL-CALC-ADV-DUR-N
                                      TO MIR-ISWL-CALC-ADV-DUR.
           MOVE RPD-PREM-RECALC-OPT-CD        TO MIR-PREM-RECALC-OPT-CD.
016641*    MOVE RPH-ISWL-PREM-VAR-RT  TO WS-PCT-PREM-VAR.
016641*    MOVE WS-PCT-PREM-VAR       TO MIR-ISWL-PREM-VAR-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPH-ISWL-PREM-VAR-RT * 100000.
020874     MOVE RPH-ISWL-PREM-VAR-RT TO L0290-INPUT-V05.
016641     MOVE 5  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-ISWL-PREM-VAR-RT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-ISWL-PREM-VAR-RT.

           MOVE RPH-FPUL-ADDL-PREM-IND        TO MIR-FPUL-ADDL-PREM-IND.
           MOVE RPH-FPUL-LOAD-TYP-CD  TO MIR-FPUL-LOAD-TYP-CD.
           MOVE RPD-AUTO-PREM-PMT-IND TO MIR-AUTO-PREM-PMT-IND.

010314     MOVE RPH-INDX-INCR-MTHD-CD TO MIR-INDX-INCR-MTHD-CD.
010314     MOVE RPH-INDX-INCR-MO-DUR  TO MIR-INDX-INCR-MO-DUR.
010314     MOVE RPH-INDX-INCR-DY-DUR  TO MIR-INDX-INCR-DY-DUR.


           MOVE RPH-PMT-LOAD-ORDR-CD  TO MIR-PMT-LOAD-ORDR-CD.
           MOVE RPH-PMT-LOAD-RTBL2-ID TO MIR-PMT-LOAD-RTBL2-ID.
008455*    MOVE RPH-PMT-LOAD-FLAT-AMT      TO WS-FEL-FLAT.
008455*    MOVE WS-FEL-FLAT                TO MIR-PMT-LOAD-FLAT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-PMT-LOAD-FLAT-AMT * 100.
020874     MOVE RPH-PMT-LOAD-FLAT-AMT TO L0290-INPUT-V02.
016641     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PMT-LOAD-FLAT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PMT-LOAD-FLAT-AMT.
010302*    MOVE RPH-PMT-LOAD-RH-ID         TO MIR-PAYRH.
           MOVE RPH-PMT-LOAD-CALC-CD  TO MIR-PMT-LOAD-CALC-CD.

008455*    MOVE RPH-DIR-DPOS-MIN-AMT       TO WS-DEP-MIN.
008455*    MOVE WS-DEP-MIN                 TO MIR-DIR-DPOS-MIN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-DIR-DPOS-MIN-AMT * 100.
020874     MOVE RPH-DIR-DPOS-MIN-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-DPOS-MIN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DIR-DPOS-MIN-AMT.
008455*    MOVE RPH-PAC-DPOS-MIN-AMT       TO WS-DEP-MIN.
008455*    MOVE WS-DEP-MIN                 TO MIR-PAC-DPOS-MIN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-PAC-DPOS-MIN-AMT * 100.
020874     MOVE RPH-PAC-DPOS-MIN-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PAC-DPOS-MIN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DPOS-MIN-AMT.
020467
020467     MOVE RPH-DD2-DPOS-MIN-AMT  TO L0290-INPUT-V02.
020467     MOVE 2                     TO L0290-PRECISION.
020467     MOVE LENGTH OF MIR-DD2-DPOS-MIN-AMT
020467                                TO L0290-MAX-OUT-LEN.
020467     PERFORM   0290-2000-FORMAT-FOR-MIR
020467          THRU 0290-2000-FORMAT-FOR-MIR-X.
020467     MOVE L0290-OUTPUT-DATA     TO MIR-DD2-DPOS-MIN-AMT.

017150*    COMPUTE L0290-INPUT-NUMBER = RPH-CRC-DPOS-MIN-AMT * 100.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-CRC-DPOS-MIN-AMT
020874*                                   * L0290-CRCY-MULT-FCT.
018763*                                   * WGLOB-CRCY-SCALE-QTY.
020874     EVALUATE TRUE
020874        WHEN L0290-CRCY-MULT-FCT-0-DCML
020874           MOVE RPH-CRC-DPOS-MIN-AMT TO L0290-INPUT-V00
020874
020874        WHEN L0290-CRCY-MULT-FCT-1-DCML
020874           MOVE RPH-CRC-DPOS-MIN-AMT TO L0290-INPUT-V01
020874
020874        WHEN L0290-CRCY-MULT-FCT-2-DCML
020874           MOVE RPH-CRC-DPOS-MIN-AMT TO L0290-INPUT-V02
020874
020874        WHEN OTHER
020874           MOVE RPH-CRC-DPOS-MIN-AMT TO L0290-INPUT-V00
020874     END-EVALUATE.
017150*    MOVE 2                     TO L0290-PRECISION.
017150     MOVE WGLOB-CRCY-SCALE-QTY  TO L0290-PRECISION.
016395     MOVE LENGTH OF MIR-CRC-DPOS-MIN-AMT
016395                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.

016395     MOVE L0290-OUTPUT-DATA     TO MIR-CRC-DPOS-MIN-AMT.

019135     MOVE RPH-PLAN-INIT-PMT-IND TO MIR-PLAN-INIT-PMT-IND.

           MOVE RPH-SURR-ADJ-CALC-CD  TO MIR-SURR-ADJ-CALC-CD.
008455*    MOVE RPH-PLAN-ADMIN-FEE-AMT     TO WS-ADMIN-FEE.
008455*    MOVE WS-ADMIN-FEE               TO MIR-PLAN-ADMIN-FEE-AMT.
016307*    COMPUTE L0290-INPUT-NUMBER = RPH-PLAN-ADMIN-FEE-AMT * 100.
016307*    MOVE 2                     TO L0290-PRECISION.
016307*    MOVE LENGTH OF MIR-PLAN-ADMIN-FEE-AMT
016307*                               TO L0290-MAX-OUT-LEN.
016307*    PERFORM 0290-1000-NUMERIC-FORMAT
016307*       THRU 0290-1000-NUMERIC-FORMAT-X.
016307*    MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-ADMIN-FEE-AMT.
           MOVE RPH-SURR-ADJ-MO-DUR   TO WS-MTHV-ADJ-MONTHS.
           MOVE WS-MTHV-ADJ-MONTHS    TO MIR-SURR-ADJ-MO-DUR.
008455*    MOVE RPH-ADMIN-FEE-WAV-AMT      TO WS-ADMIN-FEE-WAIVER.
008455*    MOVE WS-ADMIN-FEE-WAIVER        TO MIR-ADMIN-FEE-WAV-AMT.
016307*    COMPUTE L0290-INPUT-NUMBER = RPH-ADMIN-FEE-WAV-AMT * 100.
016307*    MOVE 2                     TO L0290-PRECISION.
016307*    MOVE LENGTH OF MIR-ADMIN-FEE-WAV-AMT
016307*                               TO L0290-MAX-OUT-LEN.
016307*    PERFORM 0290-1000-NUMERIC-FORMAT
016307*       THRU 0290-1000-NUMERIC-FORMAT-X.
016307*    MOVE L0290-OUTPUT-DATA     TO MIR-ADMIN-FEE-WAV-AMT.
           MOVE RPH-SURR-ADJ-TYP-CD   TO MIR-SURR-ADJ-TYP-CD.
           MOVE RPH-MAT-CHRG-RTBL2-ID TO MIR-MAT-CHRG-RTBL2-ID.
           MOVE RPH-AFR-THRSHD-CD     TO MIR-AFR-THRSHD-CD.
           MOVE RPH-PLAN-MKTVAL-ADJ-CD     TO MIR-PLAN-MKTVAL-ADJ-CD.
           MOVE RPD-AFR-THRSHD-PERI-CD        TO MIR-AFR-THRSHD-PERI-CD.
010650*    MOVE RPD-FREE-WTHDR-CD          TO MIR-FREEW.
010302*    MOVE RPH-AFR-THRSHD-RH-ID       TO MIR-AFR-THRSHD-PERI-CDT.
010302*    MOVE RPD-FREE-WTHDR-QTY         TO WS-FREE-WTHDR-QTY.
010650*    MOVE WS-FREE-WTHDR-QTY          TO MIR-FREEWN.
           MOVE RPH-PLAN-SURR-CHRG-CD TO MIR-PLAN-SURR-CHRG-CD.
010650*           MOVE RPH-FREE-WTHDR-RH-ID       TO MIR-FREEWPT.
           MOVE RPH-SURR-CHRG-CALC-CD TO MIR-SURR-CHRG-CALC-CD.
012143     MOVE RPH-DPOS-WTHDR-ORDR-CD        TO MIR-DPOS-WTHDR-ORDR-CD.
010650*    MOVE RPD-FREE-WTHDR-PERI-CD     TO MIR-FREEWPD.

           MOVE RPH-PSUR-CHRG-TYP-CD  TO MIR-PSUR-CHRG-TYP-CD.
008455*    MOVE RPH-PSUR-CHRG-FLAT-AMT     TO WS-PAR-SUR-CHG-FLAT.
008455*    MOVE WS-PAR-SUR-CHG-FLAT        TO MIR-PSUR-CHRG-FLAT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-PSUR-CHRG-FLAT-AMT * 100.
020874     MOVE RPH-PSUR-CHRG-FLAT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PSUR-CHRG-FLAT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PSUR-CHRG-FLAT-AMT.
           MOVE RPH-PSUR-CHRG-RTBL2-ID        TO MIR-PSUR-CHRG-RTBL2-ID.
010302*    MOVE RPH-PSUR-CHRG-RH-ID        TO MIR-PSURRH.

           MOVE RPH-SURR-CHRG-TYP-CD  TO MIR-SURR-CHRG-TYP-CD.
008455*    MOVE RPH-SURR-CHRG-FLAT-AMT     TO WS-SUR-CHARGE-FLAT.
008455*    MOVE WS-SUR-CHARGE-FLAT         TO MIR-SURR-CHRG-FLAT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-SURR-CHRG-FLAT-AMT * 100.
020874     MOVE RPH-SURR-CHRG-FLAT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-SURR-CHRG-FLAT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-SURR-CHRG-FLAT-AMT.
           MOVE RPH-SURR-CHRG-RTBL2-ID        TO MIR-SURR-CHRG-RTBL2-ID.
010302*    MOVE RPH-SURR-CHRG-RH-ID        TO MIR-FSURRH.


010302*    MOVE RPH-MNPMT-TRG-RH-ID        TO MIR-MNPTPA.
010302*    MOVE RPH-PMT-LOAD-TRG-RH-ID     TO MIR-PYLTPA.
010302*    MOVE RPH-COMM-TRG-RH-ID         TO MIR-CMTGPA.
010302*    MOVE RPH-SURR-TRG-RH-ID         TO MIR-SURTPA.
           MOVE RPH-PMT-ALLOC-MTHD-CD TO MIR-PMT-ALLOC-MTHD-CD.

           MOVE RPH-MNPMT-TRG-SSTD-IND        TO MIR-MNPMT-TRG-SSTD-IND.
           MOVE RPH-PMT-LOAD-SSTD-IND TO MIR-PMT-LOAD-SSTD-IND.
           MOVE RPH-COMM-TRG-SSTD-IND TO MIR-COMM-TRG-SSTD-IND.
           MOVE RPH-SURR-TRG-SSTD-IND TO MIR-SURR-TRG-SSTD-IND.
010302*
010302*    MOVE RPH-SETUP-CHRG-INFO        TO MIR-ISCHPA.
010302*    MOVE RPH-PERI-LOAD-INFO         TO MIR-ADEXPA.
010302*    MOVE RPH-PLAN-COI-INFO          TO MIR-COIPA.
010302*    MOVE RPH-PLAN-GUAR-COI-INFO     TO MIR-GCOIPA.
010302*    MOVE RPH-GDLN-DB-CORDR-ID       TO MIR-DBCOR.

010302*    MOVE RPH-PLAN-SETUP-CHRG-CD     TO MIR-ISCHKC.
010302*    MOVE RPH-PLAN-PERI-LOAD-CD      TO MIR-ADEXKC.
010302*    MOVE RPH-PLAN-COI-CD            TO MIR-COIKC.
010302*    MOVE RPH-PLAN-GUAR-COI-CD       TO MIR-GCOIKC.
010302*    MOVE RPH-GDLN-DB-CORDR-CD       TO MIR-DBCORK.
           MOVE RPH-CV-ALLOC-MTHD-CD  TO MIR-CV-ALLOC-MTHD-CD.
           MOVE RPH-CVG-CV-ALLOC-IND  TO MIR-CVG-CV-ALLOC-IND.
016641*    MOVE RPH-PLAN-NAR-DSCNT-RT TO WS-RISK-RATE-DIVISOR.
016641*    MOVE WS-RISK-RATE-DIVISOR  TO MIR-PLAN-NAR-DSCNT-RT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPH-PLAN-NAR-DSCNT-RT * 100000000.
020874     MOVE RPH-PLAN-NAR-DSCNT-RT TO L0290-INPUT-V08.
016641     MOVE 8                     TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-PLAN-NAR-DSCNT-RT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-PLAN-NAR-DSCNT-RT.


010302*    MOVE RPH-ALG-PREM-TBAC-CD       TO MIR-LVAIND.
010302*    MOVE RPH-ALG-PREM-TBAC-ID       TO MIR-LVAPTA.
010302*    MOVE RPH-SLG-PREM-TBAC-CD       TO MIR-LVSIND.
010302*    MOVE RPH-SLG-PREM-TBAC-ID       TO MIR-LVSPTA.
010302*    MOVE RPH-AIG-PREM-TBAC-CD       TO MIR-INCAIN.
010302*    MOVE RPH-AIG-PREM-TBAC-ID       TO MIR-INCAPA.
010302*    MOVE RPH-SIG-PREM-TBAC-CD       TO MIR-INCSIN.
010302*    MOVE RPH-SIG-PREM-TBAC-ID       TO MIR-INCSPT.

015919*    MOVE RPH-PLAN-TAMRA-IND    TO MIR-PLAN-TAMRA-IND.
015919     MOVE RPH-PLAN-TAMRA-CD     TO MIR-PLAN-TAMRA-CD.
035251*    MOVE RPH-PLAN-TAMRA-MXDX-ID     TO MIR-PLAN-TAMRA-MXDX-ID.
035251*    MOVE RPH-PLAN-7702-MXDX-ID TO MIR-PLAN-7702-MXDX-ID.
031037*    MOVE RPD-SE-GDLN-APREM-IND TO MIR-SE-GDLN-APREM-IND.

016641*    MOVE RPD-IA-COMM-BAND-1-PCT               TO WS-IA-COMM-RATE.
016641*    MOVE WS-IA-COMM-RATE       TO MIR-IA-COMM-BAND-1-PCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-IA-COMM-BAND-1-PCT * 100.
020874     MOVE RPD-IA-COMM-BAND-1-PCT TO L0290-INPUT-V02.
016641     MOVE 2                      TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-IA-COMM-BAND-1-PCT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-IA-COMM-BAND-1-PCT.
016641
008455*    MOVE RPD-IA-COMM-BAND-1-AMT     TO WS-IA-COMM-AMT.
008455*    MOVE WS-IA-COMM-AMT             TO MIR-IA-COMM-BAND-1-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPD-IA-COMM-BAND-1-AMT * 100.
020874     MOVE RPD-IA-COMM-BAND-1-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-IA-COMM-BAND-1-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-IA-COMM-BAND-1-AMT.
016641*    MOVE RPD-IA-COMM-BAND-2-PCT               TO WS-IA-COMM-RATE.
016641*    MOVE WS-IA-COMM-RATE       TO MIR-IA-COMM-BAND-2-PCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-IA-COMM-BAND-2-PCT * 100.
020874     MOVE RPD-IA-COMM-BAND-2-PCT TO L0290-INPUT-V02.
016641     MOVE 2                      TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-IA-COMM-BAND-2-PCT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-IA-COMM-BAND-2-PCT.
016641
008455*    MOVE RPD-IA-COMM-BAND-2-AMT     TO WS-IA-COMM-AMT.
008455*    MOVE WS-IA-COMM-AMT             TO MIR-IA-COMM-BAND-2-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPD-IA-COMM-BAND-2-AMT * 100.
020874     MOVE RPD-IA-COMM-BAND-2-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-IA-COMM-BAND-2-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-IA-COMM-BAND-2-AMT.
016641*    MOVE RPD-IA-COMM-BAND-3-PCT               TO WS-IA-COMM-RATE.
016641*    MOVE WS-IA-COMM-RATE       TO MIR-IA-COMM-BAND-3-PCT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RPD-IA-COMM-BAND-3-PCT * 100.
020874     MOVE RPD-IA-COMM-BAND-3-PCT TO L0290-INPUT-V02.
016641     MOVE 2                      TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-IA-COMM-BAND-3-PCT
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-IA-COMM-BAND-3-PCT.
016641
008455*    MOVE RPD-IA-COMM-BAND-3-AMT     TO WS-IA-COMM-AMT.
008455*    MOVE WS-IA-COMM-AMT             TO MIR-IA-COMM-BAND-3-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPD-IA-COMM-BAND-3-AMT * 100.
020874     MOVE RPD-IA-COMM-BAND-3-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-IA-COMM-BAND-3-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-IA-COMM-BAND-3-AMT.
008455*    MOVE RPD-IA-COMM-MAX-AMT        TO WS-IA-MAX-COMM-PAY.
008455*    MOVE WS-IA-MAX-COMM-PAY         TO MIR-IA-COMM-MAX-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPD-IA-COMM-MAX-AMT * 100.
020874     MOVE RPD-IA-COMM-MAX-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-IA-COMM-MAX-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.

008455     MOVE L0290-OUTPUT-DATA     TO MIR-IA-COMM-MAX-AMT.
557690*    MOVE RPD-IA-TAX-INCM-RT-ID TO MIR-MORTTX.

           MOVE RPD-IA-INT-RT-ID      TO MIR-IA-INT-RT-ID.
026643*    MOVE RPD-IA-INT-PREM-ID    TO MIR-IA-INT-PREM-ID.
           MOVE RPD-IA-INT-LEGAL-ID   TO MIR-IA-INT-LEGAL-ID.
           MOVE RPD-IA-INT-TAX-ID     TO MIR-IA-INT-TAX-ID.

022730*    MOVE RPD-IA-MORT-UVAL-ID   TO MIR-IA-MORT-UVAL-ID.
022730*    MOVE RPD-IA-MORT-PREM-ID   TO MIR-IA-MORT-PREM-ID.
022730*    MOVE RPD-IA-MORT-LEGAL-ID  TO MIR-IA-MORT-LEGAL-ID.
022730*    MOVE RPD-IA-MORT-TAX-ID    TO MIR-IA-MORT-TAX-ID.


           MOVE RPD-CVG-ENHC-TYP-CD   TO MIR-CVG-ENHC-TYP-CD.
010302*    MOVE RPH-ENHC-FACE-RH-ID        TO MIR-ENHPTR.
557660*    MOVE RPH-ENHC-FREQ-DUR-N        TO MIR-ENHC-FREQ-DUR.
557660     MOVE RPH-ENHC-FREQ-DUR     TO MIR-ENHC-FREQ-DUR.
557660*    MOVE RPH-ENHC-UWG-FREQ-DUR-N    TO MIR-ENHC-UWG-FREQ-DUR.
557660     MOVE RPH-ENHC-UWG-FREQ-DUR TO MIR-ENHC-UWG-FREQ-DUR.
557660*    MOVE RPH-ENHC-STRT-DUR-N        TO MIR-ENHC-STRT-DUR.
557660     MOVE RPH-ENHC-STRT-DUR     TO MIR-ENHC-STRT-DUR.
557660*    MOVE RPH-ENHC-NELCT-DUR-N       TO MIR-ENHC-NELCT-DUR.
557660     MOVE RPH-ENHC-NELCT-DUR    TO MIR-ENHC-NELCT-DUR.
557660*    MOVE RPH-ENHC-END-DUR-N         TO MIR-ENHC-END-DUR.
557660     MOVE RPH-ENHC-END-DUR      TO MIR-ENHC-END-DUR.
557660*    MOVE RPH-ENHC-HIATUS-DUR-N      TO MIR-ENHC-HIATUS-DUR.
557660     MOVE RPH-ENHC-HIATUS-DUR   TO MIR-ENHC-HIATUS-DUR.
557660*    MOVE RPH-ENHC-END-AGE-N         TO MIR-ENHC-END-AGE.
557660     MOVE RPH-ENHC-END-AGE      TO MIR-ENHC-END-AGE.
557660*    MOVE RPD-NUM-GIR-OPT-QTY-N      TO MIR-NUM-GIR-OPT-QTY.
557660     MOVE RPD-NUM-GIR-OPT-QTY   TO MIR-NUM-GIR-OPT-QTY.
013585     MOVE RPD-PLAN-PAYO-MTHD-CD TO MIR-PLAN-PAYO-MTHD-CD.


           MOVE RPD-PLAN-TXEMP-CD     TO MIR-PLAN-TXEMP-CD.

031036     MOVE RPD-MAX-TXEMP-INCR-PCT TO L0290-INPUT-V04.
031036     MOVE 4                     TO L0290-PRECISION.
031036     MOVE LENGTH OF MIR-MAX-TXEMP-INCR-PCT
031036                                TO L0290-MAX-OUT-LEN.
031036     PERFORM   0290-2000-FORMAT-FOR-MIR
031036          THRU 0290-2000-FORMAT-FOR-MIR-X.
031036     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-TXEMP-INCR-PCT.
031036
031036     MOVE RPD-MAX-TXEMP-DECR-PCT TO L0290-INPUT-V04.
031036     MOVE 4                     TO L0290-PRECISION.
031036     MOVE LENGTH OF MIR-MAX-TXEMP-DECR-PCT
031036                                TO L0290-MAX-OUT-LEN.
031036     PERFORM   0290-2000-FORMAT-FOR-MIR
031036          THRU 0290-2000-FORMAT-FOR-MIR-X.
031036     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-TXEMP-DECR-PCT.

           MOVE RPD-PLAN-TAX-TYP-CD   TO MIR-PLAN-TAX-TYP-CD.
           MOVE RPH-PLAN-TAXWH-IND    TO MIR-PLAN-TAXWH-IND.
           MOVE RPD-GAIN-RPT-TIME-CD  TO MIR-GAIN-RPT-TIME-CD.
557788*    MOVE RPD-SALE-TAX-BASE-RT       TO WS-SALES-TAX-BASE.
557788*    MOVE WS-SALES-TAX-BASE          TO MIR-PRMTAX.

022730*    MOVE RPH-XEMP-TST-UVAL-ID  TO MIR-XEMP-TST-UVAL-ID.
015290*    MOVE RPH-DISP-WTHDR-ORDR-CD        TO MIR-DISP-WTHDR-ORDR-CD.
010302*    MOVE RPH-PLAN-TAXWH-RH-ID       TO MIR-TXRTPT.
557691     MOVE RPH-PNSN-QUALF-IND         TO MIR-PNSN-QUALF-IND.
010302*    MOVE RPH-QUALF-CNTRB-RH-ID      TO MIR-DPLMPT.
557691*    MOVE RPH-PLAN-COI-TAX-RH-ID     TO MIR-COIPNT.
557690*    MOVE RPH-IA-LXPCT-RH-ID         TO MIR-LIFEX.
557690*    MOVE RPH-IA-GUAR-RFND-RH-ID     TO MIR-GUAREF.


           MOVE RPH-PLAN-REG-IND      TO MIR-PLAN-REG-IND.
           MOVE RPH-T5-REG-TITL-TXT   TO MIR-T5-REG-TITL-TXT.

008455*    MOVE RPH-MIN-CASL-PAYO-AMT      TO WS-MIN-CASUAL-PAYMENT.
008455*    MOVE WS-MIN-CASUAL-PAYMENT      TO MIR-MIN-CASL-PAYO-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPH-MIN-CASL-PAYO-AMT * 100.
020874     MOVE RPH-MIN-CASL-PAYO-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-CASL-PAYO-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM   0290-1000-NUMERIC-FORMAT
020874*         THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM   0290-2000-FORMAT-FOR-MIR
020874          THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-CASL-PAYO-AMT.
010302*    MOVE RPH-MIN-RRIF-PAY-RH-ID     TO MIR-MNPYPT.
010302*    MOVE RPH-MAX-LIF-PAY-RH-ID      TO MIR-MXPYPT.
           MOVE RPD-PLAN-LOCK-FND-IND TO MIR-PLAN-LOCK-FND-IND.


           MOVE RPH-PLAN-RSRV-CALC-CD TO MIR-PLAN-RSRV-CALC-CD.
           MOVE RPH-VALN-LBL-ID       TO MIR-VALN-LBL-ID.

           MOVE RPH-WP-PLAN-ID        TO MIR-WP-PLAN-ID.
           MOVE RPH-ADB-PLAN-ID       TO MIR-ADB-PLAN-ID.
           MOVE RPH-REDC-EP-PLAN-ID   TO MIR-REDC-EP-PLAN-ID.
           MOVE RPH-LTA-PLAN-ID       TO MIR-LTA-PLAN-ID.
           MOVE RPH-OWN-OCCP-PLAN-ID  TO MIR-OWN-OCCP-PLAN-ID.
           MOVE RPH-LTB-PLAN-ID       TO MIR-LTB-PLAN-ID.
           MOVE RPH-PDISAB-PLAN-ID    TO MIR-PDISAB-PLAN-ID.
           MOVE RPH-COLA-1-PLAN-ID    TO MIR-COLA-1-PLAN-ID.
           MOVE RPH-COLA-2-PLAN-ID    TO MIR-COLA-2-PLAN-ID.
           MOVE RPH-COLA-3-PLAN-ID    TO MIR-COLA-3-PLAN-ID.
           MOVE RPH-COLA-4-PLAN-ID    TO MIR-COLA-4-PLAN-ID.
020475     MOVE RPD-PLAN-INCL-DBG-IND TO MIR-PLAN-INCL-DBG-IND.
023435     MOVE RPH-PLAN-OFFANNV-IND  TO MIR-PLAN-OFFANNV-IND.

028786     MOVE RPH-CPREM-CALC-RULE-CD
028786                                TO MIR-CPREM-CALC-RULE-CD.
028786     MOVE RPD-CPREM-MODE-CALC-CD
028786                                TO MIR-CPREM-MODE-CALC-CD.
029059     MOVE RPD-PLAN-GDLN-CVAT-CD TO MIR-PLAN-GDLN-CVAT-CD.
029059     MOVE RPD-PLAN-CVAT-NSP-IND TO MIR-PLAN-CVAT-NSP-IND.

       7000-DISPLAY-FIELDS-X.
           EXIT.
      /
      *-----------------
       8000-EDIT-FIELDS.
      *-----------------

           PERFORM  0113-0000-INIT-PARM-INFO
               THRU 0113-0000-INIT-PARM-INFO-X.


557660*    PERFORM  BUILD-EDIT-LINKAGE
557660     PERFORM  8010-BUILD-EDIT-LINKAGE
               THRU 8010-BUILD-EDIT-LINKAGE-X.

           PERFORM  0113-1000-PLAN-EDITS
               THRU 0113-1000-PLAN-EDITS-X.

           EVALUATE TRUE

               WHEN L0113-RETRN-INVALID-REQUEST
                    MOVE +1           TO WGLOB-RETURN-CODE

               WHEN L0113-RETRN-EDIT-ERRORS
                    MOVE +1           TO WGLOB-RETURN-CODE
                    PERFORM  8020-EDIT-RETURN-SCREEN
                        THRU 8020-EDIT-RETURN-SCREEN-X

               WHEN L0113-RETRN-OK
                    PERFORM  8020-EDIT-RETURN-SCREEN
                        THRU 8020-EDIT-RETURN-SCREEN-X

            END-EVALUATE.

       8000-EDIT-FIELDS-X.
           EXIT.

      /
      *------------------------
       8010-BUILD-EDIT-LINKAGE.
      *------------------------

           MOVE MIR-APP-FORM-TYP-ID    TO  L0113-APP-FORM-TYP-ID.
           MOVE MIR-MAJ-LN-SORT-CD     TO  L0113-MAJ-LN-SORT-CD.
           MOVE MIR-BASIC-PLAN-IND     TO  L0113-BASIC-PLAN-IND.
           MOVE MIR-DB-CALC-TYP-CD     TO  L0113-DB-CALC-TYP-CD.
           MOVE MIR-FACE-AMT-TYP-CD    TO  L0113-FACE-AMT-TYP-CD.
007685*    MOVE MIR-FPKEY              TO  L0113-PLAN-FP-ID.
007685*    MOVE MIR-FPFKEY             TO  L0113-PLAN-PG-FRMT-ID.
           MOVE MIR-PLAN-EFF-DT        TO  L0113-PLAN-EFF-DT.
           MOVE MIR-PLAN-XPRY-DT       TO  L0113-PLAN-XPRY-DT.
010651*    MOVE MIR-LWAGE              TO  L0113-PLAN-LOW-AGE.
010651*    MOVE MIR-HIAGE              TO  L0113-PLAN-HIGH-AGE.
           MOVE MIR-PLAN-MIN-MPREM-QTY
                                       TO  L0113-PLAN-MIN-MPREM-QTY.
           MOVE MIR-CASM-ID            TO  L0113-CASM-ID.
010651*    MOVE MIR-MXFAPT             TO  L0113-MAX-ISS-AMT-RH-ID.
010302*    MOVE MIR-MXADB              TO  L0113-MAX-ADB-AMT-RH-ID.
           MOVE MIR-DFLT-REQIR-ID      TO  L0113-DFLT-REQIR-ID.
010302*    MOVE MIR-INCPTR             TO  L0113-INCM-FCT-RH-ID.
           MOVE MIR-ALLOW-CCAS-IND     TO  L0113-ALLOW-CCAS-IND.
           MOVE MIR-SUM-INS-CALC-CD    TO  L0113-SUM-INS-CALC-CD.
           MOVE MIR-AGE-CALC-MTHD-CD   TO  L0113-AGE-CALC-MTHD-CD.
           MOVE MIR-PLAN-AGE-STBCK-CD
                                       TO  L0113-PLAN-AGE-STBCK-CD.
           MOVE MIR-PLAN-AGE-STBCK-QTY
                                       TO  L0113-PLAN-AGE-STBCK-QTY.
           MOVE MIR-AGE-STBCK-STRT-AGE TO  L0113-AGE-STBCK-STRT-AGE.
010302*    MOVE MIR-RTTYP              TO  L0113-PREM-RT-TBAC-CD.
           MOVE MIR-CNTRCT-PREM-IND    TO  L0113-CNTRCT-PREM-IND.
010302*    MOVE MIR-PRMPTR             TO  L0113-PREM-RT-TBAC-ID.
010302*    MOVE MIR-ULTPTR             TO  L0113-ULT-PREM-RT-RH-ID.
010302*    MOVE MIR-COLA               TO  L0113-COLA-RH-ID.
010302*    MOVE MIR-ULTCOL             TO  L0113-ULT-COLA-RH-ID.
010302*    MOVE MIR-PRSDUR             TO  L0113-SELCT-PERI-DUR.
010302*    MOVE MIR-ADAGE              TO  L0113-PLAN-ADJ-AGE-RH-ID.
010302*    MOVE MIR-PRBAND             TO  L0113-PLAN-PREM-BAND-IND.
010302*    MOVE MIR-EQAGE              TO  L0113-PLAN-EQ-AGE-RH-ID.
010302*    MOVE MIR-BMAX1              TO  L0113-FACE-BAND-1-AMT.
010302*    MOVE MIR-BMAX2              TO  L0113-FACE-BAND-2-AMT.
557697     MOVE MIR-SFB-NEG-SUSP-IND   TO  L0113-SFB-NEG-SUSP-IND.
010302*    MOVE MIR-BMAX3              TO  L0113-FACE-BAND-3-AMT.
557697     MOVE MIR-SFB-NEG-SUSP-QTY   TO  L0113-SFB-NEG-SUSP-QTY.
010302*    MOVE MIR-BMAX4              TO  L0113-FACE-BAND-4-AMT.
           MOVE MIR-PREM-RENW-RT-CD    TO  L0113-PREM-RENW-RT-CD.
           MOVE MIR-PLAN-MODE-FEE-AMT
                                       TO  L0113-PLAN-MODE-FEE-AMT.
           MOVE MIR-PAC-MODE-FEE-AMT   TO  L0113-PAC-MODE-FEE-AMT.
020467     MOVE MIR-DD2-MODE-FEE-AMT   TO  L0113-DD2-MODE-FEE-AMT.
016395     MOVE MIR-CRC-MODE-FEE-AMT   TO  L0113-CRC-MODE-FEE-AMT.
           MOVE MIR-LBILL-MODE-FEE-AMT TO  L0113-LBILL-MODE-FEE-AMT.
           MOVE MIR-COMM-RT-LOOP-IND   TO  L0113-COMM-RT-LOOP-IND.
           MOVE MIR-COMM-RT-TBAC-CD    TO  L0113-COMM-RT-TBAC-CD.
           MOVE MIR-FYR-COMM-XTRA-RT   TO  L0113-FYR-COMM-XTRA-RT.
           MOVE MIR-PLAN-MDRT-CLAS-CD
                                       TO  L0113-PLAN-MDRT-CLAS-CD.
010302*    MOVE MIR-FNDIND             TO  L0113-PLAN-FND-COMM-CD.
010302*    MOVE MIR-FNDPTR             TO  L0113-PLAN-FND-COMM-INFO.
010302*    MOVE MIR-DRWIND             TO  L0113-PLAN-DED-COMM-CD.
010302*    MOVE MIR-DRWPTR             TO  L0113-PLAN-DED-COMM-INFO.
010302*    MOVE MIR-CMTGPA             TO  L0113-COMM-TRG-RH-ID.
           MOVE MIR-COMM-TRG-SSTD-IND  TO  L0113-COMM-TRG-SSTD-IND.
           MOVE MIR-COMM-RH-SUB-CD     TO  L0113-COMM-RH-SUB-CD.
022730*    MOVE MIR-PREM-PAY-UVAL-ID   TO  L0113-PREM-PAY-UVAL-ID.
022730*    MOVE MIR-PU-UVAL-ID         TO  L0113-PU-UVAL-ID.
           MOVE MIR-CSV-CALC-MTHD-CD   TO  L0113-CSV-CALC-MTHD-CD.
           MOVE MIR-PLAN-CSV-DT-TYP-CD
                                       TO  L0113-PLAN-CSV-DT-TYP-CD.
           MOVE MIR-PLAN-CF-TYP-CD     TO  L0113-PLAN-CF-TYP-CD.
           MOVE MIR-CF-INT-MODE-CD     TO  L0113-CF-INT-MODE-CD.
           MOVE MIR-CF-INT-CALC-TYP-CD TO  L0113-CF-INT-CALC-TYP-CD.
           MOVE MIR-INT-ADJ-MAX-DUR    TO  L0113-INT-ADJ-MAX-DUR.
           MOVE MIR-CSV-INT-RT-ID      TO  L0113-CSV-INT-RT-ID.
           MOVE MIR-PDF-INT-RT-ID      TO  L0113-PDF-INT-RT-ID.
           MOVE MIR-PREM-CHNG-DT-CD    TO  L0113-PREM-CHNG-DT-CD.
           MOVE MIR-PREM-CHNG-AGE-DUR  TO  L0113-PREM-CHNG-AGE-DUR.
           MOVE MIR-INIT-PREM-CHNG-AGE TO  L0113-INIT-PREM-CHNG-AGE.
           MOVE MIR-ULT-PREM-CHNG-AGE  TO  L0113-ULT-PREM-CHNG-AGE.
           MOVE MIR-XPRY-DT-CALC-CD    TO  L0113-XPRY-DT-CALC-CD.
           MOVE MIR-POL-XPRY-AGE-DUR   TO  L0113-POL-XPRY-AGE-DUR.
           MOVE MIR-PLAN-BASE-XPRY-AGE
                                       TO  L0113-PLAN-BASE-XPRY-AGE.
           MOVE MIR-CVG-XPRY-AGE-DUR   TO  L0113-CVG-XPRY-AGE-DUR.
           MOVE MIR-PLAN-CVG-XPRY-AGE
                                       TO  L0113-PLAN-CVG-XPRY-AGE.
           MOVE MIR-MAT-DT-CALC-CD     TO  L0113-MAT-DT-CALC-CD.
           MOVE MIR-PLAN-MAT-AGE-DUR
                                       TO  L0113-PLAN-MAT-AGE-DUR.
           MOVE MIR-PLAN-MAT-AGE       TO  L0113-PLAN-MAT-AGE.
016534*    MOVE MIR-PLAN-DUR-TYP-CD    TO  L0113-PLAN-DUR-TYP-CD.
           MOVE MIR-CNVR-XPRY-DT-CD    TO  L0113-CNVR-XPRY-DT-CD.
           MOVE MIR-CNVR-XPRY-AGE-DUR  TO  L0113-CNVR-XPRY-AGE-DUR.
           MOVE MIR-PLAN-ADB-XPRY-AGE
                                       TO  L0113-PLAN-ADB-XPRY-AGE.
           MOVE MIR-PLAN-WP-XPRY-AGE
                                       TO  L0113-PLAN-WP-XPRY-AGE.
           MOVE MIR-PLAN-WP-XPRY-CD    TO  L0113-PLAN-WP-XPRY-CD.
           MOVE MIR-REDC-EP-XPRY-AGE   TO  L0113-REDC-EP-XPRY-AGE.
           MOVE MIR-OWN-OCCP-XPRY-AGE  TO  L0113-OWN-OCCP-XPRY-AGE.
           MOVE MIR-PLAN-LTA-XPRY-AGE
                                       TO  L0113-PLAN-LTA-XPRY-AGE.
           MOVE MIR-PLAN-LTB-XPRY-AGE
                                       TO  L0113-PLAN-LTB-XPRY-AGE.
           MOVE MIR-PDISAB-XPRY-AGE    TO  L0113-PDISAB-XPRY-AGE.
           MOVE MIR-PLAN-COLA-XPRY-AGE
                                       TO  L0113-PLAN-COLA-XPRY-AGE.
010300*    MOVE MIR-RMND               TO  L0113-RMND-NOTI-DUR-INFO.
010304*    MOVE MIR-LAPSE              TO  L0113-LAPS-NOTI-DUR-INFO.
           MOVE MIR-NF-PRCES-MO-DUR    TO  L0113-NF-PRCES-DUR-INFO.
012522     MOVE MIR-PLAN-MIN-PU-AMT    TO  L0113-PLAN-MIN-PU-AMT.
010650*    MOVE MIR-ULIGRC             TO  L0113-INIT-GRACE-DUR-INFO.
010650*    MOVE MIR-ULGUAR             TO  L0113-UL-NLAPS-GUAR-DUR.
010650*    MOVE MIR-ULPERS             TO  L0113-UL-NLAPS-DED-QTY.
035251*    MOVE MIR-RPU-TBAC-ID        TO  L0113-RPU-TBAC-ID.
035251     MOVE MIR-RPU-PLAN-ID        TO  L0113-RPU-PLAN-ID.
014591*    MOVE MIR-FPU-PLAN-BASE-ID   TO  L0113-FPU-PLAN-BASE-ID.
           MOVE MIR-ETI-FACE-CALC-CD   TO  L0113-ETI-FACE-CALC-CD.
035251*    MOVE MIR-ETI-TBAC-ID        TO  L0113-ETI-TBAC-ID.
035251     MOVE MIR-ETI-PLAN-ID        TO  L0113-ETI-PLAN-ID.

016270     IF RPH-NOTI-DT-CALC-CD = MIR-NOTI-DT-CALC-CD
016270        MOVE SPACES              TO  L0113-NOTI-DT-CALC-CD
016270     ELSE
016270        MOVE MIR-NOTI-DT-CALC-CD TO  L0113-NOTI-DT-CALC-CD
016270     END-IF.

016270*    MOVE MIR-NOTI-DT-CALC-CD    TO  L0113-NOTI-DT-CALC-CD.
           MOVE MIR-NOTI-LOW-AGE-DUR   TO  L0113-NOTI-LOW-AGE-DUR.
           MOVE MIR-NOTI-HIGH-AGE-DUR  TO  L0113-NOTI-HIGH-AGE-DUR.
           MOVE MIR-PLAN-NOTI-REASN-CD
                                       TO  L0113-PLAN-NOTI-REASN-CD.
           MOVE MIR-NOTI-DEPT-ID       TO  L0113-NOTI-DEPT-ID.
557693     MOVE MIR-PERI-STMT-TYP-CD   TO  L0113-PERI-STMT-TYP-CD.
557693     MOVE MIR-PERI-STMT-DY-DUR   TO  L0113-PERI-STMT-DY-DUR.
557693     MOVE MIR-PERI-STMT-MO-DUR   TO  L0113-PERI-STMT-MO-DUR.
           MOVE MIR-TRM-PREM-RFND-RT   TO  L0113-TRM-PREM-RFND-RT.
           MOVE MIR-LOAN-INT-CALC-CD   TO  L0113-LOAN-INT-CALC-CD.
012145     MOVE MIR-PLAN-COLFND-IND    TO L0113-LOAN-COLL-FND-IND.
012145     MOVE MIR-COLFND-REQIR-IND   TO L0113-LOAN-COLL-FND-REQ.
           MOVE MIR-LOAN-INT-RT-TYP-CD TO  L0113-LOAN-INT-RT-TYP-CD.
           MOVE MIR-PLAN-LOAN-INT-RT
                                       TO  L0113-PLAN-LOAN-INT-RT.
010651*    MOVE MIR-VARIRT             TO  L0113-LOAN-INT-MAX-RT.
           MOVE MIR-LOAN-INT-RT-ID     TO  L0113-LOAN-INT-RT-ID.
           MOVE MIR-APL-INT-RT-ID      TO  L0113-APL-INT-RT-ID.
           MOVE MIR-PLAN-PAR-CD        TO  L0113-PLAN-PAR-CD.
           MOVE MIR-DOD-INT-RT-ID      TO  L0113-DOD-INT-RT-ID.
035251*    MOVE MIR-DIV-OYT-TBAC-ID    TO  L0113-DIV-OYT-TBAC-ID.
557659*    MOVE MIR-DIV-PUA-TBAC-ID    TO  L0113-DIV-PUA-TBAC-ID-1-2.
035251*    MOVE MIR-DIV-PUA-TBAC-ID    TO  L0113-DIV-PUA-TBAC-ID.
           MOVE MIR-PUA-DIV-CALC-CD    TO  L0113-PUA-DIV-CALC-CD.

013924     IF MIR-PLAN-BON-EFF-MO = SPACE
020874*       MOVE RPH-PLAN-BON-EFF-MO TO WS-BON-EFF-MM
020874*       MOVE WS-BON-EFF-MM       TO MIR-PLAN-BON-EFF-MO
020874        MOVE RPH-PLAN-BON-EFF-MO   TO L0290-INPUT-V00
020874        MOVE ZERO                  TO L0290-PRECISION
020874        MOVE LENGTH OF MIR-PLAN-BON-EFF-MO
020874                                   TO L0290-MAX-OUT-LEN
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
020874        MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-BON-EFF-MO
013924     END-IF.
013924     IF MIR-PLAN-BON-EFF-DY = SPACE
020874*       MOVE RPH-PLAN-BON-EFF-DY TO WS-BON-EFF-DY
020874*       MOVE WS-BON-EFF-DY       TO MIR-PLAN-BON-EFF-DY
020874        MOVE RPH-PLAN-BON-EFF-DY   TO L0290-INPUT-V00
020874        MOVE ZERO                  TO L0290-PRECISION
020874        MOVE LENGTH OF MIR-PLAN-BON-EFF-DY
020874                                   TO L0290-MAX-OUT-LEN
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
020874        MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-BON-EFF-DY
013924     END-IF.

013924     MOVE MIR-PLAN-BON-EFF-MO    TO  L0113-BON-EFF-MON.
013924     MOVE MIR-PLAN-BON-EFF-DY    TO  L0113-BON-EFF-DY.
016016     MOVE MIR-PLAN-BON-CALC-CD   TO  L0113-PLAN-BON-CALC-CD.
013585     MOVE MIR-PLAN-CVG-LOAN-IND
                                       TO  L0113-CVG-LOAN-IND.
013930     MOVE MIR-PLAN-DIV-INT-RT-ID
                                       TO  L0113-TRMNL-DIV-INT-RT-ID.
013930     MOVE MIR-PLAN-BON-INT-RT-ID
                                       TO  L0113-TRMNL-BON-INT-RT-ID.
           MOVE MIR-PLAN-RPU-DIV-RT    TO  L0113-PLAN-RPU-DIV-RT.
010302*    MOVE MIR-CVGADJ             TO  L0113-NEW-MONY-ADJ-CD.
010302*    MOVE MIR-CVGRS              TO  L0113-NEW-MONY-RS-ID.
010302*    MOVE MIR-CVGYRS             TO  L0113-NEW-MONY-TRM-DUR.
           MOVE MIR-PLAN-VPO-IND       TO  L0113-PLAN-VPO-IND.
           MOVE MIR-ISWL-FRST-CALC-DUR TO  L0113-ISWL-FRST-CALC-DUR.
           MOVE MIR-ISWL-CALC-FREQ-DUR TO  L0113-ISWL-CALC-FREQ-DUR.
           MOVE MIR-ISWL-CALC-ADV-DUR  TO  L0113-ISWL-CALC-ADV-DUR.
           MOVE MIR-ISWL-PREM-VAR-RT   TO  L0113-ISWL-PREM-VAR-RT.
           MOVE MIR-DIR-DPOS-MIN-AMT   TO  L0113-DIR-DPOS-MIN-AMT.
           MOVE MIR-PAC-DPOS-MIN-AMT   TO  L0113-PAC-DPOS-MIN-AMT.
020467     MOVE MIR-DD2-DPOS-MIN-AMT   TO  L0113-DD2-DPOS-MIN-AMT.
019135     MOVE MIR-PLAN-INIT-PMT-IND  TO  L0113-PLAN-INIT-PMT-IND.
016395     MOVE MIR-CRC-DPOS-MIN-AMT   TO  L0113-CRC-DPOS-MIN-AMT.
           MOVE MIR-MIN-CASL-PAYO-AMT  TO  L0113-MIN-CASL-PAYO-AMT.
010302*    MOVE MIR-MNPYPT             TO  L0113-MIN-RRIF-PAY-RH-ID.
010302*    MOVE MIR-MXPYPT             TO  L0113-MAX-LIF-PAY-RH-ID.
           MOVE MIR-PLAN-GUAR-INT-RT
                                       TO  L0113-PLAN-GUAR-INT-RT.
           MOVE MIR-ACUM-BRKPT-AMT     TO  L0113-ACUM-BRKPT-AMT.
           MOVE MIR-PLAN-ROLOVR-TYP-CD
                                       TO  L0113-PLAN-ROLOVR-TYP-CD.
           MOVE MIR-MIN-ROLOVR-DY-DUR  TO  L0113-MIN-ROLOVR-DUR-INFO.
           MOVE MIR-MAX-ROLOVR-DY-DUR  TO  L0113-MAX-ROLOVR-DUR-INFO.
016307*    MOVE MIR-PLAN-ADMIN-FEE-AMT
016307*                                TO  L0113-PLAN-ADMIN-FEE-AMT.
016307*    MOVE MIR-ADMIN-FEE-WAV-AMT  TO  L0113-ADMIN-FEE-WAV-AMT.
           MOVE MIR-PLAN-MKTVAL-ADJ-CD
                                       TO  L0113-PLAN-MKTVAL-ADJ-CD.
           MOVE MIR-MAT-CHRG-RTBL2-ID  TO  L0113-MAT-CHRG-RTBL2-ID.
010302*    MOVE MIR-MNPTPA             TO  L0113-MNPMT-TRG-RH-ID.
           MOVE MIR-MNPMT-TRG-SSTD-IND TO  L0113-MNPMT-TRG-SSTD-IND.
           MOVE MIR-PMT-LOAD-ORDR-CD   TO  L0113-PMT-LOAD-ORDR-CD.
           MOVE MIR-PMT-LOAD-RTBL2-ID  TO  L0113-PMT-LOAD-RTBL2-ID.
           MOVE MIR-PMT-LOAD-FLAT-AMT  TO  L0113-PMT-LOAD-FLAT-AMT.
           MOVE MIR-PMT-LOAD-CALC-CD   TO  L0113-PMT-LOAD-CALC-CD.
010302*    MOVE MIR-PYLTPA             TO  L0113-PMT-LOAD-TRG-RH-ID.
           MOVE MIR-PMT-LOAD-SSTD-IND  TO  L0113-PMT-LOAD-SSTD-IND.
010302*    MOVE MIR-PAYRH              TO  L0113-PMT-LOAD-RH-ID.
           MOVE MIR-PMT-ALLOC-MTHD-CD  TO  L0113-PMT-ALLOC-MTHD-CD.
           MOVE MIR-AFR-THRSHD-CD      TO  L0113-AFR-THRSHD-CD.
010302*    MOVE MIR-AFR-THRSHD-PERI-CDT    TO  L0113-AFR-THRSHD-RH-ID.
           MOVE MIR-FPUL-ADDL-PREM-IND TO  L0113-FPUL-ADDL-PREM-IND.
           MOVE MIR-FPUL-LOAD-TYP-CD   TO  L0113-FPUL-LOAD-TYP-CD.
           MOVE MIR-PSUR-CHRG-TYP-CD   TO  L0113-PSUR-CHRG-TYP-CD.
           MOVE MIR-PSUR-CHRG-FLAT-AMT TO  L0113-PSUR-CHRG-FLAT-AMT.
           MOVE MIR-PSUR-CHRG-RTBL2-ID TO  L0113-PSUR-CHRG-RTBL2-ID.
010302*    MOVE MIR-PSURRH             TO  L0113-PSUR-CHRG-RH-ID.
           MOVE MIR-SURR-CHRG-TYP-CD   TO  L0113-SURR-CHRG-TYP-CD.
           MOVE MIR-SURR-CHRG-CALC-CD  TO  L0113-SURR-CHRG-CALC-CD.
012143     MOVE MIR-DPOS-WTHDR-ORDR-CD TO  L0113-SURR-CHRG-RMVL-ORDR-CD.
           MOVE MIR-SURR-CHRG-FLAT-AMT TO  L0113-SURR-CHRG-FLAT-AMT.
           MOVE MIR-SURR-CHRG-RTBL2-ID TO  L0113-SURR-CHRG-RTBL2-ID.
           MOVE MIR-PLAN-SURR-CHRG-CD
                                       TO  L0113-PLAN-SURR-CHRG-CD.
010302*    MOVE MIR-SURTPA             TO  L0113-SURR-TRG-RH-ID.
           MOVE MIR-SURR-TRG-SSTD-IND  TO  L0113-SURR-TRG-SSTD-IND.
010302*    MOVE MIR-FSURRH             TO  L0113-SURR-CHRG-RH-ID.
           MOVE MIR-SURR-ADJ-CALC-CD   TO  L0113-SURR-ADJ-CALC-CD.
           MOVE MIR-SURR-ADJ-MO-DUR    TO  L0113-SURR-ADJ-MO-DUR.
           MOVE MIR-SURR-ADJ-TYP-CD    TO  L0113-SURR-ADJ-TYP-CD.
           MOVE MIR-CV-ALLOC-MTHD-CD   TO  L0113-CV-ALLOC-MTHD-CD.
           MOVE MIR-CVG-CV-ALLOC-IND   TO  L0113-CVG-CV-ALLOC-IND.
010302*    MOVE MIR-ISCHKC             TO  L0113-PLAN-SETUP-CHRG-CD.
010302*    MOVE MIR-ISCHPA             TO  L0113-SETUP-CHRG-INFO.
010302*    MOVE MIR-ADEXKC             TO  L0113-PLAN-PERI-LOAD-CD.
010302*    MOVE MIR-ADEXPA             TO  L0113-PERI-LOAD-INFO.
010302*    MOVE MIR-COIKC              TO  L0113-PLAN-COI-CD.
010302*    MOVE MIR-COIPA              TO  L0113-PLAN-COI-INFO.
010302*    MOVE MIR-GCOIKC             TO  L0113-PLAN-GUAR-COI-CD.
010302*    MOVE MIR-GCOIPA             TO  L0113-PLAN-GUAR-COI-INFO.
           MOVE MIR-PLAN-NAR-DSCNT-RT
                                       TO  L0113-PLAN-NAR-DSCNT-RT.
           MOVE MIR-PLAN-IMPRD-RT-CD
                                       TO  L0113-PLAN-IMPRD-RT-CD.
           MOVE MIR-PLAN-IMPRD-INT-RT
                                       TO  L0113-PLAN-IMPRD-INT-RT.
           MOVE MIR-PLAN-REG-IND       TO  L0113-PLAN-REG-IND.
           MOVE MIR-T5-REG-TITL-TXT    TO  L0113-T5-REG-TITL-TXT.
           MOVE MIR-PLAN-TAXWH-IND     TO  L0113-PLAN-TAXWH-IND.
010302*    MOVE MIR-TXRTPT             TO  L0113-PLAN-TAXWH-RH-ID.
557691     MOVE MIR-PNSN-QUALF-IND     TO  L0113-PNSN-QUALF-IND.
010302*    MOVE MIR-DPLMPT             TO  L0113-QUALF-CNTRB-RH-ID.
010302*    MOVE MIR-LIFEX              TO  L0113-IA-LXPCT-RH-ID.
010302*    MOVE MIR-GUAREF             TO  L0113-IA-GUAR-RFND-RH-ID.
015290*    MOVE MIR-DISP-WTHDR-ORDR-CD TO  L0113-DISP-WTHDR-ORDR-CD.
010302*    MOVE MIR-DBCORK             TO  L0113-GDLN-DB-CORDR-CD.
010302*    MOVE MIR-DBCOR              TO  L0113-GDLN-DB-CORDR-ID.
022730*    MOVE MIR-XEMP-TST-UVAL-ID   TO  L0113-XEMP-TST-UVAL-ID.
010302*    MOVE MIR-LVAIND             TO  L0113-ALG-PREM-TBAC-CD.
010302*    MOVE MIR-LVAPTA             TO  L0113-ALG-PREM-TBAC-ID.
010302*    MOVE MIR-LVSIND             TO  L0113-SLG-PREM-TBAC-CD.
010302*    MOVE MIR-LVSPTA             TO  L0113-SLG-PREM-TBAC-ID.
010302*    MOVE MIR-INCAIN             TO  L0113-AIG-PREM-TBAC-CD.
010302*    MOVE MIR-INCAPA             TO  L0113-AIG-PREM-TBAC-ID.
010302*    MOVE MIR-INCSIN             TO  L0113-SIG-PREM-TBAC-CD.
010302*    MOVE MIR-INCSPT             TO  L0113-SIG-PREM-TBAC-ID.
015919*    MOVE MIR-PLAN-TAMRA-IND     TO  L0113-PLAN-TAMRA-IND.
015919     MOVE MIR-PLAN-TAMRA-CD      TO  L0113-PLAN-TAMRA-CD.
035251*    MOVE MIR-PLAN-TAMRA-MXDX-ID
035251*                                TO  L0113-PLAN-TAMRA-MXDX-ID.
031037*    MOVE MIR-SE-GDLN-APREM-IND  TO  L0113-SE-GDLN-APREM-IND.
035251*    MOVE MIR-PLAN-7702-MXDX-ID
035251*                                TO  L0113-PLAN-7702-MXDX-ID.
           MOVE MIR-PLAN-RSRV-CALC-CD
                                       TO  L0113-PLAN-RSRV-CALC-CD.
           MOVE MIR-VALN-LBL-ID        TO  L0113-VALN-LBL-ID.
           MOVE MIR-ADB-PLAN-ID        TO  L0113-ADB-PLAN-ID.
           MOVE MIR-WP-PLAN-ID         TO  L0113-WP-PLAN-ID.
           MOVE MIR-REDC-EP-PLAN-ID    TO  L0113-REDC-EP-PLAN-ID.
           MOVE MIR-OWN-OCCP-PLAN-ID   TO  L0113-OWN-OCCP-PLAN-ID.
           MOVE MIR-LTA-PLAN-ID        TO  L0113-LTA-PLAN-ID.
           MOVE MIR-LTB-PLAN-ID        TO  L0113-LTB-PLAN-ID.
           MOVE MIR-PDISAB-PLAN-ID     TO  L0113-PDISAB-PLAN-ID.
           MOVE MIR-COLA-1-PLAN-ID     TO  L0113-COLA-1-PLAN-ID.
           MOVE MIR-COLA-2-PLAN-ID     TO  L0113-COLA-2-PLAN-ID.
           MOVE MIR-COLA-3-PLAN-ID     TO  L0113-COLA-3-PLAN-ID.
           MOVE MIR-COLA-4-PLAN-ID     TO  L0113-COLA-4-PLAN-ID.
016395*    MOVE MIR-APPL-ID            TO  L0113-APPL-ID.
016395     MOVE MIR-PLAN-SYS-ID        TO  L0113-SYS-ID.
010302*    MOVE MIR-ENHPTR             TO  L0113-ENHC-FACE-RH-ID.
           MOVE MIR-ENHC-FREQ-DUR      TO  L0113-ENHC-FREQ-DUR.
           MOVE MIR-ENHC-STRT-DUR      TO  L0113-ENHC-STRT-DUR.
           MOVE MIR-ENHC-END-DUR       TO  L0113-ENHC-END-DUR.
           MOVE MIR-ENHC-END-AGE       TO  L0113-ENHC-END-AGE.
           MOVE MIR-ENHC-UWG-FREQ-DUR  TO  L0113-ENHC-UWG-FREQ-DUR.
           MOVE MIR-ENHC-NELCT-DUR     TO  L0113-ENHC-NELCT-DUR.
           MOVE MIR-ENHC-HIATUS-DUR    TO  L0113-ENHC-HIATUS-DUR.
010650*    MOVE MIR-FREEWPT            TO  L0113-FREE-WTHDR-RH-ID.
           MOVE MIR-PLAN-INS-TYP-CD    TO  L0113-PLAN-INS-TYP-CD.
           MOVE MIR-PLAN-BUS-CLAS-CD
                                       TO  L0113-PLAN-BUS-CLAS-CD.
010302     MOVE MIR-LOC-GR-COLCT-ID    TO  L0113-LOC-GR-COLCT-ID.
           MOVE MIR-PLAN-SUPP-BNFT-CD
                                       TO  L0113-PLAN-SUPP-BNFT-CD.
012522     MOVE MIR-MTHV-PRCES-IND      TO L0113-MTHV-PRCES-IND.
           MOVE MIR-PLAN-ACCT-TYP-CD   TO  L0113-PLAN-ACCT-TYP-CD.
           MOVE MIR-PLAN-UNIT-VALU-AMT
                                       TO  L0113-PLAN-UNIT-VALU-AMT.
010302*    MOVE MIR-MINFA              TO  L0113-MIN-ISS-FACE-AMT.
010302*    MOVE MIR-MAXFA              TO  L0113-MAX-ISS-FACE-AMT.
           MOVE MIR-PLAN-UWG-IND       TO  L0113-PLAN-UWG-IND.
           MOVE MIR-UWG-FACE-AMT-FCT   TO  L0113-UWG-FACE-AMT-FCT.
           MOVE MIR-PLAN-LOC-LIC-CD    TO  L0113-PLAN-LOC-LIC-CD.
           MOVE MIR-PREM-CALC-TYP-CD   TO  L0113-PREM-CALC-TYP-CD.
           MOVE MIR-GIR-PREM-INCL-IND  TO  L0113-GIR-PREM-INCL-IND.
           MOVE MIR-PLAN-ISS-DT-TYP-CD
                                       TO  L0113-PLAN-ISS-DT-CD.
020467*    MOVE MIR-PLAN-SEMI-ANN-FCT
020467*                                TO  L0113-PLAN-SEMI-ANN-FCT.
020467*    MOVE MIR-PLAN-QTR-FCT       TO  L0113-PLAN-QTR-FCT.
020467*    MOVE MIR-PLAN-MTHLY-FCT     TO  L0113-PLAN-MTHLY-FCT.
020467*    MOVE MIR-PAC-SEMI-ANN-FCT   TO  L0113-PAC-SEMI-ANN-FCT.
020467*    MOVE MIR-PLAN-PAC-QTR-FCT
020467*                                TO  L0113-PLAN-PAC-QTR-FCT.
020467*    MOVE MIR-PLAN-PAC-MTHLY-FCT
020467*                                TO  L0113-PLAN-PAC-MTHLY-FCT.
020467*    MOVE MIR-CRC-SEMI-ANN-FCT   TO  L0113-CRC-SEMI-ANN-FCT.
020467*    MOVE MIR-PLAN-CRC-QTR-FCT   TO  L0113-PLAN-CRC-QTR-FCT.
020467*    MOVE MIR-PLAN-CRC-MTHLY-FCT TO  L0113-PLAN-CRC-MTHLY-FCT.
           MOVE MIR-PLAN-PFEE-AMT      TO  L0113-PLAN-PFEE-AMT.
           MOVE MIR-PLAN-CVG-PFEE-AMT
                                       TO  L0113-PLAN-CVG-PFEE-AMT.
020467*    MOVE MIR-SEMI-ANN-PFEE-FCT  TO  L0113-SEMI-ANN-PFEE-FCT.
020467*    MOVE MIR-PLAN-QTR-PFEE-FCT
020467*                                TO  L0113-PLAN-QTR-PFEE-FCT.
020467*    MOVE MIR-MTHLY-PFEE-FCT     TO  L0113-MTHLY-PFEE-FCT.
020467*    MOVE MIR-PAC-SEMI-PFEE-FCT  TO  L0113-PAC-SEMI-PFEE-FCT.
020467*    MOVE MIR-PAC-QTR-PFEE-FCT   TO  L0113-PAC-QTR-PFEE-FCT.
020467*    MOVE MIR-PAC-MTHLY-PFEE-FCT TO  L0113-PAC-MTHLY-PFEE-FCT.
020467*    MOVE MIR-CRC-SEMI-PFEE-FCT  TO  L0113-CRC-SEMI-PFEE-FCT.
020467*    MOVE MIR-CRC-QTR-PFEE-FCT   TO  L0113-CRC-QTR-PFEE-FCT.
020467*    MOVE MIR-CRC-MTHLY-PFEE-FCT TO  L0113-CRC-MTHLY-PFEE-FCT.
           MOVE MIR-PLAN-IA-PFEE-AMT
                                       TO  L0113-PLAN-IA-PFEE-AMT.
           MOVE MIR-COMM-PLAN-TYP-CD   TO  L0113-COMM-PLAN-TYP-CD.
           MOVE MIR-PLAN-CPREM-CALC-CD
                                       TO  L0113-PLAN-CPREM-CALC-CD.
           MOVE MIR-OVRID-FRST-DGT-CD  TO  L0113-OVRID-FRST-DGT-CD.
           MOVE MIR-IA-COMM-BAND-1-PCT TO  L0113-IA-COMM-BAND-1-PCT.
           MOVE MIR-IA-COMM-BAND-1-AMT TO  L0113-IA-COMM-BAND-1-AMT.
           MOVE MIR-IA-COMM-BAND-2-PCT TO  L0113-IA-COMM-BAND-2-PCT.
           MOVE MIR-IA-COMM-BAND-2-AMT TO  L0113-IA-COMM-BAND-2-AMT.
           MOVE MIR-IA-COMM-BAND-3-PCT TO  L0113-IA-COMM-BAND-3-PCT.
           MOVE MIR-IA-COMM-BAND-3-AMT TO  L0113-IA-COMM-BAND-3-AMT.
           MOVE MIR-IA-COMM-MAX-AMT    TO  L0113-IA-COMM-MAX-AMT.
           MOVE MIR-IA-INT-RT-ID       TO  L0113-IA-INT-RT-ID.
026643*    MOVE MIR-IA-INT-PREM-ID     TO  L0113-IA-INT-PREM-ID.
           MOVE MIR-IA-INT-LEGAL-ID    TO  L0113-IA-INT-LEGAL-ID.
           MOVE MIR-IA-INT-TAX-ID      TO  L0113-IA-INT-TAX-ID.
           MOVE MIR-PLAN-INT-PAYO-CD
                                       TO  L0113-PLAN-INT-PAYO-CD.
           MOVE MIR-PLAN-WTHDR-ORDR-CD
                                       TO  L0113-PLAN-WTHDR-ORDR-CD.
010304*    MOVE MIR-NFO                TO  L0113-PLAN-NFO-CD.
           MOVE MIR-AUTO-PREM-PMT-IND  TO  L0113-AUTO-PREM-PMT-IND.
010648*    MOVE MIR-DIVOPT             TO  L0113-PLAN-DIV-OPT-CD.
           MOVE MIR-PREM-RECALC-OPT-CD TO  L0113-PREM-RECALC-OPT-CD.
           MOVE MIR-AFR-THRSHD-PERI-CD TO  L0113-AFR-THRSHD-PERI-CD.
           MOVE MIR-PLAN-ROLOVR-DT-IND
                                       TO  L0113-PLAN-ROLOVR-DT-IND.
           MOVE MIR-DIA-SWP-THRSHD-CD  TO  L0113-DIA-SWP-THRSHD-CD.
           MOVE MIR-DIA-SWP-THRSHD-AMT TO  L0113-DIA-SWP-THRSHD-AMT.
           MOVE MIR-PLAN-TXEMP-CD      TO  L0113-PLAN-TXEMP-CD.
031036     MOVE MIR-MAX-TXEMP-INCR-PCT TO  L0113-MAX-TXEMP-INCR-PCT.
031036     MOVE MIR-MAX-TXEMP-DECR-PCT TO  L0113-MAX-TXEMP-DECR-PCT.
           MOVE MIR-GAIN-RPT-TIME-CD   TO  L0113-GAIN-RPT-TIME-CD.
           MOVE MIR-PLAN-TAX-TYP-CD    TO  L0113-PLAN-TAX-TYP-CD.
557788*    MOVE MIR-PRMTAX             TO  L0113-SALE-TAX-BASE-RT.
557690*    MOVE MIR-MORTTX             TO  L0113-IA-TAX-INCM-RT-ID.
010302*    MOVE MIR-COIPNT             TO  L0113-PLAN-COI-TAX-RH-ID.
           MOVE MIR-PLAN-LOCK-FND-IND
                                       TO  L0113-PLAN-LOCK-FND-IND.
022730*    MOVE MIR-IA-MORT-UVAL-ID    TO  L0113-IA-MORT-UVAL-ID.
022730*    MOVE MIR-IA-MORT-PREM-ID    TO  L0113-IA-MORT-PREM-ID.
022730*    MOVE MIR-IA-MORT-LEGAL-ID   TO  L0113-IA-MORT-LEGAL-ID.
022730*    MOVE MIR-IA-MORT-TAX-ID     TO  L0113-IA-MORT-TAX-ID.
           MOVE MIR-CVG-ENHC-TYP-CD    TO  L0113-CVG-ENHC-TYP-CD.
           MOVE MIR-NUM-GIR-OPT-QTY    TO  L0113-NUM-GIR-OPT-QTY.
010650*    MOVE MIR-FREEW              TO  L0113-FREE-WTHDR-CD.
010650*    MOVE MIR-FREEWN             TO  L0113-FREE-WTHDR-QTY.
010650*    MOVE MIR-FREEWPD            TO  L0113-FREE-WTHDR-PERI-CD.
010314     MOVE MIR-INDX-INCR-MTHD-CD  TO  L0113-INDX-INCR-MTHD-CD.
010314     MOVE MIR-INDX-INCR-MO-DUR   TO  L0113-INDX-INCR-MO-DUR.
010314     MOVE MIR-INDX-INCR-DY-DUR   TO  L0113-INDX-INCR-DY-DUR.
011026     MOVE MIR-MCV-CALC-REQIR-IND TO  L0113-MCV-CALC-REQIR-IND.
011026     MOVE MIR-MCV-INT-MTHD-CD    TO  L0113-MCV-INT-MTHD-CD.
011026     MOVE MIR-MCV-PMT-LOAD-CD    TO  L0113-MCV-PMT-LOAD-CD.
011026     MOVE MIR-PLAN-EIC-FREQ-CD
                                       TO  L0113-PLAN-EIC-FREQ-CD.
011026     MOVE MIR-EIC-INIT-YR-DUR    TO  L0113-EIC-INIT-YR-DUR.
011026     MOVE MIR-EIC-SUBSEQ-YR-DUR  TO  L0113-EIC-SUBSEQ-YR-DUR.
010304     MOVE MIR-ACTN-COLCT-ID      TO  L0113-ACTN-COLCT-ID.
031035     MOVE MIR-INT-RT-LK-UP-CD    TO  L0113-INT-RT-LK-UP-CD.

018905*    MOVE MIR-PLAN-MAT-MAX-AGE TO  L0113-PLAN-MAT-MAX-AGE.
018905*    MOVE MIR-PLAN-MAT-MAX-DUR TO  L0113-PLAN-MAT-MAX-DUR.
018905*    MOVE MIR-POL-XPRY-MAX-DUR TO  L0113-POL-XPRY-MAX-DUR.
018905*    MOVE MIR-BASE-XPRY-MAX-AGE TO L0113-BASE-XPRY-MAX-AGE.
018905*    MOVE MIR-CVG-XPRY-MAX-DUR TO  L0113-CVG-XPRY-MAX-DUR.
018905*    MOVE MIR-CVG-XPRY-MAX-AGE TO  L0113-CVG-XPRY-MAX-AGE.

012136     MOVE MIR-FREE-LK-PRCES-IND  TO  L0113-FREE-LOOK-IND.
031037*    MOVE MIR-FREE-LK-INCR-CD    TO  L0113-FREE-LK-INCR-CD.
012146     MOVE MIR-MORT-XPNS-CALC-CD  TO  L0113-MORT-XPNS-CALC-CD.
012146     MOVE MIR-MORT-XPNS-CHRG-AGE TO  L0113-MORT-XPNS-CHRG-AGE.
012146     MOVE MIR-MORT-XPNS-CHRG-DUR TO  L0113-MORT-XPNS-CHRG-DUR.
012148     MOVE MIR-TRAIL-COMM-BEG-DUR TO  L0113-TRAIL-COMM-BEG-DUR.
012148     MOVE MIR-TRAIL-COMM-FREQ-CD TO  L0113-TRAIL-COMM-FREQ-CD.
012148     MOVE MIR-TRAIL-COMM-LAG-DUR TO  L0113-TRAIL-COMM-LAG-DUR.
013585     MOVE MIR-PLAN-PAYO-MTHD-CD
                                       TO  L0113-CONT-PAYO-MTHD.
010304
018846     MOVE MIR-PLAN-FND-TYP-CD    TO  L0113-PLAN-FND-TYP-CD.
021239     MOVE MIR-PLAN-UNIT-TYP-CD   TO  L0113-PLAN-UNIT-TYP-CD.
020469     MOVE MIR-PLAN-MULT-CRCY-IND TO  L0113-PLAN-MULT-CRCY-IND.
020469     MOVE MIR-PLAN-CRCY-CD       TO  L0113-PLAN-CRCY-CD.
020475     MOVE MIR-PLAN-INCL-DBG-IND  TO  L0113-PLAN-INCL-DBG-IND.
023435     MOVE MIR-PLAN-OFFANNV-IND   TO  L0113-OFFANNV-IND.
028786
028786     MOVE MIR-CPREM-CALC-RULE-CD TO  L0113-CPREM-CALC-RULE-CD.
028786     MOVE MIR-CPREM-MODE-CALC-CD TO  L0113-CPREM-MODE-CALC-CD.
029059     MOVE MIR-PLAN-GDLN-CVAT-CD  TO  L0113-PLAN-GDLN-CVAT-CD.
029059     MOVE MIR-PLAN-CVAT-NSP-IND  TO  L0113-PLAN-CVAT-NSP-IND.

       8010-BUILD-EDIT-LINKAGE-X.
           EXIT.

      /
      *------------------------
       8020-EDIT-RETURN-SCREEN.
      *------------------------

012136      IF  L0113-FREE-LOOK-IND            NOT =  HIGH-VALUES
012136          MOVE L0113-FREE-LOOK-IND
                                      TO MIR-FREE-LK-PRCES-IND
012136      END-IF.
012136
031037*     IF  L0113-FREE-LK-INCR-CD          NOT =  HIGH-VALUES
031037*         MOVE L0113-FREE-LK-INCR-CD
031037*                               TO MIR-FREE-LK-INCR-CD
031037*     END-IF.
012139
010302      IF  L0113-LOC-GR-COLCT-ID          NOT =  HIGH-VALUES
010302          MOVE L0113-LOC-GR-COLCT-ID
                                      TO MIR-LOC-GR-COLCT-ID
010302      END-IF.
010302
            IF  L0113-APP-FORM-TYP-ID          NOT =  HIGH-VALUES
                MOVE L0113-APP-FORM-TYP-ID
                                      TO MIR-APP-FORM-TYP-ID
            END-IF.


            IF  L0113-MAJ-LN-SORT-CD           NOT =  HIGH-VALUES
                MOVE L0113-MAJ-LN-SORT-CD
                                      TO MIR-MAJ-LN-SORT-CD
            END-IF.


            IF  L0113-BASIC-PLAN-IND           NOT =  HIGH-VALUES
                MOVE L0113-BASIC-PLAN-IND
                                      TO MIR-BASIC-PLAN-IND
            END-IF.


            IF  L0113-DB-CALC-TYP-CD           NOT =  HIGH-VALUES
                MOVE L0113-DB-CALC-TYP-CD
                                      TO MIR-DB-CALC-TYP-CD
            END-IF.


            IF  L0113-FACE-AMT-TYP-CD          NOT =  HIGH-VALUES
                MOVE L0113-FACE-AMT-TYP-CD
                                      TO MIR-FACE-AMT-TYP-CD
            END-IF.


031037*     IF  L0113-SE-GDLN-APREM-IND       NOT =  HIGH-VALUES
031037*         MOVE L0113-SE-GDLN-APREM-IND
031037*                               TO MIR-SE-GDLN-APREM-IND
031037*     END-IF.

007685*     IF  L0113-PLAN-FP-ID               NOT =  HIGH-VALUES
007685*         MOVE L0113-PLAN-FP-ID          TO MIR-FPKEY
007685*     END-IF.
010302*
010302*
007685*     IF  L0113-PLAN-PG-FRMT-ID          NOT =  HIGH-VALUES
007685*         MOVE L0113-PLAN-PG-FRMT-ID     TO MIR-FPFKEY
007685*     END-IF.
007685
010302
            IF  L0113-PLAN-EFF-DT              NOT =  HIGH-VALUES
                MOVE L0113-PLAN-EFF-DT         TO MIR-PLAN-EFF-DT
            END-IF.


            IF  L0113-PLAN-XPRY-DT             NOT =  HIGH-VALUES
                MOVE L0113-PLAN-XPRY-DT
                                      TO MIR-PLAN-XPRY-DT
            END-IF.


010651*     IF  L0113-PLAN-LOW-AGE             NOT =  HIGH-VALUES
010651*         MOVE L0113-PLAN-LOW-AGE        TO MIR-LWAGE
010651*     END-IF.
010651*
010651*
010651*     IF  L0113-PLAN-HIGH-AGE            NOT =  HIGH-VALUES
010651*         MOVE L0113-PLAN-HIGH-AGE       TO MIR-HIAGE
010651*     END-IF.


            IF  L0113-PLAN-MIN-MPREM-QTY       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-MIN-MPREM-QTY
                                      TO MIR-PLAN-MIN-MPREM-QTY
            END-IF.


            IF  L0113-CASM-ID                  NOT =  HIGH-VALUES
                MOVE L0113-CASM-ID    TO MIR-CASM-ID
            END-IF.


010651*     IF  L0113-MAX-ISS-AMT-RH-ID        NOT =  HIGH-VALUES
010651*         MOVE L0113-MAX-ISS-AMT-RH-ID   TO MIR-MXFAPT
010651*     END-IF.
010651*
010302*
010302*     IF  L0113-MAX-ADB-AMT-RH-ID        NOT =  HIGH-VALUES
010302*          MOVE L0113-MAX-ADB-AMT-RH-ID   TO MIR-MXADB
010302*     END-IF.
010302*
010302*
            IF  L0113-DFLT-REQIR-ID            NOT =  HIGH-VALUES
                MOVE L0113-DFLT-REQIR-ID
                                      TO MIR-DFLT-REQIR-ID
            END-IF.


010302*     IF  L0113-INCM-FCT-RH-ID           NOT =  HIGH-VALUES
010302*          MOVE L0113-INCM-FCT-RH-ID      TO MIR-INCPTR
010302*     END-IF.
010302*
010302*
            IF  L0113-ALLOW-CCAS-IND           NOT =  HIGH-VALUES
                MOVE L0113-ALLOW-CCAS-IND
                                      TO MIR-ALLOW-CCAS-IND
            END-IF.


            IF  L0113-SUM-INS-CALC-CD          NOT =  HIGH-VALUES
                MOVE L0113-SUM-INS-CALC-CD
                                      TO MIR-SUM-INS-CALC-CD
            END-IF.


            IF  L0113-AGE-CALC-MTHD-CD         NOT =  HIGH-VALUES
                MOVE L0113-AGE-CALC-MTHD-CD
                                      TO MIR-AGE-CALC-MTHD-CD
            END-IF.


            IF  L0113-PLAN-AGE-STBCK-CD        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-AGE-STBCK-CD
                                      TO MIR-PLAN-AGE-STBCK-CD
            END-IF.


            IF  L0113-PLAN-AGE-STBCK-QTY       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-AGE-STBCK-QTY
                                      TO MIR-PLAN-AGE-STBCK-QTY
            END-IF.


            IF  L0113-AGE-STBCK-STRT-AGE       NOT =  HIGH-VALUES
                MOVE L0113-AGE-STBCK-STRT-AGE
                                      TO MIR-AGE-STBCK-STRT-AGE
            END-IF.


010302*     IF  L0113-PREM-RT-TBAC-CD          NOT =  HIGH-VALUES
010302*         MOVE L0113-PREM-RT-TBAC-CD     TO MIR-RTTYP
010302*     END-IF.
010302*
            IF  L0113-CNTRCT-PREM-IND          NOT =  HIGH-VALUES
                MOVE L0113-CNTRCT-PREM-IND
                                      TO MIR-CNTRCT-PREM-IND
            END-IF.

010302*     IF  L0113-PREM-RT-TBAC-ID          NOT =  HIGH-VALUES
010302*         MOVE L0113-PREM-RT-TBAC-ID     TO MIR-PRMPTR
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-ULT-PREM-RT-RH-ID        NOT =  HIGH-VALUES
010302*         MOVE L0113-ULT-PREM-RT-RH-ID   TO MIR-ULTPTR
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-COLA-RH-ID               NOT =  HIGH-VALUES
010302*         MOVE L0113-COLA-RH-ID          TO MIR-COLA
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-ULT-COLA-RH-ID           NOT =  HIGH-VALUES
010302*         MOVE L0113-ULT-COLA-RH-ID      TO MIR-ULTCOL
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-SELCT-PERI-DUR           NOT =  HIGH-VALUES
010302*         MOVE L0113-SELCT-PERI-DUR      TO MIR-PRSDUR
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-ADJ-AGE-RH-ID       NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-ADJ-AGE-RH-ID  TO MIR-ADAGE
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-EQ-AGE-RH-ID        NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-EQ-AGE-RH-ID   TO MIR-EQAGE
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-PREM-BAND-IND       NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-PREM-BAND-IND  TO MIR-PRBAND
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-FACE-BAND-1-AMT          NOT =  HIGH-VALUES
010302*         MOVE L0113-FACE-BAND-1-AMT     TO MIR-BMAX1
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-FACE-BAND-2-AMT          NOT =  HIGH-VALUES
010302*         MOVE L0113-FACE-BAND-2-AMT     TO MIR-BMAX2
010302*     END-IF.
010302*
010302*
557697      IF  L0113-SFB-NEG-SUSP-IND         NOT =  HIGH-VALUES
557697          MOVE L0113-SFB-NEG-SUSP-IND
                                      TO MIR-SFB-NEG-SUSP-IND
557697      END-IF.


010302*     IF  L0113-FACE-BAND-3-AMT          NOT =  HIGH-VALUES
010302*         MOVE L0113-FACE-BAND-3-AMT     TO MIR-BMAX3
010302*     END-IF.
010302*
010302*
557697      IF  L0113-SFB-NEG-SUSP-QTY         NOT =  HIGH-VALUES
557697          MOVE L0113-SFB-NEG-SUSP-QTY
                                      TO MIR-SFB-NEG-SUSP-QTY
557697      END-IF.


010302*     IF  L0113-FACE-BAND-4-AMT          NOT =  HIGH-VALUES
010302*         MOVE L0113-FACE-BAND-4-AMT     TO MIR-BMAX4
010302*     END-IF.
010302*
010302*
            IF  L0113-PREM-RENW-RT-CD          NOT =  HIGH-VALUES
                MOVE L0113-PREM-RENW-RT-CD
                                      TO MIR-PREM-RENW-RT-CD
            END-IF.


            IF  L0113-PLAN-MODE-FEE-AMT        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-MODE-FEE-AMT
                                      TO MIR-PLAN-MODE-FEE-AMT
            END-IF.


            IF  L0113-PAC-MODE-FEE-AMT         NOT =  HIGH-VALUES
                MOVE L0113-PAC-MODE-FEE-AMT
                                      TO MIR-PAC-MODE-FEE-AMT
            END-IF.

020467      IF  L0113-DD2-MODE-FEE-AMT         NOT =  HIGH-VALUES
020467          MOVE L0113-DD2-MODE-FEE-AMT
020467                                TO MIR-DD2-MODE-FEE-AMT
020467      END-IF.
020467
016395      IF  L0113-CRC-MODE-FEE-AMT         NOT =  HIGH-VALUES
016395          MOVE L0113-CRC-MODE-FEE-AMT
016395                                TO MIR-CRC-MODE-FEE-AMT
016395      END-IF.


            IF  L0113-LBILL-MODE-FEE-AMT       NOT =  HIGH-VALUES
                MOVE L0113-LBILL-MODE-FEE-AMT
                                      TO MIR-LBILL-MODE-FEE-AMT
            END-IF.


            IF  L0113-COMM-RT-LOOP-IND         NOT =  HIGH-VALUES
                MOVE L0113-COMM-RT-LOOP-IND
                                      TO MIR-COMM-RT-LOOP-IND
            END-IF.


            IF  L0113-COMM-RT-TBAC-CD          NOT =  HIGH-VALUES
                MOVE L0113-COMM-RT-TBAC-CD
                                      TO MIR-COMM-RT-TBAC-CD
            END-IF.


            IF  L0113-FYR-COMM-XTRA-RT         NOT =  HIGH-VALUES
                MOVE L0113-FYR-COMM-XTRA-RT
                                      TO MIR-FYR-COMM-XTRA-RT
            END-IF.


            IF  L0113-PLAN-MDRT-CLAS-CD        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-MDRT-CLAS-CD
                                      TO MIR-PLAN-MDRT-CLAS-CD
            END-IF.


010302*     IF  L0113-PLAN-FND-COMM-CD         NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-FND-COMM-CD    TO MIR-FNDIND
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-FND-COMM-INFO       NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-FND-COMM-INFO  TO MIR-FNDPTR
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-DED-COMM-CD         NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-DED-COMM-CD    TO MIR-DRWIND
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-DED-COMM-INFO       NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-DED-COMM-INFO  TO MIR-DRWPTR
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-COMM-TRG-RH-ID           NOT =  HIGH-VALUES
010302*         MOVE L0113-COMM-TRG-RH-ID      TO MIR-CMTGPA
010302*     END-IF.
010302*
010302*
            IF  L0113-COMM-TRG-SSTD-IND        NOT =  HIGH-VALUES
                MOVE L0113-COMM-TRG-SSTD-IND
                                      TO MIR-COMM-TRG-SSTD-IND
            END-IF.


            IF  L0113-COMM-RH-SUB-CD           NOT =  HIGH-VALUES
                MOVE L0113-COMM-RH-SUB-CD
                                      TO MIR-COMM-RH-SUB-CD
            END-IF.


022730*     IF  L0113-PREM-PAY-UVAL-ID         NOT =  HIGH-VALUES
022730*         MOVE L0113-PREM-PAY-UVAL-ID
022730*                               TO MIR-PREM-PAY-UVAL-ID
022730*     END-IF.
022730*
022730*
022730*     IF  L0113-PU-UVAL-ID               NOT =  HIGH-VALUES
022730*         MOVE L0113-PU-UVAL-ID TO MIR-PU-UVAL-ID
022730*     END-IF.


            IF  L0113-CSV-CALC-MTHD-CD         NOT =  HIGH-VALUES
                MOVE L0113-CSV-CALC-MTHD-CD
                                      TO MIR-CSV-CALC-MTHD-CD
            END-IF.


            IF  L0113-PLAN-CSV-DT-TYP-CD       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-CSV-DT-TYP-CD
                                      TO MIR-PLAN-CSV-DT-TYP-CD
            END-IF.


            IF  L0113-PLAN-CF-TYP-CD           NOT =  HIGH-VALUES
                MOVE L0113-PLAN-CF-TYP-CD
                                      TO MIR-PLAN-CF-TYP-CD
            END-IF.


            IF  L0113-CF-INT-MODE-CD           NOT =  HIGH-VALUES
                MOVE L0113-CF-INT-MODE-CD
                                      TO MIR-CF-INT-MODE-CD
            END-IF.


            IF  L0113-CF-INT-CALC-TYP-CD       NOT =  HIGH-VALUES
                MOVE L0113-CF-INT-CALC-TYP-CD
                                      TO MIR-CF-INT-CALC-TYP-CD
            END-IF.


            IF  L0113-INT-ADJ-MAX-DUR          NOT =  HIGH-VALUES
                MOVE L0113-INT-ADJ-MAX-DUR
                                      TO MIR-INT-ADJ-MAX-DUR
            END-IF.


            IF  L0113-CSV-INT-RT-ID            NOT =  HIGH-VALUES
                MOVE L0113-CSV-INT-RT-ID
                                      TO MIR-CSV-INT-RT-ID
            END-IF.


            IF  L0113-PDF-INT-RT-ID            NOT =  HIGH-VALUES
                MOVE L0113-PDF-INT-RT-ID
                                      TO MIR-PDF-INT-RT-ID
            END-IF.


            IF  L0113-PREM-CHNG-DT-CD          NOT =  HIGH-VALUES
                MOVE L0113-PREM-CHNG-DT-CD
                                      TO MIR-PREM-CHNG-DT-CD
            END-IF.


            IF  L0113-PREM-CHNG-AGE-DUR        NOT =  HIGH-VALUES
                MOVE L0113-PREM-CHNG-AGE-DUR
                                      TO MIR-PREM-CHNG-AGE-DUR
            END-IF.


            IF  L0113-INIT-PREM-CHNG-AGE       NOT =  HIGH-VALUES
                MOVE L0113-INIT-PREM-CHNG-AGE
                                      TO MIR-INIT-PREM-CHNG-AGE
            END-IF.


            IF  L0113-ULT-PREM-CHNG-AGE        NOT =  HIGH-VALUES
                MOVE L0113-ULT-PREM-CHNG-AGE
                                      TO MIR-ULT-PREM-CHNG-AGE
            END-IF.


            IF  L0113-XPRY-DT-CALC-CD          NOT =  HIGH-VALUES
                MOVE L0113-XPRY-DT-CALC-CD
                                      TO MIR-XPRY-DT-CALC-CD
            END-IF.


            IF  L0113-POL-XPRY-AGE-DUR         NOT =  HIGH-VALUES
                MOVE L0113-POL-XPRY-AGE-DUR
                                      TO MIR-POL-XPRY-AGE-DUR
            END-IF.


            IF  L0113-PLAN-BASE-XPRY-AGE       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-BASE-XPRY-AGE
                                      TO MIR-PLAN-BASE-XPRY-AGE
            END-IF.


            IF  L0113-CVG-XPRY-AGE-DUR         NOT =  HIGH-VALUES
                MOVE L0113-CVG-XPRY-AGE-DUR
                                      TO MIR-CVG-XPRY-AGE-DUR
            END-IF.


            IF  L0113-PLAN-CVG-XPRY-AGE        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-CVG-XPRY-AGE
                                      TO MIR-PLAN-CVG-XPRY-AGE
            END-IF.


            IF  L0113-MAT-DT-CALC-CD           NOT =  HIGH-VALUES
                MOVE L0113-MAT-DT-CALC-CD
                                      TO MIR-MAT-DT-CALC-CD
            END-IF.


            IF  L0113-PLAN-MAT-AGE-DUR         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-MAT-AGE-DUR
                                      TO MIR-PLAN-MAT-AGE-DUR
            END-IF.


            IF  L0113-PLAN-MAT-AGE             NOT =  HIGH-VALUES
                MOVE L0113-PLAN-MAT-AGE
                                      TO MIR-PLAN-MAT-AGE
            END-IF.


016534*     IF  L0113-PLAN-DUR-TYP-CD          NOT =  HIGH-VALUES
016534*                MOVE L0113-PLAN-DUR-TYP-CD
016534*                                      TO MIR-PLAN-DUR-TYP-CD
016534*     END-IF.


            IF  L0113-CNVR-XPRY-DT-CD          NOT =  HIGH-VALUES
                MOVE L0113-CNVR-XPRY-DT-CD
                                      TO MIR-CNVR-XPRY-DT-CD
            END-IF.


            IF  L0113-CNVR-XPRY-AGE-DUR        NOT =  HIGH-VALUES
                MOVE L0113-CNVR-XPRY-AGE-DUR
                                      TO MIR-CNVR-XPRY-AGE-DUR
            END-IF.


            IF  L0113-PLAN-ADB-XPRY-AGE        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-ADB-XPRY-AGE
                                      TO MIR-PLAN-ADB-XPRY-AGE
            END-IF.


            IF  L0113-PLAN-WP-XPRY-AGE         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-WP-XPRY-AGE
                                      TO MIR-PLAN-WP-XPRY-AGE
            END-IF.


            IF  L0113-PLAN-WP-XPRY-CD          NOT =  HIGH-VALUES
                MOVE L0113-PLAN-WP-XPRY-CD
                                      TO MIR-PLAN-WP-XPRY-CD
            END-IF.


            IF  L0113-REDC-EP-XPRY-AGE         NOT =  HIGH-VALUES
                MOVE L0113-REDC-EP-XPRY-AGE
                                      TO MIR-REDC-EP-XPRY-AGE
            END-IF.


            IF  L0113-OWN-OCCP-XPRY-AGE        NOT =  HIGH-VALUES
                MOVE L0113-OWN-OCCP-XPRY-AGE
                                      TO MIR-OWN-OCCP-XPRY-AGE
            END-IF.


            IF  L0113-PLAN-LTA-XPRY-AGE        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-LTA-XPRY-AGE
                                      TO MIR-PLAN-LTA-XPRY-AGE
            END-IF.


            IF  L0113-PLAN-LTB-XPRY-AGE        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-LTB-XPRY-AGE
                                      TO MIR-PLAN-LTB-XPRY-AGE
            END-IF.


            IF  L0113-PDISAB-XPRY-AGE          NOT =  HIGH-VALUES
                MOVE L0113-PDISAB-XPRY-AGE
                                      TO MIR-PDISAB-XPRY-AGE
            END-IF.


            IF  L0113-PLAN-COLA-XPRY-AGE       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-COLA-XPRY-AGE
                                      TO MIR-PLAN-COLA-XPRY-AGE
            END-IF.


010300*     IF  L0113-RMND-NOTI-DUR-INFO       NOT =  HIGH-VALUES
010300*         MOVE L0113-RMND-NOTI-DUR-INFO  TO MIR-RMND
010300*     END-IF.
010300*
010302*
010304*     IF  L0113-LAPS-NOTI-DUR-INFO       NOT =  HIGH-VALUES
010304*         MOVE L0113-LAPS-NOTI-DUR-INFO  TO MIR-LAPSE
010302*     END-IF.
010302*
010302*
            IF  L0113-NF-PRCES-DUR-INFO        NOT =  HIGH-VALUES
                MOVE L0113-NF-PRCES-DUR-INFO
                                      TO MIR-NF-PRCES-MO-DUR
            END-IF.

012522      IF  L0113-PLAN-MIN-PU-AMT          NOT =  HIGH-VALUES
012522          MOVE L0113-PLAN-MIN-PU-AMT     TO MIR-PLAN-MIN-PU-AMT
012522      END-IF.
012522
012522
010650*     IF  L0113-INIT-GRACE-DUR-INFO      NOT =  HIGH-VALUES
010650*         MOVE L0113-INIT-GRACE-DUR-INFO TO MIR-ULIGRC
010650*     END-IF.
010650*
010302*
010650*     IF  L0113-UL-NLAPS-GUAR-DUR        NOT =  HIGH-VALUES
010650*         MOVE L0113-UL-NLAPS-GUAR-DUR   TO MIR-ULGUAR
010650*     END-IF.
010650*
010650*
010650*     IF  L0113-UL-NLAPS-DED-QTY         NOT =  HIGH-VALUES
010650*         MOVE L0113-UL-NLAPS-DED-QTY    TO MIR-ULPERS
010650*     END-IF.
010650*
010302*
035251*     IF  L0113-RPU-TBAC-ID              NOT =  HIGH-VALUES
035251*         MOVE L0113-RPU-TBAC-ID                TO MIR-RPU-TBAC-ID
035251*     END-IF.
035251
035251      IF  L0113-RPU-PLAN-ID              NOT =  HIGH-VALUES
035251          MOVE L0113-RPU-PLAN-ID                TO MIR-RPU-PLAN-ID
035251      END-IF.


014591*     IF  L0113-FPU-PLAN-BASE-ID         NOT =  HIGH-VALUES
014591*         MOVE L0113-FPU-PLAN-BASE-ID
014591*                               TO MIR-FPU-PLAN-BASE-ID
014591*     END-IF.


            IF  L0113-ETI-FACE-CALC-CD         NOT =  HIGH-VALUES
                MOVE L0113-ETI-FACE-CALC-CD
                                      TO MIR-ETI-FACE-CALC-CD
            END-IF.


035251*     IF  L0113-ETI-TBAC-ID              NOT =  HIGH-VALUES
035251*         MOVE L0113-ETI-TBAC-ID                TO MIR-ETI-TBAC-ID
035251*     END-IF.
035251
035251      IF  L0113-ETI-PLAN-ID              NOT =  HIGH-VALUES
035251          MOVE L0113-ETI-PLAN-ID                TO MIR-ETI-PLAN-ID
035251      END-IF.


            IF  L0113-NOTI-DT-CALC-CD          NOT =  HIGH-VALUES
                MOVE L0113-NOTI-DT-CALC-CD
                                      TO MIR-NOTI-DT-CALC-CD
            END-IF.


            IF  L0113-NOTI-LOW-AGE-DUR         NOT =  HIGH-VALUES
                MOVE L0113-NOTI-LOW-AGE-DUR
                                      TO MIR-NOTI-LOW-AGE-DUR
            END-IF.


            IF  L0113-NOTI-HIGH-AGE-DUR        NOT =  HIGH-VALUES
                MOVE L0113-NOTI-HIGH-AGE-DUR
                                      TO MIR-NOTI-HIGH-AGE-DUR
            END-IF.


            IF  L0113-PLAN-NOTI-REASN-CD       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-NOTI-REASN-CD
                                      TO MIR-PLAN-NOTI-REASN-CD
            END-IF.


            IF  L0113-NOTI-DEPT-ID             NOT =  HIGH-VALUES
                MOVE L0113-NOTI-DEPT-ID
                                      TO MIR-NOTI-DEPT-ID
            END-IF.
557693
557693
557693      IF  L0113-PERI-STMT-TYP-CD         NOT =  HIGH-VALUES
557693          MOVE L0113-PERI-STMT-TYP-CD
                                      TO MIR-PERI-STMT-TYP-CD
557693      END-IF.
557693
557693
557693      IF  L0113-PERI-STMT-DY-DUR         NOT =  HIGH-VALUES
557693          MOVE L0113-PERI-STMT-DY-DUR
                                      TO MIR-PERI-STMT-DY-DUR
557693      END-IF.
557693
557693
557693      IF  L0113-PERI-STMT-MO-DUR         NOT =  HIGH-VALUES
557693          MOVE L0113-PERI-STMT-MO-DUR
                                      TO MIR-PERI-STMT-MO-DUR
557693      END-IF.


            IF  L0113-TRM-PREM-RFND-RT         NOT =  HIGH-VALUES
                MOVE L0113-TRM-PREM-RFND-RT
                                      TO MIR-TRM-PREM-RFND-RT
            END-IF.


            IF  L0113-LOAN-INT-CALC-CD         NOT =  HIGH-VALUES
                MOVE L0113-LOAN-INT-CALC-CD
                                      TO MIR-LOAN-INT-CALC-CD
            END-IF.

012145      IF  L0113-LOAN-COLL-FND-IND        NOT =  HIGH-VALUES
012145          MOVE L0113-LOAN-COLL-FND-IND
                                      TO MIR-PLAN-COLFND-IND
012145      END-IF.
012145      IF  L0113-LOAN-COLL-FND-REQ        NOT =  HIGH-VALUES
012145          MOVE L0113-LOAN-COLL-FND-REQ
                                      TO MIR-COLFND-REQIR-IND
012145      END-IF.

            IF  L0113-LOAN-INT-RT-TYP-CD       NOT =  HIGH-VALUES
                MOVE L0113-LOAN-INT-RT-TYP-CD
                                      TO MIR-LOAN-INT-RT-TYP-CD
            END-IF.


            IF  L0113-PLAN-LOAN-INT-RT         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-LOAN-INT-RT
                                      TO MIR-PLAN-LOAN-INT-RT
            END-IF.


010651*     IF  L0113-LOAN-INT-MAX-RT          NOT =  HIGH-VALUES
010651*         MOVE L0113-LOAN-INT-MAX-RT     TO MIR-VARIRT
010651*     END-IF.
010651*
010302*
            IF  L0113-LOAN-INT-RT-ID           NOT =  HIGH-VALUES
                MOVE L0113-LOAN-INT-RT-ID
                                      TO MIR-LOAN-INT-RT-ID
            END-IF.


            IF  L0113-APL-INT-RT-ID            NOT =  HIGH-VALUES
                MOVE L0113-APL-INT-RT-ID
                                      TO MIR-APL-INT-RT-ID
            END-IF.


            IF  L0113-PLAN-PAR-CD              NOT =  HIGH-VALUES
                MOVE L0113-PLAN-PAR-CD             TO MIR-PLAN-PAR-CD
            END-IF.


            IF  L0113-DOD-INT-RT-ID            NOT =  HIGH-VALUES
                MOVE L0113-DOD-INT-RT-ID
                                      TO MIR-DOD-INT-RT-ID
            END-IF.


035251*     IF  L0113-DIV-OYT-TBAC-ID          NOT =  HIGH-VALUES
035251*         MOVE L0113-DIV-OYT-TBAC-ID
035251*                               TO MIR-DIV-OYT-TBAC-ID
035251*     END-IF.


035251*     IF  L0113-DIV-PUA-TBAC-ID-1-2      NOT =  HIGH-VALUES
035251*         MOVE L0113-DIV-PUA-TBAC-ID-1-2
035251*                               TO MIR-DIV-PUA-TBAC-ID
035251*     END-IF.


            IF  L0113-PUA-DIV-CALC-CD          NOT =  HIGH-VALUES
                MOVE L0113-PUA-DIV-CALC-CD
                                      TO MIR-PUA-DIV-CALC-CD
            END-IF.

013585      IF  L0113-CVG-LOAN-IND             NOT =  HIGH-VALUES
013585          MOVE L0113-CVG-LOAN-IND
                                      TO MIR-PLAN-CVG-LOAN-IND
013585      END-IF.
013585
013924      IF  L0113-BON-EFF-MON              NOT =  HIGH-VALUES
013924          MOVE L0113-BON-EFF-MON         TO MIR-PLAN-BON-EFF-MO
013924      END-IF.
013924
013924      IF  L0113-BON-EFF-DY               NOT =  HIGH-VALUES
013924          MOVE L0113-BON-EFF-DY TO MIR-PLAN-BON-EFF-DY
013924      END-IF.
013924
016016      IF  L0113-PLAN-BON-CALC-CD         NOT =  HIGH-VALUES
016016          MOVE L0113-PLAN-BON-CALC-CD
016016                                TO MIR-PLAN-BON-CALC-CD
016016      END-IF.
016016
013930      IF  L0113-TRMNL-BON-INT-RT-ID      NOT =  HIGH-VALUES
013930          MOVE L0113-TRMNL-BON-INT-RT-ID
                                      TO MIR-PLAN-BON-INT-RT-ID
013930      END-IF.
013930
013930      IF  L0113-TRMNL-DIV-INT-RT-ID      NOT =  HIGH-VALUES
013930          MOVE L0113-TRMNL-DIV-INT-RT-ID
                                      TO MIR-PLAN-DIV-INT-RT-ID
013930      END-IF.

            IF  L0113-PLAN-RPU-DIV-RT          NOT =  HIGH-VALUES
                MOVE L0113-PLAN-RPU-DIV-RT
                                      TO MIR-PLAN-RPU-DIV-RT
            END-IF.


010302*     IF  L0113-NEW-MONY-ADJ-CD          NOT =  HIGH-VALUES
010302*         MOVE L0113-NEW-MONY-ADJ-CD     TO MIR-CVGADJ
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-NEW-MONY-RS-ID           NOT =  HIGH-VALUES
010302*         MOVE L0113-NEW-MONY-RS-ID      TO MIR-CVGRS
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-NEW-MONY-TRM-DUR         NOT =  HIGH-VALUES
010302*         MOVE L0113-NEW-MONY-TRM-DUR    TO MIR-CVGYRS
010302*     END-IF.
010302*
010302*
            IF  L0113-PLAN-VPO-IND             NOT =  HIGH-VALUES
                MOVE L0113-PLAN-VPO-IND
                                      TO MIR-PLAN-VPO-IND
            END-IF.


            IF  L0113-ISWL-FRST-CALC-DUR       NOT =  HIGH-VALUES
                MOVE L0113-ISWL-FRST-CALC-DUR
                                      TO MIR-ISWL-FRST-CALC-DUR
            END-IF.


            IF  L0113-ISWL-CALC-FREQ-DUR       NOT =  HIGH-VALUES
                MOVE L0113-ISWL-CALC-FREQ-DUR
                                      TO MIR-ISWL-CALC-FREQ-DUR
            END-IF.


            IF  L0113-ISWL-CALC-ADV-DUR        NOT =  HIGH-VALUES
                MOVE L0113-ISWL-CALC-ADV-DUR
                                      TO MIR-ISWL-CALC-ADV-DUR
            END-IF.


            IF  L0113-ISWL-PREM-VAR-RT         NOT =  HIGH-VALUES
                MOVE L0113-ISWL-PREM-VAR-RT
                                      TO MIR-ISWL-PREM-VAR-RT
            END-IF.


            IF  L0113-DIR-DPOS-MIN-AMT         NOT =  HIGH-VALUES
                MOVE L0113-DIR-DPOS-MIN-AMT
                                      TO MIR-DIR-DPOS-MIN-AMT
            END-IF.


            IF  L0113-PAC-DPOS-MIN-AMT         NOT =  HIGH-VALUES
                MOVE L0113-PAC-DPOS-MIN-AMT
                                      TO MIR-PAC-DPOS-MIN-AMT
            END-IF.

020467      IF  L0113-DD2-DPOS-MIN-AMT         NOT =  HIGH-VALUES
020467          MOVE L0113-DD2-DPOS-MIN-AMT
020467                                TO MIR-DD2-DPOS-MIN-AMT
020467      END-IF.
020467
019135      IF  L0113-PLAN-INIT-PMT-IND        NOT =  HIGH-VALUES
019135          MOVE L0113-PLAN-INIT-PMT-IND
019135                                TO MIR-PLAN-INIT-PMT-IND
019135      END-IF.
019135
019135
016395      IF  L0113-CRC-DPOS-MIN-AMT         NOT =  HIGH-VALUES
016395          MOVE L0113-CRC-DPOS-MIN-AMT
016395                                TO MIR-CRC-DPOS-MIN-AMT
016395      END-IF.

            IF  L0113-MIN-CASL-PAYO-AMT        NOT =  HIGH-VALUES
                MOVE L0113-MIN-CASL-PAYO-AMT
                                      TO MIR-MIN-CASL-PAYO-AMT
            END-IF.


010302*     IF  L0113-MIN-RRIF-PAY-RH-ID       NOT =  HIGH-VALUES
010302*         MOVE L0113-MIN-RRIF-PAY-RH-ID  TO MIR-MNPYPT
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-MAX-LIF-PAY-RH-ID        NOT =  HIGH-VALUES
010302*         MOVE L0113-MAX-LIF-PAY-RH-ID   TO MIR-MXPYPT
010302*     END-IF.
010302*
010302*
            IF  L0113-PLAN-GUAR-INT-RT         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-GUAR-INT-RT
                                      TO MIR-PLAN-GUAR-INT-RT
            END-IF.


            IF  L0113-ACUM-BRKPT-AMT           NOT =  HIGH-VALUES
                MOVE L0113-ACUM-BRKPT-AMT
                                      TO MIR-ACUM-BRKPT-AMT
            END-IF.


            IF  L0113-PLAN-ROLOVR-TYP-CD       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-ROLOVR-TYP-CD
                                      TO MIR-PLAN-ROLOVR-TYP-CD
            END-IF.


            IF  L0113-MIN-ROLOVR-DUR-INFO      NOT =  HIGH-VALUES
                MOVE L0113-MIN-ROLOVR-DUR-INFO
                                      TO MIR-MIN-ROLOVR-DY-DUR
            END-IF.


            IF  L0113-MAX-ROLOVR-DUR-INFO      NOT =  HIGH-VALUES
                MOVE L0113-MAX-ROLOVR-DUR-INFO
                                      TO MIR-MAX-ROLOVR-DY-DUR
            END-IF.


016307*     IF  L0113-PLAN-ADMIN-FEE-AMT       NOT =  HIGH-VALUES
016307*         MOVE L0113-PLAN-ADMIN-FEE-AMT
016307*                               TO MIR-PLAN-ADMIN-FEE-AMT
016307*     END-IF.
016307*
016307*
016307*     IF  L0113-ADMIN-FEE-WAV-AMT        NOT =  HIGH-VALUES
016307*         MOVE L0113-ADMIN-FEE-WAV-AMT
016307*                               TO MIR-ADMIN-FEE-WAV-AMT
016307*     END-IF.
016307*

            IF  L0113-PLAN-MKTVAL-ADJ-CD       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-MKTVAL-ADJ-CD
                                      TO MIR-PLAN-MKTVAL-ADJ-CD
            END-IF.


            IF  L0113-MAT-CHRG-RTBL2-ID        NOT =  HIGH-VALUES
                MOVE L0113-MAT-CHRG-RTBL2-ID
                                      TO MIR-MAT-CHRG-RTBL2-ID
            END-IF.


010302*     IF  L0113-MNPMT-TRG-RH-ID          NOT =  HIGH-VALUES
010302*         MOVE L0113-MNPMT-TRG-RH-ID     TO MIR-MNPTPA
010302*     END-IF.
010302*
010302*
            IF  L0113-MNPMT-TRG-SSTD-IND       NOT =  HIGH-VALUES
                MOVE L0113-MNPMT-TRG-SSTD-IND
                                      TO MIR-MNPMT-TRG-SSTD-IND
            END-IF.


            IF  L0113-PMT-LOAD-ORDR-CD         NOT =  HIGH-VALUES
                MOVE L0113-PMT-LOAD-ORDR-CD
                                      TO MIR-PMT-LOAD-ORDR-CD
            END-IF.


            IF  L0113-PMT-LOAD-RTBL2-ID        NOT =  HIGH-VALUES
                MOVE L0113-PMT-LOAD-RTBL2-ID
                                      TO MIR-PMT-LOAD-RTBL2-ID
            END-IF.


            IF  L0113-PMT-LOAD-FLAT-AMT        NOT =  HIGH-VALUES
                MOVE L0113-PMT-LOAD-FLAT-AMT
                                      TO MIR-PMT-LOAD-FLAT-AMT
            END-IF.


            IF  L0113-PMT-LOAD-CALC-CD         NOT =  HIGH-VALUES
                MOVE L0113-PMT-LOAD-CALC-CD
                                      TO MIR-PMT-LOAD-CALC-CD
            END-IF.


010302*     IF  L0113-PMT-LOAD-TRG-RH-ID       NOT =  HIGH-VALUES
010302*         MOVE L0113-PMT-LOAD-TRG-RH-ID  TO MIR-PYLTPA
010302*     END-IF.
010302*
010302*
            IF  L0113-PMT-LOAD-SSTD-IND        NOT =  HIGH-VALUES
                MOVE L0113-PMT-LOAD-SSTD-IND
                                      TO MIR-PMT-LOAD-SSTD-IND
            END-IF.


010302*     IF  L0113-PMT-LOAD-RH-ID           NOT =  HIGH-VALUES
010302*         MOVE L0113-PMT-LOAD-RH-ID      TO MIR-PAYRH
010302*     END-IF.
010302*
010302*
            IF  L0113-PMT-ALLOC-MTHD-CD        NOT =  HIGH-VALUES
                MOVE L0113-PMT-ALLOC-MTHD-CD
                                      TO MIR-PMT-ALLOC-MTHD-CD
            END-IF.


            IF  L0113-AFR-THRSHD-CD            NOT =  HIGH-VALUES
                MOVE L0113-AFR-THRSHD-CD
                                      TO MIR-AFR-THRSHD-CD
            END-IF.


010302*     IF  L0113-AFR-THRSHD-RH-ID         NOT =  HIGH-VALUES
010302*         MOVE L0113-AFR-THRSHD-RH-ID TO MIR-AFR-THRSHD-PERI-CDT
010302*     END-IF.
010302*
010302*
            IF  L0113-FPUL-ADDL-PREM-IND       NOT =  HIGH-VALUES
                MOVE L0113-FPUL-ADDL-PREM-IND
                                      TO MIR-FPUL-ADDL-PREM-IND
            END-IF.


            IF  L0113-FPUL-LOAD-TYP-CD         NOT =  HIGH-VALUES
                MOVE L0113-FPUL-LOAD-TYP-CD
                                      TO MIR-FPUL-LOAD-TYP-CD
            END-IF.


            IF  L0113-PSUR-CHRG-TYP-CD         NOT =  HIGH-VALUES
                MOVE L0113-PSUR-CHRG-TYP-CD
                                      TO MIR-PSUR-CHRG-TYP-CD
            END-IF.


            IF  L0113-PSUR-CHRG-FLAT-AMT       NOT =  HIGH-VALUES
                MOVE L0113-PSUR-CHRG-FLAT-AMT
                                      TO MIR-PSUR-CHRG-FLAT-AMT
            END-IF.


            IF  L0113-PSUR-CHRG-RTBL2-ID       NOT =  HIGH-VALUES
                MOVE L0113-PSUR-CHRG-RTBL2-ID
                                      TO MIR-PSUR-CHRG-RTBL2-ID
            END-IF.


010302*     IF  L0113-PSUR-CHRG-RH-ID          NOT =  HIGH-VALUES
010302*         MOVE L0113-PSUR-CHRG-RH-ID     TO MIR-PSURRH
010302*     END-IF.
010302*
010302*
            IF  L0113-SURR-CHRG-TYP-CD         NOT =  HIGH-VALUES
                MOVE L0113-SURR-CHRG-TYP-CD
                                      TO MIR-SURR-CHRG-TYP-CD
            END-IF.


            IF  L0113-SURR-CHRG-CALC-CD        NOT =  HIGH-VALUES
                MOVE L0113-SURR-CHRG-CALC-CD
                                      TO MIR-SURR-CHRG-CALC-CD
            END-IF.

012143      IF  L0113-SURR-CHRG-RMVL-ORDR-CD   NOT =  HIGH-VALUES
012143          MOVE L0113-SURR-CHRG-RMVL-ORDR-CD
012143                                TO MIR-DPOS-WTHDR-ORDR-CD
012143      END-IF.
012143

            IF  L0113-SURR-CHRG-FLAT-AMT       NOT =  HIGH-VALUES
                MOVE L0113-SURR-CHRG-FLAT-AMT
                                      TO MIR-SURR-CHRG-FLAT-AMT
            END-IF.


            IF  L0113-SURR-CHRG-RTBL2-ID       NOT =  HIGH-VALUES
                MOVE L0113-SURR-CHRG-RTBL2-ID
                                      TO MIR-SURR-CHRG-RTBL2-ID
            END-IF.


            IF  L0113-PLAN-SURR-CHRG-CD        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-SURR-CHRG-CD
                                      TO MIR-PLAN-SURR-CHRG-CD
            END-IF.


010302*     IF  L0113-SURR-TRG-RH-ID           NOT =  HIGH-VALUES
010302*         MOVE L0113-SURR-TRG-RH-ID      TO MIR-SURTPA
010302*     END-IF.
010302*
010302*
            IF  L0113-SURR-TRG-SSTD-IND        NOT =  HIGH-VALUES
                MOVE L0113-SURR-TRG-SSTD-IND
                                      TO MIR-SURR-TRG-SSTD-IND
            END-IF.


010302*     IF  L0113-SURR-CHRG-RH-ID          NOT =  HIGH-VALUES
010302*         MOVE L0113-SURR-CHRG-RH-ID     TO MIR-FSURRH
010302*     END-IF.
010302*
010302*
            IF  L0113-SURR-ADJ-CALC-CD         NOT =  HIGH-VALUES
                MOVE L0113-SURR-ADJ-CALC-CD
                                      TO MIR-SURR-ADJ-CALC-CD
            END-IF.


            IF  L0113-SURR-ADJ-MO-DUR          NOT =  HIGH-VALUES
                MOVE L0113-SURR-ADJ-MO-DUR
                                      TO MIR-SURR-ADJ-MO-DUR
            END-IF.


            IF  L0113-SURR-ADJ-TYP-CD          NOT =  HIGH-VALUES
                MOVE L0113-SURR-ADJ-TYP-CD
                                      TO MIR-SURR-ADJ-TYP-CD
            END-IF.


            IF  L0113-CV-ALLOC-MTHD-CD         NOT =  HIGH-VALUES
                MOVE L0113-CV-ALLOC-MTHD-CD
                                      TO MIR-CV-ALLOC-MTHD-CD
            END-IF.


            IF  L0113-CVG-CV-ALLOC-IND         NOT =  HIGH-VALUES
                MOVE L0113-CVG-CV-ALLOC-IND
                                      TO MIR-CVG-CV-ALLOC-IND
            END-IF.


010302*     IF  L0113-PLAN-SETUP-CHRG-CD       NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-SETUP-CHRG-CD  TO MIR-ISCHKC
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-SETUP-CHRG-INFO          NOT =  HIGH-VALUES
010302*         MOVE L0113-SETUP-CHRG-INFO     TO MIR-ISCHPA
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-PERI-LOAD-CD        NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-PERI-LOAD-CD   TO MIR-ADEXKC
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PERI-LOAD-INFO           NOT =  HIGH-VALUES
010302*         MOVE L0113-PERI-LOAD-INFO      TO MIR-ADEXPA
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-COI-CD              NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-COI-CD         TO MIR-COIKC
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-COI-INFO            NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-COI-INFO       TO MIR-COIPA
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-GUAR-COI-CD         NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-GUAR-COI-CD    TO MIR-GCOIKC
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-PLAN-GUAR-COI-INFO       NOT =  HIGH-VALUES
010302*         MOVE L0113-PLAN-GUAR-COI-INFO  TO MIR-GCOIPA
010302*     END-IF.
010302*
010302*
            IF  L0113-PLAN-NAR-DSCNT-RT        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-NAR-DSCNT-RT
                                      TO MIR-PLAN-NAR-DSCNT-RT
            END-IF.


            IF  L0113-PLAN-IMPRD-RT-CD         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-IMPRD-RT-CD
                                      TO MIR-PLAN-IMPRD-RT-CD
            END-IF.


            IF  L0113-PLAN-IMPRD-INT-RT        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-IMPRD-INT-RT
                                      TO MIR-PLAN-IMPRD-INT-RT
            END-IF.


            IF  L0113-PLAN-REG-IND             NOT =  HIGH-VALUES
                MOVE L0113-PLAN-REG-IND
                                      TO MIR-PLAN-REG-IND
            END-IF.


            IF  L0113-T5-REG-TITL-TXT          NOT =  HIGH-VALUES
                MOVE L0113-T5-REG-TITL-TXT
                                      TO MIR-T5-REG-TITL-TXT
            END-IF.


            IF  L0113-PLAN-TAXWH-IND           NOT =  HIGH-VALUES
                MOVE L0113-PLAN-TAXWH-IND
                                      TO MIR-PLAN-TAXWH-IND
            END-IF.


010302*    IF  L0113-PLAN-TAXWH-RH-ID         NOT =  HIGH-VALUES
010302*        MOVE L0113-PLAN-TAXWH-RH-ID    TO MIR-TXRTPT
010302*    END-IF.
010302*
010302*
557691      IF  L0113-PNSN-QUALF-IND           NOT =  HIGH-VALUES
557691          MOVE L0113-PNSN-QUALF-IND
                                      TO MIR-PNSN-QUALF-IND
557691      END-IF.
557691
557691
010302*     IF  L0113-QUALF-CNTRB-RH-ID        NOT =  HIGH-VALUES
010302*         MOVE L0113-QUALF-CNTRB-RH-ID   TO MIR-DPLMPT
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-IA-LXPCT-RH-ID            NOT =  HIGH-VALUES
010302*         MOVE L0113-IA-LXPCT-RH-ID       TO MIR-LIFEX
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-IA-GUAR-RFND-RH-ID       NOT =  HIGH-VALUES
010302*         MOVE L0113-IA-GUAR-RFND-RH-ID  TO MIR-GUAREF
010302*     END-IF.
010302*
010302*
015290*     IF  L0113-DISP-WTHDR-ORDR-CD       NOT =  HIGH-VALUES
015290*         MOVE L0113-DISP-WTHDR-ORDR-CD
015290*                               TO MIR-DISP-WTHDR-ORDR-CD
015290*     END-IF.
015290*
010302*     IF  L0113-GDLN-DB-CORDR-CD         NOT =  HIGH-VALUES
010302*         MOVE L0113-GDLN-DB-CORDR-CD    TO MIR-DBCORK
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-GDLN-DB-CORDR-ID         NOT =  HIGH-VALUES
010302*         MOVE L0113-GDLN-DB-CORDR-ID    TO MIR-DBCOR
010302*     END-IF.
010302*
010302*
022730*     IF  L0113-XEMP-TST-UVAL-ID         NOT =  HIGH-VALUES
022730*         MOVE L0113-XEMP-TST-UVAL-ID
022730*                               TO MIR-XEMP-TST-UVAL-ID
022730*     END-IF.


010302*     IF  L0113-ALG-PREM-TBAC-CD         NOT =  HIGH-VALUES
010302*         MOVE L0113-ALG-PREM-TBAC-CD    TO MIR-LVAIND
010302*     END-IF.
010302*
010302*

010302*     IF  L0113-ALG-PREM-TBAC-ID         NOT =  HIGH-VALUES
010302*         MOVE L0113-ALG-PREM-TBAC-ID    TO MIR-LVAPTA
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-SLG-PREM-TBAC-CD         NOT =  HIGH-VALUES
010302*         MOVE L0113-SLG-PREM-TBAC-CD    TO MIR-LVSIND
010302*     END-IF.
010302*
010302*
010302
010302*     IF  L0113-SLG-PREM-TBAC-ID         NOT =  HIGH-VALUES
010302*         MOVE L0113-SLG-PREM-TBAC-ID    TO MIR-LVSPTA
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-AIG-PREM-TBAC-CD         NOT =  HIGH-VALUES
010302*         MOVE L0113-AIG-PREM-TBAC-CD    TO MIR-INCAIN
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-AIG-PREM-TBAC-ID         NOT =  HIGH-VALUES
010302*         MOVE L0113-AIG-PREM-TBAC-ID    TO MIR-INCAPA
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-SIG-PREM-TBAC-CD         NOT =  HIGH-VALUES
010302*         MOVE L0113-SIG-PREM-TBAC-CD    TO MIR-INCSIN
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-SIG-PREM-TBAC-ID         NOT =  HIGH-VALUES
010302*         MOVE L0113-SIG-PREM-TBAC-ID    TO MIR-INCSPT
010302*     END-IF.
010302*
010302*
015919*     IF  L0113-PLAN-TAMRA-IND           NOT =  HIGH-VALUES
015919*         MOVE L0113-PLAN-TAMRA-IND
015919*                               TO MIR-PLAN-TAMRA-IND
015919      IF  L0113-PLAN-TAMRA-CD            NOT =  HIGH-VALUES
015919          MOVE L0113-PLAN-TAMRA-CD
015919                                TO MIR-PLAN-TAMRA-CD
            END-IF.


035251*     IF  L0113-PLAN-TAMRA-MXDX-ID       NOT =  HIGH-VALUES
035251*         MOVE L0113-PLAN-TAMRA-MXDX-ID
035251*                               TO MIR-PLAN-TAMRA-MXDX-ID
035251*     END-IF.


035251*     IF  L0113-PLAN-7702-MXDX-ID        NOT =  HIGH-VALUES
035251*         MOVE L0113-PLAN-7702-MXDX-ID
035251*                               TO MIR-PLAN-7702-MXDX-ID
035251*     END-IF.


            IF  L0113-PLAN-RSRV-CALC-CD        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-RSRV-CALC-CD
                                      TO MIR-PLAN-RSRV-CALC-CD
            END-IF.


            IF  L0113-VALN-LBL-ID              NOT =  HIGH-VALUES
                MOVE L0113-VALN-LBL-ID                TO MIR-VALN-LBL-ID
            END-IF.


            IF  L0113-ADB-PLAN-ID              NOT =  HIGH-VALUES
                MOVE L0113-ADB-PLAN-ID                TO MIR-ADB-PLAN-ID
            END-IF.


            IF  L0113-WP-PLAN-ID               NOT =  HIGH-VALUES
                MOVE L0113-WP-PLAN-ID TO MIR-WP-PLAN-ID
            END-IF.


            IF  L0113-REDC-EP-PLAN-ID          NOT =  HIGH-VALUES
                MOVE L0113-REDC-EP-PLAN-ID
                                      TO MIR-REDC-EP-PLAN-ID
            END-IF.


            IF  L0113-OWN-OCCP-PLAN-ID         NOT =  HIGH-VALUES
                MOVE L0113-OWN-OCCP-PLAN-ID
                                      TO MIR-OWN-OCCP-PLAN-ID
            END-IF.


            IF  L0113-LTA-PLAN-ID              NOT =  HIGH-VALUES
                MOVE L0113-LTA-PLAN-ID                TO MIR-LTA-PLAN-ID
            END-IF.


            IF  L0113-LTB-PLAN-ID              NOT =  HIGH-VALUES
                MOVE L0113-LTB-PLAN-ID                TO MIR-LTB-PLAN-ID
            END-IF.


            IF  L0113-PDISAB-PLAN-ID           NOT =  HIGH-VALUES
                MOVE L0113-PDISAB-PLAN-ID
                                      TO MIR-PDISAB-PLAN-ID
            END-IF.


            IF  L0113-COLA-1-PLAN-ID           NOT =  HIGH-VALUES
                MOVE L0113-COLA-1-PLAN-ID
                                      TO MIR-COLA-1-PLAN-ID
            END-IF.


            IF  L0113-COLA-2-PLAN-ID           NOT =  HIGH-VALUES
                MOVE L0113-COLA-2-PLAN-ID
                                      TO MIR-COLA-2-PLAN-ID
            END-IF.


            IF  L0113-COLA-3-PLAN-ID           NOT =  HIGH-VALUES
                MOVE L0113-COLA-3-PLAN-ID
                                      TO MIR-COLA-3-PLAN-ID
            END-IF.


            IF  L0113-COLA-4-PLAN-ID           NOT =  HIGH-VALUES
                MOVE L0113-COLA-4-PLAN-ID
                                      TO MIR-COLA-4-PLAN-ID
            END-IF.


016440*     IF  L0113-APPL-ID                  NOT =  HIGH-VALUES
016440*         MOVE L0113-APPL-ID    TO MIR-APPL-ID
016440*     END-IF.

016440      IF  L0113-SYS-ID                   NOT =  HIGH-VALUES
016440          MOVE L0113-SYS-ID
016440                                TO MIR-PLAN-SYS-ID
016440      END-IF.

010302*     IF  L0113-ENHC-FACE-RH-ID          NOT =  HIGH-VALUES
010302*         MOVE L0113-ENHC-FACE-RH-ID     TO MIR-ENHPTR
010302*     END-IF.
010302*
010302*
            IF  L0113-ENHC-FREQ-DUR            NOT =  HIGH-VALUES
                MOVE L0113-ENHC-FREQ-DUR
                                      TO MIR-ENHC-FREQ-DUR
            END-IF.


            IF  L0113-ENHC-STRT-DUR            NOT =  HIGH-VALUES
                MOVE L0113-ENHC-STRT-DUR
                                      TO MIR-ENHC-STRT-DUR
            END-IF.


            IF  L0113-ENHC-END-DUR             NOT =  HIGH-VALUES
                MOVE L0113-ENHC-END-DUR
                                      TO MIR-ENHC-END-DUR
            END-IF.


            IF  L0113-ENHC-END-AGE             NOT =  HIGH-VALUES
                MOVE L0113-ENHC-END-AGE
                                      TO MIR-ENHC-END-AGE
            END-IF.


            IF  L0113-ENHC-UWG-FREQ-DUR        NOT =  HIGH-VALUES
                MOVE L0113-ENHC-UWG-FREQ-DUR
                                      TO MIR-ENHC-UWG-FREQ-DUR
            END-IF.


            IF  L0113-ENHC-NELCT-DUR           NOT =  HIGH-VALUES
                MOVE L0113-ENHC-NELCT-DUR
                                      TO MIR-ENHC-NELCT-DUR
            END-IF.


            IF  L0113-ENHC-HIATUS-DUR          NOT =  HIGH-VALUES
                MOVE L0113-ENHC-HIATUS-DUR
                                      TO MIR-ENHC-HIATUS-DUR
            END-IF.


010650*     IF  L0113-FREE-WTHDR-RH-ID         NOT =  HIGH-VALUES
010650*         MOVE L0113-FREE-WTHDR-RH-ID    TO MIR-FREEWPT
010650*     END-IF.
010650*
010302*
            IF  L0113-PLAN-INS-TYP-CD          NOT =  HIGH-VALUES
                MOVE L0113-PLAN-INS-TYP-CD
                                      TO MIR-PLAN-INS-TYP-CD
            END-IF.


            IF  L0113-PLAN-BUS-CLAS-CD         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-BUS-CLAS-CD
                                      TO MIR-PLAN-BUS-CLAS-CD
            END-IF.


            IF  L0113-PLAN-SUPP-BNFT-CD        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-SUPP-BNFT-CD
                                      TO MIR-PLAN-SUPP-BNFT-CD
            END-IF.

012522      IF  L0113-MTHV-PRCES-IND           NOT =  HIGH-VALUES
012522          MOVE L0113-MTHV-PRCES-IND TO MIR-MTHV-PRCES-IND
012522      END-IF.
012522
012522

            IF  L0113-PLAN-ACCT-TYP-CD         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-ACCT-TYP-CD
                                      TO MIR-PLAN-ACCT-TYP-CD
            END-IF.


            IF  L0113-PLAN-UNIT-VALU-AMT       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-UNIT-VALU-AMT
                                      TO MIR-PLAN-UNIT-VALU-AMT
            END-IF.


010302*     IF  L0113-MIN-ISS-FACE-AMT         NOT =  HIGH-VALUES
010302*         MOVE L0113-MIN-ISS-FACE-AMT    TO MIR-MINFA
010302*     END-IF.
010302*
010302*
010302*     IF  L0113-MAX-ISS-FACE-AMT         NOT =  HIGH-VALUES
010302*         MOVE L0113-MAX-ISS-FACE-AMT    TO MIR-MAXFA
010302*     END-IF.
010302*
010302*
            IF  L0113-PLAN-UWG-IND             NOT =  HIGH-VALUES
                MOVE L0113-PLAN-UWG-IND
                                      TO MIR-PLAN-UWG-IND
            END-IF.


            IF  L0113-UWG-FACE-AMT-FCT         NOT =  HIGH-VALUES
                MOVE L0113-UWG-FACE-AMT-FCT
                                      TO MIR-UWG-FACE-AMT-FCT
            END-IF.


            IF  L0113-PLAN-LOC-LIC-CD          NOT =  HIGH-VALUES
                MOVE L0113-PLAN-LOC-LIC-CD
                                      TO MIR-PLAN-LOC-LIC-CD
            END-IF.


            IF  L0113-PREM-CALC-TYP-CD         NOT =  HIGH-VALUES
                MOVE L0113-PREM-CALC-TYP-CD
                                      TO MIR-PREM-CALC-TYP-CD
            END-IF.


            IF  L0113-GIR-PREM-INCL-IND        NOT =  HIGH-VALUES
                MOVE L0113-GIR-PREM-INCL-IND
                                      TO MIR-GIR-PREM-INCL-IND
            END-IF.


            IF  L0113-PLAN-ISS-DT-CD           NOT =  HIGH-VALUES
                MOVE L0113-PLAN-ISS-DT-CD
                                      TO MIR-PLAN-ISS-DT-TYP-CD
            END-IF.


020467*     IF  L0113-PLAN-SEMI-ANN-FCT        NOT =  HIGH-VALUES
020467*         MOVE L0113-PLAN-SEMI-ANN-FCT
020467*                               TO MIR-PLAN-SEMI-ANN-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PLAN-QTR-FCT             NOT =  HIGH-VALUES
020467*         MOVE L0113-PLAN-QTR-FCT
020467*                               TO MIR-PLAN-QTR-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PLAN-MTHLY-FCT           NOT =  HIGH-VALUES
020467*         MOVE L0113-PLAN-MTHLY-FCT
020467*                               TO MIR-PLAN-MTHLY-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PAC-SEMI-ANN-FCT         NOT =  HIGH-VALUES
020467*         MOVE L0113-PAC-SEMI-ANN-FCT
020467*                               TO MIR-PAC-SEMI-ANN-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PLAN-PAC-QTR-FCT         NOT =  HIGH-VALUES
020467*         MOVE L0113-PLAN-PAC-QTR-FCT
020467*                               TO MIR-PLAN-PAC-QTR-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PLAN-PAC-MTHLY-FCT       NOT =  HIGH-VALUES
020467*         MOVE L0113-PLAN-PAC-MTHLY-FCT
020467*                               TO MIR-PLAN-PAC-MTHLY-FCT
020467*     END-IF.
020467*
020467*     IF  L0113-CRC-SEMI-ANN-FCT         NOT =  HIGH-VALUES
020467*         MOVE L0113-CRC-SEMI-ANN-FCT
020467*                               TO MIR-CRC-SEMI-ANN-FCT
020467*     END-IF.
020467*
020467*     IF  L0113-PLAN-CRC-QTR-FCT         NOT =  HIGH-VALUES
020467*         MOVE L0113-PLAN-CRC-QTR-FCT
020467*                               TO MIR-PLAN-CRC-QTR-FCT
020467*     END-IF.
020467*
020467*     IF  L0113-PLAN-CRC-MTHLY-FCT       NOT =  HIGH-VALUES
020467*         MOVE L0113-PLAN-CRC-MTHLY-FCT
020467*                               TO MIR-PLAN-CRC-MTHLY-FCT
020467*     END-IF.

            IF  L0113-PLAN-PFEE-AMT            NOT =  HIGH-VALUES
                MOVE L0113-PLAN-PFEE-AMT
                                      TO MIR-PLAN-PFEE-AMT
            END-IF.


            IF  L0113-PLAN-CVG-PFEE-AMT        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-CVG-PFEE-AMT
                                      TO MIR-PLAN-CVG-PFEE-AMT
            END-IF.


020467*     IF  L0113-SEMI-ANN-PFEE-FCT        NOT =  HIGH-VALUES
020467*         MOVE L0113-SEMI-ANN-PFEE-FCT
020467*                               TO MIR-SEMI-ANN-PFEE-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PLAN-QTR-PFEE-FCT        NOT =  HIGH-VALUES
020467*         MOVE L0113-PLAN-QTR-PFEE-FCT
020467*                               TO MIR-PLAN-QTR-PFEE-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-MTHLY-PFEE-FCT           NOT =  HIGH-VALUES
020467*         MOVE L0113-MTHLY-PFEE-FCT
020467*                               TO MIR-MTHLY-PFEE-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PAC-SEMI-PFEE-FCT        NOT =  HIGH-VALUES
020467*         MOVE L0113-PAC-SEMI-PFEE-FCT
020467*                               TO MIR-PAC-SEMI-PFEE-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PAC-QTR-PFEE-FCT         NOT =  HIGH-VALUES
020467*         MOVE L0113-PAC-QTR-PFEE-FCT
020467*                               TO MIR-PAC-QTR-PFEE-FCT
020467*     END-IF.
020467*
020467*
020467*     IF  L0113-PAC-MTHLY-PFEE-FCT       NOT =  HIGH-VALUES
020467*         MOVE L0113-PAC-MTHLY-PFEE-FCT
020467*                               TO MIR-PAC-MTHLY-PFEE-FCT
020467*     END-IF.
020467*
020467*     IF  L0113-CRC-SEMI-PFEE-FCT        NOT =  HIGH-VALUES
020467*         MOVE L0113-CRC-SEMI-PFEE-FCT
020467*                               TO MIR-CRC-SEMI-PFEE-FCT
020467*     END-IF.
020467*
020467*     IF  L0113-CRC-QTR-PFEE-FCT         NOT =  HIGH-VALUES
020467*         MOVE L0113-CRC-QTR-PFEE-FCT
020467*                               TO MIR-CRC-QTR-PFEE-FCT
020467*     END-IF.
020467*
020467*     IF  L0113-CRC-MTHLY-PFEE-FCT       NOT =  HIGH-VALUES
020467*         MOVE L0113-CRC-MTHLY-PFEE-FCT
020467*                               TO MIR-CRC-MTHLY-PFEE-FCT
020467*     END-IF.

            IF  L0113-PLAN-IA-PFEE-AMT         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-IA-PFEE-AMT
                                      TO MIR-PLAN-IA-PFEE-AMT
            END-IF.


            IF  L0113-COMM-PLAN-TYP-CD         NOT =  HIGH-VALUES
                MOVE L0113-COMM-PLAN-TYP-CD
                                      TO MIR-COMM-PLAN-TYP-CD
            END-IF.


            IF  L0113-PLAN-CPREM-CALC-CD       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-CPREM-CALC-CD
                                      TO MIR-PLAN-CPREM-CALC-CD
            END-IF.


            IF  L0113-OVRID-FRST-DGT-CD        NOT =  HIGH-VALUES
                MOVE L0113-OVRID-FRST-DGT-CD
                                      TO MIR-OVRID-FRST-DGT-CD
            END-IF.


            IF  L0113-IA-COMM-BAND-1-PCT       NOT =  HIGH-VALUES
                MOVE L0113-IA-COMM-BAND-1-PCT
                                      TO MIR-IA-COMM-BAND-1-PCT
            END-IF.


            IF  L0113-IA-COMM-BAND-1-AMT       NOT =  HIGH-VALUES
                MOVE L0113-IA-COMM-BAND-1-AMT
                                      TO MIR-IA-COMM-BAND-1-AMT
            END-IF.


            IF  L0113-IA-COMM-BAND-2-PCT       NOT =  HIGH-VALUES
                MOVE L0113-IA-COMM-BAND-2-PCT
                                      TO MIR-IA-COMM-BAND-2-PCT
            END-IF.


            IF  L0113-IA-COMM-BAND-2-AMT       NOT =  HIGH-VALUES
                MOVE L0113-IA-COMM-BAND-2-AMT
                                      TO MIR-IA-COMM-BAND-2-AMT
            END-IF.


            IF  L0113-IA-COMM-BAND-3-PCT       NOT =  HIGH-VALUES
                MOVE L0113-IA-COMM-BAND-3-PCT
                                      TO MIR-IA-COMM-BAND-3-PCT
            END-IF.


            IF  L0113-IA-COMM-BAND-3-AMT       NOT =  HIGH-VALUES
                MOVE L0113-IA-COMM-BAND-3-AMT
                                      TO MIR-IA-COMM-BAND-3-AMT
            END-IF.


            IF  L0113-IA-COMM-MAX-AMT          NOT =  HIGH-VALUES
                MOVE L0113-IA-COMM-MAX-AMT
                                      TO MIR-IA-COMM-MAX-AMT
            END-IF.


            IF  L0113-IA-INT-RT-ID             NOT =  HIGH-VALUES
                MOVE L0113-IA-INT-RT-ID
                                      TO MIR-IA-INT-RT-ID
            END-IF.


026643*     IF  L0113-IA-INT-PREM-ID           NOT =  HIGH-VALUES
026643*         MOVE L0113-IA-INT-PREM-ID
026643*                               TO MIR-IA-INT-PREM-ID
026643*     END-IF.


            IF  L0113-IA-INT-LEGAL-ID          NOT =  HIGH-VALUES
                MOVE L0113-IA-INT-LEGAL-ID
                                      TO MIR-IA-INT-LEGAL-ID
            END-IF.


            IF  L0113-IA-INT-TAX-ID            NOT =  HIGH-VALUES
                MOVE L0113-IA-INT-TAX-ID
                                      TO MIR-IA-INT-TAX-ID
            END-IF.


            IF  L0113-PLAN-INT-PAYO-CD         NOT =  HIGH-VALUES
                MOVE L0113-PLAN-INT-PAYO-CD
                                      TO MIR-PLAN-INT-PAYO-CD
            END-IF.


            IF  L0113-PLAN-WTHDR-ORDR-CD       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-WTHDR-ORDR-CD
                                      TO MIR-PLAN-WTHDR-ORDR-CD
            END-IF.


010304*     IF  L0113-PLAN-NFO-CD              NOT =  HIGH-VALUES
010304*         MOVE L0113-PLAN-NFO-CD         TO MIR-NFO
010304*     END-IF.
010304*
010304*
            IF  L0113-AUTO-PREM-PMT-IND        NOT =  HIGH-VALUES
                MOVE L0113-AUTO-PREM-PMT-IND
                                      TO MIR-AUTO-PREM-PMT-IND
            END-IF.


010648*     IF  L0113-PLAN-DIV-OPT-CD          NOT =  HIGH-VALUES
010648*         MOVE L0113-PLAN-DIV-OPT-CD     TO MIR-DIVOPT
010648*     END-IF.
010648*
            IF  L0113-PREM-RECALC-OPT-CD       NOT =  HIGH-VALUES
                MOVE L0113-PREM-RECALC-OPT-CD
                                      TO MIR-PREM-RECALC-OPT-CD
            END-IF.


            IF  L0113-AFR-THRSHD-PERI-CD       NOT =  HIGH-VALUES
                MOVE L0113-AFR-THRSHD-PERI-CD
                                      TO MIR-AFR-THRSHD-PERI-CD
            END-IF.


            IF  L0113-PLAN-ROLOVR-DT-IND       NOT =  HIGH-VALUES
                MOVE L0113-PLAN-ROLOVR-DT-IND
                                      TO MIR-PLAN-ROLOVR-DT-IND
            END-IF.


            IF  L0113-DIA-SWP-THRSHD-CD        NOT =  HIGH-VALUES
                MOVE L0113-DIA-SWP-THRSHD-CD
                                      TO MIR-DIA-SWP-THRSHD-CD
            END-IF.


            IF  L0113-DIA-SWP-THRSHD-AMT       NOT =  HIGH-VALUES
                MOVE L0113-DIA-SWP-THRSHD-AMT
                                      TO MIR-DIA-SWP-THRSHD-AMT
            END-IF.


            IF  L0113-PLAN-TXEMP-CD            NOT =  HIGH-VALUES
                MOVE L0113-PLAN-TXEMP-CD
                                      TO MIR-PLAN-TXEMP-CD
            END-IF.


031036      IF  L0113-MAX-TXEMP-INCR-PCT       NOT =  HIGH-VALUES
031036          MOVE L0113-MAX-TXEMP-INCR-PCT
031036                                TO MIR-MAX-TXEMP-INCR-PCT
031036      END-IF.
031036
031036
031036      IF  L0113-MAX-TXEMP-DECR-PCT       NOT =  HIGH-VALUES
031036          MOVE L0113-MAX-TXEMP-DECR-PCT
031036                                TO MIR-MAX-TXEMP-DECR-PCT
031036      END-IF.
031036
031036
            IF  L0113-GAIN-RPT-TIME-CD         NOT =  HIGH-VALUES
                MOVE L0113-GAIN-RPT-TIME-CD
                                      TO MIR-GAIN-RPT-TIME-CD
            END-IF.


            IF  L0113-PLAN-TAX-TYP-CD          NOT =  HIGH-VALUES
                MOVE L0113-PLAN-TAX-TYP-CD
                                      TO MIR-PLAN-TAX-TYP-CD
            END-IF.
557788*
557788*
557788*     IF  L0113-SALE-TAX-BASE-RT         NOT =  HIGH-VALUES
557788*         MOVE L0113-SALE-TAX-BASE-RT    TO MIR-PRMTAX
557788*     END-IF.

557690*
557690*     IF  L0113-IA-TAX-INCM-RT-ID        NOT =  HIGH-VALUES
557690*         MOVE L0113-IA-TAX-INCM-RT-ID   TO MIR-MORTTX
557690*     END-IF.
557691
010302*     IF L0113-PLAN-COI-TAX-RH-ID        = HIGH-VALUES
010302*        MOVE L0113-PLAN-COI-TAX-RH-ID   TO MIR-COIPNT
010302*     END-IF.
010302*

            IF  L0113-PLAN-LOCK-FND-IND        NOT =  HIGH-VALUES
                MOVE L0113-PLAN-LOCK-FND-IND
                                      TO MIR-PLAN-LOCK-FND-IND
            END-IF.


022730*     IF  L0113-IA-MORT-UVAL-ID          NOT =  HIGH-VALUES
022730*         MOVE L0113-IA-MORT-UVAL-ID
022730*                               TO MIR-IA-MORT-UVAL-ID
022730*     END-IF.
022730*
022730*
022730*     IF  L0113-IA-MORT-PREM-ID          NOT =  HIGH-VALUES
022730*         MOVE L0113-IA-MORT-PREM-ID
022730*                               TO MIR-IA-MORT-PREM-ID
022730*     END-IF.
022730*
022730*
022730*     IF  L0113-IA-MORT-LEGAL-ID         NOT =  HIGH-VALUES
022730*         MOVE L0113-IA-MORT-LEGAL-ID
022730*                               TO MIR-IA-MORT-LEGAL-ID
022730*     END-IF.
022730*
022730*
022730*     IF  L0113-IA-MORT-TAX-ID           NOT =  HIGH-VALUES
022730*         MOVE L0113-IA-MORT-TAX-ID
022730*                               TO MIR-IA-MORT-TAX-ID
022730*     END-IF.


            IF  L0113-CVG-ENHC-TYP-CD          NOT =  HIGH-VALUES
                MOVE L0113-CVG-ENHC-TYP-CD
                                      TO MIR-CVG-ENHC-TYP-CD
            END-IF.


            IF  L0113-NUM-GIR-OPT-QTY          NOT =  HIGH-VALUES
                MOVE L0113-NUM-GIR-OPT-QTY
                                      TO MIR-NUM-GIR-OPT-QTY
            END-IF.


010650*     IF  L0113-FREE-WTHDR-CD            NOT =  HIGH-VALUES
010650*         MOVE L0113-FREE-WTHDR-CD       TO MIR-FREEW
010650*     END-IF.
010650*
010650*
010650*     IF  L0113-FREE-WTHDR-QTY           NOT =  HIGH-VALUES
010650*         MOVE L0113-FREE-WTHDR-QTY      TO MIR-FREEWN
010650*     END-IF.
010650*
010650*
010650*     IF  L0113-FREE-WTHDR-PERI-CD       NOT =  HIGH-VALUES
010650*         MOVE L0113-FREE-WTHDR-PERI-CD  TO MIR-FREEWPD
010650*     END-IF.
010650*

010314      IF  L0113-INDX-INCR-MTHD-CD        NOT =  HIGH-VALUES
010314          MOVE L0113-INDX-INCR-MTHD-CD
                                      TO MIR-INDX-INCR-MTHD-CD
010314      END-IF.
010314
010314
010314      IF  L0113-INDX-INCR-MO-DUR         NOT =  HIGH-VALUES
010314          MOVE L0113-INDX-INCR-MO-DUR
                                      TO MIR-INDX-INCR-MO-DUR
010314      END-IF.
010314
010314
010314      IF  L0113-INDX-INCR-DY-DUR         NOT =  HIGH-VALUES
010314          MOVE L0113-INDX-INCR-DY-DUR
                                      TO MIR-INDX-INCR-DY-DUR
010314      END-IF.
010314
011026      IF  L0113-MCV-CALC-REQIR-IND       NOT =  HIGH-VALUES
011026          MOVE L0113-MCV-CALC-REQIR-IND
                                      TO MIR-MCV-CALC-REQIR-IND
011026      END-IF.
011026
011026      IF  L0113-MCV-INT-MTHD-CD          NOT =  HIGH-VALUES
011026          MOVE L0113-MCV-INT-MTHD-CD
                                      TO MIR-MCV-INT-MTHD-CD
011026      END-IF.
011026
011026      IF  L0113-MCV-PMT-LOAD-CD          NOT =  HIGH-VALUES
011026          MOVE L0113-MCV-PMT-LOAD-CD
                                      TO MIR-MCV-PMT-LOAD-CD
011026      END-IF.
011026
011026      IF  L0113-PLAN-EIC-FREQ-CD         NOT =  HIGH-VALUES
011026          MOVE L0113-PLAN-EIC-FREQ-CD
                                      TO MIR-PLAN-EIC-FREQ-CD
011026      END-IF.
011026
011026      IF  L0113-EIC-INIT-YR-DUR          NOT =  HIGH-VALUES
011026          MOVE L0113-EIC-INIT-YR-DUR
                                      TO MIR-EIC-INIT-YR-DUR
011026          END-IF.
011026
011026      IF  L0113-EIC-SUBSEQ-YR-DUR        NOT =  HIGH-VALUES
011026          MOVE L0113-EIC-SUBSEQ-YR-DUR
                                      TO MIR-EIC-SUBSEQ-YR-DUR
011026      END-IF.

031035      IF  L0113-INT-RT-LK-UP-CD          NOT =  HIGH-VALUES
031035          MOVE L0113-INT-RT-LK-UP-CD
031035                                TO MIR-INT-RT-LK-UP-CD
031035      END-IF.

018905*     IF  L0113-PLAN-MAT-MAX-AGE        NOT =   HIGH-VALUES
018905*         MOVE L0113-PLAN-MAT-MAX-AGE TO  MIR-PLAN-MAT-MAX-AGE
018905*     END-IF.
018905*
018905*     IF  L0113-PLAN-MAT-MAX-DUR        NOT =   HIGH-VALUES
018905*         MOVE L0113-PLAN-MAT-MAX-DUR TO  MIR-PLAN-MAT-MAX-DUR
018905*     END-IF.
018905*
018905*     IF  L0113-POL-XPRY-MAX-DUR        NOT =   HIGH-VALUES
018905*         MOVE L0113-POL-XPRY-MAX-DUR TO  MIR-POL-XPRY-MAX-DUR
018905*     END-IF.
018905*
018905*     IF  L0113-BASE-XPRY-MAX-AGE       NOT =   HIGH-VALUES
018905*         MOVE L0113-BASE-XPRY-MAX-AGE TO  MIR-BASE-XPRY-MAX-AGE
018905*     END-IF.
018905*
018905*     IF  L0113-CVG-XPRY-MAX-DUR        NOT =   HIGH-VALUES
018905*         MOVE L0113-CVG-XPRY-MAX-DUR  TO  MIR-CVG-XPRY-MAX-DUR
018905*     END-IF.
018905*
018905*     IF  L0113-CVG-XPRY-MAX-AGE        NOT =   HIGH-VALUES
018905*         MOVE L0113-CVG-XPRY-MAX-AGE  TO  MIR-CVG-XPRY-MAX-AGE
018905*     END-IF.

010304      IF  L0113-ACTN-COLCT-ID            NOT =  HIGH-VALUES
010304          MOVE L0113-ACTN-COLCT-ID
                                      TO MIR-ACTN-COLCT-ID
010304      END-IF.
010304
012146      IF  L0113-MORT-XPNS-CHRG-AGE       NOT =  HIGH-VALUES
012146          MOVE L0113-MORT-XPNS-CHRG-AGE
                                      TO MIR-MORT-XPNS-CHRG-AGE
012146      END-IF.
012146
012146      IF  L0113-MORT-XPNS-CHRG-DUR       NOT =  HIGH-VALUES
012146          MOVE L0113-MORT-XPNS-CHRG-DUR
                                      TO MIR-MORT-XPNS-CHRG-DUR
012146      END-IF.
012146
012146      IF  L0113-MORT-XPNS-CALC-CD        NOT =  HIGH-VALUES
012146          MOVE L0113-MORT-XPNS-CALC-CD
                                      TO MIR-MORT-XPNS-CALC-CD
012146      END-IF.
012146
012148      IF  L0113-TRAIL-COMM-FREQ-CD       NOT =  HIGH-VALUES
012148          MOVE L0113-TRAIL-COMM-FREQ-CD
                                      TO MIR-TRAIL-COMM-FREQ-CD
012148      END-IF.
012148
012148      IF  L0113-TRAIL-COMM-BEG-DUR       NOT =  HIGH-VALUES
012148          MOVE L0113-TRAIL-COMM-BEG-DUR
                                      TO MIR-TRAIL-COMM-BEG-DUR
012148      END-IF.
012148
012148      IF  L0113-TRAIL-COMM-LAG-DUR       NOT =  HIGH-VALUES
012148          MOVE L0113-TRAIL-COMM-LAG-DUR
                                      TO MIR-TRAIL-COMM-LAG-DUR
012148      END-IF.
012148
013585      IF  L0113-CONT-PAYO-MTHD           NOT =  HIGH-VALUES
013585          MOVE L0113-CONT-PAYO-MTHD
                                      TO MIR-PLAN-PAYO-MTHD-CD
013585      END-IF.
013585
018846      IF  L0113-PLAN-FND-TYP-CD NOT = HIGH-VALUES
018846          MOVE L0113-PLAN-FND-TYP-CD
018846                                TO MIR-PLAN-FND-TYP-CD
018846      END-IF.
018846
021239      IF  L0113-PLAN-UNIT-TYP-CD NOT = HIGH-VALUES
021239          MOVE L0113-PLAN-UNIT-TYP-CD
021239                                TO MIR-PLAN-UNIT-TYP-CD
021239      END-IF.
021239
020469      IF  L0113-PLAN-MULT-CRCY-IND       NOT =  HIGH-VALUES
020469          MOVE L0113-PLAN-MULT-CRCY-IND  TO MIR-PLAN-MULT-CRCY-IND
020469      END-IF.
020469
020469      IF  L0113-PLAN-CRCY-CD             NOT =  HIGH-VALUES
020469          MOVE L0113-PLAN-CRCY-CD        TO MIR-PLAN-CRCY-CD
020469      END-IF.
020469
020475      IF  L0113-PLAN-INCL-DBG-IND NOT =  HIGH-VALUES
020475          MOVE L0113-PLAN-INCL-DBG-IND TO MIR-PLAN-INCL-DBG-IND
020475      END-IF.
023435
023435      IF  L0113-OFFANNV-IND NOT = HIGH-VALUES
023435          MOVE L0113-OFFANNV-IND         TO MIR-PLAN-OFFANNV-IND
023435      END-IF.
028786
028786      IF  L0113-CPREM-CALC-RULE-CD NOT = HIGH-VALUES
028786          MOVE L0113-CPREM-CALC-RULE-CD  TO MIR-CPREM-CALC-RULE-CD
028786      END-IF.
028786
028786      IF  L0113-CPREM-MODE-CALC-CD NOT = HIGH-VALUES
028786          MOVE L0113-CPREM-MODE-CALC-CD  TO MIR-CPREM-MODE-CALC-CD
028786      END-IF.
029059
029059      IF  L0113-PLAN-GDLN-CVAT-CD NOT = HIGH-VALUES
029059          MOVE L0113-PLAN-GDLN-CVAT-CD   TO MIR-PLAN-GDLN-CVAT-CD
029059      END-IF.
029059
029059      IF  L0113-PLAN-CVAT-NSP-IND NOT = HIGH-VALUES
029059          MOVE L0113-PLAN-CVAT-NSP-IND   TO MIR-PLAN-CVAT-NSP-IND
029059      END-IF.

       8020-EDIT-RETURN-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0113-0000-INIT-PARM-INFO
025970         THRU 0113-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-OUTPUT-DISPLAYS.
025970
025970     SET WS-TRANS-PLAN             TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT       TO TRUE.
025970     SET WS-MAX-BROWSE-LNS-DEFAULT TO TRUE.
025970 
025970     MOVE ZERO                     TO WS-SUB.
025970     MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
025970
025970     MOVE SPACES                   TO WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
       COPY CCPS0113.
018764*COPY CCCL0113.
018764 COPY CCPL0113.
018764*COPY CCCLPH.
018764 COPY CCPLPH.
018764*COPY CCCLPD.
018764 COPY CCPLPD.
016537*COPY CCPEPLAN.
016537*COPY CCPNEDIT.
      /
021930*COPY XCPL0280.
021930*
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455/
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.
      /
014660*COPY XCPPMEXT.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPCPD.
      /
       COPY CCPAPD.
      /
       COPY CCPNPD.
      /
       COPY CCPUPD.
      /
      /
       COPY CCPCPH.
      /
       COPY CCPAPH.
      /
       COPY CCPBPH.
      /
       COPY CCPNPH.
      /
       COPY CCPUPH.
      /
       COPY CCPXPH.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0111                     **
      *****************************************************************
