      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5090.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5090                                         **
      **  REMARKS:  BHST - BANK DRAW HISTORY MAINTENANCE AND         **
      **            REVERSAL                                         **
      **            THIS PROCESS DRIVER ALLOWS THE USER TO INQUIRE,  **
      **            CREATE, MAINTAIN, AND DELETE BANK DRAW RECORDS.  **
      **            ALSO, THE BANK DRAW CAN BE REVERSED, THROUGH THE **
      **            PPAY REVERSAL FUNCTION DRIVER.                   **
      **                                                             **
      **  DOMAIN :  BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CHANGE TO STANDARD                               **
557708**  5.5       HANDLING OF CICS ABENDS                          **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZING FOR INTL SUPPORT             **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       PUT WORK DATES THRU THE DATE ROUTINE TO GET      **
005409**            VALID DATE PRIOR TO MOVING TO DB2 TABLES         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010397**  5.6       CHANGES DUE TO LOAN REPAYMENT PROCESSING         **
010418**  5.6       CHANGES DUE TO MULTI-COMPANY                     **
011614**  5.6       FIX GUI ABEND ON EMPTY PAC DRAW DATE             **
014035**  5.6V      CODE CLEANUP AND STANDARDIZATION                 **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
015694**  6.2       FIX SBSDRY CODE ON PRDW RECORD                   **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018258**  6.2       FIX PAC DRAW AMOUNT CALCULATION                  **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
028620**  6.7       CREDIT CARD AND PAC PREMIUM PAYMENT REVERSAL     **
026664**  6.7       PAC REVERSAL ON UNAPPLIED DRAW                   **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
038204**  7.1       PAC PAYMENT REVERSAL                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************


      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5090'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
       COPY XCWEBLCH.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-DETAILS-SCREEN-1     PIC S9(4)  BINARY.
025970         88  WS-MAX-DETAILS-SCREEN-1-DFLT       VALUE +100.
025970     05  WS-MAX-DETAILS-SCREEN-2     PIC S9(4)  BINARY.
025970         88  WS-MAX-DETAILS-SCREEN-2-DFLT       VALUE +100.
025970     05  WS-TWRK-KEY                 PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                VALUE '5090'.
025970     05  HOLD-RUN-ID                 PIC X(01).
025970         88  HOLD-RUN-ID-DEFAULT                VALUE '0'.

       01  WS-WORKING-STORAGE.
016548*    05  I                           PIC S9(4)  VALUE ZERO COMP.
016548     05  I                           PIC S9(4)  VALUE ZERO BINARY.
016548*    05  WS-MAX-DETAILS-SCREEN-1     PIC S9(4)  VALUE +100 COMP.
025970*    05  WS-MAX-DETAILS-SCREEN-1     PIC S9(4)  VALUE +100 BINARY.
016548*    05  WS-MAX-DETAILS-SCREEN-2     PIC S9(4)  VALUE +100 COMP.
025970*    05  WS-MAX-DETAILS-SCREEN-2     PIC S9(4)  VALUE +100 BINARY.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-ID-VALID                VALUES ARE
                   '5090' '5091' '5092' '5093' '5094' '5095' '5096'
                   '5100' '5102' '5103' '5104'.
               88  WS-BUS-FCN-RETRIEVE                VALUE '5090'.
               88  WS-BUS-FCN-CREATE                  VALUE '5091'.
               88  WS-BUS-FCN-UPDATE                  VALUE '5092'.
               88  WS-BUS-FCN-DELETE                  VALUE '5093'.
               88  WS-BUS-FCN-LIST                    VALUE '5094'.
               88  WS-BUS-FCN-ADDPOL                  VALUE '5095'.
               88  WS-BUS-FCN-REVERSE                 VALUE '5096'.

               88  WS-BUS-FCN-RETRIEVE-POL            VALUE '5100'.
               88  WS-BUS-FCN-UPDATE-POL              VALUE '5102'.
               88  WS-BUS-FCN-DELETE-POL              VALUE '5103'.
               88  WS-BUS-FCN-LIST-POL                VALUE '5104'.
025970*    05  WS-TWRK-KEY                 PIC X(04)  VALUE '5090'.
           05  WS-STATUS-CODE              PIC X(01)  VALUE SPACES.
               88  WS-STATUS-ERROR                    VALUE 'E'.
           05  WS-NUMERIC-ERROR-SW         PIC X(01)  VALUE SPACES.
               88  WS-NUMERIC-ERROR                   VALUE 'Y'.
           05  WS-TEST-REDRAW              PIC X(01).
               88  WS-REDRAW-VALID                    VALUE 'N' 'Y'.
           05  WS-TEST-SYSTEM-IND          PIC X(01).
               88  WS-SYSI-VALID                      VALUE 'S' 'M'.
           05  WS-TEST-REASON              PIC X(01).
               88  WS-REASON-VALID             VALUE 'N' 'C' 'S' 'D'.
008455*    05  DISPLAY-NUMBER-Z-9-2        PIC Z(8)9.99.
008455*    05  DISPLAY-NUMBER-S-6-2        PIC -9(6).99.
008455*    05  DISPLAY-NUMBER-S-7-2        PIC -9(7).99.
008455*    05  DISPLAY-NUMBER-Z-7-2        PIC Z(6)9.99.
008455*    05  DISPLAY-NUMBER-9-2          PIC 9(9).99.
008455*    05  DISPLAY-NUMBER-9            PIC 9(9).
008455*    05  DISPLAY-NUMBER-7-2          PIC 9(7).99.
008455*    05  DISPLAY-NUMBER-5-2          PIC 9(5).99.
           05  DISPLAY-NUMBER-3            PIC 999.
           05  WS-PIC-999                  PIC 999.
           05  WS-KEY-DRAW-DATE            PIC X(10).
           05  WS-INVERTED-DRAW-DATE       PIC 9(7).
           05  WS-DUE-DATE                 PIC X(10).
557973*    05  WS-AMOUNT-DRAWN             PIC S9(7)V99.
           05  WS-AMOUNT-DRAWN             PIC S9(11)V99.
016503     05  WS-PAC-DRW-DT               PIC X(10).
008455*    05  WS-TOTAL-BILLED             PIC S9(7)V99.
           05  WS-TOP-ATTR                 PIC X.
           05  WS-BOTTOM-ATTR              PIC X.
025970*    05  HOLD-RUN-ID                 PIC X      VALUE '0'.
           05  WS-MAINTAIN-RECORD          PIC X.
               88  WS-MAINTAIN-PDRW                   VALUE 'H'.
               88  WS-MAINTAIN-PDRD                   VALUE 'D'.
           05  WS-DELETE-RECORD            PIC X.
               88  WS-DELETE-PDRW                     VALUE 'H'.
               88  WS-DELETE-PDRD                     VALUE 'D'.
           05  WS-POL-ID.
               10  WS-POL-ID-BASE          PIC X(9).
               10  WS-POL-ID-SUFFIX        PIC X.
           05  WS-PDRW-ENDBR-SW            PIC X.
               88  WS-PDRW-ENDBR-NEEDED               VALUE 'Y'.
010418     05  WS-UPDATE-HDR-SW            PIC X.
010418         88  WS-UPDATE-HDR-YES                  VALUE 'Y'.
010418         88  WS-UPDATE-HDR-NO                   VALUE 'N'.
           05  WS-PDRD-MORE-DATA           PIC X.
               88  WS-PDRD-MORE-DATA-YES              VALUE 'Y'.
               88  WS-PDRD-MORE-DATA-NO               VALUE 'N'.
026664     05  WS-POL-PD-TO-DT             PIC X(10).
      /
557756*COPY CCWTYSNO.
014221 COPY CCWWLOCK.
      /
       COPY CCFHCVGS.
      /
016503 COPY CCWL0289.
020478 COPY CCWL2626.
      /
016108 COPY CCWL0985.
016108/
       COPY CCWL1651.
      /
       COPY CCWL5091.
      /
       COPY CCWL5400.
      /
014035*COPY XCWEBLCH.
      /
038204 COPY CCWL0183.
038204 COPY CCWL2625.
038204/
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
      /
       COPY XCWL1640.
      /
       COPY XCWL1660.
      /
005409 COPY XCWL1670.
      /
005409 COPY XCWL1680.
      /
013578*COPY XCWL2510.
      /
014221 COPY XCWL8090.
014221/
       COPY XCWLDTLK.
      /
       COPY XCWWWKDT.
      /
014221 COPY CCFWBNKA.
014221 COPY CCFRBNKA.
014221/
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWPDRD.
       COPY CCFRPDRD.
      /
       COPY CCFWPDRW.
       COPY CCFRPDRW.
      /
010418 COPY CCFWPDRS.
010418/
       COPY CCFHPOL.
       COPY CCFWPOL.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      /
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM5090.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.


      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

           MOVE SPACE                 TO WS-MAINTAIN-RECORD.
           MOVE SPACE                 TO WS-DELETE-RECORD.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.


      *
      *    CHECK SECURITY BASED UPON THE 'ENTER CODE'
      *
           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
016503     MOVE WWKDT-ZERO-DT              TO WS-PAC-DRW-DT.


           IF  WGLOB-MSG-ERROR-SW          > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.


013578*    IF  MIR-DV-PRCES-STATE-CD = '3'
013578*        PERFORM 2510-1000-BUILD-PARM-INFO
013578*            THRU 2510-1000-BUILD-PARM-INFO-X
013578*        MOVE MIR-DV-VERIF-TXT  TO L2510-RESPONSE-TXT
013578*        PERFORM 2510-1000-VALIDATE-RESPONSE
013578*            THRU 2510-1000-VALIDATE-RESPONSE-X
013578*    END-IF.

013578*    IF  MIR-DV-PRCES-STATE-CD = '3'
557756*ANDMIR-DV-VERIF-TXT NOT = TYSNO-YES-NO-LONG (WGLOB-VERIF-SUB, 1)
557756*ANDMIR-DV-VERIF-TXT NOT = TYSNO-YES-NO-LONG (WGLOB-VERIF-SUB, 2)
557756*    AND MIR-DV-VERIF-TXT NOT = ' SI'
557756*    AND MIR-DV-VERIF-TXT NOT = ' NO'
013578*    AND NOT L2510-RESPONSE-YES
013578*    AND NOT L2510-RESPONSE-NO
013578*        MOVE 'XS00000219'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-2000-GET-MESSAGE
013578*            THRU 0260-2000-GET-MESSAGE-X
013578*        MOVE WGLOB-MSG-TXT     TO MIR-VERIFY
013578*        MOVE 'XS00000221'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        GO TO 2000-PROCESS-REQUEST-X
013578*    END-IF.

013578*    IF  MIR-DV-PRCES-STATE-CD = '3'
557756*  AND (MIR-DV-VERIF-TXT = TYSNO-YES-NO-LONG (WGLOB-VERIF-SUB,2)
557756*    OR   MIR-DV-VERIF-TXT = ' NO')
013578*    AND L2510-RESPONSE-NO
013578*        GO TO 2000-PROCESS-REQUEST-X
013578*    END-IF.

           PERFORM  2100-VALIDATE-KEY-FIELDS
               THRU 2100-VALIDATE-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW          > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *
      *    PROCESS SCREEN FUNCTIONS
      *

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE-BANK
                        THRU 3000-PROCESS-RETRIEVE-BANK-X

               WHEN WS-BUS-FCN-RETRIEVE-POL
                    PERFORM  3500-PROCESS-RETRIEVE-POL
                        THRU 3500-PROCESS-RETRIEVE-POL-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-DELETE
               OR   WS-BUS-FCN-DELETE-POL
                    PERFORM  4500-PROCESS-DELETE
                        THRU 4500-PROCESS-DELETE-X

               WHEN WS-BUS-FCN-UPDATE
               OR   WS-BUS-FCN-UPDATE-POL
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  6000-PROCESS-LIST-BANK
                        THRU 6000-PROCESS-LIST-BANK-X

               WHEN WS-BUS-FCN-LIST-POL
                    PERFORM  6500-PROCESS-LIST-POLICY
                        THRU 6500-PROCESS-LIST-POLICY-X

               WHEN WS-BUS-FCN-REVERSE
                    PERFORM  7000-PROCESS-REVERSE
                        THRU 7000-PROCESS-REVERSE-X

               WHEN WS-BUS-FCN-ADDPOL
                    PERFORM  8000-PROCESS-ADD
                        THRU 8000-PROCESS-ADD-X

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------------
       2100-VALIDATE-KEY-FIELDS.
      *-------------------------

           IF  WS-BUS-FCN-CREATE
           OR  WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-PAC-DRWD-DUE-DT
               MOVE SPACES            TO MIR-POL-ID-BASE
               MOVE SPACES            TO MIR-POL-ID-SFX
           END-IF.

      *     IF  WS-BUS-FCN-UPDATE
      *         IF  MIR-POL-ID-BASE          NOT = SPACES
      *             MOVE 'D'           TO WS-MAINTAIN-RECORD
      *         ELSE
      *             MOVE 'H'           TO WS-MAINTAIN-RECORD
      *         END-IF
      *     END-IF.

      * UPDATE BANK HISTORY

           IF  WS-BUS-FCN-UPDATE
               MOVE 'H'           TO WS-MAINTAIN-RECORD
           END-IF.

      * UPDATE POLICY DETAILS

           IF  WS-BUS-FCN-UPDATE-POL
               IF  MIR-POL-ID-BASE          NOT = SPACES
                   MOVE 'D'           TO WS-MAINTAIN-RECORD
               END-IF
           END-IF.

      *     IF  WS-BUS-FCN-DELETE
      *         IF  MIR-POL-ID-BASE          NOT = SPACES
      *             MOVE 'D'           TO WS-DELETE-RECORD
      *         ELSE
      *             MOVE 'H'           TO WS-DELETE-RECORD
      *         END-IF
      *     END-IF.

      * DELETE BANK HISTORY

           IF  WS-BUS-FCN-DELETE
               MOVE 'H'           TO WS-DELETE-RECORD
           END-IF.

      * DELETE POLICY DETAILS

           IF  WS-BUS-FCN-DELETE-POL
               IF  MIR-POL-ID-BASE          NOT = SPACES
                   MOVE 'D'           TO WS-DELETE-RECORD
               END-IF
           END-IF.
020467
020467     IF  WS-BUS-FCN-CREATE
020467     OR  WS-BUS-FCN-ADDPOL
020467         MOVE '1' TO MIR-PAC-DRW-COLCT-CD
020467     END-IF.

      *
      *    IF THE DATE IS ENTERED IT MUST BE VALID.
      *    FOR CREATE, IT MUST ALWAYS BE ENTERED.
      *
           IF  WS-BUS-FCN-CREATE
           OR  WS-BUS-FCN-ADDPOL
           OR  MIR-PAC-DRW-IDT-NUM NOT               = SPACES
               MOVE MIR-PAC-DRW-IDT-NUM
                                      TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
      * MSG - DATE (@1) INVALID
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-PAC-DRW-IDT-NUM
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
016503             MOVE L1640-INTERNAL-DATE
016503                                TO WS-PAC-DRW-DT
                   PERFORM  1660-2000-CONVERT-INT-TO-INV
                       THRU 1660-2000-CONVERT-INT-TO-INV-X
                   MOVE L1660-INVERTED-DATE
                                      TO WS-INVERTED-DRAW-DATE
               END-IF
           END-IF.

      *
      * ALL KEY FIELDS MUST BE ENTERED
      *

           IF  WS-BUS-FCN-CREATE
           OR  WS-BUS-FCN-ADDPOL
               IF  MIR-BNK-ID                = SPACES
               OR  MIR-BNK-BR-ID              = SPACES
               OR  MIR-BNK-ACCT-ID                = SPACES
      * MSG - PAC DRAW KEY FIELDS INCOMPLETE - PLEASE RE-ENTER
                   MOVE 'CS50900002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.


           IF  WS-BUS-FCN-RETRIEVE
           OR  WS-BUS-FCN-RETRIEVE-POL
           OR  WS-BUS-FCN-UPDATE
           OR  WS-BUS-FCN-UPDATE-POL
           OR  WS-BUS-FCN-DELETE
           OR  WS-BUS-FCN-DELETE-POL
               IF  MIR-PAC-DRW-SEQ-NUM IS NOT NUMERIC
      * MSG:  RECORD NOT FOUND
                   MOVE 'CS00000026'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2100-VALIDATE-KEY-FIELDS-X
               END-IF
           END-IF.

           IF  WS-BUS-FCN-CREATE
           OR  WS-BUS-FCN-LIST
           OR  WS-BUS-FCN-LIST-POL
           OR  MIR-PAC-DRW-SEQ-NUM IS NUMERIC
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      * MSG - SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'CS50900001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  MIR-PAC-DRWD-DUE-DT              NOT = SPACES
               MOVE MIR-PAC-DRWD-DUE-DT
                                      TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
           END-IF.

           IF  MIR-PAC-DRWD-DUE-DT              NOT = SPACES
           AND L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-DUE-DATE
           ELSE
               IF  WS-BUS-FCN-ADDPOL
               OR  WS-MAINTAIN-PDRD
               OR  WS-DELETE-PDRD
               OR (WS-BUS-FCN-RETRIEVE
               AND MIR-POL-ID-BASE NOT = SPACES)
               OR (WS-BUS-FCN-RETRIEVE-POL
               AND MIR-POL-ID-BASE NOT = SPACES)
      * MSG - DATE (@1) INVALID
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-PAC-DRWD-DUE-DT
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

            IF  (WS-BUS-FCN-ADDPOL
            AND MIR-PAC-DRWD-DUE-DT             NOT = SPACES
010418      AND MIR-PAC-DRW-SEQ-NUM IS NUMERIC)
            OR  WS-MAINTAIN-PDRD
            OR  WS-DELETE-PDRD
                PERFORM  2150-CHECK-PDRW-STATUS
                    THRU 2150-CHECK-PDRW-STATUS-X
                IF  WGLOB-MSG-ERROR-SW     > ZERO
                    GO TO 2100-VALIDATE-KEY-FIELDS-X
                END-IF
            END-IF.

            IF  WS-BUS-FCN-ADDPOL
            OR  WS-MAINTAIN-PDRD
            OR  WS-DELETE-PDRD
                PERFORM  2200-VALIDATE-KEY-PDRD
                    THRU 2200-VALIDATE-KEY-PDRD-X
                IF  WGLOB-MSG-ERROR-SW     > ZERO
                    GO TO 2100-VALIDATE-KEY-FIELDS-X
                END-IF
            END-IF.

            IF  WS-MAINTAIN-PDRW
            OR  WS-MAINTAIN-PDRD
            OR  WS-DELETE-PDRW
            OR  WS-DELETE-PDRD

               PERFORM 2300-CHECK-KEY-SECOND-PASS
                  THRU 2300-CHECK-KEY-SECOND-PASS-X
            END-IF.

016108      IF  WS-BUS-FCN-ADDPOL
016108      OR  WS-BUS-FCN-UPDATE-POL
016108      OR  WS-BUS-FCN-DELETE-POL
016108          PERFORM  2350-VAL-DATE-OF-DTH
016108              THRU 2350-VAL-DATE-OF-DTH-X
016108          IF  WGLOB-MSG-ERROR-SW     > ZERO
016108              GO TO 2100-VALIDATE-KEY-FIELDS-X
016108          END-IF
016108      END-IF.


       2100-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      *-----------------------
       2150-CHECK-PDRW-STATUS.
      *-----------------------

      *
      * IF THE PDRW STATUS IS REVERSED, THERE CAN BE NO CHANGE TO
      * POLICY DETAILS.
      *
           PERFORM  8900-SETUP-AND-READ-PDRW
               THRU 8900-SETUP-AND-READ-PDRW-X.

           IF  RPDRW-PAC-DRW-STAT-REVERSED
      * MSG: PAC DRAW IS REVERSED - CANNOT CHANGE DETAILS
               MOVE 'CS50900022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2150-CHECK-PDRW-STATUS-X.
           EXIT.
      /
      *-----------------------
       2200-VALIDATE-KEY-PDRD.
      *-----------------------

           IF  MIR-POL-ID-BASE                  = SPACES
      * MSG - POLICY MUST BE ENTERED
               MOVE 'CS50900005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  MIR-POL-ID-BASE              NOT = SPACES
010418     AND MIR-PAC-DRW-SEQ-NUM IS NUMERIC
           AND WS-BUS-FCN-ADDPOL
               MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE
               MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX
               PERFORM  POL-1000-READ
                   THRU POL-1000-READ-X
               IF  NOT WPOL-IO-OK
      * MSG - POLICY NOT IN FILE
                   MOVE 'CS00000019'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
010418         ELSE
010418             PERFORM  2250-DETERMINE-SUBCO
010418                 THRU 2250-DETERMINE-SUBCO-X
               END-IF
           END-IF.

           IF  MIR-PAC-DRWD-DUE-DT                  = SPACES
               MOVE 'CS50900020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2200-VALIDATE-KEY-PDRD-X.
           EXIT.
010418/
010418*---------------------
010418 2250-DETERMINE-SUBCO.
010418*---------------------
010418
010418     PERFORM  8900-SETUP-AND-READ-PDRW
010418         THRU 8900-SETUP-AND-READ-PDRW-X.
010418
010418     IF  NOT WPDRW-IO-OK
010418* MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
010418         MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 2250-DETERMINE-SUBCO-X
010418     END-IF.
010418
010418     PERFORM  5180-START-PDRD-BROWSE
010418         THRU 5180-START-PDRD-BROWSE-X.
010418
010418     IF  WPDRD-IO-EOF
010418         SET WS-UPDATE-HDR-YES     TO TRUE
010418         MOVE RPOL-SBSDRY-CO-ID TO RPDRW-SBSDRY-CO-ID
010418         PERFORM  PDRD-3000-END-BROWSE
010418             THRU PDRD-3000-END-BROWSE-X
010418         GO TO 2250-DETERMINE-SUBCO-X
010418     END-IF.
010418
010418     SET WS-UPDATE-HDR-NO          TO TRUE.

010418     IF  RPOL-SBSDRY-CO-ID NOT = RPDRW-SBSDRY-CO-ID
010418* MSG - POLICY SUB CO NOT THE SAME AS PAC DRAW SUB CO - ADD
010418* NOT ALLOWED
010418         MOVE 'CS50900028'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418     END-IF.
010418
010418     PERFORM  PDRD-3000-END-BROWSE
010418         THRU PDRD-3000-END-BROWSE-X.
010418
010418 2250-DETERMINE-SUBCO-X.
010418     EXIT.
      /
      *---------------------------
       2300-CHECK-KEY-SECOND-PASS.
      *---------------------------

           IF  WS-MAINTAIN-PDRW
           OR  WS-DELETE-PDRW
010418     OR  WS-DELETE-PDRD
               PERFORM  5260-READ-PDRW-FOR-UPDATE
                   THRU 5260-READ-PDRW-FOR-UPDATE-X
           ELSE
               PERFORM  8900-SETUP-AND-READ-PDRW
                   THRU 8900-SETUP-AND-READ-PDRW-X
           END-IF.

           IF  NOT WPDRW-IO-OK
      * MSG: RECORD LOST IN MAINTAIN
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WPDRW-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2300-CHECK-KEY-SECOND-PASS-X
           END-IF.

           IF  WS-MAINTAIN-PDRW
           OR  WS-DELETE-PDRW
               GO TO 2300-CHECK-KEY-SECOND-PASS-X
           END-IF.

           MOVE WPDRW-BNK-ID          TO WPDRD-BNK-ID.
           MOVE WPDRW-BNK-BR-ID       TO WPDRD-BNK-BR-ID.
           MOVE WPDRW-BNK-ACCT-ID     TO WPDRD-BNK-ACCT-ID.
           MOVE WPDRW-PAC-DRW-IDT-NUM TO WPDRD-PAC-DRW-IDT-NUM.
           MOVE WPDRW-PAC-DRW-SEQ-NUM TO WPDRD-PAC-DRW-SEQ-NUM.
           MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SUFFIX.
           MOVE WS-POL-ID             TO WPDRD-POL-ID.
005409*    MOVE WS-DUE-DATE                TO WPDRD-PAC-DRWD-DUE-DT.
005409     MOVE WS-DUE-DATE           TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WPDRD-PAC-DRWD-DUE-DT.

           PERFORM  PDRD-1000-READ-FOR-UPDATE
               THRU PDRD-1000-READ-FOR-UPDATE-X.

           IF  NOT WPDRD-IO-OK
      * MSG:  RECORD LOST IN MAINTAIN
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WPDRD-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2300-CHECK-KEY-SECOND-PASS-X
           END-IF.

       2300-CHECK-KEY-SECOND-PASS-X.
           EXIT.
      /
016108*---------------------
016108 2350-VAL-DATE-OF-DTH.
016108*---------------------
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     IF  MIR-POL-ID-BASE        NOT = SPACES
016108         MOVE MIR-POL-ID-BASE    TO WPOL-POL-ID-BASE
016108         MOVE MIR-POL-ID-SFX     TO WPOL-POL-ID-SFX
016108         PERFORM  POL-1000-READ
016108             THRU POL-1000-READ-X
016108         IF  NOT WPOL-IO-OK
016108* MSG - POLICY NOT IN FILE
016108             MOVE 'CS00000019'   TO WGLOB-MSG-REF-INFO
016108             PERFORM  0260-1000-GENERATE-MESSAGE
016108                 THRU 0260-1000-GENERATE-MESSAGE-X
016108             GO TO 2350-VAL-DATE-OF-DTH-X
016108         END-IF
016108     ELSE
016108* MSG - POLICY MUST BE ENTERED
016108         MOVE 'CS50900005'       TO WGLOB-MSG-REF-INFO
016108         PERFORM  0260-1000-GENERATE-MESSAGE
016108             THRU 0260-1000-GENERATE-MESSAGE-X
016108         GO TO 2350-VAL-DATE-OF-DTH-X
016108     END-IF.
016108
016108     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016108         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
016108
016108     IF  MIR-PAC-DRW-IDT-NUM NOT = SPACES
016108         MOVE MIR-PAC-DRW-IDT-NUM
016108                                 TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
016108         IF  L1640-NOT-VALID
016108* MSG - DATE (@1) INVALID
016108             MOVE 'XS00000036'   TO WGLOB-MSG-REF-INFO
016108             MOVE MIR-PAC-DRW-IDT-NUM
016108                                 TO WGLOB-MSG-PARM (1)
016108             PERFORM  0260-1000-GENERATE-MESSAGE
016108                 THRU 0260-1000-GENERATE-MESSAGE-X
016108             GO TO 2350-VAL-DATE-OF-DTH-X
016108         ELSE
016108             MOVE L1640-INTERNAL-DATE
016108                                 TO WS-KEY-DRAW-DATE
016108         END-IF
016108     ELSE
016108         MOVE WGLOB-PROCESS-DATE TO WS-KEY-DRAW-DATE
016108     END-IF.
016108
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WS-KEY-DRAW-DATE       TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE 1                  TO WGLOB-MSG-ERROR-SW
016108     END-IF.
016108
016108 2350-VAL-DATE-OF-DTH-X.
016108     EXIT.
016108/
      *---------------------------
       3000-PROCESS-RETRIEVE-BANK.
      *---------------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

014221     MOVE MIR-BNK-ID            TO WBNKA-BNK-ID.
014221     MOVE MIR-BNK-BR-ID         TO WBNKA-BNK-BR-ID.
014221     MOVE MIR-BNK-ACCT-ID       TO WBNKA-BNK-ACCT-ID.
014221     PERFORM BNKA-1000-READ-TWRK-TS
014221        THRU BNKA-1000-READ-TWRK-TS-X
014221     IF  WBNKA-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (1)
014221        MOVE 'BNKA'             TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3000-PROCESS-RETRIEVE-BANK-X
014221     END-IF.

           PERFORM  8900-SETUP-AND-READ-PDRW
               THRU 8900-SETUP-AND-READ-PDRW-X.

           IF  NOT WPDRW-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-BANK-X
           END-IF.

           PERFORM  9200-MOVE-PDRW-TO-SCREEN
               THRU 9200-MOVE-PDRW-TO-SCREEN-X.

           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-BANK-X.
           EXIT.
      /
      *--------------------------
       3500-PROCESS-RETRIEVE-POL.
      *--------------------------


           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

014221     MOVE MIR-BNK-ID            TO WBNKA-BNK-ID.
014221     MOVE MIR-BNK-BR-ID         TO WBNKA-BNK-BR-ID.
014221     MOVE MIR-BNK-ACCT-ID       TO WBNKA-BNK-ACCT-ID.
014221     PERFORM BNKA-1000-READ-TWRK-TS
014221        THRU BNKA-1000-READ-TWRK-TS-X
014221     IF  WBNKA-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (1)
014221        MOVE 'BNKA'             TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3500-PROCESS-RETRIEVE-POL-X
014221     END-IF.

           PERFORM  8900-SETUP-AND-READ-PDRW
               THRU 8900-SETUP-AND-READ-PDRW-X.

           IF  NOT WPDRW-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-RETRIEVE-POL-X
           END-IF.

           PERFORM  9200-MOVE-PDRW-TO-SCREEN
               THRU 9200-MOVE-PDRW-TO-SCREEN-X.

           MOVE RPDRW-KEY             TO WPDRD-KEY.

           MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE
           MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SUFFIX
           MOVE WS-POL-ID             TO WPDRD-POL-ID

           IF  MIR-PAC-DRWD-DUE-DT  =  SPACES
               MOVE WWKDT-LOW-DT      TO WPDRD-PAC-DRWD-DUE-DT
           ELSE
               MOVE WS-DUE-DATE       TO L1680-INTERNAL-1
               MOVE ZERO              TO L1680-NUMBER-OF-YEARS
               MOVE ZERO              TO L1680-NUMBER-OF-MONTHS
               MOVE ZERO              TO L1680-NUMBER-OF-DAYS
               PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
                   THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
               MOVE L1680-INTERNAL-2  TO WPDRD-PAC-DRWD-DUE-DT
           END-IF.

           PERFORM  PDRD-1000-READ
               THRU PDRD-1000-READ-X.

           IF  NOT WPDRD-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-RETRIEVE-POL-X
           END-IF.

           MOVE 1                     TO I.
           PERFORM  9220-DETAIL-LINE-SCREEN-2
               THRU 9220-DETAIL-LINE-SCREEN-2-X.

           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3500-PROCESS-RETRIEVE-POL-X.
           EXIT.

      *--------------------
       4000-PROCESS-CREATE.
      *--------------------

           MOVE MIR-BNK-ID            TO WPDRW-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WPDRW-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID       TO WPDRW-BNK-ACCT-ID.
           MOVE MIR-PAC-DRW-IDT-NUM   TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           MOVE L1640-INTERNAL-DATE   TO L1660-INTERNAL-DATE.
016503     MOVE L1640-INTERNAL-DATE   TO WS-PAC-DRW-DT.

           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE   TO WPDRW-PAC-DRW-IDT-NUM.
           MOVE ZEROES                TO WPDRW-PAC-DRW-SEQ-NUM.
           MOVE WPDRW-KEY             TO WPDRW-ENDBR-KEY.
           MOVE 999                   TO WPDRW-ENDBR-PAC-DRW-SEQ-NUM.

           PERFORM  PDRW-1000-BROWSE
               THRU PDRW-1000-BROWSE-X.

           IF  WPDRW-IO-OK
               PERFORM  PDRW-2000-READ-NEXT
                   THRU PDRW-2000-READ-NEXT-X
               IF  WPDRW-IO-EOF
                   MOVE 'Y'           TO WS-PDRW-ENDBR-SW
               END-IF
           END-IF.

           IF  WPDRW-IO-OK
               SUBTRACT 1 FROM RPDRW-PAC-DRW-SEQ-NUM GIVING WS-PIC-999
               PERFORM  PDRW-3000-END-BROWSE
                   THRU PDRW-3000-END-BROWSE-X
           ELSE
               IF  WS-PDRW-ENDBR-NEEDED
                   MOVE 999           TO WS-PIC-999
                   PERFORM  PDRW-3000-END-BROWSE
                       THRU PDRW-3000-END-BROWSE-X
               ELSE
                   MOVE 999           TO WS-PIC-999
               END-IF
           END-IF.

           MOVE WS-PIC-999            TO WPDRW-PAC-DRW-SEQ-NUM.

020874*    COMPUTE WS-PIC-999
020874*          = 1000
020874*          - WPDRW-PAC-DRW-SEQ-NUM.
020874*    MOVE WS-PIC-999            TO MIR-PAC-DRW-SEQ-NUM.
020874     COMPUTE L0290-INPUT-V00
020874           = 1000
020874           - WPDRW-PAC-DRW-SEQ-NUM.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-PAC-DRW-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRW-SEQ-NUM.

           PERFORM  PDRW-1000-CREATE
               THRU PDRW-1000-CREATE-X.

           MOVE 'M'                   TO RPDRW-PAC-DRW-CREAT-CD.
           MOVE 'E'                   TO RPDRW-PAC-DRW-STAT-CD.
010418     MOVE SPACES                TO RPDRW-SBSDRY-CO-ID.
020467     MOVE MIR-PAC-DRW-COLCT-CD  TO RPDRW-PAC-DRW-COLCT-CD.
           MOVE L1660-INTERNAL-DATE   TO RPDRW-PAC-DRW-DT.

           PERFORM  PDRW-1000-WRITE
               THRU PDRW-1000-WRITE-X.

014221     MOVE MIR-BNK-ID            TO WBNKA-BNK-ID.
014221     MOVE MIR-BNK-BR-ID         TO WBNKA-BNK-BR-ID.
014221     MOVE MIR-BNK-ACCT-ID       TO WBNKA-BNK-ACCT-ID.
014221     PERFORM BNKA-1000-READ-TWRK-TS
014221        THRU BNKA-1000-READ-TWRK-TS-X
014221     IF  WBNKA-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (1)
014221        MOVE 'BNKA'             TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 4000-PROCESS-CREATE-X
014221     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  9200-MOVE-PDRW-TO-SCREEN
               THRU 9200-MOVE-PDRW-TO-SCREEN-X.

           MOVE 'H'                   TO WS-MAINTAIN-RECORD.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *--------------------
       4500-PROCESS-DELETE.
      *--------------------

014221     MOVE MIR-BNK-ID            TO WBNKA-BNK-ID.
014221     MOVE MIR-BNK-BR-ID         TO WBNKA-BNK-BR-ID.
014221     MOVE MIR-BNK-ACCT-ID       TO WBNKA-BNK-ACCT-ID.
014221     PERFORM BNKA-2000-UPDATE-TWRK-TS
014221        THRU BNKA-2000-UPDATE-TWRK-TS-X.

014221     IF  WBNKA-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (1)
014221         MOVE 'BNKA'             TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4500-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'BNKA'             TO WGLOB-MSG-PARM (01)
014221         MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4500-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  8900-SETUP-AND-READ-PDRW
               THRU 8900-SETUP-AND-READ-PDRW-X.

           IF  NOT WPDRW-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
               GO TO 4500-PROCESS-DELETE-X
           END-IF.

           IF  WS-DELETE-PDRW
               MOVE ZERO                   TO I
               PERFORM  5160-LOAD-ALL-PDRD
                   THRU 5160-LOAD-ALL-PDRD-X
           ELSE
               PERFORM  5150-LOAD-SINGLE-PDRD
                   THRU 5150-LOAD-SINGLE-PDRD-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW          > ZERO
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
               GO TO 4500-PROCESS-DELETE-X
           END-IF.

           IF  WS-DELETE-PDRW
               PERFORM  4560-DELETE-PDRW-EDITS
                   THRU 4560-DELETE-PDRW-EDITS-X
           ELSE
               PERFORM  4570-DELETE-PDRD-EDITS
                   THRU 4570-DELETE-PDRD-EDITS-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW          > ZERO
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
               GO TO 4500-PROCESS-DELETE-X
           END-IF.



           IF  WS-DELETE-PDRW
               PERFORM  PDRW-1000-DELETE
                   THRU PDRW-1000-DELETE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               PERFORM  PDRD-1000-DELETE
                   THRU PDRD-1000-DELETE-X
           END-IF.

           IF  WS-DELETE-PDRD
010418         PERFORM  5180-START-PDRD-BROWSE
010418             THRU 5180-START-PDRD-BROWSE-X
010418
010418         IF  WPDRD-IO-EOF
010418             MOVE SPACES        TO RPDRW-SBSDRY-CO-ID
010418             PERFORM  PDRW-2000-REWRITE
010418                 THRU PDRW-2000-REWRITE-X
010418         ELSE
010418             PERFORM  PDRW-3000-UNLOCK
010418                 THRU PDRW-3000-UNLOCK-X
010418         END-IF
010418
010418         PERFORM  PDRD-3000-END-BROWSE
010418             THRU PDRD-3000-END-BROWSE-X
010418
               PERFORM  5091-1000-BUILD-PARM-INFO
                   THRU 5091-1000-BUILD-PARM-INFO-X
               MOVE RPDRW-KEY         TO L5091-PDRW-KEY
               PERFORM  5091-1000-RECONCILE-PDRW
                   THRU 5091-1000-RECONCILE-PDRW-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               PERFORM  9200-MOVE-PDRW-TO-SCREEN
                   THRU 9200-MOVE-PDRW-TO-SCREEN-X
           END-IF.

014221     PERFORM  BNKA-2000-REWRITE
014221         THRU BNKA-2000-REWRITE-X.
014221     PERFORM  BNKA-1000-READ-TWRK-TS
014221         THRU BNKA-1000-READ-TWRK-TS-X.

           MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4500-PROCESS-DELETE-X.
           EXIT.
      /
      *-----------------------
       4560-DELETE-PDRW-EDITS.
      *-----------------------

      *
      * CANNOT DELETE PDRW IF ATTACHED PDRD RECORDS EXIST
      * CANNOT DELETE SYSTEM GENERATED PDRW RECORDS
      *
           IF  RPDRW-PAC-DRW-CREAT-SYSTEM
      * MSG: DELETE NOT ALLOWED. PAC DRAW SYSTEM CREATED
               MOVE 'CS50900008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4560-DELETE-PDRW-EDITS-X
           END-IF.

           IF  RPDRW-PAC-DRW-STAT-REVERSED
      ***** MSG: DELETE NOT ALLOWED. PAC DRAW STATUS IS REVERSED
               MOVE 'CS50900009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4560-DELETE-PDRW-EDITS-X
           END-IF.

           IF  I                           > ZERO
      ***** MSG: DELETE NOT ALLOWED.  POLICY DETAILS FOUND
               MOVE 'CS50900010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       4560-DELETE-PDRW-EDITS-X.
           EXIT.
      /
      *-----------------------
       4570-DELETE-PDRD-EDITS.
      *-----------------------

           IF  NOT RPDRD-PAC-DRWD-STAT-MANUAL
               MOVE 'CS50900011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4570-DELETE-PDRD-EDITS-X.
           EXIT.
      /
      *----------------------
       5000-PROCESS-UPDATE.
      *----------------------

014221     MOVE MIR-BNK-ID            TO WBNKA-BNK-ID.
014221     MOVE MIR-BNK-BR-ID         TO WBNKA-BNK-BR-ID.
014221     MOVE MIR-BNK-ACCT-ID       TO WBNKA-BNK-ACCT-ID.
014221     PERFORM BNKA-2000-UPDATE-TWRK-TS
014221        THRU BNKA-2000-UPDATE-TWRK-TS-X.

014221     IF  WBNKA-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (1)
014221         MOVE 'BNKA'             TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'BNKA'             TO WGLOB-MSG-PARM (01)
014221         MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF  WS-MAINTAIN-PDRW
           AND RPDRW-PAC-DRW-CREAT-SYSTEM
           AND RPDRW-PAC-DRW-STAT-ERROR
      * MSG: CANNOT MAINTAIN SYSTEM GENERATED PAC DRAW - ERROR STATUS
               MOVE 'CS50900023'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PDRW-3000-UNLOCK
                   THRU PDRW-3000-UNLOCK-X
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           IF  RPDRW-PAC-DRW-STAT-ACTIVE
           AND RPDRW-PAC-DRW-CREAT-SYSTEM
           AND RPDRW-PAC-DRW-TOT-AMT       = ZERO
      * MSG: CANNOT MAINTAIN SYSTEM GENERATED PRENOTE RECORD
               MOVE 'CS50900024'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WS-MAINTAIN-PDRW
                  PERFORM  PDRW-3000-UNLOCK
                     THRU  PDRW-3000-UNLOCK-X
               ELSE
                  PERFORM  PDRD-3000-UNLOCK
                     THRU  PDRD-3000-UNLOCK-X
               END-IF
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           IF  WS-MAINTAIN-PDRW
               PERFORM  5220-MAINTAIN-PDRW
                   THRU 5220-MAINTAIN-PDRW-X
           END-IF.

           IF  WS-MAINTAIN-PDRD
               PERFORM  5240-MAINTAIN-PDRD
                   THRU 5240-MAINTAIN-PDRD-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW          = ZERO
020467         AND NOT RPDRW-PAC-DRW-COLCT-DD2
               PERFORM  5091-1000-BUILD-PARM-INFO
                   THRU 5091-1000-BUILD-PARM-INFO-X
               MOVE RPDRW-KEY         TO L5091-PDRW-KEY
               PERFORM  5091-1000-RECONCILE-PDRW
                   THRU 5091-1000-RECONCILE-PDRW-X
               PERFORM  8900-SETUP-AND-READ-PDRW
                   THRU 8900-SETUP-AND-READ-PDRW-X
               PERFORM  5160-LOAD-ALL-PDRD
                   THRU 5160-LOAD-ALL-PDRD-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW          > ZERO
               MOVE 'XS00000039'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  9200-MOVE-PDRW-TO-SCREEN
                   THRU 9200-MOVE-PDRW-TO-SCREEN-X
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *----------------------
       5150-LOAD-SINGLE-PDRD.
      *----------------------

           MOVE WPDRW-BNK-ID          TO WPDRD-BNK-ID.
           MOVE WPDRW-BNK-BR-ID       TO WPDRD-BNK-BR-ID.
           MOVE WPDRW-BNK-ACCT-ID     TO WPDRD-BNK-ACCT-ID.
           MOVE WPDRW-PAC-DRW-IDT-NUM TO WPDRD-PAC-DRW-IDT-NUM.
           MOVE WPDRW-PAC-DRW-SEQ-NUM TO WPDRD-PAC-DRW-SEQ-NUM.
           MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SUFFIX.
           MOVE WS-POL-ID             TO WPDRD-POL-ID.
005409*    MOVE WS-DUE-DATE                TO WPDRD-PAC-DRWD-DUE-DT.
005409     MOVE WS-DUE-DATE           TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WPDRD-PAC-DRWD-DUE-DT.

           PERFORM  PDRD-1000-READ
               THRU PDRD-1000-READ-X.

           IF  NOT WPDRD-IO-OK
      * MSG:  RECORD NOT FOUND
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               MOVE WPDRD-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5150-LOAD-SINGLE-PDRD-X
           END-IF.

           MOVE 1                     TO I.

           PERFORM  9220-DETAIL-LINE-SCREEN-2
               THRU 9220-DETAIL-LINE-SCREEN-2-X.

       5150-LOAD-SINGLE-PDRD-X.
           EXIT.
      /
      *-------------------
       5160-LOAD-ALL-PDRD.
      *-------------------

           PERFORM  5180-START-PDRD-BROWSE
               THRU 5180-START-PDRD-BROWSE-X.

           IF  WPDRD-IO-EOF
               PERFORM  PDRD-3000-END-BROWSE
                   THRU PDRD-3000-END-BROWSE-X
               SET WS-PDRD-MORE-DATA-NO  TO TRUE
               GO TO 5160-LOAD-ALL-PDRD-X
           END-IF.

           PERFORM  5170-DISPLAY-ENTIRE-SCREEN-2
               THRU 5170-DISPLAY-ENTIRE-SCREEN-2-X
               VARYING I FROM +1 BY +1
               UNTIL   I > WS-MAX-DETAILS-SCREEN-2
               OR      WPDRD-IO-EOF.

           IF WPDRD-IO-EOF
              SET WS-PDRD-MORE-DATA-NO TO TRUE
           ELSE
              SET WS-PDRD-MORE-DATA-YES TO TRUE
           END-IF.

           IF  WS-BUS-FCN-RETRIEVE
           OR  WS-BUS-FCN-RETRIEVE-POL
           OR  WS-BUS-FCN-LIST-POL
               IF  WPDRD-IO-EOF
                   MOVE MIR-POL-ID-SFX-T (1)
                                      TO WS-POL-ID-SUFFIX
                   MOVE MIR-POL-ID-BASE-T (1)
                                      TO WS-POL-ID-BASE
                   MOVE WS-POL-ID-BASE      TO MIR-POL-ID-BASE
                   MOVE WS-POL-ID-SUFFIX
                                      TO MIR-POL-ID-SFX
                   MOVE MIR-PAC-DRWD-DUE-DT-T (1)
                                      TO MIR-PAC-DRWD-DUE-DT
               ELSE
                   MOVE RPDRD-POL-ID-BASE
                                      TO MIR-POL-ID-BASE
                   MOVE RPDRD-POL-ID-SFX
                                      TO MIR-POL-ID-SFX
                   MOVE RPDRD-PAC-DRWD-DUE-DT
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM  1640-8000-INTERNAL-TO-MIR
020462                 THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PAC-DRWD-DUE-DT
               END-IF
           END-IF.

           PERFORM  PDRD-3000-END-BROWSE
               THRU PDRD-3000-END-BROWSE-X.

       5160-LOAD-ALL-PDRD-X.
           EXIT.
      /
      *-----------------------------
       5170-DISPLAY-ENTIRE-SCREEN-2.
      *-----------------------------

           PERFORM  9220-DETAIL-LINE-SCREEN-2
               THRU 9220-DETAIL-LINE-SCREEN-2-X.

           PERFORM  PDRD-2000-READ-NEXT
               THRU PDRD-2000-READ-NEXT-X.

       5170-DISPLAY-ENTIRE-SCREEN-2-X.
           EXIT.
      /
      *-----------------------
       5180-START-PDRD-BROWSE.
      *-----------------------

           MOVE RPDRW-KEY             TO WPDRD-KEY.

           IF  MIR-POL-ID-BASE                  = SPACES
010418     OR  WS-BUS-FCN-ADDPOL
010418     OR  WS-BUS-FCN-DELETE
015694     OR  WS-BUS-FCN-DELETE-POL
           OR  WS-BUS-FCN-REVERSE
               MOVE LOW-VALUES        TO WPDRD-POL-ID
           ELSE
               MOVE MIR-POL-ID-BASE        TO WS-POL-ID-BASE
               MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SUFFIX
               MOVE WS-POL-ID         TO WPDRD-POL-ID
           END-IF.

           IF  MIR-PAC-DRWD-DUE-DT                  = SPACES
010418     OR  WS-BUS-FCN-ADDPOL
010418     OR  WS-BUS-FCN-DELETE
015694     OR  WS-BUS-FCN-DELETE-POL
           OR  WS-BUS-FCN-REVERSE
               MOVE WWKDT-LOW-DT      TO WPDRD-PAC-DRWD-DUE-DT
           ELSE
005409*        MOVE WS-DUE-DATE            TO WPDRD-PAC-DRWD-DUE-DT
005409         MOVE WS-DUE-DATE       TO L1680-INTERNAL-1
005409         MOVE ZERO              TO L1680-NUMBER-OF-YEARS
005409         MOVE ZERO              TO L1680-NUMBER-OF-MONTHS
005409         MOVE ZERO              TO L1680-NUMBER-OF-DAYS
005409         PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409             THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
005409         MOVE L1680-INTERNAL-2  TO WPDRD-PAC-DRWD-DUE-DT
           END-IF.

           MOVE WPDRD-KEY             TO WPDRD-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPDRD-ENDBR-POL-ID.
           MOVE WWKDT-HIGH-DT         TO WPDRD-ENDBR-PAC-DRWD-DUE-DT.

           PERFORM  PDRD-1000-BROWSE
               THRU PDRD-1000-BROWSE-X.

           IF  WPDRD-IO-OK
               PERFORM  PDRD-2000-READ-NEXT
                   THRU PDRD-2000-READ-NEXT-X
           END-IF.

       5180-START-PDRD-BROWSE-X.
           EXIT.
      /
      *-------------------
       5220-MAINTAIN-PDRW.
      *-------------------
      *BTOT2
020467     IF MIR-CTRY-CD NOT = SPACES
020467        MOVE MIR-CTRY-CD           TO RPDRW-CTRY-CD
020467     END-IF.
020467
020467     IF MIR-PAC-DRW-COLCT-CD = '2'
020467         PERFORM  5230-MAINTAIN-PDRW-DD2
020467             THRU 5230-MAINTAIN-PDRW-DD2-X
020467         GO TO 5220-MAINTAIN-PDRW-X
020467     END-IF.
020467
           IF  MIR-PAC-DRW-TOT-AMT               NOT = SPACES
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
008455*        MOVE 9                      TO L0280-LENGTH
008455*        MOVE 12                     TO L0280-INPUT-SIZE
008455         MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH        =  L0280-INPUT-SIZE - 3
               MOVE MIR-PAC-DRW-TOT-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO RPDRW-PAC-DRW-TOT-AMT
008455*            MOVE L0280-OUTPUT-DOLLAR TO DISPLAY-NUMBER-7-2
008455*            MOVE DISPLAY-NUMBER-7-2  TO MIR-PAC-DRW-TOT-AMT
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                 L0280-OUTPUT-DOLLAR    * 100
020874             MOVE L0280-OUTPUT-DOLLAR   TO L0290-INPUT-V02
008455             MOVE 2                     TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-PAC-DRW-TOT-AMT
               ELSE
                   MOVE 'Y'           TO WS-NUMERIC-ERROR-SW
               END-IF
           END-IF.

           IF  MIR-PAC-DRW-STAT-CD  = RPDRW-PAC-DRW-STAT-CD
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               IF  MIR-PAC-DRW-STAT-CD           NOT = SPACES
               AND (RPDRW-PAC-DRW-STAT-ACTIVE
               AND MIR-PAC-DRW-STAT-CD               = 'P')
               OR (RPDRW-PAC-DRW-STAT-CD   = 'P'
               AND MIR-PAC-DRW-STAT-CD               = 'A')
                   MOVE MIR-PAC-DRW-STAT-CD
                                      TO RPDRW-PAC-DRW-STAT-CD
               ELSE
                   MOVE 'CS50900003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  WS-NUMERIC-ERROR
      * MSG - FIELD (S) MUST BE VALID NUMERIC
               MOVE 'XS00000018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  RPDRW-PAC-DRW-STAT-REVERSED
               PERFORM  7350-EDIT-REVERSAL-REASON
                   THRU 7350-EDIT-REVERSAL-REASON-X
           END-IF.


           IF  WGLOB-MSG-ERROR-SW          = ZERO
               PERFORM  PDRW-2000-REWRITE
                   THRU PDRW-2000-REWRITE-X
014221         PERFORM  BNKA-2000-REWRITE
014221             THRU BNKA-2000-REWRITE-X
014221         PERFORM  BNKA-1000-READ-TWRK-TS
014221             THRU BNKA-1000-READ-TWRK-TS-X

           ELSE
               PERFORM  PDRW-3000-UNLOCK
                   THRU PDRW-3000-UNLOCK-X
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
           END-IF.

       5220-MAINTAIN-PDRW-X.
           EXIT.
      /
020467*-----------------------
020467 5230-MAINTAIN-PDRW-DD2.
020467*-----------------------
020467
020467     IF  MIR-PAC-DRW-STAT-CD  = RPDRW-PAC-DRW-STAT-CD
034802*        NEXT SENTENCE
034802         CONTINUE
020467     ELSE
020467         IF  MIR-PAC-DRW-STAT-CD           NOT = SPACES
020467         AND ((RPDRW-PAC-DRW-STAT-TRIGGERED
020467         AND MIR-PAC-DRW-STAT-CD               = 'F')
020467         OR (RPDRW-PAC-DRW-STAT-PULL-DD2
020467         AND MIR-PAC-DRW-STAT-CD               = 'D'))
020467             MOVE MIR-PAC-DRW-STAT-CD
020467                                TO RPDRW-PAC-DRW-STAT-CD
020467         ELSE
020467             IF  MIR-PAC-DRW-STAT-CD           NOT = SPACES
020467             AND ((RPDRW-PAC-DRW-STAT-WRITTEN
020467             AND MIR-PAC-DRW-STAT-CD               = 'G')
020467             OR (RPDRW-PAC-DRW-STAT-SUSPENDED
020467             AND MIR-PAC-DRW-STAT-CD               = 'B'))
020467                 MOVE MIR-PAC-DRW-STAT-CD
020467                                    TO RPDRW-PAC-DRW-STAT-CD
020467             ELSE
020467* MSG: STATUS CHANGE CAN ONLY BE WRITTEN TO SUSPENDED & VICE-VERSA
020467*      OR TRIGGERED TO DD2 PULLED & VICE-VERSA
020467                 MOVE 'CS50900030'  TO WGLOB-MSG-REF-INFO
020467                 PERFORM  0260-1000-GENERATE-MESSAGE
020467                     THRU 0260-1000-GENERATE-MESSAGE-X
020467             END-IF
020467         END-IF
020467     END-IF.
020467
020467     IF  RPDRW-PAC-DRW-STAT-SUSPENDED
020467         PERFORM  7350-EDIT-REVERSAL-REASON
020467             THRU 7350-EDIT-REVERSAL-REASON-X
020467     END-IF.
020467
020467     IF  WGLOB-MSG-ERROR-SW          = ZERO
020467         PERFORM  PDRW-2000-REWRITE
020467             THRU PDRW-2000-REWRITE-X
020467         PERFORM  BNKA-2000-REWRITE
020467             THRU BNKA-2000-REWRITE-X
020467         PERFORM  BNKA-1000-READ-TWRK-TS
020467             THRU BNKA-1000-READ-TWRK-TS-X
020467
020467     ELSE
020467         PERFORM  PDRW-3000-UNLOCK
020467             THRU PDRW-3000-UNLOCK-X
020467         PERFORM  BNKA-3000-UNLOCK
020467             THRU BNKA-3000-UNLOCK-X
020467     END-IF.
020467
020467 5230-MAINTAIN-PDRW-DD2-X.
020467     EXIT.
020467/
      *-------------------
       5240-MAINTAIN-PDRD.
      *-------------------
020467
020467     IF MIR-PAC-DRW-COLCT-CD = '2'
020467         GO TO 5240-MAINTAIN-PDRD-X
020467     END-IF.

           MOVE  1                    TO I.
           MOVE 'N'                   TO WS-NUMERIC-ERROR-SW.

           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW          = ZERO
               PERFORM  PDRD-2000-REWRITE
                   THRU PDRD-2000-REWRITE-X
014221         PERFORM  BNKA-2000-REWRITE
014221             THRU BNKA-2000-REWRITE-X
014221         PERFORM  BNKA-1000-READ-TWRK-TS
014221             THRU BNKA-1000-READ-TWRK-TS-X
           ELSE
               PERFORM  PDRD-3000-UNLOCK
                   THRU PDRD-3000-UNLOCK-X
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
           END-IF.

       5240-MAINTAIN-PDRD-X.
           EXIT.
      /
      *--------------------------
       5260-READ-PDRW-FOR-UPDATE.
      *--------------------------

           MOVE MIR-BNK-ID            TO WPDRW-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WPDRW-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID       TO WPDRW-BNK-ACCT-ID.

           MOVE MIR-PAC-DRW-IDT-NUM   TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           MOVE L1640-INTERNAL-DATE   TO L1660-INTERNAL-DATE.
016503     MOVE L1640-INTERNAL-DATE   TO WS-PAC-DRW-DT.

           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE   TO WPDRW-PAC-DRW-IDT-NUM.

           MOVE MIR-PAC-DRW-SEQ-NUM   TO DISPLAY-NUMBER-3.

           COMPUTE WPDRW-PAC-DRW-SEQ-NUM
                 = 1000
                 - DISPLAY-NUMBER-3.

           PERFORM  PDRW-1000-READ-FOR-UPDATE
               THRU PDRW-1000-READ-FOR-UPDATE-X.

       5260-READ-PDRW-FOR-UPDATE-X.
           EXIT.
      /
      *----------------------
       5300-EDIT-DATA-FIELDS.
      *----------------------

           PERFORM  5310-EDIT-DETAIL-STATUS
               THRU 5310-EDIT-DETAIL-STATUS-X.

           PERFORM  5320-EDIT-MODE-PREM
               THRU 5320-EDIT-MODE-PREM-X.

           PERFORM  5330-EDIT-LOAN-PAY
               THRU 5330-EDIT-LOAN-PAY-X.

           PERFORM  5340-EDIT-SUNDRY-AMT
               THRU 5340-EDIT-SUNDRY-AMT-X.

           PERFORM  5350-EDIT-PREM-SUSP
               THRU 5350-EDIT-PREM-SUSP-X.

           PERFORM  5360-EDIT-REDRAW-IND
               THRU 5360-EDIT-REDRAW-IND-X.

           IF  WS-NUMERIC-ERROR
      * MSG - FIELD (S) MUST BE VALID NUMERIC
               MOVE 'XS00000018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5300-EDIT-DATA-FIELDS-X
           END-IF.

           COMPUTE WS-AMOUNT-DRAWN
                 = RPDRD-PAC-DRWD-MPREM-AMT
                 + RPDRD-PAC-DRWD-LOAN-AMT
                 + RPDRD-PAC-DRWD-SNDRY-AMT
                 - RPDRD-PAC-DRWD-SUSP-AMT.

           IF  WS-AMOUNT-DRAWN NOT         > ZERO
      * MSG - AMOUNT DRAWN MUST BE GREATER THAN ZERO
               MOVE 'CS50900007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

008455*    MOVE WS-AMOUNT-DRAWN         TO DISPLAY-NUMBER-S-7-2.
008455*    MOVE DISPLAY-NUMBER-S-7-2    TO MIR-PAC-DRW-TOT-AMT-T (I).
      *MIR-DRAWN-T
020874*    COMPUTE L0290-INPUT-NUMBER = WS-AMOUNT-DRAWN  * 100.
020874     MOVE WS-AMOUNT-DRAWN       TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     SET L0290-SIGN-DISPLAY          TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY      TO TRUE.
008455     MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRW-TOT-AMT-T (I).

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       5310-EDIT-DETAIL-STATUS.
      *------------------------

           IF  MIR-PAC-DRWD-STAT-CD-T (I)   = RPDRD-PAC-DRWD-STAT-CD
               GO TO 5310-EDIT-DETAIL-STATUS-X
           END-IF.

           IF  MIR-PAC-DRWD-STAT-CD-T (I)   = SPACES
               MOVE RPDRD-PAC-DRWD-STAT-CD
                                      TO MIR-PAC-DRWD-STAT-CD-T (I)
               GO TO 5310-EDIT-DETAIL-STATUS-X
           END-IF.

           IF  (MIR-PAC-DRWD-STAT-CD-T (I)   = 'B'
           AND  RPDRD-PAC-DRWD-STAT-ERROR)
           OR  (MIR-PAC-DRWD-STAT-CD-T (I)   = 'E'
           AND  RPDRD-PAC-DRWD-STAT-BTCH-BILL)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      * MSG - STATUS CHANGE MUST BE B TO E OR E TO B
               MOVE 'CS50900004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-PAC-DRWD-STAT-CD-T (I)
                                      TO RPDRD-PAC-DRWD-STAT-CD.

       5310-EDIT-DETAIL-STATUS-X.
           EXIT.
      /
      *--------------------
       5320-EDIT-MODE-PREM.
      *--------------------

           IF  MIR-PAC-DRWD-MPREM-AMT-T (I)   = SPACES
008455*    MOVE RPDRD-PAC-DRWD-MPREM-AMT TO DISPLAY-NUMBER-7-2
008455*    MOVE DISPLAY-NUMBER-7-2    TO MIR-PAC-DRWD-MPREM-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RPDRD-PAC-DRWD-MPREM-AMT * 100
020874         MOVE RPDRD-PAC-DRWD-MPREM-AMT      TO L0290-INPUT-V02
008455         MOVE 2                             TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PAC-DRWD-MPREM-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRWD-MPREM-AMT-T (I)
               GO TO 5320-EDIT-MODE-PREM-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                          TO L0280-LENGTH.
008455*    MOVE 10                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PAC-DRWD-MPREM-AMT-T (I)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH            =  L0280-INPUT-SIZE - 3.
           MOVE MIR-PAC-DRWD-MPREM-AMT-T (I)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPDRD-PAC-DRWD-MPREM-AMT
008455*    MOVE L0280-OUTPUT-DOLLAR    TO DISPLAY-NUMBER-7-2
008455*    MOVE DISPLAY-NUMBER-7-2     TO MIR-PAC-DRWD-MPREM-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L0280-OUTPUT-DOLLAR    * 100
020874         MOVE L0280-OUTPUT-DOLLAR       TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PAC-DRWD-MPREM-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRWD-MPREM-AMT-T (I)
           ELSE
               MOVE 'Y'               TO WS-NUMERIC-ERROR-SW
           END-IF.

       5320-EDIT-MODE-PREM-X.
           EXIT.
      /
      *-------------------
       5330-EDIT-LOAN-PAY.
      *-------------------

           IF  MIR-PAC-DRWD-LOAN-AMT-T (I)              = SPACES
008455*        MOVE RPDRD-PAC-DRWD-LOAN-AMT TO DISPLAY-NUMBER-5-2
008455*        MOVE DISPLAY-NUMBER-5-2 TO MIR-PAC-DRWD-LOAN-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RPDRD-PAC-DRWD-LOAN-AMT *  100
020874         MOVE RPDRD-PAC-DRWD-LOAN-AMT      TO L0290-INPUT-V02
008455         MOVE 2                            TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PAC-DRWD-LOAN-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRWD-LOAN-AMT-T (I)
               GO TO 5330-EDIT-LOAN-PAY-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                          TO L0280-LENGTH.
008455*    MOVE 10                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PAC-DRWD-LOAN-AMT-T (I)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-PAC-DRWD-LOAN-AMT-T (I)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPDRD-PAC-DRWD-LOAN-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR TO DISPLAY-NUMBER-5-2
008455*        MOVE DISPLAY-NUMBER-5-2  TO MIR-PAC-DRWD-LOAN-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L0280-OUTPUT-DOLLAR    *   100
020874         MOVE L0280-OUTPUT-DOLLAR       TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PAC-DRWD-LOAN-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRWD-LOAN-AMT-T (I)
           ELSE
               MOVE 'Y'               TO WS-NUMERIC-ERROR-SW
           END-IF.

       5330-EDIT-LOAN-PAY-X.
           EXIT.
      /
      *---------------------
       5340-EDIT-SUNDRY-AMT.
      *---------------------

           IF  MIR-PAC-DRWD-SNDRY-AMT-T (I)              = SPACES
008455*        MOVE RPDRD-PAC-DRWD-SNDRY-AMT TO DISPLAY-NUMBER-7-2
008455*        MOVE DISPLAY-NUMBER-7-2 TO MIR-PAC-DRWD-SNDRY-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RPDRD-PAC-DRWD-SNDRY-AMT   *  100
020874         MOVE RPDRD-PAC-DRWD-SNDRY-AMT       TO L0290-INPUT-V02
008455         MOVE 2                              TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PAC-DRWD-SNDRY-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRWD-SNDRY-AMT-T (I)
               GO TO 5340-EDIT-SUNDRY-AMT-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                          TO L0280-LENGTH.
008455*    MOVE 10                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PAC-DRWD-SNDRY-AMT-T (I)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-PAC-DRWD-SNDRY-AMT-T (I)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPDRD-PAC-DRWD-SNDRY-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR    TO DISPLAY-NUMBER-7-2
008455*        MOVE DISPLAY-NUMBER-7-2 TO MIR-PAC-DRWD-SNDRY-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L0280-OUTPUT-DOLLAR    *  100
020874         MOVE L0280-OUTPUT-DOLLAR       TO L0290-INPUT-V02
008455         MOVE 2                         TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PAC-DRWD-SNDRY-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRWD-SNDRY-AMT-T (I)
           ELSE
               MOVE 'Y'               TO WS-NUMERIC-ERROR-SW
           END-IF.

       5340-EDIT-SUNDRY-AMT-X.
           EXIT.
      /
      *--------------------
       5350-EDIT-PREM-SUSP.
      *--------------------

           IF  MIR-PAC-DRWD-SUSP-AMT-T (I)              = SPACES
008455*        MOVE RPDRD-PAC-DRWD-SUSP-AMT TO DISPLAY-NUMBER-S-7-2
008455*        MOVE DISPLAY-NUMBER-S-7-2 TOMIR-PAC-DRWD-SUSP-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RPDRD-PAC-DRWD-SUSP-AMT   * 100
020874         MOVE RPDRD-PAC-DRWD-SUSP-AMT       TO L0290-INPUT-V02
008455         MOVE 2                             TO L0290-PRECISION
008455         SET L0290-SIGN-DISPLAY             TO TRUE
008455         SET L0290-SIGN-POS-DISPLAY         TO TRUE
008455         MOVE LENGTH OF MIR-PAC-DRWD-SUSP-AMT-T (1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRWD-SUSP-AMT-T (I)
               GO TO 5350-EDIT-PREM-SUSP-X
           END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                          TO L0280-LENGTH.
008455*    MOVE 11                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PAC-DRWD-SUSP-AMT-T (I)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-PAC-DRWD-SUSP-AMT-T (I)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RPDRD-PAC-DRWD-SUSP-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR  TO DISPLAY-NUMBER-S-7-2
008455*        MOVE DISPLAY-NUMBER-S-7-2TO MIR-PAC-DRWD-SUSP-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L0280-OUTPUT-DOLLAR    *  100
020874         MOVE L0280-OUTPUT-DOLLAR        TO L0290-INPUT-V02
008455         MOVE 2                          TO L0290-PRECISION
008455         SET L0290-SIGN-DISPLAY          TO TRUE
008455         SET L0290-SIGN-POS-DISPLAY      TO TRUE
008455         MOVE LENGTH OF MIR-PAC-DRWD-SUSP-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRWD-SUSP-AMT-T (I)
           ELSE
               MOVE 'Y'               TO WS-NUMERIC-ERROR-SW
           END-IF.

       5350-EDIT-PREM-SUSP-X.
           EXIT.
      /
      *---------------------
       5360-EDIT-REDRAW-IND.
      *---------------------

           IF  MIR-PAC-DRWD-REDRW-IND-T (I)              = SPACES
               MOVE RPDRD-PAC-DRWD-REDRW-IND
                                      TO MIR-PAC-DRWD-REDRW-IND-T (I)
               GO TO 5360-EDIT-REDRAW-IND-X
           END-IF.

           MOVE MIR-PAC-DRWD-REDRW-IND-T (I)
                                      TO WS-TEST-REDRAW.

           IF  NOT WS-REDRAW-VALID
      * MSG - REDRAW INDICATOR MUST BE Y OR N ONLY
               MOVE 'CS50900014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE MIR-PAC-DRWD-REDRW-IND-T (I)
                                      TO RPDRD-PAC-DRWD-REDRW-IND
           END-IF.

       5360-EDIT-REDRAW-IND-X.
           EXIT.
      /
      *-----------------------
       6000-PROCESS-LIST-BANK.
      *-----------------------

           IF  MIR-SBSDRY-CO-ID =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-SBSDRY-CO-ID
           END-IF.

010418     IF  MIR-SBSDRY-CO-ID NOT = SPACES
010418         PERFORM  6050-BROWSE-WITH-SUBCO
010418             THRU 6050-BROWSE-WITH-SUBCO-X
010418         GO TO 6000-PROCESS-LIST-BANK-X
010418     END-IF.
010418
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE LOW-VALUES            TO WPDRW-KEY.
           MOVE MIR-BNK-ID            TO WPDRW-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WPDRW-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID       TO WPDRW-BNK-ACCT-ID.

           IF  MIR-PAC-DRW-IDT-NUM                   = SPACES
               MOVE ZEROES            TO WPDRW-PAC-DRW-IDT-NUM
           ELSE
               MOVE WS-INVERTED-DRAW-DATE
                                      TO WPDRW-PAC-DRW-IDT-NUM
           END-IF.

           IF  MIR-PAC-DRW-SEQ-NUM IS NUMERIC
               MOVE MIR-PAC-DRW-SEQ-NUM
                                      TO WS-PIC-999
               COMPUTE WPDRW-PAC-DRW-SEQ-NUM
                     = 1000
                     - WS-PIC-999
           ELSE
               MOVE ZEROES            TO WPDRW-PAC-DRW-SEQ-NUM
           END-IF.

           MOVE WPDRW-KEY             TO WPDRW-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPDRW-ENDBR-PAC-DRW-IDT-NUM.
           MOVE 999                   TO WPDRW-ENDBR-PAC-DRW-SEQ-NUM.

           PERFORM  PDRW-1000-BROWSE
               THRU PDRW-1000-BROWSE-X.

           IF  WPDRW-IO-EOF
      * MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-LIST-BANK-X
           ELSE
               PERFORM  PDRW-2000-READ-NEXT
                   THRU PDRW-2000-READ-NEXT-X
               IF  WPDRW-IO-EOF
                   PERFORM  PDRW-3000-END-BROWSE
                       THRU PDRW-3000-END-BROWSE-X
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 6000-PROCESS-LIST-BANK-X
               END-IF
           END-IF.

           PERFORM  6100-PROCESS-BROWSE-READ
               THRU 6100-PROCESS-BROWSE-READ-X
               VARYING I FROM +1 BY +1
               UNTIL   I > WS-MAX-DETAILS-SCREEN-1
                    OR WPDRW-IO-EOF.

           IF  WPDRW-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RPDRW-PAC-DRW-IDT-NUM
                                      TO L1660-INVERTED-DATE
               PERFORM  9010-CONVERT-INV-EXT
                   THRU 9010-CONVERT-INV-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PAC-DRW-IDT-NUM
020874*        COMPUTE WS-PIC-999
020874*              = 1000
020874*              - RPDRW-PAC-DRW-SEQ-NUM
020874*        MOVE WS-PIC-999        TO MIR-PAC-DRW-SEQ-NUM
020874         COMPUTE L0290-INPUT-V00
020874               = 1000
020874               - RPDRW-PAC-DRW-SEQ-NUM
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PAC-DRW-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRW-SEQ-NUM
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDRW-3000-END-BROWSE
               THRU PDRW-3000-END-BROWSE-X.

       6000-PROCESS-LIST-BANK-X.
           EXIT.
010418/
010418*-----------------------
010418 6050-BROWSE-WITH-SUBCO.
010418*-----------------------
010418
010418     PERFORM  9100-BLANK-DATA-FIELDS
010418         THRU 9100-BLANK-DATA-FIELDS-X.
010418
010418     MOVE LOW-VALUES            TO WPDRS-KEY.
010418     MOVE MIR-BNK-ID            TO WPDRS-BNK-ID.
010418     MOVE MIR-BNK-BR-ID         TO WPDRS-BNK-BR-ID.
010418     MOVE MIR-BNK-ACCT-ID       TO WPDRS-BNK-ACCT-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPDRS-SBSDRY-CO-ID.
010418
010418     IF  MIR-PAC-DRW-SEQ-NUM IS NUMERIC
010418         MOVE MIR-PAC-DRW-SEQ-NUM
                                      TO WS-PIC-999
010418         COMPUTE WPDRS-PAC-DRW-SEQ-NUM
010418               = 1000 - WS-PIC-999
010418     ELSE
010418         MOVE ZEROES            TO WPDRS-PAC-DRW-SEQ-NUM
010418     END-IF.
010418
010418     IF  MIR-PAC-DRW-IDT-NUM                   = SPACES
010418         MOVE ZEROES            TO WPDRS-PAC-DRW-IDT-NUM
010418     ELSE
010418         MOVE WS-INVERTED-DRAW-DATE
                                      TO WPDRS-PAC-DRW-IDT-NUM
010418     END-IF.
010418
010418
010418     MOVE WPDRS-KEY             TO WPDRS-ENDBR-KEY.
010418     MOVE 999                   TO WPDRS-ENDBR-PAC-DRW-SEQ-NUM.
010418     MOVE HIGH-VALUE            TO WPDRS-ENDBR-PAC-DRW-IDT-NUM.
010418
010418     PERFORM  PDRS-1000-BROWSE
010418         THRU PDRS-1000-BROWSE-X.
010418
010418     IF  WPDRS-IO-EOF
010418* MSG: NO RECORDS FOUND TO DISPLAY
010418         MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 6050-BROWSE-WITH-SUBCO-X
010418     ELSE
010418         PERFORM  PDRS-2000-READ-NEXT
010418             THRU PDRS-2000-READ-NEXT-X
010418         IF  WPDRS-IO-EOF
010418             PERFORM  PDRS-3000-END-BROWSE
010418                 THRU PDRS-3000-END-BROWSE-X
010418             MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
010418             PERFORM  0260-1000-GENERATE-MESSAGE
010418                 THRU 0260-1000-GENERATE-MESSAGE-X
010418             GO TO 6050-BROWSE-WITH-SUBCO-X
010418         END-IF
010418     END-IF.
010418
010418     PERFORM  6100-PROCESS-BROWSE-READ
010418         THRU 6100-PROCESS-BROWSE-READ-X
010418         VARYING I FROM +1 BY +1
010418         UNTIL   I > WS-MAX-DETAILS-SCREEN-1
010418         OR WPDRS-IO-EOF.
010418
010418     IF  WPDRS-IO-EOF
010418         MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418     ELSE
010418         MOVE RPDRW-PAC-DRW-IDT-NUM
                                      TO L1660-INVERTED-DATE
010418         PERFORM  9010-CONVERT-INV-EXT
010418             THRU 9010-CONVERT-INV-EXT-X
010418         MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PAC-DRW-IDT-NUM
020874*        COMPUTE WS-PIC-999
020874*              = 1000
020874*              - RPDRW-PAC-DRW-SEQ-NUM
020874*        MOVE WS-PIC-999        TO MIR-PAC-DRW-SEQ-NUM
020874         COMPUTE L0290-INPUT-V00
020874               = 1000
020874               - RPDRW-PAC-DRW-SEQ-NUM
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PAC-DRW-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRW-SEQ-NUM
010418         MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
010418         SET WGLOB-MORE-DATA-EXISTS  TO TRUE
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418     END-IF.
010418
010418     PERFORM  PDRS-3000-END-BROWSE
010418         THRU PDRS-3000-END-BROWSE-X.
010418
010418 6050-BROWSE-WITH-SUBCO-X.
010418     EXIT.
      /
      *-------------------------
       6100-PROCESS-BROWSE-READ.
      *-------------------------

020467     IF MIR-PAC-DRW-COLCT-CD NOT =
020467        RPDRW-PAC-DRW-COLCT-CD
020467         IF  MIR-SBSDRY-CO-ID = SPACE
020467             PERFORM  PDRW-2000-READ-NEXT
020467                 THRU PDRW-2000-READ-NEXT-X
020467         ELSE
020467             PERFORM  PDRS-2000-READ-NEXT
020467                 THRU PDRS-2000-READ-NEXT-X
020467         END-IF
020467         SUBTRACT 1 FROM I
020467         GO TO 6100-PROCESS-BROWSE-READ-X
020467     END-IF.
020467
           MOVE RPDRW-PAC-DRW-IDT-NUM TO L1660-INVERTED-DATE.

           PERFORM  9010-CONVERT-INV-EXT
               THRU 9010-CONVERT-INV-EXT-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-PAC-DRW-IDT-NUM-T (I).

020874*    COMPUTE WS-PIC-999
020874*          = 1000
020874*          - RPDRW-PAC-DRW-SEQ-NUM.

020874*    MOVE WS-PIC-999            TO MIR-PAC-DRW-SEQ-NUM-T (I).
020874     COMPUTE L0290-INPUT-V00
020874            = 1000
020874            - RPDRW-PAC-DRW-SEQ-NUM.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-PAC-DRW-SEQ-NUM-T (I)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRW-SEQ-NUM-T (I).
           IF  I = 1
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PAC-DRW-IDT-NUM
020874*        MOVE WS-PIC-999        TO MIR-PAC-DRW-SEQ-NUM
020874         MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRW-SEQ-NUM
           END-IF.

010418     MOVE RPDRW-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T (I).

008455*    MOVE RPDRW-PAC-DRW-TOT-AMT TO DISPLAY-NUMBER-Z-9-2.
008455*    MOVE DISPLAY-NUMBER-Z-9-2  TO MIR-PAC-DRW-TOT-AMT-T(I).
      *MIR-BTOT-T
020874*    COMPUTE L0290-INPUT-NUMBER = RPDRW-PAC-DRW-TOT-AMT * 100.
020874     MOVE RPDRW-PAC-DRW-TOT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS  TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRW-TOT-AMT-T (I).

           MOVE RPDRW-PAC-DRW-STAT-CD TO MIR-PAC-DRW-STAT-CD-T (I).
           MOVE RPDRW-PAC-DRW-CREAT-CD TO MIR-PAC-DRW-CREAT-CD-T (I).
           MOVE RPDRW-PAC-DRW-RETRN-CD TO MIR-PAC-DRW-RETRN-CD-T (I).
020467     MOVE RPDRW-CTRY-CD          TO MIR-CTRY-CD-T (I).


010418*    PERFORM  PDRW-2000-READ-NEXT
010418*        THRU PDRW-2000-READ-NEXT-X.

010418     IF  MIR-SBSDRY-CO-ID = SPACE
010418         PERFORM  PDRW-2000-READ-NEXT
010418             THRU PDRW-2000-READ-NEXT-X
010418     ELSE
010418         PERFORM  PDRS-2000-READ-NEXT
010418             THRU PDRS-2000-READ-NEXT-X
010418     END-IF.

       6100-PROCESS-BROWSE-READ-X.
           EXIT.
      /
      *-------------------------
       6500-PROCESS-LIST-POLICY.
      *-------------------------


           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  8900-SETUP-AND-READ-PDRW
               THRU 8900-SETUP-AND-READ-PDRW-X.

           IF  NOT WPDRW-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6500-PROCESS-LIST-POLICY-X
           END-IF.

           PERFORM  9200-MOVE-PDRW-TO-SCREEN
               THRU 9200-MOVE-PDRW-TO-SCREEN-X.

           PERFORM  5160-LOAD-ALL-PDRD
               THRU 5160-LOAD-ALL-PDRD-X.

           IF  WS-PDRD-MORE-DATA-NO
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6500-PROCESS-LIST-POLICY-X.
           EXIT.

      *---------------------
       7000-PROCESS-REVERSE.
      *---------------------

           IF  MIR-DV-PRCES-STATE-CD    = '1'
           OR  MIR-DV-PRCES-STATE-CD    = '2'
               PERFORM  7100-REVERSE-FIRST-PASS
                   THRU 7100-REVERSE-FIRST-PASS-X
           ELSE
               IF  MIR-DV-PRCES-STATE-CD    = '3'
                   PERFORM  7200-REVERSE-SECOND-PASS
                       THRU 7200-REVERSE-SECOND-PASS-X
               END-IF
           END-IF.

       7000-PROCESS-REVERSE-X.
           EXIT.

      *------------------------
       7100-REVERSE-FIRST-PASS.
      *------------------------

014221     MOVE MIR-BNK-ID            TO WBNKA-BNK-ID.
014221     MOVE MIR-BNK-BR-ID         TO WBNKA-BNK-BR-ID.
014221     MOVE MIR-BNK-ACCT-ID       TO WBNKA-BNK-ACCT-ID.
014221     PERFORM BNKA-1000-READ-TWRK-TS
014221        THRU BNKA-1000-READ-TWRK-TS-X
014221     IF  WBNKA-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (1)
014221        MOVE 'BNKA'             TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 7100-REVERSE-FIRST-PASS-X
014221     END-IF.

           PERFORM  8900-SETUP-AND-READ-PDRW
               THRU 8900-SETUP-AND-READ-PDRW-X.

           IF  NOT WPDRW-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7100-REVERSE-FIRST-PASS-X
           END-IF.

           IF  NOT RPDRW-PAC-DRW-STAT-ACTIVE
      * MSG: REVERSAL NOT ALLOWED FOR PDRW STATUS
               MOVE 'CS50900018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-PDRW-TO-SCREEN
                   THRU 9200-MOVE-PDRW-TO-SCREEN-X
               GO TO 7100-REVERSE-FIRST-PASS-X
           END-IF.

           IF  RPDRW-PAC-DRW-CREAT-SYSTEM
           AND RPDRW-PAC-DRW-TOT-AMT       = ZERO
           AND RPDRW-PAC-DRW-STAT-ACTIVE
      * MSG: CANNOT REVERSE SYSTEM GENERATED PRENOTE RECORD
               MOVE 'CS50900025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7100-REVERSE-FIRST-PASS-X
           END-IF.

           MOVE ZERO                  TO I.

           PERFORM  5160-LOAD-ALL-PDRD
               THRU 5160-LOAD-ALL-PDRD-X.

           IF  I                           = ZERO
      * MSG: NO PAC DRAW DETAILS TO REVERSE
               MOVE 'CS50900019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7100-REVERSE-FIRST-PASS-X
           END-IF.

           MOVE MIR-POL-ID-SFX-T (1)      TO WPOL-POL-ID-SFX.
           MOVE MIR-POL-ID-BASE-T (1)     TO WPOL-POL-ID-BASE.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7100-REVERSE-FIRST-PASS-X
           END-IF.


           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET  L5400-CRCY-MSG-REQD        TO TRUE.
           SET  L5400-STAT-MSG-NOT-REQD    TO TRUE.
           SET  L5400-BRCH-MSG-NOT-REQD    TO TRUE.

016440     IF  WS-BUS-FCN-CREATE
016440     OR  WS-BUS-FCN-UPDATE
016440     OR  WS-BUS-FCN-DELETE
016440     OR  WS-BUS-FCN-REVERSE
016440     OR  WS-BUS-FCN-ADDPOL
016440     OR  WS-BUS-FCN-UPDATE-POL
016440     OR  WS-BUS-FCN-DELETE-POL
016440         SET L5400-POL-XFER-UPDATE    TO TRUE
016440     END-IF.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  NOT L5400-CRCY-ACCS-ALLOW
016440         OR  L5400-XFER-ACCS-RESTRICTED
               GO TO 7100-REVERSE-FIRST-PASS-X
           END-IF.

           PERFORM  7350-EDIT-REVERSAL-REASON
               THRU 7350-EDIT-REVERSAL-REASON-X.

           PERFORM  9200-MOVE-PDRW-TO-SCREEN
               THRU 9200-MOVE-PDRW-TO-SCREEN-X.


           IF  MIR-PAC-DRW-RETRN-CD     = SPACES
               GO TO 7100-REVERSE-FIRST-PASS-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW       = ZERO
               MOVE 'CS00000016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'XS00000219'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-2000-GET-MESSAGE
                   THRU 0260-2000-GET-MESSAGE-X
           END-IF.

       7100-REVERSE-FIRST-PASS-X.
           EXIT.
      /
      *-------------------------
       7200-REVERSE-SECOND-PASS.
      *-------------------------

014221     MOVE MIR-BNK-ID            TO WBNKA-BNK-ID.
014221     MOVE MIR-BNK-BR-ID         TO WBNKA-BNK-BR-ID.
014221     MOVE MIR-BNK-ACCT-ID       TO WBNKA-BNK-ACCT-ID.
014221     PERFORM BNKA-2000-UPDATE-TWRK-TS
014221        THRU BNKA-2000-UPDATE-TWRK-TS-X.

014221     IF  WBNKA-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (1)
014221         MOVE 'BNKA'             TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 7200-REVERSE-SECOND-PASS-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'BNKA'             TO WGLOB-MSG-PARM (01)
014221         MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 7200-REVERSE-SECOND-PASS-X
014221     END-IF.

           PERFORM  5260-READ-PDRW-FOR-UPDATE
               THRU 5260-READ-PDRW-FOR-UPDATE-X.


           IF  NOT WPDRW-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7200-REVERSE-SECOND-PASS-X
           END-IF.

           MOVE MIR-PAC-DRW-RETRN-CD  TO RPDRW-PAC-DRW-RETRN-CD.

           PERFORM  9200-MOVE-PDRW-TO-SCREEN
               THRU 9200-MOVE-PDRW-TO-SCREEN-X.

           PERFORM  5160-LOAD-ALL-PDRD
               THRU 5160-LOAD-ALL-PDRD-X.

           IF  WGLOB-MSG-ERROR-SW          > ZERO
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
               GO TO 7200-REVERSE-SECOND-PASS-X
           END-IF.

           PERFORM  5180-START-PDRD-BROWSE
               THRU 5180-START-PDRD-BROWSE-X.

           PERFORM  7300-REVERSE-PDRD
               THRU 7300-REVERSE-PDRD-X
010397*        UNTIL WPDRD-IO-EOF.
010397         UNTIL WPDRD-IO-EOF
010397         OR WGLOB-RETURN-ERROR.
           PERFORM  PDRD-3000-END-BROWSE
               THRU PDRD-3000-END-BROWSE-X.


           IF  WGLOB-GOOD-RETURN
               MOVE 'CS50900012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'R'               TO RPDRW-PAC-DRW-STAT-CD
               MOVE 'R'               TO MIR-PAC-DRW-STAT-CD
               PERFORM  PDRW-2000-REWRITE
                   THRU PDRW-2000-REWRITE-X
014221         PERFORM  BNKA-2000-REWRITE
014221             THRU BNKA-2000-REWRITE-X
014221         PERFORM  BNKA-1000-READ-TWRK-TS
014221             THRU BNKA-1000-READ-TWRK-TS-X

           ELSE
               PERFORM  PDRW-3000-UNLOCK
                   THRU PDRW-3000-UNLOCK-X
014221         PERFORM  BNKA-3000-UNLOCK
014221             THRU BNKA-3000-UNLOCK-X
           END-IF.

       7200-REVERSE-SECOND-PASS-X.
           EXIT.
      /
      *------------------
       7300-REVERSE-PDRD.
      *------------------

           IF  RPDRD-PAC-DRWD-STAT-ERROR
               PERFORM  PDRD-2000-READ-NEXT
                   THRU PDRD-2000-READ-NEXT-X
               GO TO 7300-REVERSE-PDRD-X
           END-IF.

           MOVE RPDRD-POL-ID          TO LPGA-POLICY-NUMBER.
           MOVE 'P'                   TO WGLOB-REF-POLICY-ID.
           MOVE RPDRD-POL-ID          TO WGLOB-REF-POLICY-ID.

           MOVE RPDRD-POL-ID          TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7300-REVERSE-PDRD-X
           END-IF.

           IF  RPOL-POL-STAT-PREM-PAY-REG
           AND (RPOL-POL-PREM-NTRADL-FLEX
           OR  RPOL-POL-PREM-NTCNTRCT)
               MOVE 'CS50900027'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

016108*
016108* VALIDATE DATE OF DEATH FOR EACH POLICY
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE RPDRW-PAC-DRW-DT      TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         SET WGLOB-RETURN-ERROR TO TRUE
016108         GO TO 7300-REVERSE-PDRD-X
016108     END-IF.

014035*    MOVE WCVGS-WORK-AREA            TO HCVGS-CVGS-INFO.
014035     MOVE WCVGS-WORK-AREA       TO HCVGS-WORK-AREA.

           PERFORM  7370-SETUP-PPAY-DATA
               THRU 7370-SETUP-PPAY-DATA-X.

           PERFORM  1651-2000-POL-REVRS
               THRU 1651-2000-POL-REVRS-X.

010397* LHST RECORD NOT FOUND FOR PAYMENT REVERSAL

010397     IF  L1651-RETRN-LOAN-ERROR
010397         SET WGLOB-RETURN-ERROR     TO  TRUE
010397         GO TO 7300-REVERSE-PDRD-X
010397     END-IF.

           IF  NOT L1651-RETRN-OK
               PERFORM  7380-RETRY-PPAY
                   THRU 7380-RETRY-PPAY-X
           END-IF.

           MOVE  RPOL-REC-INFO        TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY             TO  WPOL-KEY.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.

           MOVE WGLOB-PROCESS-DATE    TO RPOL-PREV-FILE-MAINT-DT.

016503      PERFORM  0289-1000-INIT-PARM-INFO
016503          THRU 0289-1000-INIT-PARM-INFO-X.

016503      IF  WS-PAC-DRW-DT = WWKDT-ZERO-DT
016503           CONTINUE
016503      ELSE
016503           MOVE WS-PAC-DRW-DT        TO L0289-LO-PAC-DT
016503           MOVE WS-PAC-DRW-DT        TO L0289-LO-CRC-DT
016503           MOVE WS-PAC-DRW-DT        TO L0289-PROC-EFF-DT
016503      END-IF.

016503      PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503          THRU 0289-1000-OBTAIN-NXT-ACTV-X.

016503      IF  L0289-RETRN-OK
016503          MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503      ELSE
016503          MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503      END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014035*    IF  WCVGS-WORK-AREA NOT         = HCVGS-CVGS-INFO
014035     IF  WCVGS-WORK-AREA NOT         = HCVGS-WORK-AREA
               PERFORM  7400-REWRITE-COVERAGES
                   THRU 7400-REWRITE-COVERAGES-X
                   VARYING I FROM +1 BY +1
                   UNTIL I > RPOL-POL-CVG-REC-CTR-N
           END-IF.

           PERFORM  PDRD-2000-READ-NEXT
               THRU PDRD-2000-READ-NEXT-X.

       7300-REVERSE-PDRD-X.
           EXIT.
      /
      *--------------------------
       7350-EDIT-REVERSAL-REASON.
      *--------------------------

           IF  MIR-PAC-DRW-RETRN-CD                  = SPACES
      * MSG - PLEASE ENTER REVERSAL REASON
               MOVE 'CS50900017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7350-EDIT-REVERSAL-REASON-X
           END-IF.

           MOVE MIR-PAC-DRW-RETRN-CD  TO WS-TEST-REASON.
           MOVE MIR-PAC-DRW-RETRN-CD  TO RPDRW-PAC-DRW-RETRN-CD.

           IF  NOT WS-REASON-VALID
      * MSG - REVERSAL REASON MUST BE N C S OR D ONLY
               MOVE 'CS50900015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7350-EDIT-REVERSAL-REASON-X.
           EXIT.
      /
      *---------------------
       7370-SETUP-PPAY-DATA.
      *---------------------

           PERFORM  1651-0000-INIT-PARM-INFO
               THRU 1651-0000-INIT-PARM-INFO-X.

           PERFORM  1651-1000-BUILD-PARM-INFO
               THRU 1651-1000-BUILD-PARM-INFO-X.

           SET L1651-RQST-POL-PMT-REVRS    TO TRUE.
028620     SET L1651-UNDO-ORIGIN-PREMSUS   TO TRUE.
026664*    MOVE RPDRW-PAC-DRW-DT      TO L1651-EFF-DT.
026664     MOVE RPDRD-PAC-DRWD-DUE-DT TO L1651-EFF-DT.
           MOVE MIR-PAC-DRW-RETRN-CD  TO L1651-REVRS-REASN-CD.
010418     MOVE RPDRW-SBSDRY-CO-ID    TO L1651-SBSDRY-CO-ID.

           COMPUTE L1651-PAC-AMT
                 = RPDRD-PAC-DRWD-MPREM-AMT
                 + RPDRD-PAC-DRWD-SNDRY-AMT
                 + RPDRD-PAC-DRWD-LOAN-AMT
                 - RPDRD-PAC-DRWD-SUSP-AMT.

038204*    IF  RPOL-POL-STAT-PREM-PAY-REG
038204*        MOVE RPDRD-PAC-DRWD-MPREM-AMT
038204*                               TO L1651-PREM-AMT
038204*        MOVE RPDRD-PAC-DRWD-SNDRY-AMT
038204*                               TO L1651-SUSP-AMT
038204*        MOVE RPDRD-PAC-DRWD-LOAN-AMT
038204*                               TO L1651-LOAN-AMT
038204*        MULTIPLY -1 BY RPDRD-PAC-DRWD-SUSP-AMT
038204*                                  GIVING L1651-PRM-SUSP-AMT
038204*        PERFORM  7375-CHECK-PRM-SUSP-AMT
038204*            THRU 7375-CHECK-PRM-SUSP-AMT-X
038204
038204     IF  RPOL-POL-STAT-PREM-PAY-REG
038204         IF NOT RPDRD-PAC-DRWD-MPREM-AMT > ZEROES
038204             MOVE RPDRD-PAC-DRWD-MPREM-AMT
038204                                TO L1651-PREM-AMT
038204             MOVE RPDRD-PAC-DRWD-SNDRY-AMT
038204                                TO L1651-SUSP-AMT
038204             MOVE RPDRD-PAC-DRWD-LOAN-AMT
038204                                TO L1651-LOAN-AMT
038204             MULTIPLY -1 BY RPDRD-PAC-DRWD-SUSP-AMT
038204                                   GIVING L1651-PRM-SUSP-AMT
038204         ELSE
038204             PERFORM  7375-CHECK-PRM-SUSP-AMT
038204                 THRU 7375-CHECK-PRM-SUSP-AMT-X
038204         END-IF
           ELSE
               MOVE L1651-PAC-AMT     TO L1651-SUSP-AMT
      * MSG - POLICY @1 IS NOT PREMIUM PAYING - PTD WILL NOT BE CHANGED
               MOVE 'CS50900021'      TO WGLOB-MSG-REF-INFO
               MOVE RPDRD-POL-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7370-SETUP-PPAY-DATA-X.
           EXIT.
      /

026664*------------------------
026664 7375-CHECK-PRM-SUSP-AMT.
026664*------------------------
026664
038204*    MOVE RPOL-POL-PD-TO-DT-NUM TO L1680-INTERNAL-1.
038204*    MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
038204*    MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
038204*    MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
038204*    PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
038204*        THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
038204*    MOVE L1680-INTERNAL-2      TO WS-POL-PD-TO-DT.
038204*
038204*    IF  L1651-PAC-AMT      = L1651-PREM-AMT
038204*    AND L1651-SUSP-AMT     = ZERO
038204*    AND L1651-LOAN-AMT     = ZERO
038204*    AND L1651-PRM-SUSP-AMT = ZERO
038204*        IF L1651-PREM-AMT NOT > RPOL-POL-PREM-SUSP-AMT
038204*           MOVE L1651-PAC-AMT  TO L1651-PRM-SUSP-AMT
038204*           MOVE ZERO           TO L1651-PREM-AMT
038204*           MOVE WWKDT-ZERO-DT  TO RPOL-POL-PMT-DRW-DT
038204*        ELSE
038204*           MOVE WS-POL-PD-TO-DT TO L1651-EFF-DT
038204*        END-IF
038204*    END-IF.
038204
038204*
038204*   CALCULATE THE NORMAL PAID TO DATE
038204*
038204     PERFORM  2625-0000-INIT-PARM-INFO
038204         THRU 2625-0000-INIT-PARM-INFO-X.
038204
038204     MOVE RPOL-POL-PD-TO-DT-NUM        TO L0183-CRNT-PREM-DT
038204
038204     PERFORM  PTD-2000-CALC-PREV-PREM-DT
038204         THRU PTD-2000-CALC-PREV-PREM-DT-X.
038204
038204     IF  RPDRD-PAC-DRWD-DUE-DT > L0183-NEW-PREM-DT
038204         MOVE RPDRD-PAC-DRWD-MPREM-AMT TO L1651-PRM-SUSP-AMT
038204         IF  L1651-PRM-SUSP-AMT NOT > RPOL-POL-PREM-SUSP-AMT
038204             MOVE WWKDT-ZERO-DT        TO RPOL-POL-PMT-DRW-DT
038204         END-IF
038204     ELSE
038204         MOVE L0183-NEW-PREM-DT        TO L1651-EFF-DT
038204         MOVE RPDRD-PAC-DRWD-MPREM-AMT TO L1651-PREM-AMT
038204         SUBTRACT RPDRD-PAC-DRWD-SUSP-AMT FROM
038204                                          L1651-PRM-SUSP-AMT
038204     END-IF.
038204
038204     MOVE RPDRD-PAC-DRWD-SNDRY-AMT     TO L1651-SUSP-AMT.
038204     MOVE RPDRD-PAC-DRWD-LOAN-AMT      TO L1651-LOAN-AMT.
026664
026664 7375-CHECK-PRM-SUSP-AMT-X.
026664     EXIT.


      *----------------
       7380-RETRY-PPAY.
      *----------------

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.
           MOVE ZERO                  TO WGLOB-RETURN-CODE.
           SET  L1651-RETRN-OK             TO TRUE.
           MOVE ZEROES                TO L1651-LOAN-AMT.
           MOVE ZEROES                TO L1651-PREM-AMT.

           IF  RPOL-POL-STAT-PREM-PAY-REG
               MOVE L1651-PAC-AMT     TO L1651-PRM-SUSP-AMT
               MOVE ZEROES            TO L1651-SUSP-AMT
           ELSE
               IF  (RPOL-POL-STAT-IN-FORCE
               OR  RPOL-POL-SUSPENDED)
                   MOVE L1651-PAC-AMT TO L1651-SUSP-AMT
                   MOVE ZEROES        TO L1651-PRM-SUSP-AMT
               ELSE
                   MOVE L1651-PAC-AMT TO L1651-OS-DISB-AMT
                   MOVE ZEROES        TO L1651-SUSP-AMT
                   MOVE ZEROES        TO L1651-PRM-SUSP-AMT
               END-IF
           END-IF.

           PERFORM  1651-2000-POL-REVRS
               THRU 1651-2000-POL-REVRS-X.

           IF  NOT L1651-RETRN-OK
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

       7380-RETRY-PPAY-X.
           EXIT.
      /
      *-----------------------
       7400-REWRITE-COVERAGES.
      *-----------------------

           IF  HCVGS-CVG-INFO (I)      NOT = WCVGS-CVG-INFO (I)
               MOVE WCVGS-CVG-INFO (I)      TO HCVGS-CVG-INFO (I)
               MOVE RPOL-POL-ID       TO WCVG-POL-ID
               MOVE I                 TO WCVG-CVG-NUM-N
               PERFORM  CVG-1000-READ-FOR-UPDATE
                   THRU CVG-1000-READ-FOR-UPDATE-X
               IF  WCVG-IO-OK
                   MOVE HCVGS-CVG-INFO (I)
                                      TO RCVG-CVG-INFO
                   PERFORM  CVG-2000-REWRITE
                       THRU CVG-2000-REWRITE-X
               ELSE
                   MOVE 'CS00000024'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       7400-REWRITE-COVERAGES-X.
           EXIT.
      /
      *-----------------
       8000-PROCESS-ADD.
      *-----------------

           MOVE MIR-BNK-ID            TO WPDRW-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WPDRW-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID       TO WPDRW-BNK-ACCT-ID.
           MOVE MIR-PAC-DRW-IDT-NUM   TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           MOVE L1640-INTERNAL-DATE   TO L1660-INTERNAL-DATE.
016503     MOVE L1640-INTERNAL-DATE   TO WS-PAC-DRW-DT.

           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE   TO WPDRW-PAC-DRW-IDT-NUM.

           MOVE MIR-PAC-DRW-SEQ-NUM   TO DISPLAY-NUMBER-3.

           COMPUTE WPDRW-PAC-DRW-SEQ-NUM
                 = 1000
                 - DISPLAY-NUMBER-3.

010418*    PERFORM  PDRW-1000-READ
010418*        THRU PDRW-1000-READ-X.
010418     IF  WS-UPDATE-HDR-YES
010418         PERFORM  PDRW-1000-READ-FOR-UPDATE
010418             THRU PDRW-1000-READ-FOR-UPDATE-X
010418     ELSE
010418         PERFORM  PDRW-1000-READ
010418             THRU PDRW-1000-READ-X
010418     END-IF.

           IF  NOT WPDRW-IO-OK
      * MSG: PAC DRAW DOES NOT EXIST - CANNOT ADD DETAILS.
               MOVE 'CS50900006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
010418         IF  WS-UPDATE-HDR-YES
010418             PERFORM  PDRW-3000-UNLOCK
010418                 THRU PDRW-3000-UNLOCK-X
010418         END-IF
               GO TO 8000-PROCESS-ADD-X
           END-IF.

           MOVE WPDRW-BNK-ID          TO WPDRD-BNK-ID.
           MOVE WPDRW-BNK-BR-ID       TO WPDRD-BNK-BR-ID.
           MOVE WPDRW-BNK-ACCT-ID     TO WPDRD-BNK-ACCT-ID.
           MOVE WPDRW-PAC-DRW-IDT-NUM TO WPDRD-PAC-DRW-IDT-NUM.
           MOVE WPDRW-PAC-DRW-SEQ-NUM TO WPDRD-PAC-DRW-SEQ-NUM.
           MOVE RPOL-POL-ID           TO WPDRD-POL-ID.
005409*    MOVE WS-DUE-DATE                TO WPDRD-PAC-DRWD-DUE-DT.
005409     MOVE WS-DUE-DATE           TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WPDRD-PAC-DRWD-DUE-DT.

           PERFORM  PDRD-1000-READ
               THRU PDRD-1000-READ-X.

           IF  WPDRD-IO-OK
      * MSG: RECORD ALREADY EXISTS
               MOVE 'CS00000005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
010418         IF  WS-UPDATE-HDR-YES
010418             PERFORM  PDRW-3000-UNLOCK
010418                 THRU PDRW-3000-UNLOCK-X
010418         END-IF
               GO TO 8000-PROCESS-ADD-X
           END-IF.

           PERFORM  PDRD-1000-CREATE
               THRU PDRD-1000-CREATE-X.

           PERFORM  PDRD-1000-WRITE
               THRU PDRD-1000-WRITE-X.

014221     MOVE MIR-BNK-ID            TO WBNKA-BNK-ID.
014221     MOVE MIR-BNK-BR-ID         TO WBNKA-BNK-BR-ID.
014221     MOVE MIR-BNK-ACCT-ID       TO WBNKA-BNK-ACCT-ID.
014221     PERFORM BNKA-1000-READ-TWRK-TS
014221        THRU BNKA-1000-READ-TWRK-TS-X
014221     IF  WBNKA-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WBNKA-KEY          TO WGLOB-MSG-PARM (1)
014221        MOVE 'BNKA'             TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 8000-PROCESS-ADD-X
014221     END-IF.

010418     IF  WS-UPDATE-HDR-YES
010418         MOVE RPOL-SBSDRY-CO-ID TO RPDRW-SBSDRY-CO-ID
010418         PERFORM  PDRW-2000-REWRITE
010418             THRU PDRW-2000-REWRITE-X
010418     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  9200-MOVE-PDRW-TO-SCREEN
               THRU 9200-MOVE-PDRW-TO-SCREEN-X.

           PERFORM  8800-DEFAULT-POLICY-INFO
               THRU 8800-DEFAULT-POLICY-INFO-X.

           MOVE 1                     TO I.

           PERFORM  9220-DETAIL-LINE-SCREEN-2
               THRU 9220-DETAIL-LINE-SCREEN-2-X.

           MOVE 'D'                   TO WS-MAINTAIN-RECORD.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       8000-PROCESS-ADD-X.
           EXIT.
      /
      *-------------------------
       8800-DEFAULT-POLICY-INFO.
      *-------------------------

           MOVE RPOL-POL-MPREM-AMT    TO RPDRD-PAC-DRWD-MPREM-AMT.
           MOVE RPOL-POL-LOAN-REPAY-AMT
                                      TO RPDRD-PAC-DRWD-LOAN-AMT.
           MOVE RPOL-POL-SNDRY-AMT    TO RPDRD-PAC-DRWD-SNDRY-AMT.
           MOVE RPOL-POL-PREM-SUSP-AMT TO RPDRD-PAC-DRWD-SUSP-AMT.

       8800-DEFAULT-POLICY-INFO-X.
           EXIT.
      /
      *-------------------------
       8900-SETUP-AND-READ-PDRW.
      *-------------------------

           MOVE MIR-BNK-ID            TO WPDRW-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WPDRW-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID       TO WPDRW-BNK-ACCT-ID.
           MOVE MIR-PAC-DRW-IDT-NUM   TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

011614* INITIALIZE L1640-EXTERNAL-DATE IF RETURN WITH NOT VALID DATE
011614*
011614     IF  L1640-NOT-VALID
011614         MOVE WWKDT-ZERO-DT     TO L1640-INTERNAL-DATE
011614     END-IF.

           IF  L1640-INTERNAL-DATE         = ZEROES
               MOVE ZEROES            TO WPDRW-PAC-DRW-IDT-NUM
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
016503         MOVE L1640-INTERNAL-DATE
016503                                TO WS-PAC-DRW-DT
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE
                                      TO WPDRW-PAC-DRW-IDT-NUM
           END-IF.

           MOVE MIR-PAC-DRW-SEQ-NUM   TO DISPLAY-NUMBER-3.

           COMPUTE WPDRW-PAC-DRW-SEQ-NUM
                 = 1000
                 - DISPLAY-NUMBER-3.

           PERFORM  PDRW-1000-READ
               THRU PDRW-1000-READ-X.

       8900-SETUP-AND-READ-PDRW-X.
           EXIT.
      /
      *---------------------
       9010-CONVERT-INV-EXT.
      *---------------------

           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.

           MOVE L1660-INTERNAL-DATE   TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

       9010-CONVERT-INV-EXT-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           IF  WS-BUS-FCN-LIST
           OR  WS-BUS-FCN-LIST-POL
               MOVE SPACES            TO MIR-PAC-DRW-IDT-NUM-G
               MOVE SPACES            TO MIR-PAC-DRW-SEQ-NUM-G
      *MIR-BTOT-T
               MOVE SPACES            TO MIR-PAC-DRW-TOT-AMT-G
               MOVE SPACES            TO MIR-PAC-DRW-STAT-CD-G
               MOVE SPACES            TO MIR-PAC-DRW-CREAT-CD-G
               MOVE SPACES            TO MIR-PAC-DRW-RETRN-CD-G
010418         MOVE SPACES            TO MIR-SBSDRY-CO-ID-G
           ELSE
      *BTOT2
               MOVE SPACES            TO MIR-PAC-DRW-STAT-CD-G
               MOVE SPACES            TO MIR-PAC-DRW-CREAT-CD
               MOVE SPACES            TO MIR-PAC-DRW-RETRN-CD
               MOVE SPACES            TO MIR-POL-ID-SFX-G
               MOVE SPACES            TO MIR-PAC-DRWD-DUE-DT-G
               MOVE SPACES            TO MIR-PAC-DRWD-STAT-CD-G
      *MIR-DRAWN-T
               MOVE SPACES            TO MIR-PAC-DRW-TOT-AMT-G
               MOVE SPACES            TO MIR-PAC-DRWD-MPREM-AMT-G
               MOVE SPACES            TO MIR-PAC-DRWD-LOAN-AMT-G
               MOVE SPACES            TO MIR-PAC-DRWD-SNDRY-AMT-G
               MOVE SPACES            TO MIR-PAC-DRWD-SUSP-AMT-G
               MOVE SPACES            TO MIR-PAC-DRWD-REDRW-IND-G
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *-------------------------
       9200-MOVE-PDRW-TO-SCREEN.
      *-------------------------

           MOVE RPDRW-BNK-ID          TO MIR-BNK-ID.
           MOVE RPDRW-BNK-BR-ID       TO MIR-BNK-BR-ID.
           MOVE RPDRW-BNK-ACCT-ID     TO MIR-BNK-ACCT-ID.
           MOVE RPDRW-PAC-DRW-DT      TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-PAC-DRW-IDT-NUM.

020874*    COMPUTE WS-PIC-999
020874*          = 1000
020874*          - RPDRW-PAC-DRW-SEQ-NUM.

020874*    MOVE WS-PIC-999            TO MIR-PAC-DRW-SEQ-NUM.
020874     COMPUTE L0290-INPUT-V00
020874            = 1000
020874            - RPDRW-PAC-DRW-SEQ-NUM.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-PAC-DRW-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-PAC-DRW-SEQ-NUM.
010418     MOVE RPDRW-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID.

008455*    MOVE RPDRW-PAC-DRW-TOT-AMT      TO DISPLAY-NUMBER-9-2.
008455*    MOVE DISPLAY-NUMBER-9-2         TO MIR-PAC-DRW-TOT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RPDRW-PAC-DRW-TOT-AMT * 100.
020874     MOVE RPDRW-PAC-DRW-TOT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
      *BTOT2
008455     MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRW-TOT-AMT.

           MOVE RPDRW-PAC-DRW-STAT-CD TO MIR-PAC-DRW-STAT-CD.
           MOVE RPDRW-PAC-DRW-CREAT-CD          TO MIR-PAC-DRW-CREAT-CD.
           MOVE RPDRW-PAC-DRW-RETRN-CD          TO MIR-PAC-DRW-RETRN-CD.
020467     MOVE RPDRW-PAC-DRW-COLCT-CD TO MIR-PAC-DRW-COLCT-CD.

       9200-MOVE-PDRW-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9220-DETAIL-LINE-SCREEN-2.
      *--------------------------

           MOVE RPDRD-POL-ID-SFX      TO MIR-POL-ID-SFX-T (I).
           MOVE RPDRD-POL-ID-BASE     TO MIR-POL-ID-BASE-T (I).
           MOVE RPDRD-PAC-DRWD-DUE-DT TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-PAC-DRWD-DUE-DT-T (I).

      *
      * IF A SYSTEM GENERATED PAC DRAW TOTAL IS ZERO
      * IT IS ASSUMED TO BE A PRENOTE, SO THE 'DETAIL TOTALS'
      * ARE SET TO ZERO TO MATCH THE PAC REGISTER
      *
           IF  RPDRW-PAC-DRW-CREAT-SYSTEM
           AND RPDRW-PAC-DRW-TOT-AMT       = ZERO
           AND RPDRW-PAC-DRW-STAT-ACTIVE
008455*        MOVE ZEROES                 TO DISPLAY-NUMBER-S-7-2
008455         MOVE ZEROES                 TO L0290-INPUT-NUMBER
           ELSE
008455*        COMPUTE DISPLAY-NUMBER-S-7-2
008455*              = RPDRD-PAC-DRWD-MPREM-AMT
008455*              + RPDRD-PAC-DRWD-LOAN-AMT
008455*              + RPDRD-PAC-DRWD-SNDRY-AMT
008455*              - RPDRD-PAC-DRWD-SUSP-AMT
018258*        COMPUTE L0290-INPUT-NUMBER
018258*              = RPDRD-PAC-DRWD-MPREM-AMT * 100
018258*              + RPDRD-PAC-DRWD-LOAN-AMT  * 100
018258*              + RPDRD-PAC-DRWD-SNDRY-AMT * 100
018258*              - RPDRD-PAC-DRWD-SUSP-AMT  * 100
018258         IF  RPDRD-PAC-DRWD-SUSP-AMT > ZERO
020874*            COMPUTE L0290-INPUT-NUMBER
020874*                  = RPDRD-PAC-DRWD-MPREM-AMT * 100
020874*                  + RPDRD-PAC-DRWD-LOAN-AMT  * 100
020874*                  + RPDRD-PAC-DRWD-SNDRY-AMT * 100
020874*                  - RPDRD-PAC-DRWD-SUSP-AMT  * 100
020874            COMPUTE L0290-INPUT-V02
020874                   = (RPDRD-PAC-DRWD-MPREM-AMT
020874                   + RPDRD-PAC-DRWD-LOAN-AMT
020874                   + RPDRD-PAC-DRWD-SNDRY-AMT
020874                   - RPDRD-PAC-DRWD-SUSP-AMT)
018258         ELSE
020874*            COMPUTE L0290-INPUT-NUMBER
020874*                  = RPDRD-PAC-DRWD-MPREM-AMT * 100
020874*                  + RPDRD-PAC-DRWD-LOAN-AMT  * 100
020874*                  + RPDRD-PAC-DRWD-SNDRY-AMT * 100
020874*                  + RPDRD-PAC-DRWD-SUSP-AMT  * 100
020874             COMPUTE L0290-INPUT-V02
020874                   = (RPDRD-PAC-DRWD-MPREM-AMT
020874                   + RPDRD-PAC-DRWD-LOAN-AMT
020874                   + RPDRD-PAC-DRWD-SNDRY-AMT
020874                   + RPDRD-PAC-DRWD-SUSP-AMT)
018258         END-IF
           END-IF.

008455*    MOVE DISPLAY-NUMBER-S-7-2       TO MIR-PAC-DRW-TOT-AMT-T(I).
      *MIR-DRAWN-T
008455     MOVE 2                     TO L0290-PRECISION.
008455     SET L0290-SIGN-DISPLAY          TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY      TO TRUE.
008455     MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRW-TOT-AMT-T (I).

           MOVE RPDRD-PAC-DRWD-STAT-CD   TO MIR-PAC-DRWD-STAT-CD-T  (I).

008455*    MOVE RPDRD-PAC-DRWD-MPREM-AMT   TO DISPLAY-NUMBER-7-2.
008455*    MOVE DISPLAY-NUMBER-7-2     TO MIR-PAC-DRWD-MPREM-AMT-T (I).
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RPDRD-PAC-DRWD-MPREM-AMT   * 100.
020874     MOVE RPDRD-PAC-DRWD-MPREM-AMT       TO L0290-INPUT-V02.
008455     MOVE 2                              TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PAC-DRWD-MPREM-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRWD-MPREM-AMT-T (I).

008455*    MOVE RPDRD-PAC-DRWD-LOAN-AMT    TO DISPLAY-NUMBER-5-2.
008455*    MOVE DISPLAY-NUMBER-5-2     TO MIR-PAC-DRWD-LOAN-AMT-T (I).
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RPDRD-PAC-DRWD-LOAN-AMT    *  100.
020874     MOVE RPDRD-PAC-DRWD-LOAN-AMT       TO L0290-INPUT-V02.
008455     MOVE 2                             TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PAC-DRWD-LOAN-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRWD-LOAN-AMT-T (I).

008455*    MOVE RPDRD-PAC-DRWD-SNDRY-AMT   TO DISPLAY-NUMBER-7-2.
008455*    MOVE DISPLAY-NUMBER-7-2    TO MIR-PAC-DRWD-SNDRY-AMT-T (I).
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*        RPDRD-PAC-DRWD-SNDRY-AMT   *  100.
020874     MOVE RPDRD-PAC-DRWD-SNDRY-AMT       TO L0290-INPUT-V02.
008455     MOVE 2                              TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PAC-DRWD-SNDRY-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRWD-SNDRY-AMT-T (I).

008455*    MOVE RPDRD-PAC-DRWD-SUSP-AMT    TO DISPLAY-NUMBER-S-7-2.
008455*    MOVE DISPLAY-NUMBER-S-7-2   TO MIR-PAC-DRWD-SUSP-AMT-T (I).
018258     IF  RPDRD-PAC-DRWD-SUSP-AMT > ZERO
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RPDRD-PAC-DRWD-SUSP-AMT    *  100
020874     MOVE RPDRD-PAC-DRWD-SUSP-AMT      TO L0290-INPUT-V02
018258     ELSE
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RPDRD-PAC-DRWD-SUSP-AMT  * -100
020874         COMPUTE L0290-INPUT-V02  =
020874              RPDRD-PAC-DRWD-SUSP-AMT  * -1
018258     END-IF.
018258*    COMPUTE L0290-INPUT-NUMBER =
018258*         RPDRD-PAC-DRWD-SUSP-AMT    *  100.
020874     MOVE RPDRD-PAC-DRWD-SUSP-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
008455     SET L0290-SIGN-DISPLAY          TO TRUE.
008455     SET L0290-SIGN-POS-DISPLAY      TO TRUE.
008455     MOVE LENGTH OF MIR-PAC-DRWD-SUSP-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PAC-DRWD-SUSP-AMT-T  (I).

           MOVE RPDRD-PAC-DRWD-REDRW-IND
                                      TO MIR-PAC-DRWD-REDRW-IND-T  (I).

       9220-DETAIL-LINE-SCREEN-2-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1651-0000-INIT-PARM-INFO
025970         THRU 1651-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5091-0000-INIT-PARM-INFO
025970         THRU 5091-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
038204     PERFORM  0183-0000-INIT-PARM-INFO
038204         THRU 0183-0000-INIT-PARM-INFO-X.
038204
038204     PERFORM  2625-0000-INIT-PARM-INFO
038204         THRU 2625-0000-INIT-PARM-INFO-X.
038204
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                       TO WWKDT-WORK-FIELDS.
025970     SET WS-MAX-DETAILS-SCREEN-1-DFLT  TO TRUE.
025970     SET WS-MAX-DETAILS-SCREEN-2-DFLT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT           TO TRUE.
025970     SET HOLD-RUN-ID-DEFAULT           TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY BNKA
014221                         '$VAR2' BY 'BNKA'.

013578*COPY XCPS2510.
      /
038204 COPY CCPPPTD.
038204/
018764*COPY CCCL0289.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY CCPL0289.
016503 COPY CCPS0289.
      /
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108 COPY CCPS0985.
016108/
018764*COPY CCCL1651.
018764 COPY CCPL1651.
       COPY CCPS1651.
      /
018764*COPY CCCL5091.
018764 COPY CCPL5091.
       COPY CCPS5091.
      /
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.
      /
       COPY CCPSPGA.
      /
       COPY NCPPCVGS.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
014221/
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
025970 COPY XCPS1680.
005409 COPY XCPL1680.
      /
038204 COPY CCPS0183.
038204 COPY CCPL0183.
038204 COPY CCPS2625.
038204 COPY CCPL2625.
038204/
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
014221 COPY CCPNBNKA.
014221 COPY CCPUBNKA.
014221/
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPAPDRD.
       COPY CCPBPDRD.
       COPY CCPCPDRD.
       COPY CCPNPDRD.
       COPY CCPUPDRD.
       COPY CCPXPDRD.
      /
       COPY CCPAPDRW.
       COPY CCPBPDRW.
       COPY CCPCPDRW.
       COPY CCPNPDRW.
       COPY CCPUPDRW.
       COPY CCPXPDRW.
      /
010418 COPY CCPBPDRS.
016537*COPY CCPNPDRS.
010418/
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
013578*COPY XCCL2510.
      *****************************************************************
      **                 END OF PROGRAM CSOM5090                     **
      *****************************************************************
