      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2810.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2810                                         **
      **  REMARKS:  RETRIEVE PROCESS DRIVER FOR THE SPECIFIC         **
      **            ROLLOVER DESTINATION INSTRUCTIONS                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2810'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '2810'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '2810'.
025970     05  WS-MAX-LINES                 PIC 9(02).
025970         88  WS-MAX-LINES-DEFAULT     VALUE 10.
025970*    05  WS-MAX-LINES                 PIC 9(02)
025970*                                     VALUE 10.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '2810'.
           05  WS-SUB                       PIC S9(03) COMP-3.
           05  WS-CVG-NUM                   PIC S9(02).
           05  WS-CF-EFF-DT                 PIC X(10).
           05  WS-CF-SEQ-NUM                PIC S9(03) COMP-3.
           05  WS-POL-PAYO-AMT              PIC S9(13)V9(02)
                                            COMP-3.
           05  WS-POL-PAYO-NUM              PIC S9(05) COMP-3.
           05  WS-HOLD-COVNO                PIC 9(02).
           05  WS-HOLD-COVNO-R              REDEFINES
               WS-HOLD-COVNO                PIC X(02).               


       COPY XCWLCOMM REPLACING '$VAR1' BY '2810'.
           15  LCOMM-OLD-CDSI               OCCURS 10.
               20  LCOMM-CDI-ALLOC-AMT      PIC S9(13)V9(02)
                                            COMP-3.
               20  LCOMM-DPOS-TRM-MO-DUR    PIC X(03).
               20  LCOMM-DPOS-TRM-DY-DUR    PIC X(03).
               20  LCOMM-CDI-ALLOC-NUM      PIC S9(03)
                                            COMP-3.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWCVGS.
      /
       COPY CCWWINDX.
      /
       COPY CCWWLOCK.
      /
       COPY XCWWWKDT.
      /
       COPY XCWWCVGM.
026057 COPY CCWWIHSD.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRCDSI.
       COPY CCFWCDSI.
      /
       COPY CCFRCFLW.
       COPY CCFWCFLW.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
       COPY CCFRPOLP.
       COPY CCFWPOLP.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
020478 COPY CCWL2626.
       COPY CCWLPGA.
      /
       COPY CCWL5400.
       COPY CCWL6530.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2810.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 2000-PROCESS-RETRIEVE
                       THRU 2000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2810'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       2000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  COMM-3000-DELETE-TWRK
               THRU COMM-3000-DELETE-TWRK-X.

           INITIALIZE LCOMM-WORK-AREA.

           PERFORM  3200-READ-POLP
               THRU 3200-READ-POLP-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  3400-LOAD-CDSI
               THRU 3400-LOAD-CDSI-X.

           PERFORM  9250-MOVE-RECORD-TO-SCREEN2
               THRU 9250-MOVE-RECORD-TO-SCREEN2-X.

           PERFORM  3500-FIND-ORIG-DEPOSIT
               THRU 3500-FIND-ORIG-DEPOSIT-X.

           PERFORM  9260-MOVE-RECORD-TO-SCREEN3
               THRU 9260-MOVE-RECORD-TO-SCREEN3-X.

           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.

      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: POLICY NOT ON FILE
               MOVE 'CS28100001'       TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           IF WS-HOLD-COVNO             > RPOL-POL-CVG-REC-CTR-N
      * MSG:  COVNO (@1) NOT FOUND
               MOVE 'CS28100013'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  NOT WCVGS-CVG-CF-TYP-GIA (WS-CVG-NUM)
           AND NOT WCVGS-CVG-CF-TYP-EIA (WS-CVG-NUM)
      *MSG: RETRIEVE IS ONLY ALLOWED FOR GIA AND EIA COVERAGE
               MOVE 'CS28100002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.


026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CF-EFF-DT             TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
026057     END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-POL-XFER-INQ      TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           MOVE MIR-POL-ID             TO WCFLW-POL-ID.
           MOVE WS-CVG-NUM             TO WCFLW-CVG-NUM-N.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG-NUM)
                                       TO WCFLW-CF-TYP-CD.
           MOVE WS-CF-EFF-DT           TO WCFLW-CF-EFF-DT.
           MOVE WS-CF-SEQ-NUM          TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF  WCFLW-IO-NOT-FOUND
      *MSG: NO CASH FLOW FOUND
               MOVE 'CS28100003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  2600-READ-NEXT-CFLW
               THRU 2600-READ-NEXT-CFLW-X
               UNTIL NOT WCFLW-IO-OK
               OR    RCFLW-NXT-CF-DT  = WWKDT-ZERO-DT.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *---------------------
       2600-READ-NEXT-CFLW.
      *---------------------

           MOVE RCFLW-NXT-CF-DT        TO WCFLW-CF-EFF-DT.
           MOVE RCFLW-NXT-CF-SEQ-NUM-N TO WCFLW-CF-SEQ-NUM-N.
           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

       2600-READ-NEXT-CFLW-X.
           EXIT.

      *---------------
       3200-READ-POLP.
      *---------------

           MOVE RPOL-POL-ID            TO WPOLP-POL-ID.
           MOVE RCFLW-CF-ROLOVR-PAYO-NUM
                                       TO WPOLP-POL-PAYO-NUM.

           PERFORM  POLP-1000-READ
               THRU POLP-1000-READ-X.

           COMPUTE WS-POL-PAYO-NUM     =  100000 - WPOLP-POL-PAYO-NUM.

           IF  NOT WPOLP-IO-OK
      *MSG : PAYOUT RECORD FOR POLICY(@1) PAYOUT(@2) DOES NOT EXIST
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28100004'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3200-READ-POLP-X
           END-IF.

           IF  NOT RPOLP-POL-PAYO-TYP-ROLOVR-PAYO
      *MSG : PAYOUT RECORD TYPE FOR POL(@1) PAYOUT(@2) IS NOT ROLLOVER
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28100005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           MOVE RPOLP-POL-PAYO-AMT     TO WS-POL-PAYO-AMT.

           IF  RPOLP-POL-PAYO-STAT-ERRORS
               PERFORM  3300-CALC-ROLL-AMOUNT
                   THRU 3300-CALC-ROLL-AMOUNT-X
           END-IF.

       3200-READ-POLP-X.
           EXIT.

      *-----------------------
       3300-CALC-ROLL-AMOUNT.
      *-----------------------

           IF  WCVGS-CVG-INT-PAYO-CREDIT-ACCT (WS-CVG-NUM)

               PERFORM  6530-1000-BUILD-PARM-INFO
                   THRU 6530-1000-BUILD-PARM-INFO-X

               MOVE RPOLP-POL-PAYO-EFF-DT
                                       TO L6530-EFF-DT
               MOVE RCFLW-CF-EFF-DT    TO L6530-CF-DT
               MOVE RCFLW-CF-SEQ-NUM-N TO L6530-CF-SEQ-NUM
               MOVE WS-CVG-NUM         TO L6530-CVG
               SET L6530-CALC-MKTVAL-ADJ-NOT-REQD
                                       TO TRUE

               PERFORM  6530-3000-CALC-ACUM-VALU-CF
                   THRU 6530-3000-CALC-ACUM-VALU-CF-X

               IF  L6530-RETRN-OK
                   MOVE L6530-CF-ACUM-VALU-AMT
                                       TO WS-POL-PAYO-AMT
               END-IF
           ELSE
               COMPUTE  WS-POL-PAYO-AMT = RCFLW-CF-FND-BAL-AMT
                                        - RCFLW-CF-ACUM-INT-AMT
           END-IF.

       3300-CALC-ROLL-AMOUNT-X.
           EXIT.

      *---------------
       3400-LOAD-CDSI.
      *---------------

            PERFORM  8000-BUILD-CDSI-KEY
                THRU 8000-BUILD-CDSI-KEY-X.

            PERFORM  CDSI-1000-BROWSE
                THRU CDSI-1000-BROWSE-X.

            PERFORM  CDSI-2000-READ-NEXT
                THRU CDSI-2000-READ-NEXT-X.

            PERFORM  3450-MOVE-CDSI-TO-MIR
                THRU 3450-MOVE-CDSI-TO-MIR-X
                VARYING WS-SUB FROM 1 BY 1
                UNTIL   WS-SUB > WS-MAX-LINES
                OR NOT WCDSI-IO-OK.

            PERFORM  CDSI-3000-END-BROWSE
                THRU CDSI-3000-END-BROWSE-X.

       3400-LOAD-CDSI-X.
           EXIT.

      *-----------------------
       3450-MOVE-CDSI-TO-MIR.
      *-----------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE RCDSI-CDI-ALLOC-AMT    TO LCOMM-CDI-ALLOC-AMT
                                          (WS-SUB).
           MOVE RCDSI-DPOS-TRM-MO-DUR  TO LCOMM-DPOS-TRM-MO-DUR
                                          (WS-SUB).
           MOVE RCDSI-DPOS-TRM-DY-DUR  TO LCOMM-DPOS-TRM-DY-DUR
                                          (WS-SUB).
           MOVE RCDSI-CDI-ALLOC-NUM    TO LCOMM-CDI-ALLOC-NUM
                                          (WS-SUB).

           PERFORM  CDSI-2000-READ-NEXT
               THRU CDSI-2000-READ-NEXT-X.

       3450-MOVE-CDSI-TO-MIR-X.
           EXIT.

      *-----------------------
       3500-FIND-ORIG-DEPOSIT.
      *-----------------------

           MOVE RCFLW-PAYO-CLUST-CF-DT TO WCFLW-CF-EFF-DT.
           MOVE RCFLW-CLUST-CF-SEQ-NUM TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

       3500-FIND-ORIG-DEPOSIT-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           IF  MIR-POL-ID = SPACE
      *MSG: THE POLICY ID MUST BE ENTERED
               MOVE 'CS28100006'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  MIR-CVG-NUM = SPACE
      *MSG: THE COVERAGE NUMBER MUST BE ENTERED
               MOVE 'CS28100007'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
               SET L0280-SPACES-PERMITTED
                                       TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CVG-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CVG-NUM        TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
               AND L0280-OUTPUT-V00 > ZERO
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CVG-NUM
               ELSE
      *MSG: COVERAGE NUMBER IS INVALID
                   MOVE 'CS28100008'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           MOVE MIR-CVG-NUM            TO WS-HOLD-COVNO-R.

           IF WS-HOLD-COVNO             > WCVGM-MAX-WCVGS-NUM
      * MSG:  COVERAGE NUMBER MUST BE 2 DIGITS BETWEEN 01 AND 20
               MOVE 'CS28100014'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           IF  MIR-CF-EFF-DT = SPACE
      *MSG: THE CASH FLOW EFFECTIVE DATE MUST BE ENTERED
               MOVE 'CS28100009'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               MOVE MIR-CF-EFF-DT      TO L1640-EXTERNAL-DATE
               PERFORM  1640-7000-MIR-TO-INT
                   THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-RETRN-OK
                   MOVE L1640-INTERNAL-DATE
                                       TO WS-CF-EFF-DT
               ELSE
      *MSG: CASH FLOW EFFECTIVE DATE IS INVALID
                   MOVE 'CS28100010'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           IF  MIR-CF-SEQ-NUM = SPACE
      *MSG: THE CASH FLOW SEQUENCE NUMBER MUST BE ENTERED
               MOVE 'CS28100011'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               SET L0280-SPACES-PERMITTED   TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CF-SEQ-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CF-SEQ-NUM     TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CF-SEQ-NUM
               ELSE
      *MSG: CASH FLOW SEQUENCE NUMBER IS INVALID
                   MOVE 'CS28100012'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      *--------------------
       8000-BUILD-CDSI-KEY.
      *--------------------

           MOVE LOW-VALUES             TO WCDSI-KEY.
           MOVE RPOL-POL-ID            TO WCDSI-POL-ID.
           SET  WCDSI-CDI-TYP-ROLOVR-PAYO
                                       TO TRUE.
           MOVE RPOLP-POL-PAYO-NUM     TO WCDSI-POL-PAYO-NUM.
           MOVE RPOLP-POL-PAYO-EFF-DT
                                       TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WCDSI-CDI-EFF-IDT-NUM.

           MOVE ZERO                   TO WCDSI-CDI-SEQ-NUM.
           MOVE ZERO                   TO WCDSI-CDI-ALLOC-NUM.
           MOVE WCDSI-KEY              TO WCDSI-ENDBR-KEY.
           MOVE +9999999               TO WCDSI-ENDBR-CDI-EFF-IDT-NUM.
           MOVE +999                   TO WCDSI-ENDBR-CDI-SEQ-NUM.
           MOVE +999                   TO WCDSI-ENDBR-CDI-ALLOC-NUM.

       8000-BUILD-CDSI-KEY-X.
           EXIT.

      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE ZERO                   TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-RENW-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PAYO-RENW-AMT.

           MOVE ZERO                   TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PAYO-AMT.

           MOVE SPACE                  TO MIR-POL-PAYO-STAT-CD.

           MOVE ZERO                   TO MIR-POL-PAYO-NUM.
           MOVE SPACE                  TO MIR-CF-ORIG-LF-DT.

           MOVE ZERO                   TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-CLI-TRXN-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CF-CLI-TRXN-AMT.

           MOVE ZERO                   TO MIR-CF-DPOS-TRM-MO-DUR.
           MOVE ZERO                   TO MIR-CF-DPOS-TRM-DY-DUR.

           MOVE ZERO                   TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-INT-PCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CF-INT-PCT.

           PERFORM  9150-INIT-DATA-LINES
               THRU 9150-INIT-DATA-LINES-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LINES.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------
       9150-INIT-DATA-LINES.
      *---------------------

           MOVE SPACES                 TO MIR-DEST-CVG-NUM-T (WS-SUB).
           MOVE ZERO                   TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CDI-GUAR-INT-RT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CDI-GUAR-INT-RT-T
                                          (WS-SUB).

           MOVE ZERO                   TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CDI-ALLOC-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CDI-ALLOC-AMT-T
                                          (WS-SUB).
           MOVE ZEROES                 TO MIR-DPOS-TRM-MO-DUR-T
                                          (WS-SUB).
           MOVE ZEROES                 TO MIR-DPOS-TRM-DY-DUR-T
                                          (WS-SUB).

       9150-INIT-DATA-LINES-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RCDSI-DEST-CVG-NUM     TO MIR-DEST-CVG-NUM-T
                                          (WS-SUB).

           MOVE RCDSI-CDI-GUAR-INT-RT  TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CDI-GUAR-INT-RT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CDI-GUAR-INT-RT-T
                                          (WS-SUB).

           MOVE RCDSI-CDI-ALLOC-AMT    TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CDI-ALLOC-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CDI-ALLOC-AMT-T
                                          (WS-SUB).

           MOVE RCDSI-DPOS-TRM-MO-DUR  TO MIR-DPOS-TRM-MO-DUR-T
                                          (WS-SUB).
           MOVE RCDSI-DPOS-TRM-DY-DUR  TO MIR-DPOS-TRM-DY-DUR-T
                                          (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *----------------------------
       9250-MOVE-RECORD-TO-SCREEN2.
      *----------------------------

           MOVE RPOLP-POL-PAYO-RENW-AMT
                                       TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-RENW-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PAYO-RENW-AMT.

           MOVE WS-POL-PAYO-AMT        TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PAYO-AMT.

           COMPUTE L0290-INPUT-V00     =  100000
                                       -  RPOLP-POL-PAYO-NUM.
           MOVE 0                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-NUM
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PAYO-NUM.

           MOVE RPOLP-POL-PAYO-STAT-CD
                                       TO MIR-POL-PAYO-STAT-CD.

           MOVE RPOLP-POL-PAYO-EFF-DT  TO L1640-INTERNAL-DATE
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X
           MOVE L1640-EXTERNAL-DATE    TO MIR-POL-PAYO-EFF-DT.

           MOVE RCFLW-CF-DPOS-TRM-MO-DUR
                                       TO MIR-CF-DPOS-TRM-MO-DUR.
           MOVE RCFLW-CF-DPOS-TRM-DY-DUR
                                       TO MIR-CF-DPOS-TRM-DY-DUR.

           MOVE RCFLW-CF-INT-PCT       TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-INT-PCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CF-INT-PCT.

       9250-MOVE-RECORD-TO-SCREEN2-X.
           EXIT.

      /
      *----------------------------
       9260-MOVE-RECORD-TO-SCREEN3.
      *----------------------------

           MOVE RCFLW-CF-CLI-TRXN-AMT  TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-CLI-TRXN-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CF-CLI-TRXN-AMT.

           MOVE RCFLW-CF-ORIG-LF-DT    TO L1640-INTERNAL-DATE
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X
           MOVE L1640-EXTERNAL-DATE    TO MIR-CF-ORIG-LF-DT.

           MOVE RCFLW-CF-DPOS-TRM-MO-DUR
                                       TO MIR-CF-DPOS-TRM-MO-DUR.
           MOVE RCFLW-CF-DPOS-TRM-DY-DUR
                                       TO MIR-CF-DPOS-TRM-DY-DUR.

           MOVE RCFLW-CF-INT-PCT       TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-INT-PCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CF-INT-PCT.

       9260-MOVE-RECORD-TO-SCREEN3-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      
      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6530-0000-INIT-PARM-INFO
025970         THRU 6530-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-AREA.

025970     PERFORM  COMM-1000-INITIALIZE
025970         THRU COMM-1000-INITIALIZE-X.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.     
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE. 
025970     SET WS-MAX-LINES-DEFAULT        TO TRUE.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK                TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
      /
       COPY XCPPCOMM.
025970 COPY XCPS1670.
025970 COPY XCPSCOMM.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPSPGA.
      /
       COPY CCPS5400.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
       COPY CCPL5400.
      /
       COPY CCPS6530.
       COPY CCPL6530.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBCDSI.
       COPY CCPNCFLW.
       COPY CCPNCVG.
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNPOLP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM2810                     *
      ****************************************************************
