      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7664.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7664                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE CATX TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016457**  6.2       NEW                                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
025999**  6.6       MESSAGE CORRECTION                               **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7664'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       COPY CCWWINDX.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '7664'.
           05  WS-SUB                                  PIC S9(4) BINARY.
025970*    05  WS-MAX-LIST-LINES                       PIC S9(4) BINARY
025970*                                                VALUE +100.
            05  WS-CATX-DT                             PIC X(10).
            05  WS-CATX-PRCES-DT                       PIC X(10).
            05  WS-CATX-SEQ-NUM                        PIC 9(03).
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES                       PIC S9(4) BINARY.
025970         88 WS-MAX-LIST-LINES-DEFAULT            VALUE +100.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCATZ.
       COPY CCFRCATX.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY CCWL2430.
       COPY CCWL0620.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7664.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783*    SET MIR-RETRN-OK           TO  TRUE.
034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.


           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7664'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------


           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  CATZ-1000-BROWSE-PREV
               THRU CATZ-1000-BROWSE-PREV-X.

           PERFORM  CATZ-2000-READ-PREV
               THRU CATZ-2000-READ-PREV-X.

           IF  WCATZ-IO-EOF
               PERFORM  CATZ-3000-END-BROWSE-PREV
                   THRU CATZ-3000-END-BROWSE-PREV-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2300-SET-UP-NEXT-MIR-KEY
               THRU 2300-SET-UP-NEXT-MIR-KEY-X.

           MOVE ZERO                       TO WS-SUB.
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2200-BROWSE-CATZ
               THRU 2200-BROWSE-CATZ-X
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WCATZ-IO-EOF.

           IF  WCATZ-IO-EOF
      *MSG: 'END OF LIST'
               MOVE 'XS00000015'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS     TO TRUE
               PERFORM  2300-SET-UP-NEXT-MIR-KEY
                   THRU 2300-SET-UP-NEXT-MIR-KEY-X
           END-IF.

           PERFORM  CATZ-3000-END-BROWSE-PREV
               THRU CATZ-3000-END-BROWSE-PREV-X.

           MOVE RPOL-SBSDRY-CO-ID             TO MIR-POL-SBSDRY-CO-ID.

           PERFORM  2400-GET-OWNER-NAME
               THRU 2400-GET-OWNER-NAME-X.

       2000-LIST-X.
           EXIT.

      *----------------
       2100-EDIT-INPUT.
      *----------------

           PERFORM  2110-EDIT-POL-ID
               THRU 2110-EDIT-POL-ID-X.

           PERFORM  2120-EDIT-PRCES-DT
               THRU 2120-EDIT-PRCES-DT-X.

           PERFORM  2130-EDIT-TRXN-DT
               THRU 2130-EDIT-TRXN-DT-X.

           PERFORM  2140-EDIT-SEQ-NUM
               THRU 2140-EDIT-SEQ-NUM-X.

026057     IF  WGLOB-MSG-ERROR-SW > 0
026057         GO TO 2100-EDIT-INPUT-X
026057     END-IF.
026057
026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CATX-DT              TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.

       2100-EDIT-INPUT-X.
           EXIT.

      *------------------
       2110-EDIT-POL-ID.
      *------------------

           MOVE MIR-POL-ID               TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.
           IF  NOT WPOL-IO-OK
      *MSG:  POLICY NOT FOUND
               MOVE 'CS76640001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-POL-ID-X.
           EXIT.

      *-------------------
       2120-EDIT-PRCES-DT.
      *-------------------

           IF  MIR-CATX-PRCES-DT = SPACE
               MOVE WGLOB-PROCESS-DATE   TO WS-CATX-PRCES-DT
               GO TO 2120-EDIT-PRCES-DT-X
           END-IF.

           MOVE MIR-CATX-PRCES-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      ****MSG: INVALID PROCESS DATE
               MOVE 'CS76640002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-CATX-PRCES-DT
           END-IF.

       2120-EDIT-PRCES-DT-X.
           EXIT.

      *------------------
       2130-EDIT-TRXN-DT.
      *------------------

           IF  MIR-CATX-DT = SPACE
               MOVE WGLOB-SYSTEM-DATE-INT  TO WS-CATX-DT
               GO TO 2130-EDIT-TRXN-DT-X
           END-IF.

           MOVE MIR-CATX-DT              TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      ****MSG: INVALID SYSTEM DATE
               MOVE 'CS76640003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-CATX-DT
           END-IF.

       2130-EDIT-TRXN-DT-X.
           EXIT.

      *---------------------
       2140-EDIT-SEQ-NUM.
      *---------------------

           IF  MIR-CATX-SEQ-NUM = SPACE
               MOVE +999                 TO WS-CATX-SEQ-NUM
               GO TO 2140-EDIT-SEQ-NUM-X
           END-IF.

           MOVE MIR-CATX-SEQ-NUM        TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CATX-SEQ-NUM
                                        TO L0280-INPUT-SIZE.
           MOVE 3                       TO L0280-LENGTH.
           MOVE ZERO                    TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           SET L0280-SPACES-PERMITTED   TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00    TO WS-CATX-SEQ-NUM
           ELSE
      ****MSG: INVALID SEQUENCE NUMBER
               MOVE 'CS76640004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       2140-EDIT-SEQ-NUM-X.
           EXIT.

      *-----------------
       2200-BROWSE-CATZ.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  CATZ-2000-READ-PREV
               THRU CATZ-2000-READ-PREV-X.

       2200-BROWSE-CATZ-X.
           EXIT.
      /

      *-------------------------
       2300-SET-UP-NEXT-MIR-KEY.
      *-------------------------

           MOVE RCATX-CATX-PRCES-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CATX-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CATX-PRCES-DT
           END-IF.

           MOVE RCATX-CATX-DT            TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CATX-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CATX-DT
           END-IF.

           MOVE RCATX-CATX-SEQ-NUM        TO WS-CATX-SEQ-NUM.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-CATX-SEQ-NUM.
020874     MOVE WS-CATX-SEQ-NUM          TO L0290-INPUT-V00.
           MOVE ZERO                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-SEQ-NUM
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CATX-SEQ-NUM.

       2300-SET-UP-NEXT-MIR-KEY-X.
           EXIT.

      *--------------------
       2400-GET-OWNER-NAME.
      *--------------------

           MOVE ZERO                  TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE SPACE                 TO MIR-DV-OWN-CLI-NM
               GO TO 2400-GET-OWNER-NAME-X
           END-IF.

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF  L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
           END-IF.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.

       2400-GET-OWNER-NAME-X.
           EXIT.


      *----------------
       7000-BUILD-KEYS.
      *----------------


           MOVE MIR-POL-ID               TO WCATZ-POL-ID.
           MOVE WS-CATX-PRCES-DT         TO WCATZ-CATX-PRCES-DT.
           MOVE WS-CATX-DT               TO WCATZ-CATX-DT.
           MOVE WS-CATX-SEQ-NUM          TO WCATZ-CATX-SEQ-NUM.

           MOVE WCATZ-KEY            TO WCATZ-ENDBR-KEY.
           MOVE WWKDT-LOW-DT         TO WCATZ-ENDBR-CATX-PRCES-DT.
           MOVE WWKDT-LOW-DT         TO WCATZ-ENDBR-CATX-DT.
           MOVE ZERO                 TO WCATZ-ENDBR-CATX-SEQ-NUM.


       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           ADD +1                        TO WS-SUB.

           IF  WS-SUB > WS-MAX-LIST-LINES
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CDN-OTHR-INCM-AMT * 100.
020874     MOVE RCATX-CDN-OTHR-INCM-AMT  TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CDN-OTHR-INCM-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
           TO MIR-CDN-OTHR-INCM-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-CDN-INT-AMT * 100.
020874     MOVE RCATX-CATX-CDN-INT-AMT   TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-CDN-INT-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
           TO MIR-CATX-CDN-INT-AMT-T (WS-SUB).

           MOVE RCATX-CATX-PRCES-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CATX-PRCES-DT-T (WS-SUB)
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CATX-PRCES-DT-T (WS-SUB)
           END-IF.

           MOVE RCATX-CATX-DT            TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CATX-DT-T (WS-SUB)
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CATX-DT-T (WS-SUB)
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = RCATX-CATX-SEQ-NUM.
020874     MOVE RCATX-CATX-SEQ-NUM       TO L0290-INPUT-V00.
           MOVE +0                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CATX-SEQ-NUM-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
           TO MIR-CATX-SEQ-NUM-T (WS-SUB).

           MOVE RCATX-CATX-STAT-CD
           TO MIR-CATX-STAT-CD-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.

025970 COPY XCPS1670.
025970 COPY CCPS0620.
       COPY CCPL0620.

025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.

       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPVCATZ.
      /
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7664
      *****************************************************************
