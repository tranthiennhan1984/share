      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3100.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3100                                         **
      **  REMARKS:  ACTN & ACNR TABLE MAINTENANCE SCREEN.            **
      **            THIS PROGRAM ALLOWS THE USER TO BROWSE, MODIFY,  **
      **            ADD, AND DELETE ACTN & ACNR TABLE RECORDS.       **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010304**  5.6       ORIGINAL                                         **
012137**  5.6V      ADDED ACTN TABLE VALUES                          **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
013585**  5.6A      ADD ACTIVITY TYPE 'CPAYN'                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
013693**  6.2       ADD CLIENT ADDRESS CHANGE (CLCHG)                **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEANUP                                     **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018770**  6.3       PCR - ALLOWABLE VALUE EDIT                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3100'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      /
       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           05  TRANSACTION-NAME            PIC X(04)  VALUE 'ACTN'.
025970         88  TRANSACTION-NAME-DEFAULT           VALUE 'ACTN'.
025970     05  WS-MAX-BROWSE-LINES         PIC S9(04)
025970                                     BINARY  VALUE +12.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT     VALUE +12.
025970     05  WS-MAX-CRUD-LINES           PIC S9(04)
025970                                     BINARY  VALUE +10.
025970         88  WS-MAX-CRUD-LINES-DEFAULT       VALUE +10.
025970     05  WS-TWRK-KEY                 PIC X(04) VALUE '0830'.
025970         88  WS-TWRK-KEY-DEFAULT               VALUE '0830'.

       01  WS-MISC-WORK-FIELDS.

           05  WS-PIC-9-3                  PIC 9(03).
           05  WS-PIC-X-3                  REDEFINES
               WS-PIC-9-3                  PIC X(03).
016548*    05  WS-MAX-BROWSE-LINES         PIC S9(04)  COMP  VALUE +12.
025970*    05  WS-MAX-BROWSE-LINES         PIC S9(04)
025970*                                    BINARY  VALUE +12.
016548*    05  WS-MAX-CRUD-LINES           PIC S9(04)  COMP  VALUE +10.
025970*    05  WS-MAX-CRUD-LINES           PIC S9(04)
025970*                                    BINARY  VALUE +10.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-CREATE       VALUE '0831'.
               88  WS-BUS-FCN-RETRIEVE     VALUE '0830'.
               88  WS-BUS-FCN-UPDATE       VALUE '0832'.
               88  WS-BUS-FCN-DELETE       VALUE '0833'.
               88  WS-BUS-FCN-LIST         VALUE '0834'.
025970*    05  WS-TWRK-KEY                 PIC X(04) VALUE '0830'.
           05  HOLD-FORCE                  PIC X.
           05  HOLD-ENTER                  PIC X.

       01  WS-SUBSCRIPTS.
016548*    05  LINE-SUB                    PIC S9(04)  COMP.
016548     05  LINE-SUB                    PIC S9(04)  BINARY.
016548*    05  WACNR-SUB                   PIC S9(04)  COMP.
016548     05  WACNR-SUB                   PIC S9(04)  BINARY.
016548*    05  WS-SUB                      PIC S9(04)  COMP.
016548     05  WS-SUB                      PIC S9(04)  BINARY.

       01  WS-VALUE-EDIT                   PIC X(13).
013693*    88  WS-VALID-ACTIVITY-TYPE       VALUES 'NFONT' 'PRMCH'
013693*                                            'LINTC' 'EREPL'
013693*                                            'ANNIV' 'ANUNT'
013693*                                            'BILNO' 'REMNO'
013693*                                            'LINCT' 'CVANT'
013693*                                            'DEP'   'DRV'
013693*                                            'ADM'   'ARV'
013693*                                            'INP'   'IRV'
013693*                                            'SUR'   'SRV'
013693*                                            'LON'   'LNV'
013693*                                            'LIN'   'LIV'
013693*                                            'LNR'   'LRV'
013693*                                            'TRI'   'TRV'
013693*                                            'DT'    'RD'
013693*                                            'LPS'   'RLP'
013693*                                            'NTK'   'RNT'
013693*                                            'PO'    'POV'
013693*                                            'MON'   'MNV'
013585*                                            'MET'   'MEV'.
013693*                                            'MET'   'MEV'
013693*                                            'PAYN'.
013693*    88  WS-VALID-RECIPIENT-CODE      VALUES 'AA' 'AB' 'AP' 'DA'
013693*                                            'D1' 'D2' 'L ' 'OA'
013693*                                            'OC' 'OP' 'PA' 'P1'
013693*                                            'P2' 'P3' 'P4' 'P5'
013693*                                            'P6' 'P7' 'P8' 'P9'
013693*                                            'RC' 'S ' 'T ' 'E '
013693*                                            'P '.
           88  WS-VALID-OWNER-RECIPIENT     VALUES 'OA' 'OC' 'OP'.

       01  WS-OLD-RECIPIENT-TABLE.
           05  WS-OLD-RECIPIENT-REC OCCURS 10 TIMES.
               10  WS-OLD-RECIP            PIC X(02).
023447*        10  WS-OLD-DOCUM            PIC X(05).
023447         10  WS-OLD-DOCUM            PIC X(30).
               10  WS-OLD-REGCD            PIC X(02).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
014035*COPY XCWWWKDT.
      /
       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWACNR.
       COPY CCFRACNR.
      /
       COPY CCFWACTN.
       COPY CCFRACTN.
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWSCOM.
       COPY CCFRSCOM.
      /
018770*COPY XCFWDMAD.
018770*COPY XCFRDMAD.
018770*
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
014035*COPY XCWLDTLK.
      /
       COPY XCWL0280.
020874 COPY XCWL0290.       
014221 COPY XCWL8090.
018770 COPY XCWL8960.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
014035*COPY CCWLPGA.
      /
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3100.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      ***************
       0000-MAINLINE.
      ***************
      *
026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.
      *
           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.
      *
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.
      *
026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.
      *
       0000-MAINLINE-X.
           EXIT.
      *
      /
      **********************
       2000-PROCESS-REQUEST.
      **********************
      *
025970*    SET  MIR-RETRN-OK      TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.
      *
           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *
      *  PERFORM THE REQUIRED PROCESSING BASED ON
      *  THE TRANSACTION CODE ENTERED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************

           PERFORM 9800-INIT-CRUD-LINES
              THRU 9800-INIT-CRUD-LINES-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES.

           PERFORM 8210-BUILD-ACTN-KEY
              THRU 8210-BUILD-ACTN-KEY-X.

014221*    PERFORM ACTN-1000-READ
014221*       THRU ACTN-1000-READ-X.

014221     PERFORM  ACTN-1000-READ-TWRK-TS
014221         THRU ACTN-1000-READ-TWRK-TS-X.

           IF NOT WACTN-IO-OK
      * MSG:   RECORD NOT FOUND - CHECK KEY AND REENTER
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               MOVE WACTN-KEY         TO WGLOB-MSG-PARM(1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      * MSG:   INQUIRY COMPLETE -CONTINUE
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *******************
       3500-PROCESS-LIST.
      *******************

           PERFORM 9700-INIT-BROWSE-LINES
              THRU 9700-INIT-BROWSE-LINES-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-BROWSE-LINES.

           PERFORM 8110-BUILD-ACTN-BROWSE-KEY
              THRU 8110-BUILD-ACTN-BROWSE-KEY-X.

           PERFORM ACTN-1000-BROWSE
              THRU ACTN-1000-BROWSE-X.

           PERFORM ACTN-2000-READ-NEXT
              THRU ACTN-2000-READ-NEXT-X

           IF NOT WACTN-IO-OK
      * MSG:   NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               MOVE WACTN-KEY         TO WGLOB-MSG-PARM(1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM ACTN-3000-END-BROWSE
                  THRU ACTN-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           IF WACTN-IO-OK
               PERFORM 3600-READ-AND-DISPLAY-LOOP
                  THRU 3600-READ-AND-DISPLAY-LOOP-X
               VARYING LINE-SUB FROM 1 BY 1
                 UNTIL LINE-SUB > WS-MAX-BROWSE-LINES
                    OR WACTN-IO-EOF
           END-IF.

           IF WACTN-IO-EOF
      * MSG:   ** END OF LIST **
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
           ELSE
      * MSG:   TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               MOVE RACTN-LOC-GR-ID   TO MIR-LOC-GR-ID
               MOVE RACTN-ACTN-TYP-CD TO MIR-ACTN-TYP-CD
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM ACTN-3000-END-BROWSE
              THRU ACTN-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      ****************************
       3600-READ-AND-DISPLAY-LOOP.
      ****************************

           PERFORM 8120-BUILD-ACNR-BROWSE-KEY
              THRU 8120-BUILD-ACNR-BROWSE-KEY-X.

           PERFORM ACNR-1000-BROWSE
              THRU ACNR-1000-BROWSE-X.

           PERFORM ACNR-2000-READ-NEXT
              THRU ACNR-2000-READ-NEXT-X.

           PERFORM 9110-MOVE-ACTN-TO-SCREEN1
              THRU 9110-MOVE-ACTN-TO-SCREEN1-X.

           IF WACNR-IO-OK
               PERFORM 9120-MOVE-ACNR-TO-SCREEN1
                  THRU 9120-MOVE-ACNR-TO-SCREEN1-X
           ELSE
               PERFORM 9121-MOVE-BLNK-TO-SCREEN1
                  THRU 9121-MOVE-BLNK-TO-SCREEN1-X
           END-IF.

           PERFORM ACNR-3000-END-BROWSE
              THRU ACNR-3000-END-BROWSE-X.

           PERFORM ACTN-2000-READ-NEXT
              THRU ACTN-2000-READ-NEXT-X.

       3600-READ-AND-DISPLAY-LOOP-X.
           EXIT.
      /
      *********************
       4000-PROCESS-CREATE.
      *********************

           PERFORM 9800-INIT-CRUD-LINES
              THRU 9800-INIT-CRUD-LINES-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES.

           PERFORM 8210-BUILD-ACTN-KEY
              THRU 8210-BUILD-ACTN-KEY-X.

           PERFORM ACTN-1000-READ
              THRU ACTN-1000-READ-X.

           IF WACTN-IO-OK
      * MSG:   RECORD (@1) ALREADY EXISTS'
               MOVE WACTN-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM 4010-EDIT-KEY-FIELDS
              THRU 4010-EDIT-KEY-FIELDS-X.

           IF NOT WGLOB-GOOD-RETURN
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM ACTN-1000-CREATE
              THRU ACTN-1000-CREATE-X.

      * MSG: RECORD CREATED - CONTINUE
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM ACTN-1000-WRITE
              THRU ACTN-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM ACTN-1000-CALL-AUDIT
                  THRU ACTN-1000-CALL-AUDIT-X
           END-IF.

014221     PERFORM  ACTN-1000-READ-TWRK-TS
014221         THRU ACTN-1000-READ-TWRK-TS-X.

           PERFORM 9210-MOVE-ACTN-TO-SCREEN2
              THRU 9210-MOVE-ACTN-TO-SCREEN2-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      **********************
       4010-EDIT-KEY-FIELDS.
      **********************

           IF MIR-ACTN-COLCT-ID = SPACES
      * MSG:   ACTIVITY POINTER IS REQUIRED
               MOVE 'CS31000001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.


           MOVE MIR-ACTN-COLCT-ID     TO WEDIT-ETBL-VALU-ID.

           PERFORM  ACTV-1000-EDIT-ACTIV-POINTER
               THRU ACTV-1000-EDIT-ACTIV-POINTER-X

           IF WEDIT-IO-OK
               CONTINUE
           ELSE
      * MSG:   ACTIVITY POINTER MUST BE VALID IN EDIT, TYPE = ACTIV
               MOVE 'CS31000017'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

           IF MIR-SBSDRY-CO-ID = SPACES
      * MSG:   SUB COMPANY ID IS REQUIRED
               MOVE 'CS31000002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

           MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.
           PERFORM  SCOM-2000-READ-INDEX
               THRU SCOM-2000-READ-INDEX-X.
      *
           IF NOT WSCOM-IO-OK
      * MSG:   SUB-COMPANY MUST HAVE SUB-COMPANY PROFILE
               MOVE 'CS31000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

           MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.

           PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
               THRU LCGP-1000-EDIT-LCGP-LOCATION-X

           IF WEDIT-IO-OK
               CONTINUE
           ELSE
      * MSG:   LOCATION GROUP MUST BE VALID IN EDIT, TYPE = LOCGP
               MOVE 'CS31000004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

018770*    MOVE 'ACTN-TYP-CD'         TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE MIR-ACTN-TYP-CD       TO WDMAD-DM-AV-CD.
018770*    MOVE WGLOB-USER-LANG       TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM  DMAD-1000-READ
018770*        THRU DMAD-1000-READ-X.
018770*
013693*    MOVE MIR-ACTN-TYP-CD       TO WS-VALUE-EDIT.
013693*
013693*    IF WS-VALID-ACTIVITY-TYPE
018770*    IF  WDMAD-IO-OK
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770     MOVE 'ACTN-TYP-CD'         TO L8960-AV-TBL-CD.
018770     MOVE MIR-ACTN-TYP-CD       TO L8960-AV-CD.
018770     PERFORM  8960-1000-VALIDATE-CODE
018770         THRU 8960-1000-VALIDATE-CODE-X.
018770
018770     IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      * MSG:   INVALID ACTIVITY TYPE
               MOVE 'CS31000005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.


       4010-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *********************
       5000-PROCESS-UPDATE.
      *********************

           PERFORM 8210-BUILD-ACTN-KEY
              THRU 8210-BUILD-ACTN-KEY-X.

014221*    PERFORM ACTN-1000-READ-FOR-UPDATE
014221*       THRU ACTN-1000-READ-FOR-UPDATE-X.

014221     PERFORM  ACTN-2000-UPDATE-TWRK-TS
014221         THRU ACTN-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'ACTN'                TO WGLOB-MSG-PARM (01)
014221        MOVE WACTN-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF  WACTN-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM ACTN-1000-CALL-AUDIT
                      THRU ACTN-1000-CALL-AUDIT-X
               END-IF
           ELSE
      * MSG:   RECORD NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WACTN-KEY         TO WGLOB-MSG-PARM(1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM 5225-EDIT-DATA-FIELDS
              THRU 5225-EDIT-DATA-FIELDS-X.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM 5275-CROSS-EDITS
                  THRU 5275-CROSS-EDITS-X
               VARYING WS-SUB FROM 1 BY 1
                 UNTIL WS-SUB > WS-MAX-CRUD-LINES
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM 5300-EDIT-ACNR-RECORDS
                  THRU 5300-EDIT-ACNR-RECORDS-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM ACTN-2000-REWRITE
                  THRU ACTN-2000-REWRITE-X
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM ACTN-1000-CALL-AUDIT
                      THRU ACTN-1000-CALL-AUDIT-X
               END-IF
014221         PERFORM  ACTN-1000-READ-TWRK-TS
014221             THRU ACTN-1000-READ-TWRK-TS-X
016537     ELSE
016537         PERFORM  ACTN-3000-UNLOCK
016537             THRU ACTN-3000-UNLOCK-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
               CONTINUE
           ELSE
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

      *MSG:    MAINTENANCE COMPLETE
           MOVE 'XS00000007'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      ***********************
       5225-EDIT-DATA-FIELDS.
      ***********************

           PERFORM 5230-EDIT-LEAD-TIME-MOS
              THRU 5230-EDIT-LEAD-TIME-MOS-X.

           PERFORM 5235-EDIT-LEAD-TIME-DYS
              THRU 5235-EDIT-LEAD-TIME-DYS-X.

           PERFORM 5250-EDIT-LINES
              THRU 5250-EDIT-LINES-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES.

       5225-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *************************
       5230-EDIT-LEAD-TIME-MOS.
      *************************

           IF MIR-ACTN-LEAD-MO-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-ACTN-LEAD-MO-DUR
           END-IF.

           IF (MIR-ACTN-TYP-CD = 'ANNIV'
           OR  MIR-ACTN-TYP-CD = 'EREPL'
           OR  MIR-ACTN-TYP-CD = 'CVANT')
           AND MIR-ACTN-LEAD-MO-DUR NOT = ZEROS
      * MSG: LEAD TIME MONTHS MUST BE ZERO
               MOVE 'CS31000015'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  1                TO WGLOB-RETURN-CODE
               GO TO 5230-EDIT-LEAD-TIME-MOS-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-ACTN-LEAD-MO-DUR  TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-9-3
020874*        MOVE WS-PIC-9-3        TO MIR-ACTN-LEAD-MO-DUR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ACTN-LEAD-MO-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-ACTN-LEAD-MO-DUR
               MOVE L0280-OUTPUT      TO RACTN-ACTN-LEAD-MO-DUR-N
           ELSE
      * MSG: LEAD TIME MONTHS MUST BE NUMERIC - 999
               MOVE 'CS31000006'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  1                TO WGLOB-RETURN-CODE
           END-IF.

       5230-EDIT-LEAD-TIME-MOS-X.
           EXIT.
      /
      *************************
       5235-EDIT-LEAD-TIME-DYS.
      *************************

           IF MIR-ACTN-LEAD-DY-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-ACTN-LEAD-DY-DUR
           END-IF.

           IF (MIR-ACTN-TYP-CD = 'ANNIV'
           OR  MIR-ACTN-TYP-CD = 'EREPL'
           OR  MIR-ACTN-TYP-CD = 'CVANT')
           AND MIR-ACTN-LEAD-DY-DUR NOT = ZEROS
      * MSG: LEAD TIME DAYS MUST BE ZERO
               MOVE 'CS31000016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  1                TO WGLOB-RETURN-CODE
               GO TO 5235-EDIT-LEAD-TIME-DYS-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-ACTN-LEAD-DY-DUR  TO L0280-INPUT-DATA.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-9-3
020874*        MOVE WS-PIC-9-3        TO MIR-ACTN-LEAD-DY-DUR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ACTN-LEAD-DY-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-ACTN-LEAD-DY-DUR
               MOVE L0280-OUTPUT      TO RACTN-ACTN-LEAD-DY-DUR-N
           ELSE
      * MSG: LEAD TIME DAYS MUST BE NUMERIC - 999
               MOVE 'CS31000007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  1                TO WGLOB-RETURN-CODE
           END-IF.

       5235-EDIT-LEAD-TIME-DYS-X.
           EXIT.
      /
      *****************
       5250-EDIT-LINES.
      *****************

           PERFORM 5255-EDIT-RECIPIENT
              THRU 5255-EDIT-RECIPIENT-X.

           PERFORM 5260-EDIT-DOCUMENT
              THRU 5260-EDIT-DOCUMENT-X.

           PERFORM 5265-EDIT-REGISTER
              THRU 5265-EDIT-REGISTER-X.

       5250-EDIT-LINES-X.
           EXIT.
      /
      *********************
       5255-EDIT-RECIPIENT.
      *********************

           IF MIR-ACTN-RECIP-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES           TO MIR-DOC-ID-T (WS-SUB)
               MOVE SPACES           TO MIR-ACTN-RECIP-RPT-CD-T (WS-SUB)
           END-IF.

018770     IF  MIR-ACTN-RECIP-CD-T (WS-SUB) = SPACES
018770     OR  MIR-ACTN-RECIP-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
018770         GO TO 5255-EDIT-RECIPIENT-X
018770     END-IF.
013693*    MOVE MIR-ACTN-RECIP-CD-T (WS-SUB)
013693*                               TO WS-VALUE-EDIT.
013693*
018770*    MOVE 'ACTN-RECIP-CD'       TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE MIR-ACTN-RECIP-CD-T (WS-SUB)
018770*                               TO WDMAD-DM-AV-CD.
018770*    MOVE WGLOB-USER-LANG       TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM  DMAD-1000-READ
018770*        THRU DMAD-1000-READ-X.
018770*
013693*    IF WS-VALID-RECIPIENT-CODE
018770*    IF WDMAD-IO-OK
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
013693     MOVE 'ACTN-RECIP-CD'       TO L8960-AV-TBL-CD.
013693     MOVE MIR-ACTN-RECIP-CD-T (WS-SUB)
013693                                TO L8960-AV-CD.
018770     PERFORM  8960-1000-VALIDATE-CODE
018770         THRU 8960-1000-VALIDATE-CODE-X.
018770
018770     IF  L8960-RETRN-OK
018770*    OR MIR-ACTN-RECIP-CD-T (WS-SUB) = SPACES
018770*    OR MIR-ACTN-RECIP-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               CONTINUE
           ELSE
      * MSG:   INVALID RECIPIENT CODE - REENTER
               MOVE 'CS31000008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

       5255-EDIT-RECIPIENT-X.
           EXIT.
      /
      ********************
       5260-EDIT-DOCUMENT.
      ********************

           IF MIR-DOC-ID-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-DOC-ID-T (WS-SUB)
               GO TO 5260-EDIT-DOCUMENT-X
           END-IF.

           MOVE MIR-DOC-ID-T (WS-SUB) TO WEDIT-ETBL-VALU-ID.


           PERFORM DOCM-1000-EDIT
              THRU DOCM-1000-EDIT-X.

           IF WEDIT-IO-OK
           OR MIR-DOC-ID-T (WS-SUB) = SPACES
               CONTINUE
           ELSE
      * MSG:   DOCUMENT MUST BE VALID IN DOCUMENT DEFAULT MAINT.(DOCM)
               MOVE 'CS31000009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

       5260-EDIT-DOCUMENT-X.
           EXIT.
      /
      ********************
       5265-EDIT-REGISTER.
      ********************

           IF MIR-ACTN-RECIP-RPT-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES           TO MIR-ACTN-RECIP-RPT-CD-T (WS-SUB)
               GO TO 5265-EDIT-REGISTER-X
           END-IF.

           MOVE MIR-ACTN-RECIP-RPT-CD-T (WS-SUB)
                                      TO WEDIT-ETBL-VALU-ID.

           PERFORM ACTR-1000-EDIT
              THRU ACTR-1000-EDIT-X.

           IF WEDIT-IO-OK
           OR MIR-ACTN-RECIP-RPT-CD-T (WS-SUB) = SPACES
               CONTINUE
           ELSE
      * MSG:   INVALID REGISTER CODE - REENTER
               MOVE 'CS31000010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

       5265-EDIT-REGISTER-X.
           EXIT.
      /
      ******************
       5275-CROSS-EDITS.
      ******************

           IF MIR-ACTN-RECIP-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
           OR (MIR-ACTN-RECIP-CD-T (WS-SUB) = SPACES
             AND MIR-DOC-ID-T (WS-SUB) = SPACES
             AND MIR-ACTN-RECIP-RPT-CD-T (WS-SUB) = SPACES)
                GO TO 5275-CROSS-EDITS-X
           END-IF.

           IF  (MIR-ACTN-RECIP-CD-T (WS-SUB) = SPACES)
           AND ((MIR-DOC-ID-T (WS-SUB) NOT = SPACES)
           OR  (MIR-ACTN-RECIP-RPT-CD-T (WS-SUB) NOT = SPACES))
      * MSG:    RECIPIENT CODE REQUIRED
                MOVE 'CS31000011'     TO WGLOB-MSG-REF-INFO
                PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
                IF WGLOB-MSG-SEVRTY-FATAL
                    MOVE 1            TO WGLOB-RETURN-CODE
                END-IF
           END-IF.

           MOVE MIR-ACTN-RECIP-CD-T (WS-SUB)
                                      TO WS-VALUE-EDIT.

           IF  MIR-DOC-ID-T (WS-SUB) NOT = SPACES
           OR (MIR-DOC-ID-T (WS-SUB) = SPACE
             AND WS-VALID-OWNER-RECIPIENT)
                CONTINUE
           ELSE
      * MSG:    DOCUMENT REQUIRED IF RECIPIENT IS NOT OWNER
                MOVE 'CS31000012'     TO WGLOB-MSG-REF-INFO
                PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
                IF WGLOB-MSG-SEVRTY-FATAL
                    MOVE 1            TO WGLOB-RETURN-CODE
                END-IF
           END-IF.

           IF  (MIR-ACTN-RECIP-RPT-CD-T (WS-SUB) NOT = SPACES)
           AND (MIR-DOC-ID-T (WS-SUB) = SPACES)
      * MSG:    DOCUMENT REQUIRED WHEN REGISTER CODE ENTERED
                MOVE 'CS31000013'     TO WGLOB-MSG-REF-INFO
                PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
                IF WGLOB-MSG-SEVRTY-FATAL
                    MOVE 1            TO WGLOB-RETURN-CODE
                END-IF
           END-IF.

       5275-CROSS-EDITS-X.
           EXIT.
      /
      ************************
       5300-EDIT-ACNR-RECORDS.
      ************************

           PERFORM 8220-BUILD-ACNR-KEY
              THRU 8220-BUILD-ACNR-KEY-X.

           PERFORM ACNR-1000-BROWSE
              THRU ACNR-1000-BROWSE-X.

           MOVE SPACES                TO WS-OLD-RECIPIENT-TABLE.

           PERFORM 5310-GET-OLD-RECIPS
              THRU 5310-GET-OLD-RECIPS-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES
             OR WACNR-IO-EOF.

           PERFORM ACNR-3000-END-BROWSE
              THRU ACNR-3000-END-BROWSE-X.

           PERFORM 5320-EDIT-RECIPS-DATA
              THRU 5320-EDIT-RECIPS-DATA-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES.

           PERFORM 5330-FIND-DUPL-RECIPS
              THRU 5330-FIND-DUPL-RECIPS-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES.

           PERFORM 5340-DELETE-OLD-RECIPS
              THRU 5340-DELETE-OLD-RECIPS-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES.

           PERFORM 5350-UPDATE-RECIPS
              THRU 5350-UPDATE-RECIPS-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES.

       5300-EDIT-ACNR-RECORDS-X.
           EXIT.
      /
      *********************
       5310-GET-OLD-RECIPS.
      *********************

           PERFORM ACNR-2000-READ-NEXT
              THRU ACNR-2000-READ-NEXT-X.

           IF WACNR-IO-OK
               MOVE RACNR-ACTN-RECIP-CD
                                      TO WS-OLD-RECIP (WS-SUB)
               MOVE RACNR-DOC-ID      TO WS-OLD-DOCUM (WS-SUB)
               MOVE RACNR-ACTN-RECIP-RPT-CD
                                      TO WS-OLD-REGCD (WS-SUB)
           END-IF.

       5310-GET-OLD-RECIPS-X.
           EXIT.
      /
      ***********************
       5320-EDIT-RECIPS-DATA.
      ***********************

           IF  (MIR-ACTN-RECIP-CD-T (WS-SUB) = SPACES)
           AND (MIR-DOC-ID-T (WS-SUB) = SPACES)
           AND (MIR-ACTN-RECIP-RPT-CD-T (WS-SUB) = SPACES)
           AND (WS-OLD-RECIPIENT-REC (WS-SUB) NOT = SPACES)
                MOVE WS-OLD-RECIP (WS-SUB)
                                      TO MIR-ACTN-RECIP-CD-T (WS-SUB)
                MOVE WS-OLD-DOCUM (WS-SUB)
                                      TO MIR-DOC-ID-T (WS-SUB)
                MOVE WS-OLD-REGCD (WS-SUB)
                                     TO MIR-ACTN-RECIP-RPT-CD-T (WS-SUB)
           END-IF.

       5320-EDIT-RECIPS-DATA-X.
           EXIT.
      /
      ***********************
       5330-FIND-DUPL-RECIPS.
      ***********************

           PERFORM 5331-CHECK-DUPLICATES
              THRU 5331-CHECK-DUPLICATES-X
           VARYING WACNR-SUB FROM WS-SUB BY 1
             UNTIL WACNR-SUB > WS-MAX-CRUD-LINES.

       5330-FIND-DUPL-RECIPS-X.
           EXIT.
      /
      ***********************
       5331-CHECK-DUPLICATES.
      ***********************

           IF WACNR-SUB = WS-SUB
               GO TO 5331-CHECK-DUPLICATES-X
           END-IF.

           IF (MIR-ACTN-RECIP-CD-T (WACNR-SUB) = HIGH-VALUES)
           OR (MIR-ACTN-RECIP-CD-T (WACNR-SUB) = SPACES)
           OR (MIR-ACTN-RECIP-CD-T (WACNR-SUB) = EBLCH-BLANK-FIELD-CHAR)
               GO TO 5331-CHECK-DUPLICATES-X
           END-IF.

           IF MIR-ACTN-RECIP-CD-T (WACNR-SUB) =
                                            MIR-ACTN-RECIP-CD-T (WS-SUB)
      * MSG:   DUPLICATE RECIPIENT ENTERED
               MOVE 'CS31000014'      TO WGLOB-MSG-REF-INFO
               IF MIR-ACTN-RECIP-CD-T (WACNR-SUB) =
                                                WS-OLD-RECIP (WACNR-SUB)
                   MOVE 1             TO WGLOB-RETURN-CODE
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE 1             TO WGLOB-RETURN-CODE
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       5331-CHECK-DUPLICATES-X.
           EXIT.
      /
      ************************
       5340-DELETE-OLD-RECIPS.
      ************************

           IF MIR-ACTN-RECIP-CD-T (WS-SUB) = SPACES
               GO TO 5340-DELETE-OLD-RECIPS-X
           END-IF.

           IF MIR-ACTN-RECIP-CD-T (WS-SUB) NOT = WS-OLD-RECIP (WS-SUB)
               PERFORM 5341-PROCESS-DEL-OLD-RECIPS
                  THRU 5341-PROCESS-DEL-OLD-RECIPS-X
           END-IF.

           IF MIR-ACTN-RECIP-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-ACTN-RECIP-CD-T (WS-SUB)
           END-IF.


       5340-DELETE-OLD-RECIPS-X.
           EXIT.
      /
      *****************************
       5341-PROCESS-DEL-OLD-RECIPS.
      *****************************

           MOVE LOW-VALUES            TO WACNR-KEY.
           MOVE WS-OLD-RECIP (WS-SUB) TO WACNR-ACTN-RECIP-CD.

           PERFORM 8221-BUILD-ACNR-KEY-2
              THRU 8221-BUILD-ACNR-KEY-2-X.

           PERFORM ACNR-1000-READ-FOR-UPDATE
              THRU ACNR-1000-READ-FOR-UPDATE-X.

           IF WACNR-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM ACNR-1000-CALL-AUDIT
                      THRU ACNR-1000-CALL-AUDIT-X
               END-IF
               PERFORM ACNR-1000-DELETE
                  THRU ACNR-1000-DELETE-X
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM ACNR-1000-CALL-AUDIT
                      THRU ACNR-1000-CALL-AUDIT-X
               END-IF
           END-IF.

       5341-PROCESS-DEL-OLD-RECIPS-X.
           EXIT.
      /
      ********************
       5350-UPDATE-RECIPS.
      ********************

           IF MIR-ACTN-RECIP-CD-T (WS-SUB) = SPACE
           OR MIR-ACTN-RECIP-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
           OR MIR-ACTN-RECIP-CD-T (WS-SUB) = HIGH-VALUES
               GO TO 5350-UPDATE-RECIPS-X
           END-IF.

           MOVE LOW-VALUES            TO WACNR-KEY.
           MOVE MIR-ACTN-RECIP-CD-T (WS-SUB)
                                      TO WACNR-ACTN-RECIP-CD.
           PERFORM 8221-BUILD-ACNR-KEY-2
              THRU 8221-BUILD-ACNR-KEY-2-X.
           PERFORM ACNR-1000-READ
              THRU ACNR-1000-READ-X.

           IF WACNR-IO-OK
               IF  RACNR-DOC-ID = MIR-DOC-ID-T (WS-SUB)
               AND RACNR-ACTN-RECIP-RPT-CD =
                   MIR-ACTN-RECIP-RPT-CD-T (WS-SUB)
                    GO TO 5350-UPDATE-RECIPS-X
               END-IF
           END-IF.

           IF WACNR-IO-OK
               PERFORM ACNR-1000-READ-FOR-UPDATE
                  THRU ACNR-1000-READ-FOR-UPDATE-X
               IF WACNR-IO-OK
                   PERFORM 5351-PROCESS-UPDATE-RECIPS
                      THRU 5351-PROCESS-UPDATE-RECIPS-X
                   GO TO 5350-UPDATE-RECIPS-X
               END-IF
           END-IF.

           MOVE MIR-ACTN-RECIP-CD-T (WS-SUB)
                                      TO WACNR-ACTN-RECIP-CD.
           PERFORM ACNR-1000-CREATE
              THRU ACNR-1000-CREATE-X.
           PERFORM 5352-UPDATE-RACNR
              THRU 5352-UPDATE-RACNR-X.
           PERFORM ACNR-1000-WRITE
              THRU ACNR-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM ACNR-1000-CALL-AUDIT
                  THRU ACNR-1000-CALL-AUDIT-X
           END-IF.

       5350-UPDATE-RECIPS-X.
           EXIT.
      /
      ****************************
       5351-PROCESS-UPDATE-RECIPS.
      ****************************

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM ACNR-1000-CALL-AUDIT
                  THRU ACNR-1000-CALL-AUDIT-X
           END-IF.

           PERFORM 5352-UPDATE-RACNR
              THRU 5352-UPDATE-RACNR-X.

           PERFORM ACNR-2000-REWRITE
              THRU ACNR-2000-REWRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM ACNR-1000-CALL-AUDIT
                  THRU ACNR-1000-CALL-AUDIT-X
           END-IF.

       5351-PROCESS-UPDATE-RECIPS-X.
           EXIT.
      /
      *******************
       5352-UPDATE-RACNR.
      *******************

      *    IF MIR-DOC-ID-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
      *        MOVE SPACES TO RACNR-DOC-ID
      *    ELSE
               MOVE MIR-DOC-ID-T (WS-SUB)
                                      TO RACNR-DOC-ID.
      *    END-IF.

      *    IF MIR-ACTN-RECIP-RPT-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
      *        MOVE SPACES TO RACNR-ACTN-RECIP-RPT-CD
      *    ELSE
               MOVE MIR-ACTN-RECIP-RPT-CD-T (WS-SUB)
                                      TO RACNR-ACTN-RECIP-RPT-CD.
      *    END-IF.

       5352-UPDATE-RACNR-X.
           EXIT.
      /
      *********************
       6000-PROCESS-DELETE.
      *********************

           PERFORM 8210-BUILD-ACTN-KEY
              THRU 8210-BUILD-ACTN-KEY-X.

014221*    PERFORM ACTN-1000-READ-FOR-UPDATE
014221*       THRU ACTN-1000-READ-FOR-UPDATE-X.

014221     PERFORM  ACTN-2000-UPDATE-TWRK-TS
014221         THRU ACTN-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'ACTN'                TO WGLOB-MSG-PARM (01)
014221        MOVE WACTN-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WACTN-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM ACTN-1000-CALL-AUDIT
                      THRU ACTN-1000-CALL-AUDIT-X
               END-IF
           ELSE
      * MSG:   RECORD LOST IN DELETE
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WACTN-KEY         TO WGLOB-MSG-PARM(1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

           PERFORM ACTN-1000-DELETE
              THRU ACTN-1000-DELETE-X.

           IF WACTN-IO-OK
      * MSG:   DELETE COMPLETED - CONTINUE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM ACTN-1000-CALL-AUDIT
                      THRU ACTN-1000-CALL-AUDIT-X
               END-IF
           ELSE
      * MSG:   RECORD NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WACTN-KEY         TO WGLOB-MSG-PARM(1)
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9800-INIT-CRUD-LINES
              THRU 9800-INIT-CRUD-LINES-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      ****************************
       8110-BUILD-ACTN-BROWSE-KEY.
      ****************************

           MOVE LOW-VALUES            TO WACTN-KEY.
           MOVE MIR-ACTN-COLCT-ID     TO WACTN-ACTN-COLCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WACTN-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID         TO WACTN-LOC-GR-ID.
           MOVE MIR-ACTN-TYP-CD       TO WACTN-ACTN-TYP-CD.

           MOVE HIGH-VALUES           TO WACTN-ENDBR-KEY.
           MOVE MIR-ACTN-COLCT-ID     TO WACTN-ENDBR-ACTN-COLCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WACTN-ENDBR-SBSDRY-CO-ID.

       8110-BUILD-ACTN-BROWSE-KEY-X.
           EXIT.
      /
      ****************************
       8120-BUILD-ACNR-BROWSE-KEY.
      ****************************

           MOVE LOW-VALUES            TO WACNR-KEY.
           MOVE MIR-ACTN-COLCT-ID     TO WACNR-ACTN-COLCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WACNR-SBSDRY-CO-ID.
           MOVE RACTN-LOC-GR-ID       TO WACNR-LOC-GR-ID.
           MOVE RACTN-ACTN-TYP-CD     TO WACNR-ACTN-TYP-CD.
           MOVE SPACES                TO WACNR-ACTN-RECIP-CD.

           MOVE HIGH-VALUES           TO WACNR-ENDBR-KEY.
           MOVE MIR-ACTN-COLCT-ID     TO WACNR-ENDBR-ACTN-COLCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WACNR-ENDBR-SBSDRY-CO-ID.
           MOVE RACTN-LOC-GR-ID       TO WACNR-ENDBR-LOC-GR-ID.
           MOVE RACTN-ACTN-TYP-CD     TO WACNR-ENDBR-ACTN-TYP-CD.

       8120-BUILD-ACNR-BROWSE-KEY-X.
           EXIT.
      /
      *********************
       8210-BUILD-ACTN-KEY.
      *********************

           MOVE LOW-VALUES            TO WACTN-KEY.
           MOVE MIR-ACTN-COLCT-ID     TO WACTN-ACTN-COLCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WACTN-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID         TO WACTN-LOC-GR-ID.
           MOVE MIR-ACTN-TYP-CD       TO WACTN-ACTN-TYP-CD.

           MOVE HIGH-VALUES           TO WACTN-ENDBR-KEY.
           MOVE WACTN-ACTN-COLCT-ID   TO WACTN-ENDBR-ACTN-COLCT-ID.

       8210-BUILD-ACTN-KEY-X.
           EXIT.
      /
      *********************
       8220-BUILD-ACNR-KEY.
      *********************

           MOVE LOW-VALUES            TO WACNR-KEY.
           MOVE MIR-ACTN-COLCT-ID     TO WACNR-ACTN-COLCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WACNR-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID         TO WACNR-LOC-GR-ID.
           MOVE MIR-ACTN-TYP-CD       TO WACNR-ACTN-TYP-CD.
           MOVE SPACES                TO WACNR-ACTN-RECIP-CD.

           MOVE HIGH-VALUES           TO WACNR-ENDBR-KEY.
           MOVE MIR-ACTN-COLCT-ID     TO WACNR-ENDBR-ACTN-COLCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WACNR-ENDBR-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID         TO WACNR-ENDBR-LOC-GR-ID.
           MOVE MIR-ACTN-TYP-CD       TO WACNR-ENDBR-ACTN-TYP-CD.

       8220-BUILD-ACNR-KEY-X.
           EXIT.
      /
      ***********************
       8221-BUILD-ACNR-KEY-2.
      ***********************

           MOVE MIR-ACTN-COLCT-ID     TO WACNR-ACTN-COLCT-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WACNR-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID         TO WACNR-LOC-GR-ID.
           MOVE MIR-ACTN-TYP-CD       TO WACNR-ACTN-TYP-CD.

           MOVE HIGH-VALUES           TO WACNR-ENDBR-KEY.

       8221-BUILD-ACNR-KEY-2-X.
           EXIT.
      /
      ***************************
       9110-MOVE-ACTN-TO-SCREEN1.
      ***************************

           MOVE RACTN-LOC-GR-ID       TO MIR-LOC-GR-ID-T (LINE-SUB).
           MOVE RACTN-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T (LINE-SUB).
           MOVE RACTN-ACTN-TYP-CD     TO MIR-ACTN-TYP-CD-T (LINE-SUB).
           MOVE RACTN-ACTN-LEAD-MO-DUR
                                   TO MIR-ACTN-LEAD-MO-DUR-T (LINE-SUB).
           MOVE RACTN-ACTN-LEAD-DY-DUR
                                   TO MIR-ACTN-LEAD-DY-DUR-T (LINE-SUB).

       9110-MOVE-ACTN-TO-SCREEN1-X.
           EXIT.
      /
      ***************************
       9120-MOVE-ACNR-TO-SCREEN1.
      ***************************

           MOVE RACNR-ACTN-RECIP-CD   TO MIR-ACTN-RECIP-CD-T (LINE-SUB).
           MOVE RACNR-DOC-ID          TO MIR-DOC-ID-T (LINE-SUB).
           MOVE RACNR-ACTN-RECIP-RPT-CD
                                  TO MIR-ACTN-RECIP-RPT-CD-T (LINE-SUB).

       9120-MOVE-ACNR-TO-SCREEN1-X.
           EXIT.
      /
      ***************************
       9121-MOVE-BLNK-TO-SCREEN1.
      ***************************

           MOVE SPACES                TO MIR-ACTN-RECIP-CD-T (LINE-SUB).
           MOVE SPACES                TO MIR-DOC-ID-T (LINE-SUB).
           MOVE SPACES            TO MIR-ACTN-RECIP-RPT-CD-T (LINE-SUB).

       9121-MOVE-BLNK-TO-SCREEN1-X.
           EXIT.
      *
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************
      *
           PERFORM 9210-MOVE-ACTN-TO-SCREEN2
              THRU 9210-MOVE-ACTN-TO-SCREEN2-X.
           PERFORM 8220-BUILD-ACNR-KEY
              THRU 8220-BUILD-ACNR-KEY-X.
           PERFORM ACNR-1000-BROWSE
              THRU ACNR-1000-BROWSE-X.
           PERFORM ACNR-2000-READ-NEXT
              THRU ACNR-2000-READ-NEXT-X.
           PERFORM 9220-MOVE-ACNR-TO-SCREEN2
              THRU 9220-MOVE-ACNR-TO-SCREEN2-X
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-CRUD-LINES
                OR WACNR-IO-EOF.
           PERFORM
           VARYING LINE-SUB FROM WS-SUB BY 1
             UNTIL LINE-SUB > WS-MAX-CRUD-LINES
               MOVE SPACE             TO MIR-ACTN-RECIP-CD-T (LINE-SUB)
               MOVE SPACE             TO MIR-DOC-ID-T (LINE-SUB)
               MOVE SPACE          TO MIR-ACTN-RECIP-RPT-CD-T (LINE-SUB)
           END-PERFORM.
           PERFORM ACNR-3000-END-BROWSE
              THRU ACNR-3000-END-BROWSE-X.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      ***************************
       9210-MOVE-ACTN-TO-SCREEN2.
      ***************************

           MOVE RACTN-ACTN-LEAD-MO-DUR          TO MIR-ACTN-LEAD-MO-DUR.
           MOVE RACTN-ACTN-LEAD-DY-DUR          TO MIR-ACTN-LEAD-DY-DUR.

       9210-MOVE-ACTN-TO-SCREEN2-X.
           EXIT.
      /
      ***************************
       9220-MOVE-ACNR-TO-SCREEN2.
      ***************************

           MOVE RACNR-ACTN-RECIP-CD   TO MIR-ACTN-RECIP-CD-T (WS-SUB).
           MOVE RACNR-DOC-ID          TO MIR-DOC-ID-T (WS-SUB).
           MOVE RACNR-ACTN-RECIP-RPT-CD
                                    TO MIR-ACTN-RECIP-RPT-CD-T (WS-SUB).

           PERFORM ACNR-2000-READ-NEXT
              THRU ACNR-2000-READ-NEXT-X.

       9220-MOVE-ACNR-TO-SCREEN2-X.
           EXIT.
      /
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      ************************
       9700-INIT-BROWSE-LINES.
      ************************

           MOVE SPACES                TO MIR-LOC-GR-ID-T (WS-SUB).
           MOVE SPACES                TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE SPACES                TO MIR-ACTN-TYP-CD-T (WS-SUB).
           MOVE SPACES               TO MIR-ACTN-LEAD-MO-DUR-T (WS-SUB).
           MOVE SPACES               TO MIR-ACTN-LEAD-DY-DUR-T (WS-SUB).
           MOVE SPACES                TO MIR-ACTN-RECIP-CD-T (WS-SUB).
           MOVE SPACES                TO MIR-DOC-ID-T (WS-SUB).
           MOVE SPACES              TO MIR-ACTN-RECIP-RPT-CD-T (WS-SUB).

       9700-INIT-BROWSE-LINES-X.
           EXIT.
      /
      **********************
       9800-INIT-CRUD-LINES.
      **********************

           MOVE ZEROES                TO MIR-ACTN-LEAD-MO-DUR.
           MOVE ZEROES                TO MIR-ACTN-LEAD-DY-DUR.
           MOVE SPACES                TO MIR-ACTN-RECIP-CD-T (WS-SUB).
           MOVE SPACES                TO MIR-DOC-ID-T (WS-SUB).
           MOVE SPACES              TO MIR-ACTN-RECIP-RPT-CD-T (WS-SUB).

       9800-INIT-CRUD-LINES-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WS-MISC-WORK-FIELDS.
025970     INITIALIZE WS-SUBSCRIPTS.
025970     INITIALIZE WS-VALUE-EDIT.
025970     INITIALIZE WS-OLD-RECIPIENT-TABLE.
025970     SET  TRANSACTION-NAME-DEFAULT    TO TRUE.
025970     SET  WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET  WS-MAX-CRUD-LINES-DEFAULT   TO TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET  MIR-RETRN-OK          TO  TRUE.
025970     MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      * COPY CCPPPLIN.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY ACTN
014221                         '$VAR2' BY 'ACTN'.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
023447*COPY NCPEDOCM.
023447 COPY XCPEDOCM.
       COPY CCPELCGP.
       COPY CCPEACTR.
       COPY CCPEACTV.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY CCCLACNR.
018764 COPY CCPLACNR.
      /
018764*COPY CCCLACTN.
018764 COPY CCPLACTN.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS8090.
018770 COPY XCPS8960.
018770 COPY XCPL8960.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.       
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPAACTN.
       COPY CCPBACTN.
       COPY CCPCACTN.
       COPY CCPNACTN.
       COPY CCPUACTN.
       COPY CCPXACTN.

       COPY CCPAACNR.
       COPY CCPBACNR.
       COPY CCPCACNR.
       COPY CCPNACNR.
       COPY CCPUACNR.
       COPY CCPXACNR.

018770*COPY XCPNDMAD.

       COPY CCPNEDIT.

       COPY CCPNSCOM.

      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM3100                     **
      *****************************************************************
