      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM5225.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5225                                         **
      **  REMARKS:  THIS WILL LINK CREDIT CARD INFORMATION TO        **
      **            A POLICY                                         **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016395**  6.2       CREDIT CARD LINK TO POLICY                       **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5225'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.
021930*COPY XCWWFNDM.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-CRC-ACCOUNTS          PIC S9(4).
025970         88  WS-MAX-CRC-ACCOUNTS-DEFAULT         VALUE +9.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-LIST                     VALUE '5225'.
           05  WS-IF-VALIDATE-OK            PIC X(01).
               88  WS-VALIDATE-OK                      VALUE 'Y'.
               88  WS-VALIDATE-FAILED                  VALUE 'N'.
           05  WS-IF-CLCN-ENDBR-NEEDED                 PIC X(01).
               88  WS-CLCN-ENDBR-NEEDED                VALUE 'Y'.
           05  WS-IF-NUMBER-FOUND                      PIC X(01).
               88  WS-NUMBER-NOT-FOUND                 VALUE 'N'.
               88  WS-NUMBER-FOUND                     VALUE 'Y'.
           05  WS-CLI-CRC-NUM                          PIC S9(03).
           05  I                            PIC S9(3)  VALUE ZERO.
025970*    05  WS-MAX-CRC-ACCOUNTS          PIC S9(4)  VALUE +9.
           05  WS-PIC-9                     PIC 9.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
021930*COPY XCWWWKDT.
      *
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRCRCD.
       COPY CCFWCRCD.
       COPY CCFWCLCR.
       COPY CCFRCLCR.
       COPY CCFWCLCN.
      *
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
      *
028298 COPY CCWL2626.
       COPY NCWL0240.
021930*COPY XCWL0280.
       COPY CCWL5600.
      *
      * LINKAGE TO NUMERIC EDITING MODULE
021930*COPY XCWL0290.
      *
      * LINKAGE TO DATE CONVERSION MODULES
021930*COPY XCWL1640.
021930*COPY XCWL1660.
      *
      * DATE MANIPULATION WORK AREAS
021930*COPY XCWLDTLK.
      *
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
021930*COPY CCWWCVGS.
      *
      *-----------------
       LINKAGE   SECTION.

CVMQ71 COPY XCWWDFH.
      *-----------------
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5225.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *-------------
       0000-MAINLINE.
      *-------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       2000-PROCESS-REQUEST.
      *--------------------

           MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
           SET MIR-RETRN-OK               TO TRUE.

021930*    PERFORM  0290-1000-BUILD-PARM-INFO
021930*        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  2200-EDIT-CONTROL-FIELDS
               THRU 2200-EDIT-CONTROL-FIELDS-X.

           IF WS-VALIDATE-FAILED
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  3000-PROCESS-LINK
               THRU 3000-PROCESS-LINK-X.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------------
       2200-EDIT-CONTROL-FIELDS.
      *----------------------------

           MOVE 'Y'                       TO WS-IF-VALIDATE-OK.
           MOVE LOW-VALUES                TO WCRCD-KEY.
           MOVE MIR-CRC-TYP-CD            TO WCRCD-CRC-TYP-CD.
           MOVE MIR-CRC-ID                TO WCRCD-CRC-ID.
           PERFORM  CRCD-1000-READ
               THRU CRCD-1000-READ-X.

           IF WCRCD-IO-OK
               GO TO 2200-EDIT-CONTROL-FIELDS-X
           END-IF.

      *MSG: 'NO CREDIT CARD RECORD FOUND TO LINK TO PLEASE RETRY'
           MOVE 'CS52250001'         TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE 'N'                       TO WS-IF-VALIDATE-OK.

       2200-EDIT-CONTROL-FIELDS-X.
           EXIT.


      *---------------------
       3000-PROCESS-LINK.
      *---------------------

           PERFORM  8500-EDITS-FOR-ATTACH-REMOVE
               THRU 8500-EDITS-FOR-ATTACH-REMOVE-X.

           IF WS-VALIDATE-FAILED
               GO TO 3000-PROCESS-LINK-X
           END-IF.

           MOVE LOW-VALUES                  TO WCRCD-KEY.
           MOVE MIR-CRC-TYP-CD              TO WCRCD-CRC-TYP-CD.
           MOVE MIR-CRC-ID                  TO WCRCD-CRC-ID.
           PERFORM  CRCD-1000-READ
               THRU CRCD-1000-READ-X.

           IF NOT WCRCD-IO-OK
               PERFORM 9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      *MSG: CREDIT CARD ACCOUNT MUST BE CREATED IN THE ACCOUNT TABLE
               MOVE 'CS52250002'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-LINK-X
           END-IF.

           MOVE LOW-VALUES                  TO WCLCR-KEY.
           MOVE MIR-CRC-TYP-CD              TO WCLCR-CRC-TYP-CD.
           MOVE MIR-CRC-ID                  TO WCLCR-CRC-ID.
           MOVE MIR-CLI-ID                  TO WCLCR-CLI-ID.

           PERFORM  CLCR-1000-READ
               THRU CLCR-1000-READ-X.

           IF WCLCR-IO-OK
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               PERFORM  9200-MOVE-CLCR-TO-SCREEN
                   THRU 9200-MOVE-CLCR-TO-SCREEN-X
      *MSG: CREDIT CARD ACCOUNT EXISTS IN THE CLIENT CREDIT CARD TABLE
               MOVE 'CS52250003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-LINK-X
           END-IF.

           MOVE LOW-VALUES                 TO WCLCN-KEY.
           MOVE +001                       TO WCLCN-CLI-CRC-NUM.
           MOVE MIR-CLI-ID                 TO WCLCN-CLI-ID.
           MOVE WCLCN-KEY                  TO WCLCN-ENDBR-KEY.
           MOVE +009                       TO WCLCN-ENDBR-CLI-CRC-NUM.
           MOVE 'N'                        TO WS-IF-CLCN-ENDBR-NEEDED.
           MOVE 'N'                        TO WS-IF-NUMBER-FOUND.

           PERFORM  CLCN-1000-BROWSE
               THRU CLCN-1000-BROWSE-X.

           MOVE 'Y'                        TO WS-IF-CLCN-ENDBR-NEEDED.

           PERFORM  CLCN-2000-READ-NEXT
               THRU CLCN-2000-READ-NEXT-X.

           PERFORM  7220-FIND-CLI-CRC-ID
               THRU 7220-FIND-CLI-CRC-ID-X
               VARYING I FROM 1 BY 1
               UNTIL WS-NUMBER-FOUND
               OR I > WS-MAX-CRC-ACCOUNTS.

           IF WS-CLCN-ENDBR-NEEDED
               PERFORM CLCN-3000-END-BROWSE
                   THRU CLCN-3000-END-BROWSE-X
           END-IF.


           IF WS-NUMBER-NOT-FOUND
      *MSG CREATE FAILED - CLIENT ALREADY HAS @1 CREDIT CARD ACCOUNTS
               MOVE 'CS52250004'         TO WGLOB-MSG-REF-INFO
               MOVE WS-MAX-CRC-ACCOUNTS TO WS-PIC-9
               MOVE WS-PIC-9             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3000-PROCESS-LINK-X
           END-IF

           MOVE LOW-VALUES                 TO WCLCR-KEY.
           MOVE MIR-CRC-TYP-CD             TO WCLCR-CRC-TYP-CD.
           MOVE MIR-CRC-ID                 TO WCLCR-CRC-ID.
           MOVE MIR-CLI-ID                 TO WCLCR-CLI-ID,

           PERFORM  CLCR-1000-CREATE
               THRU CLCR-1000-CREATE-X.

           MOVE WS-CLI-CRC-NUM             TO RCLCR-CLI-CRC-NUM.

           PERFORM  CLCR-1000-WRITE
               THRU CLCR-1000-WRITE-X.

           MOVE MIR-CLI-ID                 TO L0240-CLIENT-NUMBER.
           MOVE WS-CLI-CRC-NUM             TO L0240-ACCT-NO.
           SET L0240-REQIR-TYP-CRC         TO TRUE.

           PERFORM 0240-1000-PRCES-OS-PMT-RQIR
               THRU 0240-1000-PRCES-OS-PMT-RQIR-X.

           MOVE 'CS52250005'             TO WGLOB-MSG-REF-INFO.
           MOVE WS-CLI-CRC-NUM           TO WS-PIC-9.
           MOVE WS-PIC-9                 TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-LINK-X.
           EXIT.

      *-------------------
       7220-FIND-CLI-CRC-ID.
      *-------------------

           IF  WCLCN-IO-EOF OR
               I < WCLCN-CLI-CRC-NUM
                 MOVE I                      TO WS-CLI-CRC-NUM
                 MOVE 'Y'                    TO WS-IF-NUMBER-FOUND
                 GO TO 7220-FIND-CLI-CRC-ID-X
           END-IF.

           PERFORM  CLCN-2000-READ-NEXT
               THRU CLCN-2000-READ-NEXT-X.

       7220-FIND-CLI-CRC-ID-X.
           EXIT.

      *-------------------
       8500-EDITS-FOR-ATTACH-REMOVE.
      *-------------------

           MOVE 'Y'                    TO WS-IF-VALIDATE-OK.
           IF MIR-CLI-ID = SPACES
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               MOVE 'N'                TO WS-IF-VALIDATE-OK
               GO TO 8500-EDITS-FOR-ATTACH-REMOVE-X
           END-IF

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CLI-ID             TO L5600-CLI-ID.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           IF L5600-RETRN-CLI-NOT-FOUND     OR
               L5600-CNFD-ACCS-RESTRICTED   OR
               L5600-CCAS-ACCS-RESTRICTED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               MOVE 'N'                TO WS-IF-VALIDATE-OK
           END-IF.

       8500-EDITS-FOR-ATTACH-REMOVE-X.
           EXIT.

      *------------------
       9100-BLANK-DATA-FIELDS.
      *------------------

           MOVE SPACES                 TO MIR-CRC-TYP-CD.
           MOVE SPACES                 TO MIR-CRC-ID.
           MOVE SPACES                 TO MIR-CLI-ID.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *---------------------
       9200-MOVE-CLCR-TO-SCREEN.
      *---------------------

           MOVE RCLCR-CRC-TYP-CD       TO MIR-CRC-TYP-CD.
           MOVE RCLCR-CRC-ID           TO MIR-CRC-ID.
           MOVE RCLCR-CLI-ID           TO MIR-CLI-ID.

       9200-MOVE-CLCR-TO-SCREEN-X.
           EXIT.

      *-------------------------
       9300-SETUP-MSIN-REFERENCE.
      *-------------------------


           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0240-0000-INIT-PARM-INFO
025970         THRU 0240-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-MAX-CRC-ACCOUNTS-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *                      PROCESSING COPYBOOKS                     *
      *****************************************************************

028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPSPGA.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
      *****************************************************************
      *                      LINK COPYBOOKS                           *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
021930*COPY XCPL0280.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
021930*COPY XCPL0290.
021930*COPY XCPS0290.
021930*COPY XCPL1640.
021930*COPY XCPL1660.
018764*COPY NCCL0240.
025970 COPY NCPS0240.
018764 COPY NCPL0240.
      *
      *****************************************************************
      *  FILE I/O COPYBOOKS                                           *
      *****************************************************************
021930*COPY CCPACRCD.
021930*COPY CCPBCRCD.
021930*COPY CCPCCRCD.
       COPY CCPNCRCD.
021930*COPY CCPBCLCR.
       COPY CCPACLCR.
       COPY CCPCCLCR.
       COPY CCPNCLCR.
       COPY CCPBCLCN.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM5225                     **
      *****************************************************************
