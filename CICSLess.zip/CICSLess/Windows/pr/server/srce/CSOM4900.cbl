      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4900.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4900                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION FOR     **
      **            THE PH TABLE. THE SELECTION IS BASED ON THE      **
      **            INPUTTED VALUES OF: APPLICATION FORM TYPE, SUB   **
      **            COMPANY, ISSUE LOCATION AND APPLICATION SIGN     **
      **            DATE. IT WILL RETURN CORRESPONDING PLANS AND     **
      **            THEIR DESCRIPTIONS.                              **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       NEW FOR RELEASE 6.0                              **
014660**  6.0       REMOVE XCCPMEXT                                  **
016051**  6.1       INCREASE TABLE SIZE FROM 50 TO 100               **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017176**  6.3       ONLY SELECT BASIC PLANS FOR MIR RETURN           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018798**  6.4       REMOVE MESSAGE FOR NO RECORD                     **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4900'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
014590*COPY XCWL0030.
      /
025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970                                                 VALUE 100.
025970         88  WS-MAX-LIST-LINES-DEFAULT           VALUE 100.
025970
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '4900'.
016548*    05  WS-SUB                                  PIC S9(04) COMP.
016548     05  WS-SUB                                  PIC S9(04)
016548                                                 BINARY.
016548*    05  WS-MAX-LIST-LINES                       PIC S9(04) COMP
025970*    05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970*                                                VALUE 100.
016051*                                                VALUE 50.
           05  WS-PHAP-REL-SW                          PIC X(01).
               88  WS-PHAP-REL                         VALUE 'Y'.
               88  WS-PHAP-REL-NO                      VALUE 'N'.
           05  WS-ERROR-SW                             PIC X(01).
               88  WS-ERROR-FOUND                      VALUE 'Y'.
               88  WS-ERROR-FOUND-NO                   VALUE 'N'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
016537*COPY CCWWINDX.
025970 COPY CCWWINDX.
      /
016537*COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
025970 COPY CCFRPOL.
025970 COPY CCWWCVGS.
025970
       COPY CCFWPHAP.
016537*COPY CCFWPH.
       COPY CCFRPH.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0540.
       COPY CCWL3320.
      /
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4900.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*    SET MIR-RETRN-OK           TO TRUE.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4900'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           SET WS-ERROR-FOUND-NO      TO TRUE.

           PERFORM  3000-VERIFY-SBSDRY-CD
               THRU 3000-VERIFY-SBSDRY-CD-X.

           PERFORM  3100-VERIFY-APP-RECV-DT
               THRU 3100-VERIFY-APP-RECV-DT-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PHAP-1000-BROWSE
               THRU PHAP-1000-BROWSE-X.

           PERFORM  PHAP-2000-READ-NEXT
               THRU PHAP-2000-READ-NEXT-X.

           IF  WPHAP-IO-EOF
               PERFORM  PHAP-3000-END-BROWSE
                   THRU PHAP-3000-END-BROWSE-X
      *MSG: NO RECORDS FOUND TO DISPLAY
018798*        MOVE 'XS00000034'
018798*          TO WGLOB-MSG-REF-INFO
018798*        PERFORM  0260-1000-GENERATE-MESSAGE
018798*            THRU 0260-1000-GENERATE-MESSAGE-X
018798*        SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                  TO WS-SUB.
           PERFORM  2010-BROWSE-TABLE-PH
               THRU 2010-BROWSE-TABLE-PH-X
              UNTIL WS-SUB > WS-MAX-LIST-LINES
                 OR WPHAP-IO-EOF.

           IF  WPHAP-IO-EOF
               CONTINUE
           ELSE
      *        SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG: MORE DATA EXISTS
               MOVE 'XS00000014'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PHAP-3000-END-BROWSE
               THRU PHAP-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *---------------------
       2010-BROWSE-TABLE-PH.
      *---------------------

      *
      * INITIALIZE THE L0540 AREA SPECIFICALLY, NOT THROUGH CCPS0540
      * CCPS0540 USES POLICY AND COVERAGE FIELDS THAT ARE NOT AVAILABLE
      * OR REQUIRED IN THIS MODULE
      *
017176*    INITIALIZE L0540-INPUT-PARM-INFO.
017176*    INITIALIZE L0540-IO-PARM-INFO.
017176*
014591*    MOVE RPH-PLAN-ID           TO L0540-PH-PLAN-RS.
017176*    MOVE RPH-PLAN-ID           TO L0540-PH-PLAN-ID.
017176*    MOVE MIR-SBSDRY-CO-ID      TO L0540-SBSDRY-CO-ID.
017176*    MOVE MIR-POL-ISS-LOC-CD    TO L0540-POL-ISS-LOC-CD.
017176*    MOVE MIR-POL-ISS-LOC-CD    TO L0540-POL-CRNT-LOC-CD.
017176*    MOVE L1640-INTERNAL-DATE   TO L0540-POL-ISS-EFF-DT.
017176*    MOVE L1640-INTERNAL-DATE   TO L0540-CVG-ISS-EFF-DT (1).
017176*
017176*    PERFORM  0540-1000-VALIDATE-PACK
017176*        THRU 0540-1000-VALIDATE-PACK-X.
017176*
017176*    IF  L0540-RETRN-OK
017176*        PERFORM  2220-GET-PLAN-NAME
017176*            THRU 2220-GET-PLAN-NAME-X
017176*        PERFORM  9200-MOVE-RECORD-TO-MIR
017176*            THRU 9200-MOVE-RECORD-TO-MIR-X
017176*    END-IF.

020469* SKIP PLAN RECORD IF PLAN CRCY CD IS NOT EQUAL TO THE INPUT CRCY
020469*
020469     IF  MIR-CRCY-CD NOT = SPACES
020469         IF  MIR-CRCY-CD NOT = RPH-PLAN-CRCY-CD
020469             PERFORM  PHAP-2000-READ-NEXT
020469                 THRU PHAP-2000-READ-NEXT-X
020469             GO TO 2010-BROWSE-TABLE-PH-X
020469         END-IF
020469     END-IF.

017176     IF  RPH-BASIC-PLAN
017176         INITIALIZE L0540-INPUT-PARM-INFO
017176         INITIALIZE L0540-IO-PARM-INFO
017176
017176         MOVE RPH-PLAN-ID           TO L0540-PH-PLAN-ID
017176         MOVE MIR-SBSDRY-CO-ID      TO L0540-SBSDRY-CO-ID
017176         MOVE MIR-POL-ISS-LOC-CD    TO L0540-POL-ISS-LOC-CD
017176         MOVE MIR-POL-ISS-LOC-CD    TO L0540-POL-CRNT-LOC-CD
017176         MOVE L1640-INTERNAL-DATE   TO L0540-POL-ISS-EFF-DT
017176         MOVE L1640-INTERNAL-DATE   TO L0540-CVG-ISS-EFF-DT (1)
017176
017176         PERFORM  0540-1000-VALIDATE-PACK
017176             THRU 0540-1000-VALIDATE-PACK-X
017176
017176         IF  L0540-RETRN-OK
017176             PERFORM  2220-GET-PLAN-NAME
017176                 THRU 2220-GET-PLAN-NAME-X
017176             PERFORM  9200-MOVE-RECORD-TO-MIR
017176                 THRU 9200-MOVE-RECORD-TO-MIR-X
017176         END-IF
017176     END-IF.
017176
           PERFORM  PHAP-2000-READ-NEXT
               THRU PHAP-2000-READ-NEXT-X.

       2010-BROWSE-TABLE-PH-X.
           EXIT.
      /
      *-------------------
       2220-GET-PLAN-NAME.
      *-------------------

      * READ EDIT TABLE "PLAN" RECORD TYPE FOR THE GIVEN PLAN
      * CODE/RATE SCALE AND GET FULL PLAN NAME.

           MOVE RPH-PLAN-ID           TO WEDIT-ETBL-VALU-ID.
           PERFORM PLAN-2000-DESC
              THRU PLAN-2000-DESC-X.
           IF  NOT WEDIT-IO-OK
      *MSG: PLAN NAME MUST BE ON EDIT TYPE PLAN
      *        MOVE 'CS49000003'      TO WGLOB-MSG-REF-INFO
      *        PERFORM 0260-1000-GENERATE-MESSAGE
      *           THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO REDIT-ETBL-DESC-TXT
           END-IF.

       2220-GET-PLAN-NAME-X.
           EXIT.
      /
      *----------------------
       3000-VERIFY-SBSDRY-CD.
      *----------------------

      * IF NO SBSDRY CODE ENTER, GET DEFAULT SBSDRY CODE.
      * IF DEFAULT SBSDRY CODE CAN NOT BE FOUND, IT'S AN ERROR.

           IF (MIR-SBSDRY-CO-ID = SPACES)
               PERFORM  3320-1000-BUILD-PARM-INFO
                   THRU 3320-1000-BUILD-PARM-INFO-X
               PERFORM  3320-1000-DEFAULT-SUB-CO
                   THRU 3320-1000-DEFAULT-SUB-CO-X
               MOVE L3320-RETRN-SBSDRY-CO-ID TO MIR-SBSDRY-CO-ID
               IF  MIR-SBSDRY-CO-ID = SPACES
      *MSG: SUB-COMPANY MUST BE ENTERED
                   MOVE 'CS49000001'         TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-EDIT-ERROR  TO TRUE
                   SET WS-ERROR-FOUND        TO TRUE
               END-IF
           END-IF.

       3000-VERIFY-SBSDRY-CD-X.
           EXIT.
      /
      *------------------------
       3100-VERIFY-APP-RECV-DT.
      *------------------------

      * VERIFY THAT A CORRECT DATE WAS ENTERED.

      *
      * CONVERT TO INTERNAL FORMAT
      *
           MOVE MIR-POL-APP-RECV-DT     TO L1640-EXTERNAL-DATE
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  NOT L1640-VALID
               MOVE 'CS49000002'        TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-APP-RECV-DT TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               SET WS-ERROR-FOUND       TO TRUE
           END-IF.

       3100-VERIFY-APP-RECV-DT-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES            TO WPHAP-KEY.
           MOVE HIGH-VALUES           TO WPHAP-ENDBR-KEY.

           MOVE MIR-APP-FORM-TYP-ID   TO WPHAP-APP-FORM-TYP-ID.
           MOVE WPHAP-APP-FORM-TYP-ID TO WPHAP-ENDBR-APP-FORM-TYP-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-DV-SBOX-CD-G.
           MOVE SPACES                TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           ADD +1                     TO WS-SUB.
           IF  WS-SUB > WS-MAX-LIST-LINES
               GO TO 9200-MOVE-RECORD-TO-MIR-X
           END-IF.
           MOVE RPH-PLAN-ID           TO MIR-DV-SBOX-CD-T (WS-SUB).
           MOVE REDIT-ETBL-DESC-TXT   TO MIR-DV-SBOX-DESC-TXT-T
                                         (WS-SUB).

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
      *    MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0540-0000-INIT-PARM-INFO
025970         THRU 0540-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  3320-0000-INIT-PARM-INFO
025970         THRU 3320-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET  WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
034783*    SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY CCPEPLAN.
      /
016537*COPY XCPPINIT.
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY CCCL0540.
018764 COPY CCPL0540.
      /
018764*COPY CCCL3320.
018764 COPY CCPL3320.
025970 COPY CCPS0540.
       COPY CCPS3320.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY CCPBPHAP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM4900                     **
      *****************************************************************


