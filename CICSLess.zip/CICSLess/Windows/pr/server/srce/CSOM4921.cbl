      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4921.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4921                                         **
      **  REMARKS:  THIS MODULE PROVIDES A LIST OF FUNDS AVAILABLE   **
      **            FOR APPLYING TO INVESTOR POROFILES               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4921'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-LIST-LINES                 PIC 9(03) VALUE 300.
025970         88  WS-MAX-LIST-LINES-DEFAULT               VALUE 300.
025970
       01  WS-WORKING-STORAGE.
           05  WS-BUSINESS-FUNCTION              PIC X(04).
               88  WS-BUSINESS-FUNCTION-LIST     VALUE '4921'.
           05  WS-SUB                            PIC S9(04) BINARY SYNC.
025970*    05  WS-MAX-LIST-LINES                 PIC 9(03) VALUE 300.
           05  WS-FUND-TYP-IND                   PIC X(01).
               88  WS-FUND-SEG                   VALUE 'F'.
               88  WS-FUND-PLN                   VALUE 'P'.
           05  WS-CODE.
               10  WS-F-P-CD                     PIC X(01).
               10  WS-FND-PLAN-ID                PIC X(06).
      
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDFA.
       COPY CCFREDFA.
      /
       COPY CCFWEDVF.
       COPY CCFREDVF.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4921.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
           
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUSINESS-FUNCTION.

           EVALUATE TRUE

               WHEN WS-BUSINESS-FUNCTION-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4921'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-LIST.
      *------------

           MOVE 1 TO WS-SUB.
           
           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

      * RETRIEVE THE FUNDS FROM THE EDIT TABLE

           SET WS-FUND-SEG TO TRUE.
           
           PERFORM 2100-RETRIEVE-FUNDS
              THRU 2100-RETRIEVE-FUNDS-X.
           
      * RETRIEVE THE PLANS FROM THE EDIT TABLE

           SET WS-FUND-PLN TO TRUE.
           
           PERFORM 2300-RETRIEVE-PLANS
              THRU 2300-RETRIEVE-PLANS-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
       2100-RETRIEVE-FUNDS.
      *-----------------
      * USES CUSTOM SQL TO GET COMPANY ID, DESCRIPTION AND FUND ID 
      * FOR ALL 'OPEN' FUNDS. THERE IS NO END-BROWSE KEY.
           MOVE LOW-VALUES       TO WEDVF-KEY.
           MOVE WGLOB-USER-LANG  TO WEDVF-ETBL-LANG-CD.

           PERFORM EDVF-1000-BROWSE
              THRU EDVF-1000-BROWSE-X.
           
           PERFORM EDVF-2000-READ-NEXT
              THRU EDVF-2000-READ-NEXT-X.
              
           IF WEDVF-IO-OK
               PERFORM 2200-MOVE-EDVF-TO-SCREEN
                  THRU 2200-MOVE-EDVF-TO-SCREEN-X
               UNTIL NOT WEDVF-IO-OK
               OR WS-SUB > WS-MAX-LIST-LINES
           END-IF.
           
           PERFORM EDVF-3000-END-BROWSE
              THRU EDVF-3000-END-BROWSE-X.
       
       2100-RETRIEVE-FUNDS-X.
           EXIT.
      /
      *---------------------------
       2200-MOVE-EDVF-TO-SCREEN.
      *---------------------------

           MOVE WS-FUND-TYP-IND      TO WS-F-P-CD      
           MOVE REDVF-ETBL-VALU-ID   TO WS-FND-PLAN-ID 

           MOVE WS-CODE              TO MIR-DV-SBOX-CD-T (WS-SUB).
           MOVE REDVF-ETBL-DESC-TXT
                               TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB).
       
           ADD 1 TO WS-SUB.
           
           PERFORM EDVF-2000-READ-NEXT
              THRU EDVF-2000-READ-NEXT-X.
              
       2200-MOVE-EDVF-TO-SCREEN-X.
           EXIT.
      /
      *--------------------
       2300-RETRIEVE-PLANS.
      *--------------------
      * USES CUSTOM SQL TO GET COMPANY ID, DESCRIPTION AND PLAN ID 
      * FOR ALL 'OPEN' FLEXIBLE PREMIUM ANNUITY PLANS THAT ARE NOT
      * SIDE FUNDS.
           MOVE LOW-VALUES       TO WEDFA-KEY.
           MOVE WGLOB-USER-LANG  TO WEDFA-ETBL-LANG-CD.

           PERFORM EDFA-1000-BROWSE
              THRU EDFA-1000-BROWSE-X.
           
           PERFORM EDFA-2000-READ-NEXT
              THRU EDFA-2000-READ-NEXT-X.
              
           IF WEDFA-IO-OK
               PERFORM 2400-MOVE-EDFA-TO-SCREEN
                  THRU 2400-MOVE-EDFA-TO-SCREEN-X
               UNTIL NOT WEDFA-IO-OK
               OR WS-SUB > WS-MAX-LIST-LINES
           END-IF.
           
           PERFORM EDFA-3000-END-BROWSE
              THRU EDFA-3000-END-BROWSE-X.
       
       2300-RETRIEVE-PLANS-X.
           EXIT.
      /
      *---------------------------
       2400-MOVE-EDFA-TO-SCREEN.
      *---------------------------

           MOVE WS-FUND-TYP-IND      TO WS-F-P-CD      
           MOVE REDFA-ETBL-VALU-ID   TO WS-FND-PLAN-ID 

           MOVE WS-CODE              TO MIR-DV-SBOX-CD-T (WS-SUB).
           MOVE REDFA-ETBL-DESC-TXT
                               TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB).
       
           ADD 1 TO WS-SUB.
           
           PERFORM EDFA-2000-READ-NEXT
              THRU EDFA-2000-READ-NEXT-X.
              
       2400-MOVE-EDFA-TO-SCREEN-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES         TO MIR-DV-SBOX-CD-G.
           MOVE SPACES         TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
           INITIALIZE          WS-WORKING-STORAGE.
025970     SET  WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUSINESS-FUNCTION.
025970*    MOVE +300       TO  WS-MAX-LIST-LINES.
      
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBEDFA.
      /
       COPY CCPBEDVF.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4921                     **
      *****************************************************************
