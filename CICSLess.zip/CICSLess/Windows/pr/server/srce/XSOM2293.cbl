      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM2293.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM2293                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE DOCS TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
025244**  6.6       ADDED STANDARD MESSAGE                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM2293'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-DELETE                VALUE '2293'.
           05  WS-INDX                          PIC S9(04) BINARY.
           05  WS-ORIG-LVL-NUM                  PIC S9(04) BINARY.
           05  WS-END-DEL-LOOP-IND              PIC X(01).
               88 WS-END-DEL-LOOP-N                 VALUE 'N'.
               88 WS-END-DEL-LOOP-Y                 VALUE 'Y'.
           05  WS-DEL-ENTIRE-STRCTR-IND         PIC X(01).
               88 WS-DEL-ENTIRE-STRCTR-N            VALUE 'N'.
               88 WS-DEL-ENTIRE-STRCTR-Y            VALUE 'Y'.
           05  WS-DOCS-DBSRL-ID                 PIC X(04).
       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '2293'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY XCFWDOCS.
       COPY XCFRDOCS.
       COPY CCWWLOCK.
       COPY XCFWDOCN.
       COPY XCFRDOCM.
       COPY XCFWDTOM.
       COPY XCFRDTOK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0620.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
       COPY XCWL2566.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM2293.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2293'      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'    TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-DELETE.
      *------------
      * ENSURE SELECTED RECORD EXISTS
           PERFORM  8000-BUILD-KEYS
               THRU 8000-BUILD-KEYS-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.
      
      *  UPDATE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  DOCS-1000-READ-TWRK-TS
               THRU DOCS-1000-READ-TWRK-TS-X.

           IF  WDOCS-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WDOCS-KEY              TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-DELETE-X
           END-IF.
      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           MOVE RDOCS-PARNT-DBSRL-ID       TO MIR-PARNT-DBSRL-ID.
           MOVE RDOCS-DOCSTC-SEQ-NUM       TO MIR-DOCSTC-SEQ-NUM.
           MOVE RDOCS-DOCSTC-GR-ID         TO MIR-DOCSTC-GR-ID.

      * CALL THE DOCUMENT STRUCTURE UTILITY TO LOAD THE DOCUMENT 
      * STRUCTURE INTO ITS WORKING-STORAGE TABLE
      
           PERFORM  2566-0000-INIT-PARM-INFO
               THRU 2566-0000-INIT-PARM-INFO-X.
               
           MOVE MIR-DOCSTC-ID              TO L2566-DOCSTC-ID.
           
           PERFORM  2566-1000-STRT-DOCM
               THRU 2566-1000-STRT-DOCM-X.
      
      *MSG: THE DOCUMENT STRUCTURE LOAD FAILED     
           IF L2566-RETRN-ERROR
               MOVE 'XS22930002'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

      * DO KEYED READ ON THE TABLE STRUCTURE TO RETURN RECORD VALUES
          
           PERFORM  2566-0000-INIT-PARM-INFO
               THRU 2566-0000-INIT-PARM-INFO-X.
               
           MOVE MIR-DOCSTC-ID              TO L2566-DOCSTC-ID.
           MOVE MIR-DBSRL-ID               TO L2566-DBSRL-ID.
           
           PERFORM  2566-5000-GET-DOCS-BY-KEY
               THRU 2566-5000-GET-DOCS-BY-KEY-X.
      
      *MSG: THE DOCUMENT STRUCTURE KEY READ FAILED           
           IF L2566-RETRN-ERROR
               MOVE 'XS22930003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2000-DELETE-X
           END-IF.
           
      * STORE THE ORIGINAL NODE DETAILS
           MOVE L2566-INDX                 TO WS-INDX.
           MOVE L2566-DV-DOCSTC-LVL-NUM    TO WS-ORIG-LVL-NUM.
           MOVE L2566-DBSRL-ID             TO WS-DOCS-DBSRL-ID.

      * IF THIS IS A 'TOP-LEVEL' NODE (IT HAS NO PARENT) THEN SEE IF 
      * WE ARE ABOUT TO DELETE THE ENTIRE STRUCTURE
      
           IF  RDOCS-PARNT-DBSRL-ID = SPACES
               PERFORM  4000-TOP-LVL-CHECK
                   THRU 4000-TOP-LVL-CHECK-X
           END-IF.
          
           IF  MIR-RETRN-EDIT-ERROR
               GO TO 2000-DELETE-X
           END-IF.

      * IF WE ARE DELETING THE ENTIRE STRUCTURE WE HAVE ALREADY XREF
      * DOCS WITH THE DOCM SO CAN EXIT ON EDIT PASS OR DELETE ON FINAL
      * PASS.
           IF  WS-DEL-ENTIRE-STRCTR-Y
               IF  MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  7000-DEL-DOCS
                       THRU 7000-DEL-DOCS-X
               ELSE
      *MSG: THE DOCUMENT STRUCTURE NODE WILL BE DELETED ALONG WITH
      *     ALL RELATED CHILDREN               
                   MOVE 'XS22930001'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
               GO TO 2000-DELETE-X
           END-IF.

      * WORKING DOWN THE STRUCTURE XREF THE DOCS RECORD WITH DTOK
           PERFORM  5000-CHECK-DTOK
               THRU 5000-CHECK-DTOK-X
               UNTIL WS-END-DEL-LOOP-Y
               OR    MIR-RETRN-EDIT-ERROR.

           IF MIR-RETRN-EDIT-ERROR
               GO TO 2000-DELETE-X
           END-IF.

      * ONCE ALL THE EDITS HAVE BEEN PASSED ON THE EDIT PASS PRODUCE
      * THE WARNING MESSAGE AND ON THE FINAL PASS DELETE THE ORIGINAL 
      * NODE.
           IF  MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  7000-DEL-DOCS
                   THRU 7000-DEL-DOCS-X
           ELSE
      *MSG: THE DOCUMENT STRUCTURE NODE WILL BE DELETED ALONG WITH
      *     ALL RELATED CHILDREN               
               MOVE 'XS22930001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      
       2000-DELETE-X.
           EXIT.
      /
      *-------------------
       4000-TOP-LVL-CHECK.
      *-------------------
      
      * IF THE NUMBER OF TOP LEVEL NODE VALUES IS EQUAL TO '1' (IE.
      * THERE IS ONLY ONE STRUCTURE HANGING OFF PRTX), THEN WE NEED TO
      * READ DOCM TO ESTABLISH IF THERE ARE AND DOCUMENTS THAT USE THE
      * STRUCTURE WE ARE ABOUT TO DELETE.  OTHERWISE WE'LL SEE IF ANY
      * DOCUMENT TOKENS ARE LINKED TO THE STRUCTURE WE ARE ABOUT TO
      * DELETE.  IF THERE ARE DOCUMENTS OR DOCUMENT TOKENS THAT USE THE
      * STRUCTURE-ID, THEN ERROR AND EXIT WITH A MESSAGE.
      
           PERFORM  2566-0000-INIT-PARM-INFO
               THRU 2566-0000-INIT-PARM-INFO-X.
               
           MOVE MIR-DOCSTC-ID              TO L2566-DOCSTC-ID.
      
           PERFORM  2566-6000-DOCS-CHILD-CTR
               THRU 2566-6000-DOCS-CHILD-CTR-X.
      
           IF  L2566-DOCS-CHILD-CTR = 1
               
               PERFORM  4100-CHECK-DOCM
                   THRU 4100-CHECK-DOCM-X

               IF MIR-RETRN-EDIT-ERROR
                   GO TO 4000-TOP-LVL-CHECK-X
               END-IF

              SET WS-DEL-ENTIRE-STRCTR-Y TO TRUE

           END-IF.
      
       4000-TOP-LVL-CHECK-X.
           EXIT.
      /
      *----------------
       4100-CHECK-DOCM.
      *----------------
      
      * CHECK DOCSTC-ID AGAINST DOCM
      
            MOVE MIR-DOCSTC-ID             TO WDOCN-DOCSTC-ID.
            
            MOVE WDOCN-KEY                 TO WDOCN-ENDBR-KEY.
            
            PERFORM  DOCN-4000-BROWSE-INDEX
                THRU DOCN-4000-BROWSE-INDEX-X.
                
            PERFORM  DOCN-5000-READ-NEXT-INDEX
                THRU DOCN-5000-READ-NEXT-INDEX-X.

            IF  WDOCN-IO-OK
      ***MSG: 'THE DOCUMENT STRUCTURE ID IS REFERENCED IN THE DOCUMENT 
      ***      TABLE AND CANNOT BE DELETED'
                MOVE 'XS22930004'          TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X                         
                SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.

           PERFORM  DOCN-6000-END-BROWSE-INDEX
               THRU DOCN-6000-END-BROWSE-INDEX-X.

       4100-CHECK-DOCM-X.
           EXIT.
      /
      *----------------
       5000-CHECK-DTOK.
      *----------------
      
      * CHECK DOCSTC-ID AND DBSRL-ID (FROM DOCS) AGAINST DTOK
      
           MOVE MIR-DOCSTC-ID              TO WDTOM-DOCSTC-ID.
           MOVE WS-DOCS-DBSRL-ID           TO WDTOM-DBSRL-ID.
           
           MOVE WDTOM-KEY                  TO WDTOM-ENDBR-KEY.

           PERFORM  DTOM-4000-BROWSE-INDEX
               THRU DTOM-4000-BROWSE-INDEX-X.
               
           PERFORM  DTOM-5000-READ-NEXT-INDEX
               THRU DTOM-5000-READ-NEXT-INDEX-X.

           IF  WDTOM-IO-OK
      *** MSG: 'THE DOCUMENT STRUCTURE PARENT OR CHILD IS REFERENCED 
      ***       IN THE DOCUMENT TOKEN TABLE AND CANNOT BE DELETED'
               MOVE 'XS22930006' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X                         
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 5000-CHECK-DTOK-X
           END-IF.

           PERFORM  DTOM-6000-END-BROWSE-INDEX
               THRU DTOM-6000-END-BROWSE-INDEX-X.

      * MOVE ONTO THE NEXT DOCS
      
           PERFORM  2566-0000-INIT-PARM-INFO
               THRU 2566-0000-INIT-PARM-INFO-X.
           
           MOVE MIR-DOCSTC-ID              TO L2566-DOCSTC-ID.
           
           ADD +1                          TO WS-INDX.
           MOVE WS-INDX                    TO L2566-INDX.
           
           PERFORM  2566-5500-GET-DOCS-BY-INDX
               THRU 2566-5500-GET-DOCS-BY-INDX-X.
           
      *MSG: THE DOCUMENT STRUCTURE INDEX READ FAILED           
           IF L2566-RETRN-ERROR
               MOVE 'XS22930005'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 5000-CHECK-DTOK-X
           END-IF.

      * IF THE LEVEL NUMBER IS THE SAME OR LESS THAN THE ORIGINAL
      * WE NO LONGER HAVE A CHILD OF THE ORIGINAL.
      
           IF L2566-DV-DOCSTC-LVL-NUM <= WS-ORIG-LVL-NUM
           OR L2566-GET-DOCS-BY-INDX-EOF
               SET WS-END-DEL-LOOP-Y TO TRUE
               GO TO 5000-CHECK-DTOK-X
           END-IF.

           MOVE L2566-DBSRL-ID             TO WS-DOCS-DBSRL-ID.
           
       5000-CHECK-DTOK-X.
           EXIT.
      /
      *--------------
       7000-DEL-DOCS.
      *--------------

      * ONLY THE ORIGINAL NODE NEEDS TO BE DELETED DUE TO CASCADE
      * DELETE ON DOCS.
           PERFORM  DOCS-1000-READ-FOR-UPDATE
               THRU DOCS-1000-READ-FOR-UPDATE-X.

           IF WDOCS-IO-OK
               CONTINUE
           ELSE
      *MSG: RECORD @1 NOT FOUND
               MOVE WDOCS-KEY              TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 7000-DEL-DOCS-X
           END-IF.

           PERFORM  DOCS-1000-DELETE
               THRU DOCS-1000-DELETE-X.

025244*MSG: 'DELETE COMPLETED - CONTINUE'
025244     MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO.
025244     PERFORM  0260-1000-GENERATE-MESSAGE
025244         THRU 0260-1000-GENERATE-MESSAGE-X.
025244
       7000-DEL-DOCS-X.
           EXIT.
      /
      *----------------
       8000-BUILD-KEYS.
      *----------------

           MOVE MIR-DOCSTC-ID              TO WDOCS-DOCSTC-ID.
           MOVE MIR-DBSRL-ID               TO WDOCS-DBSRL-ID.

       8000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                     TO MIR-PARNT-DBSRL-ID.
           MOVE SPACES                     TO MIR-DOCSTC-SEQ-NUM.
           MOVE SPACES                     TO MIR-DOCSTC-GR-ID.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                     TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE         TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2566-0000-INIT-PARM-INFO
025970         THRU 2566-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE MIR-OUTPUT-AREA.

           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
           MOVE ZEROES                     TO WS-INDX.
           MOVE ZEROES                     TO WS-ORIG-LVL-NUM.
           SET WS-END-DEL-LOOP-N           TO TRUE.
           SET WS-DEL-ENTIRE-STRCTR-N      TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
           
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  DOCS
                                '$VAR2'   BY 'DOCS'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS8090.
025970 COPY CCPS0620.
       COPY CCPL0620.
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
       COPY XCPS2566.
       COPY XCPL2566.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY XCPBDOCS.
       COPY XCPNDOCS.
       COPY XCPUDOCS.
       COPY XCPXDOCS.
      /
       COPY XCPBDOCN.
       COPY XCPBDTOM. 
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM XSOM2293                     **
      *****************************************************************
