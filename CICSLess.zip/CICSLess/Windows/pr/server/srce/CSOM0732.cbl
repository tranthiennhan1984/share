      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM0732.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0732                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE MAINTAIN FUNCTION       **
      **            FOR THE GUIDELINE PREMIUM ACTIVITY RECORD.       **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0732'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-UPDATE             VALUE '0732'.
           05  WS-EFF-DT                         PIC X(10).
           05  WS-CVG-NUM                        PIC X(02).
           05  WS-CVG-NUM-N REDEFINES WS-CVG-NUM PIC 9(02).
           05  WS-SEQ-NUM                        PIC S9(3) COMP-3.
           05  WS-STATUS-CODE                    PIC X(01).
               88  WS-STATUS-VALID               VALUE 'A' 'R' 'H' 'E'.
           05  WS-PCHST-SEQ-NUM                  PIC S9(5) COMP-3.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWCVGS.
       COPY CCWWINDX.
       COPY CCWWLOCK.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY CCWL0620.

       COPY CCWL2430.

       COPY CCWL5395.

       COPY CCWL5400.

       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.

       COPY XCWL8090.

       COPY XCWLCOMM REPLACING '$VAR1' BY '0732'.
           15  LCOMM-TWRK-AREA         PIC X(264).
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0732.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                         TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0732'
                                         TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                                         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                         TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  5395-1000-BUILD-PARM-INFO
               THRU 5395-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID               TO L5395-POL-ID.
           MOVE WS-EFF-DT                TO L5395-GDLN-EFF-DT.
           MOVE WS-CVG-NUM               TO L5395-CVG-NUM.
           MOVE WS-SEQ-NUM               TO L5395-GDLN-SEQ-NUM.

           PERFORM  5395-1000-GDLN-RETRIEVE
               THRU 5395-1000-GDLN-RETRIEVE-X.

           IF  NOT L5395-RETRN-OK
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               MOVE 'XS00000008'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  2200-VALIDATE-DETAILS
               THRU 2200-VALIDATE-DETAILS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           IF  WGLOB-AUDIT-REQUESTED
               SET L5395-AUDIT-REQUESTED TO TRUE
           END-IF.

           PERFORM  5395-2000-GDLN-UPDATE
               THRU 5395-2000-GDLN-UPDATE-X.

           IF  WS-PCHST-SEQ-NUM NOT = ZERO
               MOVE WS-PCHST-SEQ-NUM     TO L5395-ORIG-PCHST-SEQ-NUM
               PERFORM  5395-6000-GDLN-ERROR
                   THRU 5395-6000-GDLN-ERROR-X
           END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
              MOVE 'XS00000008'          TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
              MOVE 'XS00000007'          TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2000-UPDATE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  2110-EDIT-POLICY
               THRU 2110-EDIT-POLICY-X.

           PERFORM  2120-EDIT-EFF-DT
               THRU 2120-EDIT-EFF-DT-X.

           PERFORM  2130-EDIT-CVG-NUM
               THRU 2130-EDIT-CVG-NUM-X.

           PERFORM  2140-EDIT-SEQ-NUM
               THRU 2140-EDIT-SEQ-NUM-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       2110-EDIT-POLICY.
      *-----------------

           MOVE MIR-POL-ID-BASE          TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX           TO WPOL-POL-ID-SFX.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: 'TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2,
      *      PROCESS NOT COMPLETE'
               MOVE 'XS00000303'         TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2110-EDIT-POLICY-X
           END-IF.

           IF  NOT WPOL-IO-OK
               SET WGLOB-RETURN-ERROR    TO TRUE
               MOVE 'CS00000019'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET L5400-CRCY-MSG-REQD       TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR    TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
           END-IF.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID              TO L2430-POL-ID.
           MOVE ZERO                     TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE                L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM
                                         TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                         TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                         TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                         TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD     TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME    TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES               TO MIR-DV-OWN-CLI-NM
           END-IF.

       2110-EDIT-POLICY-X.
           EXIT.
      /
      *-----------------
       2120-EDIT-EFF-DT.
      *-----------------

           MOVE MIR-GDLN-EFF-DT          TO L1640-EXTERNAL-DATE
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-INTERNAL-DATE = WWKDT-ZERO-DT
               MOVE 'CS00000054'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
           END-IF.

       2120-EDIT-EFF-DT-X.
           EXIT.

      *--------------------
       2130-EDIT-CVG-NUM.
      *--------------------

           IF  MIR-CVG-NUM = ZERO
           OR  MIR-CVG-NUM = SPACES
               MOVE ZERO                 TO WS-CVG-NUM-N
               GO TO 2130-EDIT-CVG-NUM-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE LENGTH OF MIR-CVG-NUM
                                         TO L0280-LENGTH.
           MOVE ZERO                     TO L0280-PRECISION.
           MOVE MIR-CVG-NUM              TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT         TO WS-CVG-NUM-N
               IF  WS-CVG-NUM-N > RPOL-POL-CVG-REC-CTR-N
      *MSG: THE COVERAGE MUST BE A NUMBER IN THE RANGE FROM 00 TO (@1)
                   MOVE 'CS00000055'     TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CVG-NUM      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
               END-IF
           ELSE
      *MSG:    'COVERAGE MUST BE NUMERIC'
               MOVE 'XS00000079'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2130-EDIT-CVG-NUM-X.
           EXIT.

      *-------------------
       2140-EDIT-SEQ-NUM.
      *-------------------

           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE LENGTH OF MIR-GDLN-SEQ-NUM
                                         TO L0280-LENGTH.
           MOVE ZERO                     TO L0280-PRECISION.
           MOVE MIR-GDLN-SEQ-NUM         TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT         TO WS-SEQ-NUM
               IF  WS-SEQ-NUM = ZERO
      *MSG:        'INVALID SEQUENCE NUMBER'
                   MOVE 'CS07320001'     TO WGLOB-MSG-REF-INFO
                   MOVE MIR-GDLN-SEQ-NUM TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
               END-IF
           ELSE
      *MSG:    'INVALID SEQUENCE NUMBER'
               MOVE 'CS07320001'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-GDLN-SEQ-NUM     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2140-EDIT-SEQ-NUM-X.
           EXIT.

      *-----------------------
       2200-VALIDATE-DETAILS.
      *-----------------------

           PERFORM  2210-EDIT-POL-GDLN-SPREM
               THRU 2210-EDIT-POL-GDLN-SPREM-X.

           PERFORM  2220-EDIT-POL-GDLN-APREM
               THRU 2220-EDIT-POL-GDLN-APREM-X.

           PERFORM  2230-EDIT-ACUM-GDLN-PREM
               THRU 2230-EDIT-ACUM-GDLN-PREM-X.

           PERFORM  2240-EDIT-CVG-GDLN-SPREM
               THRU 2240-EDIT-CVG-GDLN-SPREM-X.

           PERFORM  2250-EDIT-CVG-GDLN-APREM
               THRU 2250-EDIT-CVG-GDLN-APREM-X.

           PERFORM  2260-EDIT-STATUS
               THRU 2260-EDIT-STATUS-X.

       2200-VALIDATE-DETAILS-X.
           EXIT.



      *-------------------------
       2210-EDIT-POL-GDLN-SPREM.
      *-------------------------

           IF  MIR-POL-GDLN-SPREM-AMT = SPACES
               MOVE L5395-POL-GDLN-SPREM-AMT
                                         TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-GDLN-SPREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-POL-GDLN-SPREM-AMT
               GO TO 2210-EDIT-POL-GDLN-SPREM-X
           END-IF.

           SET L0280-SIGN-PERMITTED      TO TRUE
           MOVE 2                        TO L0280-PRECISION.
           MOVE LENGTH OF MIR-POL-GDLN-SPREM-AMT
                                         TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           MOVE MIR-POL-GDLN-SPREM-AMT   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               IF  NOT L5395-GDLN-STAT-ACTIVE
               AND L0280-OUTPUT-DOLLAR NOT = L5395-POL-GDLN-SPREM-AMT
      *MSG: CANNOT CHANGE AMOUNT ON INACTIVE RECORD
                   MOVE 'CS07320002'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2210-EDIT-POL-GDLN-SPREM-X
               END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                         TO L5395-POL-GDLN-SPREM-AMT
               MOVE L0280-OUTPUT-DOLLAR  TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-GDLN-SPREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-POL-GDLN-SPREM-AMT
           ELSE
      *MSG: INVALID AMOUNT FIELD ENTERED
               MOVE 'CS07320003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2210-EDIT-POL-GDLN-SPREM-X.
           EXIT.


      *-------------------------
       2220-EDIT-POL-GDLN-APREM.
      *-------------------------

           IF  MIR-POL-GDLN-APREM-AMT = SPACES
               MOVE L5395-POL-GDLN-APREM-AMT
                                         TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-GDLN-APREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-POL-GDLN-APREM-AMT
               GO TO 2220-EDIT-POL-GDLN-APREM-X
           END-IF.

           SET L0280-SIGN-PERMITTED      TO TRUE
           MOVE 2                        TO L0280-PRECISION.
           MOVE LENGTH OF MIR-POL-GDLN-APREM-AMT
                                         TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           MOVE MIR-POL-GDLN-APREM-AMT   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               IF  NOT L5395-GDLN-STAT-ACTIVE
               AND L0280-OUTPUT-DOLLAR NOT = L5395-POL-GDLN-APREM-AMT
      *MSG: CANNOT CHANGE AMOUNT ON INACTIVE RECORD
                   MOVE 'CS07320002'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2220-EDIT-POL-GDLN-APREM-X
               END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                         TO L5395-POL-GDLN-APREM-AMT
               MOVE L0280-OUTPUT-DOLLAR  TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-GDLN-APREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-POL-GDLN-APREM-AMT
           ELSE
      *MSG: INVALID AMOUNT FIELD ENTERED
               MOVE 'CS07320003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2220-EDIT-POL-GDLN-APREM-X.
           EXIT.


      *-------------------------
       2230-EDIT-ACUM-GDLN-PREM.
      *-------------------------

           IF  MIR-ACUM-GDLN-PREM-AMT = SPACES
               MOVE L5395-ACUM-GDLN-PREM-AMT
                                         TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-ACUM-GDLN-PREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-ACUM-GDLN-PREM-AMT
               GO TO 2230-EDIT-ACUM-GDLN-PREM-X
           END-IF.

           SET L0280-SIGN-PERMITTED      TO TRUE
           MOVE 2                        TO L0280-PRECISION.
           MOVE LENGTH OF MIR-ACUM-GDLN-PREM-AMT
                                         TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           MOVE MIR-ACUM-GDLN-PREM-AMT   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               IF  NOT L5395-GDLN-STAT-ACTIVE
               AND L0280-OUTPUT-DOLLAR NOT = L5395-ACUM-GDLN-PREM-AMT
      *MSG: CANNOT CHANGE AMOUNT ON INACTIVE RECORD
                   MOVE 'CS07320002'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2230-EDIT-ACUM-GDLN-PREM-X
               END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                         TO L5395-ACUM-GDLN-PREM-AMT
               MOVE L0280-OUTPUT-DOLLAR  TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-ACUM-GDLN-PREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-ACUM-GDLN-PREM-AMT
           ELSE
      *MSG: INVALID AMOUNT FIELD ENTERED
               MOVE 'CS07320003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2230-EDIT-ACUM-GDLN-PREM-X.
           EXIT.

      *-------------------------
       2240-EDIT-CVG-GDLN-SPREM.
      *-------------------------

           IF  WS-CVG-NUM-N = ZERO
               GO TO 2240-EDIT-CVG-GDLN-SPREM-X
           END-IF.

           IF  MIR-CVG-GDLN-SPREM-AMT = SPACES
               MOVE L5395-CVG-GDLN-SPREM-AMT (WS-CVG-NUM-N)
                                         TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-CVG-GDLN-SPREM-AMT
               GO TO 2240-EDIT-CVG-GDLN-SPREM-X
           END-IF.

           SET L0280-SIGN-PERMITTED      TO TRUE
           MOVE 2                        TO L0280-PRECISION.
           MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT
                                         TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           MOVE MIR-CVG-GDLN-SPREM-AMT   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               IF  NOT L5395-GDLN-STAT-ACTIVE
               AND L0280-OUTPUT-DOLLAR NOT = L5395-CVG-GDLN-SPREM-AMT
                                             (WS-CVG-NUM-N)
      *MSG: CANNOT CHANGE AMOUNT ON INACTIVE RECORD
                   MOVE 'CS07320002'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2240-EDIT-CVG-GDLN-SPREM-X
               END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                         TO L5395-CVG-GDLN-SPREM-AMT
                                            (WS-CVG-NUM-N)
               MOVE L0280-OUTPUT-DOLLAR  TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-CVG-GDLN-SPREM-AMT
           ELSE
      *MSG: INVALID AMOUNT FIELD ENTERED
               MOVE 'CS07320003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2240-EDIT-CVG-GDLN-SPREM-X.
           EXIT.


      *-------------------------
       2250-EDIT-CVG-GDLN-APREM.
      *-------------------------

           IF  WS-CVG-NUM-N = ZERO
               GO TO 2250-EDIT-CVG-GDLN-APREM-X
           END-IF.

           IF  MIR-CVG-GDLN-APREM-AMT = SPACES
               MOVE L5395-CVG-GDLN-APREM-AMT (WS-CVG-NUM-N)
                                         TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-CVG-GDLN-APREM-AMT
               GO TO 2250-EDIT-CVG-GDLN-APREM-X
           END-IF.

           SET L0280-SIGN-PERMITTED      TO TRUE
           MOVE 2                        TO L0280-PRECISION.
           MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT
                                         TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           MOVE MIR-CVG-GDLN-APREM-AMT   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               IF  NOT L5395-GDLN-STAT-ACTIVE
               AND L0280-OUTPUT-DOLLAR NOT = L5395-CVG-GDLN-APREM-AMT
                                             (WS-CVG-NUM-N)
      *MSG: CANNOT CHANGE AMOUNT ON INACTIVE RECORD
                   MOVE 'CS07320002'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2250-EDIT-CVG-GDLN-APREM-X
               END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                         TO L5395-CVG-GDLN-APREM-AMT
                                            (WS-CVG-NUM-N)
               MOVE L0280-OUTPUT-DOLLAR  TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT
                                         TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-CVG-GDLN-APREM-AMT
           ELSE
      *MSG: INVALID AMOUNT FIELD ENTERED
               MOVE 'CS07320003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2250-EDIT-CVG-GDLN-APREM-X.
           EXIT.



      *------------------
       2260-EDIT-STATUS.
      *------------------

           MOVE MIR-GDLN-STAT-CD         TO WS-STATUS-CODE.

           IF  NOT WS-STATUS-VALID
      *MSG: INVALID STATUS CODE
               MOVE MIR-GDLN-STAT-CD     TO WGLOB-MSG-PARM (1)
               MOVE 'CS07320005'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2260-EDIT-STATUS-X
           END-IF.

           IF  L5395-GDLN-STAT-HISTORY
           AND NOT MIR-GDLN-STAT-HISTORY
      *MSG: CANNOT CHANGE STATUS @1 TO @2
               MOVE L5395-GDLN-STAT-CD   TO WGLOB-MSG-PARM (1)
               MOVE MIR-GDLN-STAT-CD     TO WGLOB-MSG-PARM (2)
               MOVE 'CS07320004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2260-EDIT-STATUS-X
           END-IF.

           IF  L5395-GDLN-STAT-ERROR
           AND NOT MIR-GDLN-STAT-ERROR
      *MSG: CANNOT CHANGE STATUS @1 TO @2
               MOVE L5395-GDLN-STAT-CD   TO WGLOB-MSG-PARM (1)
               MOVE MIR-GDLN-STAT-CD     TO WGLOB-MSG-PARM (2)
               MOVE 'CS07320004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2260-EDIT-STATUS-X
           END-IF.

           IF  L5395-GDLN-STAT-ACTIVE
           AND NOT MIR-GDLN-STAT-ACTIVE
      *MSG: CANNOT CHANGE STATUS @1 TO @2
               MOVE L5395-GDLN-STAT-CD   TO WGLOB-MSG-PARM (1)
               MOVE MIR-GDLN-STAT-CD     TO WGLOB-MSG-PARM (2)
               MOVE 'CS07320004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2260-EDIT-STATUS-X
           END-IF.

           IF  L5395-GDLN-STAT-REVERSED
           AND NOT MIR-GDLN-STAT-ERROR
           AND NOT MIR-GDLN-STAT-REVERSED
      *MSG: REVERSE STATUS CAN ONLY BE CHANGED TO ERROR
               MOVE 'CS07320006'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2260-EDIT-STATUS-X
           ELSE
               IF  MIR-GDLN-STAT-ERROR
               AND L5395-GDLN-STAT-REVERSED
      *MSG: GDLN STATUS CHANGED TO 'ERROR'. CORRESPONDING CHANGE
      *     HISTORY STATUS SHOULD ALSO BE CHANGED.
                   MOVE 'CS07320007'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF  WGLOB-MSG-SEVRTY-FATAL
                       SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   END-IF
                   MOVE L5395-PCHST-SEQ-NUM
                                         TO WS-PCHST-SEQ-NUM
               END-IF
           END-IF.

           MOVE MIR-GDLN-STAT-CD         TO L5395-GDLN-STAT-CD.

       2260-EDIT-STATUS-X.
           EXIT.


      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  5395-0000-INIT-PARM-INFO
               THRU 5395-0000-INIT-PARM-INFO-X.

           PERFORM  5400-0000-INIT-PARM-INFO
               THRU 5400-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-AREA.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           MOVE SPACES                 TO WWKDT-WORK-FIELDS.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPCOMM.
       COPY XCPPEXIT.
       COPY XCPPINIT.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************

       COPY CCPS0620.
       COPY CCPL0620.

       COPY CCPS2430.
       COPY CCPL2430.

       COPY CCPS5395.
       COPY CCPL5395.

       COPY CCPS5400.
       COPY CCPL5400.

       COPY XCPL0260.

       COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPS0290.
       COPY XCPL0290.

       COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************

       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM0732                     **
      *****************************************************************
