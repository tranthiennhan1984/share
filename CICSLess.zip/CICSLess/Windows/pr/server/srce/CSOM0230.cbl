      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0230.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0230                                         **
      **  REMARKS:  THIS MODULE PERFORMS RETRIEVE FUNCTION           **
      **            FOR THE CHTX TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016457**  6.2       NEW                                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0230'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       COPY CCWWINDX.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-RETRIEVE                 VALUE '0230'.
           05  WS-CHQ-DT                               PIC X(10).

       COPY XCWLCOMM REPLACING '$VAR1' BY '0230'.
           15  LCOMM-CURR-KEY.
               20  LCOMM-CHQ-ID                 PIC X(16).
               20  LCOMM-SBSDRY-CO-ID           PIC X(02).
               20  LCOMM-CHQ-DT                 PIC X(10).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCHTD.
       COPY CCFRCHTX.
      /
       COPY CCFWSCOM.
       COPY CCFRSCOM.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
021930*COPY CCWL0620.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0230.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  COMM-1000-INITIALIZE
               THRU COMM-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-RETRIEVE
                        THRU 3000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0230'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *---------------
       3000-RETRIEVE.
      *---------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 3000-RETRIEVE-X
           END-IF.

           PERFORM  CHTD-1000-READ
               THRU CHTD-1000-READ-X.

           IF  NOT WCHTD-IO-OK
      *MSG: 'NO RECORDS FOUND'
               MOVE 'CS02300003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE RCHTX-CHQ-ID          TO LCOMM-CHQ-ID
               MOVE RCHTX-SBSDRY-CO-ID    TO LCOMM-SBSDRY-CO-ID
               MOVE RCHTX-CHQ-DT          TO LCOMM-CHQ-DT
           END-IF.

           PERFORM  COMM-3000-DELETE-TWRK
               THRU COMM-3000-DELETE-TWRK-X.
           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.


       3000-RETRIEVE-X.
           EXIT.


      *----------------
       7000-BUILD-KEYS.
      *----------------

           EVALUATE TRUE

               WHEN MIR-DV-BCKWRD-SCROLL
                    PERFORM  COMM-1000-RETRIEVE-TWRK
                        THRU COMM-1000-RETRIEVE-TWRK-X
                    IF  LCOMM-RETRN-OK
                        PERFORM  7100-GET-PREV-KEY
                            THRU 7100-GET-PREV-KEY-X
                    ELSE
      *MSG: TWRK ERROR - CALL SYSTEMS
                        MOVE 'XS00000243'      TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                    END-IF

               WHEN MIR-DV-FORWRD-SCROLL
                    PERFORM  COMM-1000-RETRIEVE-TWRK
                        THRU COMM-1000-RETRIEVE-TWRK-X
                    IF  LCOMM-RETRN-OK
                        PERFORM  7200-GET-NEXT-KEY
                            THRU 7200-GET-NEXT-KEY-X
                    ELSE
      *MSG: TWRK ERROR - CALL SYSTEMS
                        MOVE 'XS00000243'      TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                    END-IF

           END-EVALUATE.

           PERFORM  7300-EDIT-INPUT
               THRU 7300-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           MOVE MIR-CHQ-ID              TO WCHTD-CHQ-ID.
           MOVE MIR-SBSDRY-CO-ID        TO WCHTD-SBSDRY-CO-ID.
           MOVE WS-CHQ-DT               TO WCHTD-CHQ-DT.


       7000-BUILD-KEYS-X.
           EXIT.

      *-------------------
       7100-GET-PREV-KEY.
      *-------------------

           MOVE LCOMM-CHQ-ID          TO WCHTD-CHQ-ID.
           MOVE LCOMM-SBSDRY-CO-ID    TO WCHTD-SBSDRY-CO-ID.
           MOVE LCOMM-CHQ-DT          TO WCHTD-CHQ-DT.

           MOVE LOW-VALUES            TO WCHTD-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WCHTD-ENDBR-CHQ-DT.

           PERFORM  CHTD-1000-BROWSE-PREV
               THRU CHTD-1000-BROWSE-PREV-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > 2
               OR NOT WCHTD-IO-OK

               PERFORM  CHTD-2000-READ-PREV
                   THRU CHTD-2000-READ-PREV-X

               IF  WCHTD-IO-OK
                   PERFORM  7110-SET-KEY
                       THRU 7110-SET-KEY-X
               END-IF

           END-PERFORM.

           IF  NOT WCHTD-IO-OK
      *MSG: 'END OF LIST'
               MOVE 'XS00000015'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  CHTD-3000-END-BROWSE-PREV
               THRU CHTD-3000-END-BROWSE-PREV-X.

       7100-GET-PREV-KEY-X.
           EXIT.
      /
      *-------------
       7110-SET-KEY.
      *-------------

           MOVE RCHTX-CHQ-ID            TO MIR-CHQ-ID.
           MOVE RCHTX-SBSDRY-CO-ID      TO MIR-SBSDRY-CO-ID.
           MOVE RCHTX-CHQ-DT            TO WS-CHQ-DT.
           MOVE RCHTX-CHQ-DT            TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE               TO MIR-CHQ-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE TO MIR-CHQ-DT
           END-IF.

       7110-SET-KEY-X.
           EXIT.

      *-------------------
       7200-GET-NEXT-KEY.
      *-------------------

           MOVE LCOMM-CHQ-ID          TO WCHTD-CHQ-ID.
           MOVE LCOMM-SBSDRY-CO-ID    TO WCHTD-SBSDRY-CO-ID.
           MOVE LCOMM-CHQ-DT          TO WCHTD-CHQ-DT.

           MOVE HIGH-VALUES           TO WCHTD-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT         TO WCHTD-ENDBR-CHQ-DT.

           PERFORM  CHTD-1000-BROWSE
               THRU CHTD-1000-BROWSE-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > 2
               OR NOT WCHTD-IO-OK

               PERFORM  CHTD-2000-READ-NEXT
                   THRU CHTD-2000-READ-NEXT-X

               IF  WCHTD-IO-OK
                   PERFORM  7110-SET-KEY
                       THRU 7110-SET-KEY-X
               END-IF

           END-PERFORM.

           IF  NOT WCHTD-IO-OK
      *MSG: 'END OF LIST'
               MOVE 'XS00000015'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  CHTD-3000-END-BROWSE
               THRU CHTD-3000-END-BROWSE-X.

       7200-GET-NEXT-KEY-X.
           EXIT.
      /
      *----------------
       7300-EDIT-INPUT.
      *----------------

           PERFORM  7310-EDIT-SBSDRY-CO-ID
               THRU 7310-EDIT-SBSDRY-CO-ID-X.

           PERFORM  7320-EDIT-CHQ-DT
               THRU 7320-EDIT-CHQ-DT-X.

       7300-EDIT-INPUT-X.
           EXIT.

      *-----------------------
       7310-EDIT-SBSDRY-CO-ID.
      *-----------------------

           MOVE MIR-SBSDRY-CO-ID            TO WSCOM-SBSDRY-CO-ID.
           PERFORM  SCOM-1000-READ
               THRU SCOM-1000-READ-X.
           IF  NOT WSCOM-IO-OK
      *MSG: SUB CO DOES NOT EXIST
               MOVE 'CS02300001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7310-EDIT-SBSDRY-CO-ID-X.
           EXIT.

      *-------------------
       7320-EDIT-CHQ-DT.
      *-------------------

           MOVE MIR-CHQ-DT               TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      ****MSG: INVALID DATE
               MOVE 'CS02300002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WWKDT-LOW-DT         TO WS-CHQ-DT
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-CHQ-DT
           END-IF.

       7320-EDIT-CHQ-DT-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RCHTX-CHQ-ID             TO MIR-CHQ-ID.
           MOVE RCHTX-SBSDRY-CO-ID       TO MIR-SBSDRY-CO-ID.

           MOVE RCHTX-CHQ-DT             TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CHQ-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CHQ-DT
           END-IF.

           MOVE RCHTX-CHQ-MICR-NUM       TO MIR-CHQ-MICR-NUM.

020874*    COMPUTE L0290-INPUT-NUMBER = RCHTX-CHQ-AMT * 100.
020874     MOVE RCHTX-CHQ-AMT            TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CHQ-AMT    TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CHQ-AMT.

           MOVE RCHTX-CHQ-CRCY-CD        TO MIR-CHQ-CRCY-CD.
           MOVE RCHTX-CHQ-PAYE-1-TXT     TO MIR-CHQ-PAYE-1-TXT.
           MOVE RCHTX-CHQ-PAYE-2-TXT     TO MIR-CHQ-PAYE-2-TXT.

           MOVE RCHTX-CHQ-PRCES-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CHQ-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CHQ-PRCES-DT
           END-IF.

           MOVE RCHTX-CHQ-TYP-CD         TO MIR-CHQ-TYP-CD.
           MOVE RCHTX-CHQ-STAT-CD        TO MIR-CHQ-STAT-CD.


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-WORKING-STORAGE.
025970
025970     INITIALIZE  FREQUENTLY-USED-INDICES.
025970     
025970     MOVE SPACES TO  WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
       COPY XCPSCOMM.
       COPY XCPPCOMM.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.

021930*COPY CCPL0620.

025970 COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCHTD.
       COPY CCPBCHTD.
       COPY CCPVCHTD.
      /
       COPY CCPNSCOM.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0230
      *****************************************************************
