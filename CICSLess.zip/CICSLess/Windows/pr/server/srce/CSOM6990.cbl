      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM6990.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6990                                         **
      **  REMARKS:  POLI - POLICY INQUIRY RRIF INFORMATION           **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       ARCHITECTURAL CHANGES                            **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
017243**  6.4       REMOVE EXTRA FIELDS FROM POLICY INQUIRY          **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6990'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


      *COPY XCWL0030.
021930*COPY XCWWCVGM.

025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                      PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT          VALUE 'POLI'.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                      PIC X(04)
025970*                                           VALUE 'POLI'.
           05  WS-SUBD                            PIC 9(03).
      *    05  WS-START-CVGNO                     PIC S9(4)  COMP.
           05  WS-START-CVGNO                     PIC S9(4)  BINARY.
      *    05  WS-END-CVGNO                       PIC S9(4)  COMP.
           05  WS-END-CVGNO                       PIC S9(4)  BINARY.
           05  WS-FOUND-PRIMARY-SW                PIC X(01).
               88  WS-FOUND-PRIMARY               VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS           VALUE 'N'.
           05  WS-SCREEN-CLIENT                   PIC X(10).
      *    05  WS-SUB                             PIC S9(04)    COMP.
           05  WS-SUB                             PIC S9(04)    BINARY.
           05  WS-CONN-POL-CVG-INFO.
               10  WS-CONN-POL-ID-BASE            PIC X(09).
               10  WS-CONN-POL-ID-SFX             PIC X(01).
               10  WS-CONN-CVG-NUM                PIC X(02).

       01  WS-EDIT-PROCESS-CHECKS.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-BLANK         VALUE SPACES.
               88  WS-BUS-FCN-VALID         VALUE '6990'.
               88  WS-BUS-FCN-RRIF-INFO     VALUE '6990'.

           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.

           05  WS-CLIENT-FOUND-SW           PIC X(01).
               88  WS-CLIENT-FOUND          VALUE 'Y'.
               88  WS-NO-CLIENT-FOUND       VALUE 'N'.

016440*    05  WS-POL-APPL-CTL-CD           PIC X(02).
016440*        88  WS-POL-APP-CTL-ADMIN     VALUE 'AD'.
016440*        88  WS-POL-APP-CTL-NBS       VALUE 'NB'.

           05  WS-POLICY.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
017243*    05  WS-CVG-NUM              PIC X(02).
017243*        88  WS-CVG-NUM-BLANK    VALUE SPACES ZEROS.
017243*    05  WS-CVG-NUM-R            REDEFINES
017243*        WS-CVG-NUM              PIC 9(02).
           05  WS-CURR-DATE.
               10  WS-CURR-YEAR             PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-CURR-MONTH            PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-CURR-DAY              PIC 9(02).
           05  WS-COMPANY                   PIC X(02).

           05  WS-POL-STATUS                PIC X(04).

       01  WS-NUMERIC-CONVERSIONS.
           05  WS-PIC-0-5                   PIC -.9(5).
           05  WS-PIC-1-2                   PIC -9.99.
           05  WS-PIC-1-4                   PIC -9.9(4).
           05  WS-PIC-1-5                   PIC -9.9(5).
           05  WS-PIC-2                     PIC -(2)9.
           05  WS-PIC-2-3                   PIC -(2)9.9(3).
           05  WS-PIC-2-7                   PIC --9.9(7).
           05  WS-PIC-P3-1                  PIC 999.9.
           05  WS-PIC-3-2                   PIC -(3)9.99.
           05  WS-PIC-3-3                   PIC -(3)9.999.
           05  WS-PIC-3-4                   PIC -(3)9.9(4).
           05  WS-PIC-2-4                   PIC -(2)9.9(4).
           05  WS-PIC-2-5                   PIC Z9.9(5).
           05  WS-PIC-3-6                   PIC -(3)9.9(6).
           05  WS-PIC-4-5                   PIC -(4)9.9(5).
           05  WS-PIC-5-4                   PIC -(5)9.9(4).
           05  WS-PIC-P6-5                  PIC Z(5)9.9(5).
           05  WS-PIC-8-5                   PIC -(8)9.9(5).

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
      *
       COPY CCWWINDX.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
       COPY CCFWPOLC.
       COPY CCFRPOLC.
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************
028298 COPY CCWL2626.
       COPY XCWL0290.

       COPY CCWL0620.
       COPY CCWL2430.
      *
       COPY CCWL5400.
      *
       COPY CCWL6927.
      *
       COPY XCWLDTLK.
016537*COPY XCWL0225.
021930*COPY XCWL0280.
       COPY XCWL1640.
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM6990.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           INITIALIZE L2430-OUTPUT-PARM-INFO.
           INITIALIZE RPOL-REC-INFO.

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  0100-SET-MIR-VALUES
               THRU 0100-SET-MIR-VALUES-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------
       0100-SET-MIR-VALUES.
      *--------------------

           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX.
           MOVE WS-BUS-FCN-ID         TO MIR-BUS-FCN-ID.
017243*    MOVE WS-CVG-NUM            TO MIR-CVG-NUM.

       0100-SET-MIR-VALUES-X.
           EXIT.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

           PERFORM  9500-SETUP-MSIN-REFERENCE
               THRU 9500-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           MOVE WGLOB-PROCESS-DATE    TO WS-CURR-DATE.
           MOVE SPACES                TO WS-SCREEN-CLIENT.

           PERFORM  2050-SET-WS-FROM-MIR
               THRU 2050-SET-WS-FROM-MIR-X.

           SET WS-NO-ERRORS-FOUND      TO TRUE.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2200-MORE-INITIAL-EDITS
               THRU 2200-MORE-INITIAL-EDITS-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.

           PERFORM  3000-DISPLAY-SCREEN
               THRU 3000-DISPLAY-SCREEN-X.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *---------------------
       2050-SET-WS-FROM-MIR.
      *---------------------

           MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SFX.
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
017243*    MOVE MIR-CVG-NUM           TO WS-CVG-NUM.

           MOVE WGLOB-COMPANY-CODE    TO WS-COMPANY.

       2050-SET-WS-FROM-MIR-X.
           EXIT.
      *
      *------------------------
       2200-MORE-INITIAL-EDITS.
      *------------------------

           MOVE WS-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    POLICY RECORD NOT FOUND (@1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

017243*    MOVE 'N'                   TO L0280-SIGN-IND.
017243*    MOVE 2                     TO L0280-LENGTH.
017243*    MOVE ZERO                  TO L0280-PRECISION.
017243*    MOVE WS-CVG-NUM            TO L0280-INPUT-DATA.
017243*
017243*    PERFORM  0280-1000-NUMERIC-EDIT
017243*        THRU 0280-1000-NUMERIC-EDIT-X.
017243*
017243*    IF  L0280-OK
017243*        MOVE L0280-OUTPUT      TO WS-CVG-NUM-R
017243*        IF  WS-CVG-NUM > WCVGM-MAX-WCVGS-NUM
017243*            SET WS-ERROR-FOUND      TO TRUE
017243*MSG:        COVERAGE MUST BE NUMERIC
017243*            MOVE 'XS00000079'  TO WGLOB-MSG-REF-INFO
017243*            MOVE WS-CVG-NUM    TO WGLOB-MSG-PARM (1)
017243*            MOVE WCVGM-MAX-WCVGS-NUM
017243*                               TO  WGLOB-MSG-PARM (2)
017243*            PERFORM  0260-1000-GENERATE-MESSAGE
017243*                THRU 0260-1000-GENERATE-MESSAGE-X
017243*        END-IF
017243*    ELSE
017243*        SET WS-ERROR-FOUND      TO TRUE
017243*MSG:    COVERAGE MUST BE NUMERIC
017243*        MOVE 'XS00000079'      TO WGLOB-MSG-REF-INFO
017243*        MOVE WS-CVG-NUM        TO WGLOB-MSG-PARM (1)
017243*        MOVE WCVGM-MAX-WCVGS-NUM
017243*                               TO  WGLOB-MSG-PARM (2)
017243*        PERFORM  0260-1000-GENERATE-MESSAGE
017243*            THRU 0260-1000-GENERATE-MESSAGE-X
017243*    END-IF.

           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.
      *
      * PERFORM CONFIDENTIAL POLICY AND BRANCH LEVEL SECURITY CHECKS
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

016440     SET L5400-POL-XFER-INQ      TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
               SET WS-ERROR-FOUND      TO TRUE
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

           IF  RPOL-POL-CVG-REC-CTR-N = ZEROS
      *MSG:    NO COVERAGES TO DISPLAY
               MOVE 'XS00000095'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
017243*    ELSE
017243*        IF  WS-CVG-NUM-R > RPOL-POL-CVG-REC-CTR-N
017243*MSG:        'COVERAGE (@1) DOES NOT EXIST'
017243*            MOVE 'XS00000080'  TO WGLOB-MSG-REF-INFO
017243*            MOVE WS-CVG-NUM    TO WGLOB-MSG-PARM (1)
017243*            PERFORM  0260-1000-GENERATE-MESSAGE
017243*                THRU 0260-1000-GENERATE-MESSAGE-X
017243*        END-IF
           END-IF.

           PERFORM  2210-READ-ALL-CVG
               THRU 2210-READ-ALL-CVG-X
               VARYING WS-SUBD FROM 1 BY 1
               UNTIL   WS-SUBD > RPOL-POL-CVG-REC-CTR-N
               OR      WS-ERROR-FOUND.

           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

       2200-MORE-INITIAL-EDITS-X.
           EXIT.
      *
      *------------------
       2210-READ-ALL-CVG.
      *------------------

           MOVE WS-POL-ID-BASE        TO WCVG-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WCVG-POL-ID-SFX.
           MOVE WS-SUBD               TO WCVG-CVG-NUM-N.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  WCVG-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'POLICY & COVERAGE (@1) OUT OF SYNC ...'
               MOVE 'XS00000084'      TO WGLOB-MSG-REF-INFO
017243*        MOVE WS-CVG-NUM        TO WGLOB-MSG-PARM (1)
017243         MOVE WCVG-CVG-NUM      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2210-READ-ALL-CVG-X
           END-IF.

           MOVE RCVG-CVG-INFO         TO WCVGS-CVG-INFO (WS-SUBD).
           MOVE WS-SUBD               TO WCVGS-CVG-SEQ-NUM-N (WS-SUBD).

       2210-READ-ALL-CVG-X.
           EXIT.
      *
      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------

           SET  WS-NO-CLIENT-FOUND TO TRUE.

017243*    IF  WS-CVG-NUM-BLANK
017243*        MOVE +1                TO WS-START-CVGNO
017243*    ELSE
017243*        MOVE WS-CVG-NUM-R      TO WS-START-CVGNO
017243*    END-IF.
017243     MOVE +1                    TO WS-START-CVGNO.

           MOVE WS-START-CVGNO        TO WS-END-CVGNO.

           IF  WS-END-CVGNO > RPOL-POL-CVG-REC-CTR-N
               MOVE RPOL-POL-CVG-REC-CTR-N
                                      TO WS-END-CVGNO
           END-IF.
      *
      * READ AND FORMAT OWNERS NAME
      *
           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
           END-IF.
           MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM.
           MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
           MOVE RPOL-POL-CVG-REC-CTR  TO MIR-POL-CVG-REC-CTR.

           MOVE RPOL-POL-CSTAT-CD     TO WS-POL-STATUS.

           MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

       2300-COMMON-LINE-SET-X.
           EXIT.
      *
      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF WS-POLICY         = SPACES
               GO TO 2320-GET-OWNER-X
           END-IF.

           IF  L2430-CLI-ID = SPACES
               PERFORM  2400-CHECK-FOR-OWNER-CLI
                   THRU 2400-CHECK-FOR-OWNER-CLI-X
           ELSE
               IF  L2430-CLI-NM-COMPRESSED = SPACES
      *MSG:        OWNER CLIENT NAME = SPACES
                   MOVE 'CS69900006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2320-GET-OWNER-X.
           EXIT.
      *
      *-------------------------
       2400-CHECK-FOR-OWNER-CLI.
      *-------------------------
      *
      * BUILD START/END BROWSE KEY
      *
           MOVE LOW-VALUES            TO  WPOLC-KEY.
           MOVE RPOL-POL-ID           TO  WPOLC-POL-ID.
           MOVE 'O'                   TO  WPOLC-POL-CLI-REL-TYP-CD.

           MOVE WPOLC-KEY             TO  WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO  WPOLC-ENDBR-CLI-ID.

      *
      *  POSITION AT THE FIRST RECORD FOR THE GIVEN RELATIONSHIP
      *
           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

           IF  WPOLC-IO-OK
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

           IF  WPOLC-IO-EOF
               MOVE 'CS69900007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           SET  WS-NO-PRIMARY-EXISTS TO TRUE.
           PERFORM  2500-DETERMINE-IF-PRIMARY
               THRU 2500-DETERMINE-IF-PRIMARY-X
               UNTIL WPOLC-IO-EOF
               OR    WS-FOUND-PRIMARY.

           IF  WS-NO-PRIMARY-EXISTS
               MOVE 'CS69900007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           PERFORM  2600-FIND-OWNERS-LOOP
               THRU 2600-FIND-OWNERS-LOOP-X
               UNTIL WPOLC-IO-EOF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.

       2400-CHECK-FOR-OWNER-CLI-X.
           EXIT.

      *--------------------------
       2500-DETERMINE-IF-PRIMARY.
      *--------------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD = 'P'
               SET WS-FOUND-PRIMARY TO TRUE
               GO TO 2500-DETERMINE-IF-PRIMARY-X
           END-IF.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2500-DETERMINE-IF-PRIMARY-X.
           EXIT.

      *----------------------
       2600-FIND-OWNERS-LOOP.
      *----------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD NOT = 'P'
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
               GO TO 2600-FIND-OWNERS-LOOP-X
           END-IF.

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
      *
      * WE HAVE FOUND THE REQUIRED RECORD, READ THE CLIENT FILE
      *
           MOVE  RPOLC-CLI-ID         TO  L2430-CLI-ID.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

       2600-FIND-OWNERS-LOOP-X.
           EXIT.
      *
      *--------------------
       3000-DISPLAY-SCREEN.
      *--------------------

           PERFORM  6927-1000-BUILD-PARM-INFO
               THRU 6927-1000-BUILD-PARM-INFO-X.

           PERFORM  6927-1000-INQUIRE
               THRU 6927-1000-INQUIRE-X.

      *    PERFORM  6927-2000-RETRN-PARM-INFO
      *        THRU 6927-2000-RETRN-PARM-INFO-X.

           PERFORM  4000-RETRN-PARM-INFO
               THRU 4000-RETRN-PARM-INFO-X.

       3000-DISPLAY-SCREEN-X.
           EXIT.
      *
      *---------------------
       4000-RETRN-PARM-INFO.
      *---------------------

           MOVE L6927-ANNP1                   TO MIR-ANPAYO-1-DEST-CD.
           MOVE L6927-CNRSN                   TO MIR-CVG-CONN-REASN-CD.
           MOVE L6927-CONPN                   TO WS-CONN-POL-CVG-INFO.
           MOVE WS-CONN-POL-ID-BASE           TO MIR-CONN-POL-ID-BASE.
           MOVE WS-CONN-POL-ID-SFX            TO MIR-CONN-POL-ID-SFX.
           MOVE WS-CONN-CVG-NUM               TO MIR-CONN-CVG-NUM.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-FTNYR * 100.
020874     MOVE L6927-FTNYR                   TO L0290-INPUT-V02.  
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAXWH-NYR-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-FED-TAXWH-NYR-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-FTSSP * 100.
020874     MOVE L6927-FTSSP                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAX-SUSP-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-FED-TAX-SUSP-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-FTWHD * 100.
020874     MOVE L6927-FTWHD                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-AMT   TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-PAYO-FTAXWH-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA             TO MIR-FED-TAXWH-AMT.
029060     MOVE L0290-OUTPUT-DATA             TO MIR-PAYO-FTAXWH-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-FTYTD * 100.
020874     MOVE L6927-FTYTD                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAXWH-YTD-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-FED-TAXWH-YTD-AMT.

           MOVE L6927-IAEDT                   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE       TO MIR-POL-ANPAYO-EFF-DT
           ELSE
               MOVE SPACES                    TO MIR-POL-ANPAYO-EFF-DT
           END-IF.

           MOVE L6927-IAMOD                   TO MIR-POL-ANPAYO-MODE-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-IAMT1 * 100.
020874     MOVE L6927-IAMT1                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-ANPAYO-1-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-POL-ANPAYO-1-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-LTDPY * 100.
020874     MOVE L6927-LTDPY                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-ANPAYO-LTD-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-POL-ANPAYO-LTD-AMT.

           MOVE L6927-LTPAY                   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE       TO MIR-POL-ANPAYO-PMT-DT
           ELSE
               MOVE SPACES                    TO MIR-POL-ANPAYO-PMT-DT
           END-IF.

           MOVE L6927-MTHD1                   TO MIR-ANPAYO-1-MTHD-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-PTNYR * 100.
020874     MOVE L6927-PTNYR                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PROV-TAXWH-NYR-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-PROV-TAXWH-NYR-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-PTSSP * 100.
020874     MOVE L6927-PTSSP                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PROV-TAX-SUSP-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-PROV-TAX-SUSP-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-PTWHD * 100.
020874     MOVE L6927-PTWHD                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PROV-TAXWH-AMT  TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-PROV-TAXWH-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-PTYTD * 100.
020874     MOVE L6927-PTYTD                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PROV-TAXWH-YTD-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-PROV-TAXWH-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-TXADL * 100.
020874     MOVE L6927-TXADL                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAXWH-ADDL-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-FED-TAXWH-ADDL-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-TXPRN * 100.
020874     MOVE L6927-TXPRN                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-PAYO-AMT  TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-TAXBL-PAYO-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-YTDPY * 100.
020874     MOVE L6927-YTDPY                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-ANPAYO-YTD-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-POL-ANPAYO-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-CSLYTD * 100.
020874     MOVE L6927-CSLYTD                  TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CASL-PMT-YTD-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-CASL-PMT-YTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-AUTOP * 100.
020874     MOVE L6927-AUTOP                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-AUTO-ANPAYO-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-DV-AUTO-ANPAYO-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-RRIFS * 100.
020874     MOVE L6927-RRIFS                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-ANTY-SUSP-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-POL-ANTY-SUSP-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-MNPAY * 100.
020874     MOVE L6927-MNPAY                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-RRIF-MNPMT-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-POL-RRIF-MNPMT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6927-MXPAY * 100.
020874     MOVE L6927-MXPAY                   TO L0290-INPUT-V02.
           MOVE 2                             TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-LIF-MXPMT-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY             TO TRUE.
           SET L0290-SIGN-FLOAT               TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-POL-LIF-MXPMT-AMT.

       4000-RETRN-PARM-INFO-X.
           EXIT.
      *
      *--------------------------
       9500-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.

       9500-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6927-0000-INIT-PARM-INFO
025970         THRU 6927-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-PROCESS-CHECKS.
025970     SET WS-TRANS-NAME-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
      *
       COPY CCPSPGA.
      *
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      *
       COPY XCPS0290.
       COPY XCPL0290.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
       COPY CCPS6927.
018764*COPY CCCL6927.
018764 COPY CCPL6927.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
016537*COPY XCCL0225.
      *
021930*COPY XCPL0280.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNCVG.
      *
       COPY CCPNPOL.
      *
       COPY CCPBPOLC.
      *
      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6990                     **
      *****************************************************************
