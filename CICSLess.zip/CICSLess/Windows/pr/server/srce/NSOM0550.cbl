      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0550.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0550                                         **
      **  REMARKS:  TOTI - TOTAL INSURANCE INFORCE - LIFE            **
      **                                                             **
      **            THIS MODULE PERFORMS THE MAINTENANCE FUNCTIONS   **
      **            OF THE TOTAL INSURANCE INFORCE BY CLIENT.        **
      **            INFORMATION IS STORED ON THE APPLICATION FIXED   **
      **            INFORMATION TABLE.                               **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       GLOBAL CHANGES                                   **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       MODIFICATIONS FOR FORMAT CLIENT FULL NAME        **
014221**  6.2       LOGICAL LOCKING                                  **
016387**  6.2       REMOVE CLIENT CONSOLIDATION SUPPORT              **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
018622**  6.4       LOGICAL LOCKING FOR CREATE FLOW                  **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0550'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'TOTI'.
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
025970*    05  WS-DISPLAY-SUB               PIC ZZZ9   VALUE ZERO.
025970     05  WS-DISPLAY-SUB               PIC ZZZ9.
025970         88  WS-DEFAULT-DISPLAY-SUB              VALUE ZERO.
           05  WS-PIC-DATE.
               10  WS-PIC-DATE-YR           PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-PIC-DATE-MO           PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-PIC-DATE-DA           PIC 9(02).
           05  WS-PROCESS-YEAR              PIC 9999.
008455*    05  WS-PIC-DOLLAR                PIC 9(05)9.
008455*    05  WS-N-DOLLAR                  PIC S9(6).
008455*    05  WS-PIC-DOL-9                 PIC 9(08)9.
008455*    05  WS-N-DOL-9                   PIC S9(09).
           05  WS-PIC-9999                  PIC 9999.
           05  WS-N-9999                    PIC S9(04).
           05  WS-VALIDATE-CONTROL          PIC X(01).
               88  WS-INVALID-CONTROL                  VALUE '1'.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-VALID         VALUE
013578             '0550' '0552'.
013578         88  WS-BUS-FCN-RETRIEVE      VALUE '0550'.
013578         88  WS-BUS-FCN-UPDATE        VALUE '0552'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0550'.
           05  WS-EDIT-OK-SW                PIC X(01).
               88  WS-EDIT-OK               VALUE '0'.
               88  WS-CROSS-EDIT-ERR        VALUE '2'.
025970*    05  WS-YRISS-SW                  PIC X(01) VALUE 'Y'.
025970     05  WS-YRISS-SW                  PIC X(01).
025970         88  WS-DEFAULT-YRISS         VALUE 'Y'.
               88  WS-YRISS-OK              VALUE 'Y'.
               88  WS-YRISS-NOT-OK          VALUE 'N'.
025970*    05  WS-OTHER-DATA-ENTERED-SW     PIC X(01) VALUE 'N'.
025970     05  WS-OTHER-DATA-ENTERED-SW     PIC X(01).
025970         88  WS-DEFAULT-OTHER-DATA-ENTERED      VALUE 'N'.
               88  WS-OTHER-DATA-WAS-ENTERED VALUE 'Y'.
               88  WS-OTHER-DATA-NOT-ENTERED VALUE 'N'.
025970*    05  WS-LINE-DATA-ENTERED-SW      PIC X(01) VALUE 'N'.
025970     05  WS-LINE-DATA-ENTERED-SW      PIC X(01).
025970         88  WS-DEFAULT-LINE-DATA-ENTERED       VALUE 'N'.
               88  WS-LINE-DATA-WAS-ENTERED  VALUE 'Y'.
           05  WS-TEST-OTHIP                PIC X(01).
               88  WS-OTHIP-OK              VALUE ' ' 'I' 'P'.
           05  WS-TEST-REFTC                PIC X(01).
               88  WS-REFTC-OK              VALUE ' ' 'Y' 'N'.
           05  WS-TEST-WDIND                PIC X(01).
               88  WS-WDIND-OK              VALUE ' ' 'Y' 'N'.
           05  WS-TEST-OITCO                PIC X(01).
               88  WS-OITCO-OK              VALUE ' ' 'Y' 'N'.
           05  WS-TEST-REFIN                PIC X(01).
               88  WS-REFIN-OK              VALUE ' ' 'Y' 'N'.
               88  WS-REFIN-YES             VALUE  'Y'.
           05  WS-TEST-OTHBP                PIC X(01).
               88  WS-OTHBP-OK              VALUE ' ' 'B' 'P'.
           05  WS-TEST-OIPIN                PIC X(01).
               88  WS-OIPIN-OK              VALUE 'Y' 'N' ' '.
           05  WS-TEST-ITYPE                PIC X(01).
               88  WS-ITYPE-OK              VALUE 'A' 'H' 'L' 'O'.
               88  WS-ITYPE-HEALTH          VALUE 'H'.
           05  WS-TEST-COMMENT.
               10  WS-COMMENT-2             PIC X(02).
               10  WS-COMMENT-12 REDEFINES WS-COMMENT-2.
                   15  WS-COMMENT-1         PIC X(01).
                   15  FILLER               PIC X(01).
               10  FILLER                   PIC X(13).
           05  WS-CLIO-DATA-SW              PIC X(01).
               88  WS-CLIO-DATA-TO-WRITE         VALUE 'Y'.
               88  WS-CLIO-NO-DATA-TO-WRITE      VALUE ' '.

025970*
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'TOTI'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '0550'.
      *
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
       COPY XCWEBLCH.

      ** WORK ARRAY FOR CLIO **

       COPY NCFWAPPF.
       COPY NCFRAPPF.

       COPY CCFWEDIT.
       COPY CCFREDIT.

014221 COPY CCFWCLI.
014221 COPY CCFRCLI.

028298 COPY CCWL2626.
       COPY XCWL0280.
008455 COPY XCWL0290.
       COPY CCWL0620.

       COPY XCWLDTLK.
       COPY XCWL1640.
014221 COPY XCWL8090.

       COPY NCWL2437.
       COPY NCWL5850.
       COPY CCWL5600.

      *
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0550.

      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
013578     SET MIR-RETRN-OK            TO TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

013578     PERFORM  2000-PROCESS-REQUEST
013578         THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.


      *********************
013578 2000-PROCESS-REQUEST.
      **********************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.

           PERFORM  7000-VALIDATE-ACCESS
               THRU 7000-VALIDATE-ACCESS-X.

           IF  L2437-RETRN-CLI-NOT-FOUND
           OR  L5600-CNFD-ACCS-RESTRICTED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
013578         GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *

           EVALUATE TRUE

013578         WHEN WS-BUS-FCN-RETRIEVE
013578              PERFORM  3000-PROCESS-RETRIEVE
013578                  THRU 3000-PROCESS-RETRIEVE-X

013578         WHEN WS-BUS-FCN-UPDATE
013578              PERFORM  4200-PROCESS-UPDATE
013578                  THRU 4200-PROCESS-UPDATE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2950'        TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

013578 2000-PROCESS-REQUEST-X.
           EXIT.

      /
      ***************************************************************
      *   INQUIRY PROCESSING: SETUP BROWSW KEYS, BEGIN BROWSE AND
      *   LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.
      ***************************************************************
      ***********************
013578 3000-PROCESS-RETRIEVE.
      ***********************
      *
           PERFORM  8000-BUILD-APPF-KEY
               THRU 8000-BUILD-APPF-KEY-X.
      *
018622     MOVE MIR-CLI-ID         TO WCLI-CLI-ID.
018622     PERFORM  CLI-1000-READ-TWRK-TS
018622         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  APPF-1000-READ
               THRU APPF-1000-READ-X.
      *
           IF  NOT WAPPF-IO-OK
               MOVE 'XS00000118'   TO WGLOB-MSG-REF-INFO
               MOVE WAPPF-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
013578         GO TO 3000-PROCESS-RETRIEVE-X
           ELSE
018622*        MOVE MIR-CLI-ID        TO WCLI-CLI-ID
018622*        PERFORM  CLI-1000-READ-TWRK-TS
018622*            THRU CLI-1000-READ-TWRK-TS-X
               PERFORM  8200-BUILD-CLIO-KEY
                   THRU 8200-BUILD-CLIO-KEY-X
               PERFORM  5850-1000-LOAD-CLIO-ARRAY
                   THRU 5850-1000-LOAD-CLIO-ARRAY-X
557660     END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE 'XS00000002'   TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

013578 3000-PROCESS-RETRIEVE-X.
           EXIT.

      /
      *--------------------
013578 4200-PROCESS-UPDATE.
      *--------------------

           IF  L5600-CCAS-ACCS-RESTRICTED
013578         GO TO 4200-PROCESS-UPDATE-X
           END-IF.

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CLI'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WCLI-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 4200-PROCESS-UPDATE-X
014221     END-IF.

013578
013578     PERFORM  8000-BUILD-APPF-KEY
013578         THRU 8000-BUILD-APPF-KEY-X.
013578
013578*   CHECK IF RECORD EXISTS.
013578
013578     PERFORM  APPF-1000-READ
013578         THRU APPF-1000-READ-X.
013578
013578     PERFORM  8200-BUILD-CLIO-KEY
013578         THRU 8200-BUILD-CLIO-KEY-X.
013578
013578     PERFORM  5850-1000-LOAD-CLIO-ARRAY
013578         THRU 5850-1000-LOAD-CLIO-ARRAY-X.
013578
013578     IF  WAPPF-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
013578     ELSE
013578         PERFORM  APPF-1000-CREATE
013578             THRU APPF-1000-CREATE-X
013578         PERFORM  4210-DEFAULT-PREGNANCY-IND
013578             THRU 4210-DEFAULT-PREGNANCY-IND-X
013578         PERFORM  APPF-1000-WRITE
013578             THRU APPF-1000-WRITE-X
013578     END-IF.

           PERFORM  8000-BUILD-APPF-KEY
               THRU 8000-BUILD-APPF-KEY-X.

           PERFORM  APPF-1000-READ-FOR-UPDATE
               THRU APPF-1000-READ-FOR-UPDATE-X.

           IF  WAPPF-IO-OK
               PERFORM  8200-BUILD-CLIO-KEY
                   THRU 8200-BUILD-CLIO-KEY-X
      *
               PERFORM  5850-1000-LOAD-CLIO-ARRAY
                   THRU 5850-1000-LOAD-CLIO-ARRAY-X
           ELSE
               MOVE 'XS00000016'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
013578*        GO TO 4200-ADD-PART-2-X
013578         GO TO 4200-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  5000-EDIT-FIELDS
               THRU 5000-EDIT-FIELDS-X.

           PERFORM  APPF-2000-REWRITE
               THRU APPF-2000-REWRITE-X.

014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  4230-CHECK-FOR-DATA-TO-WRITE
               THRU 4230-CHECK-FOR-DATA-TO-WRITE-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 6.

           IF WS-CLIO-DATA-TO-WRITE
               PERFORM  5850-2000-UPDATE-CLIO
                   THRU 5850-2000-UPDATE-CLIO-X
557660     END-IF.
      *
      * UPDATE THE LAST UPD DATE ON THE SCREEN
      *
014221*    MOVE RAPPF-PREV-UPDT-DT      TO L1640-INTERNAL-DATE.
014221*    MOVE RAPPF-PREV-UPDT-TS      TO L1640-INTERNAL-DATE.
014221     MOVE RAPPF-PREV-UPDT-TS      TO WWKDT-INT-TS.
014221     MOVE WWKDT-INT-TS            TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
014221*    MOVE L1640-EXTERNAL-DATE     TO MIR-PREV-UPDT-DT.
014221     MOVE L1640-EXTERNAL-DATE     TO MIR-DV-PREV-UPDT-DT.

           IF  WS-EDIT-OK
               MOVE 'XS00000007'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013578 4200-PROCESS-UPDATE-X.
           EXIT.


       4210-DEFAULT-PREGNANCY-IND.

           IF  L2437-CLI-SEX-CD NOT = 'F'
               MOVE 'N' TO RAPPF-CLI-PREG-IND
557660     END-IF.

       4210-DEFAULT-PREGNANCY-IND-X.
           EXIT.


       4230-CHECK-FOR-DATA-TO-WRITE.

           IF MIR-CLI-OINS-CO-NM-T (WS-SUB) NOT = SPACES
           OR MIR-OINS-INFC-PEND-CD-T (WS-SUB) NOT = SPACES
           OR MIR-OINS-THIS-CO-IND-T (WS-SUB) NOT = SPACES
           OR MIR-OINS-BUS-PERS-CD-T (WS-SUB) NOT = SPACES
           OR MIR-CLI-OINS-TOT-AMT-T (WS-SUB) > ZERO
           OR MIR-CLI-OINS-ADB-AMT-T (WS-SUB) > ZERO
           OR MIR-OINS-WP-INFC-IND-T (WS-SUB) NOT = SPACES
           OR MIR-CLI-OINS-ISS-YR-T (WS-SUB) > ZERO
           OR MIR-OINS-INS-TYP-CD-T (WS-SUB) NOT = SPACES
               MOVE 'Y' TO WS-CLIO-DATA-SW
               MOVE 'Y' TO L5850-CLIO-DATA-THIS-LINE (WS-SUB)
557660     END-IF.

       4230-CHECK-FOR-DATA-TO-WRITE-X.
           EXIT.

      /
       5000-EDIT-FIELDS.

           MOVE '0'       TO WS-EDIT-OK-SW.

           PERFORM  5100-EDIT-OIPIN
               THRU 5100-EDIT-OIPIN-X.

           PERFORM  5200-EDIT-SPAMT
               THRU 5200-EDIT-SPAMT-X.

           PERFORM  5400-EDIT-OINS-DETAIL-ARRAY
               THRU 5400-EDIT-OINS-DETAIL-ARRAY-X
                    VARYING WS-SUB FROM 1 BY 1
                    UNTIL WS-SUB > 6.

           PERFORM  5300-EDIT-REFIN
               THRU 5300-EDIT-REFIN-X.

           PERFORM  5350-EDIT-REFYR
               THRU 5350-EDIT-REFYR-X.

           PERFORM  6200-EDIT-REFUSED-INFO
               THRU 6200-EDIT-REFUSED-INFO-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 2.
      *
      *   CROSS EDITS
      *
           PERFORM  6700-KEY-FIELD-CROSS-EDITS
               THRU 6700-KEY-FIELD-CROSS-EDITS-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 6.

           PERFORM  6750-OINS-CROSS-EDITS
               THRU 6750-OINS-CROSS-EDITS-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 6.

           IF  MIR-OINS-INFC-PEND-IND  IS EQUAL TO 'Y'
           AND WS-OTHER-DATA-NOT-ENTERED
               MOVE 'NS05500022'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WS-EDIT-OK
                   MOVE '2'        TO WS-EDIT-OK-SW
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               IF  MIR-OINS-INFC-PEND-IND = 'N'
               AND WS-OTHER-DATA-WAS-ENTERED
                   MOVE 'NS05500026' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF  WS-EDIT-OK
                       MOVE '2'    TO WS-EDIT-OK-SW
034802*            ELSE
034802*                NEXT SENTENCE
557660             END-IF
557660         END-IF
557660     END-IF.

           PERFORM 6600-EDIT-RRSN-TO-REFIN
              THRU 6600-EDIT-RRSN-TO-REFIN-X.

       5000-EDIT-FIELDS-X.
           EXIT.

      *
      *****************************************************************
      *  OTHER INSURANCE IND: MUST BE Y OR N OR BLANK
      *****************************************************************
       5100-EDIT-OIPIN.

           IF MIR-OINS-INFC-PEND-IND  = SPACES
               MOVE RAPPF-OINS-INFC-PEND-IND TO MIR-OINS-INFC-PEND-IND
               GO TO 5100-EDIT-OIPIN-X
557660     END-IF.

           IF MIR-OINS-INFC-PEND-IND  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES        TO MIR-OINS-INFC-PEND-IND
557660     END-IF.

           MOVE MIR-OINS-INFC-PEND-IND         TO WS-TEST-OIPIN.

           IF WS-OIPIN-OK
               MOVE MIR-OINS-INFC-PEND-IND  TO RAPPF-OINS-INFC-PEND-IND
           ELSE
               MOVE 'NS05500004'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-OINS-INFC-PEND-IND
013578                  TO RAPPF-OINS-INFC-PEND-IND
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.

       5100-EDIT-OIPIN-X.
           EXIT.

      *****************************************************************
      *  SPOUSE INSURED AMOUNT: MUST BE NUMERIC
      *****************************************************************
       5200-EDIT-SPAMT.

           IF  MIR-CLI-SPOUS-INS-AMT = SPACES
008455*        MOVE RAPPF-CLI-SPOUS-INS-AMT  TO WS-N-DOL-9
008455*        MOVE WS-N-DOL-9               TO WS-PIC-DOL-9
008455*        MOVE WS-PIC-DOL-9             TO MIR-CLI-SPOUS-INS-AMT
020874*        MOVE RAPPF-CLI-SPOUS-INS-AMT  TO L0290-INPUT-NUMBER
020874         MOVE RAPPF-CLI-SPOUS-INS-AMT  TO L0290-INPUT-V00
008455         PERFORM  9280-FORMAT-SPAMT
008455             THRU 9280-FORMAT-SPAMT-X
               GO TO 5200-EDIT-SPAMT-X
557660     END-IF.

           IF  MIR-CLI-SPOUS-INS-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZERO          TO WS-PIC-DOL-9
008455*        MOVE WS-PIC-DOL-9  TO MIR-CLI-SPOUS-INS-AMT
008455         MOVE ZERO          TO MIR-CLI-SPOUS-INS-AMT
               MOVE ZERO          TO RAPPF-CLI-SPOUS-INS-AMT
               GO TO 5200-EDIT-SPAMT-X
557660     END-IF.

           MOVE 'N'          TO L0280-SIGN-IND.
           MOVE 0            TO L0280-PRECISION.
008455*    MOVE 9            TO L0280-LENGTH.
008455*    MOVE 9            TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-SPOUS-INS-AMT
008455                       TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-CLI-SPOUS-INS-AMT    TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF  L0280-OK
008455*        MOVE L0280-OUTPUT             TO WS-N-DOL-9
               MOVE L0280-OUTPUT             TO RAPPF-CLI-SPOUS-INS-AMT
008455*        MOVE WS-N-DOL-9               TO WS-PIC-DOL-9
008455*        MOVE WS-PIC-DOL-9             TO MIR-CLI-SPOUS-INS-AMT
020874*        MOVE L0280-OUTPUT             TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT             TO L0290-INPUT-V00
008455         PERFORM  9280-FORMAT-SPAMT
008455             THRU 9280-FORMAT-SPAMT-X
           ELSE
               MOVE 'NS05500006'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.

       5200-EDIT-SPAMT-X.
           EXIT.

      *****************************************************************
      *  EDIT INSURANCE REFUSED IND
      *****************************************************************
       5300-EDIT-REFIN.

           IF  MIR-CLI-INS-REFUS-IND  = SPACES
               MOVE RAPPF-CLI-INS-REFUS-IND TO MIR-CLI-INS-REFUS-IND
               GO TO 5300-EDIT-REFIN-X
557660     END-IF.

           IF  MIR-CLI-INS-REFUS-IND  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES        TO MIR-CLI-INS-REFUS-IND
557660     END-IF.

           MOVE MIR-CLI-INS-REFUS-IND         TO WS-TEST-REFIN.

           IF  WS-REFIN-OK
               MOVE MIR-CLI-INS-REFUS-IND  TO RAPPF-CLI-INS-REFUS-IND
           ELSE
               MOVE 'NS05500005'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-CLI-INS-REFUS-IND
013578                  TO RAPPF-CLI-INS-REFUS-IND
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.

       5300-EDIT-REFIN-X.
           EXIT.


      *****************************************************************
      *  EDIT YEAR INSURANCE REFUSED
      *****************************************************************
       5350-EDIT-REFYR.

013578*    IF  MIR-CLI-INS-REFUS-YR = SPACES
013578*        MOVE RAPPF-CLI-INS-REFUS-YR  TO WS-N-9999
013578*        MOVE WS-N-9999               TO WS-PIC-9999
013578*        MOVE WS-PIC-9999             TO MIR-CLI-INS-REFUS-YR
013578*        GO TO 5350-EDIT-REFYR-X
013578*    END-IF.
013578*
013578*    IF  MIR-CLI-INS-REFUS-YR = EBLCH-BLANK-FIELD-CHAR
013578*        MOVE ZERO              TO RAPPF-CLI-INS-REFUS-YR
013578*        MOVE ZERO              TO WS-PIC-9999
013578*        MOVE WS-PIC-9999       TO MIR-CLI-INS-REFUS-YR
013578*        GO TO 5350-EDIT-REFYR-X
013578*    END-IF.
013578*
013578     IF  MIR-CLI-INS-REFUS-YR = SPACES
013578     OR  MIR-CLI-INS-REFUS-YR = ZEROES
013578         MOVE ZERO              TO RAPPF-CLI-INS-REFUS-YR
013578         GO TO 5350-EDIT-REFYR-X
013578     END-IF.

           IF  RAPPF-CLI-INS-REFUS-IND NOT = 'Y'
               MOVE 'NS05500017'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
               GO TO 5350-EDIT-REFYR-X
557660     END-IF.

           MOVE 'N'                    TO L0280-SIGN-IND.
           MOVE 0                      TO L0280-PRECISION.
           MOVE 4                      TO L0280-LENGTH.
           MOVE 4                      TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-INS-REFUS-YR   TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF  L0280-OK
               PERFORM 5351-VALIDATE-REFYR
                  THRU 5351-VALIDATE-REFYR-X
           ELSE
               MOVE 'NS05500018'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.

       5350-EDIT-REFYR-X.
           EXIT.
      *
       5351-VALIDATE-REFYR.

           MOVE L0280-OUTPUT         TO WS-N-9999.
           MOVE WGLOB-PROCESS-DATE   TO WS-PIC-DATE.
           MOVE WS-PIC-DATE-YR TO WS-PROCESS-YEAR.
           IF  WS-N-9999 > WS-PROCESS-YEAR
               MOVE 'NS05500023'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW

           ELSE
557659*        MOVE L0280-OUTPUT     TO RAPPF-INS-REFUS-YR-QTY
557659         MOVE L0280-OUTPUT     TO RAPPF-CLI-INS-REFUS-YR
020874*        MOVE WS-N-9999        TO WS-PIC-9999
020874*        MOVE WS-PIC-9999      TO MIR-CLI-INS-REFUS-YR
020874         MOVE L0280-OUTPUT     TO L0290-INPUT-V00
020874         MOVE 0                TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-INS-REFUS-YR
020874                               TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-INS-REFUS-YR
557660     END-IF.

       5351-VALIDATE-REFYR-X.
           EXIT.

      /
      *****************************************************************
      *  EDIT OTHER INSURANCE DETAIL INFORMATION
      *****************************************************************
       5400-EDIT-OINS-DETAIL-ARRAY.

           MOVE MIR-CLI-OINS-CO-NM-T (WS-SUB)  TO WS-TEST-COMMENT.

           IF  WS-COMMENT-1  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES         TO MIR-CLI-OINS-CO-NM-T (WS-SUB)
557660     END-IF.

           IF  WS-COMMENT-1  = EBLCH-BLANK-FIELD-CHAR AND
               WS-COMMENT-2 NOT = EBLCH-BLANK-FIELD-GROUP
               MOVE 'NS05500019'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-CLI-OINS-CO-NM-T (WS-SUB)
                                   TO L5850-CLI-OINS-CO-NM (WS-SUB)
               ELSE
                   MOVE '1'        TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.

           IF  WS-COMMENT-2  = EBLCH-BLANK-FIELD-GROUP
               MOVE 'Y'        TO WS-CLIO-DATA-SW
               MOVE 'D'        TO L5850-CLIO-DATA-THIS-LINE (WS-SUB)
               MOVE SPACES     TO MIR-OINS-INFC-PEND-CD-T (WS-SUB)
               MOVE MIR-OINS-INFC-PEND-CD-T (WS-SUB)
                               TO L5850-OINS-INFC-PEND-CD (WS-SUB)
               MOVE SPACES     TO MIR-OINS-THIS-CO-IND-T (WS-SUB)
               MOVE MIR-OINS-THIS-CO-IND-T (WS-SUB)
                               TO L5850-OINS-THIS-CO-IND (WS-SUB)
               MOVE SPACES     TO MIR-OINS-BUS-PERS-CD-T (WS-SUB)
               MOVE MIR-OINS-BUS-PERS-CD-T (WS-SUB)
                               TO L5850-OINS-BUS-PERS-CD (WS-SUB)
               MOVE ZERO       TO L5850-CLI-OINS-TOT-AMT (WS-SUB)
008455*        MOVE ZERO            TO WS-PIC-DOL-9
008455*        MOVE WS-PIC-DOL-9    TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
020874*        MOVE 0          TO L0290-INPUT-NUMBER
020874         MOVE 0          TO L0290-INPUT-V00
008455         PERFORM  9282-FORMAT-TOTIA-T
008455             THRU 9282-FORMAT-TOTIA-T-X
               MOVE ZERO       TO L5850-CLI-OINS-ADB-AMT (WS-SUB)
008455*        MOVE ZERO            TO WS-PIC-DOLLAR
008455*        MOVE WS-PIC-DOLLAR   TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
020874*        MOVE 0          TO L0290-INPUT-NUMBER
020874         MOVE 0          TO L0290-INPUT-V00
008455         PERFORM  9284-FORMAT-ADBAM-T
008455             THRU 9284-FORMAT-ADBAM-T-X
               MOVE SPACES     TO MIR-OINS-WP-INFC-IND-T (WS-SUB)
               MOVE MIR-OINS-WP-INFC-IND-T (WS-SUB)
                               TO L5850-OINS-WP-INFC-IND (WS-SUB)
557659*        MOVE ZERO            TO L5850-OINS-ISS-YR-QTY (WS-SUB)
557659         MOVE ZERO       TO L5850-CLI-OINS-ISS-YR (WS-SUB)
020874*        MOVE ZERO       TO WS-PIC-9999
020874*        MOVE WS-PIC-9999    TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874         MOVE ZERO       TO L0290-INPUT-V00
020874         MOVE 0          TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874                         TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
               MOVE SPACES     TO MIR-OINS-INS-TYP-CD-T (WS-SUB)
               MOVE MIR-OINS-INS-TYP-CD-T (WS-SUB)
                               TO L5850-OINS-INS-TYP-CD (WS-SUB)
               MOVE MIR-CLI-OINS-CO-NM-T (WS-SUB)
                               TO L5850-CLI-OINS-CO-NM (WS-SUB)
               GO TO 5400-EDIT-OINS-DETAIL-ARRAY-X
557660     END-IF.

           PERFORM  5450-EDIT-OTPCO
               THRU 5450-EDIT-OTPCO-X.

           PERFORM  5500-EDIT-OTHIP
               THRU 5500-EDIT-OTHIP-X.

           PERFORM  5600-EDIT-OITCO
               THRU 5600-EDIT-OITCO-X.

           PERFORM  5700-EDIT-OTHBP
               THRU 5700-EDIT-OTHBP-X.

           PERFORM  6300-EDIT-YRISS
               THRU 6300-EDIT-YRISS-X.

           PERFORM  5800-EDIT-ITYPE
               THRU 5800-EDIT-ITYPE-X.

           PERFORM  5900-EDIT-TOTIA
               THRU 5900-EDIT-TOTIA-X.

           PERFORM  6000-EDIT-ADBAM
               THRU 6000-EDIT-ADBAM-X.

           PERFORM  6100-EDIT-WDIND
               THRU 6100-EDIT-WDIND-X.

       5400-EDIT-OINS-DETAIL-ARRAY-X.
           EXIT.

      *
      *****************************************************************
      *  EDIT COMPANY NAME
      *****************************************************************
       5450-EDIT-OTPCO.
      *
           IF  MIR-CLI-OINS-CO-NM-T (WS-SUB) = SPACES
               MOVE L5850-CLI-OINS-CO-NM   (WS-SUB)
                                   TO MIR-CLI-OINS-CO-NM-T (WS-SUB)
               GO TO 5450-EDIT-OTPCO-X
557660     END-IF.

           MOVE MIR-CLI-OINS-CO-NM-T (WS-SUB)
                                   TO L5850-CLI-OINS-CO-NM (WS-SUB).
      *
       5450-EDIT-OTPCO-X.
           EXIT.


      *****************************************************************
      *  EDIT INFORCE/PENDING INDICATOR
      *****************************************************************
       5500-EDIT-OTHIP.
      *
           IF  MIR-OINS-INFC-PEND-CD-T (WS-SUB) = SPACES
               MOVE L5850-OINS-INFC-PEND-CD (WS-SUB)
                                   TO MIR-OINS-INFC-PEND-CD-T (WS-SUB)
               GO TO 5500-EDIT-OTHIP-X
557660     END-IF.

           IF  MIR-OINS-INFC-PEND-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES         TO MIR-OINS-INFC-PEND-CD-T (WS-SUB)
557660     END-IF.

           MOVE MIR-OINS-INFC-PEND-CD-T (WS-SUB) TO WS-TEST-OTHIP.

           IF  WS-OTHIP-OK
               MOVE MIR-OINS-INFC-PEND-CD-T (WS-SUB)
                                   TO L5850-OINS-INFC-PEND-CD (WS-SUB)
           ELSE
               MOVE 'NS05500007'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-OINS-INFC-PEND-CD-T (WS-SUB)
                                   TO L5850-OINS-INFC-PEND-CD (WS-SUB)
               ELSE
                   MOVE '1'        TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5500-EDIT-OTHIP-X.
           EXIT.


      *****************************************************************
      *  EDIT THIS COMPANY
      *****************************************************************
       5600-EDIT-OITCO.
      *
           IF  MIR-OINS-THIS-CO-IND-T (WS-SUB) = SPACES
               MOVE L5850-OINS-THIS-CO-IND (WS-SUB)
                                   TO MIR-OINS-THIS-CO-IND-T (WS-SUB)
               GO TO 5600-EDIT-OITCO-X
557660     END-IF.

           IF  MIR-OINS-THIS-CO-IND-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES         TO MIR-OINS-THIS-CO-IND-T (WS-SUB)
557660     END-IF.

           MOVE MIR-OINS-THIS-CO-IND-T (WS-SUB) TO WS-TEST-OITCO.

           IF  WS-OITCO-OK
               MOVE MIR-OINS-THIS-CO-IND-T (WS-SUB)
                                   TO L5850-OINS-THIS-CO-IND (WS-SUB)
           ELSE
               MOVE 'NS05500008'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-OINS-THIS-CO-IND-T (WS-SUB)
                                   TO L5850-OINS-THIS-CO-IND (WS-SUB)
               ELSE
                   MOVE '1'        TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5600-EDIT-OITCO-X.
           EXIT.


      *****************************************************************
      *  EDIT BUSINESS OR PERSONAL IND
      *****************************************************************
       5700-EDIT-OTHBP.
      *
           IF  MIR-OINS-BUS-PERS-CD-T (WS-SUB) = SPACES
               MOVE L5850-OINS-BUS-PERS-CD (WS-SUB)
                                   TO MIR-OINS-BUS-PERS-CD-T (WS-SUB)
               GO TO 5700-EDIT-OTHBP-X
557660     END-IF.

           IF  MIR-OINS-BUS-PERS-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES         TO MIR-OINS-BUS-PERS-CD-T (WS-SUB)
557660     END-IF.

           MOVE MIR-OINS-BUS-PERS-CD-T (WS-SUB) TO WS-TEST-OTHBP.

           IF  WS-OTHBP-OK
               MOVE MIR-OINS-BUS-PERS-CD-T (WS-SUB)
                                   TO L5850-OINS-BUS-PERS-CD (WS-SUB)
           ELSE
               MOVE 'NS05500009'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-OINS-BUS-PERS-CD-T (WS-SUB)
                                   TO L5850-OINS-BUS-PERS-CD (WS-SUB)
               ELSE
                   MOVE '1'        TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5700-EDIT-OTHBP-X.
           EXIT.


      *****************************************************************
      *  EDIT INSURANCE TYPE
      *****************************************************************
       5800-EDIT-ITYPE.
      *
           IF  MIR-OINS-INS-TYP-CD-T (WS-SUB) = SPACES
               MOVE L5850-OINS-INS-TYP-CD  (WS-SUB)
                                   TO MIR-OINS-INS-TYP-CD-T (WS-SUB)
               GO TO 5800-EDIT-ITYPE-X
557660     END-IF.

           IF  MIR-OINS-INS-TYP-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES         TO MIR-OINS-INS-TYP-CD-T (WS-SUB)
557660     END-IF.

           MOVE MIR-OINS-INS-TYP-CD-T (WS-SUB) TO WS-TEST-ITYPE.

           IF  WS-ITYPE-OK
               MOVE MIR-OINS-INS-TYP-CD-T (WS-SUB)
                                   TO L5850-OINS-INS-TYP-CD (WS-SUB)
           ELSE
               MOVE 'NS05500010'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE '1'        TO WS-EDIT-OK-SW
                   GO TO 5800-EDIT-ITYPE-X
557660         END-IF
557660     END-IF.

           IF  WS-ITYPE-HEALTH
      *** MSG (W) WARNING ... USE TOTH TO ENTER HEALTH AMOUNTS
               MOVE 'NS05500027'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-OINS-INS-TYP-CD-T (WS-SUB)
                                   TO L5850-OINS-INS-TYP-CD (WS-SUB)
               ELSE
                   MOVE '1'        TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5800-EDIT-ITYPE-X.
           EXIT.


      *****************************************************************
      *  EDIT TOTAL AMOUNT: MUST BE NUMERIC
      *****************************************************************
       5900-EDIT-TOTIA.
      *
           IF  MIR-CLI-OINS-TOT-AMT-T (WS-SUB) = SPACES
008455*        MOVE L5850-CLI-OINS-TOT-AMT (WS-SUB)
008455*                                     TO WS-N-DOL-9
008455*        MOVE WS-N-DOL-9              TO WS-PIC-DOL-9
008455*        MOVE WS-PIC-DOL-9   TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
008455         MOVE L5850-CLI-OINS-TOT-AMT (WS-SUB)
020874*                                      TO L0290-INPUT-NUMBER
020874                                       TO L0290-INPUT-V00
008455         PERFORM  9282-FORMAT-TOTIA-T
008455             THRU 9282-FORMAT-TOTIA-T-X
               GO TO 5900-EDIT-TOTIA-X
557660     END-IF.

           IF  MIR-OINS-INFC-PEND-IND = 'Y'
               IF  MIR-CLI-OINS-TOT-AMT-T (WS-SUB) NOT = SPACES
                   AND MIR-CLI-OINS-TOT-AMT-T (WS-SUB) NOT = ZEROES
                   PERFORM  5950-WHEN-TOTIA-NOT-ZERO
                       THRU 5950-WHEN-TOTIA-NOT-ZERO-X
557660         END-IF
557660     END-IF.

           IF  MIR-CLI-OINS-TOT-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO           TO L5850-CLI-OINS-TOT-AMT (WS-SUB)
008455*        MOVE ZERO            TO WS-PIC-DOL-9
008455*        MOVE WS-PIC-DOL-9    TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
020874*        MOVE 0          TO L0290-INPUT-NUMBER
020874         MOVE 0          TO L0290-INPUT-V00
008455         PERFORM  9282-FORMAT-TOTIA-T
008455             THRU 9282-FORMAT-TOTIA-T-X
               GO TO 5900-EDIT-TOTIA-X
557660     END-IF.

008455*    MOVE ZERO                TO WS-PIC-DOL-9.

           MOVE 'N'                TO L0280-SIGN-IND.
           MOVE 0                  TO L0280-PRECISION.
008455*    MOVE 9                    TO L0280-LENGTH.
008455*    MOVE 9                    TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
008455                              TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-CLI-OINS-TOT-AMT-T (WS-SUB) TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF  L0280-OK
008455*        MOVE L0280-OUTPUT     TO WS-N-DOL-9
               MOVE L0280-OUTPUT   TO L5850-CLI-OINS-TOT-AMT (WS-SUB)
008455*        MOVE WS-N-DOL-9       TO WS-PIC-DOL-9
008455*        MOVE WS-PIC-DOL-9     TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
020874*        MOVE L0280-OUTPUT   TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT   TO L0290-INPUT-V00
008455         PERFORM  9282-FORMAT-TOTIA-T
008455             THRU 9282-FORMAT-TOTIA-T-X
           ELSE
               MOVE 'NS05500013'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'            TO WS-EDIT-OK-SW
557660     END-IF.
      *
       5900-EDIT-TOTIA-X.
           EXIT.

      *
       5950-WHEN-TOTIA-NOT-ZERO.
      *
           IF  MIR-OINS-INFC-PEND-CD-T (WS-SUB) = SPACES
               MOVE  'I'   TO MIR-OINS-INFC-PEND-CD-T (WS-SUB)
               MOVE  'I'   TO L5850-OINS-INFC-PEND-CD (WS-SUB)
557660     END-IF.

           IF  MIR-OINS-THIS-CO-IND-T (WS-SUB) = SPACES
               MOVE  'N'   TO MIR-OINS-THIS-CO-IND-T (WS-SUB)
               MOVE  'N'   TO L5850-OINS-THIS-CO-IND (WS-SUB)
557660     END-IF.

           IF  MIR-OINS-BUS-PERS-CD-T (WS-SUB) = SPACES
               MOVE  'P'   TO MIR-OINS-BUS-PERS-CD-T (WS-SUB)
               MOVE  'P'   TO L5850-OINS-BUS-PERS-CD (WS-SUB)
557660     END-IF.
      *
       5950-WHEN-TOTIA-NOT-ZERO-X.
           EXIT.


      *****************************************************************
      *  EDIT TOTAL AMOUNT: MUST BE NUMERIC
      *****************************************************************
       6000-EDIT-ADBAM.
      *
           IF  MIR-CLI-OINS-ADB-AMT-T (WS-SUB) = SPACES
008455*        MOVE L5850-CLI-OINS-ADB-AMT (WS-SUB)
008455*                               TO WS-N-DOLLAR
008455*        MOVE WS-N-DOLLAR        TO WS-PIC-DOLLAR
008455*        MOVE WS-PIC-DOLLAR    TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
008455         MOVE L5850-CLI-OINS-ADB-AMT (WS-SUB)
020874*                             TO L0290-INPUT-NUMBER
020874                              TO L0290-INPUT-V00
008455         PERFORM  9284-FORMAT-ADBAM-T
008455             THRU 9284-FORMAT-ADBAM-T-X
               GO TO 6000-EDIT-ADBAM-X
557660     END-IF.

           IF  MIR-CLI-OINS-ADB-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO           TO L5850-CLI-OINS-ADB-AMT (WS-SUB)
008455*        MOVE ZERO             TO WS-PIC-DOLLAR
008455*        MOVE WS-PIC-DOLLAR    TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
020874*        MOVE 0              TO L0290-INPUT-NUMBER
020874         MOVE 0              TO L0290-INPUT-V00
008455         PERFORM  9284-FORMAT-ADBAM-T
008455             THRU 9284-FORMAT-ADBAM-T-X
               GO TO 6000-EDIT-ADBAM-X
557660     END-IF.

008455*    MOVE ZERO                 TO WS-PIC-DOLLAR.

           MOVE 'N'                TO L0280-SIGN-IND.
           MOVE 0                  TO L0280-PRECISION.
008455*    MOVE 6                      TO L0280-LENGTH.
008455*    MOVE 6                      TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
008455                             TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-CLI-OINS-ADB-AMT-T (WS-SUB)   TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF  L0280-OK
008455*        MOVE L0280-OUTPUT     TO WS-N-DOLLAR
               MOVE L0280-OUTPUT   TO L5850-CLI-OINS-ADB-AMT (WS-SUB)
008455*        MOVE WS-N-DOLLAR      TO WS-PIC-DOLLAR
008455*        MOVE WS-PIC-DOLLAR    TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
020874*        MOVE L0280-OUTPUT   TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT   TO L0290-INPUT-V00
008455         PERFORM  9284-FORMAT-ADBAM-T
008455             THRU 9284-FORMAT-ADBAM-T-X
           ELSE
               MOVE 'NS05500014'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'                    TO WS-EDIT-OK-SW
557660     END-IF.
      *
       6000-EDIT-ADBAM-X.
           EXIT.


      *****************************************************************
      *  EDIT WAIVER OF PREMIUM INDICATOR
      *****************************************************************
       6100-EDIT-WDIND.
      *
           IF  MIR-OINS-WP-INFC-IND-T (WS-SUB) = SPACES
               MOVE L5850-OINS-WP-INFC-IND (WS-SUB)
                                    TO MIR-OINS-WP-INFC-IND-T (WS-SUB)
               GO TO 6100-EDIT-WDIND-X
557660     END-IF.

           IF  MIR-OINS-WP-INFC-IND-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES          TO MIR-OINS-WP-INFC-IND-T (WS-SUB)
557660     END-IF.

           MOVE MIR-OINS-WP-INFC-IND-T (WS-SUB)    TO WS-TEST-WDIND.

           IF  WS-WDIND-OK
              MOVE MIR-OINS-WP-INFC-IND-T (WS-SUB)
                                    TO L5850-OINS-WP-INFC-IND (WS-SUB)
           ELSE
               MOVE 'NS05500011'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-OINS-WP-INFC-IND-T (WS-SUB)
                                    TO L5850-OINS-WP-INFC-IND (WS-SUB)
               ELSE
                   MOVE '1'         TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6100-EDIT-WDIND-X.
           EXIT.


      *****************************************************************
      *  EDIT REFUSED COMPANY NAME
      *****************************************************************
      *  EDIT LIFE REFUSED INFORMATION
      *****************************************************************
       6200-EDIT-REFUSED-INFO.

           PERFORM  6250-EDIT-REFCO
               THRU 6250-EDIT-REFCO-X.

           PERFORM  6450-EDIT-REFTC
               THRU 6450-EDIT-REFTC-X.

           PERFORM  6550-EDIT-RRSN
               THRU 6550-EDIT-RRSN-X.

       6200-EDIT-REFUSED-INFO-X.
           EXIT.

      *
       6250-EDIT-REFCO.
      *
           IF  MIR-INS-REFUS-CO-1-NM-T (WS-SUB) = SPACES
               MOVE RAPPF-INS-REFUS-CO-NM (WS-SUB)
                                   TO MIR-INS-REFUS-CO-1-NM-T (WS-SUB)
               GO TO 6250-EDIT-REFCO-X
557660     END-IF.

           MOVE MIR-INS-REFUS-CO-1-NM-T (WS-SUB)    TO WS-TEST-COMMENT.

           IF  WS-COMMENT-1  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES         TO MIR-INS-REFUS-CO-1-NM-T (WS-SUB)
557660     END-IF.

           MOVE MIR-INS-REFUS-CO-1-NM-T (WS-SUB)
013578                             TO RAPPF-INS-REFUS-CO-NM (WS-SUB).
      *
       6250-EDIT-REFCO-X.
           EXIT.

      *****************************************************************
      *  EDIT ISSUE YEAR: MUST BE NUMERIC
      *****************************************************************
       6300-EDIT-YRISS.
      *
           MOVE WGLOB-PROCESS-DATE     TO WS-PIC-DATE.
           PERFORM  6350-EDIT-YRISS
               THRU 6350-EDIT-YRISS-X.

           IF  WS-YRISS-NOT-OK
               MOVE 'NS05500024'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE 'Y'                    TO WS-YRISS-SW.
      *
       6300-EDIT-YRISS-X.
           EXIT.


      *
       6350-EDIT-YRISS.
      *
           IF  MIR-CLI-OINS-ISS-YR-T (WS-SUB) = SPACES
557659*        MOVE L5850-OINS-ISS-YR-QTY  (WS-SUB)
020874*        MOVE L5850-CLI-OINS-ISS-YR  (WS-SUB)
020874*                            TO WS-N-9999
020874*        MOVE WS-N-9999      TO WS-PIC-9999
020874*        MOVE WS-PIC-9999    TO MIR-CLI-OINS-ISS-YR-T
020874*                                        (WS-SUB)
020874         MOVE L5850-CLI-OINS-ISS-YR  (WS-SUB) TO L0290-INPUT-V00
020874         MOVE 0              TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874                             TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
               GO TO 6350-EDIT-YRISS-X
557660     END-IF.

           IF  MIR-CLI-OINS-ISS-YR-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
557659*        MOVE ZERO              TO L5850-OINS-ISS-YR-QTY (WS-SUB)
557659         MOVE ZERO           TO L5850-CLI-OINS-ISS-YR (WS-SUB)
020874*        MOVE ZERO           TO WS-PIC-9999
020874*        MOVE WS-PIC-9999    TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874         MOVE ZERO           TO L0290-INPUT-V00
020874         MOVE 0              TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874                             TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
               GO TO 6350-EDIT-YRISS-X
557660     END-IF.

           MOVE 'N'                            TO L0280-SIGN-IND.
           MOVE 0                              TO L0280-PRECISION.
           MOVE 4                              TO L0280-LENGTH.
           MOVE 4                              TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-OINS-ISS-YR-T (WS-SUB) TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF  L0280-OK
               PERFORM 6351-VALIDATE-YRISS
                  THRU 6351-VALIDATE-YRISS-X
           ELSE
               MOVE 'NS05500015'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'                    TO WS-EDIT-OK-SW
557660     END-IF.
      *
       6350-EDIT-YRISS-X.
           EXIT.

      *
       6351-VALIDATE-YRISS.
      *
           MOVE L0280-OUTPUT               TO WS-N-9999.
           MOVE WS-PIC-DATE-YR             TO WS-PROCESS-YEAR.
           IF  WS-N-9999 > WS-PROCESS-YEAR
               MOVE '1'                    TO WS-EDIT-OK-SW
               MOVE 'N'                    TO WS-YRISS-SW
           ELSE
557659*        MOVE L0280-OUTPUT     TO L5850-OINS-ISS-YR-QTY (WS-SUB)
557659         MOVE L0280-OUTPUT   TO L5850-CLI-OINS-ISS-YR (WS-SUB)
020874*        MOVE WS-N-9999      TO WS-PIC-9999
020874*        MOVE WS-PIC-9999    TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874         MOVE L0280-OUTPUT   TO L0290-INPUT-V00
020874         MOVE 0              TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874                             TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
557660     END-IF.
      *
       6351-VALIDATE-YRISS-X.
           EXIT.

      *
       6450-EDIT-REFTC.
      *
           IF  MIR-CLI-REFUS-CO-1-IND-T (WS-SUB) = SPACES
               MOVE RAPPF-CLI-REFUS-CO-IND (WS-SUB)
                                   TO MIR-CLI-REFUS-CO-1-IND-T (WS-SUB)
               GO TO 6450-EDIT-REFTC-X
557660     END-IF.

           IF  MIR-CLI-REFUS-CO-1-IND-T (WS-SUB)
               = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES         TO MIR-CLI-REFUS-CO-1-IND-T (WS-SUB)
557660     END-IF.

           MOVE MIR-CLI-REFUS-CO-1-IND-T (WS-SUB)
                                   TO WS-TEST-REFTC.

           IF  WS-REFTC-OK
               MOVE MIR-CLI-REFUS-CO-1-IND-T (WS-SUB)
                                   TO RAPPF-CLI-REFUS-CO-IND (WS-SUB)
           ELSE
               MOVE 'NS05500008'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-CLI-REFUS-CO-1-IND-T (WS-SUB)
                                   TO RAPPF-CLI-REFUS-CO-IND (WS-SUB)
               ELSE
                   MOVE '1'        TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6450-EDIT-REFTC-X.
           EXIT.


      *****************************************************************
      *  INSURANCE REFUSED REASON:  MUST BE VALIDATED AGAINST EDIT
      *****************************************************************
       6550-EDIT-RRSN.
      *
           IF  MIR-REFUS-REASN-1-TXT-T (WS-SUB) = SPACES
               MOVE RAPPF-REFUS-REASN-TXT (WS-SUB)
                               TO MIR-REFUS-REASN-1-TXT-T (WS-SUB)
               GO TO 6550-EDIT-RRSN-X
557660     END-IF.

           IF  MIR-REFUS-REASN-1-TXT-T (WS-SUB) = RAPPF-REFUS-REASN-TXT
013578                                           (WS-SUB)
               GO TO 6550-EDIT-RRSN-X
557660     END-IF.

           IF  MIR-REFUS-REASN-1-TXT-T (WS-SUB)
               = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES     TO MIR-REFUS-REASN-1-TXT-T (WS-SUB)
               MOVE SPACES     TO RAPPF-REFUS-REASN-TXT (WS-SUB)
               GO TO 6550-EDIT-RRSN-X
557660     END-IF.

           MOVE MIR-REFUS-REASN-1-TXT-T (WS-SUB)
013578                         TO WEDIT-ETBL-VALU-ID.

           PERFORM  RRES-1000-EDIT
               THRU RRES-1000-EDIT-X.

           IF  WEDIT-IO-OK
               MOVE MIR-REFUS-REASN-1-TXT-T (WS-SUB)
                                   TO RAPPF-REFUS-REASN-TXT (WS-SUB)
           ELSE
               MOVE 'NS05500012'   TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-REFUS-REASN-1-TXT-T (WS-SUB)
                                   TO RAPPF-REFUS-REASN-TXT (WS-SUB)
               ELSE
                   MOVE '1'        TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6550-EDIT-RRSN-X.
           EXIT.


      *****************************************************************
      *  CHECK THAT THE REASON FIELD IS ENTERED WHEN INDICATOR = "Y"
      *****************************************************************
       6600-EDIT-RRSN-TO-REFIN.
      *
           IF  WS-REFIN-YES
               IF  MIR-REFUS-REASN-1-TXT-T (1) = SPACES  AND
                   MIR-REFUS-REASN-1-TXT-T (2) = SPACES
                   MOVE 'NS05500021'           TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'                    TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6600-EDIT-RRSN-TO-REFIN-X.
           EXIT.

      *
       6700-KEY-FIELD-CROSS-EDITS.
      *
           IF  L5850-CLI-OINS-CO-NM (WS-SUB) NOT = SPACES
557659*        IF L5850-OINS-ISS-YR-QTY (WS-SUB) NOT = ZEROES
557659         IF  L5850-CLI-OINS-ISS-YR (WS-SUB) NOT = ZEROES
                   IF  L5850-CLI-OINS-TOT-AMT (WS-SUB) NOT = ZEROES
                       GO TO 6700-KEY-FIELD-CROSS-EDITS-X
016537*            ELSE
016537             END-IF
                   MOVE 'NS05500025'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF  WGLOB-MSG-SEVRTY-WARNING
034802*                NEXT SENTENCE
034802                 CONTINUE
                   ELSE
                       MOVE '1'                TO WS-EDIT-OK-SW
557660             END-IF
016537*            END-IF
               ELSE
                   MOVE 'NS05500025'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF  WGLOB-MSG-SEVRTY-WARNING
034802*                NEXT SENTENCE
034802                 CONTINUE
                   ELSE
                       MOVE '1'                    TO WS-EDIT-OK-SW
557660             END-IF
557660         END-IF
557660     END-IF.
      *
       6700-KEY-FIELD-CROSS-EDITS-X.
           EXIT.

      *
       6750-OINS-CROSS-EDITS.
      *
           MOVE 'N'                TO WS-LINE-DATA-ENTERED-SW.

           IF  L5850-CLI-OINS-CO-NM   (WS-SUB) NOT = SPACES
               MOVE 'Y'            TO WS-OTHER-DATA-ENTERED-SW
557660     END-IF.
           IF  L5850-OINS-INFC-PEND-CD (WS-SUB) NOT = SPACES
               MOVE 'Y'            TO WS-LINE-DATA-ENTERED-SW
               MOVE 'Y'            TO WS-OTHER-DATA-ENTERED-SW
557660     END-IF.
           IF  L5850-OINS-THIS-CO-IND (WS-SUB) NOT = SPACES
               MOVE 'Y'            TO WS-LINE-DATA-ENTERED-SW
               MOVE 'Y'            TO WS-OTHER-DATA-ENTERED-SW
557660     END-IF.
           IF  L5850-OINS-BUS-PERS-CD (WS-SUB) NOT = SPACES
               MOVE 'Y'            TO WS-LINE-DATA-ENTERED-SW
               MOVE 'Y'            TO WS-OTHER-DATA-ENTERED-SW
557660     END-IF.
557659*    IF  L5850-OINS-ISS-YR-QTY (WS-SUB) NOT = ZEROES
557659     IF  L5850-CLI-OINS-ISS-YR (WS-SUB) NOT = ZEROES
               MOVE 'Y'            TO WS-LINE-DATA-ENTERED-SW
               MOVE 'Y'            TO WS-OTHER-DATA-ENTERED-SW
557660     END-IF.
           IF  L5850-CLI-OINS-TOT-AMT (WS-SUB) NOT = ZEROES
               MOVE 'Y'            TO WS-LINE-DATA-ENTERED-SW
               MOVE 'Y'            TO WS-OTHER-DATA-ENTERED-SW
557660     END-IF.

           IF  MIR-CLI-OINS-CO-NM-T (WS-SUB) = SPACES
           AND L5850-CLI-OINS-CO-NM   (WS-SUB) = SPACES
           AND WS-LINE-DATA-WAS-ENTERED
               MOVE 'NS05500020'   TO WGLOB-MSG-REF-INFO
               MOVE WS-SUB         TO WS-DISPLAY-SUB
               MOVE WS-DISPLAY-SUB TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WS-EDIT-OK
                   MOVE '2'        TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6750-OINS-CROSS-EDITS-X.
           EXIT.

      /
      *****************************************************************
      *  CHECK FOR EXISTING CLIENT
      *****************************************************************
       7000-VALIDATE-ACCESS.
      *
           PERFORM  8100-BUILD-NAL-KEY
               THRU 8100-BUILD-NAL-KEY-X.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  L2437-RETRN-CLI-NOT-FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE L2437-WCLI-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-VALIDATE-ACCESS-X
           END-IF.

           MOVE L2437-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
557698*    MOVE L2437-CLI-CO-NM             TO L0620-CLI-CO-NM.
557698*    MOVE L2437-CLI-GIV-NM            TO L0620-CLI-GIV-NM.
557698*    MOVE L2437-CLI-SUR-NM            TO L0620-CLI-SUR-NM.
557698     MOVE L2437-CLI-ENTR-CO-NM       TO L0620-CLI-CO-NM
557698     MOVE L2437-CLI-ENTR-GIV-NM      TO L0620-CLI-GIV-NM
557698     MOVE L2437-CLI-ENTR-SUR-NM      TO L0620-CLI-SUR-NM
014653     MOVE L2437-CLI-MID-INIT-NM      TO L0620-CLI-MID-INIT-NM
014653     MOVE L2437-CLI-SFX-NM           TO L0620-CLI-SFX-NM

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
      *
           MOVE L0620-SCREEN-NAME          TO MIR-DV-INSRD-CLI-NM.

      *
      *  INITIALIZE INPUT PARAMETERS
      *
           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE L2437-CLI-ID               TO L5600-CLI-ID.
016387*    SET L5600-GEN-CNSLDT-MSG-WARN   TO TRUE.

      *
      *  CALL MODULE TO CHECK CLIENT CONFIDENTIALITY INDICATOR
      *
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

      *
       7000-VALIDATE-ACCESS-X.
           EXIT.

      *
      *****************************************************************
      *  NUMERIC EDIT
      *****************************************************************
       7800-NUMERIC-EDIT.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.

           IF  L0280-ARGS-INVALID
               MOVE 'XS00000020'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
       7800-NUMERIC-EDIT-X.
           EXIT.

      /
      *****************************************************************
      *  BUILD APPF KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************
       8000-BUILD-APPF-KEY.

           MOVE MIR-CLI-ID        TO WAPPF-CLI-ID.

       8000-BUILD-APPF-KEY-X.
           EXIT.


      *****************************************************************
      *  BUILD NAL KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************
       8100-BUILD-NAL-KEY.

           MOVE MIR-CLI-ID        TO L2437-CLI-ID.

       8100-BUILD-NAL-KEY-X.
           EXIT.


      *****************************************************************
      *  BUILD CLIO KEY
      *****************************************************************
       8200-BUILD-CLIO-KEY.

           MOVE MIR-CLI-ID        TO L5850-CLI-ID.
           MOVE 'L'              TO L5850-CLI-OINS-TYP-CD.

       8200-BUILD-CLIO-KEY-X.
           EXIT.

      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.
      *
014221*    MOVE SPACES         TO MIR-PREV-UPDT-DT.
014221     MOVE SPACES         TO MIR-DV-PREV-UPDT-DT.
           MOVE SPACES         TO MIR-OINS-INFC-PEND-IND.
           MOVE SPACES         TO MIR-CLI-SPOUS-INS-AMT.
           MOVE SPACES         TO MIR-CLI-INS-REFUS-IND.
           MOVE SPACES         TO MIR-CLI-INS-REFUS-YR.

           MOVE SPACES         TO MIR-ADBAM-G.
           MOVE SPACES         TO MIR-ITYPE-G.
           MOVE SPACES         TO MIR-OIPCO-G.
           MOVE SPACES         TO MIR-OITCO-G.
           MOVE SPACES         TO MIR-OTHBP-G.
           MOVE SPACES         TO MIR-OTHIP-G.
           MOVE SPACES         TO MIR-TOTIA-G.
           MOVE SPACES         TO MIR-WDIND-G.
           MOVE SPACES         TO MIR-YRISS-G.

           MOVE SPACES         TO MIR-REFCO-G.
           MOVE SPACES         TO MIR-REFTC-G.
           MOVE SPACES         TO MIR-RRSN-G.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.
      *
           MOVE RAPPF-OINS-INFC-PEND-IND   TO MIR-OINS-INFC-PEND-IND.
           MOVE RAPPF-CLI-INS-REFUS-IND    TO MIR-CLI-INS-REFUS-IND.
008455*    MOVE RAPPF-CLI-SPOUS-INS-AMT    TO WS-N-DOL-9.
008455*    MOVE WS-N-DOL-9                 TO WS-PIC-DOL-9.
008455*    MOVE WS-PIC-DOL-9               TO MIR-CLI-SPOUS-INS-AMT.
020874*    MOVE RAPPF-CLI-SPOUS-INS-AMT    TO L0290-INPUT-NUMBER.
020874     MOVE RAPPF-CLI-SPOUS-INS-AMT    TO L0290-INPUT-V00.
008455     PERFORM  9280-FORMAT-SPAMT
008455         THRU 9280-FORMAT-SPAMT-X
557659*    MOVE RAPPF-INS-REFUS-YR-QTY     TO WS-N-9999.
020874*    MOVE RAPPF-CLI-INS-REFUS-YR     TO WS-N-9999.
020874*    MOVE WS-N-9999                  TO WS-PIC-9999.
020874*    MOVE WS-PIC-9999                TO MIR-CLI-INS-REFUS-YR.
020874     MOVE RAPPF-CLI-INS-REFUS-YR     TO L0290-INPUT-V00.
020874     MOVE 0                          TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLI-INS-REFUS-YR
020874                                     TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA          TO MIR-CLI-INS-REFUS-YR.
      *
014221*    MOVE RAPPF-PREV-UPDT-DT      TO L1640-INTERNAL-DATE.
014221*    MOVE RAPPF-PREV-UPDT-TS      TO L1640-INTERNAL-DATE.
014221     MOVE RAPPF-PREV-UPDT-TS      TO WWKDT-INT-TS.
014221     MOVE WWKDT-INT-TS            TO L1640-INTERNAL-DATE.
      *
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
      *
014221*    MOVE L1640-EXTERNAL-DATE     TO MIR-PREV-UPDT-DT.
014221     MOVE L1640-EXTERNAL-DATE     TO MIR-DV-PREV-UPDT-DT.
      *
           PERFORM  9250-DATA-LINES
               THRU 9250-DATA-LINES-X
                    VARYING WS-SUB FROM 1 BY 1
                        UNTIL WS-SUB GREATER 6.
      *
           PERFORM  9270-REFUSE-LINES
               THRU 9270-REFUSE-LINES-X
                    VARYING WS-SUB FROM 1 BY 1
                        UNTIL WS-SUB GREATER 2.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *
       9250-DATA-LINES.
      *
           MOVE L5850-CLI-OINS-CO-NM    (WS-SUB)
                                 TO MIR-CLI-OINS-CO-NM-T (WS-SUB).
           MOVE L5850-OINS-INFC-PEND-CD (WS-SUB)
                                 TO MIR-OINS-INFC-PEND-CD-T (WS-SUB).
           MOVE L5850-OINS-THIS-CO-IND  (WS-SUB)
                                 TO MIR-OINS-THIS-CO-IND-T (WS-SUB).
           MOVE L5850-OINS-BUS-PERS-CD (WS-SUB)
                                 TO MIR-OINS-BUS-PERS-CD-T (WS-SUB).
           MOVE L5850-OINS-INS-TYP-CD   (WS-SUB)
                                 TO MIR-OINS-INS-TYP-CD-T (WS-SUB).
           MOVE L5850-OINS-WP-INFC-IND  (WS-SUB)
                                 TO MIR-OINS-WP-INFC-IND-T (WS-SUB).
557659*    MOVE L5850-OINS-ISS-YR-QTY   (WS-SUB)
020874*    MOVE L5850-CLI-OINS-ISS-YR   (WS-SUB)
020874*                          TO WS-N-9999.
020874*    MOVE WS-N-9999        TO WS-PIC-9999.
020874*    MOVE WS-PIC-9999      TO MIR-CLI-OINS-ISS-YR-T (WS-SUB).
020874     MOVE L5850-CLI-OINS-ISS-YR (WS-SUB) TO L0290-INPUT-V00.
020874     MOVE 0                TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874                           TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-CLI-OINS-ISS-YR-T (WS-SUB).
008455*    MOVE L5850-CLI-OINS-TOT-AMT (WS-SUB)
008455*                          TO WS-N-DOL-9
008455*    MOVE WS-N-DOL-9       TO WS-PIC-DOL-9.
008455*    MOVE WS-PIC-DOL-9     TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB).
008455     MOVE L5850-CLI-OINS-TOT-AMT (WS-SUB)
020874*                          TO L0290-INPUT-NUMBER.
020874                           TO L0290-INPUT-V00.
008455     PERFORM  9282-FORMAT-TOTIA-T
008455         THRU 9282-FORMAT-TOTIA-T-X.
008455*    MOVE L5850-CLI-OINS-ADB-AMT (WS-SUB)
008455*                          TO WS-N-DOLLAR
008455*    MOVE WS-N-DOLLAR      TO WS-PIC-DOLLAR.
008455*    MOVE WS-PIC-DOLLAR    TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB).
008455     MOVE L5850-CLI-OINS-ADB-AMT (WS-SUB)
020874*                          TO L0290-INPUT-NUMBER.
020874                           TO L0290-INPUT-V00.
008455     PERFORM  9284-FORMAT-ADBAM-T
008455         THRU 9284-FORMAT-ADBAM-T-X.
      *
       9250-DATA-LINES-X.
           EXIT.
      *
      *
       9270-REFUSE-LINES.
      *
           MOVE RAPPF-INS-REFUS-CO-NM   (WS-SUB)
                                 TO MIR-INS-REFUS-CO-1-NM-T (WS-SUB).
           MOVE RAPPF-CLI-REFUS-CO-IND  (WS-SUB)
                                 TO MIR-CLI-REFUS-CO-1-IND-T (WS-SUB).
           MOVE RAPPF-REFUS-REASN-TXT   (WS-SUB)
                                 TO MIR-REFUS-REASN-1-TXT-T (WS-SUB).
      *
       9270-REFUSE-LINES-X.
           EXIT.
008455*
008455*
008455 9280-FORMAT-SPAMT.
008455     MOVE 0                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-SPOUS-INS-AMT
013578                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA         TO MIR-CLI-SPOUS-INS-AMT.
008455 9280-FORMAT-SPAMT-X.
008455     EXIT.
008455*
008455 9282-FORMAT-TOTIA-T.
008455     MOVE 0                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
008455                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA         TO MIR-CLI-OINS-TOT-AMT-T
013578                                       (WS-SUB).
008455 9282-FORMAT-TOTIA-T-X.
008455     EXIT.
008455*
008455 9284-FORMAT-ADBAM-T.
008455     MOVE 0                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
008455                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA         TO MIR-CLI-OINS-ADB-AMT-T
013578                                       (WS-SUB).
008455 9284-FORMAT-ADBAM-T-X.
008455     EXIT.
008455*

      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                    TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID             TO WGLOB-REF-CLIENT-NUMBER.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5850-0000-INIT-PARM-INFO
025970         THRU 5850-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-DISPLAY-SUB         TO TRUE.
025970     SET WS-DEFAULT-YRISS               TO TRUE.
025970     SET WS-DEFAULT-OTHER-DATA-ENTERED  TO TRUE.
025970     SET WS-DEFAULT-LINE-DATA-ENTERED   TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     MOVE SPACES                        TO WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
       COPY CCPS5600.

       COPY NCPCAPPF.

       COPY NCPERRES.

008455 COPY XCPS0290.

021930*COPY XCPS8090.
      *****************************************************************
      *  HOUSEKEEPING
      *****************************************************************
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.

      *****************************************************************
      *  LINK TO COPYBOOKS
      *****************************************************************
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.

018764*COPY CCCL5600.
018764 COPY CCPL5600.

018764*COPY XCCL8090.
018764 COPY XCPL8090.

018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.

018764*COPY NCCL5850.
025970 COPY NCPS5850.
018764 COPY NCPL5850.

018764*COPY XCCL0260.
018764 COPY XCPL0260.

025970 COPY XCPS0280.
       COPY XCPL0280.

008455 COPY XCPL0290.

025970 COPY XCPS1640.
       COPY XCPL1640.

      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY NCPAAPPF.
       COPY NCPNAPPF.
       COPY NCPUAPPF.

014221 COPY CCPNCLI.
014221 COPY CCPUCLI.

       COPY CCPNEDIT.
      *
      ****************************************************************
      * ADMIN COPYBOOKS                                             *
      ****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM0550                     **
      *****************************************************************
