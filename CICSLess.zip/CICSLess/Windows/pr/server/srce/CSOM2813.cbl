      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2813.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2813                                         **
      **  REMARKS:  DELETE PROCESS DRIVER FOR THE SPECIFIC           **
      **            ROLLOVER DESTINATION INSTRUCTIONS                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2813'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.


       01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '2810'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '2810'.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-DELETE        VALUE '2813'.
           05  WS-CVG-NUM                   PIC S9(02).
           05  WS-CF-EFF-DT                 PIC X(10).
           05  WS-CF-SEQ-NUM                PIC S9(03) COMP-3.
           05  WS-POL-PAYO-NUM              PIC S9(05) COMP-3.
           05  WS-HOLD-COVNO                PIC 9(02).
           05  WS-HOLD-COVNO-R              REDEFINES
               WS-HOLD-COVNO                PIC X(02).
                      
       COPY XCWLCOMM REPLACING '$VAR1' BY '2810'.
           15  LCOMM-OLD-CDSI               OCCURS 10.
               20  LCOMM-CDI-ALLOC-AMT      PIC S9(13)V9(02)
                                            COMP-3.
               20  LCOMM-DPOS-TRM-MO-DUR    PIC X(03).
               20  LCOMM-DPOS-TRM-DY-DUR    PIC X(03).
               20  LCOMM-CDI-ALLOC-NUM      PIC S9(03)
                                            COMP-3.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWCVGS.
      /
       COPY CCWWINDX.
      /
       COPY CCWWLOCK.
026057 COPY CCWWIHSD.
      /
       COPY XCWWWKDT.
      /
       COPY XCWWCVGM.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRCDSI.
       COPY CCFWCDSI.
      /
       COPY CCFRCFLW.
       COPY CCFWCFLW.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
       COPY CCFRPOLP.
       COPY CCFWPOLP.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
028298 COPY CCWL2626.
       COPY CCWL5400.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL0280.
      /
       COPY XCWL1640.
      /
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2813.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-PROCESS-DELETE
                        THRU 2000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2813'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       2000-PROCESS-DELETE.
      *--------------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-DELETE-X
           END-IF.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-DELETE-X
           END-IF.

           PERFORM  COMM-3000-DELETE-TWRK
               THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  2300-READ-POLP
               THRU 2300-READ-POLP-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-PROCESS-DELETE-X
           END-IF.

           PERFORM  8000-BUILD-CDSI-KEY
               THRU 8000-BUILD-CDSI-KEY-X.

           PERFORM  CDSI-1000-DELETE-KEY-RANGE
               THRU CDSI-1000-DELETE-KEY-RANGE-X.

           PERFORM  3200-UPDATE-CFLW
               THRU 3200-UPDATE-CFLW-X.

           PERFORM  3300-UPDATE-POLP
               THRU 3300-UPDATE-POLP-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-PROCESS-DELETE-X
           END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       2000-PROCESS-DELETE-X.
           EXIT.

      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: POLICY NOT ON FILE
               MOVE 'CS28130001'       TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
               MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF

           IF WS-HOLD-COVNO             > RPOL-POL-CVG-REC-CTR-N
      * MSG:  COVNO (@1) NOT FOUND
               MOVE 'CS28130016'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  NOT WCVGS-CVG-CF-TYP-GIA (WS-CVG-NUM)
           AND NOT WCVGS-CVG-CF-TYP-EIA (WS-CVG-NUM)
      *MSG: DELETE IS ONLY ALLOWED FOR GIA AND EIA COVERAGE
               MOVE 'CS28130002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CF-EFF-DT           TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-3000-CHK-IHSD-INSTR
026057         THRU IHSD-3000-CHK-IHSD-INSTR-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WGLOB-RETURN-ERROR  TO TRUE
026057         GO TO 2100-VALIDATE-KEYS-X
026057     END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-POL-XFER-UPDATE   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR  TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           MOVE MIR-POL-ID             TO WCFLW-POL-ID.
           MOVE WS-CVG-NUM             TO WCFLW-CVG-NUM-N.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG-NUM)
                                       TO WCFLW-CF-TYP-CD.
           MOVE WS-CF-EFF-DT           TO WCFLW-CF-EFF-DT.
           MOVE WS-CF-SEQ-NUM          TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF  WCFLW-IO-NOT-FOUND
      *MSG: NO CASH FLOW FOUND
               MOVE 'CS28130003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  2200-READ-NEXT-CFLW
               THRU 2200-READ-NEXT-CFLW-X
               UNTIL NOT WCFLW-IO-OK
               OR    RCFLW-NXT-CF-DT  = WWKDT-ZERO-DT.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *---------------------
       2200-READ-NEXT-CFLW.
      *---------------------

           MOVE RCFLW-NXT-CF-DT        TO WCFLW-CF-EFF-DT.
           MOVE RCFLW-NXT-CF-SEQ-NUM-N TO WCFLW-CF-SEQ-NUM-N.
           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

       2200-READ-NEXT-CFLW-X.
           EXIT.

      *---------------
       2300-READ-POLP.
      *---------------

           MOVE RPOL-POL-ID            TO WPOLP-POL-ID.
           MOVE RCFLW-CF-ROLOVR-PAYO-NUM
                                       TO WPOLP-POL-PAYO-NUM.

           PERFORM  POLP-1000-READ
               THRU POLP-1000-READ-X.
               
           COMPUTE WS-POL-PAYO-NUM     =  100000 - WPOLP-POL-PAYO-NUM.     

           IF  NOT WPOLP-IO-OK
      *MSG : PAYOUT RECORD FOR POLICY(@1) PAYOUT (@2) DOES NOT EXIST
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28130004'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2300-READ-POLP-X
           END-IF.

           IF  NOT RPOLP-POL-PAYO-TYP-ROLOVR-PAYO
      *MSG : PAYOUT RECORD TYPE FOR POLICY(@1) PAYOUT(@2) IS 
      *      NOT ROLLOVER
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28130005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2300-READ-POLP-X
           END-IF.

           IF  NOT RPOLP-POL-PAYO-STAT-ERRORS
           AND NOT RPOLP-POL-PAYO-STAT-ROLOVR
      *MSG : ONLY ROLLOVER DESTINATION INSTRUCTIONS WITH STATUS
      *      ACTIVE ROLLOVER PAYOUT CAN BE DELETED
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28130006'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2300-READ-POLP-X
           END-IF.

       2300-READ-POLP-X.
           EXIT.

      *-----------------
       3200-UPDATE-CFLW.
      *-----------------

           PERFORM  CFLW-1000-READ-FOR-UPDATE
               THRU CFLW-1000-READ-FOR-UPDATE-X.

           IF  NOT WCFLW-IO-OK
      *MSG : CASH FLOW RECORD NOT FOUND
               MOVE 'CS28130007'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3200-UPDATE-CFLW-X
           END-IF.

           MOVE ZERO                   TO RCFLW-CF-ROLOVR-PAYO-NUM.
           MOVE ZERO                   TO RCFLW-DEST-CDA-SEQ-NUM.

           PERFORM  CFLW-2000-REWRITE
               THRU CFLW-2000-REWRITE-X.

       3200-UPDATE-CFLW-X.
           EXIT.


      *-----------------
       3300-UPDATE-POLP.
      *-----------------

           PERFORM  POLP-1000-READ-FOR-UPDATE
               THRU POLP-1000-READ-FOR-UPDATE-X.

           IF  NOT WPOLP-IO-OK
      *MSG : PAYOUT RECORD FOR POLICY(@1), PAYOUT(@2) DOES NOT EXIST
               COMPUTE WS-POL-PAYO-NUM =  100000 - WPOLP-POL-PAYO-NUM     
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28130008'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3300-UPDATE-POLP-X
           END-IF.

           PERFORM  POLP-1000-DELETE
               THRU POLP-1000-DELETE-X.

       3300-UPDATE-POLP-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           IF  MIR-POL-ID = SPACE
      *MSG: THE POLICY ID MUST BE ENTERED
               MOVE 'CS28130009'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  MIR-CVG-NUM = SPACE
      *MSG: THE COVERAGE NUMBER MUST BE ENTERED
               MOVE 'CS28130010'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
               SET L0280-SPACES-PERMITTED
                                       TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CVG-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CVG-NUM        TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
               AND L0280-OUTPUT-V00 > ZERO
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CVG-NUM
               ELSE
      *MSG: COVERAGE NUMBER IS INVALID
                   MOVE 'CS28130011'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           MOVE MIR-CVG-NUM            TO WS-HOLD-COVNO-R.

           IF WS-HOLD-COVNO             > WCVGM-MAX-WCVGS-NUM
      * MSG:  COVERAGE NUMBER MUST BE 2 DIGITS BETWEEN 01 AND 20
               MOVE 'CS28130017'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           IF  MIR-CF-EFF-DT = SPACE
      *MSG: THE CASH FLOW EFFECTIVE DATE MUST BE ENTERED
               MOVE 'CS28130012'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               MOVE MIR-CF-EFF-DT      TO L1640-EXTERNAL-DATE
               PERFORM  1640-7000-MIR-TO-INT
                   THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-RETRN-OK
                   MOVE L1640-INTERNAL-DATE
                                       TO WS-CF-EFF-DT
               ELSE
      *MSG: CASH FLOW EFFECTIVE DATE IS INVALID
                   MOVE 'CS28130013'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           IF  MIR-CF-SEQ-NUM = SPACE
      *MSG: THE CASH FLOW SEQUENCE NUMBER MUST BE ENTERED
               MOVE 'CS28130014'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               SET L0280-SPACES-PERMITTED   TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CF-SEQ-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CF-SEQ-NUM     TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CF-SEQ-NUM
               ELSE
      *MSG: CASH FLOW SEQUENCE NUMBER IS INVALID
                   MOVE 'CS28130015'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.


      *--------------------
       8000-BUILD-CDSI-KEY.
      *--------------------

           MOVE LOW-VALUES             TO WCDSI-KEY.
           MOVE RPOL-POL-ID            TO WCDSI-POL-ID.
           SET  WCDSI-CDI-TYP-ROLOVR-PAYO
                                       TO TRUE.
           MOVE RPOLP-POL-PAYO-NUM     TO WCDSI-POL-PAYO-NUM.
           MOVE RPOLP-POL-PAYO-EFF-DT
                                       TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WCDSI-CDI-EFF-IDT-NUM.

           MOVE +001                   TO WCDSI-CDI-SEQ-NUM.
           MOVE ZERO                   TO WCDSI-CDI-ALLOC-NUM.
           MOVE WCDSI-KEY              TO WCDSI-ENDBR-KEY.
           MOVE +999                   TO WCDSI-ENDBR-CDI-ALLOC-NUM.

       8000-BUILD-CDSI-KEY-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      
      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-AREA.

025970     PERFORM  COMM-1000-INITIALIZE
025970         THRU COMM-1000-INITIALIZE-X.
025970*
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.     
025970     SET WS-TWRK-KEY-DEFAULT  TO TRUE.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK                TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
      /
       COPY XCPPCOMM.
025970 COPY XCPS1670.
025970 COPY XCPSCOMM.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPS5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL5400.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPGCDSI.
      /
       COPY CCPNCFLW.
       COPY CCPUCFLW.
      /
       COPY CCPNCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNPOLP.
       COPY CCPUPOLP.
       COPY CCPXPOLP.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM2813                     *
      ****************************************************************
