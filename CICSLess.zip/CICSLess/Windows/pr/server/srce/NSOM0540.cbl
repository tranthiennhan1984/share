      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0540.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0540                                         **
      **  REMARKS:  PHPI - PHYSICIAN AND PERSONAL INFORMATION        **
      **                                                             **
      **            THIS MODULE PERFORMS THE MAINTENANCE FUNCTIONS   **
      **            OF THE MEDICAL DATA FOR AN INSURED.  MEDICAL     **
      **            DATA INCLUDES HEIGHT AND WEIGHT DETAILS, NAME    **
      **            AND ADDRESS OF THE FAMILY PHYSICIAN AND DETAILS  **
      **            OF THE MOST RECENT VISIT. INFORMATION IS STORED  **
      **            ON THE APPLICATION FIXED INFORMATION TABLE.      **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       CICS ABEND HANDLING                              **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
006002**  6.0       SELECTION BOX AND CODE TRANSLATION CHANGES       **
013578**  6.0       GLOBAL CHANGES                                   **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       MODIFICATIONS FOR FORMAT CLIENT FULL NAME        **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016387**  6.2       REMOVE CLIENT CONSOLIDATION SUPPORT              **
016537**  6.2       CODE CLEAN UP                                    **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
015703**  6.4       REMOVE CCWLPGA                                   **
019435**  6.4       WEIGHT AND HEIGHT EDITS                          **
018622**  6.4       LOGICAL LOCKING FOR CREATE FLOW                  **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0540'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

      *
       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'PHPI'.
           05  WS-PIC-DATE                  PIC X(10).
           05  WS-PIC-999                   PIC 999.
           05  WS-PIC-999V9                 PIC 999.9.
           05  WS-PIC-9                     PIC 9.
           05  WS-PIC-99                    PIC 99.
           05  WS-N-9                       PIC S9(1).
           05  WS-N-99                      PIC S9(2).
           05  WS-N-999                     PIC S9(3).
           05  WS-N-999V9                   PIC S9(3)V9.
           05  WS-SAVE-HEIGHT               PIC S9(3)V9.
013578     05  WS-MIR-HEIGHT-FT             PIC S9(3) COMP-3.
013578     05  WS-MIR-HEIGHT-IN             PIC S9(2) COMP-3.
013578     05  WS-MIR-HEIGHT-CM             PIC S9(3)V9 COMP-3.
013578     05  WS-MIR-WEIGHT-LB             PIC S9(3) COMP-3.
013578     05  WS-MIR-WEIGHT-KG             PIC S9(3)V9 COMP-3.
013578     05  WS-MIR-WEIGHT-CHNG-LB        PIC S9(3) COMP-3.
013578     05  WS-MIR-WEIGHT-CHNG-KG        PIC S9(3)V9 COMP-3.
           05  WS-SAVE-WEIGHT               PIC S9(3)V9.
           05  WS-SCALE                     PIC X(01).
               88  SCALE-IMPERIAL                      VALUE 'I'.
               88  SCALE-METRIC                        VALUE 'M'.
           05  WS-VALIDATE-CONTROL          PIC X(01).
               88  WS-INVALID-CONTROL                  VALUE '1'.
           05  WS-VALUES-ENTERED-CD         PIC X(01).
               88  WS-BOTH-ENTERED          VALUE 'B'.
               88  WS-METRIC-ENTERED        VALUE 'M'.
               88  WS-IMPERIAL-ENTERED      VALUE 'I'.
013578         88  WS-NONE-ENTERED          VALUE 'N'.
           05  WS-METRIC-EDIT-SW            PIC X(01).
               88  WS-METRIC-OK             VALUE 'Y'.
               88  WS-METRIC-OK-NO          VALUE 'N'.
           05  WS-IMPERIAL-EDIT-SW            PIC X(01).
               88  WS-IMPERIAL-OK           VALUE 'Y'.
               88  WS-IMPERIAL-OK-NO        VALUE 'N'.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-VALID         VALUE '0540' '0542'.
013578         88  WS-BUS-FCN-RETRIEVE      VALUE '0540'.
013578         88  WS-BUS-FCN-UPDATE        VALUE '0542'.
           05  WS-EDIT-OK-SW                PIC X(01).
               88  WS-EDIT-OK               VALUE '0'.
           05  WS-CROSS-EDIT-OK-SW          PIC X(01).
               88  WS-CROSS-EDIT-OK         VALUE '0'.
           05  WS-TEST-GLIND                PIC X(01).
               88  WS-GLIND-OK              VALUE '+' '-'.
           05  WS-TEST-RPHYS                PIC X(01).
               88  WS-RPHYS-OK              VALUE 'Y' 'N'.
               88  WS-RPHYS-YES             VALUE 'Y'.
           05  WS-TEST-FEET                 PIC X(01).
               88  WS-FEET-OK               VALUE '0' THRU '9'.
           05  WS-TEST-YES-NO               PIC X(01).
               88  WS-TEST-YES-NO-OK        VALUE 'Y' 'N'.
013578     05  WS-CLI-HT-CM                 PIC S9(3)V9 COMP-3.
013578     05  WS-CLI-HT-FT                 PIC S9(3) COMP-3.
013578     05  WS-CLI-HT-IN                 PIC S9(2) COMP-3.
013578     05  WS-CLI-WGT-CHNG-QTY-KG       PIC S9(04)V9 COMP-3.
013578     05  WS-CLI-WGT-CHNG-QTY-LB       PIC S9(04)V9 COMP-3.
013578     05  WS-CLI-WGT-KG                PIC S9(04)V9  COMP-3.
013578     05  WS-CLI-WGT-LB                PIC S9(04)V9  COMP-3.
025970*
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'PHPI'.
025970*
018633*01  WS-TWRK-KEY                      PIC X(04) VALUE '0540'.
018633*01  WS-WORK-AREA.
018633*    05  WS-WORK-PROGRAM-NUMBER       PIC X(04).
018633*    05  WS-WORK-CLIENT-NUMBER        PIC X(10).
018633*    05  WS-WORK-POL-ID.
018633*        10  WS-WORK-POL-ID-BASE      PIC X(09).
018633*        10  WS-WORK-POL-ID-SFX       PIC X(01).
018633*    05  WS-WORK-QUOTE-NUMBER         PIC X(06).
018633*    05  WS-WORK-CLAIM-NO             PIC X(06).
018633*    05  WS-WORK-SPECIFIC-AREA        PIC X(264).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '0540'.
018633     15  LCOMM-PROGRAM-NUMBER         PIC X(04).
018633     15  LCOMM-CLIENT-NUMBER          PIC X(10).
018633     15  LCOMM-POL-ID.
018633         20  LCOMM-POL-ID-BASE        PIC X(09).
018633         20  LCOMM-POL-ID-SFX         PIC X(01).
018633     15  LCOMM-QUOTE-NUMBER           PIC X(06).
018633     15  LCOMM-CLAIM-NO               PIC X(06).
018633     15  LCOMM-SPECIFIC-AREA          PIC X(264).
      *
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      *
      *
       COPY XCWEBLCH.
      *
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY NCFWAPPF.
      *
       COPY NCFRAPPF.
      *
       COPY CCFWPCOM.
       COPY CCFRPCOM.
      *
006002 COPY XCFWCTLC.
006002 COPY XCFRCTLC.
       COPY CCFWEDIT.
      *
014221 COPY CCFWCLI.
014221 COPY CCFRCLI.
      *
       COPY CCFREDIT.
      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL0280.
      *
       COPY NCWL0520.
      *
       COPY NCWL0530.
      *
       COPY NCWL2437.
      *
       COPY CCWL0620.
      *
       COPY XCWLDTLK.
      *
       COPY XCWL1640.
      *
013578 COPY XCWL8090.
      *
       COPY CCWL5600.
      *
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
015703*COPY CCWLPGA.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0540.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.

013578     PERFORM  2000-PROCESS-REQUEST
013578         THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      ***************************
       2000-PROCESS-REQUEST.
      ***************************

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.
018633*    MOVE SPACES TO WS-WORK-AREA.
      *
      *  ACCESS PCOM TO OBTAIN THE SCALE
      *
025970*    SET MIR-RETRN-OK                 TO TRUE.
           PERFORM  PCOM-1000-READ
               THRU PCOM-1000-READ-X.

           IF NOT WPCOM-IO-OK
               MOVE 'XS00000053'            TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
013578         GO TO 2000-PROCESS-REQUEST-X
           END-IF.

013578     IF MIR-CLI-ID = SPACES
018633*        MOVE WS-WORK-CLIENT-NUMBER     TO MIR-CLI-ID
018633         MOVE LCOMM-CLIENT-NUMBER       TO MIR-CLI-ID
013578     END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  7000-VALIDATE-ACCESS
               THRU 7000-VALIDATE-ACCESS-X.

           IF  L2437-RETRN-CLI-NOT-FOUND
           OR  L5600-CNFD-ACCS-RESTRICTED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
013578         GO TO 2000-PROCESS-REQUEST-X
013578     ELSE
018633*        MOVE MIR-CLI-ID               TO WS-WORK-CLIENT-NUMBER
018633         MOVE MIR-CLI-ID               TO LCOMM-CLIENT-NUMBER
           END-IF.

      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           MOVE RPCOM-CO-HWTB-SCALE-CD      TO  WS-SCALE.

013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-RETRIEVE
013578             PERFORM  3000-PROCESS-RETRIEVE
013578                 THRU 3000-PROCESS-RETRIEVE-X
013578
013578         WHEN WS-BUS-FCN-UPDATE
013578             PERFORM  4000-PROCESS-UPDATE
013578                 THRU 4000-PROCESS-UPDATE-X
013578
013578         WHEN OTHER
013578*MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
013578              MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
013578              MOVE 'NSOM0540'        TO WGLOB-MSG-PARM (2)
013578              MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
013578              PERFORM  0260-1000-GENERATE-MESSAGE
013578                  THRU 0260-1000-GENERATE-MESSAGE-X
013578              SET MIR-RETRN-INVALD-RQST TO TRUE
013578
013578     END-EVALUATE.

013578 2000-PROCESS-REQUEST-X.
           EXIT.
      *
      ***************************************************************
      *   RETRIEVE PROCESSING: SETUP BROWSW KEYS, BEGIN BROWSE AND
      *   LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.
      ***************************************************************
      ***************************
013578 3000-PROCESS-RETRIEVE.
      ***************************

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  8000-BUILD-APPF-KEY
               THRU 8000-BUILD-APPF-KEY-X.

018622     MOVE MIR-CLI-ID         TO WCLI-CLI-ID.
018622     PERFORM  CLI-1000-READ-TWRK-TS
018622         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  APPF-1000-READ
               THRU APPF-1000-READ-X.

           IF NOT WAPPF-IO-OK
               MOVE 'XS00000118'   TO WGLOB-MSG-REF-INFO
               MOVE WAPPF-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
013578         GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.

018622*    MOVE RAPPF-CLI-ID           TO WCLI-CLI-ID.

018622*    PERFORM  CLI-1000-READ-TWRK-TS
018622*        THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE 'XS00000002'   TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.

013578 3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *--------------------
013578 4000-PROCESS-UPDATE.
      *--------------------

018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.
013578
018633*    IF L8090-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT TO WS-WORK-AREA
018633*    END-IF.
018633*
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           IF  L5600-CCAS-ACCS-RESTRICTED
013578         GO TO 4000-PROCESS-UPDATE-X
           END-IF.

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.
014221
014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CLI'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WCLI-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 4000-PROCESS-UPDATE-X
014221     END-IF.

014221     PERFORM  CLI-3000-UNLOCK
014221         THRU CLI-3000-UNLOCK-X.

013578     PERFORM  8000-BUILD-APPF-KEY
013578         THRU 8000-BUILD-APPF-KEY-X.
013578*
013578*   CHECK IF RECORD EXISTS.
013578*
013578     PERFORM  APPF-1000-READ
013578         THRU APPF-1000-READ-X.
013578     IF WAPPF-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
013578     ELSE
013578         PERFORM  APPF-1000-CREATE
013578             THRU APPF-1000-CREATE-X
013578         PERFORM  4110-DEFAULT-PREGNANCY-IND
013578             THRU 4110-DEFAULT-PREGNANCY-IND-X
013578         PERFORM  APPF-1000-WRITE
013578             THRU APPF-1000-WRITE-X
013578     END-IF.

           PERFORM  8000-BUILD-APPF-KEY
               THRU 8000-BUILD-APPF-KEY-X.

           PERFORM  APPF-1000-READ-FOR-UPDATE
               THRU APPF-1000-READ-FOR-UPDATE-X.

           IF WAPPF-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'XS00000016'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
013578         GO TO 4000-PROCESS-UPDATE-X
557660     END-IF.
      *
      *
           PERFORM  5000-EDIT-FIELDS
               THRU 5000-EDIT-FIELDS-X.
      *
           IF WS-SAVE-WEIGHT NOT = L2437-CLI-WGT      OR
              WS-SAVE-HEIGHT NOT = L2437-CLI-HT
               PERFORM  4300-UPDATE-NAL
                   THRU 4300-UPDATE-NAL-X
557660     END-IF.
      *
           PERFORM  APPF-2000-REWRITE
               THRU APPF-2000-REWRITE-X.

014221     PERFORM  CLI-1000-READ-FOR-UPDATE
014221         THRU CLI-1000-READ-FOR-UPDATE-X.

014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

      *
      ***  UPDATE THE NEW LAST-UPDATE-DATE ON THE SCREEN.
      *
014221*    MOVE RAPPF-PREV-UPDT-DT      TO L1640-INTERNAL-DATE.
014221*    MOVE RAPPF-PREV-UPDT-TS      TO L1640-INTERNAL-DATE.
014221     MOVE RAPPF-PREV-UPDT-TS      TO WWKDT-INT-TS.
014221     MOVE WWKDT-INT-TS            TO L1640-INTERNAL-DATE.
           PERFORM  9250-CONVERT-DATE
               THRU 9250-CONVERT-DATE-X.
014221*    MOVE L1640-EXTERNAL-DATE     TO MIR-PREV-UPDT-DT.
014221     MOVE L1640-EXTERNAL-DATE     TO MIR-DV-PREV-UPDT-DT.
      *
           IF  WS-EDIT-OK
           AND WS-CROSS-EDIT-OK
               MOVE 'XS00000007'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
013578*        MOVE 'I'            TO MIR-ENTER
           ELSE
               MOVE 'XS00000008'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.

013578 4000-PROCESS-UPDATE-X.
           EXIT.
      *
      *---------------------------
       4110-DEFAULT-PREGNANCY-IND.
      *---------------------------
           IF L2437-CLI-SEX-CD NOT = 'F'
               MOVE 'N' TO RAPPF-CLI-PREG-IND
557660     END-IF.

       4110-DEFAULT-PREGNANCY-IND-X.
           EXIT.
      *
      *----------------
       4300-UPDATE-NAL.
      *----------------

      ***************************************************************
      *   UPDATE NAL RECORD WITH NEW HEIGHT AND WEIGHT
      ***************************************************************

           PERFORM  8100-BUILD-NAL-KEY
               THRU 8100-BUILD-NAL-KEY-X.

      *
      *   UPDATE CLI INFORMATION.
      *
           IF  WS-SAVE-HEIGHT       NOT =  L2437-CLI-HT
               MOVE WS-SAVE-HEIGHT      TO L2437-CLI-HT
               SET  L2437-CLI-HT-UPDT   TO TRUE
           END-IF.

           IF  WS-SAVE-WEIGHT       NOT =  L2437-CLI-WGT
               MOVE WS-SAVE-WEIGHT      TO L2437-CLI-WGT
               SET  L2437-CLI-WGT-UPDT  TO TRUE
           END-IF.

           PERFORM  2437-2000-UPDT-CLI-INFO
               THRU 2437-2000-UPDT-CLI-INFO-X.

           IF  L2437-RETRN-CLI-NOT-FOUND
      *MSG: LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
               MOVE 'XS00000006'            TO WGLOB-MSG-REF-INFO
               MOVE L2437-WCLI-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4300-UPDATE-NAL-X.
           EXIT.
      *
      *-----------------
       5000-EDIT-FIELDS.
      *-----------------
           MOVE '0'   TO WS-EDIT-OK-SW.
           MOVE '0'   TO WS-CROSS-EDIT-OK-SW.

013578     PERFORM  5050-HOLD-CLIENT-INFO
013578         THRU 5050-HOLD-CLIENT-INFO-X.

           PERFORM  5100-EDIT-HEIGHT
               THRU 5100-EDIT-HEIGHT-X.

           PERFORM  5200-EDIT-WEIGHT
               THRU 5200-EDIT-WEIGHT-X.

           PERFORM  5400-EDIT-WGTCH
               THRU 5400-EDIT-WGTCH-X.

           PERFORM  5300-EDIT-GLIND
               THRU 5300-EDIT-GLIND-X.

           PERFORM  5500-EDIT-RPHYS
               THRU 5500-EDIT-RPHYS-X.

           PERFORM  5600-EDIT-PPROV
               THRU 5600-EDIT-PPROV-X.

           PERFORM  5700-EDIT-VDATE
               THRU 5700-EDIT-VDATE-X.

           PERFORM  5800-EDIT-VREAS
               THRU 5800-EDIT-VREAS-X.

           PERFORM  5900-EDIT-RWGTC
               THRU 5900-EDIT-RWGTC-X.

           PERFORM  6000-EDIT-PNAME
               THRU 6000-EDIT-PNAME-X.

           PERFORM  6100-EDIT-PCITY
               THRU 6100-EDIT-PCITY-X.

           PERFORM  6200-EDIT-RSLTS
               THRU 6200-EDIT-RSLTS-X.

           PERFORM  6300-EDIT-IMED
               THRU 6300-EDIT-IMED-X.

           PERFORM  6400-EDIT-TRTMT
               THRU 6400-EDIT-TRTMT-X.

           PERFORM  6500-EDIT-IDISO
               THRU 6500-EDIT-IDISO-X.

           PERFORM  6600-EDIT-PREGI
               THRU 6600-EDIT-PREGI-X.

           PERFORM  6700-EDIT-CONDT
               THRU 6700-EDIT-CONDT-X.

           PERFORM  6800-EDIT-CMPLI
               THRU 6800-EDIT-CMPLI-X.

           PERFORM  6900-PREG-XEDITS
               THRU 6900-PREG-XEDITS-X.
      *
      *   PERFORM ANY CROSS EDITS USING VALUES ON THE RECORD.
      *
           IF  RAPPF-REASN-WGT-CHNG-TXT = SPACES
           AND RAPPF-CLI-WGT-CHNG-QTY NOT = ZEROS
               MOVE 'NS05400032'    TO WGLOB-MSG-REF-INFO
      * MESSAGE: WEIGHT CHANGE REASON REQUIRED IF WGT CHANGE NOT 0
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.

       5000-EDIT-FIELDS-X.
           EXIT.
      *
      **********************
013578 5050-HOLD-CLIENT-INFO.
      **********************

013578     IF SCALE-METRIC
013578         MOVE L2437-CLI-HT           TO WS-CLI-HT-CM
013578         MOVE L2437-CLI-WGT          TO WS-CLI-WGT-KG
013578         MOVE L2437-CLI-HT           TO L0520-METRIC-HEIGHT
013578         PERFORM  0520-2000-CM-TO-FEET
013578             THRU 0520-2000-CM-TO-FEET-X
013578         MOVE L0520-IMPERIAL-FEET    TO WS-CLI-HT-FT
013578         MOVE L0520-IMPERIAL-INCHES  TO WS-CLI-HT-IN
013578         MOVE L2437-CLI-WGT          TO L0530-METRIC-WEIGHT
013578         PERFORM  0530-2000-KG-TO-LBS
013578             THRU 0530-2000-KG-TO-LBS-X
013578         MOVE L0530-IMPERIAL-WEIGHT  TO WS-CLI-WGT-LB
013578     ELSE
013578         MOVE L2437-CLI-HT           TO L0520-IMPERIAL-INCHES
013578         SET L0520-RQST-IN-TO-FEET   TO TRUE
013578         PERFORM  0520-3000-IN-TO-FEET
013578             THRU 0520-3000-IN-TO-FEET-X
013578         MOVE L0520-IMPERIAL-FEET    TO WS-CLI-HT-FT
013578         MOVE L0520-IMPERIAL-INCHES  TO WS-CLI-HT-IN
013578         PERFORM  0520-1000-FEET-TO-CM
013578             THRU 0520-1000-FEET-TO-CM-X
013578         MOVE L0520-METRIC-HEIGHT    TO WS-CLI-HT-CM
013578         MOVE L2437-CLI-WGT          TO WS-CLI-WGT-LB
013578         MOVE L2437-CLI-WGT          TO L0530-IMPERIAL-WEIGHT
013578         PERFORM  0530-1000-LBS-TO-KG
013578             THRU 0530-1000-LBS-TO-KG-X
013578         MOVE L0530-METRIC-WEIGHT    TO WS-CLI-WGT-KG
013578     END-IF.

013578     IF SCALE-METRIC
013578         MOVE RAPPF-CLI-WGT-CHNG-QTY TO WS-CLI-WGT-CHNG-QTY-KG
013578         MOVE RAPPF-CLI-WGT-CHNG-QTY TO L0530-METRIC-WEIGHT
013578         PERFORM  0530-2000-KG-TO-LBS
013578             THRU 0530-2000-KG-TO-LBS-X
013578         MOVE L0530-IMPERIAL-WEIGHT  TO WS-CLI-WGT-CHNG-QTY-LB
013578     ELSE
013578         MOVE RAPPF-CLI-WGT-CHNG-QTY TO WS-CLI-WGT-CHNG-QTY-LB
013578         MOVE RAPPF-CLI-WGT-CHNG-QTY TO L0530-IMPERIAL-WEIGHT
013578         PERFORM  0530-1000-LBS-TO-KG
013578             THRU 0530-1000-LBS-TO-KG-X
013578         MOVE L0530-METRIC-WEIGHT    TO WS-CLI-WGT-CHNG-QTY-KG
013578     END-IF.

013578 5050-HOLD-CLIENT-INFO-X.
013578     EXIT.

      *
      *-----------------
       5100-EDIT-HEIGHT.
      *-----------------
           MOVE L2437-CLI-HT             TO WS-SAVE-HEIGHT.
           MOVE ZEROES                   TO L0520-IMPERIAL-FEET.
           MOVE ZEROES                   TO L0520-IMPERIAL-INCHES.
           MOVE SPACES                   TO WS-VALUES-ENTERED-CD.
           SET WS-METRIC-OK-NO           TO TRUE.
           SET WS-IMPERIAL-OK-NO         TO TRUE.

           IF MIR-DV-CLI-CM-HT = EBLCH-BLANK-FIELD-CHAR
           OR MIR-DV-CLI-FT-HT = EBLCH-BLANK-FIELD-CHAR
           OR MIR-DV-CLI-INCH-HT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO          TO WS-PIC-999V9
               MOVE ZERO          TO WS-SAVE-HEIGHT
               MOVE WS-PIC-999V9  TO MIR-DV-CLI-CM-HT
               MOVE ZERO          TO MIR-DV-CLI-FT-HT
               MOVE ZERO          TO WS-N-99
               MOVE WS-N-99       TO WS-PIC-99
               MOVE WS-PIC-99     TO MIR-DV-CLI-INCH-HT
               GO TO 5100-EDIT-HEIGHT-X
557660     END-IF.

013578     MOVE WS-CLI-HT-CM TO WS-MIR-HEIGHT-CM.
013578     MOVE WS-CLI-HT-FT TO WS-MIR-HEIGHT-FT.
013578     MOVE WS-CLI-HT-IN TO WS-MIR-HEIGHT-IN.

013578     IF MIR-DV-CLI-CM-HT > SPACES
013578         MOVE 'N'          TO L0280-SIGN-IND
013578         MOVE 1            TO L0280-PRECISION
013578         MOVE 3            TO L0280-LENGTH
013578         MOVE 5            TO L0280-INPUT-SIZE
013578         MOVE MIR-DV-CLI-CM-HT   TO L0280-INPUT-DATA
013578         PERFORM  7800-NUMERIC-EDIT
013578             THRU 7800-NUMERIC-EDIT-X
013578         IF L0280-OK
013578             MOVE L0280-OUTPUT-V01 TO WS-MIR-HEIGHT-CM
013578         ELSE
013578*MSG: CENTIMETERS MUST BE NUMERIC IN THE FORM 999.9
013578             MOVE 'NS05400009'  TO  WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578         END-IF
013578     END-IF.

013578     IF  MIR-DV-CLI-FT-HT > SPACES
013578         MOVE 'N'          TO L0280-SIGN-IND
013578         MOVE 0            TO L0280-PRECISION
013578         MOVE 3            TO L0280-LENGTH
013578         MOVE 3                    TO L0280-INPUT-SIZE
013578         MOVE MIR-DV-CLI-FT-HT     TO L0280-INPUT-DATA
013578         PERFORM  7800-NUMERIC-EDIT
013578             THRU 7800-NUMERIC-EDIT-X
013578         IF L0280-OK
013578             MOVE L0280-OUTPUT-V00 TO WS-MIR-HEIGHT-FT
013578         ELSE
013578*MSG: FEET MUST BE NUMERIC
013578             MOVE 'NS05400010'     TO  WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578         END-IF
013578     END-IF.

013578     IF  MIR-DV-CLI-INCH-HT > SPACES
013578         MOVE 'N'                  TO L0280-SIGN-IND
013578         MOVE 0                    TO L0280-PRECISION
013578         MOVE 2                    TO L0280-LENGTH
013578         MOVE 2                    TO L0280-INPUT-SIZE
013578         MOVE MIR-DV-CLI-INCH-HT     TO L0280-INPUT-DATA
013578         PERFORM  7800-NUMERIC-EDIT
013578             THRU 7800-NUMERIC-EDIT-X
013578         IF L0280-OK
013578             MOVE L0280-OUTPUT-V00 TO WS-MIR-HEIGHT-IN
013578         ELSE
013578*MSG: INCHES MUST BE NUMERIC IN THE FORM 99
013578             MOVE 'NS05400011'     TO  WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578         END-IF
013578     END-IF.

013578     IF WS-MIR-HEIGHT-IN > 11
018763        MOVE WS-CLI-HT-IN     TO WS-MIR-HEIGHT-IN
013578*MSG: INCHES MUST BE LESS THAN 12
               MOVE 'NS05400012'    TO WGLOB-MSG-REF-INFO
013578         PERFORM  0260-1000-GENERATE-MESSAGE
013578             THRU 0260-1000-GENERATE-MESSAGE-X
018763*        GO TO 5100-EDIT-HEIGHT-X
013578     END-IF.

018763     IF WS-MIR-HEIGHT-CM > 302.3
018763        MOVE WS-CLI-HT-IN     TO WS-MIR-HEIGHT-IN
018763*MSG: HEIGHT MUST BE LESS THAN 302.3CM
018763         MOVE 'NS05400037'    TO WGLOB-MSG-REF-INFO
018763         PERFORM  0260-1000-GENERATE-MESSAGE
018763             THRU 0260-1000-GENERATE-MESSAGE-X
018763     END-IF.

013578     SET WS-NONE-ENTERED        TO TRUE.

013578     EVALUATE TRUE

013578         WHEN WS-MIR-HEIGHT-CM NOT = WS-CLI-HT-CM
013578             IF WS-MIR-HEIGHT-FT     NOT = WS-CLI-HT-FT
013578             OR WS-MIR-HEIGHT-IN NOT = WS-CLI-HT-IN
013578                 SET WS-BOTH-ENTERED TO TRUE
013578             ELSE
013578                 SET WS-METRIC-ENTERED TO TRUE
013578             END-IF

013578         WHEN OTHER
013578             IF WS-MIR-HEIGHT-FT     NOT = WS-CLI-HT-FT
013578             OR WS-MIR-HEIGHT-IN NOT = WS-CLI-HT-IN
013578                 SET WS-IMPERIAL-ENTERED TO TRUE
013578             END-IF

013578     END-EVALUATE.

013578     IF WS-METRIC-ENTERED
019435     OR WS-BOTH-ENTERED
013578         MOVE WS-MIR-HEIGHT-CM  TO WS-CLI-HT-CM
013578         MOVE WS-MIR-HEIGHT-CM  TO L0520-METRIC-HEIGHT
013578         PERFORM  0520-2000-CM-TO-FEET
013578             THRU 0520-2000-CM-TO-FEET-X
013578         MOVE L0520-IMPERIAL-FEET   TO WS-CLI-HT-FT
013578         MOVE L0520-IMPERIAL-INCHES TO WS-CLI-HT-IN
019435         IF WS-BOTH-ENTERED
019435             MOVE 'NS05400039'      TO  WGLOB-MSG-REF-INFO
019435             PERFORM  0260-1000-GENERATE-MESSAGE
019435                 THRU 0260-1000-GENERATE-MESSAGE-X
019435         END-IF
019435*    END-IF.
019435     ELSE
013578         IF WS-IMPERIAL-ENTERED
013578             MOVE WS-MIR-HEIGHT-FT     TO WS-CLI-HT-FT
013578             MOVE WS-MIR-HEIGHT-IN     TO WS-CLI-HT-IN
013578             MOVE WS-MIR-HEIGHT-FT     TO L0520-IMPERIAL-FEET
013578             MOVE WS-MIR-HEIGHT-IN TO L0520-IMPERIAL-INCHES
013578             PERFORM  0520-1000-FEET-TO-CM
013578                 THRU 0520-1000-FEET-TO-CM-X
013578             MOVE L0520-METRIC-HEIGHT  TO WS-CLI-HT-CM
019435         END-IF
013578     END-IF.

013578     IF SCALE-METRIC
013578         MOVE WS-CLI-HT-CM           TO WS-SAVE-HEIGHT
013578     ELSE
013578         MOVE WS-CLI-HT-FT           TO L0520-IMPERIAL-FEET
013578         MOVE WS-CLI-HT-IN           TO L0520-IMPERIAL-INCHES
013578         PERFORM  0520-4000-FEET-TO-IN
013578             THRU 0520-4000-FEET-TO-IN-X
013578         MOVE L0520-IMPERIAL-INCHES  TO L0280-INPUT-DATA
013578         PERFORM  5125-CONVERT-TO-DECIMAL
013578             THRU 5125-CONVERT-TO-DECIMAL-X
013578         MOVE L0280-OUTPUT-V01       TO WS-SAVE-HEIGHT
           END-IF.

013578*  REDISPLAY ON MIR

013578     MOVE WS-CLI-HT-CM   TO WS-PIC-999V9.
013578     MOVE WS-PIC-999V9   TO MIR-DV-CLI-CM-HT.
013578     MOVE WS-CLI-HT-FT   TO WS-N-9.
013578     MOVE WS-N-9         TO MIR-DV-CLI-FT-HT.
013578     MOVE WS-CLI-HT-IN   TO WS-PIC-99.
013578     MOVE WS-PIC-99      TO MIR-DV-CLI-INCH-HT.




013578     GO TO 5100-EDIT-HEIGHT-X.


013578*    IF MIR-DV-CLI-CM-HT = SPACES AND
013578*       (MIR-DV-CLI-FT-HT = SPACES AND MIR-DV-CLI-INCH-HT
013578*       = SPACES)
013578*        IF SCALE-METRIC
013578*            MOVE L2437-CLI-HT             TO WS-N-999V9
013578*            MOVE L2437-CLI-HT             TO WS-SAVE-HEIGHT
013578*            MOVE WS-N-999V9               TO WS-PIC-999V9
013578*            MOVE WS-PIC-999V9             TO MIR-DV-CLI-CM-HT
013578*            MOVE L2437-CLI-HT             TO L0520-METRIC-HEIGHT
013578*            PERFORM 0520-2000-CM-TO-FEET
013578*                THRU 0520-2000-CM-TO-FEET-X
013578*            MOVE L0520-IMPERIAL-FEET      TO WS-N-9
013578*            MOVE WS-N-9                   TO MIR-DV-CLI-FT-HT
013578*            MOVE L0520-IMPERIAL-INCHES    TO WS-N-99
013578*            MOVE WS-N-99                  TO WS-PIC-99
013578*            MOVE WS-PIC-99                TO MIR-DV-CLI-INCH-HT
013578*            GO TO 5100-EDIT-HEIGHT-X
013578*        ELSE
013578*            MOVE L2437-CLI-HT           TO WS-SAVE-HEIGHT
013578*            MOVE L2437-CLI-HT           TO L0520-IMPERIAL-INCHES
013578*            PERFORM  0520-3000-IN-TO-FEET
013578*               THRU  0520-3000-IN-TO-FEET-X
013578*            PERFORM  0520-1000-FEET-TO-CM
013578*               THRU  0520-1000-FEET-TO-CM-X
013578*            MOVE L0520-METRIC-HEIGHT      TO WS-N-999V9
013578*            MOVE WS-N-999V9               TO WS-PIC-999V9
013578*            MOVE WS-PIC-999V9             TO MIR-DV-CLI-CM-HT
013578*            MOVE L0520-IMPERIAL-FEET      TO WS-N-9
013578*            MOVE WS-N-9                   TO MIR-DV-CLI-FT-HT
013578*            MOVE L0520-IMPERIAL-INCHES    TO WS-N-99
013578*            MOVE WS-N-99                  TO WS-PIC-99
013578*            MOVE WS-PIC-99                TO MIR-DV-CLI-INCH-HT
013578*            PERFORM  5150-CHECK-FEET
013578*                THRU 5150-CHECK-FEET-X
013578*            GO TO 5100-EDIT-HEIGHT-X
013578*        END-IF
013578*    END-IF.


013578****   IF METRIC AND IMPERIAL ENTERED
013578****   CONVERT IMPERIAL TO METRIC AND STORE/DISPLAY
013578*    IF SCALE-METRIC
013578*        IF  MIR-DV-CLI-FT-HT NOT = SPACES
013578*        AND MIR-DV-CLI-INCH-HT NOT = SPACES
013578*            PERFORM  5150-CHECK-FEET
013578*                THRU 5150-CHECK-FEET-X
013578*            IF WGLOB-MSG-ERROR-SW > 0
013578*            AND WS-IMPERIAL-ENTERED
013578*                GO TO 5100-EDIT-HEIGHT-X
013578*            ELSE
013578*                IF NOT WS-BOTH-ENTERED
013578*                    MOVE 'NS05400001'   TO WGLOB-MSG-REF-INFO
013578*                    PERFORM  0260-1000-GENERATE-MESSAGE
013578*                        THRU 0260-1000-GENERATE-MESSAGE-X
013578*                    GO TO 5100-EDIT-HEIGHT-X
013578*                END-IF
013578*            END-IF
013578*        END-IF
013578*    END-IF.

013578*    IF SCALE-METRIC
013578*        IF WS-IMPERIAL-ENTERED
013578*        OR WS-BOTH-ENTERED
013578*             IF MIR-DV-CLI-FT-HT = SPACES
013578*             OR MIR-DV-CLI-INCH-HT = SPACES
013578*           PERFORM  5105-GET-IMPERIAL
013578*               THRU 5105-GET-IMPERIAL-X
013578*            PERFORM  5150-CHECK-FEET
013578*                THRU 5150-CHECK-FEET-X
013578*                IF WS-IMPERIAL-ENTERED
013578*                AND WGLOB-MSG-ERROR-SW NOT > 0
013578*                    MOVE 'NS05400001'   TO WGLOB-MSG-REF-INFO
013578*                    PERFORM  0260-1000-GENERATE-MESSAGE
013578*                        THRU 0260-1000-GENERATE-MESSAGE-X
013578*                    GO TO 5100-EDIT-HEIGHT-X
013578*                END-IF
013578*            END-IF
013578*        END-IF
013578*    END-IF.

013578****   IF METRIC AND METRIC ENTERED
013578****   STORE METRIC; CONVERT METRIC TO IMPERIAL AND DISPLAY
013578*    IF SCALE-METRIC
013578*         IF MIR-DV-CLI-CM-HT > SPACES
013578*            MOVE 'N'          TO L0280-SIGN-IND
013578*            MOVE 1            TO L0280-PRECISION
013578*            MOVE 3            TO L0280-LENGTH
013578*            MOVE 5            TO L0280-INPUT-SIZE
013578*            MOVE MIR-DV-CLI-CM-HT   TO L0280-INPUT-DATA
013578*            PERFORM  7800-NUMERIC-EDIT
013578*                THRU 7800-NUMERIC-EDIT-X
013578*            IF L0280-OK
013578*            MOVE L0280-OUTPUT-V01         TO WS-N-999V9
013578*            MOVE WS-N-999V9               TO WS-PIC-999V9
013578*            MOVE WS-PIC-999V9             TO MIR-DV-CLI-CM-HT
013578*            MOVE L0280-OUTPUT-V01         TO L0520-METRIC-HEIGHT
013578*            IF L0280-OUTPUT-V01 = 0
013578*                PERFORM  5150-CHECK-FEET
013578*                    THRU 5150-CHECK-FEET-X
013578*                GO TO 5100-EDIT-HEIGHT-X
013578*            ELSE
013578*                PERFORM  0520-2000-CM-TO-FEET
013578*                    THRU 0520-2000-CM-TO-FEET-X
013578*                IF L0520-RETRN-FAILED
013578*                    MOVE 'NS05400023'      TO WGLOB-MSG-REF-INFO
013578*                    PERFORM  0260-1000-GENERATE-MESSAGE
013578*                        THRU 0260-1000-GENERATE-MESSAGE-X
013578*                    MOVE L2437-CLI-HT      TO L0520-METRIC-HEIGHT
013578*                    PERFORM  0520-2000-CM-TO-FEET
013578*                        THRU 0520-2000-CM-TO-FEET-X
013578*                    MOVE L0520-IMPERIAL-FEET   TO WS-N-9
013578*                    MOVE WS-N-9             TO MIR-DV-CLI-FT-HT
013578*                    MOVE L0520-IMPERIAL-INCHES TO WS-N-99
013578*                    MOVE WS-N-99               TO WS-PIC-99
013578*                    MOVE WS-PIC-99          TO MIR-DV-CLI-INCH-HT
013578*                    MOVE '1'                   TO WS-EDIT-OK-SW
013578*                    GO TO 5100-EDIT-HEIGHT-X
013578*                ELSE
013578*                    MOVE L0280-OUTPUT-V01     TO WS-SAVE-HEIGHT
013578*                    MOVE L0520-IMPERIAL-FEET      TO WS-N-9
013578*                    MOVE L0520-IMPERIAL-INCHES    TO WS-N-99
013578*                    MOVE WS-N-99                  TO WS-PIC-99
013578*                    IF (MIR-DV-CLI-FT-HT = SPACES   OR
013578*                        MIR-DV-CLI-FT-HT
013578*                                       = EBLCH-BLANK-FIELD-CHAR)
013578*                    AND (MIR-DV-CLI-INCH-HT = SPACES   OR
013578*                        MIR-DV-CLI-INCH-HT
013578*                                       = EBLCH-BLANK-FIELD-CHAR)
013578*                        OR NOT WS-IMPERIAL-OK
013578*                        MOVE WS-N-9          TO MIR-DV-CLI-FT-HT
013578*                        MOVE WS-PIC-99       TO MIR-
013578*                        DV-CLI-INCH-HT
013578*                        GO TO 5100-EDIT-HEIGHT-X
013578*                    ELSE
013578*                        MOVE WS-N-9          TO MIR-DV-CLI-FT-HT
013578*                        MOVE WS-PIC-99       TO MIR-
013578*                        DV-CLI-INCH-HT
013578*                        MOVE 'NS05400016'   TO WGLOB-MSG-REF-INFO
013578*                        PERFORM 0260-1000-GENERATE-MESSAGE
013578*                           THRU 0260-1000-GENERATE-MESSAGE-X
013578*                        GO TO 5100-EDIT-HEIGHT-X
013578*                    END-IF
013578*                END-IF
013578*            END-IF
013578*        ELSE
013578*            MOVE 'NS05400009'    TO WGLOB-MSG-REF-INFO
013578*            PERFORM 0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            MOVE '1'              TO WS-EDIT-OK-SW
013578*            GO TO 5100-EDIT-HEIGHT-X
013578*        END-IF
013578*      END-IF
013578*    END-IF.
013578*
013578*
013578****   IF IMPERIAL MAY HAVE TO GET IN/FT IF ONLY ONE ENTERED;
013578****   STORE IMPERIAL; CONVERT IMPERIAL TO METRIC AND DISPLAY
013578*
013578*    IF SCALE-IMPERIAL
013578*         IF  MIR-DV-CLI-FT-HT NOT = SPACES
013578*         AND MIR-DV-CLI-INCH-HT NOT = SPACES
013578*            PERFORM  5150-CHECK-FEET
013578*                THRU 5150-CHECK-FEET-X
013578*        END-IF
013578*        IF (MIR-DV-CLI-FT-HT = SPACES OR
013578*            MIR-DV-CLI-INCH-HT = SPACES)   AND
013578*           WS-BOTH-ENTERED
013578*        OR ((MIR-DV-CLI-FT-HT = SPACES OR
013578*             MIR-DV-CLI-INCH-HT = SPACES)  AND
013578*            WS-IMPERIAL-ENTERED)
013578*           PERFORM  5105-GET-IMPERIAL
013578*               THRU 5105-GET-IMPERIAL-X
013578*           PERFORM  5150-CHECK-FEET
013578*               THRU 5150-CHECK-FEET-X
013578*        END-IF
013578*        IF  NOT WS-METRIC-ENTERED
013578*        AND WGLOB-MSG-ERROR-SW  = 0
013578*            SET WS-IMPERIAL-OK TO TRUE
013578*            PERFORM  0520-4000-FEET-TO-IN
013578*                THRU 0520-4000-FEET-TO-IN-X
013578*            MOVE L0520-IMPERIAL-INCHES  TO L0280-INPUT-DATA
013578*            PERFORM  5125-CONVERT-TO-DECIMAL
013578*                THRU 5125-CONVERT-TO-DECIMAL-X
013578*            MOVE L0280-OUTPUT-V01       TO WS-SAVE-HEIGHT
013578*            PERFORM  0520-3000-IN-TO-FEET
013578*                THRU 0520-3000-IN-TO-FEET-X
013578*            PERFORM  0520-1000-FEET-TO-CM
013578*                THRU 0520-1000-FEET-TO-CM-X
013578*            MOVE L0520-METRIC-HEIGHT    TO WS-N-999V9
013578*            MOVE WS-N-999V9             TO WS-PIC-999V9
013578*            MOVE WS-PIC-999V9        TO MIR-DV-CLI-CM-HT
013578*            MOVE L0520-IMPERIAL-FEET    TO WS-N-9
013578*            MOVE WS-N-9              TO MIR-DV-CLI-FT-HT
013578*            MOVE L0520-IMPERIAL-INCHES  TO WS-N-99
013578*            MOVE WS-N-99                TO WS-PIC-99
013578*            MOVE WS-PIC-99           TO MIR-DV-CLI-INCH-HT
013578*        END-IF
013578*    END-IF.
013578*
013578*        IF WS-IMPERIAL-ENTERED
013578*            GO TO 5100-EDIT-HEIGHT-X
013578*        END-IF.
013578*
013578****   IF IMPERIAL AND METRIC ENTERED
013578****   CONVERT METRIC TO IMPERIAL AND STORE/DISPLAY
013578*
013578*
013578*    IF SCALE-IMPERIAL
013578*        IF  MIR-DV-CLI-CM-HT NOT = SPACES
013578*           MOVE 'N'          TO L0280-SIGN-IND
013578*           MOVE 1            TO L0280-PRECISION
013578*           MOVE 3            TO L0280-LENGTH
013578*           MOVE 5            TO L0280-INPUT-SIZE
013578*           MOVE MIR-DV-CLI-CM-HT TO L0280-INPUT-DATA
013578*           PERFORM  7800-NUMERIC-EDIT
013578*               THRU 7800-NUMERIC-EDIT-X
013578*           IF L0280-OK
013578*               SET WS-METRIC-OK     TO TRUE
013578*               IF WS-BOTH-ENTERED
013578*                    NEXT SENTENCE
013578*               ELSE
013578*                    MOVE L0280-OUTPUT-V01 TO L0520-METRIC-HEIGHT
013578*                    MOVE L0520-METRIC-HEIGHT   TO WS-N-999V9
013578*                    MOVE WS-N-999V9        TO WS-PIC-999V9
013578*                    MOVE WS-PIC-999V9      TO MIR-DV-CLI-CM-HT
013578*                    PERFORM   0520-2000-CM-TO-FEET
013578*                        THRU  0520-2000-CM-TO-FEET-X
013578*                    IF L0520-RETRN-FAILED
013578*                        MOVE 'NS05400023' TO WGLOB-MSG-REF-INFO
013578*                        PERFORM  0260-1000-GENERATE-MESSAGE
013578*                            THRU 0260-1000-GENERATE-MESSAGE-X
013578*                        MOVE '1'             TO WS-EDIT-OK-SW
013578*                        GO TO 5100-EDIT-HEIGHT-X
013578*                    ELSE
013578*                        MOVE L0520-IMPERIAL-FEET      TO WS-N-9
013578*                        MOVE L0520-IMPERIAL-INCHES    TO WS-N-99
013578*                        MOVE WS-N-99                TO WS-PIC-99
013578*                        MOVE WS-N-9          TO MIR-DV-CLI-FT-HT
013578*                        MOVE WS-PIC-99       TO MIR-
013578*                        DV-CLI-INCH-HT
013578*                        PERFORM  0520-4000-FEET-TO-IN
013578*                            THRU 0520-4000-FEET-TO-IN-X
013578*                        MOVE L0520-IMPERIAL-INCHES
013578*                                             TO L0280-INPUT-DATA
013578*                        PERFORM  5125-CONVERT-TO-DECIMAL
013578*                            THRU 5125-CONVERT-TO-DECIMAL-X
013578*                        MOVE L0280-OUTPUT-V01  TO WS-SAVE-HEIGHT
013578*                    END-IF
013578*                END-IF
013578*           ELSE
013578*               IF WS-METRIC-ENTERED
013578*                   MOVE 'NS05400009' TO WGLOB-MSG-REF-INFO
013578*                   PERFORM  0260-1000-GENERATE-MESSAGE
013578*                       THRU 0260-1000-GENERATE-MESSAGE-X
013578*                   MOVE '1'               TO WS-EDIT-OK-SW
013578*               END-IF
013578*           END-IF
013578*       END-IF
013578*    END-IF.
013578*
013578*    IF WS-BOTH-ENTERED
013578*    AND WS-IMPERIAL-OK
013578*    AND WS-METRIC-OK
013578*        MOVE 'NS05400016' TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    END-IF.
013578*
013578*    IF SCALE-IMPERIAL
013578*        IF WS-METRIC-ENTERED
013578*            IF WS-METRIC-OK
013578*            MOVE 'NS05400001'    TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            END-IF
013578*        END-IF
013578*    END-IF.
      *
       5100-EDIT-HEIGHT-X.
           EXIT.
      *
      *------------------
013578*5105-GET-IMPERIAL.
      *------------------
013578*    IF SCALE-METRIC
013578*        MOVE L2437-CLI-HT         TO L0520-METRIC-HEIGHT
013578*        PERFORM  0520-2000-CM-TO-FEET
013578*            THRU 0520-2000-CM-TO-FEET-X
013578*    END-IF.
013578*
013578*    IF SCALE-IMPERIAL
013578*        MOVE L2437-CLI-HT         TO L0520-IMPERIAL-INCHES
013578*        PERFORM  0520-3000-IN-TO-FEET
013578*            THRU 0520-3000-IN-TO-FEET-X
013578*    END-IF.
013578*
013578*    IF MIR-DV-CLI-FT-HT = SPACES
013578*        MOVE L0520-IMPERIAL-FEET    TO WS-PIC-9
013578*        MOVE WS-PIC-9               TO MIR-DV-CLI-FT-HT
013578*    ELSE
013578*        IF MIR-DV-CLI-INCH-HT = SPACES
013578*            MOVE L0520-IMPERIAL-INCHES  TO WS-N-99
013578*            MOVE WS-N-99                TO WS-PIC-99
013578*            MOVE WS-PIC-99           TO MIR-DV-CLI-INCH-HT
013578*        END-IF
013578*    END-IF.
      *
013578*5105-GET-IMPERIAL-X.
013578*    EXIT.
      *
      *------------------------
       5125-CONVERT-TO-DECIMAL.
      *------------------------
           MOVE 'N'          TO L0280-SIGN-IND.
           MOVE 1            TO L0280-PRECISION.
           MOVE 3            TO L0280-LENGTH.
           MOVE 3            TO L0280-INPUT-SIZE.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

       5125-CONVERT-TO-DECIMAL-X.
           EXIT.
      *
      *----------------
013578*5150-CHECK-FEET.
013578*----------------
013578*    MOVE MIR-DV-CLI-FT-HT    TO WS-TEST-FEET.
013578*
013578*    IF NOT WS-FEET-OK
013578*        IF  WS-IMPERIAL-ENTERED
013578*        OR (SCALE-IMPERIAL
013578*        AND WS-BOTH-ENTERED)
013578*            MOVE 'NS05400010'    TO WGLOB-MSG-REF-INFO
013578*            PERFORM 0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            MOVE L2437-CLI-HT          TO WS-SAVE-HEIGHT
013578*            MOVE '1'              TO WS-EDIT-OK-SW
013578*        ELSE
013578*            IF (SCALE-METRIC
013578*            AND WS-BOTH-ENTERED)
013578*                MOVE 1            TO WGLOB-MSG-ERROR-SW
013578*                GO TO 5150-CHECK-FEET-X
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*    MOVE 'N'          TO L0280-SIGN-IND.
013578*    MOVE 0            TO L0280-PRECISION.
013578*    MOVE 2            TO L0280-LENGTH.
013578*    MOVE 2            TO L0280-INPUT-SIZE.
013578*    MOVE MIR-DV-CLI-INCH-HT    TO L0280-INPUT-DATA.
013578*    PERFORM  7800-NUMERIC-EDIT
013578*        THRU 7800-NUMERIC-EDIT-X.
013578*
013578*    IF L0280-OK
013578*        IF L0280-OUTPUT GREATER 11
013578*             MOVE 'NS05400012'    TO WGLOB-MSG-REF-INFO
013578*             PERFORM 0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*             MOVE L2437-CLI-HT          TO WS-SAVE-HEIGHT
013578*             MOVE '1'              TO WS-EDIT-OK-SW
013578*             GO TO 5150-CHECK-FEET-X
013578*        ELSE
013578*            NEXT SENTENCE
013578*        END-IF
013578*    ELSE
013578*        IF (SCALE-METRIC
013578*        AND WS-BOTH-ENTERED)
013578*            GO TO 5150-CHECK-FEET-X
013578*        ELSE
013578*            MOVE 'NS05400011'    TO WGLOB-MSG-REF-INFO
013578*            PERFORM 0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            MOVE L2437-CLI-HT          TO WS-SAVE-HEIGHT
013578*            MOVE '1'          TO WS-EDIT-OK-SW
013578*            GO TO 5150-CHECK-FEET-X
013578*        END-IF
013578*    END-IF.
013578*
013578*    SET WS-IMPERIAL-OK                TO TRUE.
013578*    IF WS-FEET-OK
013578*        MOVE L0280-OUTPUT             TO L0520-IMPERIAL-INCHES
013578*        MOVE L0280-OUTPUT             TO WS-PIC-99
013578*        MOVE WS-PIC-99                TO MIR-DV-CLI-INCH-HT
013578*        MOVE MIR-DV-CLI-FT-HT         TO L0520-IMPERIAL-FEET
013578*        IF WS-BOTH-ENTERED
013578*            GO TO 5150-CHECK-FEET-X
013578*        ELSE
013578*            PERFORM  0520-1000-FEET-TO-CM
013578*                THRU 0520-1000-FEET-TO-CM-X
013578*            MOVE L0520-METRIC-HEIGHT      TO WS-N-999V9
013578*            MOVE WS-N-999V9               TO WS-PIC-999V9
013578*            MOVE WS-PIC-999V9          TO MIR-DV-CLI-CM-HT
013578*            IF SCALE-METRIC
013578*                MOVE L0520-METRIC-HEIGHT      TO WS-SAVE-HEIGHT
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*5150-CHECK-FEET-X.
013578*    EXIT.
      *
      *****************************************************************
      *  CLIENT WEIGHT: MUST BE NUMERIC - METRIC TAKES PRECEDENCE
      *****************************************************************
      *-----------------
       5200-EDIT-WEIGHT.
      *-----------------
013578     MOVE WS-CLI-WGT-LB TO WS-MIR-WEIGHT-LB.
013578     MOVE WS-CLI-WGT-KG TO WS-MIR-WEIGHT-KG.

013578     IF MIR-DV-CLI-KG-WGT > SPACES
013578         MOVE 'N'                      TO L0280-SIGN-IND
013578         MOVE 1                        TO L0280-PRECISION
013578         MOVE 3                        TO L0280-LENGTH
013578         MOVE 5                        TO L0280-INPUT-SIZE
013578         MOVE MIR-DV-CLI-KG-WGT        TO L0280-INPUT-DATA
013578         PERFORM  7800-NUMERIC-EDIT
013578             THRU 7800-NUMERIC-EDIT-X
013578         IF L0280-OK
013578             MOVE L0280-OUTPUT-V01     TO WS-MIR-WEIGHT-KG
013578         ELSE
013578*MSG: WEIGHT IN KILOGRAMS MUST BE NUMERIC IN THE FORM 999.9
013578             MOVE 'NS05400013'         TO  WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578         END-IF
013578     END-IF.

018763     IF WS-MIR-WEIGHT-KG > 453.1
018763         MOVE WS-CLI-WGT-KG   TO WS-MIR-WEIGHT-KG
018763*MSG: WEIGHT MUST BE LESS THAN 453.1KG
018763         MOVE 'NS05400038'    TO WGLOB-MSG-REF-INFO
018763         PERFORM  0260-1000-GENERATE-MESSAGE
018763             THRU 0260-1000-GENERATE-MESSAGE-X
018763     END-IF.

013578     IF MIR-DV-CLI-LB-WGT > SPACES
013578         MOVE 'N'                      TO L0280-SIGN-IND
013578         MOVE 0                        TO L0280-PRECISION
013578         MOVE 3                        TO L0280-LENGTH
013578         MOVE 3                        TO L0280-INPUT-SIZE
013578         MOVE MIR-DV-CLI-LB-WGT        TO L0280-INPUT-DATA
013578         PERFORM  7800-NUMERIC-EDIT
013578             THRU 7800-NUMERIC-EDIT-X
013578         IF L0280-OK
013578             MOVE L0280-OUTPUT-V00     TO WS-MIR-WEIGHT-LB
013578         ELSE
013578*MSG: WEIGHT IN POUNDS MUST BE NUMERIC IN THE FORM 999
013578             MOVE 'NS05400014'         TO  WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578         END-IF
013578     END-IF.

013578     SET WS-NONE-ENTERED        TO TRUE.

013578     EVALUATE TRUE

013578         WHEN WS-MIR-WEIGHT-KG NOT = WS-CLI-WGT-KG
013578             IF WS-MIR-WEIGHT-LB     NOT = WS-CLI-WGT-LB
013578                 SET WS-BOTH-ENTERED TO TRUE
013578             ELSE
013578                 SET WS-METRIC-ENTERED TO TRUE
013578             END-IF

013578         WHEN OTHER
013578             IF WS-MIR-WEIGHT-LB     NOT = WS-CLI-WGT-LB
013578                 SET WS-IMPERIAL-ENTERED TO TRUE
013578             END-IF

013578     END-EVALUATE.

013578     IF WS-METRIC-ENTERED
019435     OR WS-BOTH-ENTERED
013578         MOVE WS-MIR-WEIGHT-KG      TO WS-CLI-WGT-KG
013578         MOVE WS-MIR-WEIGHT-KG      TO L0530-METRIC-WEIGHT
013578         PERFORM  0530-2000-KG-TO-LBS
013578             THRU 0530-2000-KG-TO-LBS-X
013578         MOVE L0530-IMPERIAL-WEIGHT TO WS-CLI-WGT-LB
019435         IF WS-BOTH-ENTERED
019435             MOVE 'NS05400039'      TO  WGLOB-MSG-REF-INFO
019435             PERFORM  0260-1000-GENERATE-MESSAGE
019435                 THRU 0260-1000-GENERATE-MESSAGE-X
019435         END-IF
019435*    END-IF.
019435     ELSE
013578         IF WS-IMPERIAL-ENTERED
013578             MOVE WS-MIR-WEIGHT-LB     TO WS-CLI-WGT-LB
013578             MOVE WS-MIR-WEIGHT-LB     TO L0530-IMPERIAL-WEIGHT
013578             PERFORM  0530-1000-LBS-TO-KG
013578                 THRU 0530-1000-LBS-TO-KG-X
013578             MOVE L0530-METRIC-WEIGHT  TO WS-CLI-WGT-KG
019435         END-IF
013578     END-IF.

013578     IF SCALE-METRIC
013578         MOVE WS-CLI-WGT-KG          TO WS-SAVE-WEIGHT
013578     ELSE
013578         MOVE WS-CLI-WGT-LB          TO WS-SAVE-WEIGHT
013578     END-IF.

013578*  REDISPLAY ON MIR

013578     MOVE WS-CLI-WGT-KG   TO WS-PIC-999V9.
013578     MOVE WS-PIC-999V9    TO MIR-DV-CLI-KG-WGT
013578     MOVE WS-CLI-WGT-LB   TO WS-N-999.
013578     MOVE WS-N-999        TO MIR-DV-CLI-LB-WGT.

013578     GO TO 5200-EDIT-WEIGHT-X.

013578*    MOVE L2437-CLI-WGT            TO WS-SAVE-WEIGHT.
013578*    MOVE SPACES                   TO WS-VALUES-ENTERED-CD.
013578*    SET WS-METRIC-OK-NO           TO TRUE.
013578*    SET WS-IMPERIAL-OK-NO         TO TRUE.
013578*
013578*    IF MIR-DV-CLI-KG-WGT = EBLCH-BLANK-FIELD-CHAR
013578*    OR MIR-DV-CLI-LB-WGT = EBLCH-BLANK-FIELD-CHAR
013578*        MOVE ZERO          TO WS-PIC-999V9
013578*        MOVE ZERO          TO WS-SAVE-WEIGHT
013578*        MOVE WS-PIC-999V9  TO MIR-DV-CLI-KG-WGT
013578*        MOVE ZERO          TO WS-N-999
013578*        MOVE WS-N-999      TO WS-PIC-999
013578*        MOVE WS-PIC-999    TO MIR-DV-CLI-LB-WGT
013578*        GO TO 5200-EDIT-WEIGHT-X
013578*    END-IF.
013578*
013578*    IF MIR-DV-CLI-KG-WGT > SPACES
013578*    AND MIR-DV-CLI-LB-WGT = SPACES
013578*        MOVE 'M'  TO WS-VALUES-ENTERED-CD
013578*    END-IF.
013578*
013578*    IF MIR-DV-CLI-KG-WGT = SPACES
013578*    AND MIR-DV-CLI-LB-WGT > SPACES
013578*        MOVE 'I'  TO WS-VALUES-ENTERED-CD
013578*    END-IF.
013578*
013578*    IF   MIR-DV-CLI-KG-WGT > SPACES
013578*    AND  MIR-DV-CLI-LB-WGT > SPACES
013578*        MOVE 'B' TO WS-VALUES-ENTERED-CD
013578*    END-IF.
013578*
013578*
013578*  IF NO DATA WAS ENTERED ASUME VALUE IN RCLI AND CONVERT
013578*
013578*    IF (MIR-DV-CLI-KG-WGT = SPACES
013578*    AND MIR-DV-CLI-LB-WGT = SPACES)
013578*       IF SCALE-METRIC
013578*          MOVE L2437-CLI-WGT          TO WS-N-999V9
013578*          MOVE L2437-CLI-WGT          TO WS-SAVE-WEIGHT
013578*          MOVE WS-N-999V9             TO WS-PIC-999V9
013578*          MOVE WS-PIC-999V9           TO MIR-DV-CLI-KG-WGT
013578*          MOVE L2437-CLI-WGT          TO L0530-METRIC-WEIGHT
013578*          PERFORM  0530-2000-KG-TO-LBS
013578*              THRU 0530-2000-KG-TO-LBS-X
013578*          MOVE L0530-IMPERIAL-WEIGHT  TO WS-N-999
013578*          MOVE WS-N-999               TO WS-PIC-999
013578*          MOVE WS-PIC-999             TO MIR-DV-CLI-LB-WGT
013578*          GO TO 5200-EDIT-WEIGHT-X
013578*       ELSE
013578*          MOVE L2437-CLI-WGT          TO WS-N-999
013578*          MOVE L2437-CLI-WGT          TO WS-SAVE-WEIGHT
013578*          MOVE WS-N-999               TO WS-PIC-999
013578*          MOVE WS-PIC-999             TO MIR-DV-CLI-LB-WGT
013578*          MOVE WS-N-999               TO L0530-IMPERIAL-WEIGHT
013578*          PERFORM  0530-1000-LBS-TO-KG
013578*              THRU 0530-1000-LBS-TO-KG-X
013578*          MOVE L0530-METRIC-WEIGHT    TO WS-N-999V9
013578*          MOVE WS-N-999V9             TO WS-PIC-999V9
013578*          MOVE WS-PIC-999V9           TO MIR-DV-CLI-KG-WGT
013578*          GO TO 5200-EDIT-WEIGHT-X
013578*       END-IF
013578*    END-IF.
013578*
013578*  IF SCALE-METRIC AND KILOS ENTERED SAVE KILOS,
013578*  IF SCALE-METRIC AND POUNDS ENTERED CONVERT TO KILOS,
013578*
013578*    IF SCALE-METRIC
013578*        IF WS-IMPERIAL-ENTERED
013578*        OR WS-BOTH-ENTERED
013578*            PERFORM  5250-CHECK-LBS
013578*                THRU 5250-CHECK-LBS-X
013578*            IF WGLOB-MSG-ERROR-SW NOT > 0
013578*                IF WS-IMPERIAL-ENTERED
013578*                MOVE 'NS05400002'  TO WGLOB-MSG-REF-INFO
013578*                PERFORM  0260-1000-GENERATE-MESSAGE
013578*                    THRU 0260-1000-GENERATE-MESSAGE-X
013578*                END-IF
013578*            END-IF
013578*            IF WGLOB-MSG-ERROR-SW NOT > 0
013578*                SET WS-IMPERIAL-OK TO TRUE
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*    IF SCALE-METRIC
013578*        IF WS-METRIC-ENTERED
013578*        OR WS-BOTH-ENTERED
013578*            MOVE 'N'                      TO L0280-SIGN-IND
013578*            MOVE 1                        TO L0280-PRECISION
013578*            MOVE 3                        TO L0280-LENGTH
013578*            MOVE 5                        TO L0280-INPUT-SIZE
013578*            MOVE MIR-DV-CLI-KG-WGT        TO L0280-INPUT-DATA
013578*            PERFORM  7800-NUMERIC-EDIT
013578*                THRU 7800-NUMERIC-EDIT-X
013578*            IF L0280-OK
013578*                MOVE L0280-OUTPUT-V01     TO WS-N-999V9
013578*                MOVE WS-N-999V9           TO WS-PIC-999V9
013578*                MOVE WS-PIC-999V9         TO MIR-DV-CLI-KG-WGT
013578*                MOVE L0280-OUTPUT-V01
013578*                  TO L0530-METRIC-WEIGHT
013578*                PERFORM  0530-2000-KG-TO-LBS
013578*                    THRU 0530-2000-KG-TO-LBS-X
013578*                IF L0530-RETRN-FAILED
013578*                    MOVE 'NS05400024'   TO WGLOB-MSG-REF-INFO
013578*                    PERFORM  0260-1000-GENERATE-MESSAGE
013578*                        THRU 0260-1000-GENERATE-MESSAGE-X
013578*                    MOVE L2437-CLI-WGT  TO L0530-METRIC-WEIGHT
013578*                    PERFORM  0530-2000-KG-TO-LBS
013578*                        THRU 0530-2000-KG-TO-LBS-X
013578*                    MOVE L0530-IMPERIAL-WEIGHT TO WS-N-999
013578*                    MOVE WS-N-999         TO WS-PIC-999
013578*                    MOVE WS-PIC-999       TO MIR-DV-CLI-LB-WGT
013578*                    MOVE '1'             TO WS-EDIT-OK-SW
013578*                ELSE
013578*                    MOVE L0280-OUTPUT-V01     TO WS-SAVE-WEIGHT
013578*                    MOVE L0530-IMPERIAL-WEIGHT TO WS-N-999
013578*                    MOVE WS-N-999              TO WS-PIC-999
013578*                    MOVE WS-PIC-999      TO MIR-DV-CLI-LB-WGT
013578*                    SET WS-METRIC-OK     TO TRUE
013578*                END-IF
013578*            ELSE
013578*                MOVE 'NS05400013'    TO WGLOB-MSG-REF-INFO
013578*                PERFORM 0260-1000-GENERATE-MESSAGE
013578*                    THRU 0260-1000-GENERATE-MESSAGE-X
013578*                MOVE L2437-CLI-WGT       TO WS-SAVE-WEIGHT
013578*                MOVE '1'              TO WS-EDIT-OK-SW
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*    IF (SCALE-METRIC
013578*        AND WS-BOTH-ENTERED)
013578*        IF (WS-METRIC-OK
013578*            AND WS-IMPERIAL-OK)
013578*            MOVE 'NS05400015'       TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            GO TO 5200-EDIT-WEIGHT-X
013578*        ELSE
013578*            GO TO 5200-EDIT-WEIGHT-X
013578*        END-IF
013578*    END-IF.
013578*
013578*
013578*  IF SCALE-IMPERIAL AND POUNDS ENTERED SAVE POUNDS,
013578*  IF SCALE-IMPERIAL AND KILOS ENTERED CONVERT TO POUNDS
013578*
013578*    IF SCALE-IMPERIAL
013578*        IF WS-IMPERIAL-ENTERED
013578*        OR WS-BOTH-ENTERED
013578*            PERFORM  5250-CHECK-LBS
013578*                THRU 5250-CHECK-LBS-X
013578*            IF WGLOB-MSG-ERROR-SW > ZERO
013578*                GO TO 5200-EDIT-WEIGHT-X
013578*            ELSE
013578*                MOVE L0530-IMPERIAL-WEIGHT  TO WS-N-999
013578*                MOVE WS-N-999               TO WS-PIC-999
013578*                MOVE WS-PIC-999             TO MIR-DV-CLI-LB-WGT
013578*                MOVE L0530-IMPERIAL-WEIGHT  TO L0280-INPUT-DATA
013578*                PERFORM  5125-CONVERT-TO-DECIMAL
013578*                    THRU 5125-CONVERT-TO-DECIMAL-X
013578*                MOVE L0280-OUTPUT-V01         TO WS-SAVE-WEIGHT
013578*                IF WS-IMPERIAL-ENTERED
013578*                    GO TO 5200-EDIT-WEIGHT-X
013578*                END-IF
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*    IF SCALE-IMPERIAL
013578*        IF WS-BOTH-ENTERED
013578*        OR WS-METRIC-ENTERED
013578*            MOVE 'N'                      TO L0280-SIGN-IND
013578*            MOVE 1                        TO L0280-PRECISION
013578*            MOVE 3                        TO L0280-LENGTH
013578*            MOVE 5                        TO L0280-INPUT-SIZE
013578*            MOVE MIR-DV-CLI-KG-WGT        TO L0280-INPUT-DATA
013578*            PERFORM  7800-NUMERIC-EDIT
013578*                THRU 7800-NUMERIC-EDIT-X
013578*            IF L0280-OK
013578*                SET WS-METRIC-OK          TO TRUE
013578*                IF WS-BOTH-ENTERED
013578*                    NEXT SENTENCE
013578*                ELSE
013578*                    MOVE 'NS05400002'   TO WGLOB-MSG-REF-INFO
013578*                    PERFORM  0260-1000-GENERATE-MESSAGE
013578*                        THRU 0260-1000-GENERATE-MESSAGE-X
013578*                    MOVE L0280-OUTPUT-V01  TO WS-N-999V9
013578*                    MOVE WS-N-999V9        TO WS-PIC-999V9
013578*                    MOVE WS-PIC-999V9      TO MIR-DV-CLI-KG-WGT
013578*                    MOVE L0280-OUTPUT-V01  TO L0530-METRIC-WEIGHT
013578*                    PERFORM  0530-2000-KG-TO-LBS
013578*                        THRU 0530-2000-KG-TO-LBS-X
013578*                    IF L0530-RETRN-FAILED
013578*                        MOVE 'NS05400024' TO WGLOB-MSG-REF-INFO
013578*                        PERFORM  0260-1000-GENERATE-MESSAGE
013578*                            THRU 0260-1000-GENERATE-MESSAGE-X
013578*                        MOVE '1'             TO WS-EDIT-OK-SW
013578*                        MOVE L2437-CLI-WGT   TO WS-PIC-999
013578*                        MOVE WS-PIC-999      TO MIR-DV-CLI-LB-WGT
013578*                        GO TO 5200-EDIT-WEIGHT-X
013578*                    ELSE
013578*                        MOVE L0530-IMPERIAL-WEIGHT  TO WS-N-999
013578*                        MOVE WS-N-999        TO WS-PIC-999
013578*                        MOVE WS-PIC-999      TO MIR-DV-CLI-LB-WGT
013578*                        MOVE L0530-IMPERIAL-WEIGHT
013578*                                             TO L0280-INPUT-DATA
013578*                        PERFORM  5125-CONVERT-TO-DECIMAL
013578*                            THRU 5125-CONVERT-TO-DECIMAL-X
013578*                        MOVE L0280-OUTPUT-V01  TO WS-SAVE-WEIGHT
013578*                    END-IF
013578*                END-IF
013578*            ELSE
013578*                IF WS-METRIC-ENTERED
013578*                    MOVE 'NS05400013'   TO WGLOB-MSG-REF-INFO
013578*                    PERFORM  0260-1000-GENERATE-MESSAGE
013578*                        THRU 0260-1000-GENERATE-MESSAGE-X
013578*                    MOVE L2437-CLI-WGT    TO WS-SAVE-WEIGHT
013578*                    MOVE '1'              TO WS-EDIT-OK-SW
013578*                ELSE
013578*                    IF WS-BOTH-ENTERED
013578*                        PERFORM  0530-1000-LBS-TO-KG
013578*                            THRU 0530-1000-LBS-TO-KG-X
013578*                        MOVE L0530-METRIC-WEIGHT  TO WS-N-999V9
013578*                        MOVE WS-N-999V9           TO WS-PIC-999V9
013578*                        MOVE WS-PIC-999V9    TO MIR-DV-CLI-KG-WGT
013578*                        GO TO 5200-EDIT-WEIGHT-X
013578*                    END-IF
013578*                END-IF
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*    IF WS-BOTH-ENTERED
013578*        IF WS-IMPERIAL-OK
013578*        AND WS-METRIC-OK
013578*            MOVE 'NS05400015'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*        END-IF
013578*    END-IF.
013578*
       5200-EDIT-WEIGHT-X.
           EXIT.
      *
      *---------------
013578*5250-CHECK-LBS.
013578*---------------
013578*    MOVE 'N'          TO L0280-SIGN-IND.
013578*    MOVE 0            TO L0280-PRECISION.
013578*    MOVE 3            TO L0280-LENGTH.
013578*    MOVE 3            TO L0280-INPUT-SIZE.
013578*    MOVE MIR-DV-CLI-LB-WGT  TO L0280-INPUT-DATA.
013578*    PERFORM  7800-NUMERIC-EDIT
013578*        THRU 7800-NUMERIC-EDIT-X.
013578*
013578*    IF L0280-OK
013578*        NEXT SENTENCE
013578*    ELSE
013578*        IF (SCALE-METRIC
013578*        AND WS-IMPERIAL-ENTERED)
013578*        OR (SCALE-IMPERIAL
013578*        AND NOT WS-METRIC-ENTERED)
013578*            MOVE 'NS05400014'    TO WGLOB-MSG-REF-INFO
013578*            PERFORM 0260-1000-GENERATE-MESSAGE
013578*               THRU 0260-1000-GENERATE-MESSAGE-X
013578*            MOVE L2437-CLI-WGT       TO WS-SAVE-WEIGHT
013578*            MOVE '1'              TO WS-EDIT-OK-SW
013578*            GO TO 5250-CHECK-LBS-X
013578*        ELSE
013578*            MOVE 1                TO WGLOB-MSG-ERROR-SW
013578*            GO TO 5250-CHECK-LBS-X
013578*        END-IF
013578*    END-IF.
013578*
013578*    SET WS-IMPERIAL-OK            TO TRUE.
013578*    MOVE L0280-OUTPUT             TO L0530-IMPERIAL-WEIGHT.
013578*    MOVE L0530-IMPERIAL-WEIGHT    TO WS-N-999
013578*    MOVE WS-N-999                 TO WS-PIC-999
013578*    MOVE WS-PIC-999               TO MIR-DV-CLI-LB-WGT
013578*    IF SCALE-METRIC
013578*    AND WS-BOTH-ENTERED
013578*        GO TO 5250-CHECK-LBS-X
013578*    ELSE
013578*        PERFORM  0530-1000-LBS-TO-KG
013578*            THRU 0530-1000-LBS-TO-KG-X
013578*        MOVE L0530-METRIC-WEIGHT      TO WS-N-999V9
013578*        MOVE WS-N-999V9               TO WS-PIC-999V9
013578*    END-IF.
013578*    IF SCALE-METRIC
013578*        MOVE L0530-METRIC-WEIGHT  TO WS-SAVE-WEIGHT
013578*    END-IF.
013578*    MOVE WS-PIC-999V9             TO MIR-DV-CLI-KG-WGT.
013578*
013578*5250-CHECK-LBS-X.
013578*    EXIT.
      *****************************************************************
      *  EDIT GAIN-OR-LOSS INDICATOR
      *****************************************************************
       5300-EDIT-GLIND.
      *
           IF MIR-WGT-GAIN-LOS-CD  = SPACES
557659*        MOVE RAPPF-WGT-GAIN-LOS-IND  TO MIR-WGT-GAIN-LOS-CD
557659         MOVE RAPPF-WGT-GAIN-LOS-CD   TO MIR-WGT-GAIN-LOS-CD
               GO TO 5300-EDIT-GLIND-X
557660     END-IF.
      *
           IF MIR-WGT-GAIN-LOS-CD  = EBLCH-BLANK-FIELD-CHAR
               MOVE '+'           TO MIR-WGT-GAIN-LOS-CD
557660     END-IF.
      *
           MOVE MIR-WGT-GAIN-LOS-CD         TO WS-TEST-GLIND.
      *
           IF WS-GLIND-OK
557659*        MOVE MIR-WGT-GAIN-LOS-CD     TO RAPPF-WGT-GAIN-LOS-IND
557659         MOVE MIR-WGT-GAIN-LOS-CD     TO RAPPF-WGT-GAIN-LOS-CD
           ELSE
               MOVE 'NS05400004'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.
      *
           IF WS-GLIND-OK
               IF  MIR-DV-CLI-WGT-CHNG-LB-QTY = SPACES
557660         AND MIR-DV-CLI-WGT-CHNG-KG-QTY = SPACES
                    MOVE 'NS05400020'     TO WGLOB-MSG-REF-INFO
                    PERFORM 0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    MOVE '1'       TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5300-EDIT-GLIND-X.
           EXIT.
      ****************************************
      *  CLIENT WEIGHT CHG: MUST BE NUMERIC
      *  RESTRUCTURED FOR 5.3
      *****************************************
       5400-EDIT-WGTCH.
      *
           MOVE SPACES            TO WS-VALUES-ENTERED-CD.
           SET WS-METRIC-OK-NO    TO TRUE.
           SET WS-IMPERIAL-OK-NO  TO TRUE.
      *
           IF MIR-DV-CLI-WGT-CHNG-KG-QTY = EBLCH-BLANK-FIELD-CHAR
           OR MIR-DV-CLI-WGT-CHNG-LB-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO          TO WS-PIC-999V9
               MOVE ZERO          TO WS-N-999V9
               MOVE WS-N-999V9    TO RAPPF-CLI-WGT-CHNG-QTY
               MOVE ZERO          TO WS-N-999
               MOVE WS-PIC-999V9  TO MIR-DV-CLI-WGT-CHNG-KG-QTY
               MOVE WS-N-999      TO WS-PIC-999
               MOVE WS-PIC-999    TO MIR-DV-CLI-WGT-CHNG-LB-QTY
               MOVE '+'           TO MIR-WGT-GAIN-LOS-CD
               GO TO 5400-EDIT-WGTCH-X
557660     END-IF.


013578     MOVE WS-CLI-WGT-CHNG-QTY-LB TO WS-MIR-WEIGHT-CHNG-LB.
013578     MOVE WS-CLI-WGT-CHNG-QTY-KG TO WS-MIR-WEIGHT-CHNG-KG.

013578     IF MIR-DV-CLI-WGT-CHNG-KG-QTY > SPACES
013578         MOVE 'N'                   TO L0280-SIGN-IND
013578         MOVE 1                     TO L0280-PRECISION
013578         MOVE 3                     TO L0280-LENGTH
013578         MOVE 5                     TO L0280-INPUT-SIZE
013578         MOVE MIR-DV-CLI-WGT-CHNG-KG-QTY TO L0280-INPUT-DATA
013578         PERFORM  7800-NUMERIC-EDIT
013578             THRU 7800-NUMERIC-EDIT-X
013578         IF L0280-OK
013578             MOVE L0280-OUTPUT-V01  TO WS-MIR-WEIGHT-CHNG-KG
013578         ELSE
013578*MSG: WEIGHT IN KILOGRAMS MUST BE NUMERIC IN THE FORM 999.9
013578             MOVE 'NS05400013'      TO  WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578         END-IF
013578     END-IF.

018763     IF WS-MIR-WEIGHT-CHNG-KG > 453.1
018763         MOVE WS-CLI-WGT-CHNG-QTY-KG TO WS-MIR-WEIGHT-CHNG-KG
018763*MSG: WEIGHT MUST BE LESS THAN 453.1KG
018763         MOVE 'NS05400038'    TO WGLOB-MSG-REF-INFO
018763         PERFORM  0260-1000-GENERATE-MESSAGE
018763             THRU 0260-1000-GENERATE-MESSAGE-X
018763     END-IF.

013578     IF MIR-DV-CLI-WGT-CHNG-LB-QTY > SPACES
013578         MOVE 'N'                   TO L0280-SIGN-IND
013578         MOVE 0                     TO L0280-PRECISION
013578         MOVE 3                     TO L0280-LENGTH
013578         MOVE 3                     TO L0280-INPUT-SIZE
013578         MOVE MIR-DV-CLI-WGT-CHNG-LB-QTY TO L0280-INPUT-DATA
013578         PERFORM  7800-NUMERIC-EDIT
013578             THRU 7800-NUMERIC-EDIT-X
013578         IF L0280-OK
013578             MOVE L0280-OUTPUT-V00  TO WS-MIR-WEIGHT-CHNG-LB
013578         ELSE
013578*MSG: WEIGHT IN POUNDS MUST BE NUMERIC IN THE FORM 999
013578             MOVE 'NS05400014'      TO  WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578         END-IF
013578     END-IF.

013578     SET WS-NONE-ENTERED            TO TRUE.

013578     EVALUATE TRUE

013578         WHEN WS-MIR-WEIGHT-CHNG-KG NOT = WS-CLI-WGT-CHNG-QTY-KG
013578             IF WS-MIR-WEIGHT-CHNG-LB NOT = WS-CLI-WGT-CHNG-QTY-LB
013578                 SET WS-BOTH-ENTERED TO TRUE
013578             ELSE
013578                 SET WS-METRIC-ENTERED TO TRUE
013578             END-IF

013578         WHEN OTHER
013578             IF WS-MIR-WEIGHT-CHNG-LB NOT = WS-CLI-WGT-CHNG-QTY-LB
013578                 SET WS-IMPERIAL-ENTERED TO TRUE
013578             END-IF

013578     END-EVALUATE.

013578     IF WS-METRIC-ENTERED
019435     OR WS-BOTH-ENTERED
013578         MOVE WS-MIR-WEIGHT-CHNG-KG TO WS-CLI-WGT-CHNG-QTY-KG
013578         MOVE WS-MIR-WEIGHT-CHNG-KG TO L0530-METRIC-WEIGHT
013578         PERFORM  0530-2000-KG-TO-LBS
013578             THRU 0530-2000-KG-TO-LBS-X
013578         MOVE L0530-IMPERIAL-WEIGHT TO WS-CLI-WGT-CHNG-QTY-LB
019435         IF WS-BOTH-ENTERED
019435             MOVE 'NS05400039'      TO  WGLOB-MSG-REF-INFO
019435             PERFORM  0260-1000-GENERATE-MESSAGE
019435                 THRU 0260-1000-GENERATE-MESSAGE-X
019435         END-IF
019435*    END-IF.
019435     ELSE
013578         IF WS-IMPERIAL-ENTERED
013578             MOVE WS-MIR-WEIGHT-CHNG-LB TO WS-CLI-WGT-CHNG-QTY-LB
013578             MOVE WS-MIR-WEIGHT-CHNG-LB TO L0530-IMPERIAL-WEIGHT
013578             PERFORM  0530-1000-LBS-TO-KG
013578                 THRU 0530-1000-LBS-TO-KG-X
013578             MOVE L0530-METRIC-WEIGHT   TO WS-CLI-WGT-CHNG-QTY-KG
019435         END-IF
013578     END-IF.

013578     IF SCALE-METRIC
013578         MOVE WS-CLI-WGT-CHNG-QTY-KG    TO RAPPF-CLI-WGT-CHNG-QTY
013578     ELSE
013578         MOVE WS-CLI-WGT-CHNG-QTY-LB    TO RAPPF-CLI-WGT-CHNG-QTY
013578     END-IF.

013578*  REDISPLAY ON MIR

013578     MOVE WS-CLI-WGT-CHNG-QTY-KG    TO WS-PIC-999V9.
013578     MOVE WS-PIC-999V9              TO MIR-DV-CLI-WGT-CHNG-KG-QTY
013578     MOVE WS-CLI-WGT-CHNG-QTY-LB    TO WS-N-999.
013578     MOVE WS-N-999                  TO MIR-DV-CLI-WGT-CHNG-LB-QTY.

013578     GO TO 5400-EDIT-WGTCH-X.

      *
013578*    IF MIR-DV-CLI-WGT-CHNG-KG-QTY > SPACES
013578*    AND MIR-DV-CLI-WGT-CHNG-LB-QTY = SPACES
013578*        MOVE 'M'           TO WS-VALUES-ENTERED-CD
013578*    END-IF.
013578*
013578*    IF MIR-DV-CLI-WGT-CHNG-LB-QTY > SPACES
013578*    AND MIR-DV-CLI-WGT-CHNG-KG-QTY = SPACES
013578*        MOVE 'I'           TO WS-VALUES-ENTERED-CD
013578*    END-IF.
013578*
013578*    IF MIR-DV-CLI-WGT-CHNG-LB-QTY > SPACES
013578*    AND MIR-DV-CLI-WGT-CHNG-KG-QTY > SPACES
013578*        MOVE 'B'           TO WS-VALUES-ENTERED-CD
013578*    END-IF.
013578*
013578*NEITHER VALUE ENTERED ON SCREEN
013578*
013578*    IF  MIR-DV-CLI-WGT-CHNG-KG-QTY = SPACES
013578*        IF MIR-DV-CLI-WGT-CHNG-LB-QTY = SPACES
013578*            IF SCALE-METRIC
013578*                MOVE RAPPF-CLI-WGT-CHNG-QTY   TO WS-N-999V9
013578*                MOVE WS-N-999V9               TO WS-PIC-999V9
013578*                MOVE WS-PIC-999V9  TO MIR-DV-CLI-WGT-CHNG-KG-QTY
013578*                MOVE RAPPF-CLI-WGT-CHNG-QTY
013578*                                           TO L0530-METRIC-WEIGHT
013578*                PERFORM  0530-2000-KG-TO-LBS
013578*                    THRU 0530-2000-KG-TO-LBS-X
013578*                MOVE L0530-IMPERIAL-WEIGHT    TO WS-N-999
013578*                MOVE WS-N-999                 TO WS-PIC-999
013578*                MOVE WS-PIC-999     TO MIR-DV-CLI-WGT-CHNG-LB-QTY
013578*                GO TO 5400-EDIT-WGTCH-X
013578*            ELSE
013578*                MOVE RAPPF-CLI-WGT-CHNG-QTY
013578*                                         TO L0530-IMPERIAL-WEIGHT
013578*                MOVE L0530-IMPERIAL-WEIGHT    TO WS-N-999
013578*                MOVE WS-N-999                 TO WS-PIC-999
013578*                MOVE WS-PIC-999     TO MIR-DV-CLI-WGT-CHNG-LB-QTY
013578*                PERFORM  0530-1000-LBS-TO-KG
013578*                   THRU 0530-1000-LBS-TO-KG-X
013578*                MOVE L0530-METRIC-WEIGHT    TO WS-N-999V9
013578*                MOVE WS-N-999V9               TO WS-PIC-999V9
013578*                MOVE WS-PIC-999V9   TO MIR-DV-CLI-WGT-CHNG-KG-QTY
013578*                GO TO 5400-EDIT-WGTCH-X
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*    IF SCALE-METRIC
013578*        IF WS-IMPERIAL-ENTERED
013578*        OR WS-BOTH-ENTERED
013578*            PERFORM  5450-CHECK-LBS
013578*                THRU 5450-CHECK-LBS-X
013578*            IF WGLOB-MSG-ERROR-SW > 0
013578*            AND WS-IMPERIAL-ENTERED
013578*                GO TO 5400-EDIT-WGTCH-X
013578*                IF WGLOB-MSG-ERROR-SW > 0
013578*                AND WS-BOTH-ENTERED
013578*                    NEXT SENTENCE
013578*                ELSE
013578*                    MOVE 'NS05400003'   TO WGLOB-MSG-REF-INFO
013578*                    PERFORM  0260-1000-GENERATE-MESSAGE
013578*                        THRU 0260-1000-GENERATE-MESSAGE-X
013578*                    GO TO 5400-EDIT-WGTCH-X
013578*                END-IF
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*
013578*    IF SCALE-METRIC
013578*        IF WS-METRIC-ENTERED
013578*        OR WS-BOTH-ENTERED
013578*            MOVE 'N'          TO L0280-SIGN-IND
013578*            MOVE 1            TO L0280-PRECISION
013578*            MOVE 3            TO L0280-LENGTH
013578*            MOVE 5            TO L0280-INPUT-SIZE
013578*            MOVE MIR-DV-CLI-WGT-CHNG-KG-QTY TO L0280-INPUT-DATA
013578*            PERFORM  7800-NUMERIC-EDIT
013578*                THRU 7800-NUMERIC-EDIT-X
013578*            IF NOT L0280-OK
013578*                MOVE 'NS05400018'    TO WGLOB-MSG-REF-INFO
013578*                PERFORM 0260-1000-GENERATE-MESSAGE
013578*                    THRU 0260-1000-GENERATE-MESSAGE-X
013578*                MOVE '1'              TO WS-EDIT-OK-SW
013578*                GO TO 5400-EDIT-WGTCH-X
013578*            ELSE
013578*                SET WS-METRIC-OK           TO TRUE
013578*                MOVE L0280-OUTPUT-V01      TO WS-N-999V9
013578*                MOVE WS-N-999V9            TO WS-PIC-999V9
013578*                MOVE WS-PIC-999V9   TO MIR-DV-CLI-WGT-CHNG-KG-QTY
013578*                MOVE L0280-OUTPUT-V01      TO L0530-METRIC-WEIGHT
013578*                PERFORM  0530-2000-KG-TO-LBS
013578*                    THRU 0530-2000-KG-TO-LBS-X
013578*                IF L0530-RETRN-FAILED
013578*                    MOVE 'NS05400024'      TO WGLOB-MSG-REF-INFO
013578*                    PERFORM  0260-1000-GENERATE-MESSAGE
013578*                        THRU 0260-1000-GENERATE-MESSAGE-X
013578*                    MOVE L0530-IMPERIAL-WEIGHT TO WS-N-999
013578*                    MOVE WS-N-999              TO WS-PIC-999
013578*                    MOVE WS-PIC-999 TO MIR-DV-CLI-WGT-CHNG-LB-QTY
013578*                    MOVE '1'                   TO WS-EDIT-OK-SW
013578*                    GO TO 5400-EDIT-WGTCH-X
013578*                ELSE
013578*                    MOVE L0530-IMPERIAL-WEIGHT TO WS-N-999
013578*                    MOVE WS-N-999              TO WS-PIC-999
013578*                    MOVE WS-PIC-999 TO MIR-DV-CLI-WGT-CHNG-LB-QTY
013578*                    MOVE L0530-METRIC-WEIGHT
013578*                                     TO RAPPF-CLI-WGT-CHNG-QTY
013578*                    IF WS-METRIC-ENTERED
013578*                        GO TO 5400-EDIT-WGTCH-X
013578*                    ELSE
013578*                        IF WS-BOTH-ENTERED
013578*                        AND NOT WS-IMPERIAL-OK
013578*                            GO TO 5400-EDIT-WGTCH-X
013578*                        ELSE
013578*                            MOVE 'NS05400017'
013578*                                         TO WGLOB-MSG-REF-INFO
013578*                            PERFORM 0260-1000-GENERATE-MESSAGE
013578*                                THRU 0260-1000-GENERATE-MESSAGE-X
013578*                            GO TO 5400-EDIT-WGTCH-X
013578*                        END-IF
013578*                    END-IF
013578*                END-IF
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*    IF SCALE-IMPERIAL
013578*        IF WS-IMPERIAL-ENTERED
013578*            PERFORM  5450-CHECK-LBS
013578*                THRU 5450-CHECK-LBS-X
013578*        ELSE
013578*            IF WS-METRIC-ENTERED
013578*            OR WS-BOTH-ENTERED
013578*                MOVE 'N'          TO L0280-SIGN-IND
013578*                MOVE 1            TO L0280-PRECISION
013578*                MOVE 3            TO L0280-LENGTH
013578*                MOVE 5            TO L0280-INPUT-SIZE
013578*                MOVE MIR-DV-CLI-WGT-CHNG-KG-QTY
013578*                                  TO L0280-INPUT-DATA
013578*                PERFORM  7800-NUMERIC-EDIT
013578*                    THRU 7800-NUMERIC-EDIT-X
013578*               IF L0280-OK
013578*                   SET WS-METRIC-OK TO TRUE
013578*                   MOVE L0280-OUTPUT-V01      TO WS-N-999V9
013578*                   MOVE WS-N-999V9            TO WS-PIC-999V9
013578*                   MOVE WS-PIC-999V9
013578*                        TO MIR-DV-CLI-WGT-CHNG-KG-QTY
013578*                   IF WS-BOTH-ENTERED
013578*                       NEXT SENTENCE
013578*                   ELSE
013578*                       MOVE 'NS05400003'   TO WGLOB-MSG-REF-INFO
013578*                       PERFORM  0260-1000-GENERATE-MESSAGE
013578*                           THRU 0260-1000-GENERATE-MESSAGE-X
013578*                   END-IF
013578*                   MOVE L0280-OUTPUT-V01   TO L0530-METRIC-WEIGHT
013578*                   PERFORM  0530-2000-KG-TO-LBS
013578*                       THRU 0530-2000-KG-TO-LBS-X
013578*                   IF L0530-RETRN-FAILED
013578*                       MOVE 'NS05400024' TO WGLOB-MSG-REF-INFO
013578*                       PERFORM  0260-1000-GENERATE-MESSAGE
013578*                           THRU 0260-1000-GENERATE-MESSAGE-X
013578*                       MOVE L0530-IMPERIAL-WEIGHT TO WS-N-999
013578*                       MOVE WS-N-999              TO WS-PIC-999
013578*                       MOVE WS-PIC-999
013578*                            TO MIR-DV-CLI-WGT-CHNG-LB-QTY
013578*                       MOVE -1
013578*                       MOVE '1'                  TO WS-EDIT-OK-SW
013578*                       GO TO 5400-EDIT-WGTCH-X
013578*                   ELSE
013578*                       MOVE L0530-IMPERIAL-WEIGHT TO WS-N-999
013578*                       MOVE WS-N-999              TO WS-PIC-999
013578*                       MOVE WS-PIC-999
013578*                            TO MIR-DV-CLI-WGT-CHNG-LB-QTY
013578*                       MOVE L0530-IMPERIAL-WEIGHT
013578*                                      TO RAPPF-CLI-WGT-CHNG-QTY
013578*                   END-IF
013578*               ELSE
013578*                   IF WS-METRIC-ENTERED
013578*                       MOVE 'NS05400018'    TO WGLOB-MSG-REF-INFO
013578*                       PERFORM 0260-1000-GENERATE-MESSAGE
013578*                           THRU 0260-1000-GENERATE-MESSAGE-X
013578*                       MOVE -1
013578*                       MOVE '1'              TO WS-EDIT-OK-SW
013578*                       GO TO 5400-EDIT-WGTCH-X
013578*                   ELSE
013578*                       IF WS-BOTH-ENTERED
013578*                           PERFORM  5450-CHECK-LBS
013578*                               THRU 5450-CHECK-LBS-X
013578*                       END-IF
013578*                   END-IF
013578*               END-IF
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
013578*    IF SCALE-IMPERIAL
013578*        IF WS-BOTH-ENTERED
013578*            PERFORM  5450-CHECK-LBS
013578*                THRU 5450-CHECK-LBS-X
013578*            IF NOT WS-IMPERIAL-OK
013578*                MOVE 'NS05400019'    TO WGLOB-MSG-REF-INFO
013578*                PERFORM 0260-1000-GENERATE-MESSAGE
013578*                    THRU 0260-1000-GENERATE-MESSAGE-X
013578*                MOVE '1'              TO WS-EDIT-OK-SW
013578*            END-IF
013578*        END-IF
013578*    END-IF.
013578*
       5400-EDIT-WGTCH-X.
           EXIT.
      *
013578*5450-CHECK-LBS.
013578*
013578*    MOVE 'N'          TO L0280-SIGN-IND.
013578*    MOVE 0            TO L0280-PRECISION.
013578*    MOVE 3            TO L0280-LENGTH.
013578*    MOVE 3            TO L0280-INPUT-SIZE.
013578*    MOVE MIR-DV-CLI-WGT-CHNG-LB-QTY  TO L0280-INPUT-DATA.
013578*    PERFORM  7800-NUMERIC-EDIT
013578*        THRU 7800-NUMERIC-EDIT-X.
013578*
013578*    IF L0280-OK
013578*        NEXT SENTENCE
013578*    ELSE
013578*        IF WS-BOTH-ENTERED
013578*            MOVE 1              TO WGLOB-MSG-ERROR-SW
013578*            GO TO 5450-CHECK-LBS-X
013578*        ELSE
013578*            MOVE 'NS05400019'    TO WGLOB-MSG-REF-INFO
013578*            PERFORM 0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            MOVE '1'              TO WS-EDIT-OK-SW
013578*            GO TO 5450-CHECK-LBS-X
013578*        END-IF
013578*    END-IF.
013578*
013578*    SET WS-IMPERIAL-OK            TO TRUE.
013578*    MOVE L0280-OUTPUT             TO L0530-IMPERIAL-WEIGHT.
013578*    MOVE L0530-IMPERIAL-WEIGHT    TO WS-N-999
013578*    MOVE WS-N-999                 TO WS-PIC-999
013578*    MOVE WS-PIC-999            TO MIR-DV-CLI-WGT-CHNG-LB-QTY
013578*    IF SCALE-METRIC
013578*    AND WS-BOTH-ENTERED
013578*        GO TO 5450-CHECK-LBS-X
013578*    ELSE
013578*        PERFORM  0530-1000-LBS-TO-KG
013578*            THRU 0530-1000-LBS-TO-KG-X
013578*    END-IF.
013578*        MOVE L0530-METRIC-WEIGHT      TO WS-N-999V9.
013578*        MOVE WS-N-999V9               TO WS-PIC-999V9.
013578*    IF SCALE-METRIC
013578*        MOVE L0530-METRIC-WEIGHT  TO RAPPF-CLI-WGT-CHNG-QTY
013578*    ELSE
013578*        MOVE L0530-IMPERIAL-WEIGHT TO RAPPF-CLI-WGT-CHNG-QTY
013578*    END-IF.
013578*    MOVE WS-PIC-999V9          TO MIR-DV-CLI-WGT-CHNG-KG-QTY.
013578*
013578*    IF WS-BOTH-ENTERED
013578*    AND WS-METRIC-OK
013578*    AND WS-IMPERIAL-OK
013578*        MOVE 'NS05400017'         TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    END-IF.
013578*
       5450-CHECK-LBS-X.
           EXIT.
      *****************************************************************
      *  EDIT REGULAR PHYSICIAN INDICATOR
      *****************************************************************
       5500-EDIT-RPHYS.
      *
           IF MIR-REGU-DOCTOR-IND  = SPACES
               MOVE RAPPF-REGU-DOCTOR-IND   TO MIR-REGU-DOCTOR-IND
               GO TO 5500-EDIT-RPHYS-X
557660     END-IF.
      *
           IF MIR-REGU-DOCTOR-IND  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES        TO MIR-REGU-DOCTOR-IND
557660     END-IF.
      *
           MOVE MIR-REGU-DOCTOR-IND         TO WS-TEST-RPHYS.
      *
           IF WS-RPHYS-OK
               MOVE MIR-REGU-DOCTOR-IND    TO RAPPF-REGU-DOCTOR-IND
           ELSE
               MOVE 'NS05400005'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.
      *
       5500-EDIT-RPHYS-X.
           EXIT.
      *
      *****************************************************************
      *  CURRENT LOCATION (PROV/STATE):  MUST BE VALIDATED AGAINST EDIT
      *****************************************************************
       5600-EDIT-PPROV.
      *
           IF MIR-CLI-DOCTOR-PROV-CD = SPACES
               MOVE RAPPF-CLI-DOCTOR-PROV-CD TO MIR-CLI-DOCTOR-PROV-CD
               GO TO 5600-EDIT-PPROV-X
557660     END-IF.
      *
           IF MIR-CLI-DOCTOR-PROV-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES       TO RAPPF-CLI-DOCTOR-PROV-CD
               MOVE SPACES       TO MIR-CLI-DOCTOR-PROV-CD
               GO TO 5600-EDIT-PPROV-X
557660     END-IF.
      *
006002*    MOVE MIR-CLI-DOCTOR-PROV-CD        TO WEDIT-ETBL-VALU-ID.
      *
006002*    PERFORM  CLOC-1000-EDIT-CURR-LOCATION
006002*        THRU CLOC-1000-EDIT-CURR-LOCATION-X.
006002*
006002*    IF WEDIT-IO-OK

006002     MOVE MIR-CLI-DOCTOR-PROV-CD        TO WCTLC-CTRY-LOC-CD.
006002     MOVE WGLOB-COUNTRY-CODE            TO WCTLC-CTRY-CD.
006002     MOVE WGLOB-COMPANY-CODE            TO WCTLC-CO-ID
006002     SET WCTLC-CTRY-LOC-TYP-CURRENT     TO TRUE
006002     PERFORM  CTLC-1000-READ
006002         THRU CTLC-1000-READ-X
006002     IF  WCTLC-IO-OK
               MOVE MIR-CLI-DOCTOR-PROV-CD  TO RAPPF-CLI-DOCTOR-PROV-CD
           ELSE
               MOVE 'NS05400006'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-CLI-DOCTOR-PROV-CD
013578                    TO RAPPF-CLI-DOCTOR-PROV-CD
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5600-EDIT-PPROV-X.
           EXIT.
      *****************************************************************
      *  VISIT DATE: MUST BE IN FORM DDMMMYYYY
      *****************************************************************
       5700-EDIT-VDATE.
      *
           IF MIR-DOCTOR-PREV-VST-DT = SPACES
               MOVE RAPPF-DOCTOR-PREV-VST-DT TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE    TO MIR-DOCTOR-PREV-VST-DT
               GO TO 5700-EDIT-VDATE-X
557660     END-IF.
      *
           IF MIR-DOCTOR-PREV-VST-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE WWKDT-ZERO-DT TO RAPPF-DOCTOR-PREV-VST-DT
               MOVE SPACES       TO MIR-DOCTOR-PREV-VST-DT
               GO TO 5700-EDIT-VDATE-X
557660     END-IF.
      *
           MOVE MIR-DOCTOR-PREV-VST-DT TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-NOT-VALID
               MOVE '1'              TO WS-EDIT-OK-SW
               MOVE MIR-DOCTOR-PREV-VST-DT        TO WGLOB-MSG-PARM (1)
               MOVE 'NS05400007'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF L1640-INTERNAL-DATE > WGLOB-SYSTEM-DATE-INT
                   MOVE 'NS05400025'    TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'              TO WS-EDIT-OK-SW
               ELSE
                   MOVE L1640-INTERNAL-DATE TO RAPPF-DOCTOR-PREV-VST-DT
557660         END-IF
557660     END-IF.
      *
       5700-EDIT-VDATE-X.
           EXIT.
      *****************************************************************
      *  VISIT REASON:  MUST BE VALIDATED AGAINST EDIT
      *****************************************************************
       5800-EDIT-VREAS.
      *
           IF MIR-PREV-VST-REASN-CD = SPACES
               MOVE RAPPF-PREV-VST-REASN-CD TO MIR-PREV-VST-REASN-CD
               GO TO 5800-EDIT-VREAS-X
557660     END-IF.
      *
           IF MIR-PREV-VST-REASN-CD = RAPPF-PREV-VST-REASN-CD
               GO TO 5800-EDIT-VREAS-X
557660     END-IF.
      *
           IF MIR-PREV-VST-REASN-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES       TO MIR-PREV-VST-REASN-CD
557660     END-IF.
      *
           MOVE MIR-PREV-VST-REASN-CD        TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  VRES-1000-EDIT
               THRU VRES-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
               MOVE MIR-PREV-VST-REASN-CD  TO RAPPF-PREV-VST-REASN-CD
           ELSE
               MOVE 'NS05400008'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-PREV-VST-REASN-CD
013578                     TO RAPPF-PREV-VST-REASN-CD
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5800-EDIT-VREAS-X.
           EXIT.
      *****************************************************************
      *  WEIGHT CHANGE REASON: VALIDATE AGAINST EDIT
      *****************************************************************
       5900-EDIT-RWGTC.
      *
           IF MIR-REASN-WGT-CHNG-TXT = SPACES
               MOVE RAPPF-REASN-WGT-CHNG-TXT TO MIR-REASN-WGT-CHNG-TXT
               GO TO 5900-EDIT-RWGTC-X
557660     END-IF.
      *
           IF MIR-REASN-WGT-CHNG-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES      TO RAPPF-REASN-WGT-CHNG-TXT
               MOVE SPACES      TO MIR-REASN-WGT-CHNG-TXT
               GO TO 5900-EDIT-RWGTC-X
557660     END-IF.
      *
      *
           MOVE MIR-REASN-WGT-CHNG-TXT       TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  WRSN-1000-EDIT
               THRU WRSN-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
               MOVE MIR-REASN-WGT-CHNG-TXT  TO RAPPF-REASN-WGT-CHNG-TXT
           ELSE
               MOVE 'NS05400026'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-REASN-WGT-CHNG-TXT
013578                          TO RAPPF-REASN-WGT-CHNG-TXT
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5900-EDIT-RWGTC-X.
           EXIT.
      *****************************************************************
      *  PHYSICIAN NAME: NO EDITS
      *****************************************************************
       6000-EDIT-PNAME.
      *
           IF MIR-CLI-DOCTOR-NM = SPACES
               MOVE RAPPF-CLI-DOCTOR-NM   TO MIR-CLI-DOCTOR-NM
557660     END-IF.
      *
           IF MIR-CLI-DOCTOR-NM = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES          TO MIR-CLI-DOCTOR-NM
557660     END-IF.
      *
           MOVE MIR-REGU-DOCTOR-IND           TO WS-TEST-RPHYS.
      *
           IF  WS-RPHYS-YES
           AND MIR-CLI-DOCTOR-NM = SPACES
               MOVE 'NS05400031'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-CLI-DOCTOR-NM   TO RAPPF-CLI-DOCTOR-NM
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
           ELSE
               MOVE MIR-CLI-DOCTOR-NM       TO RAPPF-CLI-DOCTOR-NM
           END-IF.
      *
       6000-EDIT-PNAME-X.
           EXIT.
      *****************************************************************
      *  PHYSICIAN CITY: NO EDITS
      *****************************************************************
       6100-EDIT-PCITY.
      *
           IF MIR-DOCTOR-CITY-NM-TXT = SPACES
               MOVE RAPPF-DOCTOR-CITY-NM-TXT TO MIR-DOCTOR-CITY-NM-TXT
               GO TO 6100-EDIT-PCITY-X
557660     END-IF.
      *
           IF MIR-DOCTOR-CITY-NM-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES       TO MIR-DOCTOR-CITY-NM-TXT
557660     END-IF.
      *
           MOVE MIR-DOCTOR-CITY-NM-TXT    TO RAPPF-DOCTOR-CITY-NM-TXT.
      *
       6100-EDIT-PCITY-X.
           EXIT.
      *****************************************************************
      *  LAST VISIT RESULTS: VALIDATE AGAINST EDIT
      *****************************************************************
       6200-EDIT-RSLTS.
      *
           IF MIR-PREV-VST-RSLT-TXT = SPACES
               MOVE RAPPF-PREV-VST-RSLT-TXT  TO MIR-PREV-VST-RSLT-TXT
               GO TO 6200-EDIT-RSLTS-X
557660     END-IF.
      *
           IF MIR-PREV-VST-RSLT-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES       TO MIR-PREV-VST-RSLT-TXT
557660     END-IF.
      *
           MOVE MIR-PREV-VST-RSLT-TXT        TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  LRLT-1000-EDIT
               THRU LRLT-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
               MOVE MIR-PREV-VST-RSLT-TXT   TO RAPPF-PREV-VST-RSLT-TXT
           ELSE
               MOVE 'NS05400027'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-PREV-VST-RSLT-TXT
013578                       TO RAPPF-PREV-VST-RSLT-TXT
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6200-EDIT-RSLTS-X.
           EXIT.
      *****************************************************************
      *  MEDICATION GIVEN: VALIDATE AGAINST EDIT
      *****************************************************************
       6300-EDIT-IMED.
      *
           IF MIR-CLI-MEDCTN-GIV-TXT = SPACES
               MOVE RAPPF-CLI-MEDCTN-GIV-TXT TO MIR-CLI-MEDCTN-GIV-TXT
               GO TO 6300-EDIT-IMED-X
557660     END-IF.
      *
           IF MIR-CLI-MEDCTN-GIV-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES       TO MIR-CLI-MEDCTN-GIV-TXT
557660     END-IF.
      *
           MOVE MIR-CLI-MEDCTN-GIV-TXT         TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  LMED-1000-EDIT
               THRU LMED-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
               MOVE MIR-CLI-MEDCTN-GIV-TXT TO RAPPF-CLI-MEDCTN-GIV-TXT
           ELSE
               MOVE 'NS05400029'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-CLI-MEDCTN-GIV-TXT
013578                  TO RAPPF-CLI-MEDCTN-GIV-TXT
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6300-EDIT-IMED-X.
           EXIT.
      *****************************************************************
      *  TREATMENT RECEIVED: VALIDATE AGAINST EDIT
      *****************************************************************
       6400-EDIT-TRTMT.
      *
           IF MIR-TRTMNT-RECV-TXT = SPACES
               MOVE RAPPF-TRTMNT-RECV-TXT TO MIR-TRTMNT-RECV-TXT
               GO TO 6400-EDIT-TRTMT-X
557660     END-IF.
      *
           IF MIR-TRTMNT-RECV-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES       TO MIR-TRTMNT-RECV-TXT
557660     END-IF.
      *
           MOVE MIR-TRTMNT-RECV-TXT        TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  LTRT-1000-EDIT
               THRU LTRT-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
               MOVE MIR-TRTMNT-RECV-TXT    TO RAPPF-TRTMNT-RECV-TXT
           ELSE
               MOVE 'NS05400028'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-TRTMNT-RECV-TXT TO RAPPF-TRTMNT-RECV-TXT
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6400-EDIT-TRTMT-X.
           EXIT.
      *****************************************************************
      *  DISORDER DIAGNOSED: VALIDATE AGAINST EDIT
      *****************************************************************
       6500-EDIT-IDISO.
      *
           IF MIR-DISORD-DIAGNS-TXT = SPACES
               MOVE RAPPF-DISORD-DIAGNS-TXT TO MIR-DISORD-DIAGNS-TXT
               GO TO 6500-EDIT-IDISO-X
557660     END-IF.
      *
           IF MIR-DISORD-DIAGNS-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES       TO MIR-DISORD-DIAGNS-TXT
557660     END-IF.
      *
           MOVE MIR-DISORD-DIAGNS-TXT        TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  LDIS-1000-EDIT
               THRU LDIS-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
               MOVE MIR-DISORD-DIAGNS-TXT   TO RAPPF-DISORD-DIAGNS-TXT
           ELSE
               MOVE 'NS05400030'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-DISORD-DIAGNS-TXT TO RAPPF-DISORD-DIAGNS-TXT
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       6500-EDIT-IDISO-X.
           EXIT.
      *
       6600-EDIT-PREGI.

           IF MIR-CLI-PREG-IND = SPACES
               MOVE RAPPF-CLI-PREG-IND  TO MIR-CLI-PREG-IND
               GO TO 6600-EDIT-PREGI-X
557660     END-IF.

           IF MIR-CLI-PREG-IND  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-CLI-PREG-IND
               MOVE SPACE         TO RAPPF-CLI-PREG-IND
               GO TO 6600-EDIT-PREGI-X
557660     END-IF.

           MOVE MIR-CLI-PREG-IND         TO WS-TEST-YES-NO.

           IF NOT WS-TEST-YES-NO-OK
      *** MSG (S) PREGNANT IND MUST BE BLANK, Y OR N
               MOVE 'NS05400033'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
               GO TO 6600-EDIT-PREGI-X
557660     END-IF.

           MOVE MIR-CLI-PREG-IND            TO RAPPF-CLI-PREG-IND.

       6600-EDIT-PREGI-X.
           EXIT.
      *
       6700-EDIT-CONDT.

           IF MIR-CLI-PREG-CNFMT-DT = SPACES
               MOVE RAPPF-CLI-PREG-CNFMT-DT TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-PREG-CNFMT-DT
               GO TO 6700-EDIT-CONDT-X
557660     END-IF.

           IF MIR-CLI-PREG-CNFMT-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES TO MIR-CLI-PREG-CNFMT-DT
               MOVE WWKDT-ZERO-DT  TO RAPPF-CLI-PREG-CNFMT-DT
               GO TO 6700-EDIT-CONDT-X
557660     END-IF.

           MOVE MIR-CLI-PREG-CNFMT-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
      *** MSG (S) CONFINEMENT DATE MUST BE VALID DATE-FORMAT DDMMMYYYY
               MOVE 'NS05400034'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
               GO TO 6700-EDIT-CONDT-X
557660     END-IF.

           MOVE L1640-INTERNAL-DATE  TO RAPPF-CLI-PREG-CNFMT-DT.

       6700-EDIT-CONDT-X.
           EXIT.
      *
       6800-EDIT-CMPLI.

           IF MIR-PREG-CMPLIC-IND = SPACES
557659*        MOVE RAPPF-CLI-PREG-CMPLIC-CD TO MIR-PREG-CMPLIC-IND
557659         MOVE RAPPF-PREG-CMPLIC-IND    TO MIR-PREG-CMPLIC-IND
               GO TO 6800-EDIT-CMPLI-X
557660     END-IF.

           IF MIR-PREG-CMPLIC-IND  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-PREG-CMPLIC-IND
557659*        MOVE SPACE         TO RAPPF-CLI-PREG-CMPLIC-CD
557659         MOVE SPACE         TO RAPPF-PREG-CMPLIC-IND
               GO TO 6800-EDIT-CMPLI-X
557660     END-IF.

           MOVE MIR-PREG-CMPLIC-IND         TO WS-TEST-YES-NO.

           IF NOT WS-TEST-YES-NO-OK
      *** MSG (S) COMPLICATIONS IND MUST BE BLANK, Y OR N
               MOVE 'NS05400035'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
               GO TO 6800-EDIT-CMPLI-X
557660     END-IF.

557659*    MOVE MIR-PREG-CMPLIC-IND     TO RAPPF-CLI-PREG-CMPLIC-CD.
557659     MOVE MIR-PREG-CMPLIC-IND     TO RAPPF-PREG-CMPLIC-IND.

       6800-EDIT-CMPLI-X.
            EXIT.
      *
       6900-PREG-XEDITS.

           IF L2437-CLI-SEX-CD NOT = 'F'
               IF RAPPF-CLI-PREG-IND  = 'Y'
               OR RAPPF-CLI-PREG-CNFMT-DT > WWKDT-ZERO-DT
557659*        OR RAPPF-CLI-PREG-CMPLIC-CD = 'Y'
557659         OR RAPPF-PREG-CMPLIC-IND    = 'Y'
      *** MSG (S) CLIENT NOT FEMALE, PREGNANCY DATA SHOULD BE NEGATIVE
                   MOVE 'NS05400036'     TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

       6900-PREG-XEDITS-X.
           EXIT.
      *
      *****************************************************************
      *  CHECK FOR EXISTING CLIENT
      *****************************************************************
       7000-VALIDATE-ACCESS.
      *
           PERFORM  8100-BUILD-NAL-KEY
               THRU 8100-BUILD-NAL-KEY-X.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X

           IF  L2437-RETRN-CLI-NOT-FOUND
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               MOVE L2437-WCLI-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-VALIDATE-ACCESS-X
           END-IF.

           MOVE L2437-CLI-SEX-CD            TO L0620-CLI-SEX-CD.
557698*    MOVE L2437-CLI-CO-NM             TO L0620-CLI-CO-NM.
557698*    MOVE L2437-CLI-GIV-NM            TO L0620-CLI-GIV-NM.
557698*    MOVE L2437-CLI-SUR-NM            TO L0620-CLI-SUR-NM.
557698     MOVE L2437-CLI-ENTR-CO-NM        TO L0620-CLI-CO-NM
557698     MOVE L2437-CLI-ENTR-GIV-NM       TO L0620-CLI-GIV-NM
557698     MOVE L2437-CLI-ENTR-SUR-NM       TO L0620-CLI-SUR-NM
014653     MOVE L2437-CLI-MID-INIT-NM       TO L0620-CLI-MID-INIT-NM
014653     MOVE L2437-CLI-SFX-NM            TO L0620-CLI-SFX-NM

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
      *
           MOVE L0620-SCREEN-NAME           TO MIR-DV-INSRD-CLI-NM.
           MOVE L2437-CLI-SEX-CD            TO MIR-CLI-SEX-CD.

      *
      *  INITIALIZE INPUT PARAMETERS
      *
           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE L2437-CLI-ID                TO L5600-CLI-ID.
016387*    SET L5600-GEN-CNSLDT-MSG-WARN    TO TRUE.

      *
      *  CALL MODULE TO CHECK CLIENT CONFIDENTIALITY INDICATOR
      *
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.
      *
       7000-VALIDATE-ACCESS-X.
           EXIT.
      *
      *****************************************************************
      *  NUMERIC EDIT
      *****************************************************************
       7800-NUMERIC-EDIT.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
       7800-NUMERIC-EDIT-X.
           EXIT.
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970     COPY XCPS0280.
           COPY XCPL0280.
      *****************************************************************
      *  BUILD APPF KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************
       8000-BUILD-APPF-KEY.
      *
           MOVE MIR-CLI-ID        TO WAPPF-CLI-ID.
      *
       8000-BUILD-APPF-KEY-X.
           EXIT.
      *****************************************************************
      *  BUILD NAL KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************
       8100-BUILD-NAL-KEY.
      *
           MOVE MIR-CLI-ID        TO L2437-CLI-ID.
      *
       8100-BUILD-NAL-KEY-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.
      *
014221*    MOVE SPACES     TO MIR-PREV-UPDT-DT.
014221     MOVE SPACES     TO MIR-DV-PREV-UPDT-DT.
           MOVE SPACES     TO MIR-DV-CLI-FT-HT.
           MOVE SPACES     TO MIR-DV-CLI-INCH-HT.
           MOVE SPACES     TO MIR-DV-CLI-CM-HT.
           MOVE SPACES     TO MIR-DV-CLI-KG-WGT.
           MOVE SPACES     TO MIR-DV-CLI-LB-WGT.
           MOVE SPACES     TO MIR-WGT-GAIN-LOS-CD.
           MOVE SPACES     TO MIR-DV-CLI-WGT-CHNG-KG-QTY.
           MOVE SPACES     TO MIR-DV-CLI-WGT-CHNG-LB-QTY.
           MOVE SPACES     TO MIR-REASN-WGT-CHNG-TXT.
           MOVE SPACES     TO MIR-REGU-DOCTOR-IND.
           MOVE SPACES     TO MIR-CLI-DOCTOR-NM.
           MOVE SPACES     TO MIR-DOCTOR-CITY-NM-TXT.
           MOVE SPACES     TO MIR-CLI-DOCTOR-PROV-CD.
           MOVE SPACES     TO MIR-DOCTOR-PREV-VST-DT.
           MOVE SPACES     TO MIR-PREV-VST-RSLT-TXT.
           MOVE SPACES     TO MIR-CLI-MEDCTN-GIV-TXT.
           MOVE SPACES     TO MIR-PREV-VST-REASN-CD.
           MOVE SPACES     TO MIR-TRTMNT-RECV-TXT.
           MOVE SPACES     TO MIR-DISORD-DIAGNS-TXT.
           MOVE SPACES     TO MIR-CLI-PREG-IND.
           MOVE SPACES     TO MIR-CLI-PREG-CNFMT-DT.
           MOVE SPACES     TO MIR-PREG-CMPLIC-IND.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.
      *
557659*    MOVE RAPPF-WGT-GAIN-LOS-IND     TO MIR-WGT-GAIN-LOS-CD.
557659     MOVE RAPPF-WGT-GAIN-LOS-CD      TO MIR-WGT-GAIN-LOS-CD.
           MOVE RAPPF-REASN-WGT-CHNG-TXT   TO MIR-REASN-WGT-CHNG-TXT.
           MOVE RAPPF-CLI-DOCTOR-NM        TO MIR-CLI-DOCTOR-NM.
           MOVE RAPPF-REGU-DOCTOR-IND      TO MIR-REGU-DOCTOR-IND.
           MOVE RAPPF-DOCTOR-CITY-NM-TXT   TO MIR-DOCTOR-CITY-NM-TXT.
           MOVE RAPPF-CLI-DOCTOR-PROV-CD   TO MIR-CLI-DOCTOR-PROV-CD.
           MOVE RAPPF-PREV-VST-REASN-CD    TO MIR-PREV-VST-REASN-CD.
           MOVE RAPPF-PREV-VST-RSLT-TXT    TO MIR-PREV-VST-RSLT-TXT.
           MOVE RAPPF-TRTMNT-RECV-TXT      TO MIR-TRTMNT-RECV-TXT.
           MOVE RAPPF-CLI-MEDCTN-GIV-TXT   TO MIR-CLI-MEDCTN-GIV-TXT.
           MOVE RAPPF-DISORD-DIAGNS-TXT    TO MIR-DISORD-DIAGNS-TXT.
      *
      *THIS PORTION RESTRUCTURED FOR 5.3
      *
           IF SCALE-METRIC
               MOVE L2437-CLI-HT          TO WS-N-999V9
               MOVE WS-N-999V9            TO WS-PIC-999V9
               MOVE WS-PIC-999V9          TO MIR-DV-CLI-CM-HT
               MOVE L2437-CLI-WGT         TO WS-N-999V9
               MOVE WS-N-999V9            TO WS-PIC-999V9
               MOVE WS-PIC-999V9          TO MIR-DV-CLI-KG-WGT
               MOVE L2437-CLI-HT          TO L0520-METRIC-HEIGHT
               PERFORM  0520-2000-CM-TO-FEET
                   THRU 0520-2000-CM-TO-FEET-X
      *---DISPLAY COVERTED VALUES IN IMPERIAL FIELDS
      *---HEIGHT
               MOVE L0520-IMPERIAL-FEET    TO WS-PIC-9
               MOVE WS-PIC-9               TO MIR-DV-CLI-FT-HT
               MOVE L0520-IMPERIAL-INCHES  TO WS-N-99
               MOVE WS-N-99                TO WS-PIC-99
               MOVE WS-PIC-99              TO MIR-DV-CLI-INCH-HT
      *---WEIGHT
               MOVE L2437-CLI-WGT          TO L0530-METRIC-WEIGHT
               PERFORM  0530-2000-KG-TO-LBS
                   THRU 0530-2000-KG-TO-LBS-X
               MOVE L0530-IMPERIAL-WEIGHT  TO WS-PIC-999
               MOVE WS-PIC-999             TO MIR-DV-CLI-LB-WGT
557660     END-IF.

      *---IMPERIAL HEIGHT STORED IN INCHES SO NEED TO CONVERT FIRST
           IF SCALE-IMPERIAL
               MOVE L2437-CLI-HT            TO L0520-IMPERIAL-INCHES
               SET L0520-RQST-IN-TO-FEET    TO TRUE
               PERFORM  0520-3000-IN-TO-FEET
                   THRU 0520-3000-IN-TO-FEET-X
      *---HEIGHT
               MOVE L0520-IMPERIAL-FEET      TO WS-PIC-9
               MOVE WS-PIC-9                 TO MIR-DV-CLI-FT-HT
               MOVE L0520-IMPERIAL-INCHES    TO WS-PIC-99
               MOVE WS-PIC-99                TO MIR-DV-CLI-INCH-HT
               PERFORM  0520-1000-FEET-TO-CM
                   THRU 0520-1000-FEET-TO-CM-X
               MOVE L0520-METRIC-HEIGHT   TO WS-N-999V9
               MOVE WS-N-999V9            TO WS-PIC-999V9
               MOVE WS-PIC-999V9          TO MIR-DV-CLI-CM-HT
      *---WEIGHT
               MOVE L2437-CLI-WGT         TO WS-PIC-999
               MOVE WS-PIC-999            TO MIR-DV-CLI-LB-WGT
               MOVE L2437-CLI-WGT         TO L0530-IMPERIAL-WEIGHT
               PERFORM  0530-1000-LBS-TO-KG
                   THRU 0530-1000-LBS-TO-KG-X
               MOVE L0530-METRIC-WEIGHT   TO WS-N-999V9
               MOVE WS-N-999V9            TO WS-PIC-999V9
               MOVE WS-PIC-999V9          TO MIR-DV-CLI-KG-WGT
557660     END-IF.

      *
           IF SCALE-METRIC
               MOVE RAPPF-CLI-WGT-CHNG-QTY TO WS-N-999V9
               MOVE WS-N-999V9            TO WS-PIC-999V9
               MOVE WS-PIC-999V9       TO MIR-DV-CLI-WGT-CHNG-KG-QTY
               MOVE RAPPF-CLI-WGT-CHNG-QTY   TO L0530-METRIC-WEIGHT
               PERFORM  0530-2000-KG-TO-LBS
                   THRU 0530-2000-KG-TO-LBS-X
               MOVE L0530-IMPERIAL-WEIGHT    TO WS-PIC-999
               MOVE WS-PIC-999            TO MIR-DV-CLI-WGT-CHNG-LB-QTY
           END-IF.
      *
           IF SCALE-IMPERIAL
               MOVE RAPPF-CLI-WGT-CHNG-QTY TO WS-N-999
               MOVE WS-N-999              TO WS-PIC-999
               MOVE WS-PIC-999         TO MIR-DV-CLI-WGT-CHNG-LB-QTY
               MOVE RAPPF-CLI-WGT-CHNG-QTY   TO L0530-IMPERIAL-WEIGHT
               PERFORM  0530-1000-LBS-TO-KG
                   THRU 0530-1000-LBS-TO-KG-X
               MOVE L0530-METRIC-WEIGHT       TO WS-PIC-999V9
               MOVE WS-PIC-999V9           TO MIR-DV-CLI-WGT-CHNG-KG-QTY
           END-IF.

014221*    MOVE RAPPF-PREV-UPDT-DT      TO L1640-INTERNAL-DATE.
014221*    MOVE RAPPF-PREV-UPDT-TS      TO L1640-INTERNAL-DATE.
014221     MOVE RAPPF-PREV-UPDT-TS      TO WWKDT-INT-TS.
014221     MOVE WWKDT-INT-TS            TO L1640-INTERNAL-DATE.
           PERFORM  9250-CONVERT-DATE
               THRU 9250-CONVERT-DATE-X
014221*    MOVE L1640-EXTERNAL-DATE     TO MIR-PREV-UPDT-DT.
014221     MOVE L1640-EXTERNAL-DATE     TO MIR-DV-PREV-UPDT-DT.
      *
           MOVE RAPPF-DOCTOR-PREV-VST-DT TO L1640-INTERNAL-DATE.
           PERFORM  9250-CONVERT-DATE
               THRU 9250-CONVERT-DATE-X
           MOVE L1640-EXTERNAL-DATE     TO MIR-DOCTOR-PREV-VST-DT.
      *
           MOVE RAPPF-CLI-PREG-IND      TO MIR-CLI-PREG-IND.
      *
           MOVE RAPPF-CLI-PREG-CNFMT-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE     TO MIR-CLI-PREG-CNFMT-DT.
      *
557659*    MOVE RAPPF-CLI-PREG-CMPLIC-CD TO MIR-PREG-CMPLIC-IND.
557659     MOVE RAPPF-PREG-CMPLIC-IND    TO MIR-PREG-CMPLIC-IND.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *
       9250-CONVERT-DATE.
      *
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
      *
       9250-CONVERT-DATE-X.
           EXIT.

      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                    TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID              TO WGLOB-REF-CLIENT-NUMBER.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0520-0000-INIT-PARM-INFO
025970         THRU 0520-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0530-0000-INIT-PARM-INFO
025970         THRU 0530-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
023514
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     MOVE SPACES                        TO WWKDT-WORK-FIELDS.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
018633*-------------------
018633*9500-BUILD-TWRK-KEY.
018633*-------------------
018633*
018633*    MOVE WS-TWRK-KEY
018633*      TO L8090-BUS-FCN-ID.
018633*    MOVE ZEROS
018633*      TO L8090-TEMP-WRK-SEQ-NUM.
018633*    SET L8090-USAGE-COMM TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9800-WRITE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*    MOVE 300
018633*      TO L8090-AREA-LEN.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*
018633*-------------------
018633*9900-DELETE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
018633*
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
006002*COPY CCPECLOC.
028298 COPY CCPPFCCK.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      *
       COPY NCPELDIS.
      *
       COPY NCPELMED.
      *
       COPY NCPELRLT.
      *
       COPY NCPELTRT.
      *
       COPY NCPEVRES.
      *
       COPY NCPEWRSN.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
021930*COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
025970 COPY NCPS0520.
       COPY NCPL0520.
      *
025970 COPY NCPS0530.
       COPY NCPL0530.
      *
025970 COPY CCPS0620.
       COPY CCPL0620.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
      *
013578 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
       COPY CCPS5600.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY NCPAAPPF.
      *
       COPY NCPNAPPF.
      *
       COPY NCPUAPPF.
      *
       COPY NCPCAPPF.
      *
016537*COPY NCPXAPPF.
       COPY CCPNEDIT.
      *
       COPY CCPNPCOM.
006002 COPY XCPNCTLC.
      *
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM0540                     **
      *****************************************************************
