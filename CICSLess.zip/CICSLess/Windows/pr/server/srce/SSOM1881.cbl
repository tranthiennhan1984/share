      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM1881.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1881                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE FV TABLE                                 **
      **                                                             **
      **            THE CREATE WILL CREATE ALL UNIT TYPES            **
      **            FOR THE FUND                                     **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1881'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-CREATE         VALUE '1881'.
           05  WS-FNDVL-EFF-DT               PIC X(10).
           05  WS-FNDVL-IDT-NUM              PIC X(07).
           05  WS-FND-NXT-VALN-DT            PIC X(10).
           05  WS-OVRID-SW                   PIC X(01).
               88  WS-OVRID                  VALUE 'Y'.
           05  WS-LAST-FNDVL-EFF-DT          PIC X(10).
           05  WS-FH-LOCKED-SW               PIC X(01).
               88  WS-FH-LOCKED              VALUE 'Y'.
               88  WS-FH-LOCKED-NO           VALUE SPACE.

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1880'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1880'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWFH.
       COPY SCFRFH.

       COPY SCFWFUTP.
       COPY SCFRFUTP.

       COPY SCFWFV.
       COPY SCFWFVAA.
       COPY SCFRFV.

       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWL1670.
       COPY XCWL1680.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1881.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-CREATE.
      *-------------

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               IF  WS-FH-LOCKED
                   PERFORM  FH-3000-UNLOCK
                       THRU FH-3000-UNLOCK-X
                   SET WS-FH-LOCKED-NO   TO TRUE
               END-IF
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE LOW-VALUE                TO WFUTP-KEY.
           MOVE MIR-FND-ID               TO WFUTP-FND-ID.

           MOVE WFUTP-KEY                TO WFUTP-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WFUTP-ENDBR-FND-UNIT-TYP-CD.

           PERFORM  FUTP-1000-BROWSE
               THRU FUTP-1000-BROWSE-X.

           PERFORM  FUTP-2000-READ-NEXT
               THRU FUTP-2000-READ-NEXT-X.

           MOVE RFH-FND-PRIC-STRUCT-CD   TO MIR-FND-PRIC-STRUCT-CD.
           MOVE RFH-FND-TYP-CD           TO MIR-FND-TYP-CD.
           MOVE ZERO                     TO I.

           PERFORM
               UNTIL NOT WFUTP-IO-OK

               IF  MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  2200-CREATE-FV
                       THRU 2200-CREATE-FV-X
               END-IF

               ADD +1                     TO I
               MOVE RFUTP-FND-UNIT-TYP-CD
                 TO MIR-FNDVL-UNIT-TYP-CD-T (I)

               PERFORM  FUTP-2000-READ-NEXT
                   THRU FUTP-2000-READ-NEXT-X

           END-PERFORM.

           PERFORM  FUTP-3000-END-BROWSE
               THRU FUTP-3000-END-BROWSE-X.

           IF  I = ZERO

      *MSG: NO FUND UNIT TYPE RECORDS FOUND. FUND UNIT VALUE
      *     NOT CREATED.
               MOVE 'SS18810009'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WS-FH-LOCKED
                   PERFORM  FH-3000-UNLOCK
                       THRU FH-3000-UNLOCK-X
               END-IF

               GO TO 2000-CREATE-X
           END-IF.


           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  9355-SETUP-FH-AUDIT-INFO
               THRU 9355-SETUP-FH-AUDIT-INFO-X.

           MOVE WS-FND-NXT-VALN-DT     TO RFH-FND-NXT-VALN-DT.

           PERFORM  FH-2000-REWRITE
               THRU FH-2000-REWRITE-X.

           SET WS-FH-LOCKED-NO         TO TRUE.

           PERFORM  9355-SETUP-FH-AUDIT-INFO
               THRU 9355-SETUP-FH-AUDIT-INFO-X.

           PERFORM  FH-1000-READ-TWRK-TS
               THRU FH-1000-READ-TWRK-TS-X.

       2000-CREATE-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-FND-ID
               THRU 2110-EDIT-FND-ID-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2100-VALIDATE-DATA-X
           END-IF.

           PERFORM  2120-EDIT-FNDVL-EFF-DT
               THRU 2120-EDIT-FNDVL-EFF-DT-X.

           PERFORM  2140-EDIT-FV-EXIST
               THRU 2140-EDIT-FV-EXIST-X.

           PERFORM  2130-EDIT-FND-NXT-VALN-DT
               THRU 2130-EDIT-FND-NXT-VALN-DT-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-FND-ID.
      *----------------------------

           MOVE MIR-FND-ID                  TO WFH-FND-ID.

           PERFORM  FH-1000-READ-TWRK-TS
               THRU FH-1000-READ-TWRK-TS-X.
           SET WS-FH-LOCKED-NO          TO TRUE.

           IF  MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  FH-2000-UPDATE-TWRK-TS
                   THRU FH-2000-UPDATE-TWRK-TS-X
               SET WS-FH-LOCKED             TO TRUE
           END-IF.

           IF  WFH-IO-NOT-FOUND
      *MSG: @1 RECORD (@2) NOT FOUND
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                    TO WGLOB-MSG-PARM (1)
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FH-LOCKED-NO          TO TRUE
               GO TO 2110-EDIT-FND-ID-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD = '3'
           AND MIR-RETRN-TS-MISMATCH
      *MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
      *     PROCESS NOT COMPLETE
               MOVE 'XS00000303'            TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                    TO WGLOB-MSG-PARM (1)
               MOVE WFH-FND-ID              TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FH-LOCKED-NO          TO TRUE
               GO TO 2110-EDIT-FND-ID-X
           END-IF.

       2110-EDIT-FND-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-FNDVL-EFF-DT.
      *----------------------------

           MOVE MIR-FNDVL-EFF-DT       TO L1640-EXTERNAL-DATE.

           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID FUND VALUATION DATE
               MOVE 'SS18810001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2120-EDIT-FNDVL-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE    TO WS-FNDVL-EFF-DT.

           MOVE WS-FNDVL-EFF-DT        TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WS-FNDVL-IDT-NUM.

           IF  (RFH-FND-CLOS-DT NOT = WWKDT-ZERO-DT)
           AND (RFH-FND-CLOS-DT NOT > WGLOB-PROCESS-DATE)
      *MSG: THE FUND MUST NOT BE CLOSED
               MOVE 'SS18810002'   TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-FNDVL-EFF-DT NOT = RFH-FND-NXT-VALN-DT
      *MSG: EFFECTIVE DATE MUST EQUAL THE NEXT VALUATION DATE FROM FH
               MOVE 'SS18810003'    TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2120-EDIT-FNDVL-EFF-DT-X.
           EXIT.

      *----------------------------
       2130-EDIT-FND-NXT-VALN-DT.
      *----------------------------

           MOVE MIR-FND-NXT-VALN-DT         TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID NEXT FUND VALUATION DATE
               MOVE 'SS18810004'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2130-EDIT-FND-NXT-VALN-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE   TO WS-FND-NXT-VALN-DT.

           MOVE LOW-VALUES            TO WFVAA-KEY.

           MOVE MIR-FND-ID            TO WFVAA-FND-ID.

           MOVE WFVAA-KEY             TO WFVAA-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WFVAA-ENDBR-FNDVL-IDT-NUM.
           MOVE HIGH-VALUES           TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.

           PERFORM  FVAA-1000-BROWSE
               THRU FVAA-1000-BROWSE-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

           IF  WFVAA-IO-OK
               MOVE RFV-FNDVL-EFF-DT        TO WS-LAST-FNDVL-EFF-DT
           ELSE
               MOVE WWKDT-ZERO-DT           TO WS-LAST-FNDVL-EFF-DT
           END-IF.

           PERFORM  FVAA-3000-END-BROWSE
               THRU FVAA-3000-END-BROWSE-X.

           IF  WS-FND-NXT-VALN-DT <= WS-LAST-FNDVL-EFF-DT
               SET WS-OVRID                 TO TRUE
      *MSG: NEXT VALUATION DATE MUST BE GREATER THAN EFFECTIVE DATE
               MOVE 'SS18810005'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-FND-NXT-VALN-DT <= RFH-PREV-UNIT-ALLOC-DT
               SET WS-OVRID                 TO TRUE
      *MSG: NEXT VALUATION DATE MUST BE GREATER THAN LAST ALLOCATION
      *     DATE
               MOVE 'SS18810006'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE WS-FND-NXT-VALN-DT         TO L1680-INTERNAL-2.
           MOVE WS-FNDVL-EFF-DT            TO L1680-INTERNAL-1.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
           COMPUTE L1680-NUMBER-OF-MONTHS = L1680-NUMBER-OF-MONTHS
                   + (L1680-NUMBER-OF-YEARS * 12).

           IF (L1680-NUMBER-OF-MONTHS > RFH-MAX-VALN-MO-DUR-N)
           OR ((L1680-NUMBER-OF-DAYS > RFH-MAX-VALN-DY-DUR-N) AND
               (L1680-NUMBER-OF-MONTHS = RFH-MAX-VALN-MO-DUR-N))
               SET WS-OVRID                 TO TRUE
      *MSG: TIME BETWEEN VALUATION DATES EXCEEDS MAX. VAL. PERIOD
               MOVE 'SS18810007'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF (L1680-NUMBER-OF-MONTHS < RFH-MIN-VALN-MO-DUR-N)
               OR ((L1680-NUMBER-OF-DAYS < RFH-MIN-VALN-DY-DUR-N)
               AND (L1680-TOTAL-DAYS < RFH-MIN-VALN-DY-DUR-N)
               AND (L1680-NUMBER-OF-MONTHS = RFH-MIN-VALN-MO-DUR-N))
               SET WS-OVRID                 TO TRUE
      *MSG: TIME BETWEEN VAL. DATES IS LESS THAN MIN. VAL. PERIOD
                   MOVE 'SS18810008'        TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
            END-IF

           IF  WS-OVRID
               MOVE 'Y'                     TO MIR-DV-PRCES-OVRID-IND
           END-IF.

       2130-EDIT-FND-NXT-VALN-DT-X.
           EXIT.

      *----------------------------
       2140-EDIT-FV-EXIST.
      *----------------------------

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2140-EDIT-FV-EXIST-X
           END-IF.

           MOVE LOW-VALUES             TO WFVAA-KEY.

           MOVE MIR-FND-ID             TO WFVAA-FND-ID.
           MOVE WS-FNDVL-IDT-NUM       TO WFVAA-FNDVL-IDT-NUM.

           MOVE WFVAA-KEY              TO WFVAA-ENDBR-KEY.
           MOVE HIGH-VALUE             TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.

           PERFORM  FVAA-1000-BROWSE
               THRU FVAA-1000-BROWSE-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

           IF  WFVAA-IO-OK
      *MSG: RECORD @1 ALREADY EXISTS
               MOVE 'XS00000003'            TO WGLOB-MSG-REF-INFO
               MOVE RFV-KEY                 TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  FVAA-3000-END-BROWSE
               THRU FVAA-3000-END-BROWSE-X.

       2140-EDIT-FV-EXIST-X.
           EXIT.

      *----------------------------
       2200-CREATE-FV.
      *----------------------------

           IF  RFUTP-FND-UNIT-END-DT NOT = WWKDT-ZERO-DT
           AND RFUTP-FND-UNIT-END-DT < WS-FNDVL-EFF-DT
               GO TO 2200-CREATE-FV-X
           END-IF.

           PERFORM  FV-1000-CREATE
               THRU FV-1000-CREATE-X.

           MOVE RFUTP-FND-ID                TO WFV-FND-ID.
           MOVE RFUTP-FND-UNIT-TYP-CD       TO WFV-FNDVL-UNIT-TYP-CD.
           MOVE WS-FNDVL-IDT-NUM            TO WFV-FNDVL-IDT-NUM.

           MOVE WS-FNDVL-EFF-DT             TO RFV-FNDVL-EFF-DT.

           PERFORM  FV-1000-WRITE
               THRU FV-1000-WRITE-X.

           PERFORM  9350-SETUP-FV-AUDIT-INFO
               THRU 9350-SETUP-FV-AUDIT-INFO-X.

           MOVE RFV-KEY                     TO WFV-KEY
           ADD +1                           TO WFV-FNDVL-IDT-NUM-N.

           MOVE WFV-KEY                     TO WFV-ENDBR-KEY
           MOVE ALL '9'                     TO WFV-ENDBR-FNDVL-IDT-NUM.

           PERFORM  FV-1000-BROWSE
               THRU FV-1000-BROWSE-X.

           PERFORM  FV-2000-READ-NEXT
               THRU FV-2000-READ-NEXT-X.

           IF  NOT WFV-IO-OK
               PERFORM  FV-3000-END-BROWSE
                   THRU FV-3000-END-BROWSE-X
               GO TO 2200-CREATE-FV-X
           END-IF.

           MOVE RFV-KEY                TO WFV-KEY.
           PERFORM  FV-1000-READ-FOR-UPDATE
               THRU FV-1000-READ-FOR-UPDATE-X.

           MOVE WS-FNDVL-IDT-NUM       TO RFV-PREV-FNDVL-IDT-NUM.

           PERFORM  FV-2000-REWRITE
               THRU FV-2000-REWRITE-X.

           PERFORM  FV-3000-END-BROWSE
               THRU FV-3000-END-BROWSE-X.

       2200-CREATE-FV-X.
           EXIT.

      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           MOVE SPACE                       TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                     TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE         TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------
       9350-SETUP-FV-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  FV-1000-CALL-AUDIT
                   THRU FV-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-FV-AUDIT-INFO-X.
           EXIT.
      /
      *----------------------
       9355-SETUP-FH-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  FH-1000-CALL-AUDIT
                   THRU FH-1000-CALL-AUDIT-X
           END-IF.

       9355-SETUP-FH-AUDIT-INFO-X.
           EXIT.
      /
      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE MIR-OUTPUT-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     MOVE SPACES     TO WWKDT-WORK-FIELDS.
           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  FH
                                '$VAR2'   BY 'FH'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL8090.

       COPY XCPL0260.

025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.

025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
       COPY XCPL1680.

       COPY SCPLFV.

      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPLFH.
       COPY SCPNFH.
       COPY SCPUFH.

       COPY SCPBFUTP.

       COPY SCPBFVAA.
       COPY SCPAFV.
       COPY SCPBFV.
       COPY SCPUFV.
       COPY SCPCFV.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM SSOM1881                        **
      *****************************************************************
