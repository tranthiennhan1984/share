      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM5044.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5044                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE CRTX TABLE                               **
      **                                                             **
      **  DOMAIN :  BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016395**  6.2       CREATE PROGRAM                                   **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *---------------------
       ENVIRONMENT DIVISION.
      *---------------------

      *--------------
       DATA DIVISION.
      *--------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5044'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       COPY XCWEBLCH.
      /

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES                   PIC S9(04) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT       VALUE +20.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                       PIC X(04).
               88  WS-BUS-FCN-LIST                 VALUE '5044'.
           05  WS-SUB                              PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES                   PIC S9(04) BINARY
025970*                                            VALUE 20.
           05  WS-CRTA-SW                          PIC X(01).
               88  WS-USE-CRTA                     VALUE 'Y'.
               88  WS-NO-CRTA                      VALUE 'N'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCRTA.
       COPY CCFWCRTX.
       COPY CCFRCRTX.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5044.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF MIR-SBSDRY-CO-ID NOT = SPACES
               SET WS-USE-CRTA       TO TRUE
           ELSE
               SET WS-NO-CRTA        TO TRUE
           END-IF.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5044'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           IF  MIR-SBSDRY-CO-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES TO MIR-SBSDRY-CO-ID
           END-IF.

           IF  WS-USE-CRTA
               PERFORM  2050-LIST-WITH-SUBCO
                   THRU 2050-LIST-WITH-SUBCO-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  CRTX-1000-BROWSE-PREV
               THRU CRTX-1000-BROWSE-PREV-X.

           PERFORM  CRTX-2000-READ-PREV
               THRU CRTX-2000-READ-PREV-X.

           IF  WCRTX-IO-EOF
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
           END-IF.

           PERFORM  2100-BROWSE-CRTX
               THRU 2100-BROWSE-CRTX-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WCRTX-IO-EOF.

           IF  WCRTX-IO-EOF
               MOVE 'XS00000015' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RCRTX-CRC-TYP-CD        TO MIR-CRC-TYP-CD
               MOVE RCRTX-CRC-ID            TO MIR-CRC-ID
               MOVE RCRTX-CRC-TRXN-DT       TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE     TO MIR-CRC-TRXN-DT
               IF WS-USE-CRTA
                   MOVE RCRTX-SBSDRY-CO-ID  TO MIR-SBSDRY-CO-ID
               END-IF
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                       RCRTX-CRC-TRXN-SEQ-NUM   * 1
020874         MOVE RCRTX-CRC-TRXN-SEQ-NUM  TO L0290-INPUT-V00
               MOVE 0                       TO L0290-PRECISION
               MOVE LENGTH OF MIR-CRC-TRXN-SEQ-NUM
                                            TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA     TO MIR-CRC-TRXN-SEQ-NUM
           END-IF.

           PERFORM  CRTX-3000-END-BROWSE-PREV
               THRU CRTX-3000-END-BROWSE-PREV-X.

       2000-LIST-X.
           EXIT.

      /
      *---------------------
       2050-LIST-WITH-SUBCO.
      *---------------------

           PERFORM  7050-BUILD-KEYS-WITH-SUBCO
               THRU 7050-BUILD-KEYS-WITH-SUBCO-X.

           PERFORM  CRTA-1000-BROWSE-PREV
               THRU CRTA-1000-BROWSE-PREV-X.

           PERFORM  CRTA-2000-READ-PREV
               THRU CRTA-2000-READ-PREV-X.

           IF  WCRTA-IO-EOF
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
           END-IF.

           PERFORM  2100-BROWSE-CRTX
               THRU 2100-BROWSE-CRTX-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WCRTA-IO-EOF.

           IF  WCRTA-IO-EOF
               CONTINUE
           ELSE
               MOVE 'XS00000014'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE
               MOVE RCRTX-CRC-TYP-CD       TO MIR-CRC-TYP-CD
               MOVE RCRTX-CRC-ID           TO MIR-CRC-ID
               MOVE RCRTX-CRC-TRXN-DT      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE    TO MIR-CRC-TRXN-DT
               MOVE RCRTX-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                       RCRTX-CRC-TRXN-SEQ-NUM   * 1
020874         MOVE RCRTX-CRC-TRXN-SEQ-NUM  TO L0290-INPUT-V00
               MOVE 0                      TO L0290-PRECISION
               MOVE LENGTH OF MIR-CRC-TRXN-SEQ-NUM
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA      TO MIR-CRC-TRXN-SEQ-NUM
           END-IF.

           PERFORM  CRTA-3000-END-BROWSE-PREV
               THRU CRTA-3000-END-BROWSE-PREV-X.

       2050-LIST-WITH-SUBCO-X.
           EXIT.
      /
      *-----------------
       2100-BROWSE-CRTX.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF  WS-NO-CRTA
               PERFORM  CRTX-2000-READ-PREV
                   THRU CRTX-2000-READ-PREV-X
           ELSE
               PERFORM  CRTA-2000-READ-PREV
                   THRU CRTA-2000-READ-PREV-X
           END-IF.


       2100-BROWSE-CRTX-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES            TO WCRTX-KEY.
           MOVE MIR-CRC-TYP-CD        TO WCRTX-CRC-TYP-CD.
           MOVE MIR-CRC-ID            TO WCRTX-CRC-ID.

           IF  MIR-CRC-TRXN-DT = SPACES
               MOVE WWKDT-HIGH-DT     TO WCRTX-CRC-TRXN-DT
           ELSE
               MOVE MIR-CRC-TRXN-DT   TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X                   
               IF  L1640-NOT-VALID
      * MSG - DATE (@1) INVALID
                   MOVE WWKDT-HIGH-DT  TO WCRTX-CRC-TRXN-DT
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CRC-TRXN-DT
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO WCRTX-CRC-TRXN-DT
               END-IF
           END-IF.

           IF MIR-CRC-TRXN-SEQ-NUM = SPACES
               MOVE 999               TO MIR-CRC-TRXN-SEQ-NUM
           END-IF.

           MOVE MIR-CRC-TRXN-SEQ-NUM  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE 4                     TO L0280-LENGTH.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WCRTX-CRC-TRXN-SEQ-NUM
           ELSE
      * MSG: 'INVALID NUMERIC FIELD'
               MOVE 'XS00000018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE ZERO              TO WCRTX-CRC-TRXN-SEQ-NUM
           END-IF.

           MOVE WCRTX-KEY             TO WCRTX-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WCRTX-ENDBR-CRC-TRXN-DT.
           MOVE +001                  TO WCRTX-ENDBR-CRC-TRXN-SEQ-NUM.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *---------------------------
       7050-BUILD-KEYS-WITH-SUBCO.
      *---------------------------

           MOVE LOW-VALUES            TO WCRTA-KEY.
           MOVE MIR-CRC-TYP-CD        TO WCRTA-CRC-TYP-CD.
           MOVE MIR-CRC-ID            TO WCRTA-CRC-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WCRTA-SBSDRY-CO-ID.

           IF  MIR-CRC-TRXN-DT = SPACES
               MOVE WWKDT-HIGH-DT     TO WCRTA-CRC-TRXN-DT
           ELSE
               MOVE MIR-CRC-TRXN-DT   TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X                   
               IF  L1640-NOT-VALID
      * MSG - DATE (@1) INVALID
                   MOVE WWKDT-HIGH-DT TO WCRTA-CRC-TRXN-DT
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CRC-TRXN-DT   TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO WCRTA-CRC-TRXN-DT
               END-IF
           END-IF.

           IF MIR-CRC-TRXN-SEQ-NUM = SPACES
               MOVE 999               TO MIR-CRC-TRXN-SEQ-NUM
           END-IF.

           MOVE MIR-CRC-TRXN-SEQ-NUM  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE 4                     TO L0280-LENGTH.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WCRTA-CRC-TRXN-SEQ-NUM
           ELSE
      * MSG: 'INVALID NUMERIC FIELD'
               MOVE 'XS00000018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 999               TO WCRTA-CRC-TRXN-SEQ-NUM
           END-IF.

           MOVE WCRTA-KEY             TO WCRTA-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WCRTA-ENDBR-CRC-TRXN-DT.
           MOVE +001                  TO WCRTA-ENDBR-CRC-TRXN-SEQ-NUM.

       7050-BUILD-KEYS-WITH-SUBCO-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-CRC-TYP-CD-G.
           MOVE SPACES                 TO MIR-CRC-ID-G.
           MOVE SPACES                 TO MIR-CRC-TRXN-DT-G.
           MOVE SPACES                 TO MIR-CRC-TRXN-SEQ-NUM-G.
           MOVE SPACES                 TO MIR-CRC-TRXN-AMT-G.
           MOVE SPACES                 TO MIR-CRC-TRXN-STAT-CD-G.
           MOVE SPACES                 TO MIR-SBSDRY-CO-ID-G.
           MOVE SPACES                 TO MIR-CRC-TRXN-REVRS-CD-G.
           MOVE SPACES                 TO MIR-CRC-TRXN-CRCY-CD-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RCRTX-CRC-TYP-CD      TO MIR-CRC-TYP-CD-T (WS-SUB).
           MOVE RCRTX-CRC-ID          TO MIR-CRC-ID-T (WS-SUB).
           MOVE RCRTX-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T (WS-SUB).

           MOVE RCRTX-CRC-TRXN-DT     TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CRC-TRXN-DT-T (WS-SUB).

           MOVE RCRTX-CRC-TRXN-STAT-CD
             TO MIR-CRC-TRXN-STAT-CD-T  (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCRTX-CRC-TRXN-SEQ-NUM   * 1.
020874     MOVE RCRTX-CRC-TRXN-SEQ-NUM  TO L0290-INPUT-V00.
           MOVE 0                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-TRXN-SEQ-NUM-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-CRC-TRXN-SEQ-NUM-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCRTX-CRC-TRXN-AMT   * 100.
020874     MOVE RCRTX-CRC-TRXN-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-TRXN-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-CRC-TRXN-AMT-T (WS-SUB).

           MOVE RCRTX-CRC-TRXN-REVRS-CD
             TO MIR-CRC-TRXN-REVRS-CD-T  (WS-SUB).

           MOVE RCRTX-CRC-TRXN-CRCY-CD
             TO MIR-CRC-TRXN-CRCY-CD-T  (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                     TO WWKDT-WORK-FIELDS.
025970     SET WS-MAX-LIST-LINES-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPVCRTA.
       COPY CCPVCRTX.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM5044                      *
      *****************************************************************

