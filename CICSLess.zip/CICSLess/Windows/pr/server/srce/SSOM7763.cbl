      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM7763.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM7763                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE FUTP TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM7763'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-DELETE            VALUE '7763'.

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                      PIC X(04) VALUE '7760'.
025970     05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '7760'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFRFH.
       COPY SCFWFH.
      /
       COPY SCFRFV.
       COPY SCFWFV.
      /
       COPY SCFWFUTP.
       COPY SCFRFUTP.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL8090.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM7763.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM7763'       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-DELETE.
      *------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.


           MOVE WFUTP-FND-ID          TO WFH-FND-ID.
           PERFORM FH-2000-UPDATE-TWRK-TS
              THRU FH-2000-UPDATE-TWRK-TS-X.

           IF  WFH-IO-NOT-FOUND
      *MSG: 'RECORD (@1) NOT FOUND'
               MOVE WFH-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
               MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                  TO WGLOB-MSG-PARM (01)
               MOVE WFH-KEY               TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-DELETE-X
           END-IF

           PERFORM  FUTP-1000-READ-FOR-UPDATE
               THRU FUTP-1000-READ-FOR-UPDATE-X

           IF  NOT WFUTP-IO-OK
               PERFORM FH-3000-UNLOCK
                  THRU FH-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WFUTP-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  FH-3000-UNLOCK
                   THRU FH-3000-UNLOCK-X
               PERFORM  FUTP-3000-UNLOCK
                   THRU FUTP-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  FUTP-1000-DELETE
               THRU FUTP-1000-DELETE-X.

           IF  WFUTP-IO-OK
               PERFORM  9350-SETUP-AUDIT-INFO
                   THRU 9350-SETUP-AUDIT-INFO-X
               PERFORM  FH-2000-REWRITE
                   THRU FH-2000-REWRITE-X
               PERFORM  FH-1000-READ-TWRK-TS
                   THRU FH-1000-READ-TWRK-TS-X
           ELSE
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WFUTP-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               PERFORM  FH-3000-UNLOCK
                   THRU FH-3000-UNLOCK-X
           END-IF.



       2000-DELETE-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-CHECK-FV-EXIST
               THRU 2110-CHECK-FV-EXIST-X.

           PERFORM  2120-CHECK-FND-UNIT-QTY
               THRU 2120-CHECK-FND-UNIT-QTY-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-CHECK-FV-EXIST.
      *----------------------------

           MOVE LOW-VALUES             TO WFV-KEY.
           MOVE RFUTP-FND-ID           TO WFV-FND-ID.
           MOVE RFUTP-FND-UNIT-TYP-CD  TO WFV-FNDVL-UNIT-TYP-CD.

           MOVE WFV-KEY                TO WFV-ENDBR-KEY.
           MOVE HIGH-VALUE             TO WFV-ENDBR-FNDVL-IDT-NUM.

           PERFORM  FV-1000-BROWSE
               THRU FV-1000-BROWSE-X.

           PERFORM  FV-2000-READ-NEXT
               THRU FV-2000-READ-NEXT-X.

           IF  WFV-IO-OK
      *MSG: CANNOT DELETE (@1), FUND PRICE EXISTS
               MOVE 'SS77630001'      TO WGLOB-MSG-REF-INFO
               MOVE WFUTP-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
           END-IF.

           PERFORM  FV-3000-END-BROWSE
               THRU FV-3000-END-BROWSE-X.

       2110-CHECK-FV-EXIST-X.
           EXIT.

      *----------------------------
       2120-CHECK-FND-UNIT-QTY.
      *----------------------------

           IF  RFUTP-FND-UNIT-QTY NOT = ZERO
      *MSG: CANNOT DELETE (@1), FUND HAS UNITS
               MOVE 'SS77630002'      TO WGLOB-MSG-REF-INFO
               MOVE WFUTP-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
           END-IF.

       2120-CHECK-FND-UNIT-QTY-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-FND-ID           TO WFUTP-FND-ID.
           MOVE MIR-FND-UNIT-TYP-CD  TO WFUTP-FND-UNIT-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES              TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE  TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  FUTP-1000-CALL-AUDIT
                   THRU FUTP-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY FH
                                '$VAR2'   BY 'FH'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
       COPY XCPL8090.
       COPY SCPLFUTP.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNFH.
       COPY SCPUFH.
       COPY SCPUFUTP.
       COPY SCPXFUTP.
       COPY SCPBFV.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM XSOM7323                     **
      *****************************************************************
