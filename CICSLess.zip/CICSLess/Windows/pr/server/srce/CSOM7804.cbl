      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM7804.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7804                                         **
      **  REMARKS:  EFTX BY CLIENT ID                                **
      **  DOMAIN :  AC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018764**  6.3       LINKAGE ENHANCEMENT                              **
018731**  6.3       EFT ENHANCEMENTS                                 **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
028789**  6.7       EXTERNAL AGENCY INTEGRATION - REAL TIME INFO.    **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7804'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

021930*COPY XCWLDTLK.

       COPY XCWWWKDT.
036742 COPY XCWWCNST.       

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-LIST                     VALUE '7804'.
025970*    05  WS-MAX-SCREEN-LINES          PIC 999 VALUE 100.
           05  WS-SUB-7804                  PIC 999.
           05  WS-SUB                       PIC 999.
036742     05  WS-TRXN-GEN-ID               PIC 9(10).
036742*    05  WS-CLI-ID                    PIC X(10).
036742*    05  WS-EFT-IDT-NUM               PIC 9(07).
036742*    05  WS-EFT-TS                    PIC X(10).
036742*    05  WS-USER-ID                   PIC X(08).
036742*    05  WS-EFT-INSTC-ID              PIC X(10).
018633*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '7804'.
018633*    05  WS-TWRK-AREA.
018633*        10 WS-TWRK-WEFTA-KEY-AREA.
018633*           15 WS-TWRK-WEFTA-CO-ID               PIC X(02).
018633*           15 WS-TWRK-WEFTA-CLI-ID              PIC X(10).
018633*           15 WS-TWRK-WEFTA-TRXN-IDT-NUM        PIC X(07).
018633*           15 WS-TWRK-WEFTA-TRXN-IDT-NUM-N      REDEFINES
018633*              WS-TWRK-WEFTA-TRXN-IDT-NUM        PIC 9(07).
018633*           15 WS-TWRK-WEFTA-EFT-TRXN-TS         PIC X(26).
018633*           15 WS-TWRK-WEFTA-USER-ID             PIC X(08).
018633*           15 WS-TWRK-WEFTA-TRXN-INSTC-ID       PIC S9(04)
018633*                                                   BINARY.
018633*        10 WS-TWRK-WEFTF-KEY-AREA-X             REDEFINES
018633*           WS-TWRK-WEFTA-KEY-AREA.
018633*           15 WS-TWRK-WEFTF-CO-ID               PIC X(02).
018633*           15 FILLER                            PIC X(10).
018633*           15 WS-TWRK-WEFTF-TRXN-IDT-NUM        PIC X(07).
018633*           15 WS-TWRK-WEFTF-TRXN-IDT-NUM-N      REDEFINES
018633*              WS-TWRK-WEFTF-TRXN-IDT-NUM        PIC 9(07).
018633*           15 WS-TWRK-WEFTF-EFT-TRXN-TS         PIC X(26).
018633*           15 WS-TWRK-WEFTF-USER-ID             PIC X(08).
018633*           15 WS-TWRK-WEFTF-TRXN-INSTC-ID       PIC S9(04)
018633*                                                   BINARY.
018633*        10 WS-TWRK-MORE-EFTF-SW                 PIC X(01)
018633*                                                VALUE 'N'.
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '7804'.
018633         15 LCOMM-WEFTA-KEY-AREA.
018633            20 LCOMM-WEFTA-CO-ID                 PIC X(02).
018633            20 LCOMM-WEFTA-CLI-ID                PIC X(10).
018633            20 LCOMM-WEFTA-TRXN-IDT-NUM          PIC X(07).
018633            20 LCOMM-WEFTA-TRXN-IDT-NUM-N        REDEFINES
018633               LCOMM-WEFTA-TRXN-IDT-NUM          PIC 9(07).
036742*           20 LCOMM-WEFTA-EFT-TRXN-TS           PIC X(26).
036742*           20 LCOMM-WEFTA-USER-ID               PIC X(08).
036742*           20 LCOMM-WEFTA-TRXN-INSTC-ID         PIC S9(04)
036742*                                                   BINARY.
036742            20 LCOMM-WEFTA-TRXN-GEN-ID           PIC S9(09).
018633         15 LCOMM-WEFTF-KEY-AREA-X               REDEFINES
018633            LCOMM-WEFTA-KEY-AREA.
018633            20 LCOMM-WEFTF-CO-ID                 PIC X(02).
018633            20 FILLER                            PIC X(10).
018633            20 LCOMM-WEFTF-TRXN-IDT-NUM          PIC X(07).
018633            20 LCOMM-WEFTF-TRXN-IDT-NUM-N        REDEFINES
018633               LCOMM-WEFTF-TRXN-IDT-NUM          PIC 9(07).
036742*           20 LCOMM-WEFTF-EFT-TRXN-TS           PIC X(26).
036742*           20 LCOMM-WEFTF-USER-ID               PIC X(08).
036742*           20 LCOMM-WEFTF-TRXN-INSTC-ID         PIC S9(04)
036742*                                                   BINARY.
036742            20 LCOMM-WEFTF-TRXN-GEN-ID           PIC S9(09).

018633         10 LCOMM-MORE-EFTF-SW                   PIC X(01)
018633                                                 VALUE 'N'.
018633
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-SCREEN-LINES                     PIC 999.
025970         88  WS-MAX-SCREEN-LINES-DEFAULT         VALUE 100.

028789 COPY CCWLACCT.
028789 COPY CCWL2110.
028298 COPY CCWL2626.
       COPY XCWL0290.

       COPY XCWL8090.

       COPY CCFREFTX.
021930*COPY CCFWEFTX.

       COPY CCFWEFTA.

       COPY CCFWEFTF.
      *
       COPY CCWLPGA.
      *
028789 COPY CCFRPOL.
028789 COPY CCWWCVGS.
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7804.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

025970*    MOVE SPACES                TO LPGA-PARM-INFO.
025970*    INITIALIZE LPGA-PARM-INFO.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3000-PROCESS-LIST
                       THRU 3000-PROCESS-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7804'   TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *------------------
       3000-PROCESS-LIST.
      *------------------

           PERFORM  3100-CLEAR-SCREEN
               THRU 3100-CLEAR-SCREEN-X
            VARYING WS-SUB-7804 FROM 1 BY 1
                UNTIL WS-SUB-7804 > WS-MAX-SCREEN-LINES.

           PERFORM  3200-PROCESSING
               THRU 3200-PROCESSING-X.

028789     PERFORM  2110-0000-INIT-PARM-INFO
028789         THRU 2110-0000-INIT-PARM-INFO-X.
028789     PERFORM  2110-3000-LOCATE-AGT-PMT
028789         THRU 2110-3000-LOCATE-AGT-PMT-X.
028789     MOVE L2110-AGT-COMM-SYS-IND   TO MIR-DV-XTRNL-AGT-INQ-IND.
028789
       3000-PROCESS-LIST-X.
           EXIT.

      *------------------
       3100-CLEAR-SCREEN.
      *------------------

           MOVE SPACES      TO MIR-BNK-ACCT-HLDR-NM-T (WS-SUB-7804).
           MOVE SPACES      TO MIR-BNK-ID-T           (WS-SUB-7804).
           MOVE SPACES      TO MIR-BNK-BR-ID-T        (WS-SUB-7804).
           MOVE SPACES      TO MIR-BNK-ACCT-ID-T      (WS-SUB-7804).
           MOVE SPACES      TO MIR-BNK-ACCT-TYP-CD-T  (WS-SUB-7804).
           MOVE SPACES      TO MIR-EFT-TRXN-EFF-DT-T  (WS-SUB-7804).
           MOVE SPACES      TO MIR-EFT-TRXN-AMT-T     (WS-SUB-7804).
           MOVE SPACES      TO MIR-CLI-ID-T           (WS-SUB-7804).
           MOVE SPACES      TO MIR-AGT-ID-T           (WS-SUB-7804).
           MOVE SPACES      TO MIR-POL-ID-T           (WS-SUB-7804).
           MOVE SPACES      TO MIR-SBSDRY-CO-ID-T     (WS-SUB-7804).
           MOVE SPACES      TO MIR-EFT-TRXN-STAT-CD-T (WS-SUB-7804).           

       3100-CLEAR-SCREEN-X.
           EXIT.

      *----------------
       3200-PROCESSING.
      *----------------

036742     MOVE  MIR-EFT-TRXN-GEN-ID    TO WS-TRXN-GEN-ID.           
           PERFORM  9000-BUILD-EFTA-BROWSE-KEY
               THRU 9000-BUILD-EFTA-BROWSE-KEY-X.

           PERFORM  EFTA-1000-BROWSE
               THRU EFTA-1000-BROWSE-X.

           IF  WEFTA-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3200-PROCESSING-X
           END-IF.

           PERFORM  EFTA-2000-READ-NEXT
               THRU EFTA-2000-READ-NEXT-X.

           IF  WEFTA-IO-EOF
               IF  MIR-CLI-ID = SPACES
                   PERFORM  4000-BROWSE-EFTF
                       THRU 4000-BROWSE-EFTF-X
               ELSE
                   MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
               GO TO 3200-PROCESSING-X
           END-IF.

           PERFORM  3210-BUILD-LIST-SCREEN
               THRU 3210-BUILD-LIST-SCREEN-X
               VARYING WS-SUB-7804 FROM 1 BY 1
               UNTIL   WS-SUB-7804 > WS-MAX-SCREEN-LINES
                  OR   WEFTA-IO-EOF.

           IF  WEFTA-IO-EOF
      * MSG: INQUIRE COMPLETE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
           ELSE
      * MSG: HIT ENTER TO VIEW MORE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               MOVE REFTX-CLI-ID            TO MIR-CLI-ID
018633*                              WS-TWRK-WEFTA-CLI-ID
018633                               LCOMM-WEFTA-CLI-ID
               MOVE REFTX-EFT-TRXN-IDT-NUM  TO MIR-EFT-TRXN-IDT-NUM
018633*                              WS-TWRK-WEFTA-TRXN-IDT-NUM
018633                               LCOMM-WEFTA-TRXN-IDT-NUM
036742*        MOVE REFTX-EFT-TRXN-TS       TO MIR-EFT-TRXN-TS
018633*                              WS-TWRK-WEFTA-EFT-TRXN-TS
036742*                              LCOMM-WEFTA-EFT-TRXN-TS

036742         MOVE REFTX-EFT-TRXN-GEN-ID TO WS-TRXN-GEN-ID
036742         MOVE  WS-TRXN-GEN-ID       TO L0290-INPUT-V00
036742         MOVE  +0                   TO L0290-PRECISION
036742         MOVE LENGTH OF MIR-EFT-TRXN-GEN-ID
036742                                    TO L0290-MAX-OUT-LEN
036742         SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE
036742         SET L0290-SIGN-SUPPRESS       TO TRUE
036742         PERFORM  0290-2000-FORMAT-FOR-MIR
036742             THRU 0290-2000-FORMAT-FOR-MIR-X
036742         MOVE L0290-OUTPUT-DATA     TO MIR-EFT-TRXN-GEN-ID
036742
036742         MOVE REFTX-EFT-TRXN-GEN-ID TO
036742                                   LCOMM-WEFTA-TRXN-GEN-ID
               SET  WGLOB-MORE-DATA-EXISTS  TO TRUE
018633*        MOVE WS-TWRK-AREA            TO L8090-AREA-INFO-TEXT

018633*        PERFORM  9800-WRITE-TWRK
018633*            THRU 9800-WRITE-TWRK-X
018633         PERFORM  COMM-2000-WRITE-TWRK
018633             THRU COMM-2000-WRITE-TWRK-X
018633*        INITIALIZE WS-TWRK-AREA
018633*        MOVE 'N' TO WS-TWRK-MORE-EFTF-SW
018633         INITIALIZE LCOMM-WORK-AREA
018633         MOVE 'N' TO LCOMM-MORE-EFTF-SW
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  EFTA-3000-END-BROWSE
               THRU EFTA-3000-END-BROWSE-X.

       3200-PROCESSING-X.
           EXIT.

      *-----------------------
       3210-BUILD-LIST-SCREEN.
      *-----------------------

           PERFORM  8000-MOVE-EFTX-TO-LIST-ROW
               THRU 8000-MOVE-EFTX-TO-LIST-ROW-X.

           PERFORM  EFTA-2000-READ-NEXT
               THRU EFTA-2000-READ-NEXT-X.

       3210-BUILD-LIST-SCREEN-X.
             EXIT.

      *-----------------
       4000-BROWSE-EFTF.
      *-----------------

           PERFORM  9100-BUILD-EFTF-BROWSE-KEY
               THRU 9100-BUILD-EFTF-BROWSE-KEY-X.

           PERFORM  EFTF-1000-BROWSE
               THRU EFTF-1000-BROWSE-X.

           IF  WEFTF-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-BROWSE-EFTF-X
           END-IF.

           PERFORM  EFTF-2000-READ-NEXT
               THRU EFTF-2000-READ-NEXT-X.

           IF  WEFTF-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-BROWSE-EFTF-X
           END-IF.

           PERFORM  4100-BUILD-LIST-SCREEN
               THRU 4100-BUILD-LIST-SCREEN-X
               VARYING WS-SUB-7804 FROM 1 BY 1
               UNTIL   WS-SUB-7804 > WS-MAX-SCREEN-LINES
                  OR   WEFTF-IO-EOF.

           IF  WEFTF-IO-EOF
      * MSG: INQUIRE COMPLETE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
           ELSE
      * MSG: HIT ENTER TO VIEW MORE
               MOVE 'XS00000014'           TO WGLOB-MSG-REF-INFO
018633*        MOVE 'Y'                    TO WS-TWRK-MORE-EFTF-SW
018633         MOVE 'Y'                    TO LCOMM-MORE-EFTF-SW
               MOVE SPACES                 TO MIR-CLI-ID
               MOVE REFTX-EFT-TRXN-IDT-NUM TO MIR-EFT-TRXN-IDT-NUM
018633*                             WS-TWRK-WEFTF-TRXN-IDT-NUM
018633                              LCOMM-WEFTF-TRXN-IDT-NUM
036742*        MOVE REFTX-EFT-TRXN-TS      TO MIR-EFT-TRXN-TS
018633*                             WS-TWRK-WEFTF-EFT-TRXN-TS
036742*                             LCOMM-WEFTF-EFT-TRXN-TS
036742
036742         MOVE REFTX-EFT-TRXN-GEN-ID TO WS-TRXN-GEN-ID
036742         MOVE  WS-TRXN-GEN-ID       TO L0290-INPUT-V00
036742         MOVE  +0                   TO L0290-PRECISION
036742         MOVE LENGTH OF MIR-EFT-TRXN-GEN-ID
036742                                    TO L0290-MAX-OUT-LEN
036742         SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE
036742         SET L0290-SIGN-SUPPRESS       TO TRUE
036742         PERFORM  0290-2000-FORMAT-FOR-MIR
036742             THRU 0290-2000-FORMAT-FOR-MIR-X
036742         MOVE L0290-OUTPUT-DATA     TO MIR-EFT-TRXN-GEN-ID
036742
036742         MOVE REFTX-EFT-TRXN-GEN-ID TO
036742                                   LCOMM-WEFTF-TRXN-GEN-ID
               SET  WGLOB-MORE-DATA-EXISTS TO TRUE
018633*        MOVE WS-TWRK-AREA            TO L8090-AREA-INFO-TEXT

018633*        PERFORM  9800-WRITE-TWRK
018633*            THRU 9800-WRITE-TWRK-X
018633         PERFORM  COMM-2000-WRITE-TWRK
018633             THRU COMM-2000-WRITE-TWRK-X
018633*        INITIALIZE WS-TWRK-AREA
018633*        MOVE 'N' TO WS-TWRK-MORE-EFTF-SW
018633         INITIALIZE LCOMM-WORK-AREA
018633         MOVE 'N' TO LCOMM-MORE-EFTF-SW
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  EFTF-3000-END-BROWSE
               THRU EFTF-3000-END-BROWSE-X.

       4000-BROWSE-EFTF-X.
           EXIT.

      *-----------------------
       4100-BUILD-LIST-SCREEN.
      *-----------------------

           PERFORM  8000-MOVE-EFTX-TO-LIST-ROW
               THRU 8000-MOVE-EFTX-TO-LIST-ROW-X.

           PERFORM  EFTF-2000-READ-NEXT
               THRU EFTF-2000-READ-NEXT-X.

       4100-BUILD-LIST-SCREEN-X.
           EXIT.

      *---------------------------
       8000-MOVE-EFTX-TO-LIST-ROW.
      *---------------------------

           MOVE REFTX-BNK-ACCT-HLDR-NM
                               TO MIR-BNK-ACCT-HLDR-NM-T (WS-SUB-7804).
           MOVE REFTX-BNK-ID       TO MIR-BNK-ID-T (WS-SUB-7804).
           MOVE REFTX-BNK-BR-ID    TO MIR-BNK-BR-ID-T (WS-SUB-7804).
           MOVE REFTX-BNK-ACCT-ID TO MIR-BNK-ACCT-ID-T (WS-SUB-7804).
           MOVE REFTX-BNK-ACCT-TYP-CD
                                TO MIR-BNK-ACCT-TYP-CD-T (WS-SUB-7804).
           MOVE REFTX-EFT-TRXN-EFF-DT
                                TO MIR-EFT-TRXN-EFF-DT-T (WS-SUB-7804).

020874*    COMPUTE L0290-INPUT-NUMBER = REFTX-EFT-TRXN-AMT * 100.
020874     MOVE REFTX-EFT-TRXN-AMT TO L0290-INPUT-V02.
           MOVE 2                  TO L0290-PRECISION.
           MOVE LENGTH OF MIR-EFT-TRXN-AMT-T (WS-SUB-7804)
                                   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA  TO MIR-EFT-TRXN-AMT-T (WS-SUB-7804).

           MOVE REFTX-CLI-ID       TO MIR-CLI-ID-T (WS-SUB-7804).
           MOVE REFTX-AGT-ID       TO MIR-AGT-ID-T (WS-SUB-7804).
           MOVE REFTX-POL-ID       TO MIR-POL-ID-T (WS-SUB-7804).
           MOVE REFTX-SBSDRY-CO-ID TO MIR-SBSDRY-CO-ID-T (WS-SUB-7804).
           MOVE REFTX-EFT-TRXN-STAT-CD
                               TO MIR-EFT-TRXN-STAT-CD-T (WS-SUB-7804).

       8000-MOVE-EFTX-TO-LIST-ROW-X.
           EXIT.

      *---------------------------
       9000-BUILD-EFTA-BROWSE-KEY.
      *---------------------------

018633*    PERFORM 9700-RETRIEVE-TWRK
018633*       THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM COMM-1000-RETRIEVE-TWRK
018633        THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF  L8090-RETRN-OK
018633     IF  LCOMM-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT TO WS-TWRK-AREA
018633         CONTINUE
           ELSE
018633*        MOVE SPACE                TO WS-TWRK-AREA
018633*        MOVE 'N'                  TO WS-TWRK-MORE-EFTF-SW
018633         MOVE SPACE                TO LCOMM-WORK-AREA
018633         MOVE 'N'                  TO LCOMM-MORE-EFTF-SW
           END-IF.

018633*    IF WS-TWRK-MORE-EFTF-SW = 'N'
018633     IF LCOMM-MORE-EFTF-SW = 'N'
018633*       PERFORM  9900-DELETE-TWRK
018633*           THRU 9900-DELETE-TWRK-X
018633        PERFORM  COMM-3000-DELETE-TWRK
018633            THRU COMM-3000-DELETE-TWRK-X
           END-IF.

           MOVE LOW-VALUES               TO WEFTA-KEY.
036742*    MOVE ZEROS                    TO WEFTA-EFT-TRXN-INSTC-ID.
036742     MOVE ZEROS                    TO WEFTA-EFT-TRXN-GEN-ID.
           MOVE MIR-CLI-ID               TO WEFTA-CLI-ID.

036742*    IF  MIR-CLI-ID = SPACES
018633*    AND (WS-TWRK-AREA = SPACE OR LOW-VALUES)
036742*    AND (LCOMM-WORK-AREA = SPACE OR LOW-VALUES)
036742*       MOVE "0000000"            TO WEFTA-EFT-TRXN-IDT-NUM
036742*       MOVE "0001-01-01-00.00.00.000000"
036742*                                 TO WEFTA-EFT-TRXN-TS
036742*    ELSE
018633*        IF  MIR-CLI-ID           =  WS-TWRK-WEFTA-CLI-ID
036742*        IF  MIR-CLI-ID           =  LCOMM-WEFTA-CLI-ID
036742*        AND MIR-EFT-TRXN-IDT-NUM =
018633*                           WS-TWRK-WEFTA-TRXN-IDT-NUM
018633*        AND MIR-EFT-TRXN-TS      =  WS-TWRK-WEFTA-EFT-TRXN-TS
036742*                           LCOMM-WEFTA-TRXN-IDT-NUM
036742*        AND MIR-EFT-TRXN-TS      =  LCOMM-WEFTA-EFT-TRXN-TS
036742*            MOVE MIR-EFT-TRXN-IDT-NUM
036742*                                 TO WEFTA-EFT-TRXN-IDT-NUM
036742*            MOVE MIR-EFT-TRXN-TS TO WEFTA-EFT-TRXN-TS
036742*        ELSE
018633*            IF  MIR-CLI-ID           NOT =  WS-TWRK-WEFTA-CLI-ID
036742*            IF  MIR-CLI-ID           NOT =  LCOMM-WEFTA-CLI-ID
036742*            OR  MIR-EFT-TRXN-IDT-NUM NOT =
018633*                                  WS-TWRK-WEFTA-TRXN-IDT-NUM
036742*                                  LCOMM-WEFTA-TRXN-IDT-NUM
036742*            OR  MIR-EFT-TRXN-TS      NOT =
018633*                                   WS-TWRK-WEFTA-EFT-TRXN-TS
036742*                             LCOMM-WEFTA-EFT-TRXN-TS
036742*                MOVE "0000000"  TO WEFTA-EFT-TRXN-IDT-NUM
036742*                MOVE "0001-01-01-00.00.00.000000"
036742*                                TO WEFTA-EFT-TRXN-TS
036742*            END-IF
036742*        END-IF
036742*     END-IF.
036742            
036742     IF  MIR-CLI-ID = SPACES
036742     AND (LCOMM-WORK-AREA = SPACE OR LOW-VALUES)
036742        MOVE "0000000"            TO WEFTA-EFT-TRXN-IDT-NUM
036742
036742        MOVE ZEROS                TO WEFTA-EFT-TRXN-GEN-ID
036742     ELSE
036742         IF  MIR-CLI-ID           =  LCOMM-WEFTA-CLI-ID
036742         AND MIR-EFT-TRXN-IDT-NUM =
036742                                   LCOMM-WEFTA-TRXN-IDT-NUM
036742
036742         AND WS-TRXN-GEN-ID  =  LCOMM-WEFTA-TRXN-GEN-ID
036742             MOVE MIR-EFT-TRXN-IDT-NUM
036742                                  TO WEFTA-EFT-TRXN-IDT-NUM
036742
036742             MOVE WS-TRXN-GEN-ID  TO WEFTA-EFT-TRXN-GEN-ID
036742         ELSE
036742             IF  MIR-CLI-ID           NOT =  LCOMM-WEFTA-CLI-ID
036742             OR  MIR-EFT-TRXN-IDT-NUM NOT =
036742                                     LCOMM-WEFTA-TRXN-IDT-NUM
036742
036742             OR  WS-TRXN-GEN-ID       NOT = 
036742                                     LCOMM-WEFTA-TRXN-GEN-ID
036742                 MOVE "0000000"   TO WEFTA-EFT-TRXN-IDT-NUM
036742
036742                 MOVE ZEROS       TO WEFTA-EFT-TRXN-GEN-ID
036742             END-IF
036742         END-IF
036742      END-IF.            

           MOVE HIGH-VALUES          TO WEFTA-ENDBR-KEY.
036742*    MOVE WWKDT-HIGH-TS        TO WEFTA-ENDBR-EFT-TRXN-TS.
036742*    MOVE ALL '9'              TO WEFTA-ENDBR-EFT-TRXN-INSTC-ID.
036742     MOVE WCNST-MAX-EFT-TRXN-GEN-ID-N  
036742                               TO WEFTA-ENDBR-EFT-TRXN-GEN-ID.

018633*    INITIALIZE WS-TWRK-AREA.
018633*    MOVE 'N' TO WS-TWRK-MORE-EFTF-SW.
018633     INITIALIZE LCOMM-WORK-AREA
018633     MOVE 'N' TO LCOMM-MORE-EFTF-SW.

       9000-BUILD-EFTA-BROWSE-KEY-X.
           EXIT.

      *---------------------------
       9100-BUILD-EFTF-BROWSE-KEY.
      *---------------------------

018633*    PERFORM 9700-RETRIEVE-TWRK
018633*       THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM COMM-1000-RETRIEVE-TWRK
018633        THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF  L8090-RETRN-OK
018633     IF  LCOMM-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT TO WS-TWRK-AREA
018633         CONTINUE
           ELSE
018633*        MOVE SPACE                TO WS-TWRK-AREA
018633*        MOVE 'N'                  TO WS-TWRK-MORE-EFTF-SW
018633         MOVE SPACE                TO LCOMM-WORK-AREA
018633         MOVE 'N'                  TO LCOMM-MORE-EFTF-SW
           END-IF.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           MOVE LOW-VALUES           TO WEFTF-KEY.

036742*    IF  MIR-CLI-ID = SPACES
018633*    AND (WS-TWRK-AREA = SPACE OR LOW-VALUES)
036742*    AND (LCOMM-WORK-AREA = SPACE OR LOW-VALUES)
036742*       MOVE "0000000"                TO WEFTF-EFT-TRXN-IDT-NUM
036742*       MOVE "0001-01-01-00.00.00.000000"  TO WEFTF-EFT-TRXN-TS
036742*    ELSE
036742*        IF  MIR-EFT-TRXN-IDT-NUM =
018633*                               WS-TWRK-WEFTF-TRXN-IDT-NUM
036742*                               LCOMM-WEFTF-TRXN-IDT-NUM
036742*        AND MIR-EFT-TRXN-TS      =
018633*                               WS-TWRK-WEFTF-EFT-TRXN-TS
036742*                               LCOMM-WEFTF-EFT-TRXN-TS
036742*            MOVE MIR-EFT-TRXN-IDT-NUM
036742*                            TO WEFTF-EFT-TRXN-IDT-NUM
036742*            MOVE MIR-EFT-TRXN-TS      TO WEFTF-EFT-TRXN-TS
036742*        ELSE
036742*            IF  MIR-EFT-TRXN-IDT-NUM NOT =
018633*                               WS-TWRK-WEFTF-TRXN-IDT-NUM
036742*                               LCOMM-WEFTF-TRXN-IDT-NUM
036742*            OR  MIR-EFT-TRXN-TS      NOT =
018633*                               WS-TWRK-WEFTF-EFT-TRXN-TS
036742*                               LCOMM-WEFTF-EFT-TRXN-TS
036742*                MOVE "0000000" TO WEFTF-EFT-TRXN-IDT-NUM
036742*                MOVE "0001-01-01-00.00.00.000000"
036742*                               TO WEFTF-EFT-TRXN-TS
036742*            END-IF
036742*        END-IF
036742*    END-IF.
036742      
036742     IF  MIR-CLI-ID = SPACES
036742     AND (LCOMM-WORK-AREA = SPACE OR LOW-VALUES)
036742        MOVE "0000000"                TO WEFTF-EFT-TRXN-IDT-NUM
036742        MOVE ZEROS                    TO WEFTF-EFT-TRXN-GEN-ID
036742     ELSE
036742         IF  MIR-EFT-TRXN-IDT-NUM =
036742                                LCOMM-WEFTF-TRXN-IDT-NUM
036742         AND WS-TRXN-GEN-ID  =  LCOMM-WEFTF-TRXN-GEN-ID
036742             MOVE MIR-EFT-TRXN-IDT-NUM
036742                                    TO WEFTF-EFT-TRXN-IDT-NUM
036742             MOVE WS-TRXN-GEN-ID    TO WEFTF-EFT-TRXN-GEN-ID
036742         ELSE
036742             IF  MIR-EFT-TRXN-IDT-NUM NOT =
018633                                LCOMM-WEFTF-TRXN-IDT-NUM
036742             OR  WS-TRXN-GEN-ID       NOT = 
036742                                     LCOMM-WEFTF-TRXN-GEN-ID
036742                 MOVE "0000000"   TO WEFTF-EFT-TRXN-IDT-NUM
036742                 MOVE ZEROS       TO WEFTF-EFT-TRXN-GEN-ID
036742             END-IF
036742         END-IF
036742     END-IF.            

           MOVE HIGH-VALUES          TO WEFTF-ENDBR-KEY.
036742*    MOVE WWKDT-HIGH-TS        TO WEFTF-ENDBR-EFT-TRXN-TS.
036742     MOVE WCNST-MAX-EFT-TRXN-GEN-ID-N  
036742                               TO WEFTF-ENDBR-EFT-TRXN-GEN-ID.

018633*    INITIALIZE WS-TWRK-AREA.
018633*    MOVE 'N' TO WS-TWRK-MORE-EFTF-SW.
018633     INITIALIZE LCOMM-WORK-AREA
018633     MOVE 'N' TO LCOMM-MORE-EFTF-SW.

       9100-BUILD-EFTF-BROWSE-KEY-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
028789     PERFORM  2110-0000-INIT-PARM-INFO
028789         THRU 2110-0000-INIT-PARM-INFO-X.
028789
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970      INITIALIZE WS-WORKING-STORAGE.
025970
025970      MOVE SPACES                TO LPGA-PARM-INFO.
025970      INITIALIZE LPGA-PARM-INFO.
025970
025970      SET WS-MAX-SCREEN-LINES-DEFAULT TO TRUE.
025970
025970      MOVE SPACES                TO WWKDT-WORK-FIELDS.
025970
025970      MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

018633*--------------------
018633*9500-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*     MOVE WS-TWRK-KEY          TO L8090-BUS-FCN-ID.
018633*     MOVE ZEROS                TO L8090-TEMP-WRK-SEQ-NUM.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    SET L8090-USAGE-COMM       TO TRUE.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*----------------
018633*9800-WRITE-TWRK.
018633*----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*    SET L8090-USAGE-COMM        TO TRUE.
018633*    MOVE LENGTH OF WS-TWRK-AREA TO L8090-AREA-LEN.
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9900-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    SET L8090-USAGE-COMM        TO TRUE.
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
018633*
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
028789 COPY CCPS2110.
028789 COPY CCPL2110.
028789
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
      *
018633 COPY XCPS8090.
       COPY XCPL8090.
      *
       COPY XCPL0290.
       COPY XCPS0290.
      *
       COPY CCPBEFTA.
      *
       COPY CCPBEFTF.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM7804                     **
      *****************************************************************
