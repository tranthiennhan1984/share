      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7321.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7321                                         **
      **  REMARKS:  PDBG - PLAN DEATH BENEFIT GUARANTEE CREATE       **
      **            THIS MODULE CREATES THE PDBG TABLE               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7321'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-CONSTANT-FIELDS.
025970*        10  WS-TWRK-KEY                 PIC X(04)
025970*                                        VALUE '7320'.
025970
025970         10  WS-TWRK-KEY                 PIC X(04).
025970             88 WS-TWRK-KEY-DEFAULT      VALUE '7320'.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID               PIC X(04).
                   88  WS-BUS-FCN-CREATE       VALUE '7321'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWLOCK.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRPDBG.
       COPY CCFWPDBG.
      /
       COPY CCFRPH.
       COPY CCFWPH.
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY XCWL8090.
       COPY XCWL8960.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7321.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------


           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7321'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  7000-BUILD-KEY
               THRU 7000-BUILD-KEY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  PDBG-2000-READ-INDEX
               THRU PDBG-2000-READ-INDEX-X.

           IF  WPDBG-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE 'XS00000003'  TO WGLOB-MSG-REF-INFO
               MOVE WPDBG-KEY     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1             TO WGLOB-MSG-ERROR-SW
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  PDBG-1000-CREATE
               THRU PDBG-1000-CREATE-X.

           IF  RPDBG-PLAN-DBG-TYP-RESET
               SET  RPDBG-PLAN-DBG-LOCK-POL-YR TO  TRUE
           END-IF.

           IF  RPDBG-PLAN-DBG-TYP-ROLU
               SET RPDBG-PLAN-DBG-MAX-TO-AGE       TO TRUE
           END-IF.

           PERFORM  PDBG-1000-WRITE
               THRU PDBG-1000-WRITE-X.

           MOVE WPDBG-PLAN-ID        TO WPH-PLAN-ID.
           PERFORM  PH-1000-READ-TWRK-TS
               THRU PH-1000-READ-TWRK-TS-X.


       2000-CREATE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  4110-EDIT-PLAN-ID
               THRU 4110-EDIT-PLAN-ID-X.

           PERFORM  4120-EDIT-LOC-GR
               THRU 4120-EDIT-LOC-GR-X.

           PERFORM  4130-EDIT-DBG-TYP
               THRU 4130-EDIT-DBG-TYP-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       4110-EDIT-PLAN-ID.
      *-----------------

           MOVE MIR-PLAN-ID          TO WPH-PLAN-ID.

           PERFORM  PH-2000-READ-INDEX
               THRU PH-2000-READ-INDEX-X.

           IF NOT WPH-IO-OK
      *MSG:    PLAN (@1) DOES NOT EXIST
               MOVE 'XS00000049'  TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-ID   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1             TO WGLOB-MSG-ERROR-SW
           END-IF.

       4110-EDIT-PLAN-ID-X.
           EXIT.


      *-----------------
       4120-EDIT-LOC-GR.
      *-----------------

           MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.

           PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
               THRU LCGP-1000-EDIT-LCGP-LOCATION-X.

           IF  WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG: 'LOCATION GROUP MUST BE IN EDIT TYPE 'LOCGP''
               MOVE 'XS00000235'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
           END-IF.

       4120-EDIT-LOC-GR-X.
           EXIT.

      *-----------------
       4130-EDIT-DBG-TYP.
      *-----------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-DBG-TYP-CD'         TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-DBG-TYP-CD       TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID PLAN DEATH BENEFIT GUARANTEE TYPE
               MOVE 'CS73210001'          TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
           END-IF.

       4130-EDIT-DBG-TYP-X.
           EXIT.
      /
      *---------------
       7000-BUILD-KEY.
      *---------------

           MOVE MIR-PLAN-ID           TO WPDBG-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPDBG-LOC-GR-ID.
           MOVE MIR-PLAN-DBG-TYP-CD   TO WPDBG-PLAN-DBG-TYP-CD.

       7000-BUILD-KEY-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *-------------------------
       9990-INIT-WORKING-STORAGE.
      *-------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-FIELDS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970           
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPELCGP.
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
                                '$VAR2' BY 'PH'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY XCPL0260.
       COPY XCPL8090.
025970 COPY XCPS8090.
       COPY XCPS8960.
       COPY XCPL8960.
      /
      ****************************************************************
      *  FILE I/O PROCESS MODULES                                    *
      ****************************************************************
       COPY CCPNPH.
       COPY CCPUPH.
       COPY CCPNEDIT.
       COPY CCPAPDBG.
       COPY CCPCPDBG.
       COPY CCPNPDBG.
      /
      ****************************************************************
      *  ERROR HANDLING ROUTINES                                     *
      ****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ****************************************************************
      *                  END OF PROGRAM CSOM7321                     *
      ****************************************************************
