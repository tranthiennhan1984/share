      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7834.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7834                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE LIST FUNCTION           **
      **            FOR THE FUTURE DATED POLICY ACTIVITY             **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028611**  6.7       POLICY ACTIVITY STATUS CODE                      **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7834'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-CONSTANT-FIELDS.
           05  WS-MAX-LIST-LINES                 PIC S9(04) BINARY.
               88  WS-MAX-LIST-LINES-DEFAULT
                                                 VALUE 100.
           05  WS-PALC-TBL-MAX                   PIC S9(04) BINARY.
               88  WS-PALC-TBL-MAX-DEFAULT
                                                 VALUE 100.
           05  WS-CLOC-TBL-MAX                   PIC S9(04) BINARY.
               88  WS-CLOC-TBL-MAX-DEFAULT
                                                 VALUE 100.
           05  WS-OTHR-TBL-MAX                   PIC S9(04) BINARY.
               88  WS-OTHR-TBL-MAX-DEFAULT
                                                 VALUE 100.
           05  WS-LOAN-TBL-MAX                   PIC S9(04) BINARY.
               88  WS-LOAN-TBL-MAX-DEFAULT
                                                 VALUE 100.

       01  WS-WORK-AREA.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID                 PIC X(04).
                   88  WS-BUS-FCN-LIST           VALUE '7834'.

               10  WS-PALC-IND                   PIC X(01).
                   88  WS-NORMAL-PALC            VALUE 'N'.
                   88  WS-BYPASS-PALC            VALUE 'B'.
                   88  WS-SELECT-PALC            VALUE 'S'.
               10  WS-CLOC-IND                   PIC X(01).
                   88  WS-NORMAL-CLOC            VALUE 'N'.
                   88  WS-BYPASS-CLOC            VALUE 'B'.
                   88  WS-SELECT-CLOC            VALUE 'S'.
               10  WS-OTHR-IND                   PIC X(01).
                   88  WS-NORMAL-OTHR            VALUE 'N'.
                   88  WS-BYPASS-OTHR            VALUE 'B'.
                   88  WS-SELECT-OTHR            VALUE 'S'.
               10  WS-VALIDATE-SW                PIC X(01).
                   88  WS-VALIDATE-OK            VALUE 'Y'.
                   88  WS-VALIDATE-NOT-OK        VALUE 'N'.

               10  WS-SUB                        PIC S9(04) BINARY.
               10  WS-IDX                        PIC S9(04) BINARY.
               10  WS-PRCES-COUNT                PIC S9(04) BINARY.
               10  WS-EFF-DT-INT                 PIC X(10).
036742*        10  WS-TS                         PIC X(26).
036742         10  WS-GEN-ID                     PIC X(10).
               10  WS-SAVE-EFF-DT                PIC X(10).
               10  WS-NEXT-KEY-IDX               PIC S9(04) BINARY.
               10  WS-ENTER-KEY.
                   15  WS-ENTER-CO-ID            PIC X(02).
                   15  WS-ENTER-POL-ID           PIC X(10).
036742*            15  WS-ENTER-TS               PIC X(26).
036742             15  WS-ENTER-GEN-ID           PIC X(10).
               10  WS-ENTER-EFF-DT               PIC X(10).

           05  WS-PALC-TABLE.
               10  WS-PALC-COUNT                 PIC S9(3) COMP-3.
               10  WS-PALC-TBL                   OCCURS 100.
                   15  WS-PALC-POL-ID            PIC X(010).
                   15  WS-PALC-POL-RQST-EFF-DT   PIC X(010).
036742*            15  WS-PALC-POL-RQST-CREAT-TS PIC X(026).
036742             15  WS-PALC-POL-RQST-GEN-ID   PIC S9(10).
                   15  WS-PALC-POL-RQST-TYP-CD   PIC X(002).
                   15  WS-PALC-BUS-FCN-ID        PIC X(004).
                   15  WS-PALC-USER-ID           PIC X(008).
                   15  WS-PALC-POL-RQST-STAT-CD  PIC X(001).
                   15  WS-PALC-PREV-UPDT-USER-ID PIC X(008).

           05  WS-CLOC-TABLE.
               10  WS-CLOC-COUNT                 PIC S9(3) COMP-3.
               10  WS-CLOC-TBL                   OCCURS 100.
                   15  WS-CLOC-POL-ID            PIC X(010).
                   15  WS-CLOC-POL-RQST-EFF-DT   PIC X(010).
036742*            15  WS-CLOC-POL-RQST-CREAT-TS PIC X(026).
036742             15  WS-CLOC-POL-RQST-GEN-ID   PIC S9(10).
                   15  WS-CLOC-POL-RQST-TYP-CD   PIC X(002).
                   15  WS-CLOC-BUS-FCN-ID        PIC X(004).
                   15  WS-CLOC-USER-ID           PIC X(008).
                   15  WS-CLOC-POL-RQST-STAT-CD  PIC X(001).
                   15  WS-CLOC-PREV-UPDT-USER-ID PIC X(008).

           05  WS-OTHR-TABLE.
               10  WS-OTHR-COUNT                 PIC S9(3) COMP-3.
               10  WS-OTHR-TBL                   OCCURS 100.
                   15  WS-OTHR-POL-ID            PIC X(010).
                   15  WS-OTHR-POL-RQST-EFF-DT   PIC X(010).
036742*            15  WS-OTHR-POL-RQST-CREAT-TS PIC X(026).
036742             15  WS-OTHR-POL-RQST-GEN-ID   PIC S9(10).
                   15  WS-OTHR-POL-RQST-TYP-CD   PIC X(002).
                   15  WS-OTHR-BUS-FCN-ID        PIC X(004).
                   15  WS-OTHR-USER-ID           PIC X(008).
                   15  WS-OTHR-POL-RQST-STAT-CD  PIC X(001).
                   15  WS-OTHR-PREV-UPDT-USER-ID PIC X(008).

           05  WS-LOAN-TABLE.
               10  WS-LOAN-COUNT                 PIC S9(3) COMP-3.
               10  WS-LOAN-TBL                   OCCURS 100.
                   15  WS-LOAN-POL-ID            PIC X(010).
                   15  WS-LOAN-POL-RQST-EFF-DT   PIC X(010).
036742*            15  WS-LOAN-POL-RQST-CREAT-TS PIC X(026).
036742             15  WS-LOAN-POL-RQST-GEN-ID   PIC S9(10).
                   15  WS-LOAN-POL-RQST-TYP-CD   PIC X(002).
                   15  WS-LOAN-BUS-FCN-ID        PIC X(004).
                   15  WS-LOAN-USER-ID           PIC X(008).
                   15  WS-LOAN-POL-RQST-STAT-CD  PIC X(001).
                   15  WS-LOAN-PREV-UPDT-USER-ID PIC X(008).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
036742 COPY XCWWCNST.
028611 COPY XCWEBLCH.
       COPY XCWWWKDT.
028298 COPY CCWL2626.
036742 COPY XCWL0280.
036742 COPY XCWL0290.
       COPY XCWLDTLK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.

036742*    EXEC SQL INCLUDE CCFWPORS END-EXEC.
036742     EXEC SQL INCLUDE CCFWPORQ END-EXEC.
           EXEC SQL INCLUDE CCFRPORQ END-EXEC.

       COPY XCFWDMAD.
       COPY XCFRDMAD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
      /
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7834.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID      TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM7834'          TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'        TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                             TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *------------
       2000-LIST.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WS-VALIDATE-NOT-OK
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

036742*    PERFORM  PORS-1000-BROWSE
036742*        THRU PORS-1000-BROWSE-X.
036742*
036742*    PERFORM  PORS-2000-READ-NEXT
036742*        THRU PORS-2000-READ-NEXT-X.
036742
036742     PERFORM  PORQ-1000-BROWSE
036742         THRU PORQ-1000-BROWSE-X.
036742
036742     PERFORM  PORQ-2000-READ-NEXT
036742         THRU PORQ-2000-READ-NEXT-X.

036742*    IF  WPORS-IO-EOF
036742     IF  WPORQ-IO-EOF
036742*        PERFORM  PORS-3000-END-BROWSE
036742*            THRU PORS-3000-END-BROWSE-X
036742         PERFORM  PORQ-3000-END-BROWSE
036742             THRU PORQ-3000-END-BROWSE-X
      *MSG: 'NO FUTURE DATED ACTIVITIES EXISTS'
               MOVE 'CS78340001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                         TO WS-SUB.
           MOVE ZERO                         TO WS-PRCES-COUNT.
           MOVE RPORQ-POL-RQST-EFF-DT        TO WS-SAVE-EFF-DT.

036742*    PERFORM  2010-BROWSE-PORS
036742*        THRU 2010-BROWSE-PORS-X
036742*        UNTIL WS-PRCES-COUNT > WS-MAX-LIST-LINES
036742*        OR    WS-PRCES-COUNT = WS-MAX-LIST-LINES
036742*        OR    NOT WPORS-IO-OK.
036742     PERFORM  2010-BROWSE-PORQ
036742         THRU 2010-BROWSE-PORQ-X
036742         UNTIL WS-PRCES-COUNT > WS-MAX-LIST-LINES
036742         OR    WS-PRCES-COUNT = WS-MAX-LIST-LINES
036742         OR    NOT WPORQ-IO-OK.

           IF  WS-SUB < WS-MAX-LIST-LINES
               PERFORM  2020-COPY-WS-TO-MIR
                   THRU 2020-COPY-WS-TO-MIR-X
           END-IF.

           IF  (WS-SUB > WS-MAX-LIST-LINES)
           OR  (WS-SUB = WS-MAX-LIST-LINES)
               PERFORM  2200-SET-NEXT-KEY
                   THRU 2200-SET-NEXT-KEY-X
           END-IF.

           IF  WGLOB-MORE-DATA-EXISTS
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               MOVE 'XS00000014'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE MIR-POL-RQST-EFF-DT-T (1)
                                         TO MIR-POL-RQST-EFF-DT
036742*        MOVE MIR-POL-RQST-CREAT-TS-T (1)
036742*                                  TO MIR-POL-RQST-CREAT-TS
036742         MOVE MIR-POL-RQST-GEN-ID-T (1)
036742                                   TO MIR-POL-RQST-GEN-ID
               MOVE MIR-POL-RQST-TYP-CD-T (1)
                                         TO MIR-POL-RQST-TYP-CD
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


036742*    PERFORM  PORS-3000-END-BROWSE
036742*        THRU PORS-3000-END-BROWSE-X.
036742     PERFORM  PORQ-3000-END-BROWSE
036742         THRU PORQ-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
036742*2010-BROWSE-PORS.
036742 2010-BROWSE-PORQ.
      *-----------------

           IF  MIR-POL-RQST-STAT-CD = SPACE
           OR  MIR-POL-RQST-STAT-CD = RPORQ-POL-RQST-STAT-CD
               CONTINUE
           ELSE
036742*        PERFORM  PORS-2000-READ-NEXT
036742*            THRU PORS-2000-READ-NEXT-X
036742         PERFORM  PORQ-2000-READ-NEXT
036742             THRU PORQ-2000-READ-NEXT-X
036742*        GO TO 2010-BROWSE-PORS-X
036742         GO TO 2010-BROWSE-PORQ-X
           END-IF.

           ADD +1                            TO WS-PRCES-COUNT.

           IF  WS-SAVE-EFF-DT  NOT = RPORQ-POL-RQST-EFF-DT
               PERFORM  2020-COPY-WS-TO-MIR
                   THRU 2020-COPY-WS-TO-MIR-X
               SET WS-NORMAL-PALC            TO TRUE
               SET WS-NORMAL-CLOC            TO TRUE
               SET WS-NORMAL-OTHR            TO TRUE
               IF  WS-SUB > WS-MAX-LIST-LINES
036742*            GO TO 2010-BROWSE-PORS-X
036742             GO TO 2010-BROWSE-PORQ-X
               END-IF

               MOVE RPORQ-POL-RQST-EFF-DT
                                             TO WS-SAVE-EFF-DT
               INITIALIZE WS-PALC-TABLE
               INITIALIZE WS-CLOC-TABLE
               INITIALIZE WS-OTHR-TABLE
               INITIALIZE WS-LOAN-TABLE
               MOVE ZERO                     TO WS-CLOC-COUNT
               MOVE ZERO                     TO WS-PALC-COUNT
               MOVE ZERO                     TO WS-OTHR-COUNT
               MOVE ZERO                     TO WS-LOAN-COUNT
           END-IF.

           PERFORM  2030-SAVE-REC-TO-WS
               THRU 2030-SAVE-REC-TO-WS-X.

036742*    PERFORM  PORS-2000-READ-NEXT
036742*        THRU PORS-2000-READ-NEXT-X.
036742     PERFORM  PORQ-2000-READ-NEXT
036742         THRU PORQ-2000-READ-NEXT-X.

036742*2010-BROWSE-PORS-X.
036742 2010-BROWSE-PORQ-X.
           EXIT.

      *---------------------
       2020-COPY-WS-TO-MIR.
      *---------------------

      * DISPLAY POLICY ALLOCATION ACTIVITY FIRST

           PERFORM
               VARYING WS-IDX FROM 1 BY 1
               UNTIL   WS-IDX > WS-PALC-COUNT
               OR      WS-SUB > WS-MAX-LIST-LINES

               ADD 1                         TO WS-SUB

               MOVE WS-PALC-POL-ID (WS-IDX)  TO MIR-POL-ID-T
                                                (WS-SUB)

               MOVE WS-PALC-POL-RQST-EFF-DT (WS-IDX)
                                             TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-POL-RQST-EFF-DT-T
                                                (WS-SUB)

036742*        MOVE WS-PALC-POL-RQST-CREAT-TS (WS-IDX)
036742*                                      TO MIR-POL-RQST-CREAT-TS-T
036742*                                         (WS-SUB)
036742         MOVE WS-PALC-POL-RQST-GEN-ID (WS-IDX)
036742                                       TO L0290-INPUT-V00
036742         MOVE ZERO                     TO L0290-PRECISION
036742         MOVE LENGTH OF MIR-POL-RQST-GEN-ID-T (WS-SUB)
036742                                       TO L0290-MAX-OUT-LEN
036742         SET L0290-LEAD-ZEROS-SUPPRESS
036742                                       TO TRUE
036742         PERFORM  0290-2000-FORMAT-FOR-MIR
036742             THRU 0290-2000-FORMAT-FOR-MIR-X
036742
036742         MOVE L0290-OUTPUT-DATA        TO MIR-POL-RQST-GEN-ID-T
036742                                          (WS-SUB)

               MOVE WS-PALC-POL-RQST-TYP-CD (WS-IDX)
                                             TO MIR-POL-RQST-TYP-CD-T
                                                (WS-SUB)
               MOVE WS-PALC-BUS-FCN-ID (WS-IDX)
                                             TO MIR-BUS-FCN-ID-T
                                                (WS-SUB)
               MOVE WS-PALC-USER-ID (WS-IDX) TO MIR-USER-ID-T
                                                (WS-SUB)

               MOVE WS-PALC-POL-RQST-STAT-CD (WS-IDX)
                                             TO MIR-POL-RQST-STAT-CD-T
                                                (WS-SUB)
               MOVE WS-PALC-PREV-UPDT-USER-ID (WS-IDX)
                                             TO MIR-PREV-UPDT-USER-ID-T
                                                (WS-SUB)
           END-PERFORM.

           IF  WS-SUB <= WS-MAX-LIST-LINES
               MOVE ZERO                     TO WS-PALC-COUNT
               INITIALIZE WS-PALC-TABLE
           ELSE
               MOVE WS-IDX                   TO WS-NEXT-KEY-IDX
               GO TO 2020-COPY-WS-TO-MIR-X
           END-IF.


      * DISPLAY CURRENT LOCATION CHANGE ACTIVITY SECOND

           PERFORM
               VARYING WS-IDX FROM 1 BY 1
               UNTIL   WS-IDX > WS-CLOC-COUNT
               OR      WS-SUB > WS-MAX-LIST-LINES

               ADD 1                         TO WS-SUB

               MOVE WS-CLOC-POL-ID (WS-IDX)  TO MIR-POL-ID-T
                                                (WS-SUB)

               MOVE WS-CLOC-POL-RQST-EFF-DT (WS-IDX)
                                             TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-POL-RQST-EFF-DT-T
                                                (WS-SUB)

036742*        MOVE WS-CLOC-POL-RQST-CREAT-TS (WS-IDX)
036742*                                      TO MIR-POL-RQST-CREAT-TS-T
036742*                                         (WS-SUB)
036742         MOVE WS-CLOC-POL-RQST-GEN-ID (WS-IDX)
036742                                       TO L0290-INPUT-V00
036742         MOVE ZERO                     TO L0290-PRECISION
036742         MOVE LENGTH OF MIR-POL-RQST-GEN-ID-T (WS-SUB)
036742                                       TO L0290-MAX-OUT-LEN
036742         SET L0290-LEAD-ZEROS-SUPPRESS
036742                                       TO TRUE
036742         PERFORM  0290-2000-FORMAT-FOR-MIR
036742             THRU 0290-2000-FORMAT-FOR-MIR-X
036742
036742         MOVE L0290-OUTPUT-DATA        TO MIR-POL-RQST-GEN-ID-T
036742                                          (WS-SUB)

               MOVE WS-CLOC-POL-RQST-TYP-CD (WS-IDX)
                                             TO MIR-POL-RQST-TYP-CD-T
                                                (WS-SUB)
               MOVE WS-CLOC-BUS-FCN-ID (WS-IDX)
                                             TO MIR-BUS-FCN-ID-T
                                                (WS-SUB)
               MOVE WS-CLOC-USER-ID (WS-IDX)
                                             TO MIR-USER-ID-T
                                                (WS-SUB)

               MOVE WS-CLOC-POL-RQST-STAT-CD (WS-IDX)
                                             TO MIR-POL-RQST-STAT-CD-T
                                                (WS-SUB)
               MOVE WS-CLOC-PREV-UPDT-USER-ID (WS-IDX)
                                             TO MIR-PREV-UPDT-USER-ID-T
                                                (WS-SUB)
           END-PERFORM.

           IF  WS-SUB <= WS-MAX-LIST-LINES
               MOVE ZERO                     TO WS-CLOC-COUNT
               INITIALIZE WS-CLOC-TABLE
           ELSE
               MOVE WS-IDX                   TO WS-NEXT-KEY-IDX
               GO TO 2020-COPY-WS-TO-MIR-X
           END-IF.


      * DISPLAY ALL OTHER ACTIVITIES EXCEPT LOAN, IN TIMESTAMP SEQ

           PERFORM
               VARYING WS-IDX FROM 1 BY 1
               UNTIL   WS-IDX > WS-OTHR-COUNT
               OR      WS-SUB > WS-MAX-LIST-LINES

               ADD 1                         TO WS-SUB

               MOVE WS-OTHR-POL-ID (WS-IDX)  TO MIR-POL-ID-T
                                                (WS-SUB)

               MOVE WS-OTHR-POL-RQST-EFF-DT (WS-IDX)
                                             TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-POL-RQST-EFF-DT-T
                                                (WS-SUB)

036742*        MOVE WS-OTHR-POL-RQST-CREAT-TS (WS-IDX)
036742*                                      TO MIR-POL-RQST-CREAT-TS-T
036742*                                         (WS-SUB)
036742         MOVE WS-OTHR-POL-RQST-GEN-ID (WS-IDX)
036742                                       TO L0290-INPUT-V00
036742         MOVE ZERO                     TO L0290-PRECISION
036742         MOVE LENGTH OF MIR-POL-RQST-GEN-ID-T (WS-SUB)
036742                                       TO L0290-MAX-OUT-LEN
036742         SET L0290-LEAD-ZEROS-SUPPRESS
036742                                       TO TRUE
036742         PERFORM  0290-2000-FORMAT-FOR-MIR
036742             THRU 0290-2000-FORMAT-FOR-MIR-X
036742
036742         MOVE L0290-OUTPUT-DATA        TO MIR-POL-RQST-GEN-ID-T
036742                                          (WS-SUB)

               MOVE WS-OTHR-POL-RQST-TYP-CD (WS-IDX)
                                             TO MIR-POL-RQST-TYP-CD-T
                                                (WS-SUB)
               MOVE WS-OTHR-BUS-FCN-ID (WS-IDX)
                                             TO MIR-BUS-FCN-ID-T
                                                (WS-SUB)
               MOVE WS-OTHR-USER-ID (WS-IDX) TO MIR-USER-ID-T
                                                (WS-SUB)

               MOVE WS-OTHR-POL-RQST-STAT-CD (WS-IDX)
                                             TO MIR-POL-RQST-STAT-CD-T
                                                (WS-SUB)
               MOVE WS-OTHR-PREV-UPDT-USER-ID (WS-IDX)
                                             TO MIR-PREV-UPDT-USER-ID-T
                                                (WS-SUB)
           END-PERFORM.

           IF  WS-SUB <= WS-MAX-LIST-LINES
               MOVE ZERO                     TO WS-OTHR-COUNT
           ELSE
               MOVE WS-IDX                   TO WS-NEXT-KEY-IDX
               INITIALIZE WS-OTHR-TABLE
           END-IF.

      * DISPLAY LOAN ACTIVITY LAST

           PERFORM
               VARYING WS-IDX FROM 1 BY 1
               UNTIL   WS-IDX > WS-LOAN-COUNT
               OR      WS-SUB > WS-MAX-LIST-LINES

               ADD 1                         TO WS-SUB

               MOVE WS-LOAN-POL-ID (WS-IDX)  TO MIR-POL-ID-T
                                                (WS-SUB)

               MOVE WS-LOAN-POL-RQST-EFF-DT (WS-IDX)
                                             TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-POL-RQST-EFF-DT-T
                                                (WS-SUB)

036742*        MOVE WS-LOAN-POL-RQST-CREAT-TS (WS-IDX)
036742*                                      TO MIR-POL-RQST-CREAT-TS-T
036742*                                         (WS-SUB)
036742         MOVE WS-LOAN-POL-RQST-GEN-ID (WS-IDX)
036742                                       TO L0290-INPUT-V00
036742         MOVE ZERO                     TO L0290-PRECISION
036742         MOVE LENGTH OF MIR-POL-RQST-GEN-ID-T (WS-SUB)
036742                                       TO L0290-MAX-OUT-LEN
036742         SET L0290-LEAD-ZEROS-SUPPRESS
036742                                       TO TRUE
036742         PERFORM  0290-2000-FORMAT-FOR-MIR
036742             THRU 0290-2000-FORMAT-FOR-MIR-X
036742
036742         MOVE L0290-OUTPUT-DATA        TO MIR-POL-RQST-GEN-ID-T
036742                                          (WS-SUB)

               MOVE WS-LOAN-POL-RQST-TYP-CD (WS-IDX)
                                             TO MIR-POL-RQST-TYP-CD-T
                                                (WS-SUB)
               MOVE WS-LOAN-BUS-FCN-ID (WS-IDX)
                                             TO MIR-BUS-FCN-ID-T
                                                (WS-SUB)
               MOVE WS-LOAN-USER-ID (WS-IDX) TO MIR-USER-ID-T
                                                (WS-SUB)

               MOVE WS-LOAN-POL-RQST-STAT-CD (WS-IDX)
                                             TO MIR-POL-RQST-STAT-CD-T
                                                (WS-SUB)
               MOVE WS-LOAN-PREV-UPDT-USER-ID (WS-IDX)
                                             TO MIR-PREV-UPDT-USER-ID-T
                                                (WS-SUB)
           END-PERFORM.

           IF  WS-SUB <= WS-MAX-LIST-LINES
               MOVE ZERO                     TO WS-LOAN-COUNT
               INITIALIZE WS-LOAN-TABLE
           ELSE
               MOVE WS-IDX                   TO WS-NEXT-KEY-IDX
               GO TO 2020-COPY-WS-TO-MIR-X
           END-IF.

       2020-COPY-WS-TO-MIR-X.
           EXIT.

      *--------------------
       2030-SAVE-REC-TO-WS.
      *--------------------

           EVALUATE TRUE

               WHEN  RPORQ-POL-RQST-TYP-ALLOC-INSTR
                   EVALUATE TRUE
                       WHEN WS-BYPASS-PALC
                           SUBTRACT +1       FROM WS-PRCES-COUNT
                       WHEN WS-SELECT-PALC
                       AND  RPORQ-POL-RQST-EFF-DT = WS-ENTER-EFF-DT
                       AND  RPORQ-KEY < WS-ENTER-KEY
                           SUBTRACT +1       FROM WS-PRCES-COUNT
                       WHEN OTHER
                           PERFORM  2040-SAVE-TO-PALC-TBL
                               THRU 2040-SAVE-TO-PALC-TBL-X
                   END-EVALUATE

               WHEN  RPORQ-POL-RQST-TYP-CRNT-LOC
                   EVALUATE TRUE
                       WHEN WS-BYPASS-CLOC
                           SUBTRACT +1       FROM WS-PRCES-COUNT
                       WHEN WS-SELECT-CLOC
                       AND  RPORQ-POL-RQST-EFF-DT = WS-ENTER-EFF-DT
                       AND  RPORQ-KEY < WS-ENTER-KEY
                           SUBTRACT +1       FROM WS-PRCES-COUNT
                       WHEN OTHER
                           PERFORM  2060-SAVE-TO-CLOC-TBL
                               THRU 2060-SAVE-TO-CLOC-TBL-X
                   END-EVALUATE

               WHEN  NOT RPORQ-POL-RQST-TYP-LOAN
                   EVALUATE TRUE
                       WHEN WS-BYPASS-OTHR
                           SUBTRACT +1       FROM WS-PRCES-COUNT
                       WHEN WS-SELECT-OTHR
                       AND  RPORQ-POL-RQST-EFF-DT = WS-ENTER-EFF-DT
                       AND  RPORQ-KEY < WS-ENTER-KEY
                           SUBTRACT +1       FROM WS-PRCES-COUNT
                       WHEN OTHER
                           PERFORM  2050-SAVE-TO-OTHR-TBL
                               THRU 2050-SAVE-TO-OTHR-TBL-X
                   END-EVALUATE

               WHEN OTHER
                   PERFORM  2070-SAVE-TO-LOAN-TBL
                       THRU 2070-SAVE-TO-LOAN-TBL-X

           END-EVALUATE.

       2030-SAVE-REC-TO-WS-X.
           EXIT.

      *----------------------
       2040-SAVE-TO-PALC-TBL.
      *----------------------

           ADD 1                       TO WS-PALC-COUNT.
           IF  WS-PALC-COUNT > WS-PALC-TBL-MAX
      *MSG: 'INTERNAL TABLE OVERFLOW'
               MOVE 'CS78340002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  0030-5000-LOGIC-ERROR
                   THRU 0030-5000-LOGIC-ERROR-X
           END-IF.

           MOVE RPORQ-POL-ID           TO WS-PALC-POL-ID
                                          (WS-PALC-COUNT).

           MOVE RPORQ-POL-RQST-EFF-DT  TO WS-PALC-POL-RQST-EFF-DT
                                          (WS-PALC-COUNT).

036742*    MOVE RPORQ-POL-RQST-CREAT-TS
036742*                                TO WS-PALC-POL-RQST-CREAT-TS
036742*                                   (WS-PALC-COUNT).
036742     MOVE RPORQ-POL-RQST-GEN-ID
036742                                 TO WS-PALC-POL-RQST-GEN-ID
036742                                    (WS-PALC-COUNT).

           MOVE RPORQ-POL-RQST-TYP-CD  TO WS-PALC-POL-RQST-TYP-CD
                                          (WS-PALC-COUNT).
           MOVE RPORQ-BUS-FCN-ID       TO WS-PALC-BUS-FCN-ID
                                          (WS-PALC-COUNT).
           MOVE RPORQ-USER-ID          TO WS-PALC-USER-ID
                                          (WS-PALC-COUNT).

           MOVE RPORQ-POL-RQST-STAT-CD TO WS-PALC-POL-RQST-STAT-CD
                                          (WS-PALC-COUNT).
           MOVE RPORQ-PREV-UPDT-USER-ID
                                       TO WS-PALC-PREV-UPDT-USER-ID
                                          (WS-PALC-COUNT).

       2040-SAVE-TO-PALC-TBL-X.
           EXIT.

      *-----------------------
       2050-SAVE-TO-OTHR-TBL.
      *-----------------------

           ADD 1                       TO WS-OTHR-COUNT.
           IF  WS-OTHR-COUNT > WS-OTHR-TBL-MAX
      *MSG: 'INTERNAL TABLE OVERFLOW'
               MOVE 'CS78340002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  0030-5000-LOGIC-ERROR
                   THRU 0030-5000-LOGIC-ERROR-X
           END-IF.

           MOVE RPORQ-POL-ID           TO WS-OTHR-POL-ID
                                          (WS-OTHR-COUNT).

           MOVE RPORQ-POL-RQST-EFF-DT
                                       TO WS-OTHR-POL-RQST-EFF-DT
                                          (WS-OTHR-COUNT).

036742*    MOVE RPORQ-POL-RQST-CREAT-TS
036742*                                TO WS-OTHR-POL-RQST-CREAT-TS
036742*                                   (WS-OTHR-COUNT).
036742     MOVE RPORQ-POL-RQST-GEN-ID
036742                                 TO WS-OTHR-POL-RQST-GEN-ID
036742                                    (WS-OTHR-COUNT).

           MOVE RPORQ-POL-RQST-TYP-CD  TO WS-OTHR-POL-RQST-TYP-CD
                                          (WS-OTHR-COUNT).
           MOVE RPORQ-BUS-FCN-ID       TO WS-OTHR-BUS-FCN-ID
                                          (WS-OTHR-COUNT).
           MOVE RPORQ-USER-ID          TO WS-OTHR-USER-ID
                                          (WS-OTHR-COUNT).

           MOVE RPORQ-POL-RQST-STAT-CD
                                       TO WS-OTHR-POL-RQST-STAT-CD
                                          (WS-OTHR-COUNT).

           MOVE RPORQ-PREV-UPDT-USER-ID
                                       TO WS-OTHR-PREV-UPDT-USER-ID
                                          (WS-OTHR-COUNT).

       2050-SAVE-TO-OTHR-TBL-X.
           EXIT.

      *----------------------
       2060-SAVE-TO-CLOC-TBL.
      *----------------------

           ADD 1                       TO WS-CLOC-COUNT.
           IF  WS-CLOC-COUNT > WS-CLOC-TBL-MAX
      *MSG: 'INTERNAL TABLE OVERFLOW'
               MOVE 'CS78340002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  0030-5000-LOGIC-ERROR
                   THRU 0030-5000-LOGIC-ERROR-X
           END-IF.

           MOVE RPORQ-POL-ID           TO WS-CLOC-POL-ID
                                          (WS-CLOC-COUNT).

           MOVE RPORQ-POL-RQST-EFF-DT
                                       TO WS-CLOC-POL-RQST-EFF-DT
                                          (WS-CLOC-COUNT).

036742*    MOVE RPORQ-POL-RQST-CREAT-TS
036742*                                TO WS-CLOC-POL-RQST-CREAT-TS
036742*                                   (WS-CLOC-COUNT).
036742     MOVE RPORQ-POL-RQST-GEN-ID
036742                                 TO WS-CLOC-POL-RQST-GEN-ID
036742                                    (WS-CLOC-COUNT).

           MOVE RPORQ-POL-RQST-TYP-CD
                                       TO WS-CLOC-POL-RQST-TYP-CD
                                          (WS-CLOC-COUNT).
           MOVE RPORQ-BUS-FCN-ID       TO WS-CLOC-BUS-FCN-ID
                                          (WS-CLOC-COUNT).
           MOVE RPORQ-USER-ID          TO WS-CLOC-USER-ID
                                          (WS-CLOC-COUNT).

           MOVE RPORQ-POL-RQST-STAT-CD
                                       TO WS-CLOC-POL-RQST-STAT-CD
                                          (WS-CLOC-COUNT).
           MOVE RPORQ-PREV-UPDT-USER-ID
                                       TO WS-CLOC-PREV-UPDT-USER-ID
                                          (WS-CLOC-COUNT).

       2060-SAVE-TO-CLOC-TBL-X.
           EXIT.

      *----------------------
       2070-SAVE-TO-LOAN-TBL.
      *----------------------

           ADD 1                       TO WS-LOAN-COUNT.
           IF  WS-LOAN-COUNT > WS-LOAN-TBL-MAX
      *MSG: 'INTERNAL TABLE OVERFLOW'
               MOVE 'CS78340002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  0030-5000-LOGIC-ERROR
                   THRU 0030-5000-LOGIC-ERROR-X
           END-IF.

           MOVE RPORQ-POL-ID           TO WS-LOAN-POL-ID
                                          (WS-LOAN-COUNT).

           MOVE RPORQ-POL-RQST-EFF-DT
                                       TO WS-LOAN-POL-RQST-EFF-DT
                                          (WS-LOAN-COUNT).

036742*    MOVE RPORQ-POL-RQST-CREAT-TS
036742*                                TO WS-LOAN-POL-RQST-CREAT-TS
036742*                                   (WS-LOAN-COUNT).
036742     MOVE RPORQ-POL-RQST-GEN-ID
036742                                 TO WS-LOAN-POL-RQST-GEN-ID
036742                                    (WS-LOAN-COUNT).

           MOVE RPORQ-POL-RQST-TYP-CD
                                       TO WS-LOAN-POL-RQST-TYP-CD
                                          (WS-LOAN-COUNT).
           MOVE RPORQ-BUS-FCN-ID       TO WS-LOAN-BUS-FCN-ID
                                          (WS-LOAN-COUNT).
           MOVE RPORQ-USER-ID          TO WS-LOAN-USER-ID
                                          (WS-LOAN-COUNT).

           MOVE RPORQ-POL-RQST-STAT-CD
                                       TO WS-LOAN-POL-RQST-STAT-CD
                                          (WS-LOAN-COUNT).
           MOVE RPORQ-PREV-UPDT-USER-ID
                                       TO WS-LOAN-PREV-UPDT-USER-ID
                                          (WS-LOAN-COUNT).

       2070-SAVE-TO-LOAN-TBL-X.
           EXIT.

      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           SET WS-VALIDATE-OK                TO TRUE.
           PERFORM  2110-EDIT-POL-ID
               THRU 2110-EDIT-POL-ID-X.

           IF  WS-VALIDATE-NOT-OK
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  2120-EDIT-EFF-DT
               THRU 2120-EDIT-EFF-DT-X.

           PERFORM  2130-EDIT-STAT-CD
               THRU 2130-EDIT-STAT-CD-X.

036742*    IF  MIR-POL-RQST-CREAT-TS = SPACE
036742*        MOVE WWKDT-LOW-TS             TO WS-TS
036742*    ELSE
036742*        MOVE MIR-POL-RQST-CREAT-TS
036742*                                      TO WS-TS
036742*    END-IF.
036742     MOVE MIR-POL-RQST-GEN-ID          TO L0280-INPUT-DATA.
036742     MOVE LENGTH OF MIR-POL-RQST-GEN-ID
036742                                       TO L0280-INPUT-SIZE.
036742     MOVE L0280-INPUT-SIZE             TO L0280-LENGTH.
036742     MOVE ZERO                         TO L0280-PRECISION.
036742     SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
036742     SET L0280-SPACES-PERMITTED        TO TRUE.
036742
036742     PERFORM  0280-1000-NUMERIC-EDIT
036742         THRU 0280-1000-NUMERIC-EDIT-X.
036742
036742     IF  L0280-OK
036742         MOVE L0280-OUTPUT-V00         TO WS-GEN-ID
036742     ELSE
036742         MOVE ZERO
036742                                       TO WS-GEN-ID
036742     END-IF.

           MOVE MIR-POL-RQST-TYP-CD          TO RPORQ-POL-RQST-TYP-CD.
           EVALUATE TRUE
               WHEN MIR-POL-RQST-TYP-CD = SPACE
                    SET WS-NORMAL-PALC       TO TRUE
                    SET WS-NORMAL-CLOC       TO TRUE
                    SET WS-NORMAL-OTHR       TO TRUE

               WHEN RPORQ-POL-RQST-TYP-ALLOC-INSTR
      * READ ALL AND DISPLAY PALC WITH KEY > THAN MIR KEY
                    SET WS-SELECT-PALC       TO TRUE
                    SET WS-NORMAL-CLOC       TO TRUE
                    SET WS-NORMAL-OTHR       TO TRUE
                    MOVE RPOL-CO-ID          TO WS-ENTER-CO-ID
                    MOVE MIR-POL-ID          TO WS-ENTER-POL-ID
                    MOVE WS-EFF-DT-INT       TO WS-ENTER-EFF-DT
036742*             MOVE WS-TS               TO WS-ENTER-TS
036742*             MOVE WWKDT-LOW-TS        TO WS-TS
036742              MOVE WS-GEN-ID           TO WS-ENTER-GEN-ID
036742              MOVE ZERO                TO WS-GEN-ID

               WHEN RPORQ-POL-RQST-TYP-CRNT-LOC
      * READ ALL AND DISPLAY CLOC WITH KEY > THAN MIR KEY
                    SET WS-BYPASS-PALC       TO TRUE
                    SET WS-SELECT-CLOC       TO TRUE
                    SET WS-NORMAL-OTHR       TO TRUE
                    MOVE RPOL-CO-ID          TO WS-ENTER-CO-ID
                    MOVE MIR-POL-ID          TO WS-ENTER-POL-ID
                    MOVE WS-EFF-DT-INT       TO WS-ENTER-EFF-DT
036742*             MOVE WS-TS               TO WS-ENTER-TS
036742*             MOVE WWKDT-LOW-TS        TO WS-TS
036742              MOVE WS-GEN-ID           TO WS-ENTER-GEN-ID
036742              MOVE ZERO                TO WS-GEN-ID

               WHEN NOT RPORQ-POL-RQST-TYP-LOAN
      * READ ALL AND DISPLAY OTHR WITH KEY > THAN MIR KEY
                    SET WS-BYPASS-PALC       TO TRUE
                    SET WS-BYPASS-CLOC       TO TRUE
                    SET WS-SELECT-OTHR       TO TRUE
                    MOVE RPOL-CO-ID          TO WS-ENTER-CO-ID
                    MOVE MIR-POL-ID          TO WS-ENTER-POL-ID
                    MOVE WS-EFF-DT-INT       TO WS-ENTER-EFF-DT
036742*             MOVE WS-TS               TO WS-ENTER-TS
036742*             MOVE WWKDT-LOW-TS        TO WS-TS
036742              MOVE WS-GEN-ID           TO WS-ENTER-GEN-ID
036742              MOVE ZERO                TO WS-GEN-ID

               WHEN OTHER
                    SET WS-BYPASS-PALC       TO TRUE
                    SET WS-BYPASS-CLOC       TO TRUE
                    SET WS-BYPASS-OTHR       TO TRUE
           END-EVALUATE.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       2110-EDIT-POL-ID.
      *-----------------

           IF  MIR-POL-ID = SPACES
      *MSG: POLICY ID MUST BE ENTERED
               MOVE 'CS00000048'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

           MOVE  MIR-POL-ID                  TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: @2 RECORD (@1) NOT FOUND
               MOVE 'XS00000001'             TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY                 TO WGLOB-MSG-PARM (1)
               MOVE 'POL'                    TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

       2110-EDIT-POL-ID-X.
           EXIT.

      *-----------------
       2120-EDIT-EFF-DT.
      *-----------------

           IF  MIR-POL-RQST-EFF-DT = SPACE
               MOVE WWKDT-LOW-DT             TO WS-EFF-DT-INT
               GO TO 2120-EDIT-EFF-DT-X
           END-IF.

           MOVE MIR-POL-RQST-EFF-DT          TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      * MSG EFFECTIVE DATE (@1) INVALID
               MOVE 'XS00000355'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-RQST-EFF-DT      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
               GO TO 2120-EDIT-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE          TO WS-EFF-DT-INT.

       2120-EDIT-EFF-DT-X.
           EXIT.

      *------------------
       2130-EDIT-STAT-CD.
      *------------------

028611     IF  MIR-POL-RQST-STAT-CD = EBLCH-BLANK-FIELD-CHAR
028611         MOVE SPACE              TO MIR-POL-RQST-STAT-CD
028611     END-IF.
           IF  MIR-POL-RQST-STAT-CD = SPACE
               GO TO 2130-EDIT-STAT-CD-X
           END-IF.

           MOVE MIR-POL-RQST-STAT-CD   TO WDMAD-DM-AV-CD.
           MOVE 'POL-RQST-STAT-CD'     TO WDMAD-DM-AV-TBL-CD.
           MOVE WGLOB-USER-LANG        TO WDMAD-DM-AV-DESC-LANG-CD.

           PERFORM  DMAD-1000-READ
               THRU DMAD-1000-READ-X.

           IF NOT WDMAD-IO-OK
      *MSG: INVALID STATUS VALUE
               MOVE 'CS78340003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK  TO TRUE
           END-IF.

       2130-EDIT-STAT-CD-X.
           EXIT.

      *----------------
       2200-SET-NEXT-KEY.
      *----------------

036742*    IF  WPORS-IO-OK
036742     IF  WPORQ-IO-OK
               PERFORM  9100-MOVE-RECORD-TO-KEY
                   THRU 9100-MOVE-RECORD-TO-KEY-X
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
           END-IF.

       2200-SET-NEXT-KEY-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

036742*    MOVE HIGH-VALUES            TO WPORS-KEY.
036742*    MOVE MIR-POL-ID             TO WPORS-POL-ID.
036742*    MOVE WS-EFF-DT-INT          TO WPORS-POL-RQST-EFF-DT.
036742*    MOVE WS-TS                  TO WPORS-POL-RQST-CREAT-TS.
036742*
036742*    MOVE WPORS-KEY              TO WPORS-ENDBR-KEY.
036742*    MOVE WWKDT-HIGH-DT          TO WPORS-ENDBR-POL-RQST-EFF-DT.
036742*    MOVE WWKDT-HIGH-TS          TO WPORS-ENDBR-POL-RQST-CREAT-TS.
036742     MOVE HIGH-VALUES            TO WPORQ-KEY.
036742     MOVE MIR-POL-ID             TO WPORQ-POL-ID.
036742     MOVE WS-EFF-DT-INT          TO WPORQ-POL-RQST-EFF-DT.
036742     MOVE WS-GEN-ID              TO WPORQ-POL-RQST-GEN-ID.
036742
036742     MOVE WPORQ-KEY              TO WPORQ-ENDBR-KEY.
036742     MOVE WWKDT-HIGH-DT          TO WPORQ-ENDBR-POL-RQST-EFF-DT.
036742     MOVE WCNST-MAX-POL-RQST-GEN-ID-N
036742                                 TO WPORQ-ENDBR-POL-RQST-GEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                  TO MIR-POL-ID-G.
           MOVE SPACE                  TO MIR-POL-RQST-EFF-DT-G.
036742*    MOVE SPACE                  TO MIR-POL-RQST-CREAT-TS-G.
036742     MOVE SPACE                  TO MIR-POL-RQST-GEN-ID-G.
           MOVE SPACE                  TO MIR-POL-RQST-TYP-CD-G.
           MOVE SPACE                  TO MIR-BUS-FCN-ID-G.
           MOVE SPACE                  TO MIR-USER-ID-G.
           MOVE SPACE                  TO MIR-POL-RQST-STAT-CD-G.
           MOVE SPACE                  TO MIR-PREV-UPDT-USER-ID-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *------------------------
       9100-MOVE-RECORD-TO-KEY.
      *------------------------

           MOVE RPORQ-POL-ID           TO MIR-POL-ID.

           MOVE RPORQ-POL-RQST-EFF-DT  TO L1640-INTERNAL-DATE.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE    TO MIR-POL-RQST-EFF-DT.

036742*    MOVE RPORQ-POL-RQST-CREAT-TS
036742*                                TO MIR-POL-RQST-CREAT-TS.
036742     MOVE RPORQ-POL-RQST-GEN-ID  TO L0290-INPUT-V00
036742     MOVE ZERO                   TO L0290-PRECISION
036742     MOVE LENGTH OF MIR-POL-RQST-GEN-ID
036742                                 TO L0290-MAX-OUT-LEN
036742     SET L0290-LEAD-ZEROS-SUPPRESS
036742                                 TO TRUE
036742     PERFORM  0290-2000-FORMAT-FOR-MIR
036742         THRU 0290-2000-FORMAT-FOR-MIR-X
036742
036742     MOVE L0290-OUTPUT-DATA      TO MIR-POL-RQST-GEN-ID.
           MOVE RPORQ-POL-RQST-TYP-CD  TO MIR-POL-RQST-TYP-CD.

       9100-MOVE-RECORD-TO-KEY-X.
           EXIT.


      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                     TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE         TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX          TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.
036742
036742     PERFORM  0280-0000-INIT-PARM-INFO
036742         THRU 0280-0000-INIT-PARM-INFO-X.
036742
036742     PERFORM  0290-0000-INIT-PARM-INFO
036742         THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
           INITIALIZE WS-WORK-AREA.
           SET WS-MAX-LIST-LINES-DEFAULT     TO TRUE.
           SET WS-PALC-TBL-MAX-DEFAULT       TO TRUE.
           SET WS-CLOC-TBL-MAX-DEFAULT       TO TRUE.
           SET WS-OTHR-TBL-MAX-DEFAULT       TO TRUE.
           SET WS-LOAN-TBL-MAX-DEFAULT       TO TRUE.
           MOVE SPACES                       TO WWKDT-WORK-FIELDS.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.

       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
      /
036742 COPY XCPS0280.
036742 COPY XCPL0280.
036742 COPY XCPS0290.
036742 COPY XCPL0290.
       COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.

036742*COPY CCPBPORS.
036742 COPY CCPBPORQ.

       COPY XCPNDMAD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.

       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM7834                     **
      *****************************************************************
