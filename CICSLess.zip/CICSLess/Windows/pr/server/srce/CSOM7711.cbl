      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7711.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7711                                         **
      **  REMARKS:  USRP - U.S. REPORTING TABLE CREATE               **
      **            THIS MODULE CREATES THE USRP TABLE               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7711'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-CREATE        VALUE '7711'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '7710'.
           05  WS-USRP-TAX-YR               PIC 9(4).
           05  WS-USRP-SEQ-NUM              PIC 9(4).
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '7710'.
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************

       COPY CCWWLOCK.

      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRUSRP.
       COPY CCFWUSRP.
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
021930*COPY XCWLDTLK.
028298 COPY CCWL2626.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL8090.

      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7711.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.


           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7711'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  7000-BUILD-KEY
               THRU 7000-BUILD-KEY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  USRP-1000-READ
               THRU USRP-1000-READ-X.

           IF  WUSRP-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE 'XS00000003'  TO WGLOB-MSG-REF-INFO
               MOVE WUSRP-KEY     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1             TO WGLOB-MSG-ERROR-SW
               GO TO 2000-CREATE-X
           END-IF.


           PERFORM  USRP-1000-CREATE
               THRU USRP-1000-CREATE-X.

           SET  RUSRP-USRP-SRC-MANL     TO TRUE.

           PERFORM  USRP-1000-WRITE
               THRU USRP-1000-WRITE-X.

           PERFORM  USRP-1000-READ-TWRK-TS
               THRU USRP-1000-READ-TWRK-TS-X.


       2000-CREATE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  4110-EDIT-POL-ID
               THRU 4110-EDIT-POL-ID-X.

           PERFORM  4120-EDIT-TAX-YR
               THRU 4120-EDIT-TAX-YR-X.

           PERFORM  4130-EDIT-SEQ-NO
               THRU 4130-EDIT-SEQ-NO-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       4110-EDIT-POL-ID.
      *-----------------

           MOVE MIR-POL-ID           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
      *MSG:    POLICY (@1) DOES NOT EXIST
               MOVE 'CS77110001'  TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ID    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
           END-IF.

       4110-EDIT-POL-ID-X.
           EXIT.


      *-----------------
       4120-EDIT-TAX-YR.
      *-----------------

           MOVE MIR-USRP-TAX-YR             TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-TAX-YR   TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-USRP-TAX-YR
           ELSE
      *MSG: INVALID TAX YEAR
               MOVE 'CS77110004'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4120-EDIT-TAX-YR-X.
           EXIT.

      *-----------------
       4130-EDIT-SEQ-NO.
      *-----------------

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4130-EDIT-SEQ-NO-X
           END-IF.


           MOVE MIR-POL-ID            TO WUSRP-POL-ID.
           MOVE WS-USRP-TAX-YR        TO WUSRP-USRP-TAX-YR.
           MOVE ZERO                  TO WUSRP-USRP-SEQ-NUM.
           MOVE WUSRP-KEY             TO WUSRP-ENDBR-KEY.
           MOVE +999                  TO WUSRP-ENDBR-USRP-SEQ-NUM.

           PERFORM  USRP-2000-READ-MAX
               THRU USRP-2000-READ-MAX-X.

           IF  WUSRP-IO-OK
               MOVE WUSRP-MAX-USRP-SEQ-NUM TO WS-USRP-SEQ-NUM
           ELSE
               MOVE 0                      TO WS-USRP-SEQ-NUM
           END-IF.

           IF WS-USRP-SEQ-NUM = 9999
      *MSG:    CAN NOT CREATE ANOTHER RECEIPT RECORD
               MOVE 'CS77110002'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 4130-EDIT-SEQ-NO-X
           END-IF.

           ADD 1                         TO WS-USRP-SEQ-NUM.

       4130-EDIT-SEQ-NO-X.
           EXIT.
      /
      *---------------
       7000-BUILD-KEY.
      *---------------

           MOVE MIR-POL-ID            TO WUSRP-POL-ID.
           MOVE WS-USRP-TAX-YR        TO WUSRP-USRP-TAX-YR.
           MOVE WS-USRP-SEQ-NUM       TO WUSRP-USRP-SEQ-NUM.

020874*    COMPUTE L0290-INPUT-NUMBER = WUSRP-USRP-SEQ-NUM.
020874     MOVE WUSRP-USRP-SEQ-NUM         TO L0290-INPUT-V00.
           MOVE 0                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-SEQ-NUM TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO MIR-USRP-SEQ-NUM.

       7000-BUILD-KEY-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY USRP
                                '$VAR2' BY 'USRP'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
      /
       COPY CCPAUSRP.
       COPY CCPCUSRP.
       COPY CCPNUSRP.
       COPY CCPUUSRP.
       COPY CCPFUSRP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM7711                     *
      ****************************************************************
