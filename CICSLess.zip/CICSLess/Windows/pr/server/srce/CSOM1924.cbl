      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1924.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1924                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE BPFS TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015508**  6.0       NAME ENHANCEMENTS                                **
016548**  6.2       CHANGE COMP TO BINARY                            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1924'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '1924'.
016548*    05  WS-SUB                       PIC S9(4) VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4) VALUE ZERO BINARY.
016548*    05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 50   COMP.
025970*    05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 50   BINARY.
016548*    05  WS-GR                        PIC 9(04) COMP SYNC.
016548     05  WS-GR                        PIC 9(04) BINARY SYNC.
016548*    05  WS-MAX-GR        VALUE 2     PIC 9(04) COMP SYNC.
025970*    05  WS-MAX-GR        VALUE 2     PIC 9(04) BINARY SYNC.
           05  WS-PIC-999                   PIC 9(3).
020478     05  WS-EFF-DT                    PIC X(10).

025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-MAX-LIST-LINES              PIC S9(4) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT  VALUE 50.
025970     05  WS-MAX-GR                      PIC 9(04) BINARY SYNC.
025970         88  WS-MAX-GR-DEFAULT          VALUE 2.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
020478 COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCLNM.
       COPY CCFRCLNM.
020478*COPY CCFWCLNP.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
020874 COPY XCWL0290.
020478 COPY XCWL1640.
020478 COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1924.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1924'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

020478     PERFORM  2100-VALIDATE-KEYS
020478         THRU 2100-VALIDATE-KEYS-X.
020478
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

018732*    PERFORM  CLNM-1000-BROWSE
018732*        THRU CLNM-1000-BROWSE-X.
020478*    PERFORM  CLNP-1000-BROWSE
020478*        THRU CLNP-1000-BROWSE-X.


018732*    PERFORM  CLNM-2000-READ-NEXT
018732*        THRU CLNM-2000-READ-NEXT-X.
020478*    PERFORM  CLNP-2000-READ-NEXT
020478*        THRU CLNP-2000-READ-NEXT-X.

020478     PERFORM  CLNM-1000-BROWSE-PREV
020478         THRU CLNM-1000-BROWSE-PREV-X.
020478
020478     PERFORM  CLNM-2000-READ-PREV
020478         THRU CLNM-2000-READ-PREV-X.

018732*    IF  WCLNM-IO-EOF
020478*    IF  WCLNP-IO-EOF
020478     IF  WCLNM-IO-EOF
018732*        PERFORM  CLNM-3000-END-BROWSE
018732*            THRU CLNM-3000-END-BROWSE-X
020478*        PERFORM  CLNP-3000-END-BROWSE
020478*            THRU CLNP-3000-END-BROWSE-X
020478         PERFORM  CLNM-3000-END-BROWSE-PREV
020478             THRU CLNM-3000-END-BROWSE-PREV-X

      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2010-BROWSE-CLNM
               THRU 2010-BROWSE-CLNM-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB = WS-MAX-LIST-LINES
018732*        OR      WCLNM-IO-EOF.
020478*        OR      WCLNP-IO-EOF.
020478         OR      WCLNM-IO-EOF.

018732*    IF  WCLNM-IO-EOF
020478*    IF  WCLNP-IO-EOF
020478     IF  WCLNM-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE
020478         MOVE RCLNM-CLI-INDV-EFF-DT
020478                                    TO L1640-INTERNAL-DATE
020478         PERFORM 1640-8000-INTERNAL-TO-MIR
020478            THRU 1640-8000-INTERNAL-TO-MIR-X
020478         MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-INDV-EFF-DT
           END-IF.

018732*    PERFORM  CLNM-3000-END-BROWSE
018732*        THRU CLNM-3000-END-BROWSE-X.
020478*    PERFORM  CLNP-3000-END-BROWSE
020478*        THRU CLNP-3000-END-BROWSE-X.
020478     PERFORM  CLNM-3000-END-BROWSE-PREV
020478         THRU CLNM-3000-END-BROWSE-PREV-X.


       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-CLNM.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X
018732*     VARYING WS-GR FROM 1 BY 1
018732*       UNTIL WS-GR > WS-MAX-GR.

018732*    PERFORM  CLNM-2000-READ-NEXT
018732*        THRU CLNM-2000-READ-NEXT-X.
020478*    PERFORM  CLNP-2000-READ-NEXT
020478*        THRU CLNP-2000-READ-NEXT-X.
020478     PERFORM  CLNM-2000-READ-PREV
020478         THRU CLNM-2000-READ-PREV-X.

       2010-BROWSE-CLNM-X.
           EXIT.
      /
020478*-------------------
020478 2100-VALIDATE-KEYS.
020478*-------------------
020478
020478     IF  MIR-CLI-INDV-EFF-DT = SPACES
020478         MOVE WGLOB-PROCESS-DATE       TO WS-EFF-DT
020478         GO TO 2100-VALIDATE-KEYS-X
020478     ELSE
020478         MOVE MIR-CLI-INDV-EFF-DT      TO L1640-EXTERNAL-DATE
020478         PERFORM  1640-7000-MIR-TO-INT
020478             THRU 1640-7000-MIR-TO-INT-X
020478
020478         IF  L1640-NOT-VALID
020478*MSG : INVALID NAME EFFECTIVE DATE
020478             MOVE 'CS19240002'         TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478             GO TO 2100-VALIDATE-KEYS-X
020478         ELSE
020478             MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
020478         END-IF
020478     END-IF.
020478
020478     MOVE WS-EFF-DT           TO L1640-INTERNAL-DATE.
020478     PERFORM  1640-8000-INTERNAL-TO-MIR
020478         THRU 1640-8000-INTERNAL-TO-MIR-X.
020478     MOVE L1640-EXTERNAL-DATE TO MIR-CLI-INDV-EFF-DT.
020478
020478 2100-VALIDATE-KEYS-X.
020478     EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

018732*    MOVE LOW-VALUES                 TO WCLNM-KEY.
018732*    MOVE MIR-CLI-ID                 TO WCLNM-CLI-ID.
018732*
018732*    EVALUATE TRUE
018732*
018732*        WHEN WGLOB-COUNTRY-JAPAN
018732*             SET  WCLNM-CLI-INDV-GR-KATAKANA
018732*               TO TRUE
018732*
018732*        WHEN OTHER
018732*             SET  WCLNM-CLI-INDV-GR-ALPHA
018732*               TO TRUE
018732*
018732*    END-EVALUATE.
018732*
018732*    SET  WCLNM-CLI-INDV-NM-TYP-PREV TO TRUE.
018732*    MOVE +1                         TO WCLNM-CLI-INDV-SEQ-NUM.
018732*
018732*    MOVE WCLNM-KEY           TO WCLNM-ENDBR-KEY.
018732*    MOVE HIGH-VALUES         TO WCLNM-CLI-INDV-GR-CD.
018732*    MOVE +999                TO WCLNM-ENDBR-CLI-INDV-SEQ-NUM.

020478*    MOVE LOW-VALUE                  TO WCLNP-KEY.
020478*    MOVE MIR-CLI-ID                 TO WCLNP-CLI-ID.
020478*    SET WCLNM-CLI-INDV-NM-TYP-PREV  TO TRUE.
020478*    MOVE WCLNM-CLI-INDV-NM-TYP-CD   TO WCLNP-CLI-INDV-NM-TYP-CD.
020478*    MOVE +1                         TO WCLNP-CLI-INDV-SEQ-NUM.
020478*    MOVE WCLNP-KEY           TO WCLNP-ENDBR-KEY.
020478*    MOVE +999                TO WCLNP-ENDBR-CLI-INDV-SEQ-NUM.
020478*    MOVE HIGH-VALUE          TO WCLNP-ENDBR-CLI-INDV-GR-CD.

020478     MOVE MIR-CLI-ID          TO WCLNM-CLI-ID.
020478     MOVE WS-EFF-DT           TO WCLNM-CLI-INDV-EFF-DT.
020478     MOVE HIGH-VALUE          TO WCLNM-CLI-INDV-GR-CD.
020478     MOVE LOW-VALUE           TO WCLNM-ENDBR-KEY.
020478     MOVE WCLNM-CLI-ID        TO WCLNM-ENDBR-CLI-ID.
020478     MOVE WWKDT-LOW-DT        TO WCLNM-ENDBR-CLI-INDV-EFF-DT.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES
             TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

018732*    IF  WS-GR > 1
018732*
018732*        IF  WGLOB-COUNTRY-JAPAN
018732*            CONTINUE
018732*        ELSE
018732*            GO TO 9200-MOVE-RECORD-TO-SCREEN-X
018732*        END-IF
018732*
018732*        ADD  1                          TO WS-SUB
018732*
018732*        SET  WCLNM-CLI-INDV-GR-KANJI    TO TRUE
018732*        PERFORM  CLNM-1000-READ
018732*            THRU CLNM-1000-READ-X
018732*        IF  NOT WCLNM-IO-OK
018732*            GO TO 9200-MOVE-RECORD-TO-SCREEN-X
018732*        END-IF
018732*
018732*    END-IF.

020874*    MOVE RCLNM-CLI-INDV-SEQ-NUM
020874*      TO WS-PIC-999.
020874*    MOVE WS-PIC-999
020874*      TO MIR-CLI-INDV-SEQ-NUM-T (WS-SUB).
020478*    MOVE RCLNM-CLI-INDV-SEQ-NUM TO L0290-INPUT-V00.
020478*    MOVE ZERO                  TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-CLI-INDV-SEQ-NUM-T (WS-SUB)
020478*                               TO L0290-MAX-OUT-LEN.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA  TO MIR-CLI-INDV-SEQ-NUM-T (WS-SUB).
020478     MOVE RCLNM-CLI-INDV-EFF-DT TO L1640-INTERNAL-DATE
020478     PERFORM 1640-8000-INTERNAL-TO-MIR
020478        THRU 1640-8000-INTERNAL-TO-MIR-X
020478     MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-INDV-EFF-DT-T
020478                                   (WS-SUB).

           MOVE RCLNM-ENTR-GIV-NM
             TO MIR-ENTR-GIV-NM-T (WS-SUB).

           MOVE RCLNM-CLI-INDV-GIV-NM
             TO MIR-CLI-INDV-GIV-NM-T (WS-SUB).

           MOVE RCLNM-ENTR-SUR-NM
             TO MIR-ENTR-SUR-NM-T (WS-SUB).

           MOVE RCLNM-CLI-INDV-SUR-NM
             TO MIR-CLI-INDV-SUR-NM-T (WS-SUB).

           MOVE RCLNM-CLI-INDV-MID-NM
             TO MIR-CLI-INDV-MID-NM-T (WS-SUB).

           MOVE RCLNM-CLI-INDV-SFX-NM
             TO MIR-CLI-INDV-SFX-NM-T (WS-SUB).

           MOVE RCLNM-CLI-INDV-TITL-TXT
             TO MIR-CLI-INDV-TITL-TXT-T (WS-SUB).

018732     MOVE RCLNM-CLI-INDV-GR-CD
018732       TO MIR-CLI-INDV-GR-CD-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT
             TO TRUE.
           MOVE MIR-CLI-ID
             TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     SET  WS-MAX-GR-DEFAULT              TO TRUE.
025970     SET  WS-MAX-LIST-LINES-DEFAULT      TO TRUE.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
025970 COPY XCPS1640.
020478 COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
018732*COPY CCPBCLNM.
020478*COPY CCPBCLNP.
020478 COPY CCPVCLNM.
018732*COPY CCPNCLNM.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM1924                     **
      *****************************************************************
