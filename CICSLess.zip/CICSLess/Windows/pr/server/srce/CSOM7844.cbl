      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7844.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7844                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE LIST FUNCTION           **
      **            FOR THE FUTURE DATED CLIENT ACTIVITY             **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
029053**  7.1       RENAME CLIO ACCESS NAME TO CLIR                  **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7844'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-CONSTANT-FIELDS.
               10  WS-MAX-LIST-LINES                PIC S9(04) BINARY.
                   88  WS-MAX-LIST-LINES-DEFAULT        VALUE 100.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID                    PIC X(04).
                   88  WS-BUS-FCN-LIST                  VALUE '7844'.
               10  WS-SUB                           PIC S9(04) BINARY.
               10  WS-TS                            PIC X(26).
               10  WS-EFF-DT-INT                    PIC X(10).
               10  WS-BNK-ACCT-NUM                  PIC 9(03).
               10  WS-BNK-ACCT-NUM-N REDEFINES
                   WS-BNK-ACCT-NUM.
                   15  WS-BNK-ACCT-NUM-1-2          PIC 9(02).
                   15  WS-BNK-ACCT-NUM-3            PIC 9(01).
               10  WS-VALIDATE-SW                   PIC X(01).
                   88  WS-VALIDATE-OK                   VALUE 'Y'.
                   88  WS-VALIDATE-NOT-OK               VALUE 'N'.
036742         10  WS-CLI-BNK-GEN-ID                PIC 9(10).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCLI.
       COPY CCFRCLI.
       COPY CCFWCLRS.
       COPY CCFRCLRQ.
      /
       COPY CCFWCLNQ.
       COPY CCFRCLNM.
      /
       COPY CCFWCLIQ.
       COPY CCFRCLIA.
      /
029053*COPY CCFWCLIO.
029053 COPY CCFWCLIR.
       COPY CCFRCLIB.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
       COPY XCWL1640.
      /
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7844.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7844'          TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'        TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                             TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-LIST.
      *------------
      *
      * PERFORM EDITS
      *
           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WS-VALIDATE-NOT-OK
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-CLRS-ALT-KEY
               THRU 7000-BUILD-CLRS-ALT-KEY-X.

      *
      * BROWSE THE CLEINT FUTURE DATED ACTIVITY TABLE
      * USING ALTERNATIVE INDEX (EFFECTIVE TIMESTAMP/
      * CREATE TIMESTAMP).
      *
           PERFORM  CLRS-1000-BROWSE
               THRU CLRS-1000-BROWSE-X.

           PERFORM  CLRS-2000-READ-NEXT
               THRU CLRS-2000-READ-NEXT-X.

           IF  WCLRS-IO-EOF
               PERFORM  CLRS-3000-END-BROWSE
                   THRU CLRS-3000-END-BROWSE-X
      *MSG: 'NO FUTURE DATED ACTIVITIES EXISTS'
               MOVE 'CS78440003'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                         TO WS-SUB.

           PERFORM  2010-BROWSE-CLRS
               THRU 2010-BROWSE-CLRS-X
               UNTIL   WS-SUB >= WS-MAX-LIST-LINES
               OR      NOT WCLRS-IO-OK.

           IF  WCLRS-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
               MOVE 'XS00000014'             TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-MOVE-RECORD-TO-KEY
                   THRU 9100-MOVE-RECORD-TO-KEY-X
           ELSE
               MOVE MIR-CLI-RQST-EFF-DT-T (1)
                                             TO MIR-CLI-RQST-EFF-DT
               MOVE MIR-CLI-RQST-CREAT-TS-T (1)
                                             TO MIR-CLI-RQST-CREAT-TS
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'             TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  CLRS-3000-END-BROWSE
               THRU CLRS-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
       2010-BROWSE-CLRS.
      *-----------------

           EVALUATE  TRUE

               WHEN RCLRQ-CLI-RQST-INDV-NM-CHNG
                    PERFORM  2020-GET-CLIENT-NAME
                        THRU 2020-GET-CLIENT-NAME-X
                    IF  NOT RCLNM-CLI-INDV-GR-KANJI
                        PERFORM  9200-MOVE-RECORD-TO-MIR
                            THRU 9200-MOVE-RECORD-TO-MIR-X
                    END-IF

               WHEN RCLRQ-CLI-RQST-CLI-ADDR-CHNG
                    PERFORM  2030-GET-CLIENT-ADDR
                        THRU 2030-GET-CLIENT-ADDR-X
                    IF  NOT RCLIA-CLI-ADDR-GR-KATAKANA
                        PERFORM  9200-MOVE-RECORD-TO-MIR
                            THRU 9200-MOVE-RECORD-TO-MIR-X
                    END-IF

               WHEN RCLRQ-CLI-RQST-CLI-BNK-CHNG
                    PERFORM  2040-GET-CLIENT-BANK
                        THRU 2040-GET-CLIENT-BANK-X
                    PERFORM  9200-MOVE-RECORD-TO-MIR
                        THRU 9200-MOVE-RECORD-TO-MIR-X

           END-EVALUATE.

           PERFORM  CLRS-2000-READ-NEXT
               THRU CLRS-2000-READ-NEXT-X.

       2010-BROWSE-CLRS-X.
           EXIT.

      *---------------------
       2020-GET-CLIENT-NAME.
      *---------------------

      * ALT KEY FOR CLNM

      *
      * USE ALTERNATIVE KEY TO BROWSE, INSTEAD OF READ FUCNTION TO
      * GET CLIENT NAME (AVOID PROBLEM OF NULL KEY VALUE)
      *

           MOVE RCLRQ-CLI-ID                 TO WCLNQ-CLI-ID
           MOVE RCLRQ-CLI-RQST-CREAT-TS
                                             TO WCLNQ-CLI-RQST-CREAT-TS

           MOVE WCLNQ-KEY                    TO WCLNQ-ENDBR-KEY.

           PERFORM  CLNQ-1000-BROWSE
               THRU CLNQ-1000-BROWSE-X.

           PERFORM  CLNQ-2000-READ-NEXT
               THRU CLNQ-2000-READ-NEXT-X.

           IF  NOT WCLNQ-IO-OK
      *MSG: 'FUTURE CLIENT NAME READ FAILED'
               MOVE 'CS78440004'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED     TO TRUE
           END-IF.

           PERFORM  CLNQ-3000-END-BROWSE
               THRU CLNQ-3000-END-BROWSE-X.

       2020-GET-CLIENT-NAME-X.
           EXIT.

      *---------------------
       2030-GET-CLIENT-ADDR.
      *---------------------

      * ALT KEY FOR CLIA

      *
      * USE ALTERNATIVE KEY TO BROWSE, INSTEAD OF READ FUCNTION TO
      * GET CLIENT ADDRESS (AVOID PROBLEM OF NULL KEY VALUE)
      *

           MOVE RCLRQ-CLI-ID                 TO WCLIQ-CLI-ID
           MOVE RCLRQ-CLI-RQST-CREAT-TS
                                             TO WCLIQ-CLI-RQST-CREAT-TS

           MOVE WCLIQ-KEY                    TO WCLIQ-ENDBR-KEY.

           PERFORM  CLIQ-1000-BROWSE
               THRU CLIQ-1000-BROWSE-X.

           PERFORM  CLIQ-2000-READ-NEXT
               THRU CLIQ-2000-READ-NEXT-X.

           IF  NOT WCLIQ-IO-OK
      *MSG: 'FUTURE CLIENT ADDRESS READ FAILED'
               MOVE 'CS78440005'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED     TO TRUE
           END-IF.

           PERFORM  CLIQ-3000-END-BROWSE
               THRU CLIQ-3000-END-BROWSE-X.

       2030-GET-CLIENT-ADDR-X.
           EXIT.

      *---------------------
       2040-GET-CLIENT-BANK.
      *---------------------

      * ALT KEY FOR CLIB

      *
      * USE ALTERNATIVE KEY TO BROWSE, INSTEAD OF READ FUCNTION TO
      * GET CLIENT BANK INFORMATION (AVOID PROBLEM OF NULL KEY VALUE)
      *

029053*    MOVE RCLRQ-CLI-ID                 TO WCLIO-CLI-ID
029053*    MOVE RCLRQ-CLI-RQST-CREAT-TS
029053*                                      TO WCLIO-CLI-RQST-CREAT-TS
029053*
029053*    MOVE WCLIO-KEY                    TO WCLIO-ENDBR-KEY.
029053     MOVE RCLRQ-CLI-ID                 TO WCLIR-CLI-ID.
029053     MOVE RCLRQ-CLI-RQST-CREAT-TS      TO WCLIR-CLI-RQST-CREAT-TS.
029053     MOVE WCLIR-KEY                    TO WCLIR-ENDBR-KEY.

029053*    PERFORM  CLIO-1000-BROWSE
029053*        THRU CLIO-1000-BROWSE-X.
029053     PERFORM  CLIR-1000-BROWSE
029053         THRU CLIR-1000-BROWSE-X.

029053*    PERFORM  CLIO-2000-READ-NEXT
029053*        THRU CLIO-2000-READ-NEXT-X.
029053     PERFORM  CLIR-2000-READ-NEXT
029053         THRU CLIR-2000-READ-NEXT-X.

029053*    IF  NOT WCLIO-IO-OK
029053     IF  NOT WCLIR-IO-OK
      *MSG: 'FUTURE CLIENT BANKING READ FAILED'
               MOVE 'CS78440006'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED     TO TRUE
           END-IF.

029053*    PERFORM  CLIO-3000-END-BROWSE
029053*        THRU CLIO-3000-END-BROWSE-X.
029053     PERFORM  CLIR-3000-END-BROWSE
029053         THRU CLIR-3000-END-BROWSE-X.

       2040-GET-CLIENT-BANK-X.
           EXIT.

      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  2110-EDIT-CLI-ID
               THRU 2110-EDIT-CLI-ID-X.

           IF  WS-VALIDATE-NOT-OK
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  2120-EDIT-EFF-DT
               THRU 2120-EDIT-EFF-DT-X.

           IF  MIR-CLI-RQST-CREAT-TS = SPACE
               MOVE WWKDT-LOW-TS             TO WS-TS
           ELSE
               MOVE MIR-CLI-RQST-CREAT-TS
                                             TO WS-TS
           END-IF.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *-----------------
       2110-EDIT-CLI-ID.
      *-----------------

           IF  MIR-CLI-ID = SPACES
      *MSG: CLIENT ID MUST BE ENTERED
               MOVE 'CS78440001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

           MOVE MIR-CLI-ID                   TO WCLI-CLI-ID.

           PERFORM  CLI-1000-READ
               THRU CLI-1000-READ-X.

           IF  NOT WCLI-IO-OK
      *MSG: 'CLIENT (@1) DOES NOT EXIST
               MOVE 'XS00000076'             TO WGLOB-MSG-REF-INFO
               MOVE  WCLI-CLI-ID             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.


       2110-EDIT-CLI-ID-X.
           EXIT.
      /
      *-----------------
       2120-EDIT-EFF-DT.
      *-----------------

           IF  MIR-CLI-RQST-EFF-DT = SPACE
               MOVE WWKDT-LOW-DT             TO WS-EFF-DT-INT
               GO TO 2120-EDIT-EFF-DT-X
           END-IF.

           MOVE MIR-CLI-RQST-EFF-DT          TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      * MSG EFFECTIVE DATE (@1) INVALID
               MOVE 'CS78440002'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-RQST-EFF-DT      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
               GO TO 2120-EDIT-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE          TO WS-EFF-DT-INT.

       2120-EDIT-EFF-DT-X.
           EXIT.
      /
      *----------------
       7000-BUILD-CLRS-ALT-KEY.
      *----------------

           MOVE LOW-VALUES                   TO WCLRS-KEY.
           MOVE MIR-CLI-ID                   TO WCLRS-CLI-ID.
           MOVE WS-EFF-DT-INT                TO WCLRS-CLI-RQST-EFF-DT.
           MOVE WS-TS                        TO WCLRS-CLI-RQST-CREAT-TS.

           MOVE WCLRS-KEY                    TO WCLRS-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT        TO WCLRS-ENDBR-CLI-RQST-EFF-DT.
           MOVE WWKDT-HIGH-TS        TO WCLRS-ENDBR-CLI-RQST-CREAT-TS.

       7000-BUILD-CLRS-ALT-KEY-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                        TO MIR-CLI-RQST-EFF-DT-G.
           MOVE SPACE                        TO MIR-CLI-RQST-CREAT-TS-G.
           MOVE SPACE                        TO MIR-CLI-RQST-TYP-CD-G.
           MOVE SPACE                        TO MIR-BUS-FCN-ID-G.
           MOVE SPACE                        TO MIR-USER-ID-G.
           MOVE SPACE                        TO MIR-CLI-INDV-GR-CD-G.
           MOVE SPACE                        TO MIR-CLI-ADDR-GR-CD-G.
           MOVE SPACE                        TO MIR-CLI-ADDR-TYP-CD-G.
           MOVE SPACE                        TO MIR-CLI-BNK-ACCT-NUM-G.
           MOVE SPACE                        TO MIR-BNK-ID-G.
           MOVE SPACE                        TO MIR-BNK-BR-ID-G.
           MOVE SPACE                        TO MIR-BNK-ACCT-ID-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9100-MOVE-RECORD-TO-KEY.
      *------------------------

           MOVE RCLRQ-CLI-ID                 TO MIR-CLI-ID.

           MOVE RCLRQ-CLI-RQST-EFF-DT        TO L1640-INTERNAL-DATE.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE          TO MIR-CLI-RQST-EFF-DT.

           MOVE RCLRQ-CLI-RQST-CREAT-TS      TO MIR-CLI-RQST-CREAT-TS.

       9100-MOVE-RECORD-TO-KEY-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           ADD 1                             TO WS-SUB.

           MOVE RCLRQ-CLI-RQST-EFF-DT        TO L1640-INTERNAL-DATE.

           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE          TO MIR-CLI-RQST-EFF-DT-T
                                                (WS-SUB).

           MOVE RCLRQ-CLI-RQST-CREAT-TS      TO MIR-CLI-RQST-CREAT-TS-T
                                                (WS-SUB).

           MOVE RCLRQ-CLI-RQST-TYP-CD        TO MIR-CLI-RQST-TYP-CD-T
                                                (WS-SUB).

           MOVE RCLRQ-BUS-FCN-ID             TO MIR-BUS-FCN-ID-T
                                                (WS-SUB).

           MOVE RCLRQ-USER-ID                TO MIR-USER-ID-T
                                                (WS-SUB).

           IF  MIR-RETRN-RQST-FAILED
               GO TO 9200-MOVE-RECORD-TO-MIR-X
           END-IF.

           EVALUATE  TRUE

               WHEN RCLRQ-CLI-RQST-INDV-NM-CHNG

                   MOVE RCLNM-CLI-INDV-GR-CD
                                             TO MIR-CLI-INDV-GR-CD-T
                                                (WS-SUB)

               WHEN RCLRQ-CLI-RQST-CLI-ADDR-CHNG

                   MOVE RCLIA-CLI-ADDR-GR-CD TO MIR-CLI-ADDR-GR-CD-T
                                                (WS-SUB)
                   MOVE RCLIA-CLI-ADDR-TYP-CD
                                             TO MIR-CLI-ADDR-TYP-CD-T
                                                (WS-SUB)

               WHEN RCLRQ-CLI-RQST-CLI-BNK-CHNG

                   MOVE RCLIB-CLI-BNK-ACCT-NUM
                                             TO WS-BNK-ACCT-NUM
                   MOVE WS-BNK-ACCT-NUM-3    TO MIR-CLI-BNK-ACCT-NUM-T
                                                (WS-SUB)
                   MOVE RCLIB-BNK-ID         TO MIR-BNK-ID-T
                                                (WS-SUB)
                   MOVE RCLIB-BNK-BR-ID      TO MIR-BNK-BR-ID-T
                                                (WS-SUB)
                   MOVE RCLIB-BNK-ACCT-ID    TO MIR-BNK-ACCT-ID-T
                                                (WS-SUB)
                   MOVE RCLIB-CLI-BNK-ACCT-TS
                                             TO MIR-CLI-BNK-ACCT-TS-T
                                                (WS-SUB)
036742             MOVE RCLIB-CLI-BNK-GEN-ID TO WS-CLI-BNK-GEN-ID
036742             MOVE  WS-CLI-BNK-GEN-ID   TO L0290-INPUT-V00
036742             MOVE  +0                  TO L0290-PRECISION
036742             MOVE LENGTH OF MIR-CLI-BNK-GEN-ID-T (WS-SUB)
036742                                       TO L0290-MAX-OUT-LEN
036742             SET L0290-LEAD-ZEROS-DISPLAY   TO TRUE
036742             SET L0290-SIGN-SUPPRESS        TO TRUE
036742             PERFORM  0290-2000-FORMAT-FOR-MIR
036742                 THRU 0290-2000-FORMAT-FOR-MIR-X
036742             MOVE L0290-OUTPUT-DATA      TO MIR-CLI-BNK-GEN-ID-T
036742                                            (WS-SUB)
036742
           END-EVALUATE.

           MOVE MIR-CLI-RQST-EFF-DT-T (WS-SUB)
                                             TO MIR-CLI-RQST-EFF-DT.

           MOVE MIR-CLI-RQST-CREAT-TS-T (WS-SUB)
                                             TO MIR-CLI-RQST-CREAT-TS.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                       TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE           TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                       TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID                   TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
           INITIALIZE WS-WORK-FIELDS.
           SET WS-VALIDATE-OK                TO TRUE.
           SET WS-MAX-LIST-LINES-DEFAULT     TO TRUE.
           MOVE SPACES                       TO WWKDT-WORK-FIELDS.

           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
      /
       COPY XCPL0290.
       COPY XCPS0280.
       COPY XCPS0290.
      /
       COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCLI.
      /
       COPY CCPBCLRS.
      /
       COPY CCPBCLNQ.
      /
029053*COPY CCPBCLIO.
029053 COPY CCPBCLIR.
      /
       COPY CCPBCLIQ.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM7844                     **
      *****************************************************************
