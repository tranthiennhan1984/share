      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1210.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1210                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE RT TABLE                                 **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017163**  6.2       SIGN NOTATION                                    **
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
015567**  6.5       DEFAULT VALUES FOR AGE DURATION                  **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1210'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
018764*COPY XCWLPTR.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '1210'.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1210'.
016548*    05  WS-SUB                        PIC S9(04) COMP.
016548     05  WS-SUB                        PIC S9(04) BINARY.
016548*    05  WS-MAX-RATES                  PIC S9(04) COMP VALUE +121.
025970*    05  WS-MAX-RATES                  PIC S9(04)
025970*                                      BINARY VALUE +121.
025970*    05  WS-LOW-AGE-DUR                PIC X(03) VALUE '000'.
025970*    05  WS-HIGH-AGE-DUR               PIC X(03) VALUE '999'.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1210'.
025970     05  WS-MAX-RATES                  PIC S9(04) BINARY.
025970         88  WS-MAX-RATES-DEFAULT      VALUE +121.
025970     05  WS-LOW-AGE-DUR                PIC X(03).
025970         88  WS-LOW-AGE-DUR-DEFAULT    VALUE '000'.
025970     05  WS-HIGH-AGE-DUR               PIC X(03).
025970         88  WS-HIGH-AGE-DUR-DEFAULT   VALUE '999'.

      *
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      *
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWRT.
       COPY CCFRRT.

       COPY CCFWEDIT.
       COPY CCFREDIT.

      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWL2490.
014221 COPY XCWL8090.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1210.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1210'           TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *
      *-------------
       2000-RETRIEVE.
      *-------------
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           IF MIR-RETRN-EDIT-ERROR
               GO TO 2000-RETRIEVE-X
           END-IF.
      *
           PERFORM RT-1000-BROWSE
              THRU RT-1000-BROWSE-X.
      *
           PERFORM RT-2000-READ-NEXT
              THRU RT-2000-READ-NEXT-X.

           IF  WRT-IO-EOF
      *MSG: RECORD @1 NOT FOUND
               MOVE WRT-KEY                   TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'              TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED      TO TRUE
               PERFORM RT-3000-END-BROWSE
                  THRU RT-3000-END-BROWSE-X
               GO TO 2000-RETRIEVE-X
           END-IF.

014221     PERFORM RT-1000-READ-TWRK-TS
014221        THRU RT-1000-READ-TWRK-TS-X
014221     IF  WRT-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WRT-KEY           TO WGLOB-MSG-PARM (1)
014221         MOVE 'RT'           TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221     END-IF.

      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.
           PERFORM RT-3000-END-BROWSE
              THRU RT-3000-END-BROWSE-X.

       2000-RETRIEVE-X.
           EXIT.

      *
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.
           MOVE LOW-VALUES             TO WRT-KEY.
           MOVE MIR-RTBL-DB-OPT-CD     TO WRT-RTBL-DB-OPT-CD.
           MOVE MIR-RTBL-JNT-LIFE-CD   TO WRT-RTBL-JNT-LIFE-CD.
           MOVE MIR-LOC-GR-ID          TO WRT-LOC-GR-ID.
           MOVE MIR-RTBL-PAR-CD        TO WRT-RTBL-PAR-CD.
           MOVE MIR-RTBL-PNSN-QUALF-CD TO WRT-RTBL-PNSN-QUALF-CD.
           MOVE MIR-RTBL-RT-TYP-CD     TO WRT-RTBL-RT-TYP-CD.
           MOVE MIR-RTBL-ID            TO WRT-RTBL-ID.
           MOVE MIR-RTBL-SEX-CD        TO WRT-RTBL-SEX-CD.
           MOVE MIR-RTBL-SMKR-CD       TO WRT-RTBL-SMKR-CD.
           MOVE MIR-RTBL-STBL-1-CD     TO WRT-RTBL-STBL-1-CD.
           MOVE MIR-RTBL-STBL-2-CD     TO WRT-RTBL-STBL-2-CD.
           MOVE MIR-RTBL-STBL-3-CD     TO WRT-RTBL-STBL-3-CD.
           MOVE MIR-RTBL-STBL-4-CD     TO WRT-RTBL-STBL-4-CD.

012525     MOVE MIR-RTBL-MAT-XPRY-DUR  TO L0280-INPUT-DATA.
012525     MOVE LENGTH OF MIR-RTBL-MAT-XPRY-DUR TO L0280-INPUT-SIZE.
012525     MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
012525     MOVE ZERO                   TO L0280-PRECISION.
012525     PERFORM 0280-1000-NUMERIC-EDIT
012525          THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
012525     MOVE LENGTH OF MIR-RTBL-MAT-XPRY-DUR TO L0290-MAX-OUT-LEN.
012525     MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
012525     MOVE L0290-OUTPUT-DATA      TO WRT-RTBL-MAT-XPRY-DUR.

           MOVE MIR-DPOS-TRM-DY-DUR    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
015543*    MOVE LENGTH MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN.
015543     MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN.
           MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO WRT-DPOS-TRM-DY-DUR.
           MOVE MIR-DPOS-TRM-MO-DUR    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
015543*    MOVE LENGTH MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN.
015543     MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN.
           MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO WRT-DPOS-TRM-MO-DUR.
      *
           IF MIR-RTBL-AGE = SPACE
               MOVE SPACE              TO WRT-RTBL-AGE
           ELSE
               MOVE MIR-RTBL-AGE       TO L0280-INPUT-DATA
               MOVE LENGTH OF MIR-RTBL-AGE TO L0280-INPUT-SIZE
               MOVE ZERO               TO L0280-PRECISION
               MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
               PERFORM 0280-1000-NUMERIC-EDIT
                  THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT   TO WRT-RTBL-AGE-N
               ELSE
                   MOVE 'CS12100002'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
               END-IF
           END-IF.
      *
           MOVE MIR-RTBL-IDT-NUM       TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE TO WRT-RTBL-IDT-NUM-N
           ELSE
               MOVE 'CS12100001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
015567     IF  MIR-RTBL-AGE-DUR = SPACE
015567         MOVE WS-LOW-AGE-DUR     TO MIR-RTBL-AGE-DUR
015567     END-IF.

           MOVE MIR-RTBL-AGE-DUR       TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-AGE-DUR TO L0280-INPUT-SIZE.
           MOVE ZERO                   TO L0280-PRECISION.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT       TO WRT-RTBL-AGE-DUR
           ELSE
               MOVE 'CS12100002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           MOVE WRT-KEY                TO WRT-ENDBR-KEY.
      *
015567     IF  MIR-DV-END-RTBL-AGE-DUR = SPACE
015567         MOVE WS-HIGH-AGE-DUR    TO MIR-DV-END-RTBL-AGE-DUR
015567     END-IF.

           MOVE MIR-DV-END-RTBL-AGE-DUR TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DV-END-RTBL-AGE-DUR TO L0280-INPUT-SIZE.
           MOVE ZERO                   TO L0280-PRECISION.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT       TO WRT-ENDBR-RTBL-AGE-DUR
           ELSE
               MOVE 'CS12100002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
       7000-BUILD-KEYS-X.
           EXIT.
      *
      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------
      *
           MOVE SPACE                  TO MIR-DV-MISC-HDG-TXT.
           MOVE SPACE                  TO MIR-RTBL-1-RT-G.
           MOVE SPACE                  TO MIR-RTBL-2-RT-G.
           MOVE SPACE                  TO MIR-RTBL-3-RT-G.
           MOVE SPACE                  TO MIR-RTBL-4-RT-G.
           MOVE SPACE                  TO MIR-RTBL-5-RT-G.
           MOVE SPACE                  TO MIR-RTBL-6-RT-G.
           MOVE SPACE                  TO MIR-RTBL-7-RT-G.
           MOVE SPACE                  TO MIR-RTBL-8-RT-G.
           MOVE SPACE                  TO MIR-DV-RTBL-TXT-G.
           MOVE SPACE                  TO MIR-RTBL-REASN-CD-G.
      *
       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.
           MOVE RRT-RTBL-RT-TYP-CD     TO WEDIT-ETBL-VALU-ID.
           PERFORM  RTTP-2000-DESC
               THRU RTTP-2000-DESC-X.
      *
           IF WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT TO MIR-DV-MISC-HDG-TXT
           ELSE
               MOVE SPACES             TO MIR-DV-MISC-HDG-TXT
           END-IF.
      *
           PERFORM 2490-1000-BUILD-PARM-INFO
              THRU 2490-1000-BUILD-PARM-INFO-X.
           MOVE 'CSOM1210'             TO L2490-TXT-SRC-ID.
           MOVE RRT-RTBL-RT-TYP-CD     TO L2490-TXT-SRC-REF-ID.
           PERFORM  2490-1000-RETRIEVE-TEXT
               THRU 2490-1000-RETRIEVE-TEXT-X.
      *
           IF L2490-RETRN-REC-NOT-FOUND
               PERFORM 2490-1000-BUILD-PARM-INFO
                  THRU 2490-1000-BUILD-PARM-INFO-X
               MOVE 'CSOM1210'         TO L2490-TXT-SRC-ID
               MOVE '00001'            TO L2490-TXT-SRC-REF-ID
               PERFORM 2490-1000-RETRIEVE-TEXT
                  THRU 2490-1000-RETRIEVE-TEXT-X
           END-IF.
      *
           MOVE L2490-TXT-STR-TXT(1:15) TO MIR-DV-RTBL-TXT-T (1).
           MOVE L2490-TXT-STR-TXT(17:15) TO MIR-DV-RTBL-TXT-T (2).
           MOVE L2490-TXT-STR-TXT(33:15) TO MIR-DV-RTBL-TXT-T (3).
           MOVE L2490-TXT-STR-TXT(49:15) TO MIR-DV-RTBL-TXT-T (4).
           MOVE L2490-TXT-STR-TXT(65:15) TO MIR-DV-RTBL-TXT-T (5).
           MOVE L2490-TXT-STR-TXT(81:15) TO MIR-DV-RTBL-TXT-T (6).
           MOVE L2490-TXT-STR-TXT(97:15) TO MIR-DV-RTBL-TXT-T (7).
           MOVE L2490-TXT-STR-TXT(113:15) TO MIR-DV-RTBL-TXT-T (8).
           MOVE RRT-RTBL-IDT-NUM-N     TO L1660-INVERTED-DATE.
           PERFORM 1660-3000-CONVERT-INV-TO-INT
              THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-RTBL-IDT-NUM.
           PERFORM
             VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > WS-MAX-RATES
             OR WRT-IO-EOF
020874*        COMPUTE L0290-INPUT-NUMBER = RRT-RTBL-1-RT * 100000
020874         MOVE RRT-RTBL-1-RT      TO L0290-INPUT-V05
015543*        MOVE LENGTH MIR-RTBL-1-RT-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-1-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE 5                  TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-1-RT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RRT-RTBL-2-RT * 100000
020874         MOVE RRT-RTBL-2-RT      TO L0290-INPUT-V05
015543*        MOVE LENGTH MIR-RTBL-2-RT-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-2-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE 5                  TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-2-RT-T (WS-SUB)
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
020874*        COMPUTE L0290-INPUT-NUMBER = RRT-RTBL-3-RT * 100000
020874         MOVE RRT-RTBL-3-RT      TO L0290-INPUT-V05        
015543*        MOVE LENGTH MIR-RTBL-3-RT-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-3-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE 5                  TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-3-RT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RRT-RTBL-4-RT * 100000
020874         MOVE RRT-RTBL-4-RT      TO L0290-INPUT-V05                 
015543*        MOVE LENGTH MIR-RTBL-4-RT-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-4-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE 5                  TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-4-RT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RRT-RTBL-5-RT * 100000
020874         MOVE RRT-RTBL-5-RT      TO L0290-INPUT-V05
015543*        MOVE LENGTH MIR-RTBL-5-RT-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-5-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE 5                  TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-5-RT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RRT-RTBL-6-RT * 100000
020874         MOVE RRT-RTBL-6-RT      TO L0290-INPUT-V05
015543*        MOVE LENGTH MIR-RTBL-6-RT-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-6-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE 5                  TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-6-RT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RRT-RTBL-7-RT * 100000
020874         MOVE RRT-RTBL-7-RT      TO L0290-INPUT-V05 
015543*        MOVE LENGTH MIR-RTBL-7-RT-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-7-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE 5                  TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-7-RT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RRT-RTBL-8-RT * 100000
020874         MOVE RRT-RTBL-8-RT      TO L0290-INPUT-V05 
015543*        MOVE LENGTH MIR-RTBL-8-RT-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-8-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE 5                  TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-8-RT-T (WS-SUB)
020874*        MOVE RRT-RTBL-AGE-DUR   TO L0290-INPUT-NUMBER
020874         MOVE RRT-RTBL-AGE-DUR   TO L0290-INPUT-V00
015543*        MOVE LENGTH MIR-RTBL-AGE-DUR-T (1) TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-RTBL-AGE-DUR-T (1)
                   TO L0290-MAX-OUT-LEN
               MOVE ZERO               TO L0290-PRECISION
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X 
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-RTBL-AGE-DUR-T (WS-SUB)
               MOVE RRT-RTBL-REASN-CD  TO MIR-RTBL-REASN-CD-T (WS-SUB)
               PERFORM RT-2000-READ-NEXT
                  THRU RT-2000-READ-NEXT-X
           END-PERFORM.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2490-0000-INIT-PARM-INFO
025970         THRU 2490-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.
025970     SET WS-MAX-RATES-DEFAULT     TO TRUE.
025970     SET WS-LOW-AGE-DUR-DEFAULT   TO TRUE.
025970     SET WS-HIGH-AGE-DUR-DEFAULT  TO TRUE.
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK            TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY RT
014221                         '$VAR2' BY 'RT'.
034783 COPY XCPPINIT.
       COPY CCPERTTP.
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
       COPY XCPS2490.
018764*COPY XCCL2490.
018764 COPY XCPL2490.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBRT.
014221 COPY CCPNRT.
014221 COPY CCPURT.

       COPY CCPNEDIT.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM1210 **
      *****************************************************************
