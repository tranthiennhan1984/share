      **  MEMBER :  NSOM3900                                         **
      **  REMARKS:  THIS MODULE ALLOWS THE USER TO ENTER OR REVERSE  **
      **            A PENDING DEPOSIT TO A SUSPENDED POLICY.  IF THE **
      **            USER ENTERES OR REVERSES A DEPOSIT, EDITING AND  **
      **            PROCESSING IS PERFORMED THROUGH THE FUNCTION     **
      **            DRIVER NSLF3910.  THE SCREEN ALSO OFFERS A BROWSE**
      **            FACILITY.                                        **
      **                                                             **
      **  DOMAIN :  BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557665**  5.5       SCHEDULING ENHANCEMENTS                          **
557691**  5.5       ONLINE PROCESSING FOR US QUALIFIED               **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557788**  5.5       POLICY TABLE SPLIT                               **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       MODIFICATIONS FOR LEAP YEAR                      **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
015672**  5.6A      PCR FIX FOR CONTRACTUAL PAYOUTS                  **
012624**  6.0       SECURITY                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       GLOBAL MESSAGING                                 **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       NB/AD CONSOILDATIONS                             **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016548**  6.2       CHANGE COMP TO BINARY                            **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
017303**  6.3       PCR - PENDING DEPOSIT LIST PROBLEMS              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020906**  6.4       REMOVAL OF UNUSED FIELDS FROM GLOBAL AREA        **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
031034**  7.0       TAX COMPONENTIZATION                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM3900.

       COPY XCWWCRHT.
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM3900'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  W3900-WORK-AREA.
016548*    05  W3900-LINE-INDEX             PIC S9(04) COMP.
016548     05  W3900-LINE-INDEX             PIC S9(04) BINARY.
016548*    05  W3900-NEG-ONE                PIC S9(04) COMP.
016548     05  W3900-NEG-ONE                PIC S9(04) BINARY.
           05  W3900-VALIDATE-SW            PIC X(01).
               88  W3900-VALIDATE-SUCCEEDED            VALUE 'Y'.
               88  W3900-VALIDATE-FAILED               VALUE 'N'.
           05  W3900-CVG-SW                 PIC X(01).
               88  W3900-CVG-VALID                     VALUE 'Y'.
               88  W3900-CVG-INVALID                   VALUE 'N'.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID          VALUE '1711' '1712'
                                                   '1714'.
               88  WS-BUS-FCN-PAYMENT        VALUE '1711'.
               88  WS-BUS-FCN-REVERSE        VALUE '1712'.
               88  WS-BUS-FCN-LIST           VALUE '1714'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '1711'.
           05  W3900-DEP-DT                 PIC X(10).
           05  W3900-SEQ-NUM                PIC S9(03)    COMP-3.
           05  W3900-PIC-2-0                PIC 9(02).
            05  W3900-PIC-3-0                PIC 9(03).
008455*    05  W3900-PIC-7-2                PIC 9(07).99.
557691     05  W3900-TAX-YEAR-SW            PIC X(01).
557691         88 W3900-TAX-YR-VALID        VALUE 'Y'.
557691         88 W3900-TAX-YR-INVALID      VALUE 'N'.
015290     05  W3900-SUB                    PIC 9(4).
015290     05  W3900-CVG-XTRNL-IND          PIC X.
015290         88 W3900-CVG-XTRNL           VALUE 'Y'.
015290         88 W3900-CVG-XTRNL-NO        VALUE 'N'.
031034*    05  W3900-ALLOC-INIT-SW          PIC X(01).
031034*        88 W3900-ALLOC-INIT-NO       VALUE 'N'.
031034*        88 W3900-ALLOC-INIT          VALUE 'Y'.
031034*    05  W3900-PGAL-SW                PIC X(01).
031034*        88 W3900-PGAL-INVALID        VALUE 'N'.
031034*        88 W3900-PGAL-VALID          VALUE 'Y'.
031034*    05  W3900-PLAR-RULE-SW           PIC X(01).
031034*        88  W3900-PLAR-RULE-NOT-SET  VALUE 'N'.
031034*        88  W3900-PLAR-RULE-SET      VALUE 'Y'.
031034*    05  W3900-TOT-ALLOC-AMT          PIC S9(13)V99 COMP-3.
015290     05  W3900-AMOUNT                 PIC S9(13)V99 COMP-3.
031034*    05  W3900-DFLT-ALLOC-TYP-CD      PIC X(01).
031034*    05  W3900-MIR-PGAL-INFO.
031034*        10  W3900-MIR-PGAL-ALLOC-INFO  OCCURS 9 TIMES.
031034*            15  W3900-MIR-PGAL-ALLOC-TYP-CD   PIC X(01).
031034*            15  W3900-MIR-PGAL-TRXN-PRIN-AMT  PIC X(17).
031034*            15  W3900-MIR-PGAL-TRXN-GAIN-AMT  PIC X(17).
031034*    05  W3900-HOLD-PGAL-INFO.
031034*        10  W3900-HOLD-PGAL-ALLOC-INFO OCCURS 9 TIMES.
031034*            15  W3900-HOLD-PGAL-ALLOC-TYP-CD  PIC X(01).
031034*            15  W3900-HOLD-PGAL-TRXN-PRIN-AMT
031034*                                     PIC S9(13)V99 COMP-3.
031034*            15  W3900-HOLD-PGAL-TRXN-GAIN-AMT
031034*                                     PIC S9(13)V99 COMP-3.
557691     05  W3900-TAX-YR                 PIC 9(04).
025970
015290 01  WS-CONSTANTS.
025970*    10  WS-PDGA-TBL-SIZE             PIC S9(04)
025970*                                     VALUE +9.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY              VALUE '1711'.
025970     05  WS-PDGA-TBL-SIZE             PIC S9(04).
025970         88  WS-DEFAULT-PDGA-TBL-SIZE         VALUE +9.
      *
       COPY CCWWINDX.
      *
557756*COPY CCWTYSNO.
      *
028298 COPY CCWL2626.
       COPY NCWL3910.
      *
       COPY CCWL5400.
      *
014221 COPY CCWWLOCK.
      *
       COPY XCWWWKDT.
      *
015290 COPY XCWEBLCH.
      *
      *  FILE AREA
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
       COPY CCFWPDEP.
       COPY CCFRPDEP.

015290 COPY CCFRPDGA.
015290 COPY CCFWPDGA.
      *
      *  PARAMETER AREA
      *
       COPY XCWL0280.
      *
008455 COPY XCWL0290.
008455*
013697 COPY XCWL0316.
      *
014221 COPY XCWL8090.
       COPY XCWL1640.
      *
005409 COPY XCWL1670.
      *
005409 COPY XCWL1680.
      *
016503 COPY CCWL0289.
      *
013578 COPY CCWL0620.
      *
       COPY CCWL2430.
      *
557788 COPY CCWL2470.

031034*COPY CCWL7800.
031034*COPY CCWLPGAL.
031034*COPY CCWLCNEX.
031034 COPY CCWLPGAC.
      *
       COPY XCWLDTLK.
      *
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
       COPY CCWLPGA.
      *
       COPY CCFRPOL.
      *
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM3900.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
025970*    INITIALIZE W3900-WORK-AREA.
           MOVE -1                    TO W3900-NEG-ONE.
025970*    INITIALIZE FREQUENTLY-USED-INDICES.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      ********************
      *
      ***************************************************************
      *   NORMAL PROCESSING: DISTRIBUTE CONTROL TO THE APPROPRIATE
      *   PROCESSING ROUTINE.
      ***************************************************************
      ***************************
       2000-PROCESS-REQUEST.
      ***************************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034     PERFORM  PGAC-1000-BUILD-PARM-INFO
031034         THRU PGAC-1000-BUILD-PARM-INFO-X.

025970*    INITIALIZE W3900-HOLD-PGAL-INFO.
025970*    INITIALIZE W3900-MIR-PGAL-INFO.
031034*    SET W3900-PGAL-VALID       TO TRUE.

025388*    IF  MIR-REG-FND-SRC-CD-T (01) = EBLCH-BLANK-FIELD-CHAR
025388*        MOVE SPACES TO MIR-REG-FND-SRC-CD-T (01)
025388*    END-IF.

           PERFORM  9700-SETUP-MSIN-REFERENCE
               THRU 9700-SETUP-MSIN-REFERENCE-X

           SET W3900-VALIDATE-SUCCEEDED TO TRUE.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

031034*    PERFORM
031034*       VARYING  LPGAL-SUB FROM +1 BY +1
031034*          UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*          MOVE MIR-PLAR-ALLOC-TYP-CD-T (LPGAL-SUB)
031034*            TO W3900-MIR-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*          MOVE MIR-PDGA-PRIN-AMT-T (LPGAL-SUB)
031034*            TO W3900-MIR-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*          MOVE MIR-PDGA-GAIN-AMT-T (LPGAL-SUB)
031034*            TO W3900-MIR-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*    END-PERFORM.
031034     PERFORM
031034         VARYING W3900-SUB FROM +1 BY +1
031034         UNTIL   W3900-SUB >  WS-PDGA-TBL-SIZE
031034         MOVE MIR-PLAR-ALLOC-TYP-CD-T (W3900-SUB)
031034            TO LPGAC-PGAL-ALLOC-TYP-CD-T (W3900-SUB)
031034         MOVE MIR-PDGA-PRIN-AMT-T (W3900-SUB)
031034            TO LPGAC-PGAL-TRXN-PRIN-AMT-T (W3900-SUB)
031034         MOVE MIR-PDGA-GAIN-AMT-T (W3900-SUB)
031034            TO LPGAC-PGAL-TRXN-GAIN-AMT-T (W3900-SUB)
031034     END-PERFORM.
015290
015290     PERFORM  4890-INIT-PGAL-ALLOC-INFO
015290         THRU 4890-INIT-PGAL-ALLOC-INFO-X
015290         VARYING W3900-SUB FROM +1 BY +1
031034*          UNTIL W3900-SUB > LPGAL-MAX-ALLOC-TYP.
031034           UNTIL W3900-SUB > WS-PDGA-TBL-SIZE.

017303     PERFORM 2110-EDIT-POLICY-ID
017303        THRU 2110-EDIT-POLICY-ID-X.
017303
017303     IF W3900-VALIDATE-FAILED
017303        GO TO 2000-PROCESS-REQUEST-X
017303     END-IF.

557788*
557788* READ SUSPEND INFORMATION
557788*
557788     PERFORM 2470-1000-BUILD-PARM-INFO
557788        THRU 2470-1000-BUILD-PARM-INFO-X.
557788*
557788     IF RPOL-POL-SUSPENDED
557788         PERFORM 2470-1000-READ-SUSPEND
557788            THRU 2470-1000-READ-SUSPEND-X
557788         IF NOT L2470-RETRN-OK
557788*MSG 'POLICY OUT OF SYNC WITH SPND FOR @1 IN @2'
557788             MOVE RPOL-POL-ID   TO WGLOB-MSG-PARM (1)
557788             MOVE WGLOB-MAIN-PGM-ID
                                      TO WGLOB-MSG-PARM (2)
557788             MOVE 'XS00000229'  TO WGLOB-MSG-REF-INFO
557788             PERFORM  0260-1000-GENERATE-MESSAGE
557788                 THRU 0260-1000-GENERATE-MESSAGE-X
557788         END-IF
557788     END-IF.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '1'
                   PERFORM  2100-EDIT-CONTROL-FIELDS-1
                       THRU 2100-EDIT-CONTROL-FIELDS-1-X

               WHEN OTHER
                   PERFORM  2200-EDIT-CONTROL-FIELDS-2
                       THRU 2200-EDIT-CONTROL-FIELDS-2-X

           END-EVALUATE.

           IF W3900-VALIDATE-FAILED
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.


           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                   PERFORM  3000-PROCESS-LIST
                       THRU 3000-PROCESS-LIST-X

               WHEN WS-BUS-FCN-PAYMENT
                   PERFORM  4000-PROCESS-PAYMENT
                       THRU 4000-PROCESS-PAYMENT-X
031034             IF  LPGAC-PGAL-ALLOC-REQ
031034                 PERFORM  4850-RGN-EXIT-FOR-GAIN
031034                     THRU 4850-RGN-EXIT-FOR-GAIN-X
031034                 IF  NOT L0316-RETRN-OK
031034                 OR  L0316-RGN-EXIT-STAT-INACTV
031034                     PERFORM  PGAC-6000-POL-GAIN-REFRESH
031034                         THRU PGAC-6000-POL-GAIN-REFRESH-X
031034                 END-IF
031034             END-IF

               WHEN WS-BUS-FCN-REVERSE
                   PERFORM  5000-PROCESS-REVERSAL
                       THRU 5000-PROCESS-REVERSAL-X


               WHEN OTHER

      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                     MOVE MIR-BUS-FCN-ID
                                       TO WGLOB-MSG-PARM (1)
                     MOVE 'NSOM3900'
                                       TO WGLOB-MSG-PARM (2)
                     MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
                     PERFORM  0260-1000-GENERATE-MESSAGE
                         THRU 0260-1000-GENERATE-MESSAGE-X
                     SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.


       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      ****************************************************************
      * DO ALL VALIDITY CHECKS ON KEY AND CONTROL FIELDS THAT ARE NOT
      * FUNCTION SPECIFIC FOR INITIAL SCREEN (FORCE = 1)
      ****************************************************************
       2100-EDIT-CONTROL-FIELDS-1.


           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X

           IF WGLOB-MSG-ERROR-SW = ZERO
               CONTINUE
           ELSE
               SET W3900-VALIDATE-FAILED     TO TRUE
               GO TO 2100-EDIT-CONTROL-FIELDS-1-X
           END-IF.

           PERFORM  2110-EDIT-POLICY-ID
               THRU 2110-EDIT-POLICY-ID-X.

           IF W3900-VALIDATE-FAILED
               CONTINUE
           ELSE
               PERFORM  2120-EDIT-POLICY
                   THRU 2120-EDIT-POLICY-X
           END-IF.

           PERFORM  2130-EDIT-DEPOSIT-DATE
               THRU 2130-EDIT-DEPOSIT-DATE-X.

           IF WS-BUS-FCN-PAYMENT
               CONTINUE
           ELSE
               PERFORM  2140-EDIT-SEQUENCE-NUMBER
                   THRU 2140-EDIT-SEQUENCE-NUMBER-X
           END-IF.

       2100-EDIT-CONTROL-FIELDS-1-X.
           EXIT.
      *
      ***************************************************************
      *    EDIT POLICY NUMBER - POLICY MUST EXIST
      ***************************************************************
       2110-EDIT-POLICY-ID.

           PERFORM  8000-BUILD-POL-KEY
               THRU 8000-BUILD-POL-KEY-X.

014221     IF MIR-DV-PRCES-STATE-CD = 1

014221       PERFORM  POL-1000-READ-TWRK-TS
014221           THRU POL-1000-READ-TWRK-TS-X
014221     ELSE

             PERFORM  POL-1000-READ
                 THRU POL-1000-READ-X
014221     END-IF.


           IF NOT WPOL-IO-OK
      *** MSG (S) POLICY (@1) DOES NOT EXIST
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  W3900-VALIDATE-FAILED    TO TRUE
           ELSE
               MOVE RPOL-POL-ID       TO LPGA-POLICY-NUMBER
           END-IF.
      *
557665* PDEP PAYMENTS CAN ONLY BE DONE ON SUSPENDED POLICIES
      *
557665     IF  WS-BUS-FCN-PAYMENT
               IF RPOL-POL-NOT-SUSPENDED
557665*MSG: POLICY MUST BE SUSPENDED TO DO PAYMENTS
                   MOVE 'NS39000007'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   SET  W3900-VALIDATE-FAILED    TO TRUE
557665         END-IF
           END-IF.

       2110-EDIT-POLICY-ID-X.
           EXIT.
      *
      ***************************************************************
      *    EDIT POLICY
557665*    - POLICY MUST BE IN NBS FOR PAYMENT FUNCTION
      *    - POLICY MUST BE SUSPENDED
      *    - POLICY MUST ALLOW DEPOSITS
      ***************************************************************
       2120-EDIT-POLICY.

557665*** POLICY MUST BE IN NBS IF PROCESSING A PAYMENT
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET  L5400-STAT-MSG-NOT-REQD      TO TRUE.
557665*    SET  L5400-SYS-APPL-CTL-NB        TO TRUE.
012624*    SET  L5400-CTL-MSG-NOT-REQD       TO TRUE.

016440     IF  WS-BUS-FCN-PAYMENT
016440     OR  WS-BUS-FCN-REVERSE
016440         SET L5400-POL-XFER-UPDATE     TO TRUE
016440     END-IF.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.
557665*    IF L5400-RETRN-OK
557665*        CONTINUE
557665*    ELSE
557665*        SET W3900-VALIDATE-FAILED     TO TRUE
557665*        GO TO 2120-EDIT-POLICY-X
557665*    END-IF.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
016440     OR L5400-XFER-ACCS-RESTRICTED
               SET W3900-VALIDATE-FAILED     TO TRUE
               GO TO 2120-EDIT-POLICY-X
           END-IF.

557665*    IF L5400-CTL-ACCS-RESTRICTED
557665*        SET  W3900-VALIDATE-FAILED    TO TRUE
557665*        GO TO 2120-EDIT-POLICY-X
557665*    END-IF.

       2120-EDIT-POLICY-X.
           EXIT.
      *
      ***************************************************************
      *   DEFAULT DEPOSIT DATE - EQUAL TO SUSPEND EFFECTIVE DATE OF
      *   POLICY, IF THERE IS ONE, OTHERWISE IS CURRENT DATE
      ***************************************************************
       2121-DEFAULT-DEPOSIT-DATE.

017303*    IF WPOL-IO-OK
557788*        IF RPOL-POL-SPND-EFF-DT > WWKDT-ZERO-DT
557788*            MOVE RPOL-POL-SPND-EFF-DT TO L1640-INTERNAL-DATE
017303*        IF L2470-SPND-POL-EFF-DT > WWKDT-ZERO-DT
017303*           MOVE L2470-SPND-POL-EFF-DT
017303*                               TO L1640-INTERNAL-DATE
017303*        ELSE
017303*           MOVE WGLOB-PROCESS-DATE
017303*                               TO L1640-INTERNAL-DATE
017303*        END-IF
017303*    ELSE
017303*        MOVE WGLOB-PROCESS-DATE       TO L1640-INTERNAL-DATE
017303*    END-IF.

017303     IF  WPOL-IO-OK
017303        EVALUATE  TRUE
017303          WHEN  L2470-SPND-POL-EFF-DT > WWKDT-ZERO-DT
017303                MOVE L2470-SPND-POL-EFF-DT
017303                                 TO L1640-INTERNAL-DATE
017303          WHEN  RPOL-POL-ISS-EFF-DT > WWKDT-ZERO-DT
017303                MOVE RPOL-POL-ISS-EFF-DT
017303                                 TO L1640-INTERNAL-DATE
017303          WHEN  OTHER
017303                MOVE WWKDT-LOW-DT
017303                                TO L1640-INTERNAL-DATE
017303        END-EVALUATE
017303     ELSE
017303        MOVE  WWKDT-LOW-DT      TO L1640-INTERNAL-DATE
017303     END-IF.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-PEND-DPOS-EFF-DT.

       2121-DEFAULT-DEPOSIT-DATE-X.
           EXIT.
      *
      ***************************************************************
      *    EDIT DEPOSIT DATE - MUST BE A VALID DATE IN DDMMMYYY
      *    FORMAT
      ***************************************************************
       2130-EDIT-DEPOSIT-DATE.

           IF MIR-PEND-DPOS-EFF-DT = SPACES
               PERFORM  2121-DEFAULT-DEPOSIT-DATE
                   THRU 2121-DEFAULT-DEPOSIT-DATE-X
               MOVE L1640-INTERNAL-DATE
                                      TO W3900-DEP-DT
               GO TO 2130-EDIT-DEPOSIT-DATE-X
           END-IF.

           MOVE MIR-PEND-DPOS-EFF-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
      *** MSG (S) DEPOSIT DATE MUST BE VALID DATE IN FORMAT DDMMMYYYY
               MOVE 'NS39000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET W3900-VALIDATE-FAILED   TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO W3900-DEP-DT
           END-IF.

       2130-EDIT-DEPOSIT-DATE-X.
           EXIT.
      *
      ***************************************************************
      *    EDIT SEQUENCE NUMBER - MUST BE NUMERIC, DEFAULT TO 1
      *    NOT REQUIRED ON A PAYMENT
      ***************************************************************
       2140-EDIT-SEQUENCE-NUMBER.

           IF MIR-PEND-DPOS-SEQ-NUM = SPACES
               MOVE 1                 TO W3900-SEQ-NUM
               MOVE '001'             TO MIR-PEND-DPOS-SEQ-NUM
               GO TO 2140-EDIT-SEQUENCE-NUMBER-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-PEND-DPOS-SEQ-NUM TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO W3900-SEQ-NUM
020874*        MOVE W3900-SEQ-NUM     TO W3900-PIC-3-0
020874*        MOVE W3900-PIC-3-0     TO MIR-PEND-DPOS-SEQ-NUM
020874         MOVE L0280-OUTPUT          TO W3900-SEQ-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PEND-DPOS-SEQ-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA         TO MIR-PEND-DPOS-SEQ-NUM
           ELSE
      *** MSG (S) SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'NS39000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  W3900-VALIDATE-FAILED    TO TRUE
           END-IF.

       2140-EDIT-SEQUENCE-NUMBER-X.
           EXIT.
      *
      ****************************************************************
      * DO ALL VALIDITY CHECKS/FORMATTING ON KEY AND CONTROL FIELDS
      * FOR THE PAYMENT DATA ENTRY SCREEN (FORCE = 2)
      ****************************************************************
       2200-EDIT-CONTROL-FIELDS-2.


           PERFORM  2110-EDIT-POLICY-ID
               THRU 2110-EDIT-POLICY-ID-X.

           PERFORM  2130-EDIT-DEPOSIT-DATE
               THRU 2130-EDIT-DEPOSIT-DATE-X.

           PERFORM  2140-EDIT-SEQUENCE-NUMBER
               THRU 2140-EDIT-SEQUENCE-NUMBER-X.

           IF W3900-VALIDATE-FAILED
               GO TO 2200-EDIT-CONTROL-FIELDS-2-X
           END-IF.


       2200-EDIT-CONTROL-FIELDS-2-X.
           EXIT.
      *
      *
      *
      ****************************************************************
      *   PDEP BROWSE
      *   SETUP PDEP BROWSE KEYS, BEGIN BROWSE, AND LOAD DATA
      *   ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.
      ****************************************************************
       3000-PROCESS-LIST.

013578*    IF MIR-DV-CLI-NM = SPACES
013578     IF MIR-DV-OWN-CLI-NM = SPACES
               CONTINUE
           ELSE
      *** MSG (I) NAME IS IGNORED ON A BROWSE - CHANGED TO SPACES
               MOVE 'NS39000004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
013578*        INITIALIZE MIR-DV-CLI-NM
013578         INITIALIZE MIR-DV-OWN-CLI-NM
           END-IF

           PERFORM  8100-BUILD-PDEP-KEY
               THRU 8100-BUILD-PDEP-KEY-X.

           MOVE MIR-POL-ID-BASE       TO WPDEP-ENDBR-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPDEP-ENDBR-POL-ID-SFX.
           MOVE WWKDT-HIGH-DT         TO WPDEP-ENDBR-PEND-DPOS-EFF-DT.
           MOVE 999                   TO WPDEP-ENDBR-PEND-DPOS-SEQ-NUM.

           PERFORM  PDEP-1000-BROWSE
               THRU PDEP-1000-BROWSE-X.
           IF WPDEP-IO-OK
               CONTINUE
           ELSE
      *** MSG (I) NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-LIST-X
           END-IF.

           PERFORM  PDEP-2000-READ-NEXT
               THRU PDEP-2000-READ-NEXT-X.

           IF WPDEP-IO-OK
               CONTINUE
           ELSE
      *** MSG (I) NO RECORDS FOUND TO DISPLAY
               PERFORM  PDEP-3000-END-BROWSE
                   THRU PDEP-3000-END-BROWSE-X
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-LIST-X
           END-IF.

           PERFORM  3200-UPDATE-MIR-KEY-FIELDS
               THRU 3200-UPDATE-MIR-KEY-FIELDS-X.

           PERFORM  3100-DISPLAY-NEXT-RECORD
               THRU 3100-DISPLAY-NEXT-RECORD-X
               VARYING W3900-LINE-INDEX FROM 1 BY 1
               UNTIL   W3900-LINE-INDEX > +12
               OR      NOT WPDEP-IO-OK

           IF WPDEP-IO-OK
      *** MSG (I) TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  3200-UPDATE-MIR-KEY-FIELDS
                   THRU 3200-UPDATE-MIR-KEY-FIELDS-X
           ELSE
      *** MSG (I) INQUIRE COMPLETE - CONTINUE
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDEP-3000-END-BROWSE
               THRU PDEP-3000-END-BROWSE-X.

       3000-PROCESS-LIST-X.
           EXIT.
      *
      ****************************************************************
      *   PDEP INQUIRY - DISPLAY NEXT REOCORD
557660*   INPUT: W3900-LINE-INDEX
      ****************************************************************
       3100-DISPLAY-NEXT-RECORD.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

013578     PERFORM  9300-MOVE-NAME-TO-SCREEN
013578         THRU 9300-MOVE-NAME-TO-SCREEN-X.

           PERFORM  PDEP-2000-READ-NEXT
               THRU PDEP-2000-READ-NEXT-X.

       3100-DISPLAY-NEXT-RECORD-X.
           EXIT.
      *
      ****************************************************************
      *   UPDATE MIR KEY FIELDS WITH NEXT RECORD TO DISPLAY
      ****************************************************************
       3200-UPDATE-MIR-KEY-FIELDS.

           MOVE RPDEP-POL-ID-BASE     TO MIR-POL-ID-BASE.
           MOVE RPDEP-POL-ID-SFX      TO MIR-POL-ID-SFX.

           MOVE RPDEP-PEND-DPOS-EFF-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-PEND-DPOS-EFF-DT.

020874*    MOVE RPDEP-PEND-DPOS-SEQ-NUM
020874*                               TO W3900-PIC-3-0.
020874*    MOVE W3900-PIC-3-0         TO MIR-PEND-DPOS-SEQ-NUM.
020874     MOVE RPDEP-PEND-DPOS-SEQ-NUM TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-PEND-DPOS-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-PEND-DPOS-SEQ-NUM.

       3200-UPDATE-MIR-KEY-FIELDS-X.
           EXIT.
      *
      ***************************************************************
      *    PDEP PAYMENT
      ***************************************************************
       4000-PROCESS-PAYMENT.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  4300-PAYMENT-3
                       THRU 4300-PAYMENT-3-X

               WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  4200-PAYMENT-2
                       THRU 4200-PAYMENT-2-X

               WHEN OTHER
                   PERFORM  4100-PAYMENT-1
                       THRU 4100-PAYMENT-1-X

           END-EVALUATE.

       4000-PROCESS-PAYMENT-X.
           EXIT.
      *
      ***************************************************************
      *    PDEP PAYMENT - FORCE = 1
      *    - PERFORM PAYMENT SPECIFIC EDITS
      *    - GET NEXT SEQUENCE NUMBER
      *    - SETUP SCREEN TO ALLOW DATA ENTRY
      ***************************************************************
       4100-PAYMENT-1.
      * CHECK THE 1ST FOUR CHARACTERS OF THE OWNER'S NAME
013578*    PERFORM  4110-EDIT-NAME
013578*        THRU 4110-EDIT-NAME-X.
           IF W3900-VALIDATE-FAILED
               GO TO 4100-PAYMENT-1-X
           END-IF.

      * SET UP THE PARAMETERS AND CALL THE FUNCTION-DRIVER FOR
      * FURTHER EDITS.
           PERFORM  3910-1000-BUILD-PARM-INFO
               THRU 3910-1000-BUILD-PARM-INFO-X.
           SET  L3910-PRCES-TYP-INITIAL      TO TRUE
           MOVE W3900-DEP-DT          TO L3910-DEP-DT
           IF MIR-CVG-NUM-T(1) < '00'
               MOVE '00'              TO L3910-CVG-NUM
           ELSE
               MOVE MIR-CVG-NUM-T(1)  TO L3910-CVG-NUM
           END-IF.
557660     IF MIR-PEND-DPOS-SEQ-NUM-T(1) < '000'
557660         MOVE '000'             TO L3910-SEQ-NUM
557660     ELSE
557660         MOVE MIR-PEND-DPOS-SEQ-NUM-T(1)
                                      TO L3910-SEQ-NUM
557660     END-IF.

           PERFORM  3910-1000-PDEP-PAYMENT
               THRU 3910-1000-PDEP-PAYMENT-X
           IF L3910-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR        TO TRUE
           END-IF.

      * IF THERE ARE ERRORS IN THE CONTROL FIELDS THEN HIGHLIGHT
      * THEM AND DO NOT PROCEED WITH THE TRANSACTION.
           IF L3910-POL-ID-ERROR
               SET WGLOB-RETURN-ERROR        TO TRUE
           END-IF.

           IF L3910-DEP-DT = HIGH-VALUES
               SET WGLOB-RETURN-ERROR        TO TRUE
           END-IF.

           IF WGLOB-RETURN-ERROR
               GO TO 4100-PAYMENT-1-X
           END-IF.

      * RETURN THE GENREATED SQUENCE NUMBER TO THE SCREEN
           MOVE L3910-SEQ-NUM         TO MIR-PEND-DPOS-SEQ-NUM.

      *
      *  IF REVERSED PHST RECORDS EXIST (ERP DATE ON POLICY)
      *  GIVE WARNING MESSAGE IF DEPOSIT DATE > ERP
      *
           IF RPOL-EARLST-REVRS-DT = WWKDT-ZERO-DT
               CONTINUE
           ELSE
               IF W3900-DEP-DT >= RPOL-EARLST-REVRS-DT
                   MOVE 'NS39000041'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF
      *
      * SET UP THE INITIALIZED VALUES FOR THE SCREEN
           PERFORM  8100-BUILD-PDEP-KEY
               THRU 8100-BUILD-PDEP-KEY-X.

           PERFORM  PDEP-1000-CREATE
               THRU PDEP-1000-CREATE-X.

      *
      * OPEN THE FIRST LINE OF THE SCREEN FOR PAYMENT INPUT
           MOVE +1                    TO W3900-LINE-INDEX.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

013578     PERFORM  9300-MOVE-NAME-TO-SCREEN
013578         THRU 9300-MOVE-NAME-TO-SCREEN-X.


      *** MSG (I) ENTER DEPOSIT DETAILS
           MOVE 'NS39000006'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4100-PAYMENT-1-X.
           EXIT.
      *
013578***************************************************************
013578*    EDIT NAME - MUST EQUAL FIRST 4 CHARACTERS OF OWNERS
013578*    LAST NAME
013578***************************************************************
013578*4110-EDIT-NAME.
013578*
013578*    PERFORM  2430-1000-BUILD-PARM-INFO
013578*        THRU 2430-1000-BUILD-PARM-INFO-X
013578*
013578*    MOVE MIR-DV-CLI-NM         TO L2430-OWNER-NAME-1-4
013578*
013578*    PERFORM  2430-5000-VALIDATE-OWNER-NM
013578*        THRU 2430-5000-VALIDATE-OWNER-NM-X.
013578*
013578*    EVALUATE TRUE
013578*
013578*        WHEN L2430-RETRN-OK
013578*            CONTINUE
013578*
013578*        WHEN L2430-RETRN-OWNER-NM-MISMATCH
013578*** MSG (S) NAME MUST MATCH FIRST FOUR CHARS OF OWNER'S NAME
013578*            MOVE 'NS39000008'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            SET  W3900-VALIDATE-FAILED TO TRUE
013578*
013578*        WHEN OTHER
013578* MSG:  NO CLIENT RELATIONSHIPS EXIST FOR THIS POLICY
013578*            MOVE 'NS39000042'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            SET  W3900-VALIDATE-FAILED TO TRUE
013578*            SET  WGLOB-RETURN-ERROR   TO TRUE
013578*
013578*    END-EVALUATE.
013578*
013578*4110-EDIT-NAME-X.
013578*    EXIT.
      *
      ***************************************************************
      *    PDEP PAYMENT PROCESSING - FORCE = 2
      *    - EDIT DATA
      *    - SETUP FOR VERIFY
      ***************************************************************
       4200-PAYMENT-2.

      * SET UP THE PARAMETERS FOR THE FUNCTION
           PERFORM  3910-1000-BUILD-PARM-INFO
               THRU 3910-1000-BUILD-PARM-INFO-X.

      * EDIT THE AMOUNT FOR NUMERIC FORMAT ONLY
           PERFORM  4210-EDIT-DEPOSIT-AMOUNT
               THRU 4210-EDIT-DEPOSIT-AMOUNT-X.
008455     IF W3900-VALIDATE-FAILED
008455         GO TO 4200-PAYMENT-2-X
008455     END-IF
           MOVE L0280-OUTPUT-DOLLAR   TO L3910-AMOUNT.

      * EDIT THE COVERAGE NUMBER FOR NUMERIC FORMAT ONLY
           PERFORM  4230-EDIT-COVERAGE-NUMBER
               THRU 4230-EDIT-COVERAGE-NUMBER-X.
           IF W3900-CVG-INVALID
               SET W3900-VALIDATE-FAILED     TO TRUE
               GO TO 4200-PAYMENT-2-X
           END-IF.

557691* EDIT THE TAX YEAR FOR NUMERIC FORMAT ONLY
           PERFORM  4240-EDIT-TAX-YEAR
               THRU 4240-EDIT-TAX-YEAR-X.
           IF W3900-TAX-YR-INVALID
               SET W3900-VALIDATE-FAILED     TO TRUE
               GO TO 4200-PAYMENT-2-X
           END-IF.

      * IF THERE ARE NO ERRORS, READ IN THE COVERAGES AND CALL THE
      * FUNCTION-DRIVER FOR FURTHER TESTING.
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           MOVE W3900-DEP-DT          TO L3910-DEP-DT
           MOVE W3900-SEQ-NUM         TO L3910-SEQ-NUM-N.
           MOVE MIR-REG-FND-SRC-CD-T(1)
                                      TO L3910-SOURCE.
           IF MIR-CVG-NUM-T(1) < '00'
               MOVE '00'              TO L3910-CVG-NUM
           ELSE
               MOVE MIR-CVG-NUM-T(1)  TO L3910-CVG-NUM
           END-IF.
           MOVE MIR-FND-ID-T (1)      TO L3910-FUND.
557691     MOVE MIR-PEND-DPOS-TAX-YR-T (1)
                                      TO L3910-TAX-YR.

031034*    PERFORM  4700-GET-CNTRXN-INFO
031034*        THRU 4700-GET-CNTRXN-INFO-X.

031034*    PERFORM  4800-EDIT-PGAL-INFO
031034*        THRU 4800-EDIT-PGAL-INFO-X.
031034     PERFORM  4800-EDIT-GAIN-INFO
031034         THRU 4800-EDIT-GAIN-INFO-X.

           SET  L3910-PRCES-TYP-EDIT-ONLY    TO TRUE

           PERFORM  3910-1000-PDEP-PAYMENT
               THRU 3910-1000-PDEP-PAYMENT-X.

557691     MOVE L3910-TAX-YR          TO MIR-PEND-DPOS-TAX-YR-T (1).


008455*    MOVE L3910-AMOUNT             TO W3900-PIC-7-2
008455*    MOVE W3900-PIC-7-2            TO MIR-PEND-DPOS-AMT-T(1)
020874*    COMPUTE L0290-INPUT-NUMBER = L3910-AMOUNT * 100.
020874     MOVE L3910-AMOUNT      TO L0290-INPUT-V02.
008455     MOVE 2                 TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PEND-DPOS-AMT-T (1)
008455                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-PEND-DPOS-AMT-T (1).

557691     MOVE L3910-SOURCE      TO MIR-REG-FND-SRC-CD-T (1).

           IF L3910-RETRN-OK
               CONTINUE
           ELSE
015290*        SET  WGLOB-RETURN-ERROR       TO TRUE
               GO TO 4200-PAYMENT-2-X
           END-IF.

015290     IF  W3900-VALIDATE-FAILED
015290         GO TO 4200-PAYMENT-2-X
015290     ELSE
031034*        IF  LPGAL-PGAL-ALLOC-REQ
031034*            PERFORM  4880-XEDIT-PGAL-ALLOC-AMT
031034*                THRU 4880-XEDIT-PGAL-ALLOC-AMT-X
031034         IF  LPGAC-PGAL-ALLOC-REQ
031034             PERFORM  4880-XEDIT-GAIN-ALLOC-AMT
031034                 THRU 4880-XEDIT-GAIN-ALLOC-AMT-X
015290         END-IF
015290     END-IF.

013578* SET UP THE INITIALIZED VALUES FOR THE SCREEN
013578     PERFORM  8100-BUILD-PDEP-KEY
013578         THRU 8100-BUILD-PDEP-KEY-X.
013578
013578     PERFORM  PDEP-1000-CREATE
013578         THRU PDEP-1000-CREATE-X.

013578     MOVE RPDEP-PEND-DPOS-STAT-CD  TO MIR-PEND-DPOS-STAT-CD-T (1).

015290     PERFORM  4900-RETURN-MIR-PDGA
015290         THRU 4900-RETURN-MIR-PDGA-X
015290         VARYING  W3900-SUB FROM +1 BY +1
031034*           UNTIL W3900-SUB > LPGAL-MAX-ALLOC-TYP.
031034            UNTIL W3900-SUB > WS-PDGA-TBL-SIZE.

      *** MSG (I) VERIFY DEPOSIT DETAILS
           MOVE 'NS39000011'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

013578     PERFORM  9300-MOVE-NAME-TO-SCREEN
013578         THRU 9300-MOVE-NAME-TO-SCREEN-X.

       4200-PAYMENT-2-X.
           EXIT.
      *
      ***************************************************************
      *    EDIT DEPOSIT AMOUNT - MUST BE NUMERIC, FORMAT 999999999.99
      ***************************************************************
       4210-EDIT-DEPOSIT-AMOUNT.

           SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                            TO L0280-LENGTH.
008455*    MOVE 10                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PEND-DPOS-AMT-T (1)
                                      TO L0280-INPUT-SIZE
008455***  CHECK  (IN 3270 TERMINAL ENVIRONMENT)  TO CONTROL
008455***  THE INPUT SIZE OF DEPOSIT AMOUNT
020906*    IF NOT WGLOB-ENVRMNT-GUI
020906     IF NOT WGLOB-ENVRMNT-ONLINE
008455         MOVE 10                TO L0280-INPUT-SIZE
008455     END-IF.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           MOVE MIR-PEND-DPOS-AMT-T (1)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
008455*        MOVE L0280-OUTPUT-DOLLAR      TO W3900-PIC-7-2
008455*        MOVE W3900-PIC-7-2            TO MIR-PEND-DPOS-AMT-T (1)
015290         MOVE L0280-OUTPUT-DOLLAR      TO W3900-AMOUNT
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PEND-DPOS-AMT-T(1)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PEND-DPOS-AMT-T (1)
           ELSE
      *** MSG (S) DEPOSIT AMOUNT MUST BE NUMERIC, FORMAT 9999999.99
               MOVE 'NS39000012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  W3900-VALIDATE-FAILED    TO TRUE
           END-IF.

       4210-EDIT-DEPOSIT-AMOUNT-X.
           EXIT.
      *
      ***************************************************************
      *    EDIT COVERAGE NUMBER - MUST BE NUMERIC, FORMAT 99 AND
      *    CANNOT EXCEED THE NUMBER OF COVERAGES ON THE POLICY
      ***************************************************************
       4230-EDIT-COVERAGE-NUMBER.

           SET  W3900-CVG-VALID              TO TRUE.
           SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-NUM-T (1)     TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO W3900-PIC-2-0
020874*        MOVE W3900-PIC-2-0     TO MIR-CVG-NUM-T (1)
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NUM-T (1)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM-T (1)
           ELSE
      *** MSG (S) COVERAGE NUMBER MUST BE NUMERIC, FORMAT 99
               MOVE 'NS39000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  W3900-CVG-INVALID        TO TRUE
               GO TO 4230-EDIT-COVERAGE-NUMBER-X
           END-IF.

           IF L0280-OUTPUT > RPOL-POL-CVG-REC-CTR-N
      *** MSG (S) COVERAGE NUMBER EXCEEDS NUMBER OF CVGS ON POLICY
               MOVE 'NS39000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  W3900-CVG-INVALID        TO TRUE
               GO TO 4230-EDIT-COVERAGE-NUMBER-X
           END-IF.

           IF MIR-CVG-NUM-T (1) = '00'
               GO TO 4230-EDIT-COVERAGE-NUMBER-X
           END-IF.

           MOVE RPOL-POL-ID           TO WCVG-POL-ID.
           MOVE MIR-CVG-NUM-T (1)     TO WCVG-CVG-NUM.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.
           IF WCVG-IO-OK
               CONTINUE
           ELSE
               MOVE 'NS39000037'      TO WGLOB-MSG-REF-INFO
               MOVE WCVG-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  W3900-CVG-INVALID        TO TRUE
018846         GO TO 4230-EDIT-COVERAGE-NUMBER-X
           END-IF.

015290     IF  RCVG-PLAN-FND-TYP-XTRNL
015290         SET W3900-CVG-XTRNL      TO TRUE
015290     END-IF.
018846
018846     IF  RCVG-PLAN-FND-TYP-XTRNL
025388*    AND MIR-REG-FND-SRC-CD-T (1) NOT = SPACE
025388     AND NOT MIR-REG-FND-REG-CONTRB-T (1)
018846*MSG: FUND SOURCE CODE DEFAULTED TO REGULAR CONTRIBUTION
018846         MOVE 'NS39000042'      TO WGLOB-MSG-REF-INFO
018846         PERFORM  0260-1000-GENERATE-MESSAGE
018846             THRU 0260-1000-GENERATE-MESSAGE-X
025388*        MOVE SPACE             TO MIR-REG-FND-SRC-CD-T (1)
025388         SET  MIR-REG-FND-REG-CONTRB-T (1) TO TRUE
018846     END-IF.
018846

       4230-EDIT-COVERAGE-NUMBER-X.
           EXIT.
      *
557691***************************************************************
557691*    EDIT TAX YEAR - MUST BE NUMERIC, FORMAT 9999
557691***************************************************************
557691 4240-EDIT-TAX-YEAR.
557691
557691     SET W3900-TAX-YR-VALID            TO TRUE.
557691     SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
557691     MOVE ZERO                  TO L0280-PRECISION.
557691     MOVE 4                     TO L0280-LENGTH.
557691     MOVE 4                     TO L0280-INPUT-SIZE.
557691     MOVE MIR-PEND-DPOS-TAX-YR-T (1)
                                      TO L0280-INPUT-DATA.
557691
557691     PERFORM  0280-1000-NUMERIC-EDIT
557691         THRU 0280-1000-NUMERIC-EDIT-X.
557691
557691     IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO W3900-TAX-YR
020874*        MOVE W3900-TAX-YR      TO MIR-PEND-DPOS-TAX-YR-T (1)
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PEND-DPOS-TAX-YR-T (1)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-PEND-DPOS-TAX-YR-T (1)
557691     ELSE
557691*** MSG (S) TAX YEAR MUST BE NUMERIC, FORMAT 9999
557691         MOVE 'NS39000005'      TO WGLOB-MSG-REF-INFO
557691         PERFORM  0260-1000-GENERATE-MESSAGE
557691             THRU 0260-1000-GENERATE-MESSAGE-X
557691         SET  W3900-TAX-YR-INVALID     TO TRUE
557691     END-IF.
557691
557691
557691 4240-EDIT-TAX-YEAR-X.
557691     EXIT.
      *
      ***************************************************************
      *    PDEP PAYMENT PROCESSING - FORCE = 3
      *    - CLEAR SCREEN AND EXIT IF NOT VERIFIED
      *    - IF VERIFIED, CREATE RECORD
      ***************************************************************
       4300-PAYMENT-3.

557756*    IF L2510-RESPONSE-YES


013578     IF MIR-DV-PRCES-STATE-CD = '3'
               CONTINUE
           ELSE
      *** MSG (I) PAYMENT NOT VERIFIED
               MOVE 'NS39000022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  4310-RESET-SCREEN
                   THRU 4310-RESET-SCREEN-X
               GO TO 4300-PAYMENT-3-X
           END-IF.

      * READ THE POLICY FOR UPDATE
           PERFORM  4320-LOCK-POLICY
               THRU 4320-LOCK-POLICY-X.
           IF W3900-VALIDATE-FAILED
               GO TO 4300-PAYMENT-3-X
           END-IF.
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

015290     PERFORM  4210-EDIT-DEPOSIT-AMOUNT
015290         THRU 4210-EDIT-DEPOSIT-AMOUNT-X.

015290     IF  W3900-VALIDATE-FAILED
015290         GO TO 4300-PAYMENT-3-X
015290     END-IF.

031034*    PERFORM  4800-EDIT-PGAL-INFO
031034*        THRU 4800-EDIT-PGAL-INFO-X.
031034     PERFORM  4800-EDIT-GAIN-INFO
031034         THRU 4800-EDIT-GAIN-INFO-X.

015290     IF  W3900-VALIDATE-FAILED
015290         GO TO 4300-PAYMENT-3-X
015290     ELSE
031034*        IF LPGAL-PGAL-ALLOC-REQ
031034*        PERFORM  4880-XEDIT-PGAL-ALLOC-AMT
031034*            THRU 4880-XEDIT-PGAL-ALLOC-AMT-X
031034*        END-IF
031034         IF  LPGAC-PGAL-ALLOC-REQ
031034             PERFORM  4880-XEDIT-GAIN-ALLOC-AMT
031034                 THRU 4880-XEDIT-GAIN-ALLOC-AMT-X
031034         END-IF
015290     END-IF.

      * CALL THE FUNCTION-DRIVER TO PROCESS THE PENDING DEPOSIT
           PERFORM  4330-PDEP-PAYMENT
               THRU 4330-PDEP-PAYMENT-X.

      * REWRITE THE POLICY TO TABLE TPOL
           PERFORM  4360-UPDATE-POLICY
               THRU 4360-UPDATE-POLICY-X.

      *** MSG (I) PAYMENT COMPLETE - CONTINUE
           MOVE 'NS39000023'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

013578     PERFORM  9300-MOVE-NAME-TO-SCREEN
013578         THRU 9300-MOVE-NAME-TO-SCREEN-X.

015290     PERFORM  4890-INIT-PGAL-ALLOC-INFO
015290         THRU 4890-INIT-PGAL-ALLOC-INFO-X
015290         VARYING W3900-SUB FROM +1 BY +1
031034*          UNTIL W3900-SUB > LPGAL-MAX-ALLOC-TYP.
031034           UNTIL W3900-SUB > WS-PDGA-TBL-SIZE.

       4300-PAYMENT-3-X.
           EXIT.
      *
      ***************************************************************
      *    RESET SCREEN IF ACTION IS NOT VERIFIED
      ***************************************************************
       4310-RESET-SCREEN.


013578*    INITIALIZE MIR-DV-CLI-NM.
013578     INITIALIZE MIR-DV-OWN-CLI-NM.
           MOVE '001'                 TO MIR-PEND-DPOS-SEQ-NUM.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       4310-RESET-SCREEN-X.
           EXIT.
      *
      ***************************************************************
      *    LOCK POLICY - READ POLICY FOR UPDATE
      ***************************************************************
       4320-LOCK-POLICY.

           PERFORM  8000-BUILD-POL-KEY
               THRU 8000-BUILD-POL-KEY-X.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221         SET W3900-VALIDATE-FAILED   TO TRUE
014221        GO TO 4320-LOCK-POLICY-X
014221     END-IF.

           IF WPOL-IO-OK
               MOVE RPOL-POL-ID       TO LPGA-POLICY-NUMBER
           ELSE
      *** MSG (S) POLICY LOST - CONTACT SYSTEMS
               MOVE 'NS39000024'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET W3900-VALIDATE-FAILED   TO TRUE
           END-IF.

       4320-LOCK-POLICY-X.
           EXIT.
      *
      ***************************************************************
      *    CREATE PAYMENT RECORD - WRITE PDEP RECORD
      ***************************************************************
       4330-PDEP-PAYMENT.

           PERFORM  3910-1000-BUILD-PARM-INFO
               THRU 3910-1000-BUILD-PARM-INFO-X.

           SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                            TO L0280-LENGTH.
008455*    MOVE 10                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PEND-DPOS-AMT-T (1)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           MOVE MIR-PEND-DPOS-AMT-T (1)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           MOVE L0280-OUTPUT-DOLLAR   TO L3910-AMOUNT.
           MOVE W3900-DEP-DT          TO L3910-DEP-DT.
           MOVE W3900-SEQ-NUM         TO L3910-SEQ-NUM-N.
           IF MIR-CVG-NUM-T(1) < '00'
               MOVE '00'              TO L3910-CVG-NUM
           ELSE
               MOVE MIR-CVG-NUM-T(1)  TO L3910-CVG-NUM
           END-IF.
           MOVE MIR-FND-ID-T  (1)     TO L3910-FUND
           MOVE MIR-REG-FND-SRC-CD-T (1)
                                      TO L3910-SOURCE
557691     IF MIR-PEND-DPOS-TAX-YR-T (1) < '0000'
557691         MOVE '0000'            TO L3910-TAX-YR
557691     ELSE
557691         MOVE MIR-PEND-DPOS-TAX-YR-T (1)
                                      TO L3910-TAX-YR
557691     END-IF.

           PERFORM  3910-1000-PDEP-PAYMENT
               THRU 3910-1000-PDEP-PAYMENT-X.
           IF L3910-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR        TO TRUE
           END-IF.

       4330-PDEP-PAYMENT-X.
           EXIT.
      *
      ***************************************************************
      *    UPDATE POLICY - RESET NEXT ACTIVITY FIELDS AND REWRITE
      *    POLICY
      ***************************************************************
       4360-UPDATE-POLICY.

016503*    MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD.
016503*    MOVE WWKDT-ZERO-DT         TO RPOL-POL-NXT-ACTV-DT.

016503      PERFORM  0289-1000-INIT-PARM-INFO
016503          THRU 0289-1000-INIT-PARM-INFO-X.

016503      MOVE W3900-DEP-DT             TO L0289-LO-PAC-DT.
016503      MOVE W3900-DEP-DT             TO L0289-LO-CRC-DT.
016503      MOVE W3900-DEP-DT             TO L0289-PROC-EFF-DT.

016503      PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503          THRU 0289-1000-OBTAIN-NXT-ACTV-X.

016503      IF  L0289-RETRN-OK
016503          MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503      ELSE
016503          MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503      END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       4360-UPDATE-POLICY-X.
           EXIT.
      *
      *---------------------------
031034*4700-GET-CNTRXN-INFO.
      *---------------------------
013697
031034*    PERFORM 0316-1000-BUILD-PARM-INFO
031034*       THRU 0316-1000-BUILD-PARM-INFO-X.
031034*
031034*    SET  L0316-RGN-EXIT-CNTRB-XCPT TO TRUE.
031034*    MOVE RPOL-POL-CTRY-CD          TO L0316-CTRY-CD.
031034*
031034*    PERFORM  0316-1000-GET-RGN-EXIT-PGM
031034*        THRU 0316-1000-GET-RGN-EXIT-PGM-X.
031034*
031034*    IF  NOT L0316-RETRN-OK
031034*        SET  W3900-VALIDATE-FAILED TO TRUE
013697*MSG: 'NO CONTRIBUTION TRANSACTION REGIONAL EXIT FOUND
013697*      FOR COUNTRY @1'
031034*        MOVE 'NS39000046'        TO WGLOB-MSG-REF-INFO
031034*        MOVE L0316-CTRY-CD       TO WGLOB-MSG-PARM (1)
031034*        PERFORM  0260-1000-GENERATE-MESSAGE
031034*            THRU 0260-1000-GENERATE-MESSAGE-X
031034*        GO TO 4700-GET-CNTRXN-INFO-X
031034*    END-IF.
031034*
031034*    IF  L0316-RGN-EXIT-STAT-ACTV
031034*        CONTINUE
031034*    ELSE
031034*        INITIALIZE LCNEX-OUTPUT-PARM-INFO
031034*        GO TO 4700-GET-CNTRXN-INFO-X
031034*    END-IF.
031034*
031034*    PERFORM  CNEX-1000-BUILD-PARM-INFO
031034*        THRU CNEX-1000-BUILD-PARM-INFO-X.
031034*
031034*    SET  LCNEX-PRCES-TYP-EDIT-ONLY TO TRUE.
031034*    MOVE MIR-REG-FND-SRC-CD-T (1) TO LCNEX-TRXN-FND-SRC-CD.
031034*
031034*    PERFORM  CNEX-1000-DFLT-CNTRXN-DPOS
031034*        THRU CNEX-1000-DFLT-CNTRXN-DPOS-X.
031034*
031034*    IF  LCNEX-RETRN-OK
031034*        CONTINUE
031034*    ELSE
031034*        SET  W3900-VALIDATE-FAILED TO TRUE
031034*    END-IF.
031034*
031034*4700-GET-CNTRXN-INFO-X.
031034*    EXIT.

015290*---------------------------
031034*4800-EDIT-PGAL-INFO.
031034 4800-EDIT-GAIN-INFO.
015290*---------------------------
015290
015290     IF  W3900-CVG-XTRNL
031034*        GO TO 4800-EDIT-PGAL-INFO-X
031034         GO TO 4800-EDIT-GAIN-INFO-X
015290     END-IF.
015290
031034     PERFORM  4850-RGN-EXIT-FOR-GAIN
031034         THRU 4850-RGN-EXIT-FOR-GAIN-X.
031034
031034     IF  NOT L0316-RETRN-OK
031034     OR  L0316-RGN-EXIT-STAT-INACTV
031034         GO TO 4800-EDIT-GAIN-INFO-X
031034     END-IF.
031034
031034     MOVE MIR-REG-FND-SRC-CD-T (1) TO LPGAC-REG-FND-SRC-CD.
031034     MOVE W3900-AMOUNT             TO LPGAC-TOT-PMT-AMT.
031034     MOVE ZERO                     TO LPGAC-OTH-PMT-AMT.
031034     MOVE W3900-AMOUNT             TO LPGAC-DEPOSIT-AMT.
031034     MOVE ZERO                     TO LPGAC-SUSP-AMT.
031034     MOVE ZERO                     TO LPGAC-PRM-SUSP-AMT.
031034     MOVE ZERO                     TO LPGAC-PDF-SUSP-AMT.
031034     MOVE W3900-DEP-DT             TO LPGAC-EFF-DT.
031034     MOVE MIR-PEND-DPOS-TAX-YR-T (1)
031034                                   TO LPGAC-TAX-YR.
031034     SET LPGAC-PMT-TYP-PENDING     TO TRUE.
031034
031034     PERFORM  PGAC-1000-POL-GAIN-EDIT
031034         THRU PGAC-1000-POL-GAIN-EDIT-X.
031034
031034     IF  LPGAC-RETRN-OK
031034         CONTINUE
031034     ELSE
031034         SET WGLOB-RETURN-ERROR    TO TRUE
031034     END-IF.
031034*    PERFORM  4810-FILL-LPGAL-ALLOC-TYP-CD
031034*        THRU 4810-FILL-LPGAL-ALLOC-TYP-CD-X.
031034*
031034*    IF  LPGAL-PGAL-ALLOC-NOT-REQ
031034*    OR  W3900-VALIDATE-FAILED
031034*        GO TO 4800-EDIT-PGAL-INFO-X
031034*    END-IF.
031034*
025388*    IF  MIR-REG-FND-REG-CONTRB (1)
031034*    IF  MIR-REG-FND-REG-CONTRB-T (1)
031034*        MOVE W3900-DFLT-ALLOC-TYP-CD
031034*          TO  W3900-HOLD-PGAL-ALLOC-TYP-CD (1)
031034*        COMPUTE  W3900-HOLD-PGAL-TRXN-PRIN-AMT (1)
031034*              =  W3900-AMOUNT
031034*        MOVE ZEROS  TO W3900-HOLD-PGAL-TRXN-GAIN-AMT (1)
031034*        MOVE W3900-AMOUNT        TO W3900-TOT-ALLOC-AMT
031034*        PERFORM  4870-FILL-PGAL-TRXN-AMT
031034*            THRU 4870-FILL-PGAL-TRXN-AMT-X
031034*            VARYING  W3900-SUB FROM +1 BY +1
031034*              UNTIL  W3900-SUB > LPGAL-MAX-ALLOC-TYP
031034*        GO TO 4800-EDIT-PGAL-INFO-X
031034*    END-IF.

031034*
015290* UPDATE HOLD AREA ALLOCATION CODE BASE ON INPUT FUND SRCE
031034*    MOVE  +1   TO LPGAL-SUB.
031034*    PERFORM  4820-FILL-HOLD-AREA-PGAL
031034*        THRU 4820-FILL-HOLD-AREA-PGAL-X
031034*        VARYING  W3900-SUB FROM +1 BY +1
031034*          UNTIL  W3900-SUB > LPGAL-MAX-ALLOC-TYP.
031034*
031034*
031034*    SET W3900-ALLOC-INIT-NO        TO TRUE.
031034*
031034*    PERFORM  4830-CHECK-MIR-ALLOC-TYP-CD
031034*        THRU 4830-CHECK-MIR-ALLOC-TYP-CD-X
031034*    VARYING  W3900-SUB FROM +1 BY +1
031034*      UNTIL  W3900-SUB > LPGAL-MAX-ALLOC-TYP
031034*         OR  W3900-ALLOC-INIT.
015290
015290
031034*    IF  W3900-ALLOC-INIT
031034*        PERFORM
031034*          VARYING  LPGAL-SUB FROM +1 BY +1
031034*             UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*             MOVE  SPACES
031034*               TO W3900-HOLD-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*             MOVE ZEROS
031034*               TO W3900-HOLD-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*             MOVE ZEROS
031034*               TO W3900-HOLD-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*        END-PERFORM
031034*        MOVE ZEROS             TO W3900-TOT-ALLOC-AMT
031034*        MOVE +1                TO LPGAL-SUB
031034*        PERFORM  4820-FILL-HOLD-AREA-PGAL
031034*            THRU 4820-FILL-HOLD-AREA-PGAL-X
031034*            VARYING  W3900-SUB FROM +1 BY +1
031034*              UNTIL  W3900-SUB > LPGAL-MAX-ALLOC-TYP
031034*    ELSE
031034*        PERFORM  4870-FILL-PGAL-TRXN-AMT
031034*            THRU 4870-FILL-PGAL-TRXN-AMT-X
031034*        VARYING  W3900-SUB FROM +1 BY +1
031034*          UNTIL  W3900-SUB > LPGAL-MAX-ALLOC-TYP
031034*    END-IF.
031034*
031034*4800-EDIT-PGAL-INFO-X.
031034 4800-EDIT-GAIN-INFO-X.
015290     EXIT.
015290
015290*----------------------------
031034*4810-FILL-LPGAL-ALLOC-TYP-CD.
015290*----------------------------
015290
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE MIR-POL-ID               TO L7800-POL-ID.
031034*    MOVE W3900-DEP-DT             TO L7800-EFF-DT.
031034*    SET  L7800-TRXN-DPOS          TO TRUE.
031034*    SET  L7800-CALC-CV-REQ        TO TRUE.
031034*    SET  L7800-GET-PLAR-REQ       TO TRUE.
031034*    MOVE LCNEX-DFLT-CNTRXN-TYP-CD TO L7800-CNTRXN-TYP-CD.
031034*
031034*    IF  WS-BUS-FCN-REVERSE
031034*        SET  L7800-PRCES-REVERSE  TO TRUE
031034*    ELSE
031034*        SET  L7800-PRCES-NORMAL   TO TRUE
031034*    END-IF.
031034*
031034*    PERFORM  7800-1000-GET-PLAR-INFO
031034*        THRU 7800-1000-GET-PLAR-INFO-X
015290
031034*    IF  L7800-RETRN-OK
031034*        CONTINUE
031034*    ELSE
015290*MSG: UNABLE TO GET POLICY GAIN INFORMATION
031034*       MOVE 'NS39000009'          TO WGLOB-MSG-REF-INFO
031034*       PERFORM  0260-1000-GENERATE-MESSAGE
031034*           THRU 0260-1000-GENERATE-MESSAGE-X
031034*       SET  W3900-VALIDATE-FAILED TO TRUE
031034*       GO TO 4810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*    END-IF.
015290
031034*    MOVE L7800-PLAR-PRCES-SW      TO LPGAL-PLAR-PRCES-SW.
031034*    MOVE L7800-PGAL-ALLOC-SW      TO LPGAL-PGAL-ALLOC-SW.
015290
031034*    IF  LPGAL-PGAL-ALLOC-NOT-REQ
031034*        GO TO 4810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*    END-IF.

025388*    IF  MIR-REG-FND-REG-CONTRB (1)
031034*    IF  MIR-REG-FND-REG-CONTRB-T (1)
031034*    AND L7800-DPOS-DFLT-NOT-FOUND
015290*MSG: UNABLE TO PROCESS PAYMENT, NO DEPOSIT DEFAULT IND. IN PLAR
015290*     FOR PLAN @1
031034*        MOVE 'NS39000008'             TO WGLOB-MSG-REF-INFO
031034*        MOVE L7800-PLAN-ID            TO WGLOB-MSG-PARM (01)
031034*        PERFORM  0260-1000-GENERATE-MESSAGE
031034*            THRU 0260-1000-GENERATE-MESSAGE-X
031034*        SET W3900-VALIDATE-FAILED     TO TRUE
031034*        GO TO 4810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*    END-IF.

031034*    SET W3900-PLAR-RULE-NOT-SET       TO TRUE,
031034*    PERFORM
031034*    VARYING LPGAL-SUB FROM +1 BY +1
031034*      UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*          MOVE L7800-PGAL-ALLOC-TYP-CD     (LPGAL-SUB)
031034*               TO LPGAL-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*          MOVE L7800-PGAL-OPN-PRIN-AMT     (LPGAL-SUB)
031034*               TO LPGAL-PGAL-OPN-PRIN-AMT  (LPGAL-SUB)
031034*          MOVE L7800-PGAL-OPN-GAIN-AMT     (LPGAL-SUB)
031034*               TO LPGAL-PGAL-OPN-GAIN-AMT  (LPGAL-SUB)
031034*          MOVE L7800-PGAL-TRXN-PRIN-AMT    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*          MOVE L7800-PGAL-TRXN-GAIN-AMT    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*          MOVE L7800-PGAL-WTHDR-SEQ-NUM    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*          MOVE L7800-PGAL-WTHDR-ORDR-CD    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*          MOVE L7800-PGAL-DPOS-DFLT-IND    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-DPOS-DFLT-IND (LPGAL-SUB)
031034*          MOVE L7800-PGAL-XFER-ONLY-IND    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-XFER-ONLY-IND (LPGAL-SUB)
031034*          IF  LPGAL-PGAL-DPOS-DFLT (LPGAL-SUB)
031034*          OR  LPGAL-PGAL-XFER-ONLY (LPGAL-SUB)
031034*              SET W3900-PLAR-RULE-SET      TO TRUE
031034*          END-IF
031034*          IF  LPGAL-PGAL-DPOS-DFLT (LPGAL-SUB)
031034*              MOVE  LPGAL-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*                TO  W3900-DFLT-ALLOC-TYP-CD
031034*          END-IF
031034*    END-PERFORM.
031034*
025388*    IF  MIR-REG-FND-REG-CONTRB (1)
031034*    IF  MIR-REG-FND-REG-CONTRB-T (1)
031034*        CONTINUE
031034*    ELSE
031034*        IF  W3900-PLAR-RULE-NOT-SET
015290*MSG UNABLE TO PROCESS PAYMENT, NO ALLOCATION SPECIFIED IN
015290*    PLAN ALLOCATION RULE FOR @1
031034*            MOVE 'NS39000010'    TO WGLOB-MSG-REF-INFO
031034*            MOVE L7800-PLAN-ID   TO WGLOB-MSG-PARM (01)
031034*            PERFORM  0260-1000-GENERATE-MESSAGE
031034*                THRU 0260-1000-GENERATE-MESSAGE-X
031034*            SET W3900-VALIDATE-FAILED     TO TRUE
031034*        GO TO 4810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*       END-IF
031034*    END-IF.
031034*
031034*4810-FILL-LPGAL-ALLOC-TYP-CD-X.
031034*    EXIT.
015290
015290*---------------------------
031034*4820-FILL-HOLD-AREA-PGAL.
015290*---------------------------
015290
031034*    EVALUATE TRUE
031034*
025388*       WHEN MIR-REG-FND-REG-CONTRB (1)
031034*       WHEN MIR-REG-FND-REG-CONTRB-T (1)
031034*            IF  LPGAL-PGAL-DPOS-DFLT (W3900-SUB)
031034*                MOVE LPGAL-PGAL-ALLOC-TYP-CD (W3900-SUB)
031034*                  TO W3900-HOLD-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*                MOVE LPGAL-MAX-ALLOC-TYP   TO W3900-SUB
031034*            END-IF
031034*
031034*       WHEN OTHER
031034*            IF  LPGAL-PGAL-DPOS-DFLT (W3900-SUB)
031034*            OR  LPGAL-PGAL-XFER-ONLY (W3900-SUB)
031034*                MOVE LPGAL-PGAL-ALLOC-TYP-CD (W3900-SUB)
031034*                  TO W3900-HOLD-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*                ADD +1                     TO LPGAL-SUB
031034*            END-IF
031034*
031034*    END-EVALUATE.
031034*
031034*4820-FILL-HOLD-AREA-PGAL-X.
031034*    EXIT.
015290
015290*---------------------------
031034*4830-CHECK-MIR-ALLOC-TYP-CD.
015290*---------------------------
015290
031034*    EVALUATE  TRUE
031034*
031034*       WHEN ( W3900-HOLD-PGAL-ALLOC-TYP-CD (W3900-SUB)
031034*              =  W3900-MIR-PGAL-ALLOC-TYP-CD (W3900-SUB) )
031034*            PERFORM  4860-UPDATE-TRXN-AMOUNT
031034*                THRU 4860-UPDATE-TRXN-AMOUNT-X
031034*
031034*       WHEN OTHER
031034*            SET W3900-ALLOC-INIT           TO TRUE
031034*
031034*    END-EVALUATE.
031034*
031034*4830-CHECK-MIR-ALLOC-TYP-CD-X.
031034*    EXIT.
015290/
031034
031034*-----------------------
031034 4850-RGN-EXIT-FOR-GAIN.
031034*-----------------------
031034
031034     PERFORM  0316-1000-BUILD-PARM-INFO
031034         THRU 0316-1000-BUILD-PARM-INFO-X.
031034
031034     SET L0316-RGN-EXIT-GAIN-ALLOC-EDIT   TO TRUE.
031034
031034     MOVE RPOL-POL-CTRY-CD      TO L0316-CTRY-CD.
031034
031034     PERFORM  0316-1000-GET-RGN-EXIT-PGM
031034         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
031034
031034     IF  NOT L0316-RETRN-OK
031034*MSG: NO GAIN ALLOCATION EDIT REGIONAL EXIT FOUND FOR COUNTRY @1
031034         MOVE 'CS00000070'       TO WGLOB-MSG-REF-INFO
031034         MOVE L0316-CTRY-CD      TO WGLOB-MSG-PARM (1)
031034         PERFORM  0260-1000-GENERATE-MESSAGE
031034             THRU 0260-1000-GENERATE-MESSAGE-X
031034         SET WGLOB-RETURN-ERROR       TO TRUE
031034     END-IF.
031034
031034 4850-RGN-EXIT-FOR-GAIN-X.
031034     EXIT.
031034
015290*------------------------
031034*4860-UPDATE-TRXN-AMOUNT.
015290*------------------------
015290
031034*    IF  W3900-MIR-PGAL-ALLOC-TYP-CD   (W3900-SUB) =
031034*        W3900-HOLD-PGAL-ALLOC-TYP-CD (W3900-SUB)
031034*        IF  W3900-MIR-PGAL-TRXN-PRIN-AMT (W3900-SUB) > SPACES
031034*            MOVE W3900-MIR-PGAL-TRXN-PRIN-AMT (W3900-SUB)
031034*                                         TO L0280-INPUT-DATA
031034*            MOVE 2                       TO L0280-PRECISION
031034*            MOVE LENGTH OF
031034*                 W3900-MIR-PGAL-TRXN-PRIN-AMT (W3900-SUB)
031034*                                         TO L0280-INPUT-SIZE
031034*            SET L0280-SIGN-PERMITTED     TO TRUE
031034*            COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
031034*                                 - L0280-PRECISION
031034*                                 - 1
031034*            PERFORM  0280-1000-NUMERIC-EDIT
031034*                THRU 0280-1000-NUMERIC-EDIT-X
031034*            IF  L0280-OK
031034*                MOVE L0280-OUTPUT-DOLLAR
031034*                     TO W3900-HOLD-PGAL-TRXN-PRIN-AMT (W3900-SUB)
031034*                ADD  W3900-HOLD-PGAL-TRXN-PRIN-AMT (W3900-SUB)
031034*                     TO W3900-TOT-ALLOC-AMT
031034*            ELSE
031034*                SET W3900-VALIDATE-FAILED  TO TRUE
031034*            END-IF
031034*        END-IF
031034*        IF  W3900-MIR-PGAL-TRXN-GAIN-AMT (W3900-SUB) > SPACES
031034*            MOVE W3900-MIR-PGAL-TRXN-GAIN-AMT (W3900-SUB)
031034*                 TO L0280-INPUT-DATA
031034*            MOVE 2                       TO L0280-PRECISION
031034*            MOVE LENGTH OF
031034*                 W3900-MIR-PGAL-TRXN-GAIN-AMT (W3900-SUB)
031034*                                         TO L0280-INPUT-SIZE
031034*            SET L0280-SIGN-PERMITTED     TO TRUE
031034*            COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
031034*                                 - L0280-PRECISION
031034*                                 - 1
031034*            PERFORM  0280-1000-NUMERIC-EDIT
031034*                THRU 0280-1000-NUMERIC-EDIT-X
031034*            IF  L0280-OK
031034*                MOVE L0280-OUTPUT-DOLLAR
031034*                     TO W3900-HOLD-PGAL-TRXN-GAIN-AMT (W3900-SUB)
031034*                ADD  W3900-HOLD-PGAL-TRXN-GAIN-AMT (W3900-SUB)
031034*                                          TO W3900-TOT-ALLOC-AMT
031034*            ELSE
031034*                SET W3900-VALIDATE-FAILED TO TRUE
031034*            END-IF
031034*        END-IF
031034*    END-IF.
031034*
031034*4860-UPDATE-TRXN-AMOUNT-X.
031034*    EXIT.
015290/
015290*------------------------
031034*4870-FILL-PGAL-TRXN-AMT.
015290*------------------------
015290
031034*    PERFORM
031034*    VARYING  LPGAL-SUB FROM +1 BY +1
031034*      UNTIL  LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*         IF  W3900-HOLD-PGAL-ALLOC-TYP-CD (W3900-SUB)
031034*             =  LPGAL-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*             MOVE W3900-HOLD-PGAL-TRXN-PRIN-AMT (W3900-SUB)
031034*               TO LPGAL-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*             MOVE W3900-HOLD-PGAL-TRXN-GAIN-AMT (W3900-SUB)
031034*               TO LPGAL-PGAL-TRXN-GAIN-AMT    (LPGAL-SUB)
031034*        END-IF
031034*
031034*    END-PERFORM.
031034*
025388*    IF  MIR-REG-FND-REG-CONTRB (1)
031034*    IF  MIR-REG-FND-REG-CONTRB-T (1)
031034*        MOVE LPGAL-MAX-ALLOC-TYP     TO W3900-SUB
031034*    END-IF.
031034*
031034*4870-FILL-PGAL-TRXN-AMT-X.
031034*    EXIT.
015290
015290/
015290*---------------------------
031034*4880-XEDIT-PGAL-ALLOC-AMT.
031034 4880-XEDIT-GAIN-ALLOC-AMT.
015290*---------------------------
015290
025388*    IF  MIR-REG-FND-SRC-CD-T (1) NOT = ' '
031034*    IF  NOT MIR-REG-FND-REG-CONTRB-T (1)
031034*    AND W3900-TOT-ALLOC-AMT = ZEROS
015290*MSG:  UNABLE TO PROCESS PAYMENT, ALL PRINCIPAL AND GAIN
015290*      AMOUNT MUST BE ENTERED
031034*        MOVE 'NS39000043'      TO WGLOB-MSG-REF-INFO
031034*        PERFORM  0260-1000-GENERATE-MESSAGE
031034*            THRU 0260-1000-GENERATE-MESSAGE-X
031034*        SET W3900-PGAL-INVALID     TO TRUE
031034*        GO TO 4880-XEDIT-PGAL-ALLOC-AMT-X
031034*    END-IF.
031034*
031034*    IF  W3900-TOT-ALLOC-AMT NOT = W3900-AMOUNT
015290*MSG:  UNABLE TO PROCESS PAYMENT, ENTERED PRINCIPAL AND
015290*      GAIN AMOUNTS DO NOT BALANCE DEPOSIT AMOUNT
031034*        MOVE 'NS39000044'         TO WGLOB-MSG-REF-INFO
031034*        PERFORM  0260-1000-GENERATE-MESSAGE
031034*            THRU 0260-1000-GENERATE-MESSAGE-X
031034*        SET W3900-PGAL-INVALID    TO TRUE
031034*    END-IF.
031034*
031034     SET LPGAC-PMT-TYP-PENDING    TO TRUE.
031034     PERFORM  PGAC-2000-POL-GAIN-XEDIT
031034         THRU PGAC-2000-POL-GAIN-XEDIT-X.
031034
031034*4880-XEDIT-PGAL-ALLOC-AMT-X.
031034 4880-XEDIT-GAIN-ALLOC-AMT-X.
015290     EXIT.
015290/
015290*
015290*---------------------------
015290 4890-INIT-PGAL-ALLOC-INFO.
015290*---------------------------
015290
015290     MOVE SPACES          TO MIR-PLAR-ALLOC-TYP-CD-T (W3900-SUB).
015290
020874*    MOVE 0               TO L0290-INPUT-NUMBER.
020874     MOVE ZERO            TO L0290-INPUT-V02.
015290     MOVE 2               TO L0290-PRECISION.
015290     MOVE LENGTH OF MIR-PDGA-PRIN-AMT-T (W3900-SUB)
015290                          TO L0290-MAX-OUT-LEN.
015290     SET L0290-SIGN-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
015290     MOVE L0290-OUTPUT-DATA
015290                          TO MIR-PDGA-PRIN-AMT-T (W3900-SUB).
015290
020874*    MOVE 0               TO L0290-INPUT-NUMBER.
020874     MOVE ZERO            TO L0290-INPUT-V02.
015290     MOVE 2               TO L0290-PRECISION.
015290     MOVE LENGTH OF MIR-PDGA-GAIN-AMT-T (W3900-SUB)
015290                          TO L0290-MAX-OUT-LEN.
015290     SET L0290-SIGN-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
015290     MOVE L0290-OUTPUT-DATA
015290                          TO MIR-PDGA-GAIN-AMT-T (W3900-SUB).
015290
015290 4890-INIT-PGAL-ALLOC-INFO-X.
015290     EXIT.
015290*---------------------------
015290 4900-RETURN-MIR-PDGA.
015290*---------------------------
015290
031034*    IF  W3900-HOLD-PGAL-ALLOC-TYP-CD (W3900-SUB) = SPACES
031034     IF  LPGAC-PGAL-ALLOC-TYP-CD (W3900-SUB) = SPACES
015290         GO TO 4900-RETURN-MIR-PDGA-X
015290     END-IF.
015290
031034*    MOVE W3900-HOLD-PGAL-ALLOC-TYP-CD (W3900-SUB)
031034     MOVE LPGAC-PGAL-ALLOC-TYP-CD (W3900-SUB)
015290       TO MIR-PLAR-ALLOC-TYP-CD-T (W3900-SUB).
015290
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = W3900-HOLD-PGAL-TRXN-PRIN-AMT (W3900-SUB)
020874*          * 100.
031034*    MOVE W3900-HOLD-PGAL-TRXN-PRIN-AMT (W3900-SUB)
031034     MOVE LPGAC-PGAL-TRXN-PRIN-AMT (W3900-SUB)
020874                             TO L0290-INPUT-V02.
015290
015290     MOVE 2                  TO L0290-PRECISION.
015290     SET L0290-SIGN-DISPLAY  TO TRUE.
015290     MOVE LENGTH OF MIR-PDGA-PRIN-AMT-T (W3900-SUB)
015290       TO L0290-MAX-OUT-LEN.
015290
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
015290
015290     MOVE L0290-OUTPUT-DATA
015290       TO MIR-PDGA-PRIN-AMT-T (W3900-SUB).
015290
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = W3900-HOLD-PGAL-TRXN-GAIN-AMT (W3900-SUB)
020874*          * 100.
031034*    MOVE W3900-HOLD-PGAL-TRXN-GAIN-AMT (W3900-SUB)
031034     MOVE LPGAC-PGAL-TRXN-GAIN-AMT (W3900-SUB)
020874                             TO L0290-INPUT-V02.
015290
015290     MOVE 2                  TO L0290-PRECISION.
015290     SET L0290-SIGN-DISPLAY  TO TRUE.
015290     MOVE LENGTH OF MIR-PDGA-GAIN-AMT-T (W3900-SUB)
015290       TO L0290-MAX-OUT-LEN.
015290
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
015290
015290     MOVE L0290-OUTPUT-DATA
015290       TO MIR-PDGA-GAIN-AMT-T (W3900-SUB).
015290
015290 4900-RETURN-MIR-PDGA-X.
015290     EXIT.
015290*

      *
      ***************************************************************
      *    PDEP REVERSAL
      ***************************************************************
       5000-PROCESS-REVERSAL.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM 5300-REVERSAL-3
                      THRU 5300-REVERSAL-3-X

               WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM 5200-REVERSAL-2
                      THRU 5200-REVERSAL-2-X

               WHEN OTHER
                   PERFORM 5100-REVERSAL-1
                      THRU 5100-REVERSAL-1-X

           END-EVALUATE.

       5000-PROCESS-REVERSAL-X.
           EXIT.
      *
      ***************************************************************
      *    PDEP REVERSAL - FORCE = 1
      *    - PERFORM REVERSAL SPECIFIC EDITS
      *    - DISPLAY RECORD
      ***************************************************************
       5100-REVERSAL-1.

      * CHECK THE 1ST FOUR CHARACTERS OF THE OWNER'S NAME
013578*    PERFORM  4110-EDIT-NAME
013578*        THRU 4110-EDIT-NAME-X.
           IF W3900-VALIDATE-FAILED
               GO TO 5100-REVERSAL-1-X
           END-IF.

      * SET UP THE PARAMETERS AND CALL THE FUNCTION-DRIVER FOR
      * FURTHER DETAILS.
           PERFORM  3910-1000-BUILD-PARM-INFO
               THRU 3910-1000-BUILD-PARM-INFO-X.
           SET  L3910-PRCES-TYP-INITIAL      TO TRUE
           MOVE W3900-DEP-DT          TO L3910-DEP-DT
           MOVE W3900-SEQ-NUM         TO L3910-SEQ-NUM-N
           MOVE MIR-CVG-NUM-T(1)      TO L3910-CVG-NUM.

           PERFORM  3910-2000-PDEP-REVERSAL
               THRU 3910-2000-PDEP-REVERSAL-X
           IF L3910-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR        TO TRUE
           END-IF.

           IF L3910-POL-ID-ERROR
               GO TO 5100-REVERSAL-1-X
           END-IF.

           IF L3910-RETRN-PDEP-NOT-FOUND
               GO TO 5100-REVERSAL-1-X
           END-IF.

           PERFORM  8100-BUILD-PDEP-KEY
               THRU 8100-BUILD-PDEP-KEY-X.
           PERFORM  PDEP-1000-READ
               THRU PDEP-1000-READ-X.
           IF WPDEP-IO-OK
               CONTINUE
           ELSE
      *** MSG (S) NO PENDING DEPOSIT EXISTS TO REVERSE
               MOVE 'NS39000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5100-REVERSAL-1-X
           END-IF.

           IF RPDEP-PEND-DPOS-REVERSED
      *** MSG (S) DEPOSIT HAS ALREADY BEEN REVERSED
               MOVE 'NS39000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE +1                TO W3900-LINE-INDEX
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
013578         PERFORM  9300-MOVE-NAME-TO-SCREEN
013578            THRU  9300-MOVE-NAME-TO-SCREEN-X
               GO TO 5100-REVERSAL-1-X
           END-IF.

           MOVE +1                    TO W3900-LINE-INDEX.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

015290     PERFORM  9230-RETRIEVE-PDGA-INFO
015290         THRU 9230-RETRIEVE-PDGA-INFO-X.

013578     PERFORM  9300-MOVE-NAME-TO-SCREEN
013578         THRU 9300-MOVE-NAME-TO-SCREEN-X.


           MOVE 'N'                   TO MIR-DV-OS-DISB-IND.

      *** MSG (I) REVERSE TO OUTSTANDING DISBURSEMENTS?
           MOVE 'NS39000027'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5100-REVERSAL-1-X.
           EXIT.
      *
      ***************************************************************
      *    PDEP REVERSAL - FORCE = 2
      *    - EDIT OUTSTANDING DISBURSEMENTS INDICATOR
      *    - SETUP SCREEN TO VERIFY
      ***************************************************************
       5200-REVERSAL-2.

      * THIS PASS WILL CALL THE FUNCTION-DRIVER TO EDIT THE
      * OUTSTANDING DISBUSEMENT INPUT FIELD.
           PERFORM  3910-1000-BUILD-PARM-INFO
               THRU 3910-1000-BUILD-PARM-INFO-X.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           MOVE W3900-DEP-DT          TO L3910-DEP-DT
           MOVE W3900-SEQ-NUM         TO L3910-SEQ-NUM-N
           MOVE MIR-DV-OS-DISB-IND    TO L3910-OSDISB-IND

           SET  L3910-PRCES-TYP-EDIT-ONLY    TO TRUE

           PERFORM  3910-2000-PDEP-REVERSAL
               THRU 3910-2000-PDEP-REVERSAL-X.


           IF L3910-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR        TO TRUE
               GO TO 5200-REVERSAL-2-X
           END-IF.

      *** MSG (I) VERIFY REVERSAL
           MOVE 'NS39000028'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

013578*    TO DISPLAY TABLE FIELDS HAVE TO READ PDEP AGAIN AND
013578*    MOVE TO MIR FIELDS.

013578     PERFORM  8100-BUILD-PDEP-KEY
013578         THRU 8100-BUILD-PDEP-KEY-X.

013578     PERFORM  PDEP-1000-READ
013578         THRU PDEP-1000-READ-X.

           MOVE +1                    TO W3900-LINE-INDEX.

013578     PERFORM  9200-MOVE-RECORD-TO-SCREEN
013578         THRU 9200-MOVE-RECORD-TO-SCREEN-X.


015290     PERFORM  9230-RETRIEVE-PDGA-INFO
015290         THRU 9230-RETRIEVE-PDGA-INFO-X.


013578     PERFORM  9300-MOVE-NAME-TO-SCREEN
013578         THRU 9300-MOVE-NAME-TO-SCREEN-X.

       5200-REVERSAL-2-X.
           EXIT.
      *
      ***************************************************************
      *    PDEP REVERSAL PROCESSING - FORCE = 3
      *    - CLEAR SCREEN AND EXIT IF NOT VERIFIED
      *    - IF VERIFIED, UPDATE STATUS OF RECORD
      ***************************************************************
       5300-REVERSAL-3.


015672     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
015672         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

      * EXIT IF THE USER HAS NOT VERIFIED

013578*    IF L2510-RESPONSE-YES
013578     IF MIR-DV-PRCES-STATE-CD = '3'
               CONTINUE
           ELSE
      *** MSG (I) REVERSAL NOT VERIFIED
               MOVE 'NS39000030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  4310-RESET-SCREEN
                   THRU 4310-RESET-SCREEN-X
               GO TO 5300-REVERSAL-3-X
           END-IF.

      * READ POLICY FOR UPDATE
           PERFORM  4320-LOCK-POLICY
               THRU 4320-LOCK-POLICY-X.
           IF W3900-VALIDATE-FAILED
               GO TO 5300-REVERSAL-3-X
           END-IF.

      * CALL THE FUNCTION-DRIVER TO PROCESS THE PENDING DEPOSIT
      * REVERSAL
           PERFORM  5310-REVERSE-PDEP
               THRU 5310-REVERSE-PDEP-X.

      * REWRITE THE POLICY TO TABLE TPOL
           PERFORM  4360-UPDATE-POLICY
               THRU 4360-UPDATE-POLICY-X.

      * RESET THE SCREEN FOR A BROWSE FUNCTION
013578*    INITIALIZE MIR-DV-CLI-NM.
013578     INITIALIZE MIR-DV-OWN-CLI-NM.


      * GENERATE ACKNOWLEDGEMENT MESSAGE ACCORDING TO THE OPTION
      * CHOSEN FOR THE FUNDS.
           IF MIR-DV-OS-DISB-IND = 'N'
      *** MSG (I) DEPOSIT REVERSED - RE-APPLY OR REFUND ORIGINAL DEPOSIT
               MOVE 'NS39000031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *** MSG (I) DEPOSIT REVERSED TO OS DISB - USE IPAY TO REFUND
               MOVE 'NS39000036'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5300-REVERSAL-3-X.
           EXIT.
      *
      ***************************************************************
      *    UPDATE FOR REVERSAL - UPDATE PDEP RECORD FOR REVERSAL
      ***************************************************************
       5310-REVERSE-PDEP.

      * SET UP THE PARAMETERS TO CALL THE FUNCTION-DRIVER
           PERFORM  3910-1000-BUILD-PARM-INFO
               THRU 3910-1000-BUILD-PARM-INFO-X.
           MOVE W3900-DEP-DT          TO L3910-DEP-DT
           MOVE W3900-SEQ-NUM         TO L3910-SEQ-NUM-N
           MOVE MIR-DV-OS-DISB-IND    TO L3910-OSDISB-IND

      * CALL THE FUNCTION-DRIVER TO REVERSE THE PDEP RECORD AND
      * PERFORM ASSOCIATED ACCOUNTING

           PERFORM  3910-2000-PDEP-REVERSAL
               THRU 3910-2000-PDEP-REVERSAL-X.
           IF L3910-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR        TO TRUE
               GO TO 5310-REVERSE-PDEP-X
           END-IF.

           MOVE 'R'                   TO MIR-PEND-DPOS-STAT-CD-T (1).

       5310-REVERSE-PDEP-X.
           EXIT.
      *
      ***************************************************************
      *    BUILD THE KEY TO THE POL FILE FROM THE MIR KEY FIELDS
      ***************************************************************
       8000-BUILD-POL-KEY.

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

       8000-BUILD-POL-KEY-X.
           EXIT.
      *
      ***************************************************************
      *    BUILD THE KEY TO THE PDEP FILE FROM THE MIR KEY FIELDS
      ***************************************************************
       8100-BUILD-PDEP-KEY.

           MOVE MIR-POL-ID-BASE       TO WPDEP-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPDEP-POL-ID-SFX.
005409*    MOVE W3900-DEP-DT                 TO WPDEP-PEND-DPOS-EFF-DT.
005409     MOVE W3900-DEP-DT          TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WPDEP-PEND-DPOS-EFF-DT.
           MOVE W3900-SEQ-NUM         TO WPDEP-PEND-DPOS-SEQ-NUM.

       8100-BUILD-PDEP-KEY-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.

           INITIALIZE MIR-POL-ID-BASE-G.
           INITIALIZE MIR-POL-ID-SFX-G.
           INITIALIZE MIR-PEND-DPOS-EFF-DT-G.
           INITIALIZE MIR-PEND-DPOS-SEQ-NUM-G.
           INITIALIZE MIR-PEND-DPOS-STAT-CD-G.
           INITIALIZE MIR-PEND-DPOS-AMT-G.
025388*    INITIALIZE MIR-REG-FND-SRC-CD-G.
           INITIALIZE MIR-CVG-NUM-G.
           INITIALIZE MIR-FND-ID-G.
557691     INITIALIZE MIR-PEND-DPOS-TAX-YR-G.
025388     PERFORM
025388         VARYING I FROM 1 BY 1
025388         UNTIL   I > 12
025388         SET MIR-REG-FND-REG-CONTRB-T (I) TO TRUE
025388     END-PERFORM.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  DISPLAY PDEP RECORD ON THE SCREEN
557660*  INPUT:  W3900-LINE-INDEX
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.

           MOVE RPDEP-POL-ID-BASE
                            TO MIR-POL-ID-BASE-T(W3900-LINE-INDEX)
           MOVE RPDEP-POL-ID-SFX
                            TO MIR-POL-ID-SFX-T(W3900-LINE-INDEX)

           MOVE RPDEP-PEND-DPOS-EFF-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                             TO MIR-PEND-DPOS-EFF-DT-T(W3900-LINE-INDEX)

020874*    MOVE RPDEP-PEND-DPOS-SEQ-NUM
020874*                               TO W3900-PIC-3-0.
020874*    MOVE W3900-PIC-3-0
020874*               TO MIR-PEND-DPOS-SEQ-NUM-T(W3900-LINE-INDEX)
020874     MOVE RPDEP-PEND-DPOS-SEQ-NUM TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-PEND-DPOS-SEQ-NUM-T(W3900-LINE-INDEX)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA
020874                    TO MIR-PEND-DPOS-SEQ-NUM-T(W3900-LINE-INDEX).
           MOVE RPDEP-PEND-DPOS-STAT-CD
                          TO MIR-PEND-DPOS-STAT-CD-T(W3900-LINE-INDEX)
008455*    MOVE RPDEP-PEND-DPOS-AMT     TO W3900-PIC-7-2.
008455*    MOVE W3900-PIC-7-2  TO MIR-PEND-DPOS-AMT-T(W3900-LINE-INDEX)
020874*    COMPUTE L0290-INPUT-NUMBER = RPDEP-PEND-DPOS-AMT * 100.
020874     MOVE RPDEP-PEND-DPOS-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PEND-DPOS-AMT-T (W3900-LINE-INDEX)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
                                TO MIR-PEND-DPOS-AMT-T(W3900-LINE-INDEX)
008455
           MOVE RPDEP-REG-FND-SRC-CD
                               TO MIR-REG-FND-SRC-CD-T(W3900-LINE-INDEX)
           MOVE RPDEP-CVG-NUM         TO MIR-CVG-NUM-T(W3900-LINE-INDEX)
           MOVE RPDEP-FND-ID          TO MIR-FND-ID-T(W3900-LINE-INDEX).
557691     MOVE RPDEP-PEND-DPOS-TAX-YR
                            TO MIR-PEND-DPOS-TAX-YR-T(W3900-LINE-INDEX).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.


015290*----------------------------
015290 9230-RETRIEVE-PDGA-INFO.
015290*----------------------------
015290
015290     MOVE LOW-VALUES              TO WPDGA-KEY.
015290     MOVE MIR-POL-ID              TO WPDGA-POL-ID.
015290     MOVE RPDEP-PEND-DPOS-EFF-DT  TO WPDGA-PEND-DPOS-EFF-DT.
015290     MOVE RPDEP-PEND-DPOS-SEQ-NUM TO WPDGA-PEND-DPOS-SEQ-NUM.
015290
015290     MOVE WPDGA-KEY             TO WPDGA-ENDBR-KEY.
015290     MOVE HIGH-VALUES           TO WPDGA-ENDBR-PDGA-ALLOC-TYP-CD.
015290
015290     PERFORM  PDGA-1000-BROWSE
015290         THRU PDGA-1000-BROWSE-X.
015290
015290     PERFORM  PDGA-2000-READ-NEXT
015290         THRU PDGA-2000-READ-NEXT-X.
015290
015290     PERFORM
015290         VARYING I FROM 1 BY 1
015290         UNTIL I > WS-PDGA-TBL-SIZE
015290         OR NOT WPDGA-IO-OK
015290
015290         MOVE RPDGA-PDGA-ALLOC-TYP-CD
015290           TO MIR-PLAR-ALLOC-TYP-CD-T (I)
015290
020874*        COMPUTE L0290-INPUT-NUMBER = RPDGA-PDGA-PRIN-AMT
020874*                                   * 100
020874         MOVE RPDGA-PDGA-PRIN-AMT     TO L0290-INPUT-V02
015290         MOVE +2                      TO L0290-PRECISION
015290         MOVE LENGTH OF MIR-PDGA-PRIN-AMT-T (I)
015290           TO L0290-MAX-OUT-LEN
015290         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS   TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
015290         MOVE L0290-OUTPUT-DATA
015290         TO MIR-PDGA-PRIN-AMT-T (I)
015290
020874*        COMPUTE L0290-INPUT-NUMBER = RPDGA-PDGA-GAIN-AMT
020874*                                   * 100
020874         MOVE RPDGA-PDGA-GAIN-AMT     TO L0290-INPUT-V02
015290         MOVE +2                      TO L0290-PRECISION
015290         MOVE LENGTH OF MIR-PDGA-GAIN-AMT-T (I)
015290           TO L0290-MAX-OUT-LEN
015290         SET L0290-SIGN-DISPLAY       TO TRUE
020874*        SET L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
015290         MOVE L0290-OUTPUT-DATA
015290         TO MIR-PDGA-GAIN-AMT-T (I)
015290
015290         PERFORM  PDGA-2000-READ-NEXT
015290             THRU PDGA-2000-READ-NEXT-X
015290
015290     END-PERFORM.
015290
015290     IF  I > WS-PDGA-TBL-SIZE
015290     AND WPDGA-IO-OK
015290*MSG: INTERNAL TABLE OVERFLOWS
015290         MOVE 'NS39000045'         TO WGLOB-MSG-REF-INFO
015290         PERFORM  0260-1000-GENERATE-MESSAGE
015290             THRU 0260-1000-GENERATE-MESSAGE-X
015290     END-IF.
015290
015290     PERFORM  PDGA-3000-END-BROWSE
015290         THRU PDGA-3000-END-BROWSE-X.
015290
015290 9230-RETRIEVE-PDGA-INFO-X.
015290     EXIT.


      *
013578 9300-MOVE-NAME-TO-SCREEN.

013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE RPOL-POL-ID                   TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.

013578 9300-MOVE-NAME-TO-SCREEN-X.
013578     EXIT.
      *
       9700-SETUP-MSIN-REFERENCE.

           INITIALIZE WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9700-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0316-0000-INIT-PARM-INFO
025970         THRU 0316-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2470-0000-INIT-PARM-INFO
025970         THRU 2470-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  3910-0000-INIT-PARM-INFO
025970         THRU 3910-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  CNEX-0000-INIT-PARM-INFO
031034*        THRU CNEX-0000-INIT-PARM-INFO-X.
025970
031034     PERFORM  PGAC-0000-INIT-PARM-INFO
031034         THRU PGAC-0000-INIT-PARM-INFO-X.
031034
025970     INITIALIZE                         W3900-WORK-AREA.
025970     INITIALIZE                         FREQUENTLY-USED-INDICES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-PDGA-TBL-SIZE       TO TRUE.
023514
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970     MOVE SPACES                       TO WWKDT-WORK-FIELDS.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *****************************************************************
      * LINKING COPYBOOKS
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCCP0030.
      *
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
      *
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
025970 COPY XCPS1680.
005409 COPY XCPL1680.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS0289.
      *
025970 COPY CCPS0620.
013578 COPY CCPL0620.
      *
018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS2430.
      *
018764*COPY CCCL2470.
018764 COPY CCPL2470.
557788 COPY CCPS2470.
      *
018764*COPY NCCL3910.
018764 COPY NCPL3910.
       COPY NCPS3910.
      *
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
008455 COPY XCPS0290.
008455 COPY XCPL0290.
008455*
018764*COPY XCCL8090.
018764 COPY XCPL8090.

031034*COPY CCPSPGAL.
031034 COPY CCPSPGAC.
031034 COPY CCPLPGAC.
031034*COPY CCPS7800.
031034*COPY CCPL7800.
      *
013697 COPY XCPS0316.
013697 COPY XCPL0316.
      *
031034*COPY CCPSCNEX.
031034*COPY CCPLCNEX.
      *
      *****************************************************************
      * PROCESSING COPYBOOKS
      *****************************************************************
      *
       COPY CCPSPGA.
      *
       COPY XCPPEXIT.
      *
       COPY XCPPINIT.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      *
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNCVG.
       COPY NCPPCVGS.
      *
       COPY CCPNPOL.
       COPY CCPUPOL.
      *
       COPY CCPBPDEP.
       COPY CCPCPDEP.
       COPY CCPNPDEP.
015290 COPY CCPBPDGA.
      *
      *****************************************************************
      **                 END OF PROGRAM NSOM3900                     **
      *****************************************************************
