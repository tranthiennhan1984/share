      *************************
       IDENTIFICATION DIVISION.
      *************************

       COPY XCWWCRHT.

       PROGRAM-ID. NSOM0580.

      *****************************************************************
      **  MEMBER :  NSOM0580                                         **
      **  REMARKS:  UWKO - CLEAR CASE KICKOUT REASONS                **
      **            THIS PROGRAM ALLOWS THE USER TO VIEW THE REASONS **
      **            WHY A CLIENT FAILED CLEAR CASE PROCESSING        **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557708**  5.5       ABEND HANDLING                                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       SET UP SUBSIDIARY COMPANY ID                     **
012624**  6.0       GLOBAL SECURITY CHANGES                          **
013578**  6.0       ADD MIR-CCAS-MSG-SEQ-NUM-T                       **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
019327**  6.4       BYPASS POLICY FOR CERTAIN STATUS                 **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0580'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'CCKO'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID                    VALUE '0580'
                                                             '0584'.
               88  WS-BUS-FCN-DOC                      VALUE '0580'.
               88  WS-BUS-FCN-LIST                     VALUE '0584'.
           05  WS-INSURED-FOUND-SW          PIC X(01).
               88  WS-INSURED-FOUND                    VALUE 'Y'.
               88  WS-INSURED-FOUND-NO                 VALUE 'N'.
           05  WS-MISSING-DATA-IND          PIC X(01).
               88  WS-MISSING-DATA                     VALUE 'Y'.
               88  WS-MISSING-DATA-NO                  VALUE 'N'.
016548*    05  WS-LOOP                      PIC S9(4)  COMP.
016548     05  WS-LOOP                      PIC S9(4)  BINARY.
           05  WS-IND                       PIC 9(02)  VALUE ZEROS.
016548*    05  WS-MAX-REASONS               PIC S9(4)  COMP
025970*    05  WS-MAX-REASONS               PIC S9(4)  BINARY
025970*                                                VALUE +50.
016548*    05  WS-MAX-REQUIREMENTS          PIC S9(4)  COMP
025970*    05  WS-MAX-REQUIREMENTS          PIC S9(4)  BINARY
025970*                                                VALUE +11.
016548*    05  WS-LINES                     PIC S9(4)  COMP.
016548     05  WS-LINES                     PIC S9(4)  BINARY.
           05  WS-PIC-Z9                    PIC Z9.
           05  WS-PIC-99                    PIC S9(2).
           05  WS-EDIT-3-0                  PIC 9(03).
           05  WS-VALIDATE-CONTROL          PIC X(01).
               88  WS-INVALID-CONTROL                  VALUE '1'.
           05  WS-HOLD-KEY.
               10  WS-HOLD-CODE-COMPANY     PIC X(02).
               10  WS-HOLD-CLIENT           PIC X(10).
               10  WS-HOLD-SYSTEM           PIC X(08).
               10  WS-HOLD-REST             PIC X(13).
      **** TWO REQUIRED FIELDS FOR INITIALIZING PGA CODED HERE INSTEAD
      **** PULLING IN THE POLICY AND COVERAGE FILES
016440*    05  RPOL-POL-ID                  PIC X(10) VALUE SPACES.
016440*    05  RPOL-POL-BASE-CVG-NUM        PIC 9(02) VALUE ZERO.

       01  WS-JUST-FIELD.
           05  WS-JUST-FIELD-VALUE.
               10  WS-JUST-FIELD-DET-SP     PIC X(01) VALUE SPACES.
               10  WS-JUST-FIELD-DET1       PIC X(14) VALUE SPACES.

       01  WS-JUST-FIELD-TMP.
           05  WS-JUST-FIELD-TMP1           PIC X(14) VALUE SPACES.
           05  WS-JUST-FIELD-TMP2           PIC X(01) VALUE SPACES.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'CCKO'.
025970     05  WS-MAX-REASONS               PIC S9(4)  BINARY.
025970         88  WS-DEFAULT-MAX-REASONS              VALUE +50.
025970     05  WS-MAX-REQUIREMENTS          PIC S9(4)  BINARY.
025970         88  WS-DEFAULT-MAX-REQUIREMENTS         VALUE +11.
      /
       COPY XCWWWKDT.
016537*COPY XCWEBLCH.
      /
      *  FILE AREA

       COPY CCFWRL.
       COPY CCFRRL.
      /
016440 COPY CCFWPOL.
016440 COPY CCFRPOL.
016440/
010418 COPY CCFWSCOM.
010418 COPY CCFRSCOM.
      /
       COPY NCFWCCKO.
       COPY NCFRCCKO.
      /
023447*COPY NCFWDOCM.
023447*COPY NCFRDOCM.
023447 COPY XCFWDOCM.
023447 COPY XCFRDOCM.
      /
       COPY NCFWREQT.
       COPY NCFRREQT.
      /
      *  PARAMETER AREA

028298 COPY CCWL2626.
       COPY NCWL0303.
       COPY NCWL2437.
010418 COPY CCWL3320.
       COPY CCWL5600.

016440 COPY CCWL2222.

       COPY XCWLDTLK.
       COPY XCWL0280.
020874 COPY XCWL0290.
       COPY XCWL1640.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0580.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023118
023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------
      * NORMAL PROCESSING: DISTRIBUTE CONTROL TO THE APPROPRIATE
      * PROCESSING ROUTINE.

      * SET UP PMLK AREA.

020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST
                                      TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

016440     MOVE SPACES TO RPOL-POL-ID.
016440     MOVE ZEROES TO RPOL-POL-BASE-CVG-NUM.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.
           PERFORM  2100-PROCESS-INIT
               THRU 2100-PROCESS-INIT-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  3000-VALIDATE-CONTROL-FIELDS
               THRU 3000-VALIDATE-CONTROL-FIELDS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  4000-DISPLAY
               THRU 4000-DISPLAY-X.

           IF  MIR-DOC-ID NOT = SPACES
               PERFORM  5000-REQUEST-DOCUMENT
                   THRU 5000-REQUEST-DOCUMENT-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.


      *------------------
       2100-PROCESS-INIT.
      *------------------
      * SET UP MESSAGE VARIABLES.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

       2100-PROCESS-INIT-X.
           EXIT.


      *-----------------------------
       3000-VALIDATE-CONTROL-FIELDS.
      *-----------------------------
      * VALIDATE-CONTROL FIELDS: VALIDATE THE CLIENT AND DOCUMENT
      * TO ENSURE THAT THE RECORDS ARE FOUND ON THE FILE.
      * THE SCROLL SHOULD CONTAIN A VALID DIRECTION.

           SET WGLOB-GOOD-RETURN      TO TRUE.

      * DETERMINE IF CLIENT RECORD EXISTS

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
           SET L5600-CCAS-MSG-NOT-REQD
                                      TO TRUE.
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           IF  L5600-RETRN-CLI-NOT-FOUND
           OR  L5600-CNFD-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF  L5600-CCAS-ACCS-RESTRICTED
               MOVE 'XS00000199'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR
                                      TO TRUE
               END-IF

           END-IF.

      * READ THE CLIENT TABLE TO OBTAIN THE SURNAME

           MOVE MIR-CLI-ID            TO L2437-CLI-ID.
           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  L2437-RETRN-CLI-NOT-FOUND
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

      *   DETERMINE IF  THE REQURESTED DOCUMENT EXISTS.

           IF  MIR-DOC-ID NOT =   SPACES
               MOVE MIR-DOC-ID        TO WDOCM-DOC-ID
023447*        MOVE WGLOB-USER-LANG   TO WDOCM-DOC-LANG-CD
               PERFORM  DOCM-1000-READ
                   THRU DOCM-1000-READ-X

               IF  NOT WDOCM-IO-OK
                   SET WGLOB-RETURN-ERROR
                                      TO TRUE
                   MOVE 'XS00000041'  TO WGLOB-MSG-REF-INFO
                   MOVE WDOCM-KEY     TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

           END-IF.

      *   VALIDATE THE SEQUENCE NUMBER

           IF  MIR-CCAS-MSG-SEQ-NUM = SPACE
               MOVE ALL ZERO          TO MIR-CCAS-MSG-SEQ-NUM
           END-IF.

           MOVE  'N'                  TO L0280-SIGN-IND.
           MOVE  3                    TO L0280-LENGTH.
           MOVE  ZERO                 TO L0280-PRECISION.
           MOVE  MIR-CCAS-MSG-SEQ-NUM TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
020874*    MOVE  L0280-OUTPUT         TO WS-EDIT-3-0.
020874*    MOVE  WS-EDIT-3-0          TO MIR-CCAS-MSG-SEQ-NUM.
020874     MOVE L0280-OUTPUT          TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CCAS-MSG-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CCAS-MSG-SEQ-NUM.

           IF  L0280-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               MOVE  'NS05800004'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       3000-VALIDATE-CONTROL-FIELDS-X.
           EXIT.


      *-------------
       4000-DISPLAY.
      *-------------
      * DISPLAY PROCESSING: RETRIEVE RECORDS AND DISPLAY DATA

015904*    MOVE L2437-CLI-SUR-NM      TO MIR-CLI-SUR-NM.
015904     MOVE L2437-CLI-SUR-NM      TO MIR-CLI-INDV-SUR-NM.

      *   DISPLAY POLICY REALATED INFORMATION

           PERFORM  4100-DISPLAY-POLICY
               THRU 4100-DISPLAY-POLICY-X.

      *   DISPLAY MAXIMUM OF 11 REQUIREMENTS ON THE SCREEN

           PERFORM  4200-DISPLAY-REQUIREMENTS
               THRU 4200-DISPLAY-REQUIREMENTS-X.

      *   DISPLAY MAXIMUM OF 50 CCKO MESSAGES ON THE SCREEN

           PERFORM  4300-DISPLAY-CCKO-REASONS
               THRU 4300-DISPLAY-CCKO-REASONS-X.

       4000-DISPLAY-X.
           EXIT.


      *--------------------
       4100-DISPLAY-POLICY.
      *--------------------
      * DISPLAY POLICY: BROWSE THE RELATIONSHIP FILE TO FIND THE
      * FIRST POLICY THAT THIS CLIENT IS AN INSURED ON.

      *  BUILD KEYS FOR BROWSE.

           MOVE SPACES                TO WRL-KEY.
           MOVE MIR-CLI-ID            TO WRL-CLI-ID.
016440*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.

           MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
           MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.
016440*    MOVE 'NEWBUS'              TO WRL-ENDBR-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.

      *  POSITION AT AND READ THE FIRST CLIENT RELATIONSHIP RECORD.

           PERFORM RL-1000-BROWSE
              THRU RL-1000-BROWSE-X.
           MOVE WRL-KEY               TO WS-HOLD-KEY.

           IF  WRL-IO-OK
               PERFORM  RL-2000-READ-NEXT
                   THRU RL-2000-READ-NEXT-X
           ELSE
               MOVE 'XS00000043'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4100-DISPLAY-POLICY-X
           END-IF.

      *  LOOP THRU THE RELATIONSHIP FILE

           SET WS-INSURED-FOUND-NO    TO TRUE.
           PERFORM  4110-CHECK-FOR-INSURED
               THRU 4110-CHECK-FOR-INSURED-X
               UNTIL WS-INSURED-FOUND
                  OR WRL-IO-EOF.

           PERFORM RL-3000-END-BROWSE
              THRU RL-3000-END-BROWSE-X.

      *  DISPLAY THE RESULTS OF THE SEARCH

           IF  WS-INSURED-FOUND
               MOVE RRL-REL-SYS-REF-POL-ID
                                      TO MIR-POL-ID
           ELSE
016440*        MOVE 'XS00000043'      TO WGLOB-MSG-REF-INFO
016440         MOVE 'NS05800006'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4100-DISPLAY-POLICY-X.
           EXIT.


      *-----------------------
       4110-CHECK-FOR-INSURED.
      *-----------------------
      * CHECK FOR INSURED:  TURN THE SWITCH ON WHEN AN INSURED IS
      * FOUND, ELSE READ THE NEXT RECORD.

           IF  RRL-REL-TYP-CD =  'I'
016440         MOVE RRL-REL-SYS-REF-POL-ID TO WPOL-POL-ID
016440         PERFORM POL-1000-READ
016440            THRU POL-1000-READ-X
016440       EVALUATE TRUE
016440         WHEN RPOL-POL-STAT-PENDING
                    SET WS-INSURED-FOUND   TO TRUE
016440         WHEN RPOL-POL-STAT-IN-FORCE
016440              PERFORM 2222-1000-BUILD-PARM-INFO
016440                 THRU 2222-1000-BUILD-PARM-INFO-X
016440              MOVE RPOL-POL-ID       TO L2222-POL-ID
016440              PERFORM 2222-1000-FIND-PEND-CVG
016440                 THRU 2222-1000-FIND-PEND-CVG-X
016440              IF L2222-INFORCE-POL-PEND-CVG
016440                 SET WS-INSURED-FOUND   TO TRUE
016440              ELSE
016440                 PERFORM RL-2000-READ-NEXT
016440                    THRU RL-2000-READ-NEXT-X
016440              END-IF
019327         WHEN OTHER
019327              PERFORM  RL-2000-READ-NEXT
019327                  THRU RL-2000-READ-NEXT-X
016440       END-EVALUATE
           ELSE
               PERFORM RL-2000-READ-NEXT
                  THRU RL-2000-READ-NEXT-X
           END-IF.

       4110-CHECK-FOR-INSURED-X.
           EXIT.


      *--------------------------
       4200-DISPLAY-REQUIREMENTS.
      *--------------------------
      * DISPLAY REQUIREMENTS: BROWSE THE CLIENT REQUIREMENT FILE
      * TO DISPLAY THE 10 MOST RECENT REQUIREMENTS.

      *   BUILD KEYS FOR BROWSING.

           MOVE HIGH-VALUES           TO WREQT-KEY.
           MOVE MIR-CLI-ID            TO WREQT-CLI-ID.
           MOVE 'C'                   TO WREQT-CPREQ-POL-CLI-CD.

           MOVE LOW-VALUES            TO WREQT-ENDBR-KEY.
           MOVE MIR-CLI-ID            TO WREQT-ENDBR-CLI-ID.
           MOVE 'C'                   TO WREQT-ENDBR-CPREQ-POL-CLI-CD.

      *  POSITION AT, AND READ THE LAST CLIENT REQUIREMENT.

           PERFORM  REQT-1000-BROWSE-PREV
               THRU REQT-1000-BROWSE-PREV-X.

           IF  WREQT-IO-OK
               PERFORM  REQT-2000-READ-PREV
                   THRU REQT-2000-READ-PREV-X
           ELSE
               MOVE 'NS05800001'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4200-DISPLAY-REQUIREMENTS-X
           END-IF.

      *  DISPLAY THE REQUIREMENTS.

           MOVE 1                     TO WS-IND.
           PERFORM  4210-REQUIREMENTS-LOOP
               THRU 4210-REQUIREMENTS-LOOP-X
               UNTIL WS-IND      >  WS-MAX-REQUIREMENTS
                  OR WREQT-IO-EOF.

           PERFORM  REQT-3000-END-BROWSE-PREV
               THRU REQT-3000-END-BROWSE-PREV-X.

      *  NO REQUIREMENTS EXIST FOR THE GIVEN CLIENT.

           IF  WS-IND            =  1
               MOVE 'NS05800001'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4200-DISPLAY-REQUIREMENTS-X.
           EXIT.


      *-----------------------
       4210-REQUIREMENTS-LOOP.
      *-----------------------
      * REQUIREMENTS LOOP: MOVE THE REQUIREMENT INFORMATION FROM
      * THE CURRENT RECORD TO THE SCREEN.

      * KEEP TRACK OF TOTAL LINES DISPLAYED, FOR SCROLL PROCESSING.

           MOVE RREQT-REQIR-ID        TO MIR-REQIR-ID-T (WS-IND).
           MOVE RREQT-CPREQ-STAT-CD
                                      TO MIR-CPREQ-STAT-CD-T (WS-IND).

      * READ THE NEXT RECORD WHEN SCREEN IS NOT FULL.

           ADD 1                      TO WS-IND.

           IF  WS-IND            >  WS-MAX-REQUIREMENTS
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  REQT-2000-READ-PREV
                   THRU REQT-2000-READ-PREV-X
           END-IF.

       4210-REQUIREMENTS-LOOP-X.
           EXIT.


      *--------------------------
       4300-DISPLAY-CCKO-REASONS.
      *--------------------------
      *   DISPLAY CLEAR CASE KICK OUT REASONS: SCROLL THROUGH THE
      *   CCKO FILE, TO DISPLAY THE KICK OUT REASONS. SINCE THE
      *   REASONS ARE STORED BY CLIENT NUMBER AND SEQUENCE NUMBER,
      *   WE WILL ALWAYS BE ABLE TO DO A FORWARD BROWSE. A BACKWARD
      *   SCROLL WILL BE SIMULATED BY CALCULATING THE STARTING
      *   SEQUENCE NUMBER.

      *  BUILD KEYS FOR BROWSING.

           MOVE SPACES                TO WCCKO-KEY.
           MOVE MIR-CLI-ID            TO WCCKO-CLI-ID.
           MOVE MIR-CCAS-MSG-SEQ-NUM  TO WCCKO-CCAS-MSG-SEQ-NUM.
           MOVE WCCKO-KEY             TO WCCKO-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCCKO-ENDBR-CCAS-MSG-SEQ-NUM.

      *  POSITION AT THE REQUESTED RECORD

           PERFORM  CCKO-1000-BROWSE
               THRU CCKO-1000-BROWSE-X.
012624*
012624*    MOVE  1                    TO WS-LOOP.
012624*
012624*  READ THE NEXT RECORD.
012624*
012624*    IF  WCCKO-IO-OK
012624*        PERFORM  4310-CCKO-READ-NEXT
012624*            THRU 4310-CCKO-READ-NEXT-X  WS-LOOP  TIMES
012624*    ELSE
012624*        MOVE 'NS05800002'      TO WGLOB-MSG-REF-INFO
012624*        PERFORM  0260-1000-GENERATE-MESSAGE
012624*            THRU 0260-1000-GENERATE-MESSAGE-X
012624*        GO TO 4300-DISPLAY-CCKO-REASONS-X
012624*    END-IF.
012624*
012624*  DISPLAY LAST UPDATE DATE

           MOVE +1                    TO WS-LINES.

           IF  WCCKO-IO-OK
012624         PERFORM  4310-CCKO-READ-NEXT
012624             THRU 4310-CCKO-READ-NEXT-X
           END-IF.

           IF  WCCKO-IO-OK
014221*        MOVE RCCKO-PREV-UPDT-DT
014221*                               TO L1640-INTERNAL-DATE
014221*        PERFORM  1640-2000-INTERNAL-TO-EXT
014221*            THRU 1640-2000-INTERNAL-TO-EXT-X
014221*        MOVE L1640-EXTERNAL-DATE
014221*                               TO MIR-PREV-UPDT-DT
014221         MOVE RCCKO-PREV-UPDT-TS
014221                                TO WWKDT-INT-TS
014221         MOVE WWKDT-INT-TS-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
014221         MOVE L1640-EXTERNAL-DATE
014221                                TO MIR-DV-PREV-UPDT-DT
               PERFORM  4320-DISPLAY-LINE
                   THRU 4320-DISPLAY-LINE-X
                   UNTIL WS-LINES >  WS-MAX-REASONS
                      OR WCCKO-IO-EOF
           END-IF.

      *  COMPLETION MESSAGE

           IF  WS-LINES  =  1
           AND MIR-CCAS-MSG-SEQ-NUM =  ZEROES
               MOVE 'NS05800002'      TO WGLOB-MSG-REF-INFO
           ELSE
               IF  WCCKO-IO-EOF
                   MOVE 'XS00000002'  TO WGLOB-MSG-REF-INFO
               ELSE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   SET WGLOB-MORE-DATA-EXISTS
                                      TO TRUE
                   MOVE  RCCKO-CCAS-MSG-SEQ-NUM
                                      TO MIR-CCAS-MSG-SEQ-NUM
               END-IF
           END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *  END THE BROWSE

           PERFORM  CCKO-3000-END-BROWSE
               THRU CCKO-3000-END-BROWSE-X.

       4300-DISPLAY-CCKO-REASONS-X.
           EXIT.


      *--------------------
       4310-CCKO-READ-NEXT.
      *--------------------

           PERFORM  CCKO-2000-READ-NEXT
               THRU CCKO-2000-READ-NEXT-X.

       4310-CCKO-READ-NEXT-X.
           EXIT.


      *------------------
       4320-DISPLAY-LINE.
      *------------------
      * ACCESS THE MESSAGE FILE USING THE MESSAGE NUMBER OBTAINED
      * FROM THE CCKO FILE.
      * MOVE DATA FROM RECORD TO MIR.

           MOVE RCCKO-MSG-REF-ID      TO WGLOB-MSG-REF-ID.
           MOVE RCCKO-MSG-REF-NUM     TO WGLOB-MSG-REF-NUM.
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
           MOVE WGLOB-MSG-TXT         TO MIR-MSG-TXT-T (WS-LINES).

           MOVE RCCKO-CCAS-MSG-RESP-TXT
                                  TO MIR-CCAS-MSG-RESP-TXT-T (WS-LINES).


           MOVE MIR-CCAS-MSG-RESP-TXT-T (WS-LINES)
                                      TO WS-JUST-FIELD.

           IF  WS-JUST-FIELD NOT = SPACES
           AND WS-JUST-FIELD-DET-SP = SPACE
               PERFORM  4325-LEFT-JUSTIFY
                   THRU 4325-LEFT-JUSTIFY-X
                   UNTIL WS-JUST-FIELD-DET-SP NOT = SPACES
           END-IF.

           MOVE WS-JUST-FIELD         TO
                      MIR-CCAS-MSG-RESP-TXT-T (WS-LINES).
           MOVE RCCKO-MISS-INFO-IND   TO MIR-MISS-INFO-IND-T (WS-LINES).

013578     MOVE RCCKO-CCAS-MSG-SEQ-NUM
013578                            TO MIR-CCAS-MSG-SEQ-NUM-T (WS-LINES).

           ADD +1                     TO WS-LINES.

           PERFORM  4310-CCKO-READ-NEXT
               THRU 4310-CCKO-READ-NEXT-X.

       4320-DISPLAY-LINE-X.
           EXIT.


      *------------------
       4325-LEFT-JUSTIFY.
      *------------------

           MOVE WS-JUST-FIELD-DET1    TO WS-JUST-FIELD-TMP1
           MOVE SPACE                 TO WS-JUST-FIELD-TMP2
           MOVE WS-JUST-FIELD-TMP     TO WS-JUST-FIELD.

       4325-LEFT-JUSTIFY-X.
           EXIT.


      *----------------------
       5000-REQUEST-DOCUMENT.
      *----------------------
      * REQUEST DOCUMENT:  IF  THE USER REQUESTS THE KICK-OUT DOCUM,
      * THE 'TOKENS' REQUIRED FOR THAT DOCUMENT (I.E. THE MISSING
      * INFORMATION), WILL BE OBTAINED FROM THIS ROUTINE.

      * BUILD CCKO-FIELDS.

           MOVE SPACES                TO WCCKO-KEY.
           MOVE MIR-CLI-ID            TO WCCKO-CLI-ID.
           MOVE ZEROES                TO WCCKO-CCAS-MSG-SEQ-NUM.
           MOVE HIGH-VALUES           TO WCCKO-ENDBR-KEY.
           MOVE MIR-CLI-ID            TO WCCKO-ENDBR-CLI-ID.

      * POSITION AT, AND READ THE NEXT RECORD

           PERFORM  CCKO-1000-BROWSE
               THRU CCKO-1000-BROWSE-X.

           IF  WCCKO-IO-OK
               PERFORM  CCKO-2000-READ-NEXT
                   THRU CCKO-2000-READ-NEXT-X
           ELSE
               MOVE 'NS05800002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO MIR-DOC-ID
               GO TO 5000-REQUEST-DOCUMENT-X
           END-IF.

      *  CHECK FOR MISSING DATA REQUIREMENTS

           IF  WCCKO-IO-OK
               SET WS-MISSING-DATA-NO TO TRUE
               PERFORM  5100-MISSING-DATA
                   THRU 5100-MISSING-DATA-X
                   UNTIL WS-MISSING-DATA
                      OR WCCKO-IO-EOF
           END-IF.

      *  COMPLETION MESSAGE.

           IF  WS-MISSING-DATA
               MOVE 'NS05800003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  CCKO-3000-END-BROWSE
                   THRU CCKO-3000-END-BROWSE-X
               MOVE SPACES            TO MIR-DOC-ID
               GO TO 5000-REQUEST-DOCUMENT-X
           END-IF.

           PERFORM  CCKO-3000-END-BROWSE
               THRU CCKO-3000-END-BROWSE-X.

      *  WRITE REQUEST TO PRINT TRANSACTION FILE

           PERFORM  0303-1000-BUILD-PARM-INFO
               THRU 0303-1000-BUILD-PARM-INFO-X.

010418     PERFORM  5010-GET-DFLT-SUB-CO
010418         THRU 5010-GET-DFLT-SUB-CO-X.

           MOVE 'PR'                  TO L0303-TRNXT-REC-CD.
           MOVE MIR-DOC-ID            TO L0303-DOC-ID.
           MOVE SPACES                TO L0303-POL-ID.
           MOVE MIR-CLI-ID            TO L0303-CLI-ID.
012624*    MOVE 'NB'                  TO L0303-APPL-ID.
           MOVE SPACES                TO L0303-PRTR-ID.
023447*    MOVE ZEROES                TO L0303-TRNXT-DOC-CPY-QTY-N.
           MOVE 'CC'                  TO L0303-TRNXT-TYP-CD.
           PERFORM  0303-1000-WRITE-PRTX-TRAN
               THRU 0303-1000-WRITE-PRTX-TRAN-X.

           MOVE 'NS05800005'          TO WGLOB-MSG-REF-INFO.
           MOVE MIR-DOC-ID            TO WGLOB-MSG-PARM (1)
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           MOVE SPACES                TO MIR-DOC-ID.

       5000-REQUEST-DOCUMENT-X.
           EXIT.

      /
      *--------------------------
010418 5010-GET-DFLT-SUB-CO.
      *--------------------------
010418
010418     PERFORM  3320-1000-BUILD-PARM-INFO
010418         THRU 3320-1000-BUILD-PARM-INFO-X.

010418     PERFORM  3320-1000-DEFAULT-SUB-CO
010418         THRU 3320-1000-DEFAULT-SUB-CO-X.

010418     IF  L3320-RETRN-OK
010418     AND L3320-RETRN-SBSDRY-CO-ID NOT = SPACES
010418         MOVE L3320-RETRN-SBSDRY-CO-ID
010418                                TO L0303-SBSDRY-CO-ID
010418         GO TO 5010-GET-DFLT-SUB-CO-X
010418     END-IF.

010418     MOVE LOW-VALUES            TO WSCOM-KEY.
010418     MOVE HIGH-VALUES           TO WSCOM-ENDBR-KEY.
010418
010418     PERFORM  SCOM-1000-BROWSE
010418         THRU SCOM-1000-BROWSE-X.
010418
010418     IF  NOT WSCOM-IO-OK
010418         GO TO 5010-GET-DFLT-SUB-CO-X
010418     END-IF.
010418
010418     PERFORM  SCOM-2000-READ-NEXT
010418         THRU SCOM-2000-READ-NEXT-X.
010418
010418     IF  WSCOM-IO-OK
010418         MOVE RSCOM-SBSDRY-CO-ID
010418                                TO  L0303-SBSDRY-CO-ID
010418     END-IF.
010418
010418     PERFORM  SCOM-3000-END-BROWSE
010418         THRU SCOM-3000-END-BROWSE-X.
010418
010418 5010-GET-DFLT-SUB-CO-X.
010418     EXIT.


      *------------------
       5100-MISSING-DATA.
      *------------------
      * MISSING DATA: SEARCHES THE CLIENT REQUIREMENT FILE TO SEE
      * IF  ANY OF THE REQUIREMENTS WERE GENERATED AS A RESULT OF
      * MISSING INFO.

           IF  RCCKO-MISS-INFO-IND      =  'Y'
               SET WS-MISSING-DATA    TO TRUE
           ELSE
               PERFORM  CCKO-2000-READ-NEXT
                   THRU CCKO-2000-READ-NEXT-X
           END-IF.

       5100-MISSING-DATA-X.
           EXIT.


      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      * SET EACH NON-KEY FIELD TO SPACES

015904*    MOVE SPACES                TO MIR-CLI-SUR-NM.
015904     MOVE SPACES                TO MIR-CLI-INDV-SUR-NM.
           MOVE SPACES                TO MIR-POL-ID.
           PERFORM  9110-BLANK-DISPLAY-LINES
               THRU 9110-BLANK-DISPLAY-LINES-X
               VARYING WS-LINES FROM 1 BY 1
               UNTIL (WS-LINES > WS-MAX-REASONS).

           PERFORM  9120-BLANK-REQUIREMENTS
               THRU 9120-BLANK-REQUIREMENTS-X
               VARYING WS-LINES FROM 1 BY 1
               UNTIL (WS-LINES > WS-MAX-REQUIREMENTS).

       9100-BLANK-DATA-FIELDS-X.
           EXIT.


      *-------------------------
       9110-BLANK-DISPLAY-LINES.
      *-------------------------
      * SET EACH DISPLAY LINE TO BLANKS

           MOVE SPACES                TO MIR-MSG-TXT-T (WS-LINES).
           MOVE SPACES                TO
                       MIR-CCAS-MSG-RESP-TXT-T (WS-LINES).
           MOVE SPACES                TO MIR-MISS-INFO-IND-T (WS-LINES).
013578     MOVE SPACES                TO
013578                 MIR-CCAS-MSG-SEQ-NUM-T (WS-LINES).

       9110-BLANK-DISPLAY-LINES-X.
           EXIT.


      *------------------------
       9120-BLANK-REQUIREMENTS.
      *------------------------
      * SET EACH REQUIREMENT TO BLANKS

           MOVE SPACES                TO MIR-REQIR-ID-T (WS-LINES).
           MOVE SPACES                TO MIR-CPREQ-STAT-CD-T (WS-LINES).

       9120-BLANK-REQUIREMENTS-X.
           EXIT.


      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      * MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      * TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                   TO WGLOB-REF-POLICY-OR-CLIENT.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023118/
023118*--------------------------
023118 9990-INIT-WORKING-STORAGE.
023118*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0303-0000-INIT-PARM-INFO
025970         THRU 0303-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2222-0000-INIT-PARM-INFO
025970         THRU 2222-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3320-0000-INIT-PARM-INFO
025970         THRU 3320-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-JUST-FIELD.
025970     INITIALIZE                         WS-JUST-FIELD-TMP.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-MAX-REASONS         TO TRUE.
025970     SET WS-DEFAULT-MAX-REQUIREMENTS    TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     MOVE SPACES                        TO WWKDT-WORK-FIELDS.
023118
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.

      ****************************************************************
      * PROCESSING COPYBOOKS
      ****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY CCPSPGA.

       COPY XCPPINIT.
       COPY XCPPEXIT.
012624*COPY XCPPMEXT.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      /
010418 COPY CCPBSCOM.
      /
       COPY NCPBCCKO.
016537*COPY NCPVCCKO.

016440 COPY CCPNPOL.

023447*COPY NCPNDOCM.
023447 COPY XCPNDOCM.

       COPY NCPVREQT.

       COPY CCPBRL.
      /
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
       COPY NCPS0303.
018764*COPY NCCL0303.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY NCPL0303.

018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.

010418 COPY CCPS3320.
018764*COPY CCCL3320.
018764 COPY CCPL3320.

016440 COPY CCPS2222.
018764*COPY CCCL2222.
018764 COPY CCPL2222.

       COPY CCPS5600.
018764*COPY CCCL5600.
018764 COPY CCPL5600.

025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.

025970 COPY XCPS1640.
       COPY XCPL1640.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0580                     **
      *****************************************************************
