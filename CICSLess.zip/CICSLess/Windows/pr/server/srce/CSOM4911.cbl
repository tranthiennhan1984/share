      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4911.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4911                                         **
      **  REMARKS:  THIS MODULE PROVIDES A LIST OF THE DIV OPTIONS   **
      **            FOR A POLICY                                     **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016051**  6.1       ORIGINAL - NEW FOR RELEASE                       **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018770**  6.3       PCR - ALLOWABLE VALUE EDIT                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4911'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970                                                 VALUE 20.
025970         88  WS-MAX-LIST-LINES-DEFAULT           VALUE 20.
025970
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '4911'.
016548*    05  WS-MAX-LIST-LINES                       PIC S9(04) COMP
025970*    05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970*                                                VALUE 20.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWCVGS.
       COPY CCWWINDX.
021930*COPY XCWEBLCH.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
018770*COPY XCFWDMAD.
018770*COPY XCFRDMAD.
018770*
       COPY CCFWPDIV.
       COPY CCFRPDIV.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
018764*COPY XCWLPTR.
      /
028298 COPY CCWL2626.
       COPY CCWL3330.
      /
018770 COPY XCWL8960.
018770
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4911.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4911'               TO WGLOB-MSG-PARM (2)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------
       2000-LIST.
      *--------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE MIR-POL-ID            TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           MOVE RPOL-PLAN-ID          TO WPH-PLAN-ID.
           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  WPH-IO-NOT-FOUND
      * MSG: 'PLAN (@1) NOT FOUND'
               MOVE 'XS00000049'    TO WGLOB-MSG-REF-INFO
               MOVE WPH-PLAN-ID     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2000-LIST-X
           END-IF.

           MOVE ZEROS                   TO I.
           PERFORM  3330-1000-BUILD-PARM-INFO
               THRU 3330-1000-BUILD-PARM-INFO-X.
           SET L3330-LOC-GR-TYP-DIVOP   TO TRUE.
           PERFORM  3330-1000-GET-LOC-GROUP
               THRU 3330-1000-GET-LOC-GROUP-X.

           IF  L3330-RETRN-OK
               CONTINUE
           ELSE
      * MSG: LOCATION GROUP FOR DIVIDEND OPT NOT FOUND
              MOVE 'CS49110001'         TO  WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2000-LIST-X
           END-IF.

           MOVE LOW-VALUE            TO  WPDIV-KEY.
           MOVE RPOL-PLAN-ID         TO  WPDIV-PLAN-ID
           MOVE L3330-LOC-GR-ID      TO  WPDIV-LOC-GR-ID.

           MOVE WPDIV-KEY            TO  WPDIV-ENDBR-KEY.
           MOVE HIGH-VALUE           TO  WPDIV-ENDBR-PLAN-DIV-OPT-CD.
023436     MOVE HIGH-VALUE           TO 
023436                               WPDIV-ENDBR-PLAN-DIV-XCES-CD.
           PERFORM  PDIV-1000-BROWSE
               THRU PDIV-1000-BROWSE-X.

           IF  WPDIV-IO-OK
               PERFORM  PDIV-2000-READ-NEXT
                   THRU PDIV-2000-READ-NEXT-X
           END-IF.

018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770
018770     MOVE 'POL-DIV-OPT-CD'      TO L8960-AV-TBL-CD.
018770
           PERFORM
               VARYING I
               FROM 1 BY 1
               UNTIL I > WS-MAX-LIST-LINES
               OR NOT WPDIV-IO-OK

               MOVE RPDIV-PLAN-DIV-OPT-CD
018770*                               TO WDMAD-DM-AV-CD
018770                                TO L8960-AV-CD
               PERFORM  2100-GET-DESC-TXT
                   THRU 2100-GET-DESC-TXT-X

               MOVE RPDIV-PLAN-DIV-OPT-CD
                                      TO MIR-DV-SBOX-CD-T (I)
018770*        MOVE RDMAD-DM-AV-DESC-TXT
018770         MOVE L8960-AV-DESC-TXT
                                      TO MIR-DV-SBOX-DESC-TXT-T (I)

               PERFORM  PDIV-2000-READ-NEXT
                   THRU PDIV-2000-READ-NEXT-X

           END-PERFORM.

           IF  NOT WPDIV-IO-EOF
      *MSG: MORE DATA EXISTS
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDIV-3000-END-BROWSE
               THRU PDIV-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *------------------
       2100-GET-DESC-TXT.
      *------------------

018770*    MOVE 'POL-DIV-OPT-CD'      TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE WGLOB-USER-LANG       TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM  DMAD-1000-READ
018770*        THRU DMAD-1000-READ-X.
018770*
018770*    IF  WDMAD-IO-OK
018770
018770     PERFORM  8960-2000-RETRIEVE-CODE-DESC
018770         THRU 8960-2000-RETRIEVE-CODE-DESC-X.
018770
018770     IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      * MSG: 'DESCRIPTION FOR (@1 @2) NOT FOUND'
               MOVE 'CS49110002'      TO WGLOB-MSG-REF-INFO
018770*        MOVE 'POL-DIV-OPT-CD'  TO WGLOB-MSG-PARM (1)
018770*        MOVE WDMAD-DM-AV-CD    TO WGLOB-MSG-PARM (2)
018770         MOVE L8960-AV-TBL-CD   TO WGLOB-MSG-PARM (1)
018770         MOVE L8960-AV-CD       TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
018770*        MOVE SPACE             TO RDMAD-DM-AV-DESC-TXT
           END-IF.

       2100-GET-DESC-TXT-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES              TO MIR-DV-SBOX-CD-G.
           MOVE SPACES              TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
      * FOR POLICY RELATED TRANSACTION
      *
           SET  WGLOB-REF-POLICY          TO TRUE.

           MOVE MIR-POL-ID                TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3330-0000-INIT-PARM-INFO
025970         THRU 3330-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
       COPY CCPPMIDT.
      /
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
      /
018770 COPY XCPS8960.
018770 COPY XCPL8960.
018770
       COPY CCPS3330.
018764*COPY CCCL3330.
018764 COPY CCPL3330.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
       COPY CCPNPOL.
      /
018770*COPY XCPNDMAD.
018770*
       COPY CCPNPH.
      /
       COPY CCPBPDIV.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4911                     **
      *****************************************************************
