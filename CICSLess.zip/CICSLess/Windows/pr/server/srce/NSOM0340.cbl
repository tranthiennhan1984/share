      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0340.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0340                                         **
      **  REMARKS:  REQUIREMENTS TABLE PROCESS DRIVER (RTAB)         **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE REQUIREMENTS TABLE.            **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010645**  5.6       VARIATIONS BY LOCATION - UW AND NB               **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
030413**  7.1       DOCUMENT RECORD EDITS                            **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0340'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'RTAB'.
016548*    05  WS-SUB                       PIC S9(4)  COMP.
016548     05  WS-SUB                       PIC S9(4)  BINARY.
016548*    05  WS-SUB2                      PIC S9(4)  COMP.
016548     05  WS-SUB2                      PIC S9(4)  BINARY.
016548*    05  WS-DOC-SUB                   PIC S9(4)  COMP.
016548     05  WS-DOC-SUB                   PIC S9(4)  BINARY.
023447*    05  WS-DOC-NAME                  PIC X(5).
023447     05  WS-DOC-NAME                  PIC X(30).
025970*    05  WS-DATA-EDITS                PIC X(01)  VALUE '0'.
025970     05  WS-DATA-EDITS                PIC X(01).
025970         88  WS-DEFAULT-DATA-EDITS               VALUE '0'.
025970*    05  WS-NO-DISPLAY-LINES          PIC S9(3)  COMP-3
025970*                                                VALUE +11.
           05  WS-LINES                     PIC S9(3)  COMP-3.
           05  WS-PIC-Z9                    PIC Z9.
           05  WS-PIC-99                    PIC S9(2).
025970*    05  WS-EDIT-FUP                  PIC X      VALUE '0'.
025970     05  WS-EDIT-FUP                  PIC X.
025970         88  WS-DEFAULT-EDIT-FUP                 VALUE '0'.
025970*    05  WS-EDIT-DOC                  PIC X      VALUE '0'.
025970     05  WS-EDIT-DOC                  PIC X.
025970         88  WS-DEFAULT-EDIT-DOC                 VALUE '0'.
           05  WS-VALIDATE-CONTROL          PIC X(01).
               88  WS-INVALID-CONTROL                  VALUE '1'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE
                   '0340' '0341' '0342' '0343' '0344'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0340'.
               88  WS-BUS-FCN-CREATE        VALUE '0341'.
               88  WS-BUS-FCN-UPDATE        VALUE '0342'.
               88  WS-BUS-FCN-DELETE        VALUE '0343'.
               88  WS-BUS-FCN-LIST          VALUE '0344'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0340'.
           05  WS-REQIR-TYP-CD              PIC X(01).
010645*        88  WS-REQIR-TYP-VALID       VALUE 'I' 'U'.
010645         88  WS-REQIR-TYP-VALID       VALUE 'I' 'U' 'S'.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'RTAB'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '0340'.
025970     05  WS-NO-DISPLAY-LINES          PIC S9(3)  COMP-3.
025970         88  WS-DEFAULT-NO-DISPLAY-LINES         VALUE +11.
      /
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY XCWEBLCH.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
023447*COPY NCFWDOCM.
023447*COPY NCFRDOCM.
023447 COPY XCFWDOCM.
023447 COPY XCFRDOCM.
      /
014221 COPY CCWWLOCK.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY NCFWRTAB.
       COPY NCFRRTAB.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY XCWL0280.
020874 COPY XCWL0290.
014221 COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0340.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
557708
023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      ***************************************************************
      *   NORMAL PROCESSING: CHECK SECURITY PERMISSION & DISTRIBUTE
      *   CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      ***************************************************************

020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.
025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *
      *   CHECK BUSINESS FUNCTION ID FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3000-PROCESS-LIST
                        THRU 3000-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  4500-PROCESS-RETRIEVE
                        THRU 4500-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM0340'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       3000-PROCESS-LIST.
      *------------------
      ***************************************************************
      *   INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE AND
      *   LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.
      ***************************************************************
      *
      *  SET UP BROWSE KEY LIMITS
      *
           PERFORM  7100-BUILD-RTAB-KEY
               THRU 7100-BUILD-RTAB-KEY-X.
           MOVE HIGH-VALUES           TO WRTAB-ENDBR-KEY.
      *
      *  POSITION AT AND READ FIRST RECORD
      *
           PERFORM  RTAB-1000-BROWSE
               THRU RTAB-1000-BROWSE-X.

           IF WRTAB-IO-OK
               PERFORM  RTAB-2000-READ-NEXT
                   THRU RTAB-2000-READ-NEXT-X
              IF WRTAB-IO-EOF
                  MOVE 'XS00000034'   TO WGLOB-MSG-REF-INFO
                  MOVE WRTAB-KEY      TO WGLOB-MSG-PARM (1)
                  PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU  0260-1000-GENERATE-MESSAGE-X
034802*       ELSE
034802*           NEXT SENTENCE
              END-IF
           ELSE
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-LIST-X
           END-IF.
      *
      *   LOAD SCREEN DATA ARRAY.
      *
           IF WRTAB-IO-OK
                MOVE 1                TO WS-LINES
                PERFORM  3100-DISPLAY-RECORD
                    THRU 3100-DISPLAY-RECORD-X
                    UNTIL (WS-LINES >  WS-NO-DISPLAY-LINES)
                       OR (WRTAB-IO-EOF)
               IF WRTAB-IO-EOF
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   MOVE WRTAB-KEY     TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
                   MOVE WRTAB-KEY     TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE RRTAB-REQIR-ID TO MIR-REQIR-ID
               END-IF
           END-IF.

      *
      *   COMPLETION MESSAGE
      *

           PERFORM  RTAB-3000-END-BROWSE
               THRU RTAB-3000-END-BROWSE-X.

       3000-PROCESS-LIST-X.
           EXIT.
      /
      *--------------------
       3100-DISPLAY-RECORD.
      *--------------------
      ***************************************************************
      *   INQUIRY DISPLAY PROCESSING:INPUT: WS-LINES
      *   DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE GIVEN
      *   BY WS-LINES AND RETRIEVE THE NEXT RECORD.
      ***************************************************************

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  RTAB-2000-READ-NEXT
               THRU RTAB-2000-READ-NEXT-X.

       3100-DISPLAY-RECORD-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      ***************************************************************
      *   CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, INIT NEW
      *   RECORD AND ALLOW USER TO MODIFY.
      ***************************************************************
      *
      *   VALIDATE CONTROL FIELDS.
      *
           PERFORM 7000-VALIDATE-RTAB-KEY
              THRU 7000-VALIDATE-RTAB-KEY-X.
           IF WS-DATA-EDITS = '1'
               GO TO 4000-PROCESS-CREATE-X
           END-IF.
      *
      *   BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-RTAB-KEY
               THRU 7100-BUILD-RTAB-KEY-X.
      *
      *   CHECK IF RECORD EXISTS.
      *
           PERFORM  RTAB-1000-READ
               THRU RTAB-1000-READ-X.

           IF WRTAB-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      *   CREATE NEW RECORD
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
           PERFORM  RTAB-1000-CREATE
               THRU RTAB-1000-CREATE-X.
           PERFORM  RTAB-1000-WRITE
               THRU RTAB-1000-WRITE-X.

014221     PERFORM  RTAB-1000-READ-TWRK-TS
014221         THRU RTAB-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           MOVE WRTAB-KEY             TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE +1                    TO WS-LINES.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *----------------------
       4500-PROCESS-RETRIEVE.
      *----------------------
      *
      *   BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-RTAB-KEY
               THRU 7100-BUILD-RTAB-KEY-X.
      *
      *   CHECK IF RECORD EXISTS.
      *
014221*    PERFORM  RTAB-1000-READ
014221*        THRU RTAB-1000-READ-X.

014221     PERFORM  RTAB-1000-READ-TWRK-TS
014221         THRU RTAB-1000-READ-TWRK-TS-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF WRTAB-IO-NOT-FOUND
               MOVE 'NS03400001'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE +1                TO WS-LINES
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       4500-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------
      ***************************************************************
      *   MAINTAIN PROCESSING: GET RECORD, EDIT DATA FIELDS, AND
      *   UPDATE IF EDIT ERRORS, ELSE UNLOCK.
      ***************************************************************
      *
      *   BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-RTAB-KEY
               THRU 7100-BUILD-RTAB-KEY-X.
      *
      *   READ RECORD FOR UPDATE.
      *

014221*    PERFORM  RTAB-1000-READ-FOR-UPDATE
014221*        THRU RTAB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  RTAB-2000-UPDATE-TWRK-TS
014221         THRU RTAB-2000-UPDATE-TWRK-TS-X.

           IF WRTAB-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'RTAB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WRTAB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.

           PERFORM  8000-CROSS-EDITS
               THRU 8000-CROSS-EDITS-X.

           PERFORM  RTAB-2000-REWRITE
               THRU RTAB-2000-REWRITE-X.

014221     PERFORM  RTAB-1000-READ-TWRK-TS
014221         THRU RTAB-1000-READ-TWRK-TS-X.

           MOVE SPACES                TO REDIT-ETBL-DESC-TXT.
           MOVE RRTAB-REQIR-ID        TO WEDIT-ETBL-VALU-ID.
           PERFORM  REQT-2000-DESC
               THRU REQT-2000-DESC-X.
           MOVE REDIT-ETBL-DESC-TXT   TO MIR-DV-REQIR-DESC-TXT-T (1).

           IF WS-DATA-EDITS = '0'
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
      ***  REMOVE ASTERISK IF POPPING THE STACK LOGIC REQUIRED
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------
      ***************************************************************
      *   DELETE PROCESSING: DELETE THE RECORD
      ***************************************************************
      *
      *   BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-RTAB-KEY
               THRU 7100-BUILD-RTAB-KEY-X.
      *
      *   READ RECORD FOR UPDATE.
      *
014221*    PERFORM  RTAB-1000-READ-FOR-UPDATE
014221*        THRU RTAB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  RTAB-2000-UPDATE-TWRK-TS
014221         THRU RTAB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'RTAB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WRTAB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WRTAB-IO-NOT-FOUND
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  RTAB-1000-DELETE
                   THRU RTAB-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *-----------------------
       7000-VALIDATE-RTAB-KEY.
      *-----------------------
      *****************************************************************
      *  VALIDATE RTAB KEY: REQUIREMENT NAME (MIR-REQIR-ID)
      *****************************************************************

           MOVE '0'                   TO WS-DATA-EDITS.
           IF MIR-REQIR-ID          =  SPACES
               MOVE 'NS03400008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
               GO TO 7000-VALIDATE-RTAB-KEY-X
           END-IF.

           MOVE MIR-REQIR-ID          TO WEDIT-ETBL-VALU-ID.
           PERFORM  REQT-2000-DESC
               THRU REQT-2000-DESC-X.
           IF REDIT-ETBL-DESC-TXT = SPACES
      *MSG:    REQT (@1) DESCRIPTION NOT FOUND ON EDIT TYPE 'REQTC'
               MOVE 'NS03400014'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7000-VALIDATE-RTAB-KEY-X.
           EXIT.
      /

      *--------------------
       7100-BUILD-RTAB-KEY.
      *--------------------
      *****************************************************************
      *  BUILD RTAB KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************

           MOVE MIR-REQIR-ID          TO WRTAB-REQIR-ID.

       7100-BUILD-RTAB-KEY-X.
           EXIT.
      /
      *----------------------
       7500-EDIT-DATA-FIELDS.
      *----------------------
      *****************************************************************
      *  FIELD EDITS: CHECK VALIDITY OF ALL DATA FIELDS.
      *****************************************************************

           MOVE '0'                   TO WS-DATA-EDITS.

           PERFORM  7510-EDIT-FUPDA
               THRU 7510-EDIT-FUPDA-X.

557660     PERFORM  7511-EDIT-FUPDB
557660         THRU 7511-EDIT-FUPDB-X.

557660     PERFORM  7512-EDIT-FUPDC
557660         THRU 7512-EDIT-FUPDC-X.

           PERFORM  7520-EDIT-DOCNAMEA
               THRU 7520-EDIT-DOCNAMEA-X.

557660     PERFORM  7521-EDIT-DOCNAMEB
557660         THRU 7521-EDIT-DOCNAMEB-X.

557660     PERFORM  7522-EDIT-DOCNAMEC
557660         THRU 7522-EDIT-DOCNAMEC-X.

           PERFORM  7530-EDIT-VALID-PERIOD
               THRU 7530-EDIT-VALID-PERIOD-X.

           PERFORM  7540-EDIT-REQ-TYPE
               THRU 7540-EDIT-REQ-TYPE-X.

           PERFORM  7560-EDIT-LAB-CODE
               THRU 7560-EDIT-LAB-CODE-X.

       7500-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *----------------
       7510-EDIT-FUPDA.
      *----------------
      *****************************************************************
      *  EDIT FOLLOWUP DAYS
      *****************************************************************

           MOVE '0'                   TO  WS-EDIT-FUP.
           MOVE '0'                   TO  WS-EDIT-DOC.
           IF  MIR-FOLWUP-1-DY-DUR-T (1) = SPACES
020874*        MOVE RRTAB-FOLWUP-DY-DUR (1)
020874*                               TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-1-DY-DUR-T (1)
020874         MOVE RRTAB-FOLWUP-DY-DUR (1)  TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-1-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-1-DY-DUR-T (1)
               GO TO 7510-EDIT-FUPDA-X
           END-IF.

           IF MIR-FOLWUP-1-DY-DUR-T (1) = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE ZEROES            TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-1-DY-DUR-T (1)
020874         MOVE ZEROES            TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-1-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-1-DY-DUR-T (1)
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-FOLWUP-1-DY-DUR-T (1)
                                      TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-1-DY-DUR-T (1)
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-1-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-1-DY-DUR-T (1)
           ELSE
               MOVE 'NS03400002'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FOLWUP-1-DY-DUR-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-EDIT-FUP
               MOVE '1'               TO WS-DATA-EDITS
               GO TO 7510-EDIT-FUPDA-X
           END-IF.

           MOVE L0280-OUTPUT          TO RRTAB-FOLWUP-DY-DUR  (1).

       7510-EDIT-FUPDA-X.
           EXIT.
      /
      *----------------
557660 7511-EDIT-FUPDB.
      *----------------

           MOVE '0'                   TO  WS-EDIT-FUP.
           MOVE '0'                   TO  WS-EDIT-DOC.
           IF  MIR-FOLWUP-2-DY-DUR-T (1) = SPACES
020874*        MOVE RRTAB-FOLWUP-DY-DUR (2)
020874*                               TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-2-DY-DUR-T (1)
020874         MOVE RRTAB-FOLWUP-DY-DUR (2) TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-2-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-2-DY-DUR-T (1)
               GO TO 7511-EDIT-FUPDB-X
           END-IF.

           IF MIR-FOLWUP-2-DY-DUR-T (1) = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE ZEROES            TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-2-DY-DUR-T (1)
020874         MOVE ZEROES            TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-2-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-2-DY-DUR-T (1)
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-FOLWUP-2-DY-DUR-T (1)
                                      TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-2-DY-DUR-T (1)
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-2-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-2-DY-DUR-T (1)
           ELSE
               MOVE 'NS03400002'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FOLWUP-2-DY-DUR-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-EDIT-FUP
               MOVE '1'               TO WS-DATA-EDITS
557660         GO TO 7511-EDIT-FUPDB-X
           END-IF.

           MOVE L0280-OUTPUT          TO RRTAB-FOLWUP-DY-DUR  (2).

557660 7511-EDIT-FUPDB-X.
           EXIT.
      /
      *----------------
557660 7512-EDIT-FUPDC.
      *----------------

           MOVE '0'                   TO  WS-EDIT-FUP.
           MOVE '0'                   TO  WS-EDIT-DOC.
           IF  MIR-FOLWUP-3-DY-DUR-T (1) = SPACES
020874*        MOVE RRTAB-FOLWUP-DY-DUR (3)
020874*                               TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-3-DY-DUR-T (1)
020874         MOVE RRTAB-FOLWUP-DY-DUR (3) TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-3-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-3-DY-DUR-T (1)
               GO TO 7512-EDIT-FUPDC-X
           END-IF.

           IF MIR-FOLWUP-3-DY-DUR-T (1) = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE ZEROES            TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-3-DY-DUR-T (1)
020874         MOVE ZEROES            TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-3-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-3-DY-DUR-T (1)
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-FOLWUP-3-DY-DUR-T (1)
                                      TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FOLWUP-3-DY-DUR-T (1)
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FOLWUP-3-DY-DUR-T (1)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FOLWUP-3-DY-DUR-T (1)
           ELSE
               MOVE 'NS03400002'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FOLWUP-3-DY-DUR-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-EDIT-FUP
               MOVE '1'               TO WS-DATA-EDITS
557660         GO TO 7512-EDIT-FUPDC-X
           END-IF.

           MOVE L0280-OUTPUT          TO RRTAB-FOLWUP-DY-DUR (3).

557660 7512-EDIT-FUPDC-X.
           EXIT.
      /
      *-------------------
       7520-EDIT-DOCNAMEA.
      *-------------------
      *****************************************************************
      *  EDIT DOCUMENT NAME.
      *****************************************************************

           IF  MIR-FOLWUP-1-DOC-ID-T (1) = SPACES
               MOVE RRTAB-FOLWUP-DOC-ID (1)
                                      TO MIR-FOLWUP-1-DOC-ID-T (1)
           END-IF.

           IF MIR-FOLWUP-1-DOC-ID-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FOLWUP-1-DOC-ID-T (1)
           END-IF.

030413     IF  MIR-FOLWUP-1-DOC-ID-T (1) = SPACES
030413         GO TO 7520-EDIT-DOCNAMEA-X
030413     END-IF.
030413
           MOVE MIR-FOLWUP-1-DOC-ID-T (1)
                                      TO WS-DOC-NAME.
           MOVE +1                    TO WS-DOC-SUB.
           PERFORM  7525-VALIDATE-DOCNAME
               THRU 7525-VALIDATE-DOCNAME-X.


       7520-EDIT-DOCNAMEA-X.
           EXIT.
      /
      *-------------------
557660 7521-EDIT-DOCNAMEB.
      *-------------------

           IF  MIR-FOLWUP-2-DOC-ID-T (1) = SPACES
               MOVE RRTAB-FOLWUP-DOC-ID (2)
                                      TO MIR-FOLWUP-2-DOC-ID-T (1)
           END-IF.

           IF MIR-FOLWUP-2-DOC-ID-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FOLWUP-2-DOC-ID-T (1)
           END-IF.

030413     IF  MIR-FOLWUP-2-DOC-ID-T (1) = SPACES
030413         GO TO 7521-EDIT-DOCNAMEB-X
030413     END-IF.
030413
           MOVE MIR-FOLWUP-2-DOC-ID-T (1)
                                      TO WS-DOC-NAME.
           MOVE +2                    TO WS-DOC-SUB.
           PERFORM  7525-VALIDATE-DOCNAME
               THRU 7525-VALIDATE-DOCNAME-X.

557660 7521-EDIT-DOCNAMEB-X.
           EXIT.
      /
      *-------------------
557660 7522-EDIT-DOCNAMEC.
      *-------------------

           IF  MIR-FOLWUP-3-DOC-ID-T (1) = SPACES
               MOVE RRTAB-FOLWUP-DOC-ID (3)
                                      TO MIR-FOLWUP-3-DOC-ID-T (1)
           END-IF.

           IF MIR-FOLWUP-3-DOC-ID-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FOLWUP-3-DOC-ID-T (1)
           END-IF.

030413     IF  MIR-FOLWUP-3-DOC-ID-T (1) = SPACES
030413         GO TO 7522-EDIT-DOCNAMEC-X
030413     END-IF.
030413
           MOVE MIR-FOLWUP-3-DOC-ID-T (1)
                                      TO WS-DOC-NAME.
           MOVE +3                    TO WS-DOC-SUB.
           PERFORM  7525-VALIDATE-DOCNAME
               THRU 7525-VALIDATE-DOCNAME-X.

557660 7522-EDIT-DOCNAMEC-X.
           EXIT.
      /
      *----------------------
       7525-VALIDATE-DOCNAME.
      *----------------------

           PERFORM 7526-BUILD-DOCM-KEY
              THRU 7526-BUILD-DOCM-KEY-X.
           PERFORM DOCM-1000-READ
              THRU DOCM-1000-READ-X.

           IF  WDOCM-IO-NOT-FOUND
      *MSG:    'DOCUMENT MASTER RECORD NOT FOUND (WDOCM-KEY)
               MOVE 'NS03400013'      TO WGLOB-MSG-REF-INFO
               MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               EVALUATE WS-DOC-SUB
                   WHEN +1
                        MOVE '1'      TO WS-EDIT-FUP
                        MOVE '1'      TO WS-DATA-EDITS
                        GO TO 7525-VALIDATE-DOCNAME-X

                   WHEN +2
                        MOVE '1'      TO WS-EDIT-FUP
                        MOVE '1'      TO WS-DATA-EDITS
                        GO TO 7525-VALIDATE-DOCNAME-X

                   WHEN +3
                        MOVE '1'      TO WS-EDIT-FUP
                        MOVE '1'      TO WS-DATA-EDITS
                        GO TO 7525-VALIDATE-DOCNAME-X
557660             END-EVALUATE
557660         END-IF.

           MOVE WS-DOC-NAME         TO RRTAB-FOLWUP-DOC-ID (WS-DOC-SUB).

       7525-VALIDATE-DOCNAME-X.
           EXIT.
      /
      *--------------------
       7526-BUILD-DOCM-KEY.
      *--------------------

023447*    MOVE WGLOB-USER-LANG       TO WDOCM-DOC-LANG-CD.
           MOVE WS-DOC-NAME           TO WDOCM-DOC-ID.

       7526-BUILD-DOCM-KEY-X.
           EXIT.
      /

      *-----------------------
       7530-EDIT-VALID-PERIOD.
      *-----------------------
      *****************************************************************
      *  EDIT VALID PERIOD.
      *****************************************************************

           IF  MIR-REQIR-VALID-DUR-T (1) = SPACES
               MOVE RRTAB-REQIR-VALID-DUR
                                      TO WS-PIC-99
               MOVE WS-PIC-99         TO WS-PIC-Z9
               MOVE WS-PIC-Z9         TO MIR-REQIR-VALID-DUR-T (1)
               GO TO 7530-EDIT-VALID-PERIOD-X
           END-IF.

           IF  MIR-REQIR-VALID-DUR-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO WS-PIC-Z9
               MOVE WS-PIC-Z9         TO MIR-REQIR-VALID-DUR-T (1)
           END-IF.


           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-REQIR-VALID-DUR-T (1)
                                      TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-PIC-99
               MOVE WS-PIC-99         TO WS-PIC-Z9
               MOVE WS-PIC-Z9         TO MIR-REQIR-VALID-DUR-T (1)
           ELSE
               MOVE 'NS03400003'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-VALID-DUR-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
               GO TO 7530-EDIT-VALID-PERIOD-X
           END-IF.

           IF L0280-OUTPUT = ZERO
               MOVE 'NS03400009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           END-IF.

           MOVE L0280-OUTPUT          TO RRTAB-REQIR-VALID-DUR.

       7530-EDIT-VALID-PERIOD-X.
           EXIT.
      /
      *-------------------
       7540-EDIT-REQ-TYPE.
      *-------------------
      *****************************************************************
      *  EDIT REQUIRED BY TYPE
      *****************************************************************

           IF  MIR-REQIR-TYP-CD-T (1) = SPACES
               MOVE RRTAB-REQIR-TYP-CD         TO MIR-REQIR-TYP-CD-T (1)
               GO TO 7540-EDIT-REQ-TYPE-X
           END-IF.

           IF MIR-REQIR-TYP-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-REQIR-TYP-CD-T (1)
           END-IF.

           MOVE MIR-REQIR-TYP-CD-T (1)               TO WS-REQIR-TYP-CD.
           IF WS-REQIR-TYP-VALID
               MOVE MIR-REQIR-TYP-CD-T (1)
                                      TO RRTAB-REQIR-TYP-CD
           ELSE
               MOVE 'NS03400004'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-TYP-CD-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7540-EDIT-REQ-TYPE-X.
           EXIT.
      /
      *-------------------
       7560-EDIT-LAB-CODE.
      *-------------------
      *****************************************************************
      *  EDIT LAB CODE AGAINST EDIT TABLE 'LABCD'
      *                               (SPACES ARE ALSO A VALID VALUE)
      *****************************************************************

           IF  MIR-LAB-ID-T (1) = SPACES
               MOVE RRTAB-LAB-ID      TO MIR-LAB-ID-T (1)
               GO TO 7560-EDIT-LAB-CODE-X
           END-IF.

           IF MIR-LAB-ID-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-LAB-ID-T (1)
           END-IF.

           MOVE MIR-LAB-ID-T (1)      TO WEDIT-ETBL-VALU-ID.
           PERFORM LABC-1000-EDIT-LAB-CODE
              THRU LABC-1000-EDIT-LAB-CODE-X.

           IF WEDIT-IO-OK
               MOVE MIR-LAB-ID-T (1)  TO RRTAB-LAB-ID
           ELSE
               MOVE 'NS03400011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7560-EDIT-LAB-CODE-X.
           EXIT.
      /
      *------------------
       7800-NUMERIC-EDIT.
      *------------------
      *****************************************************************
      *  NUMERIC EDIT
      *****************************************************************

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               GO TO 7800-NUMERIC-EDIT-X
           END-IF.

           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7800-NUMERIC-EDIT-X
           END-IF.

       7800-NUMERIC-EDIT-X.
           EXIT.
      /
      *-----------------
       8000-CROSS-EDITS.
      *-----------------

           PERFORM  8100-CROSS-EDITS
               THRU 8100-CROSS-EDITS-X
               VARYING WS-SUB2 FROM 1 BY 1
               UNTIL WS-SUB2 > 3.

           PERFORM  8200-CROSS-EDITS-2
               THRU 8200-CROSS-EDITS-2-X.

           PERFORM  8300-CROSS-EDITS-3
               THRU 8300-CROSS-EDITS-3-X.

           PERFORM  8400-CROSS-EDITS-4
               THRU 8400-CROSS-EDITS-4-X.

       8000-CROSS-EDITS-X.
           EXIT.
      /
      *-----------------
       8100-CROSS-EDITS.
      *-----------------
      *****************************************************************
      *  CROSS EDIT - BOTH THE FOLLOWUP DAYS & DOC NAME MUST BE ENTERED
      *****************************************************************

           IF  (RRTAB-FOLWUP-DY-DUR (WS-SUB2) = ZEROES
                AND RRTAB-FOLWUP-DOC-ID (WS-SUB2) NOT = SPACES)
           OR  (RRTAB-FOLWUP-DOC-ID (WS-SUB2) = SPACES
                AND RRTAB-FOLWUP-DY-DUR (WS-SUB2) NOT = ZEROES)
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS03400006'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8100-CROSS-EDITS-X.
           EXIT.


      *-------------------
       8200-CROSS-EDITS-2.
      *-------------------

           IF  RRTAB-FOLWUP-DY-DUR  (3) > 0
           AND RRTAB-FOLWUP-DY-DUR  (3) <= RRTAB-FOLWUP-DY-DUR  (2)
               MOVE '1'               TO WS-DATA-EDITS
      *MSG:    FOLLOW UP DAYS (@1) MUST BE INCREMENTED SEQUENTIALLY
               MOVE 'NS03400007'      TO WGLOB-MSG-REF-INFO
               MOVE '3'               TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  RRTAB-FOLWUP-DY-DUR (2) > 0
           AND RRTAB-FOLWUP-DY-DUR (2) <= RRTAB-FOLWUP-DY-DUR  (1)
               MOVE '1'               TO WS-DATA-EDITS
      *MSG:    FOLLOW UP DAYS (@1) MUST BE INCREMENTED SEQUENTIALLY
               MOVE 'NS03400007'      TO WGLOB-MSG-REF-INFO
               MOVE '2'               TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8200-CROSS-EDITS-2-X.
           EXIT.

      *-------------------
       8300-CROSS-EDITS-3.
      *-------------------

           IF  RRTAB-FOLWUP-DY-DUR (2) = ZERO
           AND RRTAB-FOLWUP-DY-DUR (3) = ZERO
               GO TO 8300-CROSS-EDITS-3-X
           END-IF.

           IF  RRTAB-FOLWUP-DY-DUR (1) = ZERO
           OR  RRTAB-FOLWUP-DY-DUR (2) = ZERO
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS03400010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8300-CROSS-EDITS-3-X.
           EXIT.

      *-------------------
       8400-CROSS-EDITS-4.
      *-------------------

010645* VERIFY THAT LABORATORY CODE IS ONLY PRESENT FOR UNDERWRITING
010645* REQUIREMENTS.
           MOVE MIR-REQIR-TYP-CD-T (1)               TO WS-REQIR-TYP-CD.
010645*    IF  MIR-REQIR-TYP-CD-T (1) = 'I'
010645     IF  MIR-REQIR-TYP-CD-T (1) NOT = 'U'
           AND MIR-LAB-ID-T (1) NOT = SPACES
               MOVE 'NS03400012'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-REQIR-TYP-CD-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8400-CROSS-EDITS-4-X.
           EXIT.

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      *
      *    COMBINED PARAGRAPHS 9100-, 9110- AND 9120 SINCE LOOPING
      *    NOT NEEDED (WHOLE TABLE IS SPACED OUT AT ONCE)
      *
           MOVE SPACES                TO MIR-REQIR-ID-G.
           MOVE SPACES                TO MIR-DV-REQIR-DESC-TXT-G.
           MOVE SPACES                TO MIR-FOLWUP-1-DY-DUR-G.
           MOVE SPACES                TO MIR-FOLWUP-1-DOC-ID-G.
           MOVE SPACES                TO MIR-FOLWUP-2-DY-DUR-G.
           MOVE SPACES                TO MIR-FOLWUP-2-DOC-ID-G.
           MOVE SPACES                TO MIR-FOLWUP-3-DY-DUR-G.
           MOVE SPACES                TO MIR-FOLWUP-3-DOC-ID-G.
           MOVE SPACES                TO MIR-REQIR-VALID-DUR-G.
           MOVE SPACES                TO MIR-REQIR-TYP-CD-G.
           MOVE SPACES                TO MIR-LAB-ID-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************

           MOVE RRTAB-REQIR-ID        TO MIR-REQIR-ID-T (WS-LINES).
           MOVE RRTAB-REQIR-ID        TO WEDIT-ETBL-VALU-ID.
           PERFORM  REQT-2000-DESC
               THRU REQT-2000-DESC-X.
           IF WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT
                 TO MIR-DV-REQIR-DESC-TXT-T (WS-LINES)
           END-IF.

           PERFORM  9220-MOVE-FUPDA-NME
               THRU 9220-MOVE-FUPDA-NME-X
           PERFORM  9230-MOVE-FUPDB-NME
               THRU 9230-MOVE-FUPDB-NME-X
           PERFORM  9240-MOVE-FUPDC-NME
               THRU 9240-MOVE-FUPDC-NME-X.

           MOVE RRTAB-REQIR-TYP-CD    TO MIR-REQIR-TYP-CD-T (WS-LINES).

           IF RRTAB-REQIR-VALID-DUR NOT NUMERIC
               MOVE ZEROES            TO WS-PIC-Z9
           ELSE
               MOVE RRTAB-REQIR-VALID-DUR
                                      TO WS-PIC-99
               MOVE WS-PIC-99         TO WS-PIC-Z9
           END-IF.

           MOVE WS-PIC-Z9           TO MIR-REQIR-VALID-DUR-T (WS-LINES).

           MOVE RRTAB-LAB-ID          TO MIR-LAB-ID-T (WS-LINES).

           ADD +1                          TO WS-LINES.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------
       9220-MOVE-FUPDA-NME.
      *--------------------
      *****************************************************************
      *  MOVE FOLLOWUP DAYS & DOC NAME TO THE MIR.
      *****************************************************************

           IF RRTAB-FOLWUP-DY-DUR  (1) NOT NUMERIC
020874*        MOVE ZEROES            TO WS-PIC-Z9
020874         MOVE ZEROES            TO L0290-INPUT-V00
           ELSE
020874*        MOVE RRTAB-FOLWUP-DY-DUR (1)
020874*                               TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874         MOVE RRTAB-FOLWUP-DY-DUR (1) TO L0290-INPUT-V00
           END-IF.
020874*    MOVE WS-PIC-Z9           TO MIR-FOLWUP-1-DY-DUR-T (WS-LINES).
020874     MOVE 0                   TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-FOLWUP-1-DY-DUR-T (WS-LINES)
020874                              TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-FOLWUP-1-DY-DUR-T (WS-LINES).
           MOVE RRTAB-FOLWUP-DOC-ID (1)
                                    TO MIR-FOLWUP-1-DOC-ID-T (WS-LINES).

       9220-MOVE-FUPDA-NME-X.
           EXIT.

      *--------------------
       9230-MOVE-FUPDB-NME.
      *--------------------

           IF RRTAB-FOLWUP-DY-DUR  (2) NOT NUMERIC
020874*        MOVE ZEROES            TO WS-PIC-Z9
020874         MOVE ZEROES            TO L0290-INPUT-V00
           ELSE
020874*        MOVE RRTAB-FOLWUP-DY-DUR  (2)
020874*                               TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874         MOVE RRTAB-FOLWUP-DY-DUR  (2) TO L0290-INPUT-V00
           END-IF.
020874*    MOVE WS-PIC-Z9           TO MIR-FOLWUP-2-DY-DUR-T (WS-LINES).
020874     MOVE 0                   TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-FOLWUP-2-DY-DUR-T (WS-LINES)
020874                              TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-FOLWUP-2-DY-DUR-T (WS-LINES).
           MOVE RRTAB-FOLWUP-DOC-ID (2)
                                    TO MIR-FOLWUP-2-DOC-ID-T (WS-LINES).

       9230-MOVE-FUPDB-NME-X.
           EXIT.

      *--------------------
       9240-MOVE-FUPDC-NME.
      *--------------------

           IF RRTAB-FOLWUP-DY-DUR (3) NOT NUMERIC
020874*        MOVE ZEROES            TO WS-PIC-Z9
020874         MOVE ZEROES            TO L0290-INPUT-V00
           ELSE
020874*        MOVE RRTAB-FOLWUP-DY-DUR (3)
020874*                               TO WS-PIC-99
020874*        MOVE WS-PIC-99         TO WS-PIC-Z9
020874         MOVE RRTAB-FOLWUP-DY-DUR (3) TO L0290-INPUT-V00
           END-IF.
020874*    MOVE WS-PIC-Z9           TO MIR-FOLWUP-3-DY-DUR-T (WS-LINES).
020874     MOVE 0                   TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-FOLWUP-3-DY-DUR-T (WS-LINES)
020874                              TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-FOLWUP-3-DY-DUR-T (WS-LINES).
           MOVE RRTAB-FOLWUP-DOC-ID (3)
                                    TO MIR-FOLWUP-3-DOC-ID-T (WS-LINES).

       9240-MOVE-FUPDC-NME-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
023118 9990-INIT-WORKING-STORAGE.
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
023118
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-DATA-EDITS          TO TRUE.
025970     SET WS-DEFAULT-NO-DISPLAY-LINES    TO TRUE.
025970     SET WS-DEFAULT-EDIT-FUP            TO TRUE.
025970     SET WS-DEFAULT-EDIT-DOC            TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPELABC.
      /
       COPY NCPEREQT.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY RTAB
014221                         '$VAR2' BY 'RTAB'.
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
      /
023447*COPY NCPNDOCM.
023447 COPY XCPNDOCM.
      /
       COPY NCPARTAB.
       COPY NCPBRTAB.
       COPY NCPNRTAB.
       COPY NCPURTAB.
       COPY NCPXRTAB.
       COPY NCPCRTAB.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0340                     **
      *****************************************************************
