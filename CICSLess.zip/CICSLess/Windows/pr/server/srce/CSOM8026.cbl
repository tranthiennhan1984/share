      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8026.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8026                                         **
      **  REMARKS:  THIS MODULE UPDATES THE INSURED ON ALL OF THE E  **
      **            COVERAGES                                        **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       DESCRIPTION                                      **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
015918**  6.2       MOVE GDLN CALCS FROM CVG LEVEL EDITS TO POL LVL  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
029059**  7.1       CASH VALUE ACCUMULATION TEST                     **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8026'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '8026'.
025970*    05  WS-TWRK-KEY                   PIC X(04) VALUE '8020'.
016548*    05  WS-MAX-CNT                    PIC S9(04) COMP.
016548     05  WS-MAX-CNT                    PIC S9(04) BINARY.
016548*    05  WS-SUB                        PIC S9(04) COMP.
016548     05  WS-SUB                        PIC S9(04) BINARY.
016548*    05  WS-SUB1                       PIC S9(04) COMP.
016548     05  WS-SUB1                       PIC S9(04) BINARY.
016548*    05  I                             PIC S9(04) COMP.
016548     05  I                             PIC S9(04) BINARY.
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT        VALUE '8020'.
029059     05  WS-CVG-ERROR                  PIC X(01).
029059         88 WS-CVG-ERROR-EXIST         VALUE 'Y'.
029059         88 WS-CVG-ERROR-NO            VALUE 'N'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWCVGS.
015918 COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
018764*COPY XCWLPTR.
016537*COPY XCWL0290.
028298 COPY CCWL2626.
014221 COPY XCWL8090.
       COPY CCWLPGA.
       COPY CCWL0570.
029059*COPY CCWL0578.
       COPY CCWL0620.
       COPY CCWL2435.
016440 COPY CCWL5400.
016503 COPY CCWL0289.
029059 COPY CCWL5382.
029059 COPY CCWL2470.
029059 COPY CCWL0182.
029059 COPY CCWL5950.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8026.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8026'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------
       2000-UPDATE.
      *-----------
      *
      *  THE RECORD MUST EXIST ON A MAINTAIN
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 2000-UPDATE-X
014221     END-IF.

           IF  WPOL-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE 'WPOL'                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-UPDATE-X
           END-IF.

016440*
016440*  POLICY TRANSFER CHECK
016440*
016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440        THRU  5400-1000-BUILD-PARM-INFO-X.
016440     SET L5400-POL-XFER-UPDATE     TO TRUE.
016440     PERFORM  5400-1000-POL-CHK
016440        THRU  5400-1000-POL-CHK-X.
016440
016440     IF  L5400-XFER-ACCS-RESTRICTED
016440     OR  NOT L5400-RETRN-OK
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
016440         GO TO 2000-UPDATE-X
016440     END-IF.


      *
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
      *
           IF  WGLOB-MSG-ERROR-SW > ZERO
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.
      *
           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID             TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

      *
           IF  L2435-RETRN-OK
               INITIALIZE L0620-INPUT-PARM-INFO
               IF  L2435-CLI-SEX-CD = 'C'
                   MOVE L2435-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2435-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2435-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2435-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2435-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2435-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO
                                  MIR-DV-INSRD-CLI-NM
           ELSE
      *MSG: 'CLIENT @1 NOT FOUND
               MOVE MIR-CLI-ID             TO WGLOB-MSG-PARM (1)
               MOVE 'CS80260001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM 3000-EDIT-CVG
              THRU 3000-EDIT-CVG-X
              VARYING WS-SUB FROM 1 BY 1
                UNTIL WS-SUB > RPOL-POL-CVG-REC-CTR-N.

029059*    IF  RPOL-POL-TAX-TYP-GDLN-RT
029059*    OR  RPOL-POL-TAX-TYP-GDLN-FORMULA
029059*    OR  RPOL-POL-TAX-TYP-GDLN-PROJ
029059*        PERFORM  0578-1000-BUILD-PARM-INFO
029059*            THRU 0578-1000-BUILD-PARM-INFO-X
029059*        IF RPOL-POL-ISS-EFF-DT = WWKDT-ZERO-DT
029059*        OR RPOL-POL-ISS-EFF-DT = SPACES
029059*           MOVE WGLOB-PROCESS-DATE      TO L0578-EFF-DT
029059*        ELSE
029059*           MOVE RPOL-POL-ISS-EFF-DT     TO L0578-EFF-DT
029059*        END-IF
029059*        PERFORM
029059*            VARYING I FROM 1 BY 1
029059*            UNTIL   I > RPOL-POL-CVG-REC-CTR-N
029059*               SET L0578-CVG-CHNG-OCCURRED (I)   TO TRUE
029059*        END-PERFORM
029059*        PERFORM  0578-1000-CALC-TEST-GDLN
029059*            THRU 0578-1000-CALC-TEST-GDLN-X
029059*    END-IF.
029059
029059     PERFORM  5382-0500-BUILD-PARM-INFO
029059         THRU 5382-0500-BUILD-PARM-INFO-X.
029059
029059     IF  RPOL-POL-SUSPENDED
029059         PERFORM  2470-1000-BUILD-PARM-INFO
029059             THRU 2470-1000-BUILD-PARM-INFO-X
029059         PERFORM  2470-1000-READ-SUSPEND
029059             THRU 2470-1000-READ-SUSPEND-X
029059         IF NOT L2470-RETRN-OK
029059*MSG 'POLICY OUT OF SYNC WITH SPND FOR @1 IN @2'
029059             MOVE RPOL-KEY            TO WGLOB-MSG-PARM (1)
029059             MOVE WGLOB-CRNT-PGM-ID   TO WGLOB-MSG-PARM (2)
029059             MOVE 'XS00000229'        TO WGLOB-MSG-REF-INFO
029059             PERFORM  0260-1000-GENERATE-MESSAGE
029059                 THRU 0260-1000-GENERATE-MESSAGE-X
029059             IF  WGLOB-MSG-SEVRTY-FATAL
029059                 GO TO 2000-UPDATE-X
029059             END-IF
029059         ELSE
029059             MOVE WWKDT-ZERO-DT       TO  L2470-SPND-POL-EFF-DT
029059         END-IF
029059     END-IF.
029059
029059     PERFORM  5382-1000-BUILD-PARM-INFO
029059         THRU 5382-1000-BUILD-PARM-INFO-X.
029059
029059     IF  RPOL-POL-ISS-EFF-DT = WWKDT-ZERO-DT
029059     OR  RPOL-POL-ISS-EFF-DT = SPACES
029059         MOVE WGLOB-PROCESS-DATE      TO L5382-EFF-DT
029059     ELSE
029059         MOVE RPOL-POL-ISS-EFF-DT     TO L5382-EFF-DT
029059     END-IF.
029059
029059     SET  WS-CVG-ERROR-NO             TO TRUE.
029059
029059     PERFORM
029059         VARYING I FROM 1 BY 1
029059         UNTIL   I > RPOL-POL-CVG-REC-CTR-N
029059
029059         SET L5382-CVG-CHNG-OCCURRED (I)
029059                                      TO TRUE
029059         IF  WCVGS-CVG-ERROR-EXIST (I)
029059             SET WS-CVG-ERROR-EXIST   TO TRUE
029059         END-IF
029059
029059     END-PERFORM.
029059
029059     MOVE L2470-SPND-POL-EFF-DT       TO L5382-SPND-POL-EFF-DT.
029059     MOVE L2470-SPND-POL-REDT-IND     TO L5382-SPND-POL-REDT-IND.
029059
029059     PERFORM  5382-4105-CALC-TST-GDLN-CVAT
029059         THRU 5382-4105-CALC-TST-GDLN-CVAT-X.
029059
029059     IF  L5382-RETRN-OK
029059     AND WS-CVG-ERROR-NO
029059         IF  L5382-PREM-TEST-FAILED
029059         AND RPOL-POL-STAT-PENDING
029059         AND RPOL-POL-ERROR-CORRECTED
029059             SET RPOL-POL-ERROR-EXIST TO TRUE
029059         END-IF
029059         IF  L5382-PREM-TEST-FAILED
029059         AND RPOL-POL-STAT-COMPLETE
029059             SET RPOL-POL-STAT-PENDING
029059                                      TO TRUE
029059             SET RPOL-POL-ERROR-EXIST
029059                                      TO TRUE
029059             SET RPOL-POL-REQIR-OS    TO TRUE
029059             SET RPOL-POL-UWG-INCOMPLETE
029059                                      TO TRUE
029059         END-IF
029059         IF  RPOL-POL-STAT-PENDING
029059         OR  RPOL-POL-STAT-COMPLETE
029059             PERFORM  5950-1000-BUILD-PARM-INFO
029059                 THRU 5950-1000-BUILD-PARM-INFO-X
029059             PERFORM  5950-1000-ANALYZE-POL
029059                 THRU 5950-1000-ANALYZE-POL-X
029059         END-IF       
029059     END-IF.

           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

016503* UPDATE NEXT ACTIVITY INFORMATION
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF L0289-RETRN-OK
016503        MOVE L0289-NXT-ACTV-TYP-CD
016503                    TO RPOL-NXT-ACTV-TYP-CD
016503        MOVE L0289-NXT-ACTV-DT
016503                    TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503        MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503        MOVE WGLOB-PROCESS-DATE
016503                    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.
      *
      *--------------
       3000-EDIT-CVG.
      *--------------
      *
      *  EDIT THE DATA ENTERED FOR THE RECORD AND AUDIT CHANGES
      *
           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.
      *
       3000-EDIT-CVG-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-POL-ID             TO WPOL-POL-ID.

       7000-BUILD-KEYS-X.
           EXIT.


      /
      *--------------------
       8000-EDITS.
      *--------------------

           PERFORM  0570-1000-BUILD-PARM-INFO
               THRU 0570-1000-BUILD-PARM-INFO-X.

           MOVE WS-SUB      TO L0570-CVG-NUM.
           MOVE MIR-CLI-ID  TO L0570-CLI-ID (1).

           SET L0570-BYPASS-CROSS-EDITS  TO TRUE.

           PERFORM  0570-1000-MAINTAIN-COVERAGE
               THRU 0570-1000-MAINTAIN-COVERAGE-X.

       8000-EDITS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY       TO TRUE.
           MOVE MIR-POL-ID             TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  CVG-1000-CALL-AUDIT
                   THRU CVG-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0570-0000-INIT-PARM-INFO
025970         THRU 0570-0000-INIT-PARM-INFO-X.
025970
029059*    PERFORM  0578-0000-INIT-PARM-INFO
029059*        THRU 0578-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
029059
029059     PERFORM  0182-0000-INIT-PARM-INFO
029059         THRU 0182-0000-INIT-PARM-INFO-X.
029059
029059     PERFORM  2470-0000-INIT-PARM-INFO
029059         THRU 2470-0000-INIT-PARM-INFO-X.
029059
029059     PERFORM  5382-0000-INIT-PARM-INFO
029059         THRU 5382-0000-INIT-PARM-INFO-X.
029059
029059     PERFORM  5950-0000-INIT-PARM-INFO
029059         THRU 5950-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.
025970
025970     MOVE SPACES                  TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      *
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
       COPY NCPPCVGR.
       COPY NCPPCVGS.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
016537*COPY XCPL0290.
016537*COPY XCPS0290.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
021930*COPY XCPS8090.
018764*COPY CCCL0570.
018764 COPY CCPL0570.
025970 COPY XCPS8090.
       COPY CCPS0570.
018764*COPY CCCL0578.
029059*COPY CCPL0578.
029059*COPY CCPS0578.
018764*COPY CCCL2435.
018764 COPY CCPL2435.
       COPY CCPS2435.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440 COPY CCPS5400.
025970 COPY CCPS0620.
       COPY CCPL0620.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS0289.
018764*COPY CCCLCVG.
018764 COPY CCPLCVG.
       COPY CCPSPGA.
029059 COPY CCPL5382.
029059 COPY CCPS5382.
029059 COPY CCPS2470.
029059 COPY CCPL2470.
029059 COPY CCPL5950.
029059 COPY CCPS5950.
029059 COPY CCPL0182.
029059 COPY CCPS0182.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
014221 COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPUCVG.
       COPY CCPNCVG.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM8026                     **
      *****************************************************************
