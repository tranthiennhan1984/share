      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8003.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8003                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE POLICY DELETE FUNCTION  **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       INITIALIZE - NEW FOR RELEASE 6.0                 **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018633**  6.4       TWRK CLEANUP                                     **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   ** 
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8003'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
028298 COPY CCWL2626.
       COPY XCWL8090.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-DELETE                   VALUE '8003'.

018633*01  WS-TWRK-KEY                     PIC X(04)  VALUE '8000'.
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '8000'.
018633     15  FILLER                       PIC X(01).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY XCWEBLCH.
016537*COPY CCWWFRMT.
016537*COPY XCWWWKDT.
016108 COPY CCWWINDX.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
016108 COPY CCFRCVG.
016108 COPY CCFWCVG.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
021930*COPY XCWLDTLK.
016537*COPY XCWL0280.
016537*COPY XCWL1640.
016537*COPY CCWL0620.
016108 COPY CCWL0985.
016440 COPY CCWL5400.
       COPY CCWL6050.
       COPY CCWL8240.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
       COPY CCWLPGA.
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8003.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  2000-PROCESS-TRANSACTIONS
               THRU 2000-PROCESS-TRANSACTIONS-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------------
       2000-PROCESS-TRANSACTIONS.
      *--------------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  3000-DELETE
                        THRU 3000-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8003'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'      TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-TRANSACTIONS-X.
           EXIT.

      /
      *--------------
       3000-DELETE.
      *--------------
      *
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.
      *
      *  THE RECORD MUST EXIST ON A DELETE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
               MOVE WPOL-KEY                   TO WGLOB-MSG-PARM (1)
               MOVE 'TPOL'                     TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 3000-DELETE-X
           END-IF.
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016108         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
016108
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WGLOB-PROCESS-DATE    TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         GO TO 3000-DELETE-X
016108     END-IF.

016440* PEFORM POLICY TRANSFER EDIT FOR UPDATE
016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440        THRU  5400-1000-BUILD-PARM-INFO-X.
016440
016440     SET L5400-POL-XFER-UPDATE   TO TRUE.
016440
016440     PERFORM  5400-1000-POL-CHK
016440        THRU  5400-1000-POL-CHK-X.
016440
016440     IF  L5400-XFER-ACCS-RESTRICTED
016440     OR  NOT L5400-RETRN-OK
016440         GO TO 3000-DELETE-X
016440     END-IF.

           PERFORM  8240-1000-BUILD-PARM-INFO
               THRU 8240-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID           TO L8240-POL-ID.
           PERFORM  8240-1000-RETRIEVE-POLW
               THRU 8240-1000-RETRIEVE-POLW-X.

016440*    IF  RPOL-POL-SUSPENDED
016440*    AND RPOL-POL-APPL-CTL-ADMIN
016440*MSG:    POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
016440*        MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        IF  WGLOB-MSG-SEVRTY-FATAL
016440*            GO TO 3000-DELETE-X
016440*        END-IF
016440*    END-IF.

014221* CHECK IF TIMESTAMP IS CURRENT
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3000-DELETE-X
014221     END-IF.

014221* CLOSE CURSOR
014221     PERFORM POL-3000-UNLOCK
014221        THRU POL-3000-UNLOCK-X.

      *  CALL CSLF6050 TO PERFORM DELETE EDITS, DELETE THE POLICY
      *  AND ALL THE RELATED TABLES

           PERFORM 6050-1000-INIT-PARM-INFO
              THRU 6050-1000-INIT-PARM-INFO-X.

           PERFORM 6050-2000-PRCES-DEL-POL
              THRU 6050-2000-PRCES-DEL-POL-X.


      *
      *   AUDIT THE CHANGE
      *

           IF L6050-RETRN-OK
              PERFORM  9350-SETUP-AUDIT-INFO
                  THRU 9350-SETUP-AUDIT-INFO-X
           END-IF.

       3000-DELETE-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE MIR-POL-ID    TO WPOL-POL-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

      *
      * FOR POLICY RELATED TRANSACTION
      *

           SET  WGLOB-REF-POLICY
             TO TRUE.
           MOVE MIR-POL-ID
             TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               MOVE MIR-POL-ID                 TO RPOL-POL-ID
               MOVE MIR-POL-ID                 TO WPOL-POL-ID
               SET WPOL-RQST-DELETE            TO TRUE
               PERFORM  POL-1000-CALL-AUDIT
                   THRU POL-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6050-0000-INIT-PARM-INFO
025970         THRU 6050-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8240-0000-INIT-PARM-INFO
025970         THRU 8240-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
018633*--------------------
018633*9500-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*    MOVE WS-TWRK-KEY               TO  L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                     TO  L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM          TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9900-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
016108 COPY NCPPCVGS.
016108/
       COPY XCPPINIT.
       COPY XCPPEXIT.
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
       COPY CCPSPGA.
016108 COPY CCPS0985.
       COPY CCPS6050.
       COPY CCPS8240.
018764*COPY XCCL8090.
018633 COPY XCPS8090.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL8090.
      /
018764*COPY CCCLPOL.
018764 COPY CCPLPOL.
016537*COPY CCPL0620.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440 COPY CCPS5400.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
018764*COPY CCCL6050.
018764 COPY CCPL6050.
018764*COPY CCCL8240.
018764 COPY CCPL8240.
016537*COPY XCPL0280.
016537*COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
       COPY CCPNPOL.
014221 COPY CCPUPOL.
      /
016108 COPY CCPNCVG.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM8003                     **
      *****************************************************************
