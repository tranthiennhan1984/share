      *****************************************************************
      **  MEMBER :  NSOM1380                                         **
      **  REMARKS:  LABR - CLIENT MEDICAL TEST RESULTS               **
      **            THIS PROGRAM WILL ALLOW THE USER TO BROWSE,      **
      **            INQUIRE, MAINTAIN OR DELETE A CLIENT'S MEDICAL   **
      **            TEST RESULTS.  THE BROWSE FUNCTION IS PROCESSED  **
      **            IN REVERSE CHRONOLOGICAL ORDER.  VARIOUS MODULES **
      **            ARE INVOKED TO PERFORM  DATA FIELD EDITS AND TO  **
      **            FORMAT INFORMATION FOR DISPLAY.                  **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
556122**  5.5       FIX FOR AS400                                    **
557660**  5.5       CODE CLEANUP                                     **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       ABEND HANDLING                                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       MODIFICATIONS FOR LEAP YEAR                      **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEAN UP                                    **
010418**  5.6       SET UP SUBSIDIARY COMPANY ID                     **
014389**  5.6A      FIX LABR ABEND 583                               **
012624**  6.0       GLOBAL SECURITY CHANGES                          **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
015543**  6.0       CODE CLEANUP AND STANDARDIZATION                 **
016475**  6.1       REMOVE 9900-DELETE-TWRK LOGIC                    **
014221**  6.2       LOGICAL LOCKING                                  **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
018645**  6.4       REDEFINE LAB RESULTS                             **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
028805**  7.0       CLEAN UP REMOVED BUSINESS FUNCTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM1380.

       COPY XCWWCRHT.
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM1380'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014221 COPY CCWWLOCK.

014590*COPY XCWL0030.
028298 COPY CCWL2626.
013578 COPY XCWL8090.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'LABR'.
013578     05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
013578         88  VALID-BUS-FCN-ID         VALUE '1550' '1551' '1552'
028805                                            '1553' '1554'.
028805*                                           '1553' '1554' '1555'.
013578         88  WS-BUS-FCN-RETRIEVE      VALUE '1550'.
013578         88  WS-BUS-FCN-CREATE        VALUE '1551'.
013578         88  WS-BUS-FCN-UPDATE        VALUE '1552'.
013578         88  WS-BUS-FCN-DELETE        VALUE '1553'.
013578         88  WS-BUS-FCN-LIST          VALUE '1554'.
028805*        88  WS-BUS-FCN-DOC           VALUE '1555'.
018633*01  WS-TWRK-KEY                      PIC X(04)  VALUE '1550'.
018633*01  WS-WORK-AREA.
018633*    05  WS-WORK-CLIENT-NUMBER        PIC X(10).
018633*    05  WS-WORK-SPECIFIC-AREA.
018633*        10  WS-WORK-CURR-SEQUENCE-NO PIC X(03).
018633*        10  WS-WORK-CURR-SEQUENCE-NO-N REDEFINES
018633*            WS-WORK-CURR-SEQUENCE-NO PIC 9(03).
018633*        10  FILLER                   PIC X(287).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '1550'.
018633     15  LCOMM-CLIENT-NUMBER          PIC X(10).
018633     15  LCOMM-SPECIFIC-AREA.
018633         20  LCOMM-CURR-SEQUENCE-NO PIC X(03).
018633         20  LCOMM-CURR-SEQUENCE-NO-N REDEFINES
018633             LCOMM-CURR-SEQUENCE-NO PIC 9(03).
018633
013578 01  WS-SWITCHES.
           05  WS-INPUT-VALID-SW            PIC X(1)   VALUE SPACES.
               88  WS-VALID-INPUT           VALUE 'Y'.
               88  WS-INVALID-INPUT         VALUE 'N'.
           05  WS-VALID-CROSS-EDITS-SW      PIC X(1)   VALUE SPACES.
               88  WS-VALID-CROSS-EDITS     VALUE 'Y'.
           05  WS-BROWSE-SW                 PIC X(1)   VALUE SPACES.
               88  WS-BROWSE-OK             VALUE 'Y'.
           05  WS-CHG-DIRECTION-SW          PIC X(1)   VALUE SPACES.
               88  WS-CHG-DIRECTION         VALUE 'Y'.
           05  WS-EOF-LABR-SW               PIC X(1)   VALUE SPACES.
               88  WS-EOF-LABR              VALUE 'Y'.
           05  WS-SCREEN-DETAIL-SW          PIC X(1)   VALUE SPACES.
               88  WS-SCREEN-DETAIL         VALUE 'Y'.
           05  WS-SAME-DISPLAY-SW           PIC X(1)   VALUE SPACES.
               88  WS-SAME-DISPLAY          VALUE 'Y'.
           05  WS-CURSOR-POS-SW             PIC X(1)   VALUE SPACES.
               88  WS-CURSOR-POS            VALUE 'Y'.
           05  WS-REMARKS-BLANKED-SW        PIC X(1)   VALUE SPACES.
               88  WS-REMARKS-BLANKED       VALUE 'Y'.
           05  WS-RSN-REQUIRED-SW           PIC X(1)   VALUE SPACES.
               88  WS-RSN-REQUIRED          VALUE 'Y'.
           05  WS-LABT-REC-FND-SW           PIC X(1)   VALUE SPACES.
               88  WS-LABT-REC-FND          VALUE 'Y'.
               88  WS-LABT-REC-NOT-FND      VALUE 'N'.
           05  WS-LABT-BROWSED-SW           PIC X(1)   VALUE SPACES.
               88  WS-LABT-BROWSED          VALUE 'Y'.
               88  WS-LABT-NOT-BROWSED      VALUE 'N'.
           05  WS-LABR-RSLT-FND-SW          PIC X(1)   VALUE SPACES.
               88  WS-LABR-RSLT-FND         VALUE 'Y'.
016548*    05  WS-MAX-SCREEN-LINES          PIC S9(4)  COMP
025970*    05  WS-MAX-SCREEN-LINES          PIC S9(4)  BINARY
025970*                                                VALUE +11.
016548*    05  WS-TEMP                      PIC S9(4)  COMP.
016548     05  WS-TEMP                      PIC S9(4)  BINARY.
016548*    05  WS-LINE                      PIC S9(4)  COMP.
016548     05  WS-LINE                      PIC S9(4)  BINARY.
016548*    05  WS-DEST                      PIC S9(4)  COMP.
016548     05  WS-DEST                      PIC S9(4)  BINARY.
016548*    05  WS-START                     PIC S9(4)  COMP.
016548     05  WS-START                     PIC S9(4)  BINARY.
016548*    05  WS-SUB                       PIC S9(4)  COMP.
016548     05  WS-SUB                       PIC S9(4)  BINARY.
           05  WS-HOLD-TEST-DATE            PIC X(10).
           05  WS-EDIT-TIME                 PIC X(04).
           05  WS-EDIT-TIME-N               PIC 9(04).
           05  WS-EDIT-TIME-N-R             REDEFINES
               WS-EDIT-TIME-N.
               10  WS-EDIT-HOUR             PIC 9(02).
               10  WS-EDIT-MINUTE           PIC 9(02).
           05  WS-PIC-LEN4                  PIC 9(04)  VALUE ZEROS.
           05  WS-PIC-LEN3                  PIC 9(03)  VALUE ZEROS.
           05  WS-HOLD-MSGS-KEY.
               10  WS-HOLD-MSGS-COMPANY     PIC X(02).
               10  WS-HOLD-SOURCE           PIC X(06).
               10  WS-HOLD-NUMBER           PIC X(04).
023447*        10  WS-HOLD-MSGS-LANG-CD     PIC X(01).
               10  WS-HOLD-MSGS-SECUR-CLAS-CD
                                            PIC X(01).
           05  WS-SEX-CODE                  PIC X(01).
           05  WS-PIC-RESULT                PIC 9(08).
           05  WS-DISPLAY-RESULT            PIC 9(08).
           05  WS-DISPLAY-RESULT-R REDEFINES
               WS-DISPLAY-RESULT            PIC X(08).
           05  WS-OLD-LAB-RESULT            PIC X(08).
018645     05  WS-OLD-LAB-QTY-TXT-RESULT    PIC X(08).
           05  WS-OLD-LAB-CODE              PIC X(03).
           05  WS-OLD-BAD-DATA-IND          PIC X(01).
           05  WS-OLD-REMARK-ID             PIC X(04).
           05  WS-OLD-STATUS                PIC X(01).
018645*    05  WS-OLD-PRECISION             PIC X(01).
018645     05  WS-OLD-PRECISION             PIC 9(01).
018645     05  WS-OLD-TST-RSLT-TYP-CD       PIC X(01).
           05  WS-SEQNO                     PIC 999.

      *  ONE FIELD REQUIRED BY CCPSPGA IS HARDCODED SO THAT
      *  THE POLICY TABLE DOES NOT NEED TO BE INCLUDED
           05  RPOL-POL-ID                  PIC X(10)  VALUE SPACES.
010311*    05  RPOL-POL-BASE-CVG-NUM        PIC 9(02)  VALUE ZERO.
010311*    05  HOLD-RUN-ID                  PIC X(01)  VALUE '0'.
      *
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'LABR'.
025970     05  WS-MAX-SCREEN-LINES          PIC S9(4)  BINARY.
025970         88  WS-DEFAULT-MAX-SCREEN-LINES         VALUE +11.
      *
       COPY XCWWWKDT.
      *
       COPY XCWEBLCH.
      *
       COPY NCWWSTAT.
      *
      ***  FILE AREA
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
023447*COPY NCFWDOCM.
023447*COPY NCFRDOCM.
023447 COPY XCFWDOCM.
023447 COPY XCFRDOCM.
      *
       COPY NCFWLABR.
       COPY NCFRLABR.
      *
       COPY NCFWLABT.
       COPY NCFRLABT.
      *
010418 COPY CCFWSCOM.
010418 COPY CCFRSCOM.
      *
      ***  PARAMETER AREA
      *
       COPY CCWL0620.
      *
010418 COPY CCWL3320.
      *
       COPY CCWL5600.
      *
       COPY NCWL0303.
      *
       COPY NCWL0760.
      *
       COPY NCWL1030.
      *
       COPY NCWL2437.
      *
       COPY NCWL7180.
      *
       COPY XCWL0280.
      *
       COPY XCWL0290.
      *
       COPY XCWL1640.
      *
       COPY XCWL1670.
      *
       COPY XCWL1680.
      *
       COPY XCWLDTLK.
      *
      ***  COMM AREA
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM1380.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023118
023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   NORMAL PROCESSING:
      *   DISTRIBUTE CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      *----------------------------------------------------------------
       2000-PROCESS-REQUEST.

023118*    MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.
018633*    MOVE SPACES         TO WS-WORK-AREA.
      *
      ***  INITIALIZE VARIABLES NEEDED FOR THIS TRANSACTION
      *
025970     PERFORM  0290-1000-BUILD-PARM-INFO
025970         THRU 0290-1000-BUILD-PARM-INFO-X.
025970
025970     PERFORM  2050-INITIALIZE
025970         THRU 2050-INITIALIZE-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           IF  WS-BUS-FCN-CREATE
               PERFORM  4000-CREATE
                   THRU 4000-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           PERFORM  2100-VALIDATE-CONTROL-FIELD
               THRU 2100-VALIDATE-CONTROL-FIELD-X.
           IF  WS-INVALID-INPUT
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           EVALUATE TRUE
013578         WHEN WS-BUS-FCN-RETRIEVE
013578             PERFORM  3000-PROCESS-RETRIEVE
013578                 THRU 3000-PROCESS-RETRIEVE-X
013578         WHEN WS-BUS-FCN-UPDATE
013578             PERFORM  5200-PROCESS-UPDATE
013578                 THRU 5200-PROCESS-UPDATE-X
013578         WHEN WS-BUS-FCN-DELETE
013578             PERFORM  6200-PROCESS-DELETE
013578                 THRU 6200-PROCESS-DELETE-X
013578         WHEN WS-BUS-FCN-LIST
013578             PERFORM  3500-PROCESS-LIST
013578                 THRU 3500-PROCESS-LIST-X
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   INITIALIZE: INITIALIZE MISCELLANEOUS VARIABLES NEEDED FOR
      *   PROCESSING IN THIS TRANSACTION.
      *----------------------------------------------------------------
       2050-INITIALIZE.
      *
      ***  INITIALIZE WORK VARIABLES
      *
           MOVE '0'                   TO WGLOB-RETURN-CODE.
           MOVE 'N'                   TO WS-SAME-DISPLAY-SW.
      *
      ***  SET UP MESSAGE VARIABLES
      *
      *-----------------------------------------------------------------
      *    SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS
      *    WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *-----------------------------------------------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID            TO WGLOB-REF-CLIENT-NUMBER.

       2050-INITIALIZE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *  VALIDATE CONTROL FIELDS: EDIT DATE TO
      *  ENSURE IT IS IN VALID FORMAT
      *----------------------------------------------------------------
       2100-VALIDATE-CONTROL-FIELD.

           MOVE 'Y'                   TO WS-INPUT-VALID-SW.

           PERFORM  4110-EDIT-CLIENT
               THRU 4110-EDIT-CLIENT-X.

           IF  MIR-CLI-LTST-DT           NOT =  SPACES
               PERFORM  4120-EDIT-TEST-DATE
                   THRU 4120-EDIT-TEST-DATE-X
557660     END-IF.

           IF  MIR-CLI-LTST-SEQ-NUM           NOT =  SPACES
               PERFORM  2200-EDIT-SEQUENCE-NUMBER
                   THRU 2200-EDIT-SEQUENCE-NUMBER-X
557660     END-IF.

       2100-VALIDATE-CONTROL-FIELD-X.
           EXIT.
      *
       2200-EDIT-SEQUENCE-NUMBER.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-LTST-SEQ-NUM  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      * MSG -  'SEQUENCE NUMBER MUST BE VALID NUMERIC'
               MOVE 'NS13800035'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
020874*        MOVE L0280-OUTPUT      TO WS-SEQNO
020874*        MOVE WS-SEQNO          TO MIR-CLI-LTST-SEQ-NUM
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-LTST-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-LTST-SEQ-NUM
           END-IF.

       2200-EDIT-SEQUENCE-NUMBER-X.
           EXIT.
      *
       3000-PROCESS-RETRIEVE.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.

           IF  MIR-DOC-ID         NOT =  SPACES
               PERFORM  7000-PROCESS-DOCUMENT
                   THRU 7000-PROCESS-DOCUMENT-X
               IF  WGLOB-MSG-ERROR-SW NOT =  ZERO
                   GO TO 3000-PROCESS-RETRIEVE-X
               END-IF
           END-IF.

           PERFORM  9230-LOAD-INSURED-DATA
               THRU 9230-LOAD-INSURED-DATA-X.

           PERFORM  8000-BUILD-LABR-KEY
               THRU 8000-BUILD-LABR-KEY-X.

014221*    PERFORM  LABR-1000-READ
014221*        THRU LABR-1000-READ-X.

014221     PERFORM  LABR-1000-READ-TWRK-TS
014221         THRU LABR-1000-READ-TWRK-TS-X.

           IF NOT WLABR-IO-OK
      * MSG: 'RECORD (@1) NOT FOUND '
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
005409*        MOVE MIR-CLI-LTST-DT           TO WLABR-CLI-LTST-DT
014389*        MOVE MIR-CLI-LTST-DT           TO L1680-INTERNAL-1
014389         MOVE WLABR-CLI-LTST-DT TO L1680-INTERNAL-1
005409         MOVE ZERO              TO L1680-NUMBER-OF-YEARS
005409         MOVE ZERO              TO L1680-NUMBER-OF-MONTHS
005409         MOVE ZERO              TO L1680-NUMBER-OF-DAYS
005409         PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409             THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
005409         MOVE L1680-INTERNAL-2  TO WLABR-CLI-LTST-DT
               MOVE WLABR-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           ELSE
010311         PERFORM  9100-BLANK-DATA-FIELDS
010311             THRU 9100-BLANK-DATA-FIELDS-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
      * MSG: 'INQUIRE COMPLETED - CONTINUE'
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

018633*    MOVE MIR-CLI-ID           TO WS-WORK-CLIENT-NUMBER.
018633*    MOVE MIR-CLI-LTST-SEQ-NUM TO WS-WORK-CURR-SEQUENCE-NO.
018633*    MOVE WS-WORK-AREA         TO L8090-AREA-INFO-TEXT.
018633     MOVE MIR-CLI-ID           TO LCOMM-CLIENT-NUMBER.
018633     MOVE MIR-CLI-LTST-SEQ-NUM TO LCOMM-CURR-SEQUENCE-NO.

018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    BROWSE PROCESSING:
      *        ONE DIRECTION ONLY - REVERSE CHRONOLOGICAL ORDER
      *
      *----------------------------------------------------------------
       3500-PROCESS-LIST.
      *
016475*    PERFORM  9900-DELETE-TWRK
016475*        THRU 9900-DELETE-TWRK-X.

           IF  MIR-DOC-ID         NOT =  SPACES
               PERFORM  7000-PROCESS-DOCUMENT
                   THRU 7000-PROCESS-DOCUMENT-X
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW > 0
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           PERFORM  9230-LOAD-INSURED-DATA
               THRU 9230-LOAD-INSURED-DATA-X.

           MOVE SPACES                TO MIR-ETBL-DESC-TXT-G.
           MOVE SPACES                TO MIR-CLI-LTST-DT-G.
           MOVE SPACES                TO MIR-LTST-ID-G.
           MOVE SPACES                TO MIR-CLI-LTST-SEQ-NUM-G.
           MOVE SPACES                TO MIR-CLI-LTST-RSLT-CD-G.
018645     MOVE SPACES                TO MIR-RSLT-QTY-TXT-G.
018645     MOVE SPACES                TO MIR-TST-RSLT-TYP-CD-G.
           MOVE SPACES                TO MIR-CLI-LTST-STAT-CD-G.
           MOVE SPACES                TO MIR-STAT-CHNG-REASN-CD-G.
           MOVE SPACES                TO MIR-CO-MIN-NRNG-QTY-G.
           MOVE SPACES                TO MIR-CO-MAX-NRNG-QTY-G.
           MOVE SPACES                TO MIR-ALPHA-RESP-CD-G.
           MOVE SPACES                TO MIR-RSLT-REC-CREAT-CD-G.
           MOVE HIGH-VALUES           TO WLABR-KEY.
           MOVE MIR-CLI-ID            TO WLABR-CLI-ID.
           MOVE MIR-CLI-LTST-DT       TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE WWKDT-HIGH-DT     TO L1640-INTERNAL-DATE
557660     END-IF.
           MOVE L1640-INTERNAL-DATE   TO WLABR-CLI-LTST-DT.
           MOVE MIR-LTST-ID           TO WLABR-LTST-ID.
           MOVE MIR-CLI-LTST-SEQ-NUM  TO WLABR-CLI-LTST-SEQ-NUM.
           MOVE WLABR-KEY             TO WLABR-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WLABR-ENDBR-CLI-LTST-DT.
           MOVE LOW-VALUES            TO WLABR-ENDBR-LTST-ID.
           MOVE LOW-VALUES            TO WLABR-ENDBR-CLI-LTST-SEQ-NUM.

           PERFORM  LABR-1000-BROWSE-PREV
               THRU LABR-1000-BROWSE-PREV-X.

           IF WLABR-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           ELSE
               PERFORM  LABR-2000-READ-PREV
                   THRU LABR-2000-READ-PREV-X
               IF WLABR-IO-EOF
                   PERFORM  LABR-3000-END-BROWSE-PREV
                       THRU LABR-3000-END-BROWSE-PREV-X
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3500-PROCESS-LIST-X
557660         END-IF
557660     END-IF.

           PERFORM  3510-PROCESS-LIST-READ
               THRU 3510-PROCESS-LIST-READ-X
               VARYING WS-LINE FROM +1 BY 1
               UNTIL WS-LINE > WS-MAX-SCREEN-LINES
               OR WLABR-IO-EOF.

           IF WLABR-IO-EOF
               MOVE MIR-CLI-LTST-DT-T (1)
                                      TO MIR-CLI-LTST-DT
               MOVE MIR-LTST-ID-T (1) TO MIR-LTST-ID
               MOVE MIR-CLI-LTST-SEQ-NUM-T (1)
                                      TO MIR-CLI-LTST-SEQ-NUM
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RLABR-CLI-LTST-DT TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CLI-LTST-DT
               MOVE RLABR-LTST-ID     TO MIR-LTST-ID
               MOVE RLABR-CLI-LTST-SEQ-NUM
                                      TO MIR-CLI-LTST-SEQ-NUM
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  LABR-3000-END-BROWSE-PREV
               THRU LABR-3000-END-BROWSE-PREV-X.

       3500-PROCESS-LIST-X.
           EXIT.
      *
       3510-PROCESS-LIST-READ.

           PERFORM  9212-GET-TEST-DESCRIPTION
               THRU 9212-GET-TEST-DESCRIPTION-X.

           IF  WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-LTST-ID-T (WS-LINE)
557660     END-IF.
           MOVE RLABR-CLI-LTST-DT     TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-LTST-DT-T (WS-LINE).
           MOVE RLABR-LTST-ID         TO MIR-LTST-ID-T (WS-LINE).
           MOVE RLABR-CLI-LTST-SEQ-NUM
                                    TO MIR-CLI-LTST-SEQ-NUM-T (WS-LINE).
           PERFORM  5500-FORMAT-RESULT
               THRU 5500-FORMAT-RESULT-X.
018645*    MOVE WS-DISPLAY-RESULT-R TO MIR-CLI-LTST-RSLT-CD-T (WS-LINE).
018645     IF  RLABR-TST-RSLT-TYP-CD = '2'
018645         MOVE WS-DISPLAY-RESULT-R TO MIR-RSLT-QTY-TXT-T (WS-LINE)
018645         MOVE SPACE               TO MIR-CLI-LTST-RSLT-CD-T
018645                                                        (WS-LINE)
018645     ELSE
018645         MOVE WS-DISPLAY-RESULT-R TO MIR-CLI-LTST-RSLT-CD-T
018645                                                        (WS-LINE)
018645         MOVE SPACE               TO MIR-RSLT-QTY-TXT-T (WS-LINE)
018645     END-IF.

           MOVE RLABR-CLI-LTST-STAT-CD
                                    TO MIR-CLI-LTST-STAT-CD-T (WS-LINE).
           MOVE RLABR-STAT-CHNG-REASN-CD
                                  TO MIR-STAT-CHNG-REASN-CD-T (WS-LINE).
018645     MOVE RLABR-TST-RSLT-TYP-CD   TO MIR-TST-RSLT-TYP-CD-T
018645                                                        (WS-LINE).

018645*    IF  RLABR-RSLT-PRECSN-QTY = SPACES
018645*    OR  RLABR-RSLT-PRECSN-ALPHA-VALUE
018645     IF  RLABR-TST-RSLT-TYP-CD NOT = '2'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE RLABR-CO-MIN-NRNG-QTY
                                      TO L0290-INPUT-NUMBER
               MOVE 'N'               TO WS-LABT-BROWSED-SW
               PERFORM  8100-DISPLAY-RESULT
                   THRU 8100-DISPLAY-RESULT-X
               MOVE L0290-OUTPUT-DATA TO MIR-CO-MIN-NRNG-QTY-T (WS-LINE)
               MOVE RLABR-CO-MAX-NRNG-QTY
                                      TO L0290-INPUT-NUMBER
               PERFORM  8100-DISPLAY-RESULT
                   THRU 8100-DISPLAY-RESULT-X
               MOVE L0290-OUTPUT-DATA TO MIR-CO-MAX-NRNG-QTY-T (WS-LINE)
               MOVE RLABR-RSLT-REC-CREAT-CD
                                    TO MIR-RSLT-REC-CREAT-CD-T (WS-LINE)
               MOVE RLABR-ALPHA-RESP-CD
                                   TO MIR-ALPHA-RESP-CD-T (WS-LINE)
           END-IF.

           PERFORM  LABR-2000-READ-PREV
               THRU LABR-2000-READ-PREV-X.

       3510-PROCESS-LIST-READ-X.
           EXIT.
      *
      *----------------------------------------------------------------
      * CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, INIT NEW RECORD
      *    AND ALLOW USER TO MODIFY.
      *----------------------------------------------------------------
       4000-CREATE.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      *** CHECK CONTROL FIELDS.
           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.

           IF  WS-INVALID-INPUT
               GO TO 4000-CREATE-X
557660     END-IF.

           PERFORM  9230-LOAD-INSURED-DATA
               THRU 9230-LOAD-INSURED-DATA-X.

           IF  MIR-DOC-ID              NOT =  SPACES
               PERFORM  7000-PROCESS-DOCUMENT
                   THRU 7000-PROCESS-DOCUMENT-X
               IF  WGLOB-MSG-ERROR-SW NOT =  ZERO
                   GO TO 4000-CREATE-X
557660         END-IF
557660     END-IF.

           IF NOT L5600-CCAS-ACCS-ALLOW
               GO TO 4000-CREATE-X
           END-IF.

      *** GET NEXT SEQUENCE NUMBER
018633*    MOVE +1                    TO WS-WORK-CURR-SEQUENCE-NO-N.
018633     MOVE +1                    TO LCOMM-CURR-SEQUENCE-NO-N.

           PERFORM  8000-BUILD-LABR-KEY
               THRU 8000-BUILD-LABR-KEY-X.

           MOVE HIGH-VALUES           TO WLABR-CLI-LTST-SEQ-NUM.

           MOVE WLABR-KEY             TO WLABR-ENDBR-KEY.
           MOVE LOW-VALUES            TO WLABR-ENDBR-CLI-LTST-SEQ-NUM.

           PERFORM  LABR-1000-BROWSE-PREV
               THRU LABR-1000-BROWSE-PREV-X.

           MOVE 'N'                   TO WS-BROWSE-SW.
           IF  WLABR-IO-OK
               PERFORM  LABR-2000-READ-PREV
                   THRU LABR-2000-READ-PREV-X
               MOVE 'Y'               TO WS-BROWSE-SW
557660     END-IF.

           IF  WLABR-IO-OK
               IF  RLABR-CLI-LTST-SEQ-NUM-N = WLABR-MAX-SEQUENCE-NO
                   PERFORM  LABR-3000-END-BROWSE-PREV
                       THRU LABR-3000-END-BROWSE-PREV-X
                   MOVE 'NS13800002'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CLI-ID    TO WGLOB-MSG-PARM (1)
                   MOVE MIR-CLI-LTST-DT
                                      TO WGLOB-MSG-PARM (2)
                   MOVE MIR-LTST-ID   TO WGLOB-MSG-PARM (3)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 4000-CREATE-X
               ELSE
018633*            COMPUTE WS-WORK-CURR-SEQUENCE-NO-N =
018633             COMPUTE LCOMM-CURR-SEQUENCE-NO-N =
                                      RLABR-CLI-LTST-SEQ-NUM-N + 1
557660         END-IF
557660     END-IF.

           IF  WS-BROWSE-OK
               PERFORM  LABR-3000-END-BROWSE-PREV
                   THRU LABR-3000-END-BROWSE-PREV-X
557660     END-IF.

           PERFORM  8000-BUILD-LABR-KEY
               THRU 8000-BUILD-LABR-KEY-X.
           PERFORM  LABR-1000-CREATE
               THRU LABR-1000-CREATE-X.
      *
      *    CALCULATE THE LENGTH OF THE LABR FILE
      *    NOTE: WE DON'T KNOW THE LENGTH OF THE RECORD YET, SO MUST
      *    USE THE MAX LENGTH UNTIL THE MAINTAIN PART OF THE CREATE.
           PERFORM  LABR-1000-WRITE
               THRU LABR-1000-WRITE-X.

014221     PERFORM  LABR-1000-READ-TWRK-TS
014221         THRU LABR-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           SET WS-BUS-FCN-UPDATE TO TRUE.
           MOVE WS-BUS-FCN-ID    TO MIR-BUS-FCN-ID.

       4000-CREATE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT KEY FIELDS: CHECK VALIDITY OF ALL KEY FIELDS TO
      *    ENSURE THAT ALL NEW RECORDS ARE CREATED WITH VALID KEYS.
      *----------------------------------------------------------------
       4100-EDIT-KEY-FIELDS.

           MOVE 'Y'                   TO WS-INPUT-VALID-SW.

           PERFORM  4110-EDIT-CLIENT
               THRU 4110-EDIT-CLIENT-X.

           PERFORM  4120-EDIT-TEST-DATE
               THRU 4120-EDIT-TEST-DATE-X.

           PERFORM  4130-EDIT-TEST-NUMBER
               THRU 4130-EDIT-TEST-NUMBER-X.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT CLIENT NUMBER - MUST BE ON CLIENT FILE
      *----------------------------------------------------------------
       4110-EDIT-CLIENT.

      *** CHECK NAME AND ADDRESS FILE

           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L5600-CLI-ID.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           IF NOT L5600-RETRN-OK
           OR L5600-CNFD-ACCS-RESTRICTED
               MOVE SPACES            TO MIR-DV-INSRD-CLI-NM
               MOVE SPACES            TO MIR-CLI-SEX-CD
               MOVE SPACES            TO MIR-DV-CLI-INSRD-AGE
               MOVE 'N'               TO WS-INPUT-VALID-SW
           END-IF.

       4110-EDIT-CLIENT-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT TEST DATE - MUST BE A VALID DATE
      *----------------------------------------------------------------
       4120-EDIT-TEST-DATE.

           MOVE MIR-CLI-LTST-DT       TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               MOVE 'NS13800003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WS-HOLD-TEST-DATE
557660     END-IF.

       4120-EDIT-TEST-DATE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT LAB TEST NUMBER - MUST BE IN EDIT/TSTNO
      *----------------------------------------------------------------
       4130-EDIT-TEST-NUMBER.

           MOVE MIR-LTST-ID           TO WEDIT-ETBL-VALU-ID.

           PERFORM  TSTN-1000-EDIT-TEST-NUMBER
               THRU TSTN-1000-EDIT-TEST-NUMBER-X.

           IF  NOT WEDIT-IO-OK
               MOVE 'NS13800004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
557660     END-IF.

       4130-EDIT-TEST-NUMBER-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    MAINTAIN PROCESSING: FETCH AND LOCK RECORD, EDIT INCOMING
      *                         DATA FIELDS, AND UPDATE RECORD.
      *----------------------------------------------------------------
       5200-PROCESS-UPDATE.

018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.
013578
018633*    IF L8090-RETRN-OK
018633     IF LCOMM-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT     TO WS-WORK-AREA
018633*        MOVE WS-WORK-CLIENT-NUMBER    TO MIR-CLI-ID
018633*        MOVE WS-WORK-CURR-SEQUENCE-NO TO MIR-CLI-LTST-SEQ-NUM
018633         MOVE LCOMM-CLIENT-NUMBER      TO MIR-CLI-ID
018633         MOVE LCOMM-CURR-SEQUENCE-NO TO MIR-CLI-LTST-SEQ-NUM
013578     END-IF.
013578
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  9230-LOAD-INSURED-DATA
               THRU 9230-LOAD-INSURED-DATA-X.

           IF  MIR-DOC-ID            NOT =  SPACES
               PERFORM  7000-PROCESS-DOCUMENT
                   THRU 7000-PROCESS-DOCUMENT-X
               IF  WGLOB-MSG-ERROR-SW NOT = ZERO
                   GO TO 5200-PROCESS-UPDATE-X
557660         END-IF
557660     END-IF.

           PERFORM  8000-BUILD-LABR-KEY
               THRU 8000-BUILD-LABR-KEY-X.

014221*    PERFORM  LABR-1000-READ-FOR-UPDATE
014221*        THRU LABR-1000-READ-FOR-UPDATE-X.

014221     PERFORM  LABR-2000-UPDATE-TWRK-TS
014221         THRU LABR-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'        TO WGLOB-MSG-REF-INFO
014221         MOVE 'LABR'              TO WGLOB-MSG-PARM (01)
014221         MOVE WLABR-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  9100-BLANK-DATA-FIELDS
014221             THRU 9100-BLANK-DATA-FIELDS-X
014221           GO TO 5200-PROCESS-UPDATE-X
014221     END-IF.

           IF  NOT WLABR-IO-OK
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WLABR-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5200-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           PERFORM  LABR-2000-REWRITE
               THRU LABR-2000-REWRITE-X.

014221     PERFORM  LABR-1000-READ-TWRK-TS
014221         THRU LABR-1000-READ-TWRK-TS-X.

           PERFORM  5400-CROSS-EDITS
               THRU 5400-CROSS-EDITS-X.

      *** MOVE IN NON-MAINTAINABLE FIELD VALUES
           MOVE RLABR-RSLT-REC-CREAT-CD
                                      TO MIR-RSLT-REC-CREAT-CD.
           MOVE RLABR-LTST-ID         TO MIR-LTST-ID.
           PERFORM  9212-GET-TEST-DESCRIPTION
               THRU 9212-GET-TEST-DESCRIPTION-X.
           IF  WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-ETBL-DESC-TXT
557660     END-IF.

      *** MOVE TEST-RANGE VALUES TO SCREEN
           PERFORM  9221-LOAD-LAB-TEST-DATA
               THRU 9221-LOAD-LAB-TEST-DATA-X.

           IF  WS-VALID-INPUT
           AND WS-VALID-CROSS-EDITS
               SET WS-BUS-FCN-RETRIEVE TO TRUE
               MOVE WS-BUS-FCN-ID      TO MIR-BUS-FCN-ID
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

018633*    MOVE MIR-CLI-ID           TO WS-WORK-CLIENT-NUMBER.
018633*    MOVE MIR-CLI-LTST-SEQ-NUM TO WS-WORK-CURR-SEQUENCE-NO.
018633*    MOVE WS-WORK-AREA         TO L8090-AREA-INFO-TEXT.
018633     MOVE MIR-CLI-ID           TO LCOMM-CLIENT-NUMBER.
018633     MOVE MIR-CLI-LTST-SEQ-NUM TO LCOMM-CURR-SEQUENCE-NO.

018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.

       5200-PROCESS-UPDATE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    FIELD EDITS: CHECK VALIDITY OF ALL DATA FIELDS.
      *----------------------------------------------------------------
       5300-EDIT-DATA-FIELDS.

           MOVE RLABR-CLI-LTST-RSLT-CD             TO WS-OLD-LAB-RESULT.
018645     MOVE RLABR-RSLT-QTY-TXT    TO WS-OLD-LAB-QTY-TXT-RESULT.
           MOVE RLABR-CLI-LTST-LAB-ID TO WS-OLD-LAB-CODE.
           MOVE RLABR-RSLT-PRECSN-QTY TO WS-OLD-PRECISION.
           MOVE RLABR-BAD-LAB-INFO-IND           TO WS-OLD-BAD-DATA-IND.
           MOVE RLABR-LAB-RMRK-NUM    TO WS-OLD-REMARK-ID.
           MOVE RLABR-CLI-LTST-STAT-CD                 TO WS-OLD-STATUS.
018645     MOVE RLABR-TST-RSLT-TYP-CD TO WS-OLD-TST-RSLT-TYP-CD.

           MOVE 'Y'                   TO WS-RSN-REQUIRED-SW.
           MOVE 'Y'                   TO WS-INPUT-VALID-SW.

           PERFORM  5305-EDIT-LAB-CODE
               THRU 5305-EDIT-LAB-CODE-X.

           PERFORM  5310-EDIT-RESULT
               THRU 5310-EDIT-RESULT-X.

           PERFORM  5315-EDIT-DATE-LAST-MEAL
               THRU 5315-EDIT-DATE-LAST-MEAL-X.

           PERFORM  5320-EDIT-TIME-LAST-MEAL
               THRU 5320-EDIT-TIME-LAST-MEAL-X.

           PERFORM  5325-EDIT-SERUM-APPEARANCE
               THRU 5325-EDIT-SERUM-APPEARANCE-X.

           PERFORM  5330-EDIT-DATE-BLOOD-DRAWN
               THRU 5330-EDIT-DATE-BLOOD-DRAWN-X.

           PERFORM  5335-EDIT-TIME-BLOOD-DRAWN
               THRU 5335-EDIT-TIME-BLOOD-DRAWN-X.

           PERFORM  5340-EDIT-URINE-APPEARANCE
               THRU 5340-EDIT-URINE-APPEARANCE-X.

           PERFORM  5345-EDIT-DATE-VOIDED
               THRU 5345-EDIT-DATE-VOIDED-X.

           PERFORM  5350-EDIT-STATUS
               THRU 5350-EDIT-STATUS-X.

           PERFORM  5353-EDIT-STATUS-REASON
               THRU 5353-EDIT-STATUS-REASON-X.

           PERFORM  5355-EDIT-BAD-DATA-IND
               THRU 5355-EDIT-BAD-DATA-IND-X.

           PERFORM  5360-EDIT-REMARK-ID
               THRU 5360-EDIT-REMARK-ID-X.

           PERFORM  5365-EDIT-REMARKS
               THRU 5365-EDIT-REMARKS-X.

           PERFORM  5370-EDIT-REF-NUMBER
               THRU 5370-EDIT-REF-NUMBER-X.

      *** THE TEST STATUS MUST BE RE-ASSIGNED IF THE LAB RESULT,
      *** LAB CODE, BAD DATA INDICATOR OR REMARK ID WERE CHANGED BUT
      *** ONLY IF STATUS WAS NOT CHANGED BY THE USER.

           IF  RLABR-CLI-LTST-STAT-CD          =  WS-OLD-STATUS
               IF  RLABR-CLI-LTST-RSLT-CD  NOT =  WS-OLD-LAB-RESULT
018645         OR  RLABR-RSLT-QTY-TXT NOT =  WS-OLD-LAB-QTY-TXT-RESULT
               OR  RLABR-CLI-LTST-LAB-ID   NOT =  WS-OLD-LAB-CODE
               OR  RLABR-BAD-LAB-INFO-IND  NOT =  WS-OLD-BAD-DATA-IND
               OR  RLABR-LAB-RMRK-NUM      NOT =  WS-OLD-REMARK-ID
018645         OR  RLABR-TST-RSLT-TYP-CD NOT = WS-OLD-TST-RSLT-TYP-CD
                   MOVE RLABR-LTST-ID TO WSTAT-LTST-ID
                   MOVE RLABR-CLI-LTST-RSLT-CD
                                      TO WSTAT-LTST-RSLT-CD
                   MOVE RLABR-RSLT-PRECSN-QTY
                                      TO WSTAT-RSLT-PRECSN-QTY
018645             MOVE RLABR-TST-RSLT-TYP-CD
018645                                TO WSTAT-TST-RSLT-TYP-CD
018645             MOVE RLABR-RSLT-QTY-TXT
018645                                TO WSTAT-RSLT-QTY-TXT
                   MOVE RLABR-BAD-LAB-INFO-IND
                                      TO WSTAT-BAD-DATA-IND
                   MOVE RLABR-CO-MIN-NRNG-QTY
                                      TO WSTAT-CO-MIN-NRNG-QTY
                   MOVE RLABR-CO-MAX-NRNG-QTY
                                      TO WSTAT-CO-MAX-NRNG-QTY
                   MOVE RLABR-LAB-MIN-NRNG-QTY
                                      TO WSTAT-LAB-MIN-NRNG-QTY
                   MOVE RLABR-LAB-MAX-NRNG-QTY
                                      TO WSTAT-LAB-MAX-NRNG-QTY
                   MOVE RLABR-LAB-RMRK-NUM
                                      TO WSTAT-LAB-RMRK-NUM
                   MOVE RLABR-ALPHA-RESP-CD
                                      TO WSTAT-ALPHA-RESP-CD
                   PERFORM  STAT-1000-ASSIGN-STATUS
                       THRU STAT-1000-ASSIGN-STATUS-X
015543             PERFORM  5301-ASSIGN-STATUS-CHECK
015543                 THRU 5301-ASSIGN-STATUS-CHECK-X
557660         END-IF
557660     END-IF.
      *
      *** IF NO COMMENTS WERE ENTERED BUT A REMARK ID WAS ENTERED
      *** GET THE REMARK FROM THE MESSAGE FILE.
      **
           IF  RLABR-CLI-LTST-RMRK-TXT =  SPACES
           AND RLABR-LAB-RMRK-NUM NOT  =  SPACES
               PERFORM  9222-LOAD-REMARKS
                   THRU 9222-LOAD-REMARKS-X
               MOVE MIR-CLI-LTST-RMRK-TXT TO RLABR-CLI-LTST-RMRK-TXT
557660     END-IF.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      *
015543 5301-ASSIGN-STATUS-CHECK.
015543
015543     IF  WSTAT-RETRN-OK
015543         MOVE WSTAT-LTST-STAT-CD
015543                        TO RLABR-CLI-LTST-STAT-CD
015543         MOVE 'N'       TO WS-RSN-REQUIRED-SW
015543         MOVE WSTAT-LTST-STAT-CD
015543                        TO MIR-CLI-LTST-STAT-CD
015543     ELSE
015543         MOVE 'N'       TO WS-INPUT-VALID-SW
015543*MSG: 'PROBLEM ENCOUNTERED DURING AUTO STATUS "
015543*     'ASSIGNMENT'
015543         MOVE 'NS13800033'
015543                        TO WGLOB-MSG-REF-INFO
015543         PERFORM  0260-1000-GENERATE-MESSAGE
015543             THRU 0260-1000-GENERATE-MESSAGE-X
015543     END-IF.
015543
015543 5301-ASSIGN-STATUS-CHECK-X.
015543     EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT LAB CODE - MUST BE VALID LAB
      *----------------------------------------------------------------
       5305-EDIT-LAB-CODE.

           MOVE 'N'                   TO WS-LABT-BROWSED-SW.

           IF  MIR-CLI-LTST-LAB-ID = SPACE
               MOVE RLABR-CLI-LTST-LAB-ID
                                      TO MIR-CLI-LTST-LAB-ID
               GO TO 5305-EDIT-LAB-CODE-X
557660     END-IF.

           IF  MIR-CLI-LTST-LAB-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-CLI-LTST-LAB-ID
557660     END-IF.

           MOVE MIR-CLI-LTST-LAB-ID   TO WEDIT-ETBL-VALU-ID.
           PERFORM  LABC-1000-EDIT-LAB-CODE
               THRU LABC-1000-EDIT-LAB-CODE-X.

           IF  WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'XS00000088'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5305-EDIT-LAB-CODE-X
557660     END-IF.

      *** BROWSE LABT FILE TO FIND A MATCH ON LAB/TEST/HIGH AGE/SEX
      *** IF A SEX CODE IS AVAILABLE IT IS USED IN THE SEARCH. IF NO
      *** LABT ENTRY IS FOUND USING THE SEX CODE A CODE OF HIGH VALUES
      *** WILL BE USED.

           IF  MIR-CLI-SEX-CD = SPACES
               MOVE HIGH-VALUES       TO WS-SEX-CODE
           ELSE
               MOVE MIR-CLI-SEX-CD    TO WS-SEX-CODE
557660     END-IF.

           PERFORM  5307-BROWSE-LABT-FILE
               THRU 5307-BROWSE-LABT-FILE-X.

      *** IF THE HIGH-VALUES SEX CODE WAS USED AND NO LABT RECORD WAS
      *** FOUND, GENERATE AN ERROR MESSAGE. IF A VALID SEX WAS USED IN
      *** THE FIRST SEARCH, PERFORM ANOTHER SEARCH USING HIGH-VALUES IN
      *** THE SEX FIELD.

           IF  WS-LABT-REC-NOT-FND
               IF  MIR-CLI-SEX-CD = SPACES
                   PERFORM  5306-LAB-ERROR
                       THRU 5306-LAB-ERROR-X
                   GO TO 5305-EDIT-LAB-CODE-X
               ELSE
                   MOVE HIGH-VALUES   TO WS-SEX-CODE
                   PERFORM  5307-BROWSE-LABT-FILE
                       THRU 5307-BROWSE-LABT-FILE-X
557660         END-IF
557660     END-IF.

      *** IF A LABT RECORD EXISTS, ASSIGN THE VALUES TO THE LABR RECORD.
           IF  WS-LABT-REC-FND
               MOVE MIR-CLI-LTST-LAB-ID
                                      TO RLABR-CLI-LTST-LAB-ID
               MOVE RLABT-RSLT-PRECSN-QTY
                                      TO RLABR-RSLT-PRECSN-QTY
018645         MOVE RLABT-TST-RSLT-TYP-CD
018645                                TO RLABR-TST-RSLT-TYP-CD
               MOVE RLABT-CO-MIN-NRNG-QTY
                                      TO RLABR-CO-MIN-NRNG-QTY
               MOVE RLABT-CO-MAX-NRNG-QTY
                                      TO RLABR-CO-MAX-NRNG-QTY
               MOVE RLABT-LAB-MIN-NRNG-QTY
                                      TO RLABR-LAB-MIN-NRNG-QTY
               MOVE RLABT-LAB-MAX-NRNG-QTY
                                      TO RLABR-LAB-MAX-NRNG-QTY
               MOVE RLABT-UNIT-MESUR-TXT
                                      TO RLABR-UNIT-MESUR-TXT
               MOVE RLABT-ALPHA-RESP-ETBL-ID
                                      TO RLABR-ALPHA-RESP-CD
               PERFORM  5308-RESET-RESULT
                   THRU 5308-RESET-RESULT-X
           ELSE
               PERFORM  5306-LAB-ERROR
                   THRU 5306-LAB-ERROR-X
557660     END-IF.

       5305-EDIT-LAB-CODE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    LAB ERROR - A LAB/TEST RECORD ON LABT DID NOT EXIST FOR
      *                THIS TEST RESULT.
      *----------------------------------------------------------------
       5306-LAB-ERROR.

           MOVE 'NS13800007'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           IF  WGLOB-MSG-SEVRTY-FATAL
               MOVE 'N'               TO WS-INPUT-VALID-SW
           ELSE
               MOVE MIR-CLI-LTST-LAB-ID
                                      TO RLABR-CLI-LTST-LAB-ID
557660     END-IF.

       5306-LAB-ERROR-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    BROWSE LABT FILE: READ THE REQUIRED LABT RECORD
      *----------------------------------------------------------------
       5307-BROWSE-LABT-FILE.

           MOVE 'Y'                   TO WS-LABT-BROWSED-SW.
      *** ASSUME THE LABT RECORD IS NOT FOUND.

           MOVE 'N'                   TO WS-LABT-REC-FND-SW.

      *** BROWSE LABT FILE TO FIND A MATCH ON LAB/TEST/HIGH AGE/SEX

           MOVE LOW-VALUES            TO WLABT-KEY.
           MOVE HIGH-VALUES           TO WLABT-ENDBR-KEY.

           IF WS-BUS-FCN-LIST
               MOVE RLABR-CLI-LTST-LAB-ID
                                      TO  WLABT-LAB-ID
               MOVE RLABR-LTST-ID     TO  WLABT-LTST-ID
               MOVE RLABR-CLI-LTST-LAB-ID
                                      TO  WLABT-ENDBR-LAB-ID
               MOVE RLABR-LTST-ID     TO  WLABT-ENDBR-LTST-ID
           ELSE
               MOVE MIR-CLI-LTST-LAB-ID
                                      TO WLABT-LAB-ID
               MOVE MIR-LTST-ID       TO WLABT-LTST-ID
               MOVE MIR-CLI-LTST-LAB-ID
                                      TO WLABT-ENDBR-LAB-ID
               MOVE MIR-LTST-ID       TO WLABT-ENDBR-LTST-ID
           END-IF.

           MOVE WS-SEX-CODE           TO WLABT-LTST-STD-SEX-CD.
           MOVE MIR-DV-CLI-INSRD-AGE  TO WLABT-LTST-STD-AGE-QTY.

           MOVE WS-SEX-CODE           TO WLABT-ENDBR-LTST-STD-SEX-CD.

           PERFORM  LABT-1000-BROWSE
               THRU LABT-1000-BROWSE-X.

      *** ISSUE MESSAGE IF LAB/TEST NOT ON LABT
           IF  NOT WLABT-IO-OK
               GO TO 5307-BROWSE-LABT-FILE-X
557660     END-IF.

           PERFORM  LABT-2000-READ-NEXT
               THRU LABT-2000-READ-NEXT-X.

      *** SET THE SWITCH INDICATING WHETHER OR NOT THE RECORD WAS FND.

           IF  WLABT-IO-OK
               MOVE 'Y'               TO WS-LABT-REC-FND-SW
557660     END-IF.

           PERFORM  LABT-3000-END-BROWSE
               THRU LABT-3000-END-BROWSE-X.

       5307-BROWSE-LABT-FILE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    RESET RESULT - IF RESULT TYPE CHANGES TO NUMERIC FROM ALPHA
      *    OR VISA VERSA, THE RESULT MUST ACCORDINGLY BE RESET.
      *----------------------------------------------------------------
       5308-RESET-RESULT.

018645*    IF  WS-OLD-PRECISION       NOT =  RLABR-RSLT-PRECSN-QTY
018645*        IF  RLABR-RSLT-PRECSN-QTY  =  SPACES
018645*        OR  RLABR-RSLT-PRECSN-ALPHA-VALUE
018645*            MOVE SPACES        TO RLABR-CLI-LTST-RSLT-CD
018645*        ELSE
018645*            MOVE ZEROS         TO RLABR-CLI-LTST-RSLT-CD
018645*        END-IF
018645     IF  WS-OLD-TST-RSLT-TYP-CD NOT = RLABR-TST-RSLT-TYP-CD
018645         MOVE ZEROS             TO RLABR-RSLT-QTY-TXT
018645         MOVE SPACES            TO RLABR-CLI-LTST-RSLT-CD
557660     END-IF.

      *  IF NOTHING WAS ENTERED IN THE RESULT FIELD, OR THE
      *  TEST HAS NO VALID ALPHA RESULTS, THEN DON'T ALLOW THE
      *  RESULT PRECISION TO BE CHANGED.

           IF MIR-CLI-LTST-RSLT-CD = SPACES
           OR RLABR-ALPHA-RESP-CD = SPACES
018645     OR MIR-RSLT-QTY-TXT    = SPACES
               GO TO 5308-RESET-RESULT-X
557660     END-IF.

      *  DETERMINE IF THE INPUTTED RESULT IS NUMERIC OR ALPHA
      *  IF NUMERIC AND ALPHA RESULT IS EXPECTED, TREAT IT AS
      *  ALPHA
      *
           MOVE +7                    TO L0280-PRECISION.
           MOVE WLABR-RESULT-SIZE     TO L0280-LENGTH.

           MOVE 'N'                   TO L0280-SIGN-IND.
018645*    MOVE MIR-CLI-LTST-RSLT-CD  TO L0280-INPUT-DATA.
018645     MOVE MIR-RSLT-QTY-TXT      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
018645*        MOVE 'A'               TO RLABR-RSLT-PRECSN-QTY
018645         MOVE '1'               TO RLABR-TST-RSLT-TYP-CD
557660     END-IF.
      *
       5308-RESET-RESULT-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT TEST RESULT - MUST BE NUMERIC IF TEST IS ON LABT,
      *    OTHERWISE MUST BE IN EDIT/TSTRS
      *----------------------------------------------------------------
       5310-EDIT-RESULT.

           IF  MIR-CLI-LTST-RSLT-CD = SPACE
018645     AND MIR-RSLT-QTY-TXT     = SPACE
               PERFORM  5500-FORMAT-RESULT
                   THRU 5500-FORMAT-RESULT-X
018645*        MOVE WS-DISPLAY-RESULT-R
018645*                               TO MIR-CLI-LTST-RSLT-CD
018645         IF  RLABR-TST-RSLT-TYP-CD NOT = '2'
018645             MOVE WS-DISPLAY-RESULT-R
018645                                TO MIR-CLI-LTST-RSLT-CD
018645             MOVE SPACE         TO MIR-RSLT-QTY-TXT
018645         ELSE
018645             MOVE WS-DISPLAY-RESULT-R
018645                                TO MIR-RSLT-QTY-TXT
018645             MOVE SPACE         TO MIR-CLI-LTST-RSLT-CD
018645         END-IF
               GO TO 5310-EDIT-RESULT-X
557660     END-IF.

           IF  MIR-CLI-LTST-RSLT-CD = EBLCH-BLANK-FIELD-CHAR
018645*        IF  RLABR-RSLT-PRECSN-QTY = SPACE
018645*        OR  RLABR-RSLT-PRECSN-ALPHA-VALUE
018645*            MOVE SPACE         TO RLABR-CLI-LTST-RSLT-CD
018645*            MOVE SPACE         TO MIR-CLI-LTST-RSLT-CD
018645*            GO TO 5310-EDIT-RESULT-X
018645*        ELSE
018645*            MOVE ZEROS         TO RLABR-CLI-LTST-RSLT-CD
018645*            PERFORM  5500-FORMAT-RESULT
018645*                THRU 5500-FORMAT-RESULT-X
018645*            MOVE WS-DISPLAY-RESULT-R
018645*                               TO MIR-CLI-LTST-RSLT-CD
018645*            GO TO 5310-EDIT-RESULT-X
018645*        END-IF
018645         MOVE SPACE             TO RLABR-CLI-LTST-RSLT-CD
018645         MOVE SPACE             TO MIR-CLI-LTST-RSLT-CD
557660     END-IF.

018645     IF  MIR-RSLT-QTY-TXT = EBLCH-BLANK-FIELD-CHAR
018645         MOVE ZERO              TO RLABR-RSLT-QTY-TXT
018645         MOVE SPACE             TO MIR-RSLT-QTY-TXT
018645     END-IF.

018645     IF  MIR-CLI-LTST-RSLT-CD = SPACE
018645     AND MIR-RSLT-QTY-TXT = SPACE
018645         GO TO 5310-EDIT-RESULT-X
018645     END-IF.

018645     IF  MIR-CLI-LTST-RSLT-CD NOT = SPACE
018645     AND MIR-RSLT-QTY-TXT NOT = SPACE
018645* MSG: ONLY ONE RESULT SHOULD BE ENTERED
018645         MOVE 'N'           TO WS-INPUT-VALID-SW
018645         MOVE 'NS13800036'  TO WGLOB-MSG-REF-INFO
018645         PERFORM  0260-1000-GENERATE-MESSAGE
018645             THRU 0260-1000-GENERATE-MESSAGE-X
018645         GO TO 5310-EDIT-RESULT-X
018645     END-IF.

      * IF THE LABT FILE HAD NOT BEEN BROWSED UP TO NOW, LOOK IT UP
      * FOR PRECISION DETERMINING PURPOSES.
           IF WS-LABT-NOT-BROWSED
               IF MIR-CLI-SEX-CD = SPACES
                   MOVE HIGH-VALUES   TO WS-SEX-CODE
               ELSE
                   MOVE MIR-CLI-SEX-CD TO WS-SEX-CODE
557660         END-IF
557660     END-IF.

           IF WS-LABT-NOT-BROWSED
               PERFORM  5307-BROWSE-LABT-FILE
                   THRU 5307-BROWSE-LABT-FILE-X

               IF  WS-LABT-REC-NOT-FND
015543             PERFORM  5311-LABT-NOT-FOUND
015543                 THRU 5311-LABT-NOT-FOUND-X
557660         END-IF
557660     END-IF.

           IF WS-LABT-REC-FND
               MOVE RLABT-RSLT-PRECSN-QTY
                                      TO RLABR-RSLT-PRECSN-QTY
018645         MOVE RLABT-TST-RSLT-TYP-CD
018645                                TO RLABR-TST-RSLT-TYP-CD

      *  DETERMINE THE TYPE OF RESULT ENTERED, AND IF NECESSARY
      *  ADJUST THE PRECISION FIELD ON THE LABR RECORD.

               PERFORM  5308-RESET-RESULT
                   THRU 5308-RESET-RESULT-X
557660     END-IF.

      *** IF THE PRECISION CODE IS SPACES THEN A REMARK ONLY IS ENTERED
      *** FOR THIS TEST.
018645*    IF  RLABR-RSLT-PRECSN-QTY = SPACES
018645     IF  RLABR-TST-RSLT-TYP-CD = '3'
               IF  MIR-CLI-LTST-RSLT-CD = SPACES
018645         AND MIR-RSLT-QTY-TXT = SPACES
                   GO TO 5310-EDIT-RESULT-X
               ELSE
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   MOVE 'NS13800034'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE WS-OLD-PRECISION
                                      TO RLABR-RSLT-PRECSN-QTY
018645             MOVE WS-OLD-TST-RSLT-TYP-CD
018645                                TO RLABR-TST-RSLT-TYP-CD
                   GO TO 5310-EDIT-RESULT-X
557660         END-IF
557660     END-IF.

      *** EDIT ALPHA RESULTS AGAINST EDIT/TSTRS
018645*    IF  RLABR-RSLT-PRECSN-ALPHA-VALUE
018645     IF  RLABR-TST-RSLT-TYP-CD = '1'
               MOVE MIR-CLI-LTST-RSLT-CD
                                      TO WEDIT-ETBL-VALU-ID
               PERFORM  TSTR-1000-EDIT-TEST-RESULT
                   THRU TSTR-1000-EDIT-TEST-RESULT-X
               IF  WEDIT-IO-OK
                   MOVE MIR-CLI-LTST-RSLT-CD
                                      TO RLABR-CLI-LTST-RSLT-CD
                   GO TO 5310-EDIT-RESULT-X
               ELSE
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   MOVE 'XS00000207'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE WS-OLD-PRECISION
                                      TO RLABR-RSLT-PRECSN-QTY
018645             MOVE WS-OLD-TST-RSLT-TYP-CD
018645                                TO RLABR-TST-RSLT-TYP-CD
                   GO TO 5310-EDIT-RESULT-X
557660         END-IF
557660     END-IF.

      *** NUMERIC TEST RESULT - NUMERIC EDIT
018645*    MOVE RLABR-RSLT-PRECSN-QTY-N
018645     MOVE RLABR-RSLT-PRECSN-QTY
                                      TO L0280-PRECISION.

           IF  L0280-PRECISION = ZERO
               MOVE WLABR-RESULT-SIZE TO L0280-LENGTH
           ELSE
               COMPUTE L0280-LENGTH = WLABR-RESULT-SIZE -
                                      L0280-PRECISION
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
018645*    MOVE MIR-CLI-LTST-RSLT-CD  TO L0280-INPUT-DATA.
018645     MOVE MIR-RSLT-QTY-TXT      TO L0280-INPUT-DATA.
018645     MOVE LENGTH OF MIR-RSLT-QTY-TXT
018645                                TO L0280-INPUT-SIZE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-OLD-PRECISION  TO RLABR-RSLT-PRECSN-QTY
018645         MOVE WS-OLD-TST-RSLT-TYP-CD
018645                                TO RLABR-TST-RSLT-TYP-CD
               GO TO 5310-EDIT-RESULT-X
557660     END-IF.

           MOVE L0280-SIGN-IND        TO L0290-SIGN-IND.
008455*****MOVE L0280-LENGTH     TO L0290-LENGTH.
           MOVE L0280-PRECISION       TO L0290-PRECISION.
018645*    MOVE LENGTH OF MIR-CLI-LTST-RSLT-CD
018645     MOVE LENGTH OF MIR-RSLT-QTY-TXT
008455                                TO L0290-MAX-OUT-LEN.
013578*    SET L0290-LEAD-ZEROS-SUPPRESS
013578*                               TO TRUE.

           MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER.
           MOVE SPACES                TO L0290-OUTPUT-DATA.

020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

018645*    MOVE L0290-OUTPUT-DATA     TO MIR-CLI-LTST-RSLT-CD.
018645     MOVE L0290-OUTPUT-DATA     TO MIR-RSLT-QTY-TXT.
      ***  THE TEST RESULT MUST BE STORED IN PIC FORMAT SO
      ***  THAT IT CAN BE USED IN THE RANGE COMPARISON
      ***  IN STATUS ASSIGNMENT.
           MOVE L0280-OUTPUT          TO WS-PIC-RESULT
018645*    MOVE WS-PIC-RESULT         TO RLABR-CLI-LTST-RSLT-CD.
018645     MOVE WS-PIC-RESULT         TO RLABR-RSLT-QTY-TXT.

       5310-EDIT-RESULT-X.
           EXIT.
      *
015543 5311-LABT-NOT-FOUND.
015543
015543     IF  MIR-CLI-SEX-CD = SPACES
034802*        NEXT SENTENCE
034802         CONTINUE
015543     ELSE
015543         MOVE HIGH-VALUES
015543                        TO WS-SEX-CODE
015543         PERFORM  5307-BROWSE-LABT-FILE
015543             THRU 5307-BROWSE-LABT-FILE-X
015543     END-IF.
015543
015543 5311-LABT-NOT-FOUND-X.
015543     EXIT.
      *
      *----------------------------------------------------------------
      *   EDIT DATE OF LAST MEAL BEFORE TEST - MUST BE VALID DATE
      *   BEFORE DATE OF TEST.
      *----------------------------------------------------------------
       5315-EDIT-DATE-LAST-MEAL.

           IF  MIR-PREV-MEAL-DT = SPACE
               MOVE RLABR-PREV-MEAL-DT TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-PREV-MEAL-DT
               GO TO 5315-EDIT-DATE-LAST-MEAL-X
557660     END-IF.

           IF  MIR-PREV-MEAL-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-PREV-MEAL-DT
               MOVE WWKDT-ZERO-DT     TO RLABR-PREV-MEAL-DT
               GO TO 5315-EDIT-DATE-LAST-MEAL-X
557660     END-IF.

           MOVE MIR-PREV-MEAL-DT      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5315-EDIT-DATE-LAST-MEAL-X
557660     END-IF.

           IF  L1640-INTERNAL-DATE > RLABR-CLI-LTST-DT
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5315-EDIT-DATE-LAST-MEAL-X
557660     END-IF.

           MOVE L1640-INTERNAL-DATE   TO RLABR-PREV-MEAL-DT.

       5315-EDIT-DATE-LAST-MEAL-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT TIME OF LAST MEAL - MUST BE A VALID TIME
      *----------------------------------------------------------------
       5320-EDIT-TIME-LAST-MEAL.

           IF  MIR-PREV-MEAL-TIME = SPACE
               MOVE RLABR-PREV-MEAL-TIME
                                      TO MIR-PREV-MEAL-TIME
               GO TO 5320-EDIT-TIME-LAST-MEAL-X
557660     END-IF.

           IF  MIR-PREV-MEAL-TIME = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-PREV-MEAL-TIME
               MOVE SPACE             TO RLABR-PREV-MEAL-TIME
               GO TO 5320-EDIT-TIME-LAST-MEAL-X
557660     END-IF.

           MOVE MIR-PREV-MEAL-TIME    TO WS-EDIT-TIME.
           PERFORM  5395-EDIT-TIME
               THRU 5395-EDIT-TIME-X.
           IF  WS-EDIT-TIME = HIGH-VALUES
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5320-EDIT-TIME-LAST-MEAL-X
557660     END-IF.

           MOVE WS-EDIT-TIME          TO RLABR-PREV-MEAL-TIME.
           MOVE WS-EDIT-TIME          TO MIR-PREV-MEAL-TIME.

       5320-EDIT-TIME-LAST-MEAL-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT SERUM APPEARANCE - CAN BE ANYTHING
      *----------------------------------------------------------------
       5325-EDIT-SERUM-APPEARANCE.

           IF  MIR-SERUM-DESC-TXT = SPACE
               MOVE RLABR-SERUM-DESC-TXT
                                      TO MIR-SERUM-DESC-TXT
               GO TO 5325-EDIT-SERUM-APPEARANCE-X
557660     END-IF.

           IF  MIR-SERUM-DESC-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-SERUM-DESC-TXT
557660     END-IF.

           MOVE MIR-SERUM-DESC-TXT    TO RLABR-SERUM-DESC-TXT.

       5325-EDIT-SERUM-APPEARANCE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   EDIT DATE BLOOD DRAWN - MUST BE VALID DATE AND NOT AFTER
      *   DATE OF TEST
      *----------------------------------------------------------------
       5330-EDIT-DATE-BLOOD-DRAWN.

           IF  MIR-BLOOD-DRW-DT = SPACE
               MOVE RLABR-BLOOD-DRW-DT TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-BLOOD-DRW-DT
               GO TO 5330-EDIT-DATE-BLOOD-DRAWN-X
557660     END-IF.

           IF  MIR-BLOOD-DRW-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-BLOOD-DRW-DT
               MOVE WWKDT-ZERO-DT     TO RLABR-BLOOD-DRW-DT
               GO TO 5330-EDIT-DATE-BLOOD-DRAWN-X
557660     END-IF.

           MOVE MIR-BLOOD-DRW-DT      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5330-EDIT-DATE-BLOOD-DRAWN-X
557660     END-IF.

           IF  L1640-INTERNAL-DATE > RLABR-CLI-LTST-DT
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5330-EDIT-DATE-BLOOD-DRAWN-X
557660     END-IF.

           MOVE L1640-INTERNAL-DATE   TO RLABR-BLOOD-DRW-DT.

       5330-EDIT-DATE-BLOOD-DRAWN-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT TIME BLOOD DRAWN - MUST BE A TIME
      *----------------------------------------------------------------
       5335-EDIT-TIME-BLOOD-DRAWN.

           IF  MIR-BLOOD-DRW-TIME = SPACE
               MOVE RLABR-BLOOD-DRW-TIME
                                      TO MIR-BLOOD-DRW-TIME
               GO TO 5335-EDIT-TIME-BLOOD-DRAWN-X
557660     END-IF.

           IF  MIR-BLOOD-DRW-TIME = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-BLOOD-DRW-TIME
               MOVE SPACE             TO RLABR-BLOOD-DRW-TIME
               GO TO 5335-EDIT-TIME-BLOOD-DRAWN-X
557660     END-IF.

           MOVE MIR-BLOOD-DRW-TIME    TO WS-EDIT-TIME.
           PERFORM  5395-EDIT-TIME
               THRU 5395-EDIT-TIME-X.
           IF  WS-EDIT-TIME = HIGH-VALUES
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5335-EDIT-TIME-BLOOD-DRAWN-X
557660     END-IF.

           MOVE WS-EDIT-TIME          TO RLABR-BLOOD-DRW-TIME.
           MOVE WS-EDIT-TIME          TO MIR-BLOOD-DRW-TIME.

       5335-EDIT-TIME-BLOOD-DRAWN-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT URINE APPEARANCE - CAN BE ANYTHING
      *----------------------------------------------------------------
       5340-EDIT-URINE-APPEARANCE.

           IF  MIR-URIN-DESC-TXT = SPACE
               MOVE RLABR-URIN-DESC-TXT
                                      TO MIR-URIN-DESC-TXT
               GO TO 5340-EDIT-URINE-APPEARANCE-X
557660     END-IF.

           IF  MIR-URIN-DESC-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-URIN-DESC-TXT
557660     END-IF.

           MOVE MIR-URIN-DESC-TXT     TO RLABR-URIN-DESC-TXT.

       5340-EDIT-URINE-APPEARANCE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT DATE VOIDED - MUST BE A VALID DATE BEFORE TEST DATE
      *----------------------------------------------------------------
       5345-EDIT-DATE-VOIDED.

           IF  MIR-SAMPL-VOID-DT = SPACE
               MOVE RLABR-SAMPL-VOID-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-SAMPL-VOID-DT
               GO TO 5345-EDIT-DATE-VOIDED-X
557660     END-IF.

           IF  MIR-SAMPL-VOID-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-SAMPL-VOID-DT
               MOVE WWKDT-ZERO-DT     TO RLABR-SAMPL-VOID-DT
               GO TO 5345-EDIT-DATE-VOIDED-X
557660     END-IF.

           MOVE MIR-SAMPL-VOID-DT     TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5345-EDIT-DATE-VOIDED-X
557660     END-IF.

           IF  L1640-INTERNAL-DATE > RLABR-CLI-LTST-DT
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5345-EDIT-DATE-VOIDED-X
557660     END-IF.

           MOVE L1640-INTERNAL-DATE   TO RLABR-SAMPL-VOID-DT.

       5345-EDIT-DATE-VOIDED-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT TEST RESULT STATUS - MUST BE N OR A (NORMAL,ABNORMAL)
      *----------------------------------------------------------------
       5350-EDIT-STATUS.

           IF  MIR-CLI-LTST-STAT-CD = SPACE
               MOVE RLABR-CLI-LTST-STAT-CD
                                      TO MIR-CLI-LTST-STAT-CD
               GO TO 5350-EDIT-STATUS-X
557660     END-IF.

      ** SPACES IS NOT AN ACCEPTABLE STATUS.

           IF  MIR-CLI-LTST-STAT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-CLI-LTST-STAT-CD
               MOVE SPACE             TO RLABR-CLI-LTST-STAT-CD
               GO TO 5350-EDIT-STATUS-X
557660     END-IF.

      ** IF A VALID STATUS WAS ENTERED CREATE A DIARY ACTIVITY LOG
      ** ENTRY AND UPDATE THE LAB RESULT RECORD.

           IF  MIR-CLI-LTST-STAT-CD = 'A'
           OR  MIR-CLI-LTST-STAT-CD = 'N'
               MOVE SPACES            TO L0760-MESSAGE-NUMBER
               MOVE RLABR-CLI-LTST-STAT-CD
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CLI-LTST-STAT-CD
                                      TO L0760-MESSAGE-PARMS (2)
               MOVE MIR-CLI-LTST-STAT-CD
                                      TO RLABR-CLI-LTST-STAT-CD
               MOVE 'LTEST'           TO L0760-DAL-ACTIVITY
               MOVE 'CHG'             TO L0760-DAL-ACTION
               MOVE 'C'               TO L0760-POL-OR-CLI-TYPE
               MOVE RLABR-CLI-ID      TO L0760-POL-OR-CLI-ID
               MOVE ZEROES            TO L0760-CVG-NUM-N
               PERFORM  0760-1000-PROCESS-DAL-ENTRY
                   THRU 0760-1000-PROCESS-DAL-ENTRY-X
           ELSE
               MOVE 'N'               TO WS-INPUT-VALID-SW
      *        MESSAGE 'INVALID TEST RESULT STATUS - MUST BE "A" OR "N"
               MOVE 'NS13800028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5350-EDIT-STATUS-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT STATUS CHANGE REASON CODE - EDIT TABLE TSTRE
      *----------------------------------------------------------------

       5353-EDIT-STATUS-REASON.

           IF  MIR-STAT-CHNG-REASN-CD = SPACES
               MOVE RLABR-STAT-CHNG-REASN-CD
                                      TO MIR-STAT-CHNG-REASN-CD
               GO TO 5353-EDIT-STATUS-REASON-X
557660     END-IF.

           IF  MIR-STAT-CHNG-REASN-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RLABR-STAT-CHNG-REASN-CD
               MOVE SPACES            TO MIR-STAT-CHNG-REASN-CD
557660     END-IF.

           MOVE MIR-STAT-CHNG-REASN-CD TO WEDIT-ETBL-VALU-ID.
           PERFORM  TSTC-1000-EDIT-STAT-CHG-RSN
               THRU TSTC-1000-EDIT-STAT-CHG-RSN-X.
           IF  WEDIT-IO-NOT-FOUND
      *        MESSAGE 'STATUS CHANGE REASON NOT FOUND ON EDIT TABLE
      *                 TSTRS'
               MOVE 'NS13800029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 5353-EDIT-STATUS-REASON-X
           ELSE
               MOVE MIR-STAT-CHNG-REASN-CD
                                      TO RLABR-STAT-CHNG-REASN-CD
557660     END-IF.

       5353-EDIT-STATUS-REASON-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    EDIT BAD LAB DATA INDICATOR - MUST BE Y OR N
      *----------------------------------------------------------------

       5355-EDIT-BAD-DATA-IND.

           IF  MIR-BAD-LAB-INFO-IND = SPACE
               MOVE RLABR-BAD-LAB-INFO-IND
                                      TO MIR-BAD-LAB-INFO-IND
               GO TO 5355-EDIT-BAD-DATA-IND-X
557660     END-IF.

           IF  MIR-BAD-LAB-INFO-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-BAD-LAB-INFO-IND
557660     END-IF.

           IF  MIR-BAD-LAB-INFO-IND = 'Y'
           OR  MIR-BAD-LAB-INFO-IND = 'N'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'N'               TO WS-INPUT-VALID-SW
               MOVE 'NS13800018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5355-EDIT-BAD-DATA-IND-X
557660     END-IF.

           MOVE MIR-BAD-LAB-INFO-IND  TO RLABR-BAD-LAB-INFO-IND.

       5355-EDIT-BAD-DATA-IND-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   EDIT THE REMARK-ID.  MUST BE OM MSG FILE IF A REMARK WAS NOT
      *                        ENTERED.
      *----------------------------------------------------------------
       5360-EDIT-REMARK-ID.

           IF  MIR-LAB-RMRK-NUM = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RLABR-LAB-RMRK-NUM
               MOVE SPACES            TO MIR-LAB-RMRK-NUM
               GO TO 5360-EDIT-REMARK-ID-X
557660     END-IF.

           IF  MIR-LAB-RMRK-NUM = SPACES
               MOVE RLABR-LAB-RMRK-NUM TO MIR-LAB-RMRK-NUM
               GO TO 5360-EDIT-REMARK-ID-X
557660     END-IF.

           MOVE MIR-LAB-RMRK-NUM      TO WEDIT-ETBL-VALU-ID.
           PERFORM  TSTN-1000-EDIT-TEST-NUMBER
               THRU TSTN-1000-EDIT-TEST-NUMBER-X.
           IF  WEDIT-IO-NOT-FOUND
               MOVE 'NS13800023'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-INPUT-VALID-SW
               GO TO 5360-EDIT-REMARK-ID-X
           ELSE
               MOVE MIR-LAB-RMRK-NUM  TO RLABR-LAB-RMRK-NUM
557660     END-IF.

       5360-EDIT-REMARK-ID-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   EDIT THE REMARK-ID.  MUST BE OM MSG FILE IF A REMARK WAS NOT
      *                        ENTERED.
      *----------------------------------------------------------------
       5365-EDIT-REMARKS.

           IF  MIR-CLI-LTST-RMRK-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CLI-LTST-RMRK-TXT
               MOVE SPACES            TO RLABR-CLI-LTST-RMRK-TXT
               GO TO 5365-EDIT-REMARKS-X
557660     END-IF.

      *** IF NO COMMENTS WERE ENTERED THEN OBTAIN THE COMMENTS FROM
      *** THE LABR RECORD (IF ANY) OR THE MESSAGE FILE (IF REMARK ID
      *** EXISTS).
           IF  MIR-CLI-LTST-RMRK-TXT = SPACES
               IF  RLABR-LAB-RMRK-NUM  = SPACES
                   GO TO 5365-EDIT-REMARKS-X
               ELSE
                   PERFORM  9222-LOAD-REMARKS
                       THRU 9222-LOAD-REMARKS-X
                   GO TO 5365-EDIT-REMARKS-X
557660         END-IF
557660     END-IF.

      *** STORE THE COMMENTS ENTERED ON THE SCREEN.
           MOVE  MIR-CLI-LTST-RMRK-TXT TO RLABR-CLI-LTST-RMRK-TXT.

       5365-EDIT-REMARKS-X.
           EXIT.
      *
       5370-EDIT-REF-NUMBER.

           IF  MIR-LAB-GEN-REF-ID = SPACE
               MOVE RLABR-LAB-GEN-REF-ID
                                      TO MIR-LAB-GEN-REF-ID
               GO TO 5370-EDIT-REF-NUMBER-X
557660     END-IF.

           IF  MIR-LAB-GEN-REF-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-LAB-GEN-REF-ID
557660     END-IF.

           MOVE MIR-LAB-GEN-REF-ID    TO RLABR-LAB-GEN-REF-ID.

       5370-EDIT-REF-NUMBER-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   EDIT A TIME - MUST BE NUMERIC, AND A VALID TIME ON THE 24
      *   HOUR CLOCK.
      *----------------------------------------------------------------
       5395-EDIT-TIME.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE +4                    TO L0280-LENGTH.
013578     MOVE +4                    TO L0280-INPUT-SIZE.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE WS-EDIT-TIME          TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
               MOVE HIGH-VALUES       TO WS-EDIT-TIME
               GO TO 5395-EDIT-TIME-X
557660     END-IF.

           MOVE L0280-OUTPUT          TO WS-EDIT-TIME-N.

           IF  WS-EDIT-HOUR > 24
           OR  WS-EDIT-MINUTE > 59
               MOVE HIGH-VALUES       TO WS-EDIT-TIME
               GO TO 5395-EDIT-TIME-X
557660     END-IF.

           MOVE WS-EDIT-TIME-N        TO WS-EDIT-TIME.

       5395-EDIT-TIME-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    FIELD EDITS: CHECK VALIDITY OF ALL DATA FIELDS.
      *----------------------------------------------------------------
       5400-CROSS-EDITS.

           MOVE 'Y'                   TO WS-VALID-CROSS-EDITS-SW.

      ***  IF A LAB RESULT STATUS HAS CHANGED, A LAB REQUIREMENT
      ***  STATUS MAY BE AFFECTED SO AFTER A THE REQUIREMENT
      ***  RESOLUTION MODULE IS PERFORMED.

           IF  RLABR-CLI-LTST-STAT-CD  NOT = SPACES
           AND WS-OLD-STATUS           NOT = RLABR-CLI-LTST-STAT-CD
               PERFORM  7180-1000-BUILD-PARM-INFO
                   THRU 7180-1000-BUILD-PARM-INFO-X
               MOVE RLABR-CLI-ID      TO L7180-CLI-ID
               MOVE RLABR-CLI-LTST-LAB-ID
                                      TO L7180-LAB-CD
               MOVE SPACES            TO L7180-REQIR-CD
               MOVE SPACES            TO L7180-SEQ-NUM
               PERFORM  7180-1000-RESOLVE-REQT
                   THRU 7180-1000-RESOLVE-REQT-X
               IF L7180-CLI-DECISION-RQST
                   PERFORM  1030-1000-BUILD-PARM-INFO
                       THRU 1030-1000-BUILD-PARM-INFO-X
                   MOVE RLABR-CLI-ID  TO L1030-CLIENT-ID
                   PERFORM  1030-1000-CLIENT-DECISION
                       THRU 1030-1000-CLIENT-DECISION-X
               END-IF
      *
      * IF A STATUS WAS CHANGED THEN A REASON CODE IS NECESSARY.
      *
               IF  RLABR-STAT-CHNG-REASN-CD = SPACES
               AND WS-RSN-REQUIRED
                   MOVE 'N'           TO WS-INPUT-VALID-SW
                   MOVE 'N'           TO WS-VALID-CROSS-EDITS-SW
      * MSG: 'STATUS CHANGE REASON CODE MUST BE ENTERED'
                   MOVE 'NS13800032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *** IF THE BAD DATA INDICATOR IS SET TO 'YES' THEN THE TEST
      *** STATUS MUST BE BLANK.
           IF  RLABR-CLI-LTST-STAT-CD NOT = SPACES
           AND RLABR-BAD-LAB-INFO-IND = 'Y'
               MOVE 'N'               TO WS-VALID-CROSS-EDITS-SW
      *      MESSAGE (S) 'STATUS MUST BE BLANK FOR BAD DATA'
               MOVE 'NS13800030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

      *** BLANK STATUS IS ONLY ALLOWED FOR BAD DATA OR SERUM AND
      *** URINE DESCRIPTIONS.
           IF  RLABR-CLI-LTST-STAT-CD     = SPACES
               IF  RLABR-BAD-LAB-INFO-IND = 'Y'
               OR  RLABR-LTST-ID          = 'XXXX'
               OR  RLABR-LTST-ID          = 'YYYY'
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE 'N'           TO WS-VALID-CROSS-EDITS-SW
      **    MESSAGE (S) 'BLANK STATUS NOT ALLOWED FOR THIS RESULT'
                   MOVE 'NS13800031'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

      *** IF COMMENTS WERE ENTERED THE REMARK-ID CANNOT BE SPACES.
           IF  RLABR-CLI-LTST-RMRK-TXT NOT = SPACES
           AND RLABR-LAB-RMRK-NUM  = SPACES
               MOVE 'NS13800025'      TO WGLOB-MSG-REF-INFO
               MOVE 'N'               TO WS-VALID-CROSS-EDITS-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5400-CROSS-EDITS-X
557660     END-IF.

       5400-CROSS-EDITS-X.
           EXIT.
      *
       5500-FORMAT-RESULT.

018645*    IF  RLABR-RSLT-PRECSN-ALPHA-VALUE
018645*    OR  RLABR-RSLT-PRECSN-QTY = SPACES
018645*    OR  RLABR-CLI-LTST-RSLT-CD NOT NUMERIC
018645     IF  RLABR-TST-RSLT-TYP-CD NOT = '2'
               MOVE RLABR-CLI-LTST-RSLT-CD
                                      TO WS-DISPLAY-RESULT-R
               GO TO 5500-FORMAT-RESULT-X
557660     END-IF.

018645*    MOVE RLABR-CLI-LTST-RSLT-CD TO L0290-INPUT-NUMBER.
018645     MOVE RLABR-RSLT-QTY-TXT     TO L0290-INPUT-NUMBER.
           MOVE RLABR-RSLT-PRECSN-QTY TO L0290-PRECISION.
           MOVE 'N'                   TO L0290-SIGN-IND.

008455*****IF  RLABR-RSLT-PRECSN-QTY-N = ZERO
008455*****    MOVE WLABR-RESULT-SIZE     TO L0290-LENGTH
008455*****ELSE
008455*****    COMPUTE L0290-LENGTH = WLABR-RESULT-SIZE -
008455*****                                RLABR-RSLT-PRECSN-QTY-N
008455*****END-IF.

018645*    MOVE LENGTH OF MIR-CLI-LTST-RSLT-CD
018645     MOVE LENGTH OF MIR-RSLT-QTY-TXT
                                      TO L0290-MAX-OUT-LEN.
013578*    SET L0290-LEAD-ZEROS-SUPPRESS  TO TRUE.

           MOVE SPACES                TO L0290-OUTPUT-DATA.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO WS-DISPLAY-RESULT.

       5500-FORMAT-RESULT-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    DELETE PROCESSING:
      *    DELETE IS VERIFIED, DELETE THE RECORD.
      *----------------------------------------------------------------
       6200-PROCESS-DELETE.

018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.
013578
018633*    IF L8090-RETRN-OK
018633     IF LCOMM-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT     TO WS-WORK-AREA
018633*        MOVE WS-WORK-CLIENT-NUMBER    TO MIR-CLI-ID
018633*        MOVE WS-WORK-CURR-SEQUENCE-NO TO MIR-CLI-LTST-SEQ-NUM
018633         MOVE LCOMM-CLIENT-NUMBER      TO MIR-CLI-ID
018633         MOVE LCOMM-CURR-SEQUENCE-NO TO MIR-CLI-LTST-SEQ-NUM
013578     END-IF.
013578
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  9230-LOAD-INSURED-DATA
               THRU 9230-LOAD-INSURED-DATA-X.

           IF  MIR-DOC-ID NOT = SPACES
               PERFORM  7000-PROCESS-DOCUMENT
                   THRU 7000-PROCESS-DOCUMENT-X
               IF  WGLOB-MSG-ERROR-SW NOT = ZERO
                   GO TO 6200-PROCESS-DELETE-X
557660         END-IF
557660     END-IF.
      *
      * CHECK IF CLIENT IS LOCKED IN CLEAR-CASING
      *
           IF NOT L5600-CCAS-ACCS-ALLOW
               SET WS-BUS-FCN-RETRIEVE TO TRUE
               MOVE WS-BUS-FCN-ID      TO MIR-BUS-FCN-ID
               MOVE 'NS13800018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6200-PROCESS-DELETE-X
           END-IF.

           PERFORM  8000-BUILD-LABR-KEY
               THRU 8000-BUILD-LABR-KEY-X.

014221*    PERFORM  LABR-1000-READ-FOR-UPDATE
014221*        THRU LABR-1000-READ-FOR-UPDATE-X.

014221     PERFORM  LABR-2000-UPDATE-TWRK-TS
014221         THRU LABR-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'        TO WGLOB-MSG-REF-INFO
014221         MOVE 'LABR'              TO WGLOB-MSG-PARM (01)
014221         MOVE WLABR-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  9100-BLANK-DATA-FIELDS
014221             THRU 9100-BLANK-DATA-FIELDS-X
014221           GO TO 6200-PROCESS-DELETE-X
014221     END-IF.

           IF  NOT WLABR-IO-OK
014389         MOVE WLABR-CLI-LTST-DT TO L1680-INTERNAL-1
005409         MOVE ZERO              TO L1680-NUMBER-OF-YEARS
005409         MOVE ZERO              TO L1680-NUMBER-OF-MONTHS
005409         MOVE ZERO              TO L1680-NUMBER-OF-DAYS
005409         PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409             THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
005409         MOVE L1680-INTERNAL-2  TO WLABR-CLI-LTST-DT
               MOVE WLABR-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6200-PROCESS-DELETE-X
557660     END-IF.

           IF  RLABR-RSLT-REC-CREAT-AUTO
               MOVE 'NS13800022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6200-PROCESS-DELETE-X
557660     END-IF.

           PERFORM  LABR-1000-DELETE
               THRU LABR-1000-DELETE-X.

      *** REDISPLAY BLANK SUMMARY SCREEN
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           SET WS-BUS-FCN-RETRIEVE TO TRUE.
           MOVE WS-BUS-FCN-ID      TO MIR-BUS-FCN-ID.

       6200-PROCESS-DELETE-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    PROCESS A DOCUMENT PRINT REQUEST - CREATE PRTX RECORD
      *----------------------------------------------------------------
       7000-PROCESS-DOCUMENT.

      *** EDIT DOCUMENT NAME
           MOVE MIR-DOC-ID            TO WDOCM-DOC-ID.
023447*    MOVE WGLOB-USER-LANG       TO WDOCM-DOC-LANG-CD.
           PERFORM  DOCM-1000-READ
               THRU DOCM-1000-READ-X.
           IF  NOT WDOCM-IO-OK
               MOVE 'NS13800020'      TO WGLOB-MSG-REF-INFO
               MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-DOCUMENT-X
           END-IF.

010418     PERFORM  0303-1000-BUILD-PARM-INFO
010418         THRU 0303-1000-BUILD-PARM-INFO-X.

010418     PERFORM  7100-GET-DFLT-SUB-CO
010418         THRU 7100-GET-DFLT-SUB-CO-X.

           MOVE 'PR'                  TO L0303-TRNXT-REC-CD.
           MOVE 'LR'                  TO L0303-TRNXT-TYP-CD.
           MOVE MIR-DOC-ID            TO L0303-DOC-ID.
           MOVE MIR-CLI-ID            TO L0303-CLI-ID.
012624*    MOVE 'NB'                  TO L0303-APPL-ID.
           MOVE SPACE                 TO L0303-PRTR-ID.
           MOVE SPACE                 TO L0303-POL-ID.
023447*    MOVE ZERO                  TO L0303-TRNXT-DOC-CPY-QTY-N.
023447*    MOVE WGLOB-USER-LANG       TO L0303-TRNXT-LANG-CD.

           PERFORM  0303-1000-WRITE-PRTX-TRAN
               THRU 0303-1000-WRITE-PRTX-TRAN-X.

           MOVE 'NS13800021'          TO WGLOB-MSG-REF-INFO.
           MOVE MIR-DOC-ID            TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE SPACE                 TO MIR-DOC-ID.

       7000-PROCESS-DOCUMENT-X.
           EXIT.
      *
      *--------------------------
010418 7100-GET-DFLT-SUB-CO.
      *--------------------------
010418
010418     PERFORM  3320-1000-BUILD-PARM-INFO
010418         THRU 3320-1000-BUILD-PARM-INFO-X.

010418     PERFORM  3320-1000-DEFAULT-SUB-CO
010418         THRU 3320-1000-DEFAULT-SUB-CO-X.

010418     IF  L3320-RETRN-OK
010418     AND L3320-RETRN-SBSDRY-CO-ID NOT = SPACES
010418         MOVE L3320-RETRN-SBSDRY-CO-ID TO L0303-SBSDRY-CO-ID
010418         GO TO 7100-GET-DFLT-SUB-CO-X
010418     END-IF.

010418     MOVE LOW-VALUES            TO WSCOM-KEY.
010418     MOVE HIGH-VALUES           TO WSCOM-ENDBR-KEY.
010418
010418     PERFORM  SCOM-1000-BROWSE
010418         THRU SCOM-1000-BROWSE-X.
010418
010418     IF  NOT WSCOM-IO-OK
010418         GO TO 7100-GET-DFLT-SUB-CO-X
010418     END-IF.
010418
010418     PERFORM  SCOM-2000-READ-NEXT
010418         THRU SCOM-2000-READ-NEXT-X.
010418
010418     IF  WSCOM-IO-OK
010418         MOVE RSCOM-SBSDRY-CO-ID TO L0303-SBSDRY-CO-ID
010418     END-IF.
010418
010418     PERFORM  SCOM-3000-END-BROWSE
010418         THRU SCOM-3000-END-BROWSE-X.
010418
010418 7100-GET-DFLT-SUB-CO-X.
010418     EXIT.
      *
      *----------------------------------------------------------------
      *    BUILD LABR READ KEY.
      *----------------------------------------------------------------
       8000-BUILD-LABR-KEY.

           MOVE MIR-CLI-ID            TO WLABR-CLI-ID.
           MOVE MIR-CLI-LTST-DT       TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE WWKDT-LOW-DT      TO L1640-INTERNAL-DATE
557660     END-IF.
           MOVE L1640-INTERNAL-DATE   TO WLABR-CLI-LTST-DT.
           MOVE MIR-LTST-ID           TO WLABR-LTST-ID.
           IF WS-BUS-FCN-CREATE
018633*        MOVE WS-WORK-CURR-SEQUENCE-NO-N
018633         MOVE LCOMM-CURR-SEQUENCE-NO-N
                                      TO WLABR-CLI-LTST-SEQ-NUM-N
018633*        MOVE WS-WORK-CURR-SEQUENCE-NO
018633         MOVE LCOMM-CURR-SEQUENCE-NO
                                      TO MIR-CLI-LTST-SEQ-NUM
           ELSE
556122         MOVE MIR-CLI-LTST-SEQ-NUM
                                      TO WLABR-CLI-LTST-SEQ-NUM
556122*        MOVE MIR-CLI-LTST-SEQ-NUM TO WLABR-CLI-LTST-SEQ-NUM-N
557660     END-IF.

       8000-BUILD-LABR-KEY-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    DISPLAY A TEST RESULT RANGE VALUE
      *----------------------------------------------------------------
       8100-DISPLAY-RESULT.

018645*    IF  RLABR-RSLT-PRECSN-QTY = 'A'
018645     IF  RLABR-TST-RSLT-TYP-CD = '1'
               IF WS-LABT-NOT-BROWSED
                   PERFORM  8200-READ-LABT-RANGES
                       THRU 8200-READ-LABT-RANGES-X
               END-IF
018645*        MOVE RLABT-RSLT-PRECSN-QTY-N
018645         MOVE RLABT-RSLT-PRECSN-QTY
                                      TO L0290-PRECISION
           ELSE
018645*        MOVE RLABR-RSLT-PRECSN-QTY-N
018645         MOVE RLABR-RSLT-PRECSN-QTY
                                      TO L0290-PRECISION
           END-IF.

008455*****IF  L0290-PRECISION = ZERO
008455*****    MOVE WLABR-RESULT-SIZE    TO L0290-LENGTH
008455*****ELSE
008455*****    COMPUTE L0290-LENGTH = WLABR-RESULT-SIZE -
008455*****                                L0290-PRECISION
008455*****END-IF.

018645*    MOVE LENGTH OF MIR-CLI-LTST-RSLT-CD
018645     MOVE LENGTH OF MIR-RSLT-QTY-TXT
                                      TO L0290-MAX-OUT-LEN.
           MOVE 'N'                   TO L0290-SIGN-IND.
013578*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.

           MOVE SPACES                TO L0290-OUTPUT-DATA.

020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

       8100-DISPLAY-RESULT-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    FIND RESULT PRECISION ON LABT
      *----------------------------------------------------------------
       8200-READ-LABT-RANGES.

      *** BROWSE LABT FILE TO FIND A MATCH ON LAB/TEST/HIGH AGE/SEX

           IF  MIR-CLI-SEX-CD = SPACES
               MOVE HIGH-VALUES       TO WS-SEX-CODE
           ELSE
               MOVE MIR-CLI-SEX-CD    TO WS-SEX-CODE
557660     END-IF.

           PERFORM  5307-BROWSE-LABT-FILE
               THRU 5307-BROWSE-LABT-FILE-X.

      *** IF NO LABT RECORD WAS FOUND, PERFORM ANOTHER SEARCH USING
      *** HIGH-VALUES IN THE SEX FIELD.

           IF  WS-LABT-REC-NOT-FND
               MOVE HIGH-VALUES       TO WS-SEX-CODE
               PERFORM  5307-BROWSE-LABT-FILE
                   THRU 5307-BROWSE-LABT-FILE-X
557660     END-IF.

       8200-READ-LABT-RANGES-X.
           EXIT.
      *
      *-----------------------------------------------------------------
      *    BLANK DATA FIELDS: SET EACH DATA (NON-KEY AND NON-CONTROL) FI
      *    THE SCREEN TO SPACES.
      *-----------------------------------------------------------------
       9100-BLANK-DATA-FIELDS.

           IF  WS-BUS-FCN-LIST
               PERFORM  9110-BLANK-DISPLAY-LINES
                   THRU 9110-BLANK-DISPLAY-LINES-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL (WS-LINE > WS-MAX-SCREEN-LINES)
           ELSE
               PERFORM  9120-BLANK-DETAIL-SCREEN
                   THRU 9120-BLANK-DETAIL-SCREEN-X
557660     END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH DISPLAY LINE TO BLANKS (RE-ORDERED FOR 5.3)
      *****************************************************************
       9110-BLANK-DISPLAY-LINES.

           MOVE SPACES                TO MIR-LTST-ID-T (WS-LINE).
           MOVE SPACES                TO MIR-CLI-LTST-DT-T (WS-LINE).
           MOVE SPACES                TO MIR-LTST-ID-T (WS-LINE).
           MOVE SPACES              TO MIR-CLI-LTST-SEQ-NUM-T (WS-LINE).
           MOVE SPACES              TO MIR-CLI-LTST-RSLT-CD-T (WS-LINE).
018645     MOVE SPACES              TO MIR-RSLT-QTY-TXT-T     (WS-LINE).
018645     MOVE SPACES              TO MIR-TST-RSLT-TYP-CD-T  (WS-LINE).
           MOVE SPACES              TO MIR-CLI-LTST-STAT-CD-T (WS-LINE).
           MOVE SPACES            TO MIR-STAT-CHNG-REASN-CD-T (WS-LINE).
           MOVE SPACES               TO MIR-CO-MIN-NRNG-QTY-T (WS-LINE).
           MOVE SPACES               TO MIR-CO-MAX-NRNG-QTY-T (WS-LINE).
           MOVE SPACES            TO MIR-ALPHA-RESP-CD-T (WS-LINE).
           MOVE SPACES             TO MIR-RSLT-REC-CREAT-CD-T (WS-LINE).

       9110-BLANK-DISPLAY-LINES-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH DISPLAY LINE TO BLANKS
      *****************************************************************
       9120-BLANK-DETAIL-SCREEN.

           MOVE SPACES                TO MIR-CLI-LTST-LAB-ID.
           MOVE SPACES                TO MIR-RSLT-REC-CREAT-CD.
           MOVE SPACES                TO MIR-BAD-LAB-INFO-IND.
           MOVE SPACES                TO MIR-LAB-GEN-REF-ID.
           MOVE SPACES                TO MIR-ETBL-DESC-TXT.
           MOVE SPACES                TO MIR-CLI-LTST-RSLT-CD.
018645     MOVE SPACES                TO MIR-RSLT-QTY-TXT.
018645     MOVE SPACES                TO MIR-TST-RSLT-TYP-CD.
           MOVE SPACES                TO MIR-CO-MIN-NRNG-QTY.
           MOVE SPACES                TO MIR-CO-MAX-NRNG-QTY.
           MOVE SPACES                TO MIR-LAB-MIN-NRNG-QTY.
           MOVE SPACES                TO MIR-LAB-MAX-NRNG-QTY.
           MOVE SPACES                TO MIR-UNIT-MESUR-TXT.
           MOVE SPACES                TO MIR-ALPHA-RESP-CD.
           MOVE SPACES                TO MIR-PREV-MEAL-DT.
           MOVE SPACES                TO MIR-PREV-MEAL-TIME.
           MOVE SPACES                TO MIR-SERUM-DESC-TXT.
           MOVE SPACES                TO MIR-BLOOD-DRW-DT.
           MOVE SPACES                TO MIR-BLOOD-DRW-TIME.
           MOVE SPACES                TO MIR-URIN-DESC-TXT.
           MOVE SPACES                TO MIR-SAMPL-VOID-DT.
           MOVE SPACES                TO MIR-CLI-LTST-STAT-CD.
           MOVE SPACES                TO MIR-STAT-CHNG-REASN-CD.
           MOVE SPACES                TO MIR-LAB-RMRK-NUM.
           MOVE SPACES                TO MIR-CLI-LTST-RMRK-TXT.

       9120-BLANK-DETAIL-SCREEN-X.
           EXIT.
      *
      *----------------------------------------------------------------
      * RECORD TO SCREEN:
      *----------------------------------------------------------------
       9200-MOVE-RECORD-TO-SCREEN.

           MOVE RLABR-CLI-LTST-LAB-ID TO MIR-CLI-LTST-LAB-ID.
           MOVE RLABR-RSLT-REC-CREAT-CD
                                      TO MIR-RSLT-REC-CREAT-CD.
           MOVE RLABR-BAD-LAB-INFO-IND          TO MIR-BAD-LAB-INFO-IND.
           MOVE RLABR-LAB-GEN-REF-ID  TO MIR-LAB-GEN-REF-ID.

           PERFORM  9212-GET-TEST-DESCRIPTION
               THRU 9212-GET-TEST-DESCRIPTION-X.

           IF  WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-ETBL-DESC-TXT
557660     END-IF.

           PERFORM  5500-FORMAT-RESULT
               THRU 5500-FORMAT-RESULT-X.
018645*    MOVE WS-DISPLAY-RESULT-R   TO MIR-CLI-LTST-RSLT-CD.
018645     IF  RLABR-TST-RSLT-TYP-CD = '2'
018645         MOVE WS-DISPLAY-RESULT-R
018645                                TO MIR-RSLT-QTY-TXT
018645         MOVE SPACE             TO MIR-CLI-LTST-RSLT-CD
018645     ELSE
018645         MOVE WS-DISPLAY-RESULT-R
018645                                TO MIR-CLI-LTST-RSLT-CD
018645         MOVE SPACE             TO MIR-RSLT-QTY-TXT
018645     END-IF.

           PERFORM  9221-LOAD-LAB-TEST-DATA
               THRU 9221-LOAD-LAB-TEST-DATA-X.

           MOVE RLABR-PREV-MEAL-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-MEAL-DT.

           MOVE RLABR-PREV-MEAL-TIME  TO MIR-PREV-MEAL-TIME.

           MOVE RLABR-BLOOD-DRW-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-BLOOD-DRW-DT.

           MOVE RLABR-BLOOD-DRW-TIME  TO MIR-BLOOD-DRW-TIME.

           MOVE RLABR-SAMPL-VOID-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-SAMPL-VOID-DT.

           MOVE RLABR-SERUM-DESC-TXT  TO MIR-SERUM-DESC-TXT.
           MOVE RLABR-URIN-DESC-TXT   TO MIR-URIN-DESC-TXT.
           MOVE RLABR-CLI-LTST-STAT-CD TO MIR-CLI-LTST-STAT-CD.
           MOVE RLABR-STAT-CHNG-REASN-CD TO MIR-STAT-CHNG-REASN-CD.
           MOVE SPACES                TO MIR-CLI-LTST-RMRK-TXT.

      *** IF REMARK ID IS SPACES THEN GET OUT.
           IF  RLABR-LAB-RMRK-NUM  = SPACES
           AND RLABR-CLI-LTST-RMRK-TXT = SPACES
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.

           MOVE RLABR-LAB-RMRK-NUM    TO MIR-LAB-RMRK-NUM.

           PERFORM  9222-LOAD-REMARKS
               THRU 9222-LOAD-REMARKS-X.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    GET TEST DESCRIPTION FROM EDIT
      *----------------------------------------------------------------
       9212-GET-TEST-DESCRIPTION.

           IF  RLABR-LTST-ID         NOT = WEDIT-ETBL-VALU-ID
               MOVE RLABR-LTST-ID     TO WEDIT-ETBL-VALU-ID
               PERFORM  TSTN-2000-DESC
                   THRU TSTN-2000-DESC-X
557660     END-IF.

       9212-GET-TEST-DESCRIPTION-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *    LOAD LAB TEST RANGE DATA FROM LABT FILE INTO DETAIL SCREEN
      *----------------------------------------------------------------
       9221-LOAD-LAB-TEST-DATA.

018645     MOVE RLABR-TST-RSLT-TYP-CD TO MIR-TST-RSLT-TYP-CD.
018645*    IF  RLABR-RSLT-PRECSN-QTY = SPACES
018645     IF  RLABR-TST-RSLT-TYP-CD = '3'
               GO TO 9221-LOAD-LAB-TEST-DATA-X
           END-IF.

           MOVE RLABR-ALPHA-RESP-CD   TO MIR-ALPHA-RESP-CD.

018645*    IF  RLABR-RSLT-PRECSN-ALPHA-VALUE
018645     IF  RLABR-TST-RSLT-TYP-CD = '1'
010311         MOVE SPACES            TO MIR-CO-MIN-NRNG-QTY
010311         MOVE SPACES            TO MIR-CO-MAX-NRNG-QTY
010311         MOVE SPACES            TO MIR-LAB-MIN-NRNG-QTY
010311         MOVE SPACES            TO MIR-LAB-MAX-NRNG-QTY
010311         MOVE SPACES            TO MIR-UNIT-MESUR-TXT
010311         GO TO 9221-LOAD-LAB-TEST-DATA-X
010311     END-IF.

           MOVE RLABR-CO-MIN-NRNG-QTY TO L0290-INPUT-NUMBER.
           MOVE 'N'                   TO WS-LABT-BROWSED-SW.
           PERFORM  8100-DISPLAY-RESULT
               THRU 8100-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CO-MIN-NRNG-QTY.

           MOVE RLABR-CO-MAX-NRNG-QTY TO L0290-INPUT-NUMBER.
           PERFORM  8100-DISPLAY-RESULT
               THRU 8100-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CO-MAX-NRNG-QTY.

           MOVE RLABR-LAB-MIN-NRNG-QTY TO L0290-INPUT-NUMBER.
           PERFORM  8100-DISPLAY-RESULT
               THRU 8100-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-LAB-MIN-NRNG-QTY.

           MOVE RLABR-LAB-MAX-NRNG-QTY TO L0290-INPUT-NUMBER.
           PERFORM  8100-DISPLAY-RESULT
               THRU 8100-DISPLAY-RESULT-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-LAB-MAX-NRNG-QTY.

           MOVE RLABR-UNIT-MESUR-TXT  TO MIR-UNIT-MESUR-TXT.

       9221-LOAD-LAB-TEST-DATA-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   LOAD THE REMARKS FROM EITHER THE LABR RECORD OR THE MESSAGE
      *   FILE
      *----------------------------------------------------------------
       9222-LOAD-REMARKS.

           IF RLABR-CLI-LTST-RMRK-TXT > SPACES
               MOVE RLABR-CLI-LTST-RMRK-TXT TO MIR-CLI-LTST-RMRK-TXT
               GO TO 9222-LOAD-REMARKS-X
557660     END-IF.

      *** OBTAIN COMMENT FROM MESSAGE FILE. IF NOT FOUND DISPLAY
      *** A MESSAGE.
           MOVE 'NSLABR'              TO WGLOB-MSG-REF-ID.
           MOVE RLABR-LAB-RMRK-NUM    TO WGLOB-MSG-REF-NUM.
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
           IF  WGLOB-MSG-REF-INFO       =  'XS00000000'
               MOVE WGLOB-COMPANY-CODE TO WS-HOLD-MSGS-COMPANY
023447*        MOVE WGLOB-USER-LANG   TO WS-HOLD-MSGS-LANG-CD
               MOVE WGLOB-MSG-SECUR-CLAS-CD
                                      TO WS-HOLD-MSGS-SECUR-CLAS-CD
               MOVE RLABR-LAB-RMRK-NUM TO WS-HOLD-NUMBER
               MOVE 'NSLABR'          TO WS-HOLD-SOURCE
               MOVE WS-HOLD-MSGS-KEY  TO WGLOB-MSG-PARM (1)
               MOVE 'NS13800026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-2000-GET-MESSAGE
                   THRU 0260-2000-GET-MESSAGE-X
               MOVE WGLOB-MSG-TXT     TO MIR-CLI-LTST-RMRK-TXT
           ELSE
               MOVE WGLOB-MSG-TXT     TO MIR-CLI-LTST-RMRK-TXT
557660     END-IF.

       9222-LOAD-REMARKS-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   LOAD THE INSURED'S NAME, SEX AND AGE INTO THE TOP OF THE
      *   SCREEN (WILL BE THE SAME REGARDLESS OF WHICH SCREEN, DETAIL
      *   OR SUMMARY, IS BEING DISPLAYED)
      *----------------------------------------------------------------
       9230-LOAD-INSURED-DATA.

           IF  MIR-CLI-ID NOT = L2437-CLI-ID
               MOVE MIR-CLI-ID        TO L2437-CLI-ID
               PERFORM  2437-1000-OBTAIN-CLI-INFO
                   THRU 2437-1000-OBTAIN-CLI-INFO-X
               IF L2437-RETRN-CLI-NOT-FOUND
                   GO TO 9230-LOAD-INSURED-DATA-X
               END-IF
           END-IF.

           MOVE L2437-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
557698*    MOVE L2437-CLI-CO-NM       TO L0620-CLI-CO-NM.
557698*    MOVE L2437-CLI-GIV-NM      TO L0620-CLI-GIV-NM.
557698*    MOVE L2437-CLI-SUR-NM      TO L0620-CLI-SUR-NM.
557698     MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM.
557698     MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM.
557698     MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM.
013578     MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM.
013578     MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM.

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-INSRD-CLI-NM.
           MOVE L2437-CLI-SEX-CD      TO MIR-CLI-SEX-CD.

           IF  L2437-CLI-BTH-DT  > WWKDT-ZERO-DT
               MOVE L2437-CLI-BTH-DT  TO L1680-INTERNAL-1
               MOVE WGLOB-SYSTEM-DATE-INT
                                      TO L1680-INTERNAL-2
               PERFORM  1680-2000-COMP-DAYS-BETWEEN
                   THRU 1680-2000-COMP-DAYS-BETWEEN-X
020874*        MOVE L1680-NUMBER-OF-YEARS
020874*                               TO WS-PIC-LEN3
020874*        MOVE WS-PIC-LEN3       TO MIR-DV-CLI-INSRD-AGE
020874         MOVE L1680-NUMBER-OF-YEARS TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DV-CLI-INSRD-AGE
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DV-CLI-INSRD-AGE
557660     END-IF.

       9230-LOAD-INSURED-DATA-X.
           EXIT.
018633*-------------------
018633*9500-BUILD-TWRK-KEY.
018633*-------------------
018633*
018633*    MOVE WS-TWRK-KEY
018633*      TO L8090-BUS-FCN-ID.
018633*    MOVE ZEROS
018633*      TO L8090-TEMP-WRK-SEQ-NUM.
018633*    SET L8090-USAGE-COMM TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9800-WRITE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*    MOVE 300
018633*      TO L8090-AREA-LEN.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9900-DELETE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
023118/
023118*--------------------------
023118 9990-INIT-WORKING-STORAGE.
023118*--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0303-0000-INIT-PARM-INFO
025970         THRU 0303-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0760-0000-INIT-PARM-INFO
025970         THRU 0760-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1030-0000-INIT-PARM-INFO
025970         THRU 1030-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  3320-0000-INIT-PARM-INFO
025970         THRU 3320-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7180-0000-INIT-PARM-INFO
025970         THRU 7180-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-SWITCHES.
025970     INITIALIZE                         WSTAT-WRK-INFO.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-MAX-SCREEN-LINES    TO TRUE.
025970
025970     MOVE SPACES                        TO WWKDT-WORK-FIELDS.
023118     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023118*
025970***  INITIALIZE VARIABLES NEEDED FOR THIS TRANSACTION
025970*
025970*    PERFORM  0290-1000-BUILD-PARM-INFO
025970*        THRU 0290-1000-BUILD-PARM-INFO-X.
025970*
025970*    PERFORM  2050-INITIALIZE
025970*        THRU 2050-INITIALIZE-X.
025970*
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.

      ****************************************************************
      * TRANSACTION PROCESSING COPYMEMBERS                           *
      ****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY NCPELABC.
      *
       COPY NCPETSTC.
      *
       COPY NCPETSTN.
      *
       COPY NCPETSTR.
      *
       COPY NCPPSTAT.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY LABR
014221                         '$VAR2' BY 'LABR'.
      *
025970 COPY XCPS1670.
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      *
      ****************************************************************
      * LINK PROCESSING COPYBOOKS                                    *
      ****************************************************************
       COPY CCPSPGA.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
008455 COPY XCPS0290.
       COPY XCPL0290.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
025970 COPY XCPS1680.
       COPY XCPL1680.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      *
014660*COPY XCPPMEXT.
      *
018764*COPY CCCL3320.
018764 COPY CCPL3320.
010418 COPY CCPS3320.
      *
018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY CCPNEDIT.
      *
023447*COPY NCPNDOCM.
023447 COPY XCPNDOCM.
      *
       COPY NCPALABR.
      *
       COPY NCPNLABR.
      *
       COPY NCPULABR.
      *
       COPY NCPVLABR.
      *
       COPY NCPXLABR.
      *
       COPY NCPCLABR.
      *
       COPY NCPBLABT.
      *
010418 COPY CCPBSCOM.
      *
018764*COPY NCCL0303.
018764 COPY NCPL0303.
010418 COPY NCPS0303.
      *
018764*COPY NCCL0760.
025970 COPY NCPS0760.
018764 COPY NCPL0760.
      *
       COPY NCPS1030.
018764*COPY NCCL1030.
018764 COPY NCPL1030.
      *
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
      *
       COPY NCPS7180.
018764*COPY NCCL7180.
018764 COPY NCPL7180.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM1380                     **
      *****************************************************************
