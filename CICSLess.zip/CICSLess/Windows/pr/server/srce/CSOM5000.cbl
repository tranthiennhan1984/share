      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5000.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5000                                         **
      **  REMARKS:  BANK INFORMATION MAINTENANCE.                    **
      **            THIS PROGRAM ALLOWS THE USER TO INQUIRE, BROWSE  **
      **            MODIFY, ADD, AND DELETE BANK TABLE RECORDS. THE  **
      **            BANK TABLE STORES VALID BANK AND BRANCH INFO.    **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CHANGE TO STANDARD                               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
557756**  5.5       ENHANCEMENTS FOR MULTI-LANGUAGE SUPPORT          **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
009026**  5.6       BANK#/BRANCH CODE MUST BE ENTERED                **
009027**  5.6       BANK/BRANCH NAME MUST BE FILLED ON CREATE        **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015509**  6.0       ADDRESS CHANGES FOR JAPAN                        **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023446**  6.5       ABA ROUTING NUMBER CHECK DIGIT                   **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5000'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

014221 COPY CCWWLOCK.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES            PIC S9(4)  BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT           VALUE +12.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                 VALUE '0980'.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-LIST-LINES            PIC S9(4)  VALUE +12  COMP.
016548*    05  WS-MAX-LIST-LINES            PIC S9(4)  VALUE +12
016548*                                     BINARY.
025970*    05  WS-MAX-LIST-LINES            PIC S9(4)  VALUE +12
025970*                                     BINARY.
013578*    05  WS-HOLD-ENTER-CODE           PIC X(01)  VALUE SPACES.
013578*        88  WS-HOLD-ENTER-CODE-VALID            VALUES ARE
013578*            'I', 'C', 'M', 'D', 'B'.
013578*        88  WS-HOLD-ENTER-INQUIRE               VALUE 'I'.
013578*        88  WS-HOLD-ENTER-CREATE                VALUE 'C'.
013578*        88  WS-HOLD-ENTER-MAINTAIN              VALUE 'M'.
013578*        88  WS-HOLD-ENTER-DELETE                VALUE 'D'.
013578*        88  WS-HOLD-ENTER-BROWSE                VALUE 'B'.
013578*        88  WS-ENTER-CODES-VALID                VALUE 'Y'.
013578     05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
013578         88  WS-BUS-FCN-VALID                    VALUES ARE
013578             '0980', '0981', '0982', '0983', '0984'.
013578         88  WS-BUS-FCN-RETRIEVE                 VALUE '0980'.
013578         88  WS-BUS-FCN-CREATE                   VALUE '0981'.
013578         88  WS-BUS-FCN-UPDATE                   VALUE '0982'.
013578         88  WS-BUS-FCN-DELETE                   VALUE '0983'.
013578         88  WS-BUS-FCN-LIST                     VALUE '0984'.
014221*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '0980'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '0980'.

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
       COPY XCWEBLCH.
      *
       COPY CCFWBNKB.
       COPY CCFRBNKB.
      *
014221 COPY XCWL8090.
      *
014588*COPY CCWCCOMM.
      *
      *
016537*COPY XCWWWKDT.
      *
557756*COPY CCWTYSNO.
      *
023446 COPY CCWLPGA.
023446 COPY XCWL0316.
023446 COPY CCWLBNKV.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.


007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM5000.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023446     PERFORM  9990-INIT-WORKING-STORAGE
023446         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    PROCESS SCREEN FUNCTIONS
      *
      *    DECIDE WHICH SCREEN TO DISPLAY.
      *

023446*    MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.

           IF  WS-BUS-FCN-RETRIEVE
               PERFORM  2100-PROCESS-RETRIEVE
                   THRU 2100-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-CREATE
               PERFORM  2200-PROCESS-CREATE
                   THRU 2200-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  2300-PROCESS-UPDATE
                   THRU 2300-PROCESS-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-DELETE
               PERFORM  2400-PROCESS-DELETE
                   THRU 2400-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  2500-PROCESS-LIST
                   THRU 2500-PROCESS-LIST-X
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------
       2100-PROCESS-RETRIEVE.
      *----------------------

           MOVE MIR-BNK-ID            TO WBNKB-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WBNKB-BNK-BR-ID.
014221*    PERFORM  BNKB-1000-READ
014221*        THRU BNKB-1000-READ-X.

014221     PERFORM  BNKB-1000-READ-TWRK-TS
014221         THRU BNKB-1000-READ-TWRK-TS-X.

           IF  WBNKB-IO-OK
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           ELSE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               MOVE WBNKB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2100-PROCESS-RETRIEVE-X.
           EXIT.

      *--------------------
       2200-PROCESS-CREATE.
      *--------------------

           MOVE MIR-BNK-ID            TO WBNKB-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WBNKB-BNK-BR-ID.
           PERFORM  BNKB-1000-READ
               THRU BNKB-1000-READ-X.

           IF  WBNKB-IO-OK
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE WBNKB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2200-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  2210-CREATE-EDITS
               THRU 2210-CREATE-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2200-PROCESS-CREATE-X
557660     END-IF.

           MOVE MIR-BNK-ID            TO WBNKB-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WBNKB-BNK-BR-ID.
           PERFORM  BNKB-1000-CREATE
               THRU BNKB-1000-CREATE-X.
           PERFORM  BNKB-1000-WRITE
               THRU BNKB-1000-WRITE-X.
014221     PERFORM  BNKB-1000-READ-TWRK-TS
014221         THRU BNKB-1000-READ-TWRK-TS-X.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2200-PROCESS-CREATE-X.
           EXIT.

      *------------------
       2210-CREATE-EDITS.
      *------------------
      *
      ***  THIS WILL BE COMPANY SPECIFIC LOGIC
009026     IF  MIR-BNK-ID = SPACE
009026         MOVE 'CS50000002'      TO WGLOB-MSG-REF-INFO
009026         PERFORM  0260-1000-GENERATE-MESSAGE
009026             THRU 0260-1000-GENERATE-MESSAGE-X
009026         GO TO 2210-CREATE-EDITS-X
009026     END-IF.
009026
009026     IF  MIR-BNK-BR-ID = SPACE
009026         MOVE 'CS50000002'      TO WGLOB-MSG-REF-INFO
009026         PERFORM  0260-1000-GENERATE-MESSAGE
009026             THRU 0260-1000-GENERATE-MESSAGE-X
009026         GO TO 2210-CREATE-EDITS-X
009026     END-IF.
009026
023446     PERFORM  4000-BNKV-REGION-EXIT
023446         THRU 4000-BNKV-REGION-EXIT-X.
023446
       2210-CREATE-EDITS-X.
           EXIT.
      /
      *--------------------
       2300-PROCESS-UPDATE.
      *--------------------

           PERFORM  2320-PROCESS-UPDATE
               THRU 2320-PROCESS-UPDATE-X.

       2300-PROCESS-UPDATE-X.
           EXIT.

      *--------------------
       2320-PROCESS-UPDATE.
      *--------------------

           MOVE MIR-BNK-ID            TO WBNKB-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WBNKB-BNK-BR-ID.
014221*    PERFORM  BNKB-1000-READ-FOR-UPDATE
014221*        THRU BNKB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  BNKB-2000-UPDATE-TWRK-TS
014221         THRU BNKB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'BNKB'                TO WGLOB-MSG-PARM (01)
014221        MOVE WBNKB-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 2320-PROCESS-UPDATE-X
014221     END-IF.

           IF  WBNKB-IO-NOT-FOUND
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               MOVE WBNKB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2320-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  2330-UPDATE-EDITS
               THRU 2330-UPDATE-EDITS-X.

           PERFORM  BNKB-2000-REWRITE
               THRU BNKB-2000-REWRITE-X.

014221     PERFORM  BNKB-1000-READ-TWRK-TS
014221         THRU BNKB-1000-READ-TWRK-TS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.

       2320-PROCESS-UPDATE-X.
           EXIT.

      *------------------
       2330-UPDATE-EDITS.
      *------------------

009027*    IF  MIR-BNK-NM = EBLCH-BLANK-FIELD-CHAR
009027*        MOVE SPACES                TO RBNKB-BNK-NM
009027*    ELSE
009027*        IF  MIR-BNK-NM > SPACES
009027*            MOVE MIR-BNK-NM        TO RBNKB-BNK-NM
009027*        END-IF
009027*    END-IF.
009027
009027     EVALUATE TRUE
009027
009027      WHEN MIR-BNK-NM = EBLCH-BLANK-FIELD-CHAR
009027       MOVE 'CS50000003'        TO WGLOB-MSG-REF-INFO
009027       PERFORM  0260-1000-GENERATE-MESSAGE
009027           THRU 0260-1000-GENERATE-MESSAGE-X
009027
009027      WHEN MIR-BNK-NM    = SPACE
009027      AND  RBNKB-BNK-NM  = SPACE
009027       MOVE 'CS50000003'        TO WGLOB-MSG-REF-INFO
009027       PERFORM  0260-1000-GENERATE-MESSAGE
009027           THRU 0260-1000-GENERATE-MESSAGE-X
009027
009027      WHEN MIR-BNK-NM = SPACE
009027       CONTINUE
009027
009027      WHEN OTHER
009027       MOVE MIR-BNK-NM          TO RBNKB-BNK-NM
009027
009027     END-EVALUATE.
009027
009027*    IF  MIR-BNK-BR-NM = EBLCH-BLANK-FIELD-CHAR
009027*        MOVE SPACES            TO RBNKB-BNK-BR-NM
009027*    ELSE
009027*        IF  MIR-BNK-BR-NM > SPACES
009027*            MOVE MIR-BNK-BR-NM TO RBNKB-BNK-BR-NM
009027*        END-IF
009027*    END-IF.
009027*
009027     EVALUATE TRUE
009027
009027      WHEN MIR-BNK-BR-NM = EBLCH-BLANK-FIELD-CHAR
009027       MOVE 'CS50000003'        TO WGLOB-MSG-REF-INFO
009027       PERFORM  0260-1000-GENERATE-MESSAGE
009027           THRU 0260-1000-GENERATE-MESSAGE-X
009027
009027      WHEN MIR-BNK-BR-NM = SPACE
009027      AND  RBNKB-BNK-BR-NM = SPACE
009027       MOVE 'CS50000003'        TO WGLOB-MSG-REF-INFO
009027       PERFORM  0260-1000-GENERATE-MESSAGE
009027           THRU 0260-1000-GENERATE-MESSAGE-X
009027
009027      WHEN MIR-BNK-BR-NM = SPACE
009027       CONTINUE
009027
009027      WHEN OTHER
009027       MOVE MIR-BNK-BR-NM       TO RBNKB-BNK-BR-NM
009027
009027     END-EVALUATE.
009027
           IF  MIR-BNK-BR-ADDR-1-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RBNKB-BNK-BR-ADDR-1-TXT
           ELSE
               IF  MIR-BNK-BR-ADDR-1-TXT > SPACES
                   MOVE MIR-BNK-BR-ADDR-1-TXT
                                      TO RBNKB-BNK-BR-ADDR-1-TXT
557660         END-IF
557660     END-IF.

           IF  MIR-BNK-BR-ADDR-2-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RBNKB-BNK-BR-ADDR-2-TXT
           ELSE
               IF  MIR-BNK-BR-ADDR-2-TXT > SPACES
                   MOVE MIR-BNK-BR-ADDR-2-TXT
                                      TO RBNKB-BNK-BR-ADDR-2-TXT
557660         END-IF
557660     END-IF.

015509     IF  MIR-BNK-BR-ADDR-3-TXT = EBLCH-BLANK-FIELD-CHAR
015509         MOVE SPACES            TO RBNKB-BNK-BR-ADDR-3-TXT
015509     ELSE
015509         IF  MIR-BNK-BR-ADDR-3-TXT > SPACES
015509             MOVE MIR-BNK-BR-ADDR-3-TXT
015509                                TO RBNKB-BNK-BR-ADDR-3-TXT
015509         END-IF
015509     END-IF.

           IF  MIR-BNK-BR-CITY-NM-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RBNKB-BNK-BR-CITY-NM-TXT
           ELSE
               IF  MIR-BNK-BR-CITY-NM-TXT > SPACES
                   MOVE MIR-BNK-BR-CITY-NM-TXT
                                      TO RBNKB-BNK-BR-CITY-NM-TXT
557660         END-IF
557660     END-IF.

           IF  MIR-BNK-BR-LOC-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RBNKB-BNK-BR-LOC-TXT
           ELSE
               IF  MIR-BNK-BR-LOC-TXT > SPACES
                   MOVE MIR-BNK-BR-LOC-TXT
                                      TO RBNKB-BNK-BR-LOC-TXT
557660         END-IF
557660     END-IF.

           IF  MIR-BNK-BR-PSTL-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RBNKB-BNK-BR-PSTL-CD
           ELSE
               IF  MIR-BNK-BR-PSTL-CD > SPACES
                   MOVE MIR-BNK-BR-PSTL-CD
                                      TO RBNKB-BNK-BR-PSTL-CD
557660         END-IF
557660     END-IF.

015509     IF  MIR-BNK-BR-JP-ADDR-CD = EBLCH-BLANK-FIELD-CHAR
015509         MOVE SPACES            TO RBNKB-BNK-BR-JP-ADDR-CD
015509     ELSE
015509         IF  MIR-BNK-BR-JP-ADDR-CD > SPACES
015509             MOVE MIR-BNK-BR-JP-ADDR-CD
015509                                TO RBNKB-BNK-BR-JP-ADDR-CD
015509         END-IF
557660     END-IF.

           IF  MIR-BNK-BR-LANG-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RBNKB-BNK-BR-LANG-CD
           ELSE
               IF  MIR-BNK-BR-LANG-CD > SPACES
                   MOVE MIR-BNK-BR-LANG-CD
                                      TO RBNKB-BNK-BR-LANG-CD
557660         END-IF
557660     END-IF.

           IF  MIR-BNK-BR-CTRY-NM-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RBNKB-BNK-BR-CITY-NM-TXT
           ELSE
               IF  MIR-BNK-BR-CTRY-NM-TXT > SPACES
                   MOVE MIR-BNK-BR-CTRY-NM-TXT
                                      TO RBNKB-BNK-BR-CTRY-NM-TXT
557660         END-IF
557660     END-IF.

           IF  MIR-BNK-BR-STAT-CD   = 'A'
           OR  MIR-BNK-BR-STAT-CD   = 'C'
               MOVE MIR-BNK-BR-STAT-CD TO RBNKB-BNK-BR-STAT-CD
           ELSE
               MOVE 'CS50000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

023446     IF  MIR-BNK-BR-PAPR-IND = 'Y'
023446     OR  MIR-BNK-BR-PAPR-IND = 'N'
023446         MOVE MIR-BNK-BR-PAPR-IND
023446                                 TO RBNKB-BNK-BR-PAPR-IND
023446     ELSE
023446         MOVE 'CS50000004'       TO WGLOB-MSG-REF-INFO
023446         PERFORM  0260-1000-GENERATE-MESSAGE
023446             THRU 0260-1000-GENERATE-MESSAGE-X
023446     END-IF.

023446     PERFORM  4000-BNKV-REGION-EXIT
023446         THRU 4000-BNKV-REGION-EXIT-X.
023446
       2330-UPDATE-EDITS-X.
           EXIT.

      *--------------------
       2400-PROCESS-DELETE.
      *--------------------

           PERFORM  2420-PROCESS-DELETE
               THRU 2420-PROCESS-DELETE-X.

       2400-PROCESS-DELETE-X.
           EXIT.

      *--------------------
       2420-PROCESS-DELETE.
      *--------------------

           MOVE MIR-BNK-ID            TO WBNKB-BNK-ID.
           MOVE MIR-BNK-BR-ID         TO WBNKB-BNK-BR-ID.
014221*    PERFORM  BNKB-1000-READ-FOR-UPDATE
014221*        THRU BNKB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  BNKB-2000-UPDATE-TWRK-TS
014221         THRU BNKB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'BNKB'                TO WGLOB-MSG-PARM (01)
014221        MOVE WBNKB-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 2420-PROCESS-DELETE-X
014221     END-IF.

           IF  WBNKB-IO-OK
               PERFORM  BNKB-1000-DELETE
                    THRU BNKB-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE WBNKB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.


       2420-PROCESS-DELETE-X.
           EXIT.

      *------------------
       2500-PROCESS-LIST.
      *------------------

           MOVE SPACES            TO MIR-BNK-ID-G.
           MOVE SPACES            TO MIR-BNK-BR-ID-G.
           MOVE SPACES            TO MIR-BNK-BR-STAT-CD-G.
           MOVE SPACES            TO MIR-BNK-NM-G.
           MOVE SPACES            TO MIR-BNK-BR-ADDR-1-TXT-G.
           MOVE SPACES            TO MIR-BNK-BR-CITY-NM-TXT-G.

           IF  MIR-BNK-ID =  SPACES
               MOVE LOW-VALUES        TO WBNKB-BNK-ID
           ELSE
               MOVE MIR-BNK-ID        TO WBNKB-BNK-ID
557660     END-IF.
           IF  MIR-BNK-BR-ID = SPACES
               MOVE LOW-VALUES        TO WBNKB-BNK-BR-ID
           ELSE
               MOVE MIR-BNK-BR-ID     TO WBNKB-BNK-BR-ID
557660     END-IF.
           MOVE HIGH-VALUES           TO WBNKB-ENDBR-BNK-ID.
           MOVE HIGH-VALUES           TO WBNKB-ENDBR-BNK-BR-ID.

           PERFORM  BNKB-1000-BROWSE
               THRU BNKB-1000-BROWSE-X.

           IF  WBNKB-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2500-PROCESS-LIST-X
            ELSE
               PERFORM  BNKB-2000-READ-NEXT
                   THRU BNKB-2000-READ-NEXT-X
               IF  WBNKB-IO-EOF
                   PERFORM  BNKB-3000-END-BROWSE
                       THRU BNKB-3000-END-BROWSE-X
                   MOVE 'XS00000025'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2500-PROCESS-LIST-X
557660         END-IF
557660     END-IF.

           PERFORM  2520-PROCESS-LIST
               THRU 2520-PROCESS-LIST-X
                    VARYING WS-SUB FROM +1 BY +1
                      UNTIL WS-SUB > WS-MAX-LIST-LINES
                         OR WBNKB-IO-EOF.

           IF  WBNKB-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  BNKB-3000-END-BROWSE
               THRU BNKB-3000-END-BROWSE-X.

       2500-PROCESS-LIST-X.
           EXIT.

      *------------------
       2520-PROCESS-LIST.
      *------------------

           MOVE RBNKB-BNK-ID     TO MIR-BNK-ID-T    (WS-SUB).
           MOVE RBNKB-BNK-BR-ID  TO MIR-BNK-BR-ID-T (WS-SUB).
           MOVE RBNKB-BNK-BR-STAT-CD
                                 TO MIR-BNK-BR-STAT-CD-T  (WS-SUB).
           MOVE RBNKB-BNK-NM     TO MIR-BNK-NM-T    (WS-SUB).
           MOVE RBNKB-BNK-BR-ADDR-1-TXT
                                 TO MIR-BNK-BR-ADDR-1-TXT-T (WS-SUB).
           MOVE RBNKB-BNK-BR-CITY-NM-TXT
                                 TO MIR-BNK-BR-CITY-NM-TXT-T (WS-SUB).


           IF  WS-SUB = WS-MAX-LIST-LINES
               MOVE RBNKB-BNK-ID       TO MIR-BNK-ID
               MOVE RBNKB-BNK-BR-ID    TO MIR-BNK-BR-ID
557660     END-IF.

           PERFORM  BNKB-2000-READ-NEXT
               THRU BNKB-2000-READ-NEXT-X.

       2520-PROCESS-LIST-X.
           EXIT.
023446/
023446*-----------------------
023446 4000-BNKV-REGION-EXIT.
023446*-----------------------
023446*
023446     PERFORM  0316-1000-BUILD-PARM-INFO
023446         THRU 0316-1000-BUILD-PARM-INFO-X.
023446
023446     SET  L0316-RGN-EXIT-PRFL-BNK-VERIF  TO TRUE.
023446     MOVE WGLOB-COUNTRY-CODE             TO L0316-CTRY-CD.
023446
023446     PERFORM  0316-1000-GET-RGN-EXIT-PGM
023446         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
023446
023446     IF  L0316-RETRN-NOT-FOUND
023446         MOVE 'CS50000005'       TO WGLOB-MSG-REF-INFO
023446         PERFORM  0260-1000-GENERATE-MESSAGE
023446             THRU 0260-1000-GENERATE-MESSAGE-X
023446         GO TO 4000-BNKV-REGION-EXIT-X
023446     END-IF.
023446
023446     IF  L0316-RETRN-INVALID-REQUEST
023446         SET WGLOB-RETURN-ERROR TO TRUE
023446         GO TO 4000-BNKV-REGION-EXIT-X
023446     END-IF.
023446
023446     IF  L0316-RGN-EXIT-STAT-ACTV
023446         PERFORM  4100-REGIONAL-BNKV-EDITS
023446             THRU 4100-REGIONAL-BNKV-EDITS-X
023446     ELSE
023446* MSG : (@1) REGIONAL EXIT STATUS IS INACTIVE
023446        MOVE 'CS50000006'       TO WGLOB-MSG-REF-INFO
023446        MOVE L0316-RGN-EXIT-ID  TO WGLOB-MSG-PARM (1)
023446        PERFORM  0260-1000-GENERATE-MESSAGE
023446            THRU 0260-1000-GENERATE-MESSAGE-X
023446     END-IF.
023446
023446 4000-BNKV-REGION-EXIT-X.
023446     EXIT.
023446/
023446*--------------------------
023446 4100-REGIONAL-BNKV-EDITS.
023446*--------------------------
023446*
023446     PERFORM  BNKV-0000-INIT-PARM-INFO
023446         THRU BNKV-0000-INIT-PARM-INFO-X.
023446
023446     MOVE MIR-BNK-ID        TO LBNKV-BNK-ID.
023446     MOVE MIR-BNK-BR-ID     TO LBNKV-BNK-BR-ID.
023446
023446     PERFORM  BNKV-1000-BANK-CHECK
023446         THRU BNKV-1000-BANK-CHECK-X.
023446
023446     IF  NOT LBNKV-RETRN-OK
023446         SET WGLOB-RETURN-ERROR TO TRUE
023446     END-IF.
023446
023446 4100-REGIONAL-BNKV-EDITS-X.
023446     EXIT.
023446/
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-BNK-NM.
           MOVE SPACES                TO MIR-BNK-BR-NM.
           MOVE SPACES                TO MIR-BNK-BR-ADDR-1-TXT.
           MOVE SPACES                TO MIR-BNK-BR-ADDR-2-TXT.
015509     MOVE SPACES                TO MIR-BNK-BR-ADDR-3-TXT.
           MOVE SPACES                TO MIR-BNK-BR-CITY-NM-TXT.
           MOVE SPACES                TO MIR-BNK-BR-LOC-TXT.
           MOVE SPACES                TO MIR-BNK-BR-PSTL-CD.
015509     MOVE SPACES                TO MIR-BNK-BR-JP-ADDR-CD.
           MOVE SPACES                TO MIR-BNK-BR-CTRY-NM-TXT.
           MOVE SPACES                TO MIR-BNK-BR-STAT-CD.
           MOVE SPACES                TO MIR-BNK-BR-LANG-CD.
023446     MOVE SPACES                TO MIR-BNK-BR-PAPR-IND.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RBNKB-BNK-ID          TO MIR-BNK-ID
           MOVE RBNKB-BNK-BR-ID       TO MIR-BNK-BR-ID.
           MOVE RBNKB-BNK-NM          TO MIR-BNK-NM.
           MOVE RBNKB-BNK-BR-ADDR-1-TXT
                                      TO MIR-BNK-BR-ADDR-1-TXT.
           MOVE RBNKB-BNK-BR-ADDR-2-TXT
                                      TO MIR-BNK-BR-ADDR-2-TXT.
015509     MOVE RBNKB-BNK-BR-ADDR-3-TXT
015509                                TO MIR-BNK-BR-ADDR-3-TXT.
           MOVE RBNKB-BNK-BR-NM       TO MIR-BNK-BR-NM.
           MOVE RBNKB-BNK-BR-CITY-NM-TXT
                                      TO MIR-BNK-BR-CITY-NM-TXT.
           MOVE RBNKB-BNK-BR-LOC-TXT  TO MIR-BNK-BR-LOC-TXT.
           MOVE RBNKB-BNK-BR-PSTL-CD  TO MIR-BNK-BR-PSTL-CD.
015509     MOVE RBNKB-BNK-BR-JP-ADDR-CD  TO MIR-BNK-BR-JP-ADDR-CD.
           MOVE RBNKB-BNK-BR-CTRY-NM-TXT
                                      TO MIR-BNK-BR-CTRY-NM-TXT.
           MOVE RBNKB-BNK-BR-STAT-CD  TO MIR-BNK-BR-STAT-CD.
           MOVE RBNKB-BNK-BR-LANG-CD  TO MIR-BNK-BR-LANG-CD.
023446     MOVE RBNKB-BNK-BR-PAPR-IND TO MIR-BNK-BR-PAPR-IND.


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023446/
023446*--------------------------
023446 9990-INIT-WORKING-STORAGE.
023446*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023446
025970     PERFORM  0316-0000-INIT-PARM-INFO
025970         THRU 0316-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  BNKV-0000-INIT-PARM-INFO
025970         THRU BNKV-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
023446
023446     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023446     SET  MIR-RETRN-OK               TO TRUE.
023446
023446 9990-INIT-WORKING-STORAGE-X.
023446     EXIT.
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.

014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY BNKB
014221                         '$VAR2' BY 'BNKB'.

       COPY XCPPEXIT.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.

023446 COPY XCPL0316.
025970 COPY XCPS8090.
023446 COPY XCPS0316.
023446 COPY CCPLBNKV.
023446 COPY CCPSBNKV.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNBNKB.
       COPY CCPUBNKB.
       COPY CCPABNKB.
       COPY CCPBBNKB.
       COPY CCPCBNKB.
       COPY CCPXBNKB.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM5000                     **
      *****************************************************************
