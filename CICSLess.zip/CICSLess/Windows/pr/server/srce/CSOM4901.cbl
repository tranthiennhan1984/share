      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4901.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4901                                         **
      **  REMARKS:  THIS MODULE PROVIDES A LIST OF THE VALID BILLING **
      **            MODES AND METHODS FOR THE BASE PLAN              **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       ORIGINAL - NEW FOR RELEASE 6.0                   **
006002**  6.0       REPLACE TEXT TABLE BY DMAD                       **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
016051**  6.1       CHANGES FOR APPLICATION FLOW                     **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018770**  6.3       PCR - ALLOWABLE VALUE EDIT                       **
019605**  6.3       INITIALIZE MODE DESCRIPTION                      **
015703**  6.4       REMOVE CCWLPGA                                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4901'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-RETRIEVE                 VALUE '4901'.
016548*    05  WS-SUB                                  PIC S9(04)  COMP.
016548     05  WS-SUB                                  PIC S9(04)
016548                                                 BINARY.
016548*    05  WS-SUB1                                 PIC S9(04)  COMP.
016548     05  WS-SUB1                                 PIC S9(04)
016548                                                 BINARY.
016548*    05  WS-MAX-LIST-LINES                       PIC S9(04) COMP
025970*    05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970*                                                VALUE 50.
           05  WS-METHOD-MODE.
               10  WS-METHOD                           PIC X(01).
                   88  WS-METHOD-NOT-PENDING           VALUE '7' '8'
                                                             '9'.
               10  WS-MODE                             PIC X(02).
           05  WS-METHOD-MODE-TXT.
               10  WS-METHOD-TXT                       PIC X(50).
               10  WS-MODE-TXT                         PIC X(50).
025970
025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970                                                 VALUE 50.
025970         88  WS-MAX-LIST-LINES-DEFAULT           VALUE 50.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY CCWWFRMT.
       COPY CCWWINDX.
016537*COPY XCWEBLCH.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPBTM.
       COPY CCFRPBTM.
      /
018770*COPY XCFRDMAD.
018770*COPY XCFWDMAD.
018770*
       COPY CCWWCVGS.
      /
015703*COPY CCWLPGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
028298 COPY CCWL2626.
       COPY CCWL3330.
      /
       COPY XCWL0015.
018770 COPY XCWL8960.
016537*COPY XCWLDTLK.
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4901.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4901'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------
       2000-RETRIEVE.
      *--------------

025970*    SET MIR-RETRN-OK            TO TRUE.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.
      *
      *  READ THE PH FOR THE BASE PLAN CODE
      *
           MOVE RPOL-PLAN-ID           TO WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  NOT WPH-IO-OK
      *MSG: PLAN (@1) NOT FOUND
               MOVE 'CS49010001'       TO WGLOB-MSG-REF-INFO
               MOVE WPH-KEY            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.
      *
      *  CALL 3330 TO GET THE LOCATION GROUP
      *
           MOVE ZEROS                  TO I.
           PERFORM  3330-1000-BUILD-PARM-INFO
               THRU 3330-1000-BUILD-PARM-INFO-X.
           SET L3330-LOC-GR-TYP-BTMOD  TO TRUE.
           PERFORM  3330-1000-GET-LOC-GROUP
               THRU 3330-1000-GET-LOC-GROUP-X.

           IF  L3330-RETRN-OK
               MOVE L3330-LOC-GR-ID    TO WPBTM-LOC-GR-ID
               MOVE L3330-LOC-GR-ID    TO WPBTM-ENDBR-LOC-GR-ID
           ELSE
      *MSG: LOCATION GROUP NOT FOUND FOR 'BTMOD'
               MOVE 'CS49010002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.
      *
      *  BROWSE THE PBTM TABLE BY PLAN AND LOCATION GROUP
      *
           MOVE LOW-VALUES             TO WPBTM-KEY.
           MOVE HIGH-VALUES            TO WPBTM-ENDBR-KEY.
           MOVE RPH-PLAN-ID            TO WPBTM-PLAN-ID.
           MOVE RPH-PLAN-ID            TO WPBTM-ENDBR-PLAN-ID.
016051     MOVE L3330-LOC-GR-ID        TO WPBTM-LOC-GR-ID.
016051     MOVE L3330-LOC-GR-ID        TO WPBTM-ENDBR-LOC-GR-ID.

           PERFORM  PBTM-1000-BROWSE
               THRU PBTM-1000-BROWSE-X.

           PERFORM  PBTM-2000-READ-NEXT
               THRU PBTM-2000-READ-NEXT-X.

           IF  WPBTM-IO-EOF
               PERFORM  PBTM-3000-END-BROWSE
                   THRU PBTM-3000-END-BROWSE-X
      *MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

016051     MOVE ZEROS                   TO  WS-SUB.

           PERFORM  2100-GET-MODE-AND-METHOD-TXT
               THRU 2100-GET-MODE-AND-METHOD-TXT-X
016051*      VARYING WS-SUB FROM 1 BY 1
016051*        UNTIL WS-SUB > WS-MAX-LIST-LINES
016051         UNTIL WS-SUB = WS-MAX-LIST-LINES
                  OR WPBTM-IO-EOF.

           IF  WPBTM-IO-EOF
               CONTINUE
           ELSE
      *        SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG: MORE DATA EXISTS
               MOVE 'XS00000014'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PBTM-3000-END-BROWSE
               THRU PBTM-3000-END-BROWSE-X.

       2000-RETRIEVE-X.
           EXIT.
      /
      *-----------------------------
       2100-GET-MODE-AND-METHOD-TXT.
      *-----------------------------

           MOVE RPBTM-PLAN-BILL-TYP-CD  TO WS-METHOD.
           MOVE RPBTM-PLAN-BILL-MODE-CD TO WS-MODE.

016051     IF RPOL-POL-STAT-BEFORE-SETL
016051        IF  WS-METHOD-NOT-PENDING
016051            PERFORM  PBTM-2000-READ-NEXT
016051                THRU PBTM-2000-READ-NEXT-X
016051            GO TO 2100-GET-MODE-AND-METHOD-TXT-X
016051        END-IF
016051     END-IF.

016051     ADD +1                       TO  WS-SUB.
           MOVE WS-METHOD-MODE          TO MIR-DV-SBOX-CD-T (WS-SUB).

           PERFORM  2110-GET-METHOD-TXT
               THRU 2110-GET-METHOD-TXT-X.

           PERFORM  2120-GET-MODE-TXT
               THRU 2120-GET-MODE-TXT-X.

           MOVE SPACES                  TO  L0015-COMP-AREA-IN.
           MOVE SPACES                  TO  L0015-COMP-AREA-OUT.
           MOVE WS-METHOD-MODE-TXT      TO  L0015-COMP-AREA-IN.

           PERFORM  0015-1000-COMPRESS-BLANKS
               THRU 0015-1000-COMPRESS-BLANKS-X.

           MOVE L0015-COMP-AREA-OUT     TO  MIR-DV-SBOX-DESC-TXT-T
                                            (WS-SUB).

           PERFORM  PBTM-2000-READ-NEXT
               THRU PBTM-2000-READ-NEXT-X.

       2100-GET-MODE-AND-METHOD-TXT-X.
           EXIT.
      /
      *--------------------
       2110-GET-METHOD-TXT.
      *--------------------

018770*    MOVE RPBTM-PLAN-BILL-TYP-CD  TO WDMAD-DM-AV-CD.
018770*    MOVE 'PLAN-BILL-TYP-CD'      TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE WGLOB-USER-LANG         TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM  DMAD-1000-READ
018770*        THRU DMAD-1000-READ-X.
018770*
018770*    IF  WDMAD-IO-OK
018770*        MOVE RDMAD-DM-AV-DESC-TXT TO WS-METHOD-TXT
018770*    END-IF.
018770*
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770     MOVE 'PLAN-BILL-TYP-CD'      TO L8960-AV-TBL-CD.
018770     MOVE RPBTM-PLAN-BILL-TYP-CD  TO L8960-AV-CD.
018770
018770     PERFORM  8960-2000-RETRIEVE-CODE-DESC
018770         THRU 8960-2000-RETRIEVE-CODE-DESC-X.
018770
018770     IF  L8960-RETRN-OK
018770         MOVE L8960-AV-DESC-TXT   TO WS-METHOD-TXT
018770     END-IF.

       2110-GET-METHOD-TXT-X.
           EXIT.
      /
      *------------------
       2120-GET-MODE-TXT.
      *------------------

           IF  RPBTM-PLAN-BILL-TYP-CD = 'P'
019605          MOVE SPACES             TO WS-MODE-TXT
                GO TO 2120-GET-MODE-TXT-X
           END-IF.

018770*    MOVE RPBTM-PLAN-BILL-MODE-CD TO WDMAD-DM-AV-CD.
018770*    MOVE 'PLAN-BILL-MODE-CD'     TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE WGLOB-USER-LANG         TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM  DMAD-1000-READ
018770*        THRU DMAD-1000-READ-X.
018770*
018770*    IF  WDMAD-IO-OK
018770*        MOVE RDMAD-DM-AV-DESC-TXT TO WS-MODE-TXT
018770*    END-IF.
018770*
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770     MOVE 'PLAN-BILL-MODE-CD'     TO L8960-AV-TBL-CD.
018770     MOVE RPBTM-PLAN-BILL-MODE-CD TO L8960-AV-CD.
018770
018770     PERFORM  8960-2000-RETRIEVE-CODE-DESC
018770         THRU 8960-2000-RETRIEVE-CODE-DESC-X.
018770
018770     IF  L8960-RETRN-OK
018770         MOVE L8960-AV-DESC-TXT   TO WS-MODE-TXT
018770     END-IF.
018770
       2120-GET-MODE-TXT-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE MIR-POL-ID          TO WPOL-POL-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES              TO MIR-DV-SBOX-CD-G.
           MOVE SPACES              TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
      *
      * FOR POLICY RELATED TRANSACTION
      *
           SET  WGLOB-REF-POLICY          TO TRUE.

           MOVE MIR-POL-ID                TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0015-0000-INIT-PARM-INFO
025970         THRU 0015-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3330-0000-INIT-PARM-INFO
025970         THRU 3330-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970
025970     SET  WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970
025970     MOVE SPACES                      TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPS3330.
      /
025970 COPY XCPS0015.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0015.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
018764*COPY CCCL3330.
018764 COPY CCPL3330.
      /
       COPY CCPPMIDT.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018770 COPY XCPS8960.
018770 COPY XCPL8960.
018770
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
       COPY CCPNPOL.
      /
       COPY CCPNPH.
      /
       COPY CCPBPBTM.
016537*COPY CCPNPBTM.
      /
018770*COPY XCPNDMAD.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4901                     **
      *****************************************************************
