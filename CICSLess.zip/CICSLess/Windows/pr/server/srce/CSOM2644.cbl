      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM2644.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2644                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE PBMF TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2644'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '2644'.
           05  WS-SUB                                PIC S9(04) BINARY.
           05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPBMF.
       COPY CCFRPBMF.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL0290.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2644.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
           
           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
           SET  MIR-RETRN-OK                  TO TRUE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2644'           TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           IF  MIR-PLAN-ID = SPACES
           OR  MIR-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG:    PLAN ID IS REQUIRED
               MOVE 'CS26440001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PBMF-1000-BROWSE
               THRU PBMF-1000-BROWSE-X.

           PERFORM  PBMF-2000-READ-NEXT
               THRU PBMF-2000-READ-NEXT-X.

           IF  NOT WPBMF-IO-OK
               PERFORM  PBMF-3000-END-BROWSE
                   THRU PBMF-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-LIST-X
           END-IF.

      *  SET THE NUMBER OF LIST LINES USING MIR FIELD OCCURENCES

           COMPUTE WS-MAX-LIST-LINES
                 = LENGTH OF MIR-PLAN-BMF-TYP-CD-G
                 / LENGTH OF MIR-PLAN-BMF-TYP-CD-T (1).

           PERFORM  2010-BUILD-LIST-SCREEN
               THRU 2010-BUILD-LIST-SCREEN-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      NOT WPBMF-IO-OK.

           IF  WPBMF-IO-EOF
               MOVE 'XS00000015'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPBMF-PLAN-ID           TO MIR-PLAN-ID
               MOVE RPBMF-PLAN-BMF-BILL-CD  TO MIR-PLAN-BMF-BILL-CD
               MOVE RPBMF-PLAN-BMF-MODE-CD  TO MIR-PLAN-BMF-MODE-CD
               MOVE RPBMF-PLAN-BMF-TYP-CD   TO MIR-PLAN-BMF-TYP-CD
           END-IF.

           PERFORM  PBMF-3000-END-BROWSE
               THRU PBMF-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BUILD-LIST-SCREEN.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PBMF-2000-READ-NEXT
               THRU PBMF-2000-READ-NEXT-X.

       2010-BUILD-LIST-SCREEN-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES                   TO WPBMF-KEY.
           MOVE MIR-PLAN-ID                  TO WPBMF-PLAN-ID.

           IF  MIR-PLAN-BMF-BILL-CD  = SPACES
           OR  MIR-PLAN-BMF-BILL-CD  = EBLCH-BLANK-FIELD-CHAR
               CONTINUE
           ELSE
               MOVE MIR-PLAN-BMF-BILL-CD     TO WPBMF-PLAN-BMF-BILL-CD
           END-IF.

           IF  MIR-PLAN-BMF-MODE-CD  = SPACES
           OR  MIR-PLAN-BMF-MODE-CD  = EBLCH-BLANK-FIELD-CHAR
               CONTINUE
           ELSE
               MOVE MIR-PLAN-BMF-MODE-CD     TO WPBMF-PLAN-BMF-MODE-CD
           END-IF.

           IF  MIR-PLAN-BMF-TYP-CD   = SPACES
           OR  MIR-PLAN-BMF-TYP-CD   = EBLCH-BLANK-FIELD-CHAR
               CONTINUE
           ELSE
               MOVE MIR-PLAN-BMF-TYP-CD      TO WPBMF-PLAN-BMF-TYP-CD
           END-IF.

           MOVE WPBMF-KEY                    TO WPBMF-ENDBR-KEY.
           MOVE HIGH-VALUES             TO WPBMF-ENDBR-PLAN-BMF-BILL-CD.
           MOVE HIGH-VALUES             TO WPBMF-ENDBR-PLAN-BMF-MODE-CD.
           MOVE HIGH-VALUES             TO WPBMF-ENDBR-PLAN-BMF-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RPBMF-PLAN-BMF-BILL-CD
                   TO MIR-PLAN-BMF-BILL-CD-T (WS-SUB).
           MOVE RPBMF-PLAN-BMF-MODE-CD
                   TO MIR-PLAN-BMF-MODE-CD-T (WS-SUB).
           MOVE RPBMF-PLAN-BMF-TYP-CD
                   TO MIR-PLAN-BMF-TYP-CD-T  (WS-SUB).

           MOVE RPBMF-PLAN-BMF-FCT TO L0290-INPUT-V07.

           MOVE 7                  TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PLAN-BMF-FCT-T (WS-SUB)
                                   TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA  TO MIR-PLAN-BMF-FCT-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
    
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE   WS-WORKING-STORAGE.
025970*    CONTINUE.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
           
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
       COPY XCPS0290.
       COPY XCPL0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBPBMF.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2644                      *
      *****************************************************************
