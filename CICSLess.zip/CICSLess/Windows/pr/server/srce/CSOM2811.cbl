      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2811.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2811                                         **
      **  REMARKS:  CREATE PROCESS DRIVER FOR THE SPECIFIC           **
      **            ROLLOVER DESTINATION INSTRUCTIONS                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
025999**  6.6       MESSAGE CORRECTION                               **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2811'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '2810'.
025970     05  WS-MAX-LINES                     PIC S9(03) COMP-3.
025970         88  WS-MAX-LINES-DEFAULT         VALUE +10.
025970*    05  WS-TWRK-KEY                      PIC X(04)
025970*                                         VALUE '2810'.
025970*    05  WS-MAX-LINES                     PIC S9(03) COMP-3
025970*                                         VALUE +10.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-CREATE            VALUE '2811'.
           05  WS-SUB                           PIC S9(03) COMP-3.
           05  WS-CVG-NUM                       PIC S9(02).
           05  WS-CF-EFF-DT                     PIC X(10).
           05  WS-CF-SEQ-NUM                    PIC S9(03) COMP-3.
           05  WS-PAYO-NUM                      PIC S9(05) COMP-3.
           05  WS-HOLD-COVNO                    PIC 9(02).
           05  WS-HOLD-COVNO-R                  REDEFINES
               WS-HOLD-COVNO                    PIC X(02).               
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWCVGS.
      /
       COPY CCWWINDX.
      /
       COPY CCWWLOCK.
026057 COPY CCWWIHSD.
      /
       COPY XCWWWKDT.
      /
       COPY XCWWCVGM.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCFLW.
       COPY CCFRCFLW.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWPOLP.
       COPY CCFRPOLP.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWLPGA.
       COPY CCWL5400.
       COPY CCWL6530.
      /
       COPY XCWLDTLK.
       COPY XCWL0035.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2811.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID         TO   WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2811'
                                       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                                       TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                       TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-CREATE.
      *------------
      *
      *  THE RECORD SHOULD NOT EXIST ON A CREATE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED
                                       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED
                                       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.
      
           PERFORM  3000-CREATE-PAYOUT
               THRU 3000-CREATE-PAYOUT-X.

           PERFORM  3200-CALC-ROLL-AMOUNT
               THRU 3200-CALC-ROLL-AMOUNT-X

           PERFORM  3400-CALC-ORG-LTR-AMT
               THRU 3400-CALC-ORG-LTR-AMT-X

           PERFORM  3600-UPDATE-PAYOUT
               THRU 3600-UPDATE-PAYOUT-X.

           PERFORM  3800-UPDATE-CFLW
               THRU 3800-UPDATE-CFLW-X.

           MOVE MIR-POL-ID             TO WPOL-POL-ID.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       2000-CREATE-X.
           EXIT.
      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: POLICY NOT ON FILE
               MOVE 'CS28110001'       TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-POL-XFER-UPDATE   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           IF WS-HOLD-COVNO             > RPOL-POL-CVG-REC-CTR-N
      * MSG:  COVNO (@1) NOT FOUND
               MOVE 'CS28110014'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  NOT WCVGS-CVG-CF-TYP-GIA (WS-CVG-NUM)
           AND NOT WCVGS-CVG-CF-TYP-EIA (WS-CVG-NUM)
      *MSG: CREATES ARE ONLY ALLOWED FOR GIA AND EIA COVERAGE
               MOVE 'CS28110002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CF-EFF-DT           TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-3000-CHK-IHSD-INSTR
026057         THRU IHSD-3000-CHK-IHSD-INSTR-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WGLOB-RETURN-ERROR  TO TRUE
026057         GO TO 2100-VALIDATE-KEYS-X
026057     END-IF.

           MOVE MIR-POL-ID             TO WCFLW-POL-ID.
           MOVE WS-CVG-NUM             TO WCFLW-CVG-NUM-N.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG-NUM)
                                       TO WCFLW-CF-TYP-CD.
           MOVE WS-CF-EFF-DT           TO WCFLW-CF-EFF-DT.
           MOVE WS-CF-SEQ-NUM          TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF  NOT WCFLW-IO-OK
      *MSG: NO CASH FLOW FOUND
               MOVE 'CS28110003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  2120-SEARCH-CFLW
               THRU 2120-SEARCH-CFLW-X
               UNTIL NOT WCFLW-IO-OK
               OR    RCFLW-NXT-CF-DT = WWKDT-ZERO-DT.

           IF (RCFLW-CF-STAT-ACTIVE
           OR  RCFLW-CF-STAT-PARTL-SURR)
               CONTINUE
           ELSE
      *MSG: CASHFLOW RECORD MUST BE ACTIVE
               MOVE 'CS28110006'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           IF  RCFLW-CF-ROLOVR-PAYO-NUM NOT = ZERO

               MOVE RCFLW-POL-ID       TO WPOLP-POL-ID
               MOVE RCFLW-CF-ROLOVR-PAYO-NUM
                                       TO WPOLP-POL-PAYO-NUM
               PERFORM  POLP-1000-READ
                   THRU POLP-1000-READ-X
               IF  WPOLP-IO-OK
               AND NOT RPOLP-POL-PAYO-STAT-HIST
      *MSG: SPECIFIC INSTRUCTIONS ALREADY EXIST FOR THIS CASH FLOW
                   MOVE 'CS28110004'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
                   GO TO 2100-VALIDATE-KEYS-X
               END-IF
           END-IF.

           IF  RCFLW-ROLOVR-CF-DT NOT = WCVGS-CVG-NXT-ROLOVR-DT
                                        (WS-CVG-NUM)
      *MSG: ROLLOVER EFFECTIVE DATE DOES NOT EQUAL NEXT ROLLOVER
      *     DATE ON COVERAGE
               MOVE 'CS28110005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR  TO TRUE
                   GO TO 2100-VALIDATE-KEYS-X
               END-IF
           END-IF.

           PERFORM  CFLW-1000-READ-FOR-UPDATE
               THRU CFLW-1000-READ-FOR-UPDATE-X.

           IF  WCFLW-IO-NOT-FOUND
      *MSG: NO CASH FLOW FOUND
               MOVE 'CS28110003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *--------------------
       2120-SEARCH-CFLW.
      *--------------------

           MOVE RCFLW-NXT-CF-DT        TO WCFLW-CF-EFF-DT.
           MOVE RCFLW-NXT-CF-SEQ-NUM-N TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

       2120-SEARCH-CFLW-X.
           EXIT.
      /
      *--------------------
       3000-CREATE-PAYOUT.
      *--------------------

           MOVE RPOL-POL-ID            TO WPOLP-POL-ID.
           MOVE ZERO                   TO WPOLP-POL-PAYO-NUM.
           MOVE WPOLP-KEY              TO WPOLP-ENDBR-KEY.
           MOVE 99999                  TO WPOLP-ENDBR-POL-PAYO-NUM.

           PERFORM  POLP-1000-READ-MIN
               THRU POLP-1000-READ-MIN-X.
      
           IF  WPOLP-IO-OK
               COMPUTE WS-PAYO-NUM     = WPOLP-MIN-POL-PAYO-NUM
                                       - 1
           ELSE
               MOVE 99999              TO WS-PAYO-NUM
           END-IF.

           MOVE RPOL-POL-ID            TO WPOLP-POL-ID.
           MOVE WS-PAYO-NUM            TO WPOLP-POL-PAYO-NUM.

           PERFORM  POLP-1000-CREATE
               THRU POLP-1000-CREATE-X.
      
       3000-CREATE-PAYOUT-X.
           EXIT.

      *-----------------------
       3200-CALC-ROLL-AMOUNT.
      *-----------------------
      
           PERFORM  6530-1000-BUILD-PARM-INFO
               THRU 6530-1000-BUILD-PARM-INFO-X.
      
           MOVE WCVGS-CVG-NXT-ROLOVR-DT (WS-CVG-NUM)
                                       TO L6530-EFF-DT.
           MOVE WS-CF-EFF-DT           TO L6530-CF-DT.
           MOVE WS-CF-SEQ-NUM          TO L6530-CF-SEQ-NUM.
           MOVE WS-CVG-NUM             TO L6530-CVG.
           SET L6530-CALC-MKTVAL-ADJ-NOT-REQD
                                       TO TRUE.

           PERFORM  6530-3000-CALC-ACUM-VALU-CF
               THRU 6530-3000-CALC-ACUM-VALU-CF-X.

           IF  L6530-RETRN-OK
               IF  WCVGS-CVG-INT-PAYO-CREDIT-ACCT (WS-CVG-NUM)
                   MOVE L6530-CF-ACUM-VALU-AMT
                                       TO RPOLP-POL-PAYO-AMT
               ELSE
                   MOVE RCFLW-CF-FND-BAL-AMT
                                       TO RPOLP-POL-PAYO-AMT
               END-IF
               IF  RCFLW-CF-TYP-EIA
               OR  RCFLW-CF-TYP-GIA
                   IF  L6530-CF-ACUM-MCV-AMT
                                       >  RPOLP-POL-PAYO-AMT
                     MOVE L6530-CF-ACUM-MCV-AMT
                                       TO RPOLP-POL-PAYO-AMT
                   END-IF
               END-IF
           END-IF.

       3200-CALC-ROLL-AMOUNT-X.
           EXIT.

      *----------------------
       3400-CALC-ORG-LTR-AMT.
      *----------------------

           IF  WCVGS-CVG-CF-TYP-DIA (WS-CVG-NUM)
               MOVE ZERO               TO RPOLP-POL-PAYO-RENW-AMT
           ELSE
               MOVE RPOLP-POL-PAYO-AMT TO RPOLP-POL-PAYO-RENW-AMT
           END-IF.

       3400-CALC-ORG-LTR-AMT-X.
           EXIT.

      *-------------------
       3600-UPDATE-PAYOUT.
      *-------------------

           SET  RPOLP-POL-PAYO-CREAT-MANL
                                       TO TRUE.
           SET  RPOLP-POL-PAYO-STAT-ERRORS
                                       TO TRUE.
           MOVE RCFLW-ROLOVR-CF-DT     TO RPOLP-POL-PAYO-EFF-DT.
           SET  RPOLP-POL-PAYO-TYP-ROLOVR-PAYO
                                       TO TRUE.

           MOVE WS-CVG-NUM             TO RPOLP-CVG-NUM.

           PERFORM  POLP-1000-WRITE
               THRU POLP-1000-WRITE-X.

       3600-UPDATE-PAYOUT-X.
           EXIT.

      *------------------
       3800-UPDATE-CFLW.
      *------------------

           MOVE WS-PAYO-NUM            TO RCFLW-CF-ROLOVR-PAYO-NUM.
           PERFORM  CFLW-2000-REWRITE
               THRU CFLW-2000-REWRITE-X.

       3800-UPDATE-CFLW-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           IF  MIR-POL-ID = SPACE
      *MSG: THE POLICY ID MUST BE ENTERED
               MOVE 'CS28110007'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  MIR-CVG-NUM = SPACE
      *MSG: THE COVERAGE NUMBER MUST BE ENTERED
               MOVE 'CS28110008'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
               SET L0280-SPACES-PERMITTED
                                       TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CVG-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CVG-NUM        TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
               AND L0280-OUTPUT-V00 > ZERO
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CVG-NUM
               ELSE
      *MSG: COVERAGE NUMBER IS INVALID
                   MOVE 'CS28110009'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           MOVE MIR-CVG-NUM            TO WS-HOLD-COVNO-R.

           IF WS-HOLD-COVNO             > WCVGM-MAX-WCVGS-NUM
      * MSG:  COVERAGE NUMBER MUST BE 2 DIGITS BETWEEN 01 AND 20
               MOVE 'CS28110015'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           IF  MIR-CF-EFF-DT = SPACE
      *MSG: THE CASH FLOW EFFECTIVE DATE MUST BE ENTERED
               MOVE 'CS28110010'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               MOVE MIR-CF-EFF-DT      TO L1640-EXTERNAL-DATE
               PERFORM  1640-7000-MIR-TO-INT
                   THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-RETRN-OK
                   MOVE L1640-INTERNAL-DATE
                                       TO WS-CF-EFF-DT
               ELSE
      *MSG: CASH FLOW EFFECTIVE DATE IS INVALID
                   MOVE 'CS28110011'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           IF  MIR-CF-SEQ-NUM = SPACE
      *MSG: THE CASH FLOW SEQUENCE NUMBER MUST BE ENTERED
               MOVE 'CS28110012'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               SET L0280-SPACES-PERMITTED   TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CF-SEQ-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CF-SEQ-NUM     TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CF-SEQ-NUM
               ELSE
      *MSG: CASH FLOW SEQUENCE NUMBER IS INVALID
                   MOVE 'CS28110013'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.
      
       7000-BUILD-KEYS-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6530-0000-INIT-PARM-INFO
025970         THRU 6530-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.     
025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT    TO TRUE.
025970     MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK            TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL5400.
       COPY CCPS5400.
      /
       COPY CCPL6530.
       COPY CCPS6530.
      /
       COPY XCPL0035.
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCFLW.
       COPY CCPUCFLW.
      /
       COPY CCPNCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPAPOLP.
       COPY CCPCPOLP.
       COPY CCPFPOLP.
       COPY CCPNPOLP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM2811                     **
      *****************************************************************
