      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2340.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2340                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RETRIEVE FUNCTION FOR   **
      **            ILLUSTRATION INTERFACE                           **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018617**  6.2       NEW FOR RELEASE 6.2                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023434**  6.5       EXPAND ADDRESS LINE                              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
021657**  6.6       CORRECT FIELD NAMES IN MIR COPYBOOKS             **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2340'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '2340'.
           05  WS-PROJ-DT                    PIC X(10).
           05  WS-CVG-CLI-AGE-FLDS.
               10  FILLER                    OCCURS 5.
                   15  WS-CVG-CLI-CLI-ID     PIC X(10).
               10  WS-INS-SUB                PIC S9(04) BINARY.
           05  WS-DATA-OVERFLOW-SW           PIC X(01).
               88  WS-DATA-OVERFLOW          VALUE 'Y'.
               88  WS-DATA-OVERFLOW-NO       VALUE 'N'.
025970*    05  WS-MAX-PROJ-SUB               PIC S9(4) VALUE +110 COMP.
           05  WS-CVG                        PIC S9(04) BINARY.
           05  WS-PROJ-SUB                   PIC S9(04) BINARY.
           05  WS-REC-SUB                    PIC S9(04) BINARY.
           05  WS-SUB                        PIC S9(04) BINARY.
           05  WS-HOLD-SUB                   PIC S9(04) BINARY.
           05  WS-DUP-SUB                    PIC S9(04) BINARY.
           05  WS-CVG-NUM                    PIC X(02).
               88  WS-CVG-NUM-BLANK          VALUE SPACES ZEROS.
           05  WS-CVG-NUM-R                  REDEFINES
               WS-CVG-NUM                    PIC 9(02).
           05  WS-CURR-DATE.
               10  WS-CURR-YEAR              PIC 9(04).
               10  FILLER                    PIC X(01).
               10  WS-CURR-MONTH             PIC 9(02).
               10  FILLER                    PIC X(01).
               10  WS-CURR-DAY               PIC 9(02).
           05  WS-CV-DATE.
               10  WS-CV-DATE-YR             PIC 9(04).
               10  FILLER                    PIC X(01).
               10  WS-CV-DATE-MO             PIC 9(02).
               10  FILLER                    PIC X(01).
               10  WS-CV-DATE-DY             PIC 9(02).
           05  WS-SCREEN-DATE                PIC X(10).
           05  WS-OWNER-PRIMARY-SW           PIC X(01).
               88 WS-PRIMARY-NOT-FOUND       VALUE 'N'.
               88 WS-PRIMARY-FOUND           VALUE 'Y'.
           05  WS-DUPLICATE-REC-SW           PIC X(01).
               88  WS-REC-FOUND              VALUE 'Y'.
               88  WS-REC-NOT-FOUND          VALUE 'N'.
           05  WS-HOLD-REC                   PIC X(250).
           05  WS-EDIT-SW                    PIC X(01).
               88  WS-EDIT-OK                VALUE 'Y'.
               88  WS-EDIT-ERROR             VALUE 'N'.
           05  WS-CDI-SUBSEQ-PREM-SW            PIC X(01).
               88  WS-CDI-SUBSEQ-PREM-FOUND     VALUE 'Y'.
               88  WS-CDI-SUBSEQ-PREM-NOT-FOUND VALUE 'N'.
           05  WS-CDI-ASSET-REBAL-SW            PIC X(01).
               88  WS-CDI-ASSET-REBAL-FOUND     VALUE 'Y'.
               88  WS-CDI-ASSET-REBAL-NOT-FOUND VALUE 'N'.
           05  WS-CDI-DCA-SW                    PIC X(01).
               88  WS-CDI-DCA-FOUND             VALUE 'Y'.
               88  WS-CDI-DCA-NOT-FOUND         VALUE 'N'.
           05  WS-CDI-CNTRCT-PAYO-SW            PIC X(01).
               88  WS-CDI-CNTRCT-PAYO-FOUND     VALUE 'Y'.
               88  WS-CDI-CNTRCT-PAYO-NOT-FOUND VALUE 'N'.
           05  WS-CDI-SUBSEQ-PREM-EFF-IDT     PIC X(07).
           05  WS-CDI-ASSET-REBAL-EFF-IDT     PIC X(07).
           05  WS-CDI-DCA-EFF-IDT             PIC X(07).
           05  WS-CDI-CNTRCT-PAYO-EFF-IDT     PIC X(07).
           
025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-MAX-PROJ-SUB                PIC S9(4) BINARY.  
025970         88  WS-MAX-PROJ-SUB-DEFAULT    VALUE +110. 

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWW2340.
       COPY CCWWINDX.
021930*COPY XCWEBLCH.
021930*COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWCVGC.
       COPY CCFRCVGC.
      /
020478*COPY CCFWCLIA.
020478*COPY CCFRCLIA.
      /
       COPY CCFWCDSI.
       COPY CCFRCDSI.
      /
       COPY CCFWPOLP.
       COPY CCFRPOLP.
      /
021930*COPY CCFWPOLC.
021930*COPY CCFRPOLC.
021930*
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWMFSL.
       COPY CCFRMFSL.
      /
       COPY CCFWMFSD.
       COPY CCFRMFSD.
      /
       COPY NCFWTTAB.
       COPY NCFRTTAB.
      /
       COPY CCWWCVGS.
      /
       COPY CCWL2430.
020478 COPY CCWL2440.
028298 COPY CCWL2626.
       COPY CCWL6965.
       COPY CCWL6980.
       COPY CCWLPGA.
       COPY NCWL2437.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
021930*COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2340.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-TRANSACTIONS
               THRU 2000-PROCESS-TRANSACTIONS-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------------
       2000-PROCESS-TRANSACTIONS.
      *--------------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET  WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-PROCESS-TRANSACTIONS-X
           END-IF.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-RETRIEVE
                        THRU 3000-RETRIEVE-X

               WHEN OTHER
      *MSG: INVALID FUNCTION ID - PROCESSING STOPPED
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2340'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-TRANSACTIONS-X.
           EXIT.

      /
      *--------------
       3000-RETRIEVE.
      *--------------

      *
      *  THE RECORD MUST EXIST ON AN INQUIRE
      *
           PERFORM  7100-BUILD-KEYS
               THRU 7100-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               GO TO 3000-RETRIEVE-X
           END-IF.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               GO TO 3000-RETRIEVE-X
           END-IF.
      *
      *  PROCESS FOR UL POLICY ONLY
      *
           IF  NOT RPOL-POL-INS-TYP-UL
      *MSG: POLICY @1 IS NOT UL INSURANCE TYPE
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'CS23400001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               GO TO 3000-RETRIEVE-X
           END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           PERFORM  8200-MOVE-RECORD-TO-MIR
               THRU 8200-MOVE-RECORD-TO-MIR-X.

           IF  WS-DATA-OVERFLOW
               SET MIR-RETRN-DATA-OVERFLOW    TO TRUE
           END-IF.

       3000-RETRIEVE-X.
           EXIT.

      /
      *----------------
       7100-BUILD-KEYS.
      *----------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE MIR-POL-ID-BASE     TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX      TO WPOL-POL-ID-SFX.

       7100-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES              TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       8200-MOVE-RECORD-TO-MIR.
      *------------------------

           PERFORM  8100-BLANK-DATA-FIELDS
               THRU 8100-BLANK-DATA-FIELDS-X.

           PERFORM  8400-MOVE-POL-REC-TO-MIR
               THRU 8400-MOVE-POL-REC-TO-MIR-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               GO TO 8200-MOVE-RECORD-TO-MIR-X
           END-IF.

           MOVE ZERO                  TO WS-PROJ-SUB.
           SET  WS-DATA-OVERFLOW-NO   TO TRUE.

           PERFORM  8500-MOVE-CVG-REC-TO-MIR
               THRU 8500-MOVE-CVG-REC-TO-MIR-X
               VARYING WS-CVG FROM 1 BY 1
               UNTIL WS-CVG > RPOL-POL-CVG-REC-CTR-N
               OR    WS-DATA-OVERFLOW.

           IF  WS-DATA-OVERFLOW
               GO TO 8200-MOVE-RECORD-TO-MIR-X
           END-IF.

           PERFORM  8600-MOVE-INSURED-REC-TO-MIR
               THRU 8600-MOVE-INSURED-REC-TO-MIR-X.

           IF  WS-DATA-OVERFLOW
               GO TO 8200-MOVE-RECORD-TO-MIR-X
           END-IF.

           PERFORM  8700-MOVE-FUND-REC-TO-MIR
               THRU 8700-MOVE-FUND-REC-TO-MIR-X.

           IF  WS-DATA-OVERFLOW
               GO TO 8200-MOVE-RECORD-TO-MIR-X
           END-IF.

           PERFORM  8800-MOVE-WTHDR-REC-TO-MIR
               THRU 8800-MOVE-WTHDR-REC-TO-MIR-X.

           IF  WS-DATA-OVERFLOW
               GO TO 8200-MOVE-RECORD-TO-MIR-X
           END-IF.

       8200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *-------------------------
       8400-MOVE-POL-REC-TO-MIR.
      *-------------------------

           MOVE RPOL-POL-ISS-EFF-DT        TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE        TO MIR-POL-ISS-EFF-DT.

021657*    IF  MIR-PROJ-DT = SPACES
021657     IF  MIR-DV-PROJ-DT = SPACES
               MOVE WGLOB-PROCESS-DATE     TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
021657*        MOVE L1640-EXTERNAL-DATE    TO MIR-PROJ-DT
021657         MOVE L1640-EXTERNAL-DATE    TO MIR-DV-PROJ-DT
           END-IF.

021657*    MOVE MIR-PROJ-DT                TO L1640-EXTERNAL-DATE.
021657     MOVE MIR-DV-PROJ-DT             TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID DATE
               MOVE 'XS00000036'           TO WGLOB-MSG-REF-INFO
021657*        MOVE MIR-PROJ-DT            TO WGLOB-MSG-PARM (1)
021657         MOVE MIR-DV-PROJ-DT         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8400-MOVE-POL-REC-TO-MIR-X
           ELSE
               MOVE L1640-INTERNAL-DATE    TO WS-PROJ-DT
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = RPOL-POL-SNDRY-AMT * 100.
020874     MOVE RPOL-POL-SNDRY-AMT         TO L0290-INPUT-V02.
           MOVE 2                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-SNDRY-AMT
                                           TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO MIR-POL-SNDRY-AMT.

      * MAKE CONVERSION FOR BILLING MODE FROM TTAB TABLE

           MOVE 'PAYM'                     TO WTTAB-ETBL-TYP-ID.
           MOVE RPOL-POL-BILL-MODE-CD      TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO MIR-POL-BILL-MODE-CD
           ELSE
               MOVE RPOL-POL-BILL-MODE-CD  TO MIR-POL-BILL-MODE-CD
           END-IF.

      * MAKE CONVERSION FOR BILLING TYPE FROM TTAB TABLE

           MOVE 'PAYT'                     TO WTTAB-ETBL-TYP-ID.
           MOVE RPOL-POL-BILL-TYP-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO MIR-POL-BILL-TYP-CD
           ELSE
               MOVE RPOL-POL-BILL-TYP-CD   TO MIR-POL-BILL-TYP-CD
           END-IF.

           MOVE RPOL-POL-RBILL-CD          TO MIR-POL-RBILL-CD.

      * MAKE CONVERSION FOR DBO FROM TTAB TABLE

           MOVE 'DBO'                      TO WTTAB-ETBL-TYP-ID.
           MOVE RPOL-POL-DB-OPT-CD         TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO MIR-POL-DB-OPT-CD
           ELSE
               MOVE RPOL-POL-DB-OPT-CD     TO MIR-POL-DB-OPT-CD
           END-IF.

      * MAKE CONVERSION FOR RPOL-POL-CSTAT-CD FROM TTAB TABLE

           MOVE 'POLST'                    TO WTTAB-ETBL-TYP-ID.
           MOVE RPOL-POL-CSTAT-CD          TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
021657*        MOVE RTTAB-TTBL-VALU-TXT    TO MIR-DV-POL-CSTAT-CD
021657         MOVE RTTAB-TTBL-VALU-TXT    TO MIR-POL-CSTAT-CD
           ELSE
021657*        MOVE RPOL-POL-CSTAT-CD      TO MIR-DV-POL-CSTAT-CD
021657         MOVE RPOL-POL-CSTAT-CD      TO MIR-POL-CSTAT-CD
           END-IF.

           PERFORM  8410-GET-CDN-TAX-ACB-AMT
               THRU 8410-GET-CDN-TAX-ACB-AMT-X.

           PERFORM  8420-GET-OWNER-RECORDS
               THRU 8420-GET-OWNER-RECORDS-X.

       8400-MOVE-POL-REC-TO-MIR-X.
           EXIT.
      /
      *-------------------------
       8410-GET-CDN-TAX-ACB-AMT.
      *-------------------------
      *
      *    GET ACB AMOUNT
      *
           INITIALIZE L6965-INPUT-PARM-INFO.
           INITIALIZE L6965-IO-PARM-INFO.
      *
      * BUILD INPUT PARMS
      *
           MOVE '01'                       TO L6965-CVG-NUM.
           MOVE WGLOB-PROCESS-DATE         TO L6965-CURR-DATE.
021657*    MOVE MIR-PROJ-DT                TO L6965-SCREEN-DATE.
021657     MOVE MIR-DV-PROJ-DT             TO L6965-SCREEN-DATE.
           MOVE WS-PROJ-DT                 TO L6965-EFF-DT.

           PERFORM  6965-1000-INQUIRE
               THRU 6965-1000-INQUIRE-X.

020874*    COMPUTE L0290-INPUT-NUMBER = L6965-ACBR * 100.
020874     MOVE L6965-ACBR                 TO L0290-INPUT-V02.
           MOVE 2                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CDN-TAX-ACB-AMT
                                           TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS   TO TRUE.
           SET L0290-SIGN-DISPLAY          TO TRUE.
           SET L0290-SIGN-FLOAT            TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO MIR-DV-CDN-TAX-ACB-AMT.

       8410-GET-CDN-TAX-ACB-AMT-X.
           EXIT.
      /
      *-----------------------
       8420-GET-OWNER-RECORDS.
      *-----------------------

           MOVE +0                      TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               GO TO 8420-GET-OWNER-RECORDS-X
           END-IF.

021657*    MOVE L2430-CLI-ID            TO MIR-OWNER-CLI-ID.
021657     MOVE L2430-CLI-ID            TO MIR-CLI-ID.

      * MAKE CONVERSION FOR SEX CODE FROM TTAB TABLE

           MOVE 'SEX'                   TO WTTAB-ETBL-TYP-ID.
           MOVE L2430-CLI-SEX-CD        TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                    TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO MIR-CLI-SEX-CD
           ELSE
               MOVE L2430-CLI-SEX-CD    TO MIR-CLI-SEX-CD
           END-IF.

           MOVE L2430-CLI-BTH-DT        TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE     TO MIR-CLI-BTH-DT.

      * MAKE CONVERSION FOR SMOKER CODE FROM TTAB TABLE

           MOVE 'SMOKE'                 TO WTTAB-ETBL-TYP-ID.
           MOVE L2430-CLI-SMKR-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                    TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO MIR-CLI-SMKR-CD
           ELSE
               MOVE L2430-CLI-SMKR-CD   TO MIR-CLI-SMKR-CD
           END-IF.

      * MAKE CONVERSION FOR LANGUAGE CODE FROM TTAB TABLE

           MOVE 'LANG'                  TO WTTAB-ETBL-TYP-ID.
           MOVE L2430-CLI-LANG-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                    TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO MIR-CLI-LANG-CD
           ELSE
               MOVE L2430-CLI-LANG-CD   TO MIR-CLI-LANG-CD
           END-IF.

021657*    IF  MIR-PROJ-LANG-CD = SPACES
021657     IF  MIR-DV-PROJ-LANG-CD = SPACES
021657*        MOVE MIR-CLI-LANG-CD     TO MIR-PROJ-LANG-CD
021657         MOVE MIR-CLI-LANG-CD     TO MIR-DV-PROJ-LANG-CD
           END-IF.

           MOVE L2430-CLI-ENTR-GIV-NM   TO MIR-CLI-GIV-NM.
           MOVE L2430-CLI-ENTR-SUR-NM   TO MIR-CLI-SUR-NM.
           MOVE L2430-CLI-MID-INIT-NM   TO MIR-CLI-MID-INIT-NM.

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.
020478
020478*    MOVE L2430-CLI-ID            TO WCLIA-CLI-ID.
020478     MOVE L2430-CLI-ID            TO L2440-CLI-ID.
020478*    MOVE L2430-CLI-ADDR-TYP-CD   TO WCLIA-CLI-ADDR-TYP-CD.
020478     MOVE L2430-CLI-ADDR-TYP-CD   TO L2440-CLI-ADDR-TYP-CD.
020478*    MOVE '001'                   TO WCLIA-CLI-ADDR-SEQ-NUM.

           IF  WGLOB-COUNTRY-JAPAN
020478*        SET  WCLIA-CLI-ADDR-GR-KANJI  TO TRUE
020478         SET  L2440-CLI-ADDR-GR-KANJI  TO TRUE
           ELSE
020478*        SET  WCLIA-CLI-ADDR-GR-ALPHA  TO TRUE
020478         SET  L2440-CLI-ADDR-GR-ALPHA  TO TRUE
           END-IF.

020478*    PERFORM  CLIA-1000-READ
020478*        THRU CLIA-1000-READ-X.

020478     IF  L2430-CLI-ADDR-TYP-PRIMARY
020478         PERFORM  2440-1000-PRIMARY-ADDRESS
020478             THRU 2440-1000-PRIMARY-ADDRESS-X
020478     ELSE
020478         PERFORM  2440-2000-OTHER-ADDRESS
020478             THRU 2440-2000-OTHER-ADDRESS-X
020478     END-IF.

020478*    IF  NOT WCLIA-IO-OK
020478     IF  NOT L2440-RETRN-OK
               GO TO 8420-GET-OWNER-RECORDS-X
           END-IF.

      * MAKE CONVERSION FOR ADDRESS TYPE FROM TTAB TABLE

           MOVE 'ADTYP'                    TO WTTAB-ETBL-TYP-ID.
020478*    MOVE RCLIA-CLI-ADDR-TYP-CD      TO WTTAB-ETBL-VALU-ID.
020478     MOVE L2440-CLI-ADDR-TYP-CD      TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO MIR-CLI-ADDR-TYP-CD
           ELSE
020478*        MOVE RCLIA-CLI-ADDR-TYP-CD  TO MIR-CLI-ADDR-TYP-CD
020478         MOVE L2440-CLI-ADDR-TYP-CD  TO MIR-CLI-ADDR-TYP-CD
           END-IF.

023434*    MOVE RCLIA-CLI-ADDR-LN-1-TXT TO MIR-CLI-ADDR-LN-1-TXT.
020478*    MOVE RCLIA-CLI-ADDR-LN-1-TXT-TXT
020478     MOVE L2440-CLI-ADDR-LN-1-TXT-TXT
023434                                     TO MIR-CLI-ADDR-LN-1-TXT.
023434*    MOVE RCLIA-CLI-ADDR-LN-2-TXT TO MIR-CLI-ADDR-LN-2-TXT.
020478*    MOVE RCLIA-CLI-ADDR-LN-2-TXT-TXT
020478     MOVE L2440-CLI-ADDR-LN-2-TXT-TXT
023434                                     TO MIR-CLI-ADDR-LN-2-TXT.
023434*    MOVE RCLIA-CLI-ADDR-LN-3-TXT TO MIR-CLI-ADDR-LN-3-TXT.
020478*    MOVE RCLIA-CLI-ADDR-LN-3-TXT-TXT
020478     MOVE L2440-CLI-ADDR-LN-3-TXT-TXT
023434                                     TO MIR-CLI-ADDR-LN-3-TXT.

      * MAKE CONVERSION FOR COUNTRY FROM TTAB TABLE

           MOVE 'CNTRY'                    TO WTTAB-ETBL-TYP-ID.
020478*    MOVE RCLIA-CLI-CTRY-CD          TO WTTAB-ETBL-VALU-ID.
020478     MOVE L2440-CLI-CTRY-CD          TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO MIR-CLI-CTRY-CD
           ELSE
020478*        MOVE RCLIA-CLI-CTRY-CD      TO MIR-CLI-CTRY-CD
020478         MOVE L2440-CLI-CTRY-CD      TO MIR-CLI-CTRY-CD
           END-IF.

020478*    MOVE RCLIA-CLI-CITY-NM-TXT   TO MIR-CLI-CITY-NM-TXT.
020478     MOVE L2440-CLI-CITY-NM-TXT   TO MIR-CLI-CITY-NM-TXT.
020478*    MOVE RCLIA-CLI-PSTL-CD       TO MIR-CLI-PSTL-CD.
020478     MOVE L2440-CLI-PSTL-CD       TO MIR-CLI-PSTL-CD.

      * MAKE CONVERSION FOR PROVINCE CODE FROM TTAB TABLE

           MOVE 'CLOC'                  TO WTTAB-ETBL-TYP-ID.
020478*    MOVE RCLIA-CLI-CRNT-LOC-CD   TO WTTAB-ETBL-VALU-ID.
020478     MOVE L2440-CLI-CRNT-LOC-CD   TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                    TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT   TO MIR-CLI-CRNT-LOC-CD
           ELSE
020478*        MOVE RCLIA-CLI-CRNT-LOC-CD TO MIR-CLI-CRNT-LOC-CD
020478         MOVE L2440-CLI-CRNT-LOC-CD TO MIR-CLI-CRNT-LOC-CD
           END-IF.

020478*    MOVE RCLIA-CLI-RES-NUM       TO MIR-CLI-RES-NUM.
020478     MOVE L2440-CLI-RES-NUM       TO MIR-CLI-RES-NUM.

      * MAKE CONVERSION FOR RESIDENCE TYPE FROM TTAB TABLE

           MOVE 'RESD'                  TO WTTAB-ETBL-TYP-ID.
020478*    MOVE RCLIA-CLI-RES-TYP-CD    TO WTTAB-ETBL-VALU-ID.
020478     MOVE L2440-CLI-RES-TYP-CD    TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                    TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO MIR-CLI-RES-TYP-CD
           ELSE
020478*        MOVE RCLIA-CLI-RES-TYP-CD   TO MIR-CLI-RES-TYP-CD
020478         MOVE L2440-CLI-RES-TYP-CD   TO MIR-CLI-RES-TYP-CD
           END-IF.

       8420-GET-OWNER-RECORDS-X.
           EXIT.
      /
      *-------------------------
       8500-MOVE-CVG-REC-TO-MIR.
      *-------------------------

           IF  WCVGS-CVG-INS-TYP-UL (WS-CVG)
           OR  WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
           OR  WCVGS-CVG-INS-TYP-FPA (WS-CVG)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG:  COVERAGE @1 IS NOT UL INSURANCE TYPE
               MOVE WS-CVG             TO WGLOB-MSG-PARM (1)
               MOVE 'CS23400002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8500-MOVE-CVG-REC-TO-MIR-X
           END-IF.

           ADD +1                       TO WS-PROJ-SUB.
           IF  WS-PROJ-SUB > WS-MAX-PROJ-SUB
               SET WS-DATA-OVERFLOW     TO TRUE
               GO TO 8500-MOVE-CVG-REC-TO-MIR-X
           END-IF.

021657*    SET MIR-DV-PROJ-ARRAY-NORM-CVG-T (WS-PROJ-SUB)
021657     SET MIR-DV-PROJ-INFO-NORM-CVG-T (WS-PROJ-SUB)
                                        TO TRUE.

           MOVE SPACES                  TO W2340-CVG-ARRAY-REC.

           PERFORM  8510-UPDATE-NORMAL-CVG
               THRU 8510-UPDATE-NORMAL-CVG-X.

           PERFORM  8520-UPDATE-EMBED-CVG
               THRU 8520-UPDATE-EMBED-CVG-X.

           IF  WS-DATA-OVERFLOW
               GO TO 8500-MOVE-CVG-REC-TO-MIR-X
           END-IF.

       8500-MOVE-CVG-REC-TO-MIR-X.
           EXIT.
      /
      *-----------------------
       8510-UPDATE-NORMAL-CVG.
      *-----------------------

020874*    MOVE WS-CVG                  TO L0290-INPUT-NUMBER.
020874     MOVE WS-CVG                  TO L0290-INPUT-V00.
           MOVE ZERO                    TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-NUM TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO W2340-CVG-NUM.

           MOVE '.'                     TO W2340-DV-CVG-FILLER.
           MOVE '00'                    TO W2340-DV-EMBED-NUM.
           MOVE WCVGS-PLAN-ID (WS-CVG)  TO W2340-PLAN-ID.
           MOVE SPACES                  TO W2340-DV-EMBED-ID.

           MOVE 'PLAN'                  TO WEDIT-ETBL-TYP-ID.
           MOVE WCVGS-PLAN-ID (WS-CVG)  TO WEDIT-ETBL-VALU-ID.
021657*    MOVE MIR-PROJ-LANG-CD        TO WEDIT-ETBL-LANG-CD.
021657     MOVE MIR-DV-PROJ-LANG-CD     TO WEDIT-ETBL-LANG-CD.

           PERFORM  EDIT-1000-READ
               THRU EDIT-1000-READ-X.

           IF  WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT TO W2340-DV-PLAN-DESC-TXT
           END-IF.

      * MAKE CONVERSION FOR WCVGS-CVG-CSTAT-CD (WS-CVG) FROM TTAB TABLE

           MOVE 'CVGST'                     TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-CSTAT-CD (WS-CVG) TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                        TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT     TO W2340-DV-CVG-CSTAT-CD
           ELSE
               MOVE WCVGS-CVG-CSTAT-CD (WS-CVG)
                                            TO W2340-DV-CVG-CSTAT-CD
           END-IF.

           MOVE WCVGS-CVG-ISS-EFF-DT (WS-CVG) TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-CVG-ISS-EFF-DT.

           MOVE WCVGS-CVG-MAT-XPRY-DT (WS-CVG) TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-CVG-MAT-XPRY-DT.

      * MAKE CONVERSION FOR SMOKER CODE FROM TTAB TABLE

           MOVE 'SMOKE'                    TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-SMKR-CD (WS-CVG) TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT        TO W2340-CVG-SMKR-CD
           ELSE
               MOVE WCVGS-CVG-SMKR-CD (WS-CVG) TO W2340-CVG-SMKR-CD
           END-IF.

      * MAKE CONVERSION FOR DIVIDEND OPTION FROM TTAB TABLE

           MOVE 'DIV'                      TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-PAR-CD (WS-CVG)  TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT       TO W2340-CVG-PAR-CD
           ELSE
               MOVE WCVGS-CVG-PAR-CD (WS-CVG) TO W2340-CVG-PAR-CD
           END-IF.

      * MAKE CONVERSION FOR SEX CODE FROM TTAB TABLE

           MOVE 'SEX'                      TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-SEX-CD (WS-CVG)  TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT       TO W2340-CVG-SEX-CD
           ELSE
               MOVE WCVGS-CVG-SEX-CD (WS-CVG) TO W2340-CVG-SEX-CD
           END-IF.

      * MAKE CONVERSION FOR STB1 FROM TTAB TABLE

           MOVE 'STB1'                     TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-STBL-1-CD (WS-CVG)
                                           TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO W2340-CVG-STBL-1-CD
           ELSE
               MOVE WCVGS-CVG-STBL-1-CD (WS-CVG)
                                           TO W2340-CVG-STBL-1-CD
           END-IF.

      * MAKE CONVERSION FOR STB2 FROM TTAB TABLE

           MOVE 'STB2'                     TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-STBL-2-CD (WS-CVG)
                                           TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO W2340-CVG-STBL-2-CD
           ELSE
               MOVE WCVGS-CVG-STBL-2-CD (WS-CVG)
                                           TO W2340-CVG-STBL-2-CD
           END-IF.

      * MAKE CONVERSION FOR STB3 FROM TTAB TABLE

           MOVE 'STB3'                     TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-STBL-3-CD (WS-CVG)
                                           TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO W2340-CVG-STBL-3-CD
           ELSE
               MOVE WCVGS-CVG-STBL-3-CD (WS-CVG)
                                           TO W2340-CVG-STBL-3-CD
           END-IF.

      * MAKE CONVERSION FOR STB4 FROM TTAB TABLE

           MOVE 'STB4'                     TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-STBL-4-CD (WS-CVG)
                                           TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO W2340-CVG-STBL-4-CD
           ELSE
               MOVE WCVGS-CVG-STBL-4-CD (WS-CVG)
                                           TO W2340-CVG-STBL-4-CD
           END-IF.

           MOVE WCVGS-CVG-JNT-LIFE-CD (WS-CVG) TO W2340-CVG-JNT-LIFE-CD.
           MOVE WCVGS-CVG-RT-AGE (WS-CVG)  TO W2340-CVG-RT-AGE.

      * MAKE CONVERSION FOR AGE RESTRICT REASON FROM TTAB TABLE

           MOVE 'ARST'                     TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-AGE-RAT-REASN-CD (WS-CVG)
                                           TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO W2340-AGE-RAT-REASN-CD
           ELSE
               MOVE WCVGS-AGE-RAT-REASN-CD (WS-CVG)
                                           TO W2340-AGE-RAT-REASN-CD
           END-IF.

      * MAKE CONVERSION FOR INSURANCE TYPE FROM TTAB TABLE

           MOVE 'INSTP'                    TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-INS-TYP-CD (WS-CVG)
                                           TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO W2340-CVG-INS-TYP-CD
           ELSE
               MOVE WCVGS-CVG-INS-TYP-CD (WS-CVG)
                                           TO W2340-CVG-INS-TYP-CD
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                              WCVGS-CVG-FACE-AMT (WS-CVG) * 100.
020874     MOVE WCVGS-CVG-FACE-AMT (WS-CVG)  TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-FACE-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO W2340-CVG-FACE-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                            WCVGS-CVG-ME-FCT (WS-CVG) * 100.
020874     MOVE WCVGS-CVG-ME-FCT (WS-CVG)    TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-MULT-FCT
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CVG-MULT-FCT.

020874*    MOVE WCVGS-CVG-FE-DUR (WS-CVG)  TO L0290-INPUT-NUMBER.
020874     MOVE WCVGS-CVG-FE-DUR (WS-CVG)  TO L0290-INPUT-V00.
           MOVE 0                          TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-FE-DUR TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO  W2340-CVG-FE-DUR.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                           WCVGS-CVG-FE-UPREM-AMT (WS-CVG) * 100.
020874     MOVE WCVGS-CVG-FE-UPREM-AMT (WS-CVG)
020874                                     TO L0290-INPUT-V02.
           MOVE 2                          TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-FE-UPREM-AMT
                                           TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY         TO TRUE.
           SET  L0290-SIGN-POS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO W2340-CVG-FE-UPREM-AMT.

020874*    MOVE WCVGS-CVG-ME-DUR (WS-CVG)  TO L0290-INPUT-NUMBER.
020874     MOVE WCVGS-CVG-ME-DUR (WS-CVG)  TO L0290-INPUT-V00.
           MOVE 0                          TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-ME-DUR TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO  W2340-CVG-ME-DUR.

      * MAKE CONVERSION FOR TRUE TABLE RATING FROM TTAB TABLE

           MOVE 'TRATE'                    TO WTTAB-ETBL-TYP-ID.
           MOVE WCVGS-CVG-ME-RAT-CD (WS-CVG)
                                           TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                       TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT    TO W2340-CVG-ME-RAT-CD
           ELSE
               MOVE WCVGS-CVG-ME-RAT-CD (WS-CVG)
                                           TO W2340-CVG-ME-RAT-CD
           END-IF.

           MOVE WCVGS-CVG-ENHC-TYP-CD (WS-CVG) TO W2340-CVG-ENHC-TYP-CD.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG)   TO W2340-CVG-CF-TYP-CD.

020874*    MOVE WCVGS-MNPMT-TRG-LTD-AMT (WS-CVG) TO L0290-INPUT-NUMBER.
020874     MOVE WCVGS-MNPMT-TRG-LTD-AMT (WS-CVG) TO L0290-INPUT-V00.
           MOVE 0                           TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MNPMT-TRG-LTD-AMT
                                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO W2340-MNPMT-TRG-LTD-AMT.

020874*    MOVE WCVGS-CVG-SURR-TRG-AMT (WS-CVG) TO L0290-INPUT-NUMBER.
020874     MOVE WCVGS-CVG-SURR-TRG-AMT (WS-CVG) TO L0290-INPUT-V00.
           MOVE 0                           TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-SURR-TRG-AMT
                                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO W2340-CVG-SURR-TRG-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                   WCVGS-CVG-SURR-LTD-AMT (WS-CVG) * 100.
020874     MOVE WCVGS-CVG-SURR-LTD-AMT (WS-CVG)
020874                                      TO L0290-INPUT-V02.
           MOVE 2                           TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-SURR-LTD-AMT
                                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO W2340-CVG-SURR-LTD-AMT.

           PERFORM  8511-MOVE-TO-INSURED-REC
               THRU 8511-MOVE-TO-INSURED-REC-X.

           PERFORM  8515-GET-ATD-ACUM-CV-AMT
               THRU 8515-GET-ATD-ACUM-CV-AMT-X.

           MOVE W2340-CVG-ARRAY-REC         TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8510-UPDATE-NORMAL-CVG-X.
           EXIT.
      /
      *-------------------------
       8511-MOVE-TO-INSURED-REC.
      *-------------------------

           MOVE  SPACES        TO  WCVGC-KEY.
           MOVE  RPOL-POL-ID   TO  WCVGC-POL-ID.
           MOVE  WS-CVG        TO  WCVGC-CVG-NUM-N.

           MOVE  WCVGC-KEY     TO  WCVGC-ENDBR-KEY.
           MOVE  HIGH-VALUES   TO  WCVGC-ENDBR-CVG-CLI-REL-TYP-CD.

           PERFORM  CVGC-1000-BROWSE
               THRU CVGC-1000-BROWSE-X.

           IF  WCVGC-IO-EOF
               GO TO  8511-MOVE-TO-INSURED-REC-X
           END-IF.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

           MOVE +2  TO  WS-SUB.
           INITIALIZE WS-CVG-CLI-AGE-FLDS.
           PERFORM  8512-SET-UP-EACH-INSURED
               THRU 8512-SET-UP-EACH-INSURED-X
               UNTIL  WCVGC-IO-EOF.

           PERFORM  CVGC-3000-END-BROWSE
               THRU CVGC-3000-END-BROWSE-X.

           MOVE WS-CVG-CLI-CLI-ID (1)   TO W2340-CVG-CLI-ID-1.
           MOVE WS-CVG-CLI-CLI-ID (2)   TO W2340-CVG-CLI-ID-2.
           MOVE WS-CVG-CLI-CLI-ID (3)   TO W2340-CVG-CLI-ID-3.
           MOVE WS-CVG-CLI-CLI-ID (4)   TO W2340-CVG-CLI-ID-4.
           MOVE WS-CVG-CLI-CLI-ID (5)   TO W2340-CVG-CLI-ID-5.

       8511-MOVE-TO-INSURED-REC-X.
           EXIT.
      /
      *-------------------------
       8512-SET-UP-EACH-INSURED.
      *-------------------------
      *
      *  MAKE SURE THE PRIMARY INSURED IS ALWAYS DISPLAYED FIRST
      *
           MOVE  WS-SUB                   TO WS-HOLD-SUB.
           IF  RCVGC-CVG-CLI-REL-TYP-CD  =  'P'
               MOVE +1                    TO WS-SUB
           END-IF.

           IF  WS-SUB < +6
               MOVE RCVGC-INSRD-CLI-ID    TO WS-CVG-CLI-CLI-ID  (WS-SUB)
           END-IF.

           MOVE  WS-HOLD-SUB              TO WS-SUB.
           ADD  +1                        TO WS-SUB.
           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       8512-SET-UP-EACH-INSURED-X.
           EXIT.
      /
      *-------------------------
       8515-GET-ATD-ACUM-CV-AMT.
      *-------------------------

           INITIALIZE L6980-INPUT-PARM-INFO.
           INITIALIZE L6980-IO-PARM-INFO.

           MOVE '01'                  TO WS-CVG-NUM.
           MOVE WS-CVG-NUM-R          TO L6980-CVG.
021657*    MOVE MIR-PROJ-DT           TO WS-SCREEN-DATE.
021657     MOVE MIR-DV-PROJ-DT        TO WS-SCREEN-DATE.
           MOVE WS-SCREEN-DATE        TO L6980-SCREEN-DATE.
           MOVE WS-PROJ-DT            TO L6980-EFF-DT.

           PERFORM  6980-1000-INQUIRE
               THRU 6980-1000-INQUIRE-X.

020874*    COMPUTE L0290-INPUT-NUMBER = L6980-AVAL-T (WS-CVG) * 100.
020874     MOVE L6980-AVAL-T (WS-CVG)    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-DV-ATD-ACUM-CV-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-DV-ATD-ACUM-CV-AMT.

       8515-GET-ATD-ACUM-CV-AMT-X.
           EXIT.
      /
      *----------------------
       8520-UPDATE-EMBED-CVG.
      *----------------------

           PERFORM  8521-UPDATE-WP-CVG
               THRU 8521-UPDATE-WP-CVG-X.

           IF  WS-DATA-OVERFLOW
               GO TO 8520-UPDATE-EMBED-CVG-X
           END-IF.

           PERFORM  8522-UPDATE-AD-CVG
               THRU 8522-UPDATE-AD-CVG-X.

           IF  WS-DATA-OVERFLOW
               GO TO 8520-UPDATE-EMBED-CVG-X
           END-IF.

       8520-UPDATE-EMBED-CVG-X.
           EXIT.
      /
      *-------------------
       8521-UPDATE-WP-CVG.
      *-------------------

           IF  NOT WCVGS-CVG-WP (WS-CVG)
               GO TO 8521-UPDATE-WP-CVG-X
           END-IF.

           ADD +1                   TO WS-PROJ-SUB.
           IF  WS-PROJ-SUB > WS-MAX-PROJ-SUB
               SET WS-DATA-OVERFLOW TO TRUE
               GO TO 8521-UPDATE-WP-CVG-X
           END-IF.

021657*    SET MIR-DV-PROJ-ARRAY-EMBED-CVG-T (WS-PROJ-SUB)
021657     SET MIR-DV-PROJ-INFO-EMBED-CVG-T (WS-PROJ-SUB)
                                    TO TRUE.

           MOVE SPACES              TO W2340-CVG-ARRAY-REC.

           PERFORM  8510-UPDATE-NORMAL-CVG
               THRU 8510-UPDATE-NORMAL-CVG-X.

           MOVE '01'                TO W2340-DV-EMBED-NUM.
           MOVE 'WP'                TO W2340-DV-EMBED-ID.

           MOVE WCVGS-CVG-WP-XPRY-DT (WS-CVG) TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-CVG-MAT-XPRY-DT.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                            WCVGS-CVG-WP-MULT-FCT (WS-CVG) * 100.
020874     MOVE WCVGS-CVG-WP-MULT-FCT (WS-CVG)
020874                              TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-MULT-FCT
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CVG-MULT-FCT.

           MOVE W2340-CVG-ARRAY-REC TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8521-UPDATE-WP-CVG-X.
           EXIT.
      /
      *-------------------
       8522-UPDATE-AD-CVG.
      *-------------------

           IF  WCVGS-CVG-AD-MULT-FCT (WS-CVG) = ZERO
               GO TO 8522-UPDATE-AD-CVG-X
           END-IF.

           ADD +1                   TO WS-PROJ-SUB.
           IF  WS-PROJ-SUB > WS-MAX-PROJ-SUB
               SET WS-DATA-OVERFLOW TO TRUE
               GO TO 8522-UPDATE-AD-CVG-X
           END-IF.

021657*    SET MIR-DV-PROJ-ARRAY-EMBED-CVG-T (WS-PROJ-SUB)
021657     SET MIR-DV-PROJ-INFO-EMBED-CVG-T (WS-PROJ-SUB)
                                    TO TRUE.

           MOVE SPACES              TO W2340-CVG-ARRAY-REC.

           PERFORM  8510-UPDATE-NORMAL-CVG
               THRU 8510-UPDATE-NORMAL-CVG-X.

           MOVE '02'                TO W2340-DV-EMBED-NUM.
           MOVE 'AD'                TO W2340-DV-EMBED-ID.

           MOVE WCVGS-CVG-AD-XPRY-DT (WS-CVG) TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-CVG-MAT-XPRY-DT.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                           WCVGS-CVG-AD-FACE-AMT (WS-CVG) * 100.
020874     MOVE WCVGS-CVG-AD-FACE-AMT (WS-CVG) TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-AD-FACE-AMT
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CVG-AD-FACE-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                            WCVGS-CVG-AD-MULT-FCT (WS-CVG) * 100.
020874     MOVE WCVGS-CVG-AD-MULT-FCT (WS-CVG) TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CVG-MULT-FCT
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CVG-MULT-FCT.

           MOVE W2340-CVG-ARRAY-REC TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8522-UPDATE-AD-CVG-X.
           EXIT.
      /
      *-----------------------------
       8600-MOVE-INSURED-REC-TO-MIR.
      *-----------------------------

           MOVE  SPACES        TO  WCVGC-KEY.
           MOVE  RPOL-POL-ID   TO  WCVGC-POL-ID.

           MOVE  WCVGC-KEY     TO  WCVGC-ENDBR-KEY.
           MOVE  HIGH-VALUES   TO  WCVGC-ENDBR-CVG-NUM.

           PERFORM  CVGC-1000-BROWSE
               THRU CVGC-1000-BROWSE-X.

           IF  WCVGC-IO-OK
               PERFORM  CVGC-2000-READ-NEXT
                   THRU CVGC-2000-READ-NEXT-X
           ELSE
               GO TO 8600-MOVE-INSURED-REC-TO-MIR-X
           END-IF.

           IF  NOT WCVGC-IO-OK
               PERFORM  CVGC-3000-END-BROWSE
                   THRU CVGC-3000-END-BROWSE-X
               GO TO 8600-MOVE-INSURED-REC-TO-MIR-X
           END-IF.

           MOVE ZERO           TO WS-REC-SUB.
           COMPUTE WS-HOLD-SUB =  WS-PROJ-SUB + 1.

           PERFORM  8610-MOVE-CVGC-REC
               THRU 8610-MOVE-CVGC-REC-X
               UNTIL  WCVGC-IO-EOF
               OR     WS-DATA-OVERFLOW.

           PERFORM  CVGC-3000-END-BROWSE
               THRU CVGC-3000-END-BROWSE-X.

       8600-MOVE-INSURED-REC-TO-MIR-X.
           EXIT.
      /
      *-------------------
       8610-MOVE-CVGC-REC.
      *-------------------

      * CHECK WHETHER THE INSURED CLIENT IS DUPLICATED

           SET  WS-REC-NOT-FOUND        TO TRUE.
           MOVE W2340-INSURED-CLI-ARRAY-REC
                                        TO WS-HOLD-REC.

           PERFORM  8620-CHECK-DUPLICATE-INSURED
               THRU 8620-CHECK-DUPLICATE-INSURED-X
               VARYING WS-DUP-SUB FROM WS-HOLD-SUB BY 1
               UNTIL WS-DUP-SUB > WS-PROJ-SUB
                  OR WS-REC-FOUND.

           MOVE WS-HOLD-REC             TO W2340-INSURED-CLI-ARRAY-REC.

           IF  WS-REC-FOUND
               PERFORM  CVGC-2000-READ-NEXT
                   THRU CVGC-2000-READ-NEXT-X
               GO TO 8610-MOVE-CVGC-REC-X
           END-IF.

      * MOVE INSURED RECORDS TO MIR

           IF  WS-REC-SUB = ZERO
               ADD +1                   TO WS-PROJ-SUB
               IF  WS-PROJ-SUB > WS-MAX-PROJ-SUB
                   SET WS-DATA-OVERFLOW TO TRUE
                   GO TO 8610-MOVE-CVGC-REC-X
               END-IF
021657*        SET MIR-DV-PROJ-ARRAY-INSURED-T (WS-PROJ-SUB)
021657         SET MIR-DV-PROJ-INFO-INSURED-T (WS-PROJ-SUB)
                                        TO TRUE
               MOVE SPACES              TO W2340-INSURED-CLI-ARRAY-REC
           END-IF.

           ADD +1                       TO WS-REC-SUB.

           IF  WS-REC-SUB = 1
               PERFORM  8611-MOVE-TO-MIR-INSURED-1
                   THRU 8611-MOVE-TO-MIR-INSURED-1-X
           END-IF.

           IF  WS-REC-SUB = 2
               PERFORM  8612-MOVE-TO-MIR-INSURED-2
                   THRU 8612-MOVE-TO-MIR-INSURED-2-X
           END-IF.

           IF  WS-REC-SUB = 3
               PERFORM  8613-MOVE-TO-MIR-INSURED-3
                   THRU 8613-MOVE-TO-MIR-INSURED-3-X
               MOVE ZERO                TO WS-REC-SUB
           END-IF.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       8610-MOVE-CVGC-REC-X.
           EXIT.
      /
      *---------------------------
       8611-MOVE-TO-MIR-INSURED-1.
      *---------------------------

           MOVE RCVGC-INSRD-CLI-ID     TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  NOT L2437-RETRN-OK
               GO TO 8611-MOVE-TO-MIR-INSURED-1-X
           END-IF.

           MOVE L2437-CLI-ID           TO W2340-INSURED-CLI-ID-1.

      * MAKE CONVERSION FOR SEX CODE FROM TTAB TABLE

           MOVE 'SEX'                  TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-SEX-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                   TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-SEX-CD-1
           ELSE
               MOVE L2437-CLI-SEX-CD    TO W2340-CLI-SEX-CD-1
           END-IF.

           MOVE L2437-CLI-BTH-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO W2340-CLI-BTH-DT-1.

      * MAKE CONVERSION FOR SMOKER CODE FROM TTAB TABLE

           MOVE 'SMOKE'                TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-SMKR-CD      TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                   TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-SMKR-CD-1
           ELSE
               MOVE L2437-CLI-SMKR-CD   TO W2340-CLI-SMKR-CD-1
           END-IF.

      * MAKE CONVERSION FOR LANGUAGE CODE FROM TTAB TABLE

           MOVE 'LANG'                  TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-LANG-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                    TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-LANG-CD-1
           ELSE
               MOVE L2437-CLI-LANG-CD   TO W2340-CLI-LANG-CD-1
           END-IF.

           MOVE L2437-CLI-ENTR-GIV-NM  TO W2340-CLI-GIV-NM-1.
           MOVE L2437-CLI-ENTR-SUR-NM  TO W2340-CLI-SUR-NM-1.
           MOVE L2437-CLI-MID-INIT-NM  TO W2340-CLI-MID-INIT-NM-1.

           MOVE W2340-INSURED-CLI-ARRAY-REC TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8611-MOVE-TO-MIR-INSURED-1-X.
           EXIT.
      /
      *---------------------------
       8612-MOVE-TO-MIR-INSURED-2.
      *---------------------------

           MOVE RCVGC-INSRD-CLI-ID     TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  NOT L2437-RETRN-OK
               GO TO 8612-MOVE-TO-MIR-INSURED-2-X
           END-IF.

           MOVE L2437-CLI-ID           TO W2340-INSURED-CLI-ID-2.

      * MAKE CONVERSION FOR SEX CODE FROM TTAB TABLE

           MOVE 'SEX'                  TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-SEX-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                   TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-SEX-CD-2
           ELSE
               MOVE L2437-CLI-SEX-CD    TO W2340-CLI-SEX-CD-2
           END-IF.

           MOVE L2437-CLI-BTH-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO W2340-CLI-BTH-DT-2.

      * MAKE CONVERSION FOR SMOKER CODE FROM TTAB TABLE

           MOVE 'SMOKE'                TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-SMKR-CD      TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                   TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-SMKR-CD-2
           ELSE
               MOVE L2437-CLI-SMKR-CD   TO W2340-CLI-SMKR-CD-2
           END-IF.

      * MAKE CONVERSION FOR LANGUAGE CODE FROM TTAB TABLE

           MOVE 'LANG'                  TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-LANG-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                    TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-LANG-CD-2
           ELSE
               MOVE L2437-CLI-LANG-CD   TO W2340-CLI-LANG-CD-2
           END-IF.

           MOVE L2437-CLI-ENTR-GIV-NM  TO W2340-CLI-GIV-NM-2.
           MOVE L2437-CLI-ENTR-SUR-NM  TO W2340-CLI-SUR-NM-2.
           MOVE L2437-CLI-MID-INIT-NM  TO W2340-CLI-MID-INIT-NM-2.

           MOVE W2340-INSURED-CLI-ARRAY-REC TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8612-MOVE-TO-MIR-INSURED-2-X.
           EXIT.
      /
      *---------------------------
       8613-MOVE-TO-MIR-INSURED-3.
      *---------------------------

           MOVE RCVGC-INSRD-CLI-ID     TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  NOT L2437-RETRN-OK
               GO TO 8613-MOVE-TO-MIR-INSURED-3-X
           END-IF.

           MOVE L2437-CLI-ID           TO W2340-INSURED-CLI-ID-3.

      * MAKE CONVERSION FOR SEX CODE FROM TTAB TABLE

           MOVE 'SEX'                  TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-SEX-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                   TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-SEX-CD-3
           ELSE
               MOVE L2437-CLI-SEX-CD    TO W2340-CLI-SEX-CD-3
           END-IF.

           MOVE L2437-CLI-BTH-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO W2340-CLI-BTH-DT-3.

      * MAKE CONVERSION FOR SMOKER CODE FROM TTAB TABLE

           MOVE 'SMOKE'                TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-SMKR-CD      TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                   TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-SMKR-CD-3
           ELSE
               MOVE L2437-CLI-SMKR-CD   TO W2340-CLI-SMKR-CD-3
           END-IF.

      * MAKE CONVERSION FOR LANGUAGE CODE FROM TTAB TABLE

           MOVE 'LANG'                  TO WTTAB-ETBL-TYP-ID.
           MOVE L2437-CLI-LANG-CD       TO WTTAB-ETBL-VALU-ID.
           MOVE 'IL'                    TO WTTAB-TTBL-SYS-ID.

           PERFORM  TTAB-1000-READ
               THRU TTAB-1000-READ-X.

           IF  WTTAB-IO-OK
               MOVE RTTAB-TTBL-VALU-TXT TO W2340-CLI-LANG-CD-3
           ELSE
               MOVE L2437-CLI-LANG-CD   TO W2340-CLI-LANG-CD-3
           END-IF.

           MOVE L2437-CLI-ENTR-GIV-NM  TO W2340-CLI-GIV-NM-3.
           MOVE L2437-CLI-ENTR-SUR-NM  TO W2340-CLI-SUR-NM-3.
           MOVE L2437-CLI-MID-INIT-NM  TO W2340-CLI-MID-INIT-NM-3.

           MOVE W2340-INSURED-CLI-ARRAY-REC TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8613-MOVE-TO-MIR-INSURED-3-X.
           EXIT.
      /
      *-----------------------------
       8620-CHECK-DUPLICATE-INSURED.
      *-----------------------------

021657*    IF  NOT MIR-DV-PROJ-ARRAY-INSURED-T (WS-DUP-SUB)
021657     IF  NOT MIR-DV-PROJ-INFO-INSURED-T (WS-DUP-SUB)
               GO TO 8620-CHECK-DUPLICATE-INSURED-X
           END-IF.

021657*    MOVE MIR-DV-PROJ-ARRAY-REC-T (WS-DUP-SUB)
021657     MOVE MIR-DV-PROJ-INFO-T (WS-DUP-SUB)
                                   TO W2340-INSURED-CLI-ARRAY-REC.

           IF  RCVGC-INSRD-CLI-ID = W2340-INSURED-CLI-ID-1
               SET WS-REC-FOUND    TO TRUE
               GO TO 8620-CHECK-DUPLICATE-INSURED-X
           END-IF.

           IF  RCVGC-INSRD-CLI-ID = W2340-INSURED-CLI-ID-2
               SET WS-REC-FOUND    TO TRUE
               GO TO 8620-CHECK-DUPLICATE-INSURED-X
           END-IF.

           IF  RCVGC-INSRD-CLI-ID = W2340-INSURED-CLI-ID-3
               SET WS-REC-FOUND    TO TRUE
               GO TO 8620-CHECK-DUPLICATE-INSURED-X
           END-IF.

       8620-CHECK-DUPLICATE-INSURED-X.
           EXIT.
      /
      *--------------------------
       8700-MOVE-FUND-REC-TO-MIR.
      *--------------------------

           MOVE RPOL-POL-ID              TO WCDSI-POL-ID.
           MOVE LOW-VALUES               TO WCDSI-CDI-TYP-CD.
           MOVE 00000                    TO WCDSI-POL-PAYO-NUM.
           MOVE LOW-VALUES               TO WCDSI-CDI-EFF-IDT-NUM.
023112     MOVE +001                     TO WCDSI-CDI-SEQ-NUM.
           MOVE 000                      TO WCDSI-CDI-ALLOC-NUM.

           MOVE WCDSI-KEY                TO WCDSI-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WCDSI-ENDBR-CDI-TYP-CD.
           MOVE 99999                    TO WCDSI-ENDBR-POL-PAYO-NUM.
           MOVE HIGH-VALUES              TO WCDSI-ENDBR-CDI-EFF-IDT-NUM.
           MOVE 999                      TO WCDSI-ENDBR-CDI-ALLOC-NUM.

           PERFORM  CDSI-1000-BROWSE
               THRU CDSI-1000-BROWSE-X.

           IF  WCDSI-IO-OK
               PERFORM  CDSI-2000-READ-NEXT
                   THRU CDSI-2000-READ-NEXT-X
           ELSE
               GO TO 8700-MOVE-FUND-REC-TO-MIR-X
           END-IF.

           IF  NOT WCDSI-IO-OK
               PERFORM  CDSI-3000-END-BROWSE
                   THRU CDSI-3000-END-BROWSE-X
               GO TO 8700-MOVE-FUND-REC-TO-MIR-X
           END-IF.

           MOVE ZERO                     TO WS-REC-SUB.
           SET WS-CDI-SUBSEQ-PREM-NOT-FOUND TO TRUE.
           SET WS-CDI-ASSET-REBAL-NOT-FOUND TO TRUE.
           SET WS-CDI-DCA-NOT-FOUND         TO TRUE.
           SET WS-CDI-CNTRCT-PAYO-NOT-FOUND TO TRUE.
           MOVE SPACES                   TO WS-CDI-SUBSEQ-PREM-EFF-IDT.
           MOVE SPACES                   TO WS-CDI-ASSET-REBAL-EFF-IDT.
           MOVE SPACES                   TO WS-CDI-DCA-EFF-IDT.
           MOVE SPACES                   TO WS-CDI-CNTRCT-PAYO-EFF-IDT.

           PERFORM  8710-MOVE-CDSI-REC
               THRU 8710-MOVE-CDSI-REC-X
               UNTIL WCDSI-IO-EOF
               OR    WS-DATA-OVERFLOW.

           PERFORM  CDSI-3000-END-BROWSE
               THRU CDSI-3000-END-BROWSE-X.

       8700-MOVE-FUND-REC-TO-MIR-X.
           EXIT.
      /
      *-------------------
       8710-MOVE-CDSI-REC.
      *-------------------

      * DON'T PROCESS ANY MORE RECORDS IF ALL REQUIRED TYPES
      * HAVE BEEN FOUND

           IF  WS-CDI-SUBSEQ-PREM-FOUND
           AND WS-CDI-ASSET-REBAL-FOUND
           AND WS-CDI-DCA-FOUND
           AND WS-CDI-CNTRCT-PAYO-FOUND
               SET WCDSI-IO-EOF          TO TRUE
               GO TO 8710-MOVE-CDSI-REC-X
           END-IF.

      * REQUIRE RCDSI-CDI-TYP-CD = S, R, C, F ONLY

           IF  RCDSI-CDI-TYP-SUBSEQ-PREM
           OR  RCDSI-CDI-TYP-ASSET-REBAL
           OR  RCDSI-CDI-TYP-DCA
           OR  RCDSI-CDI-TYP-CNTRCT-PAYO
               CONTINUE
           ELSE
               PERFORM  CDSI-2000-READ-NEXT
                   THRU CDSI-2000-READ-NEXT-X
               GO TO 8710-MOVE-CDSI-REC-X
           END-IF.

           IF  RCDSI-CDI-TYP-SUBSEQ-PREM
           OR  RCDSI-CDI-TYP-ASSET-REBAL
           OR  RCDSI-CDI-TYP-DCA
               IF  RCDSI-CDI-EFF-DT <= WS-PROJ-DT
                   CONTINUE
               ELSE
                   PERFORM  CDSI-2000-READ-NEXT
                       THRU CDSI-2000-READ-NEXT-X
                   GO TO 8710-MOVE-CDSI-REC-X
               END-IF
           END-IF.

           IF  RCDSI-CDI-TYP-CNTRCT-PAYO
               PERFORM  8720-EDIT-CNTRCT-PAYO
                   THRU 8720-EDIT-CNTRCT-PAYO-X

               IF  WS-EDIT-ERROR
                   PERFORM  CDSI-2000-READ-NEXT
                       THRU CDSI-2000-READ-NEXT-X
                   GO TO 8710-MOVE-CDSI-REC-X
               END-IF
           END-IF.

      *  ONLY STORE ONE OF EACH RECORD TYPE REQUIRED

           IF  RCDSI-CDI-TYP-SUBSEQ-PREM
               IF  WS-CDI-SUBSEQ-PREM-NOT-FOUND
               OR  RCDSI-CDI-EFF-IDT-NUM = WS-CDI-SUBSEQ-PREM-EFF-IDT
                   MOVE RCDSI-CDI-EFF-IDT-NUM
                                        TO WS-CDI-SUBSEQ-PREM-EFF-IDT
                   SET WS-CDI-SUBSEQ-PREM-FOUND   TO TRUE
               ELSE
                   PERFORM  CDSI-2000-READ-NEXT
                       THRU CDSI-2000-READ-NEXT-X
                   GO TO 8710-MOVE-CDSI-REC-X
               END-IF
           END-IF.

           IF  RCDSI-CDI-TYP-ASSET-REBAL
               IF WS-CDI-ASSET-REBAL-NOT-FOUND
               OR RCDSI-CDI-EFF-IDT-NUM = WS-CDI-ASSET-REBAL-EFF-IDT
                   MOVE RCDSI-CDI-EFF-IDT-NUM
                                       TO WS-CDI-ASSET-REBAL-EFF-IDT
                   SET WS-CDI-ASSET-REBAL-FOUND   TO TRUE
               ELSE
                   PERFORM  CDSI-2000-READ-NEXT
                       THRU CDSI-2000-READ-NEXT-X
                   GO TO 8710-MOVE-CDSI-REC-X
               END-IF
           END-IF.

           IF  RCDSI-CDI-TYP-DCA
               IF WS-CDI-DCA-NOT-FOUND
               OR RCDSI-CDI-EFF-IDT-NUM = WS-CDI-DCA-EFF-IDT
                   MOVE RCDSI-CDI-EFF-IDT-NUM  TO WS-CDI-DCA-EFF-IDT
                   SET WS-CDI-DCA-FOUND           TO TRUE
               ELSE
                   PERFORM  CDSI-2000-READ-NEXT
                       THRU CDSI-2000-READ-NEXT-X
                   GO TO 8710-MOVE-CDSI-REC-X
               END-IF
           END-IF.

           IF  RCDSI-CDI-TYP-CNTRCT-PAYO
               IF WS-CDI-CNTRCT-PAYO-NOT-FOUND
               OR RCDSI-CDI-EFF-IDT-NUM = WS-CDI-CNTRCT-PAYO-EFF-IDT
                   MOVE RCDSI-CDI-EFF-IDT-NUM
                                       TO WS-CDI-CNTRCT-PAYO-EFF-IDT
                   SET WS-CDI-CNTRCT-PAYO-FOUND   TO TRUE
               ELSE
                   PERFORM  CDSI-2000-READ-NEXT
                       THRU CDSI-2000-READ-NEXT-X
                   GO TO 8710-MOVE-CDSI-REC-X
               END-IF
           END-IF.

      *
      * MOVE PAYOUT RECORDS TO MIR
      *
           IF  WS-REC-SUB = ZERO
               ADD +1                   TO WS-PROJ-SUB
               IF  WS-PROJ-SUB > WS-MAX-PROJ-SUB
                   SET WS-DATA-OVERFLOW     TO TRUE
                   GO TO 8710-MOVE-CDSI-REC-X
               END-IF
021657*        SET MIR-DV-PROJ-ARRAY-FUND-T (WS-PROJ-SUB)   TO TRUE
021657         SET MIR-DV-PROJ-INFO-FUND-T (WS-PROJ-SUB)   TO TRUE
               MOVE SPACES              TO W2340-FUND-ARRAY-REC
           END-IF.

           ADD +1                       TO WS-REC-SUB.

           IF  WS-REC-SUB = 1
               PERFORM  8711-MOVE-TO-MIR-FUND-1
                   THRU 8711-MOVE-TO-MIR-FUND-1-X
           END-IF.

           IF  WS-REC-SUB = 2
               PERFORM  8712-MOVE-TO-MIR-FUND-2
                   THRU 8712-MOVE-TO-MIR-FUND-2-X
           END-IF.

           IF  WS-REC-SUB = 3
               PERFORM  8713-MOVE-TO-MIR-FUND-3
                   THRU 8713-MOVE-TO-MIR-FUND-3-X
           END-IF.

           IF  WS-REC-SUB = 4
               PERFORM  8714-MOVE-TO-MIR-FUND-4
                   THRU 8714-MOVE-TO-MIR-FUND-4-X
           END-IF.

           IF  WS-REC-SUB = 5
               PERFORM  8715-MOVE-TO-MIR-FUND-5
                   THRU 8715-MOVE-TO-MIR-FUND-5-X
               MOVE ZERO                TO WS-REC-SUB
           END-IF.

           PERFORM  CDSI-2000-READ-NEXT
               THRU CDSI-2000-READ-NEXT-X.

       8710-MOVE-CDSI-REC-X.
           EXIT.
      /
      *------------------------
       8711-MOVE-TO-MIR-FUND-1.
      *------------------------

           MOVE RCDSI-CDI-TYP-CD    TO W2340-CDI-TYP-CD-1.

           MOVE RCDSI-CDI-EFF-IDT-NUM TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE TO W2340-CDI-EFF-DT-1.

           MOVE RCDSI-DEST-CVG-NUM  TO W2340-CVG-NUM-1.
           MOVE RCDSI-CDI-ALLOC-CD  TO W2340-CDI-ALLOC-CD-1.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-PCT
020874*                                 * 10000.
020874     MOVE RCDSI-CDI-ALLOC-PCT TO L0290-INPUT-V04.
           MOVE 4                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CDI-ALLOC-PCT-1
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-PCT-1.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-AMT
020874*                                 * 100
020874     MOVE RCDSI-CDI-ALLOC-AMT TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION
           MOVE LENGTH OF W2340-CDI-ALLOC-AMT-1
                                    TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-AMT-1.

           MOVE RCDSI-DPOS-TRM-MO-DUR TO W2340-DPOS-TRM-MO-DUR-1.
           MOVE RCDSI-DPOS-TRM-DY-DUR TO W2340-DPOS-TRM-DY-DUR-1.
           MOVE RCDSI-DEST-FND-ID     TO W2340-DEST-FND-ID-1.

           MOVE W2340-FUND-ARRAY-REC  TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8711-MOVE-TO-MIR-FUND-1-X.
           EXIT.
      /
      *------------------------
       8712-MOVE-TO-MIR-FUND-2.
      *------------------------

           MOVE RCDSI-CDI-TYP-CD    TO W2340-CDI-TYP-CD-2.

           MOVE RCDSI-CDI-EFF-IDT-NUM TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE TO W2340-CDI-EFF-DT-2.

           MOVE RCDSI-DEST-CVG-NUM  TO W2340-CVG-NUM-2.
           MOVE RCDSI-CDI-ALLOC-CD  TO W2340-CDI-ALLOC-CD-2.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-PCT
020874*                                 * 10000.
020874     MOVE RCDSI-CDI-ALLOC-PCT TO L0290-INPUT-V04.
           MOVE 4                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CDI-ALLOC-PCT-2
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-PCT-2.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-AMT
020874*                                 * 100
020874     MOVE RCDSI-CDI-ALLOC-AMT TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION
           MOVE LENGTH OF W2340-CDI-ALLOC-AMT-2
                                    TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-AMT-2.

           MOVE RCDSI-DPOS-TRM-MO-DUR TO W2340-DPOS-TRM-MO-DUR-2.
           MOVE RCDSI-DPOS-TRM-DY-DUR TO W2340-DPOS-TRM-DY-DUR-2.
           MOVE RCDSI-DEST-FND-ID     TO W2340-DEST-FND-ID-2.

           MOVE W2340-FUND-ARRAY-REC  TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8712-MOVE-TO-MIR-FUND-2-X.
           EXIT.
      /
      *------------------------
       8713-MOVE-TO-MIR-FUND-3.
      *------------------------

           MOVE RCDSI-CDI-TYP-CD    TO W2340-CDI-TYP-CD-3.

           MOVE RCDSI-CDI-EFF-IDT-NUM TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE TO W2340-CDI-EFF-DT-3.

           MOVE RCDSI-DEST-CVG-NUM  TO W2340-CVG-NUM-3.
           MOVE RCDSI-CDI-ALLOC-CD  TO W2340-CDI-ALLOC-CD-3.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-PCT
020874*                                 * 10000.
020874     MOVE RCDSI-CDI-ALLOC-PCT TO L0290-INPUT-V04.
           MOVE 4                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CDI-ALLOC-PCT-3
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-PCT-3.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-AMT
020874*                                 * 100
020874     MOVE RCDSI-CDI-ALLOC-AMT TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION
           MOVE LENGTH OF W2340-CDI-ALLOC-AMT-3
                                    TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-AMT-3.

           MOVE RCDSI-DPOS-TRM-MO-DUR TO W2340-DPOS-TRM-MO-DUR-3.
           MOVE RCDSI-DPOS-TRM-DY-DUR TO W2340-DPOS-TRM-DY-DUR-3.
           MOVE RCDSI-DEST-FND-ID     TO W2340-DEST-FND-ID-3.

           MOVE W2340-FUND-ARRAY-REC  TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8713-MOVE-TO-MIR-FUND-3-X.
           EXIT.
      /
      *------------------------
       8714-MOVE-TO-MIR-FUND-4.
      *------------------------

           MOVE RCDSI-CDI-TYP-CD    TO W2340-CDI-TYP-CD-4.

           MOVE RCDSI-CDI-EFF-IDT-NUM TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE TO W2340-CDI-EFF-DT-4.

           MOVE RCDSI-DEST-CVG-NUM  TO W2340-CVG-NUM-4.
           MOVE RCDSI-CDI-ALLOC-CD  TO W2340-CDI-ALLOC-CD-4.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-PCT
020874*                                 * 10000.
020874     MOVE RCDSI-CDI-ALLOC-PCT TO L0290-INPUT-V04.
           MOVE 4                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CDI-ALLOC-PCT-4
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-PCT-4.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-AMT
020874*                                 * 100
020874     MOVE RCDSI-CDI-ALLOC-AMT TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION
           MOVE LENGTH OF W2340-CDI-ALLOC-AMT-4
                                    TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-AMT-4.

           MOVE RCDSI-DPOS-TRM-MO-DUR TO W2340-DPOS-TRM-MO-DUR-4.
           MOVE RCDSI-DPOS-TRM-DY-DUR TO W2340-DPOS-TRM-DY-DUR-4.
           MOVE RCDSI-DEST-FND-ID     TO W2340-DEST-FND-ID-4.

           MOVE W2340-FUND-ARRAY-REC  TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8714-MOVE-TO-MIR-FUND-4-X.
           EXIT.
      /
      *------------------------
       8715-MOVE-TO-MIR-FUND-5.
      *------------------------

           MOVE RCDSI-CDI-TYP-CD    TO W2340-CDI-TYP-CD-5.

           MOVE RCDSI-CDI-EFF-IDT-NUM TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE TO W2340-CDI-EFF-DT-5.

           MOVE RCDSI-DEST-CVG-NUM  TO W2340-CVG-NUM-5.
           MOVE RCDSI-CDI-ALLOC-CD  TO W2340-CDI-ALLOC-CD-5.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-PCT
020874*                                 * 10000.
020874     MOVE RCDSI-CDI-ALLOC-PCT TO L0290-INPUT-V04.
           MOVE 4                   TO L0290-PRECISION.
           MOVE LENGTH OF W2340-CDI-ALLOC-PCT-5
                                    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-PCT-5.

020874*    COMPUTE L0290-INPUT-NUMBER = RCDSI-CDI-ALLOC-AMT
020874*                                 * 100
020874     MOVE RCDSI-CDI-ALLOC-AMT TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION
           MOVE LENGTH OF W2340-CDI-ALLOC-AMT-5
                                    TO L0290-MAX-OUT-LEN
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO W2340-CDI-ALLOC-AMT-5.

           MOVE RCDSI-DPOS-TRM-MO-DUR TO W2340-DPOS-TRM-MO-DUR-5.
           MOVE RCDSI-DPOS-TRM-DY-DUR TO W2340-DPOS-TRM-DY-DUR-5.
           MOVE RCDSI-DEST-FND-ID     TO W2340-DEST-FND-ID-5.

           MOVE W2340-FUND-ARRAY-REC  TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8715-MOVE-TO-MIR-FUND-5-X.
           EXIT.
      /
      *----------------------
       8720-EDIT-CNTRCT-PAYO.
      *----------------------

           SET WS-EDIT-OK               TO TRUE.

           IF  RCDSI-CDI-EFF-DT >= WS-PROJ-DT
               CONTINUE
           ELSE
               SET WS-EDIT-ERROR        TO TRUE
               GO TO 8720-EDIT-CNTRCT-PAYO-X
           END-IF.
      *
      * CHECK WHETHER THE PAYOUT RECORD IS ACTIVE
      *
           MOVE RCDSI-POL-ID            TO WPOLP-POL-ID.
           MOVE RCDSI-POL-PAYO-NUM      TO WPOLP-POL-PAYO-NUM.

           PERFORM  POLP-1000-READ
               THRU POLP-1000-READ-X.

           IF  NOT WPOLP-IO-OK
               SET WS-EDIT-ERROR        TO TRUE
               GO TO 8720-EDIT-CNTRCT-PAYO-X
           END-IF.

           IF  NOT RPOLP-POL-PAYO-STAT-ACTIVE
               SET WS-EDIT-ERROR        TO TRUE
               GO TO 8720-EDIT-CNTRCT-PAYO-X
           END-IF.

       8720-EDIT-CNTRCT-PAYO-X.
           EXIT.
      /
      *---------------------------
       8800-MOVE-WTHDR-REC-TO-MIR.
      *---------------------------

           MOVE LOW-VALUES                TO WMFSL-KEY.
           MOVE RPOL-POL-ID               TO WMFSL-POL-ID.
           MOVE WS-PROJ-DT                TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE       TO WMFSL-MTHV-FND-IDT-NUM.
           MOVE HIGH-VALUES               TO WMFSL-ENDBR-KEY.
           MOVE WMFSL-POL-ID              TO WMFSL-ENDBR-POL-ID.

           PERFORM  MFSL-1000-BROWSE
               THRU MFSL-1000-BROWSE-X.

           IF  WMFSL-IO-OK
               PERFORM  MFSL-2000-READ-NEXT
                   THRU MFSL-2000-READ-NEXT-X
           ELSE
               GO TO 8800-MOVE-WTHDR-REC-TO-MIR-X
           END-IF.

           IF  NOT WMFSL-IO-OK
               PERFORM  MFSL-3000-END-BROWSE
                   THRU MFSL-3000-END-BROWSE-X
               GO TO 8800-MOVE-WTHDR-REC-TO-MIR-X
           END-IF.

           PERFORM  MFSL-3000-END-BROWSE
               THRU MFSL-3000-END-BROWSE-X.

           MOVE LOW-VALUES             TO WMFSD-KEY.
           MOVE RMFSL-POL-ID           TO WMFSD-POL-ID.
           MOVE RMFSL-MTHV-FND-IDT-NUM TO WMFSD-MTHV-FND-IDT-NUM.
           MOVE 001                    TO WMFSD-MTHV-FND-WTHDR-NUM.
           MOVE HIGH-VALUES            TO WMFSD-ENDBR-KEY.
           MOVE WMFSD-POL-ID           TO WMFSD-ENDBR-POL-ID.
           MOVE WMFSD-MTHV-FND-IDT-NUM TO WMFSD-ENDBR-MTHV-FND-IDT-NUM.
           MOVE 999                   TO WMFSD-ENDBR-MTHV-FND-WTHDR-NUM.

           PERFORM  MFSD-1000-BROWSE
               THRU MFSD-1000-BROWSE-X.

           IF  WMFSD-IO-OK
               PERFORM  MFSD-2000-READ-NEXT
                   THRU MFSD-2000-READ-NEXT-X
           ELSE
               GO TO 8800-MOVE-WTHDR-REC-TO-MIR-X
           END-IF.

           IF  NOT WMFSD-IO-OK
               PERFORM  MFSD-3000-END-BROWSE
                   THRU MFSD-3000-END-BROWSE-X
               GO TO 8800-MOVE-WTHDR-REC-TO-MIR-X
           END-IF.

           MOVE ZERO                      TO WS-REC-SUB.

           PERFORM  8810-MOVE-MFSD-REC
               THRU 8810-MOVE-MFSD-REC-X
               UNTIL WMFSD-IO-EOF
               OR    WS-DATA-OVERFLOW.

           PERFORM  MFSD-3000-END-BROWSE
               THRU MFSD-3000-END-BROWSE-X.

       8800-MOVE-WTHDR-REC-TO-MIR-X.
           EXIT.
      /
      *-------------------
       8810-MOVE-MFSD-REC.
      *-------------------

           IF  WS-REC-SUB = ZERO
               ADD +1                   TO WS-PROJ-SUB
               IF  WS-PROJ-SUB > WS-MAX-PROJ-SUB
                   SET WS-DATA-OVERFLOW     TO TRUE
                   GO TO 8810-MOVE-MFSD-REC-X
               END-IF
021657*        SET MIR-DV-PROJ-ARRAY-WTHDR-T (WS-PROJ-SUB)   TO TRUE
021657         SET MIR-DV-PROJ-INFO-WTHDR-T (WS-PROJ-SUB)   TO TRUE
               MOVE SPACES              TO W2340-WTHDR-ARRAY-REC
           END-IF.

           ADD +1                       TO WS-REC-SUB.

           IF  WS-REC-SUB = 1
               PERFORM  8811-MOVE-TO-MIR-WTHDR-1
                   THRU 8811-MOVE-TO-MIR-WTHDR-1-X
           END-IF.

           IF  WS-REC-SUB = 2
               PERFORM  8812-MOVE-TO-MIR-WTHDR-2
                   THRU 8812-MOVE-TO-MIR-WTHDR-2-X
           END-IF.

           IF  WS-REC-SUB = 3
               PERFORM  8813-MOVE-TO-MIR-WTHDR-3
                   THRU 8813-MOVE-TO-MIR-WTHDR-3-X
           END-IF.

           IF  WS-REC-SUB = 4
               PERFORM  8814-MOVE-TO-MIR-WTHDR-4
                   THRU 8814-MOVE-TO-MIR-WTHDR-4-X
           END-IF.

           IF  WS-REC-SUB = 5
               PERFORM  8815-MOVE-TO-MIR-WTHDR-5
                   THRU 8815-MOVE-TO-MIR-WTHDR-5-X
           END-IF.

           IF  WS-REC-SUB = 6
               PERFORM  8816-MOVE-TO-MIR-WTHDR-6
                   THRU 8816-MOVE-TO-MIR-WTHDR-6-X
               MOVE ZERO                TO WS-REC-SUB
           END-IF.

           PERFORM  MFSD-2000-READ-NEXT
               THRU MFSD-2000-READ-NEXT-X.

       8810-MOVE-MFSD-REC-X.
           EXIT.
      /
      *-------------------------
       8811-MOVE-TO-MIR-WTHDR-1.
      *-------------------------

           MOVE RMFSD-CVG-NUM            TO W2340-WTHDR-CVG-NUM-1.

020874*    MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-NUMBER.
020874     MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-NUM-1
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-NUM-1.

           MOVE RMFSD-MTHV-FND-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-MTHV-FND-EFF-DT-1.

           MOVE RMFSD-MTHV-FND-WTHDR-CD  TO W2340-MTHV-FND-WTHDR-CD-1.

020874*    COMPUTE L0290-INPUT-NUMBER = RMFSD-MTHV-FND-WTHDR-AMT * 100.
020874     MOVE RMFSD-MTHV-FND-WTHDR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-AMT-1
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-AMT-1.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                               RMFSD-MTHV-FND-WTHDR-PCT * 10000.
020874     MOVE RMFSD-MTHV-FND-WTHDR-PCT TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-PCT-1
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-PCT-1.

           MOVE W2340-WTHDR-ARRAY-REC    TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8811-MOVE-TO-MIR-WTHDR-1-X.
           EXIT.
      /
      *-------------------------
       8812-MOVE-TO-MIR-WTHDR-2.
      *-------------------------

           MOVE RMFSD-CVG-NUM            TO W2340-WTHDR-CVG-NUM-2.

020874*    MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-NUMBER.
020874     MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-NUM-2
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-NUM-2.

           MOVE RMFSD-MTHV-FND-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-MTHV-FND-EFF-DT-2.

           MOVE RMFSD-MTHV-FND-WTHDR-CD  TO W2340-MTHV-FND-WTHDR-CD-2.

020874*    COMPUTE L0290-INPUT-NUMBER = RMFSD-MTHV-FND-WTHDR-AMT * 100.
020874     MOVE RMFSD-MTHV-FND-WTHDR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-AMT-2
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-AMT-2.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                               RMFSD-MTHV-FND-WTHDR-PCT * 10000.
020874     MOVE RMFSD-MTHV-FND-WTHDR-PCT TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-PCT-2
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-PCT-2.

           MOVE W2340-WTHDR-ARRAY-REC    TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8812-MOVE-TO-MIR-WTHDR-2-X.
           EXIT.
      /
      *-------------------------
       8813-MOVE-TO-MIR-WTHDR-3.
      *-------------------------

           MOVE RMFSD-CVG-NUM            TO W2340-WTHDR-CVG-NUM-3.

020874*    MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-NUMBER.
020874     MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-NUM-3
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-NUM-3.

           MOVE RMFSD-MTHV-FND-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-MTHV-FND-EFF-DT-3.

           MOVE RMFSD-MTHV-FND-WTHDR-CD  TO W2340-MTHV-FND-WTHDR-CD-3.

020874*    COMPUTE L0290-INPUT-NUMBER = RMFSD-MTHV-FND-WTHDR-AMT * 100.
020874     MOVE RMFSD-MTHV-FND-WTHDR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-AMT-3
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-AMT-3.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                               RMFSD-MTHV-FND-WTHDR-PCT * 10000.
020874     MOVE RMFSD-MTHV-FND-WTHDR-PCT TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-PCT-3
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-PCT-3.

           MOVE W2340-WTHDR-ARRAY-REC    TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8813-MOVE-TO-MIR-WTHDR-3-X.
           EXIT.
      /
      *-------------------------
       8814-MOVE-TO-MIR-WTHDR-4.
      *-------------------------

           MOVE RMFSD-CVG-NUM            TO W2340-WTHDR-CVG-NUM-4.

020874*    MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-NUMBER.
020874     MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-NUM-4
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-NUM-4.

           MOVE RMFSD-MTHV-FND-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-MTHV-FND-EFF-DT-4.

           MOVE RMFSD-MTHV-FND-WTHDR-CD  TO W2340-MTHV-FND-WTHDR-CD-4.

020874*    COMPUTE L0290-INPUT-NUMBER = RMFSD-MTHV-FND-WTHDR-AMT * 100.
020874     MOVE RMFSD-MTHV-FND-WTHDR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-AMT-4
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-AMT-4.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                               RMFSD-MTHV-FND-WTHDR-PCT * 10000.
020874     MOVE RMFSD-MTHV-FND-WTHDR-PCT TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-PCT-4
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-PCT-4.

           MOVE W2340-WTHDR-ARRAY-REC    TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8814-MOVE-TO-MIR-WTHDR-4-X.
           EXIT.
      /
      *-------------------------
       8815-MOVE-TO-MIR-WTHDR-5.
      *-------------------------

           MOVE RMFSD-CVG-NUM            TO W2340-WTHDR-CVG-NUM-5.

020874*    MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-NUMBER.
020874     MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-NUM-5
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-NUM-5.

           MOVE RMFSD-MTHV-FND-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-MTHV-FND-EFF-DT-5.

           MOVE RMFSD-MTHV-FND-WTHDR-CD  TO W2340-MTHV-FND-WTHDR-CD-5.

020874*    COMPUTE L0290-INPUT-NUMBER = RMFSD-MTHV-FND-WTHDR-AMT * 100.
020874     MOVE RMFSD-MTHV-FND-WTHDR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-AMT-5
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-AMT-5.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                               RMFSD-MTHV-FND-WTHDR-PCT * 10000.
020874     MOVE RMFSD-MTHV-FND-WTHDR-PCT TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-PCT-5
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-PCT-5.

           MOVE W2340-WTHDR-ARRAY-REC    TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8815-MOVE-TO-MIR-WTHDR-5-X.
           EXIT.
      /
      *-------------------------
       8816-MOVE-TO-MIR-WTHDR-6.
      *-------------------------

           MOVE RMFSD-CVG-NUM            TO W2340-WTHDR-CVG-NUM-6.

020874*    MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-NUMBER.
020874     MOVE RMFSD-MTHV-FND-WTHDR-NUM TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-NUM-6
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-NUM-6.

           MOVE RMFSD-MTHV-FND-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO W2340-MTHV-FND-EFF-DT-6.

           MOVE RMFSD-MTHV-FND-WTHDR-CD  TO W2340-MTHV-FND-WTHDR-CD-6.

020874*    COMPUTE L0290-INPUT-NUMBER = RMFSD-MTHV-FND-WTHDR-AMT * 100.
020874     MOVE RMFSD-MTHV-FND-WTHDR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-AMT-6
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-AMT-6.

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                               RMFSD-MTHV-FND-WTHDR-PCT * 10000.
020874     MOVE RMFSD-MTHV-FND-WTHDR-PCT TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF W2340-MTHV-FND-WTHDR-PCT-6
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO W2340-MTHV-FND-WTHDR-PCT-6.

           MOVE W2340-WTHDR-ARRAY-REC    TO
021657*                          MIR-DV-PROJ-ARRAY-REC-T (WS-PROJ-SUB).
021657                           MIR-DV-PROJ-INFO-T (WS-PROJ-SUB).

       8816-MOVE-TO-MIR-WTHDR-6-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
      *
      * FOR POLICY RELATED TRANSACTION
      *
           SET  WGLOB-REF-POLICY          TO TRUE.

           MOVE MIR-POL-ID-BASE           TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  6965-0000-INIT-PARM-INFO
025970         THRU 6965-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6980-0000-INIT-PARM-INFO
025970         THRU 6980-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE   FREQUENTLY-USED-INDICES.
025970     INITIALIZE   WS-WORKING-STORAGE.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
025970     SET  WS-MAX-PROJ-SUB-DEFAULT        TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
      /
025970 COPY CCPS6965.
025970 COPY CCPS6980.
       COPY CCPSPGA.
       COPY CCPS2430.
020478 COPY CCPS2440.
       COPY XCPS0290.
      /
021930*COPY CCPERELA.
021930*
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
018764*COPY CCCL2430.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL2430.
020478 COPY CCPL2440.
018764*COPY CCCL6965.
018764 COPY CCPL6965.
018764*COPY CCCL6980.
018764 COPY CCPL6980.
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
021930*COPY XCPL0280.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
021930*COPY CCPBPOLC.
       COPY CCPBCVGC.
       COPY CCPBCDSI.
       COPY CCPBMFSD.
       COPY CCPBMFSL.
       COPY CCPNCVG.
       COPY CCPNEDIT.
020478*COPY CCPNCLIA.
       COPY CCPNPOL.
       COPY CCPNPOLP.
       COPY NCPNTTAB.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2340                     **
      *****************************************************************
