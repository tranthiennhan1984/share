      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM0450.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0450                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RETRIEVE FUNCTION       **
      **            FOR THE INFORCE POLICY MODIFICATION.             **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025390**  7.0       PHST FOR UPDATE POLICY DISCOUNT PERCENT          **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0450'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-RETRIEVE           VALUE '0450'.
           05  WS-EFF-DT                         PIC X(10).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWCVGS.
       COPY CCWWLOCK.
       COPY CCWWINDX.
       COPY CCWWIHSD.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0620.
       COPY CCWL2430.
       COPY CCWL2626.
       COPY CCWL2735.
       COPY CCWL5400.
       COPY CCWL7306.
025390 COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1670.
       COPY XCWL1680.
       COPY XCWL8090.
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0450.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  FPCK-1000-CHECK-POLICY
               THRU FPCK-1000-CHECK-POLICY-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0450'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                         TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------
       2000-RETRIEVE.
      *--------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  2110-EDIT-POLICY
               THRU 2110-EDIT-POLICY-X.

           PERFORM  2120-EDIT-EFF-DT
               THRU 2120-EDIT-EFF-DT-X.

           PERFORM  2130-CHECK-IHSD-DATE
               THRU 2130-CHECK-IHSD-DATE-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       2110-EDIT-POLICY.
      *-----------------

           MOVE MIR-POL-ID-BASE          TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX           TO WPOL-POL-ID-SFX.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X

           IF  NOT WPOL-IO-OK
               SET WGLOB-RETURN-ERROR    TO TRUE
               MOVE 'CS00000019'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-POLICY-X
           END-IF.

           PERFORM  7306-1000-BUILD-PARM-INFO
               THRU 7306-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID              TO L7306-POL-ID.
           PERFORM  7306-1000-GET-DBG-INFO
               THRU 7306-1000-GET-DBG-INFO-X.

           IF  RPOL-POL-SUSPENDED
      *MSGS: POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2110-EDIT-POLICY-X
               END-IF
           END-IF.

           IF  RPOL-POL-STAT-BEFORE-SETL
      *MSGS: PENDING POLICY - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000238'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR
                                         TO TRUE
                   GO TO 2110-EDIT-POLICY-X
               END-IF
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET L5400-CRCY-MSG-REQD       TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       2110-EDIT-POLICY-X.
           EXIT.
      /
      *-----------------
       2120-EDIT-EFF-DT.
      *-----------------

           MOVE MIR-PCHST-EFF-IDT-NUM    TO L1640-EXTERNAL-DATE
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-INTERNAL-DATE = WWKDT-ZERO-DT
               MOVE 'CS00000054'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
           END-IF.

       2120-EDIT-EFF-DT-X.
           EXIT.

      *--------------------
       2130-CHECK-IHSD-DATE.
      *--------------------

      * EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE

           IF  WGLOB-RETURN-ERROR
               GO TO 2130-CHECK-IHSD-DATE-X
           END-IF.

           MOVE WS-EFF-DT            TO WIHSD-EFF-DT.
           PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
               THRU IHSD-1000-CHK-IHSD-INQUIRY-X.

           IF WIHSD-CHK-EFF-DT-NOT-OK
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

       2130-CHECK-IHSD-DATE-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                    TO MIR-DV-OWN-CLI-NM.
           MOVE SPACE                    TO MIR-SBSDRY-CO-ID.
           MOVE SPACE                    TO MIR-POL-DB-OPT-CD.
           MOVE SPACE                    TO MIR-POL-ISS-EFF-DT.
           MOVE SPACE                    TO MIR-PRFL-ID.
           MOVE SPACE                    TO MIR-DV-PRCES-STATE-CD.
           MOVE SPACE                    TO MIR-DV-ANNV-VALU-IND.
           MOVE SPACE                    TO MIR-DV-POL-DBG-MAV-IND.
           MOVE SPACE                    TO MIR-DV-POL-DBG-ROLU-IND.
           MOVE SPACE                    TO MIR-POL-ENHC-NELCT-QTY.
025390     MOVE SPACE                    TO MIR-PREM-DSCNT-TYP-CD.
025390     MOVE SPACE                    TO MIR-POL-PREM-DSCNT-PCT.
029060     MOVE SPACE                    TO MIR-POL-ANPAYO-1-AMT.
029060     MOVE SPACE                    TO MIR-POL-ANPAYO-2-AMT.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------


           MOVE RPOL-POL-DB-OPT-CD       TO MIR-POL-DB-OPT-CD.

           MOVE L7306-POL-DBG-ANNV-VALU-IND
                                         TO MIR-DV-ANNV-VALU-IND.
           MOVE L7306-POL-DBG-MAV-IND    TO MIR-DV-POL-DBG-MAV-IND.
           MOVE L7306-POL-DBG-ROLU-IND   TO MIR-DV-POL-DBG-ROLU-IND.

           MOVE RPOL-POL-ISS-EFF-DT      TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-POL-ISS-EFF-DT.


           MOVE RPOL-SBSDRY-CO-ID        TO MIR-SBSDRY-CO-ID.


           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID              TO L2430-POL-ID.
           MOVE ZERO                     TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE                L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM
                                         TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                         TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                         TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                         TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD     TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME    TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES               TO MIR-DV-OWN-CLI-NM
           END-IF.

           PERFORM  2735-1000-BUILD-PARM-INFO
               THRU 2735-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID              TO L2735-POL-ID.
           PERFORM  2735-1000-GET-PRFL
               THRU 2735-1000-GET-PRFL-X.

           IF  L2735-RETRN-PRFL-FND
               MOVE L2735-PRFL-ID        TO MIR-PRFL-ID
           ELSE
               MOVE SPACES               TO MIR-PRFL-ID
           END-IF.

           MOVE RPOL-POL-ENHC-NELCT-QTY-N  TO MIR-POL-ENHC-NELCT-QTY.

025390     MOVE RPOL-PREM-DSCNT-TYP-CD   TO MIR-PREM-DSCNT-TYP-CD
025390     MOVE RPOL-POL-PREM-DSCNT-PCT  TO L0290-INPUT-V03.
025390     MOVE 3                        TO L0290-PRECISION.
025390     MOVE LENGTH OF MIR-POL-PREM-DSCNT-PCT
025390                                   TO L0290-MAX-OUT-LEN.
025390     PERFORM 0290-2000-FORMAT-FOR-MIR
025390        THRU 0290-2000-FORMAT-FOR-MIR-X.
025390     MOVE L0290-OUTPUT-DATA        TO MIR-POL-PREM-DSCNT-PCT.
025390
029060     MOVE RPOL-POL-ANPAYO-1-AMT    TO L0290-INPUT-V02.
029060     MOVE 2                        TO L0290-PRECISION.
029060     MOVE LENGTH OF MIR-POL-ANPAYO-1-AMT
029060                                   TO L0290-MAX-OUT-LEN.
029060
029060     PERFORM  0290-2000-FORMAT-FOR-MIR
029060         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060
029060     MOVE L0290-OUTPUT-DATA        TO MIR-POL-ANPAYO-1-AMT.
029060
029060     MOVE RPOL-POL-ANPAYO-2-AMT    TO L0290-INPUT-V02.
029060     MOVE 2                        TO L0290-PRECISION.
029060     MOVE LENGTH OF MIR-POL-ANPAYO-2-AMT
029060                                   TO L0290-MAX-OUT-LEN.
029060
029060     PERFORM  0290-2000-FORMAT-FOR-MIR
029060         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060
029060     MOVE L0290-OUTPUT-DATA        TO MIR-POL-ANPAYO-2-AMT.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

025390     PERFORM  0290-0000-INIT-PARM-INFO
025390         THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  1670-0000-INIT-PARM-INFO
               THRU 1670-0000-INIT-PARM-INFO-X.

           PERFORM  1680-0000-INIT-PARM-INFO
               THRU 1680-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  2626-0000-INIT-PARM-INFO
               THRU 2626-0000-INIT-PARM-INFO-X.

           PERFORM  2735-0000-INIT-PARM-INFO
               THRU 2735-0000-INIT-PARM-INFO-X.

           PERFORM  5400-0000-INIT-PARM-INFO
               THRU 5400-0000-INIT-PARM-INFO-X.

           PERFORM  7306-0000-INIT-PARM-INFO
               THRU 7306-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-AREA.
           INITIALIZE FREQUENTLY-USED-INDICES.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           INITIALIZE WIHSD-INFO.
           MOVE SPACES                 TO WWKDT-WORK-FIELDS.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY CCPPFPCK.
       COPY NCPPCVGS.
       COPY CCPPIHSD.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY CCPS0620.
       COPY CCPL0620.
      /
       COPY CCPS2430.
       COPY CCPL2430.
      /
       COPY CCPS2626.
       COPY CCPL2626.
      /
       COPY CCPS2735.
       COPY CCPL2735.
      /
       COPY CCPS7306.
       COPY CCPL7306.
      /
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY XCPL0260.
      /
025390 COPY XCPS0290.
025390 COPY XCPL0290.
      /
       COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPS1670.
       COPY XCPS1680.
       COPY XCPL1680.
      /
       COPY XCPL8090.
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **              END OF PROGRAM CSOM0450                        **
      *****************************************************************
