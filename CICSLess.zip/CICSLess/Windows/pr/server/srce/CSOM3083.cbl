      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3083.

       COPY XCWWCRHT.


      *****************************************************************
      **  MEMBER :  CSOM3083                                         **
      **  REMARKS:  PLAR - PLAN ALLOCATION RULE TABLE DELETE         **
      **            THIS MODULE DELETES AN ENTRY IN THE PLAR TABLE   **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3083'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '3080'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '3080'.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-DELETE        VALUE '3083'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '3080'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
      /
       COPY CCWWLOCK.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPLAR.
       COPY CCFRPLAR.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
021930*COPY XCWLDTLK.
021930*COPY XCWL0290.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3083.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

021930*    PERFORM  0290-1000-BUILD-PARM-INFO
021930*        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3083'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           PERFORM  6110-BUILD-KEY
               THRU 6110-BUILD-KEY-X.

           PERFORM  PH-2000-UPDATE-TWRK-TS
               THRU PH-2000-UPDATE-TWRK-TS-X.

           IF  WPH-IO-NOT-FOUND
      *MSG:  PLAN @1 IS NOT A VALID PLAN
               MOVE 'CS30830001'      TO WGLOB-MSG-REF-INFO
               MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
      *     PROCESS NOT COMPLETE
               MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
               MOVE 'PH'               TO WGLOB-MSG-PARM (01)
               MOVE WPH-KEY            TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

           PERFORM  PLAR-1000-READ-FOR-UPDATE
               THRU PLAR-1000-READ-FOR-UPDATE-X.

           IF  WPLAR-IO-OK
               PERFORM  6200-DELETE-PLAR-REC
                   THRU 6200-DELETE-PLAR-REC-X
           ELSE
      *MSG:  PLAN ALLOCATION RECORD - PLAN @1 ALLOCATION @2 NOT FOUND
               MOVE 'CS30830002'            TO WGLOB-MSG-REF-INFO
               MOVE WPLAR-PLAN-ID           TO WGLOB-MSG-PARM (01)
               MOVE WPLAR-PLAR-ALLOC-TYP-CD TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PH-3000-UNLOCK
                   THRU PH-3000-UNLOCK-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.

      *---------------
       6110-BUILD-KEY.
      *---------------

           MOVE MIR-PLAN-ID            TO WPH-PLAN-ID.

           MOVE MIR-PLAN-ID            TO WPLAR-PLAN-ID.
           MOVE MIR-PLAR-ALLOC-TYP-CD
                                       TO WPLAR-PLAR-ALLOC-TYP-CD.

       6110-BUILD-KEY-X.
           EXIT.
      /
      *--------------------
       6200-DELETE-PLAR-REC.
      *--------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  PLAR-1000-CALL-AUDIT
                   THRU PLAR-1000-CALL-AUDIT-X
           END-IF.

           PERFORM  PLAR-1000-DELETE
               THRU PLAR-1000-DELETE-X.

           IF  WPLAR-IO-OK
      *MSG:    DELETE COMPLETED MESSAGE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM  PLAR-1000-CALL-AUDIT
                       THRU PLAR-1000-CALL-AUDIT-X
               END-IF
               PERFORM  PH-2000-REWRITE
                   THRU PH-2000-REWRITE-X
               PERFORM  PH-1000-READ-TWRK-TS
                   THRU PH-1000-READ-TWRK-TS-X
           ELSE
               PERFORM  PH-3000-UNLOCK
                   THRU PH-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WPLAR-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

       6200-DELETE-PLAR-REC-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET  MIR-RETRN-OK          TO  TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT   TO  TRUE.
025970     MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
                               '$VAR2' BY 'PH'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPLPLAR.
025970 COPY XCPS8090.
      /
       COPY XCPL0260.
      /
021930*COPY XCPS0290.
021930*COPY XCPL0290.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
021930*COPY CCPNPLAR.
       COPY CCPUPLAR.
       COPY CCPXPLAR.
      /
       COPY CCPNPH.
       COPY CCPUPH.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3083                     *
      ****************************************************************
