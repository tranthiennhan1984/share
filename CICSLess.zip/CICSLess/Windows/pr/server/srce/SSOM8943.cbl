      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM8943.

       COPY XCWWCRHT.


      *****************************************************************
      **  MEMBER :  SSOM8943                                         **
      **  REMARKS:  FBND - FUND BONUS DECLARATION DELETE             **
      **            THIS MODULE DELETES AN ENTRY IN THE FBND TABLE   **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
016016**  6.3       FUND BONUS (6.1.1E)                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019056**  6.3       REMOVE FND-BON-TYP-CD                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM8943'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-DELETE        VALUE '8943'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '8940'.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '8940'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
018764*COPY XCWLPTR.
      /
018763 COPY CCWWLOCK.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
018763*COPY SCFWFHBN.
018763*COPY SCFRFHBN.
      /
018763 COPY SCFWFBND.
018763 COPY SCFRFBND.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY XCWLDTLK.
021930*COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
021930*COPY XCWL1670.
018763 COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM8943.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

021930*    PERFORM  0290-1000-BUILD-PARM-INFO
021930*        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM8943'     TO WGLOB-MSG-PARM (2)
018763*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
018763              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------------
       3540-EXTERNAL-TO-INVERTED.
      *--------------------------

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
           ELSE
      *MSG: ERROR CONVERTING INTERNAL DATE
               MOVE 'SS89430001'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       3540-EXTERNAL-TO-INVERTED-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           PERFORM 6110-BUILD-KEY
              THRU 6110-BUILD-KEY-X.

           IF WGLOB-GOOD-RETURN
018763*        PERFORM FHBN-1000-READ-FOR-UPDATE
018763*           THRU FHBN-1000-READ-FOR-UPDATE-X
018763         PERFORM  FBND-2000-UPDATE-TWRK-TS
018763             THRU FBND-2000-UPDATE-TWRK-TS-X
           ELSE
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

018763*    IF  WFHBN-IO-NOT-FOUND
018763     IF  WFBND-IO-NOT-FOUND
      *MSG: RECORD LOST IN DELETE
               MOVE 'SS89430002'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

018763     IF  MIR-RETRN-TS-MISMATCH
018763*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
018763*     PROCESS NOT COMPLETE
018763         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
018763         MOVE 'FBND'             TO WGLOB-MSG-PARM (01)
018763         MOVE WFBND-KEY          TO WGLOB-MSG-PARM (02)
018763         PERFORM  0260-1000-GENERATE-MESSAGE
018763             THRU 0260-1000-GENERATE-MESSAGE-X
018763         SET WGLOB-RETURN-ERROR TO TRUE
018763         GO TO 6000-PROCESS-DELETE-X
018763     END-IF.

      * CANNOT DELETE BONUS IF THE STATUS IS HISTORY
019056*    IF  RFHBN-FND-BON-TYP-FUND
018763*    AND RFHBN-FND-BON-STAT-HISTORY
018763     IF  RFBND-FND-BON-STAT-HIST
      *MSG: BONUS STATUS IS HISTORY - CANNOT DELETE
               MOVE 'SS89430004'       TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
018763*        MOVE  RFHBN-FND-BON-STAT-CD TO
018763         MOVE  RFBND-FND-BON-STAT-CD TO
                     MIR-FND-BON-STAT-CD
018763*        MOVE  RFHBN-FND-BON-EFF-DT  TO
018763         MOVE  RFBND-FND-BON-EFF-DT  TO
                     MIR-FND-BON-EFF-DT
018763*        MOVE RFHBN-FND-BON-EFF-DT   TO L1640-INTERNAL-DATE
018763         MOVE RFBND-FND-BON-EFF-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE    TO MIR-FND-BON-EFF-DT
018763         PERFORM  FBND-3000-UNLOCK
018763             THRU FBND-3000-UNLOCK-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

018763*    PERFORM FHBN-1000-DELETE
018763*       THRU FHBN-1000-DELETE-X.
018763     PERFORM FBND-1000-DELETE
018763        THRU FBND-1000-DELETE-X.

      *MSG: RECORD DELETED
           MOVE 'SS89430003'  TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.

      *---------------
       6110-BUILD-KEY.
      *---------------

018763*    MOVE MIR-FND-ID              TO WFHBN-FND-ID.
018763*    MOVE MIR-SBSDRY-CO-ID        TO WFHBN-SBSDRY-CO-ID.
018763     MOVE MIR-FND-ID              TO WFBND-FND-ID.
018763     MOVE MIR-SBSDRY-CO-ID        TO WFBND-SBSDRY-CO-ID.

           IF  MIR-FND-BON-IDT-NUM = SPACE
018763*        MOVE ZERO                TO WFHBN-FND-BON-IDT-NUM
018763         MOVE ZERO                TO WFBND-FND-BON-IDT-NUM
           ELSE
               MOVE MIR-FND-BON-IDT-NUM TO L1640-EXTERNAL-DATE
               PERFORM 3540-EXTERNAL-TO-INVERTED
                  THRU 3540-EXTERNAL-TO-INVERTED-X
               IF  NOT WGLOB-RETURN-ERROR
                   MOVE L1660-INVERTED-DATE
018763*                                 TO WFHBN-FND-BON-IDT-NUM
018763                                  TO WFBND-FND-BON-IDT-NUM
               END-IF
           END-IF.

       6110-BUILD-KEY-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
           MOVE SPACE                   TO MIR-FND-BON-STAT-CD.
           MOVE SPACE                   TO MIR-FND-BON-EFF-DT.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
018763 COPY CCPPTWTS REPLACING ==:VAR1:== BY FBND
018763                         '$VAR2' BY 'FBND'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
021930*COPY XCPS0290.
021930*COPY XCPL0290.
021930*
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
018763*COPY SCPUFHBN.
018763*COPY SCPXFHBN.
018763 COPY SCPNFBND.
018763 COPY SCPUFBND.
018763 COPY SCPXFBND.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM SSOM8943                     *
      ****************************************************************
