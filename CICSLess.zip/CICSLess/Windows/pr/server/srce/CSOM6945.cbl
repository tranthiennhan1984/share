      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM6945.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6945                                         **
      **  REMARKS:  POLI - POLICY INQUIRY SCREENS                    **
      **            THIS MODULE PERFORMS THE POLICY INQUIRY FUNCTION **
      **            BENFICIARY RELATIONSHIPS                         **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       NEW                                              **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018633**  6.4       TWRK CLEANUP                                     **
015705**  6.4       NAME FORMATTING                                  **
020477**  6.4       MINIMUM DISTRIBUTION RULES                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
027105**  6.6       99 COVERAGES HANDLING                            **
026766**  6.6       PERFORMANCE MONITORING                           **
023737**  6.7       CHANGES FOR BENEFICIARY LIST SCREEN              **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
032439**  7.1       REMOVE CODE FOR COMM AREA PROCESSING             **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6945'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
       COPY XCWWCVGM.

025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                      PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT          VALUE 'POLI'.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)
025970*                                     VALUE 'POLI'.
           05  WS-SUBD                      PIC 9(03).
016548*    05  WS-START-CVGNO               PIC S9(4)  COMP.
016548     05  WS-START-CVGNO               PIC S9(4)  BINARY.
016548*    05  WS-END-CVGNO                 PIC S9(4)  COMP.
016548     05  WS-END-CVGNO                 PIC S9(4)  BINARY.
           05  WS-FOUND-PRIMARY-SW          PIC X(01).
               88  WS-FOUND-PRIMARY         VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS     VALUE 'N'.

016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
016548*    05  WS-ENTRY-MAX                 PIC S9(4)  COMP
025970*    05  WS-ENTRY-MAX              PIC S9(4)  BINARY VALUE 20.
025970*    05  WS-ENTRY-MAX              PIC S9(4)  BINARY VALUE 20.
027105     05  WS-ENTRY-MAX                 PIC S9(4)  BINARY.

018633*01  WS-TWRK-KEY                      PIC X(04) VALUE '6945'.
018633*01  WS-WORK-AREA.
018633*    05  WS-WORK-PROGRAM-NUMBER       PIC X(04).
018633*    05  WS-WORK-CLIENT-NUMBER        PIC X(10).
018633*    05  WS-WORK-POL-ID.
018633*        10  WS-WORK-POL-ID-BASE      PIC X(09).
018633*        10  WS-WORK-POL-ID-SFX       PIC X(01).
018633*    05  WS-WORK-SPECIFIC-AREA.
018633*        10  WS-WORK-CVG-NUM          PIC X(02).
018633*        10  WS-WORK-BUS-FCN-ID       PIC X(04).
018633*        10  WS-WORK-DATE             PIC X(10).
018633*        10  WS-WORK-BENE-CVG-NUM     PIC X(02).
018633*        10  WS-WORK-BENE-SEQ-NUM     PIC S9(03).
018633*        10  WS-WORK-BENE-POL-NO      PIC X(09).
018633*        10  WS-WORK-BENE-POL-SF      PIC X(01).
032439*COPY XCWLCOMM REPLACING '$VAR1' BY '6945'.
032439*    15  LCOMM-POL-ID.
032439*        20  LCOMM-POL-ID-BASE        PIC X(09).
032439*        20  LCOMM-POL-ID-SFX         PIC X(01).
032439*    15  LCOMM-SPECIFIC-AREA.
032439*        20  LCOMM-CVG-NUM            PIC X(02).
032439*        20  LCOMM-BUS-FCN-ID         PIC X(04).
032439*        20  LCOMM-DATE               PIC X(10).
032439*        20  LCOMM-BENE-CVG-NUM       PIC X(02).
032439*        20  LCOMM-BENE-SEQ-NUM       PIC S9(03).
032439*        20  LCOMM-BENE-POL-NO        PIC X(09).
032439*        20  LCOMM-BENE-POL-SF        PIC X(01).

       01  WS-EDIT-PROCESS-CHECKS.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-BLANK         VALUE SPACES.
               88  WS-BUS-FCN-VALID         VALUE '6945'.
               88  WS-BUS-FCN-BENE-RELATIONS VALUE '6945'.

           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.

           05  WS-CLIENT-FOUND-SW           PIC X(01).
               88  WS-CLIENT-FOUND          VALUE 'Y'.
               88  WS-NO-CLIENT-FOUND       VALUE 'N'.

           05  WS-POLICY.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-CVG-NUM                   PIC X(02).
               88  WS-CVG-NUM-BLANK         VALUE SPACES ZEROS.
           05  WS-CVG-NUM-R                 REDEFINES
               WS-CVG-NUM                   PIC 9(02).
           05  WS-CURR-DATE.
               10  WS-CURR-YEAR             PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-CURR-MONTH            PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-CURR-DAY              PIC 9(02).
           05  WS-CV-DATE.
               10  WS-CV-DATE-YR            PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-CV-DATE-MO            PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-CV-DATE-DY            PIC 9(02).

           05  WS-POL-STATUS                PIC X(04).

       01  WS-NUMERIC-CONVERSIONS.
           05  WS-PIC-0-5                   PIC -.9(5).
           05  WS-PIC-1-2                   PIC -9.99.
           05  WS-PIC-1-4                   PIC -9.9(4).
           05  WS-PIC-1-5                   PIC -9.9(5).
           05  WS-PIC-2                     PIC -(2)9.
           05  WS-PIC-2-3                   PIC -(2)9.9(3).
           05  WS-PIC-2-7                   PIC --9.9(7).
           05  WS-PIC-P3-1                  PIC 999.9.
           05  WS-PIC-3-2                   PIC -(3)9.99.
           05  WS-PIC-3-3                   PIC -(3)9.999.
           05  WS-PIC-3-4                   PIC -(3)9.9(4).
           05  WS-PIC-2-4                   PIC -(2)9.9(4).
           05  WS-PIC-2-5                   PIC Z9.9(5).
           05  WS-PIC-3-6                   PIC -(3)9.9(6).
           05  WS-PIC-4-5                   PIC -(4)9.9(5).
           05  WS-PIC-5-4                   PIC -(5)9.9(4).
           05  WS-PIC-P6-5                  PIC Z(5)9.9(5).
           05  WS-PIC-8-5                   PIC -(8)9.9(5).

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
      *
       COPY CCWWINDX.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
       COPY CCFWPOLC.
       COPY CCFRPOLC.
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************
028298 COPY CCWL2626.
       COPY XCWL0290.
      *
       COPY CCWL0620.
       COPY CCWL2430.
      *
016537 COPY CCWL5400.
      *
       COPY CCWL6945.
      *
021930*COPY XCWLDTLK.
       COPY XCWL0280.
016537*COPY XCWL1640.
      *
      * TWRK SUPPORT
      *
032439*COPY XCWL8090.
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM6945.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

032439*    PERFORM  COMM-1000-INITIALIZE
032439*        THRU COMM-1000-INITIALIZE-X.
032439*
           INITIALIZE L2430-OUTPUT-PARM-INFO.
           INITIALIZE RPOL-REC-INFO.

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  0100-SET-MIR-VALUES
               THRU 0100-SET-MIR-VALUES-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------
       0100-SET-MIR-VALUES.
      *--------------------

           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX.
           MOVE WS-BUS-FCN-ID         TO MIR-BUS-FCN-ID.

       0100-SET-MIR-VALUES-X.
           EXIT.

      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

           SET  MIR-RETRN-OK    TO TRUE.
           MOVE MIR-BUS-FCN-ID  TO WS-BUS-FCN-ID.
018633*    MOVE SPACES          TO WS-WORK-AREA.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
032439*    PERFORM  COMM-3000-DELETE-TWRK
032439*        THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           MOVE WGLOB-PROCESS-DATE    TO WS-CURR-DATE.

           PERFORM  2050-SET-WS-FROM-MIR
               THRU 2050-SET-WS-FROM-MIR-X.

018633*    IF  MIR-BUS-FCN-ID   NOT = WS-WORK-BUS-FCN-ID
018633*    OR  MIR-POL-ID-BASE  NOT = WS-WORK-POL-ID-BASE
018633*    OR  MIR-POL-ID-SFX   NOT = WS-WORK-POL-ID-SFX
018633*    OR  MIR-CVG-NUM      NOT = WS-WORK-CVG-NUM
018633*        INITIALIZE              WS-WORK-SPECIFIC-AREA
018633*        MOVE MIR-BUS-FCN-ID  TO WS-WORK-BUS-FCN-ID
018633*        MOVE MIR-CVG-NUM     TO WS-WORK-CVG-NUM
032439*    IF  MIR-BUS-FCN-ID   NOT = LCOMM-BUS-FCN-ID
032439*    OR  MIR-POL-ID-BASE  NOT = LCOMM-POL-ID-BASE
032439*    OR  MIR-POL-ID-SFX   NOT = LCOMM-POL-ID-SFX
032439*    OR  MIR-CVG-NUM      NOT = LCOMM-CVG-NUM
032439*        INITIALIZE              LCOMM-SPECIFIC-AREA
032439*        MOVE MIR-BUS-FCN-ID  TO LCOMM-BUS-FCN-ID
032439*        MOVE MIR-CVG-NUM     TO LCOMM-CVG-NUM
032439*    END-IF.

           SET WS-NO-ERRORS-FOUND      TO TRUE.

           PERFORM  2200-MORE-INITIAL-EDITS
               THRU 2200-MORE-INITIAL-EDITS-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.

           PERFORM  3000-DISPLAY-SCREEN
               THRU 3000-DISPLAY-SCREEN-X.

018633*    MOVE WS-POL-ID-BASE        TO WS-WORK-POL-ID-BASE.
018633*    MOVE WS-POL-ID-SFX         TO WS-WORK-POL-ID-SFX.
032439*    MOVE WS-POL-ID-BASE        TO LCOMM-POL-ID-BASE.
032439*    MOVE WS-POL-ID-SFX         TO LCOMM-POL-ID-SFX.

018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
032439*    PERFORM  COMM-2000-WRITE-TWRK
032439*        THRU COMM-2000-WRITE-TWRK-X.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *---------------------
       2050-SET-WS-FROM-MIR.
      *---------------------

032439*    IF  MIR-POL-ID-BASE = SPACES
018633*        MOVE WS-WORK-POL-ID-BASE TO MIR-POL-ID-BASE
018633*        MOVE WS-WORK-POL-ID-SFX  TO MIR-POL-ID-SFX
032439*        MOVE LCOMM-POL-ID-BASE   TO MIR-POL-ID-BASE
032439*        MOVE LCOMM-POL-ID-SFX    TO MIR-POL-ID-SFX
032439*    END-IF.

           MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SFX.
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF  MIR-CVG-NUM = SPACES
           OR ZEROES
023737*        MOVE '01'              TO WS-CVG-NUM
023737         MOVE '00'              TO WS-CVG-NUM               
           ELSE
               MOVE MIR-CVG-NUM       TO WS-CVG-NUM
           END-IF.

       2050-SET-WS-FROM-MIR-X.
           EXIT.
      *
      *------------------------
       2200-MORE-INITIAL-EDITS.
      *------------------------

           MOVE WS-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    POLICY RECORD NOT FOUND (@1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE WS-CVG-NUM            TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WS-CVG-NUM-R
               IF  WS-CVG-NUM > WCVGM-MAX-WCVGS-NUM
                   SET WS-ERROR-FOUND      TO TRUE
      *MSG:        COVERAGE MUST BE NUMERIC
                   MOVE 'XS00000079'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-CVG-NUM    TO WGLOB-MSG-PARM (1)
                   MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    COVERAGE MUST BE NUMERIC
               MOVE 'XS00000079'      TO WGLOB-MSG-REF-INFO
               MOVE WS-CVG-NUM        TO WGLOB-MSG-PARM (1)
               MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

016440*
016440* PERFORM CONFIDENTIAL POLICY AND BRANCH LEVEL SECURITY CHECKS
016440*
016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.

016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.

016440     IF L5400-CNFD-ACCS-RESTRICTED
016440     OR L5400-BRCH-ACCS-RESTRICTED
016440         SET WS-ERROR-FOUND      TO TRUE
016440         GO TO 2200-MORE-INITIAL-EDITS-X
016440     END-IF.


           IF  RPOL-POL-CVG-REC-CTR-N = ZEROS
      *MSG:    NO COVERAGES TO DISPLAY
               MOVE 'XS00000095'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  WS-CVG-NUM-R > RPOL-POL-CVG-REC-CTR-N
      *MSG:        'COVERAGE (@1) DOES NOT EXIST'
                   MOVE 'XS00000080'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-CVG-NUM    TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  2210-READ-ALL-CVG
               THRU 2210-READ-ALL-CVG-X
               VARYING WS-SUBD FROM 1 BY 1
               UNTIL   WS-SUBD > RPOL-POL-CVG-REC-CTR-N
               OR      WS-ERROR-FOUND.

           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

       2200-MORE-INITIAL-EDITS-X.
           EXIT.
      *
      *------------------
       2210-READ-ALL-CVG.
      *------------------

           MOVE WS-POL-ID-BASE        TO WCVG-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WCVG-POL-ID-SFX.
           MOVE WS-SUBD               TO WCVG-CVG-NUM-N.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  WCVG-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND     TO TRUE
      *MSG:    'POLICY & COVERAGE (@1) OUT OF SYNC ...'
               MOVE 'XS00000084'      TO WGLOB-MSG-REF-INFO
               MOVE WS-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2210-READ-ALL-CVG-X
           END-IF.

           MOVE RCVG-CVG-INFO         TO WCVGS-CVG-INFO (WS-SUBD).
           MOVE WS-SUBD               TO WCVGS-CVG-SEQ-NUM-N (WS-SUBD).

       2210-READ-ALL-CVG-X.
           EXIT.
      *
      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------

           SET  WS-NO-CLIENT-FOUND TO TRUE.

           IF  WS-CVG-NUM-BLANK
               MOVE +1                TO WS-START-CVGNO
           ELSE
               MOVE WS-CVG-NUM-R      TO WS-START-CVGNO
           END-IF.

           COMPUTE WS-END-CVGNO = WS-START-CVGNO + 10.

           IF  WS-END-CVGNO > RPOL-POL-CVG-REC-CTR-N
               MOVE RPOL-POL-CVG-REC-CTR-N
                                      TO WS-END-CVGNO
           END-IF.

      *
      * READ AND FORMAT OWNERS NAME
      *
           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
015705         MOVE L2430-CLI-MID-INIT-NM
015705                                TO L0620-CLI-MID-INIT-NM
015705         MOVE L2430-CLI-SFX-NM  TO L0620-CLI-SFX-NM

           END-IF.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
           MOVE RPOL-POL-CVG-REC-CTR  TO MIR-POL-CVG-REC-CTR.
           MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
           MOVE RPOL-POL-CSTAT-CD     TO WS-POL-STATUS.

       2300-COMMON-LINE-SET-X.
           EXIT.
      *
      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

018633*    IF  WS-WORK-POL-ID-BASE = SPACES
032439*    IF  LCOMM-POL-ID-BASE = SPACES
032439*    AND WS-POLICY           = SPACES
032439     IF  WS-POLICY           = SPACES
               GO TO 2320-GET-OWNER-X
           END-IF.

           IF  L2430-CLI-ID = SPACES
               PERFORM  2400-CHECK-FOR-OWNER-CLI
                   THRU 2400-CHECK-FOR-OWNER-CLI-X
           ELSE
               IF  L2430-CLI-NM-COMPRESSED = SPACES
      *MSG:        OWNER CLIENT NAME = SPACES
                   MOVE 'CS69450006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2320-GET-OWNER-X.
           EXIT.
      *
      *-------------------------
       2400-CHECK-FOR-OWNER-CLI.
      *-------------------------

      *
      * BUILD START/END BROWSE KEY
      *
           MOVE LOW-VALUES            TO  WPOLC-KEY.
           MOVE RPOL-POL-ID           TO  WPOLC-POL-ID.
           MOVE 'O'                   TO  WPOLC-POL-CLI-REL-TYP-CD.

           MOVE WPOLC-KEY             TO  WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO  WPOLC-ENDBR-CLI-ID.

      *
      *  POSITION AT THE FIRST RECORD FOR THE GIVEN RELATIONSHIP
      *
           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

           IF  WPOLC-IO-OK
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

           IF  WPOLC-IO-EOF
               MOVE 'CS69450007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           SET  WS-NO-PRIMARY-EXISTS TO TRUE.
           PERFORM  2500-DETERMINE-IF-PRIMARY
               THRU 2500-DETERMINE-IF-PRIMARY-X
               UNTIL WPOLC-IO-EOF
               OR    WS-FOUND-PRIMARY.

           IF  WS-NO-PRIMARY-EXISTS
               MOVE 'CS69450007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           PERFORM  2600-FIND-OWNERS-LOOP
               THRU 2600-FIND-OWNERS-LOOP-X
               UNTIL WPOLC-IO-EOF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.


       2400-CHECK-FOR-OWNER-CLI-X.
           EXIT.

      *--------------------------
       2500-DETERMINE-IF-PRIMARY.
      *--------------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD = 'P'
               SET WS-FOUND-PRIMARY TO TRUE
               GO TO 2500-DETERMINE-IF-PRIMARY-X
           END-IF.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2500-DETERMINE-IF-PRIMARY-X.
           EXIT.

      *----------------------
       2600-FIND-OWNERS-LOOP.
      *----------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD NOT = 'P'
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
               GO TO 2600-FIND-OWNERS-LOOP-X
           END-IF.

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

      *
      * WE HAVE FOUND THE REQUIRED RECORD, READ THE CLIENT FILE
      *
           MOVE  RPOLC-CLI-ID         TO  L2430-CLI-ID.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

       2600-FIND-OWNERS-LOOP-X.
           EXIT.
      *
      *--------------------
       3000-DISPLAY-SCREEN.
      *--------------------

      *
      * BUILD INPUT PARMS
      *
           PERFORM  6945-1000-BUILD-PARM-INFO
               THRU 6945-1000-BUILD-PARM-INFO-X.

           MOVE WS-CVG-NUM             TO L6945-CVG-NUM.
           MOVE WS-POLICY              TO L6945-POLICY.
018633*    MOVE WS-WORK-BENE-CVG-NUM   TO L6945-BENE-CVG-NUM.
018633*    MOVE WS-WORK-BENE-SEQ-NUM   TO L6945-BENE-SEQ-NUM.
018633*    MOVE WS-WORK-BENE-POL-NO    TO L6945-BENE-POL-NO.
018633*    MOVE WS-WORK-BENE-POL-SF    TO L6945-BENE-POL-SF.
032439*    MOVE LCOMM-BENE-CVG-NUM     TO L6945-BENE-CVG-NUM.
032439*    MOVE LCOMM-BENE-SEQ-NUM     TO L6945-BENE-SEQ-NUM.
032439*    MOVE LCOMM-BENE-POL-NO      TO L6945-BENE-POL-NO.
032439*    MOVE LCOMM-BENE-POL-SF      TO L6945-BENE-POL-SF.

023737     IF  MIR-CVG-NUM = ZEROES
023737         MOVE ZEROES             TO L6945-BENE-CVG-NUM
023737     END-IF.

           PERFORM  6945-1000-INQUIRE
               THRU 6945-1000-INQUIRE-X.

           PERFORM  3100-RETRN-PARM-INFO
               THRU 3100-RETRN-PARM-INFO-X.

018633*    MOVE L6945-BENE-CVG-NUM     TO WS-WORK-BENE-CVG-NUM.
018633*    MOVE L6945-BENE-SEQ-NUM     TO WS-WORK-BENE-SEQ-NUM.
018633*    MOVE L6945-BENE-POL-NO      TO WS-WORK-BENE-POL-NO.
018633*    MOVE L6945-BENE-POL-SF      TO WS-WORK-BENE-POL-SF.
032439*    MOVE L6945-BENE-CVG-NUM     TO LCOMM-BENE-CVG-NUM.
032439*    MOVE L6945-BENE-SEQ-NUM     TO LCOMM-BENE-SEQ-NUM.
032439*    MOVE L6945-BENE-POL-NO      TO LCOMM-BENE-POL-NO.
032439*    MOVE L6945-BENE-POL-SF      TO LCOMM-BENE-POL-SF.

       3000-DISPLAY-SCREEN-X.
           EXIT.

      *---------------------
       3100-RETRN-PARM-INFO.
      *---------------------

      *    BUILD OUTPUT PARMS

           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-ENTRY-MAX
                  OR   L6945-COVT-T (WS-SUB ) = SPACE

                       MOVE L6945-COVT-T (WS-SUB)
                                       TO MIR-CVG-NUM-T (WS-SUB)

                       MOVE L6945-SEQT-T (WS-SUB)
                                       TO MIR-BNFY-SEQ-NUM-T (WS-SUB)

                       MOVE L6945-CLIT-T (WS-SUB)
                                       TO MIR-CLI-ID-T (WS-SUB)

                       MOVE L6945-BENET-T (WS-SUB)
                                       TO MIR-BNFY-NM-T (WS-SUB)

                       MOVE L6945-TYPT-T (WS-SUB)
                                       TO MIR-BNFY-TYP-CD-T (WS-SUB)

                       MOVE L6945-CNPRT-T (WS-SUB)
                                       TO MIR-BNFY-DESGNT-CD-T (WS-SUB)

                       MOVE L6945-PERCT-T (WS-SUB)
                                       TO MIR-BNFY-PRCDS-PCT-T (WS-SUB)

                       MOVE L6945-RINST-T (WS-SUB)
                                     TO MIR-BNFY-REL-INSRD-CD-T (WS-SUB)

                       MOVE L6945-MINT-T (WS-SUB)
                                       TO MIR-BNFY-MINR-IND-T (WS-SUB)
020477
020477                 MOVE L6945-DESGNT-BNFY-IND-T (WS-SUB)
020477                                 TO MIR-DESGNT-BNFY-IND-T (WS-SUB)
           END-PERFORM.

       3100-RETRN-PARM-INFO-X.
           EXIT.
      /
      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.
           MOVE MIR-CVG-NUM
                                      TO WGLOB-REF-COVERAGE-NUMBER.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.

018633*-------------------
018633*9500-BUILD-TWRK-KEY.
018633*-------------------
018633*
018633*    MOVE WS-TWRK-KEY           TO L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                 TO L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM      TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9800-WRITE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*    MOVE LENGTH OF WS-WORK-AREA TO L8090-AREA-LEN.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9900-DELETE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6945-0000-INIT-PARM-INFO
025970         THRU 6945-0000-INIT-PARM-INFO-X.
025970
032439*    PERFORM  8090-0000-INIT-PARM-INFO
032439*        THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-PROCESS-CHECKS.
025970     SET WS-TRANS-NAME-DEFAULT   TO TRUE.
027105
027105     COMPUTE WS-ENTRY-MAX = LENGTH OF MIR-CVG-NUM-G
027105                          / LENGTH OF MIR-CVG-NUM-T (1).
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
032439*COPY XCPSCOMM.
032439*COPY XCPPCOMM.
018633
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
      *
       COPY CCPSPGA.
      *
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      *
       COPY XCPS0290.
      *
016537*COPY XCPL0290.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
016440 COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
       COPY CCPS6945.
      *
018764*COPY CCCL6945.
018764 COPY CCPL6945.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
016537*COPY XCPL1640.
      *
018764*COPY XCCL8090.
032439*COPY XCPS8090.
032439*COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNCVG.
      *
       COPY CCPNPOL.
      *
       COPY CCPBPOLC.
      *
      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6945                     **
      *****************************************************************
