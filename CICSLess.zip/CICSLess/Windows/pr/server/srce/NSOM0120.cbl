      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0120.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0120                                         **
      **  REMARKS:  DUPL - DUPLICATE RECORDS FOR CERTAIN TABLES.     **
      ***                                                            **
      **            THIS PROGRAM ALLOWS THE USER TO DUPLICATE RECORDS**
      **            IN 14 DIFFERENT FILES BY SELECTING A FILE AND    **
      **            ENTERING KEY INFORMATION FOR AN EXISTING RECORD, **
      **            AND A NEW RECORD.  THE REQUIRED KEY INFORMATION  **
      **            WILL BE DIFFERENT FOR EACH FILE.                 **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557667**  5.5       DUPL THE AGTC RECORDS IF YOU DUPL AG             **
557691**  5.5       ONLINE PROCESS. FOR US QUALIFIED CONTRACTS       **
557693**  5.5       PERIODIC STATEMENT PRODUCTION                    **
557698**  5.5       MIXED CASE DATA                                  **
557708**  5.5       HANDLING OF CICS ABENDS                          **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557767**  5.5       JOINT AGE CALCULATION                            **
557973**  5.5       INTERNATIONAL SUPPORT                            **
008454**  5.5.2     IN 'FROM' KEY CHANGE                             **
007685**  5.6       NAIC MODEL REGULATIONS - PAGE 2                  **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010302**  5.6       ARCHITECTURAL CHANGES                            **
010304**  5.6       TERMINATION RULES                                **
010311**  5.6       CODE CLEANUP                                     **
010314**  5.6       ADD DEPOSIT TERM MONTHS & DAYS TO TABLE RT       **
010418**  5.6       ADD SUB-COMPANY TO FILE TYPE AM, PF, PW          **
010648**  5.6       VARIATIONS BY LOC-DIVIDEND OPT AND DEFAULT       **
010649**  5.6       VARIATIONS BY LOC-BILLING FORM AND MODE          **
010650**  5.6       VARIATIONS BY LOC-PLAN RULES                     **
012429**  5.6       CODE CLEANUP - FIX AM KEY FIELDS                 **
013924**  5.6A      CHANGE THE LENGTH OF PL-REC                      **
014717**  5.6A      CORRECT ASRA FROM NON-NUMERIC UV AGE             **
006002**  6.0       NEW COUNTRY LOCATION TABLE                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
015546**  6.0       RESET COMPANY CODE WHEN DUPL OF A RECORD         **
015546**            IS COMPLETED                                     **
014221**  6.2       TIMESTAMP SETUP                                  **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016476**  6.2       FIX FOR COPY COMMUTATION FUNCTION                **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
021691**  6.4       CALCULATION EXIT MODIFICATIONS                   **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
022658**  6.4       ADD 'U' AS VALID SMOKER CODE WHEN COPYING UNIT   **
022658**            VALUES.                                          **
022730**  6.5       MOVE UNIT VALUES TO RATE HEADER/RATE LOAD        **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023432**  6.5       AGENT LICENSE NUMBER FIELD EXPANSION             **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
023480**  6.5       MSGS FIELDS FOR FUSION REGEN                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
022837**  7.1       COPY OF RATE TABLE                               **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0120'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

557698 COPY XCWL0005.
557698/
557756 COPY XCWL2490.
557756/

025970*01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'DUPL'.
      *
016537*COPY XCWWWKDT.
      *
       01  WS-EDIT-FIELDS.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE
                   '0120' '0121' '0122' '0123' '0124' '0125'
                   '0126' '0127' '0128' '0129' '0130' '0131'.
               88  WS-BUS-FCN-CLONEAG       VALUE '0120'.
               88  WS-BUS-FCN-CLONEAM       VALUE '0121'.
               88  WS-BUS-FCN-CLONELA       VALUE '0122'.
               88  WS-BUS-FCN-CLONEMD       VALUE '0123'.
               88  WS-BUS-FCN-CLONEMS       VALUE '0124'.
023447*        88  WS-BUS-FCN-CLONEPF       VALUE '0125'.
               88  WS-BUS-FCN-CLONEPL       VALUE '0126'.
023447*        88  WS-BUS-FCN-CLONEPW       VALUE '0127'.
               88  WS-BUS-FCN-CLONERH       VALUE '0128'.
               88  WS-BUS-FCN-CLONERT       VALUE '0129'.
               88  WS-BUS-FCN-CLONEUM       VALUE '0130'.
022730*        88  WS-BUS-FCN-CLONEUV       VALUE '0131'.
           05  WS-ENTER-CODE                PIC X(02).
               88  WS-VALID-ENTER-CODE      VALUE 'AG' 'AM' 'LA'
007685*                                           'MD' 'MS' 'PA'
007685                                            'MD' 'MS'
010302*                                           'PF' 'PL' 'PR'
010302                                            'PF' 'PL'
                                                  'PW' 'RH' 'RT'
022730                                            'UM'.
022730*                                           'UM' 'UV'.
               88  WS-ENTER-AG              VALUE 'AG'.
               88  WS-ENTER-AM              VALUE 'AM'.
               88  WS-ENTER-LA              VALUE 'LA'.
035251*        88  WS-ENTER-MD              VALUE 'MD'.
               88  WS-ENTER-MS              VALUE 'MS'.
007685*        88  WS-ENTER-PA              VALUE 'PA'.
023447*        88  WS-ENTER-PF              VALUE 'PF'.
               88  WS-ENTER-PL              VALUE 'PL'.
010302*        88  WS-ENTER-PR              VALUE 'PR'.
023447*        88  WS-ENTER-PW              VALUE 'PW'.
               88  WS-ENTER-RH              VALUE 'RH'.
               88  WS-ENTER-RT              VALUE 'RT'.
               88  WS-ENTER-UM              VALUE 'UM'.
022730*        88  WS-ENTER-UV              VALUE 'UV'.
           05  WS-FROM-KEY-ERROR-SW         PIC X(01).
               88  WS-FROM-KEY-VALID        VALUE 'Y'.
               88  WS-FROM-KEY-NOT-VALID    VALUE 'N'.
           05  WS-TO-KEY-ERROR-SW           PIC X(01).
               88  WS-TO-KEY-VALID          VALUE 'Y'.
               88  WS-TO-KEY-NOT-VALID      VALUE 'N'.
           05  WS-DUPL-SUCCESS-SW           PIC X(01).
               88  WS-DUPL-SUCCESS          VALUE 'Y'.
               88  WS-NO-DUPL-SUCCESS       VALUE 'N'.
           05  WS-EDIT-SMOKERS              PIC X(01).
               88  WS-VALID-SMOKER          VALUE 'S' 'N' 'C' 'U' ' '.
               88  WS-VALID-PR-SMOKER       VALUE 'S' 'N' 'C' ' '.
022658*        88  WS-VALID-UV-SMOKER       VALUE 'S' 'N' 'C'.
022730*        88  WS-VALID-UV-SMOKER       VALUE 'S' 'N' 'C' 'U'.
           05  WS-EDIT-PAR                  PIC X(01).
               88  WS-VALID-PAR             VALUE 'P' 'N'.
               88  WS-VALID-RT-PAR          VALUE 'P' 'N' ' '.
           05  WS-EDIT-SEX                  PIC X(01).
               88  WS-VALID-SEX             VALUE 'M' 'F' 'J'.
               88  WS-VALID-RT-SEX          VALUE 'M' 'F' 'J' ' '.
               88  WS-VALID-LABT-SEX        VALUE 'M' 'F' ' '.
557691     05  WS-EDIT-PQ                   PIC X(01).
557691         88  WS-VALID-PQ              VALUE ' ' 'C' 'D' 'I' 'F'
557691                                            'K' 'O' 'S' 'T'.
557767     05  WS-EDIT-JT                   PIC X(01).
557767         88  WS-VALID-JT              VALUE ' ' 'L' 'F'.
           05  WS-RECORD-TYPE               PIC X(02).
               88  FR-OR-CR-RECORD-TYPE                VALUE 'FR' 'CR'.
               88  TC-RECORD-TYPE                      VALUE 'TC'.
           05  WS-COMPANY-CODE              PIC X(02).
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
           05  WS-FILE-TYPE-SUB             PIC 9(02).
           05  WS-LINE                      PIC 9(02).
025970*    05  WS-MAX-LINES                 PIC 9(02) VALUE 6.
           05  WS-HOLD-AGENT                PIC X(06).
           05  WS-HOLD-AGENT-CHARS REDEFINES WS-HOLD-AGENT.
               10  WS-AGENT-CHAR            PIC X(01) OCCURS 6 TIMES.
016548*    05  WS-INDX-CHAR                 PIC S9(04) COMP SYNC.
016548     05  WS-INDX-CHAR                 PIC S9(04) BINARY SYNC.
016548*    05  WS-INDX-BLANK                PIC S9(04) COMP SYNC.
016548     05  WS-INDX-BLANK                PIC S9(04) BINARY SYNC.
025970*    05  WS-GENERIC-LOC               PIC X(02) VALUE 'XX'.
025970     05  WS-GENERIC-LOC               PIC X(02).
025970         88  WS-DEFAULT-GENERIC-LOC             VALUE 'XX'.
025970*    05  WS-LOC-GROUP                 PIC X(03) VALUE 'XXX'.
025970     05  WS-LOC-GROUP                 PIC X(03).
025970         88  WS-DEFAULT-LOC-GROUP               VALUE 'XXX'.
           05  WS-DB-OPT-TYPE               PIC X(01).
               88 WS-VALID-DB-OPT           VALUE '1' '2' 'A' 'B'
                                                  'I' 'L' ' '.

      *
      *  HOLD AREAS FOR DUPLICATING RECORDS
      *
023118* CHANGED TO USE DATABASE HOLD RECORD LAYOUT FOR EASE OF
023118* MAINTENANCE. HARD CODING RECORD LENGTH MAY CAUSE MISMATCH
023118* LENGTHS ON THE SPECIFIC TABLE WORK AREA BELOW
023118*
       01  WS-HOLD-REC-INFO.
023432*    05  WS-AG-REC-INFO.
023432*        10  WS-AG-REC-KEY           PIC X(08).
557667*        10  WS-AG-REC-DATA          PIC X(162).
010418*        10  WS-AG-REC-DATA          PIC X(136).
014221*        10  WS-AG-REC-DATA          PIC X(186).
023432*        10  WS-AG-REC-DATA          PIC X(219).
023118*    05  WS-ASMB-REC-INFO.
010418*        10  WS-ASMB-REC-KEY         PIC X(24).
023118*        10  WS-ASMB-REC-KEY         PIC X(27).
014221*        10  WS-ASMB-REC-DATA        PIC X(303).
023118*        10  WS-ASMB-REC-DATA        PIC X(305).
023118*    05  WS-LABT-REC-INFO.
023118*        10  WS-LABT-REC-KEY         PIC X(13).
014221*        10  WS-LABT-REC-DATA        PIC X(57).
023118*        10  WS-LABT-REC-DATA        PIC X(73).
023118*    05  WS-MD-REC-INFO.
023118*        10  WS-MD-REC-KEY           PIC X(07).
014221*        10  WS-MD-REC-DATA          PIC X(12).
023118*        10  WS-MD-REC-DATA          PIC X(46).
023480*    05  WS-MSGS-REC-INFO.
023480*        10  WS-MSGS-REC-KEY         PIC X(14).
014221*        10  WS-MSGS-REC-DATA        PIC X(74).
023480*        10  WS-MSGS-REC-DATA        PIC X(178).
010650*    05  WS-PA-REC-INFO.
010650*        10  WS-PA-REC-KEY           PIC X(11).
010650*        10  WS-PA-REC-DATA          PIC X(792).
023447*    05  WS-PF-REC-INFO.
010418*        10  WS-PF-REC-KEY           PIC X(11).
010418*        10  WS-PF-REC-KEY           PIC X(14).
023447*        10  WS-PF-REC-KEY           PIC X(13).
014221*        10  WS-PF-REC-DATA          PIC X(29).
023447*        10  WS-PF-REC-DATA          PIC X(26).
023118*    05  WS-PL-REC-INFO.
023118*        10  WS-PL-REC-KEY           PIC X(08).
557693*        10  WS-PL-REC-DATA          PIC X(752).
010302*        10  WS-PL-REC-DATA          PIC X(817).
010302*        10  WS-PL-REC-DATA          PIC X(551).
014221*        10  WS-PL-REC-DATA          PIC X(586).
023118*        10  WS-PL-REC-DATA          PIC X(625).
023118*    05  WS-PD-REC-INFO.
023118*        10  WS-PD-REC-KEY           PIC X(08).
557693*        10  WS-PD-REC-DATA          PIC X(192).
010302*        10  WS-PD-REC-DATA          PIC X(200).
014221*        10  WS-PD-REC-DATA          PIC X(180).
023118*        10  WS-PD-REC-DATA          PIC X(248).
010302*    05  WS-PR-REC-INFO.
010302*        10  WS-PR-REC-KEY           PIC X(36).
010302*        10  WS-PR-REC-DATA          PIC X(39).
023447*    05  WS-PW-REC-INFO.
010418*        10  WS-PW-REC-KEY           PIC X(11).
010418*        10  WS-PW-REC-KEY           PIC X(14).
023447*        10  WS-PW-REC-KEY           PIC X(13).
014221*        10  WS-PW-REC-DATA          PIC X(1389).
023447*        10  WS-PW-REC-DATA          PIC X(580).
023118*    05  WS-RH-REC-INFO.
023118*        10  WS-RH-REC-KEY           PIC X(15).
010302*        10  WS-RH-REC-DATA          PIC X(135).
014221*        10  WS-RH-REC-DATA          PIC X(136).
023118*        10  WS-RH-REC-DATA          PIC X(174).
023118*    05  WS-RT-REC-INFO.
557667*        10  WS-RT-REC-KEY           PIC X(40).
008454*        10  WS-RT-REC-KEY           PIC X(38).
010314*        10  WS-RT-REC-KEY           PIC X(45).
012525*        10  WS-RT-REC-KEY           PIC X(52).
023118*        10  WS-RT-REC-KEY           PIC X(55).
557667*        10  WS-RT-REC-DATA          PIC X(3775).
008454*        10  WS-RT-REC-DATA          PIC X(3787).
014221*        10  WS-RT-REC-DATA          PIC X(57).
023118*        10  WS-RT-REC-DATA          PIC X(94).
023118*    05  WS-UWMX-REC-INFO.
023118*        10  WS-UWMX-REC-KEY         PIC X(07).
014221*        10  WS-UWMX-REC-DATA        PIC X(169).
023118*        10  WS-UWMX-REC-DATA        PIC X(191).
022730*    05  WS-UV-REC-INFO.
022730*        10  WS-UV-REC-KEY           PIC X(32).
557973*        10  WS-UV-REC-DATA          PIC X(613).
014221*        10  WS-UV-REC-DATA          PIC X(1218).
022730*        10  WS-UV-REC-DATA          PIC X(889).
557667     05  WS-AGTC-MAIL-REC-INFO       PIC X(46).
557667     05  WS-AGTC-RES-REC-INFO        PIC X(46).
010311*    05  WS-LOW-AGE-DUR              PIC 9(3).
010311     05  WS-LOW-AGE-DUR              PIC S9(3).
010311*    05  WS-HIGH-AGE-DUR             PIC 9(3).
010311     05  WS-HIGH-AGE-DUR             PIC S9(3).
008454     05  SW-END-OF-FILE              PIC X(3).
008454     05  SUB                         PIC 9(3).
008454     05  WS-STEP-AGE-DUR             PIC 9(3) VALUE 0.
008454     05  WS-DUPL-AGE-DUR             PIC 9(3) VALUE 0.
008454     05  WS-WRT-KEY.
008454         10  WS-WRT-CO-ID                 PIC X(02).
008454         10  WS-WRT-RTBL-ID               PIC X(06).
008454         10  WS-WRT-RTBL-RT-TYP-CD        PIC X(05).
008454         10  WS-WRT-RTBL-SMKR-CD          PIC X(01).
008454         10  WS-WRT-RTBL-PAR-CD           PIC X(01).
008454         10  WS-WRT-RTBL-SEX-CD           PIC X(01).
008454         10  WS-WRT-RTBL-STBL-CD          PIC X(12).
008454         10  WS-WRT-RTBL-STBL-CD-R REDEFINES
008454             WS-WRT-RTBL-STBL-CD.
008454             15  WS-WRT-RTBL-STBL-1-CD    PIC X(02).
008454             15  WS-WRT-RTBL-STBL-2-CD    PIC X(03).
008454             15  WS-WRT-RTBL-STBL-3-CD    PIC X(05).
008454             15  WS-WRT-RTBL-STBL-4-CD    PIC X(02).
010302*        10  WS-WRT-RTBL-CRNT-LOC-CD      PIC X(02).
010302         10  WS-WRT-RTBL-LOC-GR-CD        PIC X(03).
008454         10  WS-WRT-RTBL-DB-OPT-CD        PIC X(01).
008454         10  WS-WRT-RTBL-PNSN-QUALF-CD    PIC X(01).
008454         10  WS-WRT-RTBL-JNT-LIFE-CD      PIC X(01).
010314         10  WS-WRT-RTBL-DEP-TRM-MOS      PIC X(03).
010314         10  WS-WRT-RTBL-DEP-TRM-DYS      PIC X(03).
012525         10  WS-WRT-RTBL-MAT-XPRY-DUR     PIC X(03).
008454         10  WS-WRT-RTBL-AGE              PIC X(03).
008454         10  WS-WRT-RTBL-AGE-N            REDEFINES
008454             WS-WRT-RTBL-AGE              PIC 9(03).
008454         10  WS-WRT-RTBL-IDT-NUM          PIC X(07).
008454         10  WS-WRT-RTBL-IDT-NUM-N        REDEFINES
008454             WS-WRT-RTBL-IDT-NUM          PIC 9(07).
008454         10  WS-WRT-RTBL-AGE-DUR          PIC S9(03)  COMP-3.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME              VALUE 'DUPL'.
025970     05  WS-MAX-LINES                 PIC 9(02).
025970         88  WS-DEFAULT-MAX-LINES               VALUE 6.
025970/
       COPY XCWL0280.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWLDTLK.
      /
557667 COPY CCWL0840.
      /
557667 COPY CCWL2435.
      /
023447*COPY CCWWPFLY.
      /
       COPY NCWTASMB.
      /
       COPY NCWWDUPL.
      /
       01  FILE-WS-START  PIC X(51)
           VALUE '********* START OF FILE WORKING STORAGE *********'.
      *
       COPY CCFWAB.
       COPY CCFRAB.
      /
       COPY CCFWAG.
       COPY CCFRAG.
023432 COPY CCFHAG.
      /
015290 COPY CCFWPLAR.
      /
015290 COPY CCFRPLAR.
      /
023447*COPY NCFWDOCM.
023447*COPY NCFRDOCM.
007685/
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
035251*COPY CCFWMD.
035251*COPY CCFRMD.
035251*COPY CCFHMD.
      /
007685*COPY CCFWPA.
007685*COPY CCFRPA.
      /
010649 COPY CCFWPBTM.
010649 COPY CCFRPBTM.
010649/
020467 COPY CCFWPBMF.
020467 COPY CCFRPBMF.
020467/
       COPY CCFWPD.
       COPY CCFRPD.
023118 COPY CCFHPD.
      /
020475 COPY CCFWPDBG.
020475 COPY CCFRPDBG.
020475/
021691 COPY XCFWPCXT.
021691 COPY XCFRPCXT.
021691/
010648 COPY CCFWPDIV.
010648 COPY CCFRPDIV.
010648/
023447*COPY CCFWPF.
023447*COPY CCFRPF.
      /
023447*COPY CCFWPFLN.
023447*COPY CCFRPFLN.
      /
       COPY CCFWPH.
       COPY CCFRPH.
023118 COPY CCFHPH.
      /
010304 COPY CCFWPNFO.
010304 COPY CCFRPNFO.
010304/
010302*COPY CCFWPR.
010302*COPY CCFRPR.
      /
010302 COPY CCFWPLRT.
010302 COPY CCFRPLRT.
010418/
010418 COPY CCFWSCOM.
010418 COPY CCFRSCOM.
      /
010650 COPY CCFWPLGR.
010650 COPY CCFRPLGR.
010650/
023447*COPY CCFWPW.
023447*COPY CCFRPW.
      /
       COPY CCFWRH.
       COPY CCFRRH.
023118 COPY CCFHRH.
      /
       COPY CCFWRT.
       COPY CCFRRT.
023118 COPY CCFHRT.
      /
022730*  NO LONGER SUPPORT THE USE OF THE UNIT VALUE  TABLE - WE
022730*  NOW USE THE RATE HEADER / RATE LOAD TABLES. THIS BETTER
022730*  SUPPORTS PRODUCTXPRESS AND ALLOWS CONVERSION TO OTHER PLATFORMS
022730*
022730*COPY CCFWUV.
022730*COPY CCFRUV.
      /
       COPY NCFWASMB.
       COPY NCFRASMB.
023118 COPY NCFHASMB.
      /
       COPY NCFWLABT.
       COPY NCFRLABT.
023118 COPY NCFHLABT.
      /
       COPY NCFWUWMX.
       COPY NCFRUWMX.
023118 COPY NCFHUWMX.
      /
016537*COPY XCFWCTLC.
016537*COPY XCFRCTLC.
006002/
023447 COPY XCFWDOCM.
023447 COPY XCFRDOCM.
023447/
       COPY XCFWMSGS.
       COPY XCFRMSGS.
023480 COPY XCFHMSGS.
      /
       COPY XCFWXTAB.
       COPY XCFRXTAB.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0120.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      **********************
       2000-PROCESS-REQUEST.
      **********************
      *
023514*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF  NOT WS-BUS-FCN-ID-VALID
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
               MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
               MOVE 'NSOM0120'        TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-INVALD-RQST  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2100-DETERMINE-KEY-FORMAT
               THRU 2100-DETERMINE-KEY-FORMAT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  MIR-CO-ID = SPACES
               MOVE WGLOB-COMPANY-CODE    TO MIR-CO-ID
           END-IF.

           PERFORM  2200-EDIT-COMPANY-REQUIRED
               THRU 2200-EDIT-COMPANY-REQUIRED-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           ELSE
               IF  MIR-DV-RQST-KEY-1-TXT-G = SPACES
      *            MSG: MUST ENTER AT LEAST ONE KEY TO DUPLICATE
                   MOVE 'NS01200088'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   SET WS-DUPL-SUCCESS TO TRUE
                   PERFORM  3000-PROCESS-DUPLICATION
                       THRU 3000-PROCESS-DUPLICATION-X
                       VARYING WS-LINE FROM 1 BY 1
                       UNTIL WS-LINE > WS-MAX-LINES
               END-IF
           END-IF.
      *
      *  IF NO ERRORS RESET SCREEN AND DISPLAY COMPLETION MESSAGE
      *
           IF  WS-DUPL-SUCCESS
      *        MSG: DUPLICATION PROCESS OF RECORDS SUCCESSFUL - CONTINUE
               MOVE 'NS01200085'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           END-IF.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      ********************************************************
      *   DETERMINE THE KEY FORMAT FROM THE FILE KEY ENTERED
      ********************************************************
      *
       2100-DETERMINE-KEY-FORMAT.
      *
           PERFORM  2110-SET-FILE-ID
               THRU 2110-SET-FILE-ID-X.

           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WDUPL-MAX-FILE-TYPE
557756*        OR MIR-ENTER = WDUPL-FILE-ID (WGLOB-LANG-SUB, WS-SUB)
               OR WS-ENTER-CODE = WDUPL-FILE-ID (WS-SUB)
015543         CONTINUE
           END-PERFORM.
      *
           IF WS-SUB > WDUPL-MAX-FILE-TYPE
      *        MSG: NO KEY FORMAT FOUND FOR FILE TYPE (@1)
               MOVE 'NS01200001'      TO WGLOB-MSG-REF-INFO
               MOVE WDUPL-FILE-TYPE   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-DETERMINE-KEY-FORMAT-X
           END-IF.
      *
557756*
557756     PERFORM  2490-1000-BUILD-PARM-INFO
557756         THRU 2490-1000-BUILD-PARM-INFO-X.
557756
557756     MOVE 'NSOM0120'            TO L2490-TXT-SRC-ID.
557756     MOVE WDUPL-TXT-SRC-REF-ID (WS-SUB)
                                      TO L2490-TXT-SRC-REF-ID.
557756
557756     PERFORM  2490-1000-RETRIEVE-TEXT
557756         THRU 2490-1000-RETRIEVE-TEXT-X.
557756
           MOVE L2490-TXT-STR-TXT     TO MIR-DV-FILE-KEY-TXT.
557756*    MOVE WDUPL-KEY-FORMAT (WGLOB-LANG-SUB, WS-SUB) TO
557756*         C0120-FILE-KEY.
           MOVE WS-SUB                TO WS-FILE-TYPE-SUB.

       2100-DETERMINE-KEY-FORMAT-X.
           EXIT.

      ******************
       2110-SET-FILE-ID.
      ******************
      *
      *  SET ENTER CODE FROM BUSINESS FUNCTION ID
      *
           MOVE SPACES                TO WS-ENTER-CODE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CLONEAG
                    SET WS-ENTER-AG   TO TRUE

               WHEN WS-BUS-FCN-CLONEAM
                    SET WS-ENTER-AM   TO TRUE

               WHEN WS-BUS-FCN-CLONELA
                    SET WS-ENTER-LA   TO TRUE

035251*        WHEN WS-BUS-FCN-CLONEMD
035251*             SET WS-ENTER-MD   TO TRUE

               WHEN WS-BUS-FCN-CLONEMS
                    SET WS-ENTER-MS   TO TRUE

023447*        WHEN WS-BUS-FCN-CLONEPF
023447*             SET WS-ENTER-PF   TO TRUE

               WHEN WS-BUS-FCN-CLONEPL
                    SET WS-ENTER-PL   TO TRUE

023447*        WHEN WS-BUS-FCN-CLONEPW
023447*             SET WS-ENTER-PW   TO TRUE

               WHEN WS-BUS-FCN-CLONERH
                    SET WS-ENTER-RH   TO TRUE

               WHEN WS-BUS-FCN-CLONERT
                    SET WS-ENTER-RT   TO TRUE

               WHEN WS-BUS-FCN-CLONEUM
                    SET WS-ENTER-UM   TO TRUE

022730*        WHEN WS-BUS-FCN-CLONEUV
022730*             SET WS-ENTER-UV   TO TRUE
022730*
           END-EVALUATE.

       2110-SET-FILE-ID-X.
           EXIT.

      *
      *   MOVE THE COMPANY REQUIRED CODES TO THE TABLE
      *
       2200-EDIT-COMPANY-REQUIRED.
      *
           MOVE WAG-COMPANY-REQUIRED-SW
                                      TO  WDUPL-COMPANY-SW (1).
           MOVE WASMB-COMPANY-REQUIRED-SW
                                      TO  WDUPL-COMPANY-SW (2).
           MOVE WLABT-COMPANY-REQUIRED-SW
                                      TO  WDUPL-COMPANY-SW (3).
035251     MOVE WMSGS-COMPANY-REQUIRED-SW
035251                                TO  WDUPL-COMPANY-SW (4).                                      
035251     MOVE WPH-COMPANY-REQUIRED-SW
035251                                TO  WDUPL-COMPANY-SW (5).
035251     MOVE WRH-COMPANY-REQUIRED-SW
035251                                TO  WDUPL-COMPANY-SW (6).
035251     MOVE WRT-COMPANY-REQUIRED-SW
035251                                TO  WDUPL-COMPANY-SW (7).
035251     MOVE WUWMX-COMPANY-REQUIRED-SW
035251                                TO  WDUPL-COMPANY-SW (8).
035251*    MOVE WMD-COMPANY-REQUIRED-SW
035251*                               TO  WDUPL-COMPANY-SW (4).
035251*    MOVE WMD-COMPANY-REQUIRED-SW
035251*                               TO  WDUPL-COMPANY-SW (5).
035251*    MOVE WPH-COMPANY-REQUIRED-SW
035251*                                TO  WDUPL-COMPANY-SW (6).
035251*    MOVE WRH-COMPANY-REQUIRED-SW
035251*                                TO  WDUPL-COMPANY-SW (7).
035251*    MOVE WRT-COMPANY-REQUIRED-SW
035251*                                TO  WDUPL-COMPANY-SW (8).
035251*    MOVE WUWMX-COMPANY-REQUIRED-SW
035251*                                TO  WDUPL-COMPANY-SW (9).
007685*    MOVE WPA-COMPANY-REQUIRED-SW   TO  WDUPL-COMPANY-SW (6).
010302*    MOVE WPF-COMPANY-REQUIRED-SW   TO  WDUPL-COMPANY-SW (7).
010302*    MOVE WPH-COMPANY-REQUIRED-SW   TO  WDUPL-COMPANY-SW (8).
010302*    MOVE WPR-COMPANY-REQUIRED-SW   TO  WDUPL-COMPANY-SW (9).
010302*    MOVE WPW-COMPANY-REQUIRED-SW   TO  WDUPL-COMPANY-SW (10).
010302*    MOVE WRH-COMPANY-REQUIRED-SW   TO  WDUPL-COMPANY-SW (11).
010302*    MOVE WRT-COMPANY-REQUIRED-SW   TO  WDUPL-COMPANY-SW (12).
010302*    MOVE WUWMX-COMPANY-REQUIRED-SW TO  WDUPL-COMPANY-SW (13).
010302*    MOVE WUV-COMPANY-REQUIRED-SW   TO  WDUPL-COMPANY-SW (14).
023447*    MOVE WPF-COMPANY-REQUIRED-SW
023447*                               TO  WDUPL-COMPANY-SW (6).
023447*    MOVE WPH-COMPANY-REQUIRED-SW
023447*                               TO  WDUPL-COMPANY-SW (7).
023447*    MOVE WPW-COMPANY-REQUIRED-SW
023447*                               TO  WDUPL-COMPANY-SW (8).
023447*    MOVE WRH-COMPANY-REQUIRED-SW
023447*                               TO  WDUPL-COMPANY-SW (9).
023447*    MOVE WRT-COMPANY-REQUIRED-SW
023447*                               TO  WDUPL-COMPANY-SW (10).
023447*    MOVE WUWMX-COMPANY-REQUIRED-SW
023447*                               TO  WDUPL-COMPANY-SW (11).
022730*    MOVE WUV-COMPANY-REQUIRED-SW
022730*                               TO  WDUPL-COMPANY-SW (12).

      *  IF MULTI-COMPANY EDIT COMPANY CODE
      *  DO NOT ALLOW DUPL TO A NEW COMPANY IF NOT MULTI-COMPANY FILE

           IF WDUPL-COMPANY-REQUIRED (WS-FILE-TYPE-SUB)
               PERFORM  2210-VALIDATE-TO-COMPANY
                   THRU 2210-VALIDATE-TO-COMPANY-X
           ELSE
      *        MSG: NON MULTI-COMPANY FILE (@1) - COMPANY CODE NOT VALID
               MOVE 'NS01200002'      TO WGLOB-MSG-REF-INFO
               MOVE WS-ENTER-CODE     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       2200-EDIT-COMPANY-REQUIRED-X.
           EXIT.
      *
      *****************************
      *   EDIT INPUT COMPANY CODE
      *****************************
      *
       2210-VALIDATE-TO-COMPANY.
      *
      *    VALIDATE THE COMPANY CODE
      *
           MOVE MIR-CO-ID             TO WEDIT-ETBL-VALU-ID.
           PERFORM  COMP-1000-EDIT-COMPANY
               THRU COMP-1000-EDIT-COMPANY-X.

           IF WEDIT-IO-OK
               MOVE MIR-CO-ID         TO WDUPL-COMPANY
           ELSE
      *        MSG: COMPANY CODE MUST BE IN EDIT TYPE 'COMP'
               MOVE 'XS00000082'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       2210-VALIDATE-TO-COMPANY-X.
           EXIT.
      *
      * PROCESS FILE DUPLICATION
      * IF THE FROM KEY IS SPACES THERE IS NOTHING TO DUPLICATE
      * SO SKIP THAT LINE AND CONTINUE TO THE NEXT
      *
       3000-PROCESS-DUPLICATION.
      *
           IF MIR-DV-RQST-KEY-1-TXT-T (WS-LINE) = SPACES
               GO TO 3000-PROCESS-DUPLICATION-X
           END-IF.
      *
           SET WS-FROM-KEY-VALID   TO TRUE.
           SET WS-TO-KEY-VALID     TO TRUE.
           MOVE ZEROES                TO WGLOB-MSG-ERROR-SW.
      *
      *  SAVE THE CURRENT COMPANY CODE
      *
           MOVE WGLOB-COMPANY-CODE    TO WS-COMPANY-CODE.
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-CLONEAG
                    PERFORM  4000-DUPL-AG
                        THRU 4000-DUPL-AG-X

               WHEN WS-BUS-FCN-CLONEAM
                    PERFORM  4100-DUPL-AM
                        THRU 4100-DUPL-AM-X

               WHEN WS-BUS-FCN-CLONELA
                    PERFORM  4200-DUPL-LA
                        THRU 4200-DUPL-LA-X

035251*        WHEN WS-BUS-FCN-CLONEMD
035251*             PERFORM  4300-DUPL-MD
035251*                 THRU 4300-DUPL-MD-X

               WHEN WS-BUS-FCN-CLONEMS
                    PERFORM  4400-DUPL-MS
                        THRU 4400-DUPL-MS-X

023447*        WHEN WS-BUS-FCN-CLONEPF
023447*             PERFORM  4600-DUPL-PF
023447*                 THRU 4600-DUPL-PF-X

               WHEN WS-BUS-FCN-CLONEPL
                    PERFORM  4700-DUPL-PL
                        THRU 4700-DUPL-PL-X

023447*        WHEN WS-BUS-FCN-CLONEPW
023447*             PERFORM  4900-DUPL-PW
023447*                 THRU 4900-DUPL-PW-X

               WHEN WS-BUS-FCN-CLONERH
                    PERFORM  5000-DUPL-RH
                        THRU 5000-DUPL-RH-X

               WHEN WS-BUS-FCN-CLONERT
                    PERFORM  5100-DUPL-RT
                        THRU 5100-DUPL-RT-X

               WHEN WS-BUS-FCN-CLONEUM
                    PERFORM  5200-DUPL-UM
                        THRU 5200-DUPL-UM-X

022730*        WHEN WS-BUS-FCN-CLONEUV
022730*             PERFORM  5300-DUPL-UV
022730*                 THRU 5300-DUPL-UV-X
022730*
           END-EVALUATE.

           IF WS-FROM-KEY-NOT-VALID
               SET WS-NO-DUPL-SUCCESS TO TRUE
               GO TO 3000-PROCESS-DUPLICATION-X
           END-IF.

013578     MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
      *
      *  IF NOT VALID SET ERROR ATTRIBUTES
      *  IF VALID MOVE SPACES TO THE LINE IN ORDER NOT TO EDIT
      *  IT AGAIN IF OTHER ERRORS
      *
           IF WS-TO-KEY-NOT-VALID
               SET WS-NO-DUPL-SUCCESS TO TRUE
           ELSE
               MOVE SPACES          TO MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
               MOVE SPACES          TO MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
      *        MSG: SUCCESSFUL DUPLICATION OF RECORD (@1)
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *
       3000-PROCESS-DUPLICATION-X.
           EXIT.
      *
      ******************************************************************
      *  FOR EACH FILE DUPLICATION FOLLOW THE FOLLOWING EDITS
      *  1. EDIT THE FROM KEY TO ENSURE THAT IT EXISTS ON THE FILE
      *     SAVE THE FILE RECORD
      *  2. EDIT THE TO KEY FOR VALID KEY
      *     MAKE SURE KEY DOES NOT EXIST ON FILE
      *  3. EVERYTHING IS OK - MOVE SAVED FROM FILE DATA TO DATA-REC
      *                      - MOVE TO KEY TO FILE KEY AND WRITE RECORD
      ******************************************************************
      *
       4000-DUPL-AG.
      *
      *  EDIT FROM KEY
      *  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
      *  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
      *
           MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
           MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-AG.
           PERFORM  4010-BUILD-AG-KEY
               THRU 4010-BUILD-AG-KEY-X.

           PERFORM  AG-1000-READ
               THRU AG-1000-READ-X.
           IF WAG-IO-NOT-FOUND
      *        MSG: AG FROM KEY ON LINE (@1) DOES NOT EXIST
               MOVE 'NS01200004'      TO WGLOB-MSG-REF-INFO
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 4000-DUPL-AG-X
           END-IF.
      *
      *  FROM RECORD EXISTS - SAVE RECORD
      *
023432*    MOVE RAG-REC-INFO          TO WS-AG-REC-INFO.
023432     MOVE RAG-REC-INFO          TO HAG-REC-INFO.
      *
557667*  CHECK THE FROM KEY TO SEE WHAT AGTC RECORDS EXIST
557667*    FOR BOTH MAIL AND RESIDENTIAL CLIENT IDS.

557667     INITIALIZE L0840-IO-PARM-INFO.
557667     MOVE RAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-RESIDENTIAL
557667                                TO TRUE.
557667     PERFORM 0840-5000-GET-AGT-REL
557667        THRU 0840-5000-GET-AGT-REL-X.
557667     IF L0840-RETRN-OK
557667        MOVE L0840-IO-PARM-INFO TO WS-AGTC-RES-REC-INFO
557667     ELSE
557667*         MSG: RES AGTC FROM KEY ON LINE (@1) DOES NOT EXIST
557667        MOVE 'NS01200091'       TO WGLOB-MSG-REF-INFO
557667        MOVE WS-LINE            TO WGLOB-MSG-PARM (1)
557667        PERFORM  0260-1000-GENERATE-MESSAGE
557667            THRU 0260-1000-GENERATE-MESSAGE-X
557667        SET WS-FROM-KEY-NOT-VALID TO TRUE
557667        GO TO 4000-DUPL-AG-X
557667     END-IF.

557667     INITIALIZE L0840-IO-PARM-INFO.
557667     MOVE RAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-MAILING   TO TRUE.
557667     PERFORM 0840-5000-GET-AGT-REL
557667        THRU 0840-5000-GET-AGT-REL-X.
557667     IF L0840-RETRN-OK
557667        MOVE L0840-IO-PARM-INFO TO WS-AGTC-MAIL-REC-INFO
557667     ELSE
557667*          MSG: MAIL AGTC FROM KEY ON LINE (@1) DOES NOT EXIST
557667         MOVE 'NS01200092'      TO WGLOB-MSG-REF-INFO
557667         MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
557667         PERFORM  0260-1000-GENERATE-MESSAGE
557667            THRU 0260-1000-GENERATE-MESSAGE-X
557667         SET WS-FROM-KEY-NOT-VALID TO TRUE
557667         GO TO 4000-DUPL-AG-X
557667     END-IF.

      *  MOVE COMPANY CODE IF USING
      *
           IF WDUPL-COMPANY NOT = SPACES
               MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
           END-IF.
      *
      *  EDIT TO KEY
      *
           MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-AG.
           PERFORM  4020-VALIDATE-AG-KEY
               THRU 4020-VALIDATE-AG-KEY-X.
           IF WS-TO-KEY-NOT-VALID
               GO TO 4000-DUPL-AG-X
           END-IF.

           PERFORM  4010-BUILD-AG-KEY
               THRU 4010-BUILD-AG-KEY-X.
           PERFORM  AG-1000-READ
               THRU AG-1000-READ-X.
           IF WAG-IO-OK
      *        MSG: AG TO KEY ON LINE (@1) ALREADY EXISTS
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 4000-DUPL-AG-X
           END-IF.

557667*  CHECK TO VERIFY THAT NO SUCH AGTC RECORDS EXIST ALREADY
557667*    FOR BOTH MAIL AND RESIDENTIAL CLIENT IDS.


557667

557667     PERFORM 0840-0000-INIT-PARM-INFO
557667        THRU 0840-0000-INIT-PARM-INFO-X.
557667     MOVE WAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-RESIDENTIAL
557667                                TO TRUE.
557667     PERFORM 0840-7000-CHK-AGT-REL-EXIST
557667        THRU 0840-7000-CHK-AGT-REL-EXIST-X.
557667     IF L0840-REL-EXIST-YES
557667*          MSG: RES AGTC TO KEY ON LINE (@1) ALREADY EXISTS
557667         MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
557667         MOVE 'NS01200093'      TO WGLOB-MSG-REF-INFO
557667         PERFORM  0260-1000-GENERATE-MESSAGE
557667             THRU 0260-1000-GENERATE-MESSAGE-X
557667         SET WS-TO-KEY-NOT-VALID TO TRUE
557667         GO TO 4000-DUPL-AG-X
557667     END-IF.

557667     INITIALIZE L0840-IO-PARM-INFO.
557667     PERFORM 0840-0000-INIT-PARM-INFO
557667        THRU 0840-0000-INIT-PARM-INFO-X.
557667     MOVE WAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-MAILING   TO TRUE.
557667     PERFORM 0840-7000-CHK-AGT-REL-EXIST
557667        THRU 0840-7000-CHK-AGT-REL-EXIST-X.
557667     IF L0840-REL-EXIST-YES
557667*          MSG: MAIL AGTC TO KEY ON LINE (@1) ALREADY EXISTS
557667         MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
557667         MOVE 'NS01200094'      TO WGLOB-MSG-REF-INFO
557667         PERFORM  0260-1000-GENERATE-MESSAGE
557667             THRU 0260-1000-GENERATE-MESSAGE-X
557667         SET WS-TO-KEY-NOT-VALID TO TRUE
557667         GO TO 4000-DUPL-AG-X
557667      END-IF.
      *
      *  EVERYTHING IS OK - DUPLICATE AG RECORD
      *
023432*    MOVE WS-AG-REC-INFO        TO RAG-REC-INFO.
023432     MOVE HAG-REC-INFO          TO RAG-REC-INFO.
           MOVE WDUPL-KEY-ALL         TO WAG-KEY.
           PERFORM  AG-1000-WRITE
               THRU AG-1000-WRITE-X.
           PERFORM  AB-1000-CREATE
               THRU AB-1000-CREATE-X.
010418*    PERFORM  AB-1000-WRITE
010418*        THRU AB-1000-WRITE-X.

557667* CONFIRM THAT THE MAIL AND RESIDENTIAL CLIENT NUMBERS HAVE BEEN
557667* CREATED THE CLIENT FILE, OR ELSE WE CANNOT CREATE THE AGTC
557667* RECORDS.  NOTE THAT FOR DUPL PURPOSES, WE ARE DEFAULTING THE
557667* MAIL AND RESIDENTIAL CLIENT TO THE AGENT NUMBER.

557667     PERFORM 2435-1000-BUILD-PARM-INFO
557667        THRU 2435-1000-BUILD-PARM-INFO-X.

557667     MOVE RAG-AGT-ID            TO L2435-CLI-ID.

557667     PERFORM 2435-1000-OBTAIN-CLI-INFO
557667        THRU 2435-1000-OBTAIN-CLI-INFO-X.

557667     IF L2435-RETRN-OK
034802*       NEXT SENTENCE
034802        CONTINUE
557667     ELSE
557667*MSG: MANUALLY UPDATE THE AGENT @1 WITH MAIL AND RES CLIENT IDS
557667         MOVE RAG-AGT-ID        TO WGLOB-MSG-PARM (1)
557667         MOVE 'NS01200097'      TO WGLOB-MSG-REF-INFO
557667         PERFORM  0260-1000-GENERATE-MESSAGE
557667             THRU 0260-1000-GENERATE-MESSAGE-X
557667         GO TO 4000-DUPL-AG-X
557667     END-IF.

557667*  CREATE THE REQUIRED AGTC RECORDS.

557667     PERFORM 0840-0000-INIT-PARM-INFO
557667        THRU 0840-0000-INIT-PARM-INFO-X.

557667     MOVE WS-AGTC-RES-REC-INFO  TO L0840-IO-PARM-INFO.
557667     MOVE WAG-AGT-ID            TO L0840-CLI-ID.
557667     MOVE WAG-AGT-ID            TO L0840-AGT-ID.
557667
557667     SET L0840-REL-TYP-RESIDENTIAL
557667                                TO TRUE.
018764*557667     PERFORM 0840-1000-UPDT-AGT-REL
018764*557667        THRU 0840-1000-UPDT-AGT-REL-X.
018764     PERFORM 0840-1000-UPD-AGT-REL
018764        THRU 0840-1000-UPD-AGT-REL-X.
557667     IF NOT L0840-RETRN-OK
557667*          MSG: AGTC RECORDS COULD NOT BE CREATED FOR LINE @1
557667         MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
557667         MOVE 'NS01200095'      TO WGLOB-MSG-REF-INFO
557667         PERFORM  0260-1000-GENERATE-MESSAGE
557667             THRU 0260-1000-GENERATE-MESSAGE-X
557667         GO TO 4000-DUPL-AG-X
557667     END-IF.

557667     PERFORM 0840-0000-INIT-PARM-INFO
557667        THRU 0840-0000-INIT-PARM-INFO-X.

557667     MOVE WS-AGTC-MAIL-REC-INFO TO L0840-IO-PARM-INFO.
557667     MOVE WAG-AGT-ID            TO L0840-CLI-ID.
557667     MOVE WAG-AGT-ID            TO L0840-AGT-ID.

557667     MOVE RAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-MAILING   TO TRUE.
018764*557667     PERFORM 0840-1000-UPDT-AGT-REL
018764*557667        THRU 0840-1000-UPDT-AGT-REL-X.
018764     PERFORM 0840-1000-UPD-AGT-REL
018764        THRU 0840-1000-UPD-AGT-REL-X.
557667     IF NOT L0840-RETRN-OK
557667*          MSG: MAIL AGTC COULD NOT BE CREATED FOR LINE (@1)
557667         MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
557667         MOVE 'NS01200096'      TO WGLOB-MSG-REF-INFO
557667         PERFORM  0260-1000-GENERATE-MESSAGE
557667             THRU 0260-1000-GENERATE-MESSAGE-X
557667         GO TO 4000-DUPL-AG-X
557667     END-IF.

      *
       4000-DUPL-AG-X.
           EXIT.
      *
       4010-BUILD-AG-KEY.
      *
           MOVE WDUPL-KEY-AG-AGENT    TO WAG-AGT-ID.
           MOVE WAG-KEY               TO WDUPL-KEY-ALL.
           MOVE WDUPL-KEY-ALL         TO RAG-KEY.
           MOVE WDUPL-KEY-ALL         TO WAB-KEY.
           MOVE WDUPL-KEY-ALL         TO RAB-KEY.
      *
       4010-BUILD-AG-KEY-X.
           EXIT.
      *
       4020-VALIDATE-AG-KEY.
      *
           IF WDUPL-KEY-AG-AGENT = SPACES
               SET WS-TO-KEY-NOT-VALID TO TRUE
      *        MSG: NO KEY ENTERED FOR AG DUPLICATION
               MOVE 'NS01200006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4020-VALIDATE-AG-KEY-X
           END-IF.
      *
      *  ENSURE THAT AGENT NUMBER DOES NOT HAVE IMBEDDED SPACES
      *
           MOVE WDUPL-KEY-AG-AGENT    TO WS-HOLD-AGENT.
           PERFORM
               VARYING WS-INDX-CHAR FROM 6 BY -1
               UNTIL   WS-INDX-CHAR < 1
               OR WS-AGENT-CHAR (WS-INDX-CHAR) NOT = SPACE
015543         CONTINUE
           END-PERFORM.

           PERFORM
               VARYING WS-INDX-BLANK FROM 1 BY 1
               UNTIL   WS-INDX-BLANK > 6
               OR WS-AGENT-CHAR (WS-INDX-BLANK) = SPACE
015543         CONTINUE
           END-PERFORM.

           IF  WS-INDX-BLANK     <  WS-INDX-CHAR
               SET WS-TO-KEY-NOT-VALID TO TRUE
      *        MSG: AGENT CODE MUST NOT CONTAIN IMBEDDED BLANK CHARS
               MOVE 'NS01200007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4020-VALIDATE-AG-KEY-X.
           EXIT.
      *
       4100-DUPL-AM.
      *
      *  EDIT FROM KEY
      *  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
      *  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
      *
           MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
           MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-ASMB.
           PERFORM  4123-VALIDATE-ASMB-EFF-DATE
               THRU 4123-VALIDATE-ASMB-EFF-DATE-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 4100-DUPL-AM-X
           END-IF.
           PERFORM  4110-BUILD-AM-KEY
               THRU 4110-BUILD-AM-KEY-X.

           PERFORM  ASMB-1000-READ
               THRU ASMB-1000-READ-X.
           IF WASMB-IO-NOT-FOUND
      *        MSG: ASMB FROM KEY ON LINE (@1) DOES NOT EXIST
               MOVE 'NS01200008'      TO WGLOB-MSG-REF-INFO
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 4100-DUPL-AM-X
           END-IF.
      *
      *  FROM RECORD EXISTS - SAVE RECORD
      *
023118*    MOVE RASMB-REC-INFO        TO WS-ASMB-REC-INFO.
023118     MOVE RASMB-REC-INFO        TO HASMB-REC-INFO.

      *
      *  MOVE COMPANY CODE IF USING
      *
           IF WDUPL-COMPANY NOT = SPACES
               MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
           END-IF.
      *
      *  EDIT TO KEY
      *
           MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-ASMB.
           PERFORM  4120-VALIDATE-ASMB-KEY
               THRU 4120-VALIDATE-ASMB-KEY-X.
           IF WS-TO-KEY-NOT-VALID
               GO TO 4100-DUPL-AM-X
           END-IF.

           PERFORM  4110-BUILD-AM-KEY
               THRU 4110-BUILD-AM-KEY-X.
           PERFORM  ASMB-1000-READ
               THRU ASMB-1000-READ-X.
           IF WASMB-IO-OK
      *        MSG: ASMB TO KEY ON LINE (@1) ALREADY EXISTS
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID   TO TRUE
               GO TO 4100-DUPL-AM-X
           END-IF.
      *
      *  EVERYTHING IS OK - DUPLICATE ASMB RECORD
      *
023118*    MOVE WS-ASMB-REC-INFO      TO RASMB-REC-INFO.
023118     MOVE HASMB-REC-INFO        TO RASMB-REC-INFO.
           MOVE WDUPL-KEY-ALL         TO RASMB-KEY.
           MOVE WDUPL-KEY-ALL         TO WASMB-KEY.
      *
      *    BLANK OUT ASSEMBLY INSTRUCTION FIELDS SO THAT DATA IS
      *    NOT COPIED FROM A PREVIOUS RECORD
      *
           MOVE SPACES                TO  RASMB-CASM-INSTR-TXT (1).
           MOVE SPACES                TO  RASMB-CASM-INSTR-TXT (2).
           MOVE SPACES                TO  RASMB-CASM-INSTR-TXT (3).
           MOVE SPACES                TO  RASMB-CASM-INSTR-TXT (4).

      *
           PERFORM  4140-COMPUTE-ASMB-REC-LENGTH
               THRU 4140-COMPUTE-ASMB-REC-LENGTH-X.
      *
           PERFORM  ASMB-1000-WRITE
               THRU ASMB-1000-WRITE-X.
      *
       4100-DUPL-AM-X.
           EXIT.
      *
       4110-BUILD-AM-KEY.
      *

           MOVE WDUPL-KEY-ASMB-POINTER                 TO WASMB-CASM-ID.
010418     MOVE WDUPL-KEY-ASMB-SBSDRY-CO-ID
                                      TO WASMB-SBSDRY-CO-ID.
007685*    MOVE WDUPL-KEY-ASMB-ISS-LOC TO WASMB-CASM-ISS-LOC-CD.
007685*    MOVE WDUPL-KEY-ASMB-LOC-GR  TO WASMB-CASM-LOC-GR-CD.
007685     MOVE WDUPL-KEY-ASMB-LOC-GR TO WASMB-LOC-GR-ID.
           MOVE L1660-INVERTED-DATE   TO WASMB-CASM-EFF-IDT-NUM.
           MOVE WDUPL-KEY-ASMB-SEQ-NUM            TO WASMB-CASM-SEQ-NUM.
           MOVE WDUPL-KEY-ASMB-REC-TP TO WASMB-CASM-REC-TYP-CD.
           MOVE WDUPL-KEY-ASMB-REC-NUM            TO WASMB-CASM-REC-NUM.
           MOVE WASMB-KEY             TO WDUPL-KEY-ALL.
      *
       4110-BUILD-AM-KEY-X.
           EXIT.
      *
       4120-VALIDATE-ASMB-KEY.
      *
      *    EDIT ASMB KEY FIELDS
      *
           PERFORM  4121-VALIDATE-ASMB-POINTER
               THRU 4121-VALIDATE-ASMB-POINTER-X.
007685*    PERFORM  4122-VALIDATE-ASMB-ISSUE-LOC
007685*        THRU 4122-VALIDATE-ASMB-ISSUE-LOC-X.
007685     PERFORM  4122-VALIDATE-ASMB-LOC-GROUP
007685         THRU 4122-VALIDATE-ASMB-LOC-GROUP-X.
           PERFORM  4123-VALIDATE-ASMB-EFF-DATE
               THRU 4123-VALIDATE-ASMB-EFF-DATE-X.
           PERFORM  4124-VALIDATE-ASMB-SEQ-NUM
               THRU 4124-VALIDATE-ASMB-SEQ-NUM-X.
           PERFORM  4125-VALIDATE-ASMB-REC-TYPE
               THRU 4125-VALIDATE-ASMB-REC-TYPE-X.
           PERFORM  4126-VALIDATE-ASMB-REC-NUM
               THRU 4126-VALIDATE-ASMB-REC-NUM-X.
010418     PERFORM  4127-VALIDATE-ASMB-SUB-CO
010418         THRU 4127-VALIDATE-ASMB-SUB-CO-X.
      *
           IF WS-TO-KEY-VALID
010418         PERFORM  4128-ASMB-CROSS-EDITS
010418             THRU 4128-ASMB-CROSS-EDITS-X
           END-IF.
      *
       4120-VALIDATE-ASMB-KEY-X.
           EXIT.
      /
      ****************************
       4121-VALIDATE-ASMB-POINTER.
      ****************************
      *
      *  EDIT ASSEMBLY POINTER
      *
           MOVE WDUPL-KEY-ASMB-POINTER            TO WEDIT-ETBL-VALU-ID.
           PERFORM  ASMP-1000-EDIT-ASSEMBLY-PTR
               THRU ASMP-1000-EDIT-ASSEMBLY-PTR-X.
      *
           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *        MSG: ASSEMBLY POINTER MUST BE ON EDIT TYPE 'ASMBP'
               MOVE 'NS01200011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       4121-VALIDATE-ASMB-POINTER-X.
           EXIT.
      *
007685******************************
007685*4122-VALIDATE-ASMB-ISSUE-LOC.
007685******************************
007685*
007685*    EDIT ISSUE LOCATION
007685*
007685*    IF WDUPL-KEY-ASMB-ISS-LOC EQUAL WS-GENERIC-LOC
007685*       GO TO 4122-VALIDATE-ASMB-ISSUE-LOC-X
007685*    END-IF.
007685*    MOVE WDUPL-KEY-ASMB-ISS-LOC TO WEDIT-ETBL-VALU-ID.
007685*    PERFORM  ILOC-1000-EDIT-ISSU-LOCATION
007685*        THRU ILOC-1000-EDIT-ISSU-LOCATION-X.
007685*
007685*    IF WEDIT-IO-OK
007685*        NEXT SENTENCE
007685*    ELSE
007685*        MSG: INVALID ISSUE LOCATION (@1)
007685*        MOVE WDUPL-KEY-ASMB-ISS-LOC TO WGLOB-MSG-PARM (1)
007685*        MOVE 'NS01200010'           TO WGLOB-MSG-REF-INFO
007685*        PERFORM  0260-1000-GENERATE-MESSAGE
007685*            THRU 0260-1000-GENERATE-MESSAGE-X
007685*        SET WS-TO-KEY-NOT-VALID     TO TRUE
007685*    END-IF.
007685*
007685*4122-VALIDATE-ASMB-ISSUE-LOC-X.
007685*    EXIT.
      *
007685******************************
007685 4122-VALIDATE-ASMB-LOC-GROUP.
007685******************************
007685*
007685*    EDIT ISSUE LOCATION
007685*
007685     IF WDUPL-KEY-ASMB-LOC-GR  EQUAL WS-LOC-GROUP
007685         GO TO 4122-VALIDATE-ASMB-LOC-GROUP-X
007685     END-IF.
007685
007685     MOVE WDUPL-KEY-ASMB-LOC-GR TO WEDIT-ETBL-VALU-ID.
007685     PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
007685         THRU LCGP-1000-EDIT-LCGP-LOCATION-X.
007685
007685     IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
007685     ELSE
007685*        MSG: LOC GROUP NOT VALID - CHECK EDIT TYPE 'LCGP'
007685         MOVE WDUPL-KEY-ASMB-LOC-GR
                                      TO WGLOB-MSG-PARM (1)
007685         MOVE 'NS01200098'      TO WGLOB-MSG-REF-INFO
007685         PERFORM  0260-1000-GENERATE-MESSAGE
007685             THRU 0260-1000-GENERATE-MESSAGE-X
007685         SET WS-TO-KEY-NOT-VALID     TO TRUE
007685     END-IF.
007685*
007685 4122-VALIDATE-ASMB-LOC-GROUP-X.
007685     EXIT.
007685*
      *****************************
       4123-VALIDATE-ASMB-EFF-DATE.
      *****************************
      *
      *    EDIT EFFECTIVE DATE
      *
           MOVE WDUPL-KEY-ASMB-EFF-DT TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
           ELSE
      *        MSG: INVALID EFFECTIVE DATE (@1) - USE DDMMMYYYY FORMAT
               MOVE WDUPL-KEY-ASMB-EFF-DT
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4123-VALIDATE-ASMB-EFF-DATE-X.
           EXIT.
      *
      ****************************
       4124-VALIDATE-ASMB-SEQ-NUM.
      ****************************
      *
      * SEQUENCE NUMBER MUST BE NUMERIC.
      *
           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE 3                     TO  L0280-LENGTH.
           MOVE ZERO                  TO  L0280-PRECISION.
           MOVE WDUPL-KEY-ASMB-SEQ-NUM             TO  L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'NS01200012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 4124-VALIDATE-ASMB-SEQ-NUM-X
           END-IF.
      *
       4124-VALIDATE-ASMB-SEQ-NUM-X.
           EXIT.
      *
      *
      *****************************
       4125-VALIDATE-ASMB-REC-TYPE.
      *****************************
      *
      * RECORD TYPE MUST BE VALID.
      *
           MOVE WDUPL-KEY-ASMB-REC-TP TO WEDIT-ETBL-VALU-ID.
           PERFORM  ASMT-1000-EDIT-ASSEMBLY-TYPE
               THRU ASMT-1000-EDIT-ASSEMBLY-TYPE-X.

           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: ASSEMBLY RECORD TYPE MUST BE ON EDIT TYPE 'ASMRT'
               MOVE 'NS01200013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID    TO TRUE
           END-IF.
      *
       4125-VALIDATE-ASMB-REC-TYPE-X.
           EXIT.
      *
      ****************************
       4126-VALIDATE-ASMB-REC-NUM.
      ****************************
      *
      * RECORD NUMBER MUST BE NUMERIC.
      *
           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE 2                     TO  L0280-LENGTH.
           MOVE ZERO                  TO  L0280-PRECISION.
           MOVE WDUPL-KEY-ASMB-REC-NUM             TO  L0280-INPUT-DATA.
           MOVE 2                     TO  L0280-INPUT-SIZE.
           MOVE 'N'                   TO  L0280-SPACE-PERMITTED-IND.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: RECORD NUMBER MUST BE NUMERIC
               MOVE 'NS01200014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 4126-VALIDATE-ASMB-REC-NUM-X
           END-IF.
      *
      *    VALIDATE RECORD NUMBER IS NOT ZERO
      *
012429*    IF WDUPL-KEY-ASMB-REC-NUM = ZERO
012429     IF WDUPL-KEY-ASMB-REC-NUM-N = ZERO
      *        MSG: RECORD NUMBER MUST BE 1 OR GREATER'
               MOVE 'NS01200015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       4126-VALIDATE-ASMB-REC-NUM-X.
           EXIT.
      *
010418***************************
010418 4127-VALIDATE-ASMB-SUB-CO.
010418***************************
010418*
010418* SUB-COMPANY MUST BE ON PROFILE.
010418*
010418     MOVE WDUPL-KEY-ASMB-SBSDRY-CO-ID
                                      TO WSCOM-SBSDRY-CO-ID.
010418     PERFORM  SCOM-1000-READ
010418         THRU SCOM-1000-READ-X.
010418
010418     IF WSCOM-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
010418     ELSE
010418*        MSG: SUB-COMPANY MUST BE ON SUB-COMPANY PROFILE
010418         MOVE 'NS01200100'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         SET WS-TO-KEY-NOT-VALID    TO TRUE
010418     END-IF.
010418*
010418 4127-VALIDATE-ASMB-SUB-CO-X.
010418     EXIT.
010418*
      ***********************
010418*4127-ASMB-CROSS-EDITS.
010418 4128-ASMB-CROSS-EDITS.
      ***********************
      *
      *    CROSS CHECK SEQUENCE NUMBER/RECORD TYPE
      *
           MOVE WDUPL-KEY-ASMB-REC-TP TO WS-RECORD-TYPE.
      *
012429*    IF WDUPL-KEY-ASMB-SEQ-NUM = ZEROS
012429     IF WDUPL-KEY-ASMB-SEQ-NUM-N = ZEROS
               IF FR-OR-CR-RECORD-TYPE
                   CONTINUE
               ELSE
      *            MSG: MISMATCH SEQUENCE NUMBER/RECORD TYPE
                   MOVE WDUPL-KEY-ASMB-REC-TP
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WDUPL-KEY-ASMB-SEQ-NUM
                                      TO WGLOB-MSG-PARM (2)
                   MOVE 'NS01200017'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-TO-KEY-NOT-VALID     TO TRUE
               END-IF
           END-IF.

012429*    IF WDUPL-KEY-ASMB-SEQ-NUM > ZEROS
012429     IF WDUPL-KEY-ASMB-SEQ-NUM-N > ZEROS
               IF FR-OR-CR-RECORD-TYPE
      *            MSG: MISMATCH SEQUENCE NUMBER/RECORD TYPE
                   MOVE WDUPL-KEY-ASMB-REC-TP
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WDUPL-KEY-ASMB-SEQ-NUM
                                      TO WGLOB-MSG-PARM (2)
                   MOVE 'NS01200017'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-TO-KEY-NOT-VALID     TO TRUE
               END-IF
           END-IF.

      **   CROSS CHECK RECORD TYPE AND RECORD NUMBER
           IF TC-RECORD-TYPE
012429*        IF WDUPL-KEY-ASMB-REC-NUM > 1
012429         IF WDUPL-KEY-ASMB-REC-NUM-N > 1
      *            MSG: MISMATCH RECORD NUMBER/RECORD TYPE
                   MOVE WDUPL-KEY-ASMB-REC-TP
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WDUPL-KEY-ASMB-REC-NUM
                                      TO WGLOB-MSG-PARM (2)
                   MOVE 'NS01200017'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-TO-KEY-NOT-VALID     TO TRUE
               END-IF
           END-IF.
      *
010418*4127-ASMB-CROSS-EDITS-X.
010418 4128-ASMB-CROSS-EDITS-X.
           EXIT.
      *
      *
      ******************************
       4140-COMPUTE-ASMB-REC-LENGTH.
      ******************************
      ***************************************************************
      *    COMPUTE RECORD LENGTH:  THIS ROUTINE WILL DETERMINE THE
      *    RECORD LENGTH OF THE RECORD THAT IS TO BE WRITTEN/REWRITTEN
      *    BY THE I/O MODULES.  THIS ROUTINE WILL ACCESS A WORKING
      *    STORAGE TABLE WHICH CONTAINS RECORD LENGTHS FOR ALL THE
      *    RECORD TYPES IN THE ASSEMBLY FILE.
      ***************************************************************

           SET TASMB-TABLE-SUB TO 1.

           SEARCH TASMB-TABLE-OCCURRENCES
               WHEN (TASMB-RECORD-TYPE (TASMB-TABLE-SUB) =
                   WASMB-CASM-REC-TYP-CD)
                   MOVE '1'           TO TASMB-TABLE-VALID
                   MOVE TASMB-TABLE-LENGTH (TASMB-TABLE-SUB)
                                      TO WASMB-REC-LEN
               WHEN (TASMB-RECORD-TYPE (TASMB-TABLE-SUB) = '**')
                   MOVE ZERO          TO TASMB-TABLE-VALID
                   MOVE TASMB-TABLE-LENGTH (TASMB-TABLE-SUB)
                                      TO WASMB-REC-LEN.

           IF TASMB-NOT-VALID
      *        MSG: RECORD LENGTH NOT DEFINED FOR RECORD TYPE (@1)
               MOVE WASMB-CASM-REC-TYP-CD
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4140-COMPUTE-ASMB-REC-LENGTH-X.
           EXIT.
      *
       4200-DUPL-LA.
      *
      *  EDIT FROM KEY
      *  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
      *  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
      *
           MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
           MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-LABT.
           PERFORM  4210-BUILD-LA-KEY
               THRU 4210-BUILD-LA-KEY-X.

           PERFORM  LABT-1000-READ
               THRU LABT-1000-READ-X.
           IF WLABT-IO-NOT-FOUND
      *        MSG: LABT FROM KEY ON LINE (@1) DOES NOT EXIST
               MOVE 'NS01200019'      TO WGLOB-MSG-REF-INFO
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 4200-DUPL-LA-X
           END-IF.
      *
      *  FROM RECORD EXISTS - SAVE RECORD
      *
023118*    MOVE RLABT-REC-INFO        TO WS-LABT-REC-INFO.
023118     MOVE RLABT-REC-INFO        TO HLABT-REC-INFO.
      *
      *  MOVE COMPANY CODE IF USING
      *
           IF WDUPL-COMPANY NOT = SPACES
               MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
           END-IF.
      *
      *  EDIT TO KEY
      *
           MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-LABT.
           PERFORM  4220-VALIDATE-LABT-KEY
               THRU 4220-VALIDATE-LABT-KEY-X.
           IF WS-TO-KEY-NOT-VALID
               GO TO 4200-DUPL-LA-X
           END-IF.

           PERFORM  4210-BUILD-LA-KEY
               THRU 4210-BUILD-LA-KEY-X.
           PERFORM  LABT-1000-READ
               THRU LABT-1000-READ-X.
           IF WLABT-IO-OK
      *        MSG: LABT TO KEY ON LINE (@1) ALREADY EXISTS
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 4200-DUPL-LA-X
           END-IF.
      *
      *  EVERYTHING IS OK - DUPLICATE LABT RECORD
      *
023118*    MOVE WS-LABT-REC-INFO      TO RLABT-REC-INFO.
023118     MOVE HLABT-REC-INFO        TO RLABT-REC-INFO.
           MOVE WDUPL-KEY-ALL         TO RLABT-KEY.
           MOVE WDUPL-KEY-ALL         TO WLABT-KEY.
      *
           PERFORM  LABT-1000-WRITE
               THRU LABT-1000-WRITE-X.
      *
       4200-DUPL-LA-X.
           EXIT.
      *
       4210-BUILD-LA-KEY.
      *
           MOVE WDUPL-KEY-LABT-LAB-CODE
                                      TO WLABT-LAB-ID.
           MOVE WDUPL-KEY-LABT-TEST-NO                 TO WLABT-LTST-ID.
           MOVE WDUPL-KEY-LABT-HIGH-AGE
                                      TO WLABT-LTST-STD-AGE-QTY.
           IF WDUPL-KEY-LABT-SEX = SPACES
               MOVE HIGH-VALUES       TO WLABT-LTST-STD-SEX-CD
               MOVE WLABT-KEY         TO WDUPL-KEY-ALL
           ELSE
               MOVE WDUPL-KEY-LABT-SEX          TO WLABT-LTST-STD-SEX-CD
               MOVE WLABT-KEY         TO WDUPL-KEY-ALL
           END-IF.
      *
       4210-BUILD-LA-KEY-X.
           EXIT.
      *
       4220-VALIDATE-LABT-KEY.
      *
      *    EDIT LABT KEY FIELDS
      *
           PERFORM  4221-VALIDATE-LABT-LAB-CODE
               THRU 4221-VALIDATE-LABT-LAB-CODE-X.
           PERFORM  4222-VALIDATE-LABT-TEST-NO
               THRU 4222-VALIDATE-LABT-TEST-NO-X.
           PERFORM  4223-VALIDATE-LABT-HIGH-AGE
               THRU 4223-VALIDATE-LABT-HIGH-AGE-X.
           PERFORM  4224-VALIDATE-LABT-SEX
               THRU 4224-VALIDATE-LABT-SEX-X.
      *
       4220-VALIDATE-LABT-KEY-X.
           EXIT.
      /
      ****************************
       4221-VALIDATE-LABT-LAB-CODE.
      ****************************
      *
      *    VERIFY LAB CODE IS ON EDIT/LABCD.
      *
           MOVE WDUPL-KEY-LABT-LAB-CODE
                                      TO   WEDIT-ETBL-VALU-ID.
           PERFORM LABC-1000-EDIT-LAB-CODE
              THRU LABC-1000-EDIT-LAB-CODE-X.
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: TO-KEY LAB MUST BE IN EDIT TYPE 'LABCD'
               MOVE 'NS01200021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       4221-VALIDATE-LABT-LAB-CODE-X.
           EXIT.
      *
      ****************************
       4222-VALIDATE-LABT-TEST-NO.
      ****************************
      *
      *    VERIFY TEST NUMBER IS ON EDIT/TSTNO.
      *
           MOVE WDUPL-KEY-LABT-TEST-NO            TO WEDIT-ETBL-VALU-ID.
           PERFORM TSTN-1000-EDIT-TEST-NUMBER
              THRU TSTN-1000-EDIT-TEST-NUMBER-X.
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: TO-KEY TEST NUMBER MUST BE IN EDIT TYPE 'TSTNO'
               MOVE 'NS01200022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       4222-VALIDATE-LABT-TEST-NO-X.
           EXIT.
      *
      ****************************
       4223-VALIDATE-LABT-HIGH-AGE.
      ****************************
      *
      *    VERIFY HIGH AGE IS NUMERIC.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 3                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 'N'                   TO L0280-SPACE-PERMITTED-IND.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE WDUPL-KEY-LABT-HIGH-AGE
                                      TO L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: TO-KEY AGE MUST BE NUMERIC
               MOVE 'NS01200023'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID  TO TRUE
           END-IF.
      *
       4223-VALIDATE-LABT-HIGH-AGE-X.
           EXIT.
      *
      ************************
       4224-VALIDATE-LABT-SEX.
      ************************
      *
      *    VERIFY SEX VALUES ARE BLANK, M OR F.
      *

           MOVE WDUPL-KEY-LABT-SEX    TO WS-EDIT-SEX.
           IF WS-VALID-LABT-SEX
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: TO-KEY SEX VALUES MUST M, F, OR BLANK
               MOVE 'NS01200024'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       4224-VALIDATE-LABT-SEX-X.
           EXIT.
      /
023447*
023447*4230-DUPL-PFLN.
023447*
023447*    IF WPFLY-PG-FRMT-LN-TXT (WPFLY-SUB) = SPACES
023447*        GO TO 4230-DUPL-PFLN-X
023447*    END-IF.
023447*
023447*    MOVE WPFLY-PG-FRMT-LN-NUM (WPFLY-SUB)
023447*                               TO WPFLN-PG-FRMT-LN-NUM.
023447*    MOVE WPFLN-KEY             TO RPFLN-KEY.
023447*    MOVE WPFLY-PG-FRMT-LN-TXT (WPFLY-SUB)
023447*                               TO RPFLN-PG-FRMT-LN-TXT.
023447*
023447*    PERFORM  PFLN-1000-WRITE
023447*        THRU PFLN-1000-WRITE-X.
023447*
023447*4230-DUPL-PFLN-X.
023447*    EXIT.
      /
035251*4300-DUPL-MD.
035251*
035251*  EDIT FROM KEY
035251*  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
035251*  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
035251*
035251*    MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
035251*    MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
035251*                               TO WDUPL-KEY-MD.
035251*    PERFORM  4310-BUILD-MD-KEY
035251*        THRU 4310-BUILD-MD-KEY-X.
035251*
035251*    PERFORM  MD-1000-READ
035251*        THRU MD-1000-READ-X.
035251*    IF WMD-IO-NOT-FOUND
035251*        MSG: MD FROM KEY ON LINE (@1) DOES NOT EXIST
035251*        MOVE 'NS01200025'      TO WGLOB-MSG-REF-INFO
035251*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
035251*        PERFORM  0260-1000-GENERATE-MESSAGE
035251*            THRU 0260-1000-GENERATE-MESSAGE-X
035251*        SET WS-FROM-KEY-NOT-VALID TO TRUE
035251*        GO TO 4300-DUPL-MD-X
035251*    END-IF.
035251*
035251*  FROM RECORD EXISTS - SAVE RECORD
035251*
023118*    MOVE RMD-REC-INFO          TO WS-MD-REC-INFO.
035251*    MOVE RMD-REC-INFO          TO HMD-REC-INFO.
035251*
035251*  MOVE COMPANY CODE IF USING
035251*
035251*    IF WDUPL-COMPANY NOT = SPACES
035251*        MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
035251*    END-IF.
035251*
035251*  EDIT TO KEY
035251*
035251*    MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
035251*                               TO WDUPL-KEY-MD.
035251*    PERFORM  4320-VALIDATE-MD-KEY
035251*        THRU 4320-VALIDATE-MD-KEY-X.
035251*    IF WS-TO-KEY-NOT-VALID
035251*        GO TO 4300-DUPL-MD-X
035251*    END-IF.
035251*
035251*    PERFORM  4310-BUILD-MD-KEY
035251*        THRU 4310-BUILD-MD-KEY-X.
035251*    PERFORM  MD-1000-READ
035251*        THRU MD-1000-READ-X.
035251*    IF WMD-IO-OK
035251*        MSG: MD TO KEY ON LINE (@1) ALREADY EXISTS
035251*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
035251*        MOVE 'NS01200026'      TO WGLOB-MSG-REF-INFO
035251*        PERFORM  0260-1000-GENERATE-MESSAGE
035251*            THRU 0260-1000-GENERATE-MESSAGE-X
035251*        SET WS-TO-KEY-NOT-VALID TO TRUE
035251*        GO TO 4300-DUPL-MD-X
035251*    END-IF.
035251*
035251*  EVERYTHING IS OK - DUPLICATE MD RECORD
035251*
023118*    MOVE WS-MD-REC-INFO        TO RMD-REC-INFO.
035251*    MOVE HMD-REC-INFO          TO RMD-REC-INFO.
035251*    MOVE WDUPL-KEY-ALL         TO RMD-KEY.
035251*    MOVE WDUPL-KEY-ALL         TO WMD-KEY.
035251*
035251*    PERFORM  MD-1000-WRITE
035251*        THRU MD-1000-WRITE-X.
035251*
035251*4300-DUPL-MD-X.
035251*    EXIT.
035251*
035251*4310-BUILD-MD-KEY.
035251*
035251*    MOVE WDUPL-KEY-MD-TABLE    TO WMD-MXDX-ID.
016476*    MOVE WDUPL-KEY-MD-AGE      TO WMD-MXDX-AGE-N.
035251*    MOVE WDUPL-KEY-MD-AGE      TO WMD-MXDX-AGE.
035251*    MOVE WMD-KEY               TO WDUPL-KEY-ALL.
035251*
035251*4310-BUILD-MD-KEY-X.
035251*    EXIT.
035251*
035251*4320-VALIDATE-MD-KEY.
035251*
035251* AGE MUST BE NUMERIC.
035251*
035251*    MOVE 'N'                   TO L0280-SIGN-IND.
035251*    MOVE 3                     TO L0280-LENGTH.
035251*    MOVE ZERO                  TO L0280-PRECISION.
035251*    MOVE WDUPL-KEY-MD-AGE      TO L0280-INPUT-DATA.
035251*    PERFORM 0280-1000-NUMERIC-EDIT
035251*       THRU 0280-1000-NUMERIC-EDIT-X.
035251*
035251*    IF L0280-OK
035251*    AND WDUPL-KEY-MD-AGE IS NUMERIC
034802*        NEXT SENTENCE
035251*        CONTINUE
035251*    ELSE
035251*        MSG: AGE MUST BE NUMERIC
035251*        MOVE 'NS01200027'      TO WGLOB-MSG-REF-INFO
035251*        PERFORM  0260-1000-GENERATE-MESSAGE
035251*            THRU 0260-1000-GENERATE-MESSAGE-X
035251*        SET WS-TO-KEY-NOT-VALID TO TRUE
035251*        GO TO 4320-VALIDATE-MD-KEY-X
035251*    END-IF.
035251*
035251* AGE MUST BE BETWEEN 000 AND 120. RE-ENTER.
035251*
035251*    IF WDUPL-KEY-MD-AGE-N < ZERO
035251*    OR WDUPL-KEY-MD-AGE-N > 120
035251*        MSG: AGE MUST BE BETWEEN 000 AND 120
035251*        MOVE 'NS01200028'      TO WGLOB-MSG-REF-INFO
035251*        PERFORM  0260-1000-GENERATE-MESSAGE
035251*            THRU 0260-1000-GENERATE-MESSAGE-X
035251*        SET WS-TO-KEY-NOT-VALID TO TRUE
035251*    END-IF.
035251*
035251*4320-VALIDATE-MD-KEY-X.
035251*    EXIT.
      *
       4400-DUPL-MS.
      *
      *  EDIT FROM KEY
      *  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
      *  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
      *
           MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
           MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-MS.
           PERFORM  4410-BUILD-MS-KEY
               THRU 4410-BUILD-MS-KEY-X.

           PERFORM  MSGS-1000-READ
               THRU MSGS-1000-READ-X.
           IF WMSGS-IO-NOT-FOUND
      *        MSG: MSGS FROM KEY ON LINE (@1) DOES NOT EXIST
               MOVE 'NS01200029'      TO WGLOB-MSG-REF-INFO
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 4400-DUPL-MS-X
           END-IF.
      *
      *  FROM RECORD EXISTS - SAVE RECORD
      *
023480*    MOVE RMSGS-REC-INFO        TO WS-MSGS-REC-INFO.
023480     MOVE RMSGS-REC-INFO        TO HMSGS-REC-INFO.
      *
      *  MOVE COMPANY CODE IF USING
      *
           IF WDUPL-COMPANY NOT = SPACES
               MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
           END-IF.
      *
      *  EDIT TO KEY
      *
           MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-MS.
           PERFORM  4420-VALIDATE-MS-KEY
               THRU 4420-VALIDATE-MS-KEY-X.
           IF WS-TO-KEY-NOT-VALID
               GO TO 4400-DUPL-MS-X
           END-IF.

           PERFORM  4410-BUILD-MS-KEY
               THRU 4410-BUILD-MS-KEY-X.
           PERFORM  MSGS-1000-READ
               THRU MSGS-1000-READ-X.
           IF WMSGS-IO-OK
      *        MSG: MSGS TO KEY ON LINE (@1) ALREADY EXISTS
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 4400-DUPL-MS-X
           END-IF.
      *
      *  EVERYTHING IS OK - DUPLICATE MSGS RECORD
      *
023480*    MOVE WS-MSGS-REC-INFO      TO RMSGS-REC-INFO.
023480     MOVE HMSGS-REC-INFO        TO RMSGS-REC-INFO.
           MOVE WDUPL-KEY-ALL         TO RMSGS-KEY.
           MOVE WDUPL-KEY-ALL         TO WMSGS-KEY.
      *
           PERFORM  MSGS-1000-WRITE
               THRU MSGS-1000-WRITE-X.
      *
       4400-DUPL-MS-X.
           EXIT.
      *
       4410-BUILD-MS-KEY.
      *
           MOVE WDUPL-KEY-MS-SOURCE   TO WMSGS-MSG-REF-ID.
           MOVE WDUPL-KEY-MS-MSGNO    TO WMSGS-MSG-REF-NUM.
           MOVE WDUPL-KEY-MS-LANG     TO WMSGS-MSG-LANG-CD.
           MOVE WDUPL-KEY-MS-USER-CLASS
                                      TO WMSGS-MSG-SECUR-CLAS-CD.
           MOVE WDUPL-KEY-ALL         TO RMSGS-KEY.
      *
       4410-BUILD-MS-KEY-X.
           EXIT.
      *
       4420-VALIDATE-MS-KEY.
      *
557660     IF  WDUPL-KEY-MS-TYPE = 'S'
557660     OR  WDUPL-KEY-MS-TYPE = 'C'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: TO-KEY TYPE MUST BE S OR C
               MOVE 'NS01200036'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 4420-VALIDATE-MS-KEY-X
           END-IF.
      *
      * PERFORM NUMERIC EDIT ON THE MESSAGE NUMBER
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-LENGTH.
           MOVE WDUPL-KEY-MS-MSGNO    TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               CONTINUE
           ELSE
      *        MSG: TO-KEY MESSAGE NUMBER MUST BE NUMERIC
               MOVE 'NS01200031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
      *  VALIDATE USER LANGUAGE
      *
           MOVE WDUPL-KEY-MS-LANG     TO WXTAB-ETBL-VALU-ID.
           PERFORM  LANG-1000-EDIT-USER-LANGUAGE
               THRU LANG-1000-EDIT-USER-LANGUAGE-X.
           IF WXTAB-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: INVALID LANGUAGE CODE - CHECK XTAB TYPE 'LANG'
               MOVE 'NS01200032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       4420-VALIDATE-MS-KEY-X.
           EXIT.
      /
007685*4500-DUPL-PA.
007685*
007685*  EDIT FROM KEY
007685*  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
007685*  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
007685*
007685*    MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
007685*    MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE) TO WDUPL-KEY-PA.
007685*    PERFORM  4510-BUILD-PA-KEY
007685*        THRU 4510-BUILD-PA-KEY-X.
007685*
007685*    PERFORM  PA-1000-READ
007685*        THRU PA-1000-READ-X.
007685*    IF WPA-IO-NOT-FOUND
007685*        MSG: PA FROM KEY ON LINE (@1) DOES NOT EXIST
007685*        MOVE 'NS01200033'         TO WGLOB-MSG-REF-INFO
007685*        MOVE WS-LINE              TO WGLOB-MSG-PARM (1)
007685*        PERFORM  0260-1000-GENERATE-MESSAGE
007685*            THRU 0260-1000-GENERATE-MESSAGE-X
007685*        SET WS-FROM-KEY-NOT-VALID TO TRUE
007685*        GO TO 4500-DUPL-PA-X
007685*    END-IF.
007685*
007685*  FROM RECORD EXISTS - SAVE RECORD
007685*
007685*    MOVE RPA-REC-INFO TO WS-PA-REC-INFO.
007685*
007685*  MOVE COMPANY CODE IF USING
007685*
007685*    IF WDUPL-COMPANY NOT = SPACES
007685*        MOVE WDUPL-COMPANY TO WGLOB-COMPANY-CODE
007685*    END-IF.
007685*
007685*  EDIT TO KEY
007685*
007685*    MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)  TO WDUPL-KEY-PA.
007685*    PERFORM  4520-VALIDATE-PA-KEY
007685*        THRU 4520-VALIDATE-PA-KEY-X.
007685*    IF WS-TO-KEY-NOT-VALID
007685*        GO TO 4500-DUPL-PA-X
007685*    END-IF.
007685*
007685*    PERFORM  4510-BUILD-PA-KEY
007685*        THRU 4510-BUILD-PA-KEY-X.
007685*    PERFORM  PA-1000-READ
007685*        THRU PA-1000-READ-X.
007685*    IF WPA-IO-OK
007685*        MSG: PA TO KEY ON LINE (@1) ALREADY EXISTS
007685*        MOVE WS-LINE            TO WGLOB-MSG-PARM (1)
007685*        MOVE 'NS01200034'       TO WGLOB-MSG-REF-INFO
007685*        PERFORM  0260-1000-GENERATE-MESSAGE
007685*            THRU 0260-1000-GENERATE-MESSAGE-X
007685*        SET WS-TO-KEY-NOT-VALID TO TRUE
007685*        GO TO 4500-DUPL-PA-X
007685*    END-IF.
007685*
007685*  EVERYTHING IS OK - DUPLICATE MSGS RECORD
007685*
007685*    MOVE WS-PA-REC-INFO   TO RPA-REC-INFO.
007685*    MOVE WDUPL-KEY-ALL    TO RPA-KEY.
007685*    MOVE WDUPL-KEY-ALL    TO WPA-KEY.
007685*
007685*    PERFORM  PA-1000-WRITE
007685*        THRU PA-1000-WRITE-X.
007685*
007685*4500-DUPL-PA-X.
007685*    EXIT.
007685*
007685*4510-BUILD-PA-KEY.
007685*
007685*    MOVE WDUPL-KEY-PA-CODE    TO WPA-PASM-ID-PLAN.
007685*    MOVE WDUPL-KEY-PA-SCALE   TO WPA-PASM-ID-RS.
007685*    MOVE WDUPL-KEY-PA-LANG    TO WPA-PASM-LANG-CD.
007685*    MOVE WDUPL-KEY-PA-ILOC    TO WPA-PASM-ISS-LOC-CD.
007685*    MOVE WPA-KEY              TO WDUPL-KEY-ALL.
007685*    MOVE WDUPL-KEY-ALL        TO RPA-KEY.
007685*
007685*4510-BUILD-PA-KEY-X.
007685*    EXIT.
007685*
007685*4520-VALIDATE-PA-KEY.
007685*
007685*  PASM PLAN CODE CANNOT BE SPACES
007685*
007685*    IF WDUPL-KEY-PA-CODE = SPACES
007685*        MSG: PLAN CODE CANNOT BE SPACES
007685*        MOVE 'NS01200035'       TO WGLOB-MSG-REF-INFO
007685*        PERFORM  0260-1000-GENERATE-MESSAGE
007685*            THRU 0260-1000-GENERATE-MESSAGE-X
007685*        SET WS-TO-KEY-NOT-VALID TO TRUE
007685*    END-IF.
007685*
007685*    MOVE SPACES             TO WEDIT-ETBL-VALU-ID.
007685*    MOVE WDUPL-KEY-PA-LANG  TO WEDIT-ETBL-VALU-ID.
007685*    PERFORM  LANG-1000-EDIT
007685*        THRU LANG-1000-EDIT-X.
007685*    IF NOT WEDIT-IO-OK
007685*        MSG: LANGUAGE CODE NOT VALID - CHECK EDIT TYPE 'LANG'
007685*        MOVE 'NS01200037'       TO WGLOB-MSG-REF-INFO
007685*        PERFORM  0260-1000-GENERATE-MESSAGE
007685*            THRU 0260-1000-GENERATE-MESSAGE-X
007685*        SET WS-TO-KEY-NOT-VALID TO TRUE
007685*    END-IF.
007685*
007685*    MOVE SPACES                 TO WEDIT-ETBL-VALU-ID.
007685*    IF WDUPL-KEY-PF-ILOC = WS-GENERIC-LOC
007685*        CONTINUE
007685*    ELSE
007685*      MOVE WDUPL-KEY-PA-ILOC      TO WEDIT-ETBL-VALU-ID
007685*      PERFORM  ILOC-1000-EDIT-ISSU-LOCATION
007685*          THRU ILOC-1000-EDIT-ISSU-LOCATION-X
007685*      IF NOT WEDIT-IO-OK
007685*          MSG: ISSUE LOCATION NOT VALID - CHECK EDIT TYPE 'ILOC'
007685*          MOVE 'CS08811014'       TO WGLOB-MSG-REF-INFO
007685*          PERFORM  0260-1000-GENERATE-MESSAGE
007685*              THRU 0260-1000-GENERATE-MESSAGE-X
007685*          SET WS-TO-KEY-NOT-VALID TO TRUE
007685*      END-IF
007685*    END-IF.
007685*
007685*4520-VALIDATE-PA-KEY-X.
007685*    EXIT.
023447*
023447*4600-DUPL-PF.
023447*
023447*  EDIT FROM KEY
023447*  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
023447*  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
023447*
023447*    MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
023447*    MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
023447*                               TO WDUPL-KEY-PF.
023447*    PERFORM  4610-BUILD-PF-KEY
023447*        THRU 4610-BUILD-PF-KEY-X.
023447*
023447*    PERFORM  PF-1000-READ
023447*        THRU PF-1000-READ-X.
023447*    IF WPF-IO-NOT-FOUND
023447*        MSG: PF FROM KEY ON LINE (@1) DOES NOT EXIST
023447*        MOVE 'NS01200038'      TO WGLOB-MSG-REF-INFO
023447*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-FROM-KEY-NOT-VALID TO TRUE
023447*        GO TO 4600-DUPL-PF-X
023447*    END-IF.
023447*
023447*    PERFORM  PFLY-1000-BUILD-ARRAY
023447*        THRU PFLY-1000-BUILD-ARRAY-X.
023447*
023447*  FROM RECORD EXISTS - SAVE RECORD
023447*
023447*    MOVE RPF-REC-INFO          TO WS-PF-REC-INFO.
023447*
023447*  MOVE COMPANY CODE IF USING
023447*
023447*    IF WDUPL-COMPANY NOT = SPACES
023447*        MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
023447*    END-IF.
023447*
023447*  EDIT TO KEY
023447*
023447*    MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
023447*                               TO WDUPL-KEY-PF.
023447*    PERFORM  4620-VALIDATE-PF-KEY
023447*        THRU 4620-VALIDATE-PF-KEY-X.
023447*    IF WS-TO-KEY-NOT-VALID
023447*        GO TO 4600-DUPL-PF-X
023447*    END-IF.
023447*
023447*    PERFORM  4610-BUILD-PF-KEY
023447*        THRU 4610-BUILD-PF-KEY-X.
023447*    PERFORM  PF-1000-READ
023447*        THRU PF-1000-READ-X.
023447*    IF WPF-IO-OK
023447*        MSG: PF TO KEY ON LINE (@1) ALREADY EXISTS
023447*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
023447*        MOVE 'NS01200039'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*        GO TO 4600-DUPL-PF-X
023447*    END-IF.
023447*
023447*  EVERYTHING IS OK - DUPLICATE PF RECORD
023447*
023118*    MOVE WS-PF-REC-INFO        TO RPF-REC-INFO.
023118*    MOVE HPF-REC-INFO          TO RPF-REC-INFO.
023447*    MOVE WDUPL-KEY-ALL         TO RPF-KEY.
023447*    MOVE WDUPL-KEY-ALL         TO WPF-KEY.
023447*
023447*    PERFORM  PF-1000-WRITE
023447*        THRU PF-1000-WRITE-X.
023447*
023447*    MOVE WPF-KEY               TO WPFLN-KEY.
023447*    PERFORM  4230-DUPL-PFLN
023447*        THRU 4230-DUPL-PFLN-X
023447*        VARYING WPFLY-SUB FROM 1 BY 1
023447*        UNTIL WPFLY-SUB > WPFLY-MAX-SUB.
023447*
023447*4600-DUPL-PF-X.
023447*    EXIT.
023447*
023447*4610-BUILD-PF-KEY.
023447*
007685*    MOVE WDUPL-KEY-PF-FORMAT  TO WPF-PG-FRMT-ID.
007685*    MOVE WDUPL-KEY-PF-DOC-ID  TO WPF-PG-FRMT-DOC-ID.
023447*    MOVE WDUPL-KEY-PF-DOC-ID   TO WPF-DOC-ID.
023447*    MOVE WDUPL-KEY-PF-SBSDRY-CO-ID
023447*                               TO WPF-SBSDRY-CO-ID.
007685*    MOVE WDUPL-KEY-PF-LANG    TO WPF-PG-FRMT-LANG-CD.
023447*    MOVE WDUPL-KEY-PF-LANG     TO WPF-DOC-LANG-CD.
007685*    MOVE WDUPL-KEY-PF-ILOC    TO WPF-PG-FRMT-ISS-LOC-CD.
007685*    MOVE WDUPL-KEY-PF-LOC-GR  TO WPF-PG-FRMT-LOC-GR-CD.
023447*    MOVE WDUPL-KEY-PF-LOC-GR   TO WPF-LOC-GR-ID.
023447*    MOVE WPF-KEY               TO WDUPL-KEY-ALL.
023447*    MOVE WDUPL-KEY-ALL         TO RPF-KEY.
023447*
023447*4610-BUILD-PF-KEY-X.
023447*    EXIT.
023447*
023447*4620-VALIDATE-PF-KEY.
023447*
007685*    MOVE SPACES              TO WEDIT-ETBL-VALU-ID.
007685*    PERFORM  FRMT-1000-EDIT
007685*        THRU FRMT-1000-EDIT-X.
007685*    IF NOT WEDIT-IO-OK
007685*        MSG: DOCUMENT NOT VALID - CHECK EDIT TYPE 'DOCM'
007685*        MOVE 'NS01200040'       TO WGLOB-MSG-REF-INFO
007685*        PERFORM  0260-1000-GENERATE-MESSAGE
007685*            THRU 0260-1000-GENERATE-MESSAGE-X
007685*        SET WS-TO-KEY-NOT-VALID TO TRUE
007685*    END-IF.
023447*
023447*    MOVE WDUPL-KEY-PF-SBSDRY-CO-ID
023447*                               TO WSCOM-SBSDRY-CO-ID.
023447*    PERFORM  SCOM-1000-READ
023447*        THRU SCOM-1000-READ-X.
023447*    IF NOT WSCOM-IO-OK
010418*        MSG: SUB-COMPANY MUST BE ON SUB-COMPANY PROFILE'
023447*        MOVE 'NS01200101'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*    END-IF.
010418*
023447*    MOVE SPACES                TO WEDIT-ETBL-VALU-ID.
023447*    MOVE WDUPL-KEY-PF-LANG     TO WEDIT-ETBL-VALU-ID.
023447*    PERFORM  LANG-1000-EDIT
023447*        THRU LANG-1000-EDIT-X.
023447*    IF NOT WEDIT-IO-OK
023447*        MSG: LANGUAGE CODE NOT VALID - CHECK EDIT TYPE 'LANG'
023447*        MOVE 'NS01200037'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*    END-IF.
023447*
007685*    IF WDUPL-KEY-PF-ILOC = WS-GENERIC-LOC
023447*    IF WDUPL-KEY-PF-LOC-GR = WS-LOC-GROUP
023447*        CONTINUE
023447*    ELSE
023447*        MOVE SPACES            TO WEDIT-ETBL-VALU-ID
007685*        MOVE WDUPL-KEY-PF-ILOC  TO WEDIT-ETBL-VALU-ID
007685*        PERFORM  ILOC-1000-EDIT-ISSU-LOCATION
007685*            THRU ILOC-1000-EDIT-ISSU-LOCATION-X
023447*        MOVE WDUPL-KEY-PF-LOC-GR
023447*                               TO WEDIT-ETBL-VALU-ID
023447*        PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
023447*            THRU LCGP-1000-EDIT-LCGP-LOCATION-X
023447*        IF NOT WEDIT-IO-OK
007685*            MSG: ISS LOC NOT VALID - CHECK EDIT TYPE 'ILOC'
007685*            MOVE 'NS01200041'       TO WGLOB-MSG-REF-INFO
007685*            MSG: LOC GROUP NOT VALID - CHECK EDIT TYPE 'LCGP'
023447*            MOVE 'NS01200041'  TO WGLOB-MSG-REF-INFO
023447*            PERFORM  0260-1000-GENERATE-MESSAGE
023447*                THRU 0260-1000-GENERATE-MESSAGE-X
023447*            SET WS-TO-KEY-NOT-VALID TO TRUE
023447*        END-IF
023447*    END-IF.
007685*
007685*  VERIFY DOCUMENT NAME FROM TABLE DOCM
007685*
007685*    MOVE WDUPL-KEY-PF-DOC-ID   TO WDOCM-DOC-ID.
023447*    MOVE WDUPL-KEY-PF-LANG     TO WDOCM-DOC-LANG-CD.
023447*    PERFORM  DOCM-1000-READ
023447*        THRU DOCM-1000-READ-X.
023447*    IF NOT WDOCM-IO-OK
007685*        MSG: DOCUMENT NAME ON LINE (@1) DOES NOT EXIST
023447*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
023447*        MOVE 'NS01200105'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*    END-IF.
023447*
023447*
023447*4620-VALIDATE-PF-KEY-X.
023447*    EXIT.
      /
       4700-DUPL-PL.
      *
      *  EDIT FROM KEY
      *  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
      *  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
      *
           MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
           MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-PH.
           PERFORM  4710-BUILD-PL-KEY
               THRU 4710-BUILD-PL-KEY-X.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.
           IF WPH-IO-NOT-FOUND
      *        MSG: PLAN FROM KEY ON LINE (@1) DOES NOT EXIST
               MOVE 'NS01200042'      TO WGLOB-MSG-REF-INFO
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 4700-DUPL-PL-X
           END-IF.
      *
           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.
           IF WPD-IO-NOT-FOUND
      *        MSG: PLAN DEFAULT FOR KEY ON LINE (@1) DOES NOT EXIST
               MOVE 'NS01200086'      TO WGLOB-MSG-REF-INFO
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 4700-DUPL-PL-X
           END-IF.
      *
      *  FROM RECORD EXISTS - SAVE RECORD
      *
023118*    MOVE RPH-REC-INFO          TO WS-PL-REC-INFO.
023118*    MOVE RPD-REC-INFO          TO WS-PD-REC-INFO.
023118     MOVE RPH-REC-INFO          TO HPH-REC-INFO.
023118     MOVE RPD-REC-INFO          TO HPD-REC-INFO.
      *
      *  MOVE COMPANY CODE IF USING
      *
           IF WDUPL-COMPANY NOT = SPACES
               MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
           END-IF.
      *
      *  EDIT TO KEY
      *
           MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-PH.
           PERFORM  4720-VALIDATE-PL-KEY
               THRU 4720-VALIDATE-PL-KEY-X.
           IF WS-TO-KEY-NOT-VALID
               GO TO 4700-DUPL-PL-X
           END-IF.

           PERFORM  4710-BUILD-PL-KEY
               THRU 4710-BUILD-PL-KEY-X.
           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.
           IF WPH-IO-OK
      *        MSG: PLAN TO KEY ON LINE (@1) ALREADY EXISTS
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200043'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 4700-DUPL-PL-X
           END-IF.
      *
      *  EVERYTHING IS OK - DUPLICATE PLAN RECORD
      *
023118*    MOVE WS-PL-REC-INFO        TO RPH-REC-INFO.
023118*    MOVE WS-PD-REC-INFO        TO RPD-REC-INFO.
023118     MOVE HPH-REC-INFO          TO RPH-REC-INFO.
023118     MOVE HPD-REC-INFO          TO RPD-REC-INFO.
           MOVE WDUPL-KEY-ALL         TO WPH-KEY.
           MOVE WDUPL-KEY-ALL         TO WPD-KEY.
           PERFORM  PH-1000-WRITE
               THRU PH-1000-WRITE-X.
           PERFORM  PD-1000-WRITE
               THRU PD-1000-WRITE-X.
010302
010302     PERFORM  4730-DUPLICATE-PLAN-RATE
010302         THRU 4730-DUPLICATE-PLAN-RATE-X.
010650
010650     PERFORM  4740-DUPLICATE-PLAN-VARI
010650         THRU 4740-DUPLICATE-PLAN-VARI-X.
010648
010648     PERFORM  4750-DUPLICATE-PLAN-DIVOP
010648         THRU 4750-DUPLICATE-PLAN-DIVOP-X.
010649
010649     PERFORM  4760-DUPL-BILL-TYPE-MODE
010649         THRU 4760-DUPL-BILL-TYPE-MODE-X.
010304
010304     PERFORM  4770-DUPLICATE-PLAN-NFO-OPT
010304         THRU 4770-DUPLICATE-PLAN-NFO-OPT-X.

015290     PERFORM  4780-DUPL-PLAN-ALLOC-TYP
015290         THRU 4780-DUPL-PLAN-ALLOC-TYP-X.
020475
020475     PERFORM  4790-DUPL-PLAN-DBG
020475         THRU 4790-DUPL-PLAN-DBG-X.
020467
020467     PERFORM  4800-DUPL-PLAN-MODE
020467         THRU 4800-DUPL-PLAN-MODE-X.
      *
021691     PERFORM  4810-DUPL-PLAN-CALC-EXIT
021691         THRU 4810-DUPL-PLAN-CALC-EXIT-X.

      *
       4700-DUPL-PL-X.
           EXIT.
      *
       4710-BUILD-PL-KEY.
      *
014591*    MOVE WDUPL-KEY-PH-CODE     TO WPH-PLAN-ID-BASE.
014591*    MOVE WDUPL-KEY-PH-SCALE    TO WPH-PLAN-ID-RS.
014591     MOVE WDUPL-KEY-PH-PLAN-ID  TO WPH-PLAN-ID.
           MOVE WPH-KEY               TO WDUPL-KEY-ALL.
           MOVE WDUPL-KEY-ALL         TO RPH-KEY.
           MOVE WDUPL-KEY-ALL         TO WPD-KEY.
           MOVE WDUPL-KEY-ALL         TO RPD-KEY.
      *
       4710-BUILD-PL-KEY-X.
           EXIT.
      *
       4720-VALIDATE-PL-KEY.
      *
014591*    IF (WDUPL-KEY-PH-CODE NOT > SPACES)
014591     IF (WDUPL-KEY-PH-PLAN-ID NOT > SPACES)
      *        MSG: PLAN/RS MUST BE ENTERED
               MOVE 'NS01200045'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       4720-VALIDATE-PL-KEY-X.
           EXIT.
      *
010302 4730-DUPLICATE-PLAN-RATE.
010302*
010302     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPLRT-PLAN-ID.
010302     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPLRT-ENDBR-PLAN-ID.
010302*    MOVE LOW-VALUES                  TO WPLRT-PLAN-RATE-ID.
010302     MOVE LOW-VALUES            TO WPLRT-PLAN-RT-TYP-CD.
010302*    MOVE HIGH-VALUES                 TO WPLRT-ENDBR-PLAN-RATE-ID.
010302     MOVE HIGH-VALUES           TO
010302                                       WPLRT-ENDBR-PLAN-RT-TYP-CD.
010302
010302     PERFORM  PLRT-1000-BROWSE
010302         THRU PLRT-1000-BROWSE-X.
010302
010302     PERFORM  PLRT-2000-READ-NEXT
010302         THRU PLRT-2000-READ-NEXT-X.
010302
010302     PERFORM
010302        UNTIL NOT WPLRT-IO-OK
010302        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WPLRT-PLAN-ID
010302        PERFORM  PLRT-1000-WRITE
010302            THRU PLRT-1000-WRITE-X
010302        PERFORM  PLRT-2000-READ-NEXT
010302            THRU PLRT-2000-READ-NEXT-X
010302     END-PERFORM.
010302
010302     PERFORM  PLRT-3000-END-BROWSE
010302         THRU PLRT-3000-END-BROWSE-X.
010302*
010302 4730-DUPLICATE-PLAN-RATE-X.
010302     EXIT.
010650*
010650 4740-DUPLICATE-PLAN-VARI.
010650*
010650     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPLGR-PLAN-ID.
010650     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPLGR-ENDBR-PLAN-ID.
010650     MOVE LOW-VALUES            TO WPLGR-LOC-GR-ID.
010650     MOVE HIGH-VALUES           TO WPLGR-ENDBR-LOC-GR-ID.
010650
010650     PERFORM  PLGR-1000-BROWSE
010650         THRU PLGR-1000-BROWSE-X.
010650
010650     PERFORM  PLGR-2000-READ-NEXT
010650         THRU PLGR-2000-READ-NEXT-X.
010650
010650     PERFORM
010650        UNTIL NOT WPLGR-IO-OK
010650        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WPLGR-PLAN-ID
010650        PERFORM  PLGR-1000-WRITE
010650            THRU PLGR-1000-WRITE-X
010650        PERFORM  PLGR-2000-READ-NEXT
010650            THRU PLGR-2000-READ-NEXT-X
010650     END-PERFORM.
010650
010650     PERFORM  PLGR-3000-END-BROWSE
010650         THRU PLGR-3000-END-BROWSE-X.
010650
010650 4740-DUPLICATE-PLAN-VARI-X.
010650     EXIT.
010648*
010648 4750-DUPLICATE-PLAN-DIVOP.
010648*
010648     MOVE LOW-VALUES            TO WPDIV-KEY.
010648     MOVE HIGH-VALUES           TO WPDIV-ENDBR-KEY.
010648     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPDIV-PLAN-ID.
010648     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPDIV-ENDBR-PLAN-ID.
010648
010648     PERFORM  PDIV-1000-BROWSE
010648         THRU PDIV-1000-BROWSE-X.
010648
010648     PERFORM  PDIV-2000-READ-NEXT
010648         THRU PDIV-2000-READ-NEXT-X.
010648
010648     PERFORM
010648        UNTIL NOT WPDIV-IO-OK
010648        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WPDIV-PLAN-ID
010648        PERFORM  PDIV-1000-WRITE
010648            THRU PDIV-1000-WRITE-X
010648        PERFORM  PDIV-2000-READ-NEXT
010648            THRU PDIV-2000-READ-NEXT-X
010648     END-PERFORM.
010648
010648     PERFORM  PDIV-3000-END-BROWSE
010648         THRU PDIV-3000-END-BROWSE-X.
010648*
010648 4750-DUPLICATE-PLAN-DIVOP-X.
010648     EXIT.
010649*
010649 4760-DUPL-BILL-TYPE-MODE.
010649*
010649     MOVE LOW-VALUES            TO WPBTM-KEY.
010649     MOVE HIGH-VALUES           TO WPBTM-ENDBR-KEY.
010649     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPBTM-PLAN-ID.
010649     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPBTM-ENDBR-PLAN-ID.
010649
010649     PERFORM  PBTM-1000-BROWSE
010649         THRU PBTM-1000-BROWSE-X.
010649
010649     PERFORM  PBTM-2000-READ-NEXT
010649         THRU PBTM-2000-READ-NEXT-X.
010649
010649     PERFORM
010649        UNTIL NOT WPBTM-IO-OK
010649        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WPBTM-PLAN-ID
010649        PERFORM  PBTM-1000-WRITE
010649            THRU PBTM-1000-WRITE-X
010649        PERFORM  PBTM-2000-READ-NEXT
010649            THRU PBTM-2000-READ-NEXT-X
010649     END-PERFORM.
010649
010649     PERFORM  PBTM-3000-END-BROWSE
010649         THRU PBTM-3000-END-BROWSE-X.
010649*
010649 4760-DUPL-BILL-TYPE-MODE-X.
010649     EXIT.
010304*
010304 4770-DUPLICATE-PLAN-NFO-OPT.
010304*
010304     MOVE LOW-VALUES            TO WPNFO-KEY.
010304     MOVE HIGH-VALUES           TO WPNFO-ENDBR-KEY.
010304     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPNFO-PLAN-ID.
010304     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WPNFO-ENDBR-PLAN-ID.
010304
010304     PERFORM  PNFO-1000-BROWSE
010304         THRU PNFO-1000-BROWSE-X.
010304
010304     PERFORM  PNFO-2000-READ-NEXT
010304         THRU PNFO-2000-READ-NEXT-X.
010304
010304     PERFORM
010304        UNTIL NOT WPNFO-IO-OK
010304        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WPNFO-PLAN-ID
010304        PERFORM  PNFO-1000-WRITE
010304            THRU PNFO-1000-WRITE-X
010304        PERFORM  PNFO-2000-READ-NEXT
010304            THRU PNFO-2000-READ-NEXT-X
010304     END-PERFORM.
010304
010304     PERFORM  PNFO-3000-END-BROWSE
010304         THRU PNFO-3000-END-BROWSE-X.
010304*
010304 4770-DUPLICATE-PLAN-NFO-OPT-X.
010304     EXIT.
010302/

015290 4780-DUPL-PLAN-ALLOC-TYP.
015290*
015290     MOVE LOW-VALUES            TO WPLAR-KEY.
015290     MOVE HIGH-VALUES           TO WPLAR-ENDBR-KEY.
015290     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
015290                                TO WPLAR-PLAN-ID.
015290     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
015290                                TO WPLAR-ENDBR-PLAN-ID.
015290
015290     PERFORM  PLAR-1000-BROWSE
015290         THRU PLAR-1000-BROWSE-X.
015290
015290     PERFORM  PLAR-2000-READ-NEXT
015290         THRU PLAR-2000-READ-NEXT-X.
015290
015290     PERFORM
015290        UNTIL NOT WPLAR-IO-OK
015290        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
015290                                TO WPLAR-PLAN-ID
015290        PERFORM  PLAR-1000-WRITE
015290            THRU PLAR-1000-WRITE-X
015290        PERFORM  PLAR-2000-READ-NEXT
015290            THRU PLAR-2000-READ-NEXT-X
015290     END-PERFORM.
015290
015290     PERFORM  PLAR-3000-END-BROWSE
015290         THRU PLAR-3000-END-BROWSE-X.
015290*
015290 4780-DUPL-PLAN-ALLOC-TYP-X.
015290     EXIT.

020475*------------------
020475 4790-DUPL-PLAN-DBG.
020475*------------------
020475*
020475     MOVE LOW-VALUES            TO WPDBG-KEY.
020475     MOVE HIGH-VALUES           TO WPDBG-ENDBR-KEY.
020475     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
020475                                TO WPDBG-PLAN-ID.
020475     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
020475                                TO WPDBG-ENDBR-PLAN-ID.
020475
020475     PERFORM  PDBG-1000-BROWSE
020475         THRU PDBG-1000-BROWSE-X.
020475
020475     PERFORM  PDBG-2000-READ-NEXT
020475         THRU PDBG-2000-READ-NEXT-X.
020475
020475     PERFORM
020475        UNTIL NOT WPDBG-IO-OK
020475        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
020475                                TO WPDBG-PLAN-ID
020475        PERFORM  PDBG-1000-WRITE
020475            THRU PDBG-1000-WRITE-X
020475        PERFORM  PDBG-2000-READ-NEXT
020475            THRU PDBG-2000-READ-NEXT-X
020475     END-PERFORM.
020475
020475     PERFORM  PDBG-3000-END-BROWSE
020475         THRU PDBG-3000-END-BROWSE-X.
020475*
020475 4790-DUPL-PLAN-DBG-X.
020475     EXIT.

020467
020467 4800-DUPL-PLAN-MODE.
020467*
020467     MOVE LOW-VALUES            TO WPBMF-KEY.
020467     MOVE HIGH-VALUES           TO WPBMF-ENDBR-KEY.
020467     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
020467                                TO WPBMF-PLAN-ID.
020467     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
020467                                TO WPBMF-ENDBR-PLAN-ID.
020467
020467     PERFORM  PBMF-1000-BROWSE
020467         THRU PBMF-1000-BROWSE-X.
020467
020467     PERFORM  PBMF-2000-READ-NEXT
020467         THRU PBMF-2000-READ-NEXT-X.
020467
020467     PERFORM
020467        UNTIL NOT WPBMF-IO-OK
020467        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
020467                                TO WPBMF-PLAN-ID
020467        PERFORM  PBMF-1000-WRITE
020467            THRU PBMF-1000-WRITE-X
020467        PERFORM  PBMF-2000-READ-NEXT
020467            THRU PBMF-2000-READ-NEXT-X
020467     END-PERFORM.
020467
020467     PERFORM  PBMF-3000-END-BROWSE
020467         THRU PBMF-3000-END-BROWSE-X.
020467*
020467 4800-DUPL-PLAN-MODE-X.
020467     EXIT.

021691*------------------------
021691 4810-DUPL-PLAN-CALC-EXIT.
021691*------------------------
021691*
021691     MOVE LOW-VALUES            TO WPCXT-KEY.
021691     MOVE HIGH-VALUES           TO WPCXT-ENDBR-KEY.
021691     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
021691                                TO WPCXT-PLAN-ID.
021691     MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
021691                                TO WPCXT-ENDBR-PLAN-ID.
021691
021691     PERFORM  PCXT-1000-BROWSE
021691         THRU PCXT-1000-BROWSE-X.
021691
021691     PERFORM  PCXT-2000-READ-NEXT
021691         THRU PCXT-2000-READ-NEXT-X.
021691
021691     PERFORM
021691        UNTIL NOT WPCXT-IO-OK
021691        MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
021691                                TO WPCXT-PLAN-ID
021691        PERFORM  PCXT-1000-WRITE
021691            THRU PCXT-1000-WRITE-X
021691        PERFORM  PCXT-2000-READ-NEXT
021691            THRU PCXT-2000-READ-NEXT-X
021691     END-PERFORM.
021691
021691     PERFORM  PCXT-3000-END-BROWSE
021691         THRU PCXT-3000-END-BROWSE-X.
021691*
021691 4810-DUPL-PLAN-CALC-EXIT-X.
021691     EXIT.


010302*4800-DUPL-PR.
010302*
010302*  EDIT FROM KEY
010302*  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
010302*  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
010302*
010302*    MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
010302*    MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE) TO WDUPL-KEY-PR.
010302*    PERFORM  4810-BUILD-PR-KEY
010302*        THRU 4810-BUILD-PR-KEY-X.
010302*
010302*    PERFORM  PR-1000-READ
010302*        THRU PR-1000-READ-X.
010302*    IF WPR-IO-NOT-FOUND
010302*        MSG: PR FROM KEY ON LINE (@1) DOES NOT EXIST
010302*        MOVE 'NS01200046'         TO WGLOB-MSG-REF-INFO
010302*        MOVE WS-LINE              TO WGLOB-MSG-PARM (1)
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        SET WS-FROM-KEY-NOT-VALID TO TRUE
010302*        GO TO 4800-DUPL-PR-X
010302*    END-IF.
010302*
010302*  FROM RECORD EXISTS - SAVE RECORD
010302*
010302*    MOVE RPR-REC-INFO TO WS-PR-REC-INFO.
010302*
010302*  MOVE COMPANY CODE IF USING
010302*
010302*    IF WDUPL-COMPANY NOT = SPACES
010302*        MOVE WDUPL-COMPANY TO WGLOB-COMPANY-CODE
010302*    END-IF.
010302*
010302*  EDIT TO KEY
010302*
010302*    MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)  TO WDUPL-KEY-PR.
010302*    PERFORM  4820-VALIDATE-PR-KEY
010302*        THRU 4820-VALIDATE-PR-KEY-X.
010302*    IF WS-TO-KEY-NOT-VALID
010302*        GO TO 4800-DUPL-PR-X
010302*    END-IF.
010302*
010302*    PERFORM  4810-BUILD-PR-KEY
010302*        THRU 4810-BUILD-PR-KEY-X.
010302*    PERFORM  PR-1000-READ
010302*        THRU PR-1000-READ-X.
010302*    IF WPR-IO-OK
010302*        MSG: PR TO KEY ON LINE (@1) ALREADY EXISTS
010302*        MOVE WS-LINE            TO WGLOB-MSG-PARM (1)
010302*        MOVE 'NS01200047'       TO WGLOB-MSG-REF-INFO
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        SET WS-TO-KEY-NOT-VALID TO TRUE
010302*        GO TO 4800-DUPL-PR-X
010302*    END-IF.
010302*
010302*  EVERYTHING IS OK - DUPLICATE MSGS RECORD
010302*
010302*    MOVE WS-PR-REC-INFO   TO RPR-REC-INFO.
010302*    MOVE WDUPL-KEY-ALL    TO RPR-KEY.
010302*    MOVE WDUPL-KEY-ALL    TO WPR-KEY.
010302*
010302*    PERFORM  PR-1000-WRITE
010302*        THRU PR-1000-WRITE-X.
010302*
010302*4800-DUPL-PR-X.
010302*    EXIT.
010302*
010302*4810-BUILD-PR-KEY.
010302*
010302*    MOVE WDUPL-KEY-PR-CODE     TO WPR-RTBL3-ID-PLAN.
010302*    MOVE WDUPL-KEY-PR-SCALE    TO WPR-RTBL3-ID-RS.
010302*    MOVE WDUPL-KEY-PR-SMOKERS  TO WPR-RTBL3-SMKR-CD.
010302*    MOVE WDUPL-KEY-PR-PAR      TO WPR-RTBL3-PAR-CD.
010302*    MOVE WDUPL-KEY-PR-SEX      TO WPR-RTBL3-SEX-CD.
010302*    MOVE WDUPL-KEY-PR-TABLE-1  TO WPR-RTBL3-STBL-1-CD.
010302*    MOVE WDUPL-KEY-PR-TABLE-2  TO WPR-RTBL3-STBL-2-CD.
010302*    MOVE WDUPL-KEY-PR-TABLE-3  TO WPR-RTBL3-STBL-3-CD.
010302*    MOVE WDUPL-KEY-PR-TABLE-4  TO WPR-RTBL3-STBL-4-CD.
010302*    MOVE WDUPL-KEY-PR-AGE      TO WPR-RTBL3-AGE-N.
010302*    MOVE WDUPL-KEY-PR-DURATION TO WPR-RTBL3-DUR-N.
010302*    MOVE '9999999'             TO WPR-RTBL3-IDT-NUM.
010302*    MOVE WPR-KEY               TO WDUPL-KEY-ALL.
010302*    MOVE WDUPL-KEY-ALL         TO RPR-KEY.
010302*
010302*4810-BUILD-PR-KEY-X.
010302*    EXIT.
010302*
010302*4820-VALIDATE-PR-KEY.
010302*
010302*    PERFORM  4821-VALIDATE-PR-PLAN
010302*        THRU 4821-VALIDATE-PR-PLAN-X.
010302*    PERFORM  4822-VALIDATE-PR-SMOKER-CD
010302*        THRU 4822-VALIDATE-PR-SMOKER-CD-X.
010302*    PERFORM  4823-VALIDATE-PR-PAR-CD
010302*        THRU 4823-VALIDATE-PR-PAR-CD-X.
010302*    PERFORM  4824-VALIDATE-PR-SEX-CD
010302*        THRU 4824-VALIDATE-PR-SEX-CD-X.
010302*    PERFORM  4825-VALIDATE-PR-STB1
010302*        THRU 4825-VALIDATE-PR-STB1-X.
010302*    PERFORM  4826-VALIDATE-PR-STB2
010302*        THRU 4826-VALIDATE-PR-STB2-X.
010302*    PERFORM  4827-VALIDATE-PR-STB3
010302*        THRU 4827-VALIDATE-PR-STB3-X.
010302*    PERFORM  4828-VALIDATE-PR-STB4
010302*        THRU 4828-VALIDATE-PR-STB4-X.
010302*    PERFORM  4829-VALIDATE-PR-AGE
010302*        THRU 4829-VALIDATE-PR-AGE-X.
010302*    PERFORM  4830-VALIDATE-PR-DUR
010302*        THRU 4830-VALIDATE-PR-DUR-X.
010302*
010302*4820-VALIDATE-PR-KEY-X.
010302*    EXIT.
010302*
010302*4821-VALIDATE-PR-PLAN.
010302*
010302*  PRTS PLAN CODE CANNOT BE SPACES
010302*
010302*    IF WDUPL-KEY-PR-CODE = SPACES
010302*        MSG: PLAN CODE CANNOT BE SPACES
010302*        MOVE 'NS01200035'       TO WGLOB-MSG-REF-INFO
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        SET WS-TO-KEY-NOT-VALID TO TRUE
010302*    END-IF.
010302*
010302*4821-VALIDATE-PR-PLAN-X.
010302*    EXIT.
010302*
010302*4822-VALIDATE-PR-SMOKER-CD.
010302*
010302*    MOVE WDUPL-KEY-PR-SMOKERS   TO WS-EDIT-SMOKERS.
010302*    IF WS-VALID-PR-SMOKER
010302*        NEXT SENTENCE
010302*    ELSE
010302*        MSG: INVALID SMOKER CODE - USE S, N, C, OR SPACES
010302*        MOVE 'NS01200048'       TO WGLOB-MSG-REF-INFO
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        SET WS-TO-KEY-NOT-VALID TO TRUE
010302*    END-IF.
010302*
010302*4822-VALIDATE-PR-SMOKER-CD-X.
010302*    EXIT.
010302*
010302*4823-VALIDATE-PR-PAR-CD.
010302*
010302*    MOVE WDUPL-KEY-PR-PAR       TO WS-EDIT-PAR.
010302*    IF WS-VALID-PAR
010302*        NEXT SENTENCE
010302*    ELSE
010302*        MSG: INVALID PAR CODE - USE P OR N
010302*        MOVE 'NS01200049'       TO WGLOB-MSG-REF-INFO
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        SET WS-TO-KEY-NOT-VALID TO TRUE
010302*    END-IF.
010302*
010302*4823-VALIDATE-PR-PAR-CD-X.
010302*    EXIT.
010302*
010302*4824-VALIDATE-PR-SEX-CD.
010302*
010302*    MOVE WDUPL-KEY-PR-SEX       TO WS-EDIT-SEX.
010302*    IF WS-VALID-SEX
010302*        NEXT SENTENCE
010302*    ELSE
010302*        MSG: INVALID SEX CODE - USE M, F, OR J
010302*        MOVE 'NS01200050'       TO WGLOB-MSG-REF-INFO
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        SET WS-TO-KEY-NOT-VALID TO TRUE
010302*    END-IF.
010302*
010302*4824-VALIDATE-PR-SEX-CD-X.
010302*    EXIT.
010302*
010302*4825-VALIDATE-PR-STB1.
010302*
010302*    IF WDUPL-KEY-PR-TABLE-1 NOT = SPACES
010302*        MOVE WDUPL-KEY-PR-TABLE-1   TO WEDIT-ETBL-VALU-ID
010302*        PERFORM  STB1-1000-EDIT-SUB-TABLE-1
010302*            THRU STB1-1000-EDIT-SUB-TABLE-1-X
010302*        IF WEDIT-IO-OK
010302*            NEXT SENTENCE
010302*        ELSE
010302*            MSG: SUB TABLE 1 MUST BE ON EDIT TYPE 'STB1'
010302*            MOVE 'NS01200051'       TO WGLOB-MSG-REF-INFO
010302*            PERFORM  0260-1000-GENERATE-MESSAGE
010302*                THRU 0260-1000-GENERATE-MESSAGE-X
010302*            SET WS-TO-KEY-NOT-VALID TO TRUE
010302*        END-IF
010302*    END-IF.
010302*
010302*4825-VALIDATE-PR-STB1-X.
010302*    EXIT.
010302*
010302*4826-VALIDATE-PR-STB2.
010302*
010302*    IF WDUPL-KEY-PR-TABLE-2 NOT = SPACES
010302*        MOVE WDUPL-KEY-PR-TABLE-2   TO WEDIT-ETBL-VALU-ID
010302*        PERFORM  STB2-1000-EDIT-SUB-TABLE-2
010302*            THRU STB2-1000-EDIT-SUB-TABLE-2-X
010302*        IF WEDIT-IO-OK
010302*            NEXT SENTENCE
010302*        ELSE
010302*            MSG: SUB TABLE 2 MUST BE ON EDIT TYPE 'STB2'
010302*            MOVE 'NS01200052'       TO WGLOB-MSG-REF-INFO
010302*            PERFORM  0260-1000-GENERATE-MESSAGE
010302*                THRU 0260-1000-GENERATE-MESSAGE-X
010302*            SET WS-TO-KEY-NOT-VALID TO TRUE
010302*        END-IF
010302*    END-IF.
010302*
010302*4826-VALIDATE-PR-STB2-X.
010302*    EXIT.
010302*
010302*4827-VALIDATE-PR-STB3.
010302*
010302*    IF WDUPL-KEY-PR-TABLE-3 NOT = SPACES
010302*        MOVE WDUPL-KEY-PR-TABLE-3   TO WEDIT-ETBL-VALU-ID
010302*        PERFORM  STB3-1000-EDIT-SUB-TABLE-3
010302*            THRU STB3-1000-EDIT-SUB-TABLE-3-X
010302*        IF WEDIT-IO-OK
010302*            NEXT SENTENCE
010302*        ELSE
010302*            MSG: SUB TABLE 3 MUST BE ON EDIT TYPE 'STB3'
010302*            MOVE 'NS01200053'       TO WGLOB-MSG-REF-INFO
010302*            PERFORM  0260-1000-GENERATE-MESSAGE
010302*                THRU 0260-1000-GENERATE-MESSAGE-X
010302*            SET WS-TO-KEY-NOT-VALID TO TRUE
010302*        END-IF
010302*    END-IF.
010302*
010302*4827-VALIDATE-PR-STB3-X.
010302*    EXIT.
010302*
010302*4828-VALIDATE-PR-STB4.
010302*
010302*    IF WDUPL-KEY-PR-TABLE-4 NOT = SPACES
010302*        MOVE WDUPL-KEY-PR-TABLE-4   TO WEDIT-ETBL-VALU-ID
010302*        PERFORM  STB4-1000-EDIT-SUB-TABLE-4
010302*            THRU STB4-1000-EDIT-SUB-TABLE-4-X
010302*        IF WEDIT-IO-OK
010302*            NEXT SENTENCE
010302*        ELSE
010302*            MSG: SUB TABLE 4 MUST BE ON EDIT TYPE 'STB4'
010302*            MOVE 'NS01200054'       TO WGLOB-MSG-REF-INFO
010302*            PERFORM  0260-1000-GENERATE-MESSAGE
010302*                THRU 0260-1000-GENERATE-MESSAGE-X
010302*            SET WS-TO-KEY-NOT-VALID TO TRUE
010302*        END-IF
010302*    END-IF.
010302*
010302*4828-VALIDATE-PR-STB4-X.
010302*    EXIT.
010302*
010302*4829-VALIDATE-PR-AGE.
010302*
010302*    VERIFY PR AGE IS NUMERIC.
010302*
010302*    MOVE 'N'                   TO  L0280-SIGN-IND.
010302*    MOVE 3                     TO  L0280-LENGTH.
010302*    MOVE ZERO                  TO  L0280-PRECISION.
010302*    MOVE 'N'                   TO  L0280-SPACE-PERMITTED-IND.
010302*    MOVE 3                     TO  L0280-INPUT-SIZE.
010302*    MOVE WDUPL-KEY-PR-AGE      TO  L0280-INPUT-DATA.
010302*
010302*    PERFORM 0280-1000-NUMERIC-EDIT
010302*       THRU 0280-1000-NUMERIC-EDIT-X.
010302*
010302*    IF L0280-OK
010302*        NEXT SENTENCE
010302*    ELSE
010302*        MSG: TO-KEY AGE MUST BE NUMERIC
010302*        MOVE 'NS01200055'      TO WGLOB-MSG-REF-INFO
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        SET WS-TO-KEY-NOT-VALID TO TRUE
010302*    END-IF.
010302*
010302*4829-VALIDATE-PR-AGE-X.
010302*    EXIT.
010302*
010302*4830-VALIDATE-PR-DUR.
010302*
010302*    VERIFY PR DURATION IS NUMERIC.
010302*
010302*    MOVE 'N'                   TO  L0280-SIGN-IND.
010302*    MOVE 3                     TO  L0280-LENGTH.
010302*    MOVE ZERO                  TO  L0280-PRECISION.
010302*    MOVE 'N'                   TO  L0280-SPACE-PERMITTED-IND.
010302*    MOVE 3                     TO  L0280-INPUT-SIZE.
010302*    MOVE WDUPL-KEY-PR-DURATION TO  L0280-INPUT-DATA.
010302*
010302*    PERFORM 0280-1000-NUMERIC-EDIT
010302*       THRU 0280-1000-NUMERIC-EDIT-X.
010302*
010302*    IF L0280-OK
010302*        NEXT SENTENCE
010302*    ELSE
010302*        MSG: DURATION MUST BE NUMERIC
010302*        MOVE 'NS01200056'      TO WGLOB-MSG-REF-INFO
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        SET WS-TO-KEY-NOT-VALID TO TRUE
010302*    END-IF.
010302*
010302*4830-VALIDATE-PR-DUR-X.
010302*    EXIT.
010302/
023447*4900-DUPL-PW.
023447*
023447*  EDIT FROM KEY
023447*  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
023447*  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
023447*
023447*    MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
023447*    MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
023447*                               TO WDUPL-KEY-PW.
023447*    PERFORM  4910-BUILD-PW-KEY
023447*        THRU 4910-BUILD-PW-KEY-X.
023447*
023447*    PERFORM  PW-1000-READ
023447*        THRU PW-1000-READ-X.
023447*    IF WPW-IO-NOT-FOUND
023447*        MSG: PW FROM KEY ON LINE (@1) DOES NOT EXIST
023447*        MOVE 'NS01200057'      TO WGLOB-MSG-REF-INFO
023447*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-FROM-KEY-NOT-VALID TO TRUE
023447*        GO TO 4900-DUPL-PW-X
023447*    END-IF.
023447*
023447*  FROM RECORD EXISTS - SAVE RECORD
023447*
023447*    MOVE RPW-REC-INFO          TO WS-PW-REC-INFO.
023447*
023447*  MOVE COMPANY CODE IF USING
023447*
023447*    IF WDUPL-COMPANY NOT = SPACES
023447*        MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
023447*    END-IF.
023447*
023447*  EDIT TO KEY
023447*
023447*    MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
023447*                               TO WDUPL-KEY-PW.
023447*    PERFORM  4920-VALIDATE-PW-KEY
023447*        THRU 4920-VALIDATE-PW-KEY-X.
023447*    IF WS-TO-KEY-NOT-VALID
023447*        GO TO 4900-DUPL-PW-X
023447*    END-IF.
023447*
023447*    PERFORM  4910-BUILD-PW-KEY
023447*        THRU 4910-BUILD-PW-KEY-X.
023447*    PERFORM  PW-1000-READ
023447*        THRU PW-1000-READ-X.
023447*    IF WPW-IO-OK
023447*        MSG: PW TO KEY ON LINE (@1) ALREADY EXISTS
023447*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
023447*        MOVE 'NS01200058'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*        GO TO 4900-DUPL-PW-X
023447*    END-IF.
023447*
023447*  EVERYTHING IS OK - DUPLICATE PW RECORD
023447*
023447*    MOVE WS-PW-REC-INFO        TO RPW-REC-INFO.
023447*    MOVE WDUPL-KEY-ALL         TO RPW-KEY.
023447*    MOVE WDUPL-KEY-ALL         TO WPW-KEY.
023447*
023447*    PERFORM  PW-1000-WRITE
023447*        THRU PW-1000-WRITE-X.
023447*
023447*4900-DUPL-PW-X.
023447*    EXIT.
023447*
023447*4910-BUILD-PW-KEY.
023447*
007685*    MOVE WDUPL-KEY-PW-CODE    TO WPW-PLAN-FP-ID-PLAN.
007685*    MOVE WDUPL-KEY-PW-SCALE   TO WPW-PLAN-FP-ID-RS.
007685*    MOVE WDUPL-KEY-PW-DOC-ID  TO WPW-PLAN-FP-DOC-ID.
023447*    MOVE WDUPL-KEY-PW-DOC-ID   TO WPW-DOC-ID.
023447*    MOVE WDUPL-KEY-PW-SBSDRY-CO-ID
023447*                               TO WPW-SBSDRY-CO-ID.
007685*    MOVE WDUPL-KEY-PW-LANG    TO WPW-PLAN-FP-LANG-CD.
023447*    MOVE WDUPL-KEY-PW-LANG     TO WPW-DOC-LANG-CD.
007685*    MOVE WDUPL-KEY-PW-ILOC    TO WPW-PLAN-FP-ISS-LOC-CD.
007685*    MOVE WDUPL-KEY-PW-LOC-GR  TO WPW-PLAN-FP-LOC-GR-CD.
023447*    MOVE WDUPL-KEY-PW-LOC-GR   TO WPW-LOC-GR-ID.
023447*    MOVE WPW-KEY               TO WDUPL-KEY-ALL.
023447*    MOVE WDUPL-KEY-ALL         TO RPW-KEY.
023447*
023447*4910-BUILD-PW-KEY-X.
023447*    EXIT.
023447*
023447*
023447*4920-VALIDATE-PW-KEY.
023447*
023447*  PWRD PLAN CODE CANNOT BE SPACES
023447*
007685*    IF WDUPL-KEY-PW-CODE = SPACES
023447*    IF WDUPL-KEY-PW-DOC-ID = SPACES
023447*        MSG: DOCUMENT ID CANNOT BE SPACES
023447*        MOVE 'NS01200035'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*    END-IF.
023447*
023447*    MOVE WDUPL-KEY-PW-SBSDRY-CO-ID
023447*                               TO WSCOM-SBSDRY-CO-ID.
023447*    PERFORM  SCOM-1000-READ
023447*        THRU SCOM-1000-READ-X.
023447*    IF NOT WSCOM-IO-OK
010418*        MSG: SUB-COMPANY MUST BE ON SUB-COMPANY PROFILE
023447*        MOVE 'NS01200102'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*    END-IF.
010418*
023447*
023447*    MOVE SPACES                TO WEDIT-ETBL-VALU-ID.
023447*    MOVE WDUPL-KEY-PW-LANG     TO WEDIT-ETBL-VALU-ID.
023447*    PERFORM  LANG-1000-EDIT
023447*        THRU LANG-1000-EDIT-X.
023447*    IF NOT WEDIT-IO-OK
023447*        MSG: LANGUAGE CODE NOT VALID - CHECK EDIT TYPE 'LANG'
023447*        MOVE 'NS01200037'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*    END-IF.
023447*
007685*    IF WDUPL-KEY-PW-ILOC = WS-GENERIC-LOC
023447*    IF WDUPL-KEY-PW-LOC-GR = WS-LOC-GROUP
023447*        CONTINUE
023447*    ELSE
023447*        MOVE SPACES            TO WEDIT-ETBL-VALU-ID
007685*        MOVE WDUPL-KEY-PW-ILOC      TO WEDIT-ETBL-VALU-ID
007685*        PERFORM  ILOC-1000-EDIT-ISSU-LOCATION
007685*            THRU ILOC-1000-EDIT-ISSU-LOCATION-X
023447*        MOVE WDUPL-KEY-PW-LOC-GR
023447*                               TO WEDIT-ETBL-VALU-ID
023447*        PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
023447*            THRU LCGP-1000-EDIT-LCGP-LOCATION-X
023447*        IF NOT WEDIT-IO-OK
007685*            MSG: ISS LOC NOT VALID - CHECK EDIT TYPE 'ILOC'
007685*            MOVE 'NS01200041'       TO WGLOB-MSG-REF-INFO
007685*            MSG: LOC GROUP NOT VALID - CHECK EDIT TYPE 'LCGP'
023447*            MOVE 'NS01200041'  TO WGLOB-MSG-REF-INFO
023447*            PERFORM  0260-1000-GENERATE-MESSAGE
023447*                THRU 0260-1000-GENERATE-MESSAGE-X
023447*            SET WS-TO-KEY-NOT-VALID TO TRUE
023447*        END-IF
023447*    END-IF.
023447*    MOVE 'DOCM'                TO WEDIT-ETBL-TYP-ID.
023447*    MOVE WDUPL-KEY-PF-DOC-ID   TO WEDIT-ETBL-VALU-ID.
023447*    MOVE WDUPL-KEY-PF-LANG     TO WEDIT-ETBL-LANG-CD.
023447*    PERFORM  EDIT-1000-READ
023447*        THRU EDIT-1000-READ-X.
023447*    IF NOT WEDIT-IO-OK
007685*        MSG: DOCUMENT NOT VALID - CHECK EDIT TYPE 'DOCM'
023447*        MOVE 'NS01200040'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*    END-IF.
023447*
007685*
007685*  VERIFY DOCUMENT NAME FROM TABLE DOCM
007685*
023447*    MOVE WDUPL-KEY-PW-DOC-ID   TO WDOCM-DOC-ID.
023447*    MOVE WDUPL-KEY-PW-LANG     TO WDOCM-DOC-LANG-CD.
023447*    PERFORM  DOCM-1000-READ
023447*        THRU DOCM-1000-READ-X.
023447*    IF NOT WDOCM-IO-OK
007685*        MSG: DOCUMENT NAME ON LINE (@1) DOES NOT EXIST
023447*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
023447*        MOVE 'NS01200105'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        SET WS-TO-KEY-NOT-VALID TO TRUE
023447*    END-IF.
023447*
023447*
023447*4920-VALIDATE-PW-KEY-X.
023447*    EXIT.
      *
       5000-DUPL-RH.
      *
      *  EDIT FROM KEY
      *  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
      *  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
      *
           MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
           MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-RH.
           PERFORM  5021-VALIDATE-RH-EFF-DATE
               THRU 5021-VALIDATE-RH-EFF-DATE-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 5000-DUPL-RH-X
           END-IF.
           PERFORM  5010-BUILD-RH-KEY
               THRU 5010-BUILD-RH-KEY-X.

           PERFORM  RH-1000-READ
               THRU RH-1000-READ-X.
           IF WRH-IO-NOT-FOUND
      *        MSG: RH FROM KEY ON LINE (@1) DOES NOT EXIST
               MOVE 'NS01200060'      TO WGLOB-MSG-REF-INFO
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 5000-DUPL-RH-X
           END-IF.
      *
      *  FROM RECORD EXISTS - SAVE RECORD
      *
023118*    MOVE RRH-REC-INFO          TO WS-RH-REC-INFO.
023118     MOVE RRH-REC-INFO          TO HRH-REC-INFO.
      *
      *  MOVE COMPANY CODE IF USING
      *
           IF WDUPL-COMPANY NOT = SPACES
               MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
           END-IF.
      *
      *  EDIT TO KEY
      *
           MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-RH.
           PERFORM  5020-VALIDATE-RH-KEY
               THRU 5020-VALIDATE-RH-KEY-X.
           IF WS-TO-KEY-NOT-VALID
               GO TO 5000-DUPL-RH-X
           END-IF.

           PERFORM  5010-BUILD-RH-KEY
               THRU 5010-BUILD-RH-KEY-X.
           PERFORM  RH-1000-READ
               THRU RH-1000-READ-X.
           IF WRH-IO-OK
      *        MSG: RH TO KEY ON LINE (@1) ALREADY EXISTS
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200061'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 5000-DUPL-RH-X
           END-IF.
      *
      *  EVERYTHING IS OK - DUPLICATE RH RECORD
      *
023118*    MOVE WS-RH-REC-INFO        TO RRH-REC-INFO.
023118     MOVE HRH-REC-INFO          TO RRH-REC-INFO.
      *
      *  IN ORDER TO KEEP THE DATE FIELDS CONSISTENT, MOVE THE DATE
      *  FIELD IN THE KEY TO THE DISPLAY DATE FIELD IN THE RH-FILE
      *  DATA BEFORE KLONING THE NEW RECORD.
      *
           MOVE L1640-INTERNAL-DATE   TO RRH-RH-EFF-DT.

           MOVE WDUPL-KEY-ALL         TO RRH-KEY.
           MOVE WDUPL-KEY-ALL         TO WRH-KEY.
      *
           PERFORM  RH-1000-WRITE
               THRU RH-1000-WRITE-X.
      *
       5000-DUPL-RH-X.
           EXIT.
      *
       5010-BUILD-RH-KEY.
      *
           MOVE WDUPL-KEY-RH-HEADER-PTR
                                      TO WRH-RH-ID.
           MOVE L1660-INVERTED-DATE   TO WRH-RH-IDT-NUM-N.
           MOVE WRH-KEY               TO WDUPL-KEY-ALL.
           MOVE WDUPL-KEY-ALL         TO RRH-KEY.
      *
       5010-BUILD-RH-KEY-X.
           EXIT.
      *
       5020-VALIDATE-RH-KEY.
      *
           IF WDUPL-KEY-RH-HEADER-PTR = SPACES
      *        MSG: RHDR POINTER CANNOT BE SPACES
               MOVE 'NS01200062'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID     TO TRUE
           ELSE
               IF WDUPL-KEY-RH-HEADER-PTR = 'XXXXXX'
      *            MSG: RHDR POINTER CANNOT = 'XXXXXX'
                   MOVE 'NS01200063'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-TO-KEY-NOT-VALID TO TRUE
               END-IF
           END-IF.

           PERFORM  5021-VALIDATE-RH-EFF-DATE
               THRU 5021-VALIDATE-RH-EFF-DATE-X.
      *
       5020-VALIDATE-RH-KEY-X.
           EXIT.
      *
       5021-VALIDATE-RH-EFF-DATE.
      *
           MOVE WDUPL-KEY-RH-EFF-DATE TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
           ELSE
      *        MSG: RH EFF DATE MUST BE VALID IN DDMMMYYYY FORMAT
               MOVE 'NS01200064'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID  TO TRUE
           END-IF.
      *
       5021-VALIDATE-RH-EFF-DATE-X.
           EXIT.
      *
       5100-DUPL-RT.
      *
      *  EDIT FROM KEY
      *  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
      *  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
      *
           MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
           MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-RT.
557691*    PERFORM  5132-VALIDATE-RT-EFF-DATE
557691*        THRU 5132-VALIDATE-RT-EFF-DATE-X.
557691     PERFORM  5134-VALIDATE-RT-EFF-DATE
557691         THRU 5134-VALIDATE-RT-EFF-DATE-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 5100-DUPL-RT-X
           END-IF.
           PERFORM  5110-BUILD-RT-KEY
               THRU 5110-BUILD-RT-KEY-X.

008454*    PERFORM  RT-1000-READ
008454*        THRU RT-1000-READ-X.
008454*    GET FIRST RECORD WITH SAME KEY WITH LOWEST AGE/DUR
008454*
008454             MOVE WRT-KEY       TO WRT-ENDBR-KEY
008454*            MOVE HIGH-VALUES    TO WRT-ENDBR-RTBL-IDT-NUM
008454             MOVE 0             TO WRT-RTBL-AGE-DUR
008454             MOVE 999           TO WRT-ENDBR-RTBL-AGE-DUR
008454             PERFORM  RT-1000-BROWSE
008454                 THRU RT-1000-BROWSE-X
008454             IF WRT-IO-EOF
008454                 MOVE 'NS01200065'
                                      TO WGLOB-MSG-REF-INFO
008454                 MOVE WS-LINE   TO WGLOB-MSG-PARM (1)
008454                 PERFORM  0260-1000-GENERATE-MESSAGE
008454                     THRU 0260-1000-GENERATE-MESSAGE-X
008454                 SET WS-FROM-KEY-NOT-VALID TO TRUE
008454                 PERFORM  RT-3000-END-BROWSE
008454                     THRU RT-3000-END-BROWSE-X
008454                 GO TO 5100-DUPL-RT-X
008454             ELSE
008454                 PERFORM  RT-2000-READ-NEXT
008454                     THRU RT-2000-READ-NEXT-X
008454*               IF WRT-IO-NOT-FOUND
                      IF WRT-IO-EOF
      *     MSG: RT FROM KEY ON LINE (@1) DOES NOT EXIST
                        MOVE 'NS01200065'
                                      TO WGLOB-MSG-REF-INFO
                        MOVE WS-LINE  TO WGLOB-MSG-PARM (1)
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                        SET WS-FROM-KEY-NOT-VALID TO TRUE
008454                  PERFORM  RT-3000-END-BROWSE
008454                       THRU RT-3000-END-BROWSE-X
                        GO TO 5100-DUPL-RT-X
008454                ELSE
008454                  MOVE RRT-RTBL-AGE-DUR
                                      TO WS-LOW-AGE-DUR
008454                  MOVE RRT-KEY  TO WS-WRT-KEY
008454                  PERFORM  RT-3000-END-BROWSE
008454                      THRU RT-3000-END-BROWSE-X
008454                END-IF
                   END-IF.
      *
      *  FROM RECORD EXISTS - SAVE RECORD
      *
023118*    MOVE RRT-REC-INFO          TO WS-RT-REC-INFO.
023118     MOVE RRT-REC-INFO          TO HRT-REC-INFO.
008454
008454     PERFORM  5115-GET-HIGH-AGE-DUR
008454         THRU 5115-GET-HIGH-AGE-DUR-X.

      *
      *  MOVE COMPANY CODE IF USING
      *
           IF WDUPL-COMPANY NOT = SPACES
               MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
           END-IF.
      *
      *  EDIT TO KEY
      *
           MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-RT.
           PERFORM  5120-VALIDATE-RT-KEY
               THRU 5120-VALIDATE-RT-KEY-X.
           IF WS-TO-KEY-NOT-VALID
               GO TO 5100-DUPL-RT-X
           END-IF.

           PERFORM  5110-BUILD-RT-KEY
               THRU 5110-BUILD-RT-KEY-X.
008454*    PERFORM  RT-1000-READ
008454*        THRU RT-1000-READ-X.
008454             MOVE WRT-KEY       TO WRT-ENDBR-KEY
008454*            MOVE HIGH-VALUES    TO WRT-ENDBR-RTBL-IDT-NUM
008454             MOVE 0             TO WRT-RTBL-AGE-DUR
008454             MOVE 999           TO WRT-ENDBR-RTBL-AGE-DUR
008454             PERFORM  RT-1000-BROWSE
008454                 THRU RT-1000-BROWSE-X
008454             IF WRT-IO-EOF
008454                 MOVE 'NS01200066'
                                      TO WGLOB-MSG-REF-INFO
008454                 MOVE WS-LINE   TO WGLOB-MSG-PARM (1)
008454                 PERFORM  0260-1000-GENERATE-MESSAGE
008454                     THRU 0260-1000-GENERATE-MESSAGE-X
008454                 SET WS-TO-KEY-NOT-VALID TO TRUE
008454                 PERFORM  RT-3000-END-BROWSE
008454                     THRU RT-3000-END-BROWSE-X
008454                 GO TO 5100-DUPL-RT-X
008454             ELSE
008454                 PERFORM  RT-2000-READ-NEXT
008454                     THRU RT-2000-READ-NEXT-X
008454*               IF WRT-IO-NOT-FOUND
                      IF WRT-IO-OK
008454**       MSG: RT TO KEY ON LINE (@1) ALREADY EXISTS
                        MOVE 'NS01200066'
                                      TO WGLOB-MSG-REF-INFO
                        MOVE WS-LINE  TO WGLOB-MSG-PARM (1)
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                        SET WS-TO-KEY-NOT-VALID TO TRUE
008454                  PERFORM  RT-3000-END-BROWSE
008454                       THRU RT-3000-END-BROWSE-X
                        GO TO 5100-DUPL-RT-X
008454                ELSE
008454                  PERFORM  RT-3000-END-BROWSE
008454                      THRU RT-3000-END-BROWSE-X
008454                END-IF
                   END-IF.
      *
      *  EVERYTHING IS OK - DUPLICATE PW RECORD
      *
023118*    MOVE WS-RT-REC-INFO        TO RRT-REC-INFO.
023118     MOVE HRT-REC-INFO          TO RRT-REC-INFO.
      *
      *  IN ORDER TO KEEP THE DATE FIELDS CONSISTENT, MOVE THE DATE
      *  FIELD IN THE KEY TO THE DISPLAY DATE FIELD IN THE RT-FILE
      *  DATA BEFORE KLONING THE NEW RECORD.
      *
008454*    MOVE L1640-INTERNAL-DATE TO RRT-RTBL-EFF-DT.
008454     MOVE L1640-INTERNAL-DATE   TO L1660-INTERNAL-DATE
008454     PERFORM  1660-2000-CONVERT-INT-TO-INV
008454         THRU 1660-2000-CONVERT-INT-TO-INV-X
022837*    MOVE L1660-INVERTED-DATE   TO WRT-RTBL-IDT-NUM-N.

022837*    MOVE WDUPL-KEY-ALL         TO RRT-KEY.
022837*    MOVE WDUPL-KEY-ALL         TO WRT-KEY.
022837     PERFORM  5110-BUILD-RT-KEY
022837         THRU 5110-BUILD-RT-KEY-X.
008454     MOVE WS-LOW-AGE-DUR        TO RRT-RTBL-AGE-DUR.
008454     MOVE WS-LOW-AGE-DUR        TO WRT-RTBL-AGE-DUR.
      *
           PERFORM  RT-1000-WRITE
               THRU RT-1000-WRITE-X.
      *
008454     MOVE 0                     TO SUB.
008454     MOVE 0                     TO WS-DUPL-AGE-DUR.
008454     SUBTRACT 1 FROM WS-HIGH-AGE-DUR.
008454     PERFORM  5160-WRITE-RT-RECORD
008454         THRU 5160-WRITE-RT-RECORD-X
008454           UNTIL WS-DUPL-AGE-DUR > WS-HIGH-AGE-DUR.
008454
       5100-DUPL-RT-X.
           EXIT.
      *
       5110-BUILD-RT-KEY.
      *
022837     INITIALIZE                   WRT-KEY.
           MOVE WDUPL-KEY-RT-LOAD-PTR TO WRT-RTBL-ID.
008454     MOVE WDUPL-KEY-RT-TYP-CD   TO WRT-RTBL-RT-TYP-CD.
           MOVE WDUPL-KEY-RT-SMOKER   TO WRT-RTBL-SMKR-CD.
           MOVE WDUPL-KEY-RT-PAR      TO WRT-RTBL-PAR-CD.
           MOVE WDUPL-KEY-RT-SEX      TO WRT-RTBL-SEX-CD.
           MOVE WDUPL-KEY-RT-TABLE-1  TO WRT-RTBL-STBL-1-CD.
           MOVE WDUPL-KEY-RT-TABLE-2  TO WRT-RTBL-STBL-2-CD.
           MOVE WDUPL-KEY-RT-TABLE-3  TO WRT-RTBL-STBL-3-CD.
           MOVE WDUPL-KEY-RT-TABLE-4  TO WRT-RTBL-STBL-4-CD.
010302*    MOVE WDUPL-KEY-RT-CLOC     TO WRT-RTBL-CRNT-LOC-CD.
010302*    MOVE WDUPL-KEY-RT-LOC-GR   TO WRT-RTBL-LOC-GR-CD.
010302     MOVE WDUPL-KEY-RT-LOC-GR   TO WRT-LOC-GR-ID.
           MOVE WDUPL-KEY-RT-DBO      TO WRT-RTBL-DB-OPT-CD.
557691     MOVE WDUPL-KEY-RT-PQ-IND   TO WRT-RTBL-PNSN-QUALF-CD.
557767     MOVE WDUPL-KEY-RT-JT-IND   TO WRT-RTBL-JNT-LIFE-CD.
           MOVE WDUPL-KEY-RT-AGE      TO WRT-RTBL-AGE.
010314*    MOVE WDUPL-KEY-RT-DEP-TRM-MOS
010314*                               TO WRT-RTBL-DEP-TRM-MOS.
010314     MOVE WDUPL-KEY-RT-DEP-TRM-MOS
010314                                TO WRT-DPOS-TRM-MO-DUR.
010314*    MOVE WDUPL-KEY-RT-DEP-TRM-DYS
010314*                               TO WRT-RTBL-DEP-TRM-DYS.
010314     MOVE WDUPL-KEY-RT-DEP-TRM-DYS
010314                                TO WRT-DPOS-TRM-DY-DUR.
012525     MOVE WDUPL-KEY-RT-MAT-XPRY-DUR
012525                                TO WRT-RTBL-MAT-XPRY-DUR.
           MOVE L1660-INVERTED-DATE   TO WRT-RTBL-IDT-NUM-N.
022837*    MOVE WRT-KEY               TO WDUPL-KEY-ALL.
022837*    MOVE WDUPL-KEY-ALL         TO RRT-KEY.
022837     MOVE WRT-KEY               TO RRT-KEY.
      *
       5110-BUILD-RT-KEY-X.
           EXIT.
008454
008454 5115-GET-HIGH-AGE-DUR.
008454        MOVE WRT-KEY            TO WRT-ENDBR-KEY
008454        MOVE 999                TO WRT-RTBL-AGE-DUR
008454        MOVE 0                  TO WRT-ENDBR-RTBL-AGE-DUR
008454        PERFORM RT-1000-BROWSE-PREV
008454            THRU RT-1000-BROWSE-PREV-X
008454        MOVE WRT-IO-STATUS      TO SW-END-OF-FILE
008454
008454        PERFORM RT-2000-READ-PREV
008454            THRU RT-2000-READ-PREV-X
008454        MOVE WRT-IO-STATUS      TO SW-END-OF-FILE
008454        MOVE WRT-RTBL-AGE-DUR   TO WS-HIGH-AGE-DUR
008454        PERFORM RT-3000-END-BROWSE-PREV
008454            THRU RT-3000-END-BROWSE-PREV-X
008454        MOVE WRT-IO-STATUS      TO SW-END-OF-FILE.
008454
008454 5115-GET-HIGH-AGE-DUR-X.
008454     EXIT.
008454
      *
       5120-VALIDATE-RT-KEY.
      *
           PERFORM  5121-VALIDATE-RT-PTR
               THRU 5121-VALIDATE-RT-PTR-X.
           PERFORM  5122-VALIDATE-RT-SMOKER-CD
               THRU 5122-VALIDATE-RT-SMOKER-CD-X.
           PERFORM  5123-VALIDATE-RT-PAR-CD
               THRU 5123-VALIDATE-RT-PAR-CD-X.
           PERFORM  5124-VALIDATE-RT-SEX-CD
               THRU 5124-VALIDATE-RT-SEX-CD-X.
           PERFORM  5125-VALIDATE-RT-STB1
               THRU 5125-VALIDATE-RT-STB1-X.
           PERFORM  5126-VALIDATE-RT-STB2
               THRU 5126-VALIDATE-RT-STB2-X.
           PERFORM  5127-VALIDATE-RT-STB3
               THRU 5127-VALIDATE-RT-STB3-X.
           PERFORM  5128-VALIDATE-RT-STB4
               THRU 5128-VALIDATE-RT-STB4-X.
010302*    PERFORM  5129-VALIDATE-RT-CLOC
010302*        THRU 5129-VALIDATE-RT-CLOC-X.
010302     PERFORM  5129-VALIDATE-RT-LOC-GR
010302         THRU 5129-VALIDATE-RT-LOC-GR-X.
           PERFORM  5130-VALIDATE-RT-DB-OPT
               THRU 5130-VALIDATE-RT-DB-OPT-X.
557691*    PERFORM  5131-VALIDATE-RT-ISS-AGE
557691*        THRU 5131-VALIDATE-RT-ISS-AGE-X.
557691*    PERFORM  5132-VALIDATE-RT-EFF-DATE
557691*        THRU 5132-VALIDATE-RT-EFF-DATE-X.
557691     PERFORM  5131-VALIDATE-RT-PQ-IND
557691         THRU 5131-VALIDATE-RT-PQ-IND-X.
557767     PERFORM  5132-VALIDATE-RT-JT
557767         THRU 5132-VALIDATE-RT-JT-X.
557691     PERFORM  5133-VALIDATE-RT-ISS-AGE
557691         THRU 5133-VALIDATE-RT-ISS-AGE-X.
557691     PERFORM  5134-VALIDATE-RT-EFF-DATE
557691         THRU 5134-VALIDATE-RT-EFF-DATE-X.
010314     PERFORM  5135-VALIDATE-RT-DEP-TRM
010314         THRU 5135-VALIDATE-RT-DEP-TRM-X.
012525     PERFORM  5136-VALIDAT-RT-MAT-XPRY-DUR
012525         THRU 5136-VALIDAT-RT-MAT-XPRY-DUR-X.
      *
       5120-VALIDATE-RT-KEY-X.
           EXIT.
      *
       5121-VALIDATE-RT-PTR.
      *
           IF WDUPL-KEY-RT-LOAD-PTR = 'XXXXXX'
      *        MSG: RT POINTER CANNOT = 'XXXXXX'
               MOVE 'NS01200067'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       5121-VALIDATE-RT-PTR-X.
           EXIT.
      *
       5122-VALIDATE-RT-SMOKER-CD.
      *
           MOVE WDUPL-KEY-RT-SMOKER   TO WS-EDIT-SMOKERS.
           IF WS-VALID-SMOKER
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: INVALID SMOKER CODE - USE S, N, C, U, OR SPACES
               MOVE 'NS01200089'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       5122-VALIDATE-RT-SMOKER-CD-X.
           EXIT.
      *
       5123-VALIDATE-RT-PAR-CD.
      *
           MOVE WDUPL-KEY-RT-PAR      TO WS-EDIT-PAR.
           IF WS-VALID-RT-PAR
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: INVALID PAR CODE - USE P, N, OR SPACES
               MOVE 'NS01200068'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       5123-VALIDATE-RT-PAR-CD-X.
           EXIT.
      *
       5124-VALIDATE-RT-SEX-CD.
      *
           MOVE WDUPL-KEY-RT-SEX      TO WS-EDIT-SEX.
           IF WS-VALID-RT-SEX
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: INVALID SEX CODE - USE M, F, J OR SPACES
               MOVE 'NS01200069'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       5124-VALIDATE-RT-SEX-CD-X.
           EXIT.
      *
       5125-VALIDATE-RT-STB1.
      *
           IF WDUPL-KEY-RT-TABLE-1 NOT = SPACES
               MOVE WDUPL-KEY-RT-TABLE-1
                                      TO WEDIT-ETBL-VALU-ID
               PERFORM  STB1-1000-EDIT-SUB-TABLE-1
                   THRU STB1-1000-EDIT-SUB-TABLE-1-X
               IF WEDIT-IO-OK
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *            MSG: SUB TABLE 1 MUST BE ON EDIT TYPE 'STB1'
                   MOVE 'NS01200051'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-TO-KEY-NOT-VALID TO TRUE
               END-IF
           END-IF.
      *
       5125-VALIDATE-RT-STB1-X.
           EXIT.
      *
       5126-VALIDATE-RT-STB2.
      *
           IF WDUPL-KEY-RT-TABLE-2 NOT = SPACES
               MOVE WDUPL-KEY-RT-TABLE-2
                                      TO WEDIT-ETBL-VALU-ID
               PERFORM  STB2-1000-EDIT-SUB-TABLE-2
                   THRU STB2-1000-EDIT-SUB-TABLE-2-X
               IF WEDIT-IO-OK
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *            MSG: SUB TABLE 2 MUST BE ON EDIT TYPE 'STB2'
                   MOVE 'NS01200052'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-TO-KEY-NOT-VALID TO TRUE
               END-IF
           END-IF.
      *
       5126-VALIDATE-RT-STB2-X.
           EXIT.
      *
       5127-VALIDATE-RT-STB3.
      *
           IF WDUPL-KEY-RT-TABLE-3 NOT = SPACES
               MOVE WDUPL-KEY-RT-TABLE-3
                                      TO WEDIT-ETBL-VALU-ID
               PERFORM  STB3-1000-EDIT-SUB-TABLE-3
                   THRU STB3-1000-EDIT-SUB-TABLE-3-X
               IF WEDIT-IO-OK
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *            MSG: SUB TABLE 3 MUST BE ON EDIT TYPE 'STB3'
                   MOVE 'NS01200053'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-TO-KEY-NOT-VALID TO TRUE
               END-IF
           END-IF.
      *
       5127-VALIDATE-RT-STB3-X.
           EXIT.
      *
       5128-VALIDATE-RT-STB4.
      *
           IF WDUPL-KEY-RT-TABLE-4 NOT = SPACES
               MOVE WDUPL-KEY-RT-TABLE-4
                                      TO WEDIT-ETBL-VALU-ID
               PERFORM  STB4-1000-EDIT-SUB-TABLE-4
                   THRU STB4-1000-EDIT-SUB-TABLE-4-X
               IF WEDIT-IO-OK
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *            MSG: SUB TABLE 4 MUST BE ON EDIT TYPE 'STB4'
                   MOVE 'NS01200054'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-TO-KEY-NOT-VALID TO TRUE
               END-IF
           END-IF.
      *
       5128-VALIDATE-RT-STB4-X.
           EXIT.
      *
010302*5129-VALIDATE-RT-CLOC.
      *
010302*    IF WDUPL-KEY-RT-CLOC NOT = SPACES
010302*        MOVE WDUPL-KEY-RT-CLOC      TO WEDIT-ETBL-VALU-ID
010302*        PERFORM CLOC-1000-EDIT-CURR-LOCATION
010302*           THRU CLOC-1000-EDIT-CURR-LOCATION-X
010302*        IF WEDIT-IO-OK
010302*            NEXT SENTENCE
010302*        ELSE
010302*            MSG: CURRENT LOCATION MUST BE ON EDIT TYPE 'CLOC'
010302*            MOVE 'NS01200070'       TO WGLOB-MSG-REF-INFO
010302*            PERFORM  0260-1000-GENERATE-MESSAGE
010302*                THRU 0260-1000-GENERATE-MESSAGE-X
010302*            SET WS-TO-KEY-NOT-VALID TO TRUE
010302*        END-IF
010302*    END-IF.
010302*
010302*5129-VALIDATE-RT-CLOC-X.
010302*    EXIT.
010302*
010302 5129-VALIDATE-RT-LOC-GR.
010302*
010302     IF WDUPL-KEY-RT-LOC-GR NOT = SPACES
010302         MOVE WDUPL-KEY-RT-LOC-GR
                                      TO WEDIT-ETBL-VALU-ID
010302         PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
010302             THRU LCGP-1000-EDIT-LCGP-LOCATION-X
010302         IF WEDIT-IO-OK
010302             CONTINUE
010302         ELSE
010302*            MSG: LOCATION MUST BE ON EDIT/LOCGP TABLE'
010302             MOVE 'NS01200099'  TO WGLOB-MSG-REF-INFO
010302             PERFORM  0260-1000-GENERATE-MESSAGE
010302                 THRU 0260-1000-GENERATE-MESSAGE-X
010302             SET WS-TO-KEY-NOT-VALID TO TRUE
010302         END-IF
010302     END-IF.
010302*
010302 5129-VALIDATE-RT-LOC-GR-X.
010302     EXIT.
010302*
       5130-VALIDATE-RT-DB-OPT.
      *
           MOVE WDUPL-KEY-RT-DBO      TO WS-DB-OPT-TYPE.
           IF WS-VALID-DB-OPT
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: VALID DB OPTIONS ARE 1, 2, A, B, I, L, OR SPACES
               MOVE 'NS01200071'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       5130-VALIDATE-RT-DB-OPT-X.
           EXIT.
      *
557691 5131-VALIDATE-RT-PQ-IND.
557691*
557691     MOVE WDUPL-KEY-RT-PQ-IND   TO WS-EDIT-PQ.
557691     IF WS-VALID-PQ
034802*        NEXT SENTENCE
034802         CONTINUE
557691     ELSE
557691*MSG: PENSION QUALIFIER MUST BE C D I F K O S T AND BLANK
557691         MOVE 'NS01200059'      TO WGLOB-MSG-REF-INFO
557691         PERFORM  0260-1000-GENERATE-MESSAGE
557691             THRU 0260-1000-GENERATE-MESSAGE-X
557691         SET WS-TO-KEY-NOT-VALID TO TRUE
557691     END-IF.
557691*
557691 5131-VALIDATE-RT-PQ-IND-X.
557691     EXIT.
557691*
557767 5132-VALIDATE-RT-JT.
557767*
557767     MOVE WDUPL-KEY-RT-JT-IND   TO WS-EDIT-JT.
557767     IF WS-VALID-JT
034802*        NEXT SENTENCE
034802         CONTINUE
557767     ELSE
557767*        MSG: VALID DB OPTIONS ARE L F AND BLANK
557767         MOVE 'NS01200090'      TO WGLOB-MSG-REF-INFO
557767         PERFORM  0260-1000-GENERATE-MESSAGE
557767             THRU 0260-1000-GENERATE-MESSAGE-X
557767         SET WS-TO-KEY-NOT-VALID TO TRUE
557767     END-IF.
557767*
557767 5132-VALIDATE-RT-JT-X.
557767     EXIT.
557767*
557691*5131-VALIDATE-RT-ISS-AGE.
557691 5133-VALIDATE-RT-ISS-AGE.
      *
      *    VERIFY ISSUE AGE IS NUMERIC OR BLANK.
      *
           IF WDUPL-KEY-RT-AGE = SPACES
557691*        GO TO 5131-VALIDATE-RT-ISS-AGE-X
557691         GO TO 5133-VALIDATE-RT-ISS-AGE-X
           END-IF.

           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE 3                     TO  L0280-LENGTH.
           MOVE ZERO                  TO  L0280-PRECISION.
           MOVE 'N'                   TO  L0280-SPACE-PERMITTED-IND.
           MOVE 3                     TO  L0280-INPUT-SIZE.
           MOVE WDUPL-KEY-RT-AGE      TO  L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: RT ISSUE AGE MUST BE NUMERIC OR SPACES
               MOVE 'NS01200072'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
557691*5131-VALIDATE-RT-ISS-AGE-X.
557691 5133-VALIDATE-RT-ISS-AGE-X.
           EXIT.
      *
557691*5132-VALIDATE-RT-EFF-DATE.
557691 5134-VALIDATE-RT-EFF-DATE.
      *
           MOVE WDUPL-KEY-RT-DATE     TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
           ELSE
      *        RT EFF DATE MUST BE VALID IN DDMMMYYYY FORMAT
               MOVE 'NS01200073'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID  TO TRUE
           END-IF.
      *
557691*5132-VALIDATE-RT-EFF-DATE-X.
557691 5134-VALIDATE-RT-EFF-DATE-X.
           EXIT.

010314*
010314 5135-VALIDATE-RT-DEP-TRM.
010314*
010314     IF WDUPL-KEY-RT-DEP-TRM-MOS NOT NUMERIC
010314*MSG:    RT DEPOSIT TERM MONTHS MUST BE NUMERIC
010314         MOVE 'NS01200103'      TO WGLOB-MSG-REF-INFO
010314         PERFORM  0260-1000-GENERATE-MESSAGE
010314             THRU 0260-1000-GENERATE-MESSAGE-X
010314         SET WS-TO-KEY-NOT-VALID  TO TRUE
010314     END-IF.
010314*
010314     IF WDUPL-KEY-RT-DEP-TRM-DYS NOT NUMERIC
010314*MSG:    RT DEPOSIT TERM MONTHS MUST BE NUMERIC
010314         MOVE 'NS01200104'      TO WGLOB-MSG-REF-INFO
010314         PERFORM  0260-1000-GENERATE-MESSAGE
010314             THRU 0260-1000-GENERATE-MESSAGE-X
010314         SET WS-TO-KEY-NOT-VALID  TO TRUE
010314     END-IF.
010314*
010314
010314 5135-VALIDATE-RT-DEP-TRM-X.
010314     EXIT.

012525*
012525 5136-VALIDAT-RT-MAT-XPRY-DUR.
012525*
012525     IF WDUPL-KEY-RT-MAT-XPRY-DUR NOT NUMERIC
012525*MSG:    RT COVERAGE TERM MUST BE NUMERIC
012525         MOVE 'NS01200106'        TO WGLOB-MSG-REF-INFO
012525         PERFORM  0260-1000-GENERATE-MESSAGE
012525             THRU 0260-1000-GENERATE-MESSAGE-X
012525         SET WS-TO-KEY-NOT-VALID  TO TRUE
012525     END-IF.
012525*
012525 5136-VALIDAT-RT-MAT-XPRY-DUR-X.
012525     EXIT.
012525*
      /
008454*
008454 5160-WRITE-RT-RECORD.
008454        MOVE WS-WRT-KEY         TO WRT-KEY.
008454        COMPUTE WS-STEP-AGE-DUR = WS-LOW-AGE-DUR + SUB + 1
008454        MOVE WS-STEP-AGE-DUR    TO WRT-RTBL-AGE-DUR.
008454        MOVE WRT-RTBL-AGE-DUR   TO WS-DUPL-AGE-DUR.
008454        PERFORM  RT-1000-READ
008454            THRU RT-1000-READ-X.
008454
008454        IF WRT-IO-EOF
008454            MOVE 'NS01200065'   TO WGLOB-MSG-REF-INFO
008454            MOVE WS-LINE        TO WGLOB-MSG-PARM (1)
008454            PERFORM  0260-1000-GENERATE-MESSAGE
008454                THRU 0260-1000-GENERATE-MESSAGE-X
008454            SET WS-FROM-KEY-NOT-VALID TO TRUE
008454            PERFORM  RT-3000-END-BROWSE
008454                THRU RT-3000-END-BROWSE-X
008454            GO TO 5160-WRITE-RT-RECORD-X
008454        END-IF.
008454
008454*       MOVE RRT-REC-INFO TO WS-RT-REC-INFO.
022837*       MOVE WDUPL-KEY-ALL      TO WRT-KEY.
022837        PERFORM  5110-BUILD-RT-KEY
022837            THRU 5110-BUILD-RT-KEY-X.
022837
008454        MOVE WS-DUPL-AGE-DUR    TO WRT-RTBL-AGE-DUR.
008454        PERFORM RT-1000-WRITE
008454           THRU RT-1000-WRITE-X.
008454        ADD 1 TO SUB.
008454
008454
008454
008454 5160-WRITE-RT-RECORD-X.
008454         EXIT.
      /
       5200-DUPL-UM.
      *
      *  EDIT FROM KEY
      *  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
      *  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
      *
           MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
           MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-UWMX.
           PERFORM  5210-BUILD-UM-KEY
               THRU 5210-BUILD-UM-KEY-X.

           PERFORM  UWMX-1000-READ
               THRU UWMX-1000-READ-X.
           IF WUWMX-IO-NOT-FOUND
      *        MSG: UWMX FROM KEY ON LINE (@1) DOES NOT EXIST
               MOVE 'NS01200074'      TO WGLOB-MSG-REF-INFO
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-FROM-KEY-NOT-VALID TO TRUE
               GO TO 5200-DUPL-UM-X
           END-IF.
      *
      *  FROM RECORD EXISTS - SAVE RECORD
      *
023118*    MOVE RUWMX-REC-INFO        TO WS-UWMX-REC-INFO.
023118     MOVE RUWMX-REC-INFO        TO HUWMX-REC-INFO.
      *
      *  MOVE COMPANY CODE IF USING
      *
           IF WDUPL-COMPANY NOT = SPACES
               MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
           END-IF.
      *
      *  EDIT TO KEY
      *
           MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
                                      TO WDUPL-KEY-UWMX.
           PERFORM  5220-VALIDATE-UM-KEY
               THRU 5220-VALIDATE-UM-KEY-X.
           IF WS-TO-KEY-NOT-VALID
               GO TO 5200-DUPL-UM-X
           END-IF.

           PERFORM  5210-BUILD-UM-KEY
               THRU 5210-BUILD-UM-KEY-X.
           PERFORM  UWMX-1000-READ
               THRU UWMX-1000-READ-X.
           IF WUWMX-IO-OK
      *        MSG: UWMX TO KEY ON LINE (@1) ALREADY EXISTS
               MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
               MOVE 'NS01200075'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
               GO TO 5200-DUPL-UM-X
           END-IF.
      *
      *  EVERYTHING IS OK - DUPLICATE UWMX RECORD
      *
023118*    MOVE WS-UWMX-REC-INFO      TO RUWMX-REC-INFO.
023118     MOVE HUWMX-REC-INFO        TO RUWMX-REC-INFO.
           MOVE WDUPL-KEY-ALL         TO RUWMX-KEY.
           MOVE WDUPL-KEY-ALL         TO WUWMX-KEY.
      *
           PERFORM  UWMX-1000-WRITE
               THRU UWMX-1000-WRITE-X.
      *
       5200-DUPL-UM-X.
           EXIT.
      *
       5210-BUILD-UM-KEY.
      *
557659*    MOVE WDUPL-KEY-UWMX-NUMBER TO  WUWMX-CCAS-TST-NUM.
557659*    MOVE WDUPL-KEY-UWMX-SUFFIX TO  WUWMX-CCAS-TST-SFX.
557659     MOVE WDUPL-KEY-UWMX-NUMBER TO  WUWMX-CCAS-TST-ID.
557659     MOVE WDUPL-KEY-UWMX-SUFFIX TO  WUWMX-CCAS-TST-SUBSET-ID.
           MOVE WUWMX-KEY             TO  WDUPL-KEY-ALL.
      *
       5210-BUILD-UM-KEY-X.
           EXIT.
      *
       5220-VALIDATE-UM-KEY.
      *
      * TEST NUMBER MUST BE NUMERIC.
      *
           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE 4                     TO  L0280-LENGTH.
           MOVE ZERO                  TO  L0280-PRECISION.
           MOVE WDUPL-KEY-UWMX-NUMBER TO  L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: TO-KEY TEST NUMBER MUST BE NUMERIC
               MOVE 'NS01200076'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
      * TEST SUFFIX MUST BE ALPHABETIC.
      *
557698     PERFORM  0005-1000-BUILD-PARM-INFO
557698         THRU 0005-1000-BUILD-PARM-INFO-X.
557698     MOVE WDUPL-KEY-UWMX-SUFFIX TO L0005-INPUT-STRING.
557698
557698     PERFORM  0005-2000-CONVERT-NO-ACCENTS
557698         THRU 0005-2000-CONVERT-NO-ACCENTS-X.
557698     IF L0005-RETRN-OK
557698         MOVE L0005-OUTPUT-STRING
                                      TO WDUPL-KEY-UWMX-SUFFIX
557698     END-IF.
           IF WDUPL-KEY-UWMX-SUFFIX ALPHABETIC
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: TO-KEY TEST SUBSET MUST BE ALPHABETIC
               MOVE 'NS01200077'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-TO-KEY-NOT-VALID TO TRUE
           END-IF.
      *
       5220-VALIDATE-UM-KEY-X.
           EXIT.
      *
022730*5300-DUPL-UV.
022730*
022730*  EDIT FROM KEY
022730*  SET UP COMPANY CODE IN CASE THE TO-KEY IS USING A
022730*  DIFFERENT COMPANY CODE (AND WE HAVE RESET WGLOB-COMPANY-CODE)
022730*
022730*    MOVE WS-COMPANY-CODE       TO WGLOB-COMPANY-CODE.
022730*    MOVE MIR-DV-RQST-KEY-1-TXT-T (WS-LINE)
022730*                               TO WDUPL-KEY-UV.
022730*    PERFORM  5310-BUILD-UV-KEY
022730*        THRU 5310-BUILD-UV-KEY-X.
022730*
022730*    PERFORM  UV-1000-READ
022730*        THRU UV-1000-READ-X.
022730*    IF WUV-IO-NOT-FOUND
022730*        MSG: UV FROM KEY ON LINE (@1) DOES NOT EXIST
022730*        MOVE 'NS01200078'      TO WGLOB-MSG-REF-INFO
022730*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
022730*        PERFORM  0260-1000-GENERATE-MESSAGE
022730*            THRU 0260-1000-GENERATE-MESSAGE-X
022730*        SET WS-FROM-KEY-NOT-VALID TO TRUE
022730*        GO TO 5300-DUPL-UV-X
022730*    END-IF.
022730*
022730*  FROM RECORD EXISTS - SAVE RECORD
022730*
022730*    MOVE RUV-REC-INFO          TO WS-UV-REC-INFO.
022730*
022730*  MOVE COMPANY CODE IF USING
022730*
022730*    IF WDUPL-COMPANY NOT = SPACES
022730*        MOVE WDUPL-COMPANY     TO WGLOB-COMPANY-CODE
022730*    END-IF.
022730*
022730*  EDIT TO KEY
022730*
022730*    MOVE MIR-DV-RQST-KEY-2-TXT-T (WS-LINE)
022730*                               TO WDUPL-KEY-UV.
022730*    PERFORM  5320-VALIDATE-UV-KEY
022730*        THRU 5320-VALIDATE-UV-KEY-X.
022730*    IF WS-TO-KEY-NOT-VALID
022730*        GO TO 5300-DUPL-UV-X
022730*    END-IF.
022730*
022730*    PERFORM  5310-BUILD-UV-KEY
022730*        THRU 5310-BUILD-UV-KEY-X.
022730*    PERFORM  UV-1000-READ
022730*        THRU UV-1000-READ-X.
022730*    IF WUV-IO-OK
022730*        MSG: UV TO KEY ON LINE (@1) ALREADY EXISTS
022730*        MOVE WS-LINE           TO WGLOB-MSG-PARM (1)
022730*        MOVE 'NS01200079'      TO WGLOB-MSG-REF-INFO
022730*        PERFORM  0260-1000-GENERATE-MESSAGE
022730*            THRU 0260-1000-GENERATE-MESSAGE-X
022730*        SET WS-TO-KEY-NOT-VALID TO TRUE
022730*        GO TO 5300-DUPL-UV-X
022730*    END-IF.
022730*
022730*  EVERYTHING IS OK - DUPLICATE UWMX RECORD
022730*
022730*    MOVE WS-UV-REC-INFO        TO RUV-REC-INFO.
022730*    MOVE WDUPL-KEY-ALL         TO RUV-KEY.
022730*    MOVE WDUPL-KEY-ALL         TO WUV-KEY.
022730*
022730*    PERFORM  UV-1000-WRITE
022730*        THRU UV-1000-WRITE-X.
022730*
022730*5300-DUPL-UV-X.
022730*    EXIT.
022730*
022730*5310-BUILD-UV-KEY.
022730*
022730*    MOVE WDUPL-KEY-UV-CODE     TO WUV-UVAL-ID-PLAN.
022730*    MOVE WDUPL-KEY-UV-SCALE    TO WUV-UVAL-ID-RS.
022730*    MOVE WDUPL-KEY-UV-PLAN-ID  TO WUV-UVAL-ID.
022730*    MOVE WDUPL-KEY-UV-SMOKERS  TO WUV-UVAL-SMKR-CD.
022730*    MOVE WDUPL-KEY-UV-PAR      TO WUV-UVAL-PAR-CD.
022730*    MOVE WDUPL-KEY-UV-SEX      TO WUV-UVAL-SEX-CD.
022730*    MOVE WDUPL-KEY-UV-TABLE-1  TO WUV-UVAL-STBL-1-CD.
022730*    MOVE WDUPL-KEY-UV-TABLE-2  TO WUV-UVAL-STBL-2-CD.
022730*    MOVE WDUPL-KEY-UV-TABLE-3  TO WUV-UVAL-STBL-3-CD.
022730*    MOVE WDUPL-KEY-UV-TABLE-4  TO WUV-UVAL-STBL-4-CD.
022730*    MOVE WDUPL-KEY-UV-TYPE     TO WUV-UVAL-TYP-CD.
022730*    MOVE WDUPL-KEY-UV-AGE     TO WUV-UVAL-AGE-N.
022730*    MOVE WDUPL-KEY-UV-AGE      TO WUV-UVAL-AGE.
022730*    MOVE ZEROES                TO WUV-UVAL-STRT-DUR-N.
022730*    MOVE WUV-KEY               TO WDUPL-KEY-ALL.
022730*    MOVE WDUPL-KEY-ALL         TO RUV-KEY.
022730*
022730*5310-BUILD-UV-KEY-X.
022730*    EXIT.
022730*
022730*5320-VALIDATE-UV-KEY.
022730*
022730*    PERFORM  5321-VALIDATE-UV-CODE
022730*        THRU 5321-VALIDATE-UV-CODE-X.
022730*    PERFORM  5322-VALIDATE-UV-SMOKER-CD
022730*        THRU 5322-VALIDATE-UV-SMOKER-CD-X.
022730*    PERFORM  5323-VALIDATE-UV-PAR-CD
022730*        THRU 5323-VALIDATE-UV-PAR-CD-X.
022730*    PERFORM  5324-VALIDATE-UV-SEX-CD
022730*        THRU 5324-VALIDATE-UV-SEX-CD-X.
022730*    PERFORM  5325-VALIDATE-UV-STB1
022730*        THRU 5325-VALIDATE-UV-STB1-X.
022730*    PERFORM  5326-VALIDATE-UV-STB2
022730*        THRU 5326-VALIDATE-UV-STB2-X.
022730*    PERFORM  5327-VALIDATE-UV-STB3
022730*        THRU 5327-VALIDATE-UV-STB3-X.
022730*    PERFORM  5328-VALIDATE-UV-STB4
022730*        THRU 5328-VALIDATE-UV-STB4-X.
022730*    PERFORM  5329-VALIDATE-UV-REC-TYPE
022730*        THRU 5329-VALIDATE-UV-REC-TYPE-X.
022730*    PERFORM  5330-VALIDATE-UV-ISS-AGE
022730*        THRU 5330-VALIDATE-UV-ISS-AGE-X.
022730*
022730*5320-VALIDATE-UV-KEY-X.
022730*    EXIT.
022730*
022730*5321-VALIDATE-UV-CODE.
022730*
022730*    IF WDUPL-KEY-UV-CODE = SPACES
022730*    IF  WDUPL-KEY-UV-PLAN-ID = SPACES
022730*        MSG: UV CODE CANNOT BE SPACES
022730*        MOVE 'NS01200080'      TO WGLOB-MSG-REF-INFO
022730*        PERFORM  0260-1000-GENERATE-MESSAGE
022730*            THRU 0260-1000-GENERATE-MESSAGE-X
022730*        SET WS-TO-KEY-NOT-VALID TO TRUE
022730*    END-IF.
022730*
022730*5321-VALIDATE-UV-CODE-X.
022730*    EXIT.
022730*
022730*5322-VALIDATE-UV-SMOKER-CD.
022730*
022730*    MOVE WDUPL-KEY-UV-SMOKERS  TO WS-EDIT-SMOKERS.
022730*    IF WS-VALID-UV-SMOKER
022730*        NEXT SENTENCE
022730*    ELSE
022730*        MSG: INVALID SMOKER CODE -  USE S, N, C, OR U
022730*        MOVE 'NS01200087'      TO WGLOB-MSG-REF-INFO
022730*        PERFORM  0260-1000-GENERATE-MESSAGE
022730*            THRU 0260-1000-GENERATE-MESSAGE-X
022730*        SET WS-TO-KEY-NOT-VALID TO TRUE
022730*    END-IF.
022730*
022730*5322-VALIDATE-UV-SMOKER-CD-X.
022730*    EXIT.
022730*
022730*5323-VALIDATE-UV-PAR-CD.
022730*
022730*    MOVE WDUPL-KEY-UV-PAR      TO WS-EDIT-PAR.
022730*    IF WS-VALID-PAR
022730*        NEXT SENTENCE
022730*    ELSE
022730*        MSG: INVALID PAR CODE - USE P OR N
022730*        MOVE 'NS01200049'      TO WGLOB-MSG-REF-INFO
022730*        PERFORM  0260-1000-GENERATE-MESSAGE
022730*            THRU 0260-1000-GENERATE-MESSAGE-X
022730*        SET WS-TO-KEY-NOT-VALID TO TRUE
022730*    END-IF.
022730*
022730*5323-VALIDATE-UV-PAR-CD-X.
022730*    EXIT.
022730*
022730*5324-VALIDATE-UV-SEX-CD.
022730*
022730*    MOVE WDUPL-KEY-UV-SEX      TO WS-EDIT-SEX.
022730*    IF WS-VALID-SEX
022730*        NEXT SENTENCE
022730*    ELSE
022730*        MSG: INVALID SEX CODE - USE M, F, OR J
022730*        MOVE 'NS01200050'      TO WGLOB-MSG-REF-INFO
022730*        PERFORM  0260-1000-GENERATE-MESSAGE
022730*            THRU 0260-1000-GENERATE-MESSAGE-X
022730*        SET WS-TO-KEY-NOT-VALID TO TRUE
022730*    END-IF.
022730*
022730*5324-VALIDATE-UV-SEX-CD-X.
022730*    EXIT.
022730*
022730*5325-VALIDATE-UV-STB1.
022730*
022730*    IF WDUPL-KEY-UV-TABLE-1 NOT = SPACES
022730*        MOVE WDUPL-KEY-UV-TABLE-1
022730*                               TO WEDIT-ETBL-VALU-ID
022730*        PERFORM  STB1-1000-EDIT-SUB-TABLE-1
022730*            THRU STB1-1000-EDIT-SUB-TABLE-1-X
022730*        IF WEDIT-IO-OK
022730*            NEXT SENTENCE
022730*        ELSE
022730*            MSG: SUB TABLE 1 MUST BE ON EDIT TYPE 'STB1'
022730*            MOVE 'NS01200051'  TO WGLOB-MSG-REF-INFO
022730*            PERFORM  0260-1000-GENERATE-MESSAGE
022730*                THRU 0260-1000-GENERATE-MESSAGE-X
022730*            SET WS-TO-KEY-NOT-VALID TO TRUE
022730*        END-IF
022730*    END-IF.
022730*
022730*5325-VALIDATE-UV-STB1-X.
022730*    EXIT.
022730*
022730*5326-VALIDATE-UV-STB2.
022730*
022730*    IF WDUPL-KEY-UV-TABLE-2 NOT = SPACES
022730*        MOVE WDUPL-KEY-UV-TABLE-2
022730*                               TO WEDIT-ETBL-VALU-ID
022730*        PERFORM  STB2-1000-EDIT-SUB-TABLE-2
022730*            THRU STB2-1000-EDIT-SUB-TABLE-2-X
022730*        IF WEDIT-IO-OK
022730*            NEXT SENTENCE
022730*        ELSE
022730*            MSG: SUB TABLE 2 MUST BE ON EDIT TYPE 'STB2'
022730*            MOVE 'NS01200052'  TO WGLOB-MSG-REF-INFO
022730*            PERFORM  0260-1000-GENERATE-MESSAGE
022730*                THRU 0260-1000-GENERATE-MESSAGE-X
022730*            SET WS-TO-KEY-NOT-VALID TO TRUE
022730*        END-IF
022730*    END-IF.
022730*
022730*5326-VALIDATE-UV-STB2-X.
022730*    EXIT.
022730*
022730*5327-VALIDATE-UV-STB3.
022730*
022730*    IF WDUPL-KEY-UV-TABLE-3 NOT = SPACES
022730*        MOVE WDUPL-KEY-UV-TABLE-3
022730*                               TO WEDIT-ETBL-VALU-ID
022730*        PERFORM  STB3-1000-EDIT-SUB-TABLE-3
022730*            THRU STB3-1000-EDIT-SUB-TABLE-3-X
022730*        IF WEDIT-IO-OK
022730*            NEXT SENTENCE
022730*        ELSE
022730*            MSG: SUB TABLE 3 MUST BE ON EDIT TYPE 'STB3'
022730*            MOVE 'NS01200053'  TO WGLOB-MSG-REF-INFO
022730*            PERFORM  0260-1000-GENERATE-MESSAGE
022730*                THRU 0260-1000-GENERATE-MESSAGE-X
022730*            SET WS-TO-KEY-NOT-VALID TO TRUE
022730*        END-IF
022730*    END-IF.
022730*
022730*5327-VALIDATE-UV-STB3-X.
022730*    EXIT.
022730*
022730*5328-VALIDATE-UV-STB4.
022730*
022730*    IF WDUPL-KEY-UV-TABLE-4 NOT = SPACES
022730*        MOVE WDUPL-KEY-UV-TABLE-4
022730*                               TO WEDIT-ETBL-VALU-ID
022730*        PERFORM  STB4-1000-EDIT-SUB-TABLE-4
022730*            THRU STB4-1000-EDIT-SUB-TABLE-4-X
022730*        IF WEDIT-IO-OK
022730*            NEXT SENTENCE
022730*        ELSE
022730*            MSG: SUB TABLE 4 MUST BE ON EDIT TYPE 'STB4'
022730*            MOVE 'NS01200054'  TO WGLOB-MSG-REF-INFO
022730*            PERFORM  0260-1000-GENERATE-MESSAGE
022730*                THRU 0260-1000-GENERATE-MESSAGE-X
022730*            SET WS-TO-KEY-NOT-VALID TO TRUE
022730*        END-IF
022730*    END-IF.
022730*
022730*5328-VALIDATE-UV-STB4-X.
022730*    EXIT.
022730*
022730*5329-VALIDATE-UV-REC-TYPE.
022730*
022730*    MOVE SPACES                TO WEDIT-ETBL-VALU-ID.
022730*    MOVE WDUPL-KEY-UV-TYPE     TO WEDIT-ETBL-VALU-ID.
022730*    PERFORM  UVRC-1000-EDIT
022730*        THRU UVRC-1000-EDIT-X.
022730*    IF NOT WEDIT-IO-OK
022730*        MSG: UV RECORD TYPE MUST BE ON EDIT TYPE 'UVREC'
022730*        MOVE 'NS01200081'      TO WGLOB-MSG-REF-INFO
022730*        PERFORM  0260-1000-GENERATE-MESSAGE
022730*            THRU 0260-1000-GENERATE-MESSAGE-X
022730*        SET WS-TO-KEY-NOT-VALID TO TRUE
022730*    END-IF.
022730*
022730*5329-VALIDATE-UV-REC-TYPE-X.
022730*    EXIT.
022730*
022730*5330-VALIDATE-UV-ISS-AGE.
022730*
022730*    VERIFY ISSUE AGE IS NUMERIC.
022730*
022730*    MOVE 'N'                   TO  L0280-SIGN-IND.
022730*    MOVE 3                     TO  L0280-LENGTH.
022730*    MOVE ZERO                  TO  L0280-PRECISION.
022730*    MOVE 'N'                   TO  L0280-SPACE-PERMITTED-IND.
022730*    MOVE 3                     TO  L0280-INPUT-SIZE.
022730*    MOVE WDUPL-KEY-UV-AGE      TO  L0280-INPUT-DATA.
022730*
022730*    PERFORM 0280-1000-NUMERIC-EDIT
022730*       THRU 0280-1000-NUMERIC-EDIT-X.
022730*
022730*    IF L0280-OK
022730*        NEXT SENTENCE
022730*    ELSE
022730*        MSG: UV ISSUE AGE MUST BE NUMERIC
022730*        MOVE 'NS01200082'      TO WGLOB-MSG-REF-INFO
022730*        PERFORM  0260-1000-GENERATE-MESSAGE
022730*            THRU 0260-1000-GENERATE-MESSAGE-X
022730*        SET WS-TO-KEY-NOT-VALID TO TRUE
022730*    END-IF.
022730*
022730*5330-VALIDATE-UV-ISS-AGE-X.
022730*    EXIT.
022730*    /
       9100-BLANK-DATA-FIELDS.
      *
           MOVE SPACES                TO  MIR-DV-RQST-KEY-1-TXT-G.
           MOVE SPACES                TO  MIR-DV-RQST-KEY-2-TXT-G.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0005-0000-INIT-PARM-INFO
025970         THRU 0005-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0840-0000-INIT-PARM-INFO
025970         THRU 0840-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2490-0000-INIT-PARM-INFO
025970         THRU 2490-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                        WS-EDIT-FIELDS.
025970     INITIALIZE                        WS-HOLD-REC-INFO.
025970     INITIALIZE                        TASMB-TABLE-VALID.
025970     INITIALIZE                        WDUPL-WORK-AREA.
025970
025970     SET  WS-DEFAULT-TRANS-NAME        TO TRUE.
025970     SET  WS-DEFAULT-MAX-LINES         TO TRUE.
025970     SET  WS-DEFAULT-GENERIC-LOC       TO TRUE.
025970     SET  WS-DEFAULT-LOC-GROUP         TO TRUE.
023514
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  'EDIT' COPYBOOKS                                            *
      ****************************************************************
      *
006002*COPY CCPECLOC.
007685*COPY CCPEFRMT.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY CCPELANG.
010302 COPY CCPELCGP.
      *
       COPY CCPESTB1.
       COPY CCPESTB2.
       COPY CCPESTB3.
       COPY CCPESTB4.
      *
022730*COPY CCPEUVRC.
      /
       COPY NCPEASMP.
       COPY NCPEASMT.
       COPY CCPECOMP.
006002*COPY CCPEILOC.
       COPY NCPELABC.
       COPY NCPETSTN.
      /
       COPY XCPELANG.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      *
023447*COPY CCPPPFLY.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
557698 COPY XCPS0005.
557698 COPY XCPL0005.
557698/
018764*COPY XCCL0260.
018764 COPY XCPL0260.

025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
018764*COPY XCCL2490.
018764 COPY XCPL2490.
557756 COPY XCPS2490.
018764*COPY CCCL0840.
018764 COPY CCPL0840.
557667 COPY CCPS0840.
018764*COPY CCCL2435.
018764 COPY CCPL2435.
557667 COPY CCPS2435.

      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
016537*COPY CCPAAB.
       COPY CCPCAB.
      /
       COPY CCPAAG.
       COPY CCPNAG.
      /
       COPY CCPNEDIT.
      /
035251*COPY CCPAMD.
035251*COPY CCPNMD.
      /
007685*COPY CCPAPA.
007685*COPY CCPNPA.
      /
010649 COPY CCPAPBTM.
010649 COPY CCPBPBTM.
010649/
020467 COPY CCPAPBMF.
020467 COPY CCPBPBMF.
020467/
       COPY CCPAPD.
       COPY CCPNPD.
020475 COPY CCPAPDBG.
020475 COPY CCPBPDBG.
020475/
021691 COPY XCPAPCXT.
021691 COPY XCPBPCXT.
021691/
      /
010648 COPY CCPAPDIV.
010648 COPY CCPBPDIV.
010648/
023447*COPY CCPAPF.
023447*COPY CCPNPF.
      *
023447*COPY CCPAPFLN.
023447*COPY CCPBPFLN.
      /
       COPY CCPAPH.
       COPY CCPNPH.
      /
010302 COPY CCPAPLRT.
010302 COPY CCPBPLRT.
010302/
010304 COPY CCPAPNFO.
010304 COPY CCPBPNFO.
010304/
010302*COPY CCPAPR.
010302*COPY CCPNPR.
010418/
010418 COPY CCPNSCOM.
      /
010650 COPY CCPAPLGR.
010650 COPY CCPBPLGR.
010650/
023447*COPY CCPAPW.
023447*COPY CCPNPW.
      /
       COPY CCPARH.
       COPY CCPNRH.
      /
       COPY CCPART.
       COPY CCPNRT.
      /
       COPY CCPBRT.
       COPY CCPVRT.
      /
015290 COPY CCPBPLAR.
015290 COPY CCPAPLAR.
      /
022730*COPY CCPAUV.
022730*COPY CCPNUV.
      /
       COPY NCPAASMB.
       COPY NCPNASMB.
      /
023447*COPY NCPNDOCM.
007685/
       COPY NCPALABT.
       COPY NCPNLABT.
      /
       COPY NCPAUWMX.
       COPY NCPNUWMX.
      /
016537*COPY XCPNCTLC.
006002/
023447 COPY XCPNDOCM.
       COPY XCPAMSGS.
       COPY XCPNMSGS.
      /
       COPY XCPNXTAB.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM NSOM0120                     **
      *****************************************************************
