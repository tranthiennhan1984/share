      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7714.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7714                                         **
      **  REMARKS:  USRP - U.S. REPORTING TABLE LIST                 **
      **            THIS MODULE PERFORMS LIST FUNCTION ON USRP TABLE **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7714'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '7714'.
           05  WS-SUB                                PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY
025970*                                              VALUE 50.
           05  WS-NEXT-USRP-REC-IND                  PIC X.
               88 WS-USRP-REC-FOUND                  VALUE 'Y'.
               88 WS-USRP-REC-NOT-FOUND              VALUE 'N'.
           05  WS-USRP-SEQ-NUM                       PIC 9(4).
           05  WS-USRP-TAX-YR                        PIC 9(4).
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY.
025970         88 WS-MAX-LIST-LINES-DEFAULT          VALUE 50.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY XCWEBLCH.
       COPY CCWWINDX.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWUSRR.
       COPY CCFRUSRP.
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY CCWL0620.
       COPY CCWL2430.
028298 COPY CCWL2626.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL8960.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7714.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.


           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7714'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  5100-GET-CLI-NM
               THRU 5100-GET-CLI-NM-X.

           MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

           PERFORM  7000-BUILD-KEY
               THRU 7000-BUILD-KEY-X.

           PERFORM  USRR-1000-BROWSE
               THRU USRR-1000-BROWSE-X.

           SET WS-USRP-REC-NOT-FOUND  TO TRUE.
           PERFORM  5010-READ-NEXT-USRP
               THRU 5010-READ-NEXT-USRP-X
               UNTIL WS-USRP-REC-FOUND
               OR    WUSRR-IO-EOF.

           IF  WUSRR-IO-EOF
               PERFORM  USRR-3000-END-BROWSE
                   THRU USRR-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  5000-BROWSE-USRP
               THRU 5000-BROWSE-USRP-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WUSRR-IO-EOF.

           IF  WUSRR-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE

020874*        COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-TAX-YR
020874         MOVE RUSRP-USRP-TAX-YR       TO L0290-INPUT-V00
               MOVE 0                       TO L0290-PRECISION
               MOVE LENGTH OF MIR-USRP-SEQ-NUM
                                            TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA       TO MIR-USRP-TAX-YR

020874*        COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-SEQ-NUM
020874         MOVE RUSRP-USRP-SEQ-NUM      TO L0290-INPUT-V00
               MOVE 0                       TO L0290-PRECISION
               MOVE LENGTH OF MIR-USRP-SEQ-NUM
                                            TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA       TO MIR-USRP-SEQ-NUM
           END-IF.

           PERFORM  USRR-3000-END-BROWSE
               THRU USRR-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.

      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  4110-EDIT-POL-ID
               THRU 4110-EDIT-POL-ID-X.

           PERFORM  4120-EDIT-TAX-YR
               THRU 4120-EDIT-TAX-YR-X.

           PERFORM  4130-EDIT-SEQ-NUM
               THRU 4130-EDIT-SEQ-NUM-X.

           PERFORM  4140-EDIT-RETRN-TYP
               THRU 4140-EDIT-RETRN-TYP-X.


       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       4110-EDIT-POL-ID.
      *-----------------

           MOVE MIR-POL-ID           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
      *MSG:    POLICY (@1) DOES NOT EXIST
               MOVE 'CS77140001'  TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ID    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
           END-IF.

       4110-EDIT-POL-ID-X.
           EXIT.

      *-----------------
       4120-EDIT-TAX-YR.
      *-----------------

           MOVE MIR-USRP-TAX-YR             TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-TAX-YR   TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-USRP-TAX-YR
           ELSE
      *MSG: INVALID TAX REPORTING YEAR
               MOVE 'CS77140003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

      *    IF WS-USRP-TAX-YR = 0
      *MSG: INVALID TAX REPORTING YEAR
      *        MOVE 'CS77140003'            TO WGLOB-MSG-REF-INFO
      *        PERFORM  0260-1000-GENERATE-MESSAGE
      *            THRU 0260-1000-GENERATE-MESSAGE-X
      *        MOVE 1                       TO WGLOB-MSG-ERROR-SW
      *    END-IF.

       4120-EDIT-TAX-YR-X.
           EXIT.

      *------------------
       4130-EDIT-SEQ-NUM.
      *------------------

           MOVE MIR-USRP-SEQ-NUM      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-SEQ-NUM
                                            TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-USRP-SEQ-NUM
           ELSE
      *MSG: INVALID RECEIPT SEQUENCE NUMBER
               MOVE 'CS77140002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       4130-EDIT-SEQ-NUM-X.
           EXIT.


      *--------------------
       4140-EDIT-RETRN-TYP.
      *--------------------

           IF  MIR-USRP-RETRN-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES               TO MIR-USRP-RETRN-TYP-CD
           END-IF.

           IF  MIR-USRP-RETRN-TYP-CD = SPACE
               GO TO 4140-EDIT-RETRN-TYP-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'USRP-RETRN-TYP-CD'       TO L8960-AV-TBL-CD.
           MOVE MIR-USRP-RETRN-TYP-CD     TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID RETRUN TYPE
               MOVE 'CS77140004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       4140-EDIT-RETRN-TYP-X.
           EXIT.



      *-----------------
       5000-BROWSE-USRP.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           SET WS-USRP-REC-NOT-FOUND  TO TRUE.
           PERFORM  5010-READ-NEXT-USRP
               THRU 5010-READ-NEXT-USRP-X
               UNTIL WS-USRP-REC-FOUND
               OR    WUSRR-IO-EOF.

       5000-BROWSE-USRP-X.
           EXIT.

      *--------------------
       5010-READ-NEXT-USRP.
      *--------------------

           PERFORM  USRR-2000-READ-NEXT
               THRU USRR-2000-READ-NEXT-X.

           IF WUSRR-IO-EOF
              GO TO 5010-READ-NEXT-USRP-X
           END-IF.

           IF  MIR-USRP-RETRN-TYP-CD NOT = SPACE
           AND RUSRP-USRP-RETRN-TYP-CD NOT = MIR-USRP-RETRN-TYP-CD
               GO TO 5010-READ-NEXT-USRP-X
           END-IF.

           SET WS-USRP-REC-FOUND     TO TRUE.

       5010-READ-NEXT-USRP-X.
           EXIT.


      *----------------
       5100-GET-CLI-NM.
      *----------------

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           INITIALIZE L0620-INPUT-PARM-INFO.

           IF  L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
           END-IF.

           MOVE L2430-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME          TO MIR-DV-OWN-CLI-NM.

       5100-GET-CLI-NM-X.
           EXIT.

      /
      *---------------
       7000-BUILD-KEY.
      *---------------
    
           MOVE LOW-VALUE             TO WUSRR-KEY.
           MOVE HIGH-VALUE            TO WUSRR-ENDBR-KEY.
    
           MOVE MIR-POL-ID            TO WUSRR-POL-ID.
           MOVE WS-USRP-TAX-YR        TO WUSRR-USRP-TAX-YR.
           MOVE WS-USRP-SEQ-NUM       TO WUSRR-USRP-SEQ-NUM.
           MOVE WUSRR-KEY             TO WUSRR-ENDBR-KEY.
           MOVE +9999                 TO WUSRR-ENDBR-USRP-TAX-YR.
           MOVE +9999                 TO WUSRR-ENDBR-USRP-SEQ-NUM.
    
       7000-BUILD-KEY-X.
           EXIT.
      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-DV-OWN-CLI-NM.
           MOVE SPACES                 TO MIR-SBSDRY-CO-ID.
           MOVE SPACES                 TO MIR-USRP-RETRN-TYP-CD-G.
           MOVE SPACES                 TO MIR-USRP-TAX-YR-G.
           MOVE SPACES                 TO MIR-USRP-SEQ-NUM-G.
           MOVE SPACES                 TO MIR-USRP-PNSN-QUALF-CD-G.
           MOVE SPACES                 TO MIR-USRP-NM-LN-1-TXT-G.
           MOVE SPACES                 TO MIR-USRP-RPT-CD-G.


       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RUSRP-USRP-RETRN-TYP-CD
             TO MIR-USRP-RETRN-TYP-CD-T (WS-SUB).

           MOVE RUSRP-USRP-PNSN-QUALF-CD
             TO MIR-USRP-PNSN-QUALF-CD-T (WS-SUB).

           MOVE RUSRP-USRP-NM-LN-1-TXT
             TO MIR-USRP-NM-LN-1-TXT-T (WS-SUB).

           MOVE RUSRP-USRP-RPT-CD
             TO MIR-USRP-RPT-CD-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-TAX-YR.
020874     MOVE RUSRP-USRP-TAX-YR         TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-TAX-YR-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-USRP-TAX-YR-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-SEQ-NUM.
020874     MOVE RUSRP-USRP-SEQ-NUM        TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-SEQ-NUM-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-USRP-SEQ-NUM-T (WS-SUB).


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
       COPY CCPS2430.
       COPY CCPL2430.
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
       COPY XCPS8960.
       COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBUSRR.
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ****************************************************************
      *                  END OF PROGRAM CSOM7714                     *
      ****************************************************************
