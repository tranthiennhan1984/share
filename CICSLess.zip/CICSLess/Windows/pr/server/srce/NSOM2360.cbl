      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM2360.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM2360                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR MULTIPLE REQUIREMENTS.                       **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016056**  6.1       NEW FOR INGENIUM 6.1                             **
014221**  6.2       LOGICAL LOCKING                                  **
016387**  6.2       REMOVE CLIENT CONSOLIDATION                      **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025177**  6.5       PERFORM REQUIRES AN IMPERATIVE STATEMENT         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM2360'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '2360'.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '2360'.

           05  WS-VALIDATE-FAIL-SW           PIC X(01).
               88  WS-VALIDATE-FAIL          VALUE 'Y'.
               88  WS-VALIDATE-OKAY          VALUE 'N'.
025970*    05  WS-CLI-REQT-LIMIT             PIC 999  VALUE 50.
025970*    05  WS-POL-REQT-LIMIT             PIC 999  VALUE 20.
025970*    05  WS-POLICIES-MAX               PIC 999  VALUE 10.
025970*    05  WS-CLIENTS-MAX                PIC 999  VALUE 40.
           05  WS-LOOP-MAX                   PIC 999.
           05  WS-IDX                        PIC 999.
           05  WS-POL-IDX                    PIC 999.
           05  WS-CLI-IDX                    PIC 999.
           05  WS-PREV-POL-ID                PIC X(10).
           05  WS-PIC-Z                      PIC Z.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '2360'.
025970     05  WS-CLI-REQT-LIMIT             PIC 999.
025970         88  WS-DEFAULT-CLI-REQT-LIMIT           VALUE 50.
025970     05  WS-POL-REQT-LIMIT             PIC 999.
025970         88  WS-DEFAULT-POL-REQT-LIMIT           VALUE 20.
025970     05  WS-POLICIES-MAX               PIC 999.
025970         88  WS-DEFAULT-POLICIES-MAX             VALUE 10.
025970     05  WS-CLIENTS-MAX                PIC 999.
025970         88  WS-DEFAULT-CLIENTS-MAX              VALUE 40.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
021930*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.

016440 COPY CCFRCVG.
016440 COPY CCFWCVG.

       COPY CCFRCVGC.
       COPY CCFWCVGC.

       COPY CCFRCLI.
       COPY CCFWCLI.

       COPY CCFRRL.
       COPY CCFWRL.

       COPY NCFRREQT.
       COPY NCFWREQT.

       COPY NCFWRTAB.
       COPY NCFRRTAB.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY CCWLPGA.

021930*COPY CCWL0064.
       COPY CCWL0620.
       COPY CCWL2430.
       COPY CCWL5400.
       COPY CCWL5600.
       COPY NCWL2437.
014221 COPY XCWL8090.
       COPY XCWL1640.
020874 COPY XCWL0290.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY NCWM2360.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     IF  MIR-CLI-ID = SPACE
028298         PERFORM  FPCK-1000-CHECK-POLICY
028298             THRU FPCK-1000-CHECK-POLICY-X
028298     ELSE
028298         PERFORM  FCCK-1000-CHECK-CLIENT
028298             THRU FCCK-1000-CHECK-CLIENT-X
028298     END-IF.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

014221     MOVE ZEROS                 TO WLOCK-IDX.
014221     INITIALIZE                 WLOCK-MULT-TWRK-TS-TABLE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM2360'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  2100-VALIDATE-CONTROL-FIELDS
               THRU 2100-VALIDATE-CONTROL-FIELDS-X.

           IF  WS-VALIDATE-FAIL
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  MIR-CLI-ID NOT = SPACES
               PERFORM  3000-RETRIEVE-BY-CLIENT
                   THRU 3000-RETRIEVE-BY-CLIENT-X
           ELSE
               PERFORM  4000-RETRIEVE-BY-POLICY
                   THRU 4000-RETRIEVE-BY-POLICY-X
           END-IF.

       2000-RETRIEVE-X.
           EXIT.

      *-----------------------------
       2100-VALIDATE-CONTROL-FIELDS.
      *-----------------------------

      ***  ONE OF CLIENT OR POLICY MUST BE GIVEN.

           SET WS-VALIDATE-OKAY TO TRUE.

           IF (MIR-CLI-ID = SPACES) AND
              (MIR-POL-ID-BASE = SPACES) AND
              (MIR-POL-ID-SFX = SPACES)
      * MSG: EITHER CLIENT OR POLICY MUST BE ENTERED'
               MOVE 'NS23600001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-FAIL   TO TRUE
               GO TO 2100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

      ***  BOTH CLIENT AND POLICY CANNOT BE GIVEN.

           IF  (MIR-CLI-ID      NOT =  SPACES)
           AND (MIR-POL-ID-BASE NOT =  SPACES)
           AND (MIR-POL-ID-SFX  NOT =  SPACES)
      * MSG: ENTER EITHER CLIENT OR POLICY, BUT NOT BOTH
               MOVE 'NS23600002'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-FAIL TO TRUE
               GO TO 2100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

      ***  CHECK CLIENT / POLICY.

           IF  MIR-CLI-ID NOT =  SPACES
               PERFORM  2200-CHECK-CLIENT
                   THRU 2200-CHECK-CLIENT-X
           ELSE
               PERFORM  2210-CHECK-POLICY
                   THRU 2210-CHECK-POLICY-X
           END-IF.

       2100-VALIDATE-CONTROL-FIELDS-X.
           EXIT.

      *------------------
       2200-CHECK-CLIENT.
      *------------------

      ***  CHECK CONFIDENTIALITY.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.
016387*    SET L5600-CNSLDT-MSG-NOT-REQD         TO TRUE.
016387*    SET L5600-GEN-CNSLDT-MSG-ERROR        TO TRUE.
           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           IF  L5600-CNFD-ACCS-RESTRICTED
           OR  L5600-CCAS-ACCS-RESTRICTED
               SET WS-VALIDATE-FAIL              TO TRUE
           END-IF.

       2200-CHECK-CLIENT-X.
           EXIT.

      *------------------
       2210-CHECK-POLICY.
      *------------------

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
               MOVE MIR-POL-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-FAIL   TO TRUE
               GO TO 2210-CHECK-POLICY-X
           END-IF.

016440*    IF NOT RPOL-POL-APPL-CTL-NBS
016440*        MOVE 'XS00000239'      TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        IF  WGLOB-MSG-SEVRTY-FATAL
016440*            SET  WS-VALIDATE-FAIL TO TRUE
016440*            GO TO 2210-CHECK-POLICY-X
016440*        END-IF
016440*    END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
               SET WS-VALIDATE-FAIL  TO TRUE
               GO TO 2210-CHECK-POLICY-X
           END-IF.

           IF  L5400-BRCH-ACCS-RESTRICTED
               SET WS-VALIDATE-FAIL   TO TRUE
               GO TO 2210-CHECK-POLICY-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW     >  ZERO
               SET WS-VALIDATE-FAIL  TO TRUE
           END-IF.

       2210-CHECK-POLICY-X.
           EXIT.
      /
      *------------------------
       3000-RETRIEVE-BY-CLIENT.
      *------------------------

      * GET REQUIREMENTS BY CLIENT

           MOVE LOW-VALUES            TO WREQT-KEY.
           MOVE 'C'                   TO WREQT-CPREQ-POL-CLI-CD.
           MOVE MIR-CLI-ID            TO WREQT-CLI-ID.
           MOVE ZERO                  TO WREQT-CPREQ-SEQ-NUM.
           MOVE WREQT-KEY             TO WREQT-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WREQT-ENDBR-REQIR-ID.
           MOVE 999                   TO WREQT-ENDBR-CPREQ-SEQ-NUM.

           MOVE WS-CLI-REQT-LIMIT     TO WS-LOOP-MAX.
           PERFORM  5000-GET-REQUIREMENTS
               THRU 5000-GET-REQUIREMENTS-X.

      * GET POLICIES RELATED TO THE CLIENT

           MOVE LOW-VALUES            TO WRL-KEY.
           MOVE MIR-CLI-ID            TO WRL-CLI-ID.
016440*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
           MOVE WRL-KEY               TO WRL-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WRL-ENDBR-REL-SYS-REF-ID.
           MOVE HIGH-VALUES           TO WRL-ENDBR-REL-TYP-CD.

           PERFORM  RL-1000-BROWSE
               THRU RL-1000-BROWSE-X.

           IF  WRL-IO-OK

               MOVE LOW-VALUES        TO WS-PREV-POL-ID
               MOVE ZERO              TO WS-POL-IDX
               PERFORM  3100-GET-RELATED-POLICIES
                   THRU 3100-GET-RELATED-POLICIES-X
                   UNTIL   WS-POL-IDX >= WS-POLICIES-MAX
                   OR      NOT WRL-IO-OK

               PERFORM  RL-3000-END-BROWSE
                   THRU RL-3000-END-BROWSE-X
           END-IF.

           MOVE MIR-CLI-ID     TO L2437-CLI-ID.
           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           MOVE L2437-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM.
           MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM.
           MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM.
           MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM.
           MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-INSRD-CLI-NM.

       3000-RETRIEVE-BY-CLIENT-X.
           EXIT.

      *--------------------------
       3100-GET-RELATED-POLICIES.
      *--------------------------

016440* RELATED POLICIES ARE THOSE THAT ARE PENDING/REJECTED
016440* OR THOSE THAT ARE INFORCE WITH PENDING/REJECTED COVERAGES
016440* A COVERAGE READ IS NECESSARY TO DETERMINE WHICH POLICIES
016440* HAVE PENDING/REJECTED COVERAGES


           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

           IF  NOT WRL-IO-OK
               GO TO 3100-GET-RELATED-POLICIES-X
           END-IF.

           IF  RRL-REL-TYP-CD  NOT = 'I'
               GO TO 3100-GET-RELATED-POLICIES-X
           END-IF.

           IF  RRL-REL-SYS-REF-POL-ID NOT = WS-PREV-POL-ID
               MOVE RRL-REL-SYS-REF-POL-ID TO WPOL-POL-ID
               PERFORM  POL-1000-READ
                   THRU POL-1000-READ-X
               IF  WPOL-IO-OK
               AND (MIR-SERV-BR-ID = SPACE)
                   MOVE RPOL-SERV-BR-ID
                                           TO MIR-SERV-BR-ID
               END-IF
           END-IF.

016440     MOVE RRL-REL-SYS-REF-POL-ID  TO WCVG-POL-ID.
016440     MOVE RRL-REL-SYS-REF-CVG-NUM TO WCVG-CVG-NUM.
016440     PERFORM CVG-1000-READ
016440        THRU CVG-1000-READ-X.

           IF  NOT WPOL-IO-OK
               CONTINUE
           ELSE
016440*        IF  RRL-REL-SYS-REF-POL-ID NOT = WS-PREV-POL-ID
016440         IF  RCVG-CVG-STAT-BEFORE-SETL
                   ADD 1                   TO WS-POL-IDX
                   MOVE RRL-REL-SYS-REF-POL-ID (1:9)
                                           TO MIR-POL-ID-BASE-T
                                              (WS-POL-IDX)
                   MOVE RRL-REL-SYS-REF-POL-ID (10:1)
                                           TO MIR-POL-ID-SFX-T
                                              (WS-POL-IDX)
                   MOVE RPOL-POL-CSTAT-CD  TO MIR-POL-CSTAT-CD-T
                                              (WS-POL-IDX)
               END-IF
           END-IF.

           MOVE RRL-REL-SYS-REF-POL-ID TO WS-PREV-POL-ID.

       3100-GET-RELATED-POLICIES-X.
           EXIT.

      *------------------------
       4000-RETRIEVE-BY-POLICY.
      *------------------------

      * GET REQUIREMENTS BY POLICY

           MOVE LOW-VALUES            TO WREQT-KEY.
           MOVE 'P'                   TO WREQT-CPREQ-POL-CLI-CD.
           MOVE MIR-POL-ID            TO WREQT-POL-ID.
           MOVE ZERO                  TO WREQT-CPREQ-SEQ-NUM.
           MOVE WREQT-KEY             TO WREQT-ENDBR-KEY.
           MOVE HIGH-VALUE            TO WREQT-ENDBR-REQIR-ID.
           MOVE 999                   TO WREQT-ENDBR-CPREQ-SEQ-NUM.

           MOVE WS-POL-REQT-LIMIT     TO WS-LOOP-MAX.
           PERFORM  5000-GET-REQUIREMENTS
               THRU 5000-GET-REQUIREMENTS-X.

      * GET INSURED ON POLICY'S COVERAGES

           MOVE LOW-VALUES             TO WCVGC-KEY.
           MOVE MIR-POL-ID             TO WCVGC-POL-ID.
           MOVE HIGH-VALUES            TO WCVGC-ENDBR-KEY.
           MOVE MIR-POL-ID             TO WCVGC-ENDBR-POL-ID.
           PERFORM  CVGC-1000-BROWSE
               THRU CVGC-1000-BROWSE-X.

           IF  WCVGC-IO-OK
               PERFORM  CVGC-2000-READ-NEXT
                   THRU CVGC-2000-READ-NEXT-X
               PERFORM  4100-GET-ALL-INSURED
                   THRU 4100-GET-ALL-INSURED-X
                   UNTIL WCVGC-IO-EOF
               PERFORM  CVGC-3000-END-BROWSE
                   THRU CVGC-3000-END-BROWSE-X
           END-IF.

      * GET OWNER'S NAME

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID                 TO L2430-POL-ID.
           MOVE ZERO                          TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE                        L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
           END-IF.
           MOVE RPOL-SERV-BR-ID               TO MIR-SERV-BR-ID.
           MOVE RPOL-POL-CSTAT-CD             TO MIR-POL-CSTAT-CD.

       4000-RETRIEVE-BY-POLICY-X.
           EXIT.

      *---------------------
       4100-GET-ALL-INSURED.
      *---------------------

           PERFORM
               VARYING WS-CLI-IDX FROM 1 BY 1
               UNTIL   (RCVGC-INSRD-CLI-ID = MIR-CLI-ID-T (WS-CLI-IDX))
               OR      (WS-CLI-IDX > WS-CLIENTS-MAX)
               OR      (MIR-CLI-ID-T (WS-CLI-IDX) = SPACE)
025177         CONTINUE
           END-PERFORM.

           IF  MIR-CLI-ID-T (WS-CLI-IDX) = SPACE
               MOVE RCVGC-INSRD-CLI-ID TO MIR-CLI-ID-T (WS-CLI-IDX)

               MOVE RCVGC-INSRD-CLI-ID TO L2437-CLI-ID
               PERFORM  2437-1000-OBTAIN-CLI-INFO
                   THRU 2437-1000-OBTAIN-CLI-INFO-X

               MOVE L2437-CLI-SEX-CD      TO L0620-CLI-SEX-CD
               MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
               MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
               MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
               MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME     TO MIR-DV-INSRD-CLI-NM-T
                                             (WS-CLI-IDX)

               MOVE RCVGC-INSRD-CLI-ID    TO WCLI-CLI-ID
               PERFORM  CLI-1000-READ
                   THRU CLI-1000-READ-X

               IF  WCLI-IO-OK
                   MOVE RCLI-CLI-UWGDECN-CD TO MIR-CLI-UWGDECN-CD-T
                                               (WS-CLI-IDX)
               END-IF

               PERFORM  4200-SET-REQT-IND
                   THRU 4200-SET-REQT-IND-X

           END-IF.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       4100-GET-ALL-INSURED-X.
           EXIT.

      *------------------
       4200-SET-REQT-IND.
      *------------------

           MOVE 'N'                   TO MIR-DV-CLI-UWG-REQIR-IND-T
                                         (WS-CLI-IDX).
           MOVE LOW-VALUES            TO WREQT-KEY.
           MOVE 'C'                   TO WREQT-CPREQ-POL-CLI-CD.
           MOVE MIR-CLI-ID-T (WS-CLI-IDX)
                                      TO WREQT-CLI-ID.
           MOVE ZERO                  TO WREQT-CPREQ-SEQ-NUM.
           MOVE WREQT-KEY             TO WREQT-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WREQT-ENDBR-REQIR-ID.
           MOVE 999                   TO WREQT-ENDBR-CPREQ-SEQ-NUM.

           PERFORM  REQT-1000-BROWSE
               THRU REQT-1000-BROWSE-X.

           IF  NOT WREQT-IO-OK
               GO TO 4200-SET-REQT-IND-X
           END-IF.

           PERFORM  REQT-2000-READ-NEXT
               THRU REQT-2000-READ-NEXT-X.

           IF  WREQT-IO-OK
               MOVE 'Y'               TO MIR-DV-CLI-UWG-REQIR-IND-T
                                         (WS-CLI-IDX)
           END-IF.

           PERFORM  REQT-3000-END-BROWSE
               THRU REQT-3000-END-BROWSE-X.


       4200-SET-REQT-IND-X.
           EXIT.
      /
      *----------------------
       5000-GET-REQUIREMENTS.
      *----------------------

           PERFORM  REQT-1000-BROWSE
               THRU REQT-1000-BROWSE-X.

           IF  NOT WREQT-IO-OK
      * MSG : REQUIREMENT (@1) NOT FOUND
               MOVE 'NS23600003'   TO WGLOB-MSG-REF-INFO
               MOVE WREQT-REQIR-ID TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-GET-REQUIREMENTS-X
           END-IF.

014221*    PERFORM  REQT-2000-READ-NEXT
014221*        THRU REQT-2000-READ-NEXT-X.

014221     PERFORM  REQT-1000-READ-NEXT-MBTS-TS
014221         THRU REQT-1000-READ-NEXT-MBTS-TS-X.

           PERFORM  5100-GET-ALL-REQUIREMENTS
               THRU 5100-GET-ALL-REQUIREMENTS-X
               VARYING WS-IDX FROM 1 BY 1
               UNTIL   WS-IDX > WS-LOOP-MAX
               OR      NOT WREQT-IO-OK.

           PERFORM  REQT-3000-END-BROWSE
               THRU REQT-3000-END-BROWSE-X.

014221     PERFORM  REQT-2000-BUILD-MBTS-TWRK
014221         THRU REQT-2000-BUILD-MBTS-TWRK-X.


       5000-GET-REQUIREMENTS-X.
           EXIT.

      *--------------------------
       5100-GET-ALL-REQUIREMENTS.
      *--------------------------

           MOVE RREQT-CPREQ-STAT-CD   TO MIR-CPREQ-STAT-CD-T (WS-IDX).
           MOVE RREQT-USER-ID         TO MIR-USER-ID-T (WS-IDX).
           MOVE RREQT-CPREQ-DESGNT-ID TO MIR-CPREQ-DESGNT-ID-T
                                         (WS-IDX).
           MOVE RREQT-CPREQ-TST-RSLT-CD
                                      TO MIR-CPREQ-TST-RSLT-CD-T
                                         (WS-IDX).
           MOVE RREQT-CPREQ-PD-IND    TO MIR-CPREQ-PD-IND-T (WS-IDX).
           MOVE RREQT-CPREQ-NEW-RSLT-IND
                                      TO MIR-CPREQ-NEW-RSLT-IND-T
                                         (WS-IDX).
           MOVE 'N'                   TO MIR-DV-REVW-REQIR-IND-T
                                         (WS-IDX).
020874*    MOVE RREQT-CPREQ-FOLWUP-NUM   TO WS-PIC-Z.
020874*    MOVE WS-PIC-Z              TO MIR-CPREQ-FOLWUP-NUM-T
020874*                                  (WS-IDX).
020874     MOVE RREQT-CPREQ-FOLWUP-NUM TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CPREQ-FOLWUP-NUM-T (WS-IDX)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA  TO MIR-CPREQ-FOLWUP-NUM-T (WS-IDX).

           MOVE RREQT-CPREQ-CREAT-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-CREAT-DT-T
                                         (WS-IDX).

           MOVE RREQT-CPREQ-TST-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-TST-DT-T
                                         (WS-IDX).

           MOVE RREQT-CPREQ-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-EFF-DT-T
                                         (WS-IDX).

           MOVE RREQT-CPREQ-FOLWUP-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-FOLWUP-DT-T
                                         (WS-IDX).

           MOVE RREQT-CPREQ-VALID-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-VALID-DT-T
                                         (WS-IDX).

           MOVE RREQT-REQIR-ID        TO MIR-REQIR-ID-T (WS-IDX).
           MOVE RREQT-CPREQ-SEQ-NUM   TO MIR-CPREQ-SEQ-NUM-T
                                         (WS-IDX).

           MOVE RREQT-REQIR-ID        TO WRTAB-REQIR-ID.

           PERFORM  RTAB-1000-READ
               THRU RTAB-1000-READ-X.

           IF  NOT WRTAB-IO-OK
               MOVE SPACES              TO MIR-REQIR-TYP-CD-T (WS-IDX)
           ELSE
               MOVE RRTAB-REQIR-TYP-CD   TO MIR-REQIR-TYP-CD-T (WS-IDX)
           END-IF.

014221*    PERFORM  REQT-2000-READ-NEXT
014221*        THRU REQT-2000-READ-NEXT-X.

014221     PERFORM  REQT-1000-READ-NEXT-MBTS-TS
014221         THRU REQT-1000-READ-NEXT-MBTS-TS-X.

       5100-GET-ALL-REQUIREMENTS-X.
           EXIT.

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO  MIR-DV-INSRD-CLI-NM.
           MOVE SPACES                TO  MIR-DV-OWN-CLI-NM.
           MOVE SPACES                TO  MIR-SERV-BR-ID.
           MOVE SPACES                TO  MIR-POL-CSTAT-CD.
           MOVE SPACES                TO  MIR-REQIR-ID-G
                                          MIR-CPREQ-SEQ-NUM-G
                                          MIR-CPREQ-STAT-CD-G
                                          MIR-REQIR-TYP-CD-G
                                          MIR-CPREQ-NEW-RSLT-IND-G
                                          MIR-DV-REVW-REQIR-IND-G
                                          MIR-CPREQ-CREAT-DT-G
                                          MIR-CPREQ-EFF-DT-G
                                          MIR-USER-ID-G
                                          MIR-CPREQ-DESGNT-ID-G
                                          MIR-CPREQ-TST-DT-G
                                          MIR-CPREQ-TST-RSLT-CD-G
                                          MIR-CPREQ-FOLWUP-NUM-G
                                          MIR-CPREQ-FOLWUP-DT-G
                                          MIR-CPREQ-PD-IND-G
                                          MIR-CPREQ-VALID-DT-G
                                          MIR-POL-ID-BASE-G
                                          MIR-POL-ID-SFX-G
                                          MIR-POL-CSTAT-CD-G
                                          MIR-DV-INSRD-CLI-NM-G
                                          MIR-CLI-ID-G
                                          MIR-CLI-UWGDECN-CD-G
                                          MIR-DV-CLI-UWG-REQIR-IND-G.


       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

           IF  MIR-POL-ID-BASE NOT = SPACES
           OR  MIR-POL-ID-SFX  NOT = SPACES
               MOVE 'P'               TO WGLOB-REF-POLICY-OR-CLIENT
               MOVE MIR-POL-ID-BASE   TO WGLOB-REF-POLICY-NUMBER
               MOVE MIR-POL-ID-SFX    TO WGLOB-REF-POLICY-SUFFIX
           ELSE

               IF  MIR-CLI-ID NOT = SPACES
                   MOVE 'C'           TO WGLOB-REF-POLICY-OR-CLIENT
                   MOVE MIR-CLI-ID    TO WGLOB-REF-CLIENT-NUMBER
               END-IF

           END-IF.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-WORKING-STORAGE.
025970     INITIALIZE                         FREQUENTLY-USED-INDICES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-CLI-REQT-LIMIT      TO TRUE.
025970     SET WS-DEFAULT-POL-REQT-LIMIT      TO TRUE.
025970     SET WS-DEFAULT-POLICIES-MAX        TO TRUE.
025970     SET WS-DEFAULT-CLIENTS-MAX         TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
025970 COPY XCPS8090.
       COPY CCPSPGA.
014221 COPY CCPPMBTS REPLACING ==:VAR1:== BY REQT
014221                             '$VAR2' BY 'REQT'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************

018764*COPY CCCL0064.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
021930*COPY CCPL0064.
021930*COPY CCPS0064.

018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS2430.

018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.

018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.

018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.

018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPNCLI.
       COPY CCPBRL.
016440 COPY CCPNCVG.
       COPY CCPBCVGC.
       COPY NCPBREQT.
014221 COPY NCPNREQT.
014221 COPY NCPUREQT.
       COPY NCPNRTAB.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************

025970 COPY CCPS0620.
       COPY CCPL0620.

026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM NSOM2360                        **
      *****************************************************************
