      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. CSOM0071.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  CSOM0071                                         **
      **  REMARKS:  ASIT - MAINTAIN AGENT SITUATION/OVERRIDE TABLES. **
      **            THIS PROGRAM WILL MAINTAIN THE AGENT SITUATION   **
      **            OR OVERRIDE FILE. THE AGENT'S OVERRIDE STRUCTURE **
      **            FOR EACH SITUATION APPLICABLE TO AN AGENT CAN BE **
      **            MAINTAINED. UP TO TEN LEVELS OF OVERRIDES ARE    **
      **            MAINTAINABLE WITH A SEPARATE COMMISSION PATTERN  **
      **            CODE FOR EACH OVERRIDE.                          **
      **  DOMAIN :  AG                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
557756**  5.5       ENHANCEMENTS FOR MULTI-LANGUAGE SUPPORT          **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
010519**  5.5.2     ADD MESSAGE TO INDICATE THE CORRECT VERIFY       **
010519**            CODE                                             **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEANUP                                     **
013578**  6.0       ELIMINATE SUPPORT OF CHARACTER INTERFACE         **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CORRECT STANDARDS VIOLATION                      **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
015710**  6.3       FIX MESSAGE WITH ASIT                            **
018542**  6.3       SUBSCRIPT OUT OF RANGE WHEN POPULATING MIR FIELDS**
018542**            FIELDS FOR SUBSEQUENT PAGE ON A LIST FCN. USE    **
018542**            DATABASE FIELD TO POPULATE MIR FIELDS.           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
019409**  6.4       OVERRIDE SITUATION                               **
023867**  6.5       AS/AG CROSS EDIT                                 **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
       CONFIGURATION SECTION.
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0071'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
014590*COPY XCWL0030.
014588*COPY CCWCCOMM.
014588*COPY CCWC0071.
008455 COPY XCWL0280.
008455 COPY XCWL0290.
       COPY XCWEBLCH.
       COPY CCWWAGOV.
014221 COPY CCWWLOCK.

       01  OTHER-WORK-AREAS.
           02  HOLD-INPUT-AREA.

008455*        03  WS-MAX-OR.
008455*            05 WS-MAX-OR-NO    PIC 9(5).
008455*            05 WS-MAX-OR-PT    PIC X.
008455*            05 WS-MAX-OR-DC    PIC V99.
008455*        03  WS-MAX-OR-R REDEFINES WS-MAX-OR.
008455*            05 WS-MAX-OR-NO-R  PIC 9(3).
008455*            05 WS-MAX-OR-PT-R  PIC X.
008455*            05 WS-MAX-OR-DC-R  PIC V9(4).
008455         03  WS-MAX-OR          PIC X(12).
008455         03  WS-MAX-OR-N        PIC S9(9)V9(2) COMP-3.
008455         03  WS-MAX-OR-R-N      PIC S9(7)V9(4) COMP-3.

           02  WS-ASAG-DATA-SW        PIC X(01).
               88  WS-ASAG-DATA-TO-WRITE    VALUE 'Y'.
               88  WS-ASAG-NO-DATA-TO-WRITE VALUE ' '.
           02  WS-ASAG-DATA-THIS-LINE PIC X(01)   OCCURS 10 TIMES.
           02  WS-ASAG-WRITE-SW       PIC X(01).
               88  WS-ASAG-WRITE      VALUE 'W'.
               88  WS-ASAG-REWRITE    VALUE 'R'.
008455*    02  WRK-ASIT-MAX-OR        PIC 9(5).99.
008455*    02  WRK-ASIT-MAX-OR-R REDEFINES WRK-ASIT-MAX-OR
008455*                               PIC 9(3).9999.
           02  NO-OF-TIMES            PIC 99.
016548*    02  AGNT-POS               PIC S9(04)  COMP.
016548     02  AGNT-POS               PIC S9(04)  BINARY.
016548*    02  WS-SUB-LIST            PIC S9(04)  COMP.
016548     02  WS-SUB-LIST            PIC S9(04)  BINARY.
016548*    02  WS-SUB                 PIC S9(04)  COMP.
016548     02  WS-SUB                 PIC S9(04)  BINARY.
016548*    02  WS-AGT-LINE            PIC S9(04)  COMP.
016548     02  WS-AGT-LINE            PIC S9(04)  BINARY.
016548*    02  WS-MAX-LIST-LINES      PIC S9(04)  COMP     VALUE +100.
025970*    02  WS-MAX-LIST-LINES      PIC S9(04)  BINARY     VALUE +100.
016548*    02  WS-MAX-LINES           PIC S9(04)  COMP     VALUE +10.
025970*    02  WS-MAX-LINES           PIC S9(04)  BINARY     VALUE +10.
           02  WS-MISSING-SW          PIC X(01).
               88  WS-MISSING-DATA    VALUE 'Y'.
               88  WS-NO-MISSING-DATA VALUE 'N'.
           02  A-IN-ERR               PIC 99.
           02  P-IN-ERR               PIC 99.
           02  TYP-IN-ERR             PIC 99.
           02  MXT-IN-ERR             PIC 99.
           02  MAX-IN-ERR             PIC 99.
           02  PRINT-OFF-SW           PIC 9.
           02  ERROR-LINE-SCREEN      PIC 99.
           02  UPDATE-SW              PIC 9.
               88  NO-UPDATE          VALUE 0.
               88  UPDATE-REQUIRED    VALUE 1.
           02  CURSOR-EXIT-SW         PIC 9.

013578*    02  WS-ENTER-CODE          PIC X.
013578*        88  WS-ENTER-CODE-VALID    VALUES ARE 'I' 'M' 'D' 'C'.
013578*        88  WS-ENTER-INQUIRY       VALUE  'I'.
013578*        88  WS-ENTER-MAINTAIN      VALUE  'M'.
013578*        88  WS-ENTER-CREATE        VALUE  'C'.
013578*        88  WS-ENTER-DELETE        VALUE  'D'.
013578     02  WS-BUS-FCN-ID          PIC X(04)  VALUE SPACES.
013578         88  WS-BUS-FCN-RETRIEVE    VALUE '2110'.
013578         88  WS-BUS-FCN-CREATE      VALUE '2111'.
013578         88  WS-BUS-FCN-UPDATE      VALUE '2112'.
013578         88  WS-BUS-FCN-DELETE      VALUE '2113'.
013578         88  WS-BUS-FCN-LIST        VALUE '2114'.
025970*    02  WS-TWRK-KEY            PIC X(04)  VALUE '2110'.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                    PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT        VALUE '2110'.
025970     05  WS-MAX-LIST-LINES              PIC S9(04) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT  VALUE +100.
025970     05  WS-MAX-LINES                   PIC S9(04) BINARY.
025970         88  WS-MAX-LINES-DEFAULT       VALUE +10.

       COPY CCFWAS.
       COPY CCFWASAG.
       COPY CCFRASAG.
       COPY CCFWAG.
       COPY CCFWCC.
       COPY CCFWRH.
       COPY CCFRAS.
       COPY CCFRAG.
019409 COPY CCFHAG.
       COPY CCFRCC.
       COPY CCFRRH.

014221 COPY XCWL8090.

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
557756*COPY CCWTYSNO.
013578*COPY XCWL2510.
557756*
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0071.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      *---------------
015543*0000-MAIN-LINE.
015543 0000-MAINLINE.
      *---------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

015543*0000-MAIN-LINE-X.
015543 0000-MAINLINE-X.
           EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

025970*    MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.

008455*    MOVE MIR-OVRID-MAX-AMT-PCT TO WS-MAX-OR.
           MOVE 1                     TO ERROR-LINE-SCREEN.
           MOVE ZEROES                TO WGLOB-MSG-ERROR-SW.
           MOVE ZEROES                TO UPDATE-SW.
           MOVE ZEROES                TO CURSOR-EXIT-SW.
           MOVE 1                     TO PRINT-OFF-SW.

557660     EVALUATE TRUE
               WHEN  WS-BUS-FCN-RETRIEVE
                     PERFORM  3000-PROCESS-RETRIEVE
                         THRU 3000-PROCESS-RETRIEVE-X
               WHEN  WS-BUS-FCN-LIST
                     PERFORM  3500-PROCESS-LIST
                         THRU 3500-PROCESS-LIST-X
               WHEN  WS-BUS-FCN-CREATE
                     PERFORM  4000-PROCESS-CREATE
                         THRU 4000-PROCESS-CREATE-X
               WHEN  WS-BUS-FCN-UPDATE
                     PERFORM  5000-PROCESS-UPDATE
                         THRU 5000-PROCESS-UPDATE-X
               WHEN  WS-BUS-FCN-DELETE
                     PERFORM  6000-PROCESS-DELETE
                         THRU 6000-PROCESS-DELETE-X
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

014221     MOVE MIR-OVRID-BASE-AGT-ID TO WAG-AGT-ID.

014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.

           PERFORM  8000-CREATE-ASIT-KEY
               THRU 8000-CREATE-ASIT-KEY-X.
           PERFORM  AS-1000-READ
               THRU AS-1000-READ-X.

           PERFORM  AGOV-0500-INIT-ASAG-ARRAY
               THRU AGOV-0500-INIT-ASAG-ARRAY-X
            VARYING AGNT-POS FROM 1 BY 1
              UNTIL AGNT-POS > WS-MAX-LINES.

           PERFORM  AGOV-1000-LOAD-ASAG-ARRAY
               THRU AGOV-1000-LOAD-ASAG-ARRAY-X.

013578*    MOVE 0                     TO NO-OF-TIMES.
           IF  WAS-IO-NOT-FOUND
               MOVE 'CS00000026'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  7000-CLEAR-SCREEN
                   THRU 7000-CLEAR-SCREEN-X
               GO TO 3000-PROCESS-RETRIEVE-X
           ELSE
               PERFORM  3100-INQUIRE-FORMAT
                   THRU 3100-INQUIRE-FORMAT-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.

      *--------------------
       3100-INQUIRE-FORMAT.
      *--------------------

           MOVE RAS-KEY               TO WAS-KEY.
           MOVE WAS-OVRID-BASE-AGT-ID TO MIR-OVRID-BASE-AGT-ID.
           MOVE WAS-OVRID-ID          TO MIR-OVRID-ID.
           PERFORM  7100-FORMAT-SCREEN
               THRU 7100-FORMAT-SCREEN-X.
013578*    MOVE 'CS00000027'          TO WGLOB-MSG-REF-INFO.
013578*    PERFORM  0260-1000-GENERATE-MESSAGE
013578*        THRU 0260-1000-GENERATE-MESSAGE-X.

013578*    IF  NO-OF-TIMES NOT = 0
013578*        PERFORM  AS-3000-END-BROWSE
013578*            THRU AS-3000-END-BROWSE-X
013578*    END-IF.

       3100-INQUIRE-FORMAT-X.
           EXIT.

013578*------------------
013578 3500-PROCESS-LIST.
013578*------------------
013578
013578     PERFORM  8050-AS-BROWSE-KEY
013578         THRU 8050-AS-BROWSE-KEY-X.
013578
013578     PERFORM  AS-1000-BROWSE
013578         THRU AS-1000-BROWSE-X.
013578
013578     PERFORM  AS-2000-READ-NEXT
013578         THRU AS-2000-READ-NEXT-X.
013578
013578     IF  NOT WAS-IO-OK
013578*MSG:    NO RECORDS FOUND TO DISPLAY
013578         MOVE 'XS00000034'        TO WGLOB-MSG-REF-INFO
013578
013578         PERFORM  AS-3000-END-BROWSE
013578             THRU AS-3000-END-BROWSE-X
013578         GO TO 3500-PROCESS-LIST-X
013578     END-IF.
013578
013578     PERFORM  3510-MOVE-LIST-TO-SCREEN
013578         THRU 3510-MOVE-LIST-TO-SCREEN-X
013578      VARYING WS-SUB-LIST FROM 1 BY 1
013578        UNTIL WS-SUB-LIST > WS-MAX-LIST-LINES
013578           OR WAS-IO-EOF
013578
013578     IF  WAS-IO-OK
018542*        MOVE MIR-OVRID-BASE-AGT-ID-T (WS-SUB-LIST)
018542         MOVE RAS-OVRID-BASE-AGT-ID
013578           TO MIR-OVRID-BASE-AGT-ID
018542*        MOVE MIR-OVRID-ID-T (WS-SUB-LIST)
018542         MOVE RAS-OVRID-ID
013578           TO MIR-OVRID-ID
013578*MSG: TO VIEW MORE DATA PRESS ENTER'
013578         SET WGLOB-MORE-DATA-EXISTS  TO TRUE
013578         MOVE 'XS00000014'        TO WGLOB-MSG-REF-INFO
013578         PERFORM  0260-1000-GENERATE-MESSAGE
013578             THRU 0260-1000-GENERATE-MESSAGE-X
013578     ELSE
013578*MSG: 'INQUIRE COMPLETED - CONTINUE'
015710*        MOVE 'XS00000002'        TO WGLOB-MSG-REF-INFO
015710*MSG: 'END OF LIST'
015710         MOVE 'XS00000015'        TO WGLOB-MSG-REF-INFO
013578         PERFORM  0260-1000-GENERATE-MESSAGE
013578             THRU 0260-1000-GENERATE-MESSAGE-X
013578     END-IF.
013578
013578     PERFORM  AS-3000-END-BROWSE
013578         THRU AS-3000-END-BROWSE-X.
013578
013578 3500-PROCESS-LIST-X.
013578     EXIT.
013578
013578*-------------------------
013578 3510-MOVE-LIST-TO-SCREEN.
013578*-------------------------
013578
013578     MOVE RAS-OVRID-BASE-AGT-ID
013578       TO MIR-OVRID-BASE-AGT-ID-T (WS-SUB-LIST).
013578     MOVE RAS-OVRID-ID TO MIR-OVRID-ID-T (WS-SUB-LIST).
013578
013578     PERFORM  AS-2000-READ-NEXT
013578         THRU AS-2000-READ-NEXT-X.
013578
013578
013578 3510-MOVE-LIST-TO-SCREEN-X.
013578     EXIT.

      *--------------------
       4000-PROCESS-CREATE.
      *--------------------

           PERFORM  8000-CREATE-ASIT-KEY
               THRU 8000-CREATE-ASIT-KEY-X.
           PERFORM  AS-1000-READ
               THRU AS-1000-READ-X.

           IF  WAS-IO-OK
               MOVE 'CS00000005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

023867*    MOVE MIR-OVRID-BASE-AGT-ID TO WAG-AGT-ID.

019409*    PERFORM  AG-1000-READ
019409*        THRU AG-1000-READ-X.
023867*    PERFORM  AG-2000-READ-INDEX
023867*        THRU AG-2000-READ-INDEX-X.
023867*
023867*    IF  WAG-IO-NOT-FOUND
023867*        MOVE 'CS00710001'       TO WGLOB-MSG-REF-INFO
023867*        PERFORM  0260-1000-GENERATE-MESSAGE
023867*            THRU 0260-1000-GENERATE-MESSAGE-X
023867*        GO TO 4000-PROCESS-CREATE-X
023867*    END-IF.

           PERFORM  AS-1000-CREATE
               THRU AS-1000-CREATE-X.
           PERFORM  AS-1000-WRITE
               THRU AS-1000-WRITE-X.
           MOVE 'CS00000012'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X
           MOVE 0                     TO WAS-IO-STATUS.

014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.

013578*     PERFORM  AGOV-0500-INIT-ASAG-ARRAY
013578*         THRU AGOV-0500-INIT-ASAG-ARRAY-X
013578*     VARYING AGNT-POS FROM 1 BY 1
013578*       UNTIL AGNT-POS > WS-MAX-LINES.
013578*
013578*    PERFORM  5000-PROCESS-UPDATE
013578*        THRU 5000-PROCESS-UPDATE-X.

       4000-PROCESS-CREATE-X.
           EXIT.

      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

014221     MOVE MIR-OVRID-BASE-AGT-ID   TO  WAG-AGT-ID.

014221     PERFORM  AG-2000-UPDATE-TWRK-TS
014221         THRU AG-2000-UPDATE-TWRK-TS-X.

019409     IF  WAG-IO-NOT-FOUND
019409*MSG: @2 RECORD (@1) NOT FOUND
019409         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
019409         MOVE WAG-KEY            TO WGLOB-MSG-PARM (1)
019409         MOVE 'AG'               TO WGLOB-MSG-PARM (2)
019409         PERFORM  0260-1000-GENERATE-MESSAGE
019409             THRU 0260-1000-GENERATE-MESSAGE-X
019409         GO TO 5000-PROCESS-UPDATE-X
019409     END-IF.
019409
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'AG'               TO WGLOB-MSG-PARM (01)
014221         MOVE WAG-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

019409     MOVE RAG-REC-INFO           TO HAG-REC-INFO.
019409
           PERFORM  8000-CREATE-ASIT-KEY
               THRU 8000-CREATE-ASIT-KEY-X.

           PERFORM  AS-1000-READ-FOR-UPDATE
               THRU AS-1000-READ-FOR-UPDATE-X.

           IF  WAS-IO-NOT-FOUND
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  AG-3000-UNLOCK
014221             THRU AG-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  AGOV-0500-INIT-ASAG-ARRAY
               THRU AGOV-0500-INIT-ASAG-ARRAY-X
            VARYING AGNT-POS FROM 1 BY 1
              UNTIL AGNT-POS > WS-MAX-LINES.

           PERFORM  AGOV-1000-LOAD-ASAG-ARRAY
               THRU AGOV-1000-LOAD-ASAG-ARRAY-X.

           PERFORM  5200-PROCESS-UPDATE
               THRU 5200-PROCESS-UPDATE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.

      *--------------------
       5200-PROCESS-UPDATE.
      *--------------------

           PERFORM  5210-AGENT-PATTERN-EDITS
               THRU 5210-AGENT-PATTERN-EDITS-X
            VARYING NO-OF-TIMES FROM 1 BY 1
              UNTIL NO-OF-TIMES > WS-MAX-LINES.

           PERFORM  5215-MAX-EDITS
               THRU 5215-MAX-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW = 0
               MOVE 'CS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-2000-GET-MESSAGE
                   THRU 0260-2000-GET-MESSAGE-X
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO UPDATE-SW
               MOVE 0                 TO NO-OF-TIMES
               PERFORM  5220-MOVE-TO-FILE
                   THRU 5220-MOVE-TO-FILE-X

               PERFORM  5225-MOVE-TO-AGOV
                   THRU 5225-MOVE-TO-AGOV-X
                VARYING NO-OF-TIMES FROM 1 BY 1
                  UNTIL NO-OF-TIMES > WS-MAX-LINES

               PERFORM  5230-CHECK-FOR-ASAG-DATA
                   THRU 5230-CHECK-FOR-ASAG-DATA-X
                VARYING NO-OF-TIMES FROM 1 BY 1
                  UNTIL NO-OF-TIMES > WS-MAX-LINES
           ELSE
               MOVE 1                 TO CURSOR-EXIT-SW
557660     END-IF.

           IF  UPDATE-REQUIRED
               PERFORM  AS-2000-REWRITE
                   THRU AS-2000-REWRITE-X
019409*        PERFORM  AG-2000-REWRITE
019409*            THRU AG-2000-REWRITE-X
014221     ELSE
014221         PERFORM  AS-3000-UNLOCK
014221             THRU AS-3000-UNLOCK-X
019409*        PERFORM  AG-3000-UNLOCK
019409*            THRU AG-3000-UNLOCK-X
557660     END-IF.

           IF  WS-ASAG-DATA-TO-WRITE
               PERFORM  5240-WRITE-OR-REWRITE-ASAG
                   THRU 5240-WRITE-OR-REWRITE-ASAG-X
                VARYING NO-OF-TIMES FROM 1 BY 1
                  UNTIL NO-OF-TIMES > WS-MAX-LINES
557660     END-IF.
019409
019409     IF  UPDATE-REQUIRED
019409         MOVE HAG-REC-INFO       TO RAG-REC-INFO
019409         PERFORM  AG-2000-REWRITE
019409             THRU AG-2000-REWRITE-X
019409     ELSE
019409         PERFORM  AG-3000-UNLOCK
019409             THRU AG-3000-UNLOCK-X
019409     END-IF.

       5200-PROCESS-UPDATE-X.
           EXIT.

      *-------------------------
       5210-AGENT-PATTERN-EDITS.
      *-------------------------

           IF  MIR-OVRID-AGT-ID-T(NO-OF-TIMES) = EBLCH-BLANK-FIELD-GROUP
               MOVE SPACES TO MIR-OVRID-TBAC-ID-T (NO-OF-TIMES)
               MOVE SPACES TO MIR-OVRID-CALC-CD-T (NO-OF-TIMES)
               GO TO 5210-AGENT-PATTERN-EDITS-X
557660     END-IF.

           IF  MIR-OVRID-AGT-ID-T (NO-OF-TIMES) = SPACES
               MOVE WAGOV-OVRID-AGT-ID (NO-OF-TIMES)
                 TO MIR-OVRID-AGT-ID-T (NO-OF-TIMES)
557660     END-IF.

           IF  MIR-OVRID-TBAC-ID-T (NO-OF-TIMES)  = SPACES
               MOVE WAGOV-OVRID-TBAC-ID (NO-OF-TIMES)
                 TO MIR-OVRID-TBAC-ID-T (NO-OF-TIMES)
557660     END-IF.

           IF  MIR-OVRID-CALC-CD-T (NO-OF-TIMES)  = SPACES
               MOVE WAGOV-OVRID-CALC-CD (NO-OF-TIMES)
                 TO MIR-OVRID-CALC-CD-T (NO-OF-TIMES)
557660     END-IF.

           MOVE 0                     TO A-IN-ERR.
           MOVE 0                     TO P-IN-ERR.
           MOVE 0                     TO MXT-IN-ERR.
           MOVE 0                     TO TYP-IN-ERR.
           MOVE 0                     TO MAX-IN-ERR.

           MOVE 'N'                   TO WS-MISSING-SW.

           IF  MIR-OVRID-AGT-ID-T (NO-OF-TIMES) = SPACES
           AND MIR-OVRID-TBAC-ID-T (NO-OF-TIMES) NOT = SPACES
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
               MOVE 'Y'               TO WS-MISSING-SW
557660     END-IF.

           IF  MIR-OVRID-TBAC-ID-T (NO-OF-TIMES) = SPACES
           AND MIR-OVRID-AGT-ID-T (NO-OF-TIMES) NOT = SPACES
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
               MOVE 'Y'               TO WS-MISSING-SW
557660     END-IF.

           IF  MIR-OVRID-CALC-CD-T (NO-OF-TIMES) = SPACES
               IF  MIR-OVRID-AGT-ID-T (NO-OF-TIMES) NOT = SPACES
               OR  MIR-OVRID-TBAC-ID-T (NO-OF-TIMES) NOT = SPACES
                   MOVE 1             TO WGLOB-MSG-ERROR-SW
                   MOVE 'Y'           TO WS-MISSING-SW
               END-IF
557660     END-IF.

           IF  WS-MISSING-DATA
      ***      MSG: INPUT MISSING ON LINE @1
               MOVE 'CS00710005'      TO WGLOB-MSG-REF-INFO
               MOVE NO-OF-TIMES       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  MIR-OVRID-CALC-CD-T (NO-OF-TIMES) NOT = SPACES
           AND MIR-OVRID-CALC-CD-T (NO-OF-TIMES) NOT = 'C'
           AND MIR-OVRID-CALC-CD-T (NO-OF-TIMES) NOT = 'P'
           AND MIR-OVRID-CALC-CD-T (NO-OF-TIMES) NOT = 'F'
           AND MIR-OVRID-CALC-CD-T (NO-OF-TIMES) NOT = 'R'
               MOVE 1                 TO TYP-IN-ERR
557660     END-IF.

      ** READ FILES.
           IF  MIR-OVRID-AGT-ID-T (NO-OF-TIMES) NOT = SPACES
               MOVE MIR-OVRID-AGT-ID-T (NO-OF-TIMES)
                                      TO WAG-AGT-ID
               PERFORM  AG-1000-READ
                   THRU AG-1000-READ-X
               IF  WAG-IO-NOT-FOUND
                   MOVE 1             TO A-IN-ERR
557660         END-IF
557660     END-IF.

           IF  MIR-OVRID-CALC-CD-T (NO-OF-TIMES) = 'R'
               PERFORM  5211-BROWSE-RH
                   THRU 5211-BROWSE-RH-X
557660     END-IF.

           IF  MIR-OVRID-CALC-CD-T (NO-OF-TIMES) NOT = 'R'
           AND MIR-OVRID-TBAC-ID-T (NO-OF-TIMES) NOT = SPACES
               MOVE MIR-OVRID-TBAC-ID-T (NO-OF-TIMES)
                                  TO WCC-RTBL2-ID
               PERFORM  CC-1000-READ
                   THRU CC-1000-READ-X
               IF  WCC-IO-NOT-FOUND
                   MOVE 1         TO P-IN-ERR
557660         END-IF
557660     END-IF.

           IF  A-IN-ERR NOT = 0
      ***      MSG: INVALID AGENT ON LINE @1
               MOVE 'CS00710006'      TO WGLOB-MSG-REF-INFO
               MOVE NO-OF-TIMES       TO WGLOB-MSG-PARM (1)
               MOVE MIR-OVRID-AGT-ID-T (NO-OF-TIMES)
                                      TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
557660     END-IF.

           IF  P-IN-ERR NOT = 0
      ***      MSG: INVALID PATTERN ON LINE @1
               MOVE 'CS00710007'      TO WGLOB-MSG-REF-INFO
               MOVE NO-OF-TIMES       TO WGLOB-MSG-PARM (1)
               MOVE MIR-OVRID-TBAC-ID-T (NO-OF-TIMES)
                                      TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
557660     END-IF.

           IF  TYP-IN-ERR NOT = 0
      ***      MSG: INVALID CALC CODE ON LINE @1
               MOVE 'CS00710003'      TO WGLOB-MSG-REF-INFO
               MOVE NO-OF-TIMES       TO WGLOB-MSG-PARM (1)
               MOVE MIR-OVRID-CALC-CD-T (NO-OF-TIMES)
                                      TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
557660     END-IF.
       5210-AGENT-PATTERN-EDITS-X.
           EXIT.

      *---------------
       5211-BROWSE-RH.
      *---------------

           MOVE MIR-OVRID-TBAC-ID-T (NO-OF-TIMES)
                                   TO WRH-RH-ID.
           MOVE ZERO               TO WRH-RH-IDT-NUM-N.
           MOVE HIGH-VALUES        TO WRH-ENDBR-KEY.
           MOVE MIR-OVRID-TBAC-ID-T (NO-OF-TIMES)
                                   TO WRH-ENDBR-RH-ID.
           PERFORM  RH-1000-BROWSE
               THRU RH-1000-BROWSE-X.
           IF  WRH-IO-OK
               PERFORM  RH-2000-READ-NEXT
                   THRU RH-2000-READ-NEXT-X
               IF  WRH-IO-OK
                   PERFORM  RH-3000-END-BROWSE
                       THRU RH-3000-END-BROWSE-X
               ELSE
                   MOVE 1           TO P-IN-ERR
                   PERFORM  RH-3000-END-BROWSE
                       THRU RH-3000-END-BROWSE-X
               END-IF
           ELSE
               MOVE 1              TO P-IN-ERR
557660     END-IF.

       5211-BROWSE-RH-X.
           EXIT.

      *---------------
       5215-MAX-EDITS.
      *---------------

008455     MOVE 0                     TO WS-MAX-OR-N
008455                                   WS-MAX-OR-R-N.

           IF  MIR-OVRID-MAX-TYP-CD NOT = 'A'
           AND MIR-OVRID-MAX-TYP-CD NOT = 'P'
               MOVE 1                 TO MXT-IN-ERR
557660     END-IF.

008455*    IF  MIR-OVRID-MAX-TYP-CD = 'A'
008455*    AND (WS-MAX-OR-PT NOT = '.'     OR
008455*         WS-MAX-OR-NO NOT NUMERIC   OR
008455*         WS-MAX-OR-DC NOT NUMERIC)
008455*        MOVE 1                       TO MAX-IN-ERR
008455*    END-IF.

008455*    IF  MIR-OVRID-MAX-TYP-CD = 'P'
008455*    AND (WS-MAX-OR-PT-R NOT = '.'   OR
008455*         WS-MAX-OR-NO-R NOT NUMERIC OR
008455*         WS-MAX-OR-DC-R NOT NUMERIC)
008455*        MOVE 1                       TO MAX-IN-ERR
008455*    END-IF.

008455     IF  MIR-OVRID-MAX-TYP-CD = 'A'
008455     OR  MIR-OVRID-MAX-TYP-CD = 'P'
008455         EVALUATE MIR-OVRID-MAX-TYP-CD
008455         WHEN 'A'
008455              MOVE 2            TO L0280-PRECISION
008455         WHEN 'P'
008455              MOVE 4            TO L0280-PRECISION
008455         END-EVALUATE
008455         MOVE MIR-OVRID-MAX-AMT-PCT
                                      TO L0280-INPUT-DATA
008455         MOVE 'N'               TO L0280-SIGN-IND
008455         MOVE LENGTH OF MIR-OVRID-MAX-AMT-PCT
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
008455         PERFORM  0280-1000-NUMERIC-EDIT
008455             THRU 0280-1000-NUMERIC-EDIT-X
008455         IF  L0280-OK
008455             EVALUATE MIR-OVRID-MAX-TYP-CD
008455             WHEN 'A'
008455                 MOVE L0280-OUTPUT-DOLLAR
008455                                 TO WS-MAX-OR-N
008455                 MOVE 2          TO L0290-PRECISION

008455             WHEN 'P'
008455                 MOVE L0280-OUTPUT-V04
                                       TO WS-MAX-OR-R-N
008455                 MOVE 4          TO L0290-PRECISION

008455             END-EVALUATE
008455             MOVE L0280-OUTPUT   TO L0290-INPUT-NUMBER
008455             MOVE LENGTH OF MIR-OVRID-MAX-AMT-PCT
                                       TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM  0290-2000-FORMAT-FOR-MIR
020874                 THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                       TO MIR-OVRID-MAX-AMT-PCT
008455                                          WS-MAX-OR
008455         ELSE
008455             MOVE 1              TO MAX-IN-ERR
008455         END-IF
008455     END-IF.

           IF  MXT-IN-ERR NOT = 0
      ***      MSG: INVALID OVERRIDE TYPE
               MOVE 'CS00710008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 0                 TO MXT-IN-ERR
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
557660     END-IF.

           IF  MAX-IN-ERR NOT = 0
008455     OR  WS-MAX-OR-R-N > 100
      ***     MSG: OVERRIDE AMOUNT INVALID
               MOVE 'CS00710009'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 0                 TO MAX-IN-ERR
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
557660     END-IF.

       5215-MAX-EDITS-X.
           EXIT.

      *------------------
       5220-MOVE-TO-FILE.
      *------------------

           MOVE MIR-OVRID-MAX-TYP-CD TO RAS-OVRID-MAX-TYP-CD.
           IF  MIR-OVRID-MAX-TYP-CD = 'A'
008455*        COMPUTE RAS-OVRID-MAX-AMT-PCT
008455*        = WS-MAX-OR-NO + WS-MAX-OR-DC
008455         MOVE WS-MAX-OR-N        TO RAS-OVRID-MAX-AMT-PCT
           ELSE
008455*        COMPUTE RAS-OVRID-MAX-AMT-PCT-R
008455*        = WS-MAX-OR-NO-R + WS-MAX-OR-DC-R
008455         MOVE WS-MAX-OR-R-N      TO RAS-OVRID-MAX-AMT-PCT-R
557660     END-IF.

       5220-MOVE-TO-FILE-X.
           EXIT.

      *------------------
       5225-MOVE-TO-AGOV.
      *------------------

           MOVE MIR-OVRID-AGT-ID-T (NO-OF-TIMES)
             TO WAGOV-OVRID-AGT-ID (NO-OF-TIMES).
           MOVE MIR-OVRID-TBAC-ID-T (NO-OF-TIMES)
             TO WAGOV-OVRID-TBAC-ID (NO-OF-TIMES).
           MOVE MIR-OVRID-CALC-CD-T (NO-OF-TIMES)
             TO WAGOV-OVRID-CALC-CD (NO-OF-TIMES).

       5225-MOVE-TO-AGOV-X.
           EXIT.

      *-------------------------
       5230-CHECK-FOR-ASAG-DATA.
      *-------------------------

           IF  WAGOV-OVRID-AGT-ID (NO-OF-TIMES)  NOT = SPACES
           OR  WAGOV-OVRID-TBAC-ID (NO-OF-TIMES) NOT = SPACES
           OR  WAGOV-OVRID-CALC-CD (NO-OF-TIMES) NOT = SPACES
               MOVE 'Y' TO WS-ASAG-DATA-SW
               MOVE 'Y' TO WS-ASAG-DATA-THIS-LINE (NO-OF-TIMES)
557660     END-IF.

       5230-CHECK-FOR-ASAG-DATA-X.
           EXIT.

      *---------------------------
       5240-WRITE-OR-REWRITE-ASAG.
      *---------------------------

           IF  WS-ASAG-DATA-THIS-LINE (NO-OF-TIMES) NOT = 'Y'
               GO TO 5240-WRITE-OR-REWRITE-ASAG-X
557660     END-IF.

           MOVE NO-OF-TIMES           TO WASAG-OVRID-AGT-LVL-NUM.

           PERFORM  ASAG-1000-READ-FOR-UPDATE
               THRU ASAG-1000-READ-FOR-UPDATE-X.

           IF  WASAG-IO-OK
               MOVE 'R'               TO WS-ASAG-WRITE-SW

               PERFORM  5245-ARRAY-DATA-TO-ASAG
                   THRU 5245-ARRAY-DATA-TO-ASAG-X
           ELSE
               PERFORM  ASAG-1000-CREATE
                   THRU ASAG-1000-CREATE-X
               MOVE 'W'               TO WS-ASAG-WRITE-SW
               MOVE NO-OF-TIMES
                 TO WAGOV-OVRID-AGT-LVL-NUM (NO-OF-TIMES)
               PERFORM  5245-ARRAY-DATA-TO-ASAG
                   THRU 5245-ARRAY-DATA-TO-ASAG-X
557660     END-IF.

       5240-WRITE-OR-REWRITE-ASAG-X.
           EXIT.

      *------------------------
       5245-ARRAY-DATA-TO-ASAG.
      *------------------------

           IF  WAGOV-OVRID-AGT-ID (NO-OF-TIMES)
             = EBLCH-BLANK-FIELD-GROUP
               MOVE SPACES TO MIR-OVRID-AGT-ID-T (NO-OF-TIMES)
               MOVE SPACES TO WAGOV-OVRID-AGT-ID (NO-OF-TIMES)
               MOVE SPACES TO WAGOV-OVRID-TBAC-ID (NO-OF-TIMES)
               MOVE SPACES TO WAGOV-OVRID-CALC-CD (NO-OF-TIMES)
               IF  WASAG-IO-OK
                   PERFORM  ASAG-1000-DELETE
                       THRU ASAG-1000-DELETE-X
                   GO TO 5245-ARRAY-DATA-TO-ASAG-X
               ELSE
                   GO TO 5245-ARRAY-DATA-TO-ASAG-X
557660         END-IF
557660     END-IF.

           MOVE WAGOV-OVRID-AGT-ID (NO-OF-TIMES)
                                      TO RASAG-OVRID-AGT-ID.
           MOVE WAGOV-OVRID-TBAC-ID (NO-OF-TIMES)
                                      TO RASAG-OVRID-TBAC-ID.
           MOVE WAGOV-OVRID-CALC-CD (NO-OF-TIMES)
                                      TO RASAG-OVRID-CALC-CD.

           IF  WS-ASAG-WRITE
               PERFORM  ASAG-1000-WRITE
                   THRU ASAG-1000-WRITE-X
           ELSE
               PERFORM  ASAG-2000-REWRITE
                   THRU ASAG-2000-REWRITE-X
557660     END-IF.

       5245-ARRAY-DATA-TO-ASAG-X.
           EXIT.

      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           PERFORM  6200-PROCESS-DELETE
               THRU 6200-PROCESS-DELETE-X.

       6000-PROCESS-DELETE-X.
           EXIT.

      *--------------------
       6200-PROCESS-DELETE.
      *--------------------

014221     MOVE MIR-OVRID-BASE-AGT-ID TO WAG-AGT-ID.

014221     PERFORM  AG-2000-UPDATE-TWRK-TS
014221         THRU AG-2000-UPDATE-TWRK-TS-X.

019409     IF  WAG-IO-NOT-FOUND
019409*MSG: @2 RECORD (@1) NOT FOUND
019409         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
019409         MOVE WAG-KEY            TO WGLOB-MSG-PARM (1)
019409         MOVE 'AG'               TO WGLOB-MSG-PARM (2)
019409         PERFORM  0260-1000-GENERATE-MESSAGE
019409             THRU 0260-1000-GENERATE-MESSAGE-X
019409         GO TO 6200-PROCESS-DELETE-X
019409     END-IF.
019409
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'AG'               TO WGLOB-MSG-PARM (01)
014221         MOVE WAG-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6200-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  8000-CREATE-ASIT-KEY
               THRU 8000-CREATE-ASIT-KEY-X.
           PERFORM  AS-1000-READ-FOR-UPDATE
               THRU AS-1000-READ-FOR-UPDATE-X.

           IF  WAS-IO-OK
      ****     SET ASAG-KEY
               MOVE LOW-VALUES        TO WASAG-KEY
               MOVE WAS-OVRID-BASE-AGT-ID
                                      TO WASAG-OVRID-BASE-AGT-ID
               MOVE WAS-OVRID-ID      TO WASAG-OVRID-ID
               MOVE ZEROES            TO WASAG-OVRID-AGT-LVL-NUM
               MOVE WASAG-KEY         TO WASAG-ENDBR-KEY
               MOVE +999              TO WASAG-ENDBR-OVRID-AGT-LVL-NUM

               PERFORM  ASAG-1000-DELETE-KEY-RANGE
                   THRU ASAG-1000-DELETE-KEY-RANGE-X

               PERFORM  AS-1000-DELETE
                   THRU AS-1000-DELETE-X
               IF  WAS-IO-OK
                   MOVE 'CS00000013'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
014221         PERFORM  AG-2000-REWRITE
014221             THRU AG-2000-REWRITE-X
014221         PERFORM  AG-1000-READ-TWRK-TS
014221             THRU AG-1000-READ-TWRK-TS-X
014221     ELSE
014221         PERFORM  AG-3000-UNLOCK
014221             THRU AG-3000-UNLOCK-X
557660     END-IF.

           PERFORM  7000-CLEAR-SCREEN
               THRU 7000-CLEAR-SCREEN-X.

       6200-PROCESS-DELETE-X.
           EXIT.

      *------------------
       7000-CLEAR-SCREEN.
      *------------------

           PERFORM  7010-CLEAR-REPEAT-LINES
               THRU 7010-CLEAR-REPEAT-LINES-X
            VARYING WS-SUB FROM 1 BY 1
              UNTIL WS-SUB > WS-MAX-LINES.

           MOVE SPACES                TO MIR-OVRID-MAX-TYP-CD.
           MOVE SPACES                TO MIR-OVRID-MAX-AMT-PCT.

       7000-CLEAR-SCREEN-X.
           EXIT.

      *------------------------
       7010-CLEAR-REPEAT-LINES.
      *------------------------

           MOVE SPACES TO MIR-OVRID-AGT-ID-T (WS-SUB).
           MOVE SPACES TO MIR-OVRID-TBAC-ID-T (WS-SUB).
           MOVE SPACES TO MIR-OVRID-CALC-CD-T (WS-SUB).

       7010-CLEAR-REPEAT-LINES-X.
           EXIT.

      *-------------------
       7100-FORMAT-SCREEN.
      *-------------------

           MOVE RAS-OVRID-MAX-TYP-CD  TO MIR-OVRID-MAX-TYP-CD.
008455*    IF  RAS-OVRID-MAX-TYP-CD = 'A'
008455*        MOVE RAS-OVRID-MAX-AMT-PCT TO WRK-ASIT-MAX-OR
008455*    END-IF.
008455*    IF  RAS-OVRID-MAX-TYP-CD = 'P'
008455*        MOVE RAS-OVRID-MAX-AMT-PCT-R TO WRK-ASIT-MAX-OR-R
008455*    END-IF.
008455*    MOVE WRK-ASIT-MAX-OR   TO MIR-OVRID-MAX-AMT-PCT.
008455     EVALUATE RAS-OVRID-MAX-TYP-CD
008455     WHEN 'A'
008455         MOVE 2                 TO L0290-PRECISION
020874*        COMPUTE L0290-INPUT-NUMBER = RAS-OVRID-MAX-AMT-PCT
020874*                                     * 100
020874         MOVE RAS-OVRID-MAX-AMT-PCT TO L0290-INPUT-V02
008455     WHEN 'P'
008455         MOVE 4                 TO L0290-PRECISION
020874*        COMPUTE L0290-INPUT-NUMBER = RAS-OVRID-MAX-AMT-PCT-R
020874*                                     * 10000
020874         MOVE RAS-OVRID-MAX-AMT-PCT-R  TO L0290-INPUT-V04
008455     END-EVALUATE.
008455     MOVE LENGTH OF MIR-OVRID-MAX-AMT-PCT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.

008455     MOVE L0290-OUTPUT-DATA     TO MIR-OVRID-MAX-AMT-PCT.
008455
           PERFORM  AGOV-0500-INIT-ASAG-ARRAY
               THRU AGOV-0500-INIT-ASAG-ARRAY-X
            VARYING AGNT-POS FROM 1 BY 1
              UNTIL AGNT-POS > WS-MAX-LINES.

           PERFORM  AGOV-1000-LOAD-ASAG-ARRAY
               THRU AGOV-1000-LOAD-ASAG-ARRAY-X.

           PERFORM  7110-FORMAT-REPEAT-FIELDS
               THRU 7110-FORMAT-REPEAT-FIELDS-X
            VARYING WS-SUB FROM 1 BY 1
              UNTIL WS-SUB > WS-MAX-LINES.

       7100-FORMAT-SCREEN-X.
           EXIT.

       7110-FORMAT-REPEAT-FIELDS.

           MOVE WAGOV-OVRID-AGT-ID (WS-SUB)
             TO MIR-OVRID-AGT-ID-T (WS-SUB).
           MOVE WAGOV-OVRID-TBAC-ID (WS-SUB)
             TO MIR-OVRID-TBAC-ID-T (WS-SUB).
           MOVE WAGOV-OVRID-CALC-CD (WS-SUB)
             TO MIR-OVRID-CALC-CD-T (WS-SUB).

       7110-FORMAT-REPEAT-FIELDS-X.
           EXIT.

       8000-CREATE-ASIT-KEY.

           MOVE MIR-OVRID-BASE-AGT-ID TO WAS-OVRID-BASE-AGT-ID.
           MOVE MIR-OVRID-ID          TO WAS-OVRID-ID.

       8000-CREATE-ASIT-KEY-X.
           EXIT.

013578*-------------------
013578 8050-AS-BROWSE-KEY.
013578*-------------------
013578
013578     PERFORM  8000-CREATE-ASIT-KEY
013578         THRU 8000-CREATE-ASIT-KEY-X.
013578     MOVE HIGH-VALUES           TO WAS-ENDBR-KEY.
013578
013578 8050-AS-BROWSE-KEY-X.
013578     EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE OTHER-WORK-AREAS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WAGOV-WORK-INFO.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
025970     SET WS-MAX-LIST-LINES-DEFAULT    TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT         TO TRUE.  
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY AG
014221                         '$VAR2' BY 'AG'.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
       COPY CCPPAGOV.
013578*COPY XCCL2510.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
013578*COPY XCPS2510.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
008455 COPY XCPL0280.
008455 COPY XCPL0290.
008455 COPY XCPS0290.

       COPY CCPUAS.
       COPY CCPAAS.
       COPY CCPXAS.
       COPY CCPBAS.
       COPY CCPNAS.
       COPY CCPAASAG.
       COPY CCPBASAG.
       COPY CCPCASAG.
       COPY CCPGASAG.
       COPY CCPUASAG.
       COPY CCPXASAG.
       COPY CCPCAS.
       COPY CCPNAG.
014221 COPY CCPUAG.
       COPY CCPNCC.
       COPY CCPBRH.

557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM0071                     **
      *****************************************************************
