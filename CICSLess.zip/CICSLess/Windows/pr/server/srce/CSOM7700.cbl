      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7700.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7700                                         **
      **  REMARKS:  RETRIEVE PROCESS DRIVER FOR THE NEW CONTRIBUTION **
      **            TRANSACTION TABLE (CNTX)                         **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
022455**  6.4       CORRECT POLICY ACTIVITY DATE                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
035625**  7.1       EDIT ON INPUT TIMESTAMP                          **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7700'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '7700'.
           05  WS-CLIENT-FOUND-SW           PIC X(01).
               88  WS-CLIENT-FOUND          VALUE 'Y'.
               88  WS-NO-CLIENT-FOUND       VALUE 'N'.
           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.
           05  WS-FOUND-PRIMARY-SW                PIC X(01).
               88  WS-FOUND-PRIMARY               VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS           VALUE 'N'.


      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWLOCK.

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************

       COPY CCWWINDX.

      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWCNTX.
       COPY CCFRCNTX.

       COPY CCFWPOL.
       COPY CCFRPOL.

       COPY CCFRPOLC.
       COPY CCFWPOLC.


      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
020478 COPY CCWL2626.
       COPY XCWLDTLK.
035625 COPY XCWL0280.
       COPY XCWL0290.
       COPY CCWL0620.
       COPY XCWL1640.
035625 COPY XCWL1646.
       COPY XCWL1660.
       COPY CCWL2430.
       COPY CCWL2435.
       COPY XCWL8090.

      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7700.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           INITIALIZE L2430-OUTPUT-PARM-INFO.
           INITIALIZE L2435-OUTPUT-PARM-INFO.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 2000-PROCESS-RETRIEVE
                       THRU 2000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7700'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------
       2000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  7000-BUILD-KEY
               THRU 7000-BUILD-KEY-X.

           MOVE SPACES TO MIR-OUTPUT-AREA.

           PERFORM 3000-RETRIEVE-POLICY
              THRU 3000-RETRIEVE-POLICY-X

           IF WPOL-IO-NOT-FOUND
      *MSG: RECORD NOT FOUND
              MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
              MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR    TO TRUE
              GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

035625     PERFORM  7100-EDIT-INPUT-PARM
035625         THRU 7100-EDIT-INPUT-PARM-X.

035625     IF WGLOB-MSG-ERROR-SW > ZERO
035625        GO TO 2000-PROCESS-RETRIEVE-X
035625     END-IF.
035625
           PERFORM  CNTX-1000-READ
               THRU CNTX-1000-READ-X.

           IF  NOT WCNTX-IO-OK
      *MSG:  RECORD NOT FOUND
               MOVE 'CS77000001'         TO WGLOB-MSG-REF-INFO
               MOVE WCNTX-KEY            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       2000-PROCESS-RETRIEVE-X.
           EXIT.

      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------

           SET  WS-NO-CLIENT-FOUND TO TRUE.

      * READ AND FORMAT POLICY OWNERS NAME

           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.

           PERFORM  2330-FORMAT-NAME
              THRU  2330-FORMAT-NAME-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.

      * READ AND FORMAT TAX ID OWNERS NAME

           PERFORM  2340-GET-TAX-OWNER
               THRU 2340-GET-TAX-OWNER-X.

           PERFORM 2330-FORMAT-NAME
              THRU 2330-FORMAT-NAME-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-CLI-NM.

       2300-COMMON-LINE-SET-X.
           EXIT.

      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  MIR-POL-ID-BASE = SPACES
                 GO TO 2320-GET-OWNER-X
           END-IF.

           MOVE L2430-CLI-ID TO MIR-POL-CLI-ID.

           IF  L2430-CLI-ID = SPACES
               PERFORM  2400-CHECK-FOR-OWNER-CLI
                   THRU 2400-CHECK-FOR-OWNER-CLI-X
           ELSE
               IF  L2430-CLI-NM-COMPRESSED = SPACES
      *MSG:        POLICY OWNER CLIENT NAME IS BLANK FOR CLIENT (@1)
                   MOVE L2430-CLI-ID  TO WGLOB-MSG-PARM (1)
                   MOVE 'CS77000002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2320-GET-OWNER-X.
           EXIT.

      *------------------
       2330-FORMAT-NAME.
      *------------------

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
           END-IF.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

      *-------------------
       2330-FORMAT-NAME-X.
      *-------------------
           EXIT.

      *------------------
       2340-GET-TAX-OWNER.
      *------------------

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

022455*    MOVE RCNTX-CLI-ID               TO L2435-CLI-ID.
022455     MOVE MIR-POL-CLI-ID             TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF NOT L2435-RETRN-OK
      *MSG: TAX ID OWNER DETAILS NOT FOUND FOR (@1)
               MOVE 'CS77000003'           TO WGLOB-MSG-REF-INFO
               MOVE L2435-CLI-ID           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2340-GET-TAX-OWNER-X
           END-IF.

           MOVE L2435-CLI-ENTR-CO-NM  TO L2430-CLI-ENTR-CO-NM.
           MOVE L2435-CLI-ENTR-GIV-NM TO L2430-CLI-ENTR-GIV-NM.
           MOVE L2435-CLI-ENTR-SUR-NM TO L2430-CLI-ENTR-SUR-NM.
           MOVE L2435-CLI-SEX-CD      TO L2430-CLI-SEX-CD.

      *-------------------
       2340-GET-TAX-OWNER-X.
      *-------------------
           EXIT.

      *-------------------------
       2400-CHECK-FOR-OWNER-CLI.
      *-------------------------

      * BUILD START/END BROWSE KEY

           MOVE LOW-VALUES            TO  WPOLC-KEY.
           MOVE RPOL-POL-ID           TO  WPOLC-POL-ID.
           MOVE 'O'                   TO  WPOLC-POL-CLI-REL-TYP-CD.

           MOVE WPOLC-KEY             TO  WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO  WPOLC-ENDBR-CLI-ID.

      *  POSITION AT THE FIRST RECORD FOR THE GIVEN RELATIONSHIP

           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

           IF  WPOLC-IO-OK
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

           IF  WPOLC-IO-EOF
      *MSG:    NO POLICY CLIENT RECORDS FOUND
               MOVE 'CS77000004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           SET  WS-NO-PRIMARY-EXISTS TO TRUE.
           PERFORM  2500-DETERMINE-IF-PRIMARY
               THRU 2500-DETERMINE-IF-PRIMARY-X
               UNTIL WPOLC-IO-EOF
               OR    WS-FOUND-PRIMARY.

           IF  WS-NO-PRIMARY-EXISTS
      * PRIMARY POLICY OWNER IS NOT FOUND
               MOVE 'CS77000005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           PERFORM  2600-FIND-OWNERS-LOOP
               THRU 2600-FIND-OWNERS-LOOP-X
               UNTIL WPOLC-IO-EOF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.

       2400-CHECK-FOR-OWNER-CLI-X.
           EXIT.

      *--------------------------
       2500-DETERMINE-IF-PRIMARY.
      *--------------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD = 'P'
               SET WS-FOUND-PRIMARY TO TRUE
               GO TO 2500-DETERMINE-IF-PRIMARY-X
           END-IF.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2500-DETERMINE-IF-PRIMARY-X.
           EXIT.

      *----------------------
       2600-FIND-OWNERS-LOOP.
      *----------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD NOT = 'P'
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
               GO TO 2600-FIND-OWNERS-LOOP-X
           END-IF.

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

      * WE HAVE FOUND THE REQUIRED RECORD, READ THE CLIENT FILE

           MOVE  RPOLC-CLI-ID         TO  L2430-CLI-ID.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
022455     ELSE
022455         MOVE L2430-CLI-ID      TO MIR-POL-CLI-ID
           END-IF.

       2600-FIND-OWNERS-LOOP-X.
           EXIT.

      *---------------
       3000-RETRIEVE-POLICY.
      *---------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       3000-RETRIEVE-POLICY-X.
           EXIT.

      *---------------
       7000-BUILD-KEY.
      *---------------

           MOVE MIR-POL-ID-BASE       TO WCNTX-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WCNTX-POL-ID-SFX.
           MOVE MIR-CNTRXN-TS         TO WCNTX-CNTRXN-TS.
           MOVE MIR-CNTRXN-SEQ-NUM    TO WCNTX-CNTRXN-SEQ-NUM.

       7000-BUILD-KEY-X.
           EXIT.

035625*---------------------
035625 7100-EDIT-INPUT-PARM.
035625*---------------------
035625
035625     PERFORM  7120-EDIT-TIMESTAMP
035625         THRU 7120-EDIT-TIMESTAMP-X.
035625
035625     PERFORM  7140-EDIT-SEQ-NUM
035625         THRU 7140-EDIT-SEQ-NUM-X.
035625
035625 7100-EDIT-INPUT-PARM-X.
035625     EXIT.
035625
035625*--------------------
035625 7120-EDIT-TIMESTAMP.
035625*--------------------
035625
035625     PERFORM  1646-1000-BUILD-PARM-INFO
035625         THRU 1646-1000-BUILD-PARM-INFO-X.
035625
035625     MOVE MIR-CNTRXN-TS               TO L1646-TIMESTAMP.
035625
035625     PERFORM  1646-1000-EDIT-TIMESTAMP
035625         THRU 1646-1000-EDIT-TIMESTAMP-X.
035625
035625     IF  NOT L1646-EDIT-OK
035625*MSG: INVALID TIMESTAMP
035625         MOVE 'CS77000006'            TO WGLOB-MSG-REF-INFO
035625         PERFORM  0260-1000-GENERATE-MESSAGE
035625             THRU 0260-1000-GENERATE-MESSAGE-X
035625         MOVE 1                       TO WGLOB-MSG-ERROR-SW
035625     END-IF.
035625
035625 7120-EDIT-TIMESTAMP-X.
035625     EXIT.
035625
035625*------------------
035625 7140-EDIT-SEQ-NUM.
035625*------------------
035625
035625     MOVE MIR-CNTRXN-SEQ-NUM          TO L0280-INPUT-DATA.
035625     MOVE LENGTH OF MIR-CNTRXN-SEQ-NUM
035625                                      TO L0280-INPUT-SIZE.
035625     MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
035625     MOVE ZERO                        TO L0280-PRECISION.
035625     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
035625     SET L0280-SPACES-PERMITTED       TO TRUE.
035625
035625     PERFORM  0280-1000-NUMERIC-EDIT
035625         THRU 0280-1000-NUMERIC-EDIT-X.
035625
035625     IF  L0280-OK
035625         CONTINUE
035625     ELSE
035625*MSG: INVALID CONTRIBUTION SEQUENCE NUMBER
035625         MOVE 'CS77000007'            TO WGLOB-MSG-REF-INFO
035625         PERFORM  0260-1000-GENERATE-MESSAGE
035625             THRU 0260-1000-GENERATE-MESSAGE-X
035625         MOVE 1                       TO WGLOB-MSG-ERROR-SW
035625     END-IF.
035625
035625 7140-EDIT-SEQ-NUM-X.
035625     EXIT.
035625
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------


           MOVE RCNTX-CNTRXN-TYP-CD      TO MIR-CNTRXN-TYP-CD.
           MOVE RCNTX-CLI-ID             TO MIR-CLI-ID.
           MOVE RCNTX-CNTRXN-CLI-TAX-ID  TO MIR-CNTRXN-CLI-TAX-ID.
           MOVE RCNTX-CNTRXN-TAX-YR      TO MIR-CNTRXN-TAX-YR.

020874*    COMPUTE L0290-INPUT-NUMBER = RCNTX-CNTRXN-AMT * 100.
020874     MOVE RCNTX-CNTRXN-AMT         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CNTRXN-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-CNTRXN-AMT.
           MOVE RCNTX-CDA-TYP-CD         TO MIR-CDA-TYP-CD.
           MOVE RCNTX-POL-PAYO-NUM       TO MIR-POL-PAYO-NUM.

           MOVE RCNTX-CDA-EFF-IDT-NUM     TO L1660-INVERTED-DATE.

           PERFORM 1660-3000-CONVERT-INV-TO-INT
              THRU 1660-3000-CONVERT-INV-TO-INT-X.

           MOVE L1660-INTERNAL-DATE      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

022455*    MOVE L1640-EXTERNAL-DATE      TO MIR-CDA-EFF-IDT-NUM.
022455     MOVE L1640-EXTERNAL-DATE      TO MIR-DV-EFF-DT.

           IF  RCNTX-CDA-SEQ-NUM = ZERO
020874*        COMPUTE L0290-INPUT-NUMBER = ZERO
020874         MOVE ZERO                 TO L0290-INPUT-V00
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER = 1000 - RCNTX-CDA-SEQ-NUM
020874         COMPUTE L0290-INPUT-V00    = 1000 - RCNTX-CDA-SEQ-NUM
           END-IF.

           MOVE ZERO                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CDA-SEQ-NUM TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CDA-SEQ-NUM.

           MOVE RCNTX-CNTRXN-REVRS-CD    TO MIR-CNTRXN-REVRS-CD.
           MOVE RCNTX-CNTRXN-RPT-CD      TO MIR-CNTRXN-RPT-CD.
           MOVE RCNTX-CNTRXN-STAT-CD     TO MIR-CNTRXN-STAT-CD.
           MOVE RCNTX-CNTRXN-COMNT-TXT-TXT TO MIR-CNTRXN-COMNT-TXT.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
035625     PERFORM  0280-0000-INIT-PARM-INFO
035625         THRU 0280-0000-INIT-PARM-INFO-X.
035625
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
035625     PERFORM  1646-0000-INIT-PARM-INFO
035625         THRU 1646-0000-INIT-PARM-INFO-X.
035625
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY XCPPINIT.

       COPY XCPPEXIT.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POL
                                '$VAR2'   BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
025970 COPY XCPS8090.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
       COPY XCPL0260.

035625 COPY XCPS0280.
035625 COPY XCPL0280.
035625
       COPY XCPS0290.
       COPY XCPL0290.

025970 COPY CCPS0620.
       COPY CCPL0620.

025970 COPY XCPS1640.
       COPY XCPL1640.
035625 COPY XCPS1646.
035625 COPY XCPL1646.
025970 COPY XCPS1660.
       COPY XCPL1660.

       COPY CCPS2430.
       COPY CCPL2430.

       COPY CCPS2435.
       COPY CCPL2435.

021930*COPY XCPS8090.
       COPY XCPL8090.

      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCNTX.

021930*COPY CCPUCNTX.

       COPY CCPNPOL.

       COPY CCPUPOL.

       COPY CCPBPOLC.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      ****************************************************************
      *                  END OF PROGRAM CSOM7700                     *
      ****************************************************************
