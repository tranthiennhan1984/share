       IDENTIFICATION DIVISION.

       PROGRAM-ID. CSOM0051.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0051                                         **
      **  REMARKS:  PCNT - MAINTAIN COMMISSION RATE (CC) TABLE.      **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE FUNCTIONS **
      **            FOR THE COMMISSION RATE (CC) TABLE.              **
      **  DOMAIN :  AG                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0051'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *
      /

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

      /
016537*COPY XCWEBLCH.
      /
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '2100' '2101'
                                                  '2102' '2103'
                                                  '2104'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '2100'.
               88  WS-BUS-FCN-CREATE        VALUE '2101'.
               88  WS-BUS-FCN-UPDATE        VALUE '2102'.
               88  WS-BUS-FCN-DELETE        VALUE '2103'.
               88  WS-BUS-FCN-LIST          VALUE '2104'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '2100'.
       01  OTHER-WORK-AREAS.
           05  COMMCODE-MISC-WORK-AREAS.
016548*        10  CC-MAX             PIC S9(4) COMP VALUE +11.
023514*        10  CC-MAX             PIC S9(4) BINARY VALUE +11.
023514         10  CC-MAX             PIC S9(4) BINARY.
               10  WS-SUB             PIC 999.
           05  INIT-VALUE.
               10  FILLER             PIC X(10)   VALUE '+000.00004'.
               10  FILLER             PIC X(10)   VALUE '+000.00007'.
               10  FILLER             PIC X(10)   VALUE '+000.00007'.
               10  FILLER             PIC X(10)   VALUE '+000.00007'.
               10  FILLER             PIC X(10)   VALUE '+000.00007'.
               10  FILLER             PIC X(10)   VALUE '+000.00008'.
               10  FILLER             PIC X(10)   VALUE '+000.00008'.
               10  FILLER             PIC X(10)   VALUE '+000.00008'.
               10  FILLER             PIC X(10)   VALUE '+000.00008'.
               10  FILLER             PIC X(10)   VALUE '+000.00008'.
               10  FILLER             PIC X(10)   VALUE '+000.00008'.
           05  INIT-TABLE  REDEFINES  INIT-VALUE  OCCURS 11 TIMES.
               10  INIT-CODE          PIC X(9).
               10  INIT-TYPE          PIC X.
           05  CC-SAVE                            OCCURS 11 TIMES.
               10  CCODE-SAVE.
                   15  CCSIGN                     PIC X.
                       88  CSIGN-VALID            VALUES '+' '-'.
                   15  CCWHLN                     PIC 999.
                   15  CCPT                       PIC X.
                       88 CCPT-VALID              VALUE '.'.
                   15  CCDECN                     PIC V9999.

           05  EDIT-RATE.
               10  EDIT-AGENT-RT                  PIC +999.9999
                                                  OCCURS 11 TIMES.
           05  ERROR-IND                          OCCURS 11 TIMES.
               10  ERR-IND                            PIC 9.
                   88  NO-ERRORS                      VALUE 0.
                   88  ERR-FOUND                      VALUE 1.
           05  WS-VALID-COMM-TYPE                 OCCURS 11 TIMES.
               10  WS-TYPE                            PIC X.
                   88  VALID-TYPE            VALUES '1' '4' '7' '8'
                      '9' 'L' 'M' 'N' 'O' 'P' 'Q' 'R' 'S' 'T' 'U'
                      'V' 'W' 'X' 'Y' 'Z'.
                      

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                        PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT            VALUE '2100'.
      /
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
       COPY CCFRCC.
       COPY CCFWCC.
      /
       COPY XCWL0280.
014221 COPY XCWL8090.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0051.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
557708
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
025970*    MOVE MIR-BUS-FCN-ID        TO  WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK          TO  TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.


           EVALUATE TRUE
               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X
      *
               WHEN WS-BUS-FCN-LIST
                   PERFORM  3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X
      *
               WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X
      *
               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X
      *
               WHEN WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X
557660     END-EVALUATE.
      *

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------------------------------------------------
      *   INQUIRY PROCESSING: RETRIEVE RECORD AND DISPLAY.
      *----------------------------------------------------------------
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

      *
      *    SET UP WCC-KEY FIELDS
      *
           MOVE MIR-RTBL2-ID          TO WCC-RTBL2-ID.
014221*    PERFORM  CC-1000-READ
014221*        THRU CC-1000-READ-X.

014221     PERFORM  CC-1000-READ-TWRK-TS
014221         THRU CC-1000-READ-TWRK-TS-X.

      *
           IF WCC-IO-OK
              PERFORM  7000-DISPLAY-RECORDS
                  THRU 7000-DISPLAY-RECORDS-X
           ELSE
              PERFORM  9100-INIT-DATA-FIELDS
                  THRU 9100-INIT-DATA-FIELDS-X
                  VARYING WS-SUB FROM 1 BY 1
023514*           UNTIL WS-SUB > 11
023514            UNTIL WS-SUB > CC-MAX
      ***     MESSAGE 'PCNT CODE NOT IN FILE'        ***
              MOVE 'CS00510002'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.

      /
      *---------------------------------------------------------------
      *   LIST THE RECORDS STARTING FROM THE BROWSE KEY
      *---------------------------------------------------------------
      *------------------
       3500-PROCESS-LIST.
      *------------------

      *
      *    SET UP BROWSE KEYS
      *
           PERFORM  9100-INIT-DATA-FIELDS
               THRU 9100-INIT-DATA-FIELDS-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 11.

           MOVE MIR-RTBL2-ID         TO  WCC-RTBL2-ID.
           MOVE HIGH-VALUE           TO  WCC-ENDBR-KEY.

           PERFORM  CC-1000-BROWSE
               THRU CC-1000-BROWSE-X.

           IF  NOT WCC-IO-OK
               PERFORM  CC-3000-END-BROWSE
                   THRU CC-3000-END-BROWSE-X
               MOVE 'XS00000034'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  CC-2000-READ-NEXT
               THRU CC-2000-READ-NEXT-X.

           PERFORM
               VARYING  WS-SUB FROM 1 BY 1
               UNTIL NOT WCC-IO-OK
               OR    (WS-SUB > 11)

               MOVE RCC-RTBL2-PCT(1) TO  EDIT-AGENT-RT (WS-SUB)
               MOVE RCC-RTBL2-ID     TO MIR-RTBL2-ID-T (WS-SUB)
               MOVE EDIT-AGENT-RT (WS-SUB)
                                     TO MIR-RTBL2-1-RT-T (WS-SUB)
               PERFORM  CC-2000-READ-NEXT
                   THRU CC-2000-READ-NEXT-X

           END-PERFORM.

           IF WCC-IO-OK
               MOVE RCC-RTBL2-ID     TO MIR-RTBL2-ID
           END-IF.

           PERFORM  CC-3000-END-BROWSE
               THRU CC-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *---------------------------------------------------------------
      *   CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, INIT NEW
      *   RECORD AND ALLOW USER TO MODIFY.
      *----------------------------------------------------------------
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      *
      *
      *    SET UP WCC-KEY FIELDS
      *
           MOVE MIR-RTBL2-ID          TO WCC-RTBL2-ID.
           PERFORM  CC-1000-READ
               THRU CC-1000-READ-X.
      *
           IF WCC-IO-OK
              PERFORM  7000-DISPLAY-RECORDS
                  THRU 7000-DISPLAY-RECORDS-X
      ***     MESSAGE 'PCNT CODE ALREADY IN FILE'***
              MOVE 'CS00510001'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  4100-CREATE-EDITS
               THRU 4100-CREATE-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > 0
              GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           MOVE MIR-RTBL2-ID          TO WCC-RTBL2-ID.
      *
           PERFORM  CC-1000-CREATE
               THRU CC-1000-CREATE-X.

           PERFORM  CC-1000-WRITE
               THRU CC-1000-WRITE-X.

014221     PERFORM  CC-1000-READ-TWRK-TS
014221         THRU CC-1000-READ-TWRK-TS-X.

      *
           PERFORM  7000-DISPLAY-RECORDS
               THRU 7000-DISPLAY-RECORDS-X.
      *
      ***  MESSAGE 'RECORD CREATED - CONTINUE'***
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      *
      *
      *------------------
       4100-CREATE-EDITS.
      *------------------

           IF  MIR-RTBL2-ID               =   SPACES
               MOVE 'CS00510004'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-INIT-DATA-FIELDS
                   THRU 9100-INIT-DATA-FIELDS-X
                   VARYING WS-SUB FROM 1 BY 1
023514*            UNTIL   WS-SUB > 11
023514             UNTIL   WS-SUB > CC-MAX
557660     END-IF.

       4100-CREATE-EDITS-X.
           EXIT.
      *
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------
      *---------------------------------------------------------------
      *   MAINTAIN PROCESSING: GET RECORD, EDIT DATA FIELDS, AND UPDATE
      *   IF NO EDIT ERRORS; ELSE UNLOCK.
      *----------------------------------------------------------------
      *
      *    SET UP WCC-KEY FIELDS
      *
           MOVE MIR-RTBL2-ID          TO WCC-RTBL2-ID.
014221*    PERFORM  CC-1000-READ-FOR-UPDATE
014221*        THRU CC-1000-READ-FOR-UPDATE-X.

014221     PERFORM  CC-2000-UPDATE-TWRK-TS
014221         THRU CC-2000-UPDATE-TWRK-TS-X.

           IF  WCC-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  9100-INIT-DATA-FIELDS
                   THRU 9100-INIT-DATA-FIELDS-X
                   VARYING WS-SUB FROM 1 BY 1
023514*            UNTIL   WS-SUB > 11
023514             UNTIL   WS-SUB > CC-MAX
014221         EVALUATE TRUE
014221           WHEN  MIR-RETRN-TS-MISMATCH
014221              MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221              MOVE 'CC'               TO WGLOB-MSG-PARM (01)
014221              MOVE WCC-KEY            TO WGLOB-MSG-PARM (02)
014221              PERFORM  0260-1000-GENERATE-MESSAGE
014221                  THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5000-PROCESS-UPDATE-X
014221           WHEN OTHER
      *      MESSAGE 'RECORD LOST IN MAINTAIN (@1) - CONTACT SYSTEMS'
                   MOVE WCC-KEY           TO WGLOB-MSG-PARM (1)
                   MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5000-PROCESS-UPDATE-X
014221        END-EVALUATE
           END-IF.

           PERFORM  7500-EDIT-FIELDS
               THRU 7500-EDIT-FIELDS-X.

           PERFORM  CC-2000-REWRITE
               THRU CC-2000-REWRITE-X.

014221     PERFORM  CC-1000-READ-TWRK-TS
014221         THRU CC-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW = 0
      ***      MESSAGE 'MAINTENANCE COMPLETE - CONTINUE'***
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      ***      MESSAGE 'RECORD UPDATED'                ***
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.

      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------
      *
           MOVE MIR-RTBL2-ID          TO WCC-RTBL2-ID.
014221*    PERFORM  CC-1000-READ-FOR-UPDATE
014221*        THRU CC-1000-READ-FOR-UPDATE-X.

014221     PERFORM  CC-2000-UPDATE-TWRK-TS
014221         THRU CC-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'CC'               TO WGLOB-MSG-PARM (01)
014221         MOVE WCC-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  9100-INIT-DATA-FIELDS
014221             THRU 9100-INIT-DATA-FIELDS-X
014221         VARYING WS-SUB FROM 1 BY 1
023514*        UNTIL   WS-SUB > 11
023514         UNTIL   WS-SUB > CC-MAX
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.
      *
           IF WCC-IO-OK
               PERFORM  CC-1000-DELETE
                   THRU CC-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
           ELSE
014221         EVALUATE TRUE
014221           WHEN  MIR-RETRN-TS-MISMATCH
014221              MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221              MOVE 'CC'               TO WGLOB-MSG-PARM (01)
014221              MOVE WCC-KEY            TO WGLOB-MSG-PARM (02)
014221              PERFORM  0260-1000-GENERATE-MESSAGE
014221                  THRU 0260-1000-GENERATE-MESSAGE-X
014221           WHEN OTHER
                    MOVE WCC-RTBL2-ID      TO WGLOB-MSG-PARM (1)
                    MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
014221         END-EVALUATE
           END-IF.
      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
           PERFORM  9100-INIT-DATA-FIELDS
               THRU 9100-INIT-DATA-FIELDS-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > 11.
      *
       6000-PROCESS-DELETE-X.
           EXIT.
      *
      /
      *---------------------
       7000-DISPLAY-RECORDS.
      *---------------------
      *
           PERFORM  7100-FORMAT-AGENT-RT
               THRU 7100-FORMAT-AGENT-RT-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > 11.
      *
      ***  MOVE ALL RECORD FIELDS TO THE SCREEN (MIR- FIELDS)
           PERFORM
             VARYING WS-SUB FROM 1 BY 1
023514*      UNTIL WS-SUB > 11
023514       UNTIL WS-SUB > CC-MAX
              MOVE EDIT-AGENT-RT (WS-SUB)
                                      TO  MIR-RTBL2-1-RT-T (WS-SUB)
              MOVE RCC-COMM-TYP-CD (WS-SUB)
015904*                               TO  MIR-COMM-TYP-CD-T (WS-SUB)
015904                                TO  MIR-COMM-TYP-1-CD-T (WS-SUB)
           END-PERFORM.

       7000-DISPLAY-RECORDS-X.
           EXIT.
      *
      *---------------------
       7100-FORMAT-AGENT-RT.
      *---------------------
           MOVE RCC-RTBL2-PCT (WS-SUB)       TO  EDIT-AGENT-RT (WS-SUB).
       7100-FORMAT-AGENT-RT-X.
           EXIT.
      /
      *-----------------
       7500-EDIT-FIELDS.
      *-----------------
      *
      *
      **   EDIT ALL FIELDS HERE (WHERE THE FIELD IS XXXX)
      **   ANY CROSS EDITS SHOULD BE DONE AFTER ALL OF THE FIELDS ARE
      **   EDITTED
      *
      *
           PERFORM  7510-EDIT-RATES
               THRU 7510-EDIT-RATES-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > 11.
      *
           PERFORM  7520-EDIT-COMM-TYPE
               THRU 7520-EDIT-COMM-TYPE-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > 11.

       7500-EDIT-FIELDS-X.
           EXIT.
      *
      *
      *----------------
       7510-EDIT-RATES.
      *----------------
            MOVE MIR-RTBL2-1-RT-T (WS-SUB)
                                      TO L0280-INPUT-DATA.
            MOVE 'Y'                  TO L0280-SIGN-IND.
            MOVE  3                   TO L0280-LENGTH.
            MOVE  4                   TO L0280-PRECISION.
            MOVE  9                   TO L0280-INPUT-SIZE.
            PERFORM  0280-1000-NUMERIC-EDIT
                THRU 0280-1000-NUMERIC-EDIT-X.
            IF  L0280-OK
                COMPUTE RCC-RTBL2-PCT (WS-SUB) = L0280-OUTPUT-V04
                MOVE RCC-RTBL2-PCT (WS-SUB)
                                      TO EDIT-AGENT-RT (WS-SUB)
                MOVE EDIT-AGENT-RT (WS-SUB)
                                      TO MIR-RTBL2-1-RT-T (WS-SUB)
            ELSE
              MOVE 'XS00000018'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       7510-EDIT-RATES-X.
           EXIT.
      *
      *--------------------
       7520-EDIT-COMM-TYPE.
      *--------------------
      *
015904*    MOVE MIR-COMM-TYP-CD-T (WS-SUB)
015904     MOVE MIR-COMM-TYP-1-CD-T (WS-SUB)
                                      TO WS-TYPE (WS-SUB).
           IF VALID-TYPE (WS-SUB)
015904*        MOVE MIR-COMM-TYP-CD-T (WS-SUB)
015904         MOVE MIR-COMM-TYP-1-CD-T (WS-SUB)
                                      TO RCC-COMM-TYP-CD (WS-SUB)
           ELSE
               MOVE 'CS00510003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       7520-EDIT-COMM-TYPE-X.
           EXIT.
      /
      *----------------------
       9100-INIT-DATA-FIELDS.
      *----------------------
           MOVE INIT-CODE (WS-SUB)    TO MIR-RTBL2-1-RT-T (WS-SUB).
015904*    MOVE INIT-TYPE (WS-SUB)    TO MIR-COMM-TYP-CD-T (WS-SUB).
015904     MOVE INIT-TYPE (WS-SUB)    TO MIR-COMM-TYP-1-CD-T (WS-SUB).
           MOVE SPACE                 TO MIR-RTBL2-ID-T (WS-SUB).
       9100-INIT-DATA-FIELDS-X.
           EXIT.
      *
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
023514     INITIALIZE COMMCODE-MISC-WORK-AREAS.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE EDIT-RATE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE MIR-BUS-FCN-ID        TO  WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK          TO  TRUE.
025970     SET WS-TWRK-KEY-DEFAULT    TO TRUE. 
023514     COMPUTE CC-MAX = LENGTH OF MIR-COMM-TYP-1-CD-G
023514                    / LENGTH OF MIR-COMM-TYP-1-CD-T (1).
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
023514
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CC
014221                         '$VAR2' BY 'CC'.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      /
       COPY CCPACC.
      /
       COPY CCPBCC.
      /
       COPY CCPNCC.
      /
       COPY CCPUCC.
      /
       COPY CCPXCC.
      /
       COPY CCPCCC.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM0051                     **
      *****************************************************************
