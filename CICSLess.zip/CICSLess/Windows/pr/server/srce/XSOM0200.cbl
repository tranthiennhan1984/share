      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM0200.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM0200                                         **
      **  REMARKS: THIS MODULE ALLOWS THE USER TO 'CREATE','MAINTAIN'**
      **           OR 'DELETE' ENTRIES ON EDIT TABLES WITHIN THE     **
      **           XTAB TABLE.  BEFORE DETAIL ENTRIES MAY BE ADDED,  **
      **           THE TYPE OF TABLE MUST BE ADDED TO THE XTAB TABLE **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CHANGE TO STANDARD                               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
008445**  5.5.2     GENERATE MIR FROM TECH ARCH DATABASE             **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
006002**  6.0       USE ALT.INDEX FOR LANGUAGE BROWSE                **
012624**  6.0       ADD SELECTED MIXED CASE SUPPORT FOR TABLES       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016089**  6.1       CODE CLEANUP - LIST ALL LANGUAGES                **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016765**  6.2       EXPAND EDIT TYPE ID AND DESCRIPTION              **
017055**  6.3       CHANGE TO LANGUAGE FILTER ON EDIT LISTS          **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023389**  6.5       VALUE FOR BRANCH ID IS CASE SENSITIVE            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
027709**  6.7       SECURITY CLASS LIST INCORRECT VALUE ETBL_VALU_ID **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM0200'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


012624 COPY XCWL0005.
014590*COPY XCWL0030.


       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
006002*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +10  COMP.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +250 COMP.
016765*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +250
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +200
025970*                                     BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID                 VALUES ARE
                   '2000', '2001', '2002', '2003', '2004'.
               88  WS-BUS-FCN-RETRIEVE              VALUE '2000'.
               88  WS-BUS-FCN-CREATE                VALUE '2001'.
               88  WS-BUS-FCN-UPDATE                VALUE '2002'.
               88  WS-BUS-FCN-DELETE                VALUE '2003'.
               88  WS-BUS-FCN-LIST                  VALUE '2004'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '2000'.
016765*    05  WS-SPCL-FOR-VALU-ID                  PIC X(15).
016765     05  WS-SPCL-FOR-VALU-ID                  PIC X(30).
012624         88  WS-SPCL-MIXED-CASE-VALU-ID       VALUE 'BPFID'.
027709     05  WS-CHAR-PTR                     PIC 9(09) BINARY.  

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES             PIC S9(4) BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT VALUE +200.

025970     05  WS-TWRK-KEY                     PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT         VALUE '2000'.
025970

      /
      *****************************************************************
      *  COMMON COPYBOOKS
      *****************************************************************
016537*COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS
      *****************************************************************
       COPY XCFRXTAB.
       COPY XCFWXTAB.
006002 COPY XCFWXTAD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION
      *****************************************************************
014221 COPY XCWL8090.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION
      *****************************************************************
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY XCWM0200.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*           SET  MIR-RETRN-OK          TO TRUE.
025970*           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  MIR-ETBL-LANG-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES      TO MIR-ETBL-LANG-CD
           END-IF.

           IF  MIR-ETBL-TYP-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES      TO MIR-ETBL-TYP-ID
           END-IF.

      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2100-PROCESS-RETRIEVE
                        THRU 2100-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2200-PROCESS-CREATE
                        THRU 2200-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2300-PROCESS-UPDATE
                        THRU 2300-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2400-PROCESS-DELETE
                        THRU 2400-PROCESS-DELETE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2500-PROCESS-LIST
                        THRU 2500-PROCESS-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM0200'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       2100-PROCESS-RETRIEVE.
      *----------------------

012624     PERFORM  2700-CONVERT-XTAB-KEY
012624         THRU 2700-CONVERT-XTAB-KEY-X.
           MOVE MIR-ETBL-TYP-ID       TO WXTAB-ETBL-TYP-ID.
           MOVE MIR-ETBL-VALU-ID      TO WXTAB-ETBL-VALU-ID.
           MOVE MIR-ETBL-LANG-CD      TO WXTAB-ETBL-LANG-CD.
014221*    PERFORM  XTAB-1000-READ
014221*        THRU XTAB-1000-READ-X.
014221     PERFORM  XTAB-1000-READ-TWRK-TS
014221         THRU XTAB-1000-READ-TWRK-TS-X.

           IF WXTAB-IO-OK
              PERFORM  9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X

           ELSE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X

               MOVE WXTAB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2100-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       2200-PROCESS-CREATE.
      *--------------------

012624     PERFORM  2700-CONVERT-XTAB-KEY
012624         THRU 2700-CONVERT-XTAB-KEY-X.

027709     IF  MIR-ETBL-TYP-ID = 'USCL'
027709         PERFORM  2220-EDIT-USCL
027709             THRU 2220-EDIT-USCL-X
027709         IF  WGLOB-MSG-ERROR-SW > ZERO
027709             GO TO 2200-PROCESS-CREATE-X
027709         END-IF
027709     END-IF.


           MOVE MIR-ETBL-TYP-ID       TO WXTAB-ETBL-TYP-ID.
           MOVE MIR-ETBL-VALU-ID      TO WXTAB-ETBL-VALU-ID.
           MOVE MIR-ETBL-LANG-CD      TO WXTAB-ETBL-LANG-CD.
           PERFORM  XTAB-1000-READ
               THRU XTAB-1000-READ-X.

           IF WXTAB-IO-OK
              MOVE WXTAB-KEY          TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000003'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

              GO TO 2200-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  2210-CREATE-EDITS
               THRU 2210-CREATE-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 2200-PROCESS-CREATE-X
557660     END-IF.

           MOVE MIR-ETBL-TYP-ID       TO WXTAB-ETBL-TYP-ID.
           MOVE MIR-ETBL-VALU-ID      TO WXTAB-ETBL-VALU-ID.
           MOVE MIR-ETBL-LANG-CD      TO WXTAB-ETBL-LANG-CD.
           PERFORM  XTAB-1000-CREATE
               THRU XTAB-1000-CREATE-X.

           PERFORM  XTAB-1000-WRITE
               THRU XTAB-1000-WRITE-X.

014221     PERFORM  XTAB-1000-READ-TWRK-TS
014221         THRU XTAB-1000-READ-TWRK-TS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2200-PROCESS-CREATE-X.
           EXIT.
      /
      *------------------
       2210-CREATE-EDITS.
      *------------------

      *
      *     VALIADATE TYPE
      *
           IF  WXTAB-ETBL-TYP-ID     = 'XTAB'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'XTAB'            TO WXTAB-ETBL-TYP-ID
               MOVE MIR-ETBL-TYP-ID   TO WXTAB-ETBL-VALU-ID
               MOVE WGLOB-EDIT-LANG   TO WXTAB-ETBL-LANG-CD
               PERFORM  XTAB-1000-READ
                   THRU XTAB-1000-READ-X

               IF  WXTAB-IO-OK
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE 'XS02000001'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

                   GO TO 2210-CREATE-EDITS-X
557660         END-IF
557660     END-IF.

      *
      *     VALIADATE LANGUAGE
      *
           MOVE 'ELANG'               TO WXTAB-ETBL-TYP-ID.
           MOVE MIR-ETBL-LANG-CD      TO WXTAB-ETBL-VALU-ID.
           MOVE WGLOB-EDIT-LANG       TO WXTAB-ETBL-LANG-CD.
           PERFORM  XTAB-1000-READ
               THRU XTAB-1000-READ-X.

           IF  WXTAB-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'XS02000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 2210-CREATE-EDITS-X
557660     END-IF.

       2210-CREATE-EDITS-X.
           EXIT.
      /
027709*---------------
027709 2220-EDIT-USCL.
027709*---------------
027709
027709* CHECK WHETHER LENGTH OF MIR-ETBL-VALU-ID > 10 FOR USCL
027709
027709     PERFORM
027709       VARYING WS-CHAR-PTR FROM LENGTH OF MIR-ETBL-VALU-ID BY -1
027709         UNTIL WS-CHAR-PTR = ZERO
027709            OR MIR-ETBL-VALU-ID (WS-CHAR-PTR:1) NOT = SPACE
027709         CONTINUE
027709     END-PERFORM.
027709
027709     IF  WS-CHAR-PTR > 10
027709*MSG: VALID VALUE EXCEEDS 10 CHARACTERS FOR SECURITY CLASSES
027709         MOVE 'XS02000004'      TO WGLOB-MSG-REF-INFO
027709         PERFORM  0260-1000-GENERATE-MESSAGE
027709             THRU 0260-1000-GENERATE-MESSAGE-X
027709     END-IF.
027709
027709 2220-EDIT-USCL-X.
027709     EXIT.
      /
      *--------------------
       2300-PROCESS-UPDATE.
      *--------------------

012624     PERFORM  2700-CONVERT-XTAB-KEY
012624         THRU 2700-CONVERT-XTAB-KEY-X.
           MOVE MIR-ETBL-TYP-ID       TO WXTAB-ETBL-TYP-ID.
           MOVE MIR-ETBL-VALU-ID      TO WXTAB-ETBL-VALU-ID.
           MOVE MIR-ETBL-LANG-CD      TO WXTAB-ETBL-LANG-CD.
014221*    PERFORM  XTAB-1000-READ-FOR-UPDATE
014221*        THRU XTAB-1000-READ-FOR-UPDATE-X.
014221     PERFORM  XTAB-2000-UPDATE-TWRK-TS
014221         THRU XTAB-2000-UPDATE-TWRK-TS-X.

           IF WXTAB-IO-NOT-FOUND
              PERFORM  9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X

              MOVE WXTAB-KEY          TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000006'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

              GO TO 2300-PROCESS-UPDATE-X
557660     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'XTAB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WXTAB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2300-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  2330-MAINTAIN-EDITS
               THRU 2330-MAINTAIN-EDITS-X.

           PERFORM  XTAB-2000-REWRITE
               THRU XTAB-2000-REWRITE-X.

014221     PERFORM  XTAB-1000-READ-TWRK-TS
014221         THRU XTAB-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
              MOVE 'XS00000008'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

           ELSE
              MOVE 'XS00000007'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2300-PROCESS-UPDATE-X.
           EXIT.
      /
      *--------------------
       2330-MAINTAIN-EDITS.
      *--------------------

           IF MIR-ETBL-DESC-TXT NOT = SPACE
              MOVE MIR-ETBL-DESC-TXT  TO RXTAB-ETBL-DESC-TXT
           ELSE
              MOVE RXTAB-ETBL-DESC-TXT TO MIR-ETBL-DESC-TXT
           END-IF.

       2330-MAINTAIN-EDITS-X.
           EXIT.
      /
      *--------------------
       2400-PROCESS-DELETE.
      *--------------------

012624     PERFORM  2700-CONVERT-XTAB-KEY
012624         THRU 2700-CONVERT-XTAB-KEY-X.
           MOVE MIR-ETBL-TYP-ID       TO WXTAB-ETBL-TYP-ID.
           MOVE MIR-ETBL-VALU-ID      TO WXTAB-ETBL-VALU-ID.
           MOVE MIR-ETBL-LANG-CD      TO WXTAB-ETBL-LANG-CD.
014221*    PERFORM  XTAB-1000-READ-FOR-UPDATE
014221*        THRU XTAB-1000-READ-FOR-UPDATE-X.
014221     PERFORM  XTAB-2000-UPDATE-TWRK-TS
014221         THRU XTAB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'XTAB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WXTAB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2400-PROCESS-DELETE-X
014221     END-IF.

           IF WXTAB-IO-OK
              PERFORM  XTAB-1000-DELETE
                  THRU XTAB-1000-DELETE-X

              MOVE 'XS00000011'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

           ELSE
              MOVE WXTAB-KEY          TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000010'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       2400-PROCESS-DELETE-X.
           EXIT.
      /
      *------------------
       2500-PROCESS-LIST.
      *------------------

012624     PERFORM  2700-CONVERT-XTAB-KEY
012624         THRU 2700-CONVERT-XTAB-KEY-X.

           IF MIR-ETBL-TYP-ID > SPACES
034802*       NEXT SENTENCE
034802        CONTINUE
           ELSE
              MOVE 'XS02000003'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

              GO TO 2500-PROCESS-LIST-X
557660     END-IF.

006002
006002* BROWSE BY DESCRIPTION ONLY FOR THE RELEASE 60
006002
016089*    IF  MIR-ETBL-LANG-CD     = SPACE
016089*        MOVE WGLOB-EDIT-LANG   TO MIR-ETBL-LANG-CD
016089*    END-IF.
006002
006002     IF  MIR-ETBL-LANG-CD NOT = SPACE
006002         PERFORM  2600-PROCESS-LIST-AIX
006002             THRU 2600-PROCESS-LIST-AIX-X
006002         GO TO 2500-PROCESS-LIST-X
006002     END-IF.
006002
           MOVE LOW-VALUES            TO WXTAB-KEY.
017055*    MOVE HIGH-VALUES           TO WXTAB-ENDBR-KEY.
           MOVE MIR-ETBL-TYP-ID       TO WXTAB-ETBL-TYP-ID.
           MOVE MIR-ETBL-VALU-ID      TO WXTAB-ETBL-VALU-ID.
016089*    MOVE MIR-ETBL-LANG-CD      TO WXTAB-ETBL-LANG-CD.
017055     MOVE WXTAB-KEY             TO WXTAB-ENDBR-KEY.
017055     MOVE HIGH-VALUES           TO WXTAB-ENDBR-ETBL-VALU-ID.
017055     MOVE HIGH-VALUES           TO WXTAB-ENDBR-ETBL-LANG-CD.

           PERFORM  XTAB-1000-BROWSE
               THRU XTAB-1000-BROWSE-X.

           IF WXTAB-IO-EOF
              MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

              GO TO 2500-PROCESS-LIST-X
           ELSE
              PERFORM  XTAB-2000-READ-NEXT
                  THRU XTAB-2000-READ-NEXT-X

              IF WXTAB-IO-EOF
                 MOVE 'XS00000025'    TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X

                 GO TO 2500-PROCESS-LIST-X
557660        END-IF
557660     END-IF.

           PERFORM  2510-PROCESS-BROWSE-READ
557660         THRU 2510-PROCESS-BROWSE-READ-X VARYING WS-SUB FROM +1
                    BY +1 UNTIL WS-SUB > WS-MAX-BROWSE-LINES OR
                    WXTAB-IO-EOF.

           IF WXTAB-IO-EOF
              MOVE 'XS00000025'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

           ELSE
              MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
              SET WGLOB-MORE-DATA-EXISTS TO TRUE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  XTAB-3000-END-BROWSE
               THRU XTAB-3000-END-BROWSE-X.

       2500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------------
       2510-PROCESS-BROWSE-READ.
      *-------------------------

008445*    MOVE RXTAB-ETBL-TYP-ID     TO MIR-ETBL-TYP-ID-T  (WS-SUB).
008445*    MOVE RXTAB-ETBL-VALU-ID    TO MIR-ETBL-VALU-ID-T (WS-SUB).
008445*    MOVE RXTAB-ETBL-LANG-CD    TO MIR-ETBL-LANG-CD-T  (WS-SUB).
008445     MOVE RXTAB-ETBL-TYP-ID     TO MIR-ETBL-TYP-ID-T   (WS-SUB).
008445     MOVE RXTAB-ETBL-VALU-ID    TO MIR-ETBL-VALU-ID-T  (WS-SUB).
008445     MOVE RXTAB-ETBL-LANG-CD    TO MIR-ETBL-LANG-CD-T  (WS-SUB).
           MOVE RXTAB-ETBL-DESC-TXT   TO MIR-ETBL-DESC-TXT-T (WS-SUB).

           PERFORM  XTAB-2000-READ-NEXT
               THRU XTAB-2000-READ-NEXT-X.

           IF WS-SUB = WS-MAX-BROWSE-LINES
              IF WXTAB-IO-OK
                 MOVE RXTAB-ETBL-TYP-ID
                                      TO MIR-ETBL-TYP-ID
                 MOVE RXTAB-ETBL-VALU-ID
                                      TO MIR-ETBL-VALU-ID
016089*          MOVE RXTAB-ETBL-LANG-CD
016089*                               TO MIR-ETBL-LANG-CD
016089           MOVE RXTAB-ETBL-DESC-TXT
016089                                TO MIR-ETBL-DESC-TXT
557660        END-IF
557660     END-IF.

       2510-PROCESS-BROWSE-READ-X.
           EXIT.
      /
006002*----------------------
006002 2600-PROCESS-LIST-AIX.
006002*----------------------
006002
006002     MOVE LOW-VALUES             TO WXTAD-KEY.
006002     MOVE MIR-ETBL-TYP-ID        TO WXTAD-ETBL-TYP-ID.
006002     MOVE MIR-ETBL-LANG-CD       TO WXTAD-ETBL-LANG-CD.
006002     MOVE MIR-ETBL-DESC-TXT      TO WXTAD-ETBL-DESC-TXT.
006002     MOVE MIR-ETBL-VALU-ID       TO WXTAD-ETBL-VALU-ID.
006002     MOVE WXTAD-KEY              TO WXTAD-ENDBR-KEY.
006002     MOVE HIGH-VALUES            TO WXTAD-ENDBR-ETBL-DESC-TXT.
006002     MOVE HIGH-VALUES            TO WXTAD-ENDBR-ETBL-VALU-ID.
006002
006002     MOVE SPACES                 TO MIR-ETBL-VALU-ID-G.
006002     MOVE SPACES                 TO MIR-ETBL-DESC-TXT-G.
006002
006002     PERFORM  XTAD-1000-BROWSE
006002         THRU XTAD-1000-BROWSE-X.
006002
006002     IF  NOT WXTAD-IO-OK
006002         PERFORM  XTAD-3000-END-BROWSE
006002             THRU XTAD-3000-END-BROWSE-X
006002         MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
006002         PERFORM  0260-1000-GENERATE-MESSAGE
006002             THRU 0260-1000-GENERATE-MESSAGE-X
006002         GO TO 2600-PROCESS-LIST-AIX-X
006002     END-IF.
006002
006002     PERFORM  XTAD-2000-READ-NEXT
006002         THRU XTAD-2000-READ-NEXT-X.
006002
006002     PERFORM
006002         VARYING WS-SUB FROM 1 BY 1
006002         UNTIL WXTAD-IO-EOF
006002         OR    (WS-SUB > WS-MAX-BROWSE-LINES)
006002
006002         MOVE RXTAB-ETBL-TYP-ID   TO MIR-ETBL-TYP-ID-T   (WS-SUB)
006002         MOVE RXTAB-ETBL-VALU-ID  TO MIR-ETBL-VALU-ID-T  (WS-SUB)
006002         MOVE RXTAB-ETBL-LANG-CD  TO MIR-ETBL-LANG-CD-T  (WS-SUB)
006002         MOVE RXTAB-ETBL-DESC-TXT TO MIR-ETBL-DESC-TXT-T (WS-SUB)
006002
006002         PERFORM  XTAD-2000-READ-NEXT
006002             THRU XTAD-2000-READ-NEXT-X
006002
006002     END-PERFORM.
006002
006002     IF  NOT WXTAD-IO-EOF
006002         MOVE RXTAB-ETBL-VALU-ID TO MIR-ETBL-VALU-ID
006002         MOVE RXTAB-ETBL-LANG-CD TO MIR-ETBL-LANG-CD
006002         MOVE RXTAB-ETBL-TYP-ID  TO MIR-ETBL-TYP-ID
006002         MOVE RXTAB-ETBL-DESC-TXT TO MIR-ETBL-DESC-TXT
006002         MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
006002         SET WGLOB-MORE-DATA-EXISTS TO TRUE
006002         PERFORM  0260-1000-GENERATE-MESSAGE
006002             THRU 0260-1000-GENERATE-MESSAGE-X
006002     ELSE
006002         MOVE 'XS00000025'       TO WGLOB-MSG-REF-INFO
006002         PERFORM  0260-1000-GENERATE-MESSAGE
006002             THRU 0260-1000-GENERATE-MESSAGE-X
006002     END-IF.
006002
006002     PERFORM  XTAD-3000-END-BROWSE
006002         THRU XTAD-3000-END-BROWSE-X.
006002
006002
006002 2600-PROCESS-LIST-AIX-X.
006002     EXIT.
006002/

012624*--------------------
012624 2700-CONVERT-XTAB-KEY.
012624*--------------------
023389
023389     PERFORM  0005-1000-BUILD-PARM-INFO
023389         THRU 0005-1000-BUILD-PARM-INFO-X.
023389
023389     IF  WGLOB-COUNTRY-JAPAN
023389     AND MIR-ETBL-LANG-CD = 'E'
023389         SET L0005-FORCE-UPPER  TO TRUE
023389     END-IF.
012624
012624     MOVE MIR-ETBL-TYP-ID       TO L0005-INPUT-STRING.
012624     PERFORM  0005-1000-CONVERT-STRING
012624         THRU 0005-1000-CONVERT-STRING-X.
012624     MOVE L0005-OUTPUT-STRING   TO MIR-ETBL-TYP-ID.
012624
012624     MOVE MIR-ETBL-TYP-ID       TO WS-SPCL-FOR-VALU-ID.
012624
012624     IF WS-SPCL-MIXED-CASE-VALU-ID
034802*        NEXT SENTENCE
034802         CONTINUE
012624     ELSE
012624         MOVE MIR-ETBL-VALU-ID      TO L0005-INPUT-STRING
012624         PERFORM  0005-1000-CONVERT-STRING
012624             THRU 0005-1000-CONVERT-STRING-X
012624         MOVE L0005-OUTPUT-STRING   TO MIR-ETBL-VALU-ID
012624     END-IF.
012624
012624     MOVE MIR-ETBL-LANG-CD      TO L0005-INPUT-STRING.
012624     PERFORM  0005-1000-CONVERT-STRING
012624         THRU 0005-1000-CONVERT-STRING-X.
012624     MOVE L0005-OUTPUT-STRING   TO MIR-ETBL-LANG-CD.
012624
012624 2700-CONVERT-XTAB-KEY-X.
012624     EXIT.

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                 TO MIR-ETBL-DESC-TXT.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RXTAB-ETBL-TYP-ID     TO MIR-ETBL-TYP-ID.
           MOVE RXTAB-ETBL-VALU-ID    TO MIR-ETBL-VALU-ID.
           MOVE RXTAB-ETBL-LANG-CD    TO MIR-ETBL-LANG-CD.
           MOVE RXTAB-ETBL-DESC-TXT   TO MIR-ETBL-DESC-TXT.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACE                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.

025970     PERFORM  0005-0000-INIT-PARM-INFO
025970         THRU 0005-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.

       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY XTAB
014221                         '$VAR2' BY 'XTAB'.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS8090.
023389 COPY XCPS0005.
012624 COPY XCPL0005.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY XCPBXTAB.
      /
       COPY XCPNXTAB.
      /
       COPY XCPUXTAB.
      /
       COPY XCPAXTAB.
      /
       COPY XCPCXTAB.
      /
       COPY XCPXXTAB.
006002/
006002 COPY XCPBXTAD.

      *****************************************************************
      **               END OF PROGRAM XSOM0200                       **
      *****************************************************************
