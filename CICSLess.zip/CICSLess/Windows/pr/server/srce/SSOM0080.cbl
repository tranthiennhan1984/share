      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. SSOM0080.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  SSOM0080                                         **
      **  REMARKS:  FSUR - PROCESS SEGREGATED FUND SURRENDERS        **
      **            THIS MODULE IS USED TO PROCESS SEGREGATED FUND   **
      **            SURRENDERS. THERE ARE SEVEN METHODS OF           **
      **            ALLOCATING THE SURRENDER, INCLUDING SURRENDER    **
      **            OF A SPECIFIC NUMBER OF UNITS. SURRENDER LOADS   **
      **            CAN BE FORCED ON THE SCREEN, OR THEY CAN BE      **
      **            CALCULATED. TAX WITHHOLDING CAN BE BYPASSED IF   **
      **            DESIRED.                                         **
      **                                                             **
      **  DOMAIN : CV                                                **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557701**  5.5       UNDO/REDO FOR SEGFUNDS                           **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZING FOR INTL SUPPORT             **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CLEAN UP.                                        **
004484**  5.6V      DELETE TSQ BEFORE WRITTING TO AVOID LATER        **
004484**            ON USING INCORRECT SAVED INFORMATION             **
011235**  5.6V      FSUR ALLOCATION CODE B                           **
012135**  5.6V      STATE FUND APPROVAL                              **
012137**  5.6V      SEC CONFIRMATION STATEMENTS                      **
012141**  5.6V      PORTFOLIO EXPANSION                              **
012143**  5.6V      DEPOSIT BASED SURRENDER CHARGES                  **
012146**  5.6V      MORTALITY & EXPENSE CHARGES                      **
012696**  5.6V      POLICY ALLOCATION                                **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
012624**  6.0       POLICY ACCESS VERIFICATION CHANGES               **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014591**  6.0       COMBINE PLAN\RS TWO PART FIELD                   **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014739**  6.0       FIX FSUR ABEND ON SELECTION OF FUNDS             **
015543**  6.0       CODE CLEANUP AND STANDARDIZATION                 **
016408**  6.1       SURRENDER BY PERCENTAGE                          **
013693**  6.2       LOCATION TAX                                     **
014221**  6.2       LOGICAL LOCKING                                  **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016440**  6.2       REMOVE RPOL-POL-APPL-CTL-CD                      **
016447**  6.2       FIX TO CREATE DEFERRED ACTIVITIES                **
016503**  6.2       SCHEDULING                                       **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
016107**  6.3       AUTO FACE REDUCTION (6.1.2J)                     **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
016571**  6.3       SURRENDER BY AMT REASON CODE NET FIX             **
018731**  6.3       EFT ENHANCEMENTS                                 **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018620**  6.4       ADD EDIT FOR LOCATION TAX CALC CODE              **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021311**  6.4       MULTI-PLATFORM SUPPORT                           **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
021239**  6.4       FUND UNIT VALUE                                  **
020463**  6.4       INVESTOR PROFILES                                **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
023091**  6.5       FIX REDO FOR MULTI CURRENCY PAYMENT              **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023226**  6.5       LIF MAX PYMT AMT CHANGE                          **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023444**  6.5       QUOTE INCOME ON WITHDRAWALS                      **
024550**  6.5       UNABLE TO OVERRIDE LOCATION TAX ON REG POLICY    **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025678**  6.6       FUND WITHDRAWAL BY UNITS NOT CALCULATE SURR CHRG **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
024958**  6.6       MODIFICATION FOR LOCAL TAX CALCULATION WHEN      **
024958**            TRANSACTION IS DEFERRED                          **
025325**  6.6       NEW FIELD TO STORE TAX DISP AMOUNT ON CDSA       **
028788**  6.7       EXTERNAL AGENCY INTEGRATION - POLICY EVENTS      **
029773**  6.7       99 COVERAGES HANDLING                            **
031034**  7.0       TAX COMPONENTIZATON                              **
032329**  7.0       99 COVERAGES AND 98 FUNDS HANDLING               **
031240**  7.1       ALLOCATION PERCENTS ON WITHDRAWAL BY AMOUNT      **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *---------------------
       ENVIRONMENT DIVISION.
      *---------------------

       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0080'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *
       COPY SQLCA.
018764*COPY XCWLPTR.
      *
      *
014590*COPY XCWL0030.
007766 COPY XCWWCVGM.
012141 COPY XCWWFNDM.
014221 COPY CCWWLOCK.
      *
       01  WS-SCREEN-WORK-AREA.
013578     05  WS-BUS-FCN-ID                    PIC X(04)
013578                                          VALUE SPACES.
013578         88  WS-BUS-FCN-PRORATE-FND-VALU  VALUE '1780'.
013578         88  WS-BUS-FCN-DOLLAR-AMT        VALUE '1781'.
013578         88  WS-BUS-FCN-PCT-AMT           VALUE '1782'.
013578         88  WS-BUS-FCN-PCT-TOT-VALU      VALUE '1783'.
013578         88  WS-BUS-FCN-PCT-FND-VALU      VALUE '1784'.
013578         88  WS-BUS-FCN-NUM-UNITS         VALUE '1785'.
025970*    05  WS-MAX-BROWSE-LINES              PIC S9(04)
025970*                                         VALUE +15.
032329*    05  WS-SCREEN-FS-DATA                OCCURS 25.
032329     05  WS-SCREEN-FS-DATA                OCCURS 98.
012696*        10  WS-FNUM.
012696*            15  WS-FNUM-N                PIC 9(2).
008455*        10  WS-FVAL-N                    PIC S9(11)V99 COMP-3.
008455         10  WS-FVAL-N                    PIC S9(15)V99 COMP-3.
               10  WS-SAMT.
008455*            15  WS-SAMT-N                PIC S9(7)V99 COMP-3.
008455             15  WS-SAMT-N                PIC S9(13)V99 COMP-3.
020464         10  WS-SCREEN-FS-DEFR-AMT.
020464             15  WS-SCREEN-FS-DEFR-IN-N   PIC S9(15)V99
020464                                          COMP-3.
020464             15  WS-SCREEN-FS-DEFR-OUT-N  PIC S9(15)V99
020464                                          COMP-3.
               10  WS-PALL.
                   15  WS-PALL-N                PIC S9(3)V9(4) COMP-3.
               10  WS-PFUN.
                   15  WS-PFUN-N                PIC S9(3)V9(04) COMP-3.
           05  WS-PRCES-STATE-CD                PIC X.
020475     05  WS-CVG-TRXN-AMT                  PIC S9(13)V99 COMP-3.
020475     05  WS-POL-DBG-ACCUM-AMT             PIC S9(13)V99 COMP-3.
020469     05  WS-POL-CRCY-CD                   PIC X(02)
020469                                          VALUE SPACES.
016503     05  WS-REBUILD-AFTER-REDO-SW         PIC X(01).
016503         88  WS-REBUILD-AFTER-REDO-NO     VALUE 'N'.
016503         88  WS-REBUILD-AFTER-REDO-YES    VALUE 'Y'.
023226     05  WS-RETRN-MAX-CHECK               PIC X(01).
023226         88  WS-RETRN-MAX-EXCEEDED        VALUE 'Y'.
023226         88  WS-RETRN-MAX-NOT-EXCEEDED    VALUE 'N'.
016503     05  WS-REDO-SWITCH                   PIC X(01).
016503         88  WS-REDO-OK                   VALUE 'Y'.
016503         88  WS-REDO-NOT-OK               VALUE 'N'.
015290     05  WS-SUB                    PIC S9(04)  BINARY.
031034*    05  WS-HOLD-PLAR-PRCES-SW     PIC X(01).
031034*    05  WS-HOLD-PGAL-ALLOC-SW     PIC X(01).
031034*    05  WS-HOLD-PGAL-ALLOC-INFO  OCCURS 9 TIMES.
031034*        10  WS-HOLD-PGAL-ALLOC-TYP-CD
031034*                                  PIC X(01).
031034*        10  WS-HOLD-PGAL-OPN-PRIN-AMT
031034*                                  PIC S9(13)V99 COMP-3.
031034*        10  WS-HOLD-PGAL-OPN-GAIN-AMT
031034*                                  PIC S9(13)V99 COMP-3.
031034*        10  WS-HOLD-PGAL-TRXN-PRIN-AMT
031034*                                  PIC S9(13)V99 COMP-3.
031034*        10  WS-HOLD-PGAL-TRXN-PRIN-AMT
031034*                                  PIC S9(13)V99 COMP-3.
031034*        10  WS-HOLD-PGAL-WTHDR-SEQ-NUM
021311*                                  PIC X(01).
031034*                                  PIC 9(01).
031034*        10  WS-HOLD-PGAL-WTHDR-ORDR-CD
031034*                                  PIC X(01).
015290     05  WS-CDSA-INFO.
015290         10  WS-POL-PAYO-NUM           PIC S9(05)    COMP-3.
023437*        10  WS-CDA-TYP-CD             PIC X(01).
023437         10  WS-CDA-TYP-CD             PIC X(02).
015290         10  WS-CDA-EFF-IDT-NUM        PIC X(07).
015290         10  WS-CDA-SEQ-NUM            PIC S9(03)    COMP-3.

018620     05  WS-LTAXWH-CALC-CD                PIC X(01).
018620         88  WS-BYPASS-LTAXWH             VALUE 'B'.
018620         88  WS-CALC-LTAXWH               VALUE 'C'.
018620         88  WS-USE-LTAXWH-REC-INFO       VALUE 'S'.
023437     05  WS-FED-TAXWH-RQST-AMT         PIC S9(11)V9(02).
023437     05  WS-FED-TAXWH-RQST-PCT         PIC S9(03)V9(02).
023437     05  WS-FED-TAXWH-CALC-CD          PIC X(01).
023437         88  WS-FED-TAXWH-CALC-VALID   VALUE 'S', 'C', 'B'.
023437
023437     05  WS-LOC-RQST-AMT               PIC S9(11)V9(02).
023437     05  WS-LOC-RQST-PCT               PIC S9(03)V9(04).
023437     05  WS-FED-TAXWH-AMT              PIC S9(13)V9(02).
023444     05  WS-TRMN-AMT                   PIC S9(13)V9(02) COMP-3.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES           PIC S9(04).
025970         88  WS-MAX-BROWSE-LINES-DEFAULT  VALUE +15.

557701*
557701 COPY CCFHPOL.
      *
557756*COPY CCWTYSNO.
      *
023437 COPY XCWEBLCH.
      *
       COPY XCWWWKDT.
020478 COPY CCWL2626.
       COPY XCWLDTLK.
015290 COPY XCWL1660.
       COPY XCWL1640.
021239 COPY XCWL7721.
020469 COPY XCWL8640.
      *
018846 COPY CCWL0182.
018846
023226 COPY CCWL0185.
023226/
016503 COPY CCWL0201.
016503*
016503 COPY CCWL0289.
016503*
013578 COPY CCWL0620.
      *
016108 COPY CCWL0985.
016108*
       COPY CCWL2430.
012143*
012143 COPY CCWL2600.
557701*
012135 COPY CCWL3330.
      *
018731 COPY CCWL4382.
      *
557701 COPY CCWL4750.
      *
016503 COPY CCWL4780.
016503*
       COPY CCWL5400.
      *
012143 COPY CCWL6860.
012143*
020475 COPY CCWL7305.
020475 COPY CCWL7306.
      *
015290 COPY CCWLPGAL.
031034*COPY CCWL7800.
015290
012143 COPY FCWL2760.
012696*
012696 COPY FCWL8170.
012696 COPY FCWLFUND.
012143*
       01  HEADER-MISC-WORK-AREAS.
013578     05  WS-HOLD-I                        PIC S9(04).
           05  AMOUNT-HOLD.
008455*        10  AMOUNT-HOLD-N                PIC 9(7).99.
008455         10  AMOUNT-HOLD-N                PIC S9(13)V99 COMP-3.
           05  POFVAL-HOLD.
               10  POFVAL-HOLD-N                PIC 999.9999.
008455*    05  CHARGE-HOLD.
008455*        10  CHARGE-HOLD-N                PIC 9(7).99.
008455     05  CHARGE-HOLD                      PIC X(16).
008455     05  CHARGE-HOLD-N                    PIC S9(13)V9(2) COMP-3.
557973*    05  WS-CHARGE                        PIC 9(7)V99.
557973     05  WS-CHARGE                        PIC 9(13)V99.
016548*    05  WS-HOLD-WGLOB-MSG-ERROR          PIC S9(04) COMP.
016548     05  WS-HOLD-WGLOB-MSG-ERROR          PIC S9(04) BINARY.
           05  WS-VERIFY-ERROR-SW               PIC X.
               88  WS-VERIFY-ERROR              VALUE 'Y'.
025970         88  WS-VERIFY-ERROR-NO           VALUE 'N'.
           05  RESET-SW                         PIC 9.
               88  RESET-SCREEN                 VALUE 1.
           05  WS-SCREEN-UPDATE-SW              PIC X.
               88  WS-SCREEN-UPDATE             VALUE 'Y'.
           05  CLEAR-SW                         PIC 99.
               88  CLEAR-SW-ON                  VALUE 1.
           05 FSUR-CALL-SW                      PIC 9.
               88  NO-CALL                      VALUE 0.
               88  DO-CALL                      VALUE 1.
557701     05  WS-REBUILD-AFTER-UNDO-SW         PIC X(01).
557701         88  WS-REBUILD-AFTER-UNDO-NO     VALUE 'N'.
557701         88  WS-REBUILD-AFTER-UNDO-YES    VALUE 'Y'.
016548*    05  I                                PIC S9(4)  COMP.
016548     05  I                                PIC S9(4)  BINARY.
016548*    05  J                                PIC S9(4)  COMP.
016548     05  J                                PIC S9(4)  BINARY.
557701     05  WS-INPUT-LOAD-FORCE-IND          PIC X(01).
025970         88  WS-INPUT-LOAD-FORCE-NO       VALUE 'N'.
557701     05  WS-INPUT-LOAD-AMT                PIC S9(15)V99 COMP-3.
557973*    05  WS-CONTROL-TOTAL                 PIC S9(11)V9999 COMP-3.
557973     05  WS-CONTROL-TOTAL                 PIC S9(13)V9999 COMP-3.
021239*    05  WS-CONTROL-UNITS                 PIC S9(9)V9(9) COMP-3.
021239     05  WS-CONTROL-UNITS                 PIC S9(12)V9(6) COMP-3.
557973*    05  WS-AMOUNT                        PIC S9(11)V99 COMP-3.
557973     05  WS-AMOUNT                        PIC S9(15)V99 COMP-3.
557973*    05  WS-NUM-PC                        PIC S9(3)V9(4) COMP-3.
557973     05  WS-NUM-PC                        PIC S9(9)V9(4) COMP-3.
557973*    05  WS-ALLOC-NUM                     PIC S9(7)V9999 COMP-3.
557973     05  WS-ALLOC-NUM                     PIC S9(13)V9999 COMP-3.
557973*    05  WS-AMT-SUR-FUND                  PIC S9(7)V99   COMP-3.
557973     05  WS-AMT-SUR-FUND                  PIC S9(13)V99  COMP-3.
557973*    05  WS-CV-FUND                       PIC S9(11)V99  COMP-3.
557973     05  WS-CV-FUND                       PIC S9(15)V99  COMP-3.
557973*    05  WS-CONTROL-PCT                   PIC S9(11)V99  COMP-3.
557973     05  WS-CONTROL-PCT                   PIC S9(13)V99  COMP-3.
557973*    05  WS-GRS-SURR-TOTAL                PIC S9(09)V99  COMP-3
557973     05  WS-GRS-SURR-TOTAL                PIC S9(13)V99  COMP-3
                                                VALUE ZERO.
016408     05  WS-SURR-TOTAL                    PIC S9(13)V99  COMP-3.

012143     05  WS-HOLD-FREE-WTHDR-QTY           PIC S9(03)     COMP-3.
012143     05  WS-HOLD-FREE-WTHDR-TOT-AMT       PIC S9(13)V99  COMP-3.
012143     05  WS-DBSC-TOT-SURR-AMT             PIC S9(13)V99  COMP-3.
012143     05  WS-DBSC-TOT-CHRG-AMT             PIC S9(13)V99  COMP-3.
012143     05  WS-DBSC-TOT-FREE-AMT             PIC S9(13)V99  COMP-3.
012143     05  WS-DBSC-APPLICABLE-IND           PIC X(01).
012143         88  WS-DBSC-APPLICABLE           VALUE 'Y'.
012143         88  WS-DBSC-APPLICABLE-NO        VALUE 'N'.
012143     05  WS-DBSC-CDSA-IND                 PIC X(01).
012143         88  WS-DBSC-CDSA-YES             VALUE 'Y'.
012143         88  WS-DBSC-CDSA-NO              VALUE 'N'.
008455*    05  DISP-7V2                         PIC -ZZZZZZ9.99.
008455*    05  DISP-SCR-7V2                     PIC 9(7).99.
008455*    05  DISP-SCR-11V2                    PIC 9(11).99.
           05  DISP-SCR-3V4                     PIC 9(3).9(4).
021239     05  WS-FND-UNIT-QTY                  PIC 9(12).9(06).
021239*    05  DISP-SCR-9V9                     PIC 9(9).9(9).
021239*    05  FORMAT-9V9                       PIC 9(9)V9(9).
021239*    05  FORMAT-9V8-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V8                   PIC 9(9)V9(8).
021239*        10  FILLER                       PIC X.
021239*    05  FORMAT-9V7-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V7                   PIC 9(9)V9(7).
021239*        10  FILLER                       PIC XX.
021239*    05  FORMAT-9V6-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V6                   PIC 9(9)V9(6).
021239*        10  FILLER                       PIC XXX.
021239*    05  FORMAT-9V5-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V5                   PIC 9(9)V9(5).
021239*        10  FILLER                       PIC XXXX.
021239*    05  FORMAT-9V4-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V4                   PIC 9(9)V9(4).
021239*        10  FILLER                       PIC X(05).
021239*    05  FORMAT-9V3-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V3                   PIC 9(9)V9(3).
021239*        10  FILLER                       PIC X(06).
021239*    05  FORMAT-9V2-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V2                   PIC 9(9)V9(2).
021239*        10  FILLER                       PIC X(07).
021239*    05  FORMAT-9V1-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V1                   PIC 9(9)V9(1).
021239*        10  FILLER                       PIC X(08).
021239*    05  FORMAT-9V0-X    REDEFINES        FORMAT-9V9.
021239*        10  FORMAT-9V0                   PIC 9(9).
021239*        10  FILLER                       PIC X(09).
      *
       COPY SCFRFC.
      *
       COPY SCFRFS.
      *
       COPY SCFRFA.
      *
       COPY SCFRFD.
      *
       COPY SCFWFR.
       COPY SCFRFR.
      *
       COPY SCFWFH.
       COPY SCFRFH.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
020475 COPY CCFRDBGA.
      *
       COPY CCFWPOL.
      *
013578*COPY XCWWTSQP.
013578 01  WS-TWRK-FIELDS.
025970*     05  WS-TWRK-KEY-1780                PIC X(04) VALUE '1780'.
025970*     05  WS-TWRK-KEY-1781                PIC X(04) VALUE '1781'.
025970*     05  WS-TWRK-KEY-1782                PIC X(04) VALUE '1782'.
025970*     05  WS-TWRK-KEY-1783                PIC X(04) VALUE '1783'.
025970*     05  WS-TWRK-KEY-1784                PIC X(04) VALUE '1784'.
025970*     05  WS-TWRK-KEY-1785                PIC X(04) VALUE '1785'.
025970*     05  WS-TWRK-SEQ-NUM                 PIC 9(04) VALUE ZEROES.
013578      05  WS-TWRK-WORK-AREA.
       COPY SCWWPDTQ.
      *
       COPY XCWL0280.
      *
008455 COPY XCWL0290.
008455*
013578*COPY XCWL2510.
      *
013578 COPY XCWL8090.
      *
020463 COPY CCWL2735.
020463/
       COPY SCWL0410.
      /
023437 COPY XCWL0316.
023437 COPY CCWLTAXC.
      *
       COPY SCWL6330.
      *
       COPY SCWL0500.
      *
       COPY SCWLSEGF.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
       COPY CCWLPGA.
      *
012135 COPY CCFWPH.
012135 COPY CCFRPH.
012135*
       COPY CCFRPOL.
      *
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0080.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

021311     PERFORM  9990-INIT-WORKING-STORAGE
021311         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *------------------
       1000-SET-UP-INPUT.
      *------------------

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.
           MOVE ZERO                  TO CLEAR-SW.
           SET WS-SCREEN-UPDATE TO TRUE.

      *
      * RETRIEVE POLICY NUMBER AND COVERAGE FROM THE SCREEN, STORE IT
      * IN THE LSEGF-AREA
      *

           MOVE MIR-POL-ID-BASE       TO LSEGF-INV-CVG-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO LSEGF-INV-CVG-POL-ID-SFX.
010311*    MOVE MIR-CVG-NUM           TO L6330-CVG-NUM.
010311*    MOVE L6330-CVG-NUM         TO LSEGF-INV-CVG-CVG-NUM.

      *
      * SET UP SCREEN CODES AND INDICATORS FOR EDIT PROCESSING.
      *

013578*    MOVE MIR-ALLOC             TO L6330-ALLOC-CD.
013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-PRORATE-FND-VALU
013578              MOVE 'B' TO L6330-ALLOC-CD
013578
013578         WHEN WS-BUS-FCN-DOLLAR-AMT
013578              MOVE 'C' TO L6330-ALLOC-CD
013578
013578         WHEN WS-BUS-FCN-PCT-AMT
013578              MOVE 'D' TO L6330-ALLOC-CD
013578
013578         WHEN WS-BUS-FCN-PCT-TOT-VALU
013578              MOVE 'E' TO L6330-ALLOC-CD
013578
013578         WHEN WS-BUS-FCN-PCT-FND-VALU
013578              MOVE 'F' TO L6330-ALLOC-CD
013578
013578         WHEN WS-BUS-FCN-NUM-UNITS
013578              MOVE 'G' TO L6330-ALLOC-CD
013578
013578     END-EVALUATE.

           MOVE MIR-CIA-SRC-DEST-CD   TO L6330-DEST-CD.
018731     MOVE MIR-CLI-ID            TO L6330-CLI-ID.
018731     MOVE MIR-CLI-BNK-ACCT-NUM  TO L6330-CLI-BNK-ACCT-NUM.
           MOVE MIR-CIA-REASN-CD      TO L6330-REASN-CD.
023437*    MOVE MIR-CIA-TAXWH-IND     TO L6330-TAX-BPSS-IND.
016107     MOVE MIR-DV-REDC-FACE-IND  TO L6330-REDC-FACE-IND.
029060*    MOVE MIR-LTAXWH-CALC-CD    TO L6330-LTAXWH-CALC-CD.
013693     SET  L6330-LTAXWH-DISB-NONP TO TRUE.
031034     SET L6330-TRXN-WTHDR       TO TRUE.
031034     SET L6330-SURR-FOR-NONE    TO TRUE.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L6330-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.

       1000-SET-UP-INPUT-X.
           EXIT.

      *-------------------------
       1100-PROCESS-TRANS-PHASE.
      *-------------------------

           EVALUATE WS-PRCES-STATE-CD

               WHEN '1'
                   PERFORM  1400-TRAN-PHASE-0
                       THRU 1400-TRAN-PHASE-0-X

               WHEN '2'
                   PERFORM  1500-TRAN-PHASE-1
                       THRU 1500-TRAN-PHASE-1-X

               WHEN '3'
                   PERFORM  1600-TRAN-PHASE-2
                       THRU 1600-TRAN-PHASE-2-X

           END-EVALUATE.

       1100-PROCESS-TRANS-PHASE-X.
           EXIT.

      *---------------
       1200-CALL-FSUR.
      *---------------

           MOVE LSEGF-INV-CVG-REC-INFO TO RFC-REC-INFO.
           MOVE 'SUR'                  TO LSEGF-INPUT-TYP-CD.
           MOVE MIR-POL-ID-BASE        TO LSEGF-INPUT-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO LSEGF-INPUT-POL-ID-SFX.
           MOVE MIR-CVG-NUM            TO LSEGF-INPUT-CVG-NUM.
           MOVE LSEGF-INV-CVG-CFN-EFF-DT
                                       TO LSEGF-INPUT-EFF-DT.
           MOVE +0                     TO LSEGF-INPUT-SEQ-NUM.

           IF  WS-BUS-FCN-PCT-TOT-VALU
               MOVE POFVAL-HOLD-N      TO LSEGF-INPUT-SURR-PCT
           ELSE
               MOVE +0                 TO LSEGF-INPUT-SURR-PCT
557660     END-IF.

           MOVE MIR-CIA-REASN-CD       TO LSEGF-INPUT-REASN-CD.
           MOVE L6330-SURR-AMOUNT      TO LSEGF-INPUT-AMT.

557701     IF  WS-REBUILD-AFTER-UNDO-YES
557701         MOVE WS-INPUT-LOAD-FORCE-IND
557701                                 TO LSEGF-INPUT-LOAD-FORCE-IND
557701         MOVE WS-INPUT-LOAD-AMT  TO LSEGF-INPUT-LOAD-AMT
557701     ELSE
013578         IF  MIR-CIA-LOAD-FORCE-IND = 'N'
013578*        IF  MIR-CIA-LOAD-AMT = 'XXXXXXX.XX'
013578*        OR  MIR-CIA-LOAD-AMT = SPACES
013578*        OR  MIR-CIA-LOAD-AMT = LOW-VALUES
                   MOVE 'N'            TO LSEGF-INPUT-LOAD-FORCE-IND
                   MOVE +0             TO LSEGF-INPUT-LOAD-AMT
               ELSE
                   MOVE 'Y'            TO LSEGF-INPUT-LOAD-FORCE-IND
                   MOVE CHARGE-HOLD-N  TO LSEGF-INPUT-LOAD-AMT
557701         END-IF
557660     END-IF.
           MOVE MIR-CIA-SRC-DEST-CD    TO LSEGF-INPUT-SRC-CD.
012696*    IF  MIR-ALLOC = 'A'
012696*        IF  RFC-OUT-FND-ALLOC-CD = 'P'
012696*            MOVE 'B'            TO LSEGF-INPUT-ALLOC-IND
012696*        ELSE
012696*            MOVE 'D'            TO LSEGF-INPUT-ALLOC-IND
012696*        END-IF
012696*    ELSE
013578*        MOVE MIR-ALLOC          TO LSEGF-INPUT-ALLOC-IND
013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-PRORATE-FND-VALU
013578              MOVE 'B' TO LSEGF-INPUT-ALLOC-IND
013578
013578         WHEN WS-BUS-FCN-DOLLAR-AMT
013578              MOVE 'C' TO LSEGF-INPUT-ALLOC-IND
013578
013578         WHEN WS-BUS-FCN-PCT-AMT
013578              MOVE 'D' TO LSEGF-INPUT-ALLOC-IND
013578
013578         WHEN WS-BUS-FCN-PCT-TOT-VALU
013578              MOVE 'E' TO LSEGF-INPUT-ALLOC-IND
013578
013578         WHEN WS-BUS-FCN-PCT-FND-VALU
013578              MOVE 'F' TO LSEGF-INPUT-ALLOC-IND
013578
013578         WHEN WS-BUS-FCN-NUM-UNITS
013578              MOVE 'G' TO LSEGF-INPUT-ALLOC-IND
013578
013578     END-EVALUATE.
012696*    END-IF.

           MOVE 0                      TO J.
           PERFORM  1250-FORMAT-FD-FSUR
               THRU 1250-FORMAT-FD-FSUR-X
               VARYING I FROM 1 BY 1
               UNTIL I > LSEGF-FND-CTR.

           MOVE 'SUR'                  TO LSEGF-CIA-FIA-OPT-CD.

           IF  LSEGF-INPUT-ALLOC-IND = 'B'
               MOVE LSEGF-FND-CTR      TO LSEGF-FIA-REC-CTR
           ELSE
               MOVE J                  TO LSEGF-FIA-REC-CTR
           END-IF.
023437*    MOVE MIR-CIA-TAXWH-IND      TO LSEGF-TAX-WTHLD-IND.
029060*    MOVE MIR-LTAXWH-CALC-CD     TO LSEGF-LTAXWH-CALC-CD.
013693     MOVE 'N'                    TO LSEGF-LTAXWH-DISB-CD.
016408*    SET  WS-DBSC-CDSA-NO        TO TRUE.
016408*    PERFORM  1700-DPOS-BASED-SURR-CHRG
016408*        THRU 1700-DPOS-BASED-SURR-CHRG-X.
012143
018731     PERFORM  2360-EFT-BNK-EDITS
018731         THRU 2360-EFT-BNK-EDITS-X
018731
           SET L6330-PRCES-TYP-ALL     TO TRUE.
016503     SET L6330-REDO-WARNING      TO TRUE.

018846     IF  WCVGS-PLAN-FND-TYP-XTRNL (LSEGF-INPUT-CVG-NUM)
018846         SET L6330-DBSC-APPLICABLE-NO  TO TRUE
018846     END-IF.
018846
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034*
           PERFORM  6330-1000-PROCESS-SURR
               THRU 6330-1000-PROCESS-SURR-X.
016408
016408     IF  NOT L6330-RETRN-ERROR
016408         IF  WS-BUS-FCN-PCT-TOT-VALU
016408         OR  WS-BUS-FCN-PCT-FND-VALU
016408         OR  WS-BUS-FCN-NUM-UNITS
016408
016408             MOVE ZERO TO WS-SURR-TOTAL
016408             MOVE 1 TO I
016408             PERFORM  2910-CALC-SURR-TOTAL
016408                 THRU 2910-CALC-SURR-TOTAL-X
016408                 VARYING J FROM 1 BY 1
016408                 UNTIL J > LSEGF-FND-CTR
016408
025678*            MOVE WS-SURR-TOTAL  TO LSEGF-INPUT-AMT
025678             IF  WS-SURR-TOTAL < ZERO
025678                 COMPUTE LSEGF-INPUT-AMT = WS-SURR-TOTAL
025678                                         * -1
025678             ELSE
025678                 COMPUTE LSEGF-INPUT-AMT = WS-SURR-TOTAL
025678             END-IF
016408         END-IF
016408         SET  WS-DBSC-CDSA-NO    TO TRUE
016408
016408         PERFORM  1700-DPOS-BASED-SURR-CHRG
016408             THRU 1700-DPOS-BASED-SURR-CHRG-X
016408
016408         IF  RPH-PLAN-SURR-CHRG-DPOS-BASED
018846         AND WCVGS-PLAN-FND-TYP-NONE (LSEGF-INPUT-CVG-NUM)
016408             SET L6330-PRCES-TYP-ALL TO TRUE
016503             SET L6330-REDO-WARNING  TO TRUE
031034*            PERFORM  PGAL-0000-INIT-PARM-INFO
031034*                THRU PGAL-0000-INIT-PARM-INFO-X
016408             PERFORM  6330-1000-PROCESS-SURR
016408                 THRU 6330-1000-PROCESS-SURR-X
016408         END-IF
016408     END-IF.
016408
023437* MOVE THE FEDERAL TAX REQUEST DATA TO THE SCREEN
023437
029060*    MOVE L6330-FED-TAXWH-CALC-CD  TO WS-FED-TAXWH-CALC-CD.
029060*    MOVE L6330-FED-TAXWH-RQST-AMT TO WS-FED-TAXWH-RQST-AMT.
029060*    MOVE L6330-FED-TAXWH-RQST-PCT TO WS-FED-TAXWH-RQST-PCT.
023437
023437     PERFORM  1550-MOVE-TAX-DATA-TO-MIR
023437         THRU 1550-MOVE-TAX-DATA-TO-MIR-X.
023437
023226* CHECK TO SEE IF LIF MAX EXCEEDED
023226     IF  (RPOL-POL-INS-TYP-RRIF
023226     AND RPOL-POL-LOCKED-IN-FUNDS)
023226     AND (WS-BUS-FCN-PCT-TOT-VALU
023226     OR  WS-BUS-FCN-PCT-FND-VALU
023226     OR  WS-BUS-FCN-NUM-UNITS)
023226         PERFORM  1203-CHECK-MAX
023226             THRU 1203-CHECK-MAX-X
023226             VARYING I FROM 1 BY 1
023226             UNTIL I > RPOL-POL-CVG-REC-CTR-N
023226     END-IF.

           IF  L6330-RETRN-ERROR
023226     OR  WS-RETRN-MAX-EXCEEDED
               PERFORM  1410-SET-ERROR-ATTRIB
                   THRU 1410-SET-ERROR-ATTRIB-X
557660     END-IF.

013578     IF  (WS-BUS-FCN-DOLLAR-AMT AND
                MIR-CIA-REASN-CD = 'NET')
               PERFORM  1510-TRAN-PHASE-1B
                   THRU 1510-TRAN-PHASE-1B-X
               MOVE LSEGF-INPUT-LOAD-AMT
                                      TO L6330-SURR-CHRG
               MOVE L6330-SURR-CHRG TO CHARGE-HOLD-N
008455*        MOVE CHARGE-HOLD       TO MIR-CIA-LOAD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = L6330-SURR-CHRG * 100
020874         MOVE L6330-SURR-CHRG   TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CIA-LOAD-AMT
014035         PERFORM  1205-WGLOB-TEST
014035             THRU 1205-WGLOB-TEST-X

014035         IF  WGLOB-MSG-ERROR-SW NOT = 0
013578         AND WS-PRCES-STATE-CD = '3'
014035             GO TO 1200-CALL-FSUR-X
014035         END-IF
           END-IF.

           IF  WGLOB-MSG-ERROR-SW NOT = 0
               MOVE '1'               TO WGLOB-RETURN-CODE
           ELSE
               MOVE 0                 TO WS-CONTROL-TOTAL
               MOVE 1                 TO I
               MOVE L6330-SURR-AMOUNT TO WS-AMOUNT
               MOVE ZERO              TO L6330-SURR-CHRG
               MOVE ZERO              TO CHARGE-HOLD-N
               MOVE ZERO              TO WS-CHARGE
               MOVE ZERO              TO WS-GRS-SURR-TOTAL
               PERFORM  2900-REFORMAT-SCREEN
                   THRU 2900-REFORMAT-SCREEN-X
                VARYING J FROM 1 BY 1
                  UNTIL J > LSEGF-FND-CTR
               IF WGLOB-MSG-ERROR-SW NOT = 0
                   MOVE '1'           TO WGLOB-RETURN-CODE
014035             PERFORM  1210-L6330-TEST
014035                 THRU 1210-L6330-TEST-X
557660         END-IF
557660     END-IF.

557701     IF  WS-REBUILD-AFTER-UNDO-YES
557701         GO TO 1200-CALL-FSUR-X
557701     END-IF.
557701
           IF  L6330-RETRN-OK
               IF  LSEGF-PREM-ERROR-IND NOT = 0
                   MOVE 'SS00800036'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  2925-CHECK-TOTAL
                       THRU 2925-CHECK-TOTAL-X
                   MOVE RPOL-POL-ID   TO LPGA-POLICY-NUMBER
013578*            MOVE 'CFA'         TO WTSQP-NAME-MNEMONIC
013578*            PERFORM  TSQP-4000-DELETE-TS-QUEUE
013578*                THRU TSQP-4000-DELETE-TS-QUEUE-X
013578             PERFORM  8090-1000-BUILD-PARM-INFO
013578                 THRU 8090-1000-BUILD-PARM-INFO-X
013578             SET L8090-TEMP-WRK-TYP-SEG-ACTV  TO TRUE
013578             MOVE LENGTH OF WS-TWRK-WORK-AREA TO L8090-AREA-LEN
013578             MOVE +1            TO L8090-TEMP-WRK-SEQ-NUM
013578             PERFORM  8090-3000-DELETE-TWRK
013578                 THRU 8090-3000-DELETE-TWRK-X
557973*            MOVE +8000         TO WTSQP-QUEUE-LENGTH
012141*            MOVE +8400         TO WTSQP-QUEUE-LENGTH
013578*            MOVE +13400        TO WTSQP-QUEUE-LENGTH
                   MOVE LSEGF-FC-FS-INFO
                                      TO WPDTQ-CMFC-AREA
                   MOVE LSEGF-FA-FD-INFO
                                      TO WPDTQ-CMFA-AREA
013578             PERFORM  8090-1000-BUILD-PARM-INFO
013578                 THRU 8090-1000-BUILD-PARM-INFO-X
013578             SET L8090-TEMP-WRK-TYP-SEG-ACTV TO TRUE
013578             MOVE WS-TWRK-WORK-AREA TO L8090-AREA-INFO-TEXT
013578             MOVE LENGTH OF WS-TWRK-WORK-AREA TO L8090-AREA-LEN
013578             MOVE +1            TO L8090-TEMP-WRK-SEQ-NUM
013578             PERFORM  8090-1000-WRITE-TWRK
013578                 THRU 8090-1000-WRITE-TWRK-X
013578             PERFORM  1201-CHECK-RETURN
013578                 THRU 1201-CHECK-RETURN-X
013578*            PERFORM  TSQP-2000-WRITE-TS-QUEUE
013578*                THRU TSQP-2000-WRITE-TS-QUEUE-X
013578*            PERFORM  1215-WTSQP-TEST
013578*                THRU 1215-WTSQP-TEST-X
557660         END-IF
557660     END-IF.
012696*
012696     IF  L6330-RETRN-OK
012696     AND LSEGF-PREM-ERROR-IND = 0
012696         PERFORM  8600-CHECK-TRANS-DEFER
012696             THRU 8600-CHECK-TRANS-DEFER-X
012696         IF  L8170-RETRN-OK
012696         AND L8170-DEFR-REQUIRED
012696*MSG: THIS SURRENDER WILL BE DEFERRED
012696             MOVE 'SS00800037' TO WGLOB-MSG-REF-INFO
012696             PERFORM 0260-1000-GENERATE-MESSAGE
012696                THRU 0260-1000-GENERATE-MESSAGE-X
012696         END-IF
012696     END-IF.

      ** MESSAGE PLEASE VERIFY: (OPTIONS:YES,NO,CHG) ****
           IF  L6330-RETRN-OK
               IF  LSEGF-PREM-ERROR-IND = 0
                   MOVE 'SS00800024'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  2925-CHECK-TOTAL
                       THRU 2925-CHECK-TOTAL-X
                   MOVE RPOL-POL-ID   TO LPGA-POLICY-NUMBER
013578*            MOVE 'CFA'         TO WTSQP-NAME-MNEMONIC
013578*            PERFORM  TSQP-4000-DELETE-TS-QUEUE
013578*                THRU TSQP-4000-DELETE-TS-QUEUE-X
013578*            MOVE 'CFA'         TO WTSQP-NAME-MNEMONIC
013578*            PERFORM  TSQP-4000-DELETE-TS-QUEUE
013578*                THRU TSQP-4000-DELETE-TS-QUEUE-X
013578             PERFORM  8090-1000-BUILD-PARM-INFO
013578                 THRU 8090-1000-BUILD-PARM-INFO-X
013578             SET L8090-TEMP-WRK-TYP-SEG-ACTV TO TRUE
013578             MOVE LENGTH OF WS-TWRK-WORK-AREA TO L8090-AREA-LEN
013578             MOVE +1            TO L8090-TEMP-WRK-SEQ-NUM
013578             PERFORM  8090-3000-DELETE-TWRK
013578                 THRU 8090-3000-DELETE-TWRK-X
557973*            MOVE +8000         TO WTSQP-QUEUE-LENGTH
012141*            MOVE +8400         TO WTSQP-QUEUE-LENGTH
013578*            MOVE +13400        TO WTSQP-QUEUE-LENGTH
                   MOVE LSEGF-FC-FS-INFO
                                      TO WPDTQ-CMFC-AREA
                   MOVE LSEGF-FA-FD-INFO
                                      TO WPDTQ-CMFA-AREA
013578             PERFORM  8090-1000-BUILD-PARM-INFO
013578                 THRU 8090-1000-BUILD-PARM-INFO-X
013578             SET L8090-TEMP-WRK-TYP-SEG-ACTV TO TRUE
013578             MOVE WS-TWRK-WORK-AREA TO L8090-AREA-INFO-TEXT
013578             MOVE LENGTH OF WS-TWRK-WORK-AREA TO L8090-AREA-LEN
013578             MOVE +1            TO L8090-TEMP-WRK-SEQ-NUM
013578             PERFORM  8090-1000-WRITE-TWRK
013578                 THRU 8090-1000-WRITE-TWRK-X
013578             PERFORM  1201-CHECK-RETURN
013578                 THRU 1201-CHECK-RETURN-X
013578*            PERFORM  TSQP-2000-WRITE-TS-QUEUE
013578*                THRU TSQP-2000-WRITE-TS-QUEUE-X
013578*            PERFORM  1215-WTSQP-TEST
013578*                THRU 1215-WTSQP-TEST-X
557660         END-IF
557660     END-IF.

       1200-CALL-FSUR-X.
           EXIT.

013578*------------------
013578 1201-CHECK-RETURN.
013578*------------------
013578
013578     IF  NOT L8090-RETRN-OK
013578         MOVE 'XS00000092'      TO WGLOB-MSG-REF-INFO
013578         PERFORM  0260-1000-GENERATE-MESSAGE
013578             THRU 0260-1000-GENERATE-MESSAGE-X
013578     END-IF.
013578
013578 1201-CHECK-RETURN-X.
013578     EXIT.
023226
023226*---------------------
023226 1203-CHECK-MAX.
023226*---------------------
023226
023226     IF NOT WCVGS-CVG-INS-TYP-RRIF (I)
023226     OR NOT WCVGS-CVG-STAT-IN-FORCE (I)
023226         GO TO 1203-CHECK-MAX-X
023226     END-IF.
023226
023226     PERFORM  0185-1000-BUILD-PARM-INFO
023226         THRU 0185-1000-BUILD-PARM-INFO-X.
023226     IF RPOL-POL-ANPAYO-PMT-DT NOT = WWKDT-ZERO-DT
023226         MOVE RPOL-POL-ANPAYO-PMT-DT  TO L0185-INTERNAL-1
023226     ELSE
023226         MOVE RPOL-POL-ANPAYO-EFF-DT  TO L0185-INTERNAL-1
023226     END-IF.
023226
023226     MOVE L0185-INTERNAL-1       TO L0185-INTERNAL-2.
023226
023226     COMPUTE L0185-INPUT-AMT = WS-SURR-TOTAL.
023226     MOVE L6330-EFF-DATE         TO L0185-INPUT-DATE.
023226     MOVE I                      TO L0185-SUB.
023226     SET L0185-INCLUDE-CURR-AMT  TO TRUE.
023226
023226     PERFORM  0185-2000-CHECK-MAX
023226         THRU 0185-2000-CHECK-MAX-X.
023226
023226     IF L0185-RETRN-MAX-EXCEEDED
023226         COMPUTE L0290-INPUT-NUMBER =
023226              L0185-AMOUNT-REMAINING   *  L0290-CRCY-MULT-FCT
023226         MOVE WGLOB-CRCY-SCALE-QTY     TO L0290-PRECISION
023226         MOVE 40                       TO L0290-MAX-OUT-LEN
023226         SET L0290-MESSAGE-FORMAT      TO TRUE
023226         SET L0290-SIGN-DISPLAY        TO TRUE
023226         SET L0290-SIGN-FLOAT          TO TRUE
023226         PERFORM 0290-1000-NUMERIC-FORMAT
023226            THRU 0290-1000-NUMERIC-FORMAT-X
023226         MOVE L0290-OUTPUT-DATA        TO WGLOB-MSG-PARM (1)
023226*MSG MAX ANN. PYMT EXCEED. LIF PYMT OF (@1) AVAILABLE
023226         MOVE 'SS00800058'            TO WGLOB-MSG-REF-INFO
023226         PERFORM  0260-1000-GENERATE-MESSAGE
023226             THRU 0260-1000-GENERATE-MESSAGE-X
023226
023226         IF WGLOB-MSG-SEVRTY-FATAL
023226             SET WS-RETRN-MAX-EXCEEDED    TO TRUE
023226         END-IF
023226     END-IF.
023226
023226 1203-CHECK-MAX-X.
023226     EXIT.
023226/

014035*----------------
014035 1205-WGLOB-TEST.
014035*----------------
014035
014035     IF  WGLOB-MSG-ERROR-SW NOT = 0
014035         MOVE '1'               TO WGLOB-RETURN-CODE
014035     END-IF.
014035
014035 1205-WGLOB-TEST-X.
014035     EXIT.
014035
014035*----------------
014035 1210-L6330-TEST.
014035*----------------
014035
014035     IF  L6330-RETRN-ERROR
013578         CONTINUE
014035     ELSE
014035         PERFORM  2925-CHECK-TOTAL
014035             THRU 2925-CHECK-TOTAL-X
014035     END-IF.
014035
014035 1210-L6330-TEST-X.
014035     EXIT.
014035
013578*----------------
013578*1215-WTSQP-TEST.
013578*----------------
013578*
013578*    IF  NOT WTSQP-QUEUE-OK
013578*        MOVE 'XS00000092'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    END-IF.
013578*
013578*1215-WTSQP-TEST-X.
013578*    EXIT.
014035
      *--------------------
       1250-FORMAT-FD-FSUR.
      *--------------------

557660*    IF LSEGF-INPUT-ALLOC-IND = 'C'
557660*        MOVE WS-SAMT-N (I)   TO WS-ALLOC-NUM
557660*    ELSE
557660*    IF LSEGF-INPUT-ALLOC-IND = 'D'
557660*        MOVE WS-PALL-N (I)   TO WS-ALLOC-NUM
557660*    ELSE
557660*    IF LSEGF-INPUT-ALLOC-IND = 'E'
557660*    ELSE
557660*    IF LSEGF-INPUT-ALLOC-IND = 'F'
557660*        MOVE WS-PFUN-N (I)   TO WS-ALLOC-NUM.

557660     EVALUATE LSEGF-INPUT-ALLOC-IND
557660
557660         WHEN 'C'
557660             MOVE WS-SAMT-N (I) TO WS-ALLOC-NUM
557660
557660         WHEN 'D'
557660             MOVE WS-PALL-N (I) TO WS-ALLOC-NUM
557660
557660         WHEN 'E'
                   MOVE L6330-SURR-PCT TO WS-ALLOC-NUM
557660
557660         WHEN 'F'
557660             MOVE WS-PFUN-N (I) TO WS-ALLOC-NUM
557660
557660     END-EVALUATE.

           IF  LSEGF-INPUT-ALLOC-IND = 'G'
               IF  L6330-FND-SURR-UNITS (I) NOT = 0
                   COMPUTE J = J + 1
                   MOVE L6330-FND-SURR-UNITS (I)
                                      TO LSEGF-INPUT-ALLOC-UNITS (J)
                   MOVE ZERO          TO LSEGF-INPUT-ALLOC-AMT (J)
                   MOVE L6330-FND-CD (I)
                                      TO LSEGF-INPUT-FND-ID (J)
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               IF  LSEGF-INPUT-ALLOC-IND NOT = 'B'
014035             PERFORM  1255-ALLOC-TEST
014035                 THRU 1255-ALLOC-TEST-X
               ELSE
                   MOVE 0             TO LSEGF-INPUT-ALLOC-AMT (I)
                   MOVE ZERO          TO LSEGF-INPUT-ALLOC-UNITS (I)
                   MOVE L6330-FND-CD (I)
                                      TO LSEGF-INPUT-FND-ID (I)
557660         END-IF
557660     END-IF.

       1250-FORMAT-FD-FSUR-X.
           EXIT.

014035*----------------
014035 1255-ALLOC-TEST.
014035*----------------
014035
014035     IF  WS-ALLOC-NUM NOT = 0
014035         COMPUTE               J = J + 1
014035         MOVE WS-ALLOC-NUM      TO LSEGF-INPUT-ALLOC-AMT (J)
014035         MOVE ZERO              TO LSEGF-INPUT-ALLOC-UNITS (J)
014035         MOVE L6330-FND-CD (I)  TO LSEGF-INPUT-FND-ID (J)
034802*    ELSE
034802*        NEXT SENTENCE
014035     END-IF.
014035
014035 1255-ALLOC-TEST-X.
014035     EXIT.
014035
      *--------------------------
       1300-FORMAT-OUTPUT-SCREEN.
      *--------------------------

           IF  NOT WS-SCREEN-UPDATE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               IF (CLEAR-SW-ON)
013578*        OR (WS-PRCES-STATE-CD = '1')
                   MOVE ZERO          TO POFVAL-HOLD-N
                   PERFORM  3000-FORMAT-TOP-LINE
                       THRU 3000-FORMAT-TOP-LINE-X
               ELSE
012696*            PERFORM  6050-FORMAT-FUND-NO
012696*                THRU 6050-FORMAT-FUND-NO-X
012696*                VARYING I FROM 1 BY 1
012696*                UNTIL I > LSEGF-FND-CTR
                   PERFORM  3000-FORMAT-TOP-LINE
                       THRU 3000-FORMAT-TOP-LINE-X
                   PERFORM  3100-MOVE-WS-TO-SCREEN
                       THRU 3100-MOVE-WS-TO-SCREEN-X
                       VARYING I FROM 1 BY 1
                       UNTIL I > LSEGF-FND-CTR
557660         END-IF
557660     END-IF.

       1300-FORMAT-OUTPUT-SCREEN-X.
           EXIT.

      *------------------
       1400-TRAN-PHASE-0.
      *------------------

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221         GO TO 1400-TRAN-PHASE-0-X
014221     END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  2350-EDATE-EDITS
                   THRU 2350-EDATE-EDITS-X
557660     END-IF.

018846     IF  WGLOB-GOOD-RETURN
018846         PERFORM  2355-SIDE-FND-TST
018846             THRU 2355-SIDE-FND-TST-X
018846     END-IF.
018846
018731     IF  WGLOB-GOOD-RETURN
018731         PERFORM  2360-EFT-BNK-EDITS
018731             THRU 2360-EFT-BNK-EDITS-X
018731     END-IF.
018731
016108     IF  WGLOB-GOOD-RETURN
016108         PERFORM  2370-VAL-DATE-OF-DTH
016108             THRU 2370-VAL-DATE-OF-DTH-X
016108     END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  2400-GET-FC
                   THRU 2400-GET-FC-X
557660     END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  2500-GET-CASH-VALUES
                   THRU 2500-GET-CASH-VALUES-X
557660     END-IF.
015290
031034*    IF  WGLOB-GOOD-RETURN
031034*        PERFORM  4800-GET-PGAL-INFO
031034*            THRU 4800-GET-PGAL-INFO-X
031034*    END-IF.

023437     IF  WGLOB-GOOD-RETURN
023437         PERFORM  5000-EDIT-LTAXWH-RQST
023437             THRU 5000-EDIT-LTAXWH-RQST-X
023437     END-IF.
023437
023437     IF  WGLOB-GOOD-RETURN
023437         PERFORM  5100-EDIT-TAXWH-RQST
023437             THRU 5100-EDIT-TAXWH-RQST-X
023437     END-IF.
023437
           IF  WGLOB-GOOD-RETURN
               SET L6330-PRCES-TYP-EDIT-ONLY TO TRUE
016503         SET L6330-REDO-WARNING        TO TRUE
               PERFORM 6330-1000-PROCESS-SURR
                  THRU 6330-1000-PROCESS-SURR-X
               IF  L6330-RETRN-ERROR
                   MOVE '1'           TO WGLOB-RETURN-CODE
                   PERFORM 1410-SET-ERROR-ATTRIB
                      THRU 1410-SET-ERROR-ATTRIB-X
               END-IF
           END-IF.

      * SOME FIELDS MAY BE OVERRIDDEN IN THE EDIT MODULE - MOVE THESE
      * TO THE MIR HERE

           MOVE L6330-REASN-CD        TO MIR-CIA-REASN-CD.

023437* MOVE THE FEDERAL TAX REQUEST DATA TO THE SCREEN
023437
023437     PERFORM  1550-MOVE-TAX-DATA-TO-MIR
023437         THRU 1550-MOVE-TAX-DATA-TO-MIR-X.

           PERFORM  2600-FORMAT-ATTR-PHASE-0
               THRU 2600-FORMAT-ATTR-PHASE-0-X.

       1400-TRAN-PHASE-0-X.
           EXIT.

      *----------------------
       1410-SET-ERROR-ATTRIB.
      *----------------------

           IF  L6330-CVG-NUM-ERR
013578         SET MIR-RETRN-EDIT-ERROR     TO TRUE
               GO TO 1410-SET-ERROR-ATTRIB-X
557660     END-IF.

           IF  L6330-ALLOC-CD-ERR
013578         SET MIR-RETRN-EDIT-ERROR     TO TRUE
               GO TO 1410-SET-ERROR-ATTRIB-X
557660     END-IF.

           IF  L6330-DEST-CD-ERR
013578         SET MIR-RETRN-EDIT-ERROR     TO TRUE
557660     END-IF.

           IF  L6330-SURR-AMT-ERR
013578         SET MIR-RETRN-EDIT-ERROR     TO TRUE
557660     END-IF.

           IF  L6330-REASN-CD-ERR
013578         SET MIR-RETRN-EDIT-ERROR     TO TRUE
557660     END-IF.

           IF  L6330-TAX-BPSS-ERR
013578         SET MIR-RETRN-EDIT-ERROR     TO TRUE
557660     END-IF.
013693
013693     IF  L6330-LTAXWH-CALC-ERR
013693         SET MIR-RETRN-EDIT-ERROR     TO TRUE
013693     END-IF.

           IF  L6330-EFF-DATE-ERR
013578         SET MIR-RETRN-EDIT-ERROR     TO TRUE
           END-IF.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL   I > LSEGF-FND-CTR

                   IF  L6330-SURR-UNITS-ERR (I)
013578                 SET MIR-RETRN-EDIT-ERROR     TO TRUE
                  END-IF

           END-PERFORM.

       1410-SET-ERROR-ATTRIB-X.
           EXIT.

      *------------------
       1500-TRAN-PHASE-1.
      *------------------

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221         GO TO 1500-TRAN-PHASE-1-X
014221     END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  2350-EDATE-EDITS
                   THRU 2350-EDATE-EDITS-X
           END-IF.

018846     IF  WGLOB-GOOD-RETURN
018846         PERFORM  2355-SIDE-FND-TST
018846             THRU 2355-SIDE-FND-TST-X
018846     END-IF.
018846
016108     IF  WGLOB-GOOD-RETURN
016108         PERFORM  2370-VAL-DATE-OF-DTH
016108             THRU 2370-VAL-DATE-OF-DTH-X
016108     END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  2400-GET-FC
                   THRU 2400-GET-FC-X
           END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  2500-GET-CASH-VALUES
                   THRU 2500-GET-CASH-VALUES-X
           END-IF.

031034*    IF  WGLOB-GOOD-RETURN
031034*        PERFORM  4800-GET-PGAL-INFO
031034*            THRU 4800-GET-PGAL-INFO-X
031034*    END-IF.
015290
023437     IF  WGLOB-GOOD-RETURN
023437         PERFORM  5000-EDIT-LTAXWH-RQST
023437             THRU 5000-EDIT-LTAXWH-RQST-X
023437     END-IF.
023437
023437     IF  WGLOB-GOOD-RETURN
023437         PERFORM  5100-EDIT-TAXWH-RQST
023437             THRU 5100-EDIT-TAXWH-RQST-X
023437     END-IF.
023437
           IF  WGLOB-GOOD-RETURN
               SET L6330-PRCES-TYP-EDIT-ONLY TO TRUE
016503         SET L6330-REDO-WARNING        TO TRUE
               PERFORM 6330-1000-PROCESS-SURR
                  THRU 6330-1000-PROCESS-SURR-X
               IF  L6330-RETRN-ERROR
                   MOVE '1'           TO WGLOB-RETURN-CODE
                   PERFORM 1410-SET-ERROR-ATTRIB
                      THRU 1410-SET-ERROR-ATTRIB-X
               END-IF
           END-IF.

      * SOME FIELDS MAY BE OVERRIDDEN IN THE EDIT MODULE - MOVE THESE
      * TO THE MIR HERE

           MOVE L6330-REASN-CD        TO MIR-CIA-REASN-CD.
029060*    MOVE L6330-FED-TAXWH-CALC-CD  TO WS-FED-TAXWH-CALC-CD.
029060*    MOVE L6330-FED-TAXWH-RQST-AMT TO WS-FED-TAXWH-RQST-AMT.
029060*    MOVE L6330-FED-TAXWH-RQST-PCT TO WS-FED-TAXWH-RQST-PCT.

023437* MOVE THE FEDERAL TAX REQUEST DATA TO THE SCREEN
023437
023437     PERFORM 1550-MOVE-TAX-DATA-TO-MIR
023437        THRU 1550-MOVE-TAX-DATA-TO-MIR-X.
023437
           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 1500-TRAN-PHASE-1-X
557660     END-IF.

           IF  WS-BUS-FCN-PCT-TOT-VALU
               IF  MIR-FIA-VALU-SURR-PCT = '000.0000'
      * MESSAGE - % OF VALUE MUST EXCEED ZERO
                   MOVE 'SS00800002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
014035             PERFORM  1505-POFVAL-TEST
014035                 THRU 1505-POFVAL-TEST-X
557660         END-IF
557660     END-IF.

012135     MOVE L6330-CVG-NUM         TO I.
012135
012135     PERFORM  PLIN-1000-PLAN-HEADER-IN
012135         THRU PLIN-1000-PLAN-HEADER-IN-X.
012135
           IF  (WS-BUS-FCN-DOLLAR-AMT AND
                MIR-CIA-REASN-CD = 'GRS')
           OR  WS-BUS-FCN-PCT-AMT
           OR  WS-BUS-FCN-PCT-FND-VALU
           OR  WS-BUS-FCN-NUM-UNITS
               PERFORM  1510-TRAN-PHASE-1B
                   THRU 1510-TRAN-PHASE-1B-X
               GO TO 1500-TRAN-PHASE-1-X
           ELSE
               MOVE 0                 TO WS-CONTROL-TOTAL
               MOVE 0                 TO WS-CONTROL-UNITS
               PERFORM  2800-EDIT-BOTTOM-DATA
                   THRU 2800-EDIT-BOTTOM-DATA-X
                VARYING I FROM 1 BY 1
                  UNTIL I > LSEGF-FND-CTR

               PERFORM  2650-FORMAT-ATTR-PHASE-1
                   THRU 2650-FORMAT-ATTR-PHASE-1-X
557660     END-IF.

       1500-TRAN-PHASE-1-X.
           EXIT.

014035*-----------------
014035 1505-POFVAL-TEST.
014035*-----------------
014035
014035     IF  MIR-FIA-VALU-SURR-PCT > '100.0000'
014035* MESSAGE - % OF VALUE MUST NOT EXCEED 100.0000
014035         MOVE 'SS00800018'      TO WGLOB-MSG-REF-INFO
014035         PERFORM  0260-1000-GENERATE-MESSAGE
014035             THRU 0260-1000-GENERATE-MESSAGE-X
014035     ELSE
014035         IF  MIR-FIA-VALU-SURR-PCT = '100.0000'
014035* MESSAGE - FULL SURRENDER - PLEASE USE TERM
014035             MOVE 'SS00800006'  TO WGLOB-MSG-REF-INFO
014035             PERFORM  0260-1000-GENERATE-MESSAGE
014035                 THRU 0260-1000-GENERATE-MESSAGE-X
014035         END-IF
014035     END-IF.
014035
014035 1505-POFVAL-TEST-X.
014035     EXIT.
014035
      *-------------------
       1510-TRAN-PHASE-1B.
      *-------------------

           MOVE 0                     TO WS-CONTROL-TOTAL.
           MOVE 0                     TO WS-CONTROL-UNITS.
           PERFORM  2800-EDIT-BOTTOM-DATA
               THRU 2800-EDIT-BOTTOM-DATA-X
            VARYING I FROM 1 BY 1
              UNTIL I > LSEGF-FND-CTR.

           IF  WGLOB-MSG-ERROR-SW = 0
               PERFORM  2850-TOTAL-CHECK
                   THRU 2850-TOTAL-CHECK-X
           END-IF.

           PERFORM  2650-FORMAT-ATTR-PHASE-1
               THRU 2650-FORMAT-ATTR-PHASE-1-X.

       1510-TRAN-PHASE-1B-X.
           EXIT.
023437/
023437*--------------------------
023437 1550-MOVE-TAX-DATA-TO-MIR.
023437*--------------------------
023437
023437* MOVE THE FEDERAL TAX WITHHOLDING AMOUNT
023437
023437     MOVE L6330-FED-TAX-WTHLD-AMT  TO L0290-INPUT-V02.
023437     MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-FTAXWH-AMT.
029060     MOVE L6330-LTAXWH-AMT         TO L0290-INPUT-V02.
029060     MOVE 2                        TO L0290-PRECISION.
029060     MOVE LENGTH OF MIR-LTAXWH-AMT TO L0290-MAX-OUT-LEN.
029060
029060     PERFORM  0290-2000-FORMAT-FOR-MIR
029060         THRU 0290-2000-FORMAT-FOR-MIR-X.
029060
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-LTAXWH-AMT.
023437
023437* MOVE THE FEDERAL TAX REQUEST DATA
023437
023437     MOVE WS-FED-TAXWH-RQST-AMT
023437                              TO L0290-INPUT-V02.
023437     MOVE 2                   TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                             TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                              TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA  TO MIR-FED-TAXWH-RQST-AMT.
029060     MOVE  L0290-OUTPUT-DATA  TO MIR-FTAXWH-RQST-AMT.
023437
023437     MOVE WS-FED-TAXWH-RQST-PCT
023437                              TO L0290-INPUT-V02.
023437     MOVE 2                   TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                             TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                              TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA  TO MIR-FED-TAXWH-RQST-PCT.
029060     MOVE  L0290-OUTPUT-DATA  TO MIR-FTAXWH-RQST-PCT.
023437
023437* MOVE THE LOCATION TAX REQUEST DATA
024958*023437
024958*023437     IF  L6330-LTAXWH-CALC-CD NOT = SPACES
024958*023437         MOVE L6330-LTAXWH-CALC-CD  TO MIR-LTAXWH-CALC-CD
024958*023437     END-IF.
024958*023437
024958*023437     MOVE L6330-LTAXWH-FLAT-AMT  TO L0290-INPUT-V02.
024958     MOVE WS-LOC-RQST-AMT     TO L0290-INPUT-V02.
023437     MOVE 2                   TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                             TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                              TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA  TO MIR-LTAXWH-FLAT-AMT.
029060     MOVE  L0290-OUTPUT-DATA  TO MIR-LTAXWH-RQST-AMT.
023437
024958*023437     MOVE L6330-LTAXWH-PCT    TO L0290-INPUT-V02.
024958     MOVE WS-LOC-RQST-PCT     TO L0290-INPUT-V02.
023437     MOVE 2                   TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                             TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                              TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA  TO MIR-LTAXWH-PCT.
029060     MOVE  L0290-OUTPUT-DATA  TO MIR-LTAXWH-RQST-PCT.
023437
023437 1550-MOVE-TAX-DATA-TO-MIR-X.
023437     EXIT.
      /
      *------------------
       1600-TRAN-PHASE-2.
      *------------------

013578*    MOVE 'CFA'                 TO WTSQP-NAME-MNEMONIC.
013578*    MOVE +1                    TO WTSQP-QUEUE-ITEM.
557973*    MOVE +8000                 TO WTSQP-QUEUE-LENGTH.
012141*    MOVE +8400                 TO WTSQP-QUEUE-LENGTH.
013578*    MOVE +13400                TO WTSQP-QUEUE-LENGTH.
013578*    PERFORM  TSQP-1000-READ-TS-QUEUE
013578*        THRU TSQP-1000-READ-TS-QUEUE-X.

013578     PERFORM  8090-1000-BUILD-PARM-INFO
013578         THRU 8090-1000-BUILD-PARM-INFO-X.
013578
013578     SET L8090-TEMP-WRK-TYP-SEG-ACTV TO TRUE.
013578     MOVE LENGTH OF WS-TWRK-WORK-AREA TO L8090-AREA-LEN.
013578     MOVE +1              TO L8090-TEMP-WRK-SEQ-NUM.
013578
013578     PERFORM  8090-2000-RETRIEVE-TWRK
013578         THRU 8090-2000-RETRIEVE-TWRK-X.
013578
013578     IF L8090-RETRN-OK
013578         MOVE L8090-AREA-INFO-TEXT TO WS-TWRK-WORK-AREA
               MOVE WPDTQ-CMFC-AREA       TO LSEGF-FC-FS-INFO
               MOVE WPDTQ-CMFA-AREA       TO LSEGF-FA-FD-INFO
013578         PERFORM  8090-3000-DELETE-TWRK
013578             THRU 8090-3000-DELETE-TWRK-X
013578     END-IF.

013578*    PERFORM  2510-1000-BUILD-PARM-INFO
013578*        THRU 2510-1000-BUILD-PARM-INFO-X.
013578*    SET L2510-CHG-OPTION-REQD  TO TRUE.
013578*    SET L2510-OVR-OPTION-REQD  TO TRUE.
013578*    MOVE MIR-DV-VERIF-TXT      TO L2510-RESPONSE-TXT.
013578*    PERFORM  2510-1000-VALIDATE-RESPONSE
013578*        THRU 2510-1000-VALIDATE-RESPONSE-X.
557756* IF (MIR-DV-VERIF-TXT NOT = TYSNO-YES-NO-LONG (WGLOB-LANG-SUB, 1)
557756* AND MIR-DV-VERIF-TXT NOT = TYSNO-YES-NO-LONG (WGLOB-LANG-SUB, 2)
557756*    AND MIR-DV-VERIF-TXT NOT = 'OVR'
557756*    AND MIR-DV-VERIF-TXT NOT = 'CHG'
557756*    AND MIR-DV-VERIF-TXT NOT = 'ECR')
013578*    IF  L2510-RESPONSE-INVALID
557756*    OR (MIR-DV-VERIF-TXT = 'OVR'
013578*    OR  (L2510-RESPONSE-OVR
013578*     AND  LSEGF-PREM-ERROR-IND = ZERO)
      *  RETRIEVE ALL VALUES AGAIN FROM THE FILES AND RE-DO THE EDITS
013578*        MOVE 'Y'               TO WS-VERIFY-ERROR-SW
013578*        PERFORM  1500-TRAN-PHASE-1
013578*            THRU 1500-TRAN-PHASE-1-X
013578*        MOVE WGLOB-MSG-ERROR-SW TO WS-HOLD-WGLOB-MSG-ERROR
      * MSG - INVALID VERIFY OPTION - REENTER
013578*        MOVE 'SS00800005'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        MOVE WS-HOLD-WGLOB-MSG-ERROR
013578*                               TO WGLOB-MSG-ERROR-SW
013578*        IF  WGLOB-MSG-ERROR-SW NOT = ZERO
013578*            MOVE '1'           TO WGLOB-RETURN-CODE
013578*        END-IF
013578*        MOVE RPOL-POL-ID       TO LPGA-POLICY-NUMBER
013578*        MOVE 'CFA'             TO WTSQP-NAME-MNEMONIC
013578*        PERFORM  TSQP-4000-DELETE-TS-QUEUE
013578*            THRU TSQP-4000-DELETE-TS-QUEUE-X
557973*        MOVE +8000             TO WTSQP-QUEUE-LENGTH
012141*        MOVE +8400             TO WTSQP-QUEUE-LENGTH
013578*        MOVE +13400            TO WTSQP-QUEUE-LENGTH
013578*        MOVE LSEGF-FC-FS-INFO  TO WPDTQ-CMFC-AREA
013578*        MOVE LSEGF-FA-FD-INFO  TO WPDTQ-CMFA-AREA
013578*        PERFORM  TSQP-2000-WRITE-TS-QUEUE
013578*            THRU TSQP-2000-WRITE-TS-QUEUE-X
013578*        IF  NOT WTSQP-QUEUE-OK
013578*            MOVE 'XS00000092'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*        END-IF
013578*        GO TO 1600-TRAN-PHASE-2-X
013578*    END-IF.

           MOVE 0                     TO FSUR-CALL-SW.

557756*    IF (MIR-DV-VERIF-TXT = TYSNO-YES-NO-LONG (WGLOB-LANG-SUB, 1)
013578*    IF (L2510-RESPONSE-YES
013578*        AND LSEGF-PREM-ERROR-IND = 1)
      * MSG - INVALID VERIFY OPTION - REENTER
013578*        MOVE 'SS00800005'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        MOVE SPACES            TO MIR-DV-VERIF-TXT
013578*        GO TO 1600-TRAN-PHASE-2-X
013578*    END-IF.

013578*    IF  WTSQP-QUEUE-OK
013578*        PERFORM  TSQP-4000-DELETE-TS-QUEUE
013578*            THRU TSQP-4000-DELETE-TS-QUEUE-X
013578*    ELSE
013578*        MOVE 'XS00000092'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        GO TO 1600-TRAN-PHASE-2-X
013578*    END-IF.

557756*    IF  MIR-DV-VERIF-TXT = TYSNO-YES-NO-LONG (WGLOB-LANG-SUB, 1)
013578*    IF  L2510-RESPONSE-YES
013578*    AND LSEGF-PREM-ERROR-IND = 0
013578     IF  LSEGF-PREM-ERROR-IND = 0
               MOVE ZERO              TO POFVAL-HOLD-N
               PERFORM  1620-UPDATE-ACTIVITY
                   THRU 1620-UPDATE-ACTIVITY-X
016503         IF  WS-REDO-NOT-OK
016503         OR  MIR-RETRN-TS-MISMATCH
016503             GO TO 1600-TRAN-PHASE-2-X
016503         END-IF
013578*    ELSE
557756*     IF  MIR-DV-VERIF-TXT = TYSNO-YES-NO-LONG (WGLOB-LANG-SUB, 2)
013578*        IF  L2510-RESPONSE-NO
013578*            MOVE ZERO          TO POFVAL-HOLD-N
013578*            MOVE 1             TO CLEAR-SW
013578*            MOVE 1             TO RESET-SW
013578* MSG - SURRENDER REJECTED - USER REQUEST
013578*            MOVE 'SS00800004'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*        ELSE
557756*            IF  MIR-DV-VERIF-TXT = 'OVR'
557756*            OR  MIR-DV-VERIF-TXT = 'ECR'
013578*            PERFORM  1605-L2510-TEST
013578*                THRU 1605-L2510-TEST-X
013578*        END-IF
013578     END-IF.

557756*    IF  MIR-DV-VERIF-TXT = 'YES'
557756*    OR  MIR-DV-VERIF-TXT = 'OVR'
557756*    OR  MIR-DV-VERIF-TXT = 'CHG'
557756*    OR  MIR-DV-VERIF-TXT = 'OUI'
557756*    OR  MIR-DV-VERIF-TXT = 'ECR'
013578*    IF  L2510-RESPONSE-YES
013578*    OR  L2510-RESPONSE-OVR
013578*    OR  L2510-RESPONSE-CHG
013578*        MOVE SPACES            TO MIR-DV-VERIF-TXT
013578*    ELSE
557756*     IF  MIR-DV-VERIF-TXT = TYSNO-YES-NO-LONG (WGLOB-LANG-SUB, 2)
013578*         IF  L2510-RESPONSE-NO
013578*             PERFORM  1615-LSEGF-TEST
013578*                 THRU 1615-LSEGF-TEST-X
013578*        END-IF
013578*    END-IF.

       1600-TRAN-PHASE-2-X.
           EXIT.

013578*----------------
013578*1605-L2510-TEST.
013578*----------------
013578*
013578*    IF  L2510-RESPONSE-OVR
013578*        MOVE ZERO              TO POFVAL-HOLD-N
013578*        IF  LSEGF-PREM-ERROR-IND = 0
013578*        OR  LSEGF-PREM-ERROR-IND = 1
013578*            PERFORM  1620-UPDATE-ACTIVITY
013578*                THRU 1620-UPDATE-ACTIVITY-X
013578*        ELSE
013578*            MOVE 1             TO CLEAR-SW
013578* MSG: FULL SURRENDER - PLEASE USE TERM
013578*            MOVE 'SS00800006'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*        END-IF
013578*    ELSE
013578*        IF  MIR-DV-VERIF-TXT = 'CHG'
013578*        IF  L2510-RESPONSE-CHG
013578*            MOVE 'N'           TO WS-SCREEN-UPDATE-SW
013578*            MOVE 0             TO CLEAR-SW
013578* MSG: SURRENDER HALTED - ENTER YOUR CHANGES
013578*            MOVE 'SS00800007'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*            PERFORM  2300-GET-POLICY
013578*                THRU 2300-GET-POLICY-X
013578*            IF  MIR-ALLOC = 'A'
013578*            OR  MIR-ALLOC = 'B'
013578*            PERFORM  1610-ALLOC-TEST
013578*                THRU 1610-ALLOC-TEST-X
013578*        ELSE
013578*            PERFORM  1500-TRAN-PHASE-1
013578*                THRU 1500-TRAN-PHASE-1-X
013578*            MOVE 1             TO FSUR-CALL-SW
013578* MSG: INVALID VERIFY OPTION - REENTER
013578*            MOVE 'SS00800005'  TO WGLOB-MSG-REF-INFO
013578*            PERFORM  0260-1000-GENERATE-MESSAGE
013578*                THRU 0260-1000-GENERATE-MESSAGE-X
013578*        END-IF
013578*    END-IF.
013578*
013578*1605-L2510-TEST-X.
013578*    EXIT.

013578*----------------
013578*1610-ALLOC-TEST.
013578*----------------
013578*
013578*    IF  WS-BUS-FCN-PRORATE-FND-VALU
013578*        MOVE 0                 TO FSUR-CALL-SW
013578*    ELSE
013578*        PERFORM  2600-FORMAT-ATTR-PHASE-0
013578*            THRU 2600-FORMAT-ATTR-PHASE-0-X
013578* MSG: BLANK OUT CHARGE TO AUTOMATICALLY RECALCULATE
013578*        MOVE 'SS00800045'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*    END-IF.
013578*
013578*1610-ALLOC-TEST-X.
013578*    EXIT.

013578*----------------
013578*1615-LSEGF-TEST.
013578*----------------
013578*
013578*    IF  LSEGF-ITEM-CTR = ZERO
013578*        NEXT SENTENCE
013578*    ELSE
013578*        MOVE 'SFA'             TO WTSQP-NAME-MNEMONIC
013578*        PERFORM  TSQP-4000-DELETE-TS-QUEUE
013578*            THRU TSQP-4000-DELETE-TS-QUEUE-X
013578*        MOVE 'SFI'             TO WTSQP-NAME-MNEMONIC
013578*        PERFORM  TSQP-4000-DELETE-TS-QUEUE
013578*            THRU TSQP-4000-DELETE-TS-QUEUE-X
013578*    END-IF.
013578*
013578*1615-LSEGF-TEST-X.
013578*    EXIT.

      *---------------------
       1620-UPDATE-ACTIVITY.
      *---------------------

           MOVE WGLOB-COMPANY-CODE    TO WPOL-CO-ID.
           MOVE LSEGF-INV-CVG-POL-ID  TO WPOL-POL-ID.
014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.
014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'    TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'           TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         SET WGLOB-RETURN-ERROR    TO  TRUE
014221         GO TO 1620-UPDATE-ACTIVITY-X
014221     END-IF.

           MOVE RPOL-POL-ID           TO LPGA-POLICY-NUMBER.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

557701     MOVE LSEGF-INPUT-LOAD-FORCE-IND
                                      TO WS-INPUT-LOAD-FORCE-IND.
557701     MOVE LSEGF-INPUT-LOAD-AMT  TO WS-INPUT-LOAD-AMT.

023437     IF  WGLOB-GOOD-RETURN
023437         PERFORM  5000-EDIT-LTAXWH-RQST
023437             THRU 5000-EDIT-LTAXWH-RQST-X
023437     END-IF.
023437
023437     IF  WGLOB-GOOD-RETURN
023437         PERFORM  5100-EDIT-TAXWH-RQST
023437             THRU 5100-EDIT-TAXWH-RQST-X
023437     END-IF.
023437
016503     PERFORM  1632-PROCESS-REDO
016503         THRU 1632-PROCESS-REDO-X.
016503
016503     IF  WS-REDO-NOT-OK
016503         GO TO 1620-UPDATE-ACTIVITY-X
016503     END-IF.

557701     PERFORM  1622-INVOKE-UNDO
557701         THRU 1622-INVOKE-UNDO-X.
557701
557701     IF  NOT WGLOB-GOOD-RETURN
557701         GO TO 1620-UPDATE-ACTIVITY-X
557701     END-IF.
557701
012696     PERFORM  8600-CHECK-TRANS-DEFER
012696         THRU 8600-CHECK-TRANS-DEFER-X.
012696
012696     IF  L8170-RETRN-OK
012696     AND L8170-DEFR-REQUIRED
012696         PERFORM  8700-DEFER-TRANSACTION
012696             THRU 8700-DEFER-TRANSACTION-X
016503         PERFORM  1650-SET-POL-NXT-ACTV
016503             THRU 1650-SET-POL-NXT-ACTV-X
012696         PERFORM  POL-2000-REWRITE
012696             THRU POL-2000-REWRITE-X
012696         PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
012696             THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
013578*        MOVE SPACES            TO MIR-DV-VERIF-TXT
012696         MOVE LSEGF-INV-CVG-REC-INFO
                                      TO RFC-REC-INFO
012696         MOVE RFC-CVG-CFN-REC-CTR
                                      TO LSEGF-FND-CTR
012696         MOVE 'UF'              TO LSEGF-INV-CVG-CFN-OPT-CD
012696         PERFORM  0500-1000-PROCESS-FC-FS
012696             THRU 0500-1000-PROCESS-FC-FS-X
012696         IF  WGLOB-MSG-ERROR-SW = ZERO
012696             MOVE 1             TO RESET-SW
012696         END-IF
012696         GO TO 1620-UPDATE-ACTIVITY-X
012696     END-IF.
012696
012143     PERFORM  1750-CREATE-SURR-CDSA
012143         THRU 1750-CREATE-SURR-CDSA-X.
012143
012143     SET  WS-DBSC-CDSA-YES  TO TRUE.
012143     PERFORM  1700-DPOS-BASED-SURR-CHRG
012143         THRU 1700-DPOS-BASED-SURR-CHRG-X.
012143
012143     PERFORM  1760-UPDATE-SURR-CDSA
012143         THRU 1760-UPDATE-SURR-CDSA-X.
012143
031034*    PERFORM  4800-GET-PGAL-INFO
031034*        THRU 4800-GET-PGAL-INFO-X.
015290
020475     PERFORM  7400-INIT-DBG-DATA
020475         THRU 7400-INIT-DBG-DATA-X.

012143     PERFORM  1770-CREATE-SURR-CDSD
012143         THRU 1770-CREATE-SURR-CDSD-X.
012143
           MOVE ZERO                  TO L6330-SURR-PCT
           MOVE 'VER'                 TO LSEGF-CIA-FIA-OPT-CD
016503     SET L6330-REDO-WARNING     TO TRUE
023437     MOVE L2600-CDA-TYP-CD      TO L6330-CDA-TYP-CD.
023437     MOVE L2600-POL-PAYO-NUM    TO L6330-POL-PAYO-NUM.
023437     MOVE L2600-CDA-SEQ-NUM     TO L6330-CDA-SEQ-NUM.
028788     SET L6330-AGT-COMM-RQST    TO TRUE.
029060     MOVE MIR-CIA-EFF-DT        TO L6330-EFF-DATE.

           PERFORM  6330-2000-VERIFY-SURR
               THRU 6330-2000-VERIFY-SURR-X.

013578*    MOVE SPACES                TO MIR-DV-VERIF-TXT

           IF  L6330-RETRN-ERROR
               GO TO 1620-UPDATE-ACTIVITY-X
           END-IF.

029060*    PERFORM  1780-UPDATE-SURR-CDSA
029060*        THRU 1780-UPDATE-SURR-CDSA-X.
023437
031034*    IF  WCVGS-PLAN-FND-TYP-XTRNL (LSEGF-INPUT-CVG-NUM)
031034*        CONTINUE
031034*    ELSE
031034*        IF  LPGAL-PGAL-ALLOC-REQ
031034*            PERFORM  4675-WRITE-PGAL-REC
031034*                THRU 4675-WRITE-PGAL-REC-X
031034*        END-IF
031034*    END-IF.
015290

020475     PERFORM  7410-WRITE-DBGA-REC
020475         THRU 7410-WRITE-DBGA-REC-X.

           IF  L6330-RETRN-OK
               MOVE LSEGF-INV-CVG-REC-INFO
                                      TO RFC-REC-INFO
               MOVE RFC-CVG-CFN-REC-CTR
                                      TO LSEGF-FND-CTR
               MOVE 'UF'              TO LSEGF-INV-CVG-CFN-OPT-CD
               PERFORM  0500-1000-PROCESS-FC-FS
                   THRU 0500-1000-PROCESS-FC-FS-X
               IF  L0500-RETRN-OK
      * MSG - SURRENDER ACCEPTED
                   MOVE 'SS00800003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
016503
016503     PERFORM  1650-SET-POL-NXT-ACTV
016503         THRU 1650-SET-POL-NXT-ACTV-X.
016503
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X
           IF  WGLOB-MSG-ERROR-SW = ZERO
               MOVE 1                 TO RESET-SW
557660     END-IF.

       1620-UPDATE-ACTIVITY-X.
           EXIT.
557701
557701*-----------------
557701 1622-INVOKE-UNDO.
557701*-----------------
557701
557701*  UNLOCK POLICY PRIOR TO UNDO
557701     PERFORM  POL-3000-UNLOCK
557701         THRU POL-3000-UNLOCK-X.
557701
557701     PERFORM  4750-1000-BUILD-PARM-INFO
557701         THRU 4750-1000-BUILD-PARM-INFO-X.

012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L4750-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.
557701
557701     SET L4750-FCN-DRVR-SECONDARY TO TRUE.
557701     MOVE LSEGF-INPUT-EFF-DT      TO L4750-EFF-DT.
557701     SET  L4750-PRCES-EXCLUSIVE   TO TRUE.
557701
557701     PERFORM  4750-1000-UNDO-PROCESSING
557701         THRU 4750-1000-UNDO-PROCESSING-X.
557701
557701     IF  NOT L4750-RETRN-OK
557701         SET WGLOB-RETURN-ERROR TO TRUE
557701     END-IF.
557701
557701     IF  L4750-POL-UPDATE-NOT-REQD
557701*  RELOCK POLICY
557701         MOVE  RPOL-KEY         TO WPOL-KEY
557701         PERFORM  POL-1000-READ-FOR-UPDATE
557701             THRU POL-1000-READ-FOR-UPDATE-X
557701         GO TO 1622-INVOKE-UNDO-X
557701     END-IF.
557701
557701*  SAVE POLICY CHANGES DONE BY UNDO PROCESS
557701     MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
557701
557701     MOVE RPOL-KEY              TO WPOL-KEY.
557701     PERFORM  POL-1000-READ-FOR-UPDATE
557701         THRU POL-1000-READ-FOR-UPDATE-X.
557701     MOVE HPOL-REC-INFO         TO RPOL-REC-INFO.
557701
016503     PERFORM  1650-SET-POL-NXT-ACTV
016503         THRU 1650-SET-POL-NXT-ACTV-X.
016503
557701     PERFORM  POL-2000-REWRITE
557701         THRU POL-2000-REWRITE-X.
557701     PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
557701         THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.
557701
557701*  REBUILD SEGFUND TSQ'S, ETC. AS UNDO WILL HAVE CHANGED
557701*  TRANSACTIONS DATED AFTER THIS ONE
557701*
557701     SET WS-REBUILD-AFTER-UNDO-YES TO TRUE.
557701     PERFORM  1500-TRAN-PHASE-1
557701         THRU 1500-TRAN-PHASE-1-X.
557701
557701     IF  FSUR-CALL-SW = 1
557701         PERFORM  1200-CALL-FSUR
557701             THRU 1200-CALL-FSUR-X
557701         MOVE 0                 TO FSUR-CALL-SW
557701     END-IF.
557701
557701*  RELOCK POLICY
557701     MOVE  RPOL-KEY             TO  WPOL-KEY.
557701     PERFORM  POL-1000-READ-FOR-UPDATE
557701         THRU POL-1000-READ-FOR-UPDATE-X.
557701
557701 1622-INVOKE-UNDO-X.
557701     EXIT.
016503
016503*------------------
016503 1632-PROCESS-REDO.
016503*------------------
016503
016503     IF  (RPOL-POL-NXT-ACTV-DT NOT = WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503         GO TO 1632-PROCESS-REDO-X
016503     END-IF.
016503
016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503         GO TO 1632-PROCESS-REDO-X
016503     END-IF.
016503
016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     MOVE LSEGF-INPUT-EFF-DT            TO L4780-EFF-DT.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
016503     SET L4780-PRCES-INCLUSIVE          TO TRUE.
016503
016503     PERFORM  4780-1000-GET-NEXT-ACT-DT
016503         THRU 4780-1000-GET-NEXT-ACT-DT-X.
016503
016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              SET WS-REDO-NOT-OK           TO TRUE
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503*  UNLOCK POLICY PRIOR TO UNDO
016503             PERFORM  POL-3000-UNLOCK
016503                 THRU POL-3000-UNLOCK-X
016503             MOVE LSEGF-INPUT-EFF-DT  TO L0201-EFF-DT
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X
016503
016503             PERFORM  1650-SET-POL-NXT-ACTV
016503                THRU  1650-SET-POL-NXT-ACTV-X
016503
016503             MOVE RPOL-REC-INFO            TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503             MOVE HPOL-REC-INFO            TO RPOL-REC-INFO
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
016503             PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016503                 THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
016503             IF  L0201-RETRN-OK
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503                 GO TO 1632-PROCESS-REDO-X
016503             END-IF
016503*
016503*  REBUILD SEGFUND TSQ'S, ETC.
016503*
016503             SET WS-REBUILD-AFTER-REDO-YES TO TRUE
016503
016503             PERFORM  1500-TRAN-PHASE-1
016503                 THRU 1500-TRAN-PHASE-1-X
016503
016503             IF  FSUR-CALL-SW = 1
016503                 PERFORM  1200-CALL-FSUR
016503                     THRU 1200-CALL-FSUR-X
016503                 MOVE 0                 TO FSUR-CALL-SW
016503             END-IF
016503
016503             MOVE RPOL-REC-INFO         TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503
016503             MOVE HPOL-REC-INFO         TO RPOL-REC-INFO
016503
016503     END-EVALUATE.
016503
016503
016503 1632-PROCESS-REDO-X.
016503     EXIT.
016503
016503*----------------------
016503 1650-SET-POL-NXT-ACTV.
016503*----------------------
016503
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503
016503     MOVE LSEGF-INPUT-EFF-DT     TO L0289-LO-PAC-DT.
016503     MOVE LSEGF-INPUT-EFF-DT     TO L0289-LO-CRC-DT.
016503     MOVE LSEGF-INPUT-EFF-DT     TO L0289-LO-DD2-DT.
016503     MOVE LSEGF-INPUT-EFF-DT     TO L0289-PROC-EFF-DT.
016503
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503     END-IF.
016503
016503 1650-SET-POL-NXT-ACTV-X.
016503     EXIT.
012143
012143*--------------------------
012143 1700-DPOS-BASED-SURR-CHRG.
012143*--------------------------
012143
012143     MOVE LSEGF-INPUT-AMT       TO WS-DBSC-TOT-SURR-AMT.
012143     MOVE ZEROS                 TO WS-DBSC-TOT-CHRG-AMT.
012143     MOVE ZEROS                 TO WS-DBSC-TOT-FREE-AMT.
012143
012143*
012143* CHECK IF DEPOSIT BASED SURRENDER CHARGES APPLY
012143*
012143
012143     PERFORM  2760-1000-BUILD-PARM-INFO
012143         THRU 2760-1000-BUILD-PARM-INFO-X.
012143*
012143* READ PLAN CORRESPONDING TO COVERAGE 1
012143*
012143     MOVE 1                     TO I.
012143
012143     PERFORM  PLIN-1000-PLAN-HEADER-IN
012143         THRU PLIN-1000-PLAN-HEADER-IN-X.
012143
012143     IF  NOT WPH-IO-OK
012143* MSG: PLAN NOT FOUND
012143         MOVE 'SS00800048'      TO WGLOB-MSG-REF-INFO
012143         PERFORM  0260-1000-GENERATE-MESSAGE
012143             THRU 0260-1000-GENERATE-MESSAGE-X
012143         GO TO 1700-DPOS-BASED-SURR-CHRG-X
012143     END-IF.
012143
012143     IF  NOT RPH-PLAN-SURR-CHRG-DPOS-BASED
018846     OR WCVGS-PLAN-FND-TYP-XTRNL (LSEGF-INPUT-CVG-NUM)
012143         SET WS-DBSC-APPLICABLE-NO TO TRUE
012143         SET L6330-DBSC-APPLICABLE-NO TO TRUE
012143         GO TO 1700-DPOS-BASED-SURR-CHRG-X
012143     END-IF.
012143
012143*
012143* CALL DEPOSIT BASED SURRENDER CHARGE CALCULATION ROUTINE
012143*
012143
012143     SET WS-DBSC-APPLICABLE     TO TRUE.
012143     MOVE RPOL-FREE-WTHDR-QTY   TO WS-HOLD-FREE-WTHDR-QTY.
012143     MOVE RPOL-FREE-WTHDR-TOT-AMT
                                      TO WS-HOLD-FREE-WTHDR-TOT-AMT.
012143
012143     IF  WS-DBSC-CDSA-YES
012143         SET L2760-PRCES-TYP-VER-ONLY TO TRUE
012143         MOVE L2600-POL-PAYO-NUM      TO L2760-POL-PAYO-NUM
012143         MOVE L2600-CDA-SEQ-NUM TO L2760-CDA-SEQ-NUM
012143     ELSE
012143         SET L2760-PRCES-TYP-EDIT-ONLY TO TRUE
012143     END-IF.
012143
012143     IF  LSEGF-INPUT-REASN-CD = 'NET'
012143         SET L2760-SURR-CHRG-TYP-PARTL-NET TO TRUE
012143     ELSE
012143         SET L2760-SURR-CHRG-TYP-PARTL-GRS TO TRUE
012143     END-IF.
012143
012143     MOVE LSEGF-INPUT-EFF-DT    TO L2760-EFF-DT.
012143     MOVE LSEGF-INPUT-AMT       TO L2760-SURR-AMT.
012143*
012143* GET MAX FREE AMOUNT
012143*
012143     MOVE LSEGF-INPUT-EFF-DT    TO L6860-EFF-DT.
012143
012143     PERFORM  6860-1000-CALC-MAX-FREE-PULL
012143         THRU 6860-1000-CALC-MAX-FREE-PULL-X.
012143
012143     IF  NOT L6860-RETRN-OK
012143* MSG: ERROR FOUND WHILE CALCULATING MAX FREE WITHDRAWAL
012143         MOVE 'SS00800047'      TO WGLOB-MSG-REF-INFO
012143         PERFORM  0260-1000-GENERATE-MESSAGE
012143             THRU 0260-1000-GENERATE-MESSAGE-X
012143         GO TO 1700-DPOS-BASED-SURR-CHRG-X
012143     END-IF.
012143
018846     IF  WCVGS-PLAN-FND-TYP-XTRNL (LSEGF-INPUT-CVG-NUM)
018846         MOVE ZERO             TO L6860-MAX-FREE-WITHDRAWAL
018846     END-IF.
018846
012143     MOVE L6860-MAX-FREE-WITHDRAWAL
                                      TO L2760-MAX-FREE-AMT.
012143
012143     PERFORM  2760-1000-CALC-SURR-CHRG
012143         THRU 2760-1000-CALC-SURR-CHRG-X.
012143
012143     IF  NOT L2760-RETRN-OK
012143         GO TO 1700-DPOS-BASED-SURR-CHRG-X
012143     END-IF.
012143
012143     MOVE L2760-SURR-CHRG-AMT   TO WS-DBSC-TOT-CHRG-AMT.
012143
012143     IF  L2760-MAX-FREE-AMT > L2760-REM-FREE-AMT
012143         COMPUTE WS-DBSC-TOT-FREE-AMT = L2760-MAX-FREE-AMT
012143                                      - L2760-REM-FREE-AMT
012143     END-IF.
012143
012143*
012143* SET UP DEPOSIT BASED SURRENDER CHARGES INFO IN SURRENDER
012143* CHARGE CALCULATION FUNCTION DRIVER LINKAGE COPYBOOK
012143*
012143
012143     MOVE WS-DBSC-TOT-SURR-AMT  TO L6330-DBSC-TOT-SURR-AMT.
012143     MOVE WS-DBSC-TOT-CHRG-AMT  TO L6330-DBSC-TOT-CHRG-AMT.
012143     MOVE WS-DBSC-TOT-FREE-AMT  TO L6330-DBSC-TOT-FREE-AMT.
012143     MOVE WS-DBSC-APPLICABLE-IND TO L6330-DBSC-APPLICABLE-IND.
012143
012143 1700-DPOS-BASED-SURR-CHRG-X.
012143     EXIT.
012143
012143*----------------------
012143 1750-CREATE-SURR-CDSA.
012143*----------------------
012143
012143*
012143* CALL CSLU2600 TO WRITE CDSA FOR THE WITHDRAWAL
012143*
012143     PERFORM  2600-1000-BUILD-PARM-INFO
012143         THRU 2600-1000-BUILD-PARM-INFO-X.
012143
012143     MOVE RPOL-POL-ID           TO L2600-POL-ID.
023437*    SET L2600-CDA-TYP-WITHDRAWAL TO TRUE.
023437     SET L2600-CDA-TYP-WTHDR    TO TRUE.
012143     MOVE LSEGF-INPUT-EFF-DT    TO L2600-CDA-EFF-DT.
012143     SET L2600-CDA-STAT-ACTIVE  TO TRUE.
023112*    SET L2600-CDA-CREAT-BY-SYSTEM TO TRUE.
012143     MOVE LSEGF-INPUT-AMT       TO L2600-CDA-TOT-TRXN-AMT.
012143     IF  LSEGF-INPUT-REASN-CD = 'NET'
012143         SET L2600-WTHDR-CHRG-INCL-NET TO TRUE
012143     ELSE
012143         SET L2600-WTHDR-CHRG-INCL-GRS TO TRUE
012143     END-IF.
012143
012143     IF  LSEGF-INPUT-LOAD-FORCE-IND = 'Y'
012143         SET L2600-WTHDR-OVRID-YES TO TRUE
012143     END-IF.
012143
012143     PERFORM  2600-1000-WRITE-CDSA
012143         THRU 2600-1000-WRITE-CDSA-X.
012143
012143     MOVE LSEGF-CIA-REC-INFO    TO RFA-REC-INFO.
012143     MOVE L2600-POL-PAYO-NUM    TO RFA-POL-PAYO-NUM.
012143     MOVE L2600-CDA-SEQ-NUM     TO RFA-CDA-SEQ-NUM.
012143     MOVE RFA-REC-INFO          TO LSEGF-CIA-REC-INFO.
015290     MOVE L2600-CDA-TYP-CD      TO WS-CDA-TYP-CD.
015290     MOVE L2600-POL-PAYO-NUM    TO WS-POL-PAYO-NUM.
015290     MOVE L2600-CDA-EFF-DT      TO L1660-INTERNAL-DATE
015290     PERFORM  1660-2000-CONVERT-INT-TO-INV
015290         THRU 1660-2000-CONVERT-INT-TO-INV-X
015290     MOVE L1660-INVERTED-DATE   TO WS-CDA-EFF-IDT-NUM
015290     MOVE L2600-CDA-SEQ-NUM     TO WS-CDA-SEQ-NUM.
012143
012143 1750-CREATE-SURR-CDSA-X.
012143     EXIT.
012143
012143*----------------------
012143 1760-UPDATE-SURR-CDSA.
012143*----------------------
012143
012143* CALL CSLU2600 TO UPDATE CDSA FOR THE WITHDRAWAL
012143*
012143     MOVE WS-DBSC-TOT-SURR-AMT  TO L2600-CDA-TOT-TRXN-AMT.
012143     MOVE WS-DBSC-TOT-CHRG-AMT  TO L2600-CDA-TOT-DWCHRG-AMT.
012143
012143     PERFORM  2600-6000-UPDATE-CDSA
012143         THRU 2600-6000-UPDATE-CDSA-X.
012143
012143     IF  WS-DBSC-APPLICABLE
012143     AND WS-DBSC-TOT-FREE-AMT > ZERO
012143         MOVE WS-HOLD-FREE-WTHDR-TOT-AMT
012143                                TO RPOL-FREE-WTHDR-TOT-AMT
012143         ADD  WS-DBSC-TOT-FREE-AMT TO RPOL-FREE-WTHDR-TOT-AMT
012143         MOVE WS-HOLD-FREE-WTHDR-QTY
012143                                TO RPOL-FREE-WTHDR-QTY
012143         IF  RPOL-FREE-WTHDR-QTY NOT = 99
012143             SUBTRACT +1        FROM RPOL-FREE-WTHDR-QTY
012143         END-IF
012143     END-IF.
012143
012143 1760-UPDATE-SURR-CDSA-X.
012143     EXIT.
012143
012143*----------------------
012143 1770-CREATE-SURR-CDSD.
012143*----------------------
012143
012143*
012143* CALL CSLU2600 TO WRITE CDSD FOR THE WITHDRAWAL
012143*
012143
012143     MOVE LSEGF-INPUT-AMT       TO L2600-CDAD-TRXN-AMT.
012143     MOVE LSEGF-INPUT-CVG-NUM   TO L2600-CVG-NUM.
012143     MOVE LSEGF-CIA-REC-INFO    TO RFA-REC-INFO.
012143     MOVE RFA-CDA-SEQ-NUM       TO L2600-CDAD-CF-FA-SEQ-NUM.
020475     MOVE RFA-CIA-FND-TRXN-AMT  TO WS-CVG-TRXN-AMT.
012143
012143     PERFORM  2600-2000-WRITE-CDSD
012143         THRU 2600-2000-WRITE-CDSD-X.
012143
012143 1770-CREATE-SURR-CDSD-X.
012143     EXIT.
023437/
029060*----------------------
029060* 1780-UPDATE-SURR-CDSA.
029060*----------------------
029060*
029060* CALL CSLU2600 TO UPDATE CDSA FOR THE WITHDRAWAL
029060*
029060*    MOVE L6330-FED-TAXWH-CALC-CD   TO  L2600-FED-TAXWH-CALC-CD.
029060*    MOVE L6330-FED-TAXWH-RQST-AMT  TO  L2600-CDA-FED-TAXWH-AMT.
029060*    MOVE L6330-FED-TAXWH-RQST-PCT  TO  L2600-FED-TAXWH-RQST-PCT.
029060*    MOVE L6330-TAXBL-PORTN-AMT     TO  L2600-CDA-DISP-TAX-AMT.
029060*    MOVE L6330-TAXBL-PORTN-AMT     TO  L2600-CDA-TAX-GAIN-AMT.
029060*    MOVE L6330-LTAXWH-FLAT-AMT     TO  L2600-CDA-LTAXWH-AMT.
029060*    MOVE L6330-FED-TAX-WTHLD-AMT   TO  L2600-CDA-FED-TAXWH-AMT.
029060*
029060*     PERFORM  2600-6000-UPDATE-CDSA
029060*         THRU 2600-6000-UPDATE-CDSA-X.
029060*
029060*
029060* 1780-UPDATE-SURR-CDSA-X.
029060*    EXIT.
029060*
      *---------------------
013578 2000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           MOVE MIR-DV-PRCES-STATE-CD   TO WS-PRCES-STATE-CD.

           IF  WS-BUS-FCN-PRORATE-FND-VALU
           AND MIR-DV-PRCES-STATE-CD = '2'
               MOVE '1'                 TO WS-PRCES-STATE-CD
           END-IF.


           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

021311*    INITIALIZE LSEGF-FA-FD-INFO.
021311*    INITIALIZE LSEGF-FC-FS-INFO.

031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034*
           PERFORM  6330-1000-BUILD-PARM-INFO
               THRU 6330-1000-BUILD-PARM-INFO-X.

021311*    SET WS-REBUILD-AFTER-UNDO-NO TO TRUE.
021311*    MOVE 'N'                   TO WS-INPUT-LOAD-FORCE-IND.
021311*    MOVE ZEROS                 TO WS-INPUT-LOAD-AMT.
021311*    MOVE 0                     TO RESET-SW.
021311*    MOVE 0                     TO WGLOB-MSG-ERROR-SW.
021311*    MOVE 0                     TO FSUR-CALL-SW.
021311*    MOVE ZEROS                 TO LSEGF-FND-CTR.
021311*    MOVE 'N'                   TO WS-VERIFY-ERROR-SW.

           PERFORM  1000-SET-UP-INPUT
               THRU 1000-SET-UP-INPUT-X.

           PERFORM  1100-PROCESS-TRANS-PHASE
               THRU 1100-PROCESS-TRANS-PHASE-X.

           IF  WS-PRCES-STATE-CD = '3'
016503*    AND LSEGF-PREM-ERROR-IND = 1
016503     AND (LSEGF-PREM-ERROR-IND = 1
016503     OR   WS-REDO-NOT-OK)
014221     OR  MIR-RETRN-TS-MISMATCH
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  FSUR-CALL-SW = 1
               PERFORM  1200-CALL-FSUR
                   THRU 1200-CALL-FSUR-X
           END-IF.

           PERFORM  1300-FORMAT-OUTPUT-SCREEN
               THRU 1300-FORMAT-OUTPUT-SCREEN-X.

013578 2000-PROCESS-REQUEST-X.
           EXIT.

      *----------------
       2100-EDIT-INPUT.
      *----------------

           IF  MIR-POL-ID-BASE = SPACES
               MOVE 'SS00800027'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.
           SET  L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
007766*    AND (L0280-OUTPUT > 0 AND L0280-OUTPUT < 21)
007766*    AND (L0280-OUTPUT > 0 AND L0280-OUTPUT <= 99)
029773*    AND (L0280-OUTPUT > 0 AND L0280-OUTPUT <= 20)
029773     AND (L0280-OUTPUT > ZERO
029773                 AND L0280-OUTPUT <= WCVGM-MAX-WCVGS-NUM)
               MOVE  L0280-OUTPUT     TO L6330-CVG-NUM
               MOVE  L6330-CVG-NUM    TO MIR-CVG-NUM
010311         MOVE  L6330-CVG-NUM    TO LSEGF-INV-CVG-CVG-NUM
           ELSE
               MOVE 'SS00800028'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

023437*018620     MOVE MIR-LTAXWH-CALC-CD    TO WS-LTAXWH-CALC-CD.
023437*018620     IF  WS-USE-LTAXWH-REC-INFO
023437*018620* MSG: INVALID LOCATION TAX CALCULATION OPTION
023437*018620         MOVE 'SS00800056'      TO WGLOB-MSG-REF-INFO
023437*018620         PERFORM  0260-1000-GENERATE-MESSAGE
023437*018620             THRU 0260-1000-GENERATE-MESSAGE-X
023437*018620     END-IF.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
557660     END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  2300-GET-POLICY
                   THRU 2300-GET-POLICY-X
557701         IF  WGLOB-GOOD-RETURN
014035             PERFORM  2105-COVNO-TEST
014035                 THRU 2105-COVNO-TEST-X
557701         END-IF
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221         GO TO 2100-EDIT-INPUT-X
014221     END-IF.

013578     IF  WS-BUS-FCN-PRORATE-FND-VALU
013578     OR  WS-BUS-FCN-DOLLAR-AMT
013578     OR  WS-BUS-FCN-PCT-AMT
013578         PERFORM  2101-EDIT-AMT
013578             THRU 2101-EDIT-AMT-X
013578     END-IF.

013578     IF  WS-BUS-FCN-PCT-TOT-VALU
013578         PERFORM  2102-EDIT-PERCENT
013578             THRU 2102-EDIT-PERCENT-X
557660     END-IF.

013578     IF  MIR-CIA-LOAD-FORCE-IND = 'N'
013578*    IF  MIR-CIA-LOAD-AMT = SPACES
013578*    OR  MIR-CIA-LOAD-AMT = EBLCH-BLANK-FIELD-CHAR
013578*        MOVE 'XXXXXXX.XX'      TO MIR-CIA-LOAD-AMT
013578*        MOVE 'XXXXXXX.XX'      TO CHARGE-HOLD
013578         MOVE ZEROS             TO CHARGE-HOLD
               MOVE ZEROS             TO L6330-SURR-CHRG
557660     END-IF.

013578*    IF  MIR-CIA-LOAD-AMT NOT = 'XXXXXXX.XX'
013578     IF  MIR-CIA-LOAD-FORCE-IND = 'Y'
               MOVE MIR-CIA-LOAD-AMT
                                      TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
008455*        MOVE 7                  TO L0280-LENGTH
               MOVE 2                 TO L0280-PRECISION
008455*        MOVE 10                 TO L0280-INPUT-SIZE
008455         MOVE LENGTH OF MIR-CIA-LOAD-AMT
008455                                TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
008455*            MOVE  L0280-OUTPUT-DOLLAR  TO CHARGE-HOLD-N
008455*            MOVE  CHARGE-HOLD          TO MIR-CIA-LOAD-AMT
008455*            MOVE  CHARGE-HOLD-N        TO L6330-SURR-CHRG
008455             MOVE  L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE  2             TO L0290-PRECISION
008455             MOVE  LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                 THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE  L0290-OUTPUT-DATA
                                      TO MIR-CIA-LOAD-AMT
008455             MOVE  L0280-OUTPUT-DOLLAR
                                      TO L6330-SURR-CHRG
008455                                          CHARGE-HOLD-N
               ELSE
                   MOVE 'SS00800012'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

012137     IF  MIR-SUPRES-CNFRM-IND NOT = SPACES
012137         IF  MIR-SUPRES-CNFRM-IND NOT = 'Y'
012137         AND MIR-SUPRES-CNFRM-IND NOT = 'N'
012137*MSG: SUPPRESS CONFIRMATION INVALID. ENTER 'Y' OR 'N'
012137             MOVE 'SS00800050'  TO WGLOB-MSG-REF-INFO
012137             PERFORM  0260-1000-GENERATE-MESSAGE
012137                 THRU 0260-1000-GENERATE-MESSAGE-X
012137         END-IF
012137     ELSE
012137         MOVE 'N'               TO MIR-SUPRES-CNFRM-IND
012137     END-IF.

013693     IF MIR-DV-PRCES-STATE-CD = '1'
024550     AND RPOL-POL-CTRY-US
013693         MOVE ZERO                  TO I
013693         PERFORM  2430-1000-BUILD-PARM-INFO
013693             THRU 2430-1000-BUILD-PARM-INFO-X
013693         PERFORM  2430-2100-GET-OWNER
013693             THRU 2430-2100-GET-OWNER-X
029060*       IF  (MIR-LTAXWH-CALC-CD  = 'B'
029060*       OR  MIR-LTAXWH-CALC-CD   = 'S')
029060        IF  (MIR-LTAXWH-RQST-CD  = 'B'
029060        OR  MIR-LTAXWH-RQST-CD   = 'S')
013693        AND (L2430-CLI-TXEMP-CD  = 'D'
013693        OR   L2430-CLI-TXEMP-CD  = 'M'
013693        OR   L2430-CLI-TXEMP-CD  = 'N'
013693        OR   L2430-CLI-TXEMP-CD  = 'S')
013693*MSG: (F) 'CLIENT HAS B-NOTICE CALCUATION ONLY ALLOWED'
013693           MOVE 'SS00800051'        TO  WGLOB-MSG-REF-INFO
013693           PERFORM  0260-1000-GENERATE-MESSAGE
013693               THRU 0260-1000-GENERATE-MESSAGE-X
013693        END-IF
013693     END-IF.
013693
           IF  WGLOB-MSG-ERROR-SW > ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
557660     END-IF.

       2100-EDIT-INPUT-X.
           EXIT.

013578*--------------
013578 2101-EDIT-AMT.
013578*--------------
013578
013578     MOVE MIR-CIA-ALLOC-SURR-AMT  TO L0280-INPUT-DATA.
013578     SET L0280-SIGN-NOT-PERMITTED TO TRUE.
013578     MOVE 2                     TO L0280-PRECISION.
013578     MOVE LENGTH OF MIR-CIA-ALLOC-SURR-AMT
013578                                TO L0280-INPUT-SIZE
013578     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
013578                            - 1.
013578     PERFORM  0280-1000-NUMERIC-EDIT
013578         THRU 0280-1000-NUMERIC-EDIT-X.
013578     IF  L0280-OK
013578         MOVE  L0280-OUTPUT-DOLLAR
013578                                TO AMOUNT-HOLD-N
013578         MOVE  L0280-OUTPUT     TO L0290-INPUT-NUMBER
013578         MOVE  2                TO L0290-PRECISION
013578         MOVE LENGTH OF MIR-CIA-ALLOC-SURR-AMT
013578                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
013578         MOVE L0290-OUTPUT-DATA TO MIR-CIA-ALLOC-SURR-AMT
013578         MOVE L0280-OUTPUT-DOLLAR
013578                                TO L6330-SURR-AMOUNT
013578     ELSE
013578* MESSAGE - INVALID AMOUNT - REENTER
013578         MOVE 'SS00800009'      TO WGLOB-MSG-REF-INFO
013578         PERFORM  0260-1000-GENERATE-MESSAGE
013578             THRU 0260-1000-GENERATE-MESSAGE-X
013578     END-IF.
013578
013578 2101-EDIT-AMT-X.
013578     EXIT.


013578*------------------
013578 2102-EDIT-PERCENT.
013578*------------------
013578
013578         MOVE MIR-FIA-VALU-SURR-PCT TO L0280-INPUT-DATA
013578         SET L0280-SIGN-NOT-PERMITTED TO TRUE
013578         MOVE 3                     TO L0280-LENGTH
013578         MOVE 4                     TO L0280-PRECISION
013578         MOVE 8                     TO L0280-INPUT-SIZE
013578         PERFORM  0280-1000-NUMERIC-EDIT
013578             THRU 0280-1000-NUMERIC-EDIT-X
013578         IF  L0280-OK
013578             MOVE  L0280-OUTPUT-V04  TO POFVAL-HOLD-N
013578             MOVE  POFVAL-HOLD       TO MIR-FIA-VALU-SURR-PCT
013578             MOVE  POFVAL-HOLD-N     TO L6330-SURR-PCT
013578         ELSE
013578* MESSAGE - INVALID % OF VALUE - REENTER
013578             MOVE 'SS00800011'      TO WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578         END-IF.
013578 2102-EDIT-PERCENT-X.
013578     EXIT.


014035*----------------
014035 2105-COVNO-TEST.
014035*----------------
014035
014035     IF  MIR-CVG-NUM > RPOL-POL-CVG-REC-CTR-N
014035         MOVE 'SS00800029'      TO WGLOB-MSG-REF-INFO
014035         MOVE MIR-CVG-NUM       TO WGLOB-MSG-PARM (1)
014035         PERFORM  0260-1000-GENERATE-MESSAGE
014035             THRU 0260-1000-GENERATE-MESSAGE-X
014035     END-IF.
014035
014035 2105-COVNO-TEST-X.
014035     EXIT.
014035
      *----------------
       2300-GET-POLICY.
      *----------------

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.

014221     EVALUATE MIR-DV-PRCES-STATE-CD
014221         WHEN '1'
014221         WHEN '2'
014221             PERFORM POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
014221         WHEN '3'
014221             PERFORM  POL-2000-UPDATE-TWRK-TS
014221                 THRU POL-2000-UPDATE-TWRK-TS-X
014221             IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                 MOVE 'XS00000303'    TO WGLOB-MSG-REF-INFO
014221                 MOVE 'POL'           TO WGLOB-MSG-PARM (01)
014221                 MOVE WPOL-KEY        TO WGLOB-MSG-PARM (02)
014221                 PERFORM  0260-1000-GENERATE-MESSAGE
014221                     THRU 0260-1000-GENERATE-MESSAGE-X
014221                 MOVE '1'             TO  WGLOB-RETURN-CODE
014221                 GO TO 2300-GET-POLICY-X
014221             ELSE
014221                 IF  WPOL-IO-OK
014221                     PERFORM  POL-3000-UNLOCK
014221                         THRU POL-3000-UNLOCK-X
014221                 END-IF
014221             END-IF
014221     END-EVALUATE.

           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 2300-GET-POLICY-X
557660     END-IF.

016440*    IF  RPOL-POL-APPL-CTL-NBS
016440*        MOVE 'XS00000238'      TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        MOVE '1'               TO WGLOB-RETURN-CODE
016440*        GO TO 2300-GET-POLICY-X
016440*    END-IF.
012624
012624     IF  RPOL-POL-SUSPENDED
012624         MOVE 'XS00000240'      TO WGLOB-MSG-REF-INFO
012624         PERFORM  0260-1000-GENERATE-MESSAGE
012624             THRU 0260-1000-GENERATE-MESSAGE-X
012624         MOVE '1'               TO WGLOB-RETURN-CODE
012624         GO TO 2300-GET-POLICY-X
012624     END-IF.

      *
      *  DO POLICY ACCESS CHECKS
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD    TO TRUE.
012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.

016440     SET L5400-POL-XFER-UPDATE  TO TRUE
016440
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
012624*    OR  L5400-CTL-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 2300-GET-POLICY-X
           END-IF.

020463     PERFORM  2320-CHECK-FOR-INV-PRFL
020463         THRU 2320-CHECK-FOR-INV-PRFL-X.

020463     IF  NOT WGLOB-GOOD-RETURN
020463         GO TO 2300-GET-POLICY-X
020463     END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
016440
016440     MOVE MIR-CVG-NUM           TO I.
016440
016440     IF  WCVGS-CVG-STAT-BEFORE-SETL (I)
016440         MOVE 'XS00000244'      TO WGLOB-MSG-REF-INFO
016440         PERFORM  0260-1000-GENERATE-MESSAGE
016440             THRU 0260-1000-GENERATE-MESSAGE-X
016440         MOVE '1'               TO WGLOB-RETURN-CODE
016440         GO TO 2300-GET-POLICY-X
016440     END-IF.
016440
           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 2300-GET-POLICY-X
557660     END-IF.

013578*    PERFORM  2430-1000-BUILD-PARM-INFO
013578*        THRU 2430-1000-BUILD-PARM-INFO-X.
013578*    MOVE MIR-DV-CLI-NM         TO L2430-OWNER-NAME-1-4.
013578*    PERFORM  2430-5000-VALIDATE-OWNER-NM
013578*        THRU 2430-5000-VALIDATE-OWNER-NM-X.
013578*    IF  NOT L2430-RETRN-OK
013578*        MOVE 'SS00800021'      TO WGLOB-MSG-REF-INFO
013578*        PERFORM  0260-1000-GENERATE-MESSAGE
013578*            THRU 0260-1000-GENERATE-MESSAGE-X
013578*        MOVE '1'               TO WGLOB-RETURN-CODE
013578*        GO TO 2300-GET-POLICY-X
013578*    END-IF.

013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE MIR-POL-ID                    TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.

       2300-GET-POLICY-X.
           EXIT.

      *------------------------
020463 2320-CHECK-FOR-INV-PRFL.
      *------------------------

020463     PERFORM  2735-1000-BUILD-PARM-INFO
020463         THRU 2735-1000-BUILD-PARM-INFO-X.
020463     MOVE  RPOL-POL-ID   TO L2735-POL-ID.
020463     PERFORM  2735-1000-GET-PRFL
020463         THRU 2735-1000-GET-PRFL-X.
020463
020463     IF L2735-RETRN-PRFL-FND
020463* MSG: THIS POLICY CONTAINS INVESTOR PROFILE (@1). ALLOCATIONS
020463*      ENTERED MAY NOT MATCH THOSE DEFINED FOR THE PROFILE.
020463         MOVE L2735-PRFL-ID  TO WGLOB-MSG-PARM (1)
020463         MOVE 'SS00800057'   TO WGLOB-MSG-REF-INFO
020463         PERFORM  0260-1000-GENERATE-MESSAGE
020463             THRU 0260-1000-GENERATE-MESSAGE-X

020463         IF  WGLOB-MSG-SEVRTY-FATAL
020463             SET WGLOB-RETURN-ERROR  TO TRUE
020463         END-IF

020463     END-IF.

020463 2320-CHECK-FOR-INV-PRFL-X.
020463     EXIT.


      *-----------------
       2350-EDATE-EDITS.
      *-----------------

           MOVE MIR-CIA-EFF-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE 'SS00800016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO L6330-EFF-DATE
557660     END-IF.
      *
           IF  WGLOB-MSG-ERROR-SW = 0
               MOVE L1640-INTERNAL-DATE
                                      TO LSEGF-INV-CVG-CFN-EFF-DT
               MOVE L1640-INTERNAL-DATE
                                      TO LSEGF-CIA-FIA-EFF-DT
           ELSE
               MOVE '1'               TO WGLOB-RETURN-CODE
557660     END-IF.

       2350-EDATE-EDITS-X.
           EXIT.

018846*---------------------------
018846 2355-SIDE-FND-TST.
018846*---------------------------
018846
018846* WITHDRAW FROM SIDE FUND, NO FURTHER EDIT IS REQUIRED
018846
018846     IF  WCVGS-PLAN-FND-TYP-SIDE (L6330-CVG-NUM)
018846         GO TO 2355-SIDE-FND-TST-X
018846     END-IF.
018846
018846* WITHDRAW FROM REGULAR FUND, NEED TO CHECK SIDE FUND VALUE
018846
018846     PERFORM  0182-1000-BUILD-PARM-INFO
018846         THRU 0182-1000-BUILD-PARM-INFO-X.
018846     MOVE LSEGF-INV-CVG-CFN-EFF-DT    TO L0182-EFF-DT.
018846     SET L0182-SURR-CHRG-TYP-PARTL    TO TRUE.
018846     PERFORM  0182-1000-CALC-CSV-POL
018846         THRU 0182-1000-CALC-CSV-POL-X.
018846
018846     IF  L0182-SIDFND-AFV-AMT > ZERO
018846*MSG: WITHDRAWAL FROM NON-SIDE FUND COVERAGE.
018846*     SIDE FUND VALUE > 0.00
018846         MOVE 'SS00800054'             TO WGLOB-MSG-REF-INFO
018846         PERFORM  0260-1000-GENERATE-MESSAGE
018846             THRU 0260-1000-GENERATE-MESSAGE-X
018846     END-IF.
018846
018846 2355-SIDE-FND-TST-X.
018846     EXIT.
018846
018731*------------------
018731 2360-EFT-BNK-EDITS.
018731*------------------
018731
018731     IF  MIR-CIA-SRC-DEST-CD = 'C'
018731         IF  MIR-CLI-ID           NOT = SPACES
018731         OR  MIR-CLI-BNK-ACCT-NUM NOT = SPACES
018731*MSG: BANK DETAILS ARE ONLY VALID FOR EFT PAYOUTS
018731             MOVE 'SS00800052'       TO WGLOB-MSG-REF-INFO
018731             PERFORM  0260-1000-GENERATE-MESSAGE
018731                 THRU 0260-1000-GENERATE-MESSAGE-X
018731             MOVE SPACES             TO  MIR-CLI-ID
018731             MOVE SPACES             TO  MIR-CLI-BNK-ACCT-NUM
018731             MOVE '1'                TO  WGLOB-RETURN-CODE
018731         END-IF
018731         GO TO 2360-EFT-BNK-EDITS-X
018731     END-IF.
018731
018731     IF  MIR-CIA-SRC-DEST-CD = 'E'
018731         PERFORM  2365-EDIT-EFT-CLIENT
018731             THRU 2365-EDIT-EFT-CLIENT-X
018731         PERFORM  4382-1000-BUILD-PARM-INFO
018731             THRU 4382-1000-BUILD-PARM-INFO-X
018731         MOVE MIR-CLI-ID           TO  L4382-CLI-ID
018731         MOVE MIR-CLI-BNK-ACCT-NUM TO  L4382-CLI-BNK-ACCT-NUM
018731         PERFORM  4382-1000-EFT-EDITS
018731             THRU 4382-1000-EFT-EDITS-X
018731         IF  L4382-EDIT-ERROR
018731         OR  NOT L4382-RETRN-OK
018731             MOVE '1'             TO WGLOB-RETURN-CODE
018731         END-IF
018731     END-IF.
018731
018731 2360-EFT-BNK-EDITS-X.
018731     EXIT.
018731
018731*---------------------
018731 2365-EDIT-EFT-CLIENT.
018731*----------------------
018731**  EDIT TO MAKE SURE CLIENT ID IS NOT SPACES
018731     IF  MIR-CLI-ID = SPACES
018731*MSG: CLIENT ID MUST BE ENTERED FOR EFT PROCESSING
018731         MOVE 'SS00800053'      TO WGLOB-MSG-REF-INFO
018731         PERFORM  0260-1000-GENERATE-MESSAGE
018731             THRU 0260-1000-GENERATE-MESSAGE-X
018731         GO TO 2365-EDIT-EFT-CLIENT-X
018731     END-IF.
018731
018731     PERFORM  2430-1000-BUILD-PARM-INFO
018731         THRU 2430-1000-BUILD-PARM-INFO-X.
018731
018731     MOVE MIR-POL-ID                    TO L2430-POL-ID.
018731     MOVE MIR-CLI-ID                    TO L2430-CLI-ID.
018731
018731     PERFORM  2430-3300-GET-POL-CLI-REL
018731         THRU 2430-3300-GET-POL-CLI-REL-X.
018731
018731     IF  L2430-RETRN-CLI-NOT-FOUND
018731*MSG: EFT CLIENT DOES NOT BELONG TO THE POLICY
018731         MOVE 'SS00800055'  TO WGLOB-MSG-REF-INFO
018731         PERFORM  0260-1000-GENERATE-MESSAGE
018731             THRU 0260-1000-GENERATE-MESSAGE-X
018731         SET WGLOB-RETURN-ERROR TO TRUE
018731     END-IF.
018731
018731 2365-EDIT-EFT-CLIENT-X.
018731     EXIT.
018731
016108*---------------------
016108 2370-VAL-DATE-OF-DTH.
016108*---------------------
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE L6330-EFF-DATE        TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE '1'               TO WGLOB-RETURN-CODE
016108     END-IF.
016108
016108 2370-VAL-DATE-OF-DTH-X.
016108     EXIT.

      *------------
       2400-GET-FC.
      *------------

           MOVE L6330-CVG-NUM         TO I.
014591*    MOVE WCVGS-PLAN-ID-BASE (I) TO LSEGF-PLAN-ID-BASE.
014591*    MOVE WCVGS-PLAN-ID-RS (I)  TO LSEGF-PLAN-ID-RS.
014591     MOVE WCVGS-PLAN-ID (I)     TO LSEGF-PLAN-ID.
012146     MOVE WCVGS-CVG-UNIT-TYP-CD (I)
                                      TO LSEGF-CVG-UNIT-TYP-CD.
           MOVE SPACES                TO LSEGF-ALLOC-INFO.
           MOVE 'RI'                  TO LSEGF-INV-CVG-CFN-OPT-CD.
           PERFORM  0500-1000-PROCESS-FC-FS
               THRU 0500-1000-PROCESS-FC-FS-X.
      *
           IF  L0500-RETRN-ERROR
               MOVE '1'               TO WGLOB-RETURN-CODE
           ELSE
               MOVE LSEGF-INV-CVG-REC-INFO
                                      TO RFC-REC-INFO
               MOVE 1                 TO J
               PERFORM  8000-MOVE-FS-TO-WS
                   THRU 8000-MOVE-FS-TO-WS-X
                   VARYING I FROM 1 BY 1
                     UNTIL I > LSEGF-FND-CTR
               IF  J = 1
                   MOVE 'SS00800031'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
012696*            IF  MIR-ALLOC NOT = 'A'
012696*            AND MIR-ALLOC NOT = 'B'
014035             PERFORM  2405-ALLOC-TEST
014035                 THRU 2405-ALLOC-TEST-X
557660         END-IF
557660     END-IF.

       2400-GET-FC-X.
           EXIT.

014035*----------------
014035 2405-ALLOC-TEST.
014035*----------------
014035
012696     IF  NOT WS-BUS-FCN-PRORATE-FND-VALU
014035         COMPUTE LSEGF-FND-CTR = J - 1
014035     END-IF.
014035
014035 2405-ALLOC-TEST-X.
014035     EXIT.
014035
      *---------------------
       2500-GET-CASH-VALUES.
      *---------------------

           MOVE ZERO                  TO LSEGF-INV-CVG-CFN-SEQ-NUM.
           PERFORM  0410-1000-BUILD-PARM-INFO
               THRU 0410-1000-BUILD-PARM-INFO-X.
           SET L0410-WARNING-MSG-REQD TO TRUE.
016537*    PERFORM  0410-1000-SEG-FND-CV
016537*        THRU 0410-1000-SEG-FND-CV-X.
016537     PERFORM  0410-0100-SEG-FND-CV
016537         THRU 0410-0100-SEG-FND-CV-X.

           IF  L0410-RETRN-ERROR
               MOVE '1'               TO WGLOB-RETURN-CODE
           ELSE
               PERFORM  2520-MOVE-CASH-VALUES
                   THRU 2520-MOVE-CASH-VALUES-X
                   VARYING I FROM 1 BY 1
                   UNTIL I > LSEGF-FND-CTR
557660     END-IF.

       2500-GET-CASH-VALUES-X.
           EXIT.

      *----------------------
       2520-MOVE-CASH-VALUES.
      *----------------------

020464*    MOVE LSEGF-CFN-CV-AMT (I)  TO WS-FVAL-N (I).

020464     COMPUTE WS-FVAL-N (I)
020469*          = LSEGF-CFN-CV-AMT       (I)
020469           = LSEGF-CFN-FND-CRCY-CV-AMT (I)
020464           + LSEGF-CFN-DEFR-IN-AMT  (I)
020464           + LSEGF-CFN-DEFR-OUT-AMT (I).

020464     MOVE LSEGF-CFN-DEFR-IN-AMT  (I)
020464                                 TO WS-SCREEN-FS-DEFR-IN-N  (I).
020464     MOVE LSEGF-CFN-DEFR-OUT-AMT (I)
020464                                 TO WS-SCREEN-FS-DEFR-OUT-N (I).
           MOVE LSEGF-CFN-UNIT-QTY (I) TO L6330-FND-UNITS (I).

       2520-MOVE-CASH-VALUES-X.
           EXIT.

      *-------------------------
       2600-FORMAT-ATTR-PHASE-0.
      *-------------------------

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
           OR  WGLOB-RETURN-CODE NOT = ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
               MOVE 0                 TO FSUR-CALL-SW
               GO TO 2600-FORMAT-ATTR-PHASE-0-X
           END-IF.

012696*    IF  MIR-ALLOC = 'A'
012696*    OR  MIR-ALLOC = 'B'
012696     IF  WS-BUS-FCN-PRORATE-FND-VALU
               MOVE 1                 TO FSUR-CALL-SW
           ELSE
               MOVE 0                 TO FSUR-CALL-SW
557660     END-IF.

       2600-FORMAT-ATTR-PHASE-0-X.
           EXIT.

      *-------------------------
       2650-FORMAT-ATTR-PHASE-1.
      *-------------------------

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
               MOVE 0                 TO FSUR-CALL-SW
           ELSE
               MOVE 1                 TO FSUR-CALL-SW
557660     END-IF.

       2650-FORMAT-ATTR-PHASE-1-X.
           EXIT.

      *----------------------
       2800-EDIT-BOTTOM-DATA.
      *----------------------

           IF  WS-BUS-FCN-DOLLAR-AMT
               MOVE MIR-FIA-FND-TRXN-AMT-T (I)
                                      TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
008455*        MOVE 7                 TO L0280-LENGTH
               MOVE 2                 TO L0280-PRECISION
008455*        MOVE 10                TO L0280-INPUT-SIZE
008455         MOVE LENGTH OF MIR-FIA-FND-TRXN-AMT-T (I)
008455                                TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE  L0280-OUTPUT-DOLLAR
                                      TO WS-SAMT-N (I)
                   COMPUTE WS-CONTROL-TOTAL = WS-CONTROL-TOTAL +
                                              L0280-OUTPUT-DOLLAR
               ELSE
                   MOVE HIGH-VALUES   TO WS-SAMT (I)
                   MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  WS-BUS-FCN-PCT-AMT
               MOVE MIR-FIA-OUT-ALLOC-PCT-T (I)
                                      TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE 3                 TO L0280-LENGTH
               MOVE 4                 TO L0280-PRECISION
               MOVE 8                 TO L0280-INPUT-SIZE
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE  L0280-OUTPUT-V04
                                      TO WS-PALL-N (I)
                   COMPUTE WS-CONTROL-TOTAL = WS-CONTROL-TOTAL +
                                              WS-PALL-N (I)
               ELSE
                   MOVE HIGH-VALUES   TO WS-PALL (I)
                   MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  WS-BUS-FCN-PCT-FND-VALU
               MOVE MIR-FIA-VALU-SURR-PCT-T (I)
                                      TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE 3                 TO L0280-LENGTH
               MOVE 4                 TO L0280-PRECISION
               MOVE 8                 TO L0280-INPUT-SIZE
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  NOT L0280-OK
                   MOVE HIGH-VALUES   TO WS-PFUN (I)
                   MOVE 'CS00000032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE  L0280-OUTPUT-V04
                                      TO WS-PFUN-N (I)
014035             PERFORM  2801-PFUN-TEST
014035                 THRU 2801-PFUN-TEST-X
557660         END-IF
557660     END-IF.

           IF  WS-BUS-FCN-NUM-UNITS
               IF  MIR-FIA-SURR-UNIT-QTY-T (I) = SPACES
                   MOVE ZERO          TO L6330-FND-SURR-UNITS (I)
               ELSE
                   MOVE MIR-FIA-SURR-UNIT-QTY-T (I)
                                      TO L0280-INPUT-DATA
                   SET L0280-SIGN-NOT-PERMITTED TO TRUE
                   MOVE 9             TO L0280-LENGTH
                   MOVE 9             TO L0280-PRECISION
                   MOVE 19            TO L0280-INPUT-SIZE
                   PERFORM  0280-1000-NUMERIC-EDIT
                       THRU 0280-1000-NUMERIC-EDIT-X
014035             PERFORM  2802-L0280-TEST
014035                 THRU 2802-L0280-TEST-X
557660         END-IF
557660     END-IF.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
557660     END-IF.

014591*    MOVE LSEGF-PLAN-ID-BASE    TO WFR-PLAN-ID-BASE.
014591*    MOVE LSEGF-PLAN-ID-RS      TO WFR-PLAN-ID-RS.
014591     MOVE LSEGF-PLAN-ID         TO WFR-PLAN-ID.
           MOVE L6330-FND-CD (I)      TO WFR-FND-ID.
012135     PERFORM  2805-GET-LOC-GR
012135         THRU 2805-GET-LOC-GR-X.
012135     IF  NOT L3330-RETRN-OK
012135         GO TO 2800-EDIT-BOTTOM-DATA-X
012135     END-IF.
012135     MOVE RPOL-SBSDRY-CO-ID     TO WFR-SBSDRY-CO-ID.
012135     MOVE L3330-LOC-GR-ID       TO WFR-LOC-GR-ID.
           PERFORM  FR-1000-READ
               THRU FR-1000-READ-X.
           IF  NOT WFR-IO-OK
      *MSG:  NO RELATIONSHIP DEFINED FOR THIS FUND/PLAN
               MOVE 'SS00800010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-ERROR-SW NOT = ZERO
                   MOVE '1'           TO WGLOB-RETURN-CODE
               END-IF
               GO TO 2800-EDIT-BOTTOM-DATA-X
           END-IF.

           IF  RFR-PSUR-ALLOW-IND NOT = 'N'
               GO TO 2800-EDIT-BOTTOM-DATA-X
557660     END-IF.

           IF  WS-BUS-FCN-DOLLAR-AMT
           AND WS-SAMT-N (I) NOT = ZERO
               MOVE MIR-FND-ID-T (I)  TO WGLOB-MSG-PARM (1)
               MOVE 'SS00800001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF  WS-BUS-FCN-PCT-AMT
           AND WS-PALL-N (I) = ZERO
               MOVE MIR-FND-ID-T (I)  TO WGLOB-MSG-PARM (1)
               MOVE 'SS00800001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF  WS-BUS-FCN-PCT-TOT-VALU
           AND L6330-SURR-PCT = 100
               MOVE MIR-FND-ID-T (I)  TO WGLOB-MSG-PARM (1)
               MOVE 'SS00800001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF  WS-BUS-FCN-PCT-FND-VALU
           AND WS-PFUN-N (I) NOT = 100
               MOVE MIR-FND-ID-T (I)  TO WGLOB-MSG-PARM (1)
               MOVE 'SS00800001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF  WS-BUS-FCN-NUM-UNITS
           AND L6330-FND-SURR-UNITS (I) NOT = 0
      *MSG: PARTIAL SURRENDER INVALID FOR THIS FUND
               MOVE MIR-FND-ID-T (I)  TO WGLOB-MSG-PARM (1)
               MOVE 'SS00800001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
           END-IF.

       2800-EDIT-BOTTOM-DATA-X.
           EXIT.
014035
014035*---------------
014035 2801-PFUN-TEST.
014035*---------------
014035
014035     IF  WS-PFUN-N (I) > 100
014035         MOVE 'SS00800018'      TO WGLOB-MSG-REF-INFO
014035         PERFORM  0260-1000-GENERATE-MESSAGE
014035             THRU 0260-1000-GENERATE-MESSAGE-X
014035         MOVE LSEGF-FND-CTR     TO I
014035     ELSE
014035         COMPUTE WS-CONTROL-TOTAL = WS-CONTROL-TOTAL +
014035                                    L0280-OUTPUT-V04
014035     END-IF.
014035
014035 2801-PFUN-TEST-X.
014035     EXIT.
014035
014035*----------------
014035 2802-L0280-TEST.
014035*----------------
014035
014035     IF  NOT L0280-OK
014035         MOVE ZEROS             TO L6330-FND-SURR-UNITS (I)
014035* MSG: SURRENDER NUMBER OF UNITS MUST BE VALID NUMERIC
014035         MOVE 'SS00800034'      TO WGLOB-MSG-REF-INFO
014035         PERFORM  0260-1000-GENERATE-MESSAGE
014035             THRU 0260-1000-GENERATE-MESSAGE-X
014035     ELSE
014035         MOVE L0280-OUTPUT-V09
014035                                TO L6330-FND-SURR-UNITS (I)
014035         ADD L6330-FND-SURR-UNITS (I)
014035                                TO WS-CONTROL-UNITS
014035     END-IF.
014035
014035 2802-L0280-TEST-X.
014035     EXIT.

012135 2805-GET-LOC-GR.
012135
013578*    MOVE I                     TO J.
013578     MOVE I                     TO WS-HOLD-I.
012135     MOVE MIR-CVG-NUM           TO I.
012135
012135     PERFORM  3330-1000-BUILD-PARM-INFO
012135         THRU 3330-1000-BUILD-PARM-INFO-X.
012135
013578*    MOVE J                     TO I.
013578     MOVE WS-HOLD-I             TO I.
012135     SET L3330-LOC-GR-TYP-FDOPT  TO TRUE.
012135
012135     PERFORM  3330-1000-GET-LOC-GROUP
012135         THRU 3330-1000-GET-LOC-GROUP-X.
012135
012135     IF  L3330-RETRN-OK
012135         CONTINUE
012135     ELSE
012135* MSG: FUND (@1) LOCATION GROUP NOT FOUND
012135         MOVE L6330-FND-CD (I)  TO WGLOB-MSG-PARM (1)
012135         MOVE 'SS00800046'      TO WGLOB-MSG-REF-INFO
012135         PERFORM  0260-1000-GENERATE-MESSAGE
012135             THRU 0260-1000-GENERATE-MESSAGE-X
012135     END-IF.
012135
012135 2805-GET-LOC-GR-X.
012135     EXIT.
012135

      *-----------------
       2850-TOTAL-CHECK.
      *-----------------

           IF  WS-BUS-FCN-DOLLAR-AMT
               MOVE AMOUNT-HOLD-N     TO WS-AMOUNT
016571*        IF  MIR-CIA-REASN-CD = 'NET'
016571*            ADD LSEGF-INPUT-LOAD-AMT TO WS-AMOUNT
016571*        END-IF
               IF  WS-CONTROL-TOTAL NOT = WS-AMOUNT
                   MOVE 'SS00800025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  WS-BUS-FCN-PCT-AMT
               IF  WS-CONTROL-TOTAL NOT = 100.00
                   MOVE 'SS00800026'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  WS-BUS-FCN-DOLLAR-AMT
           OR  WS-BUS-FCN-PCT-AMT
           OR  WS-BUS-FCN-PCT-FND-VALU
               IF  WS-CONTROL-TOTAL NOT > ZERO
                   MOVE 'SS00800023'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  WS-BUS-FCN-PCT-FND-VALU
               COMPUTE WS-CONTROL-PCT = 100 * LSEGF-FND-CTR
               IF  WS-CONTROL-TOTAL = WS-CONTROL-PCT
                   MOVE 'SS00800006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF  WS-BUS-FCN-NUM-UNITS
           AND WS-CONTROL-UNITS = 0
      *MSG: PLEASE ENTER UNITS TO SURRENDER
               MOVE 'SS00800042'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2850-TOTAL-CHECK-X.
           EXIT.

      *---------------------
       2900-REFORMAT-SCREEN.
      *---------------------

           IF  I > LSEGF-FIA-REC-CTR
           OR  L6330-FND-CD (J) NOT = LSEGF-INPUT-FND-ID (I)
               IF  NOT WS-BUS-FCN-DOLLAR-AMT
                   MOVE ZERO          TO WS-SAMT-N (J)
                   GO TO 2900-REFORMAT-SCREEN-X
557660         END-IF
557660     END-IF.

           IF  I > LSEGF-FIA-REC-CTR
           OR  L6330-FND-CD (J) NOT = LSEGF-INPUT-FND-ID (I)
               IF  LSEGF-INPUT-ALLOC-IND = 'B'
557660         OR  LSEGF-INPUT-ALLOC-IND = 'C'
                   MOVE ZERO          TO WS-PALL-N (J)
                   GO TO 2900-REFORMAT-SCREEN-X
557660         END-IF
557660     END-IF.

           IF  I > LSEGF-FIA-REC-CTR
           OR  L6330-FND-CD (J) NOT = LSEGF-INPUT-FND-ID (I)
               IF  LSEGF-INPUT-ALLOC-IND = 'E'
                   MOVE ZERO          TO WS-PALL-N (J)
                   MOVE ZERO          TO WS-PFUN-N (J)
                   GO TO 2900-REFORMAT-SCREEN-X
557660         END-IF
557660     END-IF.

           MOVE LSEGF-FIA-REC-INFO (I) TO RFD-REC-INFO.
020469*    COMPUTE WS-CHARGE = WS-CHARGE + RFD-FIA-LOAD-AMT.
023091*    IF  RPOL-POL-MULT-CRCY
020469         COMPUTE WS-CHARGE = WS-CHARGE + RFD-FIA-ORIG-LOAD-AMT
023091*    ELSE
023091*        COMPUTE WS-CHARGE = WS-CHARGE + RFD-FIA-LOAD-AMT
023091*    END-IF.
           MOVE WS-CHARGE             TO L6330-SURR-CHRG.
           MOVE WS-CHARGE             TO CHARGE-HOLD-N.
008455*    MOVE CHARGE-HOLD       TO MIR-CIA-LOAD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-CHARGE * 100.
020874     MOVE WS-CHARGE             TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CIA-LOAD-AMT
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT

           COMPUTE RFD-FIA-FND-TRXN-AMT = -1.0 * RFD-FIA-FND-TRXN-AMT.

020469*    COMPUTE WS-GRS-SURR-TOTAL = WS-GRS-SURR-TOTAL
020469*                              + RFD-FIA-FND-TRXN-AMT.

023091*    IF  RPOL-POL-MULT-CRCY
020469         COMPUTE WS-GRS-SURR-TOTAL = WS-GRS-SURR-TOTAL
020469                                   + RFD-FIA-ORIG-TRXN-AMT
023091*    ELSE
023091*        COMPUTE WS-GRS-SURR-TOTAL = WS-GRS-SURR-TOTAL
023091*                                  + RFD-FIA-FND-TRXN-AMT
023091*    END-IF.

           IF  NOT WS-BUS-FCN-DOLLAR-AMT
020469*        MOVE RFD-FIA-FND-TRXN-AMT
020469*                               TO WS-SAMT-N (J)
023091*        IF  RPOL-POL-MULT-CRCY
020469             MOVE RFD-FIA-ORIG-TRXN-AMT
020469                                TO WS-SAMT-N (J)
023091*        ELSE
023091*            MOVE RFD-FIA-FND-TRXN-AMT
023091*                               TO WS-SAMT-N (J)
023091*        END-IF
557660     END-IF.

           IF  LSEGF-INPUT-ALLOC-IND = 'B'
557660     OR  LSEGF-INPUT-ALLOC-IND = 'C'
020469*        COMPUTE WS-NUM-PC ROUNDED
020469*            = RFD-FIA-FND-TRXN-AMT / WS-AMOUNT * 100.0000

023091*        IF  RPOL-POL-MULT-CRCY
020469             COMPUTE WS-NUM-PC ROUNDED
020469             = RFD-FIA-ORIG-TRXN-AMT / WS-AMOUNT * 100.0000
023091*        ELSE
023091*            COMPUTE WS-NUM-PC ROUNDED
023091*            = RFD-FIA-FND-TRXN-AMT / WS-AMOUNT * 100.0000
023091*        END-IF

               MOVE WS-NUM-PC         TO WS-PALL-N (J)
031240         COMPUTE  WS-NUM-PC = WS-NUM-PC * -1
               COMPUTE WS-CONTROL-TOTAL
                   = WS-CONTROL-TOTAL + WS-NUM-PC
557660     END-IF.

           IF  LSEGF-INPUT-ALLOC-IND = 'E'
               MOVE ZERO              TO WS-PALL-N (J)
               MOVE LSEGF-INPUT-ALLOC-AMT (I)
                                      TO WS-NUM-PC
               MOVE WS-NUM-PC         TO WS-PFUN-N (J)
557660     END-IF.

014591*    MOVE LSEGF-PLAN-ID-BASE    TO WFR-PLAN-ID-BASE.
014591*    MOVE LSEGF-PLAN-ID-RS      TO WFR-PLAN-ID-RS.
014591     MOVE LSEGF-PLAN-ID         TO WFR-PLAN-ID.
           MOVE RFD-FND-ID            TO WFR-FND-ID.
012135
012135     PERFORM  2805-GET-LOC-GR
012135         THRU 2805-GET-LOC-GR-X.
012135
012135     IF  NOT L3330-RETRN-OK
012135         GO TO 2900-REFORMAT-SCREEN-X
012135     END-IF.
012135
012135     MOVE RPOL-SBSDRY-CO-ID     TO WFR-SBSDRY-CO-ID.
012135     MOVE L3330-LOC-GR-ID       TO WFR-LOC-GR-ID.
012135
           PERFORM  FR-1000-READ
               THRU FR-1000-READ-X.
           IF  WFR-IO-OK
011235         AND WS-SAMT-N (J) NOT = ZERO
               MOVE WS-SAMT-N (J)     TO WS-AMT-SUR-FUND
               COMPUTE WS-AMT-SUR-FUND
                   = WS-AMT-SUR-FUND + RFR-MIN-REMN-AMT
               MOVE WS-FVAL-N (J)     TO WS-CV-FUND
               IF  WS-AMT-SUR-FUND > WS-CV-FUND
                   MOVE 'SS00800035'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           ADD 1 TO I.

       2900-REFORMAT-SCREEN-X.
           EXIT.

016408*----------------------
016408 2910-CALC-SURR-TOTAL.
016408*----------------------
016408
016408     IF  I > LSEGF-FIA-REC-CTR
016408     OR  L6330-FND-CD (J) NOT = LSEGF-INPUT-FND-ID (I)
016408         IF  NOT WS-BUS-FCN-DOLLAR-AMT
016408             GO TO 2910-CALC-SURR-TOTAL-X
016408         END-IF
016408     END-IF.
016408
016408     IF  I > LSEGF-FIA-REC-CTR
016408     OR  L6330-FND-CD (J) NOT = LSEGF-INPUT-FND-ID (I)
016408         IF  LSEGF-INPUT-ALLOC-IND = 'B'
016408         OR  LSEGF-INPUT-ALLOC-IND = 'C'
016408             GO TO 2910-CALC-SURR-TOTAL-X
016408         END-IF
016408     END-IF.
016408
016408     IF  I > LSEGF-FIA-REC-CTR
016408     OR  L6330-FND-CD (J) NOT = LSEGF-INPUT-FND-ID (I)
016408         IF  LSEGF-INPUT-ALLOC-IND = 'E'
016408             GO TO 2910-CALC-SURR-TOTAL-X
016408         END-IF
016408     END-IF.
016408
016408     MOVE LSEGF-FIA-REC-INFO (I) TO RFD-REC-INFO.
016408
016408     COMPUTE RFD-FIA-FND-TRXN-AMT = -1.0 * RFD-FIA-FND-TRXN-AMT.
016408
020469*    COMPUTE WS-SURR-TOTAL = WS-SURR-TOTAL
020469*                              + RFD-FIA-FND-TRXN-AMT.

023091*    IF  RPOL-POL-MULT-CRCY
020469         COMPUTE WS-SURR-TOTAL = WS-SURR-TOTAL
020469                               + RFD-FIA-ORIG-TRXN-AMT
023091*    ELSE
023091*        COMPUTE WS-SURR-TOTAL = WS-SURR-TOTAL
023091*                              + RFD-FIA-FND-TRXN-AMT
023091*    END-IF.

016408     ADD 1 TO I.
016408
016408 2910-CALC-SURR-TOTAL-X.
016408     EXIT.


      *-----------------
       2925-CHECK-TOTAL.
      *-----------------

           IF  MIR-CIA-REASN-CD = 'NET'
               GO TO 2925-CHECK-TOTAL-X
           END-IF.

           IF  WS-BUS-FCN-DOLLAR-AMT
               IF  WS-CONTROL-TOTAL NOT = 100.0000
                   MOVE 0             TO J
                   PERFORM  2950-FIND-FIRST-FUND
                       THRU 2950-FIND-FIRST-FUND-X
                       VARYING I FROM 1 BY 1
012141*                UNTIL I > 15
012141                 UNTIL I > WFNDM-MAX-WFUND-NUM
                       OR J NOT = 0
                   COMPUTE WS-NUM-PC
                       = WS-PALL-N (J)
031240*                - WS-CONTROL-TOTAL + 100.0000
031240                 - (100.0000 - WS-CONTROL-TOTAL)
                   MOVE WS-NUM-PC TO WS-PALL-N (J)
557660         END-IF
557660     END-IF.

       2925-CHECK-TOTAL-X.
           EXIT.

      *---------------------
       2950-FIND-FIRST-FUND.
      *---------------------

           IF  LSEGF-INPUT-FND-ID (1) = L6330-FND-CD (I)
               MOVE I TO J
557660     END-IF.

       2950-FIND-FIRST-FUND-X.
           EXIT.

      *---------------------
       3000-FORMAT-TOP-LINE.
      *---------------------

           IF  RESET-SCREEN
               PERFORM  8500-RESET-DEFAULTS
                   THRU 8500-RESET-DEFAULTS-X
               MOVE 0                 TO RESET-SW
               GO TO 3000-FORMAT-TOP-LINE-X
557660     END-IF.

           IF  NOT WS-BUS-FCN-PCT-TOT-VALU
               MOVE '000.0000'        TO MIR-FIA-VALU-SURR-PCT
           END-IF.

020469     MOVE RPOL-POL-CRCY-CD      TO WS-POL-CRCY-CD.

       3000-FORMAT-TOP-LINE-X.
           EXIT.

      *-----------------------
       3100-MOVE-WS-TO-SCREEN.
      *-----------------------

           IF  L6330-FND-CD (I) = SPACES
               GO TO 3100-MOVE-WS-TO-SCREEN-X
557660     END-IF.

012696*    MOVE WS-FNUM (I)           TO MIR-FNUM-T (I).
           MOVE L6330-FND-CD (I)      TO MIR-FND-ID-T (I).

008455*    MOVE WS-FVAL-N (I)         TO DISP-SCR-11V2.
008455*    MOVE DISP-SCR-11V2         TO MIR-DV-CFN-APROX-AMT-T (I).
020874*    COMPUTE L0290-INPUT-NUMBER = WS-FVAL-N (I) * 100.
020874     MOVE WS-FVAL-N (I)         TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CFN-APROX-AMT-T (I).

020464*    MOVE LSEGF-CFN-POL-CRCY-CV-AMT (I)
020464*                               TO L0290-INPUT-V02.
020464     COMPUTE  L0290-INPUT-V02
020464           =  LSEGF-CFN-POL-CRCY-CV-AMT  (I)
020464           +  LSEGF-CFN-POL-DEFR-IN-AMT  (I)
020464           +  LSEGF-CFN-POL-DEFR-OUT-AMT (I).
020469
020469     MOVE 2                     TO L0290-PRECISION.
020469     MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020469     PERFORM 0290-2000-FORMAT-FOR-MIR
020469        THRU 0290-2000-FORMAT-FOR-MIR-X.
020469     MOVE L0290-OUTPUT-DATA     TO MIR-DV-FIA-POL-CRCY-AMT-T (I).
023444
023444     MOVE L6330-TAX-ACB-AMT     TO L0290-INPUT-V02.
023444     MOVE 2                     TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
023444                                TO L0290-MAX-OUT-LEN.
023444     PERFORM 0290-2000-FORMAT-FOR-MIR
023444        THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-TAX-ACB-AMT.
023444
023444     IF  WS-BUS-FCN-PCT-TOT-VALU
023444     OR  WS-BUS-FCN-PCT-FND-VALU
023444     OR  WS-BUS-FCN-NUM-UNITS
023444         IF  WS-SURR-TOTAL < ZERO
023444             COMPUTE WS-TRMN-AMT = (WS-SURR-TOTAL * -1)
023444         ELSE
023444             COMPUTE WS-TRMN-AMT = WS-SURR-TOTAL
023444         END-IF
023444     ELSE
023444         COMPUTE WS-TRMN-AMT = L6330-SURR-AMOUNT
023444     END-IF.
023444
023444     IF  MIR-CIA-REASN-CD = 'GRS'
023444         COMPUTE WS-TRMN-AMT = WS-TRMN-AMT
023444                             - WS-CHARGE
023444     END-IF.
023444
023444     MOVE WS-TRMN-AMT           TO L0290-INPUT-V02.
023444     MOVE 2                     TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
023444                                TO L0290-MAX-OUT-LEN.
023444     PERFORM 0290-2000-FORMAT-FOR-MIR
023444        THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA     TO MIR-DV-GRS-DSTRB-AMT.
023444
023444     MOVE L6330-TAXBL-PORTN-AMT TO L0290-INPUT-V02.
023444     MOVE 2                     TO L0290-PRECISION.
023444     MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
023444                                TO L0290-MAX-OUT-LEN.
023444     PERFORM 0290-2000-FORMAT-FOR-MIR
023444        THRU 0290-2000-FORMAT-FOR-MIR-X.
023444     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TAXBL-GRS-DSTRB-AMT.
023444
           IF  NOT WS-BUS-FCN-NUM-UNITS
               PERFORM  3110-MOVE-WS-TO-SCRN2
                   THRU 3110-MOVE-WS-TO-SCRN2-X
           ELSE
               PERFORM  3120-MOVE-WS-TO-SCRN3
                   THRU 3120-MOVE-WS-TO-SCRN3-X
557660     END-IF.

020469*    RETRIEVE THE FUNDS CURRENCY CODE

020469     PERFORM  8640-1000-BUILD-PARM-INFO
020469         THRU 8640-1000-BUILD-PARM-INFO-X.

020469     MOVE L6330-FND-CD (I)      TO L8640-FND-ID.

020469     PERFORM  8640-1000-GET-FND-CRCY-CD
020469         THRU 8640-1000-GET-FND-CRCY-CD-X.

020469     IF L8640-RETRN-OK
020469         MOVE L8640-FND-CRCY-CD TO MIR-FIA-CRCY-CD-T (I)
020469     ELSE
020469         MOVE SPACES            TO MIR-FIA-CRCY-CD-T (I)
020469     END-IF.

020469     MOVE WS-POL-CRCY-CD        TO MIR-POL-CRCY-CD-T (I).

       3100-MOVE-WS-TO-SCREEN-X.
           EXIT.

      *----------------------
       3110-MOVE-WS-TO-SCRN2.
      *----------------------

           IF  WS-SAMT (I) = HIGH-VALUES
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
008455*        MOVE WS-SAMT-N (I)     TO DISP-SCR-7V2
008455*        MOVE DISP-SCR-7V2      TO MIR-FIA-FND-TRXN-AMT-T (I)
020874*        COMPUTE L0290-INPUT-NUMBER = WS-SAMT-N (I) * 100
020874         MOVE WS-SAMT-N (I)     TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-FIA-FND-TRXN-AMT-T (I)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-FIA-FND-TRXN-AMT-T (I)
557660     END-IF.

           IF  WS-PALL (I) = HIGH-VALUES
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
020469*        MOVE WS-PALL-N (I)     TO DISP-SCR-3V4
020874*        MOVE DISP-SCR-3V4      TO MIR-FIA-OUT-ALLOC-PCT-T (I)
020874         MOVE WS-PALL-N (I)         TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (I)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (I)
557660     END-IF.

           IF  WS-PFUN (I) = HIGH-VALUES
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
020469*        MOVE WS-PFUN-N (I)     TO DISP-SCR-3V4
020874*        MOVE DISP-SCR-3V4      TO MIR-FIA-VALU-SURR-PCT-T (I)
020874         MOVE WS-PFUN-N (I)         TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (I)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-FIA-VALU-SURR-PCT-T (I)
557660     END-IF.

       3110-MOVE-WS-TO-SCRN2-X.
           EXIT.

      *----------------------
       3120-MOVE-WS-TO-SCRN3.
      *----------------------

           MOVE L6330-FND-CD (I)      TO WFH-FND-ID.
           PERFORM  FH-1000-READ
               THRU FH-1000-READ-X.
           IF  NOT WFH-IO-OK
021239*        MOVE +9                TO RFH-FND-UNIT-ACCUR-QTY
021239         MOVE +6                TO RFH-FND-UNIT-ACCUR-QTY
557660     END-IF.

021239*    MOVE L6330-FND-UNITS (I)   TO FORMAT-9V9.
021239     PERFORM  7721-0000-INIT-PARM-INFO
021239         THRU 7721-0000-INIT-PARM-INFO-X.
021239
021239     MOVE L6330-FND-UNITS (I)   TO L7721-ABS-IN-INTG.
021239     MOVE L6330-FND-UNITS (I)   TO L7721-ABS-IN-DCML.

           PERFORM  3130-SET-DECIMALS
               THRU 3130-SET-DECIMALS-X.

021239     COMPUTE WS-FND-UNIT-QTY    =  L7721-ABS-RND-INTG
021239                                +  L7721-ABS-RND-DCML.

021239*    MOVE DISP-SCR-9V9          TO MIR-CFN-INTG-AUNIT-QTY-T (I).

021239     MOVE WS-FND-UNIT-QTY       TO MIR-FIA-UNIT-CUM-QTY-T (I).


021239*    MOVE L6330-FND-SURR-UNITS (I)
021239*                               TO FORMAT-9V9.

021239     PERFORM  7721-0000-INIT-PARM-INFO
021239         THRU 7721-0000-INIT-PARM-INFO-X.
021239
021239     MOVE L6330-FND-SURR-UNITS (I)   TO L7721-ABS-IN-INTG.
021239     MOVE L6330-FND-SURR-UNITS (I)   TO L7721-ABS-IN-DCML.

           PERFORM  3130-SET-DECIMALS
               THRU 3130-SET-DECIMALS-X.

021239     COMPUTE WS-FND-UNIT-QTY    =  L7721-ABS-RND-INTG
021239                                +  L7721-ABS-RND-DCML.

021239*    MOVE DISP-SCR-9V9          TO MIR-FIA-SURR-UNIT-QTY-T (I).

021239     MOVE WS-FND-UNIT-QTY       TO MIR-FIA-SURR-UNIT-QTY-T (I).

       3120-MOVE-WS-TO-SCRN3-X.
           EXIT.

       3130-SET-DECIMALS.

021239     MOVE RFH-FND-UNIT-ACCUR-QTY
021239                                TO L7721-ACCUR-QTY.

021239     SET L7721-RND-DOWN         TO TRUE.

021239     PERFORM  7721-1000-NUMERIC-ROUND
021239         THRU 7721-1000-NUMERIC-ROUND-X.


021239*    EVALUATE RFH-FND-UNIT-ACCUR-QTY

021239*    WHEN 9
021239*        MOVE FORMAT-9V9        TO DISP-SCR-9V9

021239*    WHEN 8
021239*        MOVE FORMAT-9V8        TO DISP-SCR-9V9

021239*    WHEN 7
021239*        MOVE FORMAT-9V7        TO DISP-SCR-9V9

021239*    WHEN 6
021239*        MOVE FORMAT-9V6        TO DISP-SCR-9V9

021239*    WHEN 5
021239*        MOVE FORMAT-9V5        TO DISP-SCR-9V9

021239*    WHEN 4
021239*        MOVE FORMAT-9V4        TO DISP-SCR-9V9

021239*    WHEN 3
021239*        MOVE FORMAT-9V3        TO DISP-SCR-9V9

021239*    WHEN 2
021239*        MOVE FORMAT-9V2        TO DISP-SCR-9V9

021239*    WHEN 1
021239*        MOVE FORMAT-9V1        TO DISP-SCR-9V9

021239*    WHEN OTHER
021239*        MOVE FORMAT-9V0        TO DISP-SCR-9V9

021239*    END-EVALUATE.

       3130-SET-DECIMALS-X.
           EXIT.

031034*----------------------------
031034*4675-WRITE-PGAL-REC.
031034*----------------------------
031034*
031034*    MOVE MIR-POL-ID              TO L7800-POL-ID.
031034*    MOVE LSEGF-CIA-FIA-EFF-DT    TO L7800-EFF-DT.
031034*    MOVE WS-CDA-TYP-CD           TO L7800-CDA-TYP-CD.
031034*    MOVE WS-POL-PAYO-NUM         TO L7800-POL-PAYO-NUM.
031034*    MOVE WS-CDA-EFF-IDT-NUM TO L7800-CDA-EFF-IDT-NUM.
031034*    MOVE WS-CDA-SEQ-NUM          TO L7800-CDA-SEQ-NUM.
031034*    MOVE L0182-CV-TAX            TO L7800-CV-TAX.
031034*    COMPUTE L7800-TOT-SURR-AMT = RFA-CIA-CLI-TRXN-AMT
031034*                                  * -1.
031034*    COMPUTE L7800-SURR-CHRG-AMT = RFA-CIA-LOAD-AMT.
031034*    SET L7800-CALC-CV-NOT-REQ    TO TRUE
031034*    SET L7800-ORIGIN-POL-ENTRY   TO TRUE.
031034*    SET L7800-TRXN-WTHDR         TO TRUE.
031034*    SET L7800-PRCES-NORMAL       TO TRUE.
031034*
031034*    PERFORM  7700-HOLD-TO-L7800
031034*        THRU 7700-HOLD-TO-L7800-X.
031034*
031034*    PERFORM  7800-3000-DISB-TRXN-AMT
031034*        THRU 7800-3000-DISB-TRXN-AMT-X.
031034*
031034*    IF NOT L7800-RETRN-OK
031034*       SET WGLOB-RETURN-ERROR        TO TRUE
031034*       GO TO 4675-WRITE-PGAL-REC-X
031034*    END-IF.
031034*
031034*    PERFORM  7800-4000-PGAL-PRCES
031034*        THRU 7800-4000-PGAL-PRCES-X.
031034*
031034*    IF NOT L7800-RETRN-OK
031034*       SET WGLOB-RETURN-ERROR        TO TRUE
031034*    END-IF.
031034*
031034*4675-WRITE-PGAL-REC-X.
031034*    EXIT.
031034*

031034*----------------------------
031034*4800-GET-PGAL-INFO.
031034*----------------------------
031034*
031034*    PERFORM  0182-1000-BUILD-PARM-INFO
031034*        THRU 0182-1000-BUILD-PARM-INFO-X.
031034*    MOVE LSEGF-INV-CVG-CFN-EFF-DT    TO L0182-EFF-DT.
031034*    SET L0182-SURR-CHRG-TYP-PARTL    TO TRUE.
031034*    PERFORM  0182-1000-CALC-CSV-POL
031034*        THRU 0182-1000-CALC-CSV-POL-X.
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE MIR-POL-ID              TO L7800-POL-ID.
031034*    MOVE LSEGF-INV-CVG-CFN-EFF-DT  TO L7800-EFF-DT.
031034*    MOVE L0182-CV-TAX            TO L7800-CV-TAX.
031034*    SET L7800-TRXN-WTHDR         TO TRUE.
031034*    SET L7800-GET-PLAR-REQ       TO TRUE.
031034*    SET L7800-CALC-CV-NOT-REQ    TO TRUE.
031034*    SET L7800-PRCES-NORMAL       TO TRUE.
031034*
031034*    PERFORM  7800-5000-PGAL-OPEN-BAL
031034*        THRU 7800-5000-PGAL-OPEN-BAL-X.
031034*
031034*    IF NOT L7800-RETRN-OK
031034*       SET WGLOB-RETURN-ERROR     TO TRUE
031034*    END-IF.
031034*
031034*    PERFORM  7500-L7800-TO-LPGAL
031034*        THRU 7500-L7800-TO-LPGAL-X.
031034*
031034*    PERFORM  7600-L7800-TO-HOLD
031034*        THRU 7600-L7800-TO-HOLD-X.
031034*
031034*4800-GET-PGAL-INFO-X.
031034*    EXIT.
015290
023437*----------------------
023437 5000-EDIT-LTAXWH-RQST.
023437*----------------------
023437*
029060*    IF MIR-LTAXWH-CALC-CD = SPACES
029060*    OR MIR-LTAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
029060*        MOVE 'C'               TO MIR-LTAXWH-CALC-CD
029060*    END-IF.
029060
029060     IF  MIR-LTAXWH-RQST-CD = SPACES
029060     OR  MIR-LTAXWH-RQST-CD = EBLCH-BLANK-FIELD-CHAR
029060         MOVE 'C'               TO MIR-LTAXWH-RQST-CD
029060     END-IF.
029060
029060*    IF MIR-LTAXWH-CALC-CD = 'S'
029060*    OR MIR-LTAXWH-CALC-CD = 'C'
029060*    OR MIR-LTAXWH-CALC-CD = 'B'
029060
029060     IF MIR-LTAXWH-RQST-CD = 'S'
029060     OR MIR-LTAXWH-RQST-CD = 'C'
029060     OR MIR-LTAXWH-RQST-CD = 'B'
023437        CONTINUE
023437     ELSE
023437* MESSAGE - LOCATION TAX OVERRIDE MUST CONTAIN VALUES 'C' OR 'S'
023437         MOVE 'SS00800061'      TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR       TO TRUE
023437     END-IF.
023437*
029060*    IF MIR-LTAXWH-PCT = SPACES
029060*        MOVE ZERO                  TO MIR-LTAXWH-PCT
029060*    END-IF.
029060
029060     IF  MIR-LTAXWH-RQST-PCT = SPACES
029060         MOVE ZERO                  TO MIR-LTAXWH-RQST-PCT
029060     END-IF.
029060
023437*
029060*    MOVE MIR-LTAXWH-PCT            TO L0280-INPUT-DATA.
029060     MOVE MIR-LTAXWH-RQST-PCT       TO L0280-INPUT-DATA.
023437     SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
023437     MOVE 4                         TO L0280-LENGTH.
023437     MOVE 2                         TO L0280-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                    TO L0280-INPUT-SIZE.
023437     PERFORM  0280-1000-NUMERIC-EDIT
023437         THRU 0280-1000-NUMERIC-EDIT-X.
023437     IF L0280-OK
023437         MOVE L0280-OUTPUT-V02      TO WS-LOC-RQST-PCT
023437         MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
023437         MOVE  2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                    TO L0290-MAX-OUT-LEN
023437         PERFORM 0290-2000-FORMAT-FOR-MIR
023437            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-PCT
029060         MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-RQST-PCT
023437         IF WS-LOC-RQST-PCT > 100
023437         OR WS-LOC-RQST-PCT < ZERO
023437* MESSAGE - INVALID LOCATION TAX %
023437             MOVE 'SS00800062'      TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR       TO TRUE
023437         END-IF
023437     ELSE
023437* MESSAGE - INVALID LOCATION TAX % - REENTER
023437         MOVE 'SS00800063'          TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR       TO TRUE
023437     END-IF.
023437*
029060*    IF MIR-LTAXWH-FLAT-AMT = SPACES
029060*        MOVE ZERO                  TO MIR-LTAXWH-FLAT-AMT
029060*    END-IF.
029060
029060     IF  MIR-LTAXWH-RQST-AMT = SPACES
029060         MOVE ZERO                  TO MIR-LTAXWH-RQST-AMT
029060     END-IF.
029060
029060*    MOVE MIR-LTAXWH-FLAT-AMT       TO L0280-INPUT-DATA.
029060     MOVE MIR-LTAXWH-RQST-AMT       TO L0280-INPUT-DATA.
023437     SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
023437     MOVE 13                        TO L0280-LENGTH.
023437     MOVE 2                         TO L0280-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                   TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                    TO L0280-INPUT-SIZE.
023437     PERFORM  0280-1000-NUMERIC-EDIT
023437         THRU 0280-1000-NUMERIC-EDIT-X.
023437*
023437     IF L0280-OK
023437         MOVE L0280-OUTPUT-V02      TO WS-LOC-RQST-AMT
023437         MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
023437         MOVE 2                     TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                   TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                    TO L0290-MAX-OUT-LEN
023437         PERFORM 0290-2000-FORMAT-FOR-MIR
023437            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA TO MIR-LTAXWH-FLAT-AMT
029060         MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-RQST-AMT
023437     ELSE
023437* MESSAGE - INVALID LOCATION TAX WITHHELD AMOUNT
023437         MOVE 'SS00800064'          TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR       TO TRUE
023437     END-IF.
023437
023437     PERFORM  5010-EDIT-LTAXWH-CALC-CD
023437         THRU 5010-EDIT-LTAXWH-CALC-CD-X.
023437
029060*    MOVE MIR-LTAXWH-CALC-CD        TO L6330-LTAXWH-CALC-CD.
029060*    MOVE WS-LOC-RQST-PCT           TO L6330-LTAXWH-PCT.
029060*    MOVE WS-LOC-RQST-AMT           TO L6330-LTAXWH-FLAT-AMT.
023437
023437 5000-EDIT-LTAXWH-RQST-X.
023437     EXIT.
023437
023437*-------------------------
023437 5010-EDIT-LTAXWH-CALC-CD.
023437*-------------------------
023437
029060*    IF MIR-LTAXWH-CALC-CD NOT = 'S'
029060*    AND (WS-LOC-RQST-PCT > ZERO
029060*    OR  WS-LOC-RQST-AMT > ZERO)
029060*       MOVE 'SS00800071'      TO WGLOB-MSG-REF-INFO
029060*MSG: LOCATION TAX WITHHOLDING PROCESS OPTION IS NOT SPECIFIED
029060*     REQUEST AMOUNTS CANNOT BE ENTERED
029060*       PERFORM  0260-1000-GENERATE-MESSAGE
029060*           THRU 0260-1000-GENERATE-MESSAGE-X
029060*       IF  WGLOB-MSG-SEVRTY-FATAL
029060*           SET WGLOB-RETURN-ERROR  TO TRUE
029060*       END-IF
029060*    END-IF.
029060
029060     IF  MIR-LTAXWH-RQST-CD NOT = 'S'
029060         IF  WS-LOC-RQST-PCT > ZERO
029060         OR  WS-LOC-RQST-AMT > ZERO
029060             MOVE 'SS00800071'  TO WGLOB-MSG-REF-INFO
029060*MSG: LOCATION TAX WITHHOLDING PROCESS OPTION IS NOT SPECIFIED
029060*     REQUEST AMOUNTS CANNOT BE ENTERED
029060             PERFORM  0260-1000-GENERATE-MESSAGE
029060                 THRU 0260-1000-GENERATE-MESSAGE-X
029060         END-IF
029060     END-IF.
029060
029060     IF  WGLOB-MSG-SEVRTY-FATAL
029060         SET WGLOB-RETURN-ERROR TO TRUE
029060     END-IF.
023437
029060*    IF MIR-LTAXWH-CALC-CD = 'S'
029060
029060     IF  MIR-LTAXWH-RQST-CD = 'S'
023437     AND WS-LOC-RQST-PCT > ZERO
023437     AND WS-LOC-RQST-AMT > ZERO
023437        MOVE 'SS00800072'      TO WGLOB-MSG-REF-INFO
023437*MSG: CANNOT ENTER BOTH LOCATION TAX REQUEST AMOUNT AND LOCATION
023437*     TAX REQUEST PERCENT
023437        PERFORM  0260-1000-GENERATE-MESSAGE
023437            THRU 0260-1000-GENERATE-MESSAGE-X
023437        IF  WGLOB-MSG-SEVRTY-FATAL
023437            SET WGLOB-RETURN-ERROR  TO TRUE
023437        END-IF
023437     END-IF.
023437
029060*    IF MIR-LTAXWH-CALC-CD = 'S'
029060
029060     IF  MIR-LTAXWH-RQST-CD = 'S'
023437     AND WS-LOC-RQST-PCT NOT > ZERO
023437     AND WS-LOC-RQST-AMT NOT > ZERO
023437        MOVE 'SS00800073'      TO WGLOB-MSG-REF-INFO
023437*MSG: LOCATION TAX WITHHOLDING REQUEST PERCENT OR AMOUNT SHOULD BE
023437*     ENTERED
023437        PERFORM  0260-1000-GENERATE-MESSAGE
023437            THRU 0260-1000-GENERATE-MESSAGE-X
023437        IF  WGLOB-MSG-SEVRTY-FATAL
023437            SET WGLOB-RETURN-ERROR  TO TRUE
023437        END-IF
023437     END-IF.
023437
023437     IF WS-LOC-RQST-PCT < ZERO
023437     OR WS-LOC-RQST-AMT < ZERO
023437        MOVE 'SS00800074'      TO WGLOB-MSG-REF-INFO
023437*MSG: LOCATION TAX WITHHOLDING REQUEST MUST NOT BE NEGATIVE
023437        PERFORM  0260-1000-GENERATE-MESSAGE
023437            THRU 0260-1000-GENERATE-MESSAGE-X
023437        IF  WGLOB-MSG-SEVRTY-FATAL
023437            SET WGLOB-RETURN-ERROR  TO TRUE
023437        END-IF
023437     END-IF.
023437
023437 5010-EDIT-LTAXWH-CALC-CD-X.
023437     EXIT.
023437
023437*---------------------
023437 5100-EDIT-TAXWH-RQST.
023437*---------------------
023437*
029060*    MOVE MIR-FED-TAXWH-CALC-CD      TO WS-FED-TAXWH-CALC-CD.
029060     MOVE MIR-FTAXWH-RQST-CD         TO WS-FED-TAXWH-CALC-CD.
023437
023437     IF WS-FED-TAXWH-CALC-VALID
023437         CONTINUE
023437     ELSE
023437* MESSAGE - FEDERAL TAX CALC OPTION MUST CONTAIN
023437*           VALUES 'B', 'C' OR 'S'
023437         MOVE 'SS00800066'           TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR      TO TRUE
023437     END-IF.
023437
029060*    IF MIR-FED-TAXWH-RQST-AMT = SPACES
029060*        MOVE ZERO                   TO MIR-FED-TAXWH-RQST-AMT
029060*    END-IF.
029060
029060     IF  MIR-FTAXWH-RQST-AMT = SPACES
029060         MOVE ZERO                   TO MIR-FTAXWH-RQST-AMT
029060     END-IF.
023437
029060*    MOVE MIR-FED-TAXWH-RQST-AMT     TO L0280-INPUT-DATA.
029060     MOVE MIR-FTAXWH-RQST-AMT        TO L0280-INPUT-DATA.
023437     SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
023437     MOVE 13                         TO L0280-LENGTH.
023437     MOVE 2                          TO L0280-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                    TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                     TO L0280-INPUT-SIZE.
023437     PERFORM  0280-1000-NUMERIC-EDIT
023437         THRU 0280-1000-NUMERIC-EDIT-X.
023437
023437     IF L0280-OK
023437         MOVE L0280-OUTPUT-V02       TO WS-FED-TAXWH-RQST-AMT
023437         MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
023437         MOVE  2                     TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                    TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                     TO L0290-MAX-OUT-LEN
023437         PERFORM 0290-2000-FORMAT-FOR-MIR
023437            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA      TO MIR-FED-TAXWH-RQST-AMT
029060         MOVE L0290-OUTPUT-DATA      TO MIR-FTAXWH-RQST-AMT
023437     ELSE
023437* MESSAGE - INVALID FEDERAL TAX REQUEST AMOUNT
023437         MOVE 'SS00800067'           TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR      TO TRUE
023437     END-IF.
023437
029060*    IF MIR-FED-TAXWH-RQST-PCT = SPACES
029060*        MOVE ZERO                   TO MIR-FED-TAXWH-RQST-PCT
029060*    END-IF.
029060
029060     IF  MIR-FTAXWH-RQST-PCT = SPACES
029060         MOVE ZERO                   TO MIR-FTAXWH-RQST-PCT
029060     END-IF.
023437
029060*    MOVE MIR-FED-TAXWH-RQST-PCT     TO L0280-INPUT-DATA.
029060     MOVE MIR-FTAXWH-RQST-PCT        TO L0280-INPUT-DATA.
023437     SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                    TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                     TO L0280-INPUT-SIZE.
023437     MOVE L0280-INPUT-SIZE           TO L0280-LENGTH.
023437     MOVE 2                          TO L0280-PRECISION.
023437     PERFORM  0280-1000-NUMERIC-EDIT
023437         THRU 0280-1000-NUMERIC-EDIT-X.
023437     IF L0280-OK
023437         MOVE L0280-OUTPUT-V02       TO WS-FED-TAXWH-RQST-PCT
023437         MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
023437         MOVE 2                      TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                    TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                     TO L0290-MAX-OUT-LEN
023437         PERFORM 0290-2000-FORMAT-FOR-MIR
023437            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA      TO MIR-FED-TAXWH-RQST-PCT
029060         MOVE L0290-OUTPUT-DATA      TO MIR-FTAXWH-RQST-PCT
023437         IF WS-FED-TAXWH-RQST-PCT > 100
023437         OR WS-FED-TAXWH-RQST-PCT < ZERO
023437* MESSAGE - INVALID FEDERAL TAX REQUEST %
023437             MOVE 'SS00800068'       TO WGLOB-MSG-REF-INFO
023437             PERFORM  0260-1000-GENERATE-MESSAGE
023437                 THRU 0260-1000-GENERATE-MESSAGE-X
023437             SET WGLOB-RETURN-ERROR  TO TRUE
023437         END-IF
023437     ELSE
023437* MESSAGE - INVALID FEDERAL TAX REQUEST % - REENTER
023437         MOVE 'SS00800069'           TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR      TO TRUE
023437     END-IF.
023437
029060*    IF MIR-FED-TAXWH-CALC-CD = SPACES
029060*    OR MIR-FED-TAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
029060*        MOVE 'C'                    TO MIR-FED-TAXWH-CALC-CD
029060*    END-IF.
029060
029060     IF  MIR-FTAXWH-RQST-CD = SPACES
029060     OR  MIR-FTAXWH-RQST-CD = EBLCH-BLANK-FIELD-CHAR
029060         MOVE 'C'                    TO MIR-FTAXWH-RQST-CD
029060     END-IF.
029060
023437*
023437* CALL THE FEDERAL TAX EDIT REGIONAL EXIT FOR EDITS
023437*
023437     PERFORM  0316-1000-BUILD-PARM-INFO
023437         THRU 0316-1000-BUILD-PARM-INFO-X.
023437
023437     SET L0316-RGN-EXIT-TAXWH-CLI-EDITS
023437                                     TO TRUE.
023437
023437     MOVE RPOL-POL-CTRY-CD           TO L0316-CTRY-CD.
023437
023437     PERFORM  0316-1000-GET-RGN-EXIT-PGM
023437         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
023437
023437     IF  NOT L0316-RETRN-OK
023437     OR  L0316-RGN-EXIT-STAT-INACTV
023437*MSG: 'NO FEDERAL TAX EXIT REGIONAL EXIT FOUND FOR COUNTRY @1'
023437         MOVE 'SS00800070'           TO WGLOB-MSG-REF-INFO
023437         MOVE L0316-CTRY-CD          TO WGLOB-MSG-PARM (1)
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR      TO TRUE
023437         GO TO 5100-EDIT-TAXWH-RQST-X
023437     END-IF
023437
023437* AN ACTIVE REGION EXIT IS HELD. THIS MUST BE PERFORMED FIRST TO
023437* CARRY OUT EDITS FOR FEDERAL TAX WITHHOLDING DATA.
023437
023437     PERFORM  TAXC-1000-BUILD-PARM-INFO
023437         THRU TAXC-1000-BUILD-PARM-INFO-X.
023437
023437     SET LTAXC-RGN-EXIT-TAXWH-CLI-EDITS   TO TRUE.
023437
023437     MOVE RPOL-POL-ID                TO LTAXC-POL-ID.
023437     MOVE LSEGF-INV-CVG-CFN-EFF-DT   TO LTAXC-EFF-DT.
029060*    MOVE WS-FED-TAXWH-CALC-CD       TO LTAXC-FED-TAXWH-CALC-CD.
029060*    MOVE WS-FED-TAXWH-RQST-AMT      TO LTAXC-FED-TAXWH-RQST-AMT.
029060*    MOVE WS-FED-TAXWH-RQST-PCT      TO LTAXC-FED-TAXWH-RQST-PCT.
029060*    MOVE MIR-LTAXWH-CALC-CD         TO LTAXC-LTAXWH-CALC-CD.
029060*    MOVE WS-LOC-RQST-AMT            TO LTAXC-LTAXWH-FLAT-AMT.
029060*    MOVE WS-LOC-RQST-PCT            TO LTAXC-LTAXWH-PCT.
029060     MOVE WS-FED-TAXWH-CALC-CD       TO LTAXC-FTAXWH-RQST-CD.
029060     MOVE WS-FED-TAXWH-RQST-AMT      TO LTAXC-FTAXWH-RQST-AMT.
029060     MOVE WS-FED-TAXWH-RQST-PCT      TO LTAXC-FTAXWH-RQST-PCT.
029060     MOVE MIR-LTAXWH-RQST-CD         TO LTAXC-LTAXWH-RQST-CD.
029060     MOVE WS-LOC-RQST-AMT            TO LTAXC-LTAXWH-RQST-AMT.
029060     MOVE WS-LOC-RQST-PCT            TO LTAXC-LTAXWH-RQST-PCT.
023437
023437     PERFORM  TAXC-1000-TAXWH-CLI-EDIT
023437         THRU TAXC-1000-TAXWH-CLI-EDIT-X.
023437
023437     IF  LTAXC-EDIT-ERROR
023437     OR  NOT LTAXC-RETRN-OK
023437         SET WGLOB-RETURN-ERROR      TO TRUE
023437         GO TO 5100-EDIT-TAXWH-RQST-X
023437     END-IF
023437
023437*
023437* FEDERAL TAX WITHHOLDING AMOUNT
023437*
029060*    IF MIR-CDA-FED-TAXWH-AMT = SPACES
029060*        MOVE ZERO                   TO MIR-CDA-FED-TAXWH-AMT
029060*    END-IF.
029060
029060     IF  MIR-FTAXWH-AMT = SPACES
029060         MOVE ZERO                   TO MIR-FTAXWH-AMT
029060     END-IF.
023437
029060*    MOVE MIR-CDA-FED-TAXWH-AMT      TO L0280-INPUT-DATA.
029060     MOVE MIR-FTAXWH-AMT             TO L0280-INPUT-DATA.
023437     SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
023437     MOVE 13                         TO L0280-LENGTH.
023437     MOVE 2                          TO L0280-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                    TO L0280-INPUT-SIZE.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT   TO L0280-INPUT-SIZE.
029060
023437     PERFORM  0280-1000-NUMERIC-EDIT
023437         THRU 0280-1000-NUMERIC-EDIT-X.
023437*
023437     IF L0280-OK
023437         MOVE L0280-OUTPUT-V02       TO WS-FED-TAXWH-AMT
023437         MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
023437         MOVE  2                     TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                    TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-FTAXWH-AMT
029060                                     TO L0290-MAX-OUT-LEN
023437         PERFORM 0290-2000-FORMAT-FOR-MIR
023437            THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA      TO MIR-CDA-FED-TAXWH-AMT
029060         MOVE L0290-OUTPUT-DATA      TO MIR-FTAXWH-AMT
023437     ELSE
023437* MESSAGE - INVALID FEDERAL TAX WITHHELD AMOUNT
023437         MOVE 'SS00800065'           TO WGLOB-MSG-REF-INFO
023437         PERFORM  0260-1000-GENERATE-MESSAGE
023437             THRU 0260-1000-GENERATE-MESSAGE-X
023437         SET WGLOB-RETURN-ERROR      TO TRUE
023437     END-IF.
023437
023437 5100-EDIT-TAXWH-RQST-X.
023437     EXIT.
023437/
      *-------------------
020475 7400-INIT-DBG-DATA.
      *-------------------

020475     IF RPOL-POL-DBG-NO
020475     OR WCVGS-CVG-DBG-INCL-NO (LSEGF-INPUT-CVG-NUM)
020475        GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.

020475     PERFORM  7306-1000-BUILD-PARM-INFO
020475         THRU 7306-1000-BUILD-PARM-INFO-X.

020475     MOVE RPOL-POL-ID             TO L7306-POL-ID.

020475     PERFORM  7306-1000-GET-DBG-INFO
020475         THRU 7306-1000-GET-DBG-INFO-X.

020475     IF L7306-POL-DBG-BASIC-CSV
020475        GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.

020475*
020475* READ CURRENT DBGA
020475*

020475     PERFORM  7305-1000-BUILD-PARM-INFO
020475         THRU 7305-1000-BUILD-PARM-INFO-X.

020475     MOVE LSEGF-INV-CVG-CFN-EFF-DT TO L7305-EFF-DT.

020475     PERFORM  7305-1000-GET-CURR-DBGA
020475         THRU 7305-1000-GET-CURR-DBGA-X.

020475     IF NOT L7305-RETRN-OK
020475        SET WGLOB-RETURN-ERROR     TO TRUE
020475        GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.

020475     PERFORM  0182-1000-BUILD-PARM-INFO
020475         THRU 0182-1000-BUILD-PARM-INFO-X.

020475     SET L0182-CALC-DBG-AFV-YES     TO TRUE.
020475     MOVE LSEGF-INV-CVG-CFN-EFF-DT  TO L0182-EFF-DT.

020475     PERFORM  0182-1000-CALC-CSV-POL
020475         THRU 0182-1000-CALC-CSV-POL-X.

020475     IF NOT L0182-RETRN-OK
020475        SET WGLOB-RETURN-ERROR     TO TRUE
020475        GO TO 7400-INIT-DBG-DATA-X
020475     END-IF.

020475     MOVE L0182-POL-ACUM-VALU-AMT  TO WS-POL-DBG-ACCUM-AMT.
020475     ADD  L0182-SIDFND-AFV-AMT     TO WS-POL-DBG-ACCUM-AMT.

020475     IF  RPOL-POL-DBG-LOAN
020475         SUBTRACT L0182-LOAN-AMT (1)  FROM WS-POL-DBG-ACCUM-AMT
020475         SUBTRACT L0182-LOAN-ACRU-INT-AMT (1)
020475                                      FROM WS-POL-DBG-ACCUM-AMT
020475     END-IF.

020475 7400-INIT-DBG-DATA-X.
020475     EXIT.

      *--------------------
020475 7410-WRITE-DBGA-REC.
      *--------------------

020475     IF RPOL-POL-DBG-NO
020475     OR WCVGS-CVG-DBG-INCL-NO   (LSEGF-INPUT-CVG-NUM)
020475     OR L7306-POL-DBG-BASIC-CSV
020475     OR WS-CVG-TRXN-AMT = ZERO
020475        GO TO 7410-WRITE-DBGA-REC-X
020475     END-IF.


020475     SET  RDBGA-DBGA-TYP-WTHDR     TO TRUE.
020475     MOVE LSEGF-INV-CVG-CFN-EFF-DT TO L7305-EFF-DT.
020475     MOVE WS-CVG-TRXN-AMT          TO RDBGA-DBGA-TRXN-AMT.
020475     MOVE WS-POL-DBG-ACCUM-AMT     TO RDBGA-DBGA-ACUM-AMT.
020475     MOVE WS-CDA-TYP-CD            TO RDBGA-CDA-TYP-CD.
020475     MOVE WS-POL-PAYO-NUM          TO RDBGA-POL-PAYO-NUM.
020475     MOVE WS-CDA-SEQ-NUM           TO RDBGA-CDA-SEQ-NUM.

020475     PERFORM  7305-2000-CREATE-DBGA
020475         THRU 7305-2000-CREATE-DBGA-X.

020475     IF NOT L7305-RETRN-OK
020475        SET WGLOB-RETURN-ERROR     TO TRUE
020475     END-IF.

020475 7410-WRITE-DBGA-REC-X.
020475     EXIT.

031034*----------------------------
031034*7500-L7800-TO-LPGAL.
031034*----------------------------
031034*
031034*    MOVE L7800-PLAR-PRCES-SW     TO LPGAL-PLAR-PRCES-SW,
031034*    MOVE L7800-PGAL-ALLOC-SW     TO LPGAL-PGAL-ALLOC-SW.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE L7800-PGAL-ALLOC-TYP-CD    (LPGAL-SUB)
031034*          TO LPGAL-PGAL-ALLOC-TYP-CD    (LPGAL-SUB)
031034*        MOVE L7800-PGAL-DPOS-DFLT-IND   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-DPOS-DFLT-IND   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-XFER-ONLY-IND   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-XFER-ONLY-IND   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-PRIN-AMT    (LPGAL-SUB)
031034*          TO LPGAL-PGAL-OPN-PRIN-AMT    (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-GAIN-AMT    (LPGAL-SUB)
031034*          TO LPGAL-PGAL-OPN-GAIN-AMT    (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-SEQ-NUM   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-WTHDR-SEQ-NUM   (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-ORDR-CD   (LPGAL-SUB)
031034*          TO LPGAL-PGAL-WTHDR-ORDR-CD   (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*7500-L7800-TO-LPGAL-X.
031034*    EXIT.
031034*
031034*----------------------------
031034*7600-L7800-TO-HOLD.
031034*----------------------------
031034*
031034*    MOVE L7800-PLAR-PRCES-SW    TO LPGAL-PLAR-PRCES-SW.
031034*    MOVE L7800-PGAL-ALLOC-SW    TO LPGAL-PGAL-ALLOC-SW.
031034*    MOVE L7800-PLAR-PRCES-SW    TO WS-HOLD-PLAR-PRCES-SW.
031034*    MOVE L7800-PGAL-ALLOC-SW    TO WS-HOLD-PGAL-ALLOC-SW.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE L7800-PGAL-ALLOC-TYP-CD    (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-PRIN-AMT    (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-OPN-PRIN-AMT  (LPGAL-SUB)
031034*        MOVE L7800-PGAL-OPN-GAIN-AMT    (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-OPN-GAIN-AMT  (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-SEQ-NUM   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*        MOVE L7800-PGAL-WTHDR-ORDR-CD   (LPGAL-SUB)
031034*          TO WS-HOLD-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*7600-L7800-TO-HOLD-X.
031034*    EXIT.
031034*
031034*----------------------------
031034*7700-HOLD-TO-L7800.
031034*----------------------------
031034*
031034*    MOVE WS-HOLD-PLAR-PRCES-SW  TO LPGAL-PLAR-PRCES-SW.
031034*    MOVE WS-HOLD-PGAL-ALLOC-SW  TO LPGAL-PGAL-ALLOC-SW.
031034*
031034*    PERFORM
031034*        VARYING LPGAL-SUB FROM +1 BY +1
031034*        UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*        MOVE WS-HOLD-PGAL-ALLOC-TYP-CD        (LPGAL-SUB)
031034*          TO L7800-PGAL-ALLOC-TYP-CD          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-OPN-PRIN-AMT        (LPGAL-SUB)
031034*          TO L7800-PGAL-OPN-PRIN-AMT          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-OPN-GAIN-AMT        (LPGAL-SUB)
031034*          TO L7800-PGAL-OPN-GAIN-AMT          (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-WTHDR-SEQ-NUM       (LPGAL-SUB)
031034*          TO L7800-PGAL-WTHDR-SEQ-NUM         (LPGAL-SUB)
031034*        MOVE WS-HOLD-PGAL-WTHDR-ORDR-CD       (LPGAL-SUB)
031034*          TO L7800-PGAL-WTHDR-ORDR-CD         (LPGAL-SUB)
031034*
031034*    END-PERFORM.
031034*
031034*7700-HOLD-TO-L7800-X.
031034*    EXIT.
015290

012696*--------------------
012696*6050-FORMAT-FUND-NO.
012696*--------------------
012696*
012696*    MOVE I                     TO WS-FNUM-N (I).
012696*
012696*6050-FORMAT-FUND-NO-X.
012696*    EXIT.

      *-------------------
       8000-MOVE-FS-TO-WS.
      *-------------------

           MOVE LSEGF-CFN-REC-INFO (I) TO RFS-REC-INFO.
           MOVE RFS-FND-ID            TO L6330-FND-CD (J).
           MOVE ZERO                  TO WS-SAMT-N (J).
012696*    MOVE RFS-CFN-OUT-ALLOC-PCT TO WS-PALL-N (J).
012696     MOVE ZERO                  TO WS-PALL-N (J).
           MOVE ZERO                  TO WS-PFUN-N (J).
           MOVE ZERO                  TO L6330-FND-SURR-UNITS (J).
           ADD 1                      TO J.

       8000-MOVE-FS-TO-WS-X.
           EXIT.

      *--------------------
       8500-RESET-DEFAULTS.
      *--------------------

013578*    MOVE 'XXXX'                TO MIR-DV-CLI-NM.
013578     MOVE SPACES                TO MIR-DV-OWN-CLI-NM.
013578*    MOVE 'XXXXXXXXX'           TO MIR-CIA-LOAD-AMT.
           MOVE '000.0000'            TO MIR-FIA-VALU-SURR-PCT.
008455*    MOVE '0000000.00'          TO MIR-CIA-ALLOC-SURR-AMT.
020874*    MOVE 0                     TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CIA-ALLOC-SURR-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CIA-ALLOC-SURR-AMT.
020874*    MOVE 0                     TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                  TO L0290-INPUT-V02.
013578     MOVE 2                     TO L0290-PRECISION.
013578     MOVE LENGTH OF MIR-CIA-LOAD-AMT
013578                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
013578     MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.
012696*    MOVE 'A'                   TO MIR-ALLOC.
013578*    MOVE 'B'                   TO MIR-ALLOC.
           MOVE 'D'                   TO MIR-CIA-SRC-DEST-CD.
           MOVE WGLOB-PROCESS-DATE    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CIA-EFF-DT.
           MOVE 'GRS'                 TO MIR-CIA-REASN-CD.
023437*    MOVE 'N'                   TO MIR-CIA-TAXWH-IND.
029060*    MOVE 'C'                   TO MIR-LTAXWH-CALC-CD.
029060     MOVE 'C'                   TO MIR-LTAXWH-RQST-CD.

       8500-RESET-DEFAULTS-X.
           EXIT.
012696
012696*-----------------------
012696 8600-CHECK-TRANS-DEFER.
012696*-----------------------
012696
012696     PERFORM  8170-1000-BUILD-PARM-INFO
012696         THRU 8170-1000-BUILD-PARM-INFO-X.
012696     MOVE LSEGF-INPUT-EFF-DT    TO L8170-EFF-DT.
018731     MOVE MIR-CLI-ID            TO L8170-CLI-ID.
018731     MOVE MIR-CLI-BNK-ACCT-NUM  TO L8170-CLI-BNK-ACCT-NUM.
012696     MOVE LSEGF-INPUT-CVG-NUM   TO L8170-CVG-NUM-N.
012696     MOVE LSEGF-INPUT-LOAD-AMT  TO L8170-TRAN-FEE-AMT.
012696     MOVE LSEGF-INPUT-ALLOC-IND TO L8170-TRAN-AMT-ALLOC-CD.
012696     MOVE LSEGF-INPUT-SURR-PCT  TO L8170-POL-PAYO-PCT.
012696     MOVE LSEGF-TAX-WTHLD-IND   TO L8170-TAX-BPSS-IND.
029060*    MOVE LSEGF-LTAXWH-CALC-CD  TO L8170-LTAXWH-CALC-CD.
016107     MOVE MIR-DV-REDC-FACE-IND  TO L8170-REDC-FACE-IND.
012696     SET L8170-DEFR-ALLOWED     TO TRUE.
012696
012696     IF  LSEGF-INPUT-LOAD-FORCE-IND = 'Y'
012696         MOVE LSEGF-INPUT-LOAD-FORCE-IND
                 TO L8170-TRXN-FEE-OVRID-IND
012696     ELSE
012696         MOVE 'N' TO L8170-TRXN-FEE-OVRID-IND
012696     END-IF.
012696
012696     IF  L6330-SUPPRESS-CONFIRM-IND = 'Y'
012696         MOVE L6330-SUPPRESS-CONFIRM-IND
                 TO L8170-SUPR-CONF-IND
012696     ELSE
012696         MOVE 'N' TO L8170-SUPR-CONF-IND
012696     END-IF.
012696
012696     IF  LSEGF-INPUT-REASN-CD = 'GRS'
012696         SET L8170-SURR-AMT-TYP-FND-AMT TO TRUE
012696     ELSE
012696         SET L8170-SURR-AMT-TYP-CLI-AMT TO TRUE
012696     END-IF.
012696
012696     EVALUATE TRUE
012696         WHEN LSEGF-INPUT-SRC-CD = 'C'
012696             IF  LSEGF-INPUT-AMT = ZERO
012696                 MOVE 1         TO L8170-CHQ-AMT
012696             ELSE
012696                 MOVE LSEGF-INPUT-AMT
                                      TO L8170-CHQ-AMT
012696             END-IF
018731         WHEN LSEGF-INPUT-SRC-EFT
018731             IF  LSEGF-INPUT-AMT = ZERO
018731                 MOVE 1         TO L8170-EFT-AMT
018731             ELSE
018731                 MOVE LSEGF-INPUT-AMT
018731                                TO L8170-EFT-AMT
018731             END-IF
012696         WHEN LSEGF-INPUT-SRC-CD = 'D'
012696             IF  LSEGF-INPUT-AMT = ZERO
012696                 MOVE 1         TO L8170-OS-DISB-AMT
012696             ELSE
012696                 MOVE LSEGF-INPUT-AMT
                                      TO L8170-OS-DISB-AMT
012696             END-IF
012696         WHEN LSEGF-INPUT-SRC-CD = 'M'
012696             IF  LSEGF-INPUT-AMT = ZERO
012696                 MOVE 1         TO L8170-MISC-SUSP-AMT
012696             ELSE
012696                 MOVE LSEGF-INPUT-AMT
                                      TO L8170-MISC-SUSP-AMT
012696             END-IF
012696         WHEN LSEGF-INPUT-SRC-CD = 'P'
012696             IF  LSEGF-INPUT-AMT = ZERO
012696                 MOVE 1         TO L8170-PREM-SUSP-AMT
012696             ELSE
012696                 MOVE LSEGF-INPUT-AMT
                                      TO L8170-PREM-SUSP-AMT
012696             END-IF
012696         WHEN OTHER
012696             IF  LSEGF-INPUT-AMT = ZERO
012696                 MOVE 1         TO L8170-OS-DISB-AMT
012696             ELSE
012696                 MOVE LSEGF-INPUT-AMT
                         TO L8170-OS-DISB-AMT
012696             END-IF
012696     END-EVALUATE.
012696
012696     SET LFUND-ACTV-PARTIAL-SURRENDER TO TRUE.
012696     MOVE ZERO TO LFUND-FND-CTR.
012696     PERFORM
012696     VARYING J FROM 1 BY 1
014739*      UNTIL J > LSEGF-FND-CTR
014739       UNTIL J > LSEGF-FIA-REC-CTR
012696         ADD +1 TO LFUND-FND-CTR
012696         INITIALIZE LFUND-FND-INFO (LFUND-FND-CTR)
012696         MOVE LSEGF-INPUT-CVG-NUM
                 TO LFUND-CVG-NUM-N (LFUND-FND-CTR)
012696         MOVE LSEGF-INPUT-FND-ID (J)
                 TO LFUND-FND-ID (LFUND-FND-CTR)
012696         MOVE LSEGF-FIA-REC-INFO (J)
                 TO RFD-REC-INFO
012696         EVALUATE TRUE
012696             WHEN LSEGF-INPUT-ALLOC-IND = 'B'
020469*                MOVE RFD-FIA-FND-TRXN-AMT
020469*                  TO LFUND-ALLOC-AMT (LFUND-FND-CTR)

023091*                IF  RPOL-POL-MULT-CRCY
020469                     MOVE RFD-FIA-ORIG-TRXN-AMT
020469                             TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
023091*                ELSE
023091*                    MOVE RFD-FIA-FND-TRXN-AMT
023091*                            TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
023091*                END-IF

012696             WHEN LSEGF-INPUT-ALLOC-IND = 'C'
012696                 SET LFUND-ALLOC-AMOUNT (LFUND-FND-CTR) TO TRUE
012696                 SUBTRACT LSEGF-INPUT-ALLOC-AMT (J)
012696                     FROM LFUND-ALLOC-AMT (LFUND-FND-CTR)
012696             WHEN LSEGF-INPUT-ALLOC-IND = 'D'
012696             WHEN LSEGF-INPUT-ALLOC-IND = 'E'
012696             WHEN LSEGF-INPUT-ALLOC-IND = 'F'
012696                 SET LFUND-ALLOC-PERCENT (LFUND-FND-CTR) TO TRUE
012696                 SUBTRACT LSEGF-INPUT-ALLOC-AMT (J)
012696                     FROM LFUND-ALLOC-PCT (LFUND-FND-CTR)
012696                 IF  RFD-FIA-FND-TRXN-AMT = ZERO
012696                     MOVE ZERO  TO LFUND-ALLOC-PCT (LFUND-FND-CTR)
012696                 ELSE
020469*                    MOVE RFD-FIA-FND-TRXN-AMT
020469*                      TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
023091*                    IF  RPOL-POL-MULT-CRCY
020469                         MOVE RFD-FIA-ORIG-TRXN-AMT
020469                             TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
023091*                    ELSE
023091*                        MOVE RFD-FIA-FND-TRXN-AMT
023091*                            TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
023091*                    END-IF
012696                 END-IF
012696             WHEN LSEGF-INPUT-ALLOC-IND = 'G'
012696                 SET LFUND-ALLOC-UNITS (LFUND-FND-CTR) TO TRUE
012696                 SUBTRACT LSEGF-INPUT-ALLOC-UNITS (J)
012696                     FROM LFUND-ALLOC-UNIT-QTY (LFUND-FND-CTR)
020469*                MOVE RFD-FIA-FND-TRXN-AMT
020469*                  TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
023091*                IF  RPOL-POL-MULT-CRCY
020469                     MOVE RFD-FIA-ORIG-TRXN-AMT
020469                             TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
023091*                ELSE
023091*                    MOVE RFD-FIA-FND-TRXN-AMT
023091*                            TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
023091*                END-IF
012696         END-EVALUATE
012696         IF  LFUND-ALLOC-AMT (LFUND-FND-CTR) = ZERO
012696         AND LFUND-ALLOC-PCT (LFUND-FND-CTR) = ZERO
012696         AND LFUND-ALLOC-UNIT-QTY (LFUND-FND-CTR) = ZERO
012696             SUBTRACT 1 FROM LFUND-FND-CTR
012696         END-IF
012696     END-PERFORM.
012696
012696     PERFORM  8170-1000-CHECK-TRANS-DEFER
012696         THRU 8170-1000-CHECK-TRANS-DEFER-X.
012696
012696 8600-CHECK-TRANS-DEFER-X.
012696     EXIT.
012696
012696*-----------------------
012696 8700-DEFER-TRANSACTION.
012696*-----------------------
012696
012696     PERFORM  8170-2000-DEFER-TRANSACTION
012696         THRU 8170-2000-DEFER-TRANSACTION-X.
012696
012696     IF  L8170-RETRN-OK
012696*MSG: THIS SURRENDER HAS BEEN DEFERRED
012696         MOVE 'SS00800038' TO WGLOB-MSG-REF-INFO
012696         PERFORM 0260-1000-GENERATE-MESSAGE
012696            THRU 0260-1000-GENERATE-MESSAGE-X
012696     END-IF.
012696
012696 8700-DEFER-TRANSACTION-X.
012696     EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

014035*----------------
014035*9605-LSEGF-TEST.
014035*----------------
014035*
014035*    IF  LSEGF-PREM-ERROR-IND = 1
014035*        MOVE '   ' TO MIR-DV-VERIF-TXT
014035*    ELSE
014035*        PERFORM  2510-1000-BUILD-PARM-INFO
014035*            THRU 2510-1000-BUILD-PARM-INFO-X
014035*        SET L2510-RESPONSE-YES TO TRUE
014035*        PERFORM  2510-2000-SINGLE-VALUE
014035*            THRU 2510-2000-SINGLE-VALUE-X
014035*        MOVE TYSNO-YES-NO-LONG (WGLOB-LANG-SUB, 1)
014035*          TO MIR-DV-VERIF-TXT
014035*        MOVE L2510-RESPONSE-TXT TO MIR-DV-VERIF-TXT
014035*    END-IF.
014035*
014035*9605-LSEGF-TEST-X.
014035*    EXIT.
      *
021311*--------------------------
021311 9990-INIT-WORKING-STORAGE.
021311*--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
021311
025970     PERFORM  0182-0000-INIT-PARM-INFO
025970         THRU 0182-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0185-0000-INIT-PARM-INFO
025970         THRU 0185-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0316-0000-INIT-PARM-INFO
025970         THRU 0316-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0410-0000-INIT-PARM-INFO
025970         THRU 0410-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0500-0000-INIT-PARM-INFO
025970         THRU 0500-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2600-0000-INIT-PARM-INFO
025970         THRU 2600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2760-0000-INIT-PARM-INFO
025970         THRU 2760-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  3330-0000-INIT-PARM-INFO
025970         THRU 3330-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4382-0000-INIT-PARM-INFO
025970         THRU 4382-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6330-0000-INIT-PARM-INFO
025970         THRU 6330-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6860-0000-INIT-PARM-INFO
025970         THRU 6860-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7305-0000-INIT-PARM-INFO
025970         THRU 7305-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7306-0000-INIT-PARM-INFO
025970         THRU 7306-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7721-0000-INIT-PARM-INFO
025970         THRU 7721-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8170-0000-INIT-PARM-INFO
025970         THRU 8170-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8640-0000-INIT-PARM-INFO
025970         THRU 8640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  TAXC-0000-INIT-PARM-INFO
025970         THRU TAXC-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-SCREEN-WORK-AREA.
025970     INITIALIZE  HEADER-MISC-WORK-AREAS.
021311     INITIALIZE  LSEGF-FA-FD-INFO.
021311     INITIALIZE  LSEGF-FC-FS-INFO.
021311     INITIALIZE  LSEGF-PARM-INFO.
025970     INITIALIZE  WS-TWRK-FIELDS.
021311
025970     SET WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET WS-INPUT-LOAD-FORCE-NO      TO TRUE.
025970     SET WS-VERIFY-ERROR-NO          TO TRUE.
021311     SET WS-REBUILD-AFTER-UNDO-NO    TO TRUE.

025970*    MOVE 'N'                   TO WS-INPUT-LOAD-FORCE-IND.
025970*    MOVE ZEROS                 TO WS-INPUT-LOAD-AMT.
025970*    MOVE 0                     TO RESET-SW.
025970*    MOVE 0                     TO WGLOB-MSG-ERROR-SW.
025970*    MOVE 0                     TO FSUR-CALL-SW.
021311     MOVE ZEROS                 TO LSEGF-FND-CTR.
025970*    MOVE 'N'                   TO WS-VERIFY-ERROR-SW.
025970*    MOVE ZEROS                 TO WS-FED-TAXWH-RQST-AMT.
025970*    MOVE ZEROS                 TO WS-FED-TAXWH-RQST-PCT.
025970*    MOVE ZEROS                 TO WS-LOC-RQST-AMT.
025970*    MOVE ZEROS                 TO WS-LOC-RQST-PCT.
025970*    MOVE ZEROS                 TO WS-FED-TAXWH-AMT.
025970*    MOVE ZEROS                 TO WS-TRMN-AMT.
025970*    MOVE ZEROS                 TO WS-CHARGE.
025970*    MOVE ZEROS                 TO WS-SURR-TOTAL.
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.

025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
021311
021311 9990-INIT-WORKING-STORAGE-X.
021311     EXIT.
021311*
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
       COPY NCPPCVGS.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      *
       COPY NCPPCVGR.
      *
       COPY CCPSPGA.
      *
       COPY CCPS2430.
      *
       COPY CCPS5400.
      *
       COPY SCPS6330.
      *
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
018846 COPY CCPS0182.
018846 COPY CCPL0182.
018846
023226 COPY CCPS0185.
023226 COPY CCPL0185.
023226/
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455*
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503*
018764*COPY CCCL0201.
025970 COPY CCPS0201.
018764 COPY CCPL0201.
016503*
025970 COPY CCPS0620.
013578 COPY CCPL0620.
      *
018764*COPY CCCL2430.
018764 COPY CCPL2430.
557701*
016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108*
012143 COPY CCPS2600.
018764*COPY CCCL2600.
018764 COPY CCPL2600.
      *
018764*COPY CCCL3330.
018764 COPY CCPL3330.
012135 COPY CCPS3330.
      *
018731 COPY CCPS4382.
018764*COPY CCCL4382.
018764 COPY CCPL4382.
      *
557701 COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.
      *
016503 COPY CCPS4780.
018764*COPY CCCL4780.
018764 COPY CCPL4780.
016503*
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
018764*COPY CCCL6860.
025970 COPY CCPS6860.
018764 COPY CCPL6860.
      *
020475 COPY CCPS7305.
020475 COPY CCPL7305.
      *
020475 COPY CCPS7306.
020475 COPY CCPL7306.
      *
031034*COPY CCPS7800.
031034*COPY CCPL7800.
015290
015290 COPY CCPSPGAL.
012135 COPY CCPPMIDT.
012135 COPY CCPPPLIN.
012135 COPY CCPNPH.
012135*
013578*COPY XCCPTSQP.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
014660*COPY XCPPMEXT.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
      *********** LINKAGE SECTIONS ********

020463 COPY CCPS2735.
020463 COPY CCPL2735.
012143*
012143 COPY FCPS2760.
018764*COPY FCCL2760.
018764 COPY FCPL2760.
012696*
012696 COPY FCPS8170.
018764*COPY FCCL8170.
018764 COPY FCPL8170.
012143*
       COPY SCPS0410.
018764*COPY SCCL0410.
018764 COPY SCPL0410.
      *
018764*COPY SCCL0500.
025970 COPY SCPS0500.
018764 COPY SCPL0500.
      *
018764*COPY SCCL6330.
018764 COPY SCPL6330.
557756*
013578*COPY XCPS2510.
013578*COPY XCCL2510.
      *
021239 COPY XCPS7721.
021239 COPY XCPL7721.
      *
013578 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
020469 COPY XCPS8640.
020469 COPY XCPL8640.
      *
025970 COPY XCPS1660.
015290 COPY XCPL1660.
015290/
023437 COPY XCPS0316.
023437 COPY XCPL0316.
023437/
023437 COPY CCPSTAXC.
023437 COPY CCPLTAXC.

      ********** IO COPYBOOKS ************
       COPY CCPNPOL.
       COPY CCPUPOL.
      *
       COPY CCPNCVG.
      *
       COPY CCPUCVG.
      *
       COPY SCPNFR.
      *
       COPY SCPNFH.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM SSOM0080                     **
      *****************************************************************

