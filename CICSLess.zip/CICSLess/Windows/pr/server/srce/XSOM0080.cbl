      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM0080.


       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM0080                                         **
      **  REMARKS:  PROCESS DRIVER FOR MSGM                          **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CHANGE TO STANDARD                               **
557708**  5.5       NEW CICS ABEND PROCESSING                        **
008445**  5.5.2     GENERATE MIR FROM TECH ARCH DATABASE             **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       GLOBAL MESSAGING                                 **
015648**  6.0       BLANK FIELD CHARACTER                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019390**  6.4       BLANK VALUE OF SECURITY CLASS CODE               **
023480**  6.5       MSGS FIELDS FOR FUSION REGEN                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024009**  6.5       DOUBLT BYTE CHARACTER                            **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM0080'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID            PIC X(04).
                   88  WS-BUS-FCN-RETRIEVE  VALUE '0080'.
                   88  WS-BUS-FCN-CREATE    VALUE '0081'.
                   88  WS-BUS-FCN-UPDATE    VALUE '0082'.
                   88  WS-BUS-FCN-DELETE    VALUE '0083'.
                   88  WS-BUS-FCN-LIST      VALUE '0084'.
               10  WS-SEVERITY-CODE         PIC X(01).
014660*            88  VALID-SEVERITY       VALUE 'W' 'F' 'S' 'I'.
014660             88  VALID-SEVERITY       VALUE '1' '2' '3' '4' '5'.
023480         10  WS-RGEN-CD               PIC X(01).
023480             88  VALID-RGEN           VALUE '1' '2' '3' '4' '5'
023480                                            '6' '7' '8' '9' '0'.
023480         10  WS-RGEN-SUPRES-CD        PIC X(01).
023480             88  VALID-RGEN-SUPRES    VALUE '1' '2' '3' '4' '5'
023480                                            '6' '7' '8' '9' '0'.
               10  WS-MESSAGE-SOURCE.
                   15  WS-SOURCE-SYSTEM     PIC X(01).
                   15  WS-SOURCE-TYPE       PIC X(01).
                       88  VALID-SOURCE-TYPE    VALUE 'S' 'C'.
                   15  WS-SOURCE-NUMBER     PIC X(04).
               10  WS-AUDIT-IND             PIC X(01).
                   88  VALID-AUDIT-IND      VALUE 'Y' 'N'.
               10  WS-TOKENS                PIC X(01).
                   88  VALID-TOKENS         VALUE '1' '2' '3' '4'.
               10  WS-MESSAGE-SW            PIC X(01).
                   88  WS-VALID-MESSAGE     VALUE 'Y'.
                   88  WS-INVALID-MESSAGE   VALUE 'N'.
014660*        10  WS-MSIN-MSG-INQ-IND      PIC X(01).
014660*            88  VALID-INQ-IND        VALUE 'Y' 'N'.
               10  WS-MSIN-MSG-GUI-IND      PIC X(01).
                   88  VALID-GUI-IND        VALUE 'Y' 'N'.
014660*        10  WS-MSIN-MSG-PRCES-FAIL-IND PIC X(01).
014660*            88  VALID-PRCES-FAIL-IND VALUE 'Y' 'N'.

025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0080'.
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
016548*    05  WS-MAX-LINES                 PIC S9(04) COMP
025970*    05  WS-MAX-LINES                 PIC S9(04) BINARY
025970*                                                VALUE +11.
           05  WS-MORE-VALID-MSGS-SW        PIC X(01).
           05  WS-PARAMETERS-USED           PIC X(01).
016548*    05  WS-MAX-MESSAGE-LENGTH        PIC S9(04) COMP
025970*    05  WS-MAX-MESSAGE-LENGTH        PIC S9(04) BINARY
014660*                                                VALUE +68.
025970*                                                VALUE +120.
014660     05  WS-SAVE-SEVERITY             PIC X(01).
014660     05  WS-SAVE-AUDIT-IND            PIC X(01).
014660*    05  WS-SAVE-MSG-INQ-IND          PIC X(01).
014660     05  WS-SAVE-MSG-GUI-IND          PIC X(01).
014660*    05  WS-SAVE-MSG-PRCES-FAIL-IND   PIC X(01).
014660*    05  WS-SAVE-MESSAGE              PIC X(68).
014660     05  WS-SAVE-MESSAGE              PIC X(120).
023480     05  WS-SAVE-RGEN-CD              PIC X(01).
023480     05  WS-SAVE-RGEN-SUPRES-CD       PIC X(01).
014660*    05  WS-DESC-ARRAY                PIC X(68).
014660     05  WS-DESC-ARRAY                PIC X(120).
           05  WS-DESC-ARRAY-R              REDEFINES WS-DESC-ARRAY.
014660*        10  WS-SINGLE-CHAR           OCCURS 68 TIMES
014660         10  WS-SINGLE-CHAR           OCCURS 120 TIMES
                                            INDEXED BY CHAR-ARRAY
                                            PIC X(01).
025970*    05  WS-ZERO-VALUE                PIC X(01) VALUE '0'.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES            PIC S9(4) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT VALUE +11.

025970     05  WS-TWRK-KEY                  PIC X(04).  
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '0080'.
025970
025970     05  WS-MAX-MESSAGE-LENGTH        PIC S9(04) BINARY.
025970         88 WS-MAX-MESSAGE-LENGTH-DEF VALUE +120.
025970
025970     05  WS-ZERO-VALUE                PIC X(01).
025970         88  WS-ZERO-VALUE-DEFAULT    VALUE '0'.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.

      /
       COPY XCWL0280.
014221 COPY XCWL8090.
      /
       COPY XCWEBLCH.
      /
       COPY XCFWXTAB.
       COPY XCFRXTAB.
      /
014221 COPY CCWWLOCK.
024009 COPY XCWWMBCS.
      /
       COPY XCFWMSGS.
       COPY XCFRMSGS.
      /
016537*COPY XCWWWKDT.

      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY XCWM0080.

      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
025970*    SET  MIR-RETRN-OK       TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /

      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------
      ****************************************************************
      * READ MESSAGE FILE FOR SPECIFIC ERROR MESSAGE OR              *
      * GROUP LEVEL (MESSAGE NUMBER BLANK) AND DISPLAY               *
      ****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-MSGE-KEY
               THRU 7100-BUILD-MSGE-KEY-X.

014221*    PERFORM  MSGS-1000-READ
014221*        THRU MSGS-1000-READ-X.

014221     PERFORM  MSGS-1000-READ-TWRK-TS
014221         THRU MSGS-1000-READ-TWRK-TS-X.

           IF WMSGS-IO-NOT-FOUND
               MOVE WMSGS-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /

      *------------------
       3500-PROCESS-LIST.
      *------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  (MIR-MSG-REF-ID = SPACES)
           AND (MIR-MSG-REF-NUM NOT = SPACES)
               MOVE 'XS00800009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           MOVE LOW-VALUES            TO WMSGS-KEY.
           MOVE HIGH-VALUES           TO WMSGS-ENDBR-KEY.

           MOVE MIR-MSG-REF-ID        TO WMSGS-MSG-REF-ID.
           MOVE MIR-MSG-REF-ID        TO WMSGS-ENDBR-MSG-REF-ID.
           MOVE MIR-MSG-REF-NUM       TO WMSGS-MSG-REF-NUM.

015648     IF MIR-MSG-LANG-CD = '*'
015648        MOVE SPACES TO MIR-MSG-LANG-CD
015648     END-IF.

           MOVE MIR-MSG-LANG-CD       TO WMSGS-MSG-LANG-CD.

           PERFORM  MSGS-1000-BROWSE
               THRU MSGS-1000-BROWSE-X.

           IF WMSGS-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           ELSE
               PERFORM  MSGS-2000-READ-NEXT
                   THRU MSGS-2000-READ-NEXT-X

               IF WMSGS-IO-EOF
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3500-PROCESS-LIST-X
               END-IF
           END-IF.

           MOVE +1                    TO WS-SUB.
           PERFORM  3600-MSGS-INQ-READ
               THRU 3600-MSGS-INQ-READ-X
               UNTIL (WS-SUB  > WS-MAX-LIST-LINES)
               OR   WMSGS-IO-EOF.

           IF WMSGS-IO-EOF
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF MIR-MSG-LANG-CD NOT = SPACES
                   PERFORM  MSGS-2000-READ-NEXT
                       THRU MSGS-2000-READ-NEXT-X
                       UNTIL MIR-MSG-LANG-CD = RMSGS-MSG-LANG-CD
                       OR WMSGS-IO-EOF
               END-IF

               IF WMSGS-IO-EOF
                   MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
               ELSE
                   MOVE RMSGS-MSG-REF-NUM
                                      TO MIR-MSG-REF-NUM
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
               END-IF
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  MSGS-3000-END-BROWSE
               THRU MSGS-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------
       3600-MSGS-INQ-READ.
      *-------------------

           IF  (MIR-MSG-LANG-CD = SPACES)
           OR  (MIR-MSG-LANG-CD = RMSGS-MSG-LANG-CD)
               MOVE RMSGS-MSG-REF-NUM TO MIR-MSG-REF-NUM-T (WS-SUB)
               MOVE RMSGS-MSG-LANG-CD TO MIR-MSG-LANG-CD-T (WS-SUB)
               MOVE RMSGS-MSG-SECUR-CLAS-CD
                                     TO MIR-MSG-SECUR-CLAS-CD-T (WS-SUB)
               MOVE RMSGS-MSG-SEVRTY-CD
                                      TO MIR-MSG-SEVRTY-CD-T (WS-SUB)
               MOVE RMSGS-MSG-AUD-IND TO MIR-MSG-AUD-IND-T (WS-SUB)
014660*        MOVE RMSGS-MSG-INQ-IND TO MIR-MSG-INQ-IND-T (WS-SUB)
               MOVE RMSGS-MSG-GUI-IND TO MIR-MSG-GUI-IND-T (WS-SUB)
014660*        MOVE RMSGS-MSG-PRCES-FAIL-IND
014660*                             TO MIR-MSG-PRCES-FAIL-IND-T (WS-SUB)
               MOVE RMSGS-MSG-TXT     TO MIR-MSG-TXT-T (WS-SUB)
023480         MOVE RMSGS-MSG-RGEN-CD TO MIR-MSG-RGEN-CD-T (WS-SUB)
023480         MOVE RMSGS-MSG-RGEN-SUPRES-CD
023480                             TO MIR-MSG-RGEN-SUPRES-CD-T (WS-SUB)
               ADD  +1                        TO WS-SUB
           END-IF.

           PERFORM  MSGS-2000-READ-NEXT
               THRU MSGS-2000-READ-NEXT-X.

       3600-MSGS-INQ-READ-X.
           EXIT.
      /

      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      ****************************************************************
      * CREATE NEW MESSAGE RECORD.  THE RECORD IS CREATED WITH THE
      * KEY FIELDS ENTERED.  THE REMAINING DATA WILL BE UPDATED VIA
      * THE MAINTAIN SCREEN.
      ****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-MSGE-KEY
               THRU 7100-BUILD-MSGE-KEY-X.

           PERFORM  MSGS-1000-READ
               THRU MSGS-1000-READ-X.
           IF WMSGS-IO-OK
               MOVE WMSGS-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  4100-CREATE-EDITS
               THRU 4100-CREATE-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  7100-BUILD-MSGE-KEY
               THRU 7100-BUILD-MSGE-KEY-X.

           PERFORM  MSGS-1000-CREATE
               THRU MSGS-1000-CREATE-X.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  MSGS-1000-WRITE
               THRU MSGS-1000-WRITE-X.

014221     PERFORM  MSGS-1000-READ-TWRK-TS
014221         THRU MSGS-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /

      *------------------
       4100-CREATE-EDITS.
      *------------------
      ****************************************************************
      * EDIT INPUT FIELDS.
      ****************************************************************

           MOVE MIR-MSG-REF-ID        TO WS-MESSAGE-SOURCE.
           IF VALID-SOURCE-TYPE
               CONTINUE
           ELSE
               MOVE 'XS00800001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *
      * PERFORM NUMERIC EDIT ON THE MESSAGE NUMBER
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 4                     TO L0280-LENGTH.
           MOVE MIR-MSG-REF-NUM       TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF NOT L0280-OK
               MOVE 'XS00800010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF MIR-MSG-SECUR-CLAS-CD = SPACES
               MOVE WMSGS-KEY         TO WMSGS-ENDBR-KEY
               MOVE LOW-VALUES        TO WMSGS-MSG-SECUR-CLAS-CD
               MOVE HIGH-VALUES       TO WMSGS-ENDBR-MSG-SECUR-CLAS-CD

               PERFORM  MSGS-1000-BROWSE
                   THRU MSGS-1000-BROWSE-X

               IF WMSGS-IO-EOF
                   CONTINUE
               ELSE
                   PERFORM  MSGS-2000-READ-NEXT
                       THRU MSGS-2000-READ-NEXT-X
                   PERFORM  4150-END-BROWSE
                       THRU 4150-END-BROWSE-X
               END-IF

           ELSE
               MOVE SPACES            TO WMSGS-MSG-SECUR-CLAS-CD
               PERFORM  MSGS-1000-READ
                   THRU MSGS-1000-READ-X

               IF WMSGS-IO-OK
                   MOVE 'XS00800003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           MOVE MIR-MSG-LANG-CD       TO WXTAB-ETBL-VALU-ID.
           PERFORM  LANG-1000-EDIT-USER-LANGUAGE
               THRU LANG-1000-EDIT-USER-LANGUAGE-X.

           IF WXTAB-IO-OK
               CONTINUE
           ELSE
               MOVE 'XS00800004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4100-CREATE-EDITS-X.
           EXIT.
      /

      *----------------
       4150-END-BROWSE.
      *----------------

           IF WMSGS-IO-EOF
               PERFORM  MSGS-3000-END-BROWSE
                   THRU MSGS-3000-END-BROWSE-X
           ELSE
               PERFORM  MSGS-3000-END-BROWSE
                   THRU MSGS-3000-END-BROWSE-X
               IF WMSGS-MSG-SECUR-CLAS-CD = SPACES
                   CONTINUE
               ELSE
                   MOVE 'XS00800002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       4150-END-BROWSE-X.
           EXIT.
      /

      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM  7100-BUILD-MSGE-KEY
               THRU 7100-BUILD-MSGE-KEY-X.

      *
      ***  A READ IS PERFORMED AT THIS POINT INSTEAD OF A
      ***  READ-FOR-UPDATE BECAUSE IF A MESSAGE IS GENERATED DURING
      ***  THE EDITS, A DEADLOCK WOULD OCCUR ON THE MESSAGE FILE.
      *
           PERFORM  MSGS-1000-READ
               THRU MSGS-1000-READ-X.

      *
014660***  THE RECORD DATA IS STORED BECAUSE ANY MESSAGES CREATED DURING
014660***  EDITS WOULD WIPE OUT THE RECORD VALUES.
014660*
014660     MOVE RMSGS-MSG-SEVRTY-CD   TO WS-SAVE-SEVERITY.
014660     MOVE RMSGS-MSG-AUD-IND     TO WS-SAVE-AUDIT-IND.
014660*    MOVE RMSGS-MSG-INQ-IND     TO WS-SAVE-MSG-INQ-IND.
014660     MOVE RMSGS-MSG-GUI-IND     TO WS-SAVE-MSG-GUI-IND.
014660*    MOVE RMSGS-MSG-PRCES-FAIL-IND
014660*                               TO WS-SAVE-MSG-PRCES-FAIL-IND.
014660     MOVE RMSGS-MSG-TXT         TO WS-SAVE-MESSAGE.
023480     MOVE RMSGS-MSG-RGEN-CD     TO WS-SAVE-RGEN-CD.
023480     MOVE RMSGS-MSG-RGEN-SUPRES-CD
023480                                TO WS-SAVE-RGEN-SUPRES-CD.


           IF WMSGS-IO-NOT-FOUND
               MOVE WMSGS-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  5220-UPDATE-EDITS
               THRU 5220-UPDATE-EDITS-X.

      *
      ***  WE BUILD THE KEY AGAIN IN CASE ANOTHER MESSAGE WAS READ
      ***  DURING THE EDITS.
      *
           PERFORM  7100-BUILD-MSGE-KEY
               THRU 7100-BUILD-MSGE-KEY-X.

014221*    PERFORM  MSGS-1000-READ-FOR-UPDATE
014221*        THRU MSGS-1000-READ-FOR-UPDATE-X.
014221     PERFORM  MSGS-2000-UPDATE-TWRK-TS
014221         THRU MSGS-2000-UPDATE-TWRK-TS-X.

           IF WMSGS-IO-NOT-FOUND
               MOVE WMSGS-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'MSGS'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WMSGS-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014660*
014660***  THE WS- FIELDS WILL CONTAIN THE CURRENT RECORD VALUE OR THE
014660***  MIR VALUE IF IT PASSED THE EDITS.
014660*
014660     MOVE WS-SAVE-SEVERITY      TO RMSGS-MSG-SEVRTY-CD.
014660     MOVE WS-SAVE-AUDIT-IND     TO RMSGS-MSG-AUD-IND.
014660*    MOVE WS-SAVE-MSG-INQ-IND   TO RMSGS-MSG-INQ-IND.
014660     MOVE WS-SAVE-MSG-GUI-IND   TO RMSGS-MSG-GUI-IND.
014660*    MOVE WS-SAVE-MSG-PRCES-FAIL-IND
014660*                               TO RMSGS-MSG-PRCES-FAIL-IND.
014660     MOVE WS-SAVE-MESSAGE       TO RMSGS-MSG-TXT.
023480     MOVE WS-SAVE-RGEN-CD       TO RMSGS-MSG-RGEN-CD.
023480     MOVE WS-SAVE-RGEN-SUPRES-CD
023480                                TO RMSGS-MSG-RGEN-SUPRES-CD.

           MOVE WS-PARAMETERS-USED    TO RMSGS-MSG-PARM-USE-IND.

           PERFORM  MSGS-2000-REWRITE
               THRU MSGS-2000-REWRITE-X.

014221     PERFORM  MSGS-1000-READ-TWRK-TS
014221         THRU MSGS-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /

      *-----------------
       5220-UPDATE-EDITS.
      *-----------------

      ****************************************************************
      * EDIT INPUT FIELDS.                                          *
      ****************************************************************

           PERFORM  5222-EDIT-SEVERITY
               THRU 5222-EDIT-SEVERITY-X.

           PERFORM  5224-EDIT-AUDIT-IND
               THRU 5224-EDIT-AUDIT-IND-X.

014660*    PERFORM  5225-EDIT-MSIN-INQ-IND
014660*        THRU 5225-EDIT-MSIN-INQ-IND-X.

           PERFORM  5227-EDIT-GUI-DISPLAY-IND
               THRU 5227-EDIT-GUI-DISPLAY-IND-X.

014660*    PERFORM  5228-EDIT-PROCESS-FAILURE
014660*        THRU 5228-EDIT-PROCESS-FAILURE-X.

023480     PERFORM  5229-EDIT-RGEN-CD
023480         THRU 5229-EDIT-RGEN-CD-X.
023480
023480     PERFORM  5230-EDIT-RGEN-SUPRES-CD
023480         THRU 5230-EDIT-RGEN-SUPRES-CD-X.

           MOVE 'N'                   TO WS-PARAMETERS-USED.

           IF MIR-MSG-TXT = SPACES
014660         MOVE WS-SAVE-MESSAGE   TO MIR-MSG-TXT
014660         CONTINUE
           ELSE
               IF MIR-MSG-TXT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-MSG-TXT
               END-IF
           END-IF.

           MOVE MIR-MSG-TXT           TO WS-DESC-ARRAY.
           SET  WS-VALID-MESSAGE           TO TRUE.

024009     PERFORM  MBCS-0000-INIT
024009         THRU MBCS-0000-INIT-X.
024009
           PERFORM  5226-CHECK-FOR-TOKENS
               THRU 5226-CHECK-FOR-TOKENS-X
               VARYING CHAR-ARRAY FROM 1 BY 1
               UNTIL CHAR-ARRAY > WS-MAX-MESSAGE-LENGTH.

014660     IF WS-VALID-MESSAGE
014660         MOVE MIR-MSG-TXT       TO WS-SAVE-MESSAGE
014660     END-IF.

       5220-UPDATE-EDITS-X.
           EXIT.
      /

      *-------------------
       5222-EDIT-SEVERITY.
      *-------------------

      ****************************************************************
      * EDIT INPUT FIELDS - SEVERITY.                               *
      ****************************************************************

           IF MIR-MSG-SEVRTY-CD = SPACES
014660         IF WS-SAVE-SEVERITY = SPACE
014660             CONTINUE
014660         ELSE
014660             MOVE WS-SAVE-SEVERITY
014660                                TO MIR-MSG-SEVRTY-CD
014660             GO TO 5222-EDIT-SEVERITY-X
014660         END-IF
014660         CONTINUE
           ELSE
               IF MIR-MSG-SEVRTY-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-MSG-SEVRTY-CD
               END-IF
           END-IF.

           MOVE MIR-MSG-SEVRTY-CD     TO WS-SEVERITY-CODE.

           IF VALID-SEVERITY
               CONTINUE
           ELSE
               MOVE 'XS00800005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5222-EDIT-SEVERITY-X
           END-IF.

      *
      ***  A SEVERITY CODE OF SYSTEM OR INFORMATIONAL CANNOT BE CHANGED.
      *
014660*    IF  (WS-SAVE-SEVERITY = 'S'
014660*    OR  WS-SAVE-SEVERITY  = 'I')
014660*    AND MIR-MSG-SEVRTY-CD NOT     =  WS-SAVE-SEVERITY
014660     IF  (WS-SAVE-SEVERITY = '1'
014660     OR   WS-SAVE-SEVERITY = '5')
014660     AND MIR-MSG-SEVRTY-CD NOT     =  WS-SAVE-SEVERITY
               MOVE 'XS00800006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014660     ELSE
014660         MOVE MIR-MSG-SEVRTY-CD TO WS-SAVE-SEVERITY
           END-IF.

       5222-EDIT-SEVERITY-X.
           EXIT.
      /

      *--------------------
       5224-EDIT-AUDIT-IND.
      *--------------------

      ****************************************************************
      * EDIT INPUT FIELDS - AUDIT INDICATOR.
      ****************************************************************

           IF MIR-MSG-AUD-IND = SPACES
014660         MOVE WS-SAVE-AUDIT-IND TO MIR-MSG-AUD-IND
014660         GO TO 5224-EDIT-AUDIT-IND-X
014660         CONTINUE
           ELSE
               IF MIR-MSG-AUD-IND = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-MSG-AUD-IND
               END-IF
           END-IF.

           MOVE MIR-MSG-AUD-IND       TO WS-AUDIT-IND.

           IF VALID-AUDIT-IND
014660         MOVE MIR-MSG-AUD-IND   TO WS-SAVE-AUDIT-IND
014660         CONTINUE
           ELSE
               MOVE 'XS00800007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5224-EDIT-AUDIT-IND-X.
           EXIT.
      /

014660*-----------------------
014660*5225-EDIT-MSIN-INQ-IND.
014660*-----------------------
014660*
014660****************************************************************
014660* EDIT INPUT FIELDS - MSIN INQUIRY INDICATOR                   *
014660****************************************************************
014660*
014660*    IF MIR-MSG-INQ-IND = SPACES
014660*        MOVE WS-SAVE-MSG-INQ-IND
014660*                               TO MIR-MSG-INQ-IND
014660*        GO TO 5225-EDIT-MSIN-INQ-IND-X
014660*    ELSE
014660*        IF MIR-MSG-INQ-IND = EBLCH-BLANK-FIELD-CHAR
014660*            MOVE SPACES        TO MIR-MSG-INQ-IND
014660*        END-IF
014660*    END-IF.
014660*
014660*    MOVE MIR-MSG-INQ-IND       TO WS-MSIN-MSG-INQ-IND.
014660*
014660*    IF VALID-INQ-IND
014660*        MOVE MIR-MSG-INQ-IND   TO WS-SAVE-MSG-INQ-IND
014660*    ELSE
014660*        MOVE 'XS00800011'      TO WGLOB-MSG-REF-INFO
014660*        PERFORM  0260-1000-GENERATE-MESSAGE
014660*            THRU 0260-1000-GENERATE-MESSAGE-X
014660*    END-IF.
014660*
014660*5225-EDIT-MSIN-INQ-IND-X.
014660*    EXIT.
      /

      *----------------------
       5226-CHECK-FOR-TOKENS.
      *----------------------

024009     MOVE WS-SINGLE-CHAR (CHAR-ARRAY)  TO WMBCS-CS-CHARACTER.
024009
024009     PERFORM  MBCS-1000-CHECK
024009         THRU MBCS-1000-CHECK-X.
024009
024009     IF  WMBCS-CS-IS-DBCS
024009         SET CHAR-ARRAY UP BY 1
024009         GO TO 5226-CHECK-FOR-TOKENS-X
024009     END-IF.
024009
           IF WS-SINGLE-CHAR (CHAR-ARRAY) = '@'
               SET CHAR-ARRAY UP BY 1
               MOVE WS-SINGLE-CHAR (CHAR-ARRAY)
                                      TO WS-TOKENS
               IF VALID-TOKENS
                   MOVE 'Y'           TO WS-PARAMETERS-USED
               ELSE
                   SET  WS-INVALID-MESSAGE TO TRUE
                   MOVE 'XS00800008'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       5226-CHECK-FOR-TOKENS-X.
           EXIT.
      /

      *--------------------------
       5227-EDIT-GUI-DISPLAY-IND.
      *--------------------------

      ****************************************************************
      * EDIT INPUT FIELDS - GUI DISPLAY INDICATOR                    *
      ****************************************************************

           IF MIR-MSG-GUI-IND = SPACES
014660         MOVE WS-SAVE-MSG-GUI-IND
014660                                TO MIR-MSG-GUI-IND
014660         GO TO 5227-EDIT-GUI-DISPLAY-IND-X
014660         CONTINUE
           ELSE
               IF MIR-MSG-GUI-IND = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-MSG-GUI-IND
               END-IF
           END-IF.

           MOVE MIR-MSG-GUI-IND       TO WS-MSIN-MSG-GUI-IND.

           IF VALID-GUI-IND
014660         MOVE MIR-MSG-GUI-IND   TO WS-SAVE-MSG-GUI-IND
014660         CONTINUE
           ELSE
               MOVE 'XS00800012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5227-EDIT-GUI-DISPLAY-IND-X.
           EXIT.
      /

014660*--------------------------
014660*5228-EDIT-PROCESS-FAILURE.
014660*--------------------------
014660*
014660*    IF MIR-MSG-PRCES-FAIL-IND = SPACES
014660*        MOVE WS-SAVE-MSG-PRCES-FAIL-IND
014660*                               TO MIR-MSG-PRCES-FAIL-IND
014660*        GO TO 5228-EDIT-PROCESS-FAILURE-X
014660*    ELSE
014660*        IF MIR-MSG-PRCES-FAIL-IND = EBLCH-BLANK-FIELD-CHAR
014660*            MOVE SPACES        TO MIR-MSG-PRCES-FAIL-IND
014660*        END-IF
014660*    END-IF.
014660*
014660*    MOVE MIR-MSG-PRCES-FAIL-IND    TO WS-MSIN-MSG-PRCES-FAIL-IND.
014660*
014660*    IF VALID-PRCES-FAIL-IND
014660*        IF  WS-SAVE-MSG-PRCES-FAIL-IND = 'Y'
014660*        AND MIR-MSG-PRCES-FAIL-IND NOT =
014660*                           WS-SAVE-MSG-PRCES-FAIL-IND
014660*            MOVE 'XS00800013'  TO WGLOB-MSG-REF-INFO
014660*            PERFORM  0260-1000-GENERATE-MESSAGE
014660*                THRU 0260-1000-GENERATE-MESSAGE-X
014660*        ELSE
014660*            MOVE MIR-MSG-PRCES-FAIL-IND
014660*                               TO WS-SAVE-MSG-PRCES-FAIL-IND
014660*        END-IF
014660*    ELSE
014660*        MOVE 'XS00800014'      TO WGLOB-MSG-REF-INFO
014660*        PERFORM  0260-1000-GENERATE-MESSAGE
014660*            THRU 0260-1000-GENERATE-MESSAGE-X
014660*    END-IF.
014660*
014660*5228-EDIT-PROCESS-FAILURE-X.
014660*    EXIT.
      /
023480*------------------
023480 5229-EDIT-RGEN-CD.
023480*------------------
023480
023480**************************
023480*  EDIT MESSAGE REGEN CODE
023480**************************
023480
023480     IF  MIR-MSG-RGEN-CD        = EBLCH-BLANK-FIELD-CHAR
023480         MOVE SPACE               TO MIR-MSG-RGEN-CD
023480     END-IF.
023480
023480     MOVE MIR-MSG-RGEN-CD         TO WS-RGEN-CD.
023480
023480     IF  VALID-RGEN
023480         MOVE MIR-MSG-RGEN-CD     TO WS-SAVE-RGEN-CD
023480     ELSE
023480         MOVE 'XS00800015'        TO WGLOB-MSG-REF-INFO
023480         PERFORM  0260-1000-GENERATE-MESSAGE
023480             THRU 0260-1000-GENERATE-MESSAGE-X
023480         GO TO 5229-EDIT-RGEN-CD-X
023480     END-IF.
023480
023480 5229-EDIT-RGEN-CD-X.
023480     EXIT.
023480/
023480*-------------------------
023480 5230-EDIT-RGEN-SUPRES-CD.
023480*-------------------------
023480
023480**********************************
023480*  EDIT MESSAGE REGEN SUPRESS CODE
023480**********************************
023480
023480     IF  MIR-MSG-RGEN-SUPRES-CD = EBLCH-BLANK-FIELD-CHAR
023480         MOVE SPACE               TO MIR-MSG-RGEN-SUPRES-CD
023480     END-IF.
023480
023480     MOVE MIR-MSG-RGEN-SUPRES-CD  TO WS-RGEN-SUPRES-CD.
023480
023480     IF  VALID-RGEN-SUPRES
023480         MOVE MIR-MSG-RGEN-SUPRES-CD
023480                                  TO WS-SAVE-RGEN-SUPRES-CD
023480     ELSE
023480         MOVE 'XS00800016'        TO WGLOB-MSG-REF-INFO
023480         PERFORM  0260-1000-GENERATE-MESSAGE
023480             THRU 0260-1000-GENERATE-MESSAGE-X
023480         GO TO 5230-EDIT-RGEN-SUPRES-CD-X
023480     END-IF.
023480
023480 5230-EDIT-RGEN-SUPRES-CD-X.
023480     EXIT.
023480/

      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           PERFORM  7100-BUILD-MSGE-KEY
               THRU 7100-BUILD-MSGE-KEY-X.

014221*    PERFORM  MSGS-1000-READ-FOR-UPDATE
014221*        THRU MSGS-1000-READ-FOR-UPDATE-X.

014221     PERFORM  MSGS-2000-UPDATE-TWRK-TS
014221         THRU MSGS-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'MSGS'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WMSGS-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WMSGS-IO-OK
               PERFORM  MSGS-1000-DELETE
                   THRU MSGS-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO MIR-MSG-SEVRTY-CD
                                      MIR-MSG-AUD-IND
                                      MIR-MSG-TXT
014660*        MOVE SPACES            TO MIR-MSG-INQ-IND
               MOVE SPACES            TO MIR-MSG-GUI-IND
014660*        MOVE SPACES            TO MIR-MSG-PRCES-FAIL-IND
           ELSE
               MOVE WMSGS-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *--------------------
       7100-BUILD-MSGE-KEY.
      *--------------------

      ****************************************************************
      * BUILD THE KEY.                                               *
      ****************************************************************

           MOVE MIR-MSG-REF-ID        TO WMSGS-MSG-REF-ID.
           MOVE MIR-MSG-REF-NUM       TO WMSGS-MSG-REF-NUM.
           MOVE MIR-MSG-LANG-CD       TO WMSGS-MSG-LANG-CD.
019390
019390     IF  MIR-MSG-SECUR-CLAS-CD = EBLCH-BLANK-FIELD-CHAR
019390         MOVE SPACE             TO MIR-MSG-SECUR-CLAS-CD
019390     END-IF.

           MOVE MIR-MSG-SECUR-CLAS-CD TO WMSGS-MSG-SECUR-CLAS-CD.

       7100-BUILD-MSGE-KEY-X.
           EXIT.
      /

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           IF WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-MSG-REF-NUM-G
               MOVE SPACES            TO MIR-MSG-LANG-CD-G
               MOVE SPACES            TO MIR-MSG-SECUR-CLAS-CD-G
               MOVE SPACES            TO MIR-MSG-SEVRTY-CD-G
               MOVE SPACES            TO MIR-MSG-AUD-IND-G
014660*        MOVE SPACES            TO MIR-MSG-INQ-IND-G
               MOVE SPACES            TO MIR-MSG-GUI-IND-G
014660*        MOVE SPACES            TO MIR-MSG-PRCES-FAIL-IND-G
               MOVE SPACES            TO MIR-MSG-TXT-G
023480         MOVE SPACES            TO MIR-MSG-RGEN-CD-G
023480         MOVE SPACES            TO MIR-MSG-RGEN-SUPRES-CD-G
           ELSE
               MOVE SPACES            TO MIR-MSG-SEVRTY-CD
               MOVE SPACES            TO MIR-MSG-AUD-IND
014660*        MOVE SPACES            TO MIR-MSG-INQ-IND
               MOVE SPACES            TO MIR-MSG-GUI-IND
014660*        MOVE SPACES            TO MIR-MSG-PRCES-FAIL-IND
               MOVE SPACES            TO MIR-MSG-TXT
023480         MOVE SPACES            TO MIR-MSG-RGEN-CD
023480         MOVE SPACES            TO MIR-MSG-RGEN-SUPRES-CD
           END-IF.
023480*
023480* ON A CREATE THE DEFAULT REGEN VALUES FOR FUSION FIELDS
023480* ARE ZERO
023480*
023480     IF  WS-BUS-FCN-CREATE
023480         MOVE WS-ZERO-VALUE     TO MIR-MSG-RGEN-CD
023480                                   MIR-MSG-RGEN-SUPRES-CD
023480     END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RMSGS-MSG-SEVRTY-CD   TO MIR-MSG-SEVRTY-CD.
           MOVE RMSGS-MSG-AUD-IND     TO MIR-MSG-AUD-IND.
014660*    MOVE RMSGS-MSG-INQ-IND     TO MIR-MSG-INQ-IND.
           MOVE RMSGS-MSG-GUI-IND     TO MIR-MSG-GUI-IND.
014660*    MOVE RMSGS-MSG-PRCES-FAIL-IND
014660*                               TO MIR-MSG-PRCES-FAIL-IND.
           MOVE RMSGS-MSG-TXT         TO MIR-MSG-TXT.
023480     MOVE RMSGS-MSG-RGEN-CD     TO MIR-MSG-RGEN-CD.
023480     MOVE RMSGS-MSG-RGEN-SUPRES-CD
023480                                TO MIR-MSG-RGEN-SUPRES-CD.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WMBCS-CONV-TO-CHAR.
025970     INITIALIZE WMBCS-PLATFORM.
025970     INITIALIZE WMBCS-CHARACTER-SET-CD.
025970     INITIALIZE WMBCS-CS-CHARACTER. 
025970  
025970     SET  WMBCS-IN-SBCS-MODE        TO TRUE.
025970     SET  WMBCS-NEXT-IS-SBCS-MODE   TO TRUE.
025970     SET  WS-MAX-LIST-LINES-DEFAULT TO TRUE. 
025970     SET  WS-TWRK-KEY-DEFAULT       TO TRUE.
025970     SET  WS-MAX-MESSAGE-LENGTH-DEF TO TRUE.
025970     SET  WS-ZERO-VALUE-DEFAULT     TO TRUE.
025970
025970     SET  MIR-RETRN-OK              TO TRUE.
025970     MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /

      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPELANG.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY MSGS
014221                         '$VAR2' BY 'MSGS'.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
024009
024009 COPY XCPPMBCS.
      ****************************************************************
      * LINKING COPYBOOKS                                            *
      ****************************************************************

      *
      * LINK TO PROGRAM 0280 FOR NUMERIC EDITS
      *
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS
      ****************************************************************

014660*COPY XCPPMEXT.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY XCPNXTAB.
      /
       COPY XCPAMSGS.
       COPY XCPBMSGS.
       COPY XCPCMSGS.
       COPY XCPNMSGS.
       COPY XCPUMSGS.
       COPY XCPXMSGS.

      *****************************************************************
      **                 END OF PROGRAM XSOM0080                     **
      *****************************************************************
