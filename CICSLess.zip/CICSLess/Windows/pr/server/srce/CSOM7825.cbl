      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7825.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7825                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE POLP AND CDSI TABLES                     **
      **                                                             **
      **            DEFERRED ACTIVITY                                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
026070**  6.6       ERROR HANDLER                                    **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7825'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC  X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '7825'.
           05  I                             PIC S9(04)
                                             BINARY.
           05  WS-SUB                        PIC S9(04)
                                             BINARY.
           05  WS-MAX-LIST-LINES             PIC S9(04)
                                             BINARY.
           05  WS-POL-PAYO-NUM               PIC S9(05)
                                             COMP-3.
023437*    05  WS-CDI-TYP-CD                 PIC  X(01).
023437     05  WS-CDI-TYP-CD                 PIC  X(02).
               88  WS-CDI-TYP-TRMN           VALUE
023437*                  'B' 'D' 'E' 'G' 'H' 'J' 'K' 'N'.
023437                   'B ' 'D ' 'E ' 'G ' 'H ' 'J ' 'K ' 'N '.

       01  WS-CONSTANT-AREA.
           05  FILLER                        PIC  X(01).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.
      /
       COPY CCFWPOLP.
       COPY CCFRPOLP.
      /
       COPY CCFWCDSI.
       COPY CCFRCDSI.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWL5400.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
       COPY XCWL1660.
      /
       COPY XCWL8640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7825.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7825'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-RETRIEVE.
      *--------------
      *
           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  8010-EDIT-KEY-FIELDS
               THRU 8010-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  7000-BUILD-POLP-KEYS
               THRU 7000-BUILD-POLP-KEYS-X.

           PERFORM  POLP-1000-READ
               THRU POLP-1000-READ-X.

           IF  WPOLP-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOLP-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.


      /
      *---------------------------
       7000-BUILD-POLP-KEYS.
      *---------------------------

           MOVE MIR-POL-ID            TO WPOLP-POL-ID.
           MOVE WS-POL-PAYO-NUM       TO WPOLP-POL-PAYO-NUM.

       7000-BUILD-POLP-KEYS-X.
           EXIT.


      /
      *---------------------------
       7100-BUILD-CDSI-KEYS.
      *---------------------------

           MOVE RPOLP-POL-ID          TO WCDSI-POL-ID.
           MOVE RPOLP-POL-PAYO-EFF-DT TO L1660-INTERNAL-DATE.

           PERFORM 1660-2000-CONVERT-INT-TO-INV
              THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE   TO WCDSI-CDI-EFF-IDT-NUM.
           MOVE RPOLP-POL-PAYO-TYP-CD TO WCDSI-CDI-TYP-CD.
           MOVE RPOLP-POL-PAYO-NUM    TO WCDSI-POL-PAYO-NUM.
023112     MOVE ZERO                  TO WCDSI-CDI-SEQ-NUM.
           MOVE ZERO                  TO WCDSI-CDI-ALLOC-NUM.

           MOVE WCDSI-KEY             TO WCDSI-ENDBR-KEY.
023112     MOVE +999                  TO WCDSI-ENDBR-CDI-SEQ-NUM.
           MOVE +999                  TO WCDSI-ENDBR-CDI-ALLOC-NUM.

       7100-BUILD-CDSI-KEYS-X.
           EXIT.


      /
      *---------------------------
       8010-EDIT-KEY-FIELDS.
      *---------------------------

           PERFORM  8011-EDIT-POL-ID
               THRU 8011-EDIT-POL-ID-X.

           PERFORM  8012-EDIT-POL-PAYO-NUM
               THRU 8012-EDIT-POL-PAYO-NUM-X.

       8010-EDIT-KEY-FIELDS-X.
           EXIT.


      /
      *---------------------------
       8011-EDIT-POL-ID.
      *---------------------------
      *
      * CHECK POLICY EXISTS
      *
           IF  MIR-POL-ID-BASE  = SPACES
           AND MIR-POL-ID-SFX   = SPACES
      *MSG: POLICY NUMBER IS REQUIRED
               MOVE 'CS78250001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                  TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

           MOVE MIR-POL-ID             TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD NOT FOUND
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                  TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

      *
      * CHECK POLICY CONFIDENTIAL AND SECURITY ARE SATISFIED
      *

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-STAT-MSG-NOT-REQD TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
               MOVE 1                  TO WGLOB-MSG-ERROR-SW
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

       8011-EDIT-POL-ID-X.
           EXIT.



      *---------------------------
       8012-EDIT-POL-PAYO-NUM.
      *---------------------------
      *
      *  CHECK PAYOUT NUMBER
      *

           IF  MIR-POL-PAYO-NUM = SPACES
           OR  MIR-POL-PAYO-NUM = '00000'
               MOVE '00001'            TO MIR-POL-PAYO-NUM
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 0                      TO L0280-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-NUM
                                       TO L0280-INPUT-SIZE.

           COMPUTE  L0280-LENGTH
                 =  L0280-INPUT-SIZE.

           MOVE MIR-POL-PAYO-NUM       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: INVALID PAYOUT NUMBER
               MOVE 'CS78250002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                  TO WGLOB-MSG-ERROR-SW
               GO TO 8012-EDIT-POL-PAYO-NUM-X
           END-IF.

           COMPUTE  WS-POL-PAYO-NUM
                 =  100000
                 -  L0280-OUTPUT-V00.

       8012-EDIT-POL-PAYO-NUM-X.
           EXIT.


      /
      *---------------------------
       9000-BLANK-DATA-FIELDS.
      *---------------------------

           MOVE SPACES                 TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.


      /
      *---------------------------
       9200-MOVE-RECORD-TO-MIR.
      *---------------------------

           PERFORM  7100-BUILD-CDSI-KEYS
               THRU 7100-BUILD-CDSI-KEYS-X.

           PERFORM  CDSI-1000-BROWSE
               THRU CDSI-1000-BROWSE-X.

           PERFORM  CDSI-2000-READ-NEXT
               THRU CDSI-2000-READ-NEXT-X.

           PERFORM  9210-BUILD-LIST-SCREEN
               THRU 9210-BUILD-LIST-SCREEN-X
              UNTIL NOT WCDSI-IO-OK.

           PERFORM  CDSI-3000-END-BROWSE
               THRU CDSI-3000-END-BROWSE-X.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.


      /
      *---------------------------
       9210-BUILD-LIST-SCREEN.
      *---------------------------
      *
      * DESTINATION INSTRUCTION LIST WILL NOT INCLUDE THE PAYOUT METHOD
      *

           MOVE RCDSI-CDI-TYP-CD           TO WS-CDI-TYP-CD.

           IF  RCDSI-CDI-PAYO-MTHD-CD = SPACES
               CONTINUE
           ELSE
               IF  WS-CDI-TYP-TRMN
                   CONTINUE
               ELSE
                   PERFORM  CDSI-2000-READ-NEXT
                       THRU CDSI-2000-READ-NEXT-X
                   GO TO 9210-BUILD-LIST-SCREEN-X
               END-IF
           END-IF.

           ADD +1 TO WS-SUB.

           IF  WS-SUB > WS-MAX-LIST-LINES
      *MSG LIST MAXIMUM REACHED (@1), CONTACT SYSTEMS
               MOVE WS-MAX-LIST-LINES TO WGLOB-MSG-PARM (1)
               MOVE 'CS78250003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  0030-5000-LOGIC-ERROR
                   THRU 0030-5000-LOGIC-ERROR-X
           END-IF.

           PERFORM  9220-GET-DESC-TXT
               THRU 9220-GET-DESC-TXT-X.

      *
      * DISPLAY THE FUND CURRENCY
      *
           IF  RCDSI-DEST-FND-ID NOT = SPACES
               MOVE RCDSI-DEST-FND-ID        TO L8640-FND-ID
               PERFORM  8640-1000-GET-FND-CRCY-CD
                   THRU 8640-1000-GET-FND-CRCY-CD-X
               IF  L8640-RETRN-OK
                   MOVE L8640-FND-CRCY-CD TO MIR-FIA-CRCY-CD-T (WS-SUB)
               ELSE
                   MOVE SPACES            TO MIR-FIA-CRCY-CD-T (WS-SUB)
               END-IF
           END-IF.

      *
      * DISPLAY THE DOLLAR AMOUNT THAT IS ALLOCATED TO THIS INSTRUCTION
      *
           MOVE RCDSI-CDI-ALLOC-AMT TO L0290-INPUT-V02.
           MOVE 2                   TO L0290-PRECISION.
           MOVE LENGTH OF  MIR-CDI-ALLOC-AMT-T
                                    TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY   TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA   TO MIR-CDI-ALLOC-AMT-T (WS-SUB).

           PERFORM CDSI-2000-READ-NEXT
              THRU CDSI-2000-READ-NEXT-X.

       9210-BUILD-LIST-SCREEN-X.
           EXIT.


      *---------------------------
       9220-GET-DESC-TXT.
      *---------------------------
      *
      *  GET FUND OR PLAN DESCRIPTION ON THIS INSTRUCTION
      *
           EVALUATE TRUE

                WHEN RCDSI-CDI-PAYO-MTHD-CD = SPACES

                    IF  RCDSI-DEST-FND-ID      = SPACES
                    AND RCDSI-DEST-CVG-NUM NOT = SPACES
                    AND RCDSI-DEST-CVG-NUM-N   > ZEROES
                        MOVE WCVGS-PLAN-ID (RCDSI-DEST-CVG-NUM-N)
                             TO WEDIT-ETBL-VALU-ID
                        PERFORM  PLAN-2000-DESC
                            THRU PLAN-2000-DESC-X
                        MOVE REDIT-ETBL-DESC-TXT
                              TO MIR-DV-FND-DESC-TXT-T (WS-SUB)
                    ELSE
                        IF  RCDSI-DEST-FND-ID NOT = SPACES
                            MOVE RCDSI-DEST-FND-ID
                              TO WEDIT-ETBL-VALU-ID
                            PERFORM  SGFD-2000-DESC
                                THRU SGFD-2000-DESC-X
                            MOVE REDIT-ETBL-DESC-TXT
                              TO MIR-DV-FND-DESC-TXT-T (WS-SUB)
                        END-IF
                    END-IF

           END-EVALUATE.

       9220-GET-DESC-TXT-X.
           EXIT.


      /
      *---------------------------
       9300-SETUP-MSIN-REFERENCE.
      *---------------------------

           MOVE SPACES              TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE  TO WGLOB-REF-COMPANY-CODE.

           SET  WGLOB-REF-POLICY    TO TRUE.
           MOVE MIR-POL-ID          TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.


      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8640-0000-INIT-PARM-INFO
025970         THRU 8640-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.

      *
      *  SET THE NUMBER OF LIST LINES USING MIR FIELD OCCURENCES
      *

           COMPUTE WS-MAX-LIST-LINES
                 = LENGTH OF MIR-DV-FND-DESC-TXT-G
                 / LENGTH OF MIR-DV-FND-DESC-TXT-T (1).

           MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPEPLAN.
      /
       COPY CCPESGFD.
      /
       COPY NCPPCVGS.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY CCPS5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL5400.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
       COPY XCPS8640.
       COPY XCPL8640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY CCPNPOL.
      /
       COPY CCPNCVG.
      /
       COPY CCPNPOLP.
      /
       COPY CCPBCDSI.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **              END OF PROGRAM CSOM7825                        **
      *****************************************************************
