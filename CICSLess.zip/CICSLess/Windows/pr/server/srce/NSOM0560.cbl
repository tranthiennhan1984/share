      *****************************************************************
      **  MEMBER :  NSOM0560                                         **
      **  REMARKS:  FAMH - FAMILY HISTORY                            **
      **                                                             **
      **            THIS MODULE PERFORMS THE MAINTENANCE FUNCTIONS   **
      **            OF THE MEDICAL FAMILY HISTORY INFORMATION.       **
      **            MEDICAL INFORMATION IS STORED FOR PARENTS,       **
      **            BROTHERS AND SISTERS, LIVING AND DEAD.           **
      **            HEREDITARY DISORDER DATA IS ALSO STORED.         **
      **            A INDICATOR IS USED FOR CLIENTS WHOSE HISTORY IS **
      **            NOT KNOWN.  FAMILY INFORMATION IS STORED ON THE  **
      **            APPLICATION FIXED INFORMATION TABLE.             **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
555206**  5.5       ALLOW TO CHANGE RECORD BACK TO ZEROS.            **
555206**            DELETE RECORD WHEN LINE ALL ZEROS.               **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       CICS ABEND HANDLING                              **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       SET RAPPF-HERED-DISORD-IND                       **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016387**  6.2       REMOVE CLIENT CONSOLIDATION SUPPORT              **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018622**  6.4       LOGICAL LOCKING FOR CREATE FLOW                  **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0560.

       COPY XCWWCRHT.
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0560'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
016548*    05  WS-SUB2                      PIC S9(04) COMP.
016548     05  WS-SUB2                      PIC S9(04) BINARY.
016548*    05  WS-REL-SUB                   PIC S9(04) COMP.
016548     05  WS-REL-SUB                   PIC S9(04) BINARY.
016548*    05  WS-FATHER-SUB                PIC S9(04) COMP.
016548     05  WS-FATHER-SUB                PIC S9(04) BINARY.
016548*    05  WS-MOTHER-SUB                PIC S9(04) COMP.
016548     05  WS-MOTHER-SUB                PIC S9(04) BINARY.
016548*    05  WS-SISTER-SUB                PIC S9(04) COMP.
016548     05  WS-SISTER-SUB                PIC S9(04) BINARY.
016548*    05  WS-BROTHER-SUB               PIC S9(04) COMP.
016548     05  WS-BROTHER-SUB               PIC S9(04) BINARY.
           05  WS-PIC-DATE                  PIC X(10).
           05  WS-PIC-999                   PIC 9(03).
           05  WS-N-999                     PIC S9(03).
           05  WS-PIC-99                    PIC 9(02).
           05  WS-N-99                      PIC S9(02).
           05  WS-VALIDATE-CONTROL          PIC X(01).
               88  WS-INVALID-CONTROL                  VALUE '1'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE
                   '0560' '0562'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0560'.
               88  WS-BUS-FCN-UPDATE        VALUE '0562'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0560'.
           05  WS-EDIT-OK-SW                PIC X(01).
               88  WS-EDIT-OK               VALUE '0'.
           05  WS-TEST-HDET                 PIC X(01).
               88  WS-HDET-OK               VALUE ' ' 'Y' 'N'.
           05  WS-TEST-YES-NO               PIC X(01).
               88  WS-TEST-YES-NO-OK        VALUE SPACE 'Y' 'N'.
555206*    05  WS-CLIF-DATA-SW              PIC X(01).
555206*        88  WS-CLIF-DATA-TO-WRITE    VALUE 'Y'.
555206*        88  WS-CLIF-NO-DATA-TO-WRITE VALUE ' '.
555206*    05  WS-CLIF-DATA-THIS-LINE       PIC X(01)  OCCURS 4 TIMES.
           05  WS-CLIF-WRITE-SW             PIC X(01).
               88  WS-CLIF-WRITE            VALUE 'W'.
               88  WS-CLIF-REWRITE          VALUE 'R'.
       01  WS-WORK-INFO.
           05  WS-WORK-AREA                     OCCURS 4 TIMES.
               10  WS-CLI-FMLY-REL-CD               PIC X(01).
                   88  WS-REL-TO-INSRD-FATHER       VALUE 'F'.
                   88  WS-REL-TO-INSRD-MOTHER       VALUE 'M'.
                   88  WS-REL-TO-INSRD-SISTER       VALUE 'S'.
                   88  WS-REL-TO-INSRD-BROTHER      VALUE 'B'.
               10  WS-CLI-REL-LVNG-QTY              PIC S9(03)   COMP-3.
               10  WS-CLI-REL-DTH-QTY               PIC S9(03)   COMP-3.
               10  WS-CLI-REL-LVNG-AGE              PIC S9(03)   COMP-3.
               10  WS-CLI-REL-DTH-AGE               PIC S9(03)   COMP-3.
557659*        10  WS-REL-HLTH-STATE-TXT            PIC X(15).
557659*        10  WS-HERED-DISORD-1-TXT            PIC X(15).
557659*        10  WS-HERED-DISORD-2-TXT            PIC X(15).
557659*        10  WS-DISORD-1-DTL-TXT              PIC X(01).
557659*        10  WS-DISORD-2-DTL-TXT              PIC X(01).
557659         10  WS-REL-HLTH-STATE-CD             PIC X(15).
557659         10  WS-HERED-DISORD-1-CD             PIC X(15).
557659         10  WS-HERED-DISORD-2-CD             PIC X(15).
557659         10  WS-DISORD-1-DTL-IND              PIC X(01).
557659         10  WS-DISORD-2-DTL-IND              PIC X(01).
016548*    05  WS-SUB                               PIC S9(04)  COMP.
016548     05  WS-SUB                               PIC S9(04)  BINARY.
016537     05  WS-SUB-X                             PIC 9.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                VALUE '0560'.
      /
016537 COPY CCWWINDX.
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  TRANSACTION SPECIFIC COPYBOOKS
      *****************************************************************
      /
      *****************************************************************
      *  FILE LAYOUTS COPYBOOKS
      *****************************************************************
      /
       COPY NCFWAPPF.
       COPY NCFWCLIF.
       COPY NCFRCLIF.
       COPY NCFRAPPF.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
014221 COPY CCFWCLI.
014221 COPY CCFRCLI.
      /
      *****************************************************************
      *  PARAMETER AREA COPYBOOKS
      *****************************************************************
      /
       COPY CCWL0620.
028298 COPY CCWL2626.
       COPY CCWL5600.
       COPY NCWL2437.
      /
       COPY XCWL0280.
014221 COPY XCWL8090.
      /
       COPY XCWLDTLK.
       COPY XCWL1640.
      *****************************************************************
      *  COMM AREA COPYBOOKS
      *****************************************************************
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0560.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      ***************************************************************
      *   NORMAL PROCESSING: CHECK SECURITY PERMISSION & DISTRIBUTE
      *   CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      ***************************************************************
      **********************
       2000-PROCESS-REQUEST.
      **********************

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
      *
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
           PERFORM  7000-VALIDATE-ACCESS
               THRU 7000-VALIDATE-ACCESS-X.
      *
           IF  L2437-RETRN-CLI-NOT-FOUND
           OR  L5600-CNFD-ACCS-RESTRICTED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  4000-PROCESS-UPDATE
                        THRU 4000-PROCESS-UPDATE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM0560'       TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      ***************************************************************
      *   INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE AND
      *   LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.
      ***************************************************************
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************
      *
           PERFORM  8000-BUILD-APPF-KEY
               THRU 8000-BUILD-APPF-KEY-X.
      *
018622     MOVE MIR-CLI-ID         TO WCLI-CLI-ID.
018622     PERFORM  CLI-1000-READ-TWRK-TS
018622         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  APPF-1000-READ
               THRU APPF-1000-READ-X.
      *
           IF WAPPF-IO-OK
018622*        MOVE MIR-CLI-ID             TO WCLI-CLI-ID
018622*        PERFORM  CLI-1000-READ-TWRK-TS
018622*            THRU CLI-1000-READ-TWRK-TS-X
               PERFORM  8300-LOAD-CLIF-ARRAY
                   THRU 8300-LOAD-CLIF-ARRAY-X

               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE 'XS00000002'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000118'   TO WGLOB-MSG-REF-INFO
               MOVE WAPPF-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
557660     END-IF.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-UPDATE.
      *--------------------

           IF  L5600-CCAS-ACCS-RESTRICTED
               GO TO 4000-PROCESS-UPDATE-X
           END-IF.

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CLI'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WCLI-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 4000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  8000-BUILD-APPF-KEY
               THRU 8000-BUILD-APPF-KEY-X.

      *   CHECK IF RECORD EXISTS.

           PERFORM  APPF-1000-READ
               THRU APPF-1000-READ-X.

           IF WAPPF-IO-OK
               PERFORM  8300-LOAD-CLIF-ARRAY
                   THRU 8300-LOAD-CLIF-ARRAY-X

           ELSE
               PERFORM  APPF-1000-CREATE
                   THRU APPF-1000-CREATE-X
               PERFORM  4110-DEFAULT-PREGNANCY-IND
                   THRU 4110-DEFAULT-PREGNANCY-IND-X
               PERFORM  APPF-1000-WRITE
                   THRU APPF-1000-WRITE-X
           END-IF.

      *
           PERFORM  8000-BUILD-APPF-KEY
               THRU 8000-BUILD-APPF-KEY-X.
      *
           PERFORM  APPF-1000-READ-FOR-UPDATE
               THRU APPF-1000-READ-FOR-UPDATE-X.

           IF WAPPF-IO-OK
               PERFORM  8300-LOAD-CLIF-ARRAY
                   THRU 8300-LOAD-CLIF-ARRAY-X
           ELSE
               MOVE 'XS00000016'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-UPDATE-X
557660     END-IF.
      *
           PERFORM  5000-EDIT-FIELDS
               THRU 5000-EDIT-FIELDS-X.
      *
           PERFORM  APPF-2000-REWRITE
               THRU APPF-2000-REWRITE-X.

014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  5990-CHECK-FOR-DATA-TO-WRITE
               THRU 5990-CHECK-FOR-DATA-TO-WRITE-X.
      *
555206*    IF WS-CLIF-DATA-TO-WRITE
               PERFORM  4230-WRITE-OR-REWRITE-CLIF
                   THRU 4230-WRITE-OR-REWRITE-CLIF-X
                   VARYING WS-SUB FROM 1 BY 1
555206               UNTIL WS-SUB > 4.
555206*    END-IF.
      *
      *   UPDATE THE MIR LAST UPDATE DATE
      *
014221*    MOVE RAPPF-PREV-UPDT-DT      TO L1640-INTERNAL-DATE.
014221*    MOVE RAPPF-PREV-UPDT-TS      TO L1640-INTERNAL-DATE.
014221     MOVE RAPPF-PREV-UPDT-TS      TO WWKDT-INT-TS.
014221     MOVE WWKDT-INT-TS            TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
014221*    MOVE L1640-EXTERNAL-DATE     TO MIR-PREV-UPDT-DT.
014221     MOVE L1640-EXTERNAL-DATE     TO MIR-DV-PREV-UPDT-DT.
      *
           IF WS-EDIT-OK
               MOVE 'XS00000007'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       4000-PROCESS-UPDATE-X.
           EXIT.
      /
      *
       4110-DEFAULT-PREGNANCY-IND.

           IF L2437-CLI-SEX-CD NOT = 'F'
               MOVE 'N' TO RAPPF-CLI-PREG-IND
557660     END-IF.

       4110-DEFAULT-PREGNANCY-IND-X.
           EXIT.
      *
      *
       4230-WRITE-OR-REWRITE-CLIF.

555206*    IF WS-CLIF-DATA-THIS-LINE (WS-SUB) NOT = 'Y'
555206*        GO TO 4230-WRITE-OR-REWRITE-CLIF-X.
      *
           PERFORM  8210-BUILD-SPECIFIC-CLIF-KEY
               THRU 8210-BUILD-SPECIFIC-CLIF-KEY-X
      *
           PERFORM  CLIF-1000-READ-FOR-UPDATE
               THRU CLIF-1000-READ-FOR-UPDATE-X

           IF WCLIF-IO-OK
555206         IF MIR-CLI-REL-LVNG-QTY-T (WS-SUB)  > ZERO
555206         OR MIR-CLI-REL-DTH-QTY-T (WS-SUB)  > ZERO
555206         OR MIR-CLI-REL-LVNG-AGE-T (WS-SUB)  > ZERO
555206         OR MIR-CLI-REL-DTH-AGE-T (WS-SUB)  > ZERO
555206         OR MIR-REL-HLTH-STATE-CD-T (WS-SUB)  NOT = SPACES
555206         OR MIR-HERED-DISORD-1-CD-T (WS-SUB)  NOT = SPACES
555206         OR MIR-DISORD-1-DTL-IND-T  (WS-SUB)  NOT = SPACES
555206         OR MIR-HERED-DISORD-2-CD-T (WS-SUB)  NOT = SPACES
555206         OR MIR-DISORD-2-DTL-IND-T  (WS-SUB)  NOT = SPACES
                   MOVE 'R'   TO WS-CLIF-WRITE-SW

                   PERFORM  4231-CLFM-ARRAY-DATA-TO-CLIF
                       THRU 4231-CLFM-ARRAY-DATA-TO-CLIF-X
      *
555206         ELSE
555206             PERFORM  CLIF-1000-DELETE
555206                 THRU CLIF-1000-DELETE-X
555206         END-IF
           ELSE
555206         IF MIR-CLI-REL-LVNG-QTY-T (WS-SUB)  > ZERO
555206         OR MIR-CLI-REL-DTH-QTY-T (WS-SUB)  > ZERO
555206         OR MIR-CLI-REL-LVNG-AGE-T (WS-SUB)  > ZERO
555206         OR MIR-CLI-REL-DTH-AGE-T (WS-SUB)  > ZERO
555206         OR MIR-REL-HLTH-STATE-CD-T (WS-SUB)  NOT = SPACES
555206         OR MIR-HERED-DISORD-1-CD-T (WS-SUB)  NOT = SPACES
555206         OR MIR-DISORD-1-DTL-IND-T  (WS-SUB)  NOT = SPACES
555206         OR MIR-HERED-DISORD-2-CD-T (WS-SUB)  NOT = SPACES
555206         OR MIR-DISORD-2-DTL-IND-T  (WS-SUB)  NOT = SPACES
                   PERFORM  CLIF-1000-CREATE
                       THRU CLIF-1000-CREATE-X
      *
                   MOVE 'W'   TO WS-CLIF-WRITE-SW

                   PERFORM  4231-CLFM-ARRAY-DATA-TO-CLIF
                       THRU 4231-CLFM-ARRAY-DATA-TO-CLIF-X
557660         END-IF
557660     END-IF.
      *
       4230-WRITE-OR-REWRITE-CLIF-X.
           EXIT.
      *
       4231-CLFM-ARRAY-DATA-TO-CLIF.
      *
           MOVE WS-CLI-FMLY-REL-CD (WS-SUB)
                             TO RCLIF-CLI-FMLY-REL-CD.
           MOVE WS-CLI-REL-LVNG-QTY (WS-SUB)
                             TO RCLIF-CLI-REL-LVNG-QTY.
           MOVE WS-CLI-REL-DTH-QTY (WS-SUB)
                             TO RCLIF-CLI-REL-DTH-QTY.
           MOVE WS-CLI-REL-LVNG-AGE (WS-SUB)
                             TO RCLIF-CLI-REL-LVNG-AGE.
           MOVE WS-CLI-REL-DTH-AGE (WS-SUB)
                             TO RCLIF-CLI-REL-DTH-AGE.
557659*    MOVE WS-REL-HLTH-STATE-TXT (WS-SUB)
557659*                      TO RCLIF-REL-HLTH-STATE-TXT.
557659*    MOVE WS-HERED-DISORD-1-TXT (WS-SUB)
557659*                      TO RCLIF-HERED-DISORD-1-TXT.
557659*    MOVE WS-HERED-DISORD-2-TXT (WS-SUB)
557659*                      TO RCLIF-HERED-DISORD-2-TXT.
557659*    MOVE WS-DISORD-1-DTL-TXT (WS-SUB)
557659*                      TO RCLIF-DISORD-1-DTL-TXT.
557659*    MOVE WS-DISORD-2-DTL-TXT (WS-SUB)
557659*                      TO RCLIF-DISORD-2-DTL-TXT.
557659     MOVE WS-REL-HLTH-STATE-CD  (WS-SUB)
557659                       TO RCLIF-REL-HLTH-STATE-CD.
557659     MOVE WS-HERED-DISORD-1-CD  (WS-SUB)
557659                       TO RCLIF-HERED-DISORD-1-CD.
557659     MOVE WS-HERED-DISORD-2-CD  (WS-SUB)
557659                       TO RCLIF-HERED-DISORD-2-CD.
557659     MOVE WS-DISORD-1-DTL-IND (WS-SUB)
557659                       TO RCLIF-DISORD-1-DTL-IND.
557659     MOVE WS-DISORD-2-DTL-IND (WS-SUB)
557659                       TO RCLIF-DISORD-2-DTL-IND.
      *
           IF WS-CLIF-WRITE
               PERFORM  CLIF-1000-WRITE
                   THRU CLIF-1000-WRITE-X
           ELSE
               PERFORM  CLIF-2000-REWRITE
                   THRU CLIF-2000-REWRITE-X
557660     END-IF.

       4231-CLFM-ARRAY-DATA-TO-CLIF-X.
           EXIT.
      *
       5000-EDIT-FIELDS.
      *
           MOVE '0'   TO WS-EDIT-OK-SW.
      *
           PERFORM  5050-CHECK-RELATIONS
               THRU 5050-CHECK-RELATIONS-X.
      *
           PERFORM  5800-EDIT-HISUN
               THRU 5800-EDIT-HISUN-X.
      *
           PERFORM  5100-EDIT-FAMILY-HEALTH
               THRU 5100-EDIT-FAMILY-HEALTH-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 4.
      *
           PERFORM  5900-EDIT-HISHD
               THRU 5900-EDIT-HISHD-X.
      *
           PERFORM  5600-EDIT-HERED-DISORDER
               THRU 5600-EDIT-HERED-DISORDER-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 4.
      *
014653     PERFORM  5610-SET-HERED-DISORD-IND
014653         THRU 5610-SET-HERED-DISORD-IND-X.
014653
           PERFORM  6000-CROSS-EDIT
               THRU 6000-CROSS-EDIT-X.
      *
       5000-EDIT-FIELDS-X.
           EXIT.
      *****************************************************************
      *  DETERMINE WHERE EACH RELATION IS ON THE FILE
      *****************************************************************
       5050-CHECK-RELATIONS.
      *
016537*    IF WS-REL-TO-INSRD-FATHER (1)
016537*        MOVE 1   TO WS-FATHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-MOTHER (1)
016537*        MOVE 1   TO WS-MOTHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-SISTER (1)
016537*        MOVE 1   TO WS-SISTER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-BROTHER (1)
016537*        MOVE 1   TO WS-BROTHER-SUB
016537*    END-IF.
016537*
016537*    IF WS-REL-TO-INSRD-MOTHER (2)
016537*        MOVE 2   TO WS-MOTHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-FATHER (2)
016537*        MOVE 2   TO WS-FATHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-SISTER (2)
016537*        MOVE 2   TO WS-SISTER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-BROTHER (2)
016537*        MOVE 2   TO WS-BROTHER-SUB
016537*    END-IF.
016537*
016537*    IF WS-REL-TO-INSRD-SISTER (3)
016537*        MOVE 3   TO WS-SISTER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-FATHER (3)
016537*        MOVE 3   TO WS-FATHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-MOTHER (3)
016537*        MOVE 3   TO WS-MOTHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-BROTHER (3)
016537*        MOVE 3   TO WS-BROTHER-SUB
016537*    END-IF.
016537*
016537*    IF WS-REL-TO-INSRD-BROTHER (4)
016537*        MOVE 4   TO WS-BROTHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-FATHER (4)
016537*        MOVE 4   TO WS-FATHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-MOTHER (4)
016537*        MOVE 4   TO WS-MOTHER-SUB
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-SISTER (4)
016537*        MOVE 4   TO WS-SISTER-SUB
016537*    END-IF.
016537*
016537     PERFORM
016537         VARYING J FROM 1 BY 1
016537         UNTIL J > 4
016537             EVALUATE TRUE
016537
016537                 WHEN WS-REL-TO-INSRD-FATHER (J)
016537                     MOVE J   TO WS-FATHER-SUB
016537
016537                 WHEN WS-REL-TO-INSRD-MOTHER (J)
016537                     MOVE J   TO WS-MOTHER-SUB
016537
016537                 WHEN WS-REL-TO-INSRD-SISTER (J)
016537                     MOVE J   TO WS-SISTER-SUB
016537
016537                 WHEN WS-REL-TO-INSRD-BROTHER (J)
016537                     MOVE J   TO WS-BROTHER-SUB
016537
016537             END-EVALUATE
016537     END-PERFORM.
      *
       5050-CHECK-RELATIONS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT FAMILY HEALTH ARRAY
      *      NUMLI, NUMDD ONLY ENTERED WHEN WS-SUB = 3 AND 4
      *****************************************************************
       5100-EDIT-FAMILY-HEALTH.

           PERFORM  5370-SET-RELA-4
               THRU 5370-SET-RELA-4-X.

           IF WS-SUB > 2
               PERFORM  5150-EDIT-NUMLI
                   THRU 5150-EDIT-NUMLI-X
               PERFORM  5250-EDIT-NUMDD
                   THRU 5250-EDIT-NUMDD-X
557660     END-IF.

           PERFORM  5350-EDIT-AGELV
               THRU 5350-EDIT-AGELV-X.

           PERFORM  5450-EDIT-AGEDT
               THRU 5450-EDIT-AGEDT-X.

           PERFORM  5550-EDIT-SHLTH
               THRU 5550-EDIT-SHLTH-X.

       5100-EDIT-FAMILY-HEALTH-X.
           EXIT.
      *
      *
       5150-EDIT-NUMLI.
      *
           IF MIR-CLI-REL-LVNG-QTY-T (WS-SUB) = SPACES
               MOVE WS-CLI-REL-LVNG-QTY (WS-REL-SUB)
                                            TO WS-N-99
               MOVE WS-N-99                 TO WS-PIC-99
               MOVE WS-PIC-99       TO MIR-CLI-REL-LVNG-QTY-T (WS-SUB)
               GO TO 5150-EDIT-NUMLI-X
557660     END-IF.
      *
           IF MIR-CLI-REL-LVNG-QTY-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO          TO WS-CLI-REL-LVNG-QTY (WS-REL-SUB)
               MOVE ZERO          TO WS-PIC-99
               MOVE WS-PIC-99     TO MIR-CLI-REL-LVNG-QTY-T (WS-SUB)
               GO TO 5150-EDIT-NUMLI-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-REL-LVNG-QTY-T (WS-SUB)  TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT  TO WS-N-99
               MOVE L0280-OUTPUT  TO WS-CLI-REL-LVNG-QTY (WS-REL-SUB)
               MOVE WS-N-99       TO WS-PIC-99
               MOVE WS-PIC-99     TO MIR-CLI-REL-LVNG-QTY-T (WS-SUB)
           ELSE
               MOVE 'NS05600004'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.
      *
       5150-EDIT-NUMLI-X.
           EXIT.
      *
      *
      *
      *
       5250-EDIT-NUMDD.
      *
           IF MIR-CLI-REL-DTH-QTY-T (WS-SUB) = SPACES
               MOVE WS-CLI-REL-DTH-QTY     (WS-REL-SUB)
                                            TO WS-N-99
               MOVE WS-N-99                 TO WS-PIC-99
               MOVE WS-PIC-99      TO MIR-CLI-REL-DTH-QTY-T (WS-SUB)
               GO TO 5250-EDIT-NUMDD-X
557660     END-IF.
      *
           IF MIR-CLI-REL-DTH-QTY-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO           TO WS-CLI-REL-DTH-QTY (WS-REL-SUB)
               MOVE ZERO           TO WS-PIC-99
               MOVE WS-PIC-99      TO MIR-CLI-REL-DTH-QTY-T (WS-SUB)
               GO TO 5250-EDIT-NUMDD-X
557660     END-IF.
      *
           MOVE 'N'                TO L0280-SIGN-IND.
           MOVE 0                  TO L0280-PRECISION.
           MOVE 2                  TO L0280-LENGTH.
           MOVE 2                  TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-REL-DTH-QTY-T (WS-SUB) TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT   TO WS-N-99
               MOVE L0280-OUTPUT   TO WS-CLI-REL-DTH-QTY (WS-REL-SUB)
               MOVE WS-N-99        TO WS-PIC-99
               MOVE WS-PIC-99      TO MIR-CLI-REL-DTH-QTY-T (WS-SUB)
           ELSE
               MOVE 'NS05600005'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.
      *
       5250-EDIT-NUMDD-X.
           EXIT.
      *****************************************************************
      *  AGE IF LIVING - ALL FIELDS ARE ENTERABLE
      *****************************************************************
      *
      *
       5350-EDIT-AGELV.
      *
           IF MIR-CLI-REL-LVNG-AGE-T (WS-SUB) = SPACES
               MOVE WS-CLI-REL-LVNG-AGE (WS-REL-SUB)
                                            TO WS-N-999
               MOVE WS-N-999                TO WS-PIC-999
               MOVE WS-PIC-999    TO MIR-CLI-REL-LVNG-AGE-T (WS-SUB)
               GO TO 5350-EDIT-AGELV-X
557660     END-IF.
      *
           IF MIR-CLI-REL-LVNG-AGE-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO          TO WS-CLI-REL-LVNG-AGE (WS-REL-SUB)
               MOVE ZERO          TO WS-PIC-999
               MOVE WS-PIC-999    TO MIR-CLI-REL-LVNG-AGE-T (WS-SUB)
               GO TO 5350-EDIT-AGELV-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-REL-LVNG-AGE-T (WS-SUB)  TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               IF L0280-OUTPUT > 120
                   MOVE 'NS05600016'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'              TO WS-EDIT-OK-SW

               ELSE
                   MOVE L0280-OUTPUT TO WS-N-999
                   MOVE L0280-OUTPUT
                     TO WS-CLI-REL-LVNG-AGE (WS-REL-SUB)
                   MOVE WS-N-999     TO WS-PIC-999
                   MOVE WS-PIC-999   TO MIR-CLI-REL-LVNG-AGE-T (WS-SUB)
557660         END-IF
           ELSE
               MOVE 'NS05600006'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW

557660     END-IF.

           IF L0280-OK
               IF MIR-CLI-REL-LVNG-AGE-T (WS-SUB) > ZEROS  AND
                  (WS-SUB = 1 OR 2)
                   MOVE 1          TO WS-CLI-REL-LVNG-QTY (WS-REL-SUB)
                   MOVE WS-CLI-REL-LVNG-QTY (WS-REL-SUB) TO WS-N-99
                   MOVE WS-N-99    TO WS-PIC-99
                   MOVE WS-PIC-99  TO MIR-CLI-REL-LVNG-QTY-T (WS-SUB)
557660         END-IF
557660     END-IF.
      *
      *
       5350-EDIT-AGELV-X.
           EXIT.
      *
      *
       5370-SET-RELA-4.
      *
016537*    IF WS-SUB = 1
016537*        MOVE WS-FATHER-SUB  TO WS-REL-SUB
016537*    ELSE
016537*    IF WS-SUB = 2
016537*        MOVE WS-MOTHER-SUB  TO WS-REL-SUB
016537*    ELSE
016537*    IF WS-SUB = 3
016537*        MOVE WS-SISTER-SUB  TO WS-REL-SUB
016537*    ELSE
016537*        MOVE WS-BROTHER-SUB TO WS-REL-SUB
016537*    END-IF.
016537*
016537     EVALUATE WS-SUB
016537
016537         WHEN 1
016537             MOVE WS-FATHER-SUB  TO WS-REL-SUB
016537
016537         WHEN 2
016537             MOVE WS-MOTHER-SUB  TO WS-REL-SUB
016537
016537         WHEN 3
016537             MOVE WS-SISTER-SUB  TO WS-REL-SUB
016537
016537         WHEN OTHER
016537             MOVE WS-BROTHER-SUB TO WS-REL-SUB
016537
016537     END-EVALUATE.
      *
       5370-SET-RELA-4-X.
           EXIT.
      *****************************************************************
      *  AGE AT DEATH - ALL FIELDS ARE ENTERABLE
      *****************************************************************
      *
       5450-EDIT-AGEDT.
      *
           IF MIR-CLI-REL-DTH-AGE-T (WS-SUB) = SPACES
               MOVE WS-CLI-REL-DTH-AGE     (WS-REL-SUB)
                                            TO WS-N-999
               MOVE WS-N-999                TO WS-PIC-999
               MOVE WS-PIC-999     TO MIR-CLI-REL-DTH-AGE-T (WS-SUB)
               GO TO 5450-EDIT-AGEDT-X
557660     END-IF.
      *
           IF MIR-CLI-REL-DTH-AGE-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO           TO WS-CLI-REL-DTH-AGE (WS-REL-SUB)
               MOVE ZERO           TO WS-PIC-999
               MOVE WS-PIC-999     TO MIR-CLI-REL-DTH-AGE-T (WS-SUB)
               GO TO 5450-EDIT-AGEDT-X
557660     END-IF.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-REL-DTH-AGE-T (WS-SUB)  TO L0280-INPUT-DATA.
           PERFORM  7800-NUMERIC-EDIT
               THRU 7800-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               IF L0280-OUTPUT > 120
                   MOVE 'NS05600017'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'              TO WS-EDIT-OK-SW

               ELSE
                   MOVE L0280-OUTPUT  TO WS-N-999
                   MOVE L0280-OUTPUT
                     TO WS-CLI-REL-DTH-AGE (WS-REL-SUB)
                   MOVE WS-N-999      TO WS-PIC-999
                   MOVE WS-PIC-999    TO MIR-CLI-REL-DTH-AGE-T (WS-SUB)
557660         END-IF
           ELSE
               MOVE 'NS05600007'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.

           IF L0280-OK
               IF MIR-CLI-REL-DTH-AGE-T (WS-SUB) > ZEROS AND
                 (WS-SUB = 1 OR 2)
                   MOVE 1          TO WS-CLI-REL-DTH-QTY (WS-REL-SUB)
                   MOVE 0          TO WS-CLI-REL-LVNG-QTY (WS-REL-SUB)
                   MOVE WS-CLI-REL-DTH-QTY (WS-REL-SUB) TO WS-N-99
                   MOVE WS-N-99    TO WS-PIC-99
                   MOVE WS-PIC-99  TO MIR-CLI-REL-DTH-QTY-T (WS-SUB)
                   MOVE WS-CLI-REL-LVNG-QTY (WS-REL-SUB) TO WS-N-99
                   MOVE WS-N-99    TO WS-PIC-99
                   MOVE WS-PIC-99  TO MIR-CLI-REL-LVNG-QTY-T (WS-SUB)
557660         END-IF
557660     END-IF.
      *
       5450-EDIT-AGEDT-X.
           EXIT.
      *****************************************************************
      *  STATE OF HEALTH - ALL FIELDS ARE ENTERABLE
      *****************************************************************
      *
       5550-EDIT-SHLTH.
      *
           IF MIR-REL-HLTH-STATE-CD-T (WS-SUB) = SPACES
557659*        MOVE WS-REL-HLTH-STATE-TXT (WS-REL-SUB)
557659         MOVE WS-REL-HLTH-STATE-CD  (WS-REL-SUB)
                                   TO MIR-REL-HLTH-STATE-CD-T (WS-SUB)
               IF  MIR-REL-HLTH-STATE-CD-T (WS-SUB) NOT = SPACES
               OR (WS-CLI-REL-LVNG-QTY (WS-SUB) = ZERO
               AND WS-CLI-REL-DTH-QTY (WS-SUB) = ZERO)
                   GO TO 5550-EDIT-SHLTH-X
557660         END-IF
557660     END-IF.
      *
           IF MIR-REL-HLTH-STATE-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES       TO MIR-REL-HLTH-STATE-CD-T (WS-SUB)
               IF  WS-CLI-REL-LVNG-QTY (WS-SUB) = ZERO
               AND WS-CLI-REL-DTH-QTY (WS-SUB) = ZERO
557659*            MOVE SPACES TO WS-REL-HLTH-STATE-TXT (WS-REL-SUB)
557659             MOVE SPACES TO WS-REL-HLTH-STATE-CD  (WS-REL-SUB)
                   GO TO 5550-EDIT-SHLTH-X
557660         END-IF
557660     END-IF.
      *
           MOVE MIR-REL-HLTH-STATE-CD-T (WS-SUB) TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  HLTH-1000-EDIT
               THRU HLTH-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM 5551-SET-UP-ERROR-14-15-PARM
                   THRU 5551-SET-UP-ERROR-14-15-PARM-X
               MOVE 'NS05600014'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE '1'              TO WS-EDIT-OK-SW
                   GO TO 5550-EDIT-SHLTH-X
557660         END-IF
557660     END-IF.
      *
           MOVE MIR-REL-HLTH-STATE-CD-T (WS-SUB) TO
557659*                           WS-REL-HLTH-STATE-TXT (WS-REL-SUB).
557659                            WS-REL-HLTH-STATE-CD  (WS-REL-SUB).
      *
       5550-EDIT-SHLTH-X.
           EXIT.
      *
       5551-SET-UP-ERROR-14-15-PARM.
      *
016537*    IF WS-SUB = 1
016537*        MOVE      '1'            TO WGLOB-MSG-PARM (1)
016537*    ELSE
016537*    IF WS-SUB = 2
016537*        MOVE      '2'            TO WGLOB-MSG-PARM (1)
016537*    ELSE
016537*    IF WS-SUB = 3
016537*        MOVE      '3'            TO WGLOB-MSG-PARM (1)
016537*    ELSE
016537*    IF WS-SUB = 4
016537*        MOVE      '4'            TO WGLOB-MSG-PARM (1)
016537*    ELSE
016537*    IF WS-SUB = 5
016537*        MOVE      '5'            TO WGLOB-MSG-PARM (1)
016537*    ELSE
016537*    IF WS-SUB = 6
016537*        MOVE      '6'            TO WGLOB-MSG-PARM (1)
016537*    ELSE
016537*    IF WS-SUB = 7
016537*        MOVE      '7'            TO WGLOB-MSG-PARM (1)
016537*    ELSE
016537*    IF WS-SUB = 8
016537*        MOVE      '8'            TO WGLOB-MSG-PARM (1)
016537*    END-IF.
016537*
016537     IF  WS-SUB >= 1
016537     AND WS-SUB <= 8
016537         MOVE WS-SUB              TO WS-SUB-X
016537         MOVE WS-SUB-X            TO WGLOB-MSG-PARM (1)
016537     END-IF.
      *
       5551-SET-UP-ERROR-14-15-PARM-X.
           EXIT.
      *****************************************************************
      *  HEREDITARY DISORDERS AND DETAILS
      *****************************************************************
       5600-EDIT-HERED-DISORDER.

           PERFORM  5670-SET-RELA-8
               THRU 5670-SET-RELA-8-X.



           PERFORM  5650-EDIT-HRDI1
               THRU 5650-EDIT-HRDI1-X.

           PERFORM  5750-EDIT-HDT1
               THRU 5750-EDIT-HDT1-X.

           PERFORM  5655-EDIT-HRDI2
               THRU 5655-EDIT-HRDI2-X.

           PERFORM  5755-EDIT-HDT2
               THRU 5755-EDIT-HDT2-X.

       5600-EDIT-HERED-DISORDER-X.
           EXIT.
      *
014653 5610-SET-HERED-DISORD-IND.
014653
014653     EVALUATE TRUE
014653         WHEN (WS-HERED-DISORD-1-CD (1) = SPACES)
014653         AND  (WS-HERED-DISORD-1-CD (2) = SPACES)
014653         AND  (WS-HERED-DISORD-1-CD (3) = SPACES)
014653         AND  (WS-HERED-DISORD-1-CD (4) = SPACES)
014653         AND  (WS-HERED-DISORD-2-CD (1) = SPACES)
014653         AND  (WS-HERED-DISORD-2-CD (2) = SPACES)
014653         AND  (WS-HERED-DISORD-2-CD (3) = SPACES)
014653         AND  (WS-HERED-DISORD-2-CD (4) = SPACES)
014653             MOVE 'N'                 TO RAPPF-HERED-DISORD-IND
014653             MOVE 'N'                 TO MIR-HERED-DISORD-IND
014653         WHEN (WS-HERED-DISORD-1-CD (1) NOT = SPACE)
014653         OR   (WS-HERED-DISORD-1-CD (2) NOT = SPACE)
014653         OR   (WS-HERED-DISORD-1-CD (3) NOT = SPACE)
014653         OR   (WS-HERED-DISORD-1-CD (4) NOT = SPACE)
014653         OR   (WS-HERED-DISORD-2-CD (1) NOT = SPACE)
014653         OR   (WS-HERED-DISORD-2-CD (2) NOT = SPACE)
014653         OR   (WS-HERED-DISORD-2-CD (3) NOT = SPACE)
014653         OR   (WS-HERED-DISORD-2-CD (4) NOT = SPACE)
014653             MOVE 'Y'                 TO RAPPF-HERED-DISORD-IND
014653             MOVE 'Y'                 TO MIR-HERED-DISORD-IND
014653     END-EVALUATE.
014653
014653 5610-SET-HERED-DISORD-IND-X.
014653     EXIT.
014653
      *
       5650-EDIT-HRDI1.
      *
           IF MIR-HERED-DISORD-1-CD-T (WS-SUB) = SPACES
557659*        MOVE WS-HERED-DISORD-1-TXT (WS-REL-SUB)
557659         MOVE WS-HERED-DISORD-1-CD  (WS-REL-SUB)
                                    TO MIR-HERED-DISORD-1-CD-T (WS-SUB)
               GO TO 5650-EDIT-HRDI1-X
557660     END-IF.
      *
           IF MIR-HERED-DISORD-1-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
557659*        MOVE SPACES TO WS-HERED-DISORD-1-TXT (WS-REL-SUB)
557659         MOVE SPACES TO WS-HERED-DISORD-1-CD  (WS-REL-SUB)
               GO TO 5650-EDIT-HRDI1-X
557660     END-IF.
      *
           MOVE MIR-HERED-DISORD-1-CD-T (WS-SUB) TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  HDIS-1000-EDIT
               THRU HDIS-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  5551-SET-UP-ERROR-14-15-PARM
                   THRU 5551-SET-UP-ERROR-14-15-PARM-X
               MOVE 'NS05600015'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-HERED-DISORD-1-CD-T (WS-SUB)
                                         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE '1'              TO WS-EDIT-OK-SW
                   GO TO 5650-EDIT-HRDI1-X
557660         END-IF
557660     END-IF.
      *
           MOVE MIR-HERED-DISORD-1-CD-T (WS-SUB) TO
557659*                         WS-HERED-DISORD-1-TXT (WS-REL-SUB).
557659                          WS-HERED-DISORD-1-CD  (WS-REL-SUB).
      *
       5650-EDIT-HRDI1-X.
           EXIT.

       5655-EDIT-HRDI2.
      *
           IF MIR-HERED-DISORD-2-CD-T (WS-SUB) = SPACES
557659*        MOVE WS-HERED-DISORD-2-TXT (WS-REL-SUB)
557659         MOVE WS-HERED-DISORD-2-CD  (WS-REL-SUB)
                                    TO MIR-HERED-DISORD-2-CD-T (WS-SUB)
               GO TO 5655-EDIT-HRDI2-X
557660     END-IF.
      *
           IF MIR-HERED-DISORD-2-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
557659*        MOVE SPACES TO WS-HERED-DISORD-2-TXT (WS-REL-SUB)
557659         MOVE SPACES TO WS-HERED-DISORD-2-CD  (WS-REL-SUB)
               GO TO 5655-EDIT-HRDI2-X
557660     END-IF.
      *
           MOVE MIR-HERED-DISORD-2-CD-T (WS-SUB) TO WEDIT-ETBL-VALU-ID.
      *
           PERFORM  HDIS-1000-EDIT
               THRU HDIS-1000-EDIT-X.
      *
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  5551-SET-UP-ERROR-14-15-PARM
                   THRU 5551-SET-UP-ERROR-14-15-PARM-X
               MOVE 'NS05600015'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-HERED-DISORD-2-CD-T (WS-SUB)
                                         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE '1'              TO WS-EDIT-OK-SW
                   GO TO 5655-EDIT-HRDI2-X
557660         END-IF
557660     END-IF.
      *
            MOVE MIR-HERED-DISORD-2-CD-T (WS-SUB) TO
557659*                         WS-HERED-DISORD-2-TXT (WS-REL-SUB).
557659                          WS-HERED-DISORD-2-CD  (WS-REL-SUB).
      *
       5655-EDIT-HRDI2-X.
           EXIT.
      *
       5670-SET-RELA-8.

016537*    IF WS-SUB = 1
016537*        MOVE WS-FATHER-SUB  TO WS-REL-SUB
016537*    ELSE
016537*    IF WS-SUB = 2
016537*        MOVE WS-MOTHER-SUB  TO WS-REL-SUB
016537*    ELSE
016537*    IF WS-SUB = 3
016537*        MOVE WS-SISTER-SUB  TO WS-REL-SUB
016537*    ELSE
016537*    IF WS-SUB = 4
016537*        MOVE WS-BROTHER-SUB TO WS-REL-SUB
016537*    END-IF.
016537*
016537     EVALUATE WS-SUB
016537
016537         WHEN 1
016537             MOVE WS-FATHER-SUB  TO WS-REL-SUB
016537
016537         WHEN 2
016537             MOVE WS-MOTHER-SUB  TO WS-REL-SUB
016537
016537         WHEN 3
016537             MOVE WS-SISTER-SUB  TO WS-REL-SUB
016537
016537         WHEN 4
016537             MOVE WS-BROTHER-SUB TO WS-REL-SUB
016537
016537     END-EVALUATE.

      *
       5670-SET-RELA-8-X.
           EXIT.
      *****************************************************************
      *  HEREDITARY DISORDER DETAILS IND - MUST BE Y N OR BLANK
      *****************************************************************
      *
       5750-EDIT-HDT1.
      *
           IF MIR-DISORD-1-DTL-IND-T (WS-SUB) = SPACES
557659*            MOVE WS-DISORD-1-DTL-TXT (WS-REL-SUB)
557659             MOVE WS-DISORD-1-DTL-IND (WS-REL-SUB)
                           TO MIR-DISORD-1-DTL-IND-T (WS-SUB)
               GO TO 5750-EDIT-HDT1-X
557660     END-IF.
      *
           IF MIR-DISORD-1-DTL-IND-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
557659*        MOVE SPACES TO WS-DISORD-1-DTL-TXT (WS-REL-SUB)
557659         MOVE SPACES TO WS-DISORD-1-DTL-IND (WS-REL-SUB)
               GO TO 5750-EDIT-HDT1-X
557660     END-IF.
      *
           MOVE MIR-DISORD-1-DTL-IND-T (WS-SUB) TO WS-TEST-HDET.
      *
           IF WS-HDET-OK
               MOVE MIR-DISORD-1-DTL-IND-T (WS-SUB)
557659*                    TO WS-DISORD-1-DTL-TXT (WS-REL-SUB)
557659                     TO WS-DISORD-1-DTL-IND (WS-REL-SUB)
           ELSE
               MOVE 'NS05600008'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-DISORD-1-DTL-IND-T (WS-SUB)
557659*                    TO WS-DISORD-1-DTL-TXT (WS-REL-SUB)
557659                     TO WS-DISORD-1-DTL-IND (WS-REL-SUB)
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5750-EDIT-HDT1-X.
           EXIT.
      *
       5755-EDIT-HDT2.
      *
           IF MIR-DISORD-2-DTL-IND-T (WS-SUB) = SPACES
557659*        MOVE WS-DISORD-2-DTL-TXT (WS-REL-SUB)
557659         MOVE WS-DISORD-2-DTL-IND (WS-REL-SUB)
                                 TO MIR-DISORD-2-DTL-IND-T (WS-SUB)
               GO TO 5755-EDIT-HDT2-X
557660     END-IF.
      *
           IF MIR-DISORD-2-DTL-IND-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
557659*        MOVE SPACES TO WS-DISORD-2-DTL-TXT (WS-REL-SUB)
557659         MOVE SPACES TO WS-DISORD-2-DTL-IND (WS-REL-SUB)
               GO TO 5755-EDIT-HDT2-X
557660     END-IF.
      *
           MOVE MIR-DISORD-2-DTL-IND-T (WS-SUB) TO WS-TEST-HDET.
      *
           IF WS-HDET-OK
               MOVE MIR-DISORD-2-DTL-IND-T (WS-SUB)
557659*                    TO WS-DISORD-2-DTL-TXT (WS-REL-SUB)
557659                     TO WS-DISORD-2-DTL-IND (WS-REL-SUB)
           ELSE
               MOVE 'NS05600008'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
                   MOVE MIR-DISORD-2-DTL-IND-T (WS-SUB)
557659*                        TO WS-DISORD-2-DTL-TXT (WS-REL-SUB)
557659                         TO WS-DISORD-2-DTL-IND (WS-REL-SUB)
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
       5755-EDIT-HDT2-X.
           EXIT.
      *

       5800-EDIT-HISUN.

           IF MIR-HIST-UNKNWN-IND = SPACES
               MOVE RAPPF-HIST-UNKNWN-IND  TO MIR-HIST-UNKNWN-IND
               GO TO 5800-EDIT-HISUN-X
557660     END-IF.

           IF MIR-HIST-UNKNWN-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE TO MIR-HIST-UNKNWN-IND
               MOVE SPACE TO RAPPF-HIST-UNKNWN-IND
               GO TO 5800-EDIT-HISUN-X
557660     END-IF.

           MOVE MIR-HIST-UNKNWN-IND TO WS-TEST-YES-NO.
           IF NOT WS-TEST-YES-NO-OK
      *** MSG (S) HISTORY UNKNOWN SWITCH MUST BE BLANK, Y OR N
               MOVE 'NS05600018'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
               GO TO 5800-EDIT-HISUN-X
557660     END-IF.

           MOVE MIR-HIST-UNKNWN-IND TO RAPPF-HIST-UNKNWN-IND.

      *** DEFAULT HEREDITY HISTORY IND BASED ON FAMILY HISTORY IND

           IF RAPPF-HIST-UNKNOWN
           AND RAPPF-HERED-DISORD-IND  = SPACE
               MOVE 'N'   TO RAPPF-HERED-DISORD-IND
557660     END-IF.

       5800-EDIT-HISUN-X.
           EXIT.


       5900-EDIT-HISHD.

           IF MIR-HERED-DISORD-IND = SPACES
               MOVE RAPPF-HERED-DISORD-IND  TO MIR-HERED-DISORD-IND
               GO TO 5900-EDIT-HISHD-X
557660     END-IF.

           IF MIR-HERED-DISORD-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE TO MIR-HERED-DISORD-IND
               MOVE SPACE TO RAPPF-HERED-DISORD-IND
               GO TO 5900-EDIT-HISHD-X
557660     END-IF.

           MOVE MIR-HERED-DISORD-IND TO WS-TEST-YES-NO.
           IF NOT WS-TEST-YES-NO-OK
      *** MSG (S) HISTORY OF HEREDITY DISORDER IND MUST BE BLANK, Y OR N
               MOVE 'NS05600019'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
               GO TO 5900-EDIT-HISHD-X
557660     END-IF.

           MOVE MIR-HERED-DISORD-IND TO RAPPF-HERED-DISORD-IND.

       5900-EDIT-HISHD-X.
           EXIT.
      *
      *
       5990-CHECK-FOR-DATA-TO-WRITE.

           PERFORM  5994-CHECK-SINGLE-SUB-DATA
               THRU 5994-CHECK-SINGLE-SUB-DATA-X
            VARYING WS-SUB FROM 1 BY 1
              UNTIL WS-SUB > 4.


       5990-CHECK-FOR-DATA-TO-WRITE-X.
           EXIT.

       5994-CHECK-SINGLE-SUB-DATA.

555206*    IF MIR-CLI-REL-LVNG-QTY-T (WS-SUB)  > ZERO
555206*    OR MIR-CLI-REL-DTH-QTY-T (WS-SUB)  > ZERO
555206*    OR MIR-CLI-REL-LVNG-AGE-T (WS-SUB)  > ZERO
555206*    OR MIR-CLI-REL-DTH-AGE-T (WS-SUB)  > ZERO
555206*    OR MIR-REL-HLTH-STATE-CD-T (WS-SUB)  NOT = SPACES
555206*        MOVE 'Y'  TO WS-CLIF-DATA-SW
555206*        MOVE 'Y'  TO WS-CLIF-DATA-THIS-LINE (WS-SUB).

           PERFORM  5670-SET-RELA-8
               THRU 5670-SET-RELA-8-X.

           IF MIR-HERED-DISORD-1-CD-T (WS-SUB) NOT = SPACES
           OR MIR-DISORD-1-DTL-IND-T (WS-SUB)  NOT = SPACES
           OR MIR-HERED-DISORD-2-CD-T (WS-SUB) NOT = SPACES
           OR MIR-DISORD-2-DTL-IND-T (WS-SUB)  NOT = SPACES
               IF MIR-HERED-DISORD-1-CD-T (WS-SUB) =
                                           EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES TO MIR-HERED-DISORD-1-CD-T (WS-SUB)
               END-IF
               IF MIR-DISORD-1-DTL-IND-T (WS-SUB) =
                                           EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES TO MIR-DISORD-1-DTL-IND-T (WS-SUB)
               END-IF
               IF MIR-HERED-DISORD-2-CD-T (WS-SUB) =
                                           EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES TO MIR-HERED-DISORD-2-CD-T (WS-SUB)
               END-IF
               IF MIR-DISORD-2-DTL-IND-T (WS-SUB) =
                                           EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES TO MIR-DISORD-2-DTL-IND-T (WS-SUB)
               END-IF
555206*        MOVE 'Y' TO WS-CLIF-DATA-SW
555206*        MOVE 'Y' TO WS-CLIF-DATA-THIS-LINE (WS-REL-SUB)
557660     END-IF.

       5994-CHECK-SINGLE-SUB-DATA-X.
           EXIT.

      *
      *
      *

       6000-CROSS-EDIT.
      *
           IF WS-CLI-REL-LVNG-AGE (WS-FATHER-SUB) > ZERO
               MOVE 1  TO WS-CLI-REL-LVNG-QTY (WS-FATHER-SUB)
               MOVE 1  TO WS-PIC-99
               MOVE WS-PIC-99  TO  MIR-CLI-REL-LVNG-QTY-T (1)
           ELSE
               MOVE 0  TO WS-CLI-REL-LVNG-QTY (WS-FATHER-SUB)
               MOVE 0  TO WS-PIC-99
               MOVE WS-PIC-99  TO  MIR-CLI-REL-LVNG-QTY-T (1)
557660     END-IF.
      *
           IF WS-CLI-REL-LVNG-AGE (WS-MOTHER-SUB) > ZERO
               MOVE 1  TO WS-CLI-REL-LVNG-QTY (WS-MOTHER-SUB)
               MOVE 1  TO WS-PIC-99
               MOVE WS-PIC-99  TO  MIR-CLI-REL-LVNG-QTY-T (2)
           ELSE
               MOVE 0  TO WS-CLI-REL-LVNG-QTY (WS-MOTHER-SUB)
               MOVE 0  TO WS-PIC-99
               MOVE WS-PIC-99  TO  MIR-CLI-REL-LVNG-QTY-T (2)
557660     END-IF.
      *
           IF WS-CLI-REL-DTH-AGE (WS-FATHER-SUB) > ZERO
               MOVE 1  TO WS-CLI-REL-DTH-QTY (WS-FATHER-SUB)
               MOVE 1  TO WS-PIC-99
               MOVE WS-PIC-99  TO  MIR-CLI-REL-DTH-QTY-T (1)
           ELSE
               MOVE 0  TO WS-CLI-REL-DTH-QTY (WS-FATHER-SUB)
               MOVE 0  TO WS-PIC-99
               MOVE WS-PIC-99  TO  MIR-CLI-REL-DTH-QTY-T (1)
557660     END-IF.
      *
           IF WS-CLI-REL-DTH-AGE (WS-MOTHER-SUB) > ZERO
               MOVE 1  TO WS-CLI-REL-DTH-QTY (WS-MOTHER-SUB)
               MOVE 1  TO WS-PIC-99
               MOVE WS-PIC-99  TO  MIR-CLI-REL-DTH-QTY-T (2)
           ELSE
               MOVE 0  TO WS-CLI-REL-DTH-QTY (WS-MOTHER-SUB)
               MOVE 0  TO WS-PIC-99
               MOVE WS-PIC-99  TO  MIR-CLI-REL-DTH-QTY-T (2)
557660     END-IF.
      *
           IF WS-CLI-REL-LVNG-QTY (WS-FATHER-SUB) > ZERO AND
              WS-CLI-REL-DTH-QTY (WS-FATHER-SUB) > ZERO
               MOVE 'NS05600009'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.
      *
           IF WS-CLI-REL-LVNG-QTY (WS-MOTHER-SUB) > ZERO AND
              WS-CLI-REL-DTH-QTY (WS-MOTHER-SUB) > ZERO
               MOVE 'NS05600009'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'              TO WS-EDIT-OK-SW
557660     END-IF.
      *
           IF WS-CLI-REL-LVNG-QTY (WS-SISTER-SUB) = ZERO AND
              WS-CLI-REL-LVNG-AGE (WS-SISTER-SUB) NOT = ZERO
               MOVE 'NS05600010'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
           IF WS-CLI-REL-LVNG-QTY (WS-BROTHER-SUB) = ZERO AND
              WS-CLI-REL-LVNG-AGE (WS-BROTHER-SUB) NOT = ZERO
               MOVE 'NS05600010'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
           IF WS-CLI-REL-DTH-QTY (WS-SISTER-SUB) = ZERO AND
              WS-CLI-REL-DTH-AGE (WS-SISTER-SUB) NOT = ZERO
               MOVE 'NS05600011'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
           IF WS-CLI-REL-DTH-QTY (WS-BROTHER-SUB) = ZERO AND
              WS-CLI-REL-DTH-AGE (WS-BROTHER-SUB) NOT = ZERO
               MOVE 'NS05600011'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-WARNING
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE '1'              TO WS-EDIT-OK-SW
557660         END-IF
557660     END-IF.
      *
           IF WS-CLI-REL-LVNG-QTY (WS-SISTER-SUB) NOT = ZERO AND
              WS-CLI-REL-LVNG-AGE (WS-SISTER-SUB) = ZERO
               MOVE 'NS05600012'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF WS-CLI-REL-LVNG-QTY (WS-BROTHER-SUB) NOT = ZERO AND
              WS-CLI-REL-LVNG-AGE (WS-BROTHER-SUB) = ZERO
               MOVE 'NS05600012'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF WS-CLI-REL-DTH-QTY (WS-SISTER-SUB) NOT = ZERO AND
              WS-CLI-REL-DTH-AGE (WS-SISTER-SUB) = ZERO
               MOVE 'NS05600013'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF WS-CLI-REL-DTH-QTY (WS-BROTHER-SUB) NOT = ZERO AND
              WS-CLI-REL-DTH-AGE (WS-BROTHER-SUB) = ZERO
               MOVE 'NS05600013'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RAPPF-HIST-UNKNOWN
               PERFORM
                   VARYING WS-SUB FROM 1 BY 1
                   UNTIL WS-SUB > 4
                   OR WS-CLI-REL-LVNG-QTY (WS-SUB) > ZERO
                   OR WS-CLI-REL-DTH-QTY (WS-SUB) > ZERO
                   OR WS-CLI-REL-LVNG-AGE (WS-SUB) > ZERO
                   OR WS-CLI-REL-DTH-AGE (WS-SUB) > ZERO
557659*            OR WS-REL-HLTH-STATE-TXT (WS-SUB) > SPACES
557659             OR WS-REL-HLTH-STATE-CD  (WS-SUB) > SPACES
557659*            OR WS-HERED-DISORD-1-TXT (WS-SUB) > SPACES
557659             OR WS-HERED-DISORD-1-CD  (WS-SUB) > SPACES
557659*            OR WS-HERED-DISORD-2-TXT (WS-SUB) > SPACES
557659             OR WS-HERED-DISORD-2-CD  (WS-SUB) > SPACES
557659*            OR WS-DISORD-1-DTL-TXT (WS-SUB) > SPACES
557659             OR WS-DISORD-1-DTL-IND (WS-SUB) > SPACES
557659*            OR WS-DISORD-2-DTL-TXT (WS-SUB) > SPACES
557659             OR WS-DISORD-2-DTL-IND (WS-SUB) > SPACES
015543             CONTINUE
               END-PERFORM
               IF WS-SUB NOT > 4
               OR RAPPF-HERED-DISORD-IND  = 'Y'
      *** MSG (S) FAMILY HISTORY IS UNKNOWN, DO NOT ENTER HISTORY
                   MOVE 'NS05600020'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           IF RAPPF-HERED-DISORD-NO
               PERFORM
                   VARYING WS-SUB FROM 1 BY 1
                   UNTIL WS-SUB > 4
557659*            OR WS-HERED-DISORD-1-TXT (WS-SUB) > SPACES
557659             OR WS-HERED-DISORD-1-CD  (WS-SUB) > SPACES
557659*            OR WS-HERED-DISORD-2-TXT (WS-SUB) > SPACES
557659             OR WS-HERED-DISORD-2-CD  (WS-SUB) > SPACES
557659*            OR WS-DISORD-1-DTL-TXT (WS-SUB) > SPACES
557659             OR WS-DISORD-1-DTL-IND (WS-SUB) > SPACES
557659*            OR WS-DISORD-2-DTL-TXT (WS-SUB) > SPACES
557659             OR WS-DISORD-2-DTL-IND (WS-SUB) > SPACES
015543             CONTINUE
               END-PERFORM
               IF WS-SUB NOT > 4
      *** MSG (S) NO HISTORY OF HEREDITY DISORDERS-DO NOT ENTER DETAILS
                   MOVE 'NS05600021'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
       6000-CROSS-EDIT-X.
           EXIT.
      /
      *****************************************************************
      *  CHECK FOR EXISTING CLIENT
      *****************************************************************
       7000-VALIDATE-ACCESS.
      *
           PERFORM  8100-BUILD-NAL-KEY
               THRU 8100-BUILD-NAL-KEY-X.
      *
           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.
      *
           IF  L2437-RETRN-CLI-NOT-FOUND
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               MOVE L2437-WCLI-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-VALIDATE-ACCESS-X
           END-IF.

           MOVE L2437-CLI-SEX-CD            TO L0620-CLI-SEX-CD.
557698*    MOVE L2437-CLI-CO-NM             TO L0620-CLI-CO-NM.
557698*    MOVE L2437-CLI-GIV-NM            TO L0620-CLI-GIV-NM.
557698*    MOVE L2437-CLI-SUR-NM            TO L0620-CLI-SUR-NM.
557698     MOVE L2437-CLI-ENTR-CO-NM        TO L0620-CLI-CO-NM
557698     MOVE L2437-CLI-ENTR-GIV-NM       TO L0620-CLI-GIV-NM
557698     MOVE L2437-CLI-ENTR-SUR-NM       TO L0620-CLI-SUR-NM
           MOVE L2437-CLI-MID-INIT-NM       TO L0620-CLI-MID-INIT-NM
           MOVE L2437-CLI-SFX-NM            TO L0620-CLI-SFX-NM

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
      *
           MOVE L0620-SCREEN-NAME           TO MIR-DV-INSRD-CLI-NM.
      *
           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE L2437-CLI-ID                TO L5600-CLI-ID.
016387*    SET L5600-GEN-CNSLDT-MSG-WARN    TO TRUE.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

       7000-VALIDATE-ACCESS-X.
           EXIT.
      /
      *****************************************************************
      *  NUMERIC EDIT
      *****************************************************************
       7800-NUMERIC-EDIT.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
       7800-NUMERIC-EDIT-X.
           EXIT.
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
025970     COPY XCPS0280.
           COPY XCPL0280.
      *
      *****************************************************************
      *  BUILD APPF KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************
       8000-BUILD-APPF-KEY.
      *
           MOVE MIR-CLI-ID        TO WAPPF-CLI-ID.
      *
       8000-BUILD-APPF-KEY-X.
           EXIT.
      *****************************************************************
      *  BUILD NAL KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************
       8100-BUILD-NAL-KEY.
      *
           MOVE MIR-CLI-ID        TO L2437-CLI-ID.
      *
       8100-BUILD-NAL-KEY-X.
           EXIT.
      /
      *
      *****************************************************************
      *  BUILD CLIF KEY SPECIFIC TO FAMILY RELATION CODE
      *****************************************************************
       8210-BUILD-SPECIFIC-CLIF-KEY.
           MOVE MIR-CLI-ID        TO WCLIF-CLI-ID.
016537*    IF WS-SUB = 1
016537*        MOVE 'F'    TO WCLIF-CLI-FMLY-REL-CD
016537*    ELSE
016537*    IF WS-SUB = 2
016537*        MOVE 'M'    TO WCLIF-CLI-FMLY-REL-CD
016537*    ELSE
016537*    IF WS-SUB = 3
016537*        MOVE 'S'    TO WCLIF-CLI-FMLY-REL-CD
016537*    ELSE
016537*    IF WS-SUB = 4
016537*        MOVE 'B'    TO WCLIF-CLI-FMLY-REL-CD
016537*    END-IF.
016537     EVALUATE WS-SUB
016537
016537         WHEN 1
016537             MOVE 'F'    TO WCLIF-CLI-FMLY-REL-CD
016537
016537         WHEN 2
016537             MOVE 'M'    TO WCLIF-CLI-FMLY-REL-CD
016537
016537         WHEN 3
016537             MOVE 'S'    TO WCLIF-CLI-FMLY-REL-CD
016537
016537         WHEN 4
016537             MOVE 'B'    TO WCLIF-CLI-FMLY-REL-CD
016537
016537     END-EVALUATE.
016537
       8210-BUILD-SPECIFIC-CLIF-KEY-X.
           EXIT.
      /

      ***************************
       8300-LOAD-CLIF-ARRAY.
      ***************************
      *
557660     PERFORM  8350-INIT-CLIF-ARRAY
557660         THRU 8350-INIT-CLIF-ARRAY-X
               VARYING WS-SUB FROM 1 BY 1
                 UNTIL WS-SUB > 4.
      *
           MOVE MIR-CLI-ID            TO WCLIF-CLI-ID.
           MOVE LOW-VALUES            TO WCLIF-CLI-FMLY-REL-CD.
      *
           MOVE WCLIF-KEY             TO WCLIF-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCLIF-ENDBR-CLI-FMLY-REL-CD.

           PERFORM  CLIF-1000-BROWSE
               THRU CLIF-1000-BROWSE-X.
      *
           IF NOT WCLIF-IO-OK
               GO TO 8300-LOAD-CLIF-ARRAY-X
557660     END-IF.
      *
           PERFORM  CLIF-2000-READ-NEXT
               THRU CLIF-2000-READ-NEXT-X.
      *
557660     PERFORM  8400-LOAD-FMLY-HIST
557660         THRU 8400-LOAD-FMLY-HIST-X
               UNTIL WCLIF-IO-EOF.
      *
           PERFORM  CLIF-3000-END-BROWSE
               THRU CLIF-3000-END-BROWSE-X.

       8300-LOAD-CLIF-ARRAY-X.
           EXIT.

      *
      ***************************
557660 8350-INIT-CLIF-ARRAY.
      ***************************
      *
016537*    IF WS-SUB = 1
016537*        MOVE 'F'  TO WS-CLI-FMLY-REL-CD (WS-SUB)
016537*    ELSE
016537*    IF WS-SUB = 2
016537*        MOVE 'M'  TO WS-CLI-FMLY-REL-CD (WS-SUB)
016537*    ELSE
016537*    IF WS-SUB = 3
016537*        MOVE 'S'  TO WS-CLI-FMLY-REL-CD (WS-SUB)
016537*    ELSE
016537*        MOVE 'B'  TO WS-CLI-FMLY-REL-CD (WS-SUB)
016537*    END-IF.
016537     EVALUATE WS-SUB
016537
016537         WHEN 1
016537             MOVE 'F'  TO WS-CLI-FMLY-REL-CD (WS-SUB)
016537
016537         WHEN 2
016537             MOVE 'M'  TO WS-CLI-FMLY-REL-CD (WS-SUB)
016537
016537         WHEN 3
016537             MOVE 'S'  TO WS-CLI-FMLY-REL-CD (WS-SUB)
016537
016537         WHEN 4
016537             MOVE 'B'  TO WS-CLI-FMLY-REL-CD (WS-SUB)
016537
016537     END-EVALUATE.
      *
           MOVE 0         TO WS-CLI-REL-LVNG-QTY (WS-SUB).
           MOVE 0         TO WS-CLI-REL-DTH-QTY (WS-SUB).
           MOVE 0         TO WS-CLI-REL-LVNG-AGE (WS-SUB).
           MOVE 0         TO WS-CLI-REL-DTH-AGE (WS-SUB).
557659*    MOVE SPACES    TO WS-REL-HLTH-STATE-TXT (WS-SUB).
557659*    MOVE SPACES    TO WS-HERED-DISORD-1-TXT (WS-SUB).
557659*    MOVE SPACES    TO WS-HERED-DISORD-2-TXT (WS-SUB).
557659*    MOVE SPACES    TO WS-DISORD-1-DTL-TXT (WS-SUB).
557659*    MOVE SPACES    TO WS-DISORD-2-DTL-TXT (WS-SUB).
557659     MOVE SPACES    TO WS-REL-HLTH-STATE-CD  (WS-SUB).
557659     MOVE SPACES    TO WS-HERED-DISORD-1-CD  (WS-SUB).
557659     MOVE SPACES    TO WS-HERED-DISORD-2-CD  (WS-SUB).
557659     MOVE SPACES    TO WS-DISORD-1-DTL-IND (WS-SUB).
557659     MOVE SPACES    TO WS-DISORD-2-DTL-IND (WS-SUB).
      *
557660 8350-INIT-CLIF-ARRAY-X.
           EXIT.
      *
      *
      *
      *************************
557660 8400-LOAD-FMLY-HIST.
      *************************
      *
016537*    IF RCLIF-CLI-FMLY-REL-CD  = 'F'
016537*        MOVE 1 TO WS-SUB
016537*    ELSE
016537*    IF RCLIF-CLI-FMLY-REL-CD  = 'M'
016537*        MOVE 2 TO WS-SUB
016537*    ELSE
016537*    IF RCLIF-CLI-FMLY-REL-CD  = 'S'
016537*        MOVE 3 TO WS-SUB
016537*    ELSE
016537*        MOVE 4 TO WS-SUB
016537*    END-IF.
016537*
016537     EVALUATE RCLIF-CLI-FMLY-REL-CD
016537
016537         WHEN 'F'
016537             MOVE 1 TO WS-SUB
016537
016537         WHEN 'M'
016537             MOVE 2 TO WS-SUB
016537
016537         WHEN 'S'
016537             MOVE 3 TO WS-SUB
016537
016537         WHEN OTHER
016537             MOVE 4 TO WS-SUB
016537
016537     END-EVALUATE.

           MOVE RCLIF-CLI-FMLY-REL-CD
                             TO WS-CLI-FMLY-REL-CD (WS-SUB).
           MOVE RCLIF-CLI-REL-LVNG-QTY
                             TO WS-CLI-REL-LVNG-QTY (WS-SUB).
           MOVE RCLIF-CLI-REL-DTH-QTY
                             TO WS-CLI-REL-DTH-QTY (WS-SUB).
           MOVE RCLIF-CLI-REL-LVNG-AGE
                             TO WS-CLI-REL-LVNG-AGE (WS-SUB).
           MOVE RCLIF-CLI-REL-DTH-AGE
                             TO WS-CLI-REL-DTH-AGE (WS-SUB).
557659*    MOVE RCLIF-REL-HLTH-STATE-TXT
557659*                      TO WS-REL-HLTH-STATE-TXT (WS-SUB).
557659*    MOVE RCLIF-HERED-DISORD-1-TXT
557659*                      TO WS-HERED-DISORD-1-TXT (WS-SUB).
557659*    MOVE RCLIF-HERED-DISORD-2-TXT
557659*                      TO WS-HERED-DISORD-2-TXT (WS-SUB).
557659*    MOVE RCLIF-DISORD-1-DTL-TXT
557659*                      TO WS-DISORD-1-DTL-TXT (WS-SUB).
557659*    MOVE RCLIF-DISORD-2-DTL-TXT
557659*                      TO WS-DISORD-2-DTL-TXT (WS-SUB).
557659     MOVE RCLIF-REL-HLTH-STATE-CD
557659                       TO WS-REL-HLTH-STATE-CD  (WS-SUB).
557659     MOVE RCLIF-HERED-DISORD-1-CD
557659                       TO WS-HERED-DISORD-1-CD  (WS-SUB).
557659     MOVE RCLIF-HERED-DISORD-2-CD
557659                       TO WS-HERED-DISORD-2-CD  (WS-SUB).
557659     MOVE RCLIF-DISORD-1-DTL-IND
557659                       TO WS-DISORD-1-DTL-IND (WS-SUB).
557659     MOVE RCLIF-DISORD-2-DTL-IND
557659                       TO WS-DISORD-2-DTL-IND (WS-SUB).
      *
           PERFORM  CLIF-2000-READ-NEXT
               THRU CLIF-2000-READ-NEXT-X.
      *
557660 8400-LOAD-FMLY-HIST-X.
           EXIT.
      *
      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.
      *
014221*    MOVE SPACES     TO MIR-PREV-UPDT-DT.
014221     MOVE SPACES     TO MIR-DV-PREV-UPDT-DT.
           MOVE SPACES     TO MIR-HIST-UNKNWN-IND.
           MOVE SPACES     TO MIR-HERED-DISORD-IND.
      *
           PERFORM  9150-BLANK-CLIF-FIELDS
               THRU 9150-BLANK-CLIF-FIELDS-X.
      *
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
       9150-BLANK-CLIF-FIELDS.
      *
           MOVE SPACES     TO MIR-CLI-REL-LVNG-QTY-G.
           MOVE SPACES     TO MIR-CLI-REL-DTH-QTY-G.
           MOVE SPACES     TO MIR-CLI-REL-LVNG-AGE-G.
           MOVE SPACES     TO MIR-CLI-REL-DTH-AGE-G.
           MOVE SPACES     TO MIR-REL-HLTH-STATE-CD-G.
           MOVE SPACES     TO MIR-HERED-DISORD-1-CD-G.
           MOVE SPACES     TO MIR-DISORD-1-DTL-IND-G.
           MOVE SPACES     TO MIR-HERED-DISORD-2-CD-G.
           MOVE SPACES     TO MIR-DISORD-2-DTL-IND-G.
      *
       9150-BLANK-CLIF-FIELDS-X.
           EXIT.
      *
      *
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.
      *
014221*    MOVE RAPPF-PREV-UPDT-DT      TO L1640-INTERNAL-DATE.
014221*    MOVE RAPPF-PREV-UPDT-TS      TO L1640-INTERNAL-DATE.
014221     MOVE RAPPF-PREV-UPDT-TS      TO WWKDT-INT-TS.
014221     MOVE WWKDT-INT-TS            TO L1640-INTERNAL-DATE.
      *
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
      *
014221*    MOVE L1640-EXTERNAL-DATE     TO MIR-PREV-UPDT-DT.
014221     MOVE L1640-EXTERNAL-DATE     TO MIR-DV-PREV-UPDT-DT.
           MOVE RAPPF-HIST-UNKNWN-IND   TO MIR-HIST-UNKNWN-IND.
           MOVE RAPPF-HERED-DISORD-IND  TO MIR-HERED-DISORD-IND.
      *
           PERFORM  9250-DATA-LINES
               THRU 9250-DATA-LINES-X
                    VARYING WS-SUB FROM 1 BY 1
                        UNTIL WS-SUB GREATER 4.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *
       9250-DATA-LINES.
      *
016537*    IF WS-REL-TO-INSRD-FATHER (WS-SUB)
016537*        MOVE WS-CLI-REL-LVNG-QTY (WS-SUB) TO WS-N-99
016537*        MOVE WS-N-99           TO WS-PIC-99
016537*        MOVE WS-PIC-99         TO MIR-CLI-REL-LVNG-QTY-T (1)
016537*        MOVE WS-CLI-REL-DTH-QTY (WS-SUB) TO WS-N-99
016537*        MOVE WS-N-99           TO WS-PIC-99
016537*        MOVE WS-PIC-99         TO MIR-CLI-REL-DTH-QTY-T (1)
016537*        MOVE WS-CLI-REL-LVNG-AGE (WS-SUB) TO WS-N-999
016537*        MOVE WS-N-999          TO WS-PIC-999
016537*        MOVE WS-PIC-999        TO MIR-CLI-REL-LVNG-AGE-T (1)
016537*        MOVE WS-CLI-REL-DTH-AGE (WS-SUB) TO WS-N-999
016537*        MOVE WS-N-999          TO WS-PIC-999
016537*        MOVE WS-PIC-999        TO MIR-CLI-REL-DTH-AGE-T (1)
557659*        MOVE WS-REL-HLTH-STATE-TXT (WS-SUB)
557659*                                  TO MIR-REL-HLTH-STATE-CD-T (1)
557659*        MOVE WS-HERED-DISORD-1-TXT (WS-SUB)
557659*                                  TO MIR-HERED-DISORD-1-CD-T (1)
557659*        MOVE WS-HERED-DISORD-2-TXT (WS-SUB)
557659*                                  TO MIR-HERED-DISORD-2-CD-T (1)
557659*        MOVE WS-DISORD-1-DTL-TXT     (WS-SUB)
557659*                                  TO MIR-DISORD-1-DTL-IND-T (1)
557659*        MOVE WS-DISORD-2-DTL-TXT     (WS-SUB)
557659*                                  TO MIR-DISORD-2-DTL-IND-T (1)
016537*        MOVE WS-REL-HLTH-STATE-CD  (WS-SUB)
016537*                                  TO  MIR-REL-HLTH-STATE-CD-T (1)
016537*        MOVE WS-HERED-DISORD-1-CD  (WS-SUB)
016537*                                  TO MIR-HERED-DISORD-1-CD-T (1)
016537*        MOVE WS-HERED-DISORD-2-CD  (WS-SUB)
016537*                                  TO MIR-HERED-DISORD-2-CD-T (1)
016537*        MOVE WS-DISORD-1-DTL-IND     (WS-SUB)
016537*                                  TO MIR-DISORD-1-DTL-IND-T (1)
016537*        MOVE WS-DISORD-2-DTL-IND     (WS-SUB)
016537*                                  TO MIR-DISORD-2-DTL-IND-T (1)
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-MOTHER (WS-SUB)
016537*        MOVE WS-CLI-REL-LVNG-QTY (WS-SUB) TO WS-N-99
016537*        MOVE WS-N-99           TO WS-PIC-99
016537*        MOVE WS-PIC-99         TO MIR-CLI-REL-LVNG-QTY-T (2)
016537*        MOVE WS-CLI-REL-DTH-QTY (WS-SUB) TO WS-N-99
016537*        MOVE WS-N-99           TO WS-PIC-99
016537*        MOVE WS-PIC-99         TO MIR-CLI-REL-DTH-QTY-T (2)
016537*        MOVE WS-CLI-REL-LVNG-AGE (WS-SUB) TO WS-N-999
016537*        MOVE WS-N-999          TO WS-PIC-999
016537*        MOVE WS-PIC-999        TO MIR-CLI-REL-LVNG-AGE-T (2)
016537*        MOVE WS-CLI-REL-DTH-AGE (WS-SUB) TO WS-N-999
016537*        MOVE WS-N-999          TO WS-PIC-999
016537*        MOVE WS-PIC-999        TO MIR-CLI-REL-DTH-AGE-T (2)
557659*        MOVE WS-REL-HLTH-STATE-TXT (WS-SUB)
557659*                                  TO MIR-REL-HLTH-STATE-CD-T (2)
557659*        MOVE WS-HERED-DISORD-1-TXT (WS-SUB)
557659*                                  TO MIR-HERED-DISORD-1-CD-T (2)
557659*        MOVE WS-HERED-DISORD-2-TXT (WS-SUB)
557659*                                  TO MIR-HERED-DISORD-2-CD-T (2)
557659*        MOVE WS-DISORD-1-DTL-TXT     (WS-SUB)
557659*                                  TO MIR-DISORD-1-DTL-IND-T (2)
557659*        MOVE WS-DISORD-2-DTL-TXT     (WS-SUB)
557659*                                  TO MIR-DISORD-2-DTL-IND-T (2)
016537*        MOVE WS-REL-HLTH-STATE-CD  (WS-SUB)
016537*                                  TO MIR-REL-HLTH-STATE-CD-T (2)
016537*        MOVE WS-HERED-DISORD-1-CD  (WS-SUB)
016537*                                  TO MIR-HERED-DISORD-1-CD-T (2)
016537*        MOVE WS-HERED-DISORD-2-CD  (WS-SUB)
016537*                                  TO MIR-HERED-DISORD-2-CD-T (2)
016537*        MOVE WS-DISORD-1-DTL-IND     (WS-SUB)
016537*                                  TO MIR-DISORD-1-DTL-IND-T (2)
016537*        MOVE WS-DISORD-2-DTL-IND     (WS-SUB)
016537*                                  TO MIR-DISORD-2-DTL-IND-T (2)
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-SISTER (WS-SUB)
016537*        MOVE WS-CLI-REL-LVNG-QTY (WS-SUB) TO WS-N-99
016537*        MOVE WS-N-99           TO WS-PIC-99
016537*        MOVE WS-PIC-99         TO MIR-CLI-REL-LVNG-QTY-T (3)
016537*        MOVE WS-CLI-REL-DTH-QTY (WS-SUB) TO WS-N-99
016537*        MOVE WS-N-99           TO WS-PIC-99
016537*        MOVE WS-PIC-99         TO MIR-CLI-REL-DTH-QTY-T (3)
016537*        MOVE WS-CLI-REL-LVNG-AGE (WS-SUB) TO WS-N-999
016537*        MOVE WS-N-999          TO WS-PIC-999
016537*        MOVE WS-PIC-999        TO MIR-CLI-REL-LVNG-AGE-T (3)
016537*        MOVE WS-CLI-REL-DTH-AGE (WS-SUB) TO WS-N-999
016537*        MOVE WS-N-999          TO WS-PIC-999
016537*        MOVE WS-PIC-999        TO MIR-CLI-REL-DTH-AGE-T (3)
557659*        MOVE WS-REL-HLTH-STATE-TXT (WS-SUB)
557659*                                  TO MIR-REL-HLTH-STATE-CD-T (3)
557659*        MOVE WS-HERED-DISORD-1-TXT (WS-SUB)
557659*                                  TO MIR-HERED-DISORD-1-CD-T (3)
557659*        MOVE WS-HERED-DISORD-2-TXT (WS-SUB)
557659*                                  TO MIR-HERED-DISORD-2-CD-T (3)
557659*        MOVE WS-DISORD-1-DTL-TXT     (WS-SUB)
557659*                                  TO MIR-DISORD-1-DTL-IND-T (3)
557659*        MOVE WS-DISORD-2-DTL-TXT     (WS-SUB)
557659*                                  TO MIR-DISORD-2-DTL-IND-T (3)
016537*        MOVE WS-REL-HLTH-STATE-CD  (WS-SUB)
016537*                                  TO MIR-REL-HLTH-STATE-CD-T (3)
016537*        MOVE WS-HERED-DISORD-1-CD  (WS-SUB)
016537*                                  TO MIR-HERED-DISORD-1-CD-T (3)
016537*        MOVE WS-HERED-DISORD-2-CD  (WS-SUB)
016537*                                  TO MIR-HERED-DISORD-2-CD-T (3)
016537*        MOVE WS-DISORD-1-DTL-IND     (WS-SUB)
016537*                                  TO MIR-DISORD-1-DTL-IND-T (3)
016537*        MOVE WS-DISORD-2-DTL-IND     (WS-SUB)
016537*                                  TO MIR-DISORD-2-DTL-IND-T (3)
016537*    ELSE
016537*    IF WS-REL-TO-INSRD-BROTHER (WS-SUB)
016537*        MOVE WS-CLI-REL-LVNG-QTY (WS-SUB) TO WS-N-99
016537*        MOVE WS-N-99           TO WS-PIC-99
016537*        MOVE WS-PIC-99         TO MIR-CLI-REL-LVNG-QTY-T (4)
016537*        MOVE WS-CLI-REL-DTH-QTY (WS-SUB) TO WS-N-99
016537*        MOVE WS-N-99           TO WS-PIC-99
016537*        MOVE WS-PIC-99         TO MIR-CLI-REL-DTH-QTY-T (4)
016537*        MOVE WS-CLI-REL-LVNG-AGE (WS-SUB) TO WS-N-999
016537*        MOVE WS-N-999          TO WS-PIC-999
016537*        MOVE WS-PIC-999        TO MIR-CLI-REL-LVNG-AGE-T (4)
016537*        MOVE WS-CLI-REL-DTH-AGE (WS-SUB) TO WS-N-999
016537*        MOVE WS-N-999          TO WS-PIC-999
016537*        MOVE WS-PIC-999        TO MIR-CLI-REL-DTH-AGE-T (4)
557659*        MOVE WS-REL-HLTH-STATE-TXT (WS-SUB)
557659*                                  TO MIR-REL-HLTH-STATE-CD-T (4)
557659*        MOVE WS-HERED-DISORD-1-TXT (WS-SUB)
557659*                                  TO MIR-HERED-DISORD-1-CD-T (4)
557659*        MOVE WS-HERED-DISORD-2-TXT (WS-SUB)
557659*                                  TO MIR-HERED-DISORD-2-CD-T (4)
557659*        MOVE WS-DISORD-1-DTL-TXT     (WS-SUB)
557659*                                  TO MIR-DISORD-1-DTL-IND-T (4)
557659*        MOVE WS-DISORD-2-DTL-TXT     (WS-SUB)
557659*                                  TO MIR-DISORD-2-DTL-IND-T (4)
016537*        MOVE WS-REL-HLTH-STATE-CD  (WS-SUB)
016537*                                  TO MIR-REL-HLTH-STATE-CD-T (4)
016537*        MOVE WS-HERED-DISORD-1-CD  (WS-SUB)
016537*                                  TO MIR-HERED-DISORD-1-CD-T (4)
016537*        MOVE WS-HERED-DISORD-2-CD  (WS-SUB)
016537*                                  TO MIR-HERED-DISORD-2-CD-T (4)
016537*        MOVE WS-DISORD-1-DTL-IND     (WS-SUB)
016537*                                  TO MIR-DISORD-1-DTL-IND-T (4)
016537*        MOVE WS-DISORD-2-DTL-IND     (WS-SUB)
016537*                                  TO MIR-DISORD-2-DTL-IND-T (4)
016537*    END-IF.
016537*
016537     EVALUATE TRUE
016537
016537         WHEN WS-REL-TO-INSRD-FATHER (WS-SUB)
016537              MOVE 1              TO J
016537
016537         WHEN WS-REL-TO-INSRD-MOTHER (WS-SUB)
016537              MOVE 2              TO J
016537
016537         WHEN WS-REL-TO-INSRD-SISTER (WS-SUB)
016537              MOVE 3              TO J
016537
016537         WHEN WS-REL-TO-INSRD-BROTHER (WS-SUB)
016537              MOVE 4              TO J
016537
016537     END-EVALUATE.
016537
016537     MOVE WS-CLI-REL-LVNG-QTY (WS-SUB)
016537                         TO WS-N-99.
016537     MOVE WS-N-99        TO WS-PIC-99.
016537     MOVE WS-PIC-99      TO MIR-CLI-REL-LVNG-QTY-T (J).
016537     MOVE WS-CLI-REL-DTH-QTY (WS-SUB)
016537                         TO WS-N-99.
016537     MOVE WS-N-99        TO WS-PIC-99.
016537     MOVE WS-PIC-99      TO MIR-CLI-REL-DTH-QTY-T (J).
016537     MOVE WS-CLI-REL-LVNG-AGE (WS-SUB)
016537                         TO WS-N-999.
016537     MOVE WS-N-999       TO WS-PIC-999.
016537     MOVE WS-PIC-999     TO MIR-CLI-REL-LVNG-AGE-T (J).
016537     MOVE WS-CLI-REL-DTH-AGE (WS-SUB)
016537                         TO WS-N-999.
016537     MOVE WS-N-999       TO WS-PIC-999.
016537     MOVE WS-PIC-999     TO MIR-CLI-REL-DTH-AGE-T (J).
016537     MOVE WS-REL-HLTH-STATE-CD  (WS-SUB)
016537                         TO  MIR-REL-HLTH-STATE-CD-T (J).
016537     MOVE WS-HERED-DISORD-1-CD  (WS-SUB)
016537                         TO MIR-HERED-DISORD-1-CD-T (J).
016537     MOVE WS-HERED-DISORD-2-CD  (WS-SUB)
016537                         TO MIR-HERED-DISORD-2-CD-T (J).
016537     MOVE WS-DISORD-1-DTL-IND     (WS-SUB)
016537                         TO MIR-DISORD-1-DTL-IND-T (J).
016537     MOVE WS-DISORD-2-DTL-IND     (WS-SUB)
016537                         TO MIR-DISORD-2-DTL-IND-T (J).
016537
       9250-DATA-LINES-X.
           EXIT.
      *
      *
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                    TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID             TO WGLOB-REF-CLIENT-NUMBER.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-WORK-INFO.
025970     INITIALIZE                         FREQUENTLY-USED-INDICES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     MOVE SPACES                        TO WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
028298 COPY CCPPFCCK.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY NCPEHDIS.
       COPY NCPEHLTH.
       COPY CCPS5600.
021930*COPY XCPS8090.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      /
      ****************************************************************
      * LINK COPYBOOKS                                               *
      ****************************************************************
025970 COPY CCPS0620.
       COPY CCPL0620.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
       COPY XCPPINIT.
       COPY XCPPEXIT.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY NCPAAPPF.
       COPY NCPNAPPF.
       COPY NCPUAPPF.
       COPY NCPACLIF.
       COPY NCPBCLIF.
555206 COPY NCPXCLIF.
       COPY NCPUCLIF.
       COPY NCPCAPPF.
       COPY NCPCCLIF.
      /
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.
      /
       COPY CCPNEDIT.
      /
      *****************************************************************
      *  ADMIN PROCESSING COPYBOOKS
      *****************************************************************
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM0560                     **
      *****************************************************************
