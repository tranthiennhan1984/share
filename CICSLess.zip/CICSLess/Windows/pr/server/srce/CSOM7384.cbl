      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM7384.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7384                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE POLT TABLE                               **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7384'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '7384'.
           05  WS-VALIDATE-SW                        PIC X(01).
               88  WS-VALIDATE-NOT-OK                VALUE 'N'.
               88  WS-VALIDATE-OK                    VALUE 'Y'.
           05  WS-SUB                                PIC S9(04) BINARY.
           05  WS-MAX-LINES                          PIC S9(04) BINARY.
               88  WS-MAX-LIST-LINES                 VALUE 11.
           05  WS-TAX-EFF-DT                         PIC X(10).
           05  WS-TAX-SEQ-NUM                        PIC 9(05).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOLT.
       COPY CCFRPOLT.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY CCWWINDX.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY CCWL2430.
       COPY CCWL0620.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7384.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7384'            TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000000'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------
       2000-LIST.
      *-----------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WS-VALIDATE-NOT-OK
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE L0620-INPUT-PARM-INFO
               IF  L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD           TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME          TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                     TO MIR-DV-OWN-CLI-NM
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  POLT-1000-BROWSE-PREV
               THRU POLT-1000-BROWSE-PREV-X.

           PERFORM  POLT-2000-READ-PREV
               THRU POLT-2000-READ-PREV-X.

           IF  WPOLT-IO-EOF
               PERFORM  POLT-3000-END-BROWSE-PREV
                   THRU POLT-3000-END-BROWSE-PREV-X
      *MSG: 'NO POLICY TAX ACTIVITIES FOUND'
               MOVE 'CS73840001'               TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                           TO WS-SUB.

           PERFORM  2010-BROWSE-POLT
               THRU 2010-BROWSE-POLT-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LINES
               OR      WPOLT-IO-EOF.

           IF  WPOLT-IO-EOF
               IF  MIR-POL-TAX-EFF-DT-T (01) = WWKDT-LOW-DT
                   MOVE SPACES                 TO MIR-POL-TAX-EFF-DT
               ELSE
                   MOVE MIR-POL-TAX-EFF-DT-T (01)
                                               TO MIR-POL-TAX-EFF-DT
               END-IF
               MOVE MIR-POL-TAX-SEQ-NUM-T (01) TO MIR-POL-TAX-SEQ-NUM
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'               TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS      TO TRUE
               PERFORM  9100-MOVE-RECORD-TO-KEY
                   THRU 9100-MOVE-RECORD-TO-KEY-X
      *MSG:    'TO VIEW MORE DATA PRESS ENTER'
               MOVE 'XS00000014'               TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  POLT-3000-END-BROWSE-PREV
               THRU POLT-3000-END-BROWSE-PREV-X.

       2000-LIST-X.
           EXIT.
      /
      *----------------
       2010-BROWSE-POLT.
      *----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  POLT-2000-READ-PREV
               THRU POLT-2000-READ-PREV-X.

           IF  WS-SUB > WS-MAX-LINES
           AND WPOLT-IO-OK
               IF  RPOLT-POL-TAX-EFF-DT = WWKDT-LOW-DT
                   MOVE SPACES                 TO MIR-POL-TAX-EFF-DT
               ELSE
                   MOVE RPOLT-POL-TAX-EFF-DT   TO L1640-INTERNAL-DATE
                   PERFORM  1640-8000-INTERNAL-TO-MIR
                       THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE    TO MIR-POL-TAX-EFF-DT
               END-IF
               MOVE RPOLT-POL-TAX-SEQ-NUM      TO L0290-INPUT-V00
               MOVE ZERO                       TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-TAX-SEQ-NUM
                                               TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-SUPPRESS         TO TRUE
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA          TO MIR-POL-TAX-SEQ-NUM
           END-IF.

       2010-BROWSE-POLT-X.
           EXIT.
      /
      *------------------
       2100-VALIDATE-KEYS.
      *------------------

           PERFORM  4110-EDIT-POL-ID
               THRU 4110-EDIT-POL-ID-X.

           PERFORM  4120-EDIT-TAX-EFF-DT
               THRU 4120-EDIT-TAX-EFF-DT-X.

           PERFORM  4130-EDIT-TAX-SEQ-NUM
               THRU 4130-EDIT-TAX-SEQ-NUM-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *----------------
       4110-EDIT-POL-ID.
      *----------------

           IF  MIR-POL-ID = SPACES
      *MSG: POLICY ID MUST BE ENTERED
               MOVE 'CS00000048'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

           MOVE  MIR-POL-ID                  TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
      *MSG: @2 RECORD (@1) NOT FOUND
               MOVE 'XS00000001'             TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY                 TO WGLOB-MSG-PARM (1)
               MOVE 'POL'                    TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

       4110-EDIT-POL-ID-X.
           EXIT.
      /
      *--------------------
       4120-EDIT-TAX-EFF-DT.
      *--------------------

           IF  MIR-POL-TAX-EFF-DT = SPACES
               IF  MIR-POL-TAX-SEQ-NUM NOT = ZEROS
      *MSG:        TO DISPLAY THE POLICY'S NON-PENDING RECORDS, 
      *            PLEASE ENTER AN EFFECTIVE DATE 
                   MOVE 'CS73840003'         TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
               MOVE WWKDT-LOW-DT             TO WS-TAX-EFF-DT
               GO TO 4120-EDIT-TAX-EFF-DT-X
           END-IF.

           MOVE MIR-POL-TAX-EFF-DT           TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      * MESSAGE - INVALID EFFECTIVE DATE - REENTER
               MOVE 'XS00000355'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE      TO WS-TAX-EFF-DT
           END-IF.

           IF  WS-TAX-EFF-DT  < RPOL-POL-ISS-EFF-DT
      * MSG: THE EFFECTIVE DATE IS EARLIER THAN THE POLICY ISSUE DATE
               MOVE 'CS73840005'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

       4120-EDIT-TAX-EFF-DT-X.
           EXIT.
      /
      *---------------------
       4130-EDIT-TAX-SEQ-NUM.
      *---------------------

           IF  MIR-POL-TAX-SEQ-NUM = SPACE
               MOVE 99999                    TO WS-TAX-SEQ-NUM
               GO TO 4130-EDIT-TAX-SEQ-NUM-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE LENGTH OF MIR-POL-TAX-SEQ-NUM
                                             TO L0280-LENGTH.
           MOVE ZERO                         TO L0280-PRECISION.
           MOVE MIR-POL-TAX-SEQ-NUM          TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT             TO WS-TAX-SEQ-NUM
               IF  WS-TAX-SEQ-NUM = ZERO
      *MSG:    SEQUENCE NUMBER MUST BE GREATER THAN ZERO
                   MOVE 'CS73840004'         TO WGLOB-MSG-REF-INFO
                   MOVE MIR-POL-TAX-SEQ-NUM  TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-VALIDATE-NOT-OK    TO TRUE
               END-IF
           ELSE
      *MSG:    THE SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'CS73840002'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-TAX-SEQ-NUM      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

       4130-EDIT-TAX-SEQ-NUM-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE HIGH-VALUES           TO WPOLT-KEY.
           MOVE MIR-POL-ID            TO WPOLT-POL-ID.
           MOVE WS-TAX-EFF-DT         TO WPOLT-POL-TAX-EFF-DT.
           MOVE WS-TAX-SEQ-NUM        TO WPOLT-POL-TAX-SEQ-NUM.
           MOVE WPOLT-KEY             TO WPOLT-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WPOLT-ENDBR-POL-TAX-EFF-DT.
           MOVE ZERO                  TO WPOLT-ENDBR-POL-TAX-SEQ-NUM.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-POL-TAX-EFF-DT-G.
           MOVE SPACES                TO MIR-POL-TAX-SEQ-NUM-G.
           MOVE SPACES                TO MIR-POL-TAX-STAT-CD-G.
           MOVE SPACES                TO MIR-POL-TAX-EVNT-CD-G.
           MOVE SPACES                TO MIR-POL-TAX-ACTV-CD-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *-----------------------
       9100-MOVE-RECORD-TO-KEY.
      *-----------------------

           MOVE RPOLT-POL-ID          TO MIR-POL-ID.

           IF  RPOLT-POL-TAX-EFF-DT = WWKDT-LOW-DT
               MOVE SPACES            TO MIR-POL-TAX-EFF-DT
           ELSE
               MOVE RPOLT-POL-TAX-EFF-DT
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-TAX-EFF-DT
           END-IF.

           MOVE RPOLT-POL-TAX-SEQ-NUM TO L0290-INPUT-V00.
           MOVE ZERO                  TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-TAX-SEQ-NUM-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS    TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA     TO MIR-POL-TAX-SEQ-NUM.

       9100-MOVE-RECORD-TO-KEY-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  RPOLT-POL-TAX-EFF-DT = WWKDT-LOW-DT
               MOVE SPACES            TO 
                                      MIR-POL-TAX-EFF-DT-T (WS-SUB)
           ELSE 
               MOVE RPOLT-POL-TAX-EFF-DT  
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE   
                                      TO MIR-POL-TAX-EFF-DT-T (WS-SUB)
           END-IF.

           MOVE RPOLT-POL-TAX-SEQ-NUM TO L0290-INPUT-V00.
           MOVE ZERO                  TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-TAX-SEQ-NUM-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS    TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA     TO MIR-POL-TAX-SEQ-NUM-T (WS-SUB).
           MOVE RPOLT-POL-TAX-STAT-CD TO MIR-POL-TAX-STAT-CD-T (WS-SUB).
           MOVE RPOLT-POL-TAX-EVNT-CD TO MIR-POL-TAX-EVNT-CD-T (WS-SUB).
           MOVE RPOLT-POL-TAX-ACTV-CD TO MIR-POL-TAX-ACTV-CD-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
           SET WS-MAX-LIST-LINES      TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
       COPY XCPL0280.
       COPY XCPS0280.
       COPY XCPL0290.
       COPY XCPS0290.
       COPY XCPL1640.
       COPY XCPS1640.
       COPY CCPS2430.
       COPY CCPL2430.
       COPY CCPS0620.
       COPY CCPL0620.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPVPOLT.
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM7384                     **
      *****************************************************************
