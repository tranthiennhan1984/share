      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4904.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4904                                         **
      **  REMARKS:  THIS MODULE PROVIDES A LIST OF ALL CLIENTS ON    **
      **            THE POLICY                                       **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       ORIGINAL - NEW FOR RELEASE 6.0                   **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019854**  6.3       CONVERT KEY TO UPPER CASE                        **
015703**  6.4       REMOVE CCWLPGA                                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024152**  6.5       PREVENT LOOPING IN CODESERVER                    **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4904'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUSINESS-FUNCTION                PIC X(04).
               88  WS-BUSINESS-FUNCTION-LIST       VALUE '4904'.
016548*    05  WS-SUB                              PIC S9(04) COMP SYNC.
016548     05  WS-SUB                              PIC S9(04)
016548                                             BINARY SYNC.
016548*    05  WS-DUP-SUB                          PIC S9(04) COMP SYNC.
016548     05  WS-DUP-SUB                          PIC S9(04)
016548                                             BINARY SYNC.
024152*    05  WS-MAX-LIST-LINES                   PIC 9(02) VALUE 50.
024152     05  WS-MAX-LIST-LINES                   PIC 9(02).
           05  WS-DUPLICATE-CLI-ID-SW              PIC X(01).
               88  WS-CLI-ID-FOUND                 VALUE 'Y'.
               88  WS-CLI-ID-NOT-FOUND             VALUE 'N'.
024152*    05  WS-CVGC-RETRN-CD                    PIC X(02).
024152*        88  WS-CVGC-RETRN-OK                VALUE '00'.
024152*        88  WS-CVGC-RETRN-ERROR             VALUE '99'.
024152*    05  WS-POLC-RETRN-CD                    PIC X(02).
024152*        88  WS-POLC-RETRN-OK                VALUE '00'.
024152*        88  WS-POLC-RETRN-ERROR             VALUE '99'.
024152*    05  WS-MORE-DATA-EXISTS-SW              PIC X(01).
024152*        88  WS-MORE-DATA-EXISTS-YES         VALUE 'Y'.
024152*        88  WS-MORE-DATA-EXISTS-NO          VALUE 'N'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY CCWWFRMT.
016537*COPY XCWEBLCH.
016537*COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCVGC.
       COPY CCFRCVGC.
      /
       COPY CCFWPOLC.
       COPY CCFRPOLC.
      /
015703*COPY CCWLPGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
       COPY CCWL0620.
028298 COPY CCWL2626.
      /
       COPY NCWL2437.
      /
019854 COPY XCWL0005.
016537*COPY XCWLDTLK.
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4904.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUSINESS-FUNCTION.

           EVALUATE TRUE

               WHEN WS-BUSINESS-FUNCTION-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4904'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE +1                          TO WS-SUB.

024152*    PERFORM  2100-BROWSE-FROM-CVGC
024152*        THRU 2100-BROWSE-FROM-CVGC-X.
024152*
024152     IF  MIR-DV-REFRESH-SCROLL
024152         PERFORM  2100-BROWSE-FROM-CVGC
024152             THRU 2100-BROWSE-FROM-CVGC-X
024152         IF  WGLOB-MORE-DATA-EXISTS
024152             GO TO 2000-LIST-X
024152         END-IF
024152     END-IF.
024152
024152*    IF  WS-MORE-DATA-EXISTS-YES
024152*        SET WGLOB-MORE-DATA-EXISTS   TO TRUE
024152*        SET MIR-RETRN-OK             TO TRUE
024152*        GO TO 2000-LIST-X
024152*    END-IF.
024152*
           PERFORM  2200-BROWSE-FROM-POLC
               THRU 2200-BROWSE-FROM-POLC-X.

024152*    IF  WS-CVGC-RETRN-ERROR
024152*    AND WS-POLC-RETRN-ERROR
024152*MSG: NO RECORDS FOUND TO DISPLAY
024152*        MOVE 'XS00000034'            TO WGLOB-MSG-REF-INFO
024152*        PERFORM  0260-1000-GENERATE-MESSAGE
024152*            THRU 0260-1000-GENERATE-MESSAGE-X
024152*        SET MIR-RETRN-RQST-FAILED TO TRUE
024152*        GO TO 2000-LIST-X
024152*    END-IF.
024152*
024152*    IF  WS-MORE-DATA-EXISTS-YES
024152*        SET WGLOB-MORE-DATA-EXISTS   TO TRUE
024152*    END-IF.
024152*
024152*    SET MIR-RETRN-OK                 TO TRUE.
024152*
       2000-LIST-X.
           EXIT.
      /
      *----------------------
       2100-BROWSE-FROM-CVGC.
      *----------------------

024152*    MOVE SPACES                      TO WS-CVGC-RETRN-CD.
024152*    SET  WS-MORE-DATA-EXISTS-NO      TO TRUE.
024152*
           PERFORM  7000-BUILD-CVGC-KEYS
               THRU 7000-BUILD-CVGC-KEYS-X.

           PERFORM  CVGC-1000-BROWSE
               THRU CVGC-1000-BROWSE-X.

024152*    IF  NOT WCVGC-IO-OK
024152*        SET WS-CVGC-RETRN-ERROR      TO TRUE
024152*        GO TO 2100-BROWSE-FROM-CVGC-X
024152*    END-IF.
024152*
           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

024152*    IF  WCVGC-IO-EOF
024152*        PERFORM  CVGC-3000-END-BROWSE
024152*            THRU CVGC-3000-END-BROWSE-X
024152*        SET WS-CVGC-RETRN-ERROR      TO TRUE
024152*        GO TO 2100-BROWSE-FROM-CVGC-X
024152*    END-IF.
024152*
           PERFORM  2110-BROWSE-CVGC
               THRU 2110-BROWSE-CVGC-X
            VARYING WS-SUB FROM WS-SUB BY 1
              UNTIL WS-SUB > WS-MAX-LIST-LINES
                 OR WCVGC-IO-EOF.

           IF  WCVGC-IO-EOF
               CONTINUE
           ELSE
024152*        SET WS-MORE-DATA-EXISTS-YES  TO TRUE
024152         SET WGLOB-MORE-DATA-EXISTS     TO TRUE
024152         MOVE RCVGC-CVG-NUM             TO MIR-CVG-NUM
024152         MOVE RCVGC-CVG-CLI-REL-TYP-CD  TO MIR-CVG-CLI-REL-TYP-CD
024152         MOVE RCVGC-INSRD-CLI-ID        TO MIR-INSRD-CLI-ID
           END-IF.

           PERFORM  CVGC-3000-END-BROWSE
               THRU CVGC-3000-END-BROWSE-X.

024152*    SET WS-CVGC-RETRN-OK             TO TRUE.
024152*
       2100-BROWSE-FROM-CVGC-X.
           EXIT.
      /
      *-----------------
       2110-BROWSE-CVGC.
      *-----------------

           PERFORM  9100-MOVE-CVGC-REC-TO-SCREEN
               THRU 9100-MOVE-CVGC-REC-TO-SCREEN-X.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       2110-BROWSE-CVGC-X.
           EXIT.
      /
      *----------------------
       2200-BROWSE-FROM-POLC.
      *----------------------

024152*    MOVE SPACES                      TO WS-POLC-RETRN-CD.
024152*    SET  WS-MORE-DATA-EXISTS-NO      TO TRUE.
024152*
024152     SET MIR-DV-FORWRD-SCROLL         TO TRUE.
024152
           PERFORM  7100-BUILD-POLC-KEYS
               THRU 7100-BUILD-POLC-KEYS-X.

           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

024152*    IF  NOT WPOLC-IO-OK
024152*        SET WS-POLC-RETRN-ERROR      TO TRUE
024152*        GO TO 2200-BROWSE-FROM-POLC-X
024152*    END-IF.
024152*
           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

024152*    IF  WPOLC-IO-EOF
024152*        PERFORM  POLC-3000-END-BROWSE
024152*            THRU POLC-3000-END-BROWSE-X
024152*        SET WS-POLC-RETRN-ERROR      TO TRUE
024152*        GO TO 2200-BROWSE-FROM-POLC-X
024152*    END-IF.
024152*
           PERFORM  2210-BROWSE-POLC
               THRU 2210-BROWSE-POLC-X
            VARYING WS-SUB FROM WS-SUB BY 1
              UNTIL WS-SUB > WS-MAX-LIST-LINES
                 OR WPOLC-IO-EOF.

           IF  WPOLC-IO-EOF
               CONTINUE
           ELSE
024152*        SET WS-MORE-DATA-EXISTS-YES  TO TRUE
024152         SET WGLOB-MORE-DATA-EXISTS    TO TRUE
024152         MOVE RPOLC-POL-CLI-REL-TYP-CD TO MIR-POL-CLI-REL-TYP-CD
024152         MOVE RPOLC-CLI-ID             TO MIR-CLI-ID
           END-IF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.

024152*    SET WS-POLC-RETRN-OK             TO TRUE.
024152*
       2200-BROWSE-FROM-POLC-X.
           EXIT.
      /
      *-----------------
       2210-BROWSE-POLC.
      *-----------------

           PERFORM  9200-MOVE-POLC-REC-TO-SCREEN
               THRU 9200-MOVE-POLC-REC-TO-SCREEN-X.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2210-BROWSE-POLC-X.
           EXIT.
      /
      *---------------------
       7000-BUILD-CVGC-KEYS.
      *---------------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE LOW-VALUES          TO WCVGC-KEY.
019854*    MOVE MIR-POL-ID          TO WCVGC-POL-ID.
019854     PERFORM  0005-1000-BUILD-PARM-INFO
019854         THRU 0005-1000-BUILD-PARM-INFO-X.
019854     MOVE MIR-POL-ID          TO L0005-INPUT-STRING.
019854     SET  L0005-FORCE-UPPER   TO TRUE.
019854     PERFORM  0005-1000-CONVERT-STRING
019854         THRU 0005-1000-CONVERT-STRING-X.
019854     IF  L0005-RETRN-OK
019854         MOVE L0005-OUTPUT-STRING
019854                              TO WCVGC-POL-ID
019854     ELSE
019854         MOVE MIR-POL-ID      TO WCVGC-POL-ID
019854     END-IF.

024152     IF  MIR-CVG-NUM NOT = SPACE
024152         MOVE MIR-CVG-NUM     TO WCVGC-CVG-NUM
024152     END-IF.
024152
024152     IF  MIR-CVG-CLI-REL-TYP-CD NOT = SPACE
024152         MOVE MIR-CVG-CLI-REL-TYP-CD
024152           TO WCVGC-CVG-CLI-REL-TYP-CD
024152     END-IF.
024152
024152     IF  MIR-INSRD-CLI-ID NOT = SPACE
024152         MOVE MIR-INSRD-CLI-ID
024152           TO WCVGC-INSRD-CLI-ID
024152     END-IF.
024152
           MOVE WCVGC-KEY           TO WCVGC-ENDBR-KEY.
           MOVE HIGH-VALUES         TO WCVGC-ENDBR-CVG-NUM.
           MOVE HIGH-VALUES         TO WCVGC-ENDBR-CVG-CLI-REL-TYP-CD.
           MOVE HIGH-VALUES         TO WCVGC-ENDBR-INSRD-CLI-ID.

       7000-BUILD-CVGC-KEYS-X.
           EXIT.
      /
      *---------------------
       7100-BUILD-POLC-KEYS.
      *---------------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE LOW-VALUES          TO WPOLC-KEY.
019854*    MOVE MIR-POL-ID          TO WPOLC-POL-ID.
019854     PERFORM  0005-1000-BUILD-PARM-INFO
019854         THRU 0005-1000-BUILD-PARM-INFO-X.
019854     MOVE MIR-POL-ID          TO L0005-INPUT-STRING.
019854     SET  L0005-FORCE-UPPER   TO TRUE.
019854     PERFORM  0005-1000-CONVERT-STRING
019854         THRU 0005-1000-CONVERT-STRING-X.
019854     IF  L0005-RETRN-OK
019854         MOVE L0005-OUTPUT-STRING
019854                              TO WPOLC-POL-ID
019854     ELSE
019854         MOVE MIR-POL-ID      TO WPOLC-POL-ID
019854     END-IF.

024152     IF  MIR-POL-CLI-REL-TYP-CD NOT = SPACE
024152         MOVE MIR-POL-CLI-REL-TYP-CD
024152           TO WPOLC-POL-CLI-REL-TYP-CD
024152     END-IF.
024152
024152     IF  MIR-CLI-ID NOT = SPACE
024152         MOVE MIR-CLI-ID      TO WPOLC-CLI-ID
024152     END-IF.
024152
           MOVE WPOLC-KEY           TO WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES         TO WPOLC-ENDBR-POL-CLI-REL-TYP-CD.
           MOVE HIGH-VALUES         TO WPOLC-ENDBR-CLI-ID.

       7100-BUILD-POLC-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES              TO MIR-DV-SBOX-CD-G.
           MOVE SPACES              TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *-----------------------------
       9100-MOVE-CVGC-REC-TO-SCREEN.
      *-----------------------------

      *
      * CHECK WHETHER THE CLIENT ID IS ALREADY LISTED OR NOT
      *
           IF  WS-SUB > 1
               SET WS-CLI-ID-NOT-FOUND  TO TRUE
               PERFORM  9110-CHECK-CVGC-DUP-CLI-ID
                   THRU 9110-CHECK-CVGC-DUP-CLI-ID-X
                VARYING WS-DUP-SUB FROM 1 BY 1
                  UNTIL WS-DUP-SUB = WS-SUB
                     OR WS-CLI-ID-FOUND
               IF  WS-CLI-ID-FOUND
                   COMPUTE WS-SUB  = WS-SUB - 1
                   GO TO 9100-MOVE-CVGC-REC-TO-SCREEN-X
               END-IF
           END-IF.

           MOVE RCVGC-INSRD-CLI-ID        TO MIR-DV-SBOX-CD-T (WS-SUB).
      *
      *  GET AND FORMAT THE CLIENT NAME
      *
           MOVE RCVGC-INSRD-CLI-ID        TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  L2437-RETRN-OK
               MOVE L2437-CLI-SEX-CD      TO L0620-CLI-SEX-CD
               MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
               MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
               MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
               MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME     TO MIR-DV-SBOX-DESC-TXT-T
                                             (WS-SUB)
           ELSE
               MOVE SPACES                TO MIR-DV-SBOX-DESC-TXT-T
                                             (WS-SUB)
           END-IF.

       9100-MOVE-CVGC-REC-TO-SCREEN-X.
           EXIT.
      /
      *---------------------------
       9110-CHECK-CVGC-DUP-CLI-ID.
      *---------------------------

           IF  RCVGC-INSRD-CLI-ID = MIR-DV-SBOX-CD-T (WS-DUP-SUB)
               SET WS-CLI-ID-FOUND        TO TRUE
           END-IF.

       9110-CHECK-CVGC-DUP-CLI-ID-X.
           EXIT.
      /
      *-----------------------------
       9200-MOVE-POLC-REC-TO-SCREEN.
      *-----------------------------

      *
      * CHECK WHETHER THE CLIENT ID IS ALREADY LISTED OR NOT
      *
           IF  WS-SUB > 1
               SET WS-CLI-ID-NOT-FOUND  TO TRUE
               PERFORM  9210-CHECK-POLC-DUP-CLI-ID
                   THRU 9210-CHECK-POLC-DUP-CLI-ID-X
                VARYING WS-DUP-SUB FROM 1 BY 1
                  UNTIL WS-DUP-SUB = WS-SUB
                     OR WS-CLI-ID-FOUND
               IF  WS-CLI-ID-FOUND
                   COMPUTE WS-SUB  = WS-SUB - 1
                   GO TO 9200-MOVE-POLC-REC-TO-SCREEN-X
               END-IF
           END-IF.

           MOVE RPOLC-CLI-ID              TO MIR-DV-SBOX-CD-T (WS-SUB).
      *
      *  GET AND FORMAT THE CLIENT NAME
      *
           MOVE RPOLC-CLI-ID              TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  L2437-RETRN-OK
               MOVE L2437-CLI-SEX-CD      TO L0620-CLI-SEX-CD
               MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
               MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
               MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
               MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME     TO MIR-DV-SBOX-DESC-TXT-T
                                             (WS-SUB)
           ELSE
               MOVE SPACES                TO MIR-DV-SBOX-DESC-TXT-T
                                             (WS-SUB)
           END-IF.

       9200-MOVE-POLC-REC-TO-SCREEN-X.
           EXIT.
      /
      *---------------------------
       9210-CHECK-POLC-DUP-CLI-ID.
      *---------------------------

           IF  RPOLC-CLI-ID = MIR-DV-SBOX-CD-T (WS-DUP-SUB)
               SET WS-CLI-ID-FOUND        TO TRUE
           END-IF.

       9210-CHECK-POLC-DUP-CLI-ID-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
      *
      * FOR POLICY RELATED TRANSACTION
      *
           SET  WGLOB-REF-POLICY          TO TRUE.

           MOVE MIR-POL-ID                TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970     PERFORM  0005-0000-INIT-PARM-INFO
025970         THRU 0005-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
023514     INITIALIZE WS-WORKING-STORAGE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUSINESS-FUNCTION.
023514
023514     COMPUTE WS-MAX-LIST-LINES = LENGTH OF MIR-DV-SBOX-CD-G
023514                               / LENGTH OF MIR-DV-SBOX-CD-T (1).
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      /
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
      /
019854 COPY XCPS0005.
019854 COPY XCPL0005.
019854/
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
       COPY CCPBCVGC.
      /
       COPY CCPBPOLC.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4904                     **
      *****************************************************************
