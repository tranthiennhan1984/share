      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7710.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7710                                         **
      **  REMARKS:  USRP - U.S. REPORTING TABLE RETRIEVE             **
      **            THIS MODULE RETRIEVES THE USRP TABLE             **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021367**  6.4       CHANGE FIELD NAMES FROM OTH TO OTHR              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7710'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '7710'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '7710'.
           05  WS-USRP-TAX-YR               PIC 9(4).
           05  WS-USRP-SEQ-NUM              PIC 9(4).
           05  WS-MIR-ZERO-AMT              PIC X(19).
           05  WS-MIR-ZERO-TAX-AMT          PIC X(13).
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '7710'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWLOCK.
       COPY CCWWINDX.
021930*COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWUSRP.
       COPY CCFRUSRP.
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
020478 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY CCWL0620.
       COPY CCWL2430.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7710.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7710'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------
       2000-RETRIEVE.
      *--------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  USRP-1000-READ-TWRK-TS
               THRU USRP-1000-READ-TWRK-TS-X.

           IF  NOT WUSRP-IO-OK
      *MSG:  REOCRD NOT FOUND
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               MOVE WUSRP-KEY            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           MOVE RPOL-SBSDRY-CO-ID        TO MIR-SBSDRY-CO-ID.
           PERFORM  5100-GET-CLI-NM
               THRU 5100-GET-CLI-NM-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       2000-RETRIEVE-X.
           EXIT.

      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  4110-EDIT-POL-ID
               THRU 4110-EDIT-POL-ID-X.

           PERFORM  4120-EDIT-TAX-YR
               THRU 4120-EDIT-TAX-YR-X.

           PERFORM  4130-EDIT-SEQ-NO
               THRU 4130-EDIT-SEQ-NO-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       4110-EDIT-POL-ID.
      *-----------------

           MOVE MIR-POL-ID           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
      *MSG:    POLICY (@1) DOES NOT EXIST
               MOVE 'CS77100001'  TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ID    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
           END-IF.

       4110-EDIT-POL-ID-X.
           EXIT.


      *-----------------
       4120-EDIT-TAX-YR.
      *-----------------

           MOVE MIR-USRP-TAX-YR             TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-TAX-YR   TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-USRP-TAX-YR
           ELSE
      *MSG: INVALID TAX YEAR
               MOVE 'CS77100003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4120-EDIT-TAX-YR-X.
           EXIT.


      *-----------------
       4130-EDIT-SEQ-NO.
      *-----------------

           MOVE MIR-USRP-SEQ-NUM      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-USRP-SEQ-NUM
                                            TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-USRP-SEQ-NUM
           ELSE
      *MSG: INVALID RECEIPT SEQUENCE NUMBER
               MOVE 'CS77100002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       4130-EDIT-SEQ-NO-X.
           EXIT.


      *----------------
       5100-GET-CLI-NM.
      *----------------

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           INITIALIZE L0620-INPUT-PARM-INFO.

           IF  L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM       TO L0620-CLI-SFX-NM
           END-IF.

           MOVE L2430-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME          TO MIR-DV-OWN-CLI-NM.

       5100-GET-CLI-NM-X.
           EXIT.


      /
      *---------------
       7000-BUILD-KEYS.
      *---------------

           MOVE MIR-POL-ID            TO WUSRP-POL-ID.
           MOVE WS-USRP-SEQ-NUM       TO WUSRP-USRP-SEQ-NUM.
           MOVE WS-USRP-TAX-YR        TO WUSRP-USRP-TAX-YR.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                  TO MIR-OUTPUT-AREA.

020874*    MOVE ZERO                    TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                    TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-1-AMT
                                        TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO WS-MIR-ZERO-AMT.


020874*    MOVE ZERO                    TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                    TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-LTAXWH-AMT
                                        TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO WS-MIR-ZERO-TAX-AMT.

           MOVE ZEROS                   TO MIR-USRP-DSTRB-PCT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-1-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-2-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-3-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-4-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-5-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-6-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-7-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-8-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-9-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-A-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-B-AMT.
           MOVE WS-MIR-ZERO-AMT         TO MIR-USRP-PMT-C-AMT.
           MOVE WS-MIR-ZERO-TAX-AMT     TO MIR-USRP-LTAXWH-AMT.
021367*    MOVE WS-MIR-ZERO-TAX-AMT     TO MIR-USRP-OTH-TAXWH-AMT.
021367     MOVE WS-MIR-ZERO-TAX-AMT     TO MIR-OTHR-TAXWH-AMT.


       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE  RUSRP-USRP-RETRN-TYP-CD   TO MIR-USRP-RETRN-TYP-CD.
           MOVE  RUSRP-CLI-ID              TO MIR-CLI-ID.
           MOVE  RUSRP-USRP-CLI-TAX-ID     TO MIR-USRP-CLI-TAX-ID.
           MOVE  RUSRP-USRP-TAX-ID-TYP-CD  TO MIR-USRP-TAX-ID-TYP-CD.
           MOVE  RUSRP-USRP-PNSN-QUALF-CD  TO MIR-USRP-PNSN-QUALF-CD.
           MOVE  RUSRP-USRP-NM-LN-1-TXT    TO MIR-USRP-NM-LN-1-TXT.
           MOVE  RUSRP-USRP-NM-LN-2-TXT    TO MIR-USRP-NM-LN-2-TXT.
           MOVE  RUSRP-USRP-ADDR-LN-TXT    TO MIR-USRP-ADDR-LN-TXT.
           MOVE  RUSRP-USRP-CITY-NM-TXT    TO MIR-USRP-CITY-NM-TXT.
           MOVE  RUSRP-USRP-CRNT-LOC-CD    TO MIR-USRP-CRNT-LOC-CD.
           MOVE  RUSRP-USRP-PSTL-CD        TO MIR-USRP-PSTL-CD.
           MOVE  RUSRP-USRP-FRGN-CTRY-IND  TO MIR-USRP-FRGN-CTRY-IND.
           MOVE  RUSRP-USRP-FRGN-CTRY-TXT  TO MIR-USRP-FRGN-CTRY-TXT.
           MOVE  RUSRP-USRP-IRS-DSTRB-CD   TO MIR-USRP-IRS-DSTRB-CD.
           MOVE  RUSRP-USRP-TAX-DTRMN-IND  TO MIR-USRP-TAX-DTRMN-IND.
           MOVE  RUSRP-USRP-IRA-SEP-IND    TO MIR-USRP-IRA-SEP-IND.
           MOVE  RUSRP-USRP-TOT-DSTRB-IND  TO MIR-USRP-TOT-DSTRB-IND.
           MOVE  RUSRP-USRP-COMB-RPT-CD    TO MIR-USRP-COMB-RPT-CD.
           MOVE  RUSRP-USRP-TIN-NOTI-CD    TO MIR-USRP-TIN-NOTI-CD.
           MOVE  RUSRP-USRP-SPCL-DATA-TXT  TO MIR-USRP-SPCL-DATA-TXT.
           MOVE  RUSRP-USRP-SRC-CD         TO MIR-USRP-SRC-CD.
           MOVE  RUSRP-USRP-PRT-STAT-CD    TO MIR-USRP-PRT-STAT-CD.
           MOVE  RUSRP-USRP-RPT-CD         TO MIR-USRP-RPT-CD.
           MOVE  RUSRP-USRP-STAT-CD        TO MIR-USRP-STAT-CD.
023437     MOVE  RUSRP-USRP-STATE-LOC-CD   TO MIR-USRP-STATE-LOC-CD.

           MOVE RUSRP-USRP-PRT-DT          TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE        TO MIR-USRP-PRT-DT.

020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-DSTRB-PCT.
020874     MOVE RUSRP-USRP-DSTRB-PCT     TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-DSTRB-PCT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-DSTRB-PCT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-1-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-1-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-1-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-1-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-2-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-2-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-2-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-2-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-3-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-3-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-3-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-3-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-4-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-4-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-4-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-4-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-5-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-5-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-5-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-5-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-6-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-6-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-6-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-6-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-7-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-7-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-7-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-7-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-8-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-8-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-8-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-8-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-9-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-9-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-9-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-9-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-A-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-A-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-A-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-A-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-B-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-B-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-B-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-B-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-PMT-C-AMT * 100.
020874     MOVE RUSRP-USRP-PMT-C-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-PMT-C-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-PMT-C-AMT.



020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-LTAXWH-AMT * 100.
020874     MOVE RUSRP-USRP-LTAXWH-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-USRP-LTAXWH-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-USRP-LTAXWH-AMT.


020874*    COMPUTE L0290-INPUT-NUMBER = RUSRP-USRP-OTH-TAXWH-AMT * 100.
021367*    MOVE RUSRP-USRP-OTH-TAXWH-AMT TO L0290-INPUT-V02.
021367     MOVE RUSRP-OTHR-TAXWH-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
021367*    MOVE LENGTH OF MIR-USRP-OTH-TAXWH-AMT
021367     MOVE LENGTH OF MIR-OTHR-TAXWH-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
021367*    MOVE L0290-OUTPUT-DATA        TO MIR-USRP-OTH-TAXWH-AMT.
021367     MOVE L0290-OUTPUT-DATA        TO MIR-OTHR-TAXWH-AMT.


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY USRP
                                '$VAR2' BY 'USRP'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
025970 COPY XCPS8090.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
       COPY CCPL0620.
       COPY CCPS2430.
       COPY CCPL2430.
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNUSRP.
       COPY CCPUUSRP.
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM7710                     *
      ****************************************************************
