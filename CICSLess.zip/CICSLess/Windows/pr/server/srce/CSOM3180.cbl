      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3180.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3180                                         **
      **  REMARKS:  PAAF - POLICY ACTIVITY AUDIT FIELD TABLE RETRIEVE**
      **            THIS MODULE RETRIEVES THE PAAF TABLE             **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3180'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '3180'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '3180'.
025970     05  WS-MAX-BR-CTR                PIC S9(04).      
025970         88  WS-MAX-BR-CTR-DEFAULT    VALUE +100.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '3180'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '3180'.
           05  WS-SEQ-NUM                   PIC S9(03).
025970*    05  WS-MAX-BR-CTR                PIC S9(04).      
           05  WS-SUB                       PIC S9(04) BINARY.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWINDX.
       COPY CCWWLOCK.
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPAAF.
       COPY CCFRPAAF.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY CCWL2430.
028298 COPY CCWL2626.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1646.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3180.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

023514*    PERFORM  9990-INIT-WORKING-STORAGE
023514*        THRU 9990-INIT-WORKING-STORAGE-X.
023514*
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3180'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  3200-EDIT-INPUT
               THRU 3200-EDIT-INPUT-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  6000-BUILD-KEY
               THRU 6000-BUILD-KEY-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: POLICY NOT FOUND
               MOVE 'XS00000070'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  PAAF-1000-BROWSE
               THRU PAAF-1000-BROWSE-X.

           PERFORM  PAAF-2000-READ-NEXT
               THRU PAAF-2000-READ-NEXT-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X
                 VARYING WS-SUB FROM 1 BY 1
                 UNTIL WS-SUB > WS-MAX-BR-CTR
                 OR    NOT WPAAF-IO-OK.

           IF  NOT WPAAF-IO-EOF
      *MSG: TO VIEW MORE DATA SELECT MORE
               MOVE 'XS00000014'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPAAF-POL-ID        TO MIR-POL-ID
               MOVE RPAAF-PAAFLD-GR-TS
                                     TO MIR-PAAFLD-GR-TS
               MOVE RPAAF-PAAFLD-SEQ-NUM
                                     TO MIR-PAAFLD-SEQ-NUM
               SET WGLOB-MORE-DATA-EXISTS
                                        TO TRUE
           ELSE
               IF  MIR-PAAFLD-SEQ-NUM-T (1) > SPACES
                   MOVE MIR-PAAFLD-SEQ-NUM-T (1)
                                     TO MIR-PAAFLD-SEQ-NUM
      *MSG: END OF FILE REACHED
                   MOVE 'XS00000025'    TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORD FOUND FOR DISPLAY
                   MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  PAAF-3000-END-BROWSE
               THRU PAAF-3000-END-BROWSE-X.

           PERFORM  9250-MOVE-OTHER-TO-SCREEN
               THRU 9250-MOVE-OTHER-TO-SCREEN-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *---------------------------
       3200-EDIT-INPUT.
      *---------------------------

           IF  MIR-PAAFLD-GR-TS = WWKDT-ZERO-TS
               MOVE 'CS31800002'      TO  WGLOB-MSG-REF-INFO
      *MSG: TIMESTAMP MUST BE ENTERED
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO  TRUE
               GO TO 3200-EDIT-INPUT-X
           ELSE
               PERFORM  1646-1000-BUILD-PARM-INFO
                   THRU 1646-1000-BUILD-PARM-INFO-X
               MOVE MIR-PAAFLD-GR-TS      TO L1646-TIMESTAMP
               PERFORM  1646-1000-EDIT-TIMESTAMP
                   THRU 1646-1000-EDIT-TIMESTAMP-X
               IF  L1646-EDIT-FAILED
                   SET WGLOB-RETURN-ERROR TO  TRUE
                   MOVE 'CS31800001'      TO  WGLOB-MSG-REF-INFO
      * MSG: INVALID TIMESTAMP
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR TO  TRUE
                   GO TO 3200-EDIT-INPUT-X
              END-IF
           END-IF.

           IF  MIR-PAAFLD-SEQ-NUM = ZEROS
           OR  MIR-PAAFLD-SEQ-NUM = SPACES
               MOVE 001                TO WS-SEQ-NUM
           ELSE
               MOVE ZERO               TO L0280-PRECISION
               MOVE 3                  TO L0280-LENGTH
               MOVE 3                  TO L0280-INPUT-SIZE
               MOVE MIR-PAAFLD-SEQ-NUM    TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT   TO WS-SEQ-NUM
               ELSE
                   MOVE 'CS31800003'      TO  WGLOB-MSG-REF-INFO
      * MSG: ' SEQUENCE NUMBER MUST BE NUMERIC
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR TO  TRUE
                   GO TO 3200-EDIT-INPUT-X
               END-IF
           END-IF.

       3200-EDIT-INPUT-X.
           EXIT.
      /
      *---------------
       6000-BUILD-KEY.
      *---------------

           MOVE MIR-POL-ID          TO WPAAF-POL-ID.
           MOVE MIR-POL-ID          TO WPOL-POL-ID.
           MOVE MIR-PAAFLD-GR-TS    TO WPAAF-PAAFLD-GR-TS.
           MOVE WS-SEQ-NUM          TO WPAAF-PAAFLD-SEQ-NUM.
           MOVE WPAAF-KEY           TO WPAAF-ENDBR-KEY.
           MOVE +999                TO WPAAF-ENDBR-PAAFLD-SEQ-NUM.

       6000-BUILD-KEY-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                   TO MIR-PAAFLD-SEQ-NUM-G.
           MOVE SPACE                   TO MIR-PAAFLD-FLD-ID-G.
           MOVE SPACE                   TO MIR-PAAFLD-VALU-TXT-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RPAAF-PAAFLD-SEQ-NUM      TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PAAFLD-SEQ-NUM
                                          TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                           TO MIR-PAAFLD-SEQ-NUM-T          (WS-SUB).
           MOVE RPAAF-PAAFLD-FLD-ID  TO MIR-PAAFLD-FLD-ID-T (WS-SUB).
           MOVE RPAAF-PAAFLD-VALU-TXT-TXT
                           TO MIR-PAAFLD-VALU-TXT-T         (WS-SUB).

           PERFORM  PAAF-2000-READ-NEXT
               THRU PAAF-2000-READ-NEXT-X.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9250-MOVE-OTHER-TO-SCREEN.
      *--------------------------

           MOVE RPOL-SBSDRY-CO-ID        TO MIR-SBSDRY-CO-ID.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           MOVE L2430-CLI-NM-COMPRESSED  TO MIR-DV-OWN-CLI-NM.

       9250-MOVE-OTHER-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  WS-TWRK-KEY-DEFAULT     TO TRUE.
025970     SET  WS-MAX-BR-CTR-DEFAULT   TO TRUE.
           SET  MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970*    MOVE +100                    TO WS-MAX-BR-CTR.
           MOVE 001                     TO WS-SEQ-NUM.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
025970 COPY XCPS8090.
       COPY CCPS2430.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2430.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPS1646.
       COPY XCPL1646.
      /
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBPAAF.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3080                     *
      ****************************************************************
