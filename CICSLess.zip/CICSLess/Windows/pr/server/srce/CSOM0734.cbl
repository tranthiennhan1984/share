      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0734.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0734                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE LIST FUNCTION           **
      **            FOR THE GUIDELINE ACTIVITY PREMIUM ACTIVITY      **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0734'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-CONSTANT-FIELDS.
           05  WS-MAX-LIST-LINES                 PIC S9(04) BINARY.
               88  WS-MAX-LIST-LINES-DEFAULT
                                                 VALUE 100.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-LIST               VALUE '0734'.
           05  WS-VALIDATE-SW                    PIC X(01).
               88  WS-VALIDATE-NOT-OK            VALUE 'N'.
               88  WS-VALIDATE-OK                VALUE 'Y'.
           05  WS-SUB                            PIC S9(5) COMP-3.
           05  WS-EFF-DT-INT                     PIC X(10).
           05  WS-CVG-NUM                        PIC X(02).
           05  WS-CVG-NUM-N                      REDEFINES
               WS-CVG-NUM                        PIC 9(02).
           05  WS-SEQ-NUM                        PIC 9(03).
           05  WS-FILTER-CVG-NUM                 PIC X(02).

       COPY XCWLCOMM REPLACING '$VAR1' BY '0734'.
           15  LCOMM-TWRK-CVG-NUM                PIC X(02).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
       COPY XCWWCNST.
       COPY XCWWCVGM.
       COPY XCWWWKDT.
       COPY XCWLDTLK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.

       COPY CCFWGPOL.
       COPY CCFRGPOL.

       COPY CCFWGCVG.
       COPY CCFRGCVG.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
      /
       COPY CCWL0620.
       COPY CCWL2430.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0734.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0734'          TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'        TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                             TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *------------
       2000-LIST.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WS-VALIDATE-NOT-OK
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  COMM-1000-RETRIEVE-TWRK
               THRU COMM-1000-RETRIEVE-TWRK-X.

           IF  NOT LCOMM-RETRN-OK
               MOVE MIR-CVG-NUM              TO LCOMM-TWRK-CVG-NUM
               MOVE MIR-CVG-NUM              TO WS-FILTER-CVG-NUM
           ELSE
               MOVE LCOMM-TWRK-CVG-NUM       TO WS-FILTER-CVG-NUM
               PERFORM  COMM-3000-DELETE-TWRK
                   THRU COMM-3000-DELETE-TWRK-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  GCVG-1000-BROWSE-PREV
               THRU GCVG-1000-BROWSE-PREV-X.

           PERFORM  GCVG-2000-READ-PREV
               THRU GCVG-2000-READ-PREV-X.

           IF  WGCVG-IO-EOF
               PERFORM  GCVG-3000-END-BROWSE-PREV
                   THRU GCVG-3000-END-BROWSE-PREV-X
      *MSG: 'NO GUIDELINE PREMIUM ACTIVITIES FOUND'
               MOVE 'CS07340001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                         TO WS-SUB.
           PERFORM  2010-BROWSE-GCVG
               THRU 2010-BROWSE-GCVG-X
               UNTIL NOT WGCVG-IO-OK
               OR    WS-SUB > WS-MAX-LIST-LINES.

           PERFORM  2200-SET-NEXT-KEY
               THRU 2200-SET-NEXT-KEY-X.

           PERFORM  GCVG-3000-END-BROWSE-PREV
               THRU GCVG-3000-END-BROWSE-PREV-X.

           IF  WGLOB-MORE-DATA-EXISTS
      *MSG:    'TO VIEW MORE DATA PRESS ENTER'
               MOVE 'XS00000014'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE MIR-CVG-NUM-T (1)
                                             TO MIR-CVG-NUM
               MOVE MIR-GDLN-EFF-DT-T (1)
                                             TO MIR-GDLN-EFF-DT
               MOVE MIR-GDLN-SEQ-NUM-T (1)
                                             TO MIR-GDLN-SEQ-NUM
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
       2010-BROWSE-GCVG.
      *-----------------

           EVALUATE TRUE
               WHEN WS-FILTER-CVG-NUM = ZERO
               WHEN WS-FILTER-CVG-NUM = SPACE
                   CONTINUE
               WHEN WS-FILTER-CVG-NUM = RGCVG-CVG-NUM
                   CONTINUE
               WHEN OTHER
                   PERFORM  GCVG-2000-READ-PREV
                       THRU GCVG-2000-READ-PREV-X
                   GO TO 2010-BROWSE-GCVG-X
           END-EVALUATE.

           ADD 1                             TO WS-SUB.
           IF  WS-SUB > WS-MAX-LIST-LINES
               GO TO 2010-BROWSE-GCVG-X
           END-IF.

           MOVE RGCVG-CVG-NUM                TO MIR-CVG-NUM-T
                                                (WS-SUB).
           MOVE RGCVG-GDLN-EFF-DT            TO L1640-INTERNAL-DATE
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE          TO MIR-GDLN-EFF-DT-T
                                                (WS-SUB).

           MOVE RGCVG-GDLN-SEQ-NUM           TO L0290-INPUT-V00.
           MOVE ZERO                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-GDLN-SEQ-NUM-T (WS-SUB)
                                             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS           TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-GDLN-SEQ-NUM-T
                                                (WS-SUB).

           MOVE RGCVG-CVG-GDLN-APREM-AMT     TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT-T (WS-SUB)
                                             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY            TO TRUE.
           SET L0290-SIGN-FLOAT              TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-CVG-GDLN-APREM-AMT-T
                                                (WS-SUB).

           MOVE RGCVG-CVG-GDLN-SPREM-AMT     TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT-T (WS-SUB)
                                             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY            TO TRUE.
           SET L0290-SIGN-FLOAT              TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-CVG-GDLN-SPREM-AMT-T
                                                (WS-SUB).

           IF  RGPOL-POL-ID       = RGCVG-POL-ID
           AND RGPOL-GDLN-EFF-DT  = RGCVG-GDLN-EFF-DT
           AND RGPOL-GDLN-SEQ-NUM = RGCVG-GDLN-SEQ-NUM
               CONTINUE
           ELSE
               MOVE RGCVG-POL-ID             TO WGPOL-POL-ID
               MOVE RGCVG-GDLN-EFF-DT        TO WGPOL-GDLN-EFF-DT
               MOVE RGCVG-GDLN-SEQ-NUM       TO WGPOL-GDLN-SEQ-NUM
               PERFORM  GPOL-1000-READ
                   THRU GPOL-1000-READ-X
           END-IF.

           MOVE RGPOL-GDLN-STAT-CD           TO MIR-GDLN-STAT-CD-T
                                                (WS-SUB).

           MOVE RGPOL-GDLN-REASN-CD          TO MIR-GDLN-REASN-CD-T
                                                (WS-SUB).

           IF  RGPOL-PCHST-SEQ-NUM = ZERO
               MOVE RGPOL-PCHST-SEQ-NUM      TO L0290-INPUT-V00
           ELSE
               COMPUTE L0290-INPUT-V00 = WCNST-MAX-PCHST-SEQ-NUM-N
                                       - RGPOL-PCHST-SEQ-NUM
           END-IF
           MOVE ZERO                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PCHST-SEQ-NUM-T (WS-SUB)
                                             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS           TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-PCHST-SEQ-NUM-T
                                                (WS-SUB).

           PERFORM  GCVG-2000-READ-PREV
               THRU GCVG-2000-READ-PREV-X.

       2010-BROWSE-GCVG-X.
           EXIT.


      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           SET WS-VALIDATE-OK                TO TRUE.
           PERFORM  2110-EDIT-POL-ID
               THRU 2110-EDIT-POL-ID-X.

           PERFORM  2120-EDIT-EFF-DT
               THRU 2120-EDIT-EFF-DT-X.

           PERFORM  2130-EDIT-CVG-NUM
               THRU 2130-EDIT-CVG-NUM-X.

           PERFORM  2140-EDIT-SEQ-NUM
               THRU 2140-EDIT-SEQ-NUM-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       2110-EDIT-POL-ID.
      *-----------------

           IF  MIR-POL-ID = SPACES
      *MSG: POLICY ID MUST BE ENTERED
               MOVE 'CS00000048'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

           MOVE  MIR-POL-ID                  TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: @2 RECORD (@1) NOT FOUND
               MOVE 'XS00000001'             TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY                 TO WGLOB-MSG-PARM (1)
               MOVE 'POL'                    TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

           MOVE RPOL-POL-ID                  TO L2430-POL-ID.
           MOVE ZERO                         TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE                    L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM
                                             TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                             TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                             TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                             TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM     TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD         TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME        TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                   TO MIR-DV-OWN-CLI-NM
           END-IF.

       2110-EDIT-POL-ID-X.
           EXIT.

      *-----------------
       2120-EDIT-EFF-DT.
      *-----------------

           IF  MIR-GDLN-EFF-DT = SPACE
               MOVE WWKDT-HIGH-DT            TO WS-EFF-DT-INT
               GO TO 2120-EDIT-EFF-DT-X
           END-IF.

           MOVE MIR-GDLN-EFF-DT              TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      * MSG EFFECTIVE DATE (@1) INVALID
               MOVE 'XS00000355'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-GDLN-EFF-DT          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
               GO TO 2120-EDIT-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE          TO WS-EFF-DT-INT.

       2120-EDIT-EFF-DT-X.
           EXIT.

      *-------------------
       2130-EDIT-CVG-NUM.
      *-------------------

           IF  MIR-CVG-NUM = SPACE
               MOVE WCVGM-MAX-WCVGS-NUM      TO WS-CVG-NUM-N
               GO TO 2130-EDIT-CVG-NUM-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE LENGTH OF MIR-CVG-NUM        TO L0280-LENGTH.
           MOVE ZERO                         TO L0280-PRECISION.
           MOVE MIR-CVG-NUM                  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT             TO WS-CVG-NUM-N
               IF  WS-CVG-NUM-N > RPOL-POL-CVG-REC-CTR-N
      *MSG: THE COVERAGE MUST BE A NUMBER IN THE RANGE FROM 00 TO (@1)
                   MOVE 'CS00000055'     TO WGLOB-MSG-REF-INFO
                   MOVE RPOL-POL-CVG-REC-CTR
                                         TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-VALIDATE-NOT-OK    TO TRUE
               END-IF
           ELSE
      *MSG: COVERAGE MUST BE NUMERIC
               MOVE 'XS00000079'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM              TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

       2130-EDIT-CVG-NUM-X.
           EXIT.


      *-------------------
       2140-EDIT-SEQ-NUM.
      *-------------------

           IF  MIR-GDLN-SEQ-NUM = SPACE
               MOVE WCNST-MAX-GDLN-SEQ-NUM-N TO WS-SEQ-NUM
               GO TO 2140-EDIT-SEQ-NUM-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
           MOVE LENGTH OF MIR-GDLN-SEQ-NUM
                                             TO L0280-LENGTH.
           MOVE ZERO                         TO L0280-PRECISION.
           MOVE MIR-GDLN-SEQ-NUM             TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT             TO WS-SEQ-NUM
               IF  WS-SEQ-NUM = ZERO
      *MSG: INVALID SEQUENCE NUMBER
                   MOVE 'CS07340002'         TO WGLOB-MSG-REF-INFO
                   MOVE MIR-GDLN-SEQ-NUM     TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-VALIDATE-NOT-OK    TO TRUE
               END-IF
           ELSE
      *MSG:    'INVALID SEQUENCE NUMBER'
               MOVE 'CS07340002'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-GDLN-SEQ-NUM         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

       2140-EDIT-SEQ-NUM-X.
           EXIT.


      *----------------
       2200-SET-NEXT-KEY.
      *----------------

           IF  WGCVG-IO-OK
               PERFORM  9100-MOVE-RECORD-TO-KEY
                   THRU 9100-MOVE-RECORD-TO-KEY-X
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
           END-IF.

       2200-SET-NEXT-KEY-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE HIGH-VALUES            TO WGCVG-KEY.
           MOVE MIR-POL-ID             TO WGCVG-POL-ID.
           MOVE WS-EFF-DT-INT          TO WGCVG-GDLN-EFF-DT.
           MOVE WS-CVG-NUM-N           TO WGCVG-CVG-NUM-N.
           MOVE WS-SEQ-NUM             TO WGCVG-GDLN-SEQ-NUM.

           MOVE WGCVG-KEY              TO WGCVG-ENDBR-KEY.
           MOVE WWKDT-LOW-DT           TO WGCVG-ENDBR-GDLN-EFF-DT.
           MOVE ZERO                   TO WGCVG-ENDBR-CVG-NUM-N.
           MOVE ZERO                   TO WGCVG-ENDBR-GDLN-SEQ-NUM.

       7000-BUILD-KEYS-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                  TO MIR-CVG-NUM-G.
           MOVE SPACE                  TO MIR-GDLN-EFF-DT-G.
           MOVE SPACE                  TO MIR-GDLN-SEQ-NUM-G.
           MOVE SPACE                  TO MIR-GDLN-STAT-CD-G.
           MOVE SPACE                  TO MIR-GDLN-REASN-CD-G.
           MOVE SPACE                  TO MIR-CVG-GDLN-APREM-AMT-G.
           MOVE SPACE                  TO MIR-CVG-GDLN-SPREM-AMT-G.
           MOVE SPACE                  TO MIR-PCHST-SEQ-NUM-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *------------------------
       9100-MOVE-RECORD-TO-KEY.
      *------------------------

           MOVE RGCVG-POL-ID           TO MIR-POL-ID.
           MOVE RGCVG-CVG-NUM          TO MIR-CVG-NUM.

           MOVE RGCVG-GDLN-EFF-DT      TO L1640-INTERNAL-DATE.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE    TO MIR-GDLN-EFF-DT.

           MOVE RGCVG-GDLN-SEQ-NUM     TO L0290-INPUT-V00.
           MOVE ZERO                   TO L0290-PRECISION.
           MOVE LENGTH OF MIR-GDLN-SEQ-NUM-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS     TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-GDLN-SEQ-NUM.


       9100-MOVE-RECORD-TO-KEY-X.
           EXIT.


      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                    TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE        TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX         TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-AREA.
           SET WS-MAX-LIST-LINES-DEFAULT     TO TRUE.
           MOVE SPACES                       TO WWKDT-WORK-FIELDS.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPCOMM.

       COPY XCPPINIT.

       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY CCPS0620.
       COPY CCPL0620.
      /
       COPY CCPS2430.
       COPY CCPL2430.
      /
       COPY XCPL0260.
      /
       COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.

       COPY CCPVGCVG.

       COPY CCPNGPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.

       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM0734                     **
      *****************************************************************
