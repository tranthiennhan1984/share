      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM2392.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM2392                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE DBRL TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
025244**  6.6       ADDED STANDARD MESSAGE                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM2392'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '2392'.
025970*           05  WS-TWRK-KEY                   PIC X(04)
025970*                                             VALUE '2392'.
           05  WS-DBSRL-PGM-ID.
               10  WS-DBSRL-PGM-SUB-SYS      PIC X(01).
               10  WS-DBSRL-PGM              PIC X(03).
                   88 WS-DBSRL-PGM-ID-VALID  VALUE 'SDK'.
               10  WS-DBSRL-PGM-NUM          PIC X(04).
               
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                   PIC X(04).  
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '2392'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWL8090.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY XCFWDBRL.
       COPY XCFRDBRL.
       COPY CCWWLOCK.
      /
       COPY XCFRXTAB.
       COPY XCFWXTAB.
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM2392.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*           PERFORM  9300-SETUP-MSIN-REFERENCE
025970*               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*           MOVE MIR-BUS-FCN-ID
025970*             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2392'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------
      *
      *  THE RECORD MUST EXIST, AND HAVE A CURRENT TIMESTAMP
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.
    
           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  DBRL-2000-UPDATE-TWRK-TS
               THRU DBRL-2000-UPDATE-TWRK-TS-X.

           IF  WDBRL-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WDBRL-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           IF MIR-RETRN-TS-MISMATCH
      *MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2' 
              MOVE 'XS00000303'  
                TO WGLOB-MSG-REF-INFO
              MOVE 'DBRL' 
                TO WGLOB-MSG-PARM (1) 
              MOVE WDBRL-KEY
                TO WGLOB-MSG-PARM (2)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2000-UPDATE-X
           END-IF.

      *
      *
      *  EDIT THE DATA ENTERED FOR THE RECORD CHANGES
      *

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  9200-MOVE-MIR-TO-RECORD
                   THRU 9200-MOVE-MIR-TO-RECORD-X
           ELSE
               SET MIR-RETRN-EDIT-ERROR
                 TO TRUE
           END-IF.

           PERFORM  DBRL-2000-REWRITE
               THRU DBRL-2000-REWRITE-X.

      *  UPDATE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  DBRL-1000-READ-TWRK-TS
               THRU DBRL-1000-READ-TWRK-TS-X.

025244*MSG: 'MAINTENANCE COMPLETED - CONTINUE'
025244     MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO.
025244     PERFORM  0260-1000-GENERATE-MESSAGE
025244         THRU 0260-1000-GENERATE-MESSAGE-X.
025244
       2000-UPDATE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------
       
           PERFORM  4110-EDIT-REL-ID
               THRU 4110-EDIT-REL-ID-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *-----------------
       4110-EDIT-REL-ID.
      *-----------------
      *
      * RELATIONSHIP ID IS VALIDATED AGAINST THE XTAB TABLE
      *
           MOVE MIR-DBSRL-ID          TO WXTAB-ETBL-VALU-ID.
           
           PERFORM  DBRI-1000-EDIT-DBSRL-ID
               THRU DBRI-1000-EDIT-DBSRL-ID-X.
           
           IF WXTAB-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: INVALID DATABASE RELATIONSHIP ID - CHECK 
      *             XTAB TYPE 'DBRID'
               MOVE 'XS23920001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4110-EDIT-REL-ID-X
           END-IF.

       4110-EDIT-REL-ID-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
           
           MOVE LOW-VALUES             TO WDBRL-KEY.
           MOVE MIR-DBSRL-ID           TO WDBRL-DBSRL-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------
       8000-EDITS.
      *-----------
           PERFORM  8100-EDIT-CHILD-TBL
               THRU 8100-EDIT-CHILD-TBL-X.
           
           PERFORM  8200-EDIT-PARNT-TBL
               THRU 8200-EDIT-PARNT-TBL-X.
           
           PERFORM  8300-EDIT-DBSRL-PGM
               THRU 8300-EDIT-DBSRL-PGM-X.

       8000-EDITS-X.
           EXIT.
      /
      *--------------------
       8100-EDIT-CHILD-TBL.
      *--------------------
      * RELATIONSHIP CHILD DATABASE TABLE NAME IS VALIDATED
      * AGAINST THE XTAB TABLE
      *
           
           MOVE MIR-DBSRL-CHILD-TBL-ID TO WXTAB-ETBL-VALU-ID.
           
           PERFORM  DBTB-1000-EDIT-TKN-DB-TBL-ID
               THRU DBTB-1000-EDIT-TKN-DB-TBL-ID-X.
           
           IF WXTAB-IO-OK
               MOVE MIR-DBSRL-CHILD-TBL-ID 
                                        TO RDBRL-DBSRL-CHILD-TBL-ID
           ELSE
      *        MSG: INVALID RELATIONSHIP CHILD DATABASE TABLE NAME
      *             CHECK XTAB TYPE 'DBTBL'
               MOVE 'XS23920002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8100-EDIT-CHILD-TBL-X
           END-IF.

       8100-EDIT-CHILD-TBL-X.
           EXIT.
      /
      *--------------------
       8200-EDIT-PARNT-TBL.
      *--------------------
      * RELATIONSHIP CHILD DATABASE TABLE NAME IS VALIDATED
      * AGAINST THE XTAB TABLE, BUT CAN EQUAL OR BE SET TO SPACES
      *
           IF MIR-DBSRL-PARNT-TBL-ID = SPACES
           OR MIR-DBSRL-PARNT-TBL-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES              TO MIR-DBSRL-PARNT-TBL-ID
               GO TO 8200-EDIT-PARNT-TBL-X
           END-IF.

           MOVE MIR-DBSRL-PARNT-TBL-ID TO WXTAB-ETBL-VALU-ID.
           
           PERFORM  DBTB-1000-EDIT-TKN-DB-TBL-ID
               THRU DBTB-1000-EDIT-TKN-DB-TBL-ID-X.
           
           IF WXTAB-IO-OK
               MOVE MIR-DBSRL-PARNT-TBL-ID 
                                        TO RDBRL-DBSRL-PARNT-TBL-ID
           ELSE
      *        MSG: INVALID RELATIONSHIP PARENT DATABASE TABLE NAME
      *             CHECK XTAB TYPE 'DBTBL'
               MOVE 'XS23920003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8200-EDIT-PARNT-TBL-X
           END-IF.

       8200-EDIT-PARNT-TBL-X.
           EXIT.
      /
      *--------------------
       8300-EDIT-DBSRL-PGM.
      *--------------------
      * VALIDATE RELATIONSHIP PROGRAM ID. CHARS 2-4 MUST EQUAL SDK
      *
           MOVE MIR-DBSRL-PGM-ID      TO WS-DBSRL-PGM-ID.
           
           IF WS-DBSRL-PGM-ID-VALID
               MOVE MIR-DBSRL-PGM-ID TO RDBRL-DBSRL-PGM-ID
           ELSE
      *        MSG: INVALID RELATIONSHIP PROGRAM ID
               MOVE 'XS23920004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8300-EDIT-DBSRL-PGM-X
           END-IF.
                   
       8300-EDIT-DBSRL-PGM-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES         TO MIR-DBSRL-CHILD-TBL-ID.
           MOVE SPACES         TO MIR-DBSRL-PARNT-TBL-ID.
           MOVE SPACES         TO MIR-DBSRL-PGM-ID.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-MIR-TO-RECORD.
      *------------------------

           MOVE MIR-DBSRL-CHILD-TBL-ID
                               TO RDBRL-DBSRL-CHILD-TBL-ID.
           MOVE MIR-DBSRL-PARNT-TBL-ID
                               TO RDBRL-DBSRL-PARNT-TBL-ID.
           MOVE MIR-DBSRL-PGM-ID
                               TO RDBRL-DBSRL-PGM-ID.
       
       9200-MOVE-MIR-TO-RECORD-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  9300-SETUP-MSIN-REFERENCE
025970         THRU 9300-SETUP-MSIN-REFERENCE-X.

           INITIALIZE          WS-WORKING-STORAGE.
025970     MOVE MIR-BUS-FCN-ID
025970       TO WS-BUS-FCN-ID.
025970     SET  WS-TWRK-KEY-DEFAULT       TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  DBRL
                                '$VAR2'   BY 'DBRL'.
       COPY XCPL8090.
025970 COPY XCPS8090.
       COPY XCPEDBRI.
       COPY XCPEDBTB.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY XCPNDBRL.
       COPY XCPUDBRL.
       COPY XCPNXTAB.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM 'XSOM2392'                   **
      *****************************************************************
