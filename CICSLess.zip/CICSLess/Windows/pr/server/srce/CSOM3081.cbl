      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3081.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3081                                         **
      **  REMARKS:  PLAR - PLAN ALLOCATION RULE TABLE CREATE         **
      **            THIS MODULE CREATES AN ENTRY IN THE PLAR TABLE   **
      **  DOMAIN :  PR                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3081'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-CREATE        VALUE '3081'.
           05  WS-TWRK-KEY                  PIC X(04)
                                            VALUE '3080'.
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '3080'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************

       COPY CCWWLOCK.

      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
      /
       COPY CCFRPLAR.
       COPY CCFWPLAR.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY XCFWDMAD.
       COPY XCFRDMAD.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
021930*COPY XCWLDTLK.
021930*COPY XCWL0290.
       COPY XCWL8090.

      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3081.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

021930*    PERFORM  0290-1000-BUILD-PARM-INFO
021930*        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3081'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *---------------------

           PERFORM 4200-CREATE-EDITS
              THRU 4200-CREATE-EDITS-X.

           IF  WGLOB-GOOD-RETURN
               CONTINUE
           ELSE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  PLAR-1000-CREATE
               THRU PLAR-1000-CREATE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  PLAR-1000-WRITE
               THRU PLAR-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PLAR-1000-CALL-AUDIT
                  THRU PLAR-1000-CALL-AUDIT-X
           END-IF.

           MOVE MIR-PLAN-ID             TO WPH-PLAN-ID.

           PERFORM  PH-1000-READ-TWRK-TS
               THRU PH-1000-READ-TWRK-TS-X.

           IF  WPH-IO-NOT-FOUND
      *MSG:    PLAN @1 IS NOT A VALID PLAN
               MOVE 'CS30810001'         TO WGLOB-MSG-REF-INFO
               MOVE WEDIT-ETBL-VALU-ID   TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *-----------------------
       4200-CREATE-EDITS.
      *-----------------------

           MOVE MIR-PLAN-ID              TO WEDIT-ETBL-VALU-ID.

           PERFORM  PLAN-1000-EDIT
               THRU PLAN-1000-EDIT-X.

           IF  NOT WEDIT-IO-OK
      *MSG:    PLAN @1 IS NOT A VALID PLAN
               MOVE 'CS30810001'         TO WGLOB-MSG-REF-INFO
               MOVE WEDIT-ETBL-VALU-ID   TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           MOVE 'PLAR-ALLOC-TYP-CD'      TO WDMAD-DM-AV-TBL-CD.
           MOVE MIR-PLAR-ALLOC-TYP-CD    TO WDMAD-DM-AV-CD.
           MOVE WGLOB-USER-LANG          TO WDMAD-DM-AV-DESC-LANG-CD.

           PERFORM  DMAD-1000-READ
               THRU DMAD-1000-READ-X.

           IF  WDMAD-IO-OK
               CONTINUE
           ELSE
      * MSG:   PLAN ALLOCATION TYPE MUST BE A VALID SELECTION
      *        FROM THE SELECTION BOX
               MOVE 'CS30810002'         TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           MOVE MIR-PLAN-ID              TO WPLAR-PLAN-ID.
           MOVE MIR-PLAR-ALLOC-TYP-CD
                                         TO WPLAR-PLAR-ALLOC-TYP-CD.

           PERFORM  PLAR-1000-READ
               THRU PLAR-1000-READ-X.

           IF  WPLAR-IO-OK
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE WPLAR-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           MOVE MIR-PLAN-ID              TO WPH-PLAN-ID.
           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  WPH-IO-OK
               CONTINUE
           ELSE
      *MSG:    PLAN @1 IS NOT A VALID PLAN
               MOVE 'CS30810001'         TO WGLOB-MSG-REF-INFO
               MOVE WEDIT-ETBL-VALU-ID   TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       4200-CREATE-EDITS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPEPLAN.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
                               '$VAR2' BY 'PH'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPLPLAR.
025970 COPY XCPS8090.
      /
       COPY XCPL0260.
      /
021930*COPY XCPS0290.
021930*COPY XCPL0290.
021930*
021930*COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPH.
       COPY CCPUPH.
      /
       COPY CCPAPLAR.
       COPY CCPCPLAR.
       COPY CCPNPLAR.
      /
       COPY CCPNEDIT.
       COPY XCPNDMAD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3081                     *
      ****************************************************************
