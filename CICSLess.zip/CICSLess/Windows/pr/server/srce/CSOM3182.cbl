      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3182.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3182                                         **
      **  REMARKS:  PAAF - POLICY ACTIVITY AUDIT FIELD TABLE UPDATE  **
      **            THIS MODULE UPDATES THE PAAF TABLE               **
      **  DOMAIN :  PR                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3182'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '3180'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '3180'.
025970     05  WS-MAX-BR-CTR            PIC 9(03).
025970         88  WS-MAX-BR-CTR-DEFAULT    VALUE 100.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-UPDATE        VALUE '3182'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '3180'.

           05  WS-WORKING-AREA.
               10  WS-SUB                   PIC S9(04) BINARY.
025970*        10  WS-MAX-BR-CTR            PIC 9(03).
               10  WS-PRCES-SEQ-NUM         PIC S9(03).
               10  WS-ERROR-SW              PIC X(01).
                   88  WS-ERROR             VALUE 'Y'.
                   88  WS-NO-ERROR          VALUE 'N'.
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWLOCK.
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPAAF.
       COPY CCFRPAAF.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
028298 COPY CCWL2626.
       COPY CCWL3187.
       COPY CCWL3188.
       COPY XCWL1646.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3182.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

023514*    PERFORM  9990-INIT-WORKING-STORAGE
023514*        THRU 9990-INIT-WORKING-STORAGE-X.
023514*
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X
               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3182'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *---------------------------
       5000-PROCESS-UPDATE.
      *---------------------------

           MOVE MIR-POL-ID          TO WPOL-POL-ID.
           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.
           IF  WPOL-IO-NOT-FOUND
      *MSG:  REQUESTED POLICY NOT FOUND
                MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                SET WS-ERROR               TO TRUE
                GO TO 5000-PROCESS-UPDATE-X
           END-IF.
           IF  MIR-RETRN-TS-MISMATCH
      *MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
      *     PROCESS NOT COMPLETE
               MOVE 'XS00000303'    TO WGLOB-MSG-REF-INFO
               MOVE 'POL'           TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY        TO WGLOB-MSG-PARM (02)
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                SET WS-ERROR         TO TRUE
                GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           IF  MIR-PAAFLD-GR-TS = WWKDT-ZERO-TS
      *MSG: PAAF GROUP TS MUST BE ENTERED
               MOVE 'CS31820001'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR          TO TRUE
               GO TO 5000-PROCESS-UPDATE-X
           ELSE
               PERFORM  1646-1000-BUILD-PARM-INFO
                   THRU 1646-1000-BUILD-PARM-INFO-X
               MOVE MIR-PAAFLD-GR-TS      TO L1646-TIMESTAMP
               PERFORM  1646-1000-EDIT-TIMESTAMP
                   THRU 1646-1000-EDIT-TIMESTAMP-X
               IF  L1646-EDIT-FAILED
                   SET WGLOB-RETURN-ERROR TO  TRUE
                   MOVE 'CS31820002'      TO  WGLOB-MSG-REF-INFO
      * MSG: INVALID TIMESTAMP
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
                   SET WS-ERROR           TO  TRUE
                   GO TO 5000-PROCESS-UPDATE-X
               END-IF
           END-IF.

           PERFORM  5200-UPDATE-REC
               THRU 5200-UPDATE-REC-X
               VARYING WS-SUB FROM +1 BY +1
                 UNTIL WS-SUB > WS-MAX-BR-CTR
                    OR WS-ERROR.

           IF  WS-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
           ELSE
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
           END-IF.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *--------------------
       5200-UPDATE-REC.
      *--------------------

           IF  MIR-PAAFLD-FLD-ID-T (WS-SUB) = SPACES
               IF MIR-PAAFLD-VALU-TXT-T (WS-SUB) = SPACES
                  GO TO 5200-UPDATE-REC-X
               ELSE
      *MSG: FIELD ID CANNOT BE BLANK, RECORD GET CREATED
                  MOVE 'CS31820003'            TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                  SET WS-ERROR                 TO TRUE
                  GO TO 5200-UPDATE-REC-X
               END-IF
           END-IF.

           IF  (MIR-PAAFLD-SEQ-NUM-T (WS-SUB) = SPACES
           OR   MIR-PAAFLD-SEQ-NUM-T (WS-SUB) = ZEROS)
                MOVE MIR-POL-ID         TO WPAAF-POL-ID
                MOVE MIR-PAAFLD-GR-TS   TO WPAAF-PAAFLD-GR-TS
                MOVE +001               TO WPAAF-PAAFLD-SEQ-NUM
                MOVE WPAAF-KEY          TO WPAAF-ENDBR-KEY
                MOVE +999            TO WPAAF-ENDBR-PAAFLD-SEQ-NUM
                PERFORM  PAAF-2000-READ-MAX
                    THRU PAAF-2000-READ-MAX-X
                IF  WPAAF-IO-OK
                    MOVE WPAAF-MAX-PAAFLD-SEQ-NUM
                                            TO WS-PRCES-SEQ-NUM
                    ADD +1                  TO WS-PRCES-SEQ-NUM
                ELSE
                    MOVE +1                 TO WS-PRCES-SEQ-NUM
                END-IF
                PERFORM  6000-CREATE-NEW-PAAF
                    THRU 6000-CREATE-NEW-PAAF-X
           ELSE
                MOVE MIR-PAAFLD-SEQ-NUM-T (WS-SUB)
                                            TO WS-PRCES-SEQ-NUM
                PERFORM  7000-UPDATE-EXIST-PAAF
                    THRU 7000-UPDATE-EXIST-PAAF-X
           END-IF.

       5200-UPDATE-REC-X.
           EXIT.
      /
      *---------------------------
       6000-CREATE-NEW-PAAF.
      *---------------------------

           PERFORM  3187-0000-INIT-PARM-INFO
               THRU 3187-0000-INIT-PARM-INFO-X.

           MOVE MIR-POL-ID               TO L3187-POL-ID.
           MOVE MIR-PAAFLD-GR-TS         TO L3187-PAAFLD-GR-TS.
           MOVE WS-PRCES-SEQ-NUM         TO L3187-PAAFLD-SEQ-NUM.

           PERFORM  3187-1000-EDIT-PAAF-CRE-KEY
               THRU 3187-1000-EDIT-PAAF-CRE-KEY-X.

           IF  NOT L3187-RETRN-OK
               SET WS-ERROR              TO TRUE
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 6000-CREATE-NEW-PAAF-X
           END-IF.

           PERFORM  3188-0000-INIT-PARM-INFO
               THRU 3188-0000-INIT-PARM-INFO-X.

           MOVE L3187-POL-ID               TO L3188-POL-ID.
           MOVE L3187-PAAFLD-GR-TS         TO L3188-PAAFLD-GR-TS.
           MOVE L3187-PAAFLD-SEQ-NUM       TO L3188-PAAFLD-SEQ-NUM.
           MOVE MIR-PAAFLD-FLD-ID-T (WS-SUB)
                                 TO L3188-PAAFLD-FLD-ID.
           MOVE MIR-PAAFLD-VALU-TXT-T (WS-SUB)
                                TO L3188-PAAFLD-VALU-TXT.

           PERFORM  3188-1000-CREATE-PAAF
               THRU 3188-1000-CREATE-PAAF-X.

           IF  NOT L3188-RETRN-OK
               SET WS-ERROR                TO TRUE
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

       6000-CREATE-NEW-PAAF-X.
           EXIT.
      /
      *---------------------
       7000-UPDATE-EXIST-PAAF.
      *---------------------

           PERFORM  3187-0000-INIT-PARM-INFO
               THRU 3187-0000-INIT-PARM-INFO-X.

           MOVE MIR-POL-ID               TO L3187-POL-ID.
           MOVE MIR-PAAFLD-GR-TS         TO L3187-PAAFLD-GR-TS.
           MOVE WS-PRCES-SEQ-NUM         TO L3187-PAAFLD-SEQ-NUM.

           PERFORM  3187-2000-EDIT-PAAF-UPD-KEY
               THRU 3187-2000-EDIT-PAAF-UPD-KEY-X.

           IF  NOT L3187-RETRN-OK
               SET WS-ERROR              TO TRUE
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 7000-UPDATE-EXIST-PAAF-X
           END-IF.

           PERFORM  3188-0000-INIT-PARM-INFO
               THRU 3188-0000-INIT-PARM-INFO-X.

           MOVE L3187-POL-ID               TO L3188-POL-ID.
           MOVE L3187-PAAFLD-GR-TS         TO L3188-PAAFLD-GR-TS.
           MOVE L3187-PAAFLD-SEQ-NUM       TO L3188-PAAFLD-SEQ-NUM.
           MOVE MIR-PAAFLD-FLD-ID-T (WS-PRCES-SEQ-NUM)
                                           TO L3188-PAAFLD-FLD-ID.
           MOVE MIR-PAAFLD-VALU-TXT-T (WS-PRCES-SEQ-NUM)
                                           TO L3188-PAAFLD-VALU-TXT.

           PERFORM  3188-2000-UPDATE-PAAF
               THRU 3188-2000-UPDATE-PAAF-X.

           IF  NOT L3188-RETRN-OK
               SET WS-ERROR                TO TRUE
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

       7000-UPDATE-EXIST-PAAF-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3187-0000-INIT-PARM-INFO
025970         THRU 3187-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  3188-0000-INIT-PARM-INFO
025970         THRU 3188-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  WS-TWRK-KEY-DEFAULT     TO TRUE.
025970     SET  WS-MAX-BR-CTR-DEFAULT   TO TRUE.
           SET  MIR-RETRN-OK            TO TRUE.
           SET  WS-NO-ERROR             TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970*    MOVE +100                    TO WS-MAX-BR-CTR.
           MOVE +1                      TO WS-PRCES-SEQ-NUM.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
      /
025970 COPY XCPS8090.
       COPY XCPS1646.
       COPY XCPL1646.
      /
       COPY CCPS3187.
       COPY CCPL3187.
      /
       COPY CCPS3188.
       COPY CCPL3188.
      /
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPFPAAF.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3082                     *
      ****************************************************************
