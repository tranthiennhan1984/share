      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM6160.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6160                                         **
      **  REMARKS:  ADDC - MAINTAIN CLIENT CONTACT INFORMATION TABLE **
      **                                                             **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE FUNCTIONS **
      **            FOR THE CLIENT CONTACT INFORMATION (CLIC) TABLE. **
      **            AN EXISTING CLIENT IS REQUIRED FOR ANY OPERATION **
      **            ON THE TABLE.                                    **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557667**  5.5       ORIGINAL FOR 5.5                                 **
010381**  5.5.2     FIELD DISPLAY PROBLEM                            **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270, MIR RENAME                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       NEW BUSINESS                                     **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
014221**  6.2       LOGICAL LOCKING                                  **
016387**  6.2       REMOVE CLIENT CONSOLIDATION SUPPORT              **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017318**  6.2       WRAPPER P-STEPS FIX                              **
017334**  6.2       ALLOW PROGRAM TO CONTINUE WHEN RECORD NOT FOUND  **
016227**  6.3       CODE CLEAN UP (6.0.2.J)                          **
018763**  6.3       CODE CLEAN UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018622**  6.4       LOGICAL LOCKING FOR CREATE FLOW                  **
018300**  6.4       INQUIRY DURING CLIENT CLEAR CASING               **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6160'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
      /
      /
014590*COPY XCWL0030.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
      /
016537*COPY CCWWINDX.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4)  BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT         VALUE +5.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                 VALUE '1072'.

       01  WS-WORKING-STORAGE.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +5  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +5  BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE '1072' '1074'.
               88  WS-BUS-FCN-UPDATE        VALUE '1072'.
               88  WS-BUS-FCN-LIST          VALUE '1074'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1072'.
           05  WS-HOLD-CLSNM                PIC X(75)  VALUE SPACES.
           05  WS-CLI-CNTCT-ID-CD-SW        PIC X(01).
               88  WS-CLI-CNTCT-ID-CD-VALID            VALUE 'Y'.
               88  WS-CLI-CNTCT-ID-CD-INVALID          VALUE 'N'.
           05  WS-DUP-CNTCT-ID-CD-SW        PIC X(01).
               88  WS-DUP-CNTCT-ID-CD                  VALUE 'Y'.
               88  WS-DUP-CNTCT-ID-CD-NO               VALUE 'N'.
           05  WS-PROCESS-INFO.
               10  WS-PRCES-FIELDS          OCCURS  5 TIMES.
                   15  WS-PRCES-CNTCT-ID-CD     PIC X(02).
                   15  WS-PRCES-CNTCT-ID-TXT    PIC X(50).
           05  WS-SCRIPT.
016548*        10  WS-SUB                PIC S9(04) VALUE ZERO COMP.
016548         10  WS-SUB                PIC S9(04) VALUE ZERO BINARY.
016548*        10  WS-SUB1               PIC S9(04) VALUE ZERO COMP.
016548         10  WS-SUB1               PIC S9(04) VALUE ZERO BINARY.

      /
      *****************************************************************
      *  LINKAGE COPYBOOKS                                            *
      *****************************************************************
       COPY CCWL0620.
028298 COPY CCWL2626.
      /
016537*COPY CCWL0832.
      /
       COPY CCWL2435.
      /
016537*COPY XCWL0280.
      /
014221 COPY XCWL8090.
       COPY CCWL5600.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
014221 COPY CCFRCLI.
014221 COPY CCFWCLI.
       COPY CCFRCLIC.
       COPY CCFWCLIC.
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      /
014221 COPY CCWWLOCK.
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM6160.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      /
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
      *
           SET MIR-RETRN-OK           TO  TRUE.
      *
           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------
       2000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
           INITIALIZE                      WS-HOLD-CLSNM.
           INITIALIZE                      WS-PROCESS-INFO.

016227*    IF  WGLOB-MSG-ERROR-SW > ZERO
016227*    OR  NOT WGLOB-GOOD-RETURN
016227*        PERFORM  9100-BLANK-DATA-FIELDS
016227*            THRU 9100-BLANK-DATA-FIELDS-X
016227*        GO TO 2000-PROCESS-REQUEST-X
016227*    END-IF.
016227     MOVE ZERO             TO WGLOB-MSG-ERROR-SW.

           PERFORM  8100-EDIT-CLI-ID
               THRU 8100-EDIT-CLI-ID-X.

017318*    IF  WGLOB-MSG-ERROR-SW > ZERO
017318*    OR  NOT WGLOB-GOOD-RETURN
017318*        PERFORM  9100-BLANK-DATA-FIELDS
017318*            THRU 9100-BLANK-DATA-FIELDS-X
017318*        GO TO 2000-PROCESS-REQUEST-X
017318*    END-IF.
017318     MOVE  ZERO    TO WGLOB-MSG-ERROR-SW.

           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID                  TO L5600-CLI-ID.

016387*    IF  WS-BUS-FCN-LIST
016387*        SET L5600-GEN-CNSLDT-MSG-WARN TO TRUE
016387*    END-IF.

018300     IF  WS-BUS-FCN-LIST
018300         SET L5600-INQ-INFO-ONLY     TO TRUE
018300     END-IF.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           EVALUATE TRUE

               WHEN L5600-RETRN-OK
                   CONTINUE

               WHEN OTHER
      *MSG:  FATAL ERROR OCCURED IN 5600
                   MOVE 'CS61600003'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-PROCESS-REQUEST-X

           END-EVALUATE.


           IF L5600-CCAS-ACCS-RESTRICTED
              IF  WS-BUS-FCN-LIST
                  SET L5600-CCAS-ACCS-WARNING  TO TRUE
              END-IF
           END-IF.


           IF L5600-CNFD-ACCS-RESTRICTED
           OR L5600-CCAS-ACCS-RESTRICTED
016387*    OR L5600-CNSLDT-ACCS-RESTRICTED

               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
                GO TO 2000-PROCESS-REQUEST-X

           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                   PERFORM  3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       3500-PROCESS-LIST.
      *------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE +1                         TO WS-SUB.

           PERFORM  3520-BROWSE-CLIC
               THRU 3520-BROWSE-CLIC-X.

018622     MOVE MIR-CLI-ID         TO WCLI-CLI-ID.
018622     PERFORM  CLI-1000-READ-TWRK-TS
018622         THRU CLI-1000-READ-TWRK-TS-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-----------------
       3520-BROWSE-CLIC.
      *-----------------

           MOVE LOW-VALUES              TO WCLIC-KEY.
           MOVE MIR-CLI-ID              TO WCLIC-CLI-ID
                                           WCLIC-ENDBR-CLI-ID.
           MOVE HIGH-VALUES             TO WCLIC-ENDBR-CLI-CNTCT-ID-CD.

           PERFORM  3530-BROWSE-CLIC-LOOP
               THRU 3530-BROWSE-CLIC-LOOP-X.

       3520-BROWSE-CLIC-X.
           EXIT.
      /
      *----------------------
       3530-BROWSE-CLIC-LOOP.
      *----------------------

           PERFORM  CLIC-1000-BROWSE
               THRU CLIC-1000-BROWSE-X.

           IF WCLIC-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3530-BROWSE-CLIC-LOOP-X
           END-IF.

           PERFORM  CLIC-2000-READ-NEXT
               THRU CLIC-2000-READ-NEXT-X.

           IF WCLIC-IO-EOF
               PERFORM  CLIC-3000-END-BROWSE
                   THRU CLIC-3000-END-BROWSE-X
      *MSG:        'NO RECORDS FOUND TO DISPLAY'
017334*        MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
017334         MOVE 'XS00000304'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3530-BROWSE-CLIC-LOOP-X
           END-IF.

           PERFORM  3535-BROWSE-CLIC-READ
               THRU 3535-BROWSE-CLIC-READ-X
              UNTIL WS-SUB > WS-MAX-BROWSE-LINES
                 OR WCLIC-IO-EOF.

       3530-BROWSE-CLIC-LOOP-X.
           EXIT.
      /
      *----------------------
       3535-BROWSE-CLIC-READ.
      *----------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           ADD 1                       TO WS-SUB.

           IF WS-SUB > WS-MAX-BROWSE-LINES
               GO TO 3535-BROWSE-CLIC-READ-X
           END-IF.

           PERFORM  CLIC-2000-READ-NEXT
               THRU CLIC-2000-READ-NEXT-X.

       3535-BROWSE-CLIC-READ-X.
           EXIT.
      /
      *----------------
       5000-PROCESS-UPDATE.
      *----------------

           PERFORM  5200-MOVE-MIR-TO-PRCES
               THRU 5200-MOVE-MIR-TO-PRCES-X.

           PERFORM  8000-EDIT-UPDATES
               THRU 8000-EDIT-UPDATES-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  NOT WGLOB-GOOD-RETURN
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  5400-PROCESS-UPDATE-REC
               THRU 5400-PROCESS-UPDATE-REC-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *----------------------
       5200-MOVE-MIR-TO-PRCES.
      *----------------------

           MOVE ZEROS                   TO  WS-SUB.

           PERFORM  5220-MOVE-MIR-TO-REC
               THRU 5220-MOVE-MIR-TO-REC-X
               VARYING WS-SUB1 FROM +1 BY +1
               UNTIL WS-SUB1 > WS-MAX-BROWSE-LINES.

       5200-MOVE-MIR-TO-PRCES-X.
           EXIT.
      /
      *--------------------
       5220-MOVE-MIR-TO-REC.
      *--------------------

           IF  MIR-CLI-CNTCT-ID-CD-T (WS-SUB1) = SPACES
           OR  MIR-CLI-CNTCT-ID-CD-T (WS-SUB1) = EBLCH-BLANK-FIELD-CHAR
               CONTINUE
           ELSE
               ADD +1               TO  WS-SUB
               MOVE MIR-CLI-CNTCT-ID-CD-T (WS-SUB1)
                                    TO  WS-PRCES-CNTCT-ID-CD (WS-SUB)
               MOVE MIR-CLI-CNTCT-ID-TXT-T (WS-SUB1)
                                    TO  WS-PRCES-CNTCT-ID-TXT (WS-SUB)
           END-IF.

       5220-MOVE-MIR-TO-REC-X.
           EXIT.
      /
      *------------------------
       5400-PROCESS-UPDATE-REC.
      *------------------------

           PERFORM  6000-DELETE-CLIC-REC
               THRU 6000-DELETE-CLIC-REC-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
              PERFORM  9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
              GO TO 5400-PROCESS-UPDATE-REC-X
           END-IF.

           PERFORM  5420-CREATE-CLIC-REC
               THRU 5420-CREATE-CLIC-REC-X
               VARYING WS-SUB1 FROM +1 BY +1
               UNTIL WS-SUB1 > WS-MAX-BROWSE-LINES.

           MOVE SPACES                 TO  MIR-CLI-CNTCT-ID-CD-G.
           MOVE SPACES                 TO  MIR-CLI-CNTCT-ID-TXT-G.

           PERFORM  9500-MOVE-REC-FROM-PRCES
               THRU 9500-MOVE-REC-FROM-PRCES-X
               VARYING WS-SUB FROM +1 BY +1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES.

       5400-PROCESS-UPDATE-REC-X.
           EXIT.
      /
      *--------------------
       5420-CREATE-CLIC-REC.
      *--------------------
      *
           IF  WS-PRCES-CNTCT-ID-CD (WS-SUB1) = SPACES
           OR  WS-PRCES-CNTCT-ID-CD (WS-SUB1) = EBLCH-BLANK-FIELD-CHAR
              GO TO 5420-CREATE-CLIC-REC-X
           END-IF.
      *
           INITIALIZE                   RCLIC-REC-INFO.

           MOVE MIR-CLI-ID              TO  RCLIC-CLI-ID.
           MOVE WS-PRCES-CNTCT-ID-CD (WS-SUB1)
                                        TO  RCLIC-CLI-CNTCT-ID-CD.

           MOVE RCLIC-KEY               TO  WCLIC-KEY.

           PERFORM  CLIC-1000-CREATE
               THRU CLIC-1000-CREATE-X.

           MOVE WS-PRCES-CNTCT-ID-TXT (WS-SUB1)
                                          TO RCLIC-CLI-CNTCT-ID-TXT.
      *
           PERFORM  CLIC-1000-WRITE
               THRU CLIC-1000-WRITE-X.
      *
014221     MOVE MIR-CLI-ID              TO WCLI-CLI-ID.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.
      
       5420-CREATE-CLIC-REC-X.
           EXIT.
      /
      *--------------------
       6000-DELETE-CLIC-REC.
      *--------------------

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.
014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.
014221     IF WCLI-IO-NOT-FOUND
014221* MSG: 'CLIENT NOT FOUND ON CLIENT FILE'
014221        MOVE 'XS00000058'       TO WGLOB-MSG-REF-INFO
014221        MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (1)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 6000-DELETE-CLIC-REC-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABEL @1, KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'               TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-DELETE-CLIC-REC-X
014221     END-IF.



           MOVE MIR-CLI-ID            TO WCLIC-CLI-ID.
           MOVE LOW-VALUES            TO WCLIC-CLI-CNTCT-ID-CD.
           MOVE WCLIC-KEY             TO WCLIC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCLIC-ENDBR-CLI-CNTCT-ID-CD.

           PERFORM  CLIC-1000-BROWSE
               THRU CLIC-1000-BROWSE-X.

           IF  WCLIC-IO-EOF
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
               GO TO 6000-DELETE-CLIC-REC-X
           END-IF.

           PERFORM  CLIC-2000-READ-NEXT
               THRU CLIC-2000-READ-NEXT-X.

           IF NOT WCLIC-IO-OK
               PERFORM  CLIC-3000-END-BROWSE
                   THRU CLIC-3000-END-BROWSE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
               GO TO 6000-DELETE-CLIC-REC-X
           END-IF.

           PERFORM  CLIC-3000-END-BROWSE
               THRU CLIC-3000-END-BROWSE-X.

           MOVE MIR-CLI-ID            TO WCLIC-CLI-ID.
           MOVE LOW-VALUES            TO WCLIC-CLI-CNTCT-ID-CD.
           MOVE WCLIC-KEY             TO WCLIC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCLIC-ENDBR-CLI-CNTCT-ID-CD.

           PERFORM  CLIC-1000-DELETE-KEY-RANGE
               THRU CLIC-1000-DELETE-KEY-RANGE-X.

           IF NOT WCLIC-IO-OK
      *MSG:  'RECORD @1 LOST IN DELETE - CONTACT SYSTEMS'
               MOVE WCLIC-CLI-ID           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
014221         GO TO 6000-DELETE-CLIC-REC-X                   
           END-IF.
           
014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

       6000-DELETE-CLIC-REC-X.
           EXIT.
      /
      *----------------
       8000-EDIT-UPDATES.
      *-----------------

           PERFORM  8100-EDIT-CLI-ID
               THRU 8100-EDIT-CLI-ID-X

           SET WS-CLI-CNTCT-ID-CD-VALID        TO  TRUE.

           PERFORM  8200-EDIT-CTYPE
               THRU 8200-EDIT-CTYPE-X
               VARYING WS-SUB FROM +1 BY +1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR NOT WS-CLI-CNTCT-ID-CD-VALID.

           IF NOT WS-CLI-CNTCT-ID-CD-VALID
      *** MSG (S) CONTACT TYPE MUST BE IN EDIT TYPE CNTTP
               MOVE 'CS61600002'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8000-EDIT-UPDATES-X
           END-IF.

           SET WS-DUP-CNTCT-ID-CD-NO           TO  TRUE.

           PERFORM  8300-CROSS-EDIT-CTYPE
               THRU 8300-CROSS-EDIT-CTYPE-X
               VARYING WS-SUB FROM +1 BY +1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR WS-DUP-CNTCT-ID-CD.

           IF  WS-DUP-CNTCT-ID-CD
      *** MSG (S) CONTACT TYPE DUPLICATION NOT ALLOWED
               MOVE 'CS61600004'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *
       8000-EDIT-UPDATES-X.
           EXIT.
      /
      *-----------------
       8100-EDIT-CLI-ID.
      *-----------------

           MOVE SPACE                    TO MIR-DV-CLI-NM
                                            WS-HOLD-CLSNM.
           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID               TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF L2435-RETRN-CLI-NOT-FOUND
      *MSG:   'CLIENT RECORD (@1) NOT FOUND'
               MOVE MIR-CLI-ID           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000058'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8100-EDIT-CLI-ID-X
           END-IF.

           MOVE MIR-CLI-ID                 TO RCLIC-CLI-ID.
           MOVE L2435-CLI-ENTR-GIV-NM      TO L0620-CLI-GIV-NM.
           MOVE L2435-CLI-ENTR-SUR-NM      TO L0620-CLI-SUR-NM.
014653     MOVE L2435-CLI-MID-INIT-NM      TO L0620-CLI-MID-INIT-NM.
014653     MOVE L2435-CLI-SFX-NM           TO L0620-CLI-SFX-NM.
           MOVE L2435-CLI-ENTR-CO-NM       TO L0620-CLI-CO-NM.
           MOVE L2435-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

           MOVE L0620-SCREEN-NAME          TO MIR-DV-CLI-NM
                                              WS-HOLD-CLSNM.

       8100-EDIT-CLI-ID-X.
           EXIT.
      /
      *----------------
       8200-EDIT-CTYPE.
      *----------------

           IF  WS-BUS-FCN-LIST
               GO TO 8200-EDIT-CTYPE-X
           END-IF.
      *
           IF WS-PRCES-CNTCT-ID-CD (WS-SUB) = SPACES
           OR WS-PRCES-CNTCT-ID-CD (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              GO TO 8200-EDIT-CTYPE-X
           END-IF.

           MOVE WS-PRCES-CNTCT-ID-CD (WS-SUB) TO  WEDIT-ETBL-VALU-ID.

           PERFORM  CNTP-1000-EDIT
               THRU CNTP-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
              SET WS-CLI-CNTCT-ID-CD-INVALID         TO  TRUE
           END-IF.

       8200-EDIT-CTYPE-X.
           EXIT.
      /
      *---------------------
       8300-CROSS-EDIT-CTYPE.
      *---------------------

           IF WS-PRCES-CNTCT-ID-CD (WS-SUB) = SPACES
           OR WS-PRCES-CNTCT-ID-CD (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              GO TO 8300-CROSS-EDIT-CTYPE-X
           END-IF.

           PERFORM  8320-EDIT-DUP-CTYPES
               THRU 8320-EDIT-DUP-CTYPES-X
               VARYING WS-SUB1 FROM +1 BY +1
               UNTIL WS-SUB1 > WS-MAX-BROWSE-LINES
                  OR WS-DUP-CNTCT-ID-CD.

       8300-CROSS-EDIT-CTYPE-X.
           EXIT.
      /
      *--------------------
       8320-EDIT-DUP-CTYPES.
      *--------------------

           IF WS-SUB = WS-SUB1
              GO TO 8320-EDIT-DUP-CTYPES-X
           END-IF.

           IF WS-PRCES-CNTCT-ID-CD (WS-SUB) =
              WS-PRCES-CNTCT-ID-CD (WS-SUB1)
              SET WS-DUP-CNTCT-ID-CD       TO  TRUE
           END-IF.

       8320-EDIT-DUP-CTYPES-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-CLI-CNTCT-ID-CD-G.
           MOVE SPACES                 TO MIR-CLI-CNTCT-ID-TXT-G.
           MOVE SPACES                 TO MIR-DV-CLI-NM.
           MOVE SPACES                 TO MIR-CLI-CNTCT-ID-CD.
           MOVE SPACES                 TO MIR-CLI-CNTCT-ID-TXT.
           MOVE WS-HOLD-CLSNM          TO MIR-DV-CLI-NM.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF WS-BUS-FCN-LIST
               MOVE RCLIC-CLI-CNTCT-ID-CD
                                     TO MIR-CLI-CNTCT-ID-CD-T (WS-SUB)
               MOVE RCLIC-CLI-CNTCT-ID-TXT
                                     TO MIR-CLI-CNTCT-ID-TXT-T (WS-SUB)
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                    TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE        TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                       TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID                TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9500-MOVE-REC-FROM-PRCES.
      *--------------------------

           IF WS-PRCES-CNTCT-ID-CD (WS-SUB) = SPACES
           OR WS-PRCES-CNTCT-ID-CD (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
              GO TO 9500-MOVE-REC-FROM-PRCES-X
           END-IF.

           MOVE WS-PRCES-CNTCT-ID-CD (WS-SUB)
                                 TO  MIR-CLI-CNTCT-ID-CD-T (WS-SUB).
           MOVE WS-PRCES-CNTCT-ID-TXT (WS-SUB)
                                 TO  MIR-CLI-CNTCT-ID-TXT-T (WS-SUB).

       9500-MOVE-REC-FROM-PRCES-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPECNTP.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
025970 COPY XCPS8090.
       COPY CCPS2435.
      /
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      /
018764*COPY CCCL2435.
018764 COPY CCPL2435.
      /
       COPY CCPS5600.
      /
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
016537*COPY XCPL0280.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.
       COPY CCPACLIC.
       COPY CCPBCLIC.
       COPY CCPCCLIC.
       COPY CCPGCLIC.
016537*COPY CCPNCLIC.
016537*COPY CCPUCLIC.
016537*COPY CCPXCLIC.
      *
       COPY CCPNEDIT.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
018763*COPY XCCPHNDL.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6160                     **
      *****************************************************************
