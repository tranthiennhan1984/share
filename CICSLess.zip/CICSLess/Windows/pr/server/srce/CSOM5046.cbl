      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5046.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5046                                         **
      **  REMARKS:  CREDIT CARD HISTORY REVERSAL SCREEN              **
      **                                                             **
      **            THIS PROCESS DRIVER ALLOWS THE USER TO REVERSE   **
      **            A CREDIT CARD PAYMENT THROUGH THE PPAY REVERSAL  **
      **            FUNCTION DRIVER.                                 **
      **                                                             **
      **  DOMAIN :  BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014221**  6.2       LOGICAL LOCKING                                  **
016395**  6.2       NEW FOR RELEASE 6.2                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028620**  6.7       CREDIT CARD AND PAC PREMIUM PAYMENT REVERSAL     **
038204**  7.1       CREDIT CARD PAYMENT REVERSAL                     **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5046'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

021930*COPY XCWEBLCH.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                 PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT         VALUE '5046'.

       01  WS-WORKING-STORAGE.
           05  I                      PIC S9(4)  VALUE ZERO BINARY.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-REVERSE                 VALUE '5046'.
025970*    05  WS-TWRK-KEY                 PIC X(04) VALUE '5046'.
           05  WS-TEST-REASON              PIC X(01).
               88  WS-REASON-VALID             VALUE 'I' 'F' 'L' 'O'
                                               'B' 'E' 'X'.
           05  WS-CRC-DRW-DT               PIC X(10).
           05  WS-POL-ID.
               10  WS-POL-ID-BASE          PIC X(9).
               10  WS-POL-ID-SUFFIX        PIC X.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
      /
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
      /
       COPY CCWWCVGS.
       COPY CCFHCVGS.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWCRTX.
       COPY CCFRCRTX.
      /
014221 COPY CCFWCRCD.
014221 COPY CCFRCRCD.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFHPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
      /
       COPY CCWL0289.
      /
       COPY CCWL1651.
      /
       COPY CCWL5400.
      /
       COPY CCWLPGA.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
014221 COPY XCWL8090.
      /
       COPY XCWL1640.
      /
       COPY XCWLDTLK.
      /
038204 COPY XCWL1680.
038204 COPY XCWL1670.
038204/
038204 COPY CCWL0183.
038204 COPY CCWL2625.
038204/
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5046.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.


      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET WGLOB-GOOD-RETURN  TO TRUE.
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
           MOVE WWKDT-ZERO-DT              TO WS-CRC-DRW-DT.

           PERFORM  2100-VALIDATE-KEY-FIELDS
               THRU 2100-VALIDATE-KEY-FIELDS-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-REVERSE
                    PERFORM  3000-PROCESS-REVERSE
                        THRU 3000-PROCESS-REVERSE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5046'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------------
       2100-VALIDATE-KEY-FIELDS.
      *-------------------------

      *
      *    IF THE DATE IS ENTERED IT MUST BE VALID.
      *
           IF  MIR-CRC-TRXN-DT NOT = SPACES
               MOVE MIR-CRC-TRXN-DT   TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
      * MSG - DATE (@1) INVALID
                   MOVE 'XS00000036'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CRC-TRXN-DT
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO WS-CRC-DRW-DT
               END-IF
           END-IF.

       2100-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      *---------------------
       3000-PROCESS-REVERSE.
      *---------------------

           IF  MIR-DV-PRCES-STATE-CD    = '1'
           OR  MIR-DV-PRCES-STATE-CD    = '2'
               PERFORM  3100-REVERSE-FIRST-PASS
                   THRU 3100-REVERSE-FIRST-PASS-X
           ELSE
               IF  MIR-DV-PRCES-STATE-CD    = '3'
                   PERFORM  3200-REVERSE-SECOND-PASS
                       THRU 3200-REVERSE-SECOND-PASS-X
               END-IF
           END-IF.

       3000-PROCESS-REVERSE-X.
           EXIT.
      /
      *------------------------
       3100-REVERSE-FIRST-PASS.
      *------------------------

           PERFORM  8000-BUILD-KEYS
               THRU 8000-BUILD-KEYS-X.

018763*   PERFORM  CRCD-1000-READ-TWRK-TS
018763*       THRU CRCD-1000-READ-TWRK-TS-X.
018763     PERFORM  CRCD-1000-READ-TWRK-TS
018763         THRU CRCD-1000-READ-TWRK-TS-X.

014221     IF  WCRCD-IO-NOT-FOUND
014221*MSG: RECORD @1 NOT FOUND
014221         MOVE WCRCD-KEY
014221           TO WGLOB-MSG-PARM (1)
014221         MOVE 'XS00000001'
014221           TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         SET MIR-RETRN-RQST-FAILED
014221           TO TRUE
014221         GO TO 3100-REVERSE-FIRST-PASS-X
014221     END-IF.

           PERFORM  CRTX-1000-READ
               THRU CRTX-1000-READ-X.

           IF  NOT WCRTX-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3100-REVERSE-FIRST-PASS-X
           END-IF.

           IF  RCRTX-CRC-TRXN-STAT-REVRS
      * MSG: REVERSAL NOT ALLOWED FOR CRTX STATUS
               MOVE 'CS50460001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-DATA-TO-MIR
                   THRU 9200-MOVE-DATA-TO-MIR-X
               GO TO 3100-REVERSE-FIRST-PASS-X
           END-IF.

           MOVE RCRTX-POL-ID-SFX            TO WPOL-POL-ID-SFX.
           MOVE RCRTX-POL-ID-BASE           TO WPOL-POL-ID-BASE.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3100-REVERSE-FIRST-PASS-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET  L5400-CRCY-MSG-REQD        TO TRUE.
           SET  L5400-STAT-MSG-NOT-REQD    TO TRUE.
           SET  L5400-BRCH-MSG-NOT-REQD    TO TRUE.
           SET  L5400-POL-XFER-UPDATE      TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  NOT L5400-CRCY-ACCS-ALLOW
               OR  L5400-XFER-ACCS-RESTRICTED
               GO TO 3100-REVERSE-FIRST-PASS-X
           END-IF.

           PERFORM  3350-EDIT-REVERSAL-REASON
               THRU 3350-EDIT-REVERSAL-REASON-X.

           PERFORM  9200-MOVE-DATA-TO-MIR
               THRU 9200-MOVE-DATA-TO-MIR-X.

           IF  MIR-CRC-TRXN-REVRS-CD     = SPACES
               GO TO 3100-REVERSE-FIRST-PASS-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW       = ZERO
               MOVE 'CS00000016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'XS00000219'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-2000-GET-MESSAGE
                   THRU 0260-2000-GET-MESSAGE-X
           END-IF.

       3100-REVERSE-FIRST-PASS-X.
           EXIT.
      /
      *-------------------------
       3200-REVERSE-SECOND-PASS.
      *-------------------------

           PERFORM  8000-BUILD-KEYS
               THRU 8000-BUILD-KEYS-X.

014221     PERFORM  CRCD-2000-UPDATE-TWRK-TS
014221         THRU CRCD-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CRCD'                TO WGLOB-MSG-PARM (01)
014221        MOVE WCRCD-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3200-REVERSE-SECOND-PASS-X
014221     END-IF.

014221     IF  WCRCD-IO-NOT-FOUND
014221*MSG: RECORD @1 NOT FOUND
014221         MOVE WCRCD-KEY
014221           TO WGLOB-MSG-PARM (1)
014221         MOVE 'XS00000001'
014221           TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         SET MIR-RETRN-RQST-FAILED
014221           TO TRUE
014221        GO TO 3200-REVERSE-SECOND-PASS-X
014221     END-IF.

           PERFORM  CRTX-1000-READ-FOR-UPDATE
               THRU CRTX-1000-READ-FOR-UPDATE-X.

           IF  NOT WCRTX-IO-OK
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CRCD-3000-UNLOCK
014221             THRU CRCD-3000-UNLOCK-X
               GO TO 3200-REVERSE-SECOND-PASS-X
           END-IF.

           MOVE MIR-CRC-TRXN-REVRS-CD  TO RCRTX-CRC-TRXN-REVRS-CD.

           PERFORM  9200-MOVE-DATA-TO-MIR
               THRU 9200-MOVE-DATA-TO-MIR-X.

           IF  WGLOB-GOOD-RETURN
               PERFORM  3300-REVERSE-CRTX
                   THRU 3300-REVERSE-CRTX-X
           END-IF.

           IF  WGLOB-GOOD-RETURN
      *        MOVE 'CS50460002'      TO WGLOB-MSG-REF-INFO
      *        PERFORM  0260-1000-GENERATE-MESSAGE
      *            THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'R'               TO RCRTX-CRC-TRXN-STAT-CD
               MOVE 'R'               TO MIR-CRC-TRXN-STAT-CD
               PERFORM  CRTX-2000-REWRITE
                   THRU CRTX-2000-REWRITE-X
014221         PERFORM  CRCD-2000-REWRITE
014221             THRU CRCD-2000-REWRITE-X
014221         PERFORM  CRCD-1000-READ-TWRK-TS
014221             THRU CRCD-1000-READ-TWRK-TS-X
           ELSE
               PERFORM  CRTX-3000-UNLOCK
                   THRU CRTX-3000-UNLOCK-X
014221         PERFORM  CRCD-3000-UNLOCK
014221             THRU CRCD-3000-UNLOCK-X
           END-IF.

       3200-REVERSE-SECOND-PASS-X.
           EXIT.
      /
      *------------------
       3300-REVERSE-CRTX.
      *------------------

           IF  RCRTX-CRC-TRXN-STAT-REVRS
               GO TO 3300-REVERSE-CRTX-X
           END-IF.

           MOVE RCRTX-POL-ID          TO LPGA-POLICY-NUMBER.
           MOVE 'P'                   TO WGLOB-REF-POLICY-ID.
           MOVE RCRTX-POL-ID          TO WGLOB-REF-POLICY-ID.

           MOVE RCRTX-POL-ID          TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3300-REVERSE-CRTX-X
           END-IF.

           IF  RPOL-POL-STAT-PREM-PAY-REG
           AND (RPOL-POL-PREM-NTRADL-FLEX
           OR  RPOL-POL-PREM-NTCNTRCT)
               MOVE 'CS50460002'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           MOVE WCVGS-WORK-AREA       TO HCVGS-WORK-AREA.

           PERFORM  3370-SETUP-PPAY-DATA
               THRU 3370-SETUP-PPAY-DATA-X.

           PERFORM  1651-2000-POL-REVRS
               THRU 1651-2000-POL-REVRS-X.

      * LHST RECORD NOT FOUND FOR PAYMENT REVERSAL

           IF  L1651-RETRN-LOAN-ERROR
               SET WGLOB-RETURN-ERROR     TO  TRUE
               GO TO 3300-REVERSE-CRTX-X
           END-IF.

           IF  NOT L1651-RETRN-OK
               PERFORM  3380-RETRY-PPAY
                   THRU 3380-RETRY-PPAY-X
           END-IF.

           MOVE  RPOL-REC-INFO        TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY             TO  WPOL-KEY.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.

           MOVE WGLOB-PROCESS-DATE    TO RPOL-PREV-FILE-MAINT-DT.

            PERFORM  0289-1000-INIT-PARM-INFO
                THRU 0289-1000-INIT-PARM-INFO-X.

            IF  WS-CRC-DRW-DT = WWKDT-ZERO-DT
                CONTINUE
            ELSE
                 MOVE WS-CRC-DRW-DT        TO L0289-LO-PAC-DT
                 MOVE WS-CRC-DRW-DT        TO L0289-LO-CRC-DT
                 MOVE WS-CRC-DRW-DT        TO L0289-PROC-EFF-DT
            END-IF.

            PERFORM  0289-1000-OBTAIN-NXT-ACTV
                THRU 0289-1000-OBTAIN-NXT-ACTV-X.

            IF  L0289-RETRN-OK
                MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
                MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
            ELSE
                MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
                MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
            END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           IF  WCVGS-WORK-AREA NOT         = HCVGS-WORK-AREA
               PERFORM  3400-REWRITE-COVERAGES
                   THRU 3400-REWRITE-COVERAGES-X
                   VARYING I FROM +1 BY +1
                   UNTIL I > RPOL-POL-CVG-REC-CTR-N
           END-IF.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       3300-REVERSE-CRTX-X.
           EXIT.
      /
      *--------------------------
       3350-EDIT-REVERSAL-REASON.
      *--------------------------

           IF  MIR-CRC-TRXN-REVRS-CD = SPACES
      * MSG - PLEASE ENTER REVERSAL REASON
               MOVE 'CS50460003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3350-EDIT-REVERSAL-REASON-X
           END-IF.

           MOVE MIR-CRC-TRXN-REVRS-CD  TO WS-TEST-REASON.
           MOVE MIR-CRC-TRXN-REVRS-CD  TO RCRTX-CRC-TRXN-REVRS-CD.

           IF  NOT WS-REASON-VALID
      * MSG - REVERSAL REASON MUST BE I,F,L,O,B,E,X
               MOVE 'CS50460004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3350-EDIT-REVERSAL-REASON-X.
           EXIT.
      /
      *---------------------
       3370-SETUP-PPAY-DATA.
      *---------------------

           PERFORM  1651-0000-INIT-PARM-INFO
               THRU 1651-0000-INIT-PARM-INFO-X.

           PERFORM  1651-1000-BUILD-PARM-INFO
               THRU 1651-1000-BUILD-PARM-INFO-X.

           SET L1651-RQST-POL-PMT-REVRS    TO TRUE.
028620     SET L1651-UNDO-ORIGIN-PREMSUS   TO TRUE.
           MOVE RCRTX-CRC-TRXN-DT     TO L1651-EFF-DT.
           MOVE MIR-CRC-TRXN-REVRS-CD TO L1651-REVRS-REASN-CD.
           MOVE RCRTX-SBSDRY-CO-ID    TO L1651-SBSDRY-CO-ID.

           COMPUTE L1651-CRC-AMT
                 = RCRTX-CRC-TRXN-MPREM-AMT
                 + RCRTX-CRC-TRXN-SNDRY-AMT
                 + RCRTX-CRC-TRXN-LOAN-AMT
                 - RCRTX-PREM-SUSP-AMT.

038204*    IF  RPOL-POL-STAT-PREM-PAY-REG
038204*        MOVE RCRTX-CRC-TRXN-MPREM-AMT
038204*                               TO L1651-PREM-AMT
038204*        MOVE RCRTX-CRC-TRXN-SNDRY-AMT
038204*                               TO L1651-SUSP-AMT
038204*        MOVE RCRTX-CRC-TRXN-LOAN-AMT
038204*                               TO L1651-LOAN-AMT
038204*        MULTIPLY -1 BY RCRTX-PREM-SUSP-AMT
038204*                                  GIVING L1651-PRM-SUSP-AMT
038204
038204     IF  RPOL-POL-STAT-PREM-PAY-REG
038204         IF NOT RCRTX-CRC-TRXN-MPREM-AMT > ZEROES
038204             MOVE RCRTX-CRC-TRXN-MPREM-AMT
038204                                TO L1651-PREM-AMT
038204             MOVE RCRTX-CRC-TRXN-SNDRY-AMT
038204                                TO L1651-SUSP-AMT
038204             MOVE RCRTX-CRC-TRXN-LOAN-AMT
038204                                TO L1651-LOAN-AMT
038204             MULTIPLY -1 BY RCRTX-PREM-SUSP-AMT
038204                                   GIVING L1651-PRM-SUSP-AMT
038204         ELSE
038204             PERFORM  3375-CALC-PD-TO-DT
038204                 THRU 3375-CALC-PD-TO-DT-X
038204         END-IF
           ELSE
               MOVE L1651-CRC-AMT     TO L1651-SUSP-AMT
      * MSG - POLICY @1 IS NOT PREMIUM PAYING - PTD WILL NOT BE CHANGED
               MOVE 'CS50460005'      TO WGLOB-MSG-REF-INFO
               MOVE RCRTX-POL-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3370-SETUP-PPAY-DATA-X.
           EXIT.
      /
038204*---------------------
038204 3375-CALC-PD-TO-DT.
038204*---------------------
038204*
038204*   CALCULATE THE NORMAL PAID TO DATE
038204*
038204     PERFORM  2625-0000-INIT-PARM-INFO
038204         THRU 2625-0000-INIT-PARM-INFO-X.
038204
038204     MOVE RPOL-POL-PD-TO-DT-NUM TO L0183-CRNT-PREM-DT
038204
038204     PERFORM  PTD-2000-CALC-PREV-PREM-DT
038204         THRU PTD-2000-CALC-PREV-PREM-DT-X.
038204
038204     IF  RCRTX-CRC-TRXN-DUE-DT > L0183-NEW-PREM-DT
038204         MOVE RCRTX-CRC-TRXN-MPREM-AMT TO L1651-PRM-SUSP-AMT
038204         IF  RPOL-POL-PREM-SUSP-AMT NOT > L1651-PRM-SUSP-AMT
038204             MOVE WWKDT-ZERO-DT        TO RPOL-POL-PMT-DRW-DT
038204         END-IF
038204     ELSE
038204         MOVE L0183-NEW-PREM-DT        TO L1651-EFF-DT
038204         MOVE RCRTX-CRC-TRXN-MPREM-AMT TO L1651-PREM-AMT
038204         SUBTRACT RCRTX-PREM-SUSP-AMT FROM
038204                      L1651-PRM-SUSP-AMT GIVING L1651-PRM-SUSP-AMT
038204     END-IF.
038204
038204     MOVE RCRTX-CRC-TRXN-SNDRY-AMT     TO L1651-SUSP-AMT.
038204     MOVE RCRTX-CRC-TRXN-LOAN-AMT      TO L1651-LOAN-AMT.
038204
038204 3375-CALC-PD-TO-DT-X.
038204     EXIT.
038204/
      *----------------
       3380-RETRY-PPAY.
      *----------------

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.
           MOVE ZERO                  TO WGLOB-RETURN-CODE.
           SET  L1651-RETRN-OK        TO TRUE.
           MOVE ZEROES                TO L1651-LOAN-AMT.
           MOVE ZEROES                TO L1651-PREM-AMT.

           IF  RPOL-POL-STAT-PREM-PAY-REG
               MOVE L1651-CRC-AMT     TO L1651-PRM-SUSP-AMT
               MOVE ZEROES            TO L1651-SUSP-AMT
           ELSE
               IF  (RPOL-POL-STAT-IN-FORCE
               OR  RPOL-POL-SUSPENDED)
                   MOVE L1651-CRC-AMT TO L1651-SUSP-AMT
                   MOVE ZEROES        TO L1651-PRM-SUSP-AMT
               ELSE
                   MOVE L1651-CRC-AMT TO L1651-OS-DISB-AMT
                   MOVE ZEROES        TO L1651-SUSP-AMT
                   MOVE ZEROES        TO L1651-PRM-SUSP-AMT
               END-IF
           END-IF.

           PERFORM  1651-2000-POL-REVRS
               THRU 1651-2000-POL-REVRS-X.

           IF  NOT L1651-RETRN-OK
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

       3380-RETRY-PPAY-X.
           EXIT.
      /
      *-----------------------
       3400-REWRITE-COVERAGES.
      *-----------------------

           IF  HCVGS-CVG-INFO (I)      NOT = WCVGS-CVG-INFO (I)
               MOVE WCVGS-CVG-INFO (I)      TO HCVGS-CVG-INFO (I)
               MOVE RPOL-POL-ID       TO WCVG-POL-ID
               MOVE I                 TO WCVG-CVG-NUM-N
               PERFORM  CVG-1000-READ-FOR-UPDATE
                   THRU CVG-1000-READ-FOR-UPDATE-X
               IF  WCVG-IO-OK
                   MOVE HCVGS-CVG-INFO (I)
                                      TO RCVG-CVG-INFO
                   PERFORM  CVG-2000-REWRITE
                       THRU CVG-2000-REWRITE-X
               ELSE
                   MOVE 'CS00000024'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       3400-REWRITE-COVERAGES-X.
           EXIT.
      /
      *--------------------
       8000-BUILD-KEYS.
      *--------------------

           MOVE MIR-CRC-ID            TO WCRTX-CRC-ID.
           MOVE MIR-CRC-TYP-CD        TO WCRTX-CRC-TYP-CD.
           MOVE MIR-CRC-TRXN-DT       TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               MOVE WWKDT-ZERO-DT    TO WCRTX-CRC-TRXN-DT
           ELSE
               MOVE L1640-INTERNAL-DATE
                                     TO WCRTX-CRC-TRXN-DT
           END-IF.

           MOVE MIR-CRC-TRXN-SEQ-NUM  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE 4                     TO L0280-LENGTH.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WCRTX-CRC-TRXN-SEQ-NUM
           ELSE
      * MSG: 'INVALID NUMERIC FIELD'
               MOVE 'XS00000018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE ZERO              TO WCRTX-CRC-TRXN-SEQ-NUM
           END-IF.

014221     MOVE MIR-CRC-TYP-CD         TO WCRCD-CRC-TYP-CD.
014221     MOVE MIR-CRC-ID             TO WCRCD-CRC-ID.

       8000-BUILD-KEYS-X.
           EXIT.
      /
      *-------------------------
       8800-DEFAULT-POLICY-INFO.
      *-------------------------

           MOVE RPOL-POL-MPREM-AMT     TO RCRTX-CRC-TRXN-MPREM-AMT.
           MOVE RPOL-POL-LOAN-REPAY-AMT
                                       TO RCRTX-CRC-TRXN-LOAN-AMT.
           MOVE RPOL-POL-SNDRY-AMT     TO RCRTX-CRC-TRXN-SNDRY-AMT.
           MOVE RPOL-POL-PREM-SUSP-AMT TO RCRTX-PREM-SUSP-AMT.

       8800-DEFAULT-POLICY-INFO-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES            TO MIR-SBSDRY-CO-ID.
           MOVE SPACES            TO MIR-CRC-TRXN-STAT-CD.
           MOVE SPACES            TO MIR-CRC-TRXN-AMT.
           MOVE SPACES            TO MIR-CRC-TRXN-CRCY-CD.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *----------------------
       9200-MOVE-DATA-TO-MIR.
      *----------------------

           MOVE RCRTX-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
           MOVE RCRTX-CRC-TRXN-STAT-CD TO MIR-CRC-TRXN-STAT-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = RCRTX-CRC-TRXN-AMT * 100.
020874     MOVE RCRTX-CRC-TRXN-AMT     TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-TRXN-AMT
                                       TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CRC-TRXN-AMT.
           MOVE RCRTX-CRC-TRXN-CRCY-CD TO MIR-CRC-TRXN-CRCY-CD.

       9200-MOVE-DATA-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1651-0000-INIT-PARM-INFO
025970         THRU 1651-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
038204     PERFORM  1670-0000-INIT-PARM-INFO
038204         THRU 1670-0000-INIT-PARM-INFO-X.
038204
038204     PERFORM  1680-0000-INIT-PARM-INFO
038204         THRU 1680-0000-INIT-PARM-INFO-X.
038204
038204     PERFORM  0183-0000-INIT-PARM-INFO
038204         THRU 0183-0000-INIT-PARM-INFO-X.
038204
038204     PERFORM  2625-0000-INIT-PARM-INFO
038204         THRU 2625-0000-INIT-PARM-INFO-X.
038204
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                     TO WWKDT-WORK-FIELDS.
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *                      PROCESSING COPYBOOKS                     *
      *****************************************************************
021930*COPY CCPSPGA.
021930*
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
      /
       COPY XCPPINIT.
      /
038204 COPY CCPPPTD.
038204/
       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CRCD
014221                         '$VAR2' BY 'CRCD'.
      /
      *****************************************************************
      *                      LINK COPYBOOKS                           *
      *****************************************************************
018764*COPY CCCL0289.
018764 COPY CCPL0289.
025970 COPY XCPS8090.
       COPY CCPS0289.
      /
018764*COPY CCCL1651.
018764 COPY CCPL1651.
       COPY CCPS1651.
      /
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
       COPY XCPL0290.
       COPY XCPS0290.
      /
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
038204 COPY XCPS1680.
038204 COPY XCPL1680.
038204 COPY XCPS1670.
038204/
038204 COPY CCPS0183.
038204 COPY CCPL0183.
038204 COPY CCPS2625.
038204 COPY CCPL2625.
038204/
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPNCRTX.
       COPY CCPUCRTX.
      /
014221 COPY CCPNCRCD.
014221 COPY CCPUCRCD.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM5046                     **
      *****************************************************************


