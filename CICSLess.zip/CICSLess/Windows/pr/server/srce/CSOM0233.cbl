      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0233.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0233                                         **
      **  REMARKS:  THIS MODULE PERFORMS CANCEL FUNCTION             **
      **            FOR THE CHTX TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016457**  6.2       NEW                                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0233'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-CANCEL                   VALUE '0233'.
           05  WS-CHQ-DT                               PIC X(10).
           05  WS-CHQ-PRCES-DT                         PIC X(10).
           05  WS-CHQ-AMT                              PIC S9(13)V9(02)
                                                       BINARY.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
021930*COPY CCWLPGA.
       COPY XCWLDTLK.
       COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFRCHTX.
       COPY CCFWCHTX.
       COPY CCFWCHTD.
      /
       COPY CCFWSCOM.
       COPY CCFRSCOM.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
018764*COPY XCWLPTR.
      /
       COPY XCWL1640.
      /
       COPY XCWL0290.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0233.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783*    SET MIR-RETRN-OK           TO  TRUE.
034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CANCEL
                    PERFORM  3000-CANCEL
                        THRU 3000-CANCEL-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0233'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *---------------
       3000-CANCEL.
      *---------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  7300-EDIT-INPUT
               THRU 7300-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 3000-CANCEL-X
           END-IF.

           MOVE WS-CHQ-PRCES-DT         TO RCHTX-CHQ-PRCES-DT.
           SET RCHTX-CHQ-STAT-CNCL      TO TRUE.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF  MIR-DV-PRCES-STATE-CONFIRM
               PERFORM  CHTX-2000-REWRITE
                   THRU CHTX-2000-REWRITE-X
      *MSG: YOUR TRANSACTION HAS BEEN PROCESSED
               MOVE 'CS00000011'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  CHTX-3000-UNLOCK
                   THRU CHTX-3000-UNLOCK-X
      *MSG: PLEASE VERIFY TRANSACTION
               MOVE 'CS00000016'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       3000-CANCEL-X.
           EXIT.
      /
      *----------------
       7300-EDIT-INPUT.
      *----------------

           PERFORM  7310-EDIT-SBSDRY-CO-ID
               THRU 7310-EDIT-SBSDRY-CO-ID-X.

           PERFORM  7320-EDIT-CHQ-DT
               THRU 7320-EDIT-CHQ-DT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 7300-EDIT-INPUT-X
           END-IF.

           MOVE MIR-CHQ-ID                  TO WCHTD-CHQ-ID.
           MOVE MIR-SBSDRY-CO-ID            TO WCHTD-SBSDRY-CO-ID.
           MOVE WS-CHQ-DT                   TO WCHTD-CHQ-DT.

           PERFORM  CHTD-1000-READ
               THRU CHTD-1000-READ-X.

           IF  NOT WCHTD-IO-OK
      *MSG: CHEQUE MUST EXIST
               MOVE 'CS02330101'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7300-EDIT-INPUT-X
           END-IF.

           MOVE RCHTX-CHQ-PART-NUM          TO WCHTX-CHQ-PART-NUM.
036742*    MOVE RCHTX-USER-ID               TO WCHTX-USER-ID.
036742*    MOVE RCHTX-CHQ-INSTC-ID          TO WCHTX-CHQ-INSTC-ID.
036742*    MOVE RCHTX-CHQ-TS                TO WCHTX-CHQ-TS.
036742     MOVE RCHTX-CHQ-GEN-ID            TO WCHTX-CHQ-GEN-ID.           

           PERFORM  CHTX-1000-READ-FOR-UPDATE
               THRU CHTX-1000-READ-FOR-UPDATE-X.

           PERFORM  7330-EDIT-CHQ-STAT-CD
               THRU 7330-EDIT-CHQ-STAT-CD-X.

           PERFORM  7340-EDIT-CHQ-PRCES-DT
               THRU 7340-EDIT-CHQ-PRCES-DT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               PERFORM  CHTX-3000-UNLOCK
                   THRU CHTX-3000-UNLOCK-X
           END-IF.


       7300-EDIT-INPUT-X.
           EXIT.

      *-----------------------
       7310-EDIT-SBSDRY-CO-ID.
      *-----------------------

           MOVE MIR-SBSDRY-CO-ID            TO WSCOM-SBSDRY-CO-ID.
           PERFORM  SCOM-1000-READ
               THRU SCOM-1000-READ-X.
           IF  NOT WSCOM-IO-OK
      *MSG: SUB CO DOES NOT EXIST
               MOVE 'CS02330102'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7310-EDIT-SBSDRY-CO-ID-X.
           EXIT.

      *-------------------------
       7320-EDIT-CHQ-DT.
      *-------------------------

           MOVE MIR-CHQ-DT               TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      *MSG: INVALID CHEQUE DATE
               MOVE 'CS02330103'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WWKDT-ZERO-DT        TO WS-CHQ-DT
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-CHQ-DT
           END-IF.


       7320-EDIT-CHQ-DT-X.
           EXIT.

      *-----------------------
       7330-EDIT-CHQ-STAT-CD.
      *-----------------------

           EVALUATE TRUE

               WHEN RCHTX-CHQ-STAT-NO-DATA
      *MSG: CHEQUE RECORD INCOMPLETE
                    MOVE 'CS02330104'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RCHTX-CHQ-STAT-CNCL
      *MSG: CHEQUE ALREADY CANCELLED
                    MOVE 'CS02330105'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

       7330-EDIT-CHQ-STAT-CD-X.
           EXIT.


      *-------------------------
       7340-EDIT-CHQ-PRCES-DT.
      *-------------------------

           IF  MIR-CHQ-PRCES-DT = EBLCH-BLANK-FIELD-CHAR
           OR  MIR-CHQ-PRCES-DT = SPACE
               MOVE WGLOB-PROCESS-DATE      TO WS-CHQ-PRCES-DT
           ELSE
               MOVE MIR-CHQ-PRCES-DT        TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF L1640-NOT-VALID
      *MSG: INVALID PROCESS DATE
                   MOVE 'CS02330106'        TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE WWKDT-ZERO-DT       TO WS-CHQ-PRCES-DT
               ELSE
                   MOVE L1640-INTERNAL-DATE TO WS-CHQ-PRCES-DT
               END-IF
           END-IF.

           EVALUATE TRUE

               WHEN WS-CHQ-PRCES-DT = WWKDT-ZERO-DT
      *MSG: ENTER DATE IN CORRECT FORMAT
                    MOVE 'CS00000036'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN WS-CHQ-PRCES-DT > WGLOB-PROCESS-DATE
      *MSG: DATE IN FUTURE.  RE-ENTER
                    MOVE 'CS00000037'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN WS-CHQ-PRCES-DT < RCHTX-CHQ-DT
      *MSG: DATE ENTERED IS BEFORE CHEQUE DATE.  RE-ENTER
                    MOVE 'CS02330107'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.


       7340-EDIT-CHQ-PRCES-DT-X.
           EXIT.


      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RCHTX-CHQ-ID             TO MIR-CHQ-ID.
           MOVE RCHTX-SBSDRY-CO-ID       TO MIR-SBSDRY-CO-ID.

           MOVE RCHTX-CHQ-DT             TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CHQ-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CHQ-DT
           END-IF.

           MOVE RCHTX-CHQ-MICR-NUM       TO MIR-CHQ-MICR-NUM.

020874*    COMPUTE L0290-INPUT-NUMBER = RCHTX-CHQ-AMT * 100.
020874     MOVE RCHTX-CHQ-AMT            TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CHQ-AMT    TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CHQ-AMT.

           MOVE RCHTX-CHQ-CRCY-CD        TO MIR-CHQ-CRCY-CD.
           MOVE RCHTX-CHQ-PAYE-1-TXT     TO MIR-CHQ-PAYE-1-TXT.
           MOVE RCHTX-CHQ-PAYE-2-TXT     TO MIR-CHQ-PAYE-2-TXT.

           MOVE RCHTX-CHQ-PRCES-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CHQ-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CHQ-PRCES-DT
           END-IF.

           MOVE RCHTX-CHQ-TYP-CD         TO MIR-CHQ-TYP-CD.
           MOVE RCHTX-CHQ-STAT-CD        TO MIR-CHQ-STAT-CD.


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-WORKING-STORAGE.
025970
025970     MOVE SPACES TO  WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS0290.
       COPY XCPL0290.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPUCHTX.
       COPY CCPNCHTD.
      /
       COPY CCPNSCOM.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0233
      *****************************************************************
