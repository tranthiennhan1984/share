      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0196.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0196                                         **
      **  REMARKS:  PROJ - GENERATE POLICY PROJECTED VALUES.         **
      **            THIS MODULE WILL CONTROL THE GENERATION OF       **
      **            PROJECTED POLICY CASH VALUES AND DEATH BENEFITS. **
      **            THESE PROJECTIONS WILL BE DONE AS OF AN EFFECTIVE**
      **            DATE EITHER DEFAULTED TO THE ISSUE DATE OR AT A  **
      **            PRE-ELECTED EFFECTIVE DATE.  PROJECTIONS ARE DONE**
      **            UNDER TWO CONDITIONS; THE FIRST IS GUARANTEED    **
      **            MORTALITY RATES AND FUND GROWTH RATES.  THE      **
      **            SECOND IS CURRENT MORTALITY RATES AND FUND       **
      **            GROWTH RATES.                                    **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       ADJUST TSQP LENGTH DUE TO AMT FIELDS INCREASE    **
008455**  5.5.2     AMOUNT FIELD SIZING FOR INTERNATIONAL SUPPORT    **
007685**  5.6       CHANGES REQUIRED FOR NAIC PROJECTIONS            **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
011365**  5.6       CORRECT ISWL PROJECTIONS                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016440**  6.2       COMBINE NBS AND ADMIN - ONLINE REQUIREMENTS      **
018059**  6.2       PRESENTATION ENHANCEMENTS                        **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0196'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANSACTION-NAME       PIC X(4) VALUE 'PROJ'.
           05  WS-BUS-FCN-ID             PIC X(4).
               88  WS-BUS-FCN-VALID       VALUE  '0251' '0252' '0253'.
               88  WS-BUS-FCN-UPDATE      VALUE  '0252'.
               88  WS-BUS-FCN-REFRESH     VALUE  '0251'.
               88  WS-BUS-FCN-CALCULATE   VALUE  '0253'.
           05  WS-POL-ID.
               10  WS-POL-ID-BASE        PIC X(09).
               10  WS-POL-ID-SFX         PIC X(01).
           05  WS-EDIT-3V4               PIC 9(3).9(4).
           05  WS-EDIT-18V0              PIC 9(18) COMP-3.
           05  WS-EDIT-14V4 REDEFINES
               WS-EDIT-18V0              PIC 9(14)V9(4) COMP-3.
           05  WS-INT-RATE-HOLD          PIC 9(3)V9(4).
557660     05  WS-YEAR-PLUS-10           PIC 999 VALUE 000.
557660     05  WS-YEAR-PLUS-00           PIC 999 VALUE 000.
           05  WS-EFF-DATE               PIC X(10).
007685     05  WS-POLICY-YEAR            PIC 9(03) VALUE ZEROES.
           05  WS-CURR-INT               PIC 9V9(7).
           05  WS-GUAR-INT               PIC 9V9(7).
           05  WS-DB-OPTION              PIC X.
           05  WS-MODE                   PIC 9(2).
008455     05  WS-LUMP-SUM-INC           PIC 9(13)V99.
008455     05  WS-INIT-PREM              PIC 9(15)V99.
008455     05  WS-PLANNED-PREM           PIC 9(13)V99.
007685     05  WS-PIC9-3                 PIC 9(03).
557756     05  WS-I-NUM                  PIC 9(05).
025970 01  WS-CONSTANTS.
025970     05  WS-TRANSACTION-NAME            PIC X(4).
025970         88 WS-TRANSACTION-NAME-DEFAULT VALUE 'PROJ'.

      *
      *****************************************************************
      *  COMMON COPYBOOKS
      *****************************************************************
       COPY CCWWINDX.
       COPY XCWLDTLK.
       COPY XCWWWKDT.
      *
      *****************************************************************
      *  I/O COPYBOOKS
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.
      *
       COPY CCFWPOL.
      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION
      *****************************************************************
020478 COPY CCWL2626.
       COPY CCWL1600.
016440 COPY CCWL5400.
      *
       COPY XCWL0280.
008455 COPY XCWL0290.
       COPY XCWL1640.
013578*COPY XCWL2490.
      *
      *
      *****************************************************************
      *  INPUT PARAMETER INFORMATION
      *****************************************************************
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0196.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *---------------
       0000-MAINLINE.
      *---------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

      *
      *  SETUP GLOBAL PARAMETERS
      *
           PERFORM  9200-SETUP-MSIN-REFERENCE
               THRU 9200-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

      *
      *  STORE MIR POLICY NUMBER INTO THE L1600 AREA
      *
           PERFORM  1600-0000-INIT-PARM-INFO
               THRU 1600-0000-INIT-PARM-INFO-X.

           MOVE MIR-POL-ID-BASE           TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO WS-POL-ID-SFX.
008455
008455*
008455*  INITIALIZE NUMERIC FORMATTING AREA
008455*
008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

      *
      *  VALIDATE THE KEYED INPUT FIELDS
      *  IF ANY ERRORS ARE ENCOUNTERED, EXIT PARAGRAPH
      *
           PERFORM  3000-VALIDATE-INPUT
               THRU 3000-VALIDATE-INPUT-X.

           IF  WGLOB-GOOD-RETURN
               CONTINUE
           ELSE
               PERFORM  8500-SCREEN-CLEAR
                   THRU 8500-SCREEN-CLEAR-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *
      *  PROCESS REQUEST
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-REFRESH
                    PERFORM  4000-PROCESS-REFRESH
                        THRU 4000-PROCESS-REFRESH-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-MAINTAIN
                        THRU 5000-PROCESS-MAINTAIN-X

               WHEN WS-BUS-FCN-CALCULATE
                    PERFORM  6000-PROCESS-PROJECT
                        THRU 6000-PROCESS-PROJECT-X

           END-EVALUATE.


       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *--------------------
       3000-VALIDATE-INPUT.
      *--------------------

      *****************************************************************
      *  VALIDATE THE KEYED INPUT FIELDS
      *****************************************************************

      *
      *  READ THE POLICY RECORD
      *
           MOVE WS-POL-ID             TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-RETURN-ERROR       TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-VALIDATE-INPUT-X
013578     ELSE
013578         MOVE RPOL-POL-INS-TYP-CD  TO MIR-POL-INS-TYP-CD
           END-IF.

016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.

016440     SET L5400-POL-XFER-UPDATE  TO  TRUE.

016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.

016440     IF  L5400-XFER-ACCS-RESTRICTED
016440         SET WGLOB-RETURN-ERROR TO TRUE
016440         GO TO 3000-VALIDATE-INPUT-X
016440     END-IF.

      *
      *  LOAD THE COVERAGES AND DETERMINE THE FUND COVERAGE AND
      *  THE INSURANCE COVERAGE
      *
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

      *
      *  VALIDATE THE FORMAT OF THE KEYED VALUES
      *
           IF NOT WS-BUS-FCN-REFRESH
               PERFORM  3100-EDIT-SCREEN
                   THRU 3100-EDIT-SCREEN-X
           END-IF.

       3000-VALIDATE-INPUT-X.
           EXIT.
      *
      *-----------------
       3100-EDIT-SCREEN.
      *-----------------

           PERFORM  3120-EDIT-EFF-DATE
               THRU 3120-EDIT-EFF-DATE-X.

           PERFORM  3130-EDIT-CURRENT-INT
               THRU 3130-EDIT-CURRENT-INT-X.

           PERFORM  3140-EDIT-GUARANTEED-INT
               THRU 3140-EDIT-GUARANTEED-INT-X.

           PERFORM  3150-EDIT-PYMT-MODE
               THRU 3150-EDIT-PYMT-MODE-X.

           PERFORM  3160-EDIT-PLANNED-PREM
               THRU 3160-EDIT-PLANNED-PREM-X.

           PERFORM  3170-EDIT-LUMP-SUM-INC
               THRU 3170-EDIT-LUMP-SUM-INC-X.

           PERFORM  3180-EDIT-INIT-PREM
               THRU 3180-EDIT-INIT-PREM-X.

           MOVE MIR-POL-DB-OPT-CD     TO WS-DB-OPTION.
           MOVE WS-EFF-DATE           TO L1600-EFF-DT.
           MOVE WS-CURR-INT           TO L1600-CURR-INT-RT.
           MOVE WS-GUAR-INT           TO L1600-GUAR-INT-RT.
           MOVE WS-DB-OPTION          TO L1600-DB-OPT-CD.
           MOVE WS-MODE               TO L1600-MODE.
           MOVE WS-LUMP-SUM-INC       TO L1600-LUMP-SUM-INC.
           MOVE WS-INIT-PREM          TO L1600-INIT-PREM.
           MOVE WS-PLANNED-PREM       TO L1600-PLANNED-PREM.

           MOVE WS-BUS-FCN-ID         TO MIR-BUS-FCN-ID.
           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX.

           PERFORM  8600-REFRESH-SCREEN
               THRU 8600-REFRESH-SCREEN-X.

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.

       3100-EDIT-SCREEN-X.
           EXIT.
      *
      *-------------------
       3120-EDIT-EFF-DATE.
      *-------------------

           MOVE MIR-POL-ISS-EFF-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               MOVE 'CS01960007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE WGLOB-PROCESS-DATE    TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X

           END-IF.

           MOVE L1640-EXTERNAL-DATE   TO MIR-POL-ISS-EFF-DT.

           MOVE L1640-INTERNAL-DATE   TO WS-EFF-DATE.

       3120-EDIT-EFF-DATE-X.
           EXIT.
      *
      *----------------------
       3130-EDIT-CURRENT-INT.
      *----------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE  4                    TO L0280-PRECISION.
           MOVE  3                    TO L0280-LENGTH.
           MOVE  8                    TO L0280-INPUT-SIZE.
           MOVE MIR-INIT-DPOS-INT-PCT TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-EDIT-18V0
020874*        MOVE WS-EDIT-14V4      TO WS-EDIT-3V4
020874*        COMPUTE WS-CURR-INT = WS-EDIT-14V4 / 100
020874         MOVE L0280-OUTPUT-V06  TO WS-CURR-INT

           ELSE
               MOVE 'CS01960008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE +0                TO WS-EDIT-3V4
020874*        MOVE +0                TO WS-CURR-INT
           END-IF.

020874*    MOVE WS-EDIT-3V4           TO MIR-INIT-DPOS-INT-PCT.
020874     MOVE L0280-OUTPUT          TO L0290-INPUT-V00.
020874     MOVE 4                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-INIT-DPOS-INT-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-INIT-DPOS-INT-PCT.

       3130-EDIT-CURRENT-INT-X.
           EXIT.
      *
      *-------------------------
       3140-EDIT-GUARANTEED-INT.
      *-------------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE  4                    TO L0280-PRECISION.
           MOVE  3                    TO L0280-LENGTH.
           MOVE  8                    TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-GUAR-INT-PCT  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-EDIT-18V0
020874*        MOVE WS-EDIT-14V4      TO WS-EDIT-3V4
020874*        COMPUTE WS-GUAR-INT = WS-EDIT-14V4 / 100
020874         MOVE L0280-OUTPUT-V06 TO WS-GUAR-INT

           ELSE
               MOVE 'CS01960009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE +0                TO WS-GUAR-INT
020874*        MOVE +0                TO WS-EDIT-3V4

           END-IF.

020874*    MOVE WS-EDIT-3V4           TO MIR-CVG-GUAR-INT-PCT.
020874     MOVE L0280-OUTPUT          TO L0290-INPUT-V00.
020874     MOVE 4                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-GUAR-INT-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-GUAR-INT-PCT.

       3140-EDIT-GUARANTEED-INT-X.
           EXIT.
      *
      *--------------------
       3150-EDIT-PYMT-MODE.
      *--------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-POL-BILL-MODE-CD  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WS-MODE
           ELSE
               MOVE  1                TO WS-MODE
               MOVE 'CS01960010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           END-IF.

           IF  WS-MODE = 1
           OR  3
           OR  6
           OR  12
               MOVE WS-MODE           TO MIR-POL-BILL-MODE-CD
           ELSE
               MOVE  1                TO WS-MODE
               MOVE 'CS01960010'      TO WGLOB-MSG-REF-INFO
               MOVE WS-MODE           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           END-IF.

       3150-EDIT-PYMT-MODE-X.
           EXIT.
      *
      *-----------------------
       3160-EDIT-PLANNED-PREM.
      *-----------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE  2                    TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-PERI-PREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-PLAN-PERI-PREM-AMT   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-EDIT-7V2
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-PLANNED-PREM
           ELSE
               MOVE 'CS01960011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE +0                TO WS-PLANNED-PREM

           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-PLANNED-PREM * 100.
020874     MOVE WS-PLANNED-PREM       TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-PERI-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-PERI-PREM-AMT.

       3160-EDIT-PLANNED-PREM-X.
           EXIT.
      *
      *-----------------------
       3170-EDIT-LUMP-SUM-INC.
      *-----------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE  2                    TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-DV-LMPSM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-DV-LMPSM-AMT      TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-LUMP-SUM-INC
           ELSE
               MOVE 'CS01960012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE +0                TO WS-LUMP-SUM-INC

           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-LUMP-SUM-INC * 100.
020874     MOVE WS-LUMP-SUM-INC       TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-LMPSM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-LMPSM-AMT.

       3170-EDIT-LUMP-SUM-INC-X.
           EXIT.
      *
      *--------------------
       3180-EDIT-INIT-PREM.
      *--------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE  2                    TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-UL-INIT-PREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-UL-INIT-PREM-AMT  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-INIT-PREM
           ELSE
               MOVE 'CS01960013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE +0                TO WS-INIT-PREM

           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-INIT-PREM * 100.
020874     MOVE WS-INIT-PREM          TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UL-INIT-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UL-INIT-PREM-AMT.

       3180-EDIT-INIT-PREM-X.
           EXIT.
      *
      *---------------------
       4000-PROCESS-REFRESH.
      *---------------------

      *
      *  OBTAIN INITIAL MIR DISPLAY VALUES
      *
           PERFORM  1600-1000-BUILD-PARM-INFO
               THRU 1600-1000-BUILD-PARM-INFO-X.

           SET  L1600-PRCES-TYP-INIT-ONLY   TO TRUE.
           SET  L1600-INCL-PENDING-CVG      TO TRUE.

           IF  RPOL-POL-PREM-TCNTRCT
               PERFORM  1600-2000-PROJECT-TRAD
                   THRU 1600-2000-PROJECT-TRAD-X
           ELSE
               PERFORM  1600-1000-PROJECT-FLEX
                   THRU 1600-1000-PROJECT-FLEX-X
      *
      *  WRITE THE L1600 AREA TO TSQ AND DISPLAY VALUES
      *
      *        PERFORM  8200-DELETE-TSQ
      *            THRU 8200-DELETE-TSQ-X
      *        PERFORM  8100-WRITE-TSQ
      *            THRU 8100-WRITE-TSQ-X

           END-IF.

           IF  L1600-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR       TO TRUE
           END-IF.

           MOVE ZEROS                 TO WS-POLICY-YEAR.

      *
      *  REFRESH THE SCREEN BY DISPLAYING THE OBTAINED VALUES
      *
           PERFORM  8600-REFRESH-SCREEN
               THRU 8600-REFRESH-SCREEN-X.


       4000-PROCESS-REFRESH-X.
           EXIT.
      *
      *----------------------
       5000-PROCESS-MAINTAIN.
      *----------------------

           PERFORM  5200-PROCESS-UPDATE
               THRU 5200-PROCESS-UPDATE-X.

       5000-PROCESS-MAINTAIN-X.
           EXIT.
      *
      *------------------------
       5200-PROCESS-UPDATE.
      *------------------------

      *
      *  IF THE SCREEN HAS NOT DISPLAYED INITIAL VALUES AS YET,
      *  REFRESH AND OBTAIN INITIAL VALUES
      *
      *    IF  C0196-SCRN-RFRSH-REQD
013578*        PERFORM  4000-PROCESS-REFRESH
013578*            THRU 4000-PROCESS-REFRESH-X
      *    END-IF.

      *
      *  DISPLAY MIR FIELDS
      *
           PERFORM  8600-REFRESH-SCREEN
               THRU 8600-REFRESH-SCREEN-X.

      *
      *  VALIDATE THE INPUT DEATH BENEFIT OPTION
      *
557659     IF  L1600-DB-OPT-CD = 'I'
           OR 'L'
           OR 'N'
               CONTINUE
           ELSE
               MOVE 'CS01960005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               SET WGLOB-RETURN-ERROR       TO TRUE
           END-IF.


       5200-PROCESS-UPDATE-X.
           EXIT.
      *
      *---------------------
       6000-PROCESS-PROJECT.
      *---------------------
      *
      * SET INITIALIZATION DONE SO 1600 DOES NOT RE-INIT INPUT FIELDS
      *
018059     SET  L1600-INIT-DONE                TO TRUE.
      *
      *    GENERATE PROJECTION.
      *
           IF  NOT RPOL-POL-INS-TYP-FLEXIBLE
011365     AND NOT RPOL-POL-INS-TYP-ISWL
               PERFORM  6200-PROCESS-PROJ-TRAD
                   THRU 6200-PROCESS-PROJ-TRAD-X
           ELSE
               PERFORM  6100-PROCESS-PROJ-FLEX
                   THRU 6100-PROCESS-PROJ-FLEX-X
           END-IF.

       6000-PROCESS-PROJECT-X.
           EXIT.
      *
      *-----------------------
       6100-PROCESS-PROJ-FLEX.
      *-----------------------

      *
      *  IF THE FORCE-CODE IS '3' THE PROJECTIONS HAVE ALREADY BEEN
      *  MADE.  DISPLAY THE VALUES CALCULATED.
      *
      *    IF  MIR-FORCE = '3'
      *        IF  WTSQP-QUEUE-OK
      *            PERFORM  6300-MOVE-TO-SCREEN
      *                THRU 6300-MOVE-TO-SCREEN-X
      *            GO TO 6100-PROCESS-PROJ-FLEX-X
      *         END-IF
      *    END-IF.

      *
      *  CALL MODULE CSLF1600 TO CALCULATE THE PROJECTIONS.  THE
      *  PARAMETERS REQUIRED SHOULD BE VALUED BY NOW
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  1600-1000-BUILD-PARM-INFO
               THRU 1600-1000-BUILD-PARM-INFO-X.
007685     SET L1600-BAL-ALL                TO TRUE.
           MOVE WS-EFF-DATE           TO L1600-EFF-DT.
           MOVE WS-CURR-INT           TO L1600-CURR-INT-RT.
           MOVE WS-GUAR-INT           TO L1600-GUAR-INT-RT.
           MOVE WS-DB-OPTION          TO L1600-DB-OPT-CD.
           MOVE WS-MODE               TO L1600-MODE.
           MOVE WS-LUMP-SUM-INC       TO L1600-LUMP-SUM-INC.
           MOVE WS-INIT-PREM          TO L1600-INIT-PREM.
           MOVE WS-PLANNED-PREM       TO L1600-PLANNED-PREM.
013578     SET  L1600-INCL-PENDING-CVG      TO TRUE.
           PERFORM  1600-1000-PROJECT-FLEX
               THRU 1600-1000-PROJECT-FLEX-X.
007685*
007685     IF L1600-GUAR-WTH-PREM-XPRY-DT = WWKDT-ZERO-DT
007685         MOVE RPOL-POL-CEAS-DT  TO L1600-GUAR-WTH-PREM-XPRY-DT
007685     END-IF.
007685*
007685     IF L1600-GUAR-NO-PREM-XPRY-DT = WWKDT-ZERO-DT
007685         MOVE RPOL-POL-CEAS-DT  TO L1600-GUAR-NO-PREM-XPRY-DT
007685     END-IF.
007685*
007685     IF L1600-CRNT-WTH-PREM-XPRY-DT = WWKDT-ZERO-DT
007685         MOVE RPOL-POL-CEAS-DT  TO L1600-CRNT-WTH-PREM-XPRY-DT
007685     END-IF.
007685*
007685     IF L1600-CRNT-NO-PREM-XPRY-DT = WWKDT-ZERO-DT
007685         MOVE RPOL-POL-CEAS-DT  TO L1600-CRNT-NO-PREM-XPRY-DT
007685     END-IF.

           PERFORM  6300-MOVE-TO-SCREEN
               THRU 6300-MOVE-TO-SCREEN-X.

       6100-PROCESS-PROJ-FLEX-X.
           EXIT.
      *
      *-----------------------
       6200-PROCESS-PROJ-TRAD.
      *-----------------------

007685*
007685*  IF THE FORCE-CODE IS '3' THE PROJECTIONS HAVE ALREADY BEEN
007685*  MADE.  DISPLAY THE VALUES CALCULATED.
007685*
007685     PERFORM  PGA-1000-BUILD-PARMS
007685         THRU PGA-1000-BUILD-PARMS-X.
007685     PERFORM  1600-1000-BUILD-PARM-INFO
007685         THRU 1600-1000-BUILD-PARM-INFO-X.
007685     MOVE WS-EFF-DATE       TO L1600-EFF-DT.
007685     MOVE 99                TO L1600-TRAD-STATUS.
007685     SET  L1600-INCL-PENDING-CVG   TO TRUE.
007685     PERFORM  1600-2000-PROJECT-TRAD
007685         THRU 1600-2000-PROJECT-TRAD-X.
007685*
007685     MOVE +1                    TO N8.
007685     ADD WS-POLICY-YEAR +1      GIVING WS-YEAR-PLUS-00.
007685*
007685     PERFORM  6210-MOV-TRAD-ARRAY-TO-SCN
007685         THRU 6210-MOV-TRAD-ARRAY-TO-SCN-X
007685         VARYING J FROM WS-YEAR-PLUS-00 BY +1
007685           UNTIL J > L1600-YRS-TO-CALC
007685         OR N8 > +99.
007685*
007685     IF J > L1600-YRS-TO-CALC
007685     OR J > L1600-TRAD-STATUS
007685         MOVE ZERO              TO J
007685     ELSE
007685         SUBTRACT 1                    FROM J
007685     END-IF.

       6200-PROCESS-PROJ-TRAD-X.
           EXIT.
      *
      *---------------------------
       6210-MOV-TRAD-ARRAY-TO-SCN.
      *---------------------------

      *
      *  MOVE VALUE TO OUT-POLICY-YEAR-2
      *
020874*    MOVE J                     TO WS-POLICY-YEAR.
020874*    MOVE WS-POLICY-YEAR        TO MIR-DV-POL-YR-CTR-T(N8).
020874     MOVE J                     TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-DV-POL-YR-CTR-T(N8)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-YR-CTR-T(N8).

           IF  J >  L1600-TRAD-STATUS
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE L1600-AGE (J)     TO MIR-DV-CLI-AGE-T(N8)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = L1600-GUAR-WTH-PREM-DB-AMT (J) * 100
020874         MOVE L1600-GUAR-WTH-PREM-DB-AMT (J)
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-POL-GUAR-DB-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY         TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-GUAR-DB-AMT-T(N8)
008455
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = L1600-GUAR-WTH-PREM-CSV-AMT (J) * 100
020874         MOVE L1600-GUAR-WTH-PREM-CSV-AMT (J)
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-POL-TRADL-APREM-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY         TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                   TO MIR-DV-POL-TRADL-APREM-AMT-T(N8)
008455
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = L1600-GUAR-WTH-PREM-FND-AMT (J) * 100
020874         MOVE L1600-GUAR-WTH-PREM-FND-AMT (J)
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-POL-TRADL-CV-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY         TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-TRADL-CV-AMT-T(N8)
008455
           END-IF.
007685*
007685     ADD 1                            TO N8.

       6210-MOV-TRAD-ARRAY-TO-SCN-X.
           EXIT.
      *
      *--------------------
       6300-MOVE-TO-SCREEN.
      *--------------------

           MOVE +1                    TO N8.
           COMPUTE WS-YEAR-PLUS-00 = WS-POLICY-YEAR + 1.

007685     MOVE L1600-GUAR-WTH-PREM-XPRY-DT TO L1640-INTERNAL-DATE
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
007685     MOVE L1640-EXTERNAL-DATE   TO MIR-DV-GUAR-PREM-XPRY-DT.

007685     MOVE L1600-CRNT-WTH-PREM-XPRY-DT TO L1640-INTERNAL-DATE
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
007685     MOVE L1640-EXTERNAL-DATE   TO MIR-DV-CRNT-PREM-XPRY-DT.

007685     MOVE L1600-GUAR-NO-PREM-XPRY-DT  TO L1640-INTERNAL-DATE
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
007685     MOVE L1640-EXTERNAL-DATE   TO MIR-DV-GUAR-XPRY-DT.

007685     MOVE L1600-CRNT-NO-PREM-XPRY-DT  TO L1640-INTERNAL-DATE
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
007685     MOVE L1640-EXTERNAL-DATE   TO MIR-DV-CRNT-XPRY-DT.

           PERFORM  6310-MOVE-ARRAY-TO-SCN
               THRU 6310-MOVE-ARRAY-TO-SCN-X
               VARYING J FROM WS-YEAR-PLUS-00 BY +1
               UNTIL J > L1600-YRS-TO-CALC
               OR N8 > +99.

007685     IF  J > L1600-YRS-TO-CALC
               MOVE +0                TO J
           END-IF.

007685     IF  J = L1600-YRS-TO-CALC
               CONTINUE
           ELSE
               COMPUTE J = J - 1
           END-IF.

       6300-MOVE-TO-SCREEN-X.
           EXIT.
      *
      *-----------------------
       6310-MOVE-ARRAY-TO-SCN.
      *-----------------------

020874*    COMPUTE WS-POLICY-YEAR = J - 1.
020874*    MOVE WS-POLICY-YEAR        TO MIR-DV-POL-YR-CTR-T(N8).
020874     COMPUTE L0290-INPUT-V00 = J - 1.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-DV-POL-YR-CTR-T(N8)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-YR-CTR-T(N8).

           MOVE L1600-AGE (J)         TO MIR-DV-CLI-AGE-T(N8).

007685     MOVE L1600-GUAR-WTH-PREM-FND-AMT (J)
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-GUAR-FNDVL-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY             TO TRUE
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-GUAR-FNDVL-AMT-T(N8).

007685     MOVE L1600-GUAR-WTH-PREM-CSV-AMT (J)
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-GUAR-SURR-VALU-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY             TO TRUE
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
                                  TO MIR-DV-GUAR-SURR-VALU-AMT-T(N8).

007685     MOVE L1600-GUAR-WTH-PREM-DB-AMT (J)
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-POL-GUAR-DB-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY             TO TRUE
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-GUAR-DB-AMT-T(N8).

007685     MOVE L1600-CRNT-WTH-PREM-FND-AMT (J)
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CRNT-FNDVL-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY             TO TRUE
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CRNT-FNDVL-AMT-T(N8).

007685     MOVE L1600-CRNT-WTH-PREM-CSV-AMT (J)
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CRNT-SURR-VALU-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY             TO TRUE
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CRNT-SURR-VALU-AMT-T(N8).

007685     MOVE L1600-CRNT-WTH-PREM-DB-AMT (J)
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-POL-CRNT-DB-AMT-T(N8)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY             TO TRUE
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-CRNT-DB-AMT-T(N8).

           ADD +1                           TO N8.

       6310-MOVE-ARRAY-TO-SCN-X.
           EXIT.
      *
      *------------------
       8500-SCREEN-CLEAR.
      *------------------

           MOVE SPACE                 TO MIR-POL-ISS-EFF-DT.
           MOVE SPACE                 TO MIR-CVG-GUAR-INT-PCT.
           MOVE SPACE                 TO MIR-INIT-DPOS-INT-PCT.
           MOVE SPACE                 TO MIR-POL-DB-OPT-CD.
           MOVE SPACE                 TO MIR-POL-BILL-MODE-CD.
           MOVE SPACE                 TO MIR-PLAN-PERI-PREM-AMT.
           MOVE SPACE                 TO MIR-DV-LMPSM-AMT.
           MOVE SPACE                 TO MIR-UL-INIT-PREM-AMT.

       8500-SCREEN-CLEAR-X.
           EXIT.
      *
      *--------------------
       8600-REFRESH-SCREEN.
      *--------------------

           MOVE L1600-EFF-DT          TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-NOT-VALID
               MOVE WGLOB-PROCESS-DATE TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X

           END-IF.

           MOVE L1640-EXTERNAL-DATE   TO MIR-POL-ISS-EFF-DT.

020874*    COMPUTE WS-INT-RATE-HOLD = L1600-CURR-INT-RT * 100.
020874     MOVE L1600-CURR-INT-RT     TO L0290-INPUT-V07.

020874*    MOVE WS-INT-RATE-HOLD      TO WS-EDIT-3V4.
020874*    MOVE WS-EDIT-3V4           TO MIR-INIT-DPOS-INT-PCT.
020874     MOVE 5                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-INIT-DPOS-INT-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-INIT-DPOS-INT-PCT.

020874*    COMPUTE WS-INT-RATE-HOLD = L1600-GUAR-INT-RT * 100.
020874     MOVE L1600-GUAR-INT-RT     TO L0290-INPUT-V07.

020874*    MOVE WS-INT-RATE-HOLD      TO WS-EDIT-3V4.
020874*    MOVE WS-EDIT-3V4           TO MIR-CVG-GUAR-INT-PCT.
020874     MOVE 5                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-GUAR-INT-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-GUAR-INT-PCT.
           MOVE L1600-DB-OPT-CD       TO MIR-POL-DB-OPT-CD.
           MOVE L1600-MODE            TO MIR-POL-BILL-MODE-CD.
020874*    COMPUTE L0290-INPUT-NUMBER = L1600-PLANNED-PREM * 100.
020874     MOVE L1600-PLANNED-PREM    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-PERI-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-PERI-PREM-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1600-LUMP-SUM-INC * 100.
020874     MOVE L1600-LUMP-SUM-INC    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-LMPSM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-LMPSM-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1600-INIT-PREM * 100.
020874     MOVE L1600-INIT-PREM       TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UL-INIT-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UL-INIT-PREM-AMT.
008455

       8600-REFRESH-SCREEN-X.
           EXIT.
      *
      *--------------------------
       9200-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.

       9200-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1600-0000-INIT-PARM-INFO
025970         THRU 1600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     SET WS-TRANSACTION-NAME-DEFAULT TO TRUE.
025970
025970     MOVE SPACES                     TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY XCPPEXIT.
       COPY XCPPINIT.
      *
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS
      *****************************************************************
018764*COPY CCCL1600.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY CCPL1600.
016440*
018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440 COPY CCPS5400.
      *
       COPY NCPPCVGS.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
013578*COPY XCCL2490.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPS1600.
       COPY CCPSPGA.
      *
       COPY CCPNPOL.
       COPY CCPNCVG.
      *
013578*COPY XCPS2490.
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0196                     **
      *****************************************************************
