      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3181.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3181                                         **
      **  REMARKS:  PAAF - POLICY ACTIVITY ADUIT FIELD CREATE        **
      **            THIS MODULE CREATES AN ENTRY IN THE PAAF TABLE   **
      **  DOMAIN :  PR                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
035237**  7.0       EDIT PROBLEM IN CREATE                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3181'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '3180'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '3180'.
025970     05  WS-MAX-BR-CTR                PIC S9(04).
025970         88  WS-MAX-BR-CTR-DEFAULT    VALUE +100.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-CREATE        VALUE '3181'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '3180'.
           05  WS-PRCES-SEQ-NUM             PIC 9(03).
           05  WS-SUB                       PIC S9(04) BINARY.
025970*    05  WS-MAX-BR-CTR                PIC S9(04).

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************

       COPY CCWWLOCK.
       COPY XCWWWKDT.

      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
028298 COPY CCWL2626.
       COPY CCWL3187.
       COPY CCWL3188.
      /
       COPY XCWL1646.
       COPY XCWL8090.

      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3181.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

023514*    PERFORM  9990-INIT-WORKING-STORAGE
023514*        THRU 9990-INIT-WORKING-STORAGE-X.
023514*
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3181'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *---------------------

           PERFORM 4200-CREATE-EDITS
              THRU 4200-CREATE-EDITS-X.

           IF  WGLOB-GOOD-RETURN
               PERFORM  5000-CREATE-EACH-PAAF
                   THRU 5000-CREATE-EACH-PAAF-X
                   VARYING WS-SUB FROM +1 BY +1
                   UNTIL WS-SUB > WS-MAX-BR-CTR
                      OR WGLOB-RETURN-ERROR
           ELSE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           MOVE MIR-POL-ID              TO WPOL-POL-ID.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *-----------------------
       4200-CREATE-EDITS.
      *-----------------------

           MOVE MIR-POL-ID            TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: REQUEST POLICY NOT FOUND (INVALID POLICY)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID       TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           IF  MIR-PAAFLD-GR-TS   = SPACES
           OR  MIR-PAAFLD-GR-TS   = WWKDT-ZERO-TS
               MOVE WGLOB-TRXN-GR-TS  TO MIR-PAAFLD-GR-TS
           ELSE
               PERFORM  4220-CHECK-TIMESTAMP
                   THRU 4220-CHECK-TIMESTAMP-X
           END-IF.

           IF  WGLOB-RETURN-ERROR
               GO TO 4200-CREATE-EDITS-X
           ELSE
               MOVE +1                TO WS-PRCES-SEQ-NUM
           END-IF.


035237*    IF  NOT L3187-RETRN-OK
035237     IF  L3188-RETRN-OK
035237     OR  L3188-RETRN-PAAF-NOT-FOUND
035237         CONTINUE
035237     ELSE
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       4200-CREATE-EDITS-X.
           EXIT.
      /
      *---------------------------
       4220-CHECK-TIMESTAMP.
      *---------------------------

           PERFORM  1646-1000-BUILD-PARM-INFO
               THRU 1646-1000-BUILD-PARM-INFO-X.
           MOVE MIR-PAAFLD-GR-TS      TO L1646-TIMESTAMP.
           PERFORM  1646-1000-EDIT-TIMESTAMP
               THRU 1646-1000-EDIT-TIMESTAMP-X.
           IF  L1646-EDIT-FAILED
               SET WGLOB-RETURN-ERROR TO  TRUE
               MOVE 'CS31810002'      TO  WGLOB-MSG-REF-INFO
      * MSG: INVALID TIMESTAMP
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO  TRUE
               GO TO 4220-CHECK-TIMESTAMP-X
           END-IF.

           PERFORM  3188-0000-INIT-PARM-INFO
               THRU 3188-0000-INIT-PARM-INFO-X.

           PERFORM  4600-BUILD-PAAF-BR-KEY
               THRU 4600-BUILD-PAAF-BR-KEY-X.

           PERFORM  3188-3000-BR-EXIST
               THRU 3188-3000-BR-EXIST-X.

           IF  L3188-RETRN-PAAF-NOT-FOUND
               CONTINUE
           ELSE
      *MSG:  POLICY @1 WITH TIMESTAMP @2 HAS ALREADY EXISTED
               MOVE 'CS31810001'        TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ID        TO WGLOB-MSG-PARM (01)
               MOVE MIR-PAAFLD-GR-TS  TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       4220-CHECK-TIMESTAMP-X.
           EXIT.
      /
      *---------------------------
       4600-BUILD-PAAF-BR-KEY.
      *---------------------------

           MOVE MIR-POL-ID              TO L3188-POL-ID.
           MOVE MIR-PAAFLD-GR-TS        TO L3188-PAAFLD-GR-TS.

       4600-BUILD-PAAF-BR-KEY-X.
           EXIT.
      /
      *---------------------------
       5000-CREATE-EACH-PAAF.
      *---------------------------

           IF  MIR-PAAFLD-FLD-ID-T (WS-SUB) = SPACES
               IF MIR-PAAFLD-VALU-TXT-T (WS-SUB) = SPACES
                  GO TO 5000-CREATE-EACH-PAAF-X
               ELSE
      *MSG: FIELD ID CANNOT BE BLANK, RECORD NOT CREATED
                  MOVE 'CS31810003'            TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                  GO TO 5000-CREATE-EACH-PAAF-X
               END-IF
           END-IF.

           PERFORM  3187-0000-INIT-PARM-INFO
               THRU 3187-0000-INIT-PARM-INFO-X.

           MOVE MIR-POL-ID           TO L3187-POL-ID.
           MOVE MIR-PAAFLD-GR-TS     TO L3187-PAAFLD-GR-TS.
           MOVE WS-PRCES-SEQ-NUM     TO L3187-PAAFLD-SEQ-NUM.

           PERFORM  3187-1000-EDIT-PAAF-CRE-KEY
               THRU 3187-1000-EDIT-PAAF-CRE-KEY-X.

           IF  NOT L3187-RETRN-OK
               SET WGLOB-RETURN-ERROR      TO TRUE
               GO TO 5000-CREATE-EACH-PAAF-X
           END-IF.

           PERFORM  3188-0000-INIT-PARM-INFO
               THRU 3188-0000-INIT-PARM-INFO-X.

           MOVE L3187-POL-ID               TO L3188-POL-ID.
           MOVE L3187-PAAFLD-GR-TS         TO L3188-PAAFLD-GR-TS.
           MOVE L3187-PAAFLD-SEQ-NUM       TO L3188-PAAFLD-SEQ-NUM.
           MOVE MIR-PAAFLD-FLD-ID-T (WS-SUB)  TO L3188-PAAFLD-FLD-ID.
           MOVE MIR-PAAFLD-VALU-TXT-T (WS-SUB)
                                        TO L3188-PAAFLD-VALU-TXT.

           PERFORM  3188-1000-CREATE-PAAF
               THRU 3188-1000-CREATE-PAAF-X.

           IF  NOT L3188-RETRN-OK
               SET WGLOB-RETURN-ERROR      TO TRUE
               GO TO 5000-CREATE-EACH-PAAF-X
           END-IF.

           ADD +1                          TO WS-PRCES-SEQ-NUM.

       5000-CREATE-EACH-PAAF-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3187-0000-INIT-PARM-INFO
025970         THRU 3187-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  3188-0000-INIT-PARM-INFO
025970         THRU 3188-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
           SET MIR-RETRN-OK             TO TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT     TO TRUE.
025970     SET  WS-MAX-BR-CTR-DEFAULT   TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970*    MOVE +100                    TO WS-MAX-BR-CTR.
           MOVE +1                      TO WS-PRCES-SEQ-NUM.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
      /
025970 COPY XCPS8090.
       COPY XCPS1646.
       COPY XCPL1646.
      /
       COPY XCPL8090.
      /
       COPY CCPS3187.
       COPY CCPL3187.
      /
       COPY CCPS3188.
       COPY CCPL3188.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3181                     *
      ****************************************************************
