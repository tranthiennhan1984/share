      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM2220.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM2220                                         **
      **  REMARKS:  OCTB: MAINTAIN OCCUPATION CLASS TABLE.           **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE OCCUPATION CLASS TABLE.        **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM2220'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
014221 COPY XCWL8090.

       01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '1610'.
016548*    05  WS-MAX-SCREEN-LINES          PIC S9(04) COMP
025970*    05  WS-MAX-SCREEN-LINES          PIC S9(04) BINARY
025970*                                     VALUE +11.
025970     05  WS-MAX-SCREEN-LINES          PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-SCREEN-LINES         VALUE +11.

       01  WS-COUNTERS.
016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.
016548*    05  WS-DEST                      PIC S9(04) COMP.
016548     05  WS-DEST                      PIC S9(04) BINARY.

       01  WS-SWITCHES.
           05  WS-DATA-EDITS-SW             PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.
           05  WS-TEST-YES-NO               PIC X(01).
               88  WS-TEST-YES-NO-OK        VALUE 'Y' 'N'.

       01  WS-PGM-WORK-AREA.
016548*    05  WS-START                     PIC S9(04) COMP.
016548     05  WS-START                     PIC S9(04) BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1610' '1611'
                                                  '1612' '1613'
                                                  '1614'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1610'.
               88  WS-BUS-FCN-CREATE        VALUE '1611'.
               88  WS-BUS-FCN-UPDATE        VALUE '1612'.
               88  WS-BUS-FCN-DELETE        VALUE '1613'.
               88  WS-BUS-FCN-LIST          VALUE '1614'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1610'.

       COPY XCWEBLCH.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY NCFWOCTB.
       COPY NCFROCTB.
      /
014221 COPY CCWWLOCK.
016537*COPY XCWWWKDT.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM2220.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *****************************************************************
      *      PROCESS USER REQUEST
      *****************************************************************
      ***********************
       2000-PROCESS-REQUEST.
      ***********************

025970*    MOVE MIR-BUS-FCN-ID     TO  WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK       TO  TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           IF WS-BUS-FCN-CREATE
               PERFORM 4000-PROCESS-CREATE
                  THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-RETRIEVE
               PERFORM 3000-PROCESS-RETRIEVE
                  THRU 3000-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-LIST
557660         PERFORM 3500-PROCESS-LIST
557660            THRU 3500-PROCESS-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-UPDATE
               PERFORM 5000-PROCESS-UPDATE
                  THRU 5000-PROCESS-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-DELETE
               PERFORM 6000-PROCESS-DELETE
                  THRU 6000-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *****************************************************************
      *  RETRIEVE PROCESSING
      *****************************************************************
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  8000-BUILD-OCTB-KEY
               THRU 8000-BUILD-OCTB-KEY-X.
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
014221*    PERFORM  OCTB-1000-READ
014221*        THRU OCTB-1000-READ-X.
014221     PERFORM  OCTB-1000-READ-TWRK-TS
014221         THRU OCTB-1000-READ-TWRK-TS-X.

           IF WOCTB-IO-NOT-FOUND
      *** MSG (S) RECORD NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WOCTB-KEY         TO WGLOB-MSG-PARM (1)
           ELSE
      *** MSG (I) MAINTAIN DETAILS
               MOVE 'XS00000016'      TO WGLOB-MSG-REF-INFO
               MOVE +1                TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *****************************************************************
      *  BROWSE PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************
557660 3500-PROCESS-LIST.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE HIGH-VALUES           TO WOCTB-ENDBR-KEY.
           PERFORM  8000-BUILD-OCTB-KEY
               THRU 8000-BUILD-OCTB-KEY-X.
      *
      *  POSITION AT AND READ FIRST RECORD
      *
           PERFORM  OCTB-1000-BROWSE
               THRU OCTB-1000-BROWSE-X.
           IF  WOCTB-IO-EOF
      *MSG:    NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660         GO TO 3500-PROCESS-LIST-X
           END-IF.
      *
           PERFORM  OCTB-2000-READ-NEXT
               THRU OCTB-2000-READ-NEXT-X.
           IF  WOCTB-IO-EOF
      *MSG:    NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  OCTB-3000-END-BROWSE
                   THRU OCTB-3000-END-BROWSE-X
557660         GO TO 3500-PROCESS-LIST-X
           END-IF.
      *
      *  LOAD SCREEN DATA
      *
           IF WOCTB-IO-OK
                MOVE 1                TO WS-LINE
                PERFORM  3510-DISPLAY-RECORD
                    THRU 3510-DISPLAY-RECORD-X
                    UNTIL (WS-LINE >  WS-MAX-SCREEN-LINES)
                    OR (WOCTB-IO-EOF)
           END-IF.
      *
      *   COMPLETION MESSAGE
      *
           IF WOCTB-IO-EOF
      *MSG:     END OF FILE REACHED
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               MOVE WOCTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE WOCTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE ROCTB-OCCP-ID     TO MIR-OCCP-ID
           END-IF.

           PERFORM  OCTB-3000-END-BROWSE
               THRU OCTB-3000-END-BROWSE-X.
      *
557660 3500-PROCESS-LIST-X.
           EXIT.
      /
       3510-DISPLAY-RECORD.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  OCTB-2000-READ-NEXT
               THRU OCTB-2000-READ-NEXT-X.

       3510-DISPLAY-RECORD-X.
           EXIT.
      /

      *****************************************************************
      *  CREATE PROCESSING
      *****************************************************************
       4000-PROCESS-CREATE.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.
           IF NOT WS-DATA-EDITS-OK
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      ***  BUILD CONTROL FIELDS.
           PERFORM  8000-BUILD-OCTB-KEY
               THRU 8000-BUILD-OCTB-KEY-X.

      ***  CHECK RECORD EXISTENCE.
           PERFORM  OCTB-1000-READ
               THRU OCTB-1000-READ-X.
           IF WOCTB-IO-OK
      *** MSG (S) RECORD ALREADY EXISTS
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WOCTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE +1                TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      ***  CREATE NEW RECORD.
           PERFORM  OCTB-1000-CREATE
               THRU OCTB-1000-CREATE-X.
           PERFORM  OCTB-1000-WRITE
               THRU OCTB-1000-WRITE-X.

014221     PERFORM  OCTB-1000-READ-TWRK-TS
014221         THRU OCTB-1000-READ-TWRK-TS-X.

      ***MSG (I) RECORD CREATED
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE +1                    TO WS-LINE.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *** MSG (I) MAINTAIN DETAILS
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT KEY FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       4100-EDIT-KEY-FIELDS.

           MOVE 'Y'                   TO WS-DATA-EDITS-SW.

           PERFORM  4110-EDIT-OCC-CODE
               THRU 4110-EDIT-OCC-CODE-X.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: OCC CODE
      *      MUST BE IN EDIT TYPE OCCCD
      *****************************************************************
       4110-EDIT-OCC-CODE.

           MOVE MIR-OCCP-ID           TO WEDIT-ETBL-VALU-ID.
           PERFORM OCCD-1000-EDIT
               THRU OCCD-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
      *** MSG (S) OCC CODE MUST BE IN EDIT, TYPE OCCCD
               MOVE 'NS22200001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.


       4110-EDIT-OCC-CODE-X.
           EXIT.
      /
      *****************************************************************
      *  MAINTAIN PROCESSING
      *****************************************************************
       5000-PROCESS-UPDATE.

           PERFORM  8000-BUILD-OCTB-KEY
               THRU 8000-BUILD-OCTB-KEY-X.
014221*    PERFORM  OCTB-1000-READ-FOR-UPDATE
014221*        THRU OCTB-1000-READ-FOR-UPDATE-X.
014221     PERFORM  OCTB-2000-UPDATE-TWRK-TS
014221         THRU OCTB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'OCTB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WOCTB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF WOCTB-IO-NOT-FOUND
      *** MSG (S) RECORD (@1) LOST IN MAINTAIN
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WOCTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           MOVE +1                    TO WS-LINE.
           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           MOVE ROCTB-OCCP-ID         TO MIR-OCCP-ID-T (WS-LINE).

           MOVE ROCTB-OCCP-ID         TO WEDIT-ETBL-VALU-ID.
           PERFORM OCCD-2000-DESC
               THRU OCCD-2000-DESC-X.
           IF WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-ETBL-DESC-TXT-T (WS-LINE)
557660     END-IF.

           PERFORM  OCTB-2000-REWRITE
               THRU OCTB-2000-REWRITE-X.
014221     PERFORM  OCTB-1000-READ-TWRK-TS
014221         THRU OCTB-1000-READ-TWRK-TS-X.

      ***  RESET ENTER CODE TO INQUIRE WHEN MAINTAIN IS COMPLETE.
           IF WS-DATA-EDITS-OK
      *** MSG (I) MAINTAIN COMPLETE - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
           ELSE
      *** MSG (I) ?
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       5300-EDIT-DATA-FIELDS.

           MOVE 'Y'                   TO WS-DATA-EDITS-SW.

           PERFORM  5310-EDIT-OCC-CLASS
               THRU 5310-EDIT-OCC-CLASS-X.

           PERFORM  5320-EDIT-UW-IND
               THRU 5320-EDIT-UW-IND-X.

           PERFORM  5390-XEDIT-DATA-FIELDS
               THRU 5390-XEDIT-DATA-FIELDS-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  OCC CLASS:  MUST BE IN EDIT, TYPE OCCCD
      *****************************************************************
       5310-EDIT-OCC-CLASS.

           IF MIR-OCCP-CLAS-CD-T (WS-LINE) = SPACES
               MOVE ROCTB-OCCP-CLAS-CD   TO MIR-OCCP-CLAS-CD-T (WS-LINE)
               GO TO 5310-EDIT-OCC-CLASS-X
557660     END-IF.

           IF MIR-OCCP-CLAS-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-OCCP-CLAS-CD-T (WS-LINE)
557660     END-IF.

           MOVE MIR-OCCP-CLAS-CD-T (WS-LINE)
                                      TO WEDIT-ETBL-VALU-ID.
           PERFORM OCCL-1000-EDIT
               THRU OCCL-1000-EDIT-X.

           IF NOT WEDIT-IO-OK
      *** MSG (S) OCC CLASS MUST BE IN EDIT, TYPE OCCCL
               MOVE 'NS22200002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
               GO TO 5310-EDIT-OCC-CLASS-X
557660     END-IF.

           MOVE MIR-OCCP-CLAS-CD-T (WS-LINE)
                                      TO ROCTB-OCCP-CLAS-CD.

       5310-EDIT-OCC-CLASS-X.
           EXIT.
      /
      *****************************************************************
      *  UW IND:  MUST BE Y OR N
      *****************************************************************
       5320-EDIT-UW-IND.

           IF MIR-OCCP-UWG-REQIR-IND-T (WS-LINE) = SPACES
               MOVE ROCTB-OCCP-UWG-REQIR-IND
                                   TO MIR-OCCP-UWG-REQIR-IND-T (WS-LINE)
               GO TO 5320-EDIT-UW-IND-X
557660     END-IF.

           IF MIR-OCCP-UWG-REQIR-IND-T (WS-LINE)
                                   = EBLCH-BLANK-FIELD-CHAR
               MOVE 'Y'            TO MIR-OCCP-UWG-REQIR-IND-T (WS-LINE)
               MOVE 'Y'               TO ROCTB-OCCP-UWG-REQIR-IND
               GO TO 5320-EDIT-UW-IND-X
557660     END-IF.

           MOVE MIR-OCCP-UWG-REQIR-IND-T (WS-LINE)
                                      TO WS-TEST-YES-NO.
           IF NOT WS-TEST-YES-NO-OK
      *** MSG (S) UW IND MUST BE Y OR N
               MOVE 'NS22200003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
               GO TO 5320-EDIT-UW-IND-X
557660     END-IF.

           MOVE MIR-OCCP-UWG-REQIR-IND-T (WS-LINE)
                                      TO ROCTB-OCCP-UWG-REQIR-IND.

       5320-EDIT-UW-IND-X.
           EXIT.
      /
      *
       5390-XEDIT-DATA-FIELDS.
      ************************

           IF ROCTB-OCCP-CLAS-CD = SPACES
           AND MIR-OCCP-CLAS-CD-T (WS-LINE) = SPACES
      *** MSG (S) OCC CLASS MUST BE NON-BLANK
               MOVE 'NS22200004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5390-XEDIT-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  DELETE PROCESSING.
      *****************************************************************
       6000-PROCESS-DELETE.

           PERFORM  8000-BUILD-OCTB-KEY
               THRU 8000-BUILD-OCTB-KEY-X.
014221*    PERFORM  OCTB-1000-READ-FOR-UPDATE
014221*        THRU OCTB-1000-READ-FOR-UPDATE-X.
014221     PERFORM  OCTB-2000-UPDATE-TWRK-TS
014221         THRU OCTB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'OCTB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WOCTB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WOCTB-IO-NOT-FOUND
      *** MSG (S) RECORD (@1) LOST IN DELETE
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WOCTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
      *** MSG (I) RECORD DELETED - CONTINUE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  OCTB-1000-DELETE
                   THRU OCTB-1000-DELETE-X
557660     END-IF.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /

      *****************************************************************
      *  BUILD OCTB KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       8000-BUILD-OCTB-KEY.

           MOVE MIR-OCCP-ID           TO WOCTB-OCCP-ID.

       8000-BUILD-OCTB-KEY-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.

           MOVE SPACES                TO MIR-OCCP-ID-G.
           MOVE SPACES                TO MIR-OCCP-CLAS-CD-G.
           MOVE SPACES                TO MIR-OCCP-UWG-REQIR-IND-G.
           MOVE SPACES                TO MIR-ETBL-DESC-TXT-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.

           MOVE ROCTB-OCCP-ID         TO MIR-OCCP-ID-T (WS-LINE).
           MOVE ROCTB-OCCP-CLAS-CD    TO MIR-OCCP-CLAS-CD-T (WS-LINE).
           MOVE ROCTB-OCCP-UWG-REQIR-IND
                                  TO MIR-OCCP-UWG-REQIR-IND-T (WS-LINE).

           MOVE ROCTB-OCCP-ID         TO WEDIT-ETBL-VALU-ID.
           PERFORM OCCD-2000-DESC
               THRU OCCD-2000-DESC-X.
           IF WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-ETBL-DESC-TXT-T (WS-LINE)
557660     END-IF.

           ADD +1 TO WS-LINE.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-COUNTERS.
025970     INITIALIZE                         WS-SWITCHES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-MAX-SCREEN-LINES    TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY OCTB
014221                         '$VAR2' BY 'OCTB'.
       COPY XCPPEXIT.
      /
       COPY CCPEOCCD.
      /
       COPY CCPEOCCL.
      /
       COPY XCPPINIT.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
       COPY NCPAOCTB.
       COPY NCPBOCTB.
       COPY NCPNOCTB.
       COPY NCPUOCTB.
       COPY NCPXOCTB.
       COPY NCPCOCTB.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM2220                     **
      *****************************************************************
