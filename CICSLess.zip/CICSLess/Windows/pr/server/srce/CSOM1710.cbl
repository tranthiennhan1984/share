      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1710.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1710                                         **
      **  REMARKS:  THIS MODULE PERFORMS RETRIEVE FUNCTION           **
      **            FOR THE PDEP TABLE, WHICH INCLUDES ALL           **
      **            ASSOCIATED RECORDS FROM PGDA                     **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1710'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '1710'.
      /
           05  WS-MIR-FIELDS.
               10  WS-PEND-DPOS-EFF-DT      PIC X(10).
               10  WS-PEND-DPOS-SEQ-NUM     PIC 9(03).

025970*    05  WS-CONSTANTS.
025970*        10  WS-PDGA-TBL-SIZE         PIC S9(04)
025970*                                     VALUE +9.
                                            
025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-PDGA-TBL-SIZE               PIC S9(4).  
025970         88  WS-PDGA-TBL-SIZE-DEFAULT   VALUE +9. 


      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY CCWWLOCK.
       COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWPDEP.
       COPY CCFRPDEP.
      /
       COPY CCFWPDGA.
       COPY CCFRPDGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
       COPY CCWL2430.
       COPY CCWL0620.
      /

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1710.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *----------------------------
       0000-MAINLINE.
      *----------------------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *----------------------------
       1000-PROCESS-REQUEST.
      *----------------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-RETRIEVE
                        THRU 3000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------------------------
       3000-RETRIEVE.
      *----------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-RETRIEVE-X
           END-IF.

           PERFORM  PDEP-1000-READ
               THRU PDEP-1000-READ-X.

           IF  WPDEP-IO-EOF
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       3000-RETRIEVE-X.
           EXIT.

      *----------------------------
       7000-BUILD-KEYS.
      *----------------------------

           PERFORM  7100-EDIT-INPUT
               THRU 7100-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           MOVE MIR-POL-ID              TO WPDEP-POL-ID.
           MOVE WS-PEND-DPOS-EFF-DT     TO WPDEP-PEND-DPOS-EFF-DT.
           MOVE WS-PEND-DPOS-SEQ-NUM    TO WPDEP-PEND-DPOS-SEQ-NUM.


       7000-BUILD-KEYS-X.
           EXIT.
      /
      *----------------------------
       7100-EDIT-INPUT.
      *----------------------------

           PERFORM  7110-EDIT-POL-ID
               THRU 7110-EDIT-POL-ID-X.

           PERFORM  7120-EDIT-PEND-DPOS-EFF-DT
               THRU 7120-EDIT-PEND-DPOS-EFF-DT-X.

           PERFORM  7130-EDIT-PEND-DPOS-SEQ-NUM
               THRU 7130-EDIT-PEND-DPOS-SEQ-NUM-X.

       7100-EDIT-INPUT-X.
           EXIT.

      *----------------------------
       7110-EDIT-POL-ID.
      *----------------------------

           MOVE MIR-POL-ID               TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  NOT WPOL-IO-OK
      *MSG:  POLICY NOT FOUND
               MOVE 'CS17100001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7110-EDIT-POL-ID-X.
           EXIT.

      *----------------------------
       7120-EDIT-PEND-DPOS-EFF-DT.
      *----------------------------

           MOVE MIR-PEND-DPOS-EFF-DT    TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      ****MSG: INVALID EFFECTIVE DATE
               MOVE 'CS17100002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WWKDT-LOW-DT         TO WS-PEND-DPOS-EFF-DT
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-PEND-DPOS-EFF-DT
           END-IF.

       7120-EDIT-PEND-DPOS-EFF-DT-X.
           EXIT.

      *----------------------------
       7130-EDIT-PEND-DPOS-SEQ-NUM.
      *----------------------------

           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.
           MOVE +3                          TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           MOVE MIR-PEND-DPOS-SEQ-NUM       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X

           IF  L0280-OK
               MOVE L0280-OUTPUT            TO WS-PEND-DPOS-SEQ-NUM
           ELSE
      *MSG: INVALID SEQUENCE NUMBER
               MOVE ZERO                    TO WS-PEND-DPOS-SEQ-NUM
               MOVE 'CS17100003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7130-EDIT-PEND-DPOS-SEQ-NUM-X.
           EXIT.


      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RPDEP-PEND-DPOS-STAT-CD     TO MIR-PEND-DPOS-STAT-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = RPDEP-PEND-DPOS-AMT * 100.
020874     MOVE RPDEP-PEND-DPOS-AMT         TO L0290-INPUT-V02.
           MOVE +2                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PEND-DPOS-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY           TO TRUE.
020874*    SET L0290-LEAD-ZEROS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
           TO MIR-PEND-DPOS-AMT.

           MOVE RPDEP-REG-FND-SRC-CD        TO MIR-REG-FND-SRC-CD.
           MOVE RPDEP-CVG-NUM               TO MIR-CVG-NUM.
           MOVE RPDEP-FND-ID                TO MIR-FND-ID.

020874*    COMPUTE L0290-INPUT-NUMBER = RPDEP-PEND-DPOS-TAX-YR.
020874     MOVE RPDEP-PEND-DPOS-TAX-YR      TO L0290-INPUT-V02.
           MOVE ZERO                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PEND-DPOS-TAX-YR
                                            TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-SUPPRESS          TO TRUE.
020874*    SET L0290-LEAD-ZEROS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
           TO MIR-PEND-DPOS-TAX-YR.

           PERFORM  9210-GET-OWNER-NAME
               THRU 9210-GET-OWNER-NAME-X.

           PERFORM  9230-RETRIEVE-PDGA-INFO
               THRU 9230-RETRIEVE-PDGA-INFO-X.


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------
       9210-GET-OWNER-NAME.
      *--------------------

           MOVE ZERO                  TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE SPACE                 TO MIR-DV-OWN-CLI-NM
               GO TO 9210-GET-OWNER-NAME-X
           END-IF.

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF  L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
           END-IF.
           MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM.

       9210-GET-OWNER-NAME-X.
           EXIT.

      *----------------------------
       9230-RETRIEVE-PDGA-INFO.
      *----------------------------

           MOVE LOW-VALUES              TO WPDGA-KEY.
           MOVE MIR-POL-ID              TO WPDGA-POL-ID.
           MOVE RPDEP-PEND-DPOS-EFF-DT  TO WPDGA-PEND-DPOS-EFF-DT.
           MOVE RPDEP-PEND-DPOS-SEQ-NUM TO WPDGA-PEND-DPOS-SEQ-NUM.

           MOVE WPDGA-KEY             TO WPDGA-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPDGA-ENDBR-PDGA-ALLOC-TYP-CD.

           PERFORM  PDGA-1000-BROWSE
               THRU PDGA-1000-BROWSE-X.

           PERFORM  PDGA-2000-READ-NEXT
               THRU PDGA-2000-READ-NEXT-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > WS-PDGA-TBL-SIZE
               OR NOT WPDGA-IO-OK

               MOVE RPDGA-PDGA-ALLOC-TYP-CD
                 TO MIR-PDGA-ALLOC-TYP-CD-T (I)

020874*        COMPUTE L0290-INPUT-NUMBER = RPDGA-PDGA-PRIN-AMT
020874*                                   * 100
020874         MOVE RPDGA-PDGA-PRIN-AMT     TO L0290-INPUT-V02
               MOVE +2                      TO L0290-PRECISION
               MOVE LENGTH OF MIR-PDGA-PRIN-AMT-T (I)
                 TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY       TO TRUE
020874*        SET L0290-LEAD-ZEROS-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
               TO MIR-PDGA-PRIN-AMT-T (I)

020874*        COMPUTE L0290-INPUT-NUMBER = RPDGA-PDGA-GAIN-AMT
020874*                                   * 100
020874         MOVE RPDGA-PDGA-GAIN-AMT     TO L0290-INPUT-V02
               MOVE +2                      TO L0290-PRECISION
               MOVE LENGTH OF MIR-PDGA-GAIN-AMT-T (I)
                 TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY       TO TRUE
020874*        SET L0290-LEAD-ZEROS-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
               TO MIR-PDGA-GAIN-AMT-T (I)

               PERFORM  PDGA-2000-READ-NEXT
                   THRU PDGA-2000-READ-NEXT-X

           END-PERFORM.

           IF  I > WS-PDGA-TBL-SIZE
           AND WPDGA-IO-OK
      *MSG: INTERNAL TABLE OVERFLOWS
               MOVE 'CS17100004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDGA-3000-END-BROWSE
               THRU PDGA-3000-END-BROWSE-X.

       9230-RETRIEVE-PDGA-INFO-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-WORKING-STORAGE.
025970     
025970     INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
025970
025970     INITIALIZE  WLOCK-TWRK-OTHER-INFO.
025970
025970     INITIALIZE  FREQUENTLY-USED-INDICES.
025970
025970     MOVE SPACES TO  WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET WS-PDGA-TBL-SIZE-DEFAULT    TO TRUE. 
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.

025970 COPY XCPS8090.
025970 COPY CCPS0620.
       COPY CCPL0620.

025970 COPY XCPS1640.
       COPY XCPL1640.

025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY CCPS2430.
       COPY CCPL2430.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPDEP.
      /
       COPY CCPBPDGA.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POL
                                '$VAR2'   BY 'POL'.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM1710
      *****************************************************************
