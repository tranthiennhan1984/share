      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       COPY XCWWCRHT.
      *
       PROGRAM-ID. CSOM0651.
      *
      *****************************************************************
      **  MEMBER :  CSOM0651                                         **
      **  REMARKS:  THE PPAY TRANSACTION IS USED TO RECORD PAYMENTS  **
      **            AND REVERSALS, WITH ACCOUNTING AUTOMATICALLY     **
      **            GENERATED.  THE USER MAY SELECT WHERE THE MONEY  **
      **            SHOULD BE ALLOCATED OR THEY MAY USE THE ENTRY    **
      **            LINES TO RECORD ACCOUNTING DIRECTLY TO SPECIFIC  **
      **            ACCOUNTS.                                        **
      **                                                             **
      **  DOMAIN : BC                                                **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
550029**  5.5       HEAT # 10029 - FIX SHORTAGE PROBLEMS             **
551892**  5.5       INIT TURNAROUND NUMBER AFTER PROCESSING          **
557658**  5.5       YEAR 2000                                        **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557691**  5.5       ADD A TAX YEAR FIELD, APPLY ONLY TO 'US'         **
557696**  5.5       DISPLAY WARNING MSGE FOR 'US' CTRY & CURNCY      **
557708**  5.5       GLOBAL CHANGE ON ABEND HANDLING                  **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZE CHANGES FOR INTERNATIONAL      **
010128**  5.5.1     SHORT AMOUNT INITIALIZATION                      **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
010897**  5.5.2     HEAT #10897 - FIX SHORTAGE PROBLEM WHEN          **
010897**            TURNAROUND TRANSACTION                           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEANUP AND STANDARDIZATION                 **
010312**  5.6       DIR-BILL-NUM(TRNARND) INCREASED TO 10 CHAR       **
010418**  5.6       CHANGES FOR MULTI-CO                             **
012137**  5.6V      SEC CONFIRMATION STATEMENTS                      **
012143**  5.6V      DEPOSIT BASED SURRENDER CHARGES                  **
012147**  5.6V      NET OF COMMISSION                                **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT                                  **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL LOCKING                                  **
014579**  6.2       RETAINED COMMISSIONS FIX                         **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016395**  6.2       CREDIT CARD BILLING                              **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016457**  6.2       REMOVE TRAN "00"                                 **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP 0220 PARAGRAPH NOT BEING USED      **
016548**  6.2       CHANGE COMP TO BINARY                            **
018971**  6.3       FIX PROBLEM WITH TOLERANCE AMOUNT & DOCUMENTATION**
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
017484**  6.3       BLANK OUT ASTERISK FIELDS                        **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
020167**  6.3       FUND SOURCE CODE EDIT                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
018525**  6.4       EDIT FOR REVERSAL REASON CODE                    **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
021938**  6.4       DEDUCE REASON CODE FOR CSDC6750 AMOUNT EDITS     **
022637**  6.4       POLICY PAYMENTS USING ENTRY LINE                 **
022968**  6.5       INCLUDE RETAINED COMMSSION IN TOTAL PAYMENT      **
022330**  6.5       PAYMENT REVERSAL ACCOUNT INFORMATION AMOUNTS     **
023061**  6.5       MISSING PROGRAM CHANGES FOR MESSAGES NS0760      **
023662**  6.5       PDF WITHDRAWAL                                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024088**  6.4ASC    RECOGNIZE THE EARLIER PAYMENT ON A POLICY THAT   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **            WAS SUSPENDED AND IS NOW BEING RE-ISSUED         **
025586**  6.5       ADD PHST EDIT                                    **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025715**  6.6       AUTO REDO VIA POLICY PAYMENT REVERSAL            **
025767**  6.6       UNDO OF APP NOT REVERSING PAID TO DATE           **
025714**  6.6       LOOPING PROBLEM ON PREMIUM REVERSAL              **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
027435**  6.7       REVERSAL ON FINAL APL                            **
026678**  6.7       PREMIUM REVERSAL ON PAID UP POLICY               **
031034**  7.0       TAX COMPONENTIZATION                             **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
      *****************************************************************

       ENVIRONMENT DIVISION.
      *
      /
       DATA DIVISION.
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0651'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
      /
      ****************************************************************
      *  WORKING STORAGE FOR CSOM0651                                *
      ****************************************************************
      *
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID            PIC X(04).
               88  WS-BUS-FCN-PAYMENT   VALUES '0460'.
               88  WS-BUS-FCN-TRNANO    VALUES '0461'.
               88  WS-BUS-FCN-REVERSAL  VALUES '0462'.
014221     05  WS-TWRK-KEY              PIC X(04)  VALUE '0460'.
025970         88 WS-TWRK-KEY-DEFAULT       VALUE '0460'.
           05  WS-ERROR-IND             PIC X.
               88  WS-ERROR-NONE            VALUE 'N'.
               88  WS-ERROR-OCCURRED        VALUE 'Y'.
               88  WS-ACCESS-ERROR-OCCURRED VALUE 'X'.
               88  WS-ERROR-USER-CANCELLED  VALUE 'A'.
           05  WS-NUM-ERR-SW            PIC X.
               88  NO-NUM-ERR               VALUE 'N'.
               88  NUM-ERR-OCCURRED         VALUE 'Y'.
557691     05  WS-TXYR-ERR-SW           PIC X.
557691         88  WS-NO-TXYR-ERR           VALUE 'N'.
557691         88  WS-TXYR-ERR-OCCURRED     VALUE 'Y'.
016395     05  WS-REVRS-CD-ERR-SW       PIC X.
016395         88  WS-NO-REVRS-CD-ERR       VALUE 'N'.
016395         88  WS-REVRS-CD-ERR-OCCURRED VALUE 'Y'.
031034*    05  WS-PLAR-ALLOC-ERR-SW     PIC X.
031034*        88  WS-NO-PLAR-ALLOC-ERR     VALUE 'N'.
031034*        88  WS-PLAR-ALLOC-ERR-OCCURRED
031034*                                     VALUE 'Y'.
015290     05  WS-ALLOC-INIT-SW         PIC X(01).
015290         88  WS-ALLOC-INIT-NO         VALUE 'N'.
015290         88  WS-ALLOC-INIT            VALUE 'Y'.
           05  UPDATE-SW                PIC 9.
               88  NO-UPDATE                VALUE 0.
               88  UPDATE-REQUIRED          VALUE 1.
           05  WS-IF-DETAILS-ENTERED    PIC X.
               88  WS-DETAILS-ENTERED       VALUE 'Y'.
               88  WS-NO-DETAILS-ENTERED    VALUE 'N'.
016503     05  WS-REDO-SW               PIC X(01).
016503         88  WS-REDO-OK               VALUE 'Y'.
016503         88  WS-REDO-NOT-OK           VALUE 'N'.
031034*    05  WS-PLAR-RULE-SW          PIC X(01).
031034*        88  WS-PLAR-RULE-NOT-SET     VALUE 'N'.
031034*        88  WS-PLAR-RULE-SET         VALUE 'Y'.
031034*    05  WS-HOLD-PGAL-ALLOC-SW    PIC X(01).
031034*        88  WS-HOLD-PGAL-ALLOC-REQ   VALUE 'Y'.
008455     05  HOLD-DR1                 PIC S9(13)V99  COMP-3.
008455     05  HOLD-CR1                 PIC S9(13)V99  COMP-3.
008455     05  HOLD-DR2                 PIC S9(13)V99  COMP-3.
008455     05  HOLD-CR2                 PIC S9(13)V99  COMP-3.
031034*    05  WS-POL-PMT-AMT           PIC S9(13)V99  COMP-3.
031034*    05  WS-TOT-ALLOC-AMT         PIC S9(13)V99  COMP-3.
031034*    05  WS-1035-ACB-AMT          PIC S9(13)V99  COMP-3.
015290     05  WS-TOT-PMT-AMT           PIC S9(13)V99  COMP-3.
015290     05  WS-OTH-PMT-AMT           PIC S9(13)V99  COMP-3.
015290     05  WS-DEPOSIT-AMT           PIC S9(13)V99  COMP-3.
031034*    05  WS-MIR-PGAL-INFO        OCCURS 9 TIMES.
031034*        10  WS-MIR-PGAL-ALLOC-TYP-CD
031034*                                 PIC X(01).
031034*        10  WS-MIR-PGAL-TRXN-PRIN-AMT
031034*                                 PIC X(17).
031034*        10  WS-MIR-PGAL-TRXN-GAIN-AMT
031034*                                 PIC X(17).
031034*    05  WS-HOLD-PGAL-ALLOC-INFO OCCURS 9 TIMES.
031034*        10  WS-HOLD-PGAL-ALLOC-TYP-CD
031034*                                 PIC X(01).
031034*        10  WS-HOLD-PGAL-TRXN-PRIN-AMT
031034*                                 PIC S9(13)V99  COMP-3.
031034*        10  WS-HOLD-PGAL-TRXN-GAIN-AMT
031034*                                 PIC S9(13)V99  COMP-3.
031034*    05  WS-DFLT-ALLOC-TYP-CD     PIC X(01).
           05  HOLD-POLICY.
               10  FILLER               PIC X(9).
               10  HOLD-SUFFIX          PIC X.
           05  HOLD-NAME                PIC X(75).
557973     05  WS-TST-BALANCE           PIC S9(13)V99   COMP-3.
           05  WS-DATE.
557658         10  WS-DATE-YR           PIC 9(04).
               10  FILLER               PIC X.
               10  WS-DATE-MONTH        PIC 9(02).
               10  FILLER               PIC X.
               10  WS-DATE-DAY          PIC 9(02).
016503     05  WS-PD-TO-DT              PIC X(10).
016503     05  WS-REDO-EFF-DT           PIC X(10).
016548*    05  WS-SUB                   PIC S9(04) COMP.
016548     05  WS-SUB                   PIC S9(04) BINARY.
016548*    05  WS-MAX-LINES             PIC S9(04) COMP VALUE +02.
016548     05  WS-MAX-LINES             PIC S9(04) BINARY VALUE +02.
025970         88 WS-MAX-LINES-DEFAULT       VALUE +02.
557696     05  WS-ACCT.
557696         10  WS-ACCT-TYP          PIC X(01).
557696             88  WS-ACCT-TYP-COMM VALUE '5'.
557696         10  WS-ACCT-NUM          PIC X(05).
557691     05  WS-TAX-YEAR              PIC X(04).
557691     05  WS-TAX-YEAR-N            REDEFINES
557691         WS-TAX-YEAR              PIC 9(04).
012137     05  WS-SUPCNF-CODE           PIC X.
012137         88 WS-SUPCNF-CODE-VALID  VALUES  'Y' 'N'.
016395     05  WS-CRC-ID.
016395         10  WS-CRC-ID-1          PIC X(20).
016395         10  WS-CRC-ID-2          PIC X(01).
016395         10  FILLER               PIC X(19).
016395     05  WS-DALG-PARM-1.
016395         10  WS-DALG-PARM-1-1     PIC X(06).
016395         10  FILLER               PIC X(01).
016395         10  WS-DALG-PARM-1-2     PIC X(04).
016395         10  FILLER               PIC X(09).
016395     05  WS-DALG-PARM-4.
016395         10  WS-DALG-PARM-4-1     PIC X(03).
016395         10  FILLER               PIC X(01).
016395         10  WS-DALG-PARM-4-2     PIC X(16).
025586     05  WS-PHST-SW               PIC X(01).
025586         88  WS-PHST-FOUND        VALUE 'Y'.
025586         88  WS-PHST-NOTFND       VALUE 'N'.
031034     05  WS-PGAC-RETRN-CD         PIC S9(04) BINARY.
031034         88  WS-PGAC-RETRN-OK     VALUE ZERO.
029060     05  WS-VALU-EDIT-TEXT             PIC X(20).
029060     05  FILLER REDEFINES WS-VALU-EDIT-TEXT.
029060         10  WS-VALU-EDIT-AMT          PIC X(16).
029060         10  WS-VALU-EDIT-SLASH        PIC X(1).
029060         10  WS-VALU-EDIT-SEQ-NUM      PIC 9(3).

031034 01  WS-CONSTANT.
031034     05  WS-MAX-ALLOC-TYP         PIC S9(04)  BINARY.
031034         88  WS-MAX-ALLOC-TYP-DEFAULT VALUE +9.

       01  PRINT-TA-LINE.
           05  PRT-TA-POLICY            PIC X(10).
           05  PRT-TA-NAME.
               10  PRT-TA-FI            PIC XX.
               10  PRT-TA-LAST          PIC X(12).
008453     05  PRT-TA-PD-TO-DATE        PIC X(10).
      /
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
      *
       COPY CCWWINDX.
      /
       COPY XCWWWKDT.
      /
030054 COPY XCWWCNST.
030054
014221 COPY CCWWLOCK.
016395/
016395 COPY XCWEBLCH.
015290*
015290 COPY CCWWBTAX.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
      *

       COPY CCFWCVG.
       COPY CCFRCVG.
025586 COPY CCFWPHST.
025586 COPY CCFRPHST.
       COPY CCFHPOL.
       COPY CCFWPOL.
021930*COPY NCFWDALT.
021930*COPY NCFRDALT.
021930*COPY NCFWDALG.
021930*COPY NCFRDALG.
018763*COPY XCFWDMAD.
018763*COPY XCFRDMAD.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
      *
020478 COPY CCWL2626.
031034*COPY CCWLCNEX.
031034 COPY CCWLPGAC.
013697/
021930*COPY CCWLPGAI.
021930*
031034*COPY CCWLPGAL.
015290/
031034 COPY CCWL0182.
031034*COPY CCWL0187.
015290*
016503 COPY CCWL0201.
      *
016503 COPY CCWL0289.
      /
       COPY CCWL0620.
      /
       COPY CCWL0652.
      /
016108 COPY CCWL0985.
016108/
       COPY NCWL0760.
      /
       COPY CCWL1651.
      /
       COPY CCWL2430.
      /
557696 COPY CCWL4180.
557696/
016503 COPY CCWL4780.
      /
       COPY CCWL5400.
      /
031034*COPY CCWL7800.
031034*
       COPY XCWLDTLK.
      /
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
008455/
013697 COPY XCWL0316.
013697/
       COPY XCWL1640.
      /
025714*COPY XCWL1660.
025714*
014221 COPY XCWL8090.
      /
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0651.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      *--------------
       0000-MAINLINE.
      *--------------
      *
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

025388     IF  MIR-CF-REG-FND-SRC-CD = SPACES
025388         SET MIR-CF-REG-FND-REG-CONTRB  TO TRUE
025388     END-IF.
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  0200-PROCESS-REQUEST
               THRU 0200-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
       0200-PROCESS-REQUEST.
      *=========================
      ******************************************************************
      **                                                              **
      **            P R O C E S S    T R A N S A C T I O N S          **
      **                                                              **
      **--------------------------------------------------------------**
      **  THIS ROUTINE PERFORMS THE FOLLOWING TASKS:                  **
      **  0. CHECK FOR STACKED COMMAND LINE ENTRY, AND SET DEFAULTS   **
      **       WHEN CCOMM-PROGRAM-NUMBER IS BLANK                     **
      **  1. RECEIVE THE APPROPRIATE MAP                              **
      **  2. SAVE INPUT FROM THE TOP LINE                             **
      **  3. IF TURNAROUND, SET TRANSACTION TYPE TO 'T'               **
      **  4. INITIALIZE GENERAL WORKING STORAGE                       **
      **  5. CLEAR ERRORS FROM SCREEN                                 **
      **  6. CHECKS USER ACCESS                                       **
      **  7. CHECKS CODE ENTERED FOR VALIDITY                         **
      **  8. IF CANCEL CODE, RESET  MAP (TO INITIAL) AND TERMINATE    **
      **     PROCESSING                                               **
      **  9. BASED ON FORCE CODE, EITHER OPEN SCREEN FOR INPUT OR     **
      **     EDIT/PROCESS INPUT                                       **
      ******************************************************************
      *
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *
      *  9000-CHECK-SECURITY WILL VALIDATE THE ENTER CODE AND
      *  CHECK SECURITY
      *
           SET MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.
012137     MOVE MIR-SUPRES-CNFRM-IND   TO WS-SUPCNF-CODE.
016503     MOVE WWKDT-ZERO-DT          TO WS-REDO-EFF-DT.
031034*
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034     PERFORM  PGAC-1000-BUILD-PARM-INFO
031034         THRU PGAC-1000-BUILD-PARM-INFO-X.
015290
031034*    MOVE ZEROS        TO WS-POL-PMT-AMT.
031034*    MOVE ZEROS        TO WS-TOT-ALLOC-AMT
031034*    MOVE ZEROS        TO WS-1035-ACB-AMT.
015290
031034*    PERFORM
031034*    VARYING  LPGAL-SUB FROM +1 BY +1
031034*      UNTIL  LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*          MOVE SPACES TO WS-HOLD-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*          MOVE ZEROS  TO WS-HOLD-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*          MOVE ZEROS  TO WS-HOLD-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*          MOVE MIR-PLAR-ALLOC-TYP-CD-T (LPGAL-SUB)
031034*            TO WS-MIR-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*          MOVE MIR-PGAL-TRXN-PRIN-AMT-T (LPGAL-SUB)
031034*            TO WS-MIR-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*          MOVE MIR-PGAL-TRXN-GAIN-AMT-T (LPGAL-SUB)
031034*            TO WS-MIR-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*    END-PERFORM.

031034     PERFORM
031034     VARYING  WS-SUB FROM +1 BY +1
031034       UNTIL  WS-SUB > WS-MAX-ALLOC-TYP
031034           MOVE MIR-PLAR-ALLOC-TYP-CD-T    (WS-SUB)
031034             TO LPGAC-PGAL-ALLOC-TYP-CD-T  (WS-SUB)
031034           MOVE MIR-PGAL-TRXN-PRIN-AMT-T   (WS-SUB)
031034             TO LPGAC-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
031034           MOVE MIR-PGAL-TRXN-GAIN-AMT-T   (WS-SUB)
031034             TO LPGAC-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
031034     END-PERFORM.

      *
015290     PERFORM  0241-INIT-MIR-ALLOC-VALUES
015290         THRU 0241-INIT-MIR-ALLOC-VALUES-X
015290         VARYING  WS-SUB FROM +1 BY +1
031034*          UNTIL  WS-SUB > LPGAL-MAX-ALLOC-TYP.
031034           UNTIL  WS-SUB > 9.
      *
           IF  WS-BUS-FCN-TRNANO
           OR  WS-BUS-FCN-PAYMENT
           OR  WS-BUS-FCN-REVERSAL
               CONTINUE
           ELSE
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
               MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
               MOVE MIR-BUS-FCN-ID
                                 TO WGLOB-MSG-PARM (1)
               MOVE 'CSOM0651'   TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-INVALD-RQST TO TRUE
               GO TO 0200-PROCESS-REQUEST-X
           END-IF.
      *
           SET WS-ERROR-NONE             TO TRUE.
           SET NO-NUM-ERR                TO TRUE.
557691     SET WS-NO-TXYR-ERR            TO TRUE.
016395     SET WS-NO-REVRS-CD-ERR        TO TRUE.
031034*    SET WS-NO-PLAR-ALLOC-ERR      TO TRUE.
           SET WS-NO-DETAILS-ENTERED     TO TRUE.
           MOVE ZERO                     TO WGLOB-MSG-ERROR-SW.
           MOVE ZERO                     TO UPDATE-SW.
      *

           EVALUATE MIR-DV-PRCES-STATE-CD

               WHEN '2'
                    PERFORM  1100-SECOND-PASS-PROCESSING
                        THRU 1100-SECOND-PASS-PROCESSING-X

               WHEN '3'
                    PERFORM  1200-THIRD-PASS-PROCESSING
                        THRU 1200-THIRD-PASS-PROCESSING-X

               WHEN OTHER
                    SET  MIR-RETRN-INVALD-RQST TO TRUE
014590              MOVE MIR-RETRN-CD TO WGLOB-ERR-RETRN-CD
                    PERFORM  0030-5000-LOGIC-ERROR
                        THRU 0030-5000-LOGIC-ERROR-X

           END-EVALUATE.

031034     IF  LPGAC-PGAL-ALLOC-REQ
031034         PERFORM  1890-RGN-EXIT-FOR-GAIN
031034             THRU 1890-RGN-EXIT-FOR-GAIN-X
031034         IF  NOT L0316-RETRN-OK
031034         OR  L0316-RGN-EXIT-STAT-INACTV
031034             PERFORM  PGAC-6000-POL-GAIN-REFRESH
031034                 THRU PGAC-6000-POL-GAIN-REFRESH-X
031034         END-IF
031034     END-IF.
      *
       0200-PROCESS-REQUEST-X.
      *=======================
           EXIT.
      /
       0210-SETUP-FOR-TURNAROUND.
      *=====================
      ******************************************************************
      **                                                              **
      **          S E T  U P    F O R    T U R N A R O U N D          **
      **                                                              **
      **--------------------------------------------------------------**
      **  THIS ROUTINE PERFORMS THE FOLLOWING TASKS:                  **
      **  1. CALLS CSLF0652 TO EDIT THE TURNAROUND NUMBER             **
      **  2. RETURN EXPECTED POLICY, AMOUNT, ETC. FOR THE TA RECORD   **
      **  3. SET UP RESPONSE FIELD IF NO ERROR                        **
      ******************************************************************
      *

           PERFORM  0652-1000-BUILD-PARM-INFO
               THRU 0652-1000-BUILD-PARM-INFO-X.

           MOVE MIR-DIR-BILL-NUM       TO L0652-DIR-BILL-NUM.
           MOVE 'P'               TO L0652-ENTER-CD.

           PERFORM  0652-1000-TURNAROUND-EDITS
               THRU 0652-1000-TURNAROUND-EDITS-X.
      *
           IF L0652-RETRN-TA-NUM-ERROR
           OR L0652-RETRN-TA-NOT-FOUND
               SET WS-ERROR-OCCURRED TO TRUE
               GO TO 0210-SETUP-FOR-TURNAROUND-X
           END-IF.


           MOVE SPACE                    TO PRINT-TA-LINE.
           MOVE L0652-POL-ID             TO PRT-TA-POLICY.
           MOVE L0652-INSRD-FRST-INIT-NM TO PRT-TA-FI.
           MOVE L0652-INSRD-SUR-NM       TO PRT-TA-LAST.
           MOVE L0652-DIR-BILL-DUE-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO PRT-TA-PD-TO-DATE.
           MOVE PRT-TA-POLICY            TO MIR-POL-ID.
           PERFORM  0260-GET-OWNER-NAME
               THRU 0260-GET-OWNER-NAME-X.

           MOVE PRT-TA-PD-TO-DATE        TO MIR-DIR-BILL-DUE-DT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0652-DIR-BILL-CSH-AMT * 100.
020874     MOVE L0652-DIR-BILL-CSH-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-CSH-AMT     TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-CSH-AMT.

           IF L0652-RETRN-ERROR
               SET WS-ERROR-OCCURRED TO TRUE
               GO TO 0210-SETUP-FOR-TURNAROUND-X
           END-IF.


       0210-SETUP-FOR-TURNAROUND-X.
      *======================
           EXIT.
      /
016537* CODE CLEAN UP. THIS PARAGRAPH IS NOT BEING CALLED.
016537*0220-SETUP-FOR-PYMT-REV.
016537**===================
016537******************************************************************
016537**                                                              **
016537**     S E T U P     F O R    P A Y M E N T / R E V E R S A L   **
016537**                                                              **
016537**--------------------------------------------------------------**
016537**  THIS ROUTINE PERFORM S THE FOLLOWING TASKS:                 **
016537**  1. OPEN  SCREEN FOR INPUT                                   **
016537**  2. DEFAULT POLICY AND DATE FROM TERMINAL RECORD             **
016537**  3. PLACE CURSOR AT POLICY NUMBER                            **
016537******************************************************************
016537*
016537*    MOVE 'N'                        TO MIR-DV-REVRS-REASN-CD.
016537*    MOVE WGLOB-PROCESS-DATE         TO L1640-INTERNAL-DATE.
016537*    PERFORM 1640-2000-INTERNAL-TO-EXT
016537*       THRU 1640-2000-INTERNAL-TO-EXT-X.
016537*    MOVE L1640-EXTERNAL-DATE        TO MIR-DV-PRCES-DT.
016537*
016537*    0220-SETUP-FOR-PYMT-REV-X.
016537*==========
016537*    EXIT.
016537*
       0230-SETUP-FOR-CHANGE.
      *================
      ******************************************************************
      **                                                              **
      **             S E T U P     F O R    C H A N G E               **
      **                                                              **
      **--------------------------------------------------------------**
      **  THIS ROUTINE PERFORM S THE FOLLOWING TASKS:                 **
      **  1. OPEN  SCREEN FOR INPUT                                   **
      **  2. PLACE CURSOR AT FIRST DATA ELEMENT                       **
      ******************************************************************
      *

           PERFORM  0250-SHOW-PPAY-VALUES
               THRU 0250-SHOW-PPAY-VALUES-X.

       0230-SETUP-FOR-CHANGE-X.
      *==========
           EXIT.
      *
      /
      *
       0240-SET-VALUES.
      *===========
      *
013578     MOVE SPACES                   TO MIR-DV-PRCES-DT.
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-ENTR-CSH-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DV-ENTR-CSH-AMT.
008455
020467     MOVE ZEROS                    TO L0290-INPUT-V02.
020467     MOVE 2                        TO L0290-PRECISION.
020467     MOVE LENGTH OF MIR-DV-DD2-DRW-TOT-AMT TO L0290-MAX-OUT-LEN.
020467     PERFORM  0290-2000-FORMAT-FOR-MIR
020467         THRU 0290-2000-FORMAT-FOR-MIR-X.
020467     MOVE L0290-OUTPUT-DATA        TO MIR-DV-DD2-DRW-TOT-AMT.
020467
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT     TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-PAC-DRW-TOT-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
016395     MOVE 2                        TO L0290-PRECISION.
016395     MOVE LENGTH OF MIR-CRC-TRXN-AMT  TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016395     MOVE L0290-OUTPUT-DATA        TO MIR-CRC-TRXN-AMT.

020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-PREM-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-PREM-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-LOAN-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-LOAN-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-APL-AMT    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-APL-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-PDF-AMT    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-PDF-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-DPOS-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-DPOS-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
012147     MOVE 2                        TO L0290-PRECISION.
012147     MOVE LENGTH OF MIR-DV-POL-RCOMM-AMT    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
012147     MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-RCOMM-AMT.
012147
020874*    MOVE 0                           TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                       TO L0290-INPUT-V02.
008455     MOVE 2                           TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-CR-ACCT-TRXN-AMT-T (01)
015904     MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (01)
                                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-CR-ACCT-TRXN-AMT-T (01).
015904     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TRNXT-CR-AMT-T (01).
008455
020874*    MOVE 0                           TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                       TO L0290-INPUT-V02.
008455     MOVE 2                           TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-DB-ACCT-TRXN-AMT-T (01)
015904     MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (01)
                                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-DB-ACCT-TRXN-AMT-T (01).
015904     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TRNXT-DR-AMT-T (01).
008455
020874*    MOVE 0                           TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                       TO L0290-INPUT-V02.
008455     MOVE 2                           TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-CR-ACCT-TRXN-AMT-T (02)
015904     MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (02)
                                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-CR-ACCT-TRXN-AMT-T (02).
015904     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TRNXT-CR-AMT-T (02).
008455
020874*    MOVE 0                           TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                       TO L0290-INPUT-V02.
008455     MOVE 2                           TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-DB-ACCT-TRXN-AMT-T (02)
015904     MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (02)
                                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-DB-ACCT-TRXN-AMT-T (02).
015904     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TRNXT-DR-AMT-T (02).
008455
      *
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT   TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-POL-PREM-SUSP-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PDF-SUSP-AMT    TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-POL-PDF-SUSP-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT   TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-POL-MISC-SUSP-AMT.
008455
020874*    MOVE 0                        TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-OS-DISB-AMT     TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-POL-OS-DISB-AMT.
008455
020874*    MOVE ZERO                     TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                    TO L0290-INPUT-V02.
018846     MOVE 2                        TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-POL-SIDFND-DPOS-AMT
018846       TO L0290-MAX-OUT-LEN.
018846     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-SIDFND-DPOS-AMT.
018846
015290     PERFORM  0241-INIT-MIR-ALLOC-VALUES
015290         THRU 0241-INIT-MIR-ALLOC-VALUES-X
015290     VARYING  WS-SUB FROM +1 BY +1
031034*      UNTIL  WS-SUB > LPGAL-MAX-ALLOC-TYP.
031034       UNTIL  WS-SUB > 9.
      *
           MOVE '000'                    TO MIR-DV-CF-PREM-SEQ-NUM.
           MOVE '000'                    TO MIR-DV-CF-DEP-SEQ-NUM.
025388*    MOVE SPACES                   TO MIR-CF-REG-FND-SRC-CD.
025388     SET  MIR-CF-REG-FND-REG-CONTRB TO TRUE.
557691     MOVE '0000'                   TO MIR-CF-TAX-YR.
012147     MOVE SPACES                   TO MIR-AGT-ID.
      *
020478*    MOVE SPACES                 TO MIR-POL-ID-BASE.
020478*    MOVE SPACES                 TO MIR-POL-ID-SFX.
           MOVE SPACES                 TO MIR-DV-REVRS-REASN-CD.
016395     MOVE SPACES                 TO MIR-CRC-TRXN-REVRS-CD.
           MOVE SPACES                 TO MIR-ACCT-BASE-ID-T (01).
010418     MOVE SPACES                 TO MIR-SBSDRY-CO-ID-T (01).
           MOVE SPACES                 TO MIR-BR-OR-DEPT-ID-T (01).
           MOVE SPACES                 TO MIR-ACCT-ISS-LOC-CD-T (01).
           MOVE SPACES                 TO MIR-ACCT-CRNT-LOC-CD-T (01).
           MOVE SPACES                 TO MIR-AGT-ID-T (01).
016457*    MOVE SPACES                 TO MIR-DV-AGT-REASN-CD-T (01).
016457     MOVE SPACES                 TO MIR-COMM-TRXN-REASN-CD-T (01).
016457*    MOVE SPACES                 TO MIR-DV-ACCT-DESC-TXT-T (01).
016457     MOVE SPACES                 TO MIR-ACCT-DESC-TXT-T (01).
           MOVE SPACES                 TO MIR-ACCT-BASE-ID-T (02).
010418     MOVE SPACES                 TO MIR-SBSDRY-CO-ID-T (02).
           MOVE SPACES                 TO MIR-BR-OR-DEPT-ID-T (02).
           MOVE SPACES                 TO MIR-ACCT-ISS-LOC-CD-T (02).
           MOVE SPACES                 TO MIR-ACCT-CRNT-LOC-CD-T (02).
           MOVE SPACES                 TO MIR-AGT-ID-T (02).
016457*    MOVE SPACES                 TO MIR-DV-AGT-REASN-CD-T (02).
016457     MOVE SPACES                 TO MIR-COMM-TRXN-REASN-CD-T (02).
016457*    MOVE SPACES                 TO MIR-DV-ACCT-DESC-TXT-T (02).
016457     MOVE SPACES                 TO MIR-ACCT-DESC-TXT-T (02).
      *
       0240-SET-VALUES-X.
      *========
           EXIT.
      /
015290*-------------------------
015290 0241-INIT-MIR-ALLOC-VALUES.
015290*-------------------------
015290
015290     MOVE SPACES TO MIR-PLAR-ALLOC-TYP-CD-T  (WS-SUB).
015290
020874*    MOVE 0      TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS  TO L0290-INPUT-V02.
015290     MOVE 2      TO L0290-PRECISION.
015290     MOVE LENGTH OF MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
015290                 TO L0290-MAX-OUT-LEN.
015290     SET  L0290-SIGN-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015290     MOVE L0290-OUTPUT-DATA
015290                 TO MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB).
015290
020874*    MOVE 0      TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS  TO L0290-INPUT-V02.
015290     MOVE 2      TO L0290-PRECISION.
015290     MOVE LENGTH OF MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
015290                 TO L0290-MAX-OUT-LEN.
015290     SET  L0290-SIGN-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015290     MOVE L0290-OUTPUT-DATA
015290                 TO MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB).
015290
015290 0241-INIT-MIR-ALLOC-VALUES-X.
015290     EXIT.
      /
       0250-SHOW-PPAY-VALUES.
      *=================
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-CASH-AMT * 100.
020874     MOVE L1651-CASH-AMT           TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-ENTR-CSH-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DV-ENTR-CSH-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-PAC-AMT * 100.
020874     MOVE L1651-PAC-AMT            TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT     TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-PAC-DRW-TOT-AMT.
008455
020467     MOVE L1651-DD2-AMT            TO L0290-INPUT-V02.
020467     MOVE 2                        TO L0290-PRECISION.
020467     MOVE LENGTH OF MIR-DV-DD2-DRW-TOT-AMT TO L0290-MAX-OUT-LEN.
020467     PERFORM  0290-2000-FORMAT-FOR-MIR
020467         THRU 0290-2000-FORMAT-FOR-MIR-X.
020467     MOVE L0290-OUTPUT-DATA        TO MIR-DV-DD2-DRW-TOT-AMT.
020467
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-CRC-AMT * 100.
020874     MOVE L1651-CRC-AMT            TO L0290-INPUT-V02.
016395     MOVE 2                        TO L0290-PRECISION.
016395     MOVE LENGTH OF MIR-CRC-TRXN-AMT        TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
016395     MOVE L0290-OUTPUT-DATA        TO MIR-CRC-TRXN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L1651-PREM-AMT * 100.
020874     MOVE L1651-PREM-AMT           TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-PREM-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-PREM-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-LOAN-AMT * 100.
020874     MOVE L1651-LOAN-AMT           TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-LOAN-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-LOAN-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-APL-AMT * 100.
020874     MOVE L1651-APL-AMT            TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-APL-AMT    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-APL-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-PDF-SUSP-AMT * 100.
020874     MOVE L1651-PDF-SUSP-AMT       TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PDF-SUSP-AMT    TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-POL-PDF-SUSP-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-PDF-AMT * 100.
020874     MOVE L1651-PDF-AMT            TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-PDF-AMT    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-PDF-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-DEPOSIT-AMT * 100.
020874     MOVE L1651-DEPOSIT-AMT        TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DIR-BILL-DPOS-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-DIR-BILL-DPOS-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-PRM-SUSP-AMT * 100.
020874     MOVE L1651-PRM-SUSP-AMT       TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT   TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-POL-PREM-SUSP-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-SUSP-AMT * 100.
020874     MOVE L1651-SUSP-AMT           TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT   TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-POL-MISC-SUSP-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-OS-DISB-AMT * 100.
020874     MOVE L1651-OS-DISB-AMT        TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-OS-DISB-AMT     TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA        TO MIR-POL-OS-DISB-AMT.
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-SIDFND-AMT * 100.
020874     MOVE L1651-SIDFND-AMT         TO L0290-INPUT-V02.
018846     MOVE 2                        TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-POL-SIDFND-DPOS-AMT
018846       TO L0290-MAX-OUT-LEN.
018846     SET  L0290-SIGN-DISPLAY       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-SIDFND-DPOS-AMT.
018846
      *
020874*    COMPUTE L0290-INPUT-NUMBER = HOLD-DR1 * 100.
020874     MOVE HOLD-DR1                   TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-DB-ACCT-TRXN-AMT-T (01)
015904     MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (01)
                                           TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-DB-ACCT-TRXN-AMT-T (01).
015904     MOVE L0290-OUTPUT-DATA    TO MIR-DV-TRNXT-DR-AMT-T (01).
008455
020874*    COMPUTE L0290-INPUT-NUMBER = HOLD-CR1 * 100.
020874     MOVE HOLD-CR1                   TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-CR-ACCT-TRXN-AMT-T (01)
015904     MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (01)
                                           TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-CR-ACCT-TRXN-AMT-T (01).
015904     MOVE L0290-OUTPUT-DATA    TO MIR-DV-TRNXT-CR-AMT-T (01).
008455
020874*    COMPUTE L0290-INPUT-NUMBER = HOLD-DR2 * 100.
020874     MOVE HOLD-DR2                   TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-DB-ACCT-TRXN-AMT-T (02)
015904     MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (02)
                                           TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-DB-ACCT-TRXN-AMT-T (02).
015904     MOVE L0290-OUTPUT-DATA    TO MIR-DV-TRNXT-DR-AMT-T (02).
008455
020874*    COMPUTE L0290-INPUT-NUMBER = HOLD-CR2 * 100.
020874     MOVE HOLD-CR2                   TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
015904*    MOVE LENGTH OF MIR-DV-CR-ACCT-TRXN-AMT-T (02)
015904     MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (02)
                                           TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015904*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-CR-ACCT-TRXN-AMT-T (02).
015904     MOVE L0290-OUTPUT-DATA    TO MIR-DV-TRNXT-CR-AMT-T (02).
008455
020874*    COMPUTE L0290-INPUT-NUMBER = L1651-RETCOMM-AMT * 100.
020874     MOVE L1651-RETCOMM-AMT          TO L0290-INPUT-V02.
012147     MOVE 2                          TO L0290-PRECISION.
012147     MOVE LENGTH OF MIR-DV-POL-RCOMM-AMT  TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
012147     MOVE L0290-OUTPUT-DATA          TO MIR-DV-POL-RCOMM-AMT.
012147
031034*    IF  LPGAL-PGAL-ALLOC-REQ
031034     IF  LPGAC-PGAL-ALLOC-REQ
015290     AND L1651-RETRN-OK
015290     AND WS-ERROR-NONE
015290          PERFORM  0252-SHOW-PGAL-ALLOC-INFO
015290              THRU 0252-SHOW-PGAL-ALLOC-INFO-X
015290              VARYING  WS-SUB FROM +1 BY +1
031034*               UNTIL  WS-SUB > LPGAL-MAX-ALLOC-TYP
031034                UNTIL  WS-SUB > 9
015290     END-IF.
015290
           PERFORM  0260-GET-OWNER-NAME
               THRU 0260-GET-OWNER-NAME-X.

       0250-SHOW-PPAY-VALUES-X.
           EXIT.
      /
015290*-------------------------
015290 0252-SHOW-PGAL-ALLOC-INFO.
015290*-------------------------
015290
031034*    IF  WS-HOLD-PGAL-ALLOC-TYP-CD (WS-SUB) = SPACES
031034     IF  LPGAC-PGAL-ALLOC-TYP-CD (WS-SUB) = SPACES
015290         GO TO 0252-SHOW-PGAL-ALLOC-INFO-X
015290     END-IF.
015290
031034*    MOVE WS-HOLD-PGAL-ALLOC-TYP-CD (WS-SUB)
031034     MOVE LPGAC-PGAL-ALLOC-TYP-CD (WS-SUB)
015290                  TO MIR-PLAR-ALLOC-TYP-CD-T (WS-SUB).
015290
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                  WS-HOLD-PGAL-TRXN-PRIN-AMT (WS-SUB)
020874*                               * 100.
031034*    MOVE WS-HOLD-PGAL-TRXN-PRIN-AMT (WS-SUB)
031034     MOVE LPGAC-PGAL-TRXN-PRIN-AMT (WS-SUB)
020874                              TO L0290-INPUT-V02.
015290     MOVE 2       TO L0290-PRECISION.
015290     SET  L0290-SIGN-DISPLAY  TO TRUE.
015290     MOVE LENGTH OF  MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
015290                  TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015290     MOVE L0290-OUTPUT-DATA
015290                  TO MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB).
015290
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                  WS-HOLD-PGAL-TRXN-GAIN-AMT (WS-SUB)
020874*                               * 100.
031034*    MOVE WS-HOLD-PGAL-TRXN-GAIN-AMT (WS-SUB)
031034     MOVE LPGAC-PGAL-TRXN-GAIN-AMT (WS-SUB)
020874                              TO L0290-INPUT-V02.
015290     MOVE 2       TO L0290-PRECISION.
015290     SET  L0290-SIGN-DISPLAY  TO TRUE.
015290     MOVE LENGTH OF  MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
015290                  TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
015290     MOVE L0290-OUTPUT-DATA
015290                  TO MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB).
015290
015290 0252-SHOW-PGAL-ALLOC-INFO-X.
015290     EXIT.
015290/
      *---------------------
       0260-GET-OWNER-NAME.
      *---------------------

      * GET OWNER'S NAME

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID                    TO L2430-POL-ID.
           MOVE ZERO                          TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE                        L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
           END-IF.
      *

       0260-GET-OWNER-NAME-X.
           EXIT.


       1100-SECOND-PASS-PROCESSING.
      *=======================

           PERFORM  1651-0000-INIT-PARM-INFO
               THRU 1651-0000-INIT-PARM-INFO-X.

           PERFORM  1651-1000-BUILD-PARM-INFO
               THRU 1651-1000-BUILD-PARM-INFO-X.

           PERFORM  8900-INIT-ENTRY-LINE-FIELDS
               THRU 8900-INIT-ENTRY-LINE-FIELDS-X.

           IF  WS-BUS-FCN-TRNANO
               PERFORM  0210-SETUP-FOR-TURNAROUND
                   THRU 0210-SETUP-FOR-TURNAROUND-X
               IF  WS-ERROR-OCCURRED
                   GO TO 1100-SECOND-PASS-PROCESSING-X
               END-IF
               PERFORM  1300-SETUP-FROM-TURNAROUND
                   THRU 1300-SETUP-FROM-TURNAROUND-X
           ELSE
               PERFORM  1400-SETUP-FROM-SCREEN
                   THRU 1400-SETUP-FROM-SCREEN-X
           END-IF.

           IF  NUM-ERR-OCCURRED
               MOVE 'CS06510004'           TO WGLOB-MSG-REF-INFO

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-OCCURRED TO TRUE
           END-IF.

557691     IF WS-TXYR-ERR-OCCURRED
557691         MOVE 'CS06510051'           TO WGLOB-MSG-REF-INFO
557691
557691         PERFORM  0260-1000-GENERATE-MESSAGE
557691             THRU 0260-1000-GENERATE-MESSAGE-X
557691         SET WS-ERROR-OCCURRED TO TRUE
557691         SET NUM-ERR-OCCURRED  TO TRUE
557691      END-IF.

016395     IF  WS-REVRS-CD-ERR-OCCURRED
016395         SET WS-ERROR-OCCURRED TO TRUE
016395         SET NUM-ERR-OCCURRED  TO TRUE
016395      END-IF.
      *
           PERFORM  1500-BASIC-EDITS
               THRU 1500-BASIC-EDITS-X.

010418     IF  MIR-SBSDRY-CO-ID-T (01) NOT = SPACES
010418     AND MIR-SBSDRY-CO-ID-T (01) NOT = RPOL-SBSDRY-CO-ID
010418*MSG: 'POLICY SUB-CO DIFFERS FROM ENTERED SUB-CO LINE @1'
010418         MOVE 'CS06510052'  TO WGLOB-MSG-REF-INFO
010418         MOVE '1'           TO WGLOB-MSG-PARM (1)
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         IF WGLOB-MSG-ERROR-SW > 0
010418            GO TO 1100-SECOND-PASS-PROCESSING-X
010418         END-IF
010418     END-IF.

010418     IF  MIR-SBSDRY-CO-ID-T (02) NOT = SPACES
010418     AND MIR-SBSDRY-CO-ID-T (02) NOT = RPOL-SBSDRY-CO-ID
010418*MSG: 'POLICY SUB-CO DIFFERS FROM ENTERED SUB-CO LINE @1'
010418         MOVE 'CS06510052'  TO WGLOB-MSG-REF-INFO
010418         MOVE '2'           TO WGLOB-MSG-PARM (1)
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         IF WGLOB-MSG-ERROR-SW > 0
010418            GO TO 1100-SECOND-PASS-PROCESSING-X
010418         END-IF
010418     END-IF.

           IF  WS-ERROR-OCCURRED
           OR  WS-ACCESS-ERROR-OCCURRED
               PERFORM  0230-SETUP-FOR-CHANGE
                   THRU 0230-SETUP-FOR-CHANGE-X
               GO TO 1100-SECOND-PASS-PROCESSING-X
           END-IF.
013697
031034*    PERFORM  7100-GET-CNTRXN-INFO
031034*        THRU 7100-GET-CNTRXN-INFO-X.
013697
015290     IF  WS-BUS-FCN-PAYMENT
015290     OR  WS-BUS-FCN-TRNANO
031034*        PERFORM  1800-GET-PGAL-INFO
031034*            THRU 1800-GET-PGAL-INFO-X
031034         PERFORM  1800-GET-GAIN-INFO
031034             THRU 1800-GET-GAIN-INFO-X
015290     ELSE
031034*        PERFORM  1840-GET-REV-PGAL-INFO
031034*            THRU 1840-GET-REV-PGAL-INFO-X
031034         PERFORM  1840-GET-REV-GAIN-INFO
031034             THRU 1840-GET-REV-GAIN-INFO-X
015290     END-IF.

      *
      * CALL CSLF1651 TO EDIT THE REQUEST
      *
           IF  WS-ERROR-NONE
031034     AND WS-PGAC-RETRN-OK
               SET L1651-PRCES-TYP-EDIT-ONLY  TO TRUE
016503         SET L1651-REDO-WARNING         TO TRUE
031034*        MOVE LPGAL-PLAR-PRCES-SW       TO L1651-PLAR-PRCES-SW
031034*        MOVE LPGAL-PGAL-ALLOC-SW       TO L1651-PGAL-ALLOC-SW
031034*
031034*        IF  LPGAL-PGAL-ALLOC-REQ
031034*            PERFORM
031034*            VARYING  LPGAL-SUB FROM +1 BY +1
031034*              UNTIL  LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*                   MOVE LPGAL-PGAL-ALLOC-TYP-CD     (LPGAL-SUB)
031034*                        TO L1651-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*                   MOVE LPGAL-PGAL-OPN-PRIN-AMT     (LPGAL-SUB)
031034*                        TO L1651-PGAL-OPN-PRIN-AMT  (LPGAL-SUB)
031034*                   MOVE LPGAL-PGAL-OPN-GAIN-AMT     (LPGAL-SUB)
031034*                        TO L1651-PGAL-OPN-GAIN-AMT  (LPGAL-SUB)
031034*                   MOVE LPGAL-PGAL-TRXN-PRIN-AMT    (LPGAL-SUB)
031034*                        TO L1651-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*                   MOVE LPGAL-PGAL-TRXN-GAIN-AMT    (LPGAL-SUB)
031034*                        TO L1651-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*                   MOVE LPGAL-PGAL-DPOS-DFLT-IND    (LPGAL-SUB)
031034*                        TO L1651-PGAL-DPOS-DFLT-IND (LPGAL-SUB)
031034*            END-PERFORM
031034*        END-IF

               EVALUATE  TRUE
                   WHEN  WS-BUS-FCN-TRNANO
                   WHEN  WS-BUS-FCN-PAYMENT
                      PERFORM  1651-1000-POL-PAYMENT
                          THRU 1651-1000-POL-PAYMENT-X
                   WHEN  WS-BUS-FCN-REVERSAL
027435                   PERFORM  1930-VERIFY-PHST
027435                       THRU 1930-VERIFY-PHST-X
027435                   IF  NOT WS-ERROR-OCCURRED
026678                       IF  RPOL-POL-STAT-IN-FORCE
026678                           SET L1651-ORIGIN-UNDO    TO TRUE
026678                       END-IF
                             PERFORM  1651-2000-POL-REVRS
                                THRU 1651-2000-POL-REVRS-X
027435                   END-IF
               END-EVALUATE

      * SET THE ERROR SWITCH IF CSLF1651 RETURNED WITH AN ERROR

               IF  NOT L1651-RETRN-OK
                   SET WS-ERROR-OCCURRED TO TRUE
               END-IF

           END-IF.

557691***  WE WILL NEED TO KNOW IF ALREADY EXCEED THE NEXT TIME THRU

      * EVEN IF THE USER ENTERED NOTHING, CSLF1651 MAY HAVE
      * SET UP AN ACCOUNT TO PROCESS

           IF  WS-NO-DETAILS-ENTERED

               IF  L1651-PRM-SUSP-AMT NOT = ZERO
               OR  L1651-CASH-AMT     NOT = ZERO
               OR  L1651-PAC-AMT      NOT = ZERO
016395         OR  L1651-CRC-AMT      NOT = ZERO
020467         OR  L1651-DD2-AMT      NOT = ZERO
014579         OR  L1651-RETCOMM-AMT  NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
               END-IF

           END-IF.
      *
           MOVE L1651-FND-SRC-CD  TO MIR-CF-REG-FND-SRC-CD.
557691     MOVE L1651-TAX-YR      TO MIR-CF-TAX-YR.

015290     IF  WS-BUS-FCN-PAYMENT
015290     OR  WS-BUS-FCN-TRNANO
015290         PERFORM  1805-CALC-PMT-AMT
015290             THRU 1805-CALC-PMT-AMT-X
031034*        IF LPGAL-PGAL-ALLOC-REQ
031034         IF LPGAC-PGAL-ALLOC-REQ
015290         AND WS-ERROR-NONE
031034         AND WS-PGAC-RETRN-OK
031034*           PERFORM  1880-XEDIT-PGAL-ALLOC-AMT
031034*               THRU 1880-XEDIT-PGAL-ALLOC-AMT-X
031034             PERFORM  1880-XEDIT-GAIN-ALLOC-AMT
031034                 THRU 1880-XEDIT-GAIN-ALLOC-AMT-X
015290         END-IF
015290     END-IF.
015290
           IF  WS-ERROR-NONE
031034     AND WS-PGAC-RETRN-OK
           AND WS-NO-DETAILS-ENTERED
               MOVE 'CS06510047'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-OCCURRED TO TRUE
           END-IF.

027435*    IF  WS-BUS-FCN-REVERSAL
027435*    AND WS-ERROR-NONE
027435*        PERFORM  1930-VERIFY-PHST
027435*            THRU 1930-VERIFY-PHST-X
025586     IF  WS-ERROR-OCCURRED
031034     OR  NOT WS-PGAC-RETRN-OK
025714*            MOVE 'CS06510004'       TO WGLOB-MSG-REF-INFO
025714*            PERFORM  0260-1000-GENERATE-MESSAGE
025714*                THRU 0260-1000-GENERATE-MESSAGE-X
025586              SET WGLOB-RETURN-ERROR TO TRUE
027435*        END-IF
025586     END-IF.

           IF WS-ERROR-OCCURRED
           OR WS-ERROR-USER-CANCELLED
031034*    OR WS-PLAR-ALLOC-ERR-OCCURRED
031034     OR LPGAC-RETRN-ALLOC-ERROR
               PERFORM  0230-SETUP-FOR-CHANGE
                   THRU 0230-SETUP-FOR-CHANGE-X
               GO TO 1100-SECOND-PASS-PROCESSING-X
           END-IF.

           PERFORM  0250-SHOW-PPAY-VALUES
               THRU 0250-SHOW-PPAY-VALUES-X.
      *
           MOVE 'CS00000016'           TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       1100-SECOND-PASS-PROCESSING-X.
           EXIT.
      /
       1200-THIRD-PASS-PROCESSING.
      *=====================

           PERFORM  1651-0000-INIT-PARM-INFO
               THRU 1651-0000-INIT-PARM-INFO-X.

           PERFORM  1651-1000-BUILD-PARM-INFO
               THRU 1651-1000-BUILD-PARM-INFO-X.

           PERFORM  8900-INIT-ENTRY-LINE-FIELDS
               THRU 8900-INIT-ENTRY-LINE-FIELDS-X.

012147     SET L1651-FINAL-PROCESS          TO TRUE.

           IF WS-BUS-FCN-TRNANO
               PERFORM  1300-SETUP-FROM-TURNAROUND
                   THRU 1300-SETUP-FROM-TURNAROUND-X
           ELSE
               PERFORM  1400-SETUP-FROM-SCREEN
                   THRU 1400-SETUP-FROM-SCREEN-X
557660     END-IF.

           IF NUM-ERR-OCCURRED
               MOVE 'CS06510004'           TO WGLOB-MSG-REF-INFO

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-OCCURRED       TO TRUE
           END-IF.
      *
557691     IF WS-TXYR-ERR-OCCURRED
557691         MOVE 'CS06510051'           TO WGLOB-MSG-REF-INFO
557691
557691         PERFORM  0260-1000-GENERATE-MESSAGE
557691             THRU 0260-1000-GENERATE-MESSAGE-X
557691         SET WS-ERROR-OCCURRED TO TRUE
557691         SET NUM-ERR-OCCURRED  TO TRUE
557691      END-IF.

016395     IF  WS-REVRS-CD-ERR-OCCURRED
016395         SET WS-ERROR-OCCURRED TO TRUE
016395         SET NUM-ERR-OCCURRED  TO TRUE
016395      END-IF.
      *
           PERFORM  1500-BASIC-EDITS
               THRU 1500-BASIC-EDITS-X.

           IF WS-ERROR-OCCURRED
           OR WS-ACCESS-ERROR-OCCURRED
               PERFORM  0230-SETUP-FOR-CHANGE
                   THRU 0230-SETUP-FOR-CHANGE-X
               GO TO 1200-THIRD-PASS-PROCESSING-X
557660     END-IF.

           MOVE L1651-FND-SRC-CD           TO MIR-CF-REG-FND-SRC-CD.
557691     MOVE L1651-TAX-YR               TO MIR-CF-TAX-YR.

           MOVE 1                           TO UPDATE-SW.
           PERFORM  1700-PROCESS-PPAY
               THRU 1700-PROCESS-PPAY-X.
           IF NOT L1651-RETRN-OK
               PERFORM  0230-SETUP-FOR-CHANGE
                   THRU 0230-SETUP-FOR-CHANGE-X
               GO TO 1200-THIRD-PASS-PROCESSING-X
557660     END-IF.

010312     MOVE '0000000000'            TO MIR-DIR-BILL-NUM.
      *
       1200-THIRD-PASS-PROCESSING-X.
           EXIT.
      /
       1300-SETUP-FROM-TURNAROUND.
      *======================
      ******************************************************************
      **                                                              **
      **         S E T U P    F R O M    T U R N A R O U N D          **
      **                                                              **
      **--------------------------------------------------------------**
      **  THIS ROUTINE PERFORMS THE FOLLOWING TASKS:                  **
      **  1. GET THE POLICY NUMBER FROM THE TURNAROUND RECORD         **
      **  2. SET THE EFFECTIVE DATE EQUAL TO THE SYSTEM DATE          **
      **  3. BUILD THE 1651 PARM AREA FROM THE TURNAROUND RECORD      **
      **     DETAILS                                                  **
      ******************************************************************
      *
           MOVE MIR-DIR-BILL-NUM     TO L0652-DIR-BILL-NUM.

           PERFORM  0652-2000-TURNAROUND-PROCESS
               THRU 0652-2000-TURNAROUND-PROCESS-X.

           IF NOT L0652-RETRN-OK
               GO TO 1300-SETUP-FROM-TURNAROUND-X
           ELSE
               MOVE L0652-POL-ID            TO HOLD-POLICY
               MOVE WGLOB-PROCESS-DATE      TO L1651-EFF-DT
               MOVE L0652-INSRD-SUR-NM      TO HOLD-NAME
               MOVE L0652-DIR-BILL-CSH-AMT  TO L1651-CASH-AMT
               MOVE L0652-DIR-BILL-PREM-AMT TO L1651-PREM-AMT
               MOVE L0652-DIR-BILL-LOAN-AMT TO L1651-LOAN-AMT
               MOVE L0652-DIR-BILL-APL-AMT  TO L1651-APL-AMT
               MOVE L0652-DIR-BILL-PDF-AMT  TO L1651-PDF-AMT
               MOVE L0652-DIR-BILL-DPOS-AMT TO L1651-DEPOSIT-AMT
           END-IF.

      *
           IF L1651-LOAN-AMT    NOT = ZERO
           OR L1651-APL-AMT     NOT = ZERO
           OR L1651-PDF-AMT     NOT = ZERO
           OR L1651-DEPOSIT-AMT NOT = ZERO
           OR L1651-PREM-AMT    NOT = ZERO
               SET WS-DETAILS-ENTERED TO TRUE
           END-IF.

           MOVE HOLD-POLICY           TO MIR-POL-ID-BASE.
           MOVE HOLD-SUFFIX           TO MIR-POL-ID-SFX.
           MOVE WGLOB-PROCESS-DATE    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DV-PRCES-DT.

020874*    COMPUTE L0290-INPUT-NUMBER = L1651-CASH-AMT * 100.
020874     MOVE L1651-CASH-AMT        TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DIR-BILL-CSH-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DIR-BILL-CSH-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L1651-PREM-AMT * 100.
020874     MOVE L1651-PREM-AMT        TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DIR-BILL-PREM-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DIR-BILL-PREM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L1651-LOAN-AMT * 100.
020874     MOVE L1651-LOAN-AMT        TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DIR-BILL-LOAN-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DIR-BILL-LOAN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L1651-APL-AMT * 100.
020874     MOVE L1651-APL-AMT         TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DIR-BILL-APL-AMT    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DIR-BILL-APL-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L1651-PDF-AMT * 100.
020874     MOVE L1651-PDF-AMT         TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DIR-BILL-PDF-AMT    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DIR-BILL-PDF-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L1651-DEPOSIT-AMT * 100.
020874     MOVE L1651-DEPOSIT-AMT     TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DIR-BILL-DPOS-AMT   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DIR-BILL-DPOS-AMT.

      *
       1300-SETUP-FROM-TURNAROUND-X.
           EXIT.
      /
       1400-SETUP-FROM-SCREEN.
      *==================

           MOVE MIR-POL-ID-BASE             TO HOLD-POLICY.
           MOVE MIR-POL-ID-SFX              TO HOLD-SUFFIX.
           MOVE MIR-DV-OWN-CLI-NM           TO HOLD-NAME.
           MOVE MIR-DV-PRCES-DT             TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE         TO L1651-EFF-DT.
012137     IF MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L1651-SUPPRESS-CONFIRM   TO TRUE
012137     END-IF.
           PERFORM  1600-BUILD-CARD-FROM-SCREEN
               THRU 1600-BUILD-CARD-FROM-SCREEN-X.

       1400-SETUP-FROM-SCREEN-X.
           EXIT.
      /
       1500-BASIC-EDITS.
      *============
      *
      ******************************************************************
      **                                                              **
      **           B A S I C    E D I T S                             **
      **                                                              **
      **--------------------------------------------------------------**
      **  THIS ROUTINE PERFORM S THE FOLLOWING TASKS:                 **
      **  1. VALIDATES THE EFFECTIVE DATE                             **
      **  2. CHECKS THAT THE POLICY IS ON FILE.                       **
      **  3. CHECKS THAT THE POLICY CAN BE ACCESSED FOR THIS          **
      **     TRANSACTION                                              **
      **  4. CHECKS THAT THE NAME ENTERED IS THE OWNER'S NAME         **
      **  5. READS IN THE COVERAGES                                   **
      **  6. CHECKS THAT THE TRANSACTION TOTAL BALANCES TO ZERO       **
      **  7. VALIDATES TURNAROUND IS VALID FOR THIS POLICY            **
      **  8. VALIDATES THE SUPPRESS CONFIRMATION                      **
021938**  9. VALIDATES POLICY BILLING TYPE AGAINST ENTERED PAYMENT    **
021938**     AMOUNT FOR PAC/CRC/DD2                                   **
      ******************************************************************
      *
008453*  MSG:  EFFECTIVE DATE MUST BE ENTERED IN VALID FORMAT..DDMMMYYYY
008453*  MSG:  EFFECTIVE DATE MUST BE ENTERED IN VALID FORMAT
      *
           IF L1651-EFF-DT = WWKDT-ZERO-DT
               MOVE 'CS00000054'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-OCCURRED TO TRUE
           END-IF.
      *
           MOVE HOLD-POLICY          TO WPOL-POL-ID.
014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.

           EVALUATE MIR-DV-PRCES-STATE-CD
               WHEN '2'
                    PERFORM  POL-1000-READ-TWRK-TS
                        THRU POL-1000-READ-TWRK-TS-X
               WHEN '3'
014221             PERFORM  POL-2000-UPDATE-TWRK-TS
014221                 THRU POL-2000-UPDATE-TWRK-TS-X
014221            IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221                MOVE 'POL'              TO WGLOB-MSG-PARM (01)
014221                MOVE WPOL-KEY           TO WGLOB-MSG-PARM (02)
014221                PERFORM  0260-1000-GENERATE-MESSAGE
014221                    THRU 0260-1000-GENERATE-MESSAGE-X
014221                SET WS-ERROR-OCCURRED      TO TRUE
014221                GO TO 1500-BASIC-EDITS-X
014221            END-IF
014221     END-EVALUATE.

016503     MOVE RPOL-POL-PD-TO-DT-NUM      TO WS-PD-TO-DT.
           IF NOT WPOL-IO-OK
               MOVE 'CS00000019'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-OCCURRED TO TRUE
               GO TO 1500-BASIC-EDITS-X
           END-IF.
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.
      *
           IF  WS-ERROR-NONE
           AND RPOL-POL-CVG-REC-CTR-N > ZERO
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
               IF NOT WCVG-IO-OK
                   MOVE 'CS00000024' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
      *
      *  VERIFY ACCESS TO THE POLICY
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD         TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD     TO TRUE.
016440     SET L5400-POL-XFER-UPDATE       TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  NOT L5400-RETRN-OK
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               SET WS-ACCESS-ERROR-OCCURRED TO TRUE
               GO TO 1500-BASIC-EDITS-X
           END-IF.

012143*
012143* OVERRIDE EFFECTIVE DATE
012143*
012143     IF  L1651-OVRIDE-EFF-DT NOT = WWKDT-ZERO-DT
012143         PERFORM  1505-CHECK-OVERRIDE-APPLY
012143             THRU 1505-CHECK-OVERRIDE-APPLY-X
012143     END-IF.
      *
016108     IF  WS-ERROR-NONE
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108         PERFORM  0985-1000-BUILD-PARM-INFO
016108             THRU 0985-1000-BUILD-PARM-INFO-X
016108
016108         MOVE L1651-EFF-DT            TO L0985-EFF-DT
016108
016108         PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108             THRU 0985-1000-VAL-POL-DT-OF-DTH-X
016108
016108         IF  NOT L0985-RETRN-OK
016108             SET WS-ERROR-OCCURRED    TO TRUE
016108             GO TO 1500-BASIC-EDITS-X
016108         END-IF
016108     END-IF.
016108*
           IF  WS-ERROR-OCCURRED
               GO TO 1500-BASIC-EDITS-X
557660     END-IF.
      *
           IF (L1651-CASH-AMT     NOT = ZERO
014579     OR  L1651-RETCOMM-AMT  NOT = ZERO
016395     OR  L1651-PAC-AMT      NOT = ZERO
020467     OR  L1651-DD2-AMT      NOT = ZERO
016395     OR  L1651-CRC-AMT      NOT = ZERO)
016395*    OR  L1651-PAC-AMT      NOT = ZERO)
           AND WS-NO-DETAILS-ENTERED
               SET L1651-RESOLVE-CASH-ALLOC TO TRUE
               MOVE 'CS06510037'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *
      *
      * CHECK THAT BREAKDOWN BALANCES TO TOTAL (CASH/PAC/LOAN)
      *
      *  SET UP L1651-PRM-SUSP IN CASE 201 HAS DEDUCTED PREMIUM SUSPENSE
      *  FROM RTA-DIR-BILL-CSH-AMT. THIS ALLOWS THE TRANSACTION
      *  ENTRY BALANCE CHECK TO FUNCTION PROPERLY
      *
           IF WS-BUS-FCN-TRNANO
               COMPUTE WS-TST-BALANCE = L1651-PREM-AMT
                                      + L1651-LOAN-AMT
                                      + L1651-APL-AMT
                                      + L1651-PDF-AMT
                                      + L1651-DEPOSIT-AMT
               IF WS-TST-BALANCE  NOT = L1651-CASH-AMT
                   PERFORM  1550-BALANCE-TURNAROUND
                       THRU 1550-BALANCE-TURNAROUND-X
               END-IF
           END-IF.

021938*
021938*  CHECK THAT POLICY IS PAC IF PAC AMOUNT ENTERED
021938*
021938     IF  L1651-PAC-AMT NOT = 0
021938         IF  NOT RPOL-POL-BILL-TYP-PAC
021938*MSG: PAC AMOUNT MUST BE ZERO AS POLICY NOT CODED AS BILLING
021938*     TYPE PAC
021938             MOVE 'CS06510056'      TO WGLOB-MSG-REF-INFO
021938             PERFORM  0260-1000-GENERATE-MESSAGE
021938                 THRU 0260-1000-GENERATE-MESSAGE-X
021938         END-IF
021938     END-IF
021938*
021938*  CHECK THAT POLICY IS DD2 IF DD2 AMOUNT ENTERED
021938*
021938     IF  L1651-DD2-AMT NOT = 0
021938         IF  NOT RPOL-POL-BILL-TYP-DD2
021938*MSG: AUTOPAY AMOUNT MUST BE ZERO AS POLICY NOT CODED AS BILLING
021938*     TYPE AUTOPAY
021938             MOVE 'CS06510057'      TO WGLOB-MSG-REF-INFO
021938             PERFORM  0260-1000-GENERATE-MESSAGE
021938                 THRU 0260-1000-GENERATE-MESSAGE-X
021938         END-IF
021938     END-IF
021938*
021938*  CHECK THAT POLICY IS CRC IF CRC AMOUNT ENTERED
021938*
021938     IF  L1651-CRC-AMT NOT = 0
021938         IF  NOT RPOL-POL-BILL-TYP-CRC
021938*MSG: CREDIT CARD AMOUNT MUST BE ZERO AS POLICY NOT CODED AS
021938*     BILLING TYPE CREDIT CARD
021938             MOVE 'CS06510058'      TO WGLOB-MSG-REF-INFO
021938             PERFORM  0260-1000-GENERATE-MESSAGE
021938                 THRU 0260-1000-GENERATE-MESSAGE-X
021938         END-IF
021938     END-IF.
021938
       1500-BASIC-EDITS-X.
           EXIT.
      /
012143 1505-CHECK-OVERRIDE-APPLY.
012143*==========================
012143
012143* ENSURE AT LEAST ONE OF THE COVERAGES HAS INSURANCE
012143* TYPE F OR N OR D
012143     PERFORM
012143         VARYING I FROM 1 BY 1
012143         UNTIL   I > RPOL-POL-CVG-REC-CTR-N
012143            OR   WCVGS-CVG-INS-TYP-SEG-FUND (I)
012143            OR   WCVGS-CVG-INS-TYP-FPA (I)
012143            OR   WCVGS-CVG-INS-TYP-UL-INS-ANTY (I)
015543         CONTINUE
012143     END-PERFORM.
012143
012143     IF I > RPOL-POL-CVG-REC-CTR-N
012143* SEND INFORMATIONAL MESSAGE
012143* MSG: O/R DATE NOT APPLICABLE TO THIS INSURANCE TYPE
012143*      IT WILL BE IGNORED
012143         MOVE 'CS06510055'            TO WGLOB-MSG-REF-INFO
012143         PERFORM  0260-1000-GENERATE-MESSAGE
012143             THRU 0260-1000-GENERATE-MESSAGE-X
012143         MOVE WWKDT-ZERO-DT           TO L1651-OVRIDE-EFF-DT
012143         MOVE SPACES                  TO MIR-DPOS-OVRID-EFF-DT
012143     END-IF.
012143
012143 1505-CHECK-OVERRIDE-APPLY-X.
012143     EXIT.
012143/
       1550-BALANCE-TURNAROUND.
      *========================
           COMPUTE L1651-PRM-SUSP-AMT =
                           WS-TST-BALANCE - L1651-CASH-AMT.
           IF L1651-PRM-SUSP-AMT > RPOL-POL-PREM-SUSP-AMT
               MOVE ZERO   TO L1651-PRM-SUSP-AMT
           ELSE
               MULTIPLY -1 BY L1651-PRM-SUSP-AMT
           END-IF.

       1550-BALANCE-TURNAROUND-X.
           EXIT.
      /
       1600-BUILD-CARD-FROM-SCREEN.
      *========================
      ******************************************************************
      **                                                              **
      **        B U I L D    C A R D    F R O M   S C R E E N         **
      **                                                              **
      **--------------------------------------------------------------**
      **  THIS ROUTINE PERFORMS THE FOLLOWING TASKS:                  **
      **  1. FOR EACH DOLLAR FIELD ENTERED                            **
      **     1.1  ALIGN THE INPUT                                     **
      **     1.2  EDIT THAT VALID NUMBERIC ENTERED                    **
      **     1.3  IF VALID, SET UP MATCHING FIELD ON PPAY EDIT CARD   **
      **  2. CHECK AND SET OTHER NUMERIC FIELDS                       **
      **  3. CHECK AND SET ALPHA FIELDS                               **
      ******************************************************************
      *
           MOVE 'N'                         TO L0280-SIGN-IND.
           MOVE 2                           TO L0280-PRECISION.
      *
      * CASH
      *
           IF MIR-DV-ENTR-CSH-AMT > SPACES
               MOVE MIR-DV-ENTR-CSH-AMT             TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-DV-ENTR-CSH-AMT   TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR TO L1651-CASH-AMT
               ELSE
                   SET  NUM-ERR-OCCURRED    TO TRUE
               END-IF
           END-IF.
      *
      * PAC AMOUNT
      *
           IF MIR-PAC-DRW-TOT-AMT > SPACES
               MOVE MIR-PAC-DRW-TOT-AMT             TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-PAC-DRW-TOT-AMT   TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR TO L1651-PAC-AMT
               ELSE
                   SET  NUM-ERR-OCCURRED    TO TRUE
               END-IF
           END-IF.
020467*
020467* AUTOPAY AMOUNT
020467*
020467     IF MIR-DV-DD2-DRW-TOT-AMT > SPACES
020467         MOVE MIR-DV-DD2-DRW-TOT-AMT           TO L0280-INPUT-DATA
020467         MOVE LENGTH OF MIR-DV-DD2-DRW-TOT-AMT TO L0280-INPUT-SIZE
020467         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
020467                                L0280-PRECISION - 1
020467         PERFORM  0280-1000-NUMERIC-EDIT
020467             THRU 0280-1000-NUMERIC-EDIT-X
020467         IF L0280-OK
020467             MOVE L0280-OUTPUT-DOLLAR TO L1651-DD2-AMT
020467         ELSE
020467             SET  NUM-ERR-OCCURRED    TO TRUE
020467         END-IF
020467     END-IF.
016395*
016395* CRC AMOUNT
016395*
016395     IF  MIR-CRC-TRXN-AMT > SPACES
016395         MOVE  MIR-CRC-TRXN-AMT             TO L0280-INPUT-DATA
016395         MOVE LENGTH OF MIR-CRC-TRXN-AMT    TO L0280-INPUT-SIZE
016395         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
016395                                L0280-PRECISION - 1
016395         PERFORM  0280-1000-NUMERIC-EDIT
016395             THRU 0280-1000-NUMERIC-EDIT-X
016395         IF  L0280-OK
016395             MOVE L0280-OUTPUT-DOLLAR       TO L1651-CRC-AMT
016395         ELSE
016395             SET NUM-ERR-OCCURRED           TO TRUE
016395         END-IF
016395     END-IF.

021938     EVALUATE TRUE
021938         WHEN L1651-CRC-AMT > 0
021938             SET L1651-DEPOSIT-RSN-CRC TO TRUE
021938
021938         WHEN L1651-DD2-AMT > 0
021938             SET L1651-DEPOSIT-RSN-DD2 TO TRUE
021938
021938         WHEN L1651-PAC-AMT > 0
021938             SET L1651-DEPOSIT-RSN-PAC TO TRUE
021938     END-EVALUATE.
014579*
014579* RETAIN COMMISSIONS AMOUNT
014579*
014579
014579     IF  MIR-DV-POL-RCOMM-AMT > SPACES
014579         MOVE MIR-DV-POL-RCOMM-AMT           TO L0280-INPUT-DATA
014579         MOVE LENGTH OF MIR-DV-POL-RCOMM-AMT TO L0280-INPUT-SIZE
014579         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
014579                                L0280-PRECISION - 1
014579         PERFORM  0280-1000-NUMERIC-EDIT
014579             THRU 0280-1000-NUMERIC-EDIT-X
014579         IF  L0280-OK
014579             MOVE L0280-OUTPUT-DOLLAR       TO L1651-RETCOMM-AMT
014579         ELSE
014579             SET NUM-ERR-OCCURRED            TO TRUE
014579         END-IF
014579         MOVE L0280-STATUS             TO L1651-RETCOMM-ENTRY-SW
014579     END-IF.

012143*
012143* OVERRIDE EFFECTIVE DATE
012143*
012143     IF MIR-DPOS-OVRID-EFF-DT > SPACES
012143         PERFORM  1605-EDIT-OVERRIDE-DATE
012143             THRU 1605-EDIT-OVERRIDE-DATE-X
012143     ELSE
012143         MOVE WWKDT-ZERO-DT           TO L1651-OVRIDE-EFF-DT
012143     END-IF.
      /
      * PREMIUM
      *
           IF MIR-DIR-BILL-PREM-AMT > SPACES
               PERFORM  1610-EDIT-PREM
                   THRU 1610-EDIT-PREM-X
           END-IF.
      *
      * LOAN REPAYMENT
      *
           IF MIR-DIR-BILL-LOAN-AMT > SPACES
               PERFORM  1620-EDIT-LOAN
                   THRU 1620-EDIT-LOAN-X
           END-IF.
      *
      * APL REPAYMENT
      *
           IF MIR-DIR-BILL-APL-AMT > SPACES
               PERFORM  1630-EDIT-APL
                   THRU 1630-EDIT-APL-X
           END-IF.
      * PDF PAYMENT
      *
           IF MIR-DIR-BILL-PDF-AMT > SPACES
               PERFORM  1640-EDIT-PDF
                   THRU 1640-EDIT-PDF-X
           END-IF.
      *
      * DEPOSITS
      *
           IF MIR-DIR-BILL-DPOS-AMT > SPACES
               PERFORM  1650-EDIT-DEP
                   THRU 1650-EDIT-DEP-X
           END-IF.
014579*
014579*RETAINED COMMISSION
014579*
014579*    IF MIR-DV-POL-RCOMM-AMT > SPACES
014579*        PERFORM  1675-EDIT-RETCOMM
014579*            THRU 1675-EDIT-RETCOMM-X
014579*    END-IF.
      *
      * AMOUNTS FROM ENTRY LINES
      *
015904*    IF MIR-DV-DB-ACCT-TRXN-AMT-T (01) > SPACES
015904     IF MIR-DV-TRNXT-DR-AMT-T (01) > SPACES
015904*        MOVE MIR-DV-DB-ACCT-TRXN-AMT-T (01)  TO L0280-INPUT-DATA
015904         MOVE MIR-DV-TRNXT-DR-AMT-T (01)  TO L0280-INPUT-DATA
015904*        MOVE LENGTH OF MIR-DV-DB-ACCT-TRXN-AMT-T (01)
015904         MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (01)
                                                    TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR TO HOLD-DR1
014035             PERFORM  1601-HOLD-DR1-CHECK
014035                 THRU 1601-HOLD-DR1-CHECK-X
               ELSE
                   SET  NUM-ERR-OCCURRED    TO TRUE
557660         END-IF
557660     END-IF.
      *
015904*    IF MIR-DV-CR-ACCT-TRXN-AMT-T (01) > SPACES
015904     IF MIR-DV-TRNXT-CR-AMT-T (01) > SPACES
015904*        MOVE MIR-DV-CR-ACCT-TRXN-AMT-T (01)  TO L0280-INPUT-DATA
015904         MOVE MIR-DV-TRNXT-CR-AMT-T (01)  TO L0280-INPUT-DATA
015904*        MOVE LENGTH OF MIR-DV-CR-ACCT-TRXN-AMT-T (01)
015904         MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (01)
                                                    TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR TO HOLD-CR1
014035             PERFORM  1602-HOLD-CR1-CHECK
014035                 THRU 1602-HOLD-CR1-CHECK-X
               ELSE
                   SET  NUM-ERR-OCCURRED    TO TRUE
557660         END-IF
557660     END-IF.
      *
015904*    IF MIR-DV-DB-ACCT-TRXN-AMT-T (02) > SPACES
015904     IF MIR-DV-TRNXT-DR-AMT-T (02) > SPACES
015904*        MOVE MIR-DV-DB-ACCT-TRXN-AMT-T (02)  TO L0280-INPUT-DATA
015904         MOVE MIR-DV-TRNXT-DR-AMT-T (02)  TO L0280-INPUT-DATA
015904*        MOVE LENGTH OF MIR-DV-DB-ACCT-TRXN-AMT-T (02)
015904         MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (02)
                                                    TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR TO HOLD-DR2
014035             PERFORM  1603-HOLD-DR2-CHECK
014035                 THRU 1603-HOLD-DR2-CHECK-X
               ELSE
                   SET  NUM-ERR-OCCURRED    TO TRUE
557660         END-IF
557660     END-IF.
      *
015904*    IF MIR-DV-CR-ACCT-TRXN-AMT-T (02) > SPACES
015904     IF MIR-DV-TRNXT-CR-AMT-T (02) > SPACES
015904*        MOVE MIR-DV-CR-ACCT-TRXN-AMT-T (02)  TO L0280-INPUT-DATA
015904         MOVE MIR-DV-TRNXT-CR-AMT-T (02)  TO L0280-INPUT-DATA
015904*        MOVE LENGTH OF MIR-DV-CR-ACCT-TRXN-AMT-T (02)
015904         MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (02)
                                                    TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR TO HOLD-CR2
014035             PERFORM  1604-HOLD-CR2-CHECK
014035                 THRU 1604-HOLD-CR2-CHECK-X
               ELSE
                   SET  NUM-ERR-OCCURRED    TO TRUE
557660         END-IF
557660     END-IF.
      *
           IF  HOLD-DR1 NOT = ZERO
           AND HOLD-CR1 NOT = ZERO
      *        MSG: BOTH DEBIT AND CREDIT ENTERED ON ENTRY LINE @1
               MOVE 'CS06510012'  TO WGLOB-MSG-REF-INFO
               MOVE '1'           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-OCCURRED TO TRUE
           END-IF.
      *
           IF  HOLD-DR2 NOT = ZERO
           AND HOLD-CR2 NOT = ZERO
      *        MSG: BOTH DEBIT AND CREDIT ENTERED ON ENTRY LINE @1
               MOVE 'CS06510012'  TO WGLOB-MSG-REF-INFO
               MOVE '2'           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-OCCURRED TO TRUE
           END-IF.
      *
           IF WS-ERROR-NONE
               PERFORM  1710-SETUP-ENTRY-AMTS
                   THRU 1710-SETUP-ENTRY-AMTS-X
           END-IF.
      *
      *
           MOVE 'Y'               TO L0280-SIGN-IND.
           MOVE 2                 TO L0280-PRECISION.
      *
      * PREMIUM SUSPENSE
      *
           IF MIR-POL-PREM-SUSP-AMT > SPACES
               PERFORM  1660-EDIT-PRMSUSP
                   THRU 1660-EDIT-PRMSUSP-X
           END-IF.
      *
      * SUSPENSE
      *
           IF MIR-POL-MISC-SUSP-AMT > SPACES
               PERFORM  1670-EDIT-SUSP
                   THRU 1670-EDIT-SUSP-X
           END-IF.
      *
      * PDF SUSPENSE
      *
           IF MIR-POL-PDF-SUSP-AMT > SPACES
               PERFORM  1680-EDIT-PDFSUSP
                   THRU 1680-EDIT-PDFSUSP-X
           END-IF.
      *
      * O/S DISBURSEMENTS
      *
           IF MIR-POL-OS-DISB-AMT > SPACES
               PERFORM  1690-EDIT-OSDISB
                   THRU 1690-EDIT-OSDISB-X
           END-IF.
018846*
018846* SIDE FUND AMOUNT
018846*
018846     IF  MIR-DV-POL-SIDFND-DPOS-AMT > SPACES
018846         PERFORM  1685-EDIT-SIDFND-AMT
018846             THRU 1685-EDIT-SIDFND-AMT-X
018846     END-IF.
      *
      * OTHER NUMERIC: PREMIUM AND DEPOSIT CF SEQUENCE NUMBERS
      *
           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE 3                 TO L0280-LENGTH.
           MOVE 0                 TO L0280-PRECISION.

           IF MIR-DV-CF-PREM-SEQ-NUM > SPACES
               MOVE MIR-DV-CF-PREM-SEQ-NUM  TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE MIR-DV-CF-PREM-SEQ-NUM TO L1651-PREM-DEPSQ
               ELSE
                   SET  NUM-ERR-OCCURRED    TO TRUE
               END-IF
           END-IF.
      *
           IF MIR-DV-CF-DEP-SEQ-NUM > SPACES
               MOVE MIR-DV-CF-DEP-SEQ-NUM TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE MIR-DV-CF-DEP-SEQ-NUM TO L1651-DEP-DEPSQ
               ELSE
                   SET  NUM-ERR-OCCURRED    TO TRUE
               END-IF
           END-IF.
557691*
557691     IF MIR-CF-TAX-YR > SPACES
557691        MOVE 'N'               TO L0280-SIGN-IND
557691        MOVE 4                 TO L0280-LENGTH
557691        MOVE 0                 TO L0280-PRECISION
557691        MOVE MIR-CF-TAX-YR          TO WS-TAX-YEAR
557691        MOVE WS-TAX-YEAR       TO L0280-INPUT-DATA
557691        PERFORM  0280-1000-NUMERIC-EDIT
557691            THRU 0280-1000-NUMERIC-EDIT-X
010311        IF L0280-OK
010311        AND MIR-CF-TAX-YR >= '0000'
557691           MOVE MIR-CF-TAX-YR       TO L1651-TAX-YR
557691        ELSE
557691           SET WS-TXYR-ERR-OCCURRED TO TRUE
557691        END-IF
557691     END-IF.
      *
025388*    IF  MIR-CF-REG-FND-SRC-CD = '*'
025388*        MOVE SPACES TO MIR-CF-REG-FND-SRC-CD
025388*    END-IF.
           MOVE MIR-CF-REG-FND-SRC-CD      TO L1651-FND-SRC-CD.

           IF  RPOL-POL-LOCKED-IN-FUNDS
           AND MIR-CF-REG-FND-SRC-CD NOT  =  'P'
               MOVE 'P'                 TO MIR-CF-REG-FND-SRC-CD
      *        MSG: POLICY HAS LOCKED-IN FUNDS.  FND SRC CHANGED TO "P".
               MOVE 'CS06510029'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

016395*
016395* CHECK FOR THE CREDIT CARD/PAC/CASH REVERSE INFORMATION
016395*

016395     IF  WS-BUS-FCN-REVERSAL
016395         EVALUATE TRUE
016395           WHEN  L1651-CRC-AMT NOT = ZEROS
016395                 PERFORM  1692-CHECK-CRC-REV-CD
016395                     THRU 1692-CHECK-CRC-REV-CD-X
016395           WHEN  L1651-PAC-AMT NOT = ZEROS
020467           WHEN  L1651-DD2-AMT NOT = ZEROS
016395           WHEN  L1651-CASH-AMT NOT = ZEROS
016395                 PERFORM  1693-CHECK-REV-CD
016395                    THRU  1693-CHECK-REV-CD-X
016395           WHEN  OTHER
016395                 PERFORM  1691-CHECK-BOTH-REV-CD
016395                     THRU 1691-CHECK-BOTH-REV-CD-X
016395         END-EVALUATE
023662*    ELSE
023662*        PERFORM  1691-CHECK-BOTH-REV-CD
023662*            THRU 1691-CHECK-BOTH-REV-CD-X
016395     END-IF.

      *
      * APLHA FIELDS : REASON CODE, ENTRY LINE FIELDS
      *
012147     MOVE MIR-AGT-ID          TO L1651-AGTNUM.
016395     EVALUATE TRUE
016395         WHEN  L1651-CRC-AMT NOT = ZEROS
016395              MOVE MIR-CRC-TRXN-REVRS-CD TO L1651-REVRS-REASN-CD
016395         WHEN OTHER
016395              MOVE MIR-DV-REVRS-REASN-CD TO L1651-REVRS-REASN-CD
016395     END-EVALUATE.

018525*    SETUP DEFAULT REASON CODE IF IT IS REVERSING MODE PREM
018525*    TO PREMIMUM OR O/S DISBURSEMENT
018525
018525     IF  WS-BUS-FCN-REVERSAL
018525     AND (L1651-REVRS-REASN-CD = SPACE)
027435*    AND (L1651-CRC-AMT = ZERO)
027435*    AND (L1651-PAC-AMT = ZERO)
027435*    AND (L1651-DD2-AMT = ZERO)
027435*    AND (L1651-CASH-AMT = ZERO)
027435*    AND (L1651-LOAN-AMT = ZERO)
027435*    AND (L1651-APL-AMT = ZERO)
027435*    AND (L1651-PDF-AMT = ZERO)
027435*    AND (L1651-DEPOSIT-AMT = ZERO)
027435*    AND (L1651-PDF-SUSP-AMT = ZERO)
027435*    AND ((L1651-PREM-AMT * -1) =
027435*         (L1651-PRM-SUSP-AMT + L1651-OS-DISB-AMT +
027435*          L1651-SUSP-AMT))
018525         SET L1651-REVRS-REASN-OTHER     TO TRUE
018525     END-IF.
018525

016395*    MOVE MIR-DV-REVRS-REASN-CD          TO L1651-REVRS-REASN-CD.
           MOVE WGLOB-PROCESS-DATE  TO WS-DATE.
      *
           MOVE MIR-ACCT-BASE-ID-T (01) TO L1651-ELNR-ACCT-ID-BASE (1).
557658     MOVE WS-DATE-YR          TO L1651-ELNR-ACCT-YR-CD (1).
017484     IF  MIR-SBSDRY-CO-ID-T (01) = EBLCH-BLANK-FIELD-CHAR
017484         MOVE SPACES          TO MIR-SBSDRY-CO-ID-T (01)
017484     END-IF.
010418     MOVE MIR-SBSDRY-CO-ID-T (01)
010418                              TO L1651-ELNR-ACCT-SBSDRY-CO-ID (1).
           MOVE WGLOB-CURRENCY-CODE TO L1651-ELNR-ACCT-CRCY-CD (1).
017484     IF  MIR-BR-OR-DEPT-ID-T (01) = EBLCH-BLANK-FIELD-CHAR
017484         MOVE SPACES          TO MIR-BR-OR-DEPT-ID-T (01)
017484     END-IF.
           MOVE MIR-BR-OR-DEPT-ID-T (01)
                                    TO L1651-ELNR-BR-OR-DEPT-ID (1).
           MOVE SPACES              TO L1651-ELNR-ACCT-PLAN-ID (1).
017484     IF  MIR-ACCT-ISS-LOC-CD-T (01) = EBLCH-BLANK-FIELD-CHAR
017484         MOVE SPACES          TO MIR-ACCT-ISS-LOC-CD-T (01)
017484     END-IF.
           MOVE MIR-ACCT-ISS-LOC-CD-T (01)
                                    TO L1651-ELNR-ACCT-ISS-LOC-CD (1).
017484     IF  MIR-ACCT-CRNT-LOC-CD-T (01) = EBLCH-BLANK-FIELD-CHAR
017484         MOVE SPACES          TO MIR-ACCT-CRNT-LOC-CD-T (01)
017484     END-IF.
           MOVE MIR-ACCT-CRNT-LOC-CD-T (01)
                                    TO L1651-ELNR-ACCT-CRNT-LOC-CD (1).
           MOVE MIR-AGT-ID-T (01)   TO L1651-ELNR-AGT-ID  (1).
018763     IF  MIR-COMM-TRXN-REASN-CD-T (01) = EBLCH-BLANK-FIELD-CHAR
018763         MOVE SPACES          TO MIR-COMM-TRXN-REASN-CD-T (01)
017484     END-IF.
016457*    MOVE MIR-DV-AGT-REASN-CD-T (01)
016457     MOVE MIR-COMM-TRXN-REASN-CD-T (01)
                                    TO L1651-ELNR-REASN-CD (1).
016457*    MOVE MIR-DV-ACCT-DESC-TXT-T (01)
016457     MOVE MIR-ACCT-DESC-TXT-T (01)
                                    TO L1651-ELNR-DESC-TXT (1).
      *
           MOVE MIR-ACCT-BASE-ID-T (02)
                                    TO L1651-ELNR-ACCT-ID-BASE (2).
557658     MOVE WS-DATE-YR          TO L1651-ELNR-ACCT-YR-CD (2).
017484     IF  MIR-SBSDRY-CO-ID-T (02) = EBLCH-BLANK-FIELD-CHAR
017484         MOVE SPACES          TO MIR-SBSDRY-CO-ID-T (02)
017484     END-IF.
010418     MOVE MIR-SBSDRY-CO-ID-T (02)
010418                              TO L1651-ELNR-ACCT-SBSDRY-CO-ID (2).
           MOVE WGLOB-CURRENCY-CODE TO L1651-ELNR-ACCT-CRCY-CD (2).
017484     IF  MIR-BR-OR-DEPT-ID-T (02) = EBLCH-BLANK-FIELD-CHAR
017484         MOVE SPACES          TO MIR-BR-OR-DEPT-ID-T (02)
017484     END-IF.
           MOVE MIR-BR-OR-DEPT-ID-T (02)
                                    TO L1651-ELNR-BR-OR-DEPT-ID (2).
           MOVE SPACES              TO L1651-ELNR-ACCT-PLAN-ID  (2).
017484     IF  MIR-ACCT-ISS-LOC-CD-T (02) = EBLCH-BLANK-FIELD-CHAR
017484         MOVE SPACES          TO MIR-ACCT-ISS-LOC-CD-T (02)
017484     END-IF.
           MOVE MIR-ACCT-ISS-LOC-CD-T (02)
                                    TO L1651-ELNR-ACCT-ISS-LOC-CD (2).
017484     IF  MIR-ACCT-CRNT-LOC-CD-T (02) = EBLCH-BLANK-FIELD-CHAR
017484         MOVE SPACES          TO MIR-ACCT-CRNT-LOC-CD-T (02)
017484     END-IF.
           MOVE MIR-ACCT-CRNT-LOC-CD-T (02)
                                    TO L1651-ELNR-ACCT-CRNT-LOC-CD (2).
018763     IF  MIR-COMM-TRXN-REASN-CD-T (02) = EBLCH-BLANK-FIELD-CHAR
018763         MOVE SPACES          TO MIR-COMM-TRXN-REASN-CD-T (02)
017484     END-IF.
           MOVE MIR-AGT-ID-T (02)   TO L1651-ELNR-AGT-ID  (2).
016457*    MOVE MIR-DV-AGT-REASN-CD-T (02)
016457     MOVE MIR-COMM-TRXN-REASN-CD-T (02)
                                    TO L1651-ELNR-REASN-CD (2).
016457*    MOVE MIR-DV-ACCT-DESC-TXT-T (02)
016457     MOVE MIR-ACCT-DESC-TXT-T (02)
                                    TO L1651-ELNR-DESC-TXT (2).
      *
       1600-BUILD-CARD-FROM-SCREEN-X.
           EXIT.
      /
014035 1601-HOLD-DR1-CHECK.
014035*====================
014035
014035     IF HOLD-DR1 NOT = ZERO
014035         SET WS-DETAILS-ENTERED TO TRUE
034802*    ELSE
034802*        NEXT SENTENCE
014035     END-IF.
014035
014035 1601-HOLD-DR1-CHECK-X.
014035     EXIT.
014035*
014035 1602-HOLD-CR1-CHECK.
014035*====================
014035
014035     IF HOLD-CR1 NOT = ZERO
014035         SET WS-DETAILS-ENTERED TO TRUE
034802*    ELSE
034802*        NEXT SENTENCE
014035     END-IF.
014035
014035 1602-HOLD-CR1-CHECK-X.
014035     EXIT.
014035*
014035 1603-HOLD-DR2-CHECK.
014035*====================
014035
014035     IF HOLD-DR2 NOT = ZERO
014035         SET WS-DETAILS-ENTERED TO TRUE
034802*    ELSE
034802*        NEXT SENTENCE
014035     END-IF.
014035
014035 1603-HOLD-DR2-CHECK-X.
014035     EXIT.
014035*
014035 1604-HOLD-CR2-CHECK.
014035*====================
014035
014035     IF HOLD-CR2 NOT = ZERO
014035         SET WS-DETAILS-ENTERED TO TRUE
034802*    ELSE
014035*        NEXT SENTENCE
014035     END-IF.
014035
014035 1604-HOLD-CR2-CHECK-X.
014035     EXIT.
014035/
012143 1605-EDIT-OVERRIDE-DATE.
012143*========================
012143
012143     MOVE MIR-DPOS-OVRID-EFF-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
012143     IF L1640-NOT-VALID
012143* MSG: INVALID OVERRIDE EFFECTIVE DATE
012143         MOVE 'CS06510053'            TO WGLOB-MSG-REF-INFO
012143         PERFORM  0260-1000-GENERATE-MESSAGE
012143             THRU 0260-1000-GENERATE-MESSAGE-X
012143         SET WS-ERROR-OCCURRED        TO TRUE
012143         GO TO 1605-EDIT-OVERRIDE-DATE-X
012143     ELSE
012143* MESSAGE WILL HAVE SEVERITY W OR F DEPENDING ON USER SECURITY
012143         MOVE 'CS06510054'            TO WGLOB-MSG-REF-INFO
012143         PERFORM  0260-1000-GENERATE-MESSAGE
012143             THRU 0260-1000-GENERATE-MESSAGE-X
012143         IF WGLOB-MSG-SEVRTY-FATAL
012143             SET WS-ERROR-OCCURRED    TO TRUE
012143             GO TO 1605-EDIT-OVERRIDE-DATE-X
012143         ELSE
012143             MOVE L1640-INTERNAL-DATE TO L1651-OVRIDE-EFF-DT
012143         END-IF
012143     END-IF.
012143
012143 1605-EDIT-OVERRIDE-DATE-X.
012143     EXIT.
012143/
       1610-EDIT-PREM.
      *=============
           MOVE MIR-DIR-BILL-PREM-AMT              TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-DIR-BILL-PREM-AMT    TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO L1651-PREM-AMT
               IF L1651-PREM-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
               END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.

       1610-EDIT-PREM-X.
           EXIT.
      /
       1620-EDIT-LOAN.
      *=============
           MOVE MIR-DIR-BILL-LOAN-AMT              TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-DIR-BILL-LOAN-AMT    TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO L1651-LOAN-AMT
               IF L1651-LOAN-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.

       1620-EDIT-LOAN-X.
           EXIT.
      /
       1630-EDIT-APL.
      *=============
           MOVE MIR-DIR-BILL-APL-AMT               TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-DIR-BILL-APL-AMT     TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
                MOVE L0280-OUTPUT-DOLLAR   TO L1651-APL-AMT
                IF L1651-APL-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
034802*         ELSE
034802*            NEXT SENTENCE
                END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.
      *
       1630-EDIT-APL-X.
           EXIT.
      /
       1640-EDIT-PDF.
      *=============
           MOVE MIR-DIR-BILL-PDF-AMT              TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-DIR-BILL-PDF-AMT    TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO L1651-PDF-AMT
               IF L1651-PDF-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.

       1640-EDIT-PDF-X.
           EXIT.
      /
       1650-EDIT-DEP.
      *=============
           MOVE MIR-DIR-BILL-DPOS-AMT              TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-DIR-BILL-DPOS-AMT    TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO L1651-DEPOSIT-AMT
               IF L1651-DEPOSIT-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.

       1650-EDIT-DEP-X.
           EXIT.
      /
       1660-EDIT-PRMSUSP.
      *=============
           MOVE MIR-POL-PREM-SUSP-AMT              TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT    TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 2.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO L1651-PRM-SUSP-AMT
               IF L1651-PRM-SUSP-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.

       1660-EDIT-PRMSUSP-X.
           EXIT.
      /
       1670-EDIT-SUSP.
      *=============
           MOVE MIR-POL-MISC-SUSP-AMT              TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT    TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 2.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO L1651-SUSP-AMT
               IF L1651-SUSP-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.

       1670-EDIT-SUSP-X.
           EXIT.
      /
014579*1675-EDIT-RETCOMM.
014579*==================
014579*
014579*    MOVE MIR-DV-POL-RCOMM-AMT               TO L0280-INPUT-DATA.
014579*    MOVE LENGTH OF MIR-DV-POL-RCOMM-AMT     TO L0280-INPUT-SIZE.
014579*    COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
014579*                           L0280-PRECISION - 1.
014579*
014579*    PERFORM  0280-1000-NUMERIC-EDIT
014579*        THRU 0280-1000-NUMERIC-EDIT-X.
014579*
014579*    IF L0280-OK
014579*        MOVE L0280-OUTPUT-DOLLAR   TO L1651-RETCOMM-AMT
014579*        IF L1651-RETCOMM-AMT NOT = ZERO
014579*            SET WS-DETAILS-ENTERED TO TRUE
014579*        ELSE
014579*            NEXT SENTENCE
014579*        END-IF
014579*    ELSE
014579*        SET NUM-ERR-OCCURRED       TO TRUE
014579*    END-IF.
014579*
014579*    MOVE L0280-STATUS             TO L1651-RETCOMM-ENTRY-SW.
014579*
014579*1675-EDIT-RETCOMM-X.
014579*    EXIT.
014579*
       1680-EDIT-PDFSUSP.
      *=============
           MOVE MIR-POL-PDF-SUSP-AMT               TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT    TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 2.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO L1651-PDF-SUSP-AMT
               IF L1651-PDF-SUSP-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.

       1680-EDIT-PDFSUSP-X.
           EXIT.
      /
018846*---------------------------
018846 1685-EDIT-SIDFND-AMT.
018846*---------------------------
018846
018846     MOVE MIR-DV-POL-SIDFND-DPOS-AMT         TO L0280-INPUT-DATA.
018846     MOVE LENGTH OF MIR-DV-POL-SIDFND-DPOS-AMT
018846       TO L0280-INPUT-SIZE.
018846     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
018846                            L0280-PRECISION - 2.
018846     PERFORM  0280-1000-NUMERIC-EDIT
018846         THRU 0280-1000-NUMERIC-EDIT-X.
018846     IF L0280-OK
018846         MOVE L0280-OUTPUT-DOLLAR   TO L1651-SIDFND-AMT
018846         IF L1651-SIDFND-AMT NOT = ZERO
018846             SET WS-DETAILS-ENTERED TO TRUE
034802*        ELSE
034802*            NEXT SENTENCE
018846         END-IF
018846     ELSE
018846         SET  NUM-ERR-OCCURRED      TO TRUE
018846     END-IF.
018846
018846 1685-EDIT-SIDFND-AMT-X.
018846     EXIT.
018846
       1690-EDIT-OSDISB.
      *=============
           MOVE MIR-POL-OS-DISB-AMT                TO L0280-INPUT-DATA.
008455     MOVE LENGTH OF MIR-POL-OS-DISB-AMT      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                            L0280-PRECISION - 2.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO L1651-OS-DISB-AMT
               IF L1651-OS-DISB-AMT NOT = ZERO
                   SET WS-DETAILS-ENTERED TO TRUE
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               SET  NUM-ERR-OCCURRED      TO TRUE
           END-IF.

       1690-EDIT-OSDISB-X.
           EXIT.
      /
016395*-----------------------
016395 1691-CHECK-BOTH-REV-CD.
016395*-----------------------
016395
018525     PERFORM  1695-EDIT-RSN-CD-EBLCH
018525         THRU 1695-EDIT-RSN-CD-EBLCH-X.
018525
016395     IF (MIR-CRC-TRXN-REVRS-CD NOT = SPACES
016395     OR  MIR-DV-REVRS-REASN-CD NOT = SPACES)
016395*MSG: REVERSE REASON CODE SHOULD NOT BE ENTERED
016395         MOVE 'CS06510006'            TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395         SET WS-REVRS-CD-ERR-OCCURRED TO TRUE
016395     END-IF.
016395
027435*    SET L1651-ORIGIN-XFER-OUT   TO TRUE.
023662
016395 1691-CHECK-BOTH-REV-CD-X.
016395     EXIT.
016395/
016395*----------------------
016395 1692-CHECK-CRC-REV-CD.
016395*----------------------
016395
016395     PERFORM  1695-EDIT-RSN-CD-EBLCH
016395         THRU 1695-EDIT-RSN-CD-EBLCH-X.
016395
016395     IF  MIR-CRC-TRXN-REVRS-CD = SPACES
016395*MSG: CREDIT CARD REVERSE REASON CODE IS REQUIRED FOR
016395*     CREDIT CARD PAYMENT REVERSAL
016395         MOVE 'CS06510007'                TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395         SET WS-REVRS-CD-ERR-OCCURRED     TO TRUE
016395     ELSE
016395         IF  MIR-DV-REVRS-REASN-CD NOT = SPACES
016395*MSG: REVERSE REASON CODE CANNOT BE ENTERED FOR CREDIT CARD
016395*     REVERSAL
016395             MOVE 'CS06510008'            TO WGLOB-MSG-REF-INFO
016395             PERFORM  0260-1000-GENERATE-MESSAGE
016395                 THRU 0260-1000-GENERATE-MESSAGE-X
016395             SET WS-REVRS-CD-ERR-OCCURRED TO TRUE
016395         END-IF
016395     END-IF.
016395
016395 1692-CHECK-CRC-REV-CD-X.
016395     EXIT.
016395/
016395*------------------
016395 1693-CHECK-REV-CD.
016395*------------------
016395
016395     PERFORM  1695-EDIT-RSN-CD-EBLCH
016395         THRU 1695-EDIT-RSN-CD-EBLCH-X.
016395
016395     IF  MIR-DV-REVRS-REASN-CD = SPACES
016395*MSG: REVERSE REASON CODE IS REQUIRED FOR PAC/CASH PAYMENT
016395*     REVERSAL
016395         MOVE 'CS06510009'            TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395         SET WS-REVRS-CD-ERR-OCCURRED TO TRUE
016395     ELSE
016395         IF  MIR-CRC-TRXN-REVRS-CD NOT = SPACES
016395*MSG: CREDIT CARD REVERSE REASON CODE CANNOT BE ENTERED FOR
016395*     PAC/CASH PAYMENT REVERSAL
016395             MOVE 'CS06510010'        TO WGLOB-MSG-REF-INFO
016395             PERFORM  0260-1000-GENERATE-MESSAGE
016395                 THRU 0260-1000-GENERATE-MESSAGE-X
016395         SET WS-REVRS-CD-ERR-OCCURRED TO TRUE
016395         END-IF
016395     END-IF.
016395
016395 1693-CHECK-REV-CD-X.
016395     EXIT.
016395/
016395*------------------------
016395 1695-EDIT-RSN-CD-EBLCH.
016395*------------------------
016395
016395     IF MIR-CRC-TRXN-REVRS-CD = EBLCH-BLANK-FIELD-CHAR
016395         MOVE SPACES            TO MIR-CRC-TRXN-REVRS-CD
016395     END-IF.
016395
016395     IF MIR-DV-REVRS-REASN-CD = EBLCH-BLANK-FIELD-CHAR
016395         MOVE SPACES            TO MIR-DV-REVRS-REASN-CD
016395     END-IF.
016395
016395 1695-EDIT-RSN-CD-EBLCH-X.
016395     EXIT.
016395/
       1700-PROCESS-PPAY.
      *=============
      *
      ******************************************************************
      **                                                              **
      **              P R O C E S S    P P A Y                        **
      **                                                              **
      **--------------------------------------------------------------**
      **  THIS ROUTINE PERFORMS THE FOLLOWING TASKS:                  **
      **  1. BUILD THE GENERAL PARAMETER AREA                         **
      **  2. BUILD THE ACCOUNTING SPECIFIC PARAMETER COMMON AREA      **
      **  3. INITIALIZE THE WRITE-OPER-DISPLAY VARIABLES              **
      **  4. DO CV CALCS IF LOAN AMOUNTS WILL BE PROCESSED (FOR TAX)  **
      **  5. PROCESS PAYMENT OR REVERSAL FOR PRESET FIELDS            **
      **  6. UPDATE POLICY STATUS CODE IF APPROPRIATE                 **
      **  7. INITIALIZE THE WRITE-OPER-DISPLAY VARIABLES              **
      **  8. UPDATE THE POLICY AND COVERAGE RECORDS IF REQUIRED       **
      **  9. UPDATE THE TERMINAL BATCH TOTALS IF REQUIRED             **
      ** 10. CREATE DALG RECORDS IF CASH, PAC/CRC AMOUNT ENTERED      **
      ** 11. FINALIZE THE OUTPUT MAP                                  **
      ******************************************************************
      *
016503* INVOKE REDO PROCESSING IF REQUIRED.

016503     SET WS-REDO-OK                  TO TRUE.
025715*    PERFORM  1720-INVOKE-REDO
025715*        THRU 1720-INVOKE-REDO-X.
025715     IF  NOT WS-BUS-FCN-REVERSAL
025715         PERFORM  1720-INVOKE-REDO
025715            THRU 1720-INVOKE-REDO-X
025715     END-IF.
016503     IF  WS-REDO-NOT-OK
016503         GO TO 1700-PROCESS-PPAY-X
016503     END-IF.

      *  UNLOCK POLICY RECORD (THIS ALLOWS FOR POLICY UPDATES
      *  IN CSLS0065 WHICH CAN BE CALLED FROM UNDO PROCESSING
      *  IN CSLF1651)
      *
           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.
      *
           SET L1651-PRCES-TYP-ALL  TO TRUE.
018971*    SET L1651-BALANCE-BYPASS TO TRUE.
016503     SET L1651-REDO-WARNING   TO TRUE.
      *
      *** REVERSE DEBIT/CREDIT ON ENTRY LINES IF A REVERSAL TRANSACTION
      *
031034*    PERFORM  7100-GET-CNTRXN-INFO
031034*        THRU 7100-GET-CNTRXN-INFO-X
015290
015290     IF  WS-BUS-FCN-PAYMENT
015290     OR  WS-BUS-FCN-TRNANO
031034*        PERFORM  1800-GET-PGAL-INFO
031034*            THRU 1800-GET-PGAL-INFO-X
031034         PERFORM  1800-GET-GAIN-INFO
031034             THRU 1800-GET-GAIN-INFO-X
031034*        IF  LPGAL-PGAL-ALLOC-REQ
031034         IF  LPGAC-PGAL-ALLOC-REQ
015290         AND WS-ERROR-NONE
031034         AND WS-PGAC-RETRN-OK
031034*            PERFORM  1880-XEDIT-PGAL-ALLOC-AMT
031034*                THRU 1880-XEDIT-PGAL-ALLOC-AMT-X
031034             SET LPGAC-PRCES-TYP-ALL     TO TRUE
031034             PERFORM  1880-XEDIT-GAIN-ALLOC-AMT
031034                 THRU 1880-XEDIT-GAIN-ALLOC-AMT-X
031034*            IF  WS-PLAR-ALLOC-ERR-OCCURRED
031034             IF  LPGAC-RETRN-ALLOC-ERROR
015290                 SET  WS-ERROR-OCCURRED  TO TRUE
015290             END-IF
015290         END-IF
015290     ELSE
031034*        PERFORM  1840-GET-REV-PGAL-INFO
031034*            THRU 1840-GET-REV-PGAL-INFO-X
031034         PERFORM  1840-GET-REV-GAIN-INFO
031034             THRU 1840-GET-REV-GAIN-INFO-X
015290     END-IF.
015290
031034*    IF  LPGAL-PGAL-ALLOC-REQ
031034     IF  LPGAC-PGAL-ALLOC-REQ
031034*    AND WS-PLAR-ALLOC-ERR-OCCURRED
031034     AND LPGAC-RETRN-ALLOC-ERROR
015290         SET  WS-ERROR-OCCURRED    TO TRUE
015290     END-IF.
015290
022330*    IF L1651-ELNR-AMT (1) NOT = ZERO
022330*    OR L1651-ELNR-AMT (2) NOT = ZERO
022330*        IF WS-BUS-FCN-REVERSAL
022330*            COMPUTE L1651-ELNR-AMT (1) = L1651-ELNR-AMT (1) * -1
022330*            COMPUTE L1651-ELNR-AMT (2) = L1651-ELNR-AMT (2) * -1
022330*        END-IF
022330*    END-IF.
022330*
031034*    MOVE LPGAL-PLAR-PRCES-SW         TO L1651-PLAR-PRCES-SW.
031034*    MOVE LPGAL-PGAL-ALLOC-SW         TO L1651-PGAL-ALLOC-SW.
031034*
031034*    IF  LPGAL-PGAL-ALLOC-REQ
031034*        PERFORM
031034*        VARYING  LPGAL-SUB FROM +1 BY +1
031034*          UNTIL  LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*              MOVE LPGAL-PGAL-ALLOC-TYP-CD      (LPGAL-SUB)
031034*                   TO L1651-PGAL-ALLOC-TYP-CD   (LPGAL-SUB)
031034*              MOVE LPGAL-PGAL-OPN-PRIN-AMT      (LPGAL-SUB)
031034*                   TO L1651-PGAL-OPN-PRIN-AMT   (LPGAL-SUB)
031034*              MOVE LPGAL-PGAL-OPN-GAIN-AMT      (LPGAL-SUB)
031034*                   TO L1651-PGAL-OPN-GAIN-AMT   (LPGAL-SUB)
031034*              MOVE LPGAL-PGAL-TRXN-PRIN-AMT     (LPGAL-SUB)
031034*                   TO L1651-PGAL-TRXN-PRIN-AMT  (LPGAL-SUB)
031034*              MOVE LPGAL-PGAL-TRXN-GAIN-AMT     (LPGAL-SUB)
031034*                   TO L1651-PGAL-TRXN-GAIN-AMT  (LPGAL-SUB)
031034*              MOVE LPGAL-PGAL-DPOS-DFLT-IND     (LPGAL-SUB)
031034*                   TO L1651-PGAL-DPOS-DFLT-IND  (LPGAL-SUB)
031034*        END-PERFORM
031034*    END-IF.
031034     SET L1651-UPDATE-ACB              TO TRUE.

           IF WS-BUS-FCN-PAYMENT
           OR WS-BUS-FCN-TRNANO
016503         SET L1651-REDO-WARNING        TO TRUE
               PERFORM  1651-1000-POL-PAYMENT
                   THRU 1651-1000-POL-PAYMENT-X
           ELSE

025586         PERFORM  1930-VERIFY-PHST
025586             THRU 1930-VERIFY-PHST-X
025586         EVALUATE TRUE
025586             WHEN RPHST-POL-ACTV-TYP-ID = '1078'
025586                  SET L1651-UNDO-ORIGIN-PREMAPL
025586                                       TO TRUE
025767             WHEN RPHST-POL-ACTV-TYP-ID = '1080'
025767                  SET L1651-UNDO-ORIGIN-PREMAPP
025767                                       TO TRUE
025586             WHEN RPHST-POL-ACTV-TYP-ID = '1082'
025586                  SET L1651-UNDO-ORIGIN-PREMSUS
025586                                       TO TRUE
025586             WHEN RPHST-POL-ACTV-TYP-ID = '1084'
025586                  SET L1651-UNDO-ORIGIN-PREMPAY
025586                                       TO TRUE
025586         END-EVALUATE

026678         IF  RPOL-POL-STAT-IN-FORCE
026678             SET L1651-ORIGIN-UNDO    TO TRUE
026678         END-IF
               PERFORM  1651-2000-POL-REVRS
                   THRU 1651-2000-POL-REVRS-X
031034*        IF  WS-HOLD-PGAL-ALLOC-REQ
031034         IF  LPGAC-PGAL-ALLOC-REQ
015290         AND RPOL-POL-STAT-BEFORE-SETL
015290*MSG: MANUAL ADJUSTMENT MAY BE REQUIRED ON PGAL AND POLT TABLE
015290            MOVE 'CS06510028'    TO WGLOB-MSG-REF-INFO
015290            PERFORM  0260-1000-GENERATE-MESSAGE
015290                THRU 0260-1000-GENERATE-MESSAGE-X
015290         END-IF
           END-IF.
      *
031034*    IF  L1651-RETRN-OK
031034*    AND (MIR-CF-REG-FND-SRC-1035
031034*    OR   MIR-CF-REG-FND-INT-ROLOVER
031034*    OR   MIR-CF-REG-FND-DIR-ROLOVER
031034*    OR   MIR-CF-REG-FND-TRUST-TFR
031034*    OR   MIR-CF-REG-FND-ROTH-CNVR
031034*    OR   MIR-CF-REG-FND-RCHAR)
031034*        PERFORM  1900-UPDATE-1035-ACB
031034*            THRU 1900-UPDATE-1035-ACB-X
031034*    END-IF.
031034*
031034*    IF  WS-BUS-FCN-PAYMENT
031034*        IF  LPGAL-PGAL-ALLOC-REQ
031034*        AND RPOL-POL-STAT-BEFORE-SETL
031034*            PERFORM  1920-CREATE-PENDING-PGAL
031034*                THRU 1920-CREATE-PENDING-PGAL-X
031034*        END-IF
031034*    END-IF.

           MOVE  RPOL-REC-INFO TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY      TO  WPOL-KEY.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           MOVE HPOL-REC-INFO  TO  RPOL-REC-INFO.
      *

           IF NOT L1651-RETRN-OK
016503        PERFORM  0289-1000-INIT-PARM-INFO
016503            THRU 0289-1000-INIT-PARM-INFO-X
016503        MOVE L1651-EFF-DT        TO L0289-LO-PAC-DT
016503        MOVE L1651-EFF-DT        TO L0289-LO-CRC-DT
020467        MOVE L1651-EFF-DT        TO L0289-LO-DD2-DT
016503        MOVE L1651-EFF-DT        TO L0289-PROC-EFF-DT
016503        IF  RPOL-POL-PREM-TCNTRCT
016503            IF WS-REDO-EFF-DT < L1651-EFF-DT
016503               MOVE WS-REDO-EFF-DT   TO L0289-LO-PAC-DT
020467               MOVE WS-REDO-EFF-DT   TO L0289-LO-DD2-DT
016503               MOVE WS-REDO-EFF-DT   TO L0289-LO-CRC-DT
016503               MOVE WS-REDO-EFF-DT   TO L0289-PROC-EFF-DT
016503            END-IF
016503        END-IF
016503        PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503            THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503        IF  L0289-RETRN-OK
016503            MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503            MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503        ELSE
016503            MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503            MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503        END-IF
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
               PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                   THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
               GO TO 1700-PROCESS-PPAY-X
557660     END-IF.

557696     PERFORM  1701-MISC-WARN-MSG
557696         THRU 1701-MISC-WARN-MSG-X
557696       VARYING WS-SUB FROM +1 BY +1
557696          UNTIL WS-SUB > WS-MAX-LINES.

016503*    IF UPDATE-REQUIRED
016503*        MOVE WWKDT-ZERO-DT           TO RPOL-POL-NXT-ACTV-DT
016503*        IF RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*            MOVE 'RSH'               TO RPOL-NXT-ACTV-TYP-CD
016503*        END-IF
016503*    END-IF.
      *
016503     IF UPDATE-REQUIRED
016503        PERFORM  0289-1000-INIT-PARM-INFO
016503            THRU 0289-1000-INIT-PARM-INFO-X
016503        MOVE L1651-EFF-DT        TO L0289-LO-PAC-DT
020467        MOVE L1651-EFF-DT        TO L0289-LO-DD2-DT
016503        MOVE L1651-EFF-DT        TO L0289-LO-CRC-DT
016503        MOVE L1651-EFF-DT        TO L0289-PROC-EFF-DT
016503        IF  RPOL-POL-PREM-TCNTRCT
016503            IF  WS-REDO-EFF-DT < L1651-EFF-DT
016503                MOVE WS-REDO-EFF-DT    TO L0289-LO-PAC-DT
020467                MOVE WS-REDO-EFF-DT    TO L0289-LO-DD2-DT
016503                MOVE WS-REDO-EFF-DT    TO L0289-LO-CRC-DT
016503                MOVE WS-REDO-EFF-DT    TO L0289-PROC-EFF-DT
016503            END-IF
016503        END-IF
016503        PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503            THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503        IF  L0289-RETRN-OK
016503            MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503            MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503        ELSE
016503            MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503            MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503        END-IF
016503     END-IF.

           IF UPDATE-REQUIRED
               MOVE WGLOB-PROCESS-DATE TO RPOL-PREV-FILE-MAINT-DT
               MOVE 'CS00000011'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
               PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                   THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
016395         IF  L1651-CRC-AMT NOT = ZEROS
016395             PERFORM  1730-GENERATE-DALG
016395                 THRU 1730-GENERATE-DALG-X
016395         END-IF
           END-IF.
      *
           PERFORM  0240-SET-VALUES
               THRU 0240-SET-VALUES-X.
      *
       1700-PROCESS-PPAY-X.
           EXIT.
      /
557696 1701-MISC-WARN-MSG.
557696
557696     MOVE MIR-ACCT-BASE-ID-T(WS-SUB)          TO WS-ACCT.
557696     IF WS-ACCT-TYP-COMM
557696      OR MIR-AGT-ID-T(WS-SUB) NOT = SPACES
557696         PERFORM  4180-1000-BUILD-PARM-INFO
557696            THRU  4180-1000-BUILD-PARM-INFO-X
557696         MOVE MIR-ACCT-BASE-ID-T(WS-SUB)      TO L4180-ACCT-NUM
557696         MOVE MIR-AGT-ID-T(WS-SUB)     TO L4180-AGT-NUM
557696         PERFORM  4180-1000-USTM-EDITS
557696            THRU  4180-1000-USTM-EDITS-X
557696     END-IF.
557696
557696 1701-MISC-WARN-MSG-X.
557696     EXIT.

       1710-SETUP-ENTRY-AMTS.

           IF HOLD-DR1 NOT = ZERO
               COMPUTE L1651-ELNR-AMT (1) = HOLD-DR1
           ELSE
               COMPUTE L1651-ELNR-AMT (1) = HOLD-CR1 * -1
           END-IF.

           IF HOLD-DR2 NOT = ZERO
               COMPUTE L1651-ELNR-AMT (2) = HOLD-DR2
           ELSE
               COMPUTE L1651-ELNR-AMT (2) = HOLD-CR2 * -1
           END-IF.
       1710-SETUP-ENTRY-AMTS-X.
           EXIT.
      /
016503*----------------
016503 1720-INVOKE-REDO.
016503*----------------

016503     IF  (RPOL-POL-NXT-ACTV-DT NOT = WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503         GO TO 1720-INVOKE-REDO-X
016503     END-IF.

016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503         GO TO 1720-INVOKE-REDO-X
016503     END-IF.

016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     PERFORM  1722-GET-EFF-DT
016503         THRU 1722-GET-EFF-DT-X.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
016503     SET L4780-PRCES-INCLUSIVE          TO TRUE.

016503     IF  L4780-EFF-DT = WWKDT-ZERO-DT
016503         GO TO 1720-INVOKE-REDO-X
016503     ELSE
016503         PERFORM  4780-1000-GET-NEXT-ACT-DT
016503             THRU 4780-1000-GET-NEXT-ACT-DT-X
016503     END-IF.

016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              PERFORM  POL-3000-UNLOCK
016503                  THRU POL-3000-UNLOCK-X
016503              SET WS-REDO-NOT-OK           TO TRUE
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503             PERFORM  POL-3000-UNLOCK
016503                 THRU POL-3000-UNLOCK-X
016503             MOVE WS-REDO-EFF-DT      TO L0201-EFF-DT
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X
016503             PERFORM  0289-1000-INIT-PARM-INFO
016503                 THRU 0289-1000-INIT-PARM-INFO-X
016503             MOVE L1651-EFF-DT    TO L0289-LO-PAC-DT
020467             MOVE L1651-EFF-DT    TO L0289-LO-DD2-DT
016503             MOVE L1651-EFF-DT    TO L0289-LO-CRC-DT
016503             MOVE L1651-EFF-DT    TO L0289-PROC-EFF-DT
016503             IF  RPOL-POL-PREM-TCNTRCT
016503                 IF WS-REDO-EFF-DT < WGLOB-PROCESS-DATE
016503                    MOVE WS-REDO-EFF-DT  TO L0289-LO-PAC-DT
020467                    MOVE WS-REDO-EFF-DT  TO L0289-LO-DD2-DT
016503                    MOVE WS-REDO-EFF-DT  TO L0289-LO-CRC-DT
016503                    MOVE WS-REDO-EFF-DT  TO L0289-PROC-EFF-DT
016503                 END-IF
016503            END-IF
016503            PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503                THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503            IF  L0289-RETRN-OK
016503                MOVE L0289-NXT-ACTV-TYP-CD
016503                     TO RPOL-NXT-ACTV-TYP-CD
016503                MOVE L0289-NXT-ACTV-DT
016503                     TO RPOL-POL-NXT-ACTV-DT
016503            ELSE
016503                MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503                MOVE WGLOB-PROCESS-DATE
016503                          TO RPOL-POL-NXT-ACTV-DT
016503            END-IF
016503            MOVE RPOL-REC-INFO            TO HPOL-REC-INFO
016503            PERFORM  POL-1000-READ-FOR-UPDATE
016503                THRU POL-1000-READ-FOR-UPDATE-X
016503            MOVE HPOL-REC-INFO            TO RPOL-REC-INFO
016503            PERFORM  POL-2000-REWRITE
016503                THRU POL-2000-REWRITE-X
016503                PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016503                    THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221                PERFORM  POL-1000-READ-TWRK-TS
014221                    THRU POL-1000-READ-TWRK-TS-X
016503             IF  L0201-RETRN-OK
016503                 PERFORM  POL-1000-READ-FOR-UPDATE
016503                     THRU POL-1000-READ-FOR-UPDATE-X
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503             END-IF
016503     END-EVALUATE.

016503 1720-INVOKE-REDO-X.
016503     EXIT.
      /
016503*---------------
016503 1722-GET-EFF-DT.
016503*---------------

016503     IF L1651-PREM-AMT NOT = ZERO
016503         MOVE RPOL-POL-PD-TO-DT-NUM  TO WS-REDO-EFF-DT
016503     ELSE
016503         MOVE WWKDT-ZERO-DT          TO WS-REDO-EFF-DT
016503     END-IF

016503     IF  L1651-PREM-AMT = ZERO
016503     AND L1651-LOAN-AMT = ZERO
016503     AND L1651-APL-AMT = ZERO
016503     AND L1651-PDF-AMT = ZERO
016503     AND L1651-DEPOSIT-AMT = ZERO
018846     AND L1651-SIDFND-AMT = ZERO
016503         MOVE WWKDT-ZERO-DT                 TO L4780-EFF-DT
016503     ELSE
016503         IF WS-REDO-EFF-DT > L1651-EFF-DT
016503             MOVE WS-REDO-EFF-DT     TO L4780-EFF-DT
016503         ELSE
016503             MOVE L1651-EFF-DT       TO L4780-EFF-DT
016503         END-IF
016503     END-IF.

016503     IF  RPOL-POL-PREM-TCNTRCT
016503         IF  WS-REDO-EFF-DT < WGLOB-PROCESS-DATE
016503             MOVE WS-REDO-EFF-DT     TO L4780-EFF-DT
016503         ELSE
016503             MOVE WGLOB-PROCESS-DATE  TO L4780-EFF-DT
016503             MOVE WGLOB-PROCESS-DATE  TO WS-REDO-EFF-DT
016503         END-IF
016503     ELSE
016503         MOVE L1651-EFF-DT            TO WS-REDO-EFF-DT
016503     END-IF.

016503 1722-GET-EFF-DT-X.
016503     EXIT.
      /
016395*-------------------
016395 1730-GENERATE-DALG.
016395*-------------------

016395     MOVE 'P'                     TO L0760-POL-OR-CLI-TYPE
016395     MOVE RPOL-POL-ID             TO L0760-POL-OR-CLI-ID
016395     MOVE 'CRCD'                  TO L0760-DAL-ACTIVITY
016395     MOVE 'PAY'                   TO L0760-DAL-ACTION
016395     MOVE '00'                    TO L0760-CVG-NUM
023061*    MOVE 'NC07600925'            TO L0760-MESSAGE-NUMBER
023061     MOVE 'NS07600925'            TO L0760-MESSAGE-NUMBER

016395     MOVE SPACES                  TO WS-CRC-ID.
016395     MOVE SPACES                  TO WS-DALG-PARM-1.
016395     MOVE SPACES                  TO WS-DALG-PARM-4.

016395     MOVE MIR-DV-CRC-TRXN-AUTH-NUM    TO WS-DALG-PARM-1-1.
016395     MOVE MIR-CRC-TYP-CD         TO WS-DALG-PARM-1-2.
016395     MOVE WS-DALG-PARM-1         TO L0760-MESSAGE-PARMS (1).

016395     MOVE MIR-CRC-ID             TO WS-CRC-ID.
016395     MOVE WS-CRC-ID-1            TO L0760-MESSAGE-PARMS (2).
016395     MOVE WS-CRC-ID-2            TO L0760-MESSAGE-PARMS (3).

016395     MOVE MIR-CRC-XPRY-MO        TO WS-DALG-PARM-4-1.
016395     MOVE MIR-CRC-XPRY-YR        TO WS-DALG-PARM-4-2.
016395     MOVE WS-DALG-PARM-4         TO L0760-MESSAGE-PARMS (4).

016395     PERFORM  0760-1000-PROCESS-DAL-ENTRY
016395         THRU 0760-1000-PROCESS-DAL-ENTRY-X.

016395     IF NOT L0760-RETRN-OK
016395         SET L1651-RETRN-ERROR    TO TRUE
016395     END-IF.

016395 1730-GENERATE-DALG-X.
016395     EXIT.

      /
015290*------------------
031034*1800-GET-PGAL-INFO.
031034 1800-GET-GAIN-INFO.
015290*------------------
015290
015290     PERFORM  1805-CALC-PMT-AMT
015290         THRU 1805-CALC-PMT-AMT-X.
015290
031034     PERFORM  1890-RGN-EXIT-FOR-GAIN
031034         THRU 1890-RGN-EXIT-FOR-GAIN-X.
031034
031034     IF  NOT L0316-RETRN-OK
031034     OR  L0316-RGN-EXIT-STAT-INACTV
031034         GO TO 1800-GET-GAIN-INFO-X
031034     END-IF.
031034
031034     MOVE MIR-CF-REG-FND-SRC-CD    TO LPGAC-REG-FND-SRC-CD.
031034     MOVE WS-TOT-PMT-AMT           TO LPGAC-TOT-PMT-AMT.
031034     MOVE WS-OTH-PMT-AMT           TO LPGAC-OTH-PMT-AMT.
031034     MOVE WS-DEPOSIT-AMT           TO LPGAC-DEPOSIT-AMT.
031034     MOVE L1651-SUSP-AMT           TO LPGAC-SUSP-AMT.
031034     MOVE L1651-PRM-SUSP-AMT       TO LPGAC-PRM-SUSP-AMT.
031034     MOVE L1651-PDF-SUSP-AMT       TO LPGAC-PDF-SUSP-AMT.
031034     MOVE L1651-EFF-DT             TO LPGAC-EFF-DT.
031034     MOVE L1651-TAX-YR             TO LPGAC-TAX-YR.
031034     IF  WS-BUS-FCN-TRNANO
031034         SET LPGAC-PMT-TYP-TRNANO  TO TRUE
031034     END-IF.
031034
031034
031034     PERFORM  PGAC-1000-POL-GAIN-EDIT
031034         THRU PGAC-1000-POL-GAIN-EDIT-X.
031034     MOVE LPGAC-RETRN-CD           TO WS-PGAC-RETRN-CD.
031034
031034*    PERFORM  1810-FILL-LPGAL-ALLOC-TYP-CD
031034*        THRU 1810-FILL-LPGAL-ALLOC-TYP-CD-X.
031034*
031034*    IF  LPGAL-PGAL-ALLOC-NOT-REQ
031034*    OR  WS-ERROR-OCCURRED
031034*        GO TO 1800-GET-PGAL-INFO-X
031034*    END-IF.
031034*
031034*    IF  MIR-CF-REG-FND-REG-CONTRB
031034*        MOVE WS-DFLT-ALLOC-TYP-CD
031034*          TO WS-HOLD-PGAL-ALLOC-TYP-CD (1)
031034*        IF  RPOL-POL-STAT-BEFORE-SETL
031034*        OR  RPOL-POL-SUSPENDED
031034*            COMPUTE WS-HOLD-PGAL-TRXN-PRIN-AMT (1)
031034*                  = WS-TOT-PMT-AMT
031034*                  - WS-OTH-PMT-AMT
031034*        ELSE
031034*            COMPUTE WS-HOLD-PGAL-TRXN-PRIN-AMT (1)
031034*                  = WS-DEPOSIT-AMT
031034*        END-IF
031034*        MOVE ZERO  TO WS-HOLD-PGAL-TRXN-GAIN-AMT (1)
031034*        PERFORM  1870-FILL-PGAL-TRXN-AMT
031034*            THRU 1870-FILL-PGAL-TRXN-AMT-X
031034*            VARYING  WS-SUB FROM +1 BY +1
031034*               UNTIL WS-SUB > LPGAL-MAX-ALLOC-TYP
031034*        GO TO 1800-GET-PGAL-INFO-X
031034*    END-IF.

015290* UPDATE HOLD AREA ALLOCATION CODE BASE ON INPUT FUND SRCE
031034*    MOVE  +1          TO LPGAL-SUB.
031034*
031034*    PERFORM  1820-FILL-HOLD-AREA-PGAL
031034*        THRU 1820-FILL-HOLD-AREA-PGAL-X
031034*    VARYING  WS-SUB FROM +1 BY +1
031034*      UNTIL  WS-SUB > LPGAL-MAX-ALLOC-TYP.
015290

031034*    SET WS-ALLOC-INIT-NO             TO TRUE.
031034*    MOVE ZEROS                    TO WS-1035-ACB-AMT.
031034*
031034*    PERFORM  1830-CHECK-MIR-ALLOC-TYP-CD
031034*        THRU 1830-CHECK-MIR-ALLOC-TYP-CD-X
031034*    VARYING  LPGAL-SUB FROM +1 BY +1
031034*      UNTIL  LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*         OR  WS-ALLOC-INIT.
031034*
031034*    IF  NUM-ERR-OCCURRED
031034*        MOVE  'CS06510004'       TO WGLOB-MSG-REF-INFO
031034*        PERFORM  0260-1000-GENERATE-MESSAGE
031034*            THRU 0260-1000-GENERATE-MESSAGE-X
031034*        SET WS-ERROR-OCCURRED   TO TRUE
031034*        GO TO 1800-GET-PGAL-INFO-X
031034*    END-IF.
031034*
031034*    IF  WS-ALLOC-INIT
031034*        PERFORM
031034*          VARYING  LPGAL-SUB FROM +1 BY +1
031034*            UNTIL  LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*            MOVE SPACES TO WS-HOLD-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*            MOVE ZEROS  TO WS-HOLD-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*            MOVE ZEROS  TO WS-HOLD-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*        END-PERFORM
031034*        MOVE ZEROS             TO WS-TOT-ALLOC-AMT
031034*        MOVE  +1   TO LPGAL-SUB
031034*        PERFORM  1820-FILL-HOLD-AREA-PGAL
031034*            THRU 1820-FILL-HOLD-AREA-PGAL-X
031034*            VARYING  WS-SUB FROM +1 BY +1
031034*            UNTIL  WS-SUB > LPGAL-MAX-ALLOC-TYP
031034*    ELSE
031034*        PERFORM  1870-FILL-PGAL-TRXN-AMT
031034*            THRU 1870-FILL-PGAL-TRXN-AMT-X
031034*            VARYING  WS-SUB FROM +1 BY +1
031034*               UNTIL WS-SUB > LPGAL-MAX-ALLOC-TYP
031034*    END-IF.
031034*
031034*1800-GET-PGAL-INFO-X.
031034 1800-GET-GAIN-INFO-X.
015290     EXIT.
015290
015290*---------------------------
015290 1805-CALC-PMT-AMT.
015290*---------------------------
015290
015290     COMPUTE WS-TOT-PMT-AMT = L1651-CASH-AMT
015290                            + L1651-PAC-AMT
020467                            + L1651-DD2-AMT
022968                            + L1651-RETCOMM-AMT
015290                            + L1651-CRC-AMT.
015290
024088     IF  RPOL-POL-SUSPENDED
024088     AND WS-TOT-PMT-AMT         = ZERO
024088     AND L1651-PRM-SUSP-AMT NOT = ZERO
024088         COMPUTE WS-TOT-PMT-AMT = L1651-PRM-SUSP-AMT
024088     END-IF.

022637* INCLUDE ACCOUNT INFORMATION AMOUNT IN THE TOTAL PAYMENT AMOUNT
022637     ADD L1651-ELNR-AMT (1)
022637         L1651-ELNR-AMT (2)
022637         TO WS-TOT-PMT-AMT.

015290     IF  RPOL-POL-STAT-BEFORE-SETL
015290     OR  RPOL-POL-SUSPENDED
015290         COMPUTE WS-OTH-PMT-AMT = L1651-SIDFND-AMT
015290                                + L1651-OS-DISB-AMT
015290     ELSE
015290         COMPUTE WS-OTH-PMT-AMT = L1651-PREM-AMT
015290                                + L1651-LOAN-AMT
015290                                + L1651-APL-AMT
015290                                + L1651-PDF-AMT
015290                                + L1651-SIDFND-AMT
015290                                + L1651-PRM-SUSP-AMT
015290                                + L1651-OS-DISB-AMT
015290                                + L1651-SUSP-AMT
015290                                + L1651-PDF-SUSP-AMT
015290         IF RPOL-POL-INS-TYP-UL
015290            COMPUTE WS-DEPOSIT-AMT = L1651-DEPOSIT-AMT
015290                                   + L1651-PREM-AMT
015290         ELSE
015290            COMPUTE WS-DEPOSIT-AMT = L1651-DEPOSIT-AMT
015290         END-IF
015290     END-IF.
015290
015290 1805-CALC-PMT-AMT-X.
015290     EXIT.
015290
015290*----------------------------
031034*1810-FILL-LPGAL-ALLOC-TYP-CD.
015290*----------------------------
015290
031034*    EVALUATE TRUE
031034*       WHEN  RPOL-POL-STAT-BEFORE-SETL
031034*       WHEN  RPOL-POL-SUSPENDED
031034*          IF  L1651-SUSP-AMT      = ZEROS
031034*          AND L1651-PRM-SUSP-AMT  = ZEROS
031034*          AND L1651-PDF-SUSP-AMT  = ZEROS
031034*          AND WS-OTH-PMT-AMT = WS-TOT-PMT-AMT
031034*              SET LPGAL-PLAR-PRCES         TO TRUE
031034*              SET LPGAL-PGAL-ALLOC-NOT-REQ TO TRUE
031034*              GO TO 1810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*          END-IF
031034*       WHEN OTHER
031034*          IF  WS-DEPOSIT-AMT = ZEROS
031034*          AND WS-OTH-PMT-AMT = WS-TOT-PMT-AMT
031034*              SET LPGAL-PLAR-PRCES         TO TRUE
031034*              SET LPGAL-PGAL-ALLOC-NOT-REQ TO TRUE
031034*              GO TO 1810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*          END-IF
031034*    END-EVALUATE.
015290
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE MIR-POL-ID               TO L7800-POL-ID.
031034*    MOVE L1651-EFF-DT             TO L7800-EFF-DT.
031034*    SET  L7800-TRXN-DPOS          TO TRUE.
031034*    SET  L7800-CALC-CV-REQ        TO TRUE.
031034*    SET  L7800-GET-PLAR-REQ       TO TRUE.
031034*    MOVE LCNEX-DFLT-CNTRXN-TYP-CD TO L7800-CNTRXN-TYP-CD.
031034*    MOVE L1651-TAX-YR             TO L7800-TAX-YR.
031034*
031034*    IF  WS-BUS-FCN-REVERSAL
031034*        SET  L7800-PRCES-REVERSE  TO TRUE
031034*    ELSE
031034*        SET  L7800-PRCES-NORMAL   TO TRUE
031034*    END-IF.
031034*
031034*    PERFORM  7800-5000-PGAL-OPEN-BAL
031034*        THRU 7800-5000-PGAL-OPEN-BAL-X
031034*
031034
031034*    IF  L7800-RETRN-OK
031034*        CONTINUE
031034*    ELSE
015290*MSG:   UNABLE TO GET POLICY GAIN INFORMATION
031034*       MOVE 'CS06510030'               TO WGLOB-MSG-REF-INFO
031034*       PERFORM  0260-1000-GENERATE-MESSAGE
031034*           THRU 0260-1000-GENERATE-MESSAGE-X
031034*       SET  WS-ERROR-OCCURRED          TO TRUE
031034*       GO TO 1810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*    END-IF.

031034*    MOVE L7800-PLAR-PRCES-SW      TO LPGAL-PLAR-PRCES-SW.
031034*    MOVE L7800-PGAL-ALLOC-SW      TO LPGAL-PGAL-ALLOC-SW.
015290
031034*    IF  LPGAL-PGAL-ALLOC-NOT-REQ
031034*        GO TO 1810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*    END-IF.

031034*    EVALUATE  TRUE
031034*       WHEN  RPOL-POL-PNSN-QUALF-NONE
031034*         IF  MIR-CF-REG-FND-REG-CONTRB
031034*         AND L7800-DPOS-DFLT-NOT-FOUND
015290*MSG: UNABLE TO PROCESS PAYMENT, NO DEPOSIT DEFAULT IND. IN PLAR
015290*     FOR PLAN @1
031034*             MOVE 'CS06510022'        TO WGLOB-MSG-REF-INFO
031034*             MOVE L7800-PLAN-ID       TO WGLOB-MSG-PARM (01)
031034*             PERFORM  0260-1000-GENERATE-MESSAGE
031034*                 THRU 0260-1000-GENERATE-MESSAGE-X
031034*             SET WS-ERROR-OCCURRED            TO TRUE
031034*             GO TO 1810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*         END-IF
031034*       WHEN  OTHER
031034*         IF  (MIR-CF-REG-FND-REG-CONTRB
031034*         OR   MIR-CF-REG-FND-ROTH-CNVR
031034*         OR   MIR-CF-REG-FND-RCHAR
031034*         OR   MIR-CF-REG-FND-DIR-ROLOVER
031034*         OR   MIR-CF-REG-FND-TRUST-TFR)
031034*         AND  L7800-DPOS-DFLT-NOT-FOUND
015290*MSG: UNABLE TO PROCESS PAYMENT, PLAN RULE ALLOCATION ERROR
015290*     - PLAN @1
031034*             MOVE 'CS06510024'        TO WGLOB-MSG-REF-INFO
031034*             MOVE L7800-PLAN-ID       TO WGLOB-MSG-PARM (01)
031034*             PERFORM  0260-1000-GENERATE-MESSAGE
031034*                 THRU 0260-1000-GENERATE-MESSAGE-X
031034*             SET WS-ERROR-OCCURRED            TO TRUE
031034*             GO TO 1810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*         END-IF
031034*    END-EVALUATE.

031034*    SET WS-PLAR-RULE-NOT-SET               TO TRUE.
031034*    MOVE SPACES                         TO WS-DFLT-ALLOC-TYP-CD.
031034*    PERFORM
031034*    VARYING LPGAL-SUB FROM +1 BY +1
031034*      UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*          MOVE L7800-PGAL-ALLOC-TYP-CD     (LPGAL-SUB)
031034*               TO LPGAL-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*          MOVE L7800-PGAL-OPN-PRIN-AMT     (LPGAL-SUB)
031034*               TO LPGAL-PGAL-OPN-PRIN-AMT  (LPGAL-SUB)
031034*          MOVE L7800-PGAL-OPN-GAIN-AMT     (LPGAL-SUB)
031034*               TO LPGAL-PGAL-OPN-GAIN-AMT  (LPGAL-SUB)
031034*          MOVE L7800-PGAL-TRXN-PRIN-AMT    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*          MOVE L7800-PGAL-TRXN-GAIN-AMT    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*          MOVE L7800-PGAL-WTHDR-SEQ-NUM    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-WTHDR-SEQ-NUM (LPGAL-SUB)
031034*          MOVE L7800-PGAL-WTHDR-ORDR-CD    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*          MOVE L7800-PGAL-DPOS-DFLT-IND    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-DPOS-DFLT-IND (LPGAL-SUB)
031034*          MOVE L7800-PGAL-XFER-ONLY-IND    (LPGAL-SUB)
031034*               TO LPGAL-PGAL-XFER-ONLY-IND (LPGAL-SUB)
031034*          IF  LPGAL-PGAL-DPOS-DFLT (LPGAL-SUB)
031034*          OR  LPGAL-PGAL-XFER-ONLY (LPGAL-SUB)
031034*              SET WS-PLAR-RULE-SET         TO TRUE
031034*          END-IF
031034*          IF  LPGAL-PGAL-DPOS-DFLT (LPGAL-SUB)
031034*              MOVE LPGAL-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*                TO WS-DFLT-ALLOC-TYP-CD
031034*          END-IF
031034*    END-PERFORM.
031034*
031034*
031034*    IF  MIR-CF-REG-FND-REG-CONTRB
031034*    OR  MIR-CF-REG-FND-DIR-ROLOVER
031034*    OR  MIR-CF-REG-FND-TRUST-TFR
031034*    OR  MIR-CF-REG-FND-RCHAR
031034*    OR  MIR-CF-REG-FND-ROTH-CNVR
031034*        CONTINUE
031034*    ELSE
031034*        IF  WS-PLAR-RULE-NOT-SET
015290*MSG UNABLE TO PROCESS PAYMENT, NO ALLOCATION SPECIFIED IN
015290*    PLAN ALLOCATION RULE FOR @1
031034*            MOVE 'CS06510023'    TO WGLOB-MSG-REF-INFO
031034*            MOVE L7800-PLAN-ID   TO WGLOB-MSG-PARM (01)
031034*            PERFORM  0260-1000-GENERATE-MESSAGE
031034*                THRU 0260-1000-GENERATE-MESSAGE-X
031034*            SET WS-ERROR-OCCURRED             TO TRUE
031034*            GO TO 1810-FILL-LPGAL-ALLOC-TYP-CD-X
031034*       END-IF
031034*    END-IF.
031034*
031034*1810-FILL-LPGAL-ALLOC-TYP-CD-X.
031034*    EXIT.
015290
015290*---------------------------
031034*1820-FILL-HOLD-AREA-PGAL.
015290*---------------------------
015290
031034*    EVALUATE TRUE
031034*       WHEN MIR-CF-REG-FND-REG-CONTRB
031034*       WHEN MIR-CF-REG-FND-ROTH-CNVR
031034*       WHEN MIR-CF-REG-FND-RCHAR
031034*       WHEN MIR-CF-REG-FND-DIR-ROLOVER
031034*       WHEN MIR-CF-REG-FND-TRUST-TFR
031034*       WHEN WS-BUS-FCN-TRNANO
031034*            IF  LPGAL-PGAL-DPOS-DFLT (WS-SUB)
031034*                MOVE LPGAL-PGAL-ALLOC-TYP-CD (WS-SUB)
031034*                     TO WS-HOLD-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*                MOVE LPGAL-MAX-ALLOC-TYP   TO WS-SUB
031034*                GO TO 1820-FILL-HOLD-AREA-PGAL-X
031034*            END-IF
031034*       WHEN OTHER
031034*            IF  LPGAL-PGAL-DPOS-DFLT (WS-SUB)
031034*            OR  LPGAL-PGAL-XFER-ONLY (WS-SUB)
031034*                MOVE LPGAL-PGAL-ALLOC-TYP-CD (WS-SUB)
031034*                  TO WS-HOLD-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*                ADD +1                     TO LPGAL-SUB
031034*            END-IF
031034*    END-EVALUATE.
031034*
031034*1820-FILL-HOLD-AREA-PGAL-X.
031034*    EXIT.
015290
015290*---------------------------
031034*1830-CHECK-MIR-ALLOC-TYP-CD.
015290*---------------------------
015290
015290
031034*    EVALUATE  TRUE
031034*       WHEN WS-HOLD-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*         =  WS-MIR-PGAL-ALLOC-TYP-CD  (LPGAL-SUB)
031034*            PERFORM  1860-UPDATE-TRXN-AMOUNT
031034*                THRU 1860-UPDATE-TRXN-AMOUNT-X
031034*       WHEN OTHER
031034*            SET WS-ALLOC-INIT           TO TRUE
031034*    END-EVALUATE.
031034*
031034*1830-CHECK-MIR-ALLOC-TYP-CD-X.
031034*    EXIT.
015290
015290*---------------------------
031034*1840-GET-REV-PGAL-INFO.
031034 1840-GET-REV-GAIN-INFO.
015290*---------------------------
015290
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
031034*
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE MIR-POL-ID               TO L7800-POL-ID.
031034*    MOVE L1651-EFF-DT             TO L7800-EFF-DT.
031034*    SET  L7800-TRXN-DPOS          TO TRUE.
031034*    SET  L7800-GET-PLAR-REQ       TO TRUE.
031034*    MOVE LCNEX-DFLT-CNTRXN-TYP-CD TO L7800-CNTRXN-TYP-CD.
031034*
031034*    SET  L7800-PRCES-REVERSE      TO TRUE.
031034*
031034*    PERFORM  7800-1000-GET-PLAR-INFO
031034*        THRU 7800-1000-GET-PLAR-INFO-X.
031034*
031034     PERFORM  1890-RGN-EXIT-FOR-GAIN
031034         THRU 1890-RGN-EXIT-FOR-GAIN-X.
031034
031034     IF  NOT L0316-RETRN-OK
031034     OR  L0316-RGN-EXIT-STAT-INACTV
031034         GO TO 1840-GET-REV-GAIN-INFO-X
031034     END-IF.
031034
031034     MOVE L1651-EFF-DT               TO LPGAC-EFF-DT
031034     MOVE MIR-CF-REG-FND-SRC-CD      TO LPGAC-REG-FND-SRC-CD.
031034
031034     PERFORM  PGAC-4000-POL-GAIN-REV-EDIT
031034         THRU PGAC-4000-POL-GAIN-REV-EDIT-X.
031034     MOVE LPGAC-RETRN-CD             TO WS-PGAC-RETRN-CD.
031034
031034*    IF  L7800-RETRN-OK
031034     IF  WS-PGAC-RETRN-OK
015290         CONTINUE
015290     ELSE
015290        SET  WS-ERROR-OCCURRED          TO TRUE
031034*       GO TO 1840-GET-REV-PGAL-INFO-X
031034        GO TO 1840-GET-REV-GAIN-INFO-X
015290     END-IF.
015290
031034*    MOVE L7800-PGAL-ALLOC-SW      TO WS-HOLD-PGAL-ALLOC-SW.
015290
031034*    MOVE 'N'          TO LPGAL-PLAR-PRCES-SW.
031034*    MOVE 'N'          TO LPGAL-PGAL-ALLOC-SW.
015290
031034*1840-GET-REV-PGAL-INFO-X.
031034 1840-GET-REV-GAIN-INFO-X.
015290     EXIT.
015290
015290*---------------------------
031034*1860-UPDATE-TRXN-AMOUNT.
015290*---------------------------
015290
031034*    IF  WS-MIR-PGAL-ALLOC-TYP-CD  (LPGAL-SUB) =
031034*        WS-HOLD-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*        IF  WS-MIR-PGAL-TRXN-PRIN-AMT (LPGAL-SUB) > SPACES
031034*            MOVE WS-MIR-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*                 TO L0280-INPUT-DATA
031034*            MOVE 2                       TO L0280-PRECISION
031034*            MOVE LENGTH OF WS-MIR-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*                 TO L0280-INPUT-SIZE
031034*            SET L0280-SIGN-PERMITTED     TO TRUE
031034*            COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
031034*                                 - L0280-PRECISION
031034*                                 - 1
031034*            PERFORM  0280-1000-NUMERIC-EDIT
031034*                THRU 0280-1000-NUMERIC-EDIT-X
031034*            IF  L0280-OK
031034*                MOVE L0280-OUTPUT-DOLLAR
031034*                     TO WS-HOLD-PGAL-TRXN-PRIN-AMT  (LPGAL-SUB)
031034*                ADD  WS-HOLD-PGAL-TRXN-PRIN-AMT     (LPGAL-SUB)
031034*                     TO WS-TOT-ALLOC-AMT
031034*            ELSE
031034*                SET NUM-ERR-OCCURRED             TO TRUE
031034*            END-IF
031034*        END-IF
031034*        IF  WS-MIR-PGAL-TRXN-GAIN-AMT (LPGAL-SUB) > SPACES
031034*            MOVE WS-MIR-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*                 TO L0280-INPUT-DATA
031034*            MOVE 2                       TO L0280-PRECISION
031034*            MOVE LENGTH OF WS-MIR-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*                 TO L0280-INPUT-SIZE
031034*            SET L0280-SIGN-PERMITTED     TO TRUE
031034*            COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
031034*                                 - L0280-PRECISION
031034*                                 - 1
031034*            PERFORM  0280-1000-NUMERIC-EDIT
031034*                THRU 0280-1000-NUMERIC-EDIT-X
031034*            IF  L0280-OK
031034*                MOVE L0280-OUTPUT-DOLLAR
031034*                     TO WS-HOLD-PGAL-TRXN-GAIN-AMT  (LPGAL-SUB)
031034*                ADD  WS-HOLD-PGAL-TRXN-GAIN-AMT     (LPGAL-SUB)
031034*                     TO WS-TOT-ALLOC-AMT
031034*            ELSE
031034*                SET NUM-ERR-OCCURRED             TO TRUE
031034*            END-IF
031034*        END-IF
031034*    END-IF.
031034*
031034*    IF  MIR-CF-REG-FND-INT-ROLOVER
031034*    OR  MIR-CF-REG-FND-SRC-1035
031034*    OR  MIR-CF-REG-FND-DIR-ROLOVER
031034*    OR  MIR-CF-REG-FND-TRUST-TFR
031034*    OR  MIR-CF-REG-FND-ROTH-CNVR
031034*    OR  MIR-CF-REG-FND-RCHAR
031034*        ADD  WS-HOLD-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*             TO WS-1035-ACB-AMT
031034*    END-IF.
031034*
031034*1860-UPDATE-TRXN-AMOUNT-X.
031034*    EXIT.
015290*---------------------------
031034*1870-FILL-PGAL-TRXN-AMT.
015290*---------------------------
015290
031034*    PERFORM
031034*    VARYING  LPGAL-SUB FROM +1 BY +1
031034*      UNTIL  LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*         IF  WS-HOLD-PGAL-ALLOC-TYP-CD (WS-SUB)
031034*          =  LPGAL-PGAL-ALLOC-TYP-CD    (LPGAL-SUB)
031034*             MOVE WS-HOLD-PGAL-TRXN-PRIN-AMT (WS-SUB)
031034*               TO LPGAL-PGAL-TRXN-PRIN-AMT    (LPGAL-SUB)
031034*             MOVE WS-HOLD-PGAL-TRXN-GAIN-AMT (WS-SUB)
031034*               TO LPGAL-PGAL-TRXN-GAIN-AMT    (LPGAL-SUB)
031034*        END-IF
031034*
031034*    END-PERFORM.
031034*
031034*    IF  MIR-CF-REG-FND-REG-CONTRB
031034*    OR  MIR-CF-REG-FND-DIR-ROLOVER
031034*    OR  MIR-CF-REG-FND-TRUST-TFR
031034*    OR  MIR-CF-REG-FND-ROTH-CNVR
031034*    OR  MIR-CF-REG-FND-RCHAR
031034*        MOVE LPGAL-MAX-ALLOC-TYP     TO WS-SUB
031034*    END-IF.
031034*
031034*1870-FILL-PGAL-TRXN-AMT-X.
031034*    EXIT.
015290/
015290*---------------------------
031034*1880-XEDIT-PGAL-ALLOC-AMT.
031034 1880-XEDIT-GAIN-ALLOC-AMT.
015290*---------------------------
015290
031034*    IF  MIR-CF-REG-FND-REG-CONTRB
031034*    OR  MIR-CF-REG-FND-DIR-ROLOVER
031034*    OR  MIR-CF-REG-FND-TRUST-TFR
031034*    OR  MIR-CF-REG-FND-ROTH-CNVR
031034*    OR  MIR-CF-REG-FND-RCHAR
031034*        CONTINUE
031034*    ELSE
031034*        EVALUATE TRUE
031034*           WHEN  RPOL-POL-STAT-BEFORE-SETL
031034*           WHEN  RPOL-POL-SUSPENDED
031034*              IF  (L1651-SUSP-AMT       NOT = ZEROS
031034*              OR  L1651-PRM-SUSP-AMT    NOT = ZEROS
031034*              OR  L1651-PDF-SUSP-AMT    NOT = ZEROS)
031034*              AND WS-TOT-ALLOC-AMT = ZEROS
015290*MSG:  UNABLE TO PROCESS PAYMENT, ALL PRINCIPAL AND GAIN
015290*      AMOUNT MUST BE ENTERED
031034*                  MOVE 'CS06510026'   TO WGLOB-MSG-REF-INFO
031034*                  PERFORM  0260-1000-GENERATE-MESSAGE
031034*                      THRU 0260-1000-GENERATE-MESSAGE-X
031034*                  SET WS-PLAR-ALLOC-ERR-OCCURRED TO TRUE
031034*                  GO TO 1880-XEDIT-PGAL-ALLOC-AMT-X
031034*              END-IF
031034*           WHEN OTHER
031034*              IF  WS-DEPOSIT-AMT     NOT = ZEROS
031034*              AND WS-TOT-ALLOC-AMT = ZEROS
015290*MSG:  UNABLE TO PROCESS PAYMENT, ALL PRINCIPAL AND GAIN
015290*      AMOUNT MUST BE ENTERED
031034*                  MOVE 'CS06510026'   TO WGLOB-MSG-REF-INFO
031034*                  PERFORM  0260-1000-GENERATE-MESSAGE
031034*                      THRU 0260-1000-GENERATE-MESSAGE-X
031034*                  SET WS-PLAR-ALLOC-ERR-OCCURRED TO TRUE
031034*                  GO TO 1880-XEDIT-PGAL-ALLOC-AMT-X
031034*              END-IF
031034*       END-EVALUATE
031034*    END-IF.
015290
015290
031034*    IF  RPOL-POL-STAT-BEFORE-SETL
031034*    OR  RPOL-POL-SUSPENDED
031034*        COMPUTE  WS-POL-PMT-AMT = WS-TOT-PMT-AMT
031034*                                - WS-OTH-PMT-AMT
031034*    ELSE
031034*        MOVE WS-DEPOSIT-AMT     TO WS-POL-PMT-AMT
031034*    END-IF.
031034*
031034*    IF  MIR-CF-REG-FND-REG-CONTRB
031034*    OR  MIR-CF-REG-FND-DIR-ROLOVER
031034*    OR  MIR-CF-REG-FND-TRUST-TFR
031034*    OR  MIR-CF-REG-FND-ROTH-CNVR
031034*    OR  MIR-CF-REG-FND-RCHAR
031034*        MOVE WS-POL-PMT-AMT     TO WS-TOT-ALLOC-AMT
031034*    END-IF.

031034*    IF  WS-TOT-ALLOC-AMT NOT = WS-POL-PMT-AMT
015290*MSG: UNABLE TO PROCESS PAYMENT, ENTERED PRINCIPAL AMOUNTS
015290*     AND GAIN AMOUNTS DO NOT BALANCE TO DEPOSIT/MISC
015290*     AND SUSPENSE AMOUNT
031034*        MOVE 'CS06510021'         TO WGLOB-MSG-REF-INFO
031034*        PERFORM  0260-1000-GENERATE-MESSAGE
031034*            THRU 0260-1000-GENERATE-MESSAGE-X
031034*        SET WS-PLAR-ALLOC-ERR-OCCURRED TO TRUE
031034*        GO TO 1880-XEDIT-PGAL-ALLOC-AMT-X
031034*    END-IF.
031034*
031034*    IF  MIR-CF-REG-FND-REG-CONTRB
031034*    OR  MIR-CF-REG-FND-DIR-ROLOVER
031034*    OR  MIR-CF-REG-FND-TRUST-TFR
031034*    OR  MIR-CF-REG-FND-ROTH-CNVR
031034*    OR  MIR-CF-REG-FND-RCHAR
031034*        IF  WS-DFLT-ALLOC-TYP-CD = SPACES
015290*MSG: UNABLE TO PROCESS PAYMENT, NO DEPOSIT DEFAULT IND. IN PLAR
015290*     FOR PLAN @1
031034*            MOVE 'CS06510022'         TO WGLOB-MSG-REF-INFO
031034*            MOVE L7800-PLAN-ID        TO WGLOB-MSG-PARM (01)
031034*            PERFORM  0260-1000-GENERATE-MESSAGE
031034*                THRU 0260-1000-GENERATE-MESSAGE-X
031034*            SET WS-ERROR-OCCURRED            TO TRUE
031034*            GO TO 1880-XEDIT-PGAL-ALLOC-AMT-X
031034*        ELSE
031034*            PERFORM
031034*                VARYING  WS-SUB FROM +1 BY +1
031034*                UNTIL  WS-SUB > LPGAL-MAX-ALLOC-TYP
031034*                   MOVE SPACES
031034*                     TO WS-HOLD-PGAL-ALLOC-TYP-CD (WS-SUB)
031034*                   MOVE ZEROS
031034*                     TO WS-HOLD-PGAL-TRXN-PRIN-AMT (WS-SUB)
031034*                   MOVE ZEROS
031034*                     TO WS-HOLD-PGAL-TRXN-GAIN-AMT (WS-SUB)
031034*            END-PERFORM
031034*            MOVE WS-DFLT-ALLOC-TYP-CD
031034*              TO WS-HOLD-PGAL-ALLOC-TYP-CD (1)
031034*            MOVE WS-POL-PMT-AMT
031034*              TO WS-HOLD-PGAL-TRXN-PRIN-AMT (1)
031034*            MOVE ZEROS
031034*              TO WS-HOLD-PGAL-TRXN-GAIN-AMT (1)
031034*        END-IF
031034*    END-IF.
031034*
031034     MOVE L1651-SUSP-AMT           TO LPGAC-SUSP-AMT.
031034     MOVE L1651-PRM-SUSP-AMT       TO LPGAC-PRM-SUSP-AMT.
031034     MOVE L1651-PDF-SUSP-AMT       TO LPGAC-PDF-SUSP-AMT.
031034     MOVE WS-DEPOSIT-AMT           TO LPGAC-DEPOSIT-AMT.
031034     MOVE WS-TOT-PMT-AMT           TO LPGAC-TOT-PMT-AMT.
031034     MOVE WS-OTH-PMT-AMT           TO LPGAC-OTH-PMT-AMT.
031034     MOVE MIR-CF-REG-FND-SRC-CD    TO LPGAC-REG-FND-SRC-CD.
031034     IF  WS-BUS-FCN-TRNANO
031034         SET LPGAC-PMT-TYP-TRNANO  TO TRUE
031034     END-IF.
031034
031034     PERFORM  PGAC-2000-POL-GAIN-XEDIT
031034         THRU PGAC-2000-POL-GAIN-XEDIT-X.
031034     MOVE LPGAC-RETRN-CD           TO WS-PGAC-RETRN-CD.
031034
031034*1880-XEDIT-PGAL-ALLOC-AMT-X.
031034 1880-XEDIT-GAIN-ALLOC-AMT-X.
015290     EXIT.
031034
031034*-----------------------
031034 1890-RGN-EXIT-FOR-GAIN.
031034*-----------------------
031034
031034     PERFORM  0316-1000-BUILD-PARM-INFO
031034         THRU 0316-1000-BUILD-PARM-INFO-X.
031034
031034     SET L0316-RGN-EXIT-GAIN-ALLOC-EDIT   TO TRUE.
031034
031034     MOVE RPOL-POL-CTRY-CD      TO L0316-CTRY-CD.
031034
031034     PERFORM  0316-1000-GET-RGN-EXIT-PGM
031034         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
031034
031034     IF  NOT L0316-RETRN-OK
031034*MSG: NO GAIN ALLOCATION EDIT REGIONAL EXIT FOUND FOR COUNTRY @1
031034         MOVE 'CS00000070'       TO WGLOB-MSG-REF-INFO
031034         MOVE L0316-CTRY-CD      TO WGLOB-MSG-PARM (1)
031034         PERFORM  0260-1000-GENERATE-MESSAGE
031034             THRU 0260-1000-GENERATE-MESSAGE-X
031034         SET WGLOB-RETURN-ERROR       TO TRUE
031034     END-IF.
031034
031034 1890-RGN-EXIT-FOR-GAIN-X.
031034     EXIT.
      /
015290*---------------------------
031034*1900-UPDATE-1035-ACB.
015290*---------------------------
015290
031034*    IF RPOL-POL-SUSPENDED
031034*       GO TO 1900-UPDATE-1035-ACB-X
031034*    END-IF.
031034*
031034*    PERFORM 0187-1000-BUILD-PARM-INFO
031034*       THRU 0187-1000-BUILD-PARM-INFO-X.
031034*    MOVE LPGAL-PLAR-PRCES-SW      TO L0187-PLAR-PRCES-SW.
031034*    MOVE LPGAL-PGAL-ALLOC-SW      TO L0187-PGAL-ALLOC-SW.
031034*
031034*    IF  LPGAL-PGAL-ALLOC-NOT-REQ
031034*        GO TO 1900-UPDATE-1035-ACB-X
031034*    END-IF.
031034*
031034*    PERFORM
031034*       VARYING  LPGAL-SUB FROM +1 BY +1
031034*          UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
031034*          MOVE LPGAL-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*               TO L0187-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
031034*          MOVE LPGAL-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*               TO L0187-PGAL-OPN-PRIN-AMT (LPGAL-SUB)
031034*          MOVE LPGAL-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*               TO L0187-PGAL-OPN-GAIN-AMT (LPGAL-SUB)
031034*          MOVE LPGAL-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*               TO L0187-PGAL-TRXN-PRIN-AMT (LPGAL-SUB)
031034*          MOVE LPGAL-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*               TO L0187-PGAL-TRXN-GAIN-AMT (LPGAL-SUB)
031034*          MOVE LPGAL-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*               TO L0187-PGAL-SURR-CHRG-AMT (LPGAL-SUB)
031034*          MOVE LPGAL-PGAL-WTHDR-SEQ-NUM  (LPGAL-SUB)
031034*               TO L0187-PGAL-WTHDR-SEQ-NUM  (LPGAL-SUB)
031034*          MOVE LPGAL-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*               TO L0187-PGAL-WTHDR-ORDR-CD (LPGAL-SUB)
031034*    END-PERFORM.
031034*
031034*    IF WS-BUS-FCN-REVERSAL
031034*        SET L0187-EVNT-PREM-REVRS    TO TRUE
031034*    ELSE
031034*        SET L0187-EVNT-PREMIUM       TO TRUE
031034*    END-IF.
031034*
031034*    PERFORM  0187-9500-UPDT-ACB
031034*        THRU 0187-9500-UPDT-ACB-X.
031034*
031034*1900-UPDATE-1035-ACB-X.
031034*    EXIT.
015290/
015290*---------------------------
031034*1920-CREATE-PENDING-PGAL.
015290*---------------------------
015290
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
031034*    MOVE RPOL-POL-ID                  TO L7800-POL-ID.
031034*    SET  L7800-TRXN-DPOS-BEFORE-SETL  TO TRUE.
031034*    SET  L7800-CALC-CV-NOT-REQ        TO TRUE.
031034*    SET  L7800-PRCES-NORMAL           TO TRUE.
031034*    SET  L7800-ORIGIN-POL-ENTRY       TO TRUE.
031034*    MOVE L1651-EFF-DT                 TO L7800-EFF-DT.
031034*
031034*    PERFORM  1921-FILL-PGAL-INFO
031034*        THRU 1921-FILL-PGAL-INFO-X
031034*        VARYING WS-SUB FROM +1 BY +1
031034*          UNTIL WS-SUB > LPGAL-MAX-ALLOC-TYP
031034*
031034*    PERFORM  7800-4000-PGAL-PRCES
031034*        THRU 7800-4000-PGAL-PRCES-X.
031034*
031034*    IF NOT L7800-RETRN-OK
031034*       SET L1651-RETRN-ERROR     TO TRUE
031034*    END-IF.
031034*
031034*1920-CREATE-PENDING-PGAL-X.
031034*    EXIT.
015290/
015290*---------------------------
031034*1921-FILL-PGAL-INFO.
015290*---------------------------
015290
031034*    IF  LPGAL-PGAL-ALLOC-TYP-CD    (WS-SUB) = SPACES
031034*        GO TO 1921-FILL-PGAL-INFO-X
031034*    END-IF.
031034*
031034*    MOVE LPGAL-PGAL-ALLOC-TYP-CD   (WS-SUB)
031034*         TO L7800-PGAL-ALLOC-TYP-CD  (WS-SUB).
031034*
031034*    MOVE ZEROS TO L7800-PGAL-OPN-PRIN-AMT (WS-SUB).
031034*    MOVE ZEROS TO L7800-PGAL-OPN-GAIN-AMT (WS-SUB).
031034*
031034*    MOVE LPGAL-PGAL-TRXN-PRIN-AMT  (WS-SUB)
031034*         TO L7800-PGAL-TRXN-PRIN-AMT (WS-SUB).
031034*
031034*    MOVE LPGAL-PGAL-TRXN-GAIN-AMT  (WS-SUB)
031034*         TO L7800-PGAL-TRXN-GAIN-AMT (WS-SUB).
031034*
031034*1921-FILL-PGAL-INFO-X.
031034*    EXIT.
015290/
025586*-----------------
025586 1930-VERIFY-PHST.
025586*-----------------
025586
025586     IF  L1651-PREM-AMT = ZERO
025586         GO TO 1930-VERIFY-PHST-X
025586     END-IF.
025586
025714*    MOVE RPOL-POL-ID            TO WPHST-POL-ID.
025714*
025714*    MOVE L1651-EFF-DT           TO L1660-INTERNAL-DATE.
025714*
025714*    PERFORM  1660-2000-CONVERT-INT-TO-INV
025714*        THRU 1660-2000-CONVERT-INT-TO-INV-X.
025714*
025714*    MOVE L1660-INVERTED-DATE    TO WPHST-PCHST-EFF-IDT-NUM.
025714*    MOVE ZEROS                  TO WPHST-PCHST-SEQ-NUM.
025714*    MOVE WPHST-KEY              TO WPHST-ENDBR-KEY.
025714*    MOVE 999                    TO WPHST-ENDBR-PCHST-SEQ-NUM.
025714     MOVE LOW-VALUE              TO WPHST-KEY.
025714     MOVE HIGH-VALUE             TO WPHST-ENDBR-KEY.
025714     MOVE RPOL-POL-ID            TO WPHST-POL-ID.
025714     MOVE RPOL-POL-ID            TO WPHST-ENDBR-POL-ID.
025714     MOVE ZEROS                  TO WPHST-PCHST-EFF-IDT-NUM-N.
025714     MOVE ZEROS                  TO WPHST-PCHST-SEQ-NUM.
025714     MOVE ALL '9'                TO WPHST-ENDBR-PCHST-EFF-IDT-NUM.
030054*    MOVE 999                    TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                                 TO WPHST-ENDBR-PCHST-SEQ-NUM.
025586
025586     PERFORM  PHST-1000-BROWSE
025586         THRU PHST-1000-BROWSE-X.
025586
025714*    PERFORM  PHST-2000-READ-NEXT
025714*        THRU PHST-2000-READ-NEXT-X.
025586
025714     PERFORM  PHST-2000-READ-NEXT
025714         THRU PHST-2000-READ-NEXT-X
025714         UNTIL NOT WPHST-IO-OK
025714         OR    RPHST-PCHST-STAT-ACTIVE.
025586
025586     SET WS-PHST-NOTFND          TO TRUE
025586     PERFORM
025586         UNTIL NOT WPHST-IO-OK
025586         OR    WS-PHST-FOUND
025586
025586          EVALUATE TRUE
025586              WHEN RPHST-POL-ACTV-TYP-ID = '1078'
025586              AND  RPHST-PCHST-STAT-ACTIVE
025714*
025714*                  SET WS-PHST-FOUND
025714*                                TO TRUE
025714*
025767              WHEN RPHST-POL-ACTV-TYP-ID = '1080'
025767              AND  RPHST-PCHST-STAT-ACTIVE
025767
025586              WHEN RPHST-POL-ACTV-TYP-ID = '1082'
025586              AND  RPHST-PCHST-STAT-ACTIVE
025714*
025714*                  SET WS-PHST-FOUND
025714*                                TO TRUE
025586
025586              WHEN RPHST-POL-ACTV-TYP-ID = '1084'
025586              AND  RPHST-PCHST-STAT-ACTIVE
025586
025586                   SET WS-PHST-FOUND
025586                                 TO TRUE
025586
025586              WHEN OTHER
025586                   PERFORM  PHST-2000-READ-NEXT
025586                       THRU PHST-2000-READ-NEXT-X
025586
025586          END-EVALUATE
025586
025586     END-PERFORM.
025586
025586     PERFORM  PHST-3000-END-BROWSE
025586         THRU PHST-3000-END-BROWSE-X.
025586
025586     IF  WS-PHST-FOUND
025586
025714         IF RPHST-PCHST-EFF-DT  NOT =  L1651-EFF-DT
025714*MSG : CANNOT REVERSE PREMIUM, MOST RECENT ACTIVE PREMIUM PAYMENT
025714*      IS FOUND ON @1
025714             MOVE 'CS06510089'      TO WGLOB-MSG-REF-INFO
025714             MOVE RPHST-PCHST-EFF-DT TO L1640-INTERNAL-DATE
025714             PERFORM  1640-2000-INTERNAL-TO-EXT
025714                 THRU 1640-2000-INTERNAL-TO-EXT-X
025714             MOVE L1640-EXTERNAL-DATE  TO WGLOB-MSG-PARM (1)
025714             PERFORM  0260-1000-GENERATE-MESSAGE
025714                 THRU 0260-1000-GENERATE-MESSAGE-X
025714             SET WS-ERROR-OCCURRED  TO TRUE
025714             GO TO 1930-VERIFY-PHST-X
025714         END-IF

029060*        MOVE RPHST-PCHST-NEW-VALU-TXT (3:18)
029060*                                TO L0280-INPUT-DATA
029060*        MOVE 18                 TO L0280-INPUT-SIZE
029060*        MOVE 15                 TO L0280-LENGTH
029060         MOVE RPHST-PCHST-NEW-VALU-TXT  TO WS-VALU-EDIT-TEXT
029060         MOVE WS-VALU-EDIT-AMT          TO L0280-INPUT-DATA
029060         MOVE LENGTH OF WS-VALU-EDIT-AMT TO L0280-INPUT-SIZE
025586         MOVE 2                  TO L0280-PRECISION
029060         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
029060                                L0280-PRECISION - 1
025586         PERFORM  0280-1000-NUMERIC-EDIT
025586             THRU 0280-1000-NUMERIC-EDIT-X
025586         IF  NOT L0280-OK
025714*MSG : CANNOT REVERSE PREMIUM, INVALID AMOUNT FOUND IN POLICY
025714*      CHANGE HISTIRY RECORD ON @1
025714             MOVE 'CS06510090'       TO WGLOB-MSG-REF-INFO
025714             MOVE RPHST-PCHST-EFF-DT TO L1640-INTERNAL-DATE
025714             PERFORM  1640-2000-INTERNAL-TO-EXT
025714                 THRU 1640-2000-INTERNAL-TO-EXT-X
025714             MOVE L1640-EXTERNAL-DATE  TO WGLOB-MSG-PARM (1)
025714             PERFORM  0260-1000-GENERATE-MESSAGE
025714                 THRU 0260-1000-GENERATE-MESSAGE-X
025586             SET WS-ERROR-OCCURRED
025586                                 TO TRUE
025586             GO TO 1930-VERIFY-PHST-X
025586         END-IF
025586         IF L0280-OUTPUT-DOLLAR NOT =  L1651-PREM-AMT
025714*MSG : CANNOT REVERSE PREMIUM, PREMIUM @1 FOUND IN POLICY CHANGE
025714*      HISTIRY ON @2 NOT EQUAL ENTERED AMOUNT
025714             MOVE 'CS06510091'       TO WGLOB-MSG-REF-INFO
025714             MOVE L0280-OUTPUT-DOLLAR TO L0290-INPUT-V02
025714             MOVE 2                   TO L0290-PRECISION
025714             MOVE 18                  TO L0290-MAX-OUT-LEN
025714             SET L0290-SIGN-DISPLAY   TO TRUE
025714             SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
025714             PERFORM  0290-1000-NUMERIC-FORMAT
025714                 THRU 0290-1000-NUMERIC-FORMAT-X
025714             MOVE L0290-OUTPUT-DATA  TO WGLOB-MSG-PARM (1)
025714             MOVE RPHST-PCHST-EFF-DT TO L1640-INTERNAL-DATE
025714             PERFORM  1640-2000-INTERNAL-TO-EXT
025714                 THRU 1640-2000-INTERNAL-TO-EXT-X
025714             MOVE L1640-EXTERNAL-DATE  TO WGLOB-MSG-PARM (2)
025714             PERFORM  0260-1000-GENERATE-MESSAGE
025714                 THRU 0260-1000-GENERATE-MESSAGE-X
025586             SET WS-ERROR-OCCURRED
025586                                 TO TRUE
025586             GO TO 1930-VERIFY-PHST-X
025586         END-IF

025714         MOVE RPHST-PCHST-SEQ-NUM   TO L1651-PREM-DEPSQ
025586     ELSE
025714*MSG : CANNOT REVERSE PREMIUM, NO ACTIVE POLICY CHANGE HISTORY
025714*      RECORD IS FOUND ON @1
025714         MOVE 'CS06510088'       TO WGLOB-MSG-REF-INFO
025714         MOVE L1651-EFF-DT       TO L1640-INTERNAL-DATE
025714         PERFORM  1640-2000-INTERNAL-TO-EXT
025714             THRU 1640-2000-INTERNAL-TO-EXT-X
025714         MOVE L1640-EXTERNAL-DATE  TO WGLOB-MSG-PARM (1)
025714         PERFORM  0260-1000-GENERATE-MESSAGE
025714             THRU 0260-1000-GENERATE-MESSAGE-X
025586         SET WS-ERROR-OCCURRED   TO TRUE
025586     END-IF.
025586
025586 1930-VERIFY-PHST-X.
025586     EXIT.

013697*--------------------
031034*7100-GET-CNTRXN-INFO.
013697*--------------------
013697
031034*    PERFORM 0316-1000-BUILD-PARM-INFO
031034*       THRU 0316-1000-BUILD-PARM-INFO-X.
031034*
031034*    SET  L0316-RGN-EXIT-CNTRB-XCPT TO TRUE.
031034*    MOVE RPOL-POL-CTRY-CD          TO L0316-CTRY-CD.
031034*
031034*    PERFORM  0316-1000-GET-RGN-EXIT-PGM
031034*        THRU 0316-1000-GET-RGN-EXIT-PGM-X.
031034*
031034*    IF  NOT L0316-RETRN-OK
031034*        SET  WS-ERROR-OCCURRED    TO TRUE
013697*MSG: 'NO CONTRIBUTION TRANSACTION REGIONAL EXIT FOUND
013697*      FOR COUNTRY @1'
031034*        MOVE 'CS06510027'        TO WGLOB-MSG-REF-INFO
031034*        MOVE L0316-CTRY-CD       TO WGLOB-MSG-PARM (1)
031034*        PERFORM  0260-1000-GENERATE-MESSAGE
031034*            THRU 0260-1000-GENERATE-MESSAGE-X
031034*        GO TO 7100-GET-CNTRXN-INFO-X
031034*    END-IF.
031034*
031034*    IF  L0316-RGN-EXIT-STAT-ACTV
031034*        CONTINUE
031034*    ELSE
031034*        INITIALIZE LCNEX-OUTPUT-PARM-INFO
031034*        GO TO 7100-GET-CNTRXN-INFO-X
031034*    END-IF.
031034*
031034*    PERFORM  CNEX-1000-BUILD-PARM-INFO
031034*        THRU CNEX-1000-BUILD-PARM-INFO-X.
031034*
031034*    SET  LCNEX-PRCES-TYP-EDIT-ONLY TO TRUE.
031034*    MOVE MIR-CF-REG-FND-SRC-CD     TO LCNEX-TRXN-FND-SRC-CD.
031034*
031034*    PERFORM  CNEX-1000-DFLT-CNTRXN-DPOS
031034*        THRU CNEX-1000-DFLT-CNTRXN-DPOS-X.
031034*
031034*    IF  LCNEX-RETRN-OK
031034*        CONTINUE
031034*    ELSE
031034*        SET  WS-ERROR-OCCURRED     TO TRUE
031034*    END-IF.
031034*
031034*7100-GET-CNTRXN-INFO-X.
031034*    EXIT.
013697/
       8900-INIT-ENTRY-LINE-FIELDS.

           MOVE ZERO              TO HOLD-DR1.
           MOVE ZERO              TO HOLD-CR1.
           MOVE ZERO              TO HOLD-DR2.
           MOVE ZERO              TO HOLD-CR2.
           INITIALIZE L1651-ELNR-TXT-INFO.
           INITIALIZE L1651-ELNR-AMT-INFO.

       8900-INIT-ENTRY-LINE-FIELDS-X.
           EXIT.
      /
      /
       9300-SETUP-MSIN-REFERENCE.
      *
            MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
031034     PERFORM  0182-0000-INIT-PARM-INFO
031034         THRU 0182-0000-INIT-PARM-INFO-X.
031034
031034*    PERFORM  0187-0000-INIT-PARM-INFO
031034*        THRU 0187-0000-INIT-PARM-INFO-X.
031034*
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0316-0000-INIT-PARM-INFO
025970         THRU 0316-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0652-0000-INIT-PARM-INFO
025970         THRU 0652-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0760-0000-INIT-PARM-INFO
025970         THRU 0760-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1651-0000-INIT-PARM-INFO
025970         THRU 1651-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4180-0000-INIT-PARM-INFO
025970         THRU 4180-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  7800-0000-INIT-PARM-INFO
031034*        THRU 7800-0000-INIT-PARM-INFO-X.
031034*
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
031034*    PERFORM  CNEX-0000-INIT-PARM-INFO
031034*        THRU CNEX-0000-INIT-PARM-INFO-X.
031034
031034     PERFORM  PGAC-0000-INIT-PARM-INFO
031034         THRU PGAC-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE PRINT-TA-LINE.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT TO TRUE.
031034     SET WS-MAX-ALLOC-TYP-DEFAULT TO TRUE.
031034     SET WS-PGAC-RETRN-OK  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
031034 COPY CCPS0182.
016503 COPY CCPS0289.
      /
       COPY CCPS0652.
      /
016108 COPY CCPS0985.
016108/
       COPY CCPS1651.
      /
       COPY CCPS2430.
      /
557696 COPY CCPS4180.
557696/
016503 COPY CCPS4780.
      /
       COPY CCPS5400.
015290/
031034*COPY CCPS7800.
031034*
031034*COPY CCPSCNEX.
013697/
021930*COPY CCPSPGAI.
021930*
031034*COPY CCPSPGAL.
015290/
       COPY NCPPCVGR.
       COPY NCPPCVGS.
      /
013697 COPY XCPS0316.
013697/
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE COPYBOOKS                                           *
      ****************************************************************
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
       COPY CCPL0620.
      /
031034*COPY CCPS0187.
031034*COPY CCPL0187.
015290*
018764*COPY CCCL0201.
025970 COPY CCPS0201.
018764 COPY CCPL0201.
      /
018764*COPY CCCL0289.
018764 COPY CCPL0289.
      /
018764*COPY CCCL0652.
018764 COPY CCPL0652.
      /
018764*COPY NCCL0760.
025970 COPY NCPS0760.
018764 COPY NCPL0760.
      /
018764*COPY CCCL1651.
018764 COPY CCPL1651.
      /
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108/
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      /
018764*COPY CCCL4180.
018764 COPY CCPL4180.
557696/
018764*COPY CCCL4780.
018764 COPY CCPL4780.
      /
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
031034*COPY CCPLCNEX.
031034 COPY CCPSPGAC.
031034 COPY CCPLPGAC.
013697/
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
013697 COPY XCPL0316.
013697/
031034*COPY CCPL7800.
031034*
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
025714*COPY XCPL1660.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
      *
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
025586 COPY CCPBPHST.
      /
014221 COPY CCPNPOL.
       COPY CCPUPOL.
      /
021930*COPY NCPNDALT.
021930*COPY NCPCDALG.
021930*COPY NCPADALG.
018763*COPY XCPNDMAD.
      ****************************************************************
      * ERROR HANDLING ROUTINES                                      *
      ****************************************************************

557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      /
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM0651                     **
      *****************************************************************
