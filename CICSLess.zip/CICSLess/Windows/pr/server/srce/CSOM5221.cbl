      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5221.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5221                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE CRCD TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014221**  6.2       LOGICAL LOCKING                                  **
016395**  6.2       CREATES CREDIT CARD INFORMATION IN TABLE CRCD    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5221'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-TKEY                     PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                    VALUE '5220'.
025970     05  WS-MAX-CRCD                      PIC S9(4) BINARY.
025970         88  WS-MAX-CRCD-DEFAULT          VALUE +9.
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-CREATE            VALUE '5221'.
025970*    05  WS-TWRK-TKEY                     PIC X(04) VALUE '5220'.
           05  WS-CRC                           PIC S9(4) BINARY.
025970*    05  WS-MAX-CRCD           VALUE +9   PIC S9(4) BINARY.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
021930*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
       COPY CCFWCRCD.
       COPY CCFRCRCD.
       COPY CCFRPCOM.
       COPY CCFWPCOM.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
021930*COPY XCWLDTLK.
018764*COPY XCWLPTR.
021930*COPY CCWLPGA.
021930*COPY XCWL0280.
021930*COPY XCWL1640.
       COPY XCWL0315.
014221 COPY XCWL8090.
       COPY CCWL0304.
021930*COPY CCWL0620.
021930*COPY CCWL0063.
021930*COPY CCWL5020.
       COPY NCWLCDGT.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5221.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

025970*    SET MIR-RETRN-OK
025970*      TO TRUE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5221'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------
      *
      *  THE RECORD SHOULD NOT EXIST ON A CREATE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  CRCD-1000-READ
               THRU CRCD-1000-READ-X.

           IF  WCRCD-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE WCRCD-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CREATE-X
           END-IF.
      *
      *  CREATE THE NEW RECORD AND AUDIT THE CHANGE
      *
           PERFORM  CRCD-1000-CREATE
               THRU CRCD-1000-CREATE-X.

           PERFORM  CRCD-1000-WRITE
               THRU CRCD-1000-WRITE-X.

           IF WCRCD-IO-OK
      *MSG  CREDIT CARD RECORD CREATED
               MOVE 'CS52210005'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

014221     PERFORM  CRCD-1000-READ-TWRK-TS
014221         THRU CRCD-1000-READ-TWRK-TS-X.

       2000-CREATE-X.
           EXIT.
      /

      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------


           PERFORM  4110-EDIT-CRC-TYP-CD
               THRU 4110-EDIT-CRC-TYP-CD-X.

           PERFORM  4120-EDIT-CRC-ID
               THRU 4120-EDIT-CRC-ID-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /


      *------------------
       4110-EDIT-CRC-TYP-CD.
      *------------------


           IF  MIR-CRC-TYP-CD = SPACES
      *MSG: CREDIT CARD TYPE MUST BE ENTERED
               MOVE WCRCD-CRC-TYP-CD
                 TO WGLOB-MSG-PARM (1)
               MOVE 'CS52210003'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4110-EDIT-CRC-TYP-CD-X
           END-IF.

           MOVE MIR-CRC-TYP-CD TO WEDIT-ETBL-VALU-ID.

           PERFORM  CHGT-1000-EDIT
               THRU CHGT-1000-EDIT-X.

           IF  WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG:  ERROR - INVALID CREDIT CARD TYPE ENTERED
               MOVE 'CS52210001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR      TO TRUE
               MOVE HIGH-VALUES              TO MIR-CRC-TYP-CD
           END-IF.


       4110-EDIT-CRC-TYP-CD-X.
           EXIT.
      /

      *-------------------------
       4120-EDIT-CRC-ID.
      *-------------------------

           IF  MIR-CRC-ID = SPACES
      *MSG: CREDIT CARD ID MUST BE ENTERED
               MOVE 'CS52210004'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4120-EDIT-CRC-ID-X
           END-IF.

           IF MIR-CRC-ID = ZEROES
      *MSG: CREDIT CARD NUMBER CANNOT BE ZEROS
               MOVE 'CS52210006'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4120-EDIT-CRC-ID-X
           END-IF.


           PERFORM PCOM-1000-READ
               THRU PCOM-1000-READ-X.
           IF RPCOM-CO-CRC-CHK-DGT
               CONTINUE
           ELSE
              GO TO 4120-EDIT-CRC-ID-X
           END-IF.

      **** THIS ROUTINE CALLS THE LUHN ROUTINE

           PERFORM  0304-1000-BUILD-PARM-INFO
               THRU 0304-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CRC-ID  TO L0304-CRC-ID.

      * CHECK USER EXIT TABLE TO DETERMINE WHETHER USER EXIT
      * PROGRAM IS REQUIRED TO APPEND OR REPLACE THE CREDIT
      * CARD CHECK

           PERFORM  4200-GET-EXIT-PGM-ID
               THRU 4200-GET-EXIT-PGM-ID-X.

      * IF ERROR IN ACCESS MODULE, STOP PROCESSING

           IF  L0315-RETRN-OK
           OR  L0315-RETRN-NOT-FOUND
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR         TO  TRUE
               GO TO 4120-EDIT-CRC-ID-X
           END-IF.

           IF  L0315-RETRN-NOT-FOUND
               PERFORM  0304-1000-DO-VALIDATE
                   THRU 0304-1000-DO-VALIDATE-X
           ELSE
              EVALUATE TRUE
                 WHEN  L0315-INVO-TYP-BEFORE
                    PERFORM  4300-USER-EXIT
                        THRU 4300-USER-EXIT-X
                    PERFORM  0304-1000-DO-VALIDATE
                        THRU 0304-1000-DO-VALIDATE-X
                 WHEN  L0315-INVO-TYP-AFTER
                    PERFORM  0304-1000-DO-VALIDATE
                        THRU 0304-1000-DO-VALIDATE-X
                    PERFORM  4300-USER-EXIT
                        THRU 4300-USER-EXIT-X
                 WHEN  L0315-INVO-TYP-REPLACE
                    PERFORM  4300-USER-EXIT
                        THRU 4300-USER-EXIT-X
                 WHEN  L0315-INVO-TYP-INACTIVE
                    PERFORM  0304-1000-DO-VALIDATE
                        THRU 0304-1000-DO-VALIDATE-X
              END-EVALUATE
           END-IF.

           IF L0315-INVO-TYP-REPLACE
              CONTINUE
           ELSE
             IF L0304-RETRN-NOT-VALID
      **** MSG:LUHN FAILED
               MOVE 'CS52210002' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
             END-IF
           END-IF.

       4120-EDIT-CRC-ID-X.
           EXIT.
      /
      *--------------------------
       4200-GET-EXIT-PGM-ID.
      *--------------------------

      * CHECK USER EXIT TABLE TO DETERMINE WHETHER USER EXIT
      * PROGRAM IS REQUIRED TO APPEND OR REPLACE THE CREDIT
      * CARD CHECK

           PERFORM  0315-1000-BUILD-PARM-INFO
               THRU 0315-1000-BUILD-PARM-INFO-X.

           SET  L0315-USER-EXIT-CRC-CHK-DGT TO TRUE.

           PERFORM  0315-1000-GET-USER-EXIT-PGM
               THRU 0315-1000-GET-USER-EXIT-PGM-X.

       4200-GET-EXIT-PGM-ID-X.
           EXIT.
      *
      *-------------------
       4300-USER-EXIT.
      *-------------------

      * BUILD PARM AREA

           PERFORM  CDGT-1000-BUILD-PARM-INFO
               THRU CDGT-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CRC-TYP-CD  TO LCDGT-CRC-TYP-CD.
           MOVE MIR-CRC-ID      TO LCDGT-CRC-ID.

      * CALL THE USER EXIT PROGRAM

           PERFORM  CDGT-1000-VALIDATE-CRC
               THRU CDGT-1000-VALIDATE-CRC-X.

      * CHECK RETRUN CODE

            IF NOT LCDGT-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO  TRUE
               GO TO 4300-USER-EXIT-X
            END-IF.

       4300-USER-EXIT-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WCRCD-KEY.
           MOVE MIR-CRC-TYP-CD         TO WCRCD-CRC-TYP-CD.
           MOVE MIR-CRC-ID             TO WCRCD-CRC-ID.

       7000-BUILD-KEYS-X.
           EXIT.


      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0304-0000-INIT-PARM-INFO
025970         THRU 0304-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0315-0000-INIT-PARM-INFO
025970         THRU 0315-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  CDGT-0000-INIT-PARM-INFO
025970         THRU CDGT-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970     SET WS-MAX-CRCD-DEFAULT     TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID
025970       TO WS-BUS-FCN-ID.
025970
025970     SET MIR-RETRN-OK
025970       TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CRCD
014221                         '$VAR2' BY 'CRCD'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY CCCL0304.
018764 COPY CCPL0304.
021930*COPY CCPL0620.
025970 COPY XCPS8090.
       COPY XCPS0315.
018764*COPY XCCL0315.
018764 COPY XCPL0315.
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
021930*COPY XCPL0280.
021930*COPY XCPL1640.
       COPY CCPS0304.
       COPY NCPSCDGT.
018764*COPY NCCLCDGT.
018764 COPY NCPLCDGT.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPACRCD.
021930*COPY CCPAPCOM.
       COPY CCPNPCOM.
       COPY CCPNCRCD.
       COPY CCPCCRCD.
014221 COPY CCPUCRCD.
       COPY CCPNEDIT.
       COPY CCPECHGT.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM5221                     **
      *****************************************************************
