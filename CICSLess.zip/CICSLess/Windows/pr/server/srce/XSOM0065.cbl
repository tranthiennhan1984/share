      *****************************************************************
      **  MEMBER :  XSOM0065                                         **
      **  REMARKS:  PROCESS THE APPLICATION SIGN ON TRANSACTION      **
      **            FROM A TRUSTED CLIENT                            **
      **                                                             **
      **            THIS MODULE PERFORMS THE INGENIUM SIGN-ON        **
      **            BUSINESS FUNCTION WITH THE REQUIREMENT THAT      **
      **            ALL INFORMATION ABOUT THE USER, INCLUDING        **
      **            THE USER'S ID BE PASSED IN AS DATA TO THE PROCESS**
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
019474**  6.3       PATHFINDER 1.3 UPGRADE                           **
020127**  6.3.1     PATHFINDER 2.0 UPGRADE                           **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
020846**  6.5       MULTIPLE SIGN-ON SESSIONS                        **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
033436**  7.0       MULTIPLE SIMULTANEOUS SIGN-ON                    **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
033127**  7.1       LDAP SIGN ON                                     **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM0065.

       COPY XCWWCRHT.

      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------
      *
      *--------------
       DATA DIVISION.
      *--------------
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM0065'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.


       01  WS-WORKING-STORAGE.
020846     05  WS-USEU-CURSOR                PIC X(01).
020846         88  WS-USEU-CURSOR-OPEN       VALUE 'Y'.
020846         88  WS-USEU-CURSOR-CLOSED     VALUE 'N'.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID          VALUE '0065'.
               88  WS-BUS-FCN-LOGIN          VALUE '0065'.

           05  SUB1                         PIC S9(4)  VALUE ZERO
                                            BINARY.
           05  SUB2                         PIC S9(4)  VALUE ZERO
                                            BINARY.
           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-ERROR-NO              VALUE 'N'.
           05  WS-HOLD-USES-REC-INFO        PIC X(220).
           05  WS-PROCESS-DATE              PIC X(10).
      /
           05  WS-DV-APPL-STAT-CD           PIC X(01).
               88  WS-DV-APPL-STAT-ACTIVE   VALUE '1'.
               88  WS-DV-APPL-STAT-STOPPED  VALUE '2'.
               88  WS-DV-APPL-STAT-INACTIVE VALUE '3'.
               88  WS-DV-APPL-STAT-UNKNOWN  VALUE '9'.

           05  WS-USER-SESN-CTRY-CD         PIC X(02).
           05  WS-USER-SESN-CRCY-CD         PIC X(02).
           05  WS-USER-SESN-PRCES-DT        PIC X(10).
      /
       COPY XCWL1640.
       COPY XCWL8095.
      /
       COPY XCWL0020.
      /
       COPY XCFWAPPL.
       COPY XCFRAPPL.
      /
       COPY XCFWASCL.
       COPY XCFRASCL.
      /
       COPY XCFWUSCL.
       COPY XCFRUSCL.
      /
       COPY XCFWUSEU.
       COPY XCFWUSES.
       COPY XCFRUSES.
      /
       COPY XCFWXTAB.
       COPY XCFRXTAB.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL1670.
      /
       COPY XCWL1680.
      /
       COPY XCWWWKDT.
      /
021930*COPY XCWL0005.
021930*
       COPY XCWL2490.
      /
      *---------------
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *---------------

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM0065.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *-------------
       0000-MAINLINE.
      *-------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

020846     PERFORM  9990-INIT-WORKING-STORAGE
020846         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.
020846
034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

020846*    PERFORM  9300-SETUP-MSIN-REFERENCE
020846*        THRU 9300-SETUP-MSIN-REFERENCE-X.
020846*
020846*    MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
020846*    SET  MIR-RETRN-OK                   TO TRUE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LOGIN
                    PERFORM  2000-PROCESS-LOGIN
                        THRU 2000-PROCESS-LOGIN-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM0065'            TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       2000-PROCESS-LOGIN.
      *------------------

           SET WS-ERROR-NO                     TO TRUE.

           PERFORM  7000-LOGIN-EDITS
               THRU 7000-LOGIN-EDITS-X.

           IF WS-ERROR-FOUND
               PERFORM  9100-DISPLAY-THIS-APPL
                   THRU 9100-DISPLAY-THIS-APPL-X
               GO TO 2000-PROCESS-LOGIN-X
           END-IF.

           MOVE MIR-USER-ID                TO WUSEU-USER-ID.

020846     MOVE LOW-VALUES                 TO WUSEU-CO-ID.
020846     MOVE MIR-USER-ID                TO WUSEU-ENDBR-USER-ID.
020846     MOVE HIGH-VALUES                TO WUSEU-ENDBR-CO-ID.
020846*    PERFORM  USEU-1000-READ
020846*        THRU USEU-1000-READ-X.
020846*
020846*    IF  WUSEU-IO-OK
020846*        MOVE RUSES-CO-ID            TO WGLOB-COMPANY-CODE
020846*        SET WUSES-IO-OK             TO TRUE
020846*        IF  NOT RUSES-USER-SESN-STAT-API-CONN
020846*            PERFORM  2010-DELETE-OLD-USES
020846*                THRU 2010-DELETE-OLD-USES-X
020846*        ELSE
020846*            PERFORM  2020-REESTABLISH-USES-RECORD
020846*                THRU 2020-REESTABLISH-USES-RECORD-X
020846*        END-IF
020846*    END-IF.

020846     SET WS-USEU-CURSOR-OPEN TO TRUE.
020846
020846     PERFORM  USEU-1000-BROWSE
020846         THRU USEU-1000-BROWSE-X.
020846
020846     PERFORM  USEU-2000-READ-NEXT
020846         THRU USEU-2000-READ-NEXT-X
020846        UNTIL RUSES-USER-SESN-ID = WGLOB-USER-SESN-ID
020846        OR    WUSEU-IO-EOF.
020846
020846     IF  WUSEU-IO-OK
020846         SET WUSES-IO-OK             TO TRUE
020846         IF  RUSES-CO-ID         NOT =  MIR-CO-ID
020846         AND RUSES-USER-SESN-STAT-API-CONN
020846
020846*MSG: USERID CURRENTLY SIGNED ON ANOTHER COMPANY
020846             MOVE 'XS00650023'       TO WGLOB-MSG-REF-INFO
020846             PERFORM  0260-1000-GENERATE-MESSAGE
020846                 THRU 0260-1000-GENERATE-MESSAGE-X
020846             PERFORM  9100-DISPLAY-THIS-APPL
020846                 THRU 9100-DISPLAY-THIS-APPL-X
020846             GO TO 2000-PROCESS-LOGIN-X
020846         END-IF
020846     END-IF.
020846
020846     IF  WUSEU-IO-OK
020846         IF  NOT RUSES-USER-SESN-STAT-API-CONN
020846             PERFORM  2010-DELETE-OLD-USES
020846                 THRU 2010-DELETE-OLD-USES-X
020846         ELSE
020846            PERFORM  2020-REESTABLISH-USES-RECORD
020846                THRU 2020-REESTABLISH-USES-RECORD-X
020846         END-IF
020846     END-IF.
020846
020846     PERFORM  USEU-3000-END-BROWSE
020846         THRU USEU-3000-END-BROWSE-X.
020846     SET WS-USEU-CURSOR-CLOSED TO TRUE.

           MOVE RUSCL-SECUR-CNFD-ACCS-CD   TO WGLOB-SECUR-CNFD-ACCS-CD.
           MOVE RUSCL-SECUR-LVL-CD         TO WGLOB-SECUR-LVL-CD.
           MOVE MIR-BR-ID                  TO WGLOB-USER-BRANCH-CODE.
           MOVE MIR-USER-RPT-DSTRB-CD      TO WGLOB-USER-RPT-DSTRB-CD.

           PERFORM  2490-1000-BUILD-PARM-INFO
               THRU 2490-1000-BUILD-PARM-INFO-X.

           MOVE 'XSDU1640'                TO L2490-TXT-SRC-ID.
           MOVE '00001'                   TO L2490-TXT-SRC-REF-ID.

           PERFORM  2490-1000-RETRIEVE-TEXT
               THRU 2490-1000-RETRIEVE-TEXT-X.

           IF L2490-RETRN-OK
               MOVE L2490-TXT-STR-TXT     TO WGLOB-MOS-ABBR-TXT
           ELSE
               MOVE 'JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC'
                                          TO WGLOB-MOS-ABBR-TXT
           END-IF.

           PERFORM 9500-CHECK-ASCL
              THRU 9500-CHECK-ASCL-X.

           IF WS-DV-APPL-STAT-ACTIVE
           OR RUSES-USER-SESN-STAT-NOT-CONN
               PERFORM 2040-COMPLETE-SIGNON
                  THRU 2040-COMPLETE-SIGNON-X
           ELSE
020846*        IF WUSEU-IO-NOT-FOUND
020846         IF WUSEU-IO-EOF
                   PERFORM 2050-SIGNON-NOT-CONNECT
                      THRU 2050-SIGNON-NOT-CONNECT-X
               END-IF
           END-IF.

           PERFORM 9100-DISPLAY-THIS-APPL
              THRU 9100-DISPLAY-THIS-APPL-X.

           MOVE RUSES-USER-SESN-ID       TO WUSES-USER-SESN-ID.
           PERFORM USES-1000-READ-FOR-UPDATE
              THRU USES-1000-READ-FOR-UPDATE-X.
           IF WUSES-IO-OK
              MOVE L0020-ONLN-DT-CHNG-TIME   TO RUSES-ONLN-DT-CHNG-TIME
              MOVE L0020-CHNG-LEAD-TIME-DUR  TO RUSES-CHNG-LEAD-TIME-DUR
              MOVE WGLOB-SECUR-CNFD-ACCS-CD  TO RUSES-SECUR-CNFD-ACCS-CD
              MOVE WGLOB-SECUR-LVL-CD        TO RUSES-SECUR-LVL-CD
              MOVE WGLOB-SECUR-CLAS-ID       TO RUSES-SECUR-CLAS-ID
              MOVE WGLOB-USER-BRANCH-CODE    TO RUSES-BR-ID
              MOVE WGLOB-USER-RPT-DSTRB-CD   TO RUSES-RPT-DSTRB-CD
              MOVE WGLOB-DT-FRMT-CD          TO RUSES-CTRY-DT-FRMT-CD
              MOVE WGLOB-DT-SEPARATOR-SYMBL  TO RUSES-CTRY-DT-SPRT-CD
              MOVE WGLOB-DT-ZERO-SUPRES-IND  TO RUSES-CTRY-LEAD-ZERO-IND
              MOVE WGLOB-CRCY-SYMBL          TO RUSES-CRCY-SYMBL-CD
              MOVE WGLOB-CRCY-POSN-CD        TO RUSES-CRCY-PLACE-CD
              MOVE WGLOB-SIGN-POSN-CD        TO RUSES-CRCY-NEG-PLACE-CD
              MOVE WGLOB-DCML-SYMBL          TO RUSES-CRCY-DCML-SPRT-CD
              MOVE WGLOB-THOUSANDS-SYMBL     TO RUSES-CRCY-THOU-SPRT-CD
033127        MOVE WGLOB-CRCY-SCALE-QTY      TO RUSES-CRCY-SCALE-QTY
              PERFORM USES-2000-REWRITE
                 THRU USES-2000-REWRITE-X
           END-IF.


       2000-PROCESS-LOGIN-X.
           EXIT.

      *--------------------
       2010-DELETE-OLD-USES.
      *--------------------

           MOVE RUSES-USER-SESN-ID        TO WUSES-USER-SESN-ID.
           PERFORM  USES-1000-READ-FOR-UPDATE
               THRU USES-1000-READ-FOR-UPDATE-X.
           IF WUSES-IO-OK
               PERFORM  USES-1000-DELETE
                   THRU USES-1000-DELETE-X
               INITIALIZE RUSES-REC-INFO
           END-IF.
           SET WUSES-IO-NOT-FOUND         TO TRUE.

       2010-DELETE-OLD-USES-X.
           EXIT.
      /
      *----------------------------
       2020-REESTABLISH-USES-RECORD.
      *----------------------------

           IF  RUSES-USER-SESN-ID NOT = WGLOB-USER-SESN-ID
               PERFORM  2021-CREATE-NEW-USES
                   THRU 2021-CREATE-NEW-USES-X
           END-IF.
020846*
020846*    MOVE RUSES-USER-ID                  TO L8095-USER-ID.
020846*    PERFORM  8095-2000-CLEANUP-TWRK
020846*        THRU 8095-2000-CLEANUP-TWRK-X.

       2020-REESTABLISH-USES-RECORD-X.
           EXIT.

      *--------------------
       2021-CREATE-NEW-USES.
      *--------------------

      *** MSG:  USES RECORD RE-ESTABLISHED
020846*    MOVE 'XS00650020'                   TO WGLOB-MSG-REF-INFO.
020846*    PERFORM  0260-1000-GENERATE-MESSAGE
020846*        THRU 0260-1000-GENERATE-MESSAGE-X.

020846*    MOVE RUSES-REC-INFO                 TO WS-HOLD-USES-REC-INFO.
020846*    MOVE RUSES-KEY                      TO WUSES-KEY.
020846*    PERFORM  USES-1000-READ-FOR-UPDATE
020846*        THRU USES-1000-READ-FOR-UPDATE-X.

020846*    IF WUSES-IO-OK
020846*        PERFORM  USES-1000-DELETE
020846*            THRU USES-1000-DELETE-X
020846*    END-IF.

           MOVE WGLOB-USER-SESN-ID             TO WUSES-USER-SESN-ID.
           PERFORM  USES-1000-CREATE
               THRU USES-1000-CREATE-X.

           MOVE WS-HOLD-USES-REC-INFO          TO RUSES-REC-INFO.
           SET RUSES-USER-SESN-STAT-API-CONN   TO TRUE.

           MOVE WUSES-KEY                      TO RUSES-KEY.
033436**   PERFORM  USES-1000-WRITE
033436**       THRU USES-1000-WRITE-X.
033436     PERFORM  9900-WRITE-USES
033436         THRU 9900-WRITE-USES-X.

       2021-CREATE-NEW-USES-X.
           EXIT.

      *--------------------
       2040-COMPLETE-SIGNON.
      *--------------------

           PERFORM 9200-SETUP-L0020-AREA
              THRU 9200-SETUP-L0020-AREA-X.

           IF WUSEU-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE WS-PROCESS-DATE        TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE    TO L0020-ONLN-PRCES-DT-DISP
               MOVE WS-PROCESS-DATE        TO L0020-ONLN-PRCES-DT
               MOVE WS-USER-SESN-CTRY-CD   TO L0020-COUNTRY-CODE
               MOVE WS-USER-SESN-CRCY-CD   TO L0020-CURRENCY-CODE
           END-IF.

           MOVE MIR-USER-RPT-DSTRB-CD      TO L0020-USER-DIST-CODE.

           SET L0020-REQ-SIGN-ON           TO TRUE

           MOVE MIR-DV-APPL-STAT-CD        TO WS-DV-APPL-STAT-CD

           SET WS-ERROR-NO                 TO TRUE.
           EVALUATE TRUE

              WHEN  WS-DV-APPL-STAT-INACTIVE
              WHEN  WS-DV-APPL-STAT-STOPPED
      *MSG: DID NOT CONNECT. APPLICATION NOT AVAILABLE FOR SIGN-ON
                  MOVE 'XS00650002'        TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                  SET WS-ERROR-FOUND       TO TRUE

              WHEN  WS-DV-APPL-STAT-ACTIVE
                  PERFORM  7580-EDIT-CTRY-CURR
                      THRU 7580-EDIT-CTRY-CURR-X
                  IF WS-USER-SESN-CTRY-CD NOT =
                     RASCL-ASCL-CTRY-CD (SUB1)
                  OR WS-USER-SESN-CRCY-CD NOT =
                     RASCL-ASCL-CRCY-CD (SUB1 SUB2)
                      SET WS-ERROR-FOUND       TO TRUE
                  END-IF

           END-EVALUATE.

           IF WS-ERROR-FOUND
               PERFORM  9100-DISPLAY-THIS-APPL
                   THRU 9100-DISPLAY-THIS-APPL-X
               GO TO 2040-COMPLETE-SIGNON-X
           END-IF.

           PERFORM 0020-1000-LINK-TO-APPL
              THRU 0020-1000-LINK-TO-APPL-X.

           IF L0020-RES-DATA-ERROR
               PERFORM 8000-DATA-ERROR
                  THRU 8000-DATA-ERROR-X
               GO TO 2040-COMPLETE-SIGNON-X
           END-IF.

           MOVE  WGLOB-USER-SESN-ID             TO WUSES-USER-SESN-ID.
           PERFORM  USES-1000-READ
               THRU USES-1000-READ-X.

           IF WUSES-IO-NOT-FOUND
               PERFORM  2041-ACTION-WITHOUT-USES
                   THRU 2041-ACTION-WITHOUT-USES-X
           END-IF.

       2040-COMPLETE-SIGNON-X.
           EXIT.
      /
      *------------------------
       2041-ACTION-WITHOUT-USES.
      *------------------------

           EVALUATE TRUE
             WHEN L0020-RES-SIGN-ON
                MOVE WGLOB-USER-SESN-ID      TO WUSES-USER-SESN-ID
                PERFORM  USES-1000-CREATE
                    THRU USES-1000-CREATE-X
                MOVE L0020-CO-ID             TO RUSES-CO-ID
                MOVE MIR-USER-ID             TO RUSES-USER-ID
                MOVE L0020-COUNTRY-CODE      TO RUSES-USER-SESN-CTRY-CD
                MOVE L0020-CURRENCY-CODE     TO RUSES-USER-SESN-CRCY-CD
      *         MOVE L0020-PROCESS-DATE      TO L1680-INTERNAL-1
                MOVE L0020-ONLN-PRCES-DT     TO L1680-INTERNAL-1
                MOVE ZERO                    TO L1680-NUMBER-OF-YEARS
                MOVE ZERO                    TO L1680-NUMBER-OF-MONTHS
                MOVE ZERO                    TO L1680-NUMBER-OF-DAYS
                PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
                    THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
                MOVE L1680-INTERNAL-2        TO RUSES-USER-SESN-PRCES-DT
                MOVE L0020-BATCH-NUMBER      TO RUSES-USER-SESN-BTCH-NUM
                MOVE RAPPL-APPL-EDIT-LANG-CD TO RUSES-EDIT-LANG-CD
033436**        PERFORM  USES-1000-WRITE
033436**            THRU USES-1000-WRITE-X
033436          PERFORM  9900-WRITE-USES
033436              THRU 9900-WRITE-USES-X

             WHEN L0020-RES-DISCONNECT
      *MSG: ANOTHER USER IS SIGNED ONTO THE APPLICATION ON THIS TERMINAL
                MOVE 'XS00650003'        TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X

             WHEN L0020-RES-EDITS-FAILURE
      *MSG: USER SESSION RECORD AND APPLICATION MASTER (TMAST) RECORD
      *          OUT OF SYNC
                MOVE 'XS00650004'        TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X

             WHEN OTHER
      *MSG:  UNKNOWN RETURN CODE FROM L0020
                MOVE 'XS00650005'        TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
           END-EVALUATE.

       2041-ACTION-WITHOUT-USES-X.
           EXIT.

      *-----------------------
       2050-SIGNON-NOT-CONNECT.
      *-----------------------
      *  THIS PARAGRAPH WILL CREATE A USES RECORD FOR THE USER WITHOUT
      *  THE REQUIRED BATCH NUMBER, PROCESSING DATE,COUNTRY AND CURRENCY

           IF  NOT WS-DV-APPL-STAT-INACTIVE
           AND NOT WS-DV-APPL-STAT-STOPPED
               GO TO 2050-SIGNON-NOT-CONNECT-X
           END-IF.

           MOVE WGLOB-USER-SESN-ID      TO WUSES-USER-SESN-ID.
           PERFORM  USES-1000-CREATE
               THRU USES-1000-CREATE-X.
           MOVE L0020-CO-ID             TO RUSES-CO-ID.
           MOVE MIR-USER-ID             TO RUSES-USER-ID.
           MOVE SPACE                   TO RUSES-USER-SESN-CTRY-CD.
           MOVE SPACE                   TO RUSES-USER-SESN-CRCY-CD.
           MOVE WWKDT-LOW-DT            TO RUSES-USER-SESN-PRCES-DT.
           MOVE ZERO                    TO RUSES-USER-SESN-BTCH-NUM.
           MOVE RAPPL-APPL-EDIT-LANG-CD TO RUSES-EDIT-LANG-CD.
           SET RUSES-USER-SESN-STAT-NOT-CONN  TO TRUE.
033436**   PERFORM  USES-1000-WRITE
033436**       THRU USES-1000-WRITE-X.
033436     PERFORM  9900-WRITE-USES
033436         THRU 9900-WRITE-USES-X.

       2050-SIGNON-NOT-CONNECT-X.
           EXIT.
      /
      *----------------
       7000-LOGIN-EDITS.
      *----------------

           PERFORM  7510-EDIT-USER-ID
               THRU 7510-EDIT-USER-ID-X.

020846*    PERFORM  7590-EDIT-USES-WITH-USER
020846*        THRU 7590-EDIT-USES-WITH-USER-X.

           IF  WS-ERROR-FOUND
               GO TO 7000-LOGIN-EDITS-X
           END-IF.

           PERFORM  7520-EDIT-SECUR-CLAS-ID
               THRU 7520-EDIT-SECUR-CLAS-ID-X.

           PERFORM  7550-EDIT-BR-ID
               THRU 7550-EDIT-BR-ID-X.

           PERFORM  7570-EDIT-RPT-DSTRB-CD
               THRU 7570-EDIT-RPT-DSTRB-CD-X.


       7000-LOGIN-EDITS-X.
           EXIT.


      *-----------------
       7510-EDIT-USER-ID.
      *-----------------
           IF MIR-USER-ID = SPACES
      *MSG:  USER-ID REQUIRED FOR LOGIN
               MOVE 'XS00650006'                TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND               TO TRUE
               GO TO 7510-EDIT-USER-ID-X
           END-IF.

           MOVE MIR-USER-ID                    TO WGLOB-USER-ID.

       7510-EDIT-USER-ID-X.
           EXIT.

      *-----------------------
       7520-EDIT-SECUR-CLAS-ID.
      *-----------------------

           MOVE MIR-SECUR-CLAS-ID              TO WUSCL-SECUR-CLAS-ID.
           PERFORM  USCL-1000-READ
               THRU USCL-1000-READ-X.

           IF NOT WUSCL-IO-OK
               MOVE WUSCL-KEY                   TO WGLOB-MSG-PARM (1)
      *MSG: SECURITY CLASS RECORD (@1) NOT FOUND
               MOVE 'XS00650007'                TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-ERROR-FOUND               TO TRUE
           ELSE
               MOVE MIR-SECUR-CLAS-ID           TO WGLOB-SECUR-CLAS-ID
           END-IF.

       7520-EDIT-SECUR-CLAS-ID-X.
           EXIT.

      *----------------
       7550-EDIT-BR-ID.
      *----------------

           MOVE MIR-BR-ID             TO WXTAB-ETBL-VALU-ID.
           PERFORM BRCH-1000-EDIT-BRANCH-CODE
              THRU BRCH-1000-EDIT-BRANCH-CODE-X.

           IF WXTAB-IO-OK
               CONTINUE
           ELSE
      *MSG:  INVALID BRANCH ID
               MOVE 'XS00650012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7550-EDIT-BR-ID-X.
           EXIT.

      *----------------------
       7570-EDIT-RPT-DSTRB-CD.
      *----------------------

           MOVE MIR-USER-RPT-DSTRB-CD TO WXTAB-ETBL-VALU-ID.
           PERFORM DIST-1000-EDIT-DIST-CD
              THRU DIST-1000-EDIT-DIST-CD-X.

           IF WXTAB-IO-OK
               CONTINUE
           ELSE
      *MSG:  INVALID REPORT DISTRIBUTION CODE
               MOVE 'XS00650014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7570-EDIT-RPT-DSTRB-CD-X.
           EXIT.

      *-------------------
       7580-EDIT-CTRY-CURR.
      *-------------------

           MOVE WGLOB-SECUR-CLAS-ID     TO WASCL-SECUR-CLAS-ID.
           MOVE WGLOB-COMPANY-CODE      TO WASCL-CO-ID.

           IF WASCL-KEY NOT = RASCL-KEY
              PERFORM ASCL-1000-READ
                 THRU ASCL-1000-READ-X
           END-IF.

           PERFORM
              VARYING SUB1 FROM +1 BY +1
              UNTIL   SUB1 = +5
              OR RASCL-ASCL-CTRY-CD (SUB1) =
                 WS-USER-SESN-CTRY-CD
              CONTINUE
           END-PERFORM.

           IF RASCL-ASCL-CTRY-CD (SUB1) =
              WS-USER-SESN-CTRY-CD
               PERFORM
                  VARYING SUB2 FROM +1 BY +1
                  UNTIL   SUB2 = +5
                  OR RASCL-ASCL-CRCY-CD (SUB1, SUB2) =
                     WS-USER-SESN-CRCY-CD
                  CONTINUE
               END-PERFORM
               IF RASCL-ASCL-CRCY-CD (SUB1, SUB2) =
                  WS-USER-SESN-CRCY-CD
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *MSG: NOT AUTHORIZED FOR REQUESTED CURRENCY. RE-ENTER
                   MOVE 'XS00650015'   TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
      *MSG: NOT AUTHORIZED FOR REQUESTED COUNTRY. RE-ENTER
               MOVE 'XS00650016'       TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7580-EDIT-CTRY-CURR-X.
           EXIT.

      /
020846*-----------------------
020846*7590-EDIT-USES-WITH-USER.
020846*-----------------------
020846*
020846*    MOVE WGLOB-USER-SESN-ID            TO WUSES-USER-SESN-ID.
020846*    PERFORM  USES-1000-READ
020846*        THRU USES-1000-READ-X.
020846*    IF NOT WUSES-IO-OK
020846*        GO TO 7590-EDIT-USES-WITH-USER-X
020846*    END-IF.
020846*
020846*    MOVE RUSES-CO-ID                   TO WGLOB-COMPANY-CODE
020846*
020846*    IF RUSES-USER-ID NOT = MIR-USER-ID
020846*MSG: CURRENT SESSION IS ACTIVE, SIGN ON TO CURRENT SESSION WITH
020846*     NEW USER ID IS NOT ALLOWED.
020846*        MOVE 'XS00650017'              TO WGLOB-MSG-REF-INFO
020846*        PERFORM  0260-1000-GENERATE-MESSAGE
020846*            THRU 0260-1000-GENERATE-MESSAGE-X
020846*        SET WS-ERROR-FOUND             TO TRUE
020846*        GO TO 7590-EDIT-USES-WITH-USER-X
020846*    END-IF.
020846*
020846*    IF RUSES-USER-SESN-STAT-API-CONN
020846*MSG: WARNING: YOU ARE ALREADY SIGNED ON TO INGENIUM IN THIS
020846*     SESSION.  LOGIN REQUEST IS IGNORED
020846*        MOVE 'XS00650018'              TO WGLOB-MSG-REF-INFO
020846*        PERFORM  0260-1000-GENERATE-MESSAGE
020846*            THRU 0260-1000-GENERATE-MESSAGE-X
020846*        IF WGLOB-MSG-SEVRTY-FATAL
020846*            SET WS-ERROR-FOUND         TO TRUE
020846*            GO TO 7590-EDIT-USES-WITH-USER-X
020846*        END-IF
020846*    END-IF.
020846*
020846*7590-EDIT-USES-WITH-USER-X.
020846*    EXIT.
      /
      *---------------
       8000-DATA-ERROR.
      *---------------
      *
           IF L0020-CURRENCY-CODE = HIGH-VALUES
      *MSG: NOT AUTHORIZED FOR REQUESTED CURRENCY. RE-ENTER
               MOVE 'XS00650015'              TO WGLOB-MSG-REF-INFO
           ELSE
               IF L0020-COUNTRY-CODE = HIGH-VALUES
      *MSG: NOT AUTHORIZED FOR REQUESTED COUNTRY. RE-ENTER
                   MOVE 'XS00650016'          TO WGLOB-MSG-REF-INFO
               ELSE
      *MSG: UNKNOWN DATA ERROR FROM EXIT - CONTACT SYSTEMS
                   MOVE 'XS00650019'          TO WGLOB-MSG-REF-INFO
               END-IF
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9100-DISPLAY-THIS-APPL
              THRU 9100-DISPLAY-THIS-APPL-X.

       8000-DATA-ERROR-X.
           EXIT.
      /
      *----------------------
       9100-DISPLAY-THIS-APPL.
      *----------------------

           MOVE SPACE                         TO MIR-USER-SESN-BTCH-NUM.
           MOVE SPACE                         TO MIR-USER-SESN-STAT-CD.
           MOVE SPACE                         TO MIR-DV-APPL-STAT-CD.
           MOVE SPACE                         TO MIR-USER-SESN-CTRY-CD.
           MOVE SPACE                         TO MIR-USER-SESN-CRCY-CD.

           MOVE WGLOB-COMPANY-CODE            TO WAPPL-CO-ID.
           PERFORM  APPL-1000-READ
               THRU APPL-1000-READ-X.

           IF NOT WAPPL-IO-OK
      *    INTEGRITY PROBLEM WITH ASCL AND APPL TABLES.
              MOVE WAPPL-KEY                   TO WGLOB-MSG-PARM (1)
      *MSG: APPLICATION (@1) NOT FOUND. FILES OUT OF SYNC. CONTACT
      *  SYSTEMS
              MOVE 'XS00650020'                TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 9100-DISPLAY-THIS-APPL-X
           END-IF.

           PERFORM  9200-SETUP-L0020-AREA
               THRU 9200-SETUP-L0020-AREA-X.
      *
      *    REQUEST APPLICATION STATUS FROM EXIT
      *
           SET L0020-REQ-APPL-STATUS           TO TRUE.
           PERFORM  0020-1000-LINK-TO-APPL
               THRU 0020-1000-LINK-TO-APPL-X.

           PERFORM  9400-FORMAT-RESPONSE
               THRU 9400-FORMAT-RESPONSE-X.

           MOVE WGLOB-COMPANY-CODE            TO MIR-CO-ID.
           MOVE WGLOB-DT-FRMT-CD              TO MIR-CTRY-DT-FRMT-CD.
           MOVE WGLOB-DT-SEPARATOR-SYMBL      TO MIR-CTRY-DT-SPRT-CD.
           MOVE WGLOB-DT-ZERO-SUPRES-IND      TO MIR-CTRY-LEAD-ZERO-IND.
           MOVE WGLOB-CRCY-SYMBL              TO MIR-CRCY-SYMBL-CD.
           MOVE WGLOB-THOUSANDS-SYMBL         TO MIR-CRCY-THOU-SPRT-CD.
           MOVE WGLOB-DCML-SYMBL              TO MIR-CRCY-DCML-SPRT-CD.
           MOVE WGLOB-SIGN-POSN-CD            TO MIR-CRCY-NEG-PLACE-CD.
           MOVE WGLOB-CRCY-POSN-CD            TO MIR-CRCY-PLACE-CD.

      *  WHEN SUPPORT FOR ISO DATES IS ADDED THE FOLLOWING LINE SHOULD
      *  BE MODIFIED TO INDICATE THIS.
020462*    MOVE 'N'                           TO MIR-DV-ISO-DT-FRMT-IND.
020462     MOVE 'Y'                           TO MIR-DV-ISO-DT-FRMT-IND.
      *  WHEN CURRENCY SCALING LOGIC FROM THE 612J PROJECT IS ADDED
      *  THE FOLLOWING LINE SHOULD BE MODIFIED TO REFLECT THE ADDITIONAL
      *  SUPPORT.
020462*    MOVE '2'                           TO MIR-CRCY-SCALE-QTY.
020462     MOVE WGLOB-CRCY-SCALE-QTY          TO MIR-CRCY-SCALE-QTY.

           IF L0020-RES-DATA-ERROR
           OR L0020-RES-DISCONNECT
           OR L0020-RES-LOGOFF
               GO TO 9100-DISPLAY-THIS-APPL-X
           END-IF.

           IF NOT WUSES-IO-OK
               GO TO 9100-DISPLAY-THIS-APPL-X
           END-IF.

           IF L0020-RES-CLOSE-APPL
      *MSG: USER SESSION RECORD EXISTS BUT SYSTEM UNAVAILABLE
               MOVE 'XS00650021'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE RUSES-USER-SESN-CTRY-CD       TO MIR-USER-SESN-CTRY-CD.
           MOVE RUSES-USER-SESN-CRCY-CD       TO MIR-USER-SESN-CRCY-CD.
           MOVE L0020-BATCH-NUMBER            TO MIR-USER-SESN-BTCH-NUM.
           IF  RUSES-USER-SESN-PRCES-DT = WWKDT-LOW-DT
               MOVE SPACES                    TO MIR-USER-SESN-PRCES-DT
           ELSE
               MOVE RUSES-USER-SESN-PRCES-DT  TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE       TO MIR-USER-SESN-PRCES-DT
           END-IF.
           MOVE RUSES-USER-SESN-STAT-CD       TO MIR-USER-SESN-STAT-CD.
           MOVE WS-DV-APPL-STAT-CD            TO MIR-DV-APPL-STAT-CD.


       9100-DISPLAY-THIS-APPL-X.
           EXIT.
      /
      *---------------------
       9200-SETUP-L0020-AREA.
      *---------------------

           MOVE WGLOB-USER-ID                  TO WUSEU-USER-ID.

020846     MOVE LOW-VALUES                     TO WUSEU-CO-ID.
020846     MOVE WGLOB-USER-ID                  TO WUSEU-ENDBR-USER-ID.
020846     MOVE HIGH-VALUES                    TO WUSEU-ENDBR-CO-ID.
020846*    PERFORM  USEU-1000-READ
020846*        THRU USEU-1000-READ-X.
020846     IF WS-USEU-CURSOR-OPEN
020846        PERFORM  USEU-3000-END-BROWSE
020846            THRU USEU-3000-END-BROWSE-X
020846     END-IF.
020846
020846     SET WS-USEU-CURSOR-OPEN TO TRUE.
020846
020846     PERFORM  USEU-1000-BROWSE
020846         THRU USEU-1000-BROWSE-X.
020846
020846     IF WUSEU-IO-OK
020846        PERFORM  USEU-2000-READ-NEXT
020846            THRU USEU-2000-READ-NEXT-X
020846           UNTIL RUSES-USER-SESN-ID = WGLOB-USER-SESN-ID
020846           OR    WUSEU-IO-EOF
020846     END-IF.

           IF WUSEU-IO-OK
               MOVE RUSES-CO-ID                TO L0020-CO-ID
               MOVE RUSES-USER-SESN-CTRY-CD    TO L0020-COUNTRY-CODE
               MOVE RUSES-USER-SESN-CRCY-CD    TO L0020-CURRENCY-CODE
               MOVE RUSES-USER-SESN-PRCES-DT   TO L0020-ONLN-PRCES-DT
               MOVE SPACE                    TO L0020-ONLN-PRCES-DT-DISP
               MOVE RUSES-ONLN-DT-CHNG-TIME  TO L0020-ONLN-DT-CHNG-TIME
               MOVE RUSES-CHNG-LEAD-TIME-DUR TO L0020-CHNG-LEAD-TIME-DUR
           ELSE
               MOVE WGLOB-COMPANY-CODE         TO L0020-CO-ID
               MOVE SPACES                     TO L0020-ONLN-PRCES-DT
               MOVE SPACES                     TO L0020-COUNTRY-CODE
               MOVE SPACES                     TO L0020-CURRENCY-CODE
               MOVE WWKDT-ZERO-TIME        TO L0020-ONLN-DT-CHNG-TIME
               MOVE ZERO                   TO L0020-CHNG-LEAD-TIME-DUR
           END-IF.

           MOVE SPACES                         TO L0020-EXIT-RESPONSE.
           MOVE MIR-USER-ID                    TO L0020-USER-ID.
           MOVE WGLOB-USER-SESN-ID             TO L0020-USER-SESN-ID.
           MOVE ZERO                           TO L0020-BATCH-NUMBER.

       9200-SETUP-L0020-AREA-X.
           EXIT.
      /
      *-------------------------
       9300-SETUP-MSIN-REFERENCE.
      *-------------------------

           MOVE SPACES                        TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE            TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------
       9400-FORMAT-RESPONSE.
      *--------------------

           SET WS-DV-APPL-STAT-UNKNOWN         TO TRUE.

           EVALUATE TRUE
               WHEN L0020-RES-CLOSE-APPL
                 SET WS-DV-APPL-STAT-INACTIVE  TO TRUE
                 MOVE WWKDT-ZERO-DT            TO WS-PROCESS-DATE

               WHEN L0020-RES-INIT-APPL
               WHEN L0020-RES-SIGN-ON
                 SET WS-DV-APPL-STAT-ACTIVE    TO TRUE
                 MOVE L0020-ONLN-PRCES-DT-DISP TO WS-USER-SESN-PRCES-DT
                 MOVE L0020-COUNTRY-CODE       TO WS-USER-SESN-CTRY-CD
                 MOVE L0020-CURRENCY-CODE      TO WS-USER-SESN-CRCY-CD
                 MOVE L0020-ONLN-PRCES-DT      TO WS-PROCESS-DATE

               WHEN L0020-RES-PROHIBIT-ACCESS
                 SET WS-DV-APPL-STAT-STOPPED   TO TRUE
                 MOVE L0020-ONLN-PRCES-DT-DISP TO WS-USER-SESN-PRCES-DT
                 MOVE L0020-COUNTRY-CODE       TO WS-USER-SESN-CTRY-CD

                 MOVE L0020-CURRENCY-CODE      TO WS-USER-SESN-CRCY-CD
                 MOVE L0020-ONLN-PRCES-DT      TO WS-PROCESS-DATE

               WHEN L0020-RES-DISCONNECT
               WHEN L0020-RES-LOGOFF
      *MSG: SESSION FILE AND USER FILE OUT OF SYNC - CONTACT
      *       SYSTEMS
                 MOVE 'XS00650022'             TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN L0020-RES-DATA-ERROR
      *MSG: SESSION FILE AND (@1) USER FILE OUT OF SYNC - CONTACT
      *           SYSTEMS
                 MOVE 'XS00650022'             TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN OTHER
                 SET WS-DV-APPL-STAT-UNKNOWN   TO TRUE
           END-EVALUATE.

           MOVE WS-DV-APPL-STAT-CD             TO MIR-DV-APPL-STAT-CD.

       9400-FORMAT-RESPONSE-X.
           EXIT.
      /
      *---------------
       9500-CHECK-ASCL.
      *---------------

           MOVE WGLOB-SECUR-CLAS-ID        TO WASCL-SECUR-CLAS-ID.
           MOVE WGLOB-COMPANY-CODE         TO WASCL-CO-ID.

           PERFORM  ASCL-1000-READ
               THRU ASCL-1000-READ-X.

           IF WASCL-IO-NOT-FOUND
               GO TO 9500-CHECK-ASCL-X
           END-IF.

           PERFORM  9100-DISPLAY-THIS-APPL
               THRU 9100-DISPLAY-THIS-APPL-X.

       9500-CHECK-ASCL-X.
           EXIT.
      /
033436*----------------------
033436 9900-WRITE-USES.
033436*----------------------
033436
033436     PERFORM  USES-1000-WRITE
033436         THRU USES-1000-WRITE-X.
033436
033436     PERFORM
033436         UNTIL NOT WUSES-IO-DUPKEY
033436
033436         ADD +1                  TO RUSES-USER-SESN-BTCH-NUM
033436
033436         PERFORM  USES-1000-WRITE
033436             THRU USES-1000-WRITE-X
033436
033436     END-PERFORM.
033436
033436 9900-WRITE-USES-X.
033436     EXIT.
033436

020846*--------------------------
020846 9990-INIT-WORKING-STORAGE.
020846*--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
020846
025970     PERFORM  0020-0000-INIT-PARM-INFO
025970         THRU 0020-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2490-0000-INIT-PARM-INFO
025970         THRU 2490-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8095-0000-INIT-PARM-INFO
025970         THRU 8095-0000-INIT-PARM-INFO-X.
025970
020846     PERFORM  9300-SETUP-MSIN-REFERENCE
020846         THRU 9300-SETUP-MSIN-REFERENCE-X.

025970     INITIALIZE WS-WORKING-STORAGE.
020846
020846     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
020846     SET  MIR-RETRN-OK                   TO TRUE.
020846
020846 9990-INIT-WORKING-STORAGE-X.
020846     EXIT.
020846*
021930*COPY XCPPINIT.
021930*
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      /
025970 COPY XCPS1670.
025970 COPY XCPS0020.
       COPY XCPL0020.
      /
021930*COPY XCPECOMP.
       COPY XCPEBRCH.
       COPY XCPEDIST.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1680.
       COPY XCPL1680.
      /
       COPY XCCP0030.
      /
021930*COPY XCPEAPPL.
021930*
021930*COPY XCPS0005.
021930*
021930*COPY XCPL0005.
021930*
       COPY XCPS2490.
      /
       COPY XCPL2490.
025970 COPY XCPS8095.
       COPY XCPL8095.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY XCPNAPPL.
      /
021930*COPY XCPBASCL.
       COPY XCPNASCL.
      /
       COPY XCPNUSCL.
      /
       COPY XCPAUSES.
021930*COPY XCPBUSES.
       COPY XCPNUSES.
       COPY XCPUUSES.
       COPY XCPXUSES.
       COPY XCPCUSES.

020846*COPY XCPNUSEU.
020846 COPY XCPBUSEU.
      /
       COPY XCPNXTAB.
      *****************************************************************
      **                 END OF PROGRAM XSOM0065                     **
      *****************************************************************
