      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7351.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7351                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE PDCL AND PDCB TABLE                      **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7351'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                          PIC X(04).
               88  WS-BUS-FCN-CREATE                  VALUE '7351'.
           05  WS-CVG-NUM                             PIC S9(02) BINARY.
               88  WS-POL-PRCES                       VALUE ZEROS.
           05  WS-PDCB-CTR                            PIC S9(04) BINARY.
           05  WS-TOTAL-DCBNFY-PCT                    PIC S9(03)V9(02)
                                                      COMP-3.
           05  WS-PDCL-INFO.
               10  WS-PDCL-DTHCLM-SEQ-NUM             PIC S9(04) BINARY.
               10  WS-PDCL-DTHCLM-AMT                 PIC S9(13)V9(02)
                                                      COMP-3.
               10  WS-PDCL-DTHCLM-ADDL-AMT            PIC S9(13)V9(02)
                                                      COMP-3.
               10  WS-PDCL-DTHCLM-INT-DT-CD           PIC X(01).
               10  WS-PDCL-DTHCLM-INT-STRT-DT         PIC X(10).
               10  WS-PDCL-DTHCLM-INT-PCT             PIC S9(03)V9(02)
                                                      COMP-3.
               10  WS-PDCL-DTHCLM-STAT-CD             PIC X(01).
                   88  WS-PDCL-DTHCLM-STAT-PEND       VALUE '1'.
                   88  WS-PDCL-DTHCLM-STAT-PD         VALUE '2'.
                   88  WS-PDCL-DTHCLM-STAT-ERROR      VALUE '3'.
                   88  WS-PDCL-DTHCLM-STAT-REVRS      VALUE '4'.
                   88  WS-PDCL-DTHCLM-STAT-PARTL-PD   VALUE '5'.
               10  WS-PDCL-DTHCLM-CREAT-DT            PIC X(10).
               10  WS-PDCL-DTHCLM-COMNT-TXT           PIC X(255).
           05  WS-PDCB-INFO.
               10  WS-PDCB-DCBNFY-INFO                OCCURS 99 TIMES.
                   15  WS-PDCB-CLI-ID                 PIC X(10).
                   15  WS-PDCB-DCBNFY-PCT             PIC S9(03)V9(02)
                                                      COMP-3.
           05  WS-FOUND-SW                            PIC X(01).
               88  WS-FOUND                           VALUE 'Y'.
               88  WS-FOUND-NO                        VALUE 'N'.

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                            PIC X(04).
               88 WS-TWRK-KEY-DEFAULT                 VALUE '7350'.
           05  WS-MAX-PDCB-CTR                        PIC S9(4)
                                                      VALUE 99.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
       COPY CCWWINDX.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.

       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFWPDCL.
       COPY CCFWPDCM.
       COPY CCFRPDCL.

       COPY CCFRPDCN.
       COPY CCFWPDCN.

       COPY CCFWPDCB.
       COPY CCFRPDCB.

       COPY CCFWPH.
       COPY CCFRPH.

       COPY CCFWPLGR.
       COPY CCFRPLGR.

       COPY CCFWCDSA.
       COPY CCFRCDSA.

       COPY CCFWBENC.
       COPY CCFWBENE.
       COPY CCFRBENE.

       COPY CCWWCVGS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWL3330.
       COPY CCWL2430.
       COPY CCWL2435.
029060 COPY CCWL5382.
029060 COPY CCWL0182.       
       COPY CCWLPGA.

       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7351.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7351'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

      * VALIDATE KEY, CHECK WHETHER PENDING RECORD EXISTS, CHECK STATUS,
      * GET LOCATION GROUP AND PLGR

           PERFORM  8000-EDIT-INFO
               THRU 8000-EDIT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

      * BUILD PDCL INFORMATION FROM VARIOUS BUSINESS FUNCTION IN
      * INGENIUM OR FROM PRODUCTXPRESS

           PERFORM  2100-BUILD-PDCL-INFO
               THRU 2100-BUILD-PDCL-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

      * BUILD PDCB INFORMATION - BENEFICIARY DETAILS

           PERFORM  2200-BUILD-PDCB-INFO
               THRU 2200-BUILD-PDCB-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

      * CREATE AND WRITE PDCL AND PDCB RECORD

           PERFORM  2300-WRITE-PDCL-PDCB
               THRU 2300-WRITE-PDCL-PDCB-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

       2000-CREATE-X.
           EXIT.
      /
      *---------------------
       2100-BUILD-PDCL-INFO.
      *---------------------

           INITIALIZE WS-PDCL-INFO.

      * GET AMOUNT OF THE DEATH CLAIM

           PERFORM  5000-GET-DTHCLM-AMT
               THRU 5000-GET-DTHCLM-AMT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2100-BUILD-PDCL-INFO-X
           END-IF.

      * GET THE DATE FROM WHICH THE IMTEREST WILL BE CALCULATED

           PERFORM  5200-GET-INT-STRT-DT
               THRU 5200-GET-INT-STRT-DT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2100-BUILD-PDCL-INFO-X
           END-IF.

      * SET THE STATUS OF THE PENDING INTEREST ON DEATH CLAIM RECORD

           IF  WS-PDCL-DTHCLM-INT-STRT-DT = WWKDT-ZERO-DT
               SET WS-PDCL-DTHCLM-STAT-ERROR   TO TRUE
           ELSE
               SET WS-PDCL-DTHCLM-STAT-PEND    TO TRUE
           END-IF.

      * MOVE DATE TYPE CODE FROM PLGR

           MOVE RPLGR-DTHCLM-INT-DT-CD    TO WS-PDCL-DTHCLM-INT-DT-CD.

      * CREATE DATE = SYSTEM DATE

           MOVE WGLOB-PROCESS-DATE        TO WS-PDCL-DTHCLM-CREAT-DT.

       2100-BUILD-PDCL-INFO-X.
           EXIT.

      *---------------------
       2200-BUILD-PDCB-INFO.
      *---------------------

           INITIALIZE WS-PDCB-INFO.

      * GET BENEFICIARY INFO FROM BENE

           PERFORM  6000-GET-BENE-INFO
               THRU 6000-GET-BENE-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2200-BUILD-PDCB-INFO-X
           END-IF.

       2200-BUILD-PDCB-INFO-X.
           EXIT.

      *---------------------
       2300-WRITE-PDCL-PDCB.
      *---------------------

      * OBTAIN PDCL SEQUENCE NUMBER

           PERFORM  2320-OBTAIN-PDCL-SEQ-NUM
               THRU 2320-OBTAIN-PDCL-SEQ-NUM-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2300-WRITE-PDCL-PDCB-X
           END-IF.

      * CHECK WHETHER PENDING PDCB RECORD (BENEIFICARY DETAIL) EXISTS,
      * RETURN ERROR IF PENDING PDCB RECORD EXISTS.

           PERFORM  2340-CHECK-PDCB
               THRU 2340-CHECK-PDCB-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2300-WRITE-PDCL-PDCB-X
           END-IF.

      * CREATE AND WRITE PDCL RECORD

           PERFORM  2360-WRITE-PDCL
               THRU 2360-WRITE-PDCL-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2300-WRITE-PDCL-PDCB-X
           END-IF.

      * CREATE AND WRITE PDCB RECORD

           PERFORM  2380-WRITE-PDCB
               THRU 2380-WRITE-PDCB-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2300-WRITE-PDCL-PDCB-X
           END-IF.

       2300-WRITE-PDCL-PDCB-X.
           EXIT.

      *-------------------------
       2320-OBTAIN-PDCL-SEQ-NUM.
      *-------------------------

           MOVE ZEROES                    TO WS-PDCL-DTHCLM-SEQ-NUM.

           MOVE LOW-VALUES                TO WPDCL-KEY.
           MOVE WGLOB-COMPANY-CODE        TO WPDCL-CO-ID.
           MOVE RPOL-POL-ID               TO WPDCL-POL-ID.
           MOVE +1                        TO WPDCL-DTHCLM-SEQ-NUM.

           MOVE WPDCL-KEY                 TO WPDCL-ENDBR-KEY.
           MOVE +9999                     TO WPDCL-ENDBR-DTHCLM-SEQ-NUM.

           PERFORM  PDCL-2000-READ-MAX
               THRU PDCL-2000-READ-MAX-X.

           IF  WPDCL-IO-OK
               MOVE WPDCL-MAX-DTHCLM-SEQ-NUM
                                          TO WS-PDCL-DTHCLM-SEQ-NUM
           END-IF.

           IF  WS-PDCL-DTHCLM-SEQ-NUM  = 9999
      *MSG: 'MAXIMUM NUMBER OF PENDING INTEREST ON DEATH CLAIM (PDCL)
      *      CREATED (9999), RECORD CANNOT CREATE'
               MOVE 'CS73510001'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2320-OBTAIN-PDCL-SEQ-NUM-X
           END-IF.

           ADD +1                         TO WS-PDCL-DTHCLM-SEQ-NUM.

       2320-OBTAIN-PDCL-SEQ-NUM-X.
           EXIT.

      *----------------
       2340-CHECK-PDCB.
      *----------------

      * CHECK WHETHER PDCB RECORD WITH THE PDCL SEQ NUM EXISTS

           MOVE LOW-VALUES              TO WPDCB-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCB-CO-ID.
           MOVE RPOL-POL-ID             TO WPDCB-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM  TO WPDCB-DTHCLM-SEQ-NUM.

           MOVE WPDCB-KEY               TO WPDCB-ENDBR-KEY.
           MOVE HIGH-VALUES             TO WPDCB-ENDBR-CLI-ID.

           PERFORM  PDCB-1000-BROWSE
               THRU PDCB-1000-BROWSE-X.

           PERFORM  PDCB-2000-READ-NEXT
               THRU PDCB-2000-READ-NEXT-X.

           IF  NOT WPDCB-IO-OK
               PERFORM  PDCB-3000-END-BROWSE
                   THRU PDCB-3000-END-BROWSE-X
               GO TO 2340-CHECK-PDCB-X
           END-IF.

           SET WS-FOUND-NO              TO TRUE.

           PERFORM  2342-CHECK-PDCB-LOOP
               THRU 2342-CHECK-PDCB-LOOP-X
               UNTIL NOT WPDCB-IO-OK
               OR    WS-FOUND.

           PERFORM  PDCB-3000-END-BROWSE
               THRU PDCB-3000-END-BROWSE-X.

       2340-CHECK-PDCB-X.
           EXIT.

      *---------------------
       2342-CHECK-PDCB-LOOP.
      *---------------------

           IF  RPDCB-DCBNFY-STAT-PEND
               SET WS-FOUND             TO TRUE
      *MSG: PENDING DEATH CLAIM BENEFICIARY RECORD ALREADY
      *     EXISTS, CANNOT CREATE.
               MOVE 'CS73510002'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2342-CHECK-PDCB-LOOP-X
           END-IF.

           PERFORM  PDCB-2000-READ-NEXT
               THRU PDCB-2000-READ-NEXT-X.

       2342-CHECK-PDCB-LOOP-X.
           EXIT.

      *----------------
       2360-WRITE-PDCL.
      *----------------

      * CREATE AND WRITE PDCL RECORD

           MOVE LOW-VALUES                 TO WPDCL-KEY.
           MOVE WGLOB-COMPANY-CODE         TO WPDCL-CO-ID.
           MOVE RPOL-POL-ID                TO WPDCL-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM     TO WPDCL-DTHCLM-SEQ-NUM.

           PERFORM  PDCL-1000-CREATE
               THRU PDCL-1000-CREATE-X.

           MOVE WS-CVG-NUM                 TO RPDCL-CVG-NUM-N.
           MOVE WS-PDCL-DTHCLM-AMT         TO RPDCL-DTHCLM-AMT.
           MOVE WS-PDCL-DTHCLM-ADDL-AMT    TO RPDCL-DTHCLM-ADDL-AMT.
           MOVE WS-PDCL-DTHCLM-INT-DT-CD   TO RPDCL-DTHCLM-INT-DT-CD.
           MOVE WS-PDCL-DTHCLM-INT-STRT-DT TO RPDCL-DTHCLM-INT-STRT-DT.
           MOVE WS-PDCL-DTHCLM-INT-PCT     TO RPDCL-DTHCLM-INT-PCT.
           MOVE WS-PDCL-DTHCLM-STAT-CD     TO RPDCL-DTHCLM-STAT-CD.
           MOVE WS-PDCL-DTHCLM-CREAT-DT    TO RPDCL-DTHCLM-CREAT-DT.
           MOVE WS-PDCL-DTHCLM-COMNT-TXT TO RPDCL-DTHCLM-COMNT-INFO-TXT.

           PERFORM  PDCL-1000-WRITE
               THRU PDCL-1000-WRITE-X.

      * MOVE PDCL SEQUENCE NUMBER TO MIR

           MOVE WS-PDCL-DTHCLM-SEQ-NUM   TO L0290-INPUT-V00.
           MOVE ZERO                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-SEQ-NUM
                                         TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-SEQ-NUM.

       2360-WRITE-PDCL-X.
           EXIT.

      *----------------
       2380-WRITE-PDCB.
      *----------------

      * EXIT IF NO PDCB RECORD

           IF  WS-PDCB-CTR = ZERO
               GO TO 2380-WRITE-PDCB-X
           END-IF.

      * CREATE AND WRITE PDCB RECORD

           PERFORM  2382-WRITE-PDCB-LOOP
               THRU 2382-WRITE-PDCB-LOOP-X
               VARYING I FROM 1 BY +1
                 UNTIL I > WS-PDCB-CTR
                    OR WGLOB-MSG-ERROR-SW > ZERO.

       2380-WRITE-PDCB-X.
           EXIT.

      *---------------------
       2382-WRITE-PDCB-LOOP.
      *---------------------

      * CREATE AND WRITE PDCB RECORD

           MOVE LOW-VALUES                 TO WPDCB-KEY.
           MOVE WGLOB-COMPANY-CODE         TO WPDCB-CO-ID.
           MOVE RPOL-POL-ID                TO WPDCB-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM     TO WPDCB-DTHCLM-SEQ-NUM.
           MOVE WS-PDCB-CLI-ID (I)         TO WPDCB-CLI-ID.

           PERFORM  PDCB-1000-CREATE
               THRU PDCB-1000-CREATE-X.

           MOVE WS-PDCB-DCBNFY-PCT (I)     TO RPDCB-DCBNFY-PCT.
           SET RPDCB-DCBNFY-STAT-PEND      TO TRUE.

           PERFORM  PDCB-1000-WRITE
               THRU PDCB-1000-WRITE-X.

       2382-WRITE-PDCB-LOOP-X.
           EXIT.

      *--------------------
       5000-GET-DTHCLM-AMT.
      *--------------------

      * POLICY DEATH TERMINATION

           IF  WS-CVG-NUM = ZERO
           AND RPOL-POL-STAT-DEATH
               PERFORM  5010-GET-POL-DTHCLM-AMT
                   THRU 5010-GET-POL-DTHCLM-AMT-X
               GO TO 5000-GET-DTHCLM-AMT-X
           END-IF.

      * COVERAGE DEATH TERMINATION

           IF  WS-CVG-NUM > ZERO
           AND WCVGS-CVG-STAT-DEATH (WS-CVG-NUM)
               PERFORM  5020-GET-CVG-DTHCLM-AMT
                   THRU 5020-GET-CVG-DTHCLM-AMT-X
               GO TO 5000-GET-DTHCLM-AMT-X
           END-IF.

      * NOT POLICY DEATH TERMINATION NOR COVERAGE DEATH TERMINATION,
      * ZERO AMOUNT WILL BE DEFAULTED.

           MOVE ZERO                  TO WS-PDCL-DTHCLM-AMT.

       5000-GET-DTHCLM-AMT-X.
           EXIT.

      *------------------------
       5010-GET-POL-DTHCLM-AMT.
      *------------------------

      * GET RCDSA-CDA-TOT-TRXN-AMT FOR POL TERMINATION,
      * DEFAULT TO CLAIM AMOUNT

           INITIALIZE WCDSA-KEY.
           MOVE RPOL-POL-ID           TO WCDSA-POL-ID.
           SET WCDSA-CDA-TYP-DTH-TRMN TO TRUE.
           MOVE ZERO                  TO WCDSA-POL-PAYO-NUM.
           MOVE LOW-VALUES            TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE ZERO                  TO WCDSA-CDA-SEQ-NUM.

           MOVE WCDSA-KEY             TO WCDSA-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCDSA-ENDBR-CDA-EFF-IDT-NUM.
           MOVE +999                  TO WCDSA-ENDBR-CDA-SEQ-NUM.

           PERFORM  CDSA-1000-BROWSE
               THRU CDSA-1000-BROWSE-X.

           PERFORM  CDSA-2000-READ-NEXT
               THRU CDSA-2000-READ-NEXT-X
               UNTIL NOT WCDSA-IO-OK
               OR    RCDSA-CDA-STAT-ACTIVE.

           IF  NOT WCDSA-IO-OK
               PERFORM  CDSA-3000-END-BROWSE
                   THRU CDSA-3000-END-BROWSE-X
      *MSG: CANNOT GET DEATH CLAIM AMOUNT, NO MATCHING HISTORY RECORD
      *     FOUND
               MOVE 'CS73510003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5010-GET-POL-DTHCLM-AMT-X
           END-IF.

           PERFORM  CDSA-3000-END-BROWSE
               THRU CDSA-3000-END-BROWSE-X.

029060     PERFORM  5382-1000-BUILD-PARM-INFO
029060         THRU 5382-1000-BUILD-PARM-INFO-X.
029060
029060     SET L5382-GET-TAX-TYP-CDSA     TO TRUE.
029060     MOVE RCDSA-CDA-TYP-CD          TO L5382-CDA-TYP-CD.
029060     MOVE RCDSA-CDA-SEQ-NUM         TO L5382-CDA-SEQ-NUM.
029060     MOVE RCDSA-POL-PAYO-NUM        TO L5382-POL-PAYO-NUM.
029060     MOVE RCDSA-CDA-EFF-IDT-NUM     TO L5382-CDA-EFF-IDT-NUM.
029060     MOVE WWKDT-HIGH-DT             TO L5382-TAX-EFF-DT.
029060     MOVE 99999                     TO L5382-POLT-SEQ-NUM.
029060
029060     PERFORM  5382-7500-PRCES-READ-TAX
029060         THRU 5382-7500-PRCES-READ-TAX-X.
029060
029060*    COMPUTE WS-PDCL-DTHCLM-AMT = RCDSA-CDA-TOT-TRXN-AMT
029060*                               - RCDSA-CDA-FED-TAXWH-AMT
029060*                               - RCDSA-CDA-LTAXWH-AMT.
029060
029060     COMPUTE WS-PDCL-DTHCLM-AMT = RCDSA-CDA-TOT-TRXN-AMT
029060                                - L5382-FTAXWH-AMT
029060                                - L5382-LTAXWH-AMT.

       5010-GET-POL-DTHCLM-AMT-X.
           EXIT.

      *------------------------
       5020-GET-CVG-DTHCLM-AMT.
      *------------------------

      * GET RCDSA-CDA-TOT-TRXN-AMT FOR CVG TERMINATION,
      * DEFAULT TO CLAIM AMOUNT

           INITIALIZE WCDSA-KEY.
           MOVE RPOL-POL-ID           TO WCDSA-POL-ID.
           SET WCDSA-CDA-TYP-WTHDR    TO TRUE.
           MOVE ZERO                  TO WCDSA-POL-PAYO-NUM.
           MOVE LOW-VALUES            TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE ZERO                  TO WCDSA-CDA-SEQ-NUM.

           MOVE WCDSA-KEY             TO WCDSA-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCDSA-ENDBR-CDA-EFF-IDT-NUM.
           MOVE +999                  TO WCDSA-ENDBR-CDA-SEQ-NUM.

           PERFORM  CDSA-1000-BROWSE
               THRU CDSA-1000-BROWSE-X.

           PERFORM  CDSA-2000-READ-NEXT
               THRU CDSA-2000-READ-NEXT-X
               UNTIL NOT WCDSA-IO-OK
               OR   (RCDSA-CDA-STAT-ACTIVE
               AND   RCDSA-CVG-NUM-N = WS-CVG-NUM).

           IF  NOT WCDSA-IO-OK
               PERFORM  CDSA-3000-END-BROWSE
                   THRU CDSA-3000-END-BROWSE-X
      *MSG: CANNOT GET CLAIM AMOUNT, NO MATCHING HISTORY RECORD FOUND
               MOVE 'CS73510003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5020-GET-CVG-DTHCLM-AMT-X
           END-IF.

           PERFORM  CDSA-3000-END-BROWSE
               THRU CDSA-3000-END-BROWSE-X.

029060     PERFORM  5382-1000-BUILD-PARM-INFO
029060         THRU 5382-1000-BUILD-PARM-INFO-X.
029060
029060     SET L5382-GET-TAX-TYP-CDSA     TO TRUE.
029060     MOVE RCDSA-CDA-TYP-CD          TO L5382-CDA-TYP-CD.
029060     MOVE RCDSA-CDA-SEQ-NUM         TO L5382-CDA-SEQ-NUM.
029060     MOVE RCDSA-POL-PAYO-NUM        TO L5382-POL-PAYO-NUM.
029060     MOVE RCDSA-CDA-EFF-IDT-NUM     TO L5382-CDA-EFF-IDT-NUM.
029060     MOVE WWKDT-HIGH-DT             TO L5382-TAX-EFF-DT.
029060     MOVE 99999                     TO L5382-POLT-SEQ-NUM.
029060
029060     PERFORM  5382-7500-PRCES-READ-TAX
029060         THRU 5382-7500-PRCES-READ-TAX-X.
029060
029060*    COMPUTE WS-PDCL-DTHCLM-AMT = RCDSA-CDA-TOT-TRXN-AMT
029060*                               - RCDSA-CDA-FED-TAXWH-AMT
029060*                               - RCDSA-CDA-LTAXWH-AMT.
029060
029060     COMPUTE WS-PDCL-DTHCLM-AMT = RCDSA-CDA-TOT-TRXN-AMT
029060                                - L5382-FTAXWH-AMT
029060                                - L5382-LTAXWH-AMT.

       5020-GET-CVG-DTHCLM-AMT-X.
           EXIT.

      *---------------------
       5200-GET-INT-STRT-DT.
      *---------------------

           MOVE WWKDT-ZERO-DT           TO WS-PDCL-DTHCLM-INT-STRT-DT.

      * IF USER SPECIFIC DATE TYPE, USE INPUT INTEREST START DATE

           IF  RPLGR-DTHCLM-INT-DT-USER-DT
               GO TO 5200-GET-INT-STRT-DT-X
           END-IF.

      * GET CLIENT INFO

           PERFORM  5210-OBTAIN-CLI-INFO
               THRU 5210-OBTAIN-CLI-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 5200-GET-INT-STRT-DT-X
           END-IF.

      * OBTAIN INTEREST START DATE DEPENDS ON DATE TYPE CODE IN PLGR

           EVALUATE TRUE

                WHEN RPLGR-DTHCLM-INT-DT-DT-OF-DTH
                     MOVE L2435-CLI-DTH-DT
                       TO WS-PDCL-DTHCLM-INT-STRT-DT

                WHEN RPLGR-DTHCLM-INT-DT-PROOF-DTH
                     MOVE L2435-CLI-DTH-PROOF-DT
                       TO WS-PDCL-DTHCLM-INT-STRT-DT

           END-EVALUATE.

       5200-GET-INT-STRT-DT-X.
           EXIT.

      *---------------------
       5210-OBTAIN-CLI-INFO.
      *---------------------

           MOVE WS-CVG-NUM              TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-3100-GET-PRIM-INSRD
               THRU 2430-3100-GET-PRIM-INSRD-X.

           IF  NOT L2430-RETRN-OK
           OR  L2430-RELATIONSHIP-FOUND-NO
      *MSG: CANNOT GET INTEREST START DATE, NO CLIENT RECORD FOUND
               MOVE 'CS73510004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5210-OBTAIN-CLI-INFO-X
           END-IF.

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X

           MOVE L2430-CLI-ID          TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  NOT L2435-RETRN-OK
      *MSG: CANNOT GET INTEREST START DATE, NO CLIENT RECORD FOUND
               MOVE 'CS73510004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5210-OBTAIN-CLI-INFO-X
           END-IF.

       5210-OBTAIN-CLI-INFO-X.
           EXIT.

      *-------------------
       6000-GET-BENE-INFO.
      *-------------------

           MOVE ZERO                   TO WS-PDCB-CTR.
           MOVE ZERO                   TO WS-TOTAL-DCBNFY-PCT.

      * BROWSE BENE TABLE

           IF  WS-CVG-NUM = ZERO
               PERFORM  6020-BENE-POL-BROWSE
                   THRU 6020-BENE-POL-BROWSE-X
           ELSE
               PERFORM  6040-BENE-CVG-BROWSE
                   THRU 6040-BENE-CVG-BROWSE-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 6000-GET-BENE-INFO-X
           END-IF.

      * IF NO BENE RECORD, SET PDCL STATUS TO ERROR AND EXIT

           IF  WS-PDCB-CTR = ZERO
               SET WS-PDCL-DTHCLM-STAT-ERROR  TO TRUE
               GO TO 6000-GET-BENE-INFO-X
           END-IF.

           IF  WS-PDCB-CTR > WS-MAX-PDCB-CTR
      *MSG:   'BENEIFICARY RECORED EXCEEDS MAXIMUM'
               MOVE 'CS73510005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-TOTAL-DCBNFY-PCT NOT = 100
      *MSG:   'BENEIFICARY PERCENTAGE MUST TOTAL 100%'
               MOVE 'CS73510006'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6000-GET-BENE-INFO-X.
           EXIT.

      *---------------------
       6020-BENE-POL-BROWSE.
      *---------------------

      * GET ALL BENE ON A POLICY

           MOVE LOW-VALUES             TO WBENE-KEY.
           MOVE RPOL-POL-ID            TO WBENE-POL-ID.
           MOVE ZERO                   TO WBENE-BNFY-SEQ-NUM.
           MOVE WBENE-KEY              TO WBENE-ENDBR-KEY.
           MOVE '999'                  TO WBENE-ENDBR-BNFY-SEQ-NUM.

           PERFORM  BENE-1000-BROWSE
               THRU BENE-1000-BROWSE-X.

           PERFORM  BENE-2000-READ-NEXT
               THRU BENE-2000-READ-NEXT-X.

           IF  WBENE-IO-EOF
               PERFORM  BENE-3000-END-BROWSE
                   THRU BENE-3000-END-BROWSE-X
      *MSG (INFO):  'BENEIFICARY RECORED NOT FOUND'
               MOVE 'CS73510007'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6020-BENE-POL-BROWSE-X
           END-IF.

           MOVE ZERO                   TO WS-PDCB-CTR.

           PERFORM  6022-BROWSE-BENE
               THRU 6022-BROWSE-BENE-X
                 UNTIL WS-PDCB-CTR > WS-MAX-PDCB-CTR
                    OR WBENE-IO-EOF.

           PERFORM  BENE-3000-END-BROWSE
               THRU BENE-3000-END-BROWSE-X.

       6020-BENE-POL-BROWSE-X.
           EXIT.

      *-----------------
       6022-BROWSE-BENE.
      *-----------------

           IF  RBENE-CVG-NUM = ZEROES
               CONTINUE
           ELSE
               PERFORM  BENE-2000-READ-NEXT
                   THRU BENE-2000-READ-NEXT-X
               GO TO 6022-BROWSE-BENE-X
           END-IF.

      * DEFAULT BENE CLIENT WITH DESIGNATION = PRIMARY ONLY

           IF  RBENE-BNFY-DESGNT-PRIMARY
               CONTINUE
           ELSE
               PERFORM  BENE-2000-READ-NEXT
                   THRU BENE-2000-READ-NEXT-X
               GO TO 6022-BROWSE-BENE-X
           END-IF.

      * SET PDCL STATUS TO ERROR AND EXIT IF THERE IS A BENE DEATIL
      * BUT WITH NO CLIENT ID.

           IF  RBENE-CLI-ID = SPACES
               SET WS-PDCL-DTHCLM-STAT-ERROR TO TRUE
               PERFORM  BENE-2000-READ-NEXT
                   THRU BENE-2000-READ-NEXT-X
               GO TO 6022-BROWSE-BENE-X
           END-IF.

      * CHECK WHETHER COUNTER EXCEEDS MAXIMUM

           ADD +1                      TO WS-PDCB-CTR.

           IF  WS-PDCB-CTR > WS-MAX-PDCB-CTR
               GO TO 6022-BROWSE-BENE-X
           END-IF.

      * MOVE BENE INFO TO WORKING STORAGE

           MOVE RBENE-CLI-ID           TO WS-PDCB-CLI-ID (WS-PDCB-CTR).
           MOVE RBENE-BNFY-PRCDS-PCT   TO
                                      WS-PDCB-DCBNFY-PCT (WS-PDCB-CTR).

           ADD RBENE-BNFY-PRCDS-PCT    TO WS-TOTAL-DCBNFY-PCT.

      * READ NEXT BENE

           PERFORM  BENE-2000-READ-NEXT
               THRU BENE-2000-READ-NEXT-X.

       6022-BROWSE-BENE-X.
           EXIT.

      *---------------------
       6040-BENE-CVG-BROWSE.
      *---------------------

      * GET ALL BENE ON A COVERAGE

           MOVE LOW-VALUES             TO WBENC-KEY.
           MOVE RPOL-POL-ID            TO WBENC-POL-ID.
           MOVE WS-CVG-NUM             TO WBENC-CVG-NUM.
           MOVE ZERO                   TO WBENC-BNFY-SEQ-NUM.
           MOVE WBENC-KEY              TO WBENC-ENDBR-KEY.
           MOVE '999'                  TO WBENC-ENDBR-BNFY-SEQ-NUM.

           PERFORM  BENC-1000-BROWSE
               THRU BENC-1000-BROWSE-X.

           PERFORM  BENC-2000-READ-NEXT
               THRU BENC-2000-READ-NEXT-X.

           IF  WBENC-IO-EOF
               PERFORM  BENC-3000-END-BROWSE
                   THRU BENC-3000-END-BROWSE-X
      *MSG (INFO):  'BENEIFICARY RECORED NOT FOUND'
               MOVE 'CS73510007'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6040-BENE-CVG-BROWSE-X
           END-IF.

           MOVE ZERO                   TO WS-PDCB-CTR.

           PERFORM  6042-BROWSE-BENC
               THRU 6042-BROWSE-BENC-X
                 UNTIL WS-PDCB-CTR > WS-MAX-PDCB-CTR
                    OR WBENC-IO-EOF.

           PERFORM  BENC-3000-END-BROWSE
               THRU BENC-3000-END-BROWSE-X.

       6040-BENE-CVG-BROWSE-X.
           EXIT.

      *-----------------
       6042-BROWSE-BENC.
      *-----------------

      * SET PDCL STATUS TO ERROR AND EXIT IF THERE IS A BENE DEATIL
      * BUT WITH NO CLIENT ID.

           IF  RBENE-CLI-ID = SPACES
               SET WS-PDCL-DTHCLM-STAT-ERROR TO TRUE
               PERFORM  BENC-2000-READ-NEXT
                   THRU BENC-2000-READ-NEXT-X
               GO TO 6042-BROWSE-BENC-X
           END-IF.

      * DEFAULT BENE CLIENT WITH DESIGNATION = PRIMARY ONLY

           IF  RBENE-BNFY-DESGNT-PRIMARY
               CONTINUE
           ELSE
               PERFORM  BENC-2000-READ-NEXT
                   THRU BENC-2000-READ-NEXT-X
               GO TO 6042-BROWSE-BENC-X
           END-IF.

      * CHECK WHETHER COUNTER EXCEEDS MAXIMUM

           ADD +1                      TO WS-PDCB-CTR.

           IF  WS-PDCB-CTR > WS-MAX-PDCB-CTR
               GO TO 6042-BROWSE-BENC-X
           END-IF.

      * MOVE BENE INFO TO WORKING STORAGE

           MOVE RBENE-CLI-ID           TO WS-PDCB-CLI-ID (WS-PDCB-CTR).
           MOVE RBENE-BNFY-PRCDS-PCT   TO
                                      WS-PDCB-DCBNFY-PCT (WS-PDCB-CTR).

           ADD RBENE-BNFY-PRCDS-PCT    TO WS-TOTAL-DCBNFY-PCT.

      * READ NEXT BENE

           PERFORM  BENC-2000-READ-NEXT
               THRU BENC-2000-READ-NEXT-X.

       6042-BROWSE-BENC-X.
           EXIT.

      *---------------
       8000-EDIT-INFO.
      *---------------

      * VALIDATE KEY INFOMATION

            PERFORM  8010-EDIT-KEY-INFO
                THRU 8010-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

      * LOAD CVGS ARRAY

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

      * CHECK WHETHER PENDING PDCL RECORD EXISTS

           PERFORM  8020-EDIT-PDCL
               THRU 8020-EDIT-PDCL-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

      * CHECK POLICY/COVERAGE STATUS

           PERFORM  8030-EDIT-STAT
               THRU 8030-EDIT-STAT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

      * GET LOCATION GROUP AND PLGR

           PERFORM  8040-EDIT-PLGR
               THRU 8040-EDIT-PLGR-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

       8000-EDIT-INFO-X.
           EXIT.

      *-------------------
       8010-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      *  VALIDATE COVERAGE NUMBER
      *
           IF  MIR-CVG-NUM = SPACES
               MOVE ZERO                   TO WS-CVG-NUM
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE ZERO                       TO L0280-PRECISION.
           MOVE 2                          TO L0280-LENGTH.
           MOVE 2                          TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-NUM                TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'COVERAGE NUMBER MUST BE VALID NUMERIC OR SPACES'
               MOVE 'CS73510008'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           ELSE
               MOVE L0280-OUTPUT           TO WS-CVG-NUM
           END-IF.

       8010-EDIT-KEY-INFO-X.
           EXIT.

      *---------------
       8020-EDIT-PDCL.
      *---------------

           IF  WS-CVG-NUM = ZERO
               PERFORM  8025-EDIT-PDCN
                   THRU 8025-EDIT-PDCN-X
               GO TO 8020-EDIT-PDCL-X
           END-IF.

           MOVE LOW-VALUES              TO WPDCM-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCM-CO-ID.
           MOVE RPOL-POL-ID             TO WPDCM-POL-ID.
           MOVE WS-CVG-NUM              TO WPDCM-CVG-NUM-N.
           MOVE +1                      TO WPDCM-DTHCLM-SEQ-NUM.

           MOVE WPDCM-KEY               TO WPDCM-ENDBR-KEY.
           MOVE +9999                   TO WPDCM-ENDBR-DTHCLM-SEQ-NUM.

           PERFORM  PDCM-1000-BROWSE
               THRU PDCM-1000-BROWSE-X.

           PERFORM  PDCM-2000-READ-NEXT
               THRU PDCM-2000-READ-NEXT-X.

           IF  NOT WPDCM-IO-OK
               PERFORM  PDCM-3000-END-BROWSE
                   THRU PDCM-3000-END-BROWSE-X
               GO TO 8020-EDIT-PDCL-X
           END-IF.

           SET WS-FOUND-NO              TO TRUE.

           PERFORM  8022-EDIT-PDCL-LOOP
               THRU 8022-EDIT-PDCL-LOOP-X
               UNTIL NOT WPDCM-IO-OK
               OR    WS-FOUND.

           PERFORM  PDCM-3000-END-BROWSE
               THRU PDCM-3000-END-BROWSE-X.

       8020-EDIT-PDCL-X.
           EXIT.

      *--------------------
       8022-EDIT-PDCL-LOOP.
      *--------------------

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
               SET WS-FOUND             TO TRUE
      *MSG: PENDING INTEREST ON DEATH CLAIM EXISTS FOR THE
      *     POLICY/COVERAGE WITH STATUS = PENDING OR ERROR,
      *     CREATE NOT ALLOWED
               MOVE 'CS73510009'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8022-EDIT-PDCL-LOOP-X
           END-IF.

           PERFORM  PDCM-2000-READ-NEXT
               THRU PDCM-2000-READ-NEXT-X.

       8022-EDIT-PDCL-LOOP-X.
           EXIT.

      *---------------
       8025-EDIT-PDCN.
      *---------------

           MOVE LOW-VALUES              TO WPDCN-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCN-CO-ID.
           MOVE RPOL-POL-ID             TO WPDCN-POL-ID.
           MOVE +1                      TO WPDCN-DTHCLM-SEQ-NUM.
           MOVE +9999                   TO WPDCN-ENDBR-DTHCLM-SEQ-NUM.

           PERFORM  PDCN-1000-BROWSE
               THRU PDCN-1000-BROWSE-X.

           PERFORM  PDCN-2000-READ-NEXT
               THRU PDCN-2000-READ-NEXT-X.

           IF  NOT WPDCN-IO-OK
               PERFORM  PDCN-3000-END-BROWSE
                   THRU PDCN-3000-END-BROWSE-X
               GO TO 8025-EDIT-PDCN-X
           END-IF.

           SET WS-FOUND-NO              TO TRUE.

           PERFORM  8026-EDIT-PDCN-LOOP
               THRU 8026-EDIT-PDCN-LOOP-X
               UNTIL NOT WPDCN-IO-OK
               OR    WS-FOUND.

           PERFORM  PDCN-3000-END-BROWSE
               THRU PDCN-3000-END-BROWSE-X.

       8025-EDIT-PDCN-X.
           EXIT.

      *--------------------
       8026-EDIT-PDCN-LOOP.
      *--------------------

           IF  RPDCN-DTHCLM-STAT-PEND
           OR  RPDCN-DTHCLM-STAT-ERROR
               SET WS-FOUND             TO TRUE
      *MSG: PENDING INTEREST ON DEATH CLAIM EXISTS FOR THE
      *     POLICY/COVERAGE WITH STATUS = PENDING OR ERROR,
      *     CREATE NOT ALLOWED
               MOVE 'CS73510009'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8026-EDIT-PDCN-LOOP-X
           END-IF.

           PERFORM  PDCN-2000-READ-NEXT
               THRU PDCN-2000-READ-NEXT-X.

       8026-EDIT-PDCN-LOOP-X.
           EXIT.

      *---------------
       8030-EDIT-STAT.
      *---------------

      * A PENDING INTEREST ON DEATH CLAIM RECORD WILL ONLY BE ALLOWED
      * ON INFORCE AND TERMINATED DUE TO DEATH POLICIES

           IF  WS-CVG-NUM = ZERO
               PERFORM  8032-EDIT-POL-STAT
                   THRU 8032-EDIT-POL-STAT-X
           ELSE
               PERFORM  8034-EDIT-CVG-STAT
                   THRU 8034-EDIT-CVG-STAT-X
           END-IF.

       8030-EDIT-STAT-X.
           EXIT.

      *-------------------
       8032-EDIT-POL-STAT.
      *-------------------

           IF  RPOL-POL-STAT-IN-FORCE
           OR  RPOL-POL-STAT-DEATH
               CONTINUE
           ELSE
      *MSG: PENDING INTEREST ON DEATH CLAIM ALLOWED ON INFORCE AND
      *     TERMINATED ON DEATH POLICIES ONLY
               MOVE 'CS73510010'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8032-EDIT-POL-STAT-X.
           EXIT.

      *-------------------
       8034-EDIT-CVG-STAT.
      *-------------------

           IF  WS-CVG-NUM > RPOL-POL-CVG-REC-CTR-N
      *MSG: THE COVERAGE (@1) DOES NOT EXIST
               MOVE 'CS73510013'          TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8034-EDIT-CVG-STAT-X
           END-IF.

           IF  WCVGS-CVG-STAT-IN-FORCE (WS-CVG-NUM)
           OR  WCVGS-CVG-STAT-DEATH (WS-CVG-NUM)
               CONTINUE
           ELSE
      *MSG: PENDING INTEREST ON DEATH CLAIM ALLOWED ON INFORCE AND
      *     TERMINATED ON DEATH COVERAGES ONLY
               MOVE 'CS73510012'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8034-EDIT-CVG-STAT-X.
           EXIT.

      *---------------
       8040-EDIT-PLGR.
      *---------------

      * CHECK AGAINST PLGR TABLE TO ENSURE THAT A PENDING INTEREST IS
      * ALLOWED FOR THE POLICY


           IF  WS-POL-PRCES
               MOVE RPOL-POL-BASE-CVG-NUM  TO  I
           ELSE
               MOVE WS-CVG-NUM             TO  I
           END-IF.

           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.

           PERFORM  8042-BUILD-PLGR-KEY
               THRU 8042-BUILD-PLGR-KEY-X.

           IF  L3330-RETRN-OK
               PERFORM  PLGR-1000-READ
                   THRU PLGR-1000-READ-X
               IF  NOT WPLGR-IO-OK
      *MSG 'PLAN RULE VARIATIONS FOR @1, @2 NOT FOUND BY PGM @3'
                   MOVE 'CS00000063'      TO WGLOB-MSG-REF-INFO
                   MOVE WPLGR-PLAN-ID     TO WGLOB-MSG-PARM (1)
                   MOVE WPLGR-LOC-GR-ID   TO WGLOB-MSG-PARM (2)
                   MOVE WPGWS-CRNT-PGM-ID TO WGLOB-MSG-PARM (3)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 8040-EDIT-PLGR-X
               END-IF
           END-IF.

       8040-EDIT-PLGR-X.
           EXIT.

      *--------------------
       8042-BUILD-PLGR-KEY.
      *--------------------

           PERFORM  3330-1000-BUILD-PARM-INFO
               THRU 3330-1000-BUILD-PARM-INFO-X.

           SET L3330-LOC-GR-TYP-DCIDT   TO TRUE.

           PERFORM  3330-1000-GET-LOC-GROUP
               THRU 3330-1000-GET-LOC-GROUP-X.

           IF  L3330-RETRN-OK
               CONTINUE
           ELSE
      * MSG: 'LOCATION GROUP NOT FOUND FOR @1,TYPE '@2' BY PGM @3'
               MOVE 'CS00000064'        TO WGLOB-MSG-REF-INFO
               MOVE RPH-LOC-GR-COLCT-ID TO WGLOB-MSG-PARM (1)
               MOVE L3330-LOC-GR-TYP-CD TO WGLOB-MSG-PARM (2)
               MOVE WPGWS-CRNT-PGM-ID   TO WGLOB-MSG-PARM (3)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8042-BUILD-PLGR-KEY-X
           END-IF.

           MOVE L3330-LOC-GR-ID         TO WPLGR-LOC-GR-ID.

           IF  I = 0
               MOVE RPOL-PLAN-ID        TO WPLGR-PLAN-ID
           ELSE
               MOVE WCVGS-PLAN-ID (I)   TO WPLGR-PLAN-ID
035251*        IF  WCVGS-PLAN-ID-BASE-3-5 (I) = 'RPU'
035251*        OR  WCVGS-PLAN-ID-BASE-3-5 (I) = 'ETI'
035251*            MOVE WCVGS-ORIG-PLAN-ID (I)
035251*                                 TO L3330-PLAN-ID
035251*            MOVE L3330-PLAN-ID   TO WPLGR-PLAN-ID
035251*        END-IF
           END-IF.

       8042-BUILD-PLGR-KEY-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  2435-0000-INIT-PARM-INFO
               THRU 2435-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           PERFORM  3330-0000-INIT-PARM-INFO
               THRU 3330-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

029060     PERFORM  5382-0000-INIT-PARM-INFO
029060         THRU 5382-0000-INIT-PARM-INFO-X.
029060
029060     PERFORM  0182-0000-INIT-PARM-INFO
029060         THRU 0182-0000-INIT-PARM-INFO-X.
029060
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           INITIALIZE FREQUENTLY-USED-INDICES.

           SET WS-TWRK-KEY-DEFAULT   TO TRUE.
           SET MIR-RETRN-OK          TO TRUE.

           MOVE SPACES TO WWKDT-WORK-FIELDS.
           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
       COPY CCPPPLIN.
       COPY CCPPMIDT.
       COPY NCPPCVGS.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY CCPS3330.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL3330.

       COPY CCPS2430.
       COPY CCPL2430.

       COPY CCPS2435.
       COPY CCPL2435.

       COPY XCPS0290.
       COPY XCPL0290.

       COPY XCPL0260.
       COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL8090.
029060
029060 COPY CCPS5382.
029060 COPY CCPL5382.
029060
029060 COPY CCPS0182.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNCVG.

       COPY CCPBCDSA.

       COPY CCPBBENE.
       COPY CCPBBENC.

       COPY CCPNPH.

       COPY CCPNPLGR.

       COPY CCPAPDCL.
       COPY CCPBPDCL.
       COPY CCPCPDCL.
       COPY CCPFPDCL.

       COPY CCPBPDCM.

       COPY CCPBPDCN.

       COPY CCPAPDCB.
       COPY CCPBPDCB.
       COPY CCPCPDCB.
       COPY CCPFPDCB.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7351                     **
      *****************************************************************
