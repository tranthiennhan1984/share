      *------------------------
       IDENTIFICATION DIVISION.
      *------------------------
      *
       PROGRAM-ID. SSOM0090.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER : SSOM0090                                          **
      **  REMARKS: 'FREV' - PROCESS SEGREGATED FUND TRANSACTION      **
      **                    REVERSALS.                               **
      **           THIS MODULE IS USED TO PROCESS SEGREGATED FUND    **
      **           TRANSACTION REVERSALS. PROCESSING IS DONE HERE TO **
      **           OBTAIN A VALID FUND ACTIVITY RECORD FOR REVERSAL, **
      **           AND ONE OF FOUR FUNCTION DRIVERS WILL BE CALLED   **
      **           TO REVERSE A DEPOSIT, SURRENDER, ADMIN. CHARGE OR **
      **           TRANSFER.                                         **
      **                                                             **
      **  DOMAIN : CV                                                **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557701**  5.5       UNDO/REDO FOR SEGFUNDS                           **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
010842**  5.5.2     SCRE/DEST NOT DISPLAY                            **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012134**  5.6V      PASS IN TAX YEAR TO FPAY                         **
012137**  5.6V      NEW SUPPRESS CONFIRMATION SCREEN FIELD           **
012143**  5.6V      INVOKE NEW DEPOSIT REVERSAL FD (FSLF2750),       **
012146**  5.6V      LOAD SEGFUND LINKAGE COPYBOOK WITH UNIT TYPE     **
012696**  5.6V      ADD SUPPORT FOR POLICY LEVEL TRANSFERS           **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
012624**  6.0       POLICY ACCESS VERIFICATION                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       RENAME 0000-MAINLINE                             **
014221**  6.2       LOGICAL LOCKING                                  **
015981**  6.2       SEGFUND SESSION TOTAL                            **
016395**  6.2       CREDIT CARD BILLING                              **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019573**  6.4       WRITE CDSA RECORDS FOR ALL TYPES OF ACTIVITY     **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021311**  6.4       MULTI-PLATFORM SUPPORT                           **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023166**  6.5       FIX INCORRECT ACCOUNTING ON DEPOSIT REVERSAL     **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
028065**  6.6       PGAL OUT OF SYNCH AFTER AUTOMATIC UNDO/REDO      **
031034**  7.0       TAX COMPONENTIZATON                              **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       ENVIRONMENT DIVISION.
      *---------------------
      *
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0090'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  TRANSACTION-NAME      PIC X(04)  VALUE 'FREV'.
025970*    05  NUM-ERR-LN            PIC 99     VALUE 03.
           05  ERROR-LINE-SCREEN     PIC 99.
           05  WS-BUS-FCN-ID         PIC X(04).
               88  WS-BUS-FCN-VALID              VALUE '1790'.
               88  WS-BUS-FCN-REVERSE            VALUE '1790'.

025970 01  WS-CONSTANTS.
025970     05  TRANSACTION-NAME      PIC X(04).
025970         88  TRANSACTION-NAME-DEFAULT     VALUE 'FREV'.
      *
       COPY CCFHPOL.
      *
025970*01  HOLD-SQ                   PIC 9(4).
025970*01  HOLD-RUN-ID               PIC X       VALUE '0'.
      *
      /
557756*COPY CCWTYSNO.
      /
020478 COPY CCWL2626.
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
008455/
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1660.
      /
       01  HOLD-MAP-AREA.
           05  HOLD-COVERAGE.
               10 HOLD-COVERAGE-9        PIC 99.
           05  HOLD-COVERAGE-R REDEFINES HOLD-COVERAGE.
               10 HOLD-COVERAGE-R1       PIC X.
               10 HOLD-COVERAGE-R2       PIC X.
008453*    05  HOLD-EFF-DATE             PIC X(09).
           05  HOLD-SEQUENCE.
               10 HOLD-SEQUENCE-9        PIC 999.
           05  HOLD-SEQUENCE-R REDEFINES HOLD-SEQUENCE.
               10 HOLD-SEQUENCE-R1       PIC X.
               10 HOLD-SEQUENCE-R2       PIC X.
               10 HOLD-SEQUENCE-R3       PIC X.
008455*    05  WS-AMOUNT-OUT             PIC -------9.99.
      /
       01  WS-MISC-AREA.
           05  ERROR-SW                  PIC 99.
               88  NO-ERROR              VALUE 0.
               88  ERROR-OCCURED         VALUE 1.
           05  WS-INTERNAL-DATE          PIC X(10).
           05  WS-KEY-EFF-DATE           PIC 9(07).
           05  FA-CHAIN-SW               PIC X.
               88  FA-CHAIN-FINISHED     VALUE 'Y'.
           05  WS-SUBSCRIPTS.
016548*        10  I                     PIC S9(4) COMP.
016548         10  I                     PIC S9(4) BINARY.
016548*        10  J                     PIC S9(4) COMP.
016548         10  J                     PIC S9(4) BINARY.
016548*        10  K                     PIC S9(4) COMP.
016548         10  K                     PIC S9(4) BINARY.
016548*        10  N8                    PIC S9(4) COMP.
016548         10  N8                    PIC S9(4) BINARY.
016548*        10  L-NUM                 PIC S9(4) COMP.
016548         10  L-NUM                 PIC S9(4) BINARY.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY SCFWFA.
       COPY SCFRFA.
      /
       COPY SCFRFAAG.
       COPY SCFWFAAG.
      /
       COPY CCFWPOL.
      /
016108 COPY CCWL0985.
016108/
       COPY CCWL4350.
557701/
557701 COPY CCWL4750.
      /
       COPY CCWL5400.
      /
016503 COPY CCWL0289.
016503/
031034*COPY CCWLPGAL.
015290/
012143 COPY FCWL2750.
012143/
012143 COPY FCWL2770.
012143/
019573 COPY FCWL2780.
      /
       COPY SCWLSEGF.
      /
       COPY SCWL0500.
      /
016537*COPY SCWL6320.
      /
016537*COPY SCWL6330.
      /
       COPY SCWL6340.
      /
021930*COPY SCWL6350.
021930*
014221 COPY XCWL8090.
557756/
013578*COPY XCWL2510.
013578*
014035*COPY XCWWTSQP.
014035*COPY SCWWPDTQ.
       COPY SCWWAGFA.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0090.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
015543 0000-MAINLINE.
      *----------------
      *
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

021311     PERFORM  9990-INIT-WORKING-STORAGE
021311         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
      *
           PERFORM  0200-PROCESS-TRANSACTIONS
               THRU 0200-PROCESS-TRANSACTIONS-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

015543 0000-MAINLINE-X.
           EXIT.
      /
557756*        EVALUATE TRUE
557756*            WHEN WGLOB-USER-LANG-ENGLISH
557756*                MOVE 'DDMMMYYYY' TO MIR-CIA-EFF-DT
557756*            WHEN WGLOB-USER-LANG-FRENCH
557756*                MOVE 'JJMMMAAAA' TO MIR-CIA-EFF-DT
557756*            WHEN WGLOB-USER-LANG-SPANISH
557756*                MOVE 'DDMMMAAAA' TO MIR-CIA-EFF-DT
557756*            WHEN OTHER
557756*                MOVE 'DDMMMYYYY' TO MIR-CIA-EFF-DT
557756*        END-EVALUATE
      /
       0150-INIT-TRANS.
      *----------------
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.
      *
       0150-INIT-TRANS-X.
           EXIT.
      /
      *--------------------------
       0200-PROCESS-TRANSACTIONS.
      *--------------------------
      *
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST
                                      TO TRUE
               GO TO 0200-PROCESS-TRANSACTIONS-X
           END-IF.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
           PERFORM  0150-INIT-TRANS
               THRU 0150-INIT-TRANS-X.
           MOVE 1                     TO ERROR-LINE-SCREEN.
           PERFORM  0510-MAP-TO-HOLD
               THRU 0510-MAP-TO-HOLD-X.
      *
           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
               PERFORM  0700-HOLD-TO-OUT
                   THRU 0700-HOLD-TO-OUT-X
               GO TO 0200-PROCESS-TRANSACTIONS-X
           END-IF.
      *
           PERFORM  0530-TRANS-SEQ-CHECK
               THRU 0530-TRANS-SEQ-CHECK-X.
      *
           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
               PERFORM  0700-HOLD-TO-OUT
                   THRU 0700-HOLD-TO-OUT-X
               GO TO 0200-PROCESS-TRANSACTIONS-X
557660     END-IF.
      *
           PERFORM  0540-INPUT-KEY-CHECK-GET
               THRU 0540-INPUT-KEY-CHECK-GET-X.
      *
           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
               PERFORM  0700-HOLD-TO-OUT
                   THRU 0700-HOLD-TO-OUT-X
               GO TO 0200-PROCESS-TRANSACTIONS-X
           END-IF.

           PERFORM  1000-DISPLAY-FA
               THRU 1000-DISPLAY-FA-X.
           PERFORM  2000-REVERSE-FA
               THRU 2000-REVERSE-FA-X.
      *
           IF  WGLOB-GOOD-RETURN
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               PERFORM  0700-HOLD-TO-OUT
                   THRU 0700-HOLD-TO-OUT-X
               GO TO 0200-PROCESS-TRANSACTIONS-X
557660     END-IF.

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '2'
                    MOVE 'SS00900003' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM  2500-VERIFY-REVERSE
                        THRU 2500-VERIFY-REVERSE-X

           END-EVALUATE.

       0200-PROCESS-TRANSACTIONS-X.
           EXIT.
      *------------
      *
      /
      *-----------------
       0510-MAP-TO-HOLD.
      *-----------------

           IF MIR-CIA-SEQ-NUM = SPACES
              MOVE ZEROES             TO HOLD-SEQUENCE
           ELSE
               MOVE MIR-CIA-SEQ-NUM   TO HOLD-SEQUENCE
557660     END-IF.

       0510-MAP-TO-HOLD-X.
           EXIT.
      /
      *---------------------
       0530-TRANS-SEQ-CHECK.
      *---------------------
      *
           IF MIR-CIA-TYP-CD = SPACES
           OR MIR-CIA-TYP-CD = 'DEP'
           OR MIR-CIA-TYP-CD = 'SUR'
           OR MIR-CIA-TYP-CD = 'TRS'
           OR MIR-CIA-TYP-CD = 'ADM'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'SS00900010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           SET L0280-SIGN-NOT-PERMITTED
                                      TO TRUE.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE HOLD-SEQUENCE         TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO HOLD-SEQUENCE-9
           END-IF.
           IF  HOLD-SEQUENCE-R1 = '.'
           OR  HOLD-SEQUENCE-R2 = '.'
           OR  HOLD-SEQUENCE-R3 = '.'
           OR  HOLD-SEQUENCE NOT NUMERIC
               MOVE 'SS00900011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF  MIR-CIA-REVRS-REASN-CD NOT = 'NSF'
           AND MIR-CIA-REVRS-REASN-CD NOT = 'SUS'
           AND MIR-CIA-REVRS-REASN-CD NOT = '   '
016395     AND MIR-CIA-REVRS-REASN-CD NOT = 'CRR'
               MOVE 'SS00900004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       0530-TRANS-SEQ-CHECK-X.
           EXIT.
      *-----------------------
      *
      *-------------------------
       0540-INPUT-KEY-CHECK-GET.
      *-------------------------

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.
           IF  WPOL-KEY NOT = RPOL-KEY
014221*        PERFORM  POL-1000-READ
014221*            THRU POL-1000-READ-X
014221         EVALUATE TRUE
014221             WHEN  MIR-DV-PRCES-STATE-CD = '1'
014221             WHEN  MIR-DV-PRCES-STATE-CD = '2'
014221                PERFORM  POL-1000-READ-TWRK-TS
014221                    THRU POL-1000-READ-TWRK-TS-X
014221             WHEN  MIR-DV-PRCES-STATE-CD = '3'
014221                PERFORM  POL-2000-UPDATE-TWRK-TS
014221                    THRU POL-2000-UPDATE-TWRK-TS-X
014221                IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                    MOVE 'XS00000303' TO WGLOB-MSG-REF-INFO
014221                    MOVE 'POL'        TO WGLOB-MSG-PARM (01)
014221                    MOVE WPOL-KEY     TO WGLOB-MSG-PARM (02)
014221                    PERFORM  0260-1000-GENERATE-MESSAGE
014221                        THRU 0260-1000-GENERATE-MESSAGE-X
014221                    SET WGLOB-RETURN-ERROR
014221                                      TO TRUE
014221                    GO TO 0540-INPUT-KEY-CHECK-GET-X
014221                ELSE
014221                    IF  WPOL-IO-OK
014221                        PERFORM  POL-3000-UNLOCK
014221                            THRU POL-3000-UNLOCK-X
014221                    END-IF
014221                END-IF
014221         END-EVALUATE
               IF  NOT WPOL-IO-OK
                   MOVE 'CS00000019'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
016537             SET WGLOB-RETURN-ERROR
016537                                TO TRUE
                   GO TO 0540-INPUT-KEY-CHECK-GET-X
               END-IF
      *
      *** POLICY CONTROL CHECK
      *
016440         PERFORM  CVG-1000-READ
016440             THRU CVG-1000-READ-X

016440*        IF  RPOL-POL-APPL-CTL-NBS
016440         IF  WCVG-IO-OK
016440         AND RCVG-CVG-STAT-BEFORE-SETL
012624             MOVE 'XS00000238'  TO WGLOB-MSG-REF-INFO
012624             PERFORM  0260-1000-GENERATE-MESSAGE
012624                 THRU 0260-1000-GENERATE-MESSAGE-X
012624             SET WGLOB-RETURN-ERROR
012624                                TO TRUE
012624             GO TO 0540-INPUT-KEY-CHECK-GET-X
012624         END-IF
012624
               PERFORM  5400-1000-BUILD-PARM-INFO
                   THRU 5400-1000-BUILD-PARM-INFO-X
012624*        SET L5400-SYS-APPL-CTL-ADMIN
012624*                               TO TRUE
016440         SET L5400-POL-XFER-UPDATE TO TRUE
               PERFORM  5400-1000-POL-CHK
                   THRU 5400-1000-POL-CHK-X
               IF  L5400-CNFD-ACCS-RESTRICTED
012624*        OR  L5400-CTL-ACCS-RESTRICTED
               OR  L5400-BRCH-ACCS-RESTRICTED
               OR  L5400-STAT-ACCS-RESTRICTED
016440         OR  L5400-XFER-ACCS-RESTRICTED
                   SET WGLOB-RETURN-ERROR
                                      TO TRUE
                   GO TO 0540-INPUT-KEY-CHECK-GET-X
557660         END-IF
557660     END-IF.

           MOVE RPOL-POL-ID           TO LPGA-POLICY-NUMBER.

           SET L0280-SIGN-NOT-PERMITTED
                                      TO TRUE.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO HOLD-COVERAGE-9
020874*        MOVE HOLD-COVERAGE     TO MIR-CVG-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM
           END-IF.

           IF HOLD-COVERAGE-R1 = '.' OR
               HOLD-COVERAGE-R2 = '.' OR
               HOLD-COVERAGE NOT NUMERIC
               MOVE 'SS00900012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE MIR-CIA-EFF-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
               MOVE 'SS00900013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WWKDT-ZERO-DT     TO WS-INTERNAL-DATE
               MOVE ZEROES            TO WS-KEY-EFF-DATE
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WS-INTERNAL-DATE
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE
                                      TO WS-KEY-EFF-DATE
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW = ZERO
               EVALUATE TRUE

                   WHEN MIR-CIA-TYP-CD = SPACES
                   AND  MIR-CIA-SEQ-NUM  = ZEROES
                        PERFORM  0541-GET-FIRST
                            THRU 0541-GET-FIRST-X

                   WHEN MIR-CIA-TYP-CD NOT = SPACES
                   AND  MIR-CIA-SEQ-NUM = ZEROES
                        PERFORM  0542-GET-FIRST-MATCH
                            THRU 0542-GET-FIRST-MATCH-X

                   WHEN MIR-CIA-TYP-CD = SPACES
                   AND  MIR-CIA-SEQ-NUM NOT = ZEROES
                         PERFORM  0543-GET-DIRECT
                             THRU 0543-GET-DIRECT-X

                   WHEN MIR-CIA-TYP-CD NOT = SPACES
                   AND  MIR-CIA-SEQ-NUM NOT = ZEROES
                         PERFORM  0544-GET-DIRECT-MATCH
                             THRU 0544-GET-DIRECT-MATCH-X

557660         END-EVALUATE
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW = ZERO
           AND RFA-CIA-TYP-CD = 'ADM'
           AND RFA-CIA-REASN-MORT-CHRG
               MOVE 'SS00900021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

031036     IF  WGLOB-MSG-ERROR-SW = ZERO
031036     AND (RFA-CIA-REASN-XEMP-MGMT-PREV
031036     OR   RFA-CIA-REASN-XEMP-MGMT-CRNT)
031036*MSG : FUND ACTIVITY THAT RESULTED FROM EXEMPT STATUS MANAGEMENT
031036*      CANNOT BE REVERSED
031036         MOVE 'SS00900029'      TO WGLOB-MSG-REF-INFO
031036         PERFORM  0260-1000-GENERATE-MESSAGE
031036             THRU 0260-1000-GENERATE-MESSAGE-X
031036     END-IF.
031036
           IF  WGLOB-MSG-ERROR-SW = ZERO
               COMPUTE HOLD-SEQUENCE-9 = 1000 - RFA-CIA-SEQ-NUM
               MOVE RFA-REC-INFO      TO LSEGF-CIA-REC-INFO
               MOVE WAGFA-WORK-AREA   TO LSEGF-CIA-FAAG-WORK-AREA
557660     END-IF.

       0540-INPUT-KEY-CHECK-GET-X.
           EXIT.
      *--------------
      *

       0541-GET-FIRST.
      *---------------
      *
           PERFORM  0550-BUILD-FA-KEY
               THRU 0550-BUILD-FA-KEY-X.
      *
           PERFORM  FA-1000-BROWSE
               THRU FA-1000-BROWSE-X.
           IF WFA-IO-EOF
               MOVE 'SS00900014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  FA-2000-READ-NEXT
                   THRU FA-2000-READ-NEXT-X
               PERFORM  AGFA-1000-BUILD-ARRAY
                   THRU AGFA-1000-BUILD-ARRAY-X
               IF WFA-IO-OK
               AND RFA-CIA-REVRS-PRCES-DT = WWKDT-ZERO-DT
               AND (RFA-CIA-TYP-CD = 'DEP'  OR
                    RFA-CIA-TYP-CD = 'SUR'  OR
                    RFA-CIA-TYP-CD = 'ADM')
                   PERFORM  FA-3000-END-BROWSE
                       THRU FA-3000-END-BROWSE-X
               ELSE
                   PERFORM  FA-3000-END-BROWSE
                       THRU FA-3000-END-BROWSE-X
                   MOVE 'SS00900015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
       0541-GET-FIRST-X.
           EXIT.
      *------------
      /
      *------------------------
       0542-GET-FIRST-MATCH.
      *------------------------
      *
           PERFORM  0550-BUILD-FA-KEY
               THRU 0550-BUILD-FA-KEY-X.
      *
           PERFORM  FA-1000-BROWSE
               THRU FA-1000-BROWSE-X.
           IF WFA-IO-EOF
               MOVE 'SS00900014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  FA-2000-READ-NEXT
                   THRU FA-2000-READ-NEXT-X
                  UNTIL WFA-IO-EOF
      *-- NONE EXIST
                     OR (RFA-POL-ID     = RPOL-POL-ID
      *-- FOUND
                     AND RFA-CVG-NUM-N          = MIR-CVG-NUM
                     AND RFA-CIA-IDT-NUM-N      = WS-KEY-EFF-DATE
                     AND RFA-CIA-TYP-CD         = MIR-CIA-TYP-CD
                     AND RFA-CIA-REVRS-PRCES-DT = WWKDT-ZERO-DT)
               PERFORM  AGFA-1000-BUILD-ARRAY
                   THRU AGFA-1000-BUILD-ARRAY-X
      *-- NOT FOUND
      *
               IF WFA-IO-OK
                   PERFORM  FA-3000-END-BROWSE
                       THRU FA-3000-END-BROWSE-X
               ELSE
                   PERFORM  FA-3000-END-BROWSE
                       THRU FA-3000-END-BROWSE-X
                   MOVE 'SS00900015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
       0542-GET-FIRST-MATCH-X.
           EXIT.
      *-------------
      *
      *----------------
       0543-GET-DIRECT.
      *----------------
      *
           PERFORM  0550-BUILD-FA-KEY
               THRU 0550-BUILD-FA-KEY-X.
           COMPUTE WFA-CIA-SEQ-NUM = 1000 - HOLD-SEQUENCE-9.
      *
           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.
           PERFORM  AGFA-1000-BUILD-ARRAY
               THRU AGFA-1000-BUILD-ARRAY-X.
           IF NOT WFA-IO-OK
               MOVE 'SS00900014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0543-GET-DIRECT-X
           END-IF.

           IF  RFA-CIA-TYP-CD NOT = 'DEP'
           AND RFA-CIA-TYP-CD NOT = 'SUR'
           AND RFA-CIA-TYP-CD NOT = 'ADM'
               MOVE 'SS00900015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0543-GET-DIRECT-X
           END-IF.

           IF RFA-CIA-REVRS-PRCES-DT NOT = WWKDT-ZERO-DT
               MOVE 'SS00900016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       0543-GET-DIRECT-X.
           EXIT.
      *------------
      *
      *----------------------
       0544-GET-DIRECT-MATCH.
      *----------------------
      *
           PERFORM  0550-BUILD-FA-KEY
               THRU 0550-BUILD-FA-KEY-X.
           COMPUTE WFA-CIA-SEQ-NUM = 1000 - HOLD-SEQUENCE-9.
      *
           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.
           PERFORM  AGFA-1000-BUILD-ARRAY
               THRU AGFA-1000-BUILD-ARRAY-X.
           IF NOT WFA-IO-OK
               MOVE 'SS00900014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0544-GET-DIRECT-MATCH-X
           END-IF.

           IF RFA-CIA-TYP-CD NOT = MIR-CIA-TYP-CD
               MOVE 'SS00900015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0544-GET-DIRECT-MATCH-X
           END-IF.

           IF RFA-CIA-REVRS-PRCES-DT NOT = WWKDT-ZERO-DT
               MOVE 'SS00900016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       0544-GET-DIRECT-MATCH-X.
           EXIT.
      *-------------

      *-----------------
       0550-BUILD-FA-KEY.
      *-----------------

           MOVE LOW-VALUES            TO WFA-KEY.
           MOVE MIR-POL-ID-BASE            TO WFA-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO WFA-POL-ID-SFX.
           MOVE MIR-CVG-NUM           TO WFA-CVG-NUM-N.
           MOVE WS-KEY-EFF-DATE       TO WFA-CIA-IDT-NUM-N.
           MOVE WFA-KEY               TO WFA-ENDBR-KEY.
           MOVE +999                  TO WFA-ENDBR-CIA-SEQ-NUM.

       0550-BUILD-FA-KEY-X.
           EXIT.

      /
      *-----------------
       0700-HOLD-TO-OUT.
      *-----------------

           MOVE HOLD-SEQUENCE         TO MIR-CIA-SEQ-NUM.

       0700-HOLD-TO-OUT-X.
           EXIT.

      *----------------
       1000-DISPLAY-FA.
      *----------------
      *
           PERFORM  0700-HOLD-TO-OUT
               THRU 0700-HOLD-TO-OUT-X.
      *
           MOVE RFA-CIA-EFF-DT        TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-NOT-VALID
              MOVE SPACES             TO MIR-CIA-EFF-DT-2
           ELSE
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CIA-EFF-DT-2
557660     END-IF.
      *
           MOVE RFA-CIA-PRCES-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-NOT-VALID
              MOVE SPACES             TO MIR-CIA-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CIA-PRCES-DT
557660     END-IF.
      *
           MOVE WGLOB-PROCESS-DATE    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-NOT-VALID
              MOVE SPACES             TO MIR-CIA-REVRS-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CIA-REVRS-PRCES-DT
557660     END-IF.
      *
           MOVE RFA-CIA-TYP-CD        TO MIR-CIA-TYP-CD-2.
           MOVE RFA-CIA-REASN-CD      TO MIR-CIA-REASN-CD.
           MOVE MIR-CIA-REVRS-REASN-CD
                                      TO MIR-CIA-REVRS-REASN-CD-2.
008455*    MOVE RFA-CIA-CLI-TRXN-AMT   TO WS-AMOUNT-OUT.
008455*    MOVE WS-AMOUNT-OUT          TO MIR-CIA-FND-TRXN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CIA-CLI-TRXN-AMT * 100.
020874     MOVE RFA-CIA-CLI-TRXN-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CIA-FND-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CIA-FND-TRXN-AMT.
           MOVE RFA-CIA-CLI-TRXN-AMT  TO LSEGF-INPUT-AMT.
      *
      *
      *
       1000-DISPLAY-FA-X.
           EXIT.
      /
      *---------------------
       2000-REVERSE-FA.
      *---------------------

           MOVE RPOL-POL-ID           TO WCVG-POL-ID.
           IF RPOL-POL-CVG-REC-CTR-N NOT = ZERO
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-REVERSE-FA-X
557660     END-IF.

016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WS-INTERNAL-DATE      TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         SET WGLOB-RETURN-ERROR TO TRUE
016108         GO TO 2000-REVERSE-FA-X
016108     END-IF.

           MOVE RPOL-POL-ID           TO LSEGF-INV-CVG-REST-KEY-INFO.
           MOVE HOLD-COVERAGE         TO LSEGF-INV-CVG-CVG-NUM.
           MOVE WS-INTERNAL-DATE      TO LSEGF-INV-CVG-CFN-EFF-DT.
           MOVE HOLD-COVERAGE-9       TO I.
           MOVE WCVGS-PLAN-ID (I)     TO LSEGF-PLAN-ID.
012146     MOVE WCVGS-CVG-UNIT-TYP-CD (I)
012146                                TO LSEGF-CVG-UNIT-TYP-CD.
           MOVE SPACES                TO LSEGF-ALLOC-INFO.
           SET LSEGF-INV-CVG-CFN-OPT-READ-INQ
                                      TO TRUE.
           PERFORM  0500-1000-PROCESS-FC-FS
               THRU 0500-1000-PROCESS-FC-FS-X.
           IF L0500-RETRN-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-REVERSE-FA-X
557660     END-IF.

           MOVE MIR-POL-ID-BASE            TO LSEGF-INPUT-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO LSEGF-INPUT-POL-ID-SFX.
           MOVE HOLD-COVERAGE         TO LSEGF-INPUT-CVG-NUM.
           MOVE WS-INTERNAL-DATE      TO LSEGF-INPUT-EFF-DT.
           COMPUTE LSEGF-INPUT-SEQ-NUM = 1000 - HOLD-SEQUENCE-9.
           MOVE RFA-REC-INFO          TO LSEGF-CIA-REC-INFO.
           MOVE WAGFA-WORK-AREA       TO LSEGF-CIA-FAAG-WORK-AREA.
           SET LSEGF-CIA-FIA-OPT-REV  TO TRUE.
           MOVE MIR-CIA-REVRS-REASN-CD
                                      TO LSEGF-INPUT-REASN-CD.
           MOVE LSEGF-INPUT-SEQ-NUM   TO LSEGF-INV-CVG-CFN-SEQ-NUM.
           MOVE RFA-CIA-REG-FND-SRC-CD
                                      TO LSEGF-INPUT-REG-FND-SRC-CD.
010842     MOVE RFA-CIA-SRC-DEST-CD   TO LSEGF-INPUT-SRC-CD.
012134     MOVE RFA-CIA-TAX-YR        TO LSEGF-INPUT-TAX-YR.

012143*    IF RFA-CIA-TYP-CD = 'DEP'
012143*       PERFORM  6320-1000-BUILD-PARM-INFO
012143*           THRU 6320-1000-BUILD-PARM-INFO-X
012143*       MOVE LSEGF-INPUT-EFF-DT      TO L6320-EFF-DATE
012143*       MOVE LSEGF-INV-CVG-CVG-NUM   TO L6320-CVG
012143*       PERFORM  6320-3000-PROCESS-DEP-REV
012143*           THRU 6320-3000-PROCESS-DEP-REV-X
012143*       IF L6320-RETRN-ERROR
012143*          SET WGLOB-RETURN-ERROR TO TRUE
012143*          GO TO 2000-REVERSE-FA-X
012143*       END-IF

012143     IF  RFA-CIA-TYP-DPOS
012143     AND MIR-DV-PRCES-STATE-CD NOT = '3'
012143         PERFORM  2750-1000-BUILD-PARM-INFO
012143             THRU 2750-1000-BUILD-PARM-INFO-X
012143         SET  L2750-PRCES-TYP-EDIT-ONLY
012143                                TO TRUE
012143         MOVE LSEGF-INV-CVG-CVG-NUM
                                      TO L2750-CVG-NUM
012143         MOVE MIR-CIA-REVRS-REASN-CD
                                      TO L2750-REASON
012143         MOVE LSEGF-PARM-INFO   TO L2750-CASHFLOW-SEGFUND-AREA
012137         IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137             SET  L2750-SUPR-CONF
012137                                TO TRUE
012137         END-IF
023166         SET L2750-FCN-DRVR-SECONDARY  TO TRUE
012143         PERFORM  2750-1000-DEPOSIT-REVERSAL
012143            THRU 2750-1000-DEPOSIT-REVERSAL-X
012143         MOVE L2750-CASHFLOW-SEGFUND-AREA
012143                                TO LSEGF-PARM-INFO
012143         IF  L2750-RETRN-ERROR
012143             SET  WGLOB-RETURN-ERROR
012143                                TO TRUE
012143             GO TO 2000-REVERSE-FA-X
012143         END-IF
           END-IF.

012143*    IF RFA-CIA-TYP-CD = 'SUR'
012143*       PERFORM  6330-1000-BUILD-PARM-INFO
012143*           THRU 6330-1000-BUILD-PARM-INFO-X
012143*       MOVE LSEGF-INPUT-EFF-DT      TO L6330-EFF-DATE
012143*       MOVE LSEGF-INV-CVG-CVG-NUM   TO L6330-CVG-NUM
012143*       PERFORM  6330-3000-PROCESS-SURR-REV
012143*           THRU 6330-3000-PROCESS-SURR-REV-X
012143*       IF L6330-RETRN-ERROR
012143*          SET WGLOB-RETURN-ERROR TO TRUE
012143*          GO TO 2000-REVERSE-FA-X
012143*       END-IF
012143     IF  RFA-CIA-TYP-SURR
012143     AND MIR-DV-PRCES-STATE-CD NOT = '3'
012143         PERFORM  2770-1000-BUILD-PARM-INFO
012143            THRU 2770-1000-BUILD-PARM-INFO-X
012143         SET  L2770-PRCES-TYP-EDIT-ONLY
012143                                TO TRUE
012137         IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137             SET  L2770-SUPR-CONF
012137                                TO TRUE
012137         END-IF
012143         MOVE LSEGF-INV-CVG-CVG-NUM
                                      TO L2770-CVG-NUM
012143         MOVE MIR-CIA-REVRS-REASN-CD
                                      TO L2770-REASON
012143         MOVE LSEGF-PARM-INFO   TO L2770-CASHFLOW-SEGFUND-AREA
012143         PERFORM  2770-1000-SURRENDER-REVERSAL
012143            THRU 2770-1000-SURRENDER-REVERSAL-X
012143         MOVE L2770-CASHFLOW-SEGFUND-AREA
012143                                TO LSEGF-PARM-INFO
012143         IF  L2770-RETRN-ERROR
012143             SET WGLOB-RETURN-ERROR
012143                                TO TRUE
012143             GO TO 2000-REVERSE-FA-X
012143         END-IF
           END-IF.
012696*
019573*    IF RFA-CIA-TYP-XFER
019573*    AND (RFA-CIA-REASN-XFER-IN
019573*      OR RFA-CIA-REASN-XFER-OUT)
012696*MSG: USE UNDO TO REVERSE THIS ACTIVITY
019573*        MOVE 'SS00900024'      TO WGLOB-MSG-REF-INFO
019573*        PERFORM  0260-1000-GENERATE-MESSAGE
019573*           THRU 0260-1000-GENERATE-MESSAGE-X
019573*        IF WGLOB-MSG-SEVRTY-FATAL
019573*            SET WGLOB-RETURN-ERROR
019573*                               TO TRUE
019573*            GO TO 2000-REVERSE-FA-X
019573*        END-IF
019573*    END-IF.

019573*    IF RFA-CIA-TYP-CD = 'TRS'
019573*       PERFORM  6350-1000-BUILD-PARM-INFO
019573*           THRU 6350-1000-BUILD-PARM-INFO-X
019573*       MOVE LSEGF-INPUT-EFF-DT TO L6350-EFF-DT
019573*       MOVE LSEGF-INV-CVG-CVG-NUM
019573*                               TO L6350-CVG-NUM
019573*       IF  MIR-SUPRES-CNFRM-IND = 'Y'
019573*           SET  L6350-SUPPRESS-CONFIRM
019573*                               TO TRUE
019573*       END-IF
019573*       SET L6350-REDO-WARNING  TO TRUE
019573*       PERFORM  6350-3000-PROCESS-XFER-REV
019573*           THRU 6350-3000-PROCESS-XFER-REV-X
019573*       IF L6350-RETRN-ERROR
019573*          SET WGLOB-RETURN-ERROR
019573*                               TO TRUE
019573*          GO TO 2000-REVERSE-FA-X
019573*       END-IF
019573*    END-IF.

019573     IF  RFA-CIA-TYP-XFER
019573     AND MIR-DV-PRCES-STATE-CD NOT = '3'

019573         PERFORM  2780-1000-BUILD-PARM-INFO
019573             THRU 2780-1000-BUILD-PARM-INFO-X

019573         SET L2780-PRCES-TYP-EDIT-ONLY   TO TRUE
019573         IF  MIR-SUPRES-CNFRM-IND = 'Y'
019573             SET L2780-SUPR-CONF         TO TRUE
019573         END-IF
019573         MOVE LSEGF-INV-CVG-CVG-NUM      TO L2780-CVG-NUM
019573         MOVE MIR-CIA-REVRS-REASN-CD     TO L2780-REASON
019573         MOVE LSEGF-PARM-INFO
019573                         TO L2780-CASHFLOW-SEGFUND-AREA

019573         PERFORM  2780-1000-TRANSFER-REVERSAL
019573             THRU 2780-1000-TRANSFER-REVERSAL-X

019573         MOVE L2780-CASHFLOW-SEGFUND-AREA
019573                                         TO LSEGF-PARM-INFO

019573         IF  L2780-RETRN-ERROR
019573             SET WGLOB-RETURN-ERROR      TO TRUE
019573             GO TO 2000-REVERSE-FA-X
019573         END-IF

019573     END-IF.


           IF RFA-CIA-TYP-CD = 'ADM'
              PERFORM  6340-1000-BUILD-PARM-INFO
                  THRU 6340-1000-BUILD-PARM-INFO-X
              MOVE LSEGF-INPUT-EFF-DT TO L6340-EFF-DT
              MOVE LSEGF-INV-CVG-CVG-NUM
                                      TO L6340-CVG-NUM
012137        IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137            SET  L6340-SUPPRESS-CONFIRM
012137                                TO TRUE
012137        END-IF
016503        SET L6340-REDO-WARNING  TO TRUE
              PERFORM  6340-3000-PROCESS-ADMIN-REV
                  THRU 6340-3000-PROCESS-ADMIN-REV-X
              IF L6340-RETRN-ERROR
                 SET WGLOB-RETURN-ERROR
                                      TO TRUE
                 GO TO 2000-REVERSE-FA-X
              END-IF
           END-IF.

       2000-REVERSE-FA-X.
           EXIT.
      /
      *---------------------
       2500-VERIFY-REVERSE.
      *---------------------
      *
557701     PERFORM  2510-INVOKE-UNDO
557701         THRU 2510-INVOKE-UNDO-X.
557701
557701     IF  NOT WGLOB-GOOD-RETURN
557701         GO TO 2500-VERIFY-REVERSE-X
557701     END-IF.
557701
           MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
           MOVE RPOL-KEY              TO WPOL-KEY.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           MOVE HPOL-REC-INFO         TO RPOL-REC-INFO.
      *
012143*    CHECK TO SEE IF UNDO REVERSED THIS ACTIVITY AS PART OF A
012143*    POLICY LEVEL TRANSACTION
012143*
012143     MOVE RFA-KEY               TO WFA-KEY.
012143     PERFORM  FA-1000-READ
012143         THRU FA-1000-READ-X.
012143*
012143     IF RFA-CIA-REVRS-PRCES-DT NOT = WWKDT-ZERO-DT
016503         PERFORM  2600-SET-POL-NXT-ACTV
016503            THRU  2600-SET-POL-NXT-ACTV-X
012143         PERFORM  POL-2000-REWRITE
012143            THRU POL-2000-REWRITE-X
012143         PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
012143             THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
012143         GO TO 2500-VERIFY-REVERSE-X
012143     END-IF.

029060*    IF  RFA-POL-PAYO-NUM > 0
029060*    AND RFA-CIA-TYP-CD = 'SUR'
029060*        PERFORM  4350-1000-BUILD-PARM-INFO
029060*           THRU 4350-1000-BUILD-PARM-INFO-X
029060*        SET L4350-FCN-DRVR-SECONDARY
029060*                               TO TRUE
029060*        MOVE RFA-POL-PAYO-NUM  TO L4350-PAYOUT-NUMBER-N
029060*        MOVE RFA-CIA-EFF-DT    TO L4350-EFF-DT
029060*        IF  MIR-SUPRES-CNFRM-IND = 'Y'
029060*            SET  L4350-SUPPRESS-CONFIRM
029060*                               TO TRUE
029060*        END-IF
029060*        MOVE 'S'               TO L4350-SEGFND-PRCES-IND
029060*        PERFORM  4350-2000-REVRS-PAYO
029060*            THRU 4350-2000-REVRS-PAYO-X
029060*        IF L4350-RETRN-ERROR
029060*           SET WGLOB-RETURN-ERROR
029060*                               TO TRUE
029060*           GO TO 2500-VERIFY-REVERSE-X
029060*        ELSE
029060*            PERFORM  2600-SET-POL-NXT-ACTV
029060*               THRU  2600-SET-POL-NXT-ACTV-X
029060*            PERFORM  POL-2000-REWRITE
029060*                THRU POL-2000-REWRITE-X
029060*            PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
029060*                THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
029060*            PERFORM  POL-1000-READ-TWRK-TS
029060*                THRU POL-1000-READ-TWRK-TS-X
029060*        GO TO 2500-VERIFY-REVERSE-X
029060*        END-IF
029060*    END-IF.

012624*    MOVE '1'                   TO MIR-DV-PRCES-STATE-CD.
012624*    MOVE 'VRV'                 TO LSEGF-CIA-FIA-OPT-CD.
012624*
012143*    IF RFA-CIA-TYP-CD = 'DEP'
012143*       PERFORM  6320-1000-BUILD-PARM-INFO
012143*           THRU 6320-1000-BUILD-PARM-INFO-X
012143*       MOVE LSEGF-INPUT-EFF-DT     TO L6320-EFF-DATE
012143*       MOVE LSEGF-INV-CVG-CVG-NUM  TO L6320-CVG
012143*       PERFORM  6320-4000-VERIFY-DEP-REV
012143*           THRU 6320-4000-VERIFY-DEP-REV-X
012143*       IF L6320-RETRN-ERROR
012143*          SET WGLOB-RETURN-ERROR TO TRUE
012143*          GO TO 2500-VERIFY-REVERSE-X
012143*       END-IF
029060*    IF RFA-CIA-TYP-DPOS
029060*       PERFORM  2750-1000-BUILD-PARM-INFO
029060*           THRU 2750-1000-BUILD-PARM-INFO-X
029060*       SET  L2750-PRCES-TYP-VER-ONLY
029060*                               TO TRUE
029060*       IF  MIR-SUPRES-CNFRM-IND = 'Y'
029060*           SET  L2750-SUPR-CONF
029060*                               TO TRUE
029060*       END-IF
029060*       MOVE LSEGF-INV-CVG-CVG-NUM
029060*                               TO L2750-CVG-NUM
029060*       MOVE MIR-CIA-REVRS-REASN-CD
029060*                               TO L2750-REASON
029060*       MOVE LSEGF-PARM-INFO    TO L2750-CASHFLOW-SEGFUND-AREA
029060*       MOVE 'S'                TO L2750-SEGFND-PRCES-IND
029060*       SET L2750-FCN-DRVR-SECONDARY  TO TRUE
029060*       PERFORM  2750-1000-DEPOSIT-REVERSAL
029060*           THRU 2750-1000-DEPOSIT-REVERSAL-X
029060*       MOVE L2750-CASHFLOW-SEGFUND-AREA
029060*                               TO LSEGF-PARM-INFO
029060*       IF  L2750-RETRN-ERROR
029060*           SET WGLOB-RETURN-ERROR
029060*                               TO TRUE
029060*           GO TO 2500-VERIFY-REVERSE-X
029060*       END-IF
029060*    END-IF.

012143*    IF RFA-CIA-TYP-CD = 'SUR'
012143*       PERFORM  6330-1000-BUILD-PARM-INFO
012143*           THRU 6330-1000-BUILD-PARM-INFO-X
012143*       MOVE LSEGF-INPUT-EFF-DT      TO L6330-EFF-DATE
012143*       MOVE LSEGF-INV-CVG-CVG-NUM   TO L6330-CVG-NUM
012143*       PERFORM  6330-4000-VERIFY-SURR-REV
012143*           THRU 6330-4000-VERIFY-SURR-REV-X
012143*       IF L6330-RETRN-ERROR
012143*          SET WGLOB-RETURN-ERROR TO TRUE
012143*          GO TO 2500-VERIFY-REVERSE-X
012143*       END-IF
029060*    IF RFA-CIA-TYP-SURR
029060*       PERFORM  2770-1000-BUILD-PARM-INFO
029060*           THRU 2770-1000-BUILD-PARM-INFO-X
029060*       SET  L2770-PRCES-TYP-VER-ONLY
029060*                               TO TRUE
029060*       IF  MIR-SUPRES-CNFRM-IND = 'Y'
029060*           SET  L2770-SUPR-CONF
029060*                               TO TRUE
029060*       END-IF
029060*       MOVE LSEGF-INV-CVG-CVG-NUM
029060*                               TO L2770-CVG-NUM
029060*       MOVE MIR-CIA-REVRS-REASN-CD
029060*                               TO L2770-REASON
029060*       MOVE LSEGF-PARM-INFO    TO L2770-CASHFLOW-SEGFUND-AREA
029060*       PERFORM  2770-1000-SURRENDER-REVERSAL
029060*           THRU 2770-1000-SURRENDER-REVERSAL-X
029060*       MOVE L2770-CASHFLOW-SEGFUND-AREA
029060*                               TO LSEGF-PARM-INFO
029060*       IF  L2770-RETRN-ERROR
029060*           SET WGLOB-RETURN-ERROR
029060*                               TO TRUE
029060*           GO TO 2500-VERIFY-REVERSE-X
029060*       END-IF
029060*    END-IF.

019573*    IF RFA-CIA-TYP-CD = 'TRS'
019573*       PERFORM  6350-1000-BUILD-PARM-INFO
019573*           THRU 6350-1000-BUILD-PARM-INFO-X
019573*       IF  MIR-SUPRES-CNFRM-IND = 'Y'
019573*           SET  L6350-SUPPRESS-CONFIRM
019573*                               TO TRUE
019573*       END-IF
019573*       MOVE LSEGF-INPUT-EFF-DT TO L6350-EFF-DT
019573*       MOVE LSEGF-INV-CVG-CVG-NUM
019573*                               TO L6350-CVG-NUM
019573*       SET L6350-REDO-WARNING  TO TRUE
019573*       PERFORM  6350-4000-VERIFY-XFER-REV
019573*           THRU 6350-4000-VERIFY-XFER-REV-X
019573*       IF L6350-RETRN-ERROR
019573*          SET WGLOB-RETURN-ERROR
019573*                               TO TRUE
019573*          GO TO 2500-VERIFY-REVERSE-X
019573*       END-IF
019573*    END-IF.

029060*    IF  RFA-CIA-TYP-XFER
029060*
029060*        PERFORM  2780-1000-BUILD-PARM-INFO
029060*            THRU 2780-1000-BUILD-PARM-INFO-X
029060*
029060*        SET L2780-PRCES-TYP-VER-ONLY    TO TRUE
029060*
029060*        IF  MIR-SUPRES-CNFRM-IND = 'Y'
029060*            SET L2780-SUPR-CONF         TO TRUE
029060*        END-IF
029060*        MOVE LSEGF-INV-CVG-CVG-NUM      TO L2780-CVG-NUM
029060*        MOVE MIR-CIA-REVRS-REASN-CD     TO L2780-REASON
029060*        MOVE LSEGF-PARM-INFO
029060*                        TO L2780-CASHFLOW-SEGFUND-AREA
029060*
029060*        PERFORM  2780-1000-TRANSFER-REVERSAL
029060*            THRU 2780-1000-TRANSFER-REVERSAL-X
029060*
029060*        MOVE L2780-CASHFLOW-SEGFUND-AREA
029060*                                        TO LSEGF-PARM-INFO
029060*
029060*        IF  L2780-RETRN-ERROR
029060*            SET WGLOB-RETURN-ERROR      TO TRUE
029060*            GO TO 2500-VERIFY-REVERSE-X
029060*        END-IF
029060*
029060*    END-IF.

           IF RFA-CIA-TYP-CD = 'ADM'
              PERFORM  6340-1000-BUILD-PARM-INFO
                  THRU 6340-1000-BUILD-PARM-INFO-X
012137        IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137            SET  L6340-SUPPRESS-CONFIRM
012137                                TO TRUE
012137        END-IF
              MOVE LSEGF-INPUT-EFF-DT TO L6340-EFF-DT
              MOVE LSEGF-INV-CVG-CVG-NUM
                                      TO L6340-CVG-NUM
016503        SET L6340-REDO-WARNING  TO TRUE
              PERFORM  6340-4000-VERIFY-ADMIN-REV
                  THRU 6340-4000-VERIFY-ADMIN-REV-X
              IF L6340-RETRN-ERROR
                 SET WGLOB-RETURN-ERROR
                                      TO TRUE
                 GO TO 2500-VERIFY-REVERSE-X
              END-IF
029060        SET LSEGF-INV-CVG-CFN-OPT-UPD-FILE   TO TRUE
029060        PERFORM  0500-1000-PROCESS-FC-FS
029060            THRU 0500-1000-PROCESS-FC-FS-X
029060        IF L0500-RETRN-OK
029060            MOVE 'SS00900020'      TO WGLOB-MSG-REF-INFO
029060            PERFORM  0260-1000-GENERATE-MESSAGE
029060                THRU 0260-1000-GENERATE-MESSAGE-X
029060        END-IF
029060        PERFORM  POL-2000-REWRITE
029060            THRU POL-2000-REWRITE-X
029060        PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
029060            THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
           END-IF.

029060*    SET LSEGF-INV-CVG-CFN-OPT-UPD-FILE
029060*                               TO TRUE.
029060*    PERFORM  0500-1000-PROCESS-FC-FS
029060*        THRU 0500-1000-PROCESS-FC-FS-X.
029060*    IF L0500-RETRN-OK
029060*        MOVE 'SS00900020'      TO WGLOB-MSG-REF-INFO
029060*        PERFORM  0260-1000-GENERATE-MESSAGE
029060*            THRU 0260-1000-GENERATE-MESSAGE-X
029060*    END-IF.
029060*
029060*    PERFORM  POL-2000-REWRITE
029060*        THRU POL-2000-REWRITE-X.
029060*
029060*    PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
029060*        THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

       2500-VERIFY-REVERSE-X.
           EXIT.
557701/
557701******************
557701 2510-INVOKE-UNDO.
557701******************
557701
557701     PERFORM  4750-1000-BUILD-PARM-INFO
557701         THRU 4750-1000-BUILD-PARM-INFO-X.
557701
557701     SET L4750-FCN-DRVR-SECONDARY
557701                                TO TRUE.
557701     SET  L4750-PRCES-CF-REVERSAL
557701                                TO TRUE.
029060*    SET  L4750-PRCES-CF-REV-EXCL TO TRUE.
029060     SET  L4750-PRCES-CF-REV-INCL TO TRUE.
557701     MOVE LSEGF-INPUT-EFF-DT    TO L4750-EFF-DT.
557701     MOVE LSEGF-INPUT-CVG-NUM   TO L4750-CVG-NUM.
557701     MOVE HOLD-SEQUENCE         TO L4750-CF-SEQ-NUM.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET  L4750-SUPPRESS-CONFIRM
012137                                TO TRUE
012137     END-IF
557701
557701     PERFORM  4750-1000-UNDO-PROCESSING
557701         THRU 4750-1000-UNDO-PROCESSING-X.
557701
557701     IF  NOT L4750-RETRN-OK
557701         SET WGLOB-RETURN-ERROR TO TRUE
557701     END-IF.
557701
557701     IF  L4750-POL-UPDATE-NOT-REQD
557701         GO TO 2510-INVOKE-UNDO-X
557701     END-IF.
557701
557701*  SAVE POLICY CHANGES DONE BY UNDO PROCESS
557701     MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
557701
557701     MOVE RPOL-KEY              TO WPOL-KEY.
557701     PERFORM  POL-1000-READ-FOR-UPDATE
557701         THRU POL-1000-READ-FOR-UPDATE-X.
557701     MOVE HPOL-REC-INFO         TO RPOL-REC-INFO.
557701
557701     PERFORM  POL-2000-REWRITE
557701         THRU POL-2000-REWRITE-X.
557701     PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
557701         THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.
557701
557701*  REBUILD SEGFUND TSQ'S, ETC. AS UNDO WILL HAVE CHANGED
557701*  TRANSACTIONS DATED AFTER THIS ONE
557701*
031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.

557701     PERFORM  2000-REVERSE-FA
557701         THRU 2000-REVERSE-FA-X.
557701
557701 2510-INVOKE-UNDO-X.
557701     EXIT.
      /
016503*----------------------
016503 2600-SET-POL-NXT-ACTV.
016503*----------------------

016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503
016503     MOVE LSEGF-INPUT-EFF-DT TO L0289-LO-PAC-DT.
016503     MOVE LSEGF-INPUT-EFF-DT TO L0289-LO-CRC-DT.
020467     MOVE LSEGF-INPUT-EFF-DT TO L0289-LO-DD2-DT.
016503     MOVE LSEGF-INPUT-EFF-DT TO L0289-PROC-EFF-DT.
016503
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD
016503           TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT
016503           TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE
016503                     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

016503 2600-SET-POL-NXT-ACTV-X.
016503     EXIT.
      /
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET WGLOB-REF-POLICY       TO TRUE.
           MOVE MIR-POL-ID-BASE            TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
021311*--------------------------
021311 9990-INIT-WORKING-STORAGE.
021311*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
021311
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0500-0000-INIT-PARM-INFO
025970         THRU 0500-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2750-0000-INIT-PARM-INFO
025970         THRU 2750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2770-0000-INIT-PARM-INFO
025970         THRU 2770-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2780-0000-INIT-PARM-INFO
025970         THRU 2780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4350-0000-INIT-PARM-INFO
025970         THRU 4350-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6340-0000-INIT-PARM-INFO
025970         THRU 6340-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE HOLD-MAP-AREA.
025970     INITIALIZE WS-MISC-AREA.

021311     INITIALIZE WAGFA-WORK-AREA.
021311     INITIALIZE LSEGF-PARM-INFO.

025970     SET WAGFA-MAX-ROWS-DEFAULT    TO TRUE.
025970     SET TRANSACTION-NAME-DEFAULT  TO TRUE.
025970     MOVE SPACES                   TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
021311
021311 9990-INIT-WORKING-STORAGE-X.
021311     EXIT.
021311/
      ******************************************************************
      *   PROCESSING COPYBOOKS
      ******************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY SCPPAGFA.
      /
       COPY NCPPCVGR.
      /
       COPY NCPPCVGS.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      ********** PROCEDURE SECTIONS *********
      *
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
031034*COPY CCPSPGAL.
015290/
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455/
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
      ************ LINKAGE SECTIONS **********

      *
016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108/
       COPY CCPS4350.
018764*COPY CCCL4350.
018764 COPY CCPL4350.
557701/
557701 COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
      /
012143 COPY FCPS2750.
018764*COPY FCCL2750.
018764 COPY FCPL2750.
012143/
012143 COPY FCPS2770.
018764*COPY FCCL2770.
018764 COPY FCPL2770.
012143/
019573 COPY FCPS2780.
019573 COPY FCPL2780.
      /
018764*COPY SCCL0500.
025970 COPY SCPS0500.
018764 COPY SCPL0500.
      /
014035*COPY SCPS6320.
014035*COPY SCCL6320.
      /
014035*COPY SCPS6330.
014035*COPY SCCL6330.
      /
       COPY SCPS6340.
018764*COPY SCCL6340.
018764 COPY SCPL6340.
      /
021930*COPY SCPS6350.
018764*COPY SCCL6350.
021930*COPY SCPL6350.
021930*
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
557756/
013578*COPY XCPS2510.
013578*COPY XCCL2510.
013578************ IO/CR SECTIONS ************
      *
       COPY XCPPINIT.
       COPY XCPPEXIT.
012624*COPY XCPPMEXT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY SCPBFA.
       COPY SCPNFA.
      /
       COPY SCPAFAAG.
       COPY SCPBFAAG.
       COPY SCPUFAAG.
       COPY SCPXFAAG.
       COPY SCPCFAAG.

557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM SSOM0090                     **
      *****************************************************************

