      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM0052.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM0052                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE MAST TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016686**  6.2       NEW APPLICATION CONTROL UPDATE                   **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM0052'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '0052'.
           05  WS-CROSS-EDIT-IND             PIC X(01).
               88  WS-CROSS-EDIT-REQD        VALUE 'Y'.
           05  WS-ONLN-CHNG-TIME.
               10 WS-ONLN-CHNG-HH            PIC X(02).
               10 FILLER                     PIC X(01).
               10 WS-ONLN-CHNG-MM            PIC X(02).
               10 FILLER                     PIC X(01).
               10 WS-ONLN-CHNG-SS            PIC X(02).
           05  WS-SAVE-WGLOB-CO-ID           PIC X(02).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWMAST.
       COPY CCFRMAST.
       COPY XCFWUSEA.
       COPY XCFRUSES.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL0280.
021930*COPY CCWL0620.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM0052.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

025970*    PERFORM  9300-SETUP-MSIN-REFERENCE
025970*        THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM0052'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------
       2000-UPDATE.
      *-----------
      *
      *  THE RECORD MUST EXIST ON A MAINTAIN
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  MAST-1000-READ-FOR-UPDATE
               THRU MAST-1000-READ-FOR-UPDATE-X.

           MOVE WS-SAVE-WGLOB-CO-ID       TO WGLOB-COMPANY-CODE.

           IF  WMAST-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WMAST-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           MOVE RMAST-ONLN-DT-CHNG-TIME    TO WS-ONLN-CHNG-TIME.
      *
      *  EDIT THE DATA ENTERED FOR THE RECORD
      *
           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.


           MOVE WS-ONLN-CHNG-TIME      TO RMAST-ONLN-DT-CHNG-TIME.


           PERFORM  MAST-2000-REWRITE
               THRU MAST-2000-REWRITE-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               SET MIR-RETRN-EDIT-ERROR
                 TO TRUE
           END-IF.

       2000-UPDATE-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      * THE WGLOB-COMPANY-CD REPRESENTS THE COMPANY THE USER SIGNED
      * INTO, AND IS WHAT GETS SET UP IN THE KEY IN THE I/O MODULE.
      * THIS WILL HAVE TO BE OVERWRITTEN WITH THE MIR-CO-ID IN ORDER
      * TO PROPERLY UPDATE TMAST
      *

           MOVE LOW-VALUES             TO WMAST-KEY.
           MOVE WGLOB-COMPANY-CODE     TO WS-SAVE-WGLOB-CO-ID.
           MOVE MIR-CO-ID              TO WGLOB-COMPANY-CODE.


       7000-BUILD-KEYS-X.
           EXIT.


      /
      *-----------
       8000-EDITS.
      *-----------

           IF MIR-DV-ONLN-DT-CHNG-HR NOT = WS-ONLN-CHNG-HH
              PERFORM 8100-EDIT-CHNG-HR
                 THRU 8100-EDIT-CHNG-HR-X
           END-IF.

           IF MIR-DV-ONLN-DT-CHNG-MI NOT = WS-ONLN-CHNG-MM
              PERFORM 8200-EDIT-CHNG-MM
                 THRU 8200-EDIT-CHNG-MM-X
           END-IF.

018763*    IF MIR-CHNG-LEAD-TIME-DUR NOT = RMAST-CHNG-LEAD-TIME-DUR
018763*       PERFORM 8300-EDIT-CHNG-LTIME
018763*          THRU 8300-EDIT-CHNG-LTIME-X
018763*    END-IF.
018763*
018763     PERFORM 8300-EDIT-CHNG-LTIME
018763       THRU 8300-EDIT-CHNG-LTIME-X.
018763
           IF WS-CROSS-EDIT-REQD
              PERFORM 8400-EDIT-FOR-CONN-USERS
                 THRU 8400-EDIT-FOR-CONN-USERS-X
           END-IF.

       8000-EDITS-X.
           EXIT.

      /

      *-----------------
       8100-EDIT-CHNG-HR.
      *-----------------

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 0                      TO L0280-PRECISION.
           MOVE 2                      TO L0280-LENGTH.
           MOVE 2                      TO L0280-INPUT-SIZE.
           MOVE MIR-DV-ONLN-DT-CHNG-HR TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: DATE CHANGE HOUR MUST BE NUMERIC
               MOVE 'XS00520001'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8100-EDIT-CHNG-HR-X
           END-IF.

           IF L0280-OUTPUT < 0
           OR L0280-OUTPUT > 23
      *MSG: DATE CHANGE HOUR MUST BE BETWEEN 0 AND 24 HR.
              MOVE 'XS00520002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8100-EDIT-CHNG-HR-X
           END-IF.

           SET WS-CROSS-EDIT-REQD TO TRUE.

           MOVE MIR-DV-ONLN-DT-CHNG-HR TO WS-ONLN-CHNG-HH.

       8100-EDIT-CHNG-HR-X.
           EXIT.
      /

      *------------------
       8200-EDIT-CHNG-MM.
      *------------------

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 0                      TO L0280-PRECISION.
           MOVE 2                      TO L0280-LENGTH.
           MOVE 2                      TO L0280-INPUT-SIZE.
           MOVE MIR-DV-ONLN-DT-CHNG-MI TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: DATE CHANGE MINUTES MUST BE NUMERIC
               MOVE 'XS00520003'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8200-EDIT-CHNG-MM-X
           END-IF.

           IF L0280-OUTPUT < 0
           OR L0280-OUTPUT > 59
      *MSG: DATE CHANGE MINUTES MUST BE BETWEEN 0 AND 59 MIN.
              MOVE 'XS00520004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8200-EDIT-CHNG-MM-X
           END-IF.

           SET WS-CROSS-EDIT-REQD TO TRUE.
           MOVE MIR-DV-ONLN-DT-CHNG-MI TO WS-ONLN-CHNG-MM.

       8200-EDIT-CHNG-MM-X.
           EXIT.
      /

      *--------------------
       8300-EDIT-CHNG-LTIME.
      *--------------------

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 0                      TO L0280-PRECISION.
           MOVE 3                      TO L0280-LENGTH.
           MOVE 3                      TO L0280-INPUT-SIZE.
           MOVE MIR-CHNG-LEAD-TIME-DUR TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: DATE CHANGE LEAD TIME MUST BE NUMERIC
               MOVE 'XS00520005'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8300-EDIT-CHNG-LTIME-X
           END-IF.

           IF L0280-OUTPUT < 0
           OR L0280-OUTPUT > 59
      *MSG: DATE CHANGE LEAD TIME MUST BE BETWEEN 0 AND 59 MIN.
              MOVE 'XS00520006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8300-EDIT-CHNG-LTIME-X
           END-IF.

           SET WS-CROSS-EDIT-REQD TO TRUE.
018763*    MOVE MIR-CHNG-LEAD-TIME-DUR TO RMAST-CHNG-LEAD-TIME-DUR.
018763     MOVE L0280-OUTPUT           TO RMAST-CHNG-LEAD-TIME-DUR.


       8300-EDIT-CHNG-LTIME-X.
           EXIT.
      /

      *------------------------------
       8400-EDIT-FOR-CONN-USERS.
      *------------------------------
      * EDIT AGAINST TUSES USING ALTERNATE KEY TO CHECK TO SEE
      * IF THERE ARE ANY CONNECTED USERS.

            MOVE LOW-VALUES                 TO WUSEA-KEY.
            SET  WUSEA-USER-SESN-STAT-CONN  TO TRUE.
            MOVE MIR-CO-ID                  TO WUSEA-CO-ID.
            MOVE WUSEA-KEY                  TO WUSEA-ENDBR-KEY.
            MOVE HIGH-VALUES                TO WUSEA-ENDBR-USER-ID.

            PERFORM USEA-4000-BROWSE-INDEX
               THRU USEA-4000-BROWSE-INDEX-X.

            PERFORM USEA-5000-READ-NEXT-INDEX
              THRU  USEA-5000-READ-NEXT-INDEX-X.

            IF WUSEA-IO-OK
      *MSG: ALERT THAT CONNECTED USERS WILL NOT PICK UP DATE UPDATES
               MOVE 'XS00520007'       TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
            END-IF.

            PERFORM USEA-6000-END-BROWSE-INDEX
               THRU USEA-6000-END-BROWSE-INDEX-X.


       8400-EDIT-FOR-CONN-USERS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES
             TO MIR-DV-ONLN-DT-CHNG-HR.
           MOVE SPACES
             TO MIR-DV-ONLN-DT-CHNG-MI.
           MOVE SPACES
             TO MIR-CHNG-LEAD-TIME-DUR.


       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE RMAST-ONLN-DT-CHNG-TIME
             TO WS-ONLN-CHNG-TIME.

           MOVE WS-ONLN-CHNG-HH
             TO MIR-DV-ONLN-DT-CHNG-HR.

           MOVE WS-ONLN-CHNG-MM
             TO MIR-DV-ONLN-DT-CHNG-MI.

           MOVE RMAST-CHNG-LEAD-TIME-DUR
             TO MIR-CHNG-LEAD-TIME-DUR.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  9300-SETUP-MSIN-REFERENCE
025970         THRU 9300-SETUP-MSIN-REFERENCE-X.

025970     INITIALIZE WS-WORKING-STORAGE.

025970     MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK             TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
021930*COPY CCPL0620.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPUMAST.
       COPY XCPBUSEA.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM XSOM0052                     **
      *****************************************************************
