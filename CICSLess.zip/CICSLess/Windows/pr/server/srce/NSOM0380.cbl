      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0380.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0380                                         **
      **  REMARKS:  PROCESS DRIVER FOR DIARY ACTIVITY LOG TRANS(DALT)**
      **            THIS PROGRAM PERFORMS TABLE MAINTENANCE FUNCTIONS**
      **            FOR THE DIARY ACTIVITY LOG TABLE.  THE LOG ENTRY **
      **            TYPES SHOULD BE DEFINED TO FORM THE BASIS FOR    **
      **            DIARY ACTIVITY LOG ENTRIES.  FOR EACH LOG ENTRY  **
      **            TYPE, AN ACTIVITY/ACTION COMBINATION, AND        **
      **            INFORMATION SUCH AS LANGUAGE, SOURCE AND SECURITY**
      **            LEVEL WILL HAVE BEEN SPECIFIED.                  **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023061**  6.5       MISSING PROGRAM CHANGES FOR MESSAGES NS0760      **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0380'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


025970*01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'DALT'.

       COPY XCWEBLCH.
      /
016537*COPY XCWTATRB.
      /
014221 COPY CCWWLOCK.
      /
       01  WS-GENERAL-WORK-AREA.
025970*    05  FILLER                       PIC X(41)
025970*        VALUE '*** START OF GENERAL WORKING STORAGE ***'.
025970     05  WS-START-WORK-AREA           PIC X(41).
025970         88  WS-DEFAULT-START-WORK-AREA
025970         VALUE '*** START OF GENERAL WORKING STORAGE ***'.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID            PIC X(04).
                   88  WS-BUS-FCN-ID-VALID  VALUE
                       '0380' '0381' '0382' '0383' '0384'.
                   88  WS-BUS-FCN-RETRIEVE  VALUE '0380'.
                   88  WS-BUS-FCN-CREATE    VALUE '0381'.
                   88  WS-BUS-FCN-UPDATE    VALUE '0382'.
                   88  WS-BUS-FCN-DELETE    VALUE '0383'.
                   88  WS-BUS-FCN-LIST      VALUE '0384'.
025970*        10  WS-TWRK-KEY              PIC X(04) VALUE '0380'.
               10  WS-SOURCE-CODE           PIC X(01).
                   88  WS-VALID-SOURCE      VALUE 'A' 'M'.
               10  WS-USE-IND               PIC X(01).
                   88  WS-VALID-USE-IND     VALUE 'Y' 'N'.
               10  WS-SECURITY              PIC 9(01).
                   88  WS-VALID-SECURITY    VALUE 1 THRU 9.
               10  WS-MSGID                 PIC X(06).
023061             88  WS-VALID-MSGID       VALUE 'NS0760'.
023061*            88  WS-VALID-MSGID       VALUE 'NC0760'.

016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.
016548*    05  WS-MAX-ARRAY-LINES           PIC S9(04) COMP VALUE +13.
025970*    05  WS-MAX-ARRAY-LINES           PIC S9(04) BINARY VALUE +13.
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.

       01  WS-SWITCHES.
           05  WS-KEY-FIELDS-OK-SW          PIC X(01).
               88  WS-KEY-FIELDS-NOT-OK     VALUE 'N'.
025970*    05  WS-EDITS-OK-SW               PIC X(01)  VALUE 'Y'.
025970     05  WS-EDITS-OK-SW               PIC X(01).
025970         88  WS-DEFAULT-EDITS-OK                 VALUE 'Y'.
               88  WS-EDIT-OK               VALUE 'Y'.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'DALT'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '0380'.
025970     05  WS-MAX-ARRAY-LINES           PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-ARRAY-LINES          VALUE +13.
025970/
       01  WS-FILE-WORK-AREA.
025970*    05  FILLER                       PIC X(41)
025970*        VALUE '*** START OF FILE WORKING STORAGE ***   '.
025970     05  WS-FILE-START-AREA           PIC X(41).
025970         88  WS-DEFAULT-FILE-START-AREA
025970         VALUE '*** START OF FILE WORKING STORAGE ***   '.

       COPY NCFWDALT.
      /
       COPY NCFRDALT.
      /
       COPY CCFWEDIT.
      /
       COPY CCFREDIT.
      /
       COPY XCWL0280.
      /
014221 COPY XCWL8090.
      /
       01  WS-PARM-WORK-AREA.
025970*    05  FILLER                       PIC X(42)
025970*        VALUE '*** START OF COMMAREA WORKING STORAGE ***'.
025970     05  WS-DEFINE-START-PARM-AREA    PIC X(42).
025970         88  WS-DEFAULT-START-PARM-AREA
025970         VALUE '*** START OF COMMAREA WORKING STORAGE ***'.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0380.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
      * PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  7000-PROCESS-RETRIEVE
                        THRU 7000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM0380'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------
      ****************************************************************
      * BROWSE PROCESSING:  SETUP BROWSE KEYS, BEGIN BROWSE, AND     *
      * LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.         *
      ****************************************************************
      *
      * CHECK ENTER CODE FIELDS FOR INPUT
      *
           MOVE LOW-VALUES            TO WDALT-KEY.
           MOVE HIGH-VALUES           TO WDALT-ENDBR-KEY.
           PERFORM  8000-BUILD-DALT-KEY
               THRU 8000-BUILD-DALT-KEY-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3500-PROCESS-LIST-X
           END-IF.
      *
      * CLEAR DATA FROM SCREEN
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM DALT-1000-BROWSE
              THRU DALT-1000-BROWSE-X.

           IF WDALT-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           PERFORM  DALT-2000-READ-NEXT
               THRU DALT-2000-READ-NEXT-X.

           IF WDALT-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  DALT-3000-END-BROWSE
                   THRU DALT-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           ELSE
               MOVE +0                TO WS-LINE
               PERFORM  3600-DISPLAY-RECORD
                   THRU 3600-DISPLAY-RECORD-X
                   UNTIL WDALT-IO-EOF
                   OR (WS-LINE = WS-MAX-ARRAY-LINES)
557660     END-IF.

           IF WDALT-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE RDALT-EVNT-ACTV-CD  TO MIR-EVNT-ACTV-CD
               MOVE RDALT-EVNT-ACT-CD TO MIR-EVNT-ACT-CD
               MOVE RDALT-EVNT-SRC-CD TO MIR-EVNT-SRC-CD
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  DALT-3000-END-BROWSE
               THRU DALT-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.

      *--------------------
       3600-DISPLAY-RECORD.
      *--------------------

           ADD +1  TO WS-LINE.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  DALT-2000-READ-NEXT
               THRU DALT-2000-READ-NEXT-X.

       3600-DISPLAY-RECORD-X.
           EXIT.

      /
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      ****************************************************************
      * CREATE PROCESSING:  CHECK IF RECORD DOES NOT EXIST, INIT    *
      * NEW RECORD AND ALLOW USER TO MODIFY.                        *
      ****************************************************************

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.
           IF WS-KEY-FIELDS-NOT-OK
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  8000-BUILD-DALT-KEY
               THRU 8000-BUILD-DALT-KEY-X.
           PERFORM DALT-1000-READ
              THRU DALT-1000-READ-X.

           IF WDALT-IO-OK
               MOVE WDALT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  DALT-1000-CREATE
                   THRU DALT-1000-CREATE-X
               PERFORM  DALT-1000-WRITE
                   THRU DALT-1000-WRITE-X
014221         PERFORM  DALT-1000-READ-TWRK-TS
014221             THRU DALT-1000-READ-TWRK-TS-X
               MOVE 'XS00000004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *---------------------
       4100-EDIT-KEY-FIELDS.
      *---------------------

           MOVE 'Y'                   TO WS-KEY-FIELDS-OK-SW.

      *
      ***  ACTIVITY MUST EXIST ON EDIT/DACTV
      *
           MOVE MIR-EVNT-ACTV-CD      TO WEDIT-ETBL-VALU-ID.
           PERFORM  ACTV-1000-EDIT-ACTIVITY
               THRU ACTV-1000-EDIT-ACTIVITY-X.
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'N'               TO WS-KEY-FIELDS-OK-SW
               MOVE 'NS03800001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

      *
      ***  ACTION MUST EXIST ON EDIT/DACTN
      *
           MOVE MIR-EVNT-ACT-CD       TO WEDIT-ETBL-VALU-ID.
           PERFORM  ACTN-1000-EDIT-ACTION
               THRU ACTN-1000-EDIT-ACTION-X.
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'N'               TO WS-KEY-FIELDS-OK-SW
               MOVE 'NS03800002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE MIR-EVNT-SRC-CD       TO WS-SOURCE-CODE.
           IF WS-VALID-SOURCE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'N'               TO WS-KEY-FIELDS-OK-SW
               MOVE 'NS03800003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.

      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM  8000-BUILD-DALT-KEY
               THRU 8000-BUILD-DALT-KEY-X.

014221*    PERFORM DALT-1000-READ-FOR-UPDATE
014221*       THRU DALT-1000-READ-FOR-UPDATE-X.

014221     PERFORM DALT-2000-UPDATE-TWRK-TS
014221        THRU DALT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'DALT'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WDALT-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF WDALT-IO-NOT-FOUND
               MOVE WDALT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           PERFORM  DALT-2000-REWRITE
               THRU DALT-2000-REWRITE-X.

014221     PERFORM  DALT-1000-READ-TWRK-TS
014221         THRU DALT-1000-READ-TWRK-TS-X.

           IF WS-EDIT-OK
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *----------------------
       5300-EDIT-DATA-FIELDS.
      *----------------------
      ****************************************************************
      * FIELD TYPE EDIT.                                             *
      ****************************************************************

           MOVE 'Y'                   TO WS-EDITS-OK-SW.

           PERFORM  5310-EDIT-SECURITY
               THRU 5310-EDIT-SECURITY-X.

           PERFORM  5320-EDIT-USE-INDICATOR
               THRU 5320-EDIT-USE-INDICATOR-X.

           IF MIR-EVNT-GR-CD-T (1) = SPACES
               MOVE RDALT-EVNT-GR-CD  TO MIR-EVNT-GR-CD-T (1)
           ELSE
               IF MIR-EVNT-GR-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-EVNT-GR-CD-T (1)
557660         END-IF
557660     END-IF.

           IF MIR-EVNT-GR-CD-T (1) = SPACES
               MOVE 'NS03800007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE MIR-EVNT-GR-CD-T (1)
                                      TO RDALT-EVNT-GR-CD
           ELSE
               MOVE MIR-EVNT-GR-CD-T (1)
                                      TO WEDIT-ETBL-VALU-ID
               PERFORM  GRUP-1000-EDIT-GROUP
                   THRU GRUP-1000-EDIT-GROUP-X
               IF WEDIT-IO-OK
                   MOVE MIR-EVNT-GR-CD-T (1)
                                      TO RDALT-EVNT-GR-CD
               ELSE
                   MOVE 'NS03800010'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-EDITS-OK-SW
557660         END-IF
557660     END-IF.

           PERFORM  5330-EDIT-MESSAGE-REFERENCE
               THRU 5330-EDIT-MESSAGE-REFERENCE-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *-------------------
       5310-EDIT-SECURITY.
      *-------------------
      ****************************************************************
      * EDIT SECURITY CODE                                           *
      ****************************************************************

           IF MIR-EVNT-SECUR-CD-T (1) = SPACES
               MOVE RDALT-EVNT-SECUR-CD
                                      TO MIR-EVNT-SECUR-CD-T (1)
           ELSE
               IF MIR-EVNT-SECUR-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROES        TO MIR-EVNT-SECUR-CD-T (1)
557660         END-IF
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '1'                   TO L0280-LENGTH.
           MOVE '1'                   TO L0280-INPUT-SIZE.
           MOVE MIR-EVNT-SECUR-CD-T (1)
                                      TO L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'NS03800005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5310-EDIT-SECURITY-X
557660     END-IF.

           MOVE MIR-EVNT-SECUR-CD-T (1)
                                      TO WS-SECURITY.
           IF WS-VALID-SECURITY
               MOVE MIR-EVNT-SECUR-CD-T (1)
                                      TO RDALT-EVNT-SECUR-CD
           ELSE
               MOVE 'NS03800009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
557660     END-IF.

       5310-EDIT-SECURITY-X.
           EXIT.
      /
      *------------------------
       5320-EDIT-USE-INDICATOR.
      *------------------------

           IF MIR-EVNT-USE-IND-T (1) = SPACES
               MOVE RDALT-EVNT-USE-IND         TO MIR-EVNT-USE-IND-T (1)
           ELSE
               IF MIR-EVNT-USE-IND-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-EVNT-USE-IND-T (1)
557660         END-IF
557660     END-IF.

           MOVE MIR-EVNT-USE-IND-T (1)                    TO WS-USE-IND.
           IF WS-VALID-USE-IND
               MOVE MIR-EVNT-USE-IND-T (1)
                                      TO RDALT-EVNT-USE-IND
           ELSE
               MOVE 'NS03800006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
557660     END-IF.

       5320-EDIT-USE-INDICATOR-X.
           EXIT.
      /
      *----------------------------
       5330-EDIT-MESSAGE-REFERENCE.
      *----------------------------
      *
      * MESSAGE REFERENCE ID AND NUMBER MUST BE EDITED TOGETHER
      * AS THEY ARE BOTH KEYS TO THE MESSAGE FILE AND BOTH MUST
      * CONTAIN VALUES TO BE PROCESSED CORRECTLY
      *
           IF  MIR-MSG-REF-ID-T (1) = SPACES
               MOVE RDALT-MSG-REF-ID  TO MIR-MSG-REF-ID-T (1)
           ELSE
               IF MIR-MSG-REF-ID-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-MSG-REF-ID-T (1)
               END-IF
           END-IF.

           IF  MIR-MSG-REF-NUM-T (1) = SPACES
               MOVE RDALT-MSG-REF-NUM TO MIR-MSG-REF-NUM-T (1)
           ELSE
               IF MIR-MSG-REF-NUM-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-MSG-REF-NUM-T (1)
               END-IF
           END-IF.

           IF MIR-MSG-REF-ID-T (1) = SPACES
           OR MIR-MSG-REF-NUM-T (1) = SPACES
      *MSG:    MESSAGE FIELDS MUST BE ENTERED (S)
               MOVE 'NS03800011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5330-EDIT-MESSAGE-REFERENCE-X
           END-IF.

           MOVE MIR-MSG-REF-ID-T (1)  TO WS-MSGID.
           IF WS-VALID-MSGID
                CONTINUE
           ELSE
023061*MSG:    DALT MESSAGE # (@1) MUST BEGIN WITH NS0760 (F/W)
               MOVE 'NS03800012'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-MSG-REF-ID-T (1)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 5330-EDIT-MESSAGE-REFERENCE-X
               ELSE
                   CONTINUE
               END-IF
           END-IF.
      *
      * VERIFY THAT THE MESSAGE NUMBER ENTERED EXISTS ON MSGS TABLE
      *
           MOVE MIR-MSG-REF-ID-T (1)  TO WGLOB-MSG-REF-ID.
           MOVE MIR-MSG-REF-NUM-T (1) TO WGLOB-MSG-REF-NUM.
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
      *
      * IF THE MESSAGE SEVERITY RETURNED IS FATAL THE
      * MESSAGE NUMBER WAS NOT FOUND
      *
           IF WGLOB-MSG-SEVRTY-FATAL
      *MSG:    MESSAGE (@1) (@2) DOES NOT EXIST IN MESSAGE FILE
               MOVE 'NS03800013'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-MSG-REF-ID-T (1)
                                      TO WGLOB-MSG-PARM (1)
               MOVE MIR-MSG-REF-NUM-T (1)
                                      TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 5330-EDIT-MESSAGE-REFERENCE-X
               ELSE
                   CONTINUE
               END-IF
           END-IF.

           MOVE MIR-MSG-REF-ID-T (1)  TO RDALT-MSG-REF-ID.
           MOVE MIR-MSG-REF-NUM-T (1) TO RDALT-MSG-REF-NUM.

       5330-EDIT-MESSAGE-REFERENCE-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           PERFORM  8000-BUILD-DALT-KEY
               THRU 8000-BUILD-DALT-KEY-X.

014221*    PERFORM DALT-1000-READ-FOR-UPDATE
014221*       THRU DALT-1000-READ-FOR-UPDATE-X.

014221     PERFORM DALT-2000-UPDATE-TWRK-TS
014221        THRU DALT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'DALT'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WDALT-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WDALT-IO-OK
               PERFORM  DALT-1000-DELETE
                   THRU DALT-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE WDALT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *----------------------
       7000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  8000-BUILD-DALT-KEY
               THRU 8000-BUILD-DALT-KEY-X.

014221*    PERFORM  DALT-1000-READ
014221*        THRU DALT-1000-READ-X.

014221     PERFORM  DALT-1000-READ-TWRK-TS
014221         THRU DALT-1000-READ-TWRK-TS-X.

           IF WDALT-IO-OK
               MOVE 1                 TO WS-LINE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           ELSE
               MOVE WDALT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           END-IF.

       7000-PROCESS-RETRIEVE-X.
           EXIT.

      *--------------------
       8000-BUILD-DALT-KEY.
      *--------------------

           MOVE MIR-EVNT-ACTV-CD      TO WDALT-EVNT-ACTV-CD.
           MOVE MIR-EVNT-ACT-CD       TO WDALT-EVNT-ACT-CD.
           MOVE MIR-EVNT-SRC-CD       TO WDALT-EVNT-SRC-CD.

           MOVE WDALT-KEY             TO RDALT-KEY.

       8000-BUILD-DALT-KEY-X.
           EXIT.


      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO  MIR-EVNT-ACTV-CD-G.
           MOVE SPACES                TO  MIR-EVNT-ACT-CD-G.
           MOVE SPACES                TO  MIR-EVNT-SRC-CD-G.
           MOVE SPACES                TO  MIR-EVNT-SECUR-CD-G.
           MOVE SPACES                TO  MIR-EVNT-USE-IND-G.
           MOVE SPACES                TO  MIR-EVNT-GR-CD-G.
           MOVE SPACES                TO  MIR-MSG-REF-ID-G.
           MOVE SPACES                TO  MIR-MSG-REF-NUM-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RDALT-EVNT-ACTV-CD    TO MIR-EVNT-ACTV-CD-T (WS-LINE).
           MOVE RDALT-EVNT-ACT-CD     TO MIR-EVNT-ACT-CD-T (WS-LINE).
           MOVE RDALT-EVNT-SRC-CD     TO MIR-EVNT-SRC-CD-T (WS-LINE).
           MOVE RDALT-EVNT-SECUR-CD   TO MIR-EVNT-SECUR-CD-T (WS-LINE).
           MOVE RDALT-EVNT-USE-IND    TO MIR-EVNT-USE-IND-T (WS-LINE).
           MOVE RDALT-EVNT-GR-CD      TO MIR-EVNT-GR-CD-T (WS-LINE).
           MOVE RDALT-MSG-REF-ID      TO MIR-MSG-REF-ID-T (WS-LINE).
           MOVE RDALT-MSG-REF-NUM     TO MIR-MSG-REF-NUM-T (WS-LINE).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.


      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-GENERAL-WORK-AREA.
025970     INITIALIZE                         WS-FILE-WORK-AREA.
025970     INITIALIZE                         WS-PARM-WORK-AREA.
025970     INITIALIZE                         WS-SWITCHES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-START-WORK-AREA     TO TRUE.
025970     SET WS-DEFAULT-FILE-START-AREA     TO TRUE.
025970     SET WS-DEFAULT-START-PARM-AREA     TO TRUE.
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-MAX-ARRAY-LINES     TO TRUE.
025970     SET WS-DEFAULT-EDITS-OK            TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPEACTV.
       COPY NCPEACTN.
       COPY NCPEGRUP.
       COPY XCPPEXIT.
       COPY XCPPINIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY DALT
014221                         '$VAR2' BY 'DALT'.

025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
      ****************************************************************
      * MESSAGE/SECURITY PROCESSING COPYBOOKS                        *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      * FILE I/O PROCESS MODULES
      *****************************************************************
       COPY NCPADALT.
      /
       COPY NCPBDALT.
      /
       COPY NCPNDALT.
      /
       COPY NCPUDALT.
      /
       COPY NCPCDALT.
      /
       COPY NCPXDALT.
      /
       COPY CCPNEDIT.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0380                     **
      *****************************************************************
