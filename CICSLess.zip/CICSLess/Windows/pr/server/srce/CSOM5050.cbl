      *************************
       IDENTIFICATION DIVISION.
      *************************

       COPY XCWWCRHT.

       PROGRAM-ID. CSOM5050.

      *****************************************************************
      **  MEMBER :  CSOM5050                                         **
      **  REMARKS:  INQC- CLIENT INQUIRY SCREEN.                     **
      **            THIS PROGRAM PERFORMS THE FOLLOWING TYPES OF     **
      **            CLIENT RELATED INQUIRIES:                        **
      **            GENERAL - SHOW ALL POLICIES RELATED TO THE       **
      **                      SPECIFIED CLIENT                       **
      **            INSURED - SHOW ALL POLICIES FOR WHICH THE        **
      **                      SPECIFIED CLIENT IS AN INSURED         **
      **            OWNER   - SHOW ALL POLICIES FOR WHICH THE        **
      **                      SPECIFIED CLIENT IS AN OWNER           **
016395**            PAC PAYOR  - SHOW ALL POLICIES FOR WHICH THE     **
016395**                      SPECIFIED CLIENT IS THE PAYOR          **
016395**            PAYOR - SHOW ALL POLICIES FOR WHICH THE SPECIFIED**
016395**                    CLIENT IS THE PAYOR                      **
      **            LISTBILL - SHOW ALL POLICIES TO WHICH THE        **
      **                      SPECIFIED CLIENT HAS A LISTBILL        **
      **                      RELATIONSHIP                           **
      **            NON-REGISTERED CANADIAN TAX - SHOW NON-REGISTERED**
      **                      CANADIAN TAX INFORMATION FOR THE       **
      **                      SPECIFIED CLIENT                       **
      **            REGISTERED CANADIAN TAX - SHOW REGISTERED        **
      **                      CANADIAN TAX INFORMATION FOR THE       **
      **                      SPECIFIED CLIENT                       **
      **            US TAX - SHOW US TAX INFORMATION FOR THE         **
      **                     SPECIFIED CLIENT                        **
      **            EACH OF THESE SCREENS WITH THE EXCEPTION OF THE  **
      **            GENERAL SCREEN HAS A DETAIL AND A SUMMARY VIEW.  **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       CHANGE MISC-RESTR-1-IND TO MISC-RESTR-1-CD       **
557659**            MISC-RESTR-2-IND TO MISC-RESTR-2-CD              **
557660**  5.5       INQC-L/POLI STACKING ERROR                       **
557667**  5.5       MOVE CLIENT PHONE NUMBER FORM TABLE CLI TO       **
557667**            NEW TABLE CLIC                                   **
557671**  5.5       NEW FIELD 'TURE TABLE RATING CODE'               **
557691**  5.5       NEW FIELD FOR US TAX SUMMARY & DETAILS SCRN      **
557695**  5.5       TAX IDENTIFICATION                               **
557708**  5.5       CICS ABEND HANDLING ROUTINE                      **
557756**  5.5       USE FORMAT DRIVER TO IDENTIFY TXN ID FOR         **
557756**            PCL STACK                                        **
557973**  5.5       AMOUNT FIELD SIZING FOR INTERNATIONAL USE        **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTTING                    **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       MULTI-COMPANY SUPPORT                            **
010904**  5.6       DISTINGUISH BETWEEN PRIMARY AND CONTINGENT       **
010904**            OWNERS.                                          **
012624**  6.0       SECURITY FOR INGENIUM 6.0                        **
013578**  6.0       MIR RENAME & 3270 REMOVAL                        **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015508**  6.0       CLIENT NAME ENHANCEMENT FOR JAPAN                **
009798**  6.1       INGENIUM RL CVG NUM IS NUMERIC, OTHERWISE        **
009798**            IT BELONGS TO AN EXTERNAL SYSTEM                 **
016051**  6.1       APP ENTRY FLOW                                   **
016053**  6.1       MONEY FLOW                                       **
013693**  6.2       LOCATION TAX                                     **
016387**  6.2       REMOVE CLIENT CONSOLIDATION                      **
016395**  6.2       CREDIT CARD BILLING                              **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016686**  6.2       CONCURRENCY                                      **
017455**  6.2       ADD DATE TO THE EFF DATE FOR 5216 LINKAGE        **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
019143**  6.3       AMEND/DISPLAY CLIENT CONTACT INFORMATION (6.1.2J)**
019144**  6.3       CLIENT ADDRESS EXPANSION (6.1.2J)                **
019154**  6.3       USE KANJI FOR PRIMARY ADDRESS                    **
019155**  6.3       ADD STATUS, CHANGE DATE FOR 2ND ADDRESS SET      **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
018300**  6.4       INQUIRY DURING CLIENT CLEAR CASING               **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
021807**  6.4       ENSURE POL BILLING TYPE IS CRC BEFORE POLC LOOKUP**
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023257**  6.4       WORKING STORAGE INITIALIZATION                   **
023434**  6.5       EXPAND ADDRESS LINE                              **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023437**            3RD PARTY PACKAGE                                **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025388**  6.6       DATABASE CLEANUP                                 **
025517**  6.6       CHANGE INFORMATIONAL MESSAGE                     **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5050'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
008455 COPY XCWL0290.
013578 COPY XCWL8090.
      /
       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-SUB2                      PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB2                      PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-RI-SUB                    PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-RI-SUB                    PIC S9(4)  VALUE ZERO
016548                                      BINARY.
           05  HOLD-RUN-ID                  PIC X(01)  VALUE ZERO.
016548*    05  WS-MAX-DISPLAY-LINES         PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-MAX-DISPLAY-LINES         PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970*     05  WS-FORMAT-DRIVER             PIC X(08)  VALUE 'CFE6900'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALIE                    VALUE '1000'
016395*                                                THRU  '1015'.
016395                                                 THRU  '1017'.
               88  WS-BUS-FCN-VALID                    VALUE '1000'.
               88  WS-BUS-FCN-GENERAL                  VALUE '1000'.
               88  WS-BUS-FCN-PRINT                    VALUE '1001'.
               88  WS-BUS-FCN-INSDTL                   VALUE '1002'.
               88  WS-BUS-FCN-INSSUM                   VALUE '1003'.
               88  WS-BUS-FCN-LBLDTL                   VALUE '1004'.
               88  WS-BUS-FCN-LBLSUM                   VALUE '1005'.
               88  WS-BUS-FCN-CNRDTL                   VALUE '1006'.
               88  WS-BUS-FCN-CNRSUM                   VALUE '1007'.
               88  WS-BUS-FCN-OWNDTL                   VALUE '1008'.
               88  WS-BUS-FCN-OWNSUM                   VALUE '1009'.
020467         88  WS-BUS-FCN-PMTDTL                   VALUE '1010'.
020467         88  WS-BUS-FCN-PMTSUM                   VALUE '1011'.
020467*        88  WS-BUS-FCN-PACDTL                   VALUE '1010'.
020467*        88  WS-BUS-FCN-PACSUM                   VALUE '1011'.
               88  WS-BUS-FCN-CRGDTL                   VALUE '1012'.
               88  WS-BUS-FCN-CRGSUM                   VALUE '1013'.
               88  WS-BUS-FCN-USTDTL                   VALUE '1014'.
               88  WS-BUS-FCN-USTSUM                   VALUE '1015'.
016395         88  WS-BUS-FCN-CRCDTL                   VALUE '1016'.
016395         88  WS-BUS-FCN-CRCSUM                   VALUE '1017'.

020467     05  WS-AUTOPAY-TOTALS-CHECK      PIC X(01).
020467         88 WS-AUTOPAY-TOTALS-REQD               VALUE 'Y'.
020467         88 WS-AUTOPAY-TOTALS-NOT-REQD           VALUE 'N'.
020467
020467     05  WS-PAC-TOTALS-AREA.
020467         10  WS-PAC-TOTALS            OCCURS 31 TIMES.
020467             15  WS-PAC-INFORCE-AMT   PIC S9(15)V9(02) COMP-3.
020467             15  WS-PAC-PENDING-AMT   PIC S9(15)V9(02) COMP-3.
020467             15  WS-PAC-SUSPENDED-AMT PIC S9(15)V9(02) COMP-3.
020467             15  WS-PAC-TOTAL-AMT     PIC S9(15)V9(02) COMP-3.
020467             15  WS-PAC-BILL-TYP-CD   PIC X(01).

           05  WS-DISPLAY-CODE              PIC X(01).
016395*        88  WS-DISPLAY-CODE-VALID               VALUES ARE
016395*            'G', 'I', 'O', 'P', 'L', 'N', 'R', 'U'.
               88  WS-GENERAL-DISPLAY                  VALUE 'G'.
               88  WS-INSURED-DISPLAY                  VALUE 'I'.
               88  WS-OWNER-DISPLAY                    VALUE 'O'.
016395*        88  WS-PAC-PAYOR-DISPLAY                VALUE 'P'.
016395         88  WS-PAYOR-DISPLAY                    VALUE 'P'.
               88  WS-LISTBILL-DISPLAY                 VALUE 'L'.
               88  WS-CAN-TAXN-DISPLAY                 VALUE 'N'.
               88  WS-CAN-TAXR-DISPLAY                 VALUE 'R'.
               88  WS-US-TAX-DISPLAY                   VALUE 'U'.

           05  WS-VIEW-CODE                 PIC X(01)  VALUE SPACES.
               88  WS-VIEW-CODE-VALID                  VALUES ARE
                   'S', 'D'.
               88  WS-VIEW-CODE-SUMMARY                VALUE 'S'.
               88  WS-VIEW-CODE-DETAIL                 VALUE 'D'.

           05  WS-FIRST-REC-SW              PIC X(01)  VALUE SPACES.
               88  WS-FIRST-REC-FOUND                  VALUE 'Y'.
               88  WS-FIRST-REC-NOT-FOUND              VALUE 'N'.

           05  WS-RL-INDICATOR              PIC X(01)  VALUE SPACES.
               88  WS-RL-FOUND                         VALUE 'Y'.
               88  WS-RL-NOT-FOUND                     VALUE 'N'.

           05  WS-RL-RQST-SW                PIC X(01)  VALUE SPACES.
               88  WS-RL-RQST-FOUND                    VALUE 'Y'.
               88  WS-RL-RQST-NOT-FOUND                VALUE 'N'.

016395*    05  WS-BANK-NUM                  PIC X(01).
016395*        88  WS-CLI-VALID-BANK-NUM    VALUES '1' THRU '9'.
016395     05  WS-ACCT-NUM                  PIC X(01).
016395         88  WS-CLI-VALID-ACCT-NUM    VALUES '1' THRU '9'.

008455     05  WS-PIC-9                     PIC 9.
008455     05  WS-PIC-99                    PIC 99.
008455     05  WS-PIC-9-1-2                 PIC 9.99.
008455     05  WS-PIC-9-2-3                 PIC 99.999.
008455*    05  WS-PIC-Z-5-2                 PIC Z(4)9.99.
008455     05  WS-PIC-NEG-1-2               PIC -9.99.
008455*    05  WS-PIC-NEG-5-2               PIC -----9.99.
008455*    05  WS-PIC-NEG-7-2               PIC -------9.99.
008455*    05  WS-PIC-NEG-9-2               PIC ---------9.99.
008455*    05  WS-PIC-NEG-11-2              PIC -----------9.99.
008455*    05  WS-PIC-Z-7-2                 PIC Z(6)9.99.
008455*    05  WS-PIC-Z-8-2                 PIC Z(7)9.99.
008455*    05  WS-PIC-Z-9-2                 PIC Z(8)9.99.
008455*    05  WS-PIC-Z-11-2                PIC Z(10)9.99.
008455*    05  WS-PIC-Z-13-2                PIC Z(12)9.99.
557973*    05  WS-SUM-INSURED               PIC S9(9)V99 COMP-3.
557973     05  WS-SUM-INSURED               PIC S9(13)V99 COMP-3.
557973*    05  WS-TOT-SUM-INSURED           PIC S9(9)V99 COMP-3.
557973     05  WS-TOT-SUM-INSURED           PIC S9(15)V99 COMP-3.
557973*    05  WS-TOT-ACCUM-VALUE           PIC S9(9)V99 COMP-3.
557973     05  WS-TOT-ACCUM-VALUE           PIC S9(15)V99 COMP-3.
           05  WS-TEMP-KEY-RL-FIELDS.
               10  WS-TEMP-SYS-ID           PIC X(08).
               10  WS-TEMP-POL-ID           PIC X(10).
               10  WS-TEMP-CVG-NUM          PIC X(02).
               10  WS-TEMP-TYP-CD           PIC X(01).

           05  WS-POLI-POL-ID.
               10  WS-POLI-POL-BASE         PIC X(09).
               10  WS-POLI-POL-SFX          PIC X(10).
           05  WS-CLI-SUMMARY-PRINT         PIC X(01).
               88  WS-SUMMARY-VALID                VALUES ARE
                   'Y', ' '.
               88  WS-SUMMARY-PRINT-REQUEST        VALUE 'Y'.
           05  WS-POL-CVG-ID.
               10  WS-POL-ID.
                   15  WS-POL-ID-BASE       PIC X(09).
                   15  WS-POL-ID-SFX        PIC X(01).
               10  WS-CVG-NUM               PIC X(02).
           05  WS-EFF-DT.
               10  WS-EFF-YR-QTY            PIC X(04).
               10  FILLER                   PIC X(06).

016053     05  WS-SCREEN-DATE               PIC X(10).
016053     05  WS-CV-DATE.
016053         10  WS-CV-DATE-YR            PIC 9(04).
016053         10  FILLER                   PIC X(01).
016053         10  WS-CV-DATE-MO            PIC 9(02).
016053         10  FILLER                   PIC X(01).
016053         10  WS-CV-DATE-DY            PIC 9(02).

           05  WS-TEMP-AMOUNTS.
557973*        10  WS-AD-AMOUNT-HOLD        PIC S9(9)V99 COMP-3.
557973         10  WS-AD-AMOUNT-HOLD        PIC S9(13)V99 COMP-3.
557973*        10  WS-REIN-AMOUNT           PIC S9(9)V99 COMP-3.
557973         10  WS-REIN-AMOUNT           PIC S9(13)V99 COMP-3.
557973*        10  WS-LOAN-HOLD             PIC S9(7)V99 COMP-3.
557973         10  WS-LOAN-HOLD             PIC S9(13)V99 COMP-3.
               10  WS-TSYRB-HOLD            PIC 9(04).
      * THIS FIELD IS REQUIRD FOR BUILDING THE PGA PARM AREA
016053*    05  RPOL-POL-ID                  PIC X(10) VALUE SPACES.
013578
018633*    05  WS-5050-SPECIFIC-AREA.
018633*        10  WS-5050-RL-KEY-FIELDS.
018633*            15  WS-5050-RL-KEY-SYS-ID   PIC X(08).
018633*            15  WS-5050-RL-KEY-POL-ID   PIC X(10).
018633*            15  WS-5050-RL-KEY-CVG-NUM  PIC X(02).
018633*            15  WS-5050-RL-KEY-TYP-CD   PIC X(01).
018633*        10  WS-5050-CLI-ID              PIC X(10).
018633*        10  WS-5050-CLI-BNK-ACCT-NUM    PIC X(01).
018633*        10  WS-5050-BUS-FCN-ID          PIC X(04).
018633*        10  WS-5050-CLI-CRC-NUM         PIC X(01).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '5050'.
018633     15  LCOMM-SPECIFIC-AREA.
018633         20  LCOMM-RL-KEY-FIELDS.
018633             25  LCOMM-RL-KEY-SYS-ID     PIC X(08).
018633             25  LCOMM-RL-KEY-POL-ID     PIC X(10).
018633             25  LCOMM-RL-KEY-CVG-NUM    PIC X(02).
018633             25  LCOMM-RL-KEY-TYP-CD     PIC X(01).
018633         20  LCOMM-CLI-ID                PIC X(10).
018633         20  LCOMM-CLI-BNK-ACCT-NUM      PIC X(01).
018633         20  LCOMM-BUS-FCN-ID            PIC X(04).
018633         20  LCOMM-CLI-CRC-NUM           PIC X(01).
018633
016053     05  WS-PIC-5-4                   PIC -(5)9.9(4).
016053     05  WS-DV-POL-ACUM-AMT           PIC S9(16)V99.
016053     05  WS-DV-TOT-POL-SURR-AMT       PIC S9(13)V99.
016053     05  WS-DV-TOT-LOAN-MAX-AMT       PIC S9(13)V99.
018846
018846     05  WS-DV-POL-SIDFND-AFV-AMT     PIC S9(16)V9(02) COMP-3.
018846     05  WS-DV-SIDFND-NET-CV-AMT      PIC S9(16)V9(02) COMP-3.
020464     05  WS-DV-TOT-POL-PEND-AMT       PIC S9(13)V99.
020464     05  WS-DV-TOT-POL-DEFR-AMT       PIC S9(13)V99.
018846
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
557667 COPY CCWL2433.
013578*COPY XCWL2500.

       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRBENE.
       COPY CCFWBENC.
       COPY CCFWBENE.
      /
       COPY CCFWBNKA.
       COPY CCFRBNKA.
      /
016395 COPY CCFWCLCN.
021930*COPY CCFWCLCR.
016395 COPY CCFRCLCR.
016395/
       COPY CCFWCLI.
       COPY CCFRCLI.
      /
015508 COPY CCFRCLNC.
015508 COPY CCFWCLNC.
015508/
020478*COPY CCFRCLNM.
020478*COPY CCFWCLNM.
015508/
       COPY CCFWCLIA.
       COPY CCFRCLIA.
      /
016537*COPY CCFWCLIB.
020478*COPY CCFRCLIB.
      /
020478*COPY CCFWCLIN.
      /
016395 COPY CCFWCRCD.
016395 COPY CCFRCRCD.
016395/
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
016051 COPY CCFWPOL.
010904 COPY CCFWPOLC.
010904 COPY CCFRPOLC.
      /
016053 COPY CCFRCVG.
016053 COPY CCFWCVG.
016053 COPY CCWWCVGS.
      /
       COPY CCFWRL.
       COPY CCFRRL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
020478 COPY CCWL2626.
       COPY CCWL0620.
       COPY CCWL0951.
       COPY CCWL2430.
020478 COPY CCWL2435.
       COPY CCWL2440.
020478 COPY CCWL5020.
       COPY CCWL5051.
       COPY CCWL5052.
       COPY CCWL5053.
       COPY CCWL5216.
       COPY CCWL5600.

       COPY XCWL1640.
       COPY XCWLDTLK.
016053*
016053 COPY CCWL6981.
016053 COPY CCFRPOL.
016053*
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY CCWLPGA.
      /
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM5050.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      /
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

023257     MOVE SPACE   TO WS-CLI-SUMMARY-PRINT.
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
013578     PERFORM  2000-PROCESS-REQUEST
013578         THRU 2000-PROCESS-REQUEST-X.
013578
020478     PERFORM  FCCK-1000-CHECK-CLIENT
020478         THRU FCCK-1000-CHECK-CLIENT-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.


      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

      *
      *  SET UP GENERAL PARAMETER AREA FOR SUBSEQUENT CALLS
      *

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

016053     MOVE ZERO TO WS-DV-POL-ACUM-AMT.
016053     MOVE ZERO TO WS-DV-TOT-POL-SURR-AMT.
016053     MOVE ZERO TO WS-DV-TOT-LOAN-MAX-AMT.
020464     MOVE ZERO TO WS-DV-TOT-POL-PEND-AMT.
020464     MOVE ZERO TO WS-DV-TOT-POL-DEFR-AMT.
016053
018846     MOVE ZERO                   TO WS-DV-POL-SIDFND-AFV-AMT.
018846     MOVE ZERO                   TO WS-DV-SIDFND-NET-CV-AMT.
018846
016053*    IF  MIR-APPL-CTL-PRCES-DT = SPACES
016686     IF  MIR-DV-EFF-DT = SPACES
016053*        MOVE WGLOB-PROCESS-DATE      TO MIR-APPL-CTL-PRCES-DT
016686         MOVE WGLOB-PROCESS-DATE      TO MIR-DV-EFF-DT
016053         MOVE WGLOB-PROCESS-DATE      TO L1640-INTERNAL-DATE
016053         MOVE WGLOB-PROCESS-DATE      TO WS-CV-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
016053         MOVE L1640-EXTERNAL-DATE     TO WS-SCREEN-DATE
016053*        MOVE L1640-EXTERNAL-DATE     TO MIR-APPL-CTL-PRCES-DT
016686         MOVE L1640-EXTERNAL-DATE     TO MIR-DV-EFF-DT
016053     ELSE
016053*        MOVE MIR-APPL-CTL-PRCES-DT   TO WS-SCREEN-DATE
016686         MOVE MIR-DV-EFF-DT           TO WS-SCREEN-DATE
016053*        MOVE MIR-APPL-CTL-PRCES-DT   TO L1640-EXTERNAL-DATE
016686         MOVE MIR-DV-EFF-DT           TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
016053         IF  L1640-VALID
016053             MOVE L1640-INTERNAL-DATE TO WS-CV-DATE
016053             MOVE L1640-INTERNAL-DATE TO WGLOB-PROCESS-DATE
016053         END-IF
016053     END-IF.

           MOVE SPACES                TO LPGA-POLICY-NUMBER.

013578     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
013578     SET MIR-RETRN-OK           TO TRUE.

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-GENERAL
013578              SET WS-GENERAL-DISPLAY
013578                                TO TRUE
013578
013578         WHEN WS-BUS-FCN-INSDTL
013578         WHEN WS-BUS-FCN-INSSUM
013578              SET WS-INSURED-DISPLAY
013578                                TO TRUE
013578
013578         WHEN WS-BUS-FCN-LBLDTL
013578         WHEN WS-BUS-FCN-LBLSUM
013578              SET WS-LISTBILL-DISPLAY
013578                                TO TRUE
013578
013578         WHEN WS-BUS-FCN-CNRDTL
013578         WHEN WS-BUS-FCN-CNRSUM
013578              SET WS-CAN-TAXN-DISPLAY
013578                                TO TRUE
013578
013578         WHEN WS-BUS-FCN-OWNDTL
013578         WHEN WS-BUS-FCN-OWNSUM
013578              SET WS-OWNER-DISPLAY
013578                                TO TRUE
013578
020467*        WHEN WS-BUS-FCN-PACDTL
020467*        WHEN WS-BUS-FCN-PACSUM
020467         WHEN WS-BUS-FCN-PMTDTL
020467         WHEN WS-BUS-FCN-PMTSUM
016395         WHEN WS-BUS-FCN-CRCDTL
016395         WHEN WS-BUS-FCN-CRCSUM
016395*             SET WS-PAC-PAYOR-DISPLAY
016395              SET WS-PAYOR-DISPLAY
013578                                TO TRUE
013578
013578         WHEN WS-BUS-FCN-CRGDTL
013578         WHEN WS-BUS-FCN-CRGSUM
013578              SET WS-CAN-TAXR-DISPLAY
013578                                TO TRUE
013578
013578         WHEN WS-BUS-FCN-USTDTL
013578         WHEN WS-BUS-FCN-USTSUM
013578              SET WS-US-TAX-DISPLAY
013578                                TO TRUE
013578
013578         WHEN WS-BUS-FCN-PRINT
013578              SET WS-SUMMARY-PRINT-REQUEST
013578                                TO TRUE
013578
013578         WHEN OTHER
013578              SET MIR-RETRN-INVALD-RQST
013578                                TO TRUE
013578              GO TO 2000-PROCESS-REQUEST-X
013578
013578     END-EVALUATE.
013578
013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-PRINT
013578         WHEN WS-BUS-FCN-INSSUM
013578         WHEN WS-BUS-FCN-LBLSUM
013578         WHEN WS-BUS-FCN-CNRSUM
013578         WHEN WS-BUS-FCN-OWNSUM
020467*        WHEN WS-BUS-FCN-PACSUM
020467         WHEN WS-BUS-FCN-PMTSUM
013578         WHEN WS-BUS-FCN-CRGSUM
013578         WHEN WS-BUS-FCN-USTSUM
016395         WHEN WS-BUS-FCN-CRCSUM
013578              SET WS-VIEW-CODE-SUMMARY
013578                                TO TRUE
013578
013578         WHEN WS-BUS-FCN-GENERAL
013578         WHEN WS-BUS-FCN-INSDTL
013578         WHEN WS-BUS-FCN-LBLDTL
013578         WHEN WS-BUS-FCN-CNRDTL
013578         WHEN WS-BUS-FCN-OWNDTL
020467*        WHEN WS-BUS-FCN-PACDTL
020467         WHEN WS-BUS-FCN-PMTDTL
013578         WHEN WS-BUS-FCN-CRGDTL
013578         WHEN WS-BUS-FCN-USTDTL
016395         WHEN WS-BUS-FCN-CRCDTL
013578              SET WS-VIEW-CODE-DETAIL
013578                                TO TRUE
013578
013578     END-EVALUATE.
013578
018633*    INITIALIZE WS-5050-SPECIFIC-AREA.
018633     INITIALIZE LCOMM-SPECIFIC-AREA.
013578
013578     IF  WS-VIEW-CODE-DETAIL
018633*        PERFORM  9700-RETRIEVE-TWRK
018633*            THRU 9700-RETRIEVE-TWRK-X
018633         PERFORM  COMM-1000-RETRIEVE-TWRK
018633             THRU COMM-1000-RETRIEVE-TWRK-X
018633*
018633*        IF  L8090-RETRN-OK
018633*        AND MIR-DV-PRCES-STATE-CD  = '2'
018633*            MOVE L8090-AREA-INFO-TEXT
018633*                               TO WS-5050-SPECIFIC-AREA
018633*        END-IF
018633*
018633*        IF   MIR-CLI-ID           = WS-5050-CLI-ID
018633*        AND  MIR-CLI-BNK-ACCT-NUM = WS-5050-CLI-BNK-ACCT-NUM
018633*        AND  MIR-CLI-CRC-NUM      = WS-5050-CLI-CRC-NUM
018633*        AND  MIR-BUS-FCN-ID       = WS-5050-BUS-FCN-ID
018633         IF   MIR-CLI-ID           = LCOMM-CLI-ID
018633         AND  MIR-CLI-BNK-ACCT-NUM = LCOMM-CLI-BNK-ACCT-NUM
018633         AND  MIR-CLI-CRC-NUM      = LCOMM-CLI-CRC-NUM
018633         AND  MIR-BUS-FCN-ID       = LCOMM-BUS-FCN-ID
013578              CONTINUE
013578         ELSE
018633*             INITIALIZE WS-5050-SPECIFIC-AREA
018633              INITIALIZE LCOMM-SPECIFIC-AREA
013578         END-IF
013578
018633*        PERFORM  9900-DELETE-TWRK
018633*            THRU 9900-DELETE-TWRK-X
018633         PERFORM  COMM-3000-DELETE-TWRK
018633             THRU COMM-3000-DELETE-TWRK-X
013578     END-IF.
013578
           PERFORM  2200-CHECK-KEY-FIELDS
               THRU 2200-CHECK-KEY-FIELDS-X.

           IF  NOT WGLOB-GOOD-RETURN
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *
      *    PROCESS SCREEN FUNCTIONS BASED ON VIEW CODE (IF GENERAL
      *    SCREEN REQUESTED, VIEW CODE NOT USED. PROCESS AS DETAIL)
      *
           EVALUATE TRUE

               WHEN WS-VIEW-CODE-DETAIL
               WHEN WS-GENERAL-DISPLAY
                   PERFORM  3000-PROCESS-DETAIL
                       THRU 3000-PROCESS-DETAIL-X

               WHEN WS-VIEW-CODE-SUMMARY
                   PERFORM  6000-PROCESS-SUMMARY
                       THRU 6000-PROCESS-SUMMARY-X

               WHEN OTHER
                   SET  WGLOB-RETURN-ERROR
                                      TO TRUE
      *MSG:        INVALID SUM/DET VALUE (@1), RE-ENTER
                   MOVE 'CS50500007'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

           IF  WS-SUMMARY-PRINT-REQUEST
      *MSG:    CLIENT SUMMARY PRINT REQUEST PROCESSED
               MOVE 'CS50500013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  5216-1000-BUILD-PARM-INFO
                   THRU 5216-1000-BUILD-PARM-INFO-X
               MOVE MIR-CLI-ID        TO L5216-CLI-ID
023437         MOVE MIR-DV-RAPD-PRT-RQST-IND
023437                                TO L5216-DV-RAPD-PRT-RQST-IND
017455* SET THE EFFECTIVE DATE
017455         MOVE MIR-DV-EFF-DT           TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
017455         IF  L1640-VALID
017455             MOVE L1640-INTERNAL-DATE TO L5216-EFF-DT
017455         END-IF


               PERFORM  5216-1000-WRITE-CLI-SUM-STMT
                   THRU 5216-1000-WRITE-CLI-SUM-STMT-X
           END-IF.
013578
013578     IF  WS-VIEW-CODE-DETAIL
018633*        MOVE MIR-CLI-ID        TO WS-5050-CLI-ID
018633         MOVE MIR-CLI-ID        TO LCOMM-CLI-ID
013578         MOVE MIR-CLI-BNK-ACCT-NUM
018633*                               TO WS-5050-CLI-BNK-ACCT-NUM
018633*        MOVE MIR-CLI-CRC-NUM   TO WS-5050-CLI-CRC-NUM
018633*        MOVE MIR-BUS-FCN-ID    TO WS-5050-BUS-FCN-ID
018633                                TO LCOMM-CLI-BNK-ACCT-NUM
018633         MOVE MIR-CLI-CRC-NUM   TO LCOMM-CLI-CRC-NUM
018633         MOVE MIR-BUS-FCN-ID    TO LCOMM-BUS-FCN-ID
013578
018633*        PERFORM  9800-WRITE-TWRK
018633*            THRU 9800-WRITE-TWRK-X
018633         PERFORM  COMM-2000-WRITE-TWRK
018633             THRU COMM-2000-WRITE-TWRK-X
013578     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       2200-CHECK-KEY-FIELDS.
      *----------------------
      *
      * CALL MODULE TO CHECK CLIENT ACCESS
      *
           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.
           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
016387*    SET L5600-GEN-CNSLDT-MSG-WARN
016387*                               TO TRUE.

018300     IF  WS-BUS-FCN-OWNSUM
018300     OR  WS-BUS-FCN-OWNDTL
018300     OR  WS-BUS-FCN-INSSUM
018300     OR  WS-BUS-FCN-INSDTL
020467*    OR  WS-BUS-FCN-PACSUM
020467*    OR  WS-BUS-FCN-PACDTL
020467     OR  WS-BUS-FCN-PMTDTL
020467     OR  WS-BUS-FCN-PMTSUM
018300     OR  WS-BUS-FCN-CRCDTL
021807     OR  WS-BUS-FCN-CRCSUM
018300     OR  WS-BUS-FCN-USTSUM
018300     OR  WS-BUS-FCN-USTDTL
018300     OR  WS-BUS-FCN-CRGSUM
018300     OR  WS-BUS-FCN-CRGDTL
018300     OR  WS-BUS-FCN-CNRSUM
018300     OR  WS-BUS-FCN-CNRDTL
018300         SET L5600-INQ-INFO-ONLY     TO TRUE
018300     END-IF.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           IF  L5600-RETRN-OK
               MOVE MIR-CLI-ID        TO WCLI-CLI-ID
               PERFORM  CLI-1000-READ
                   THRU CLI-1000-READ-X

               MOVE RCLI-CLI-SEX-CD   TO L0620-CLI-SEX-CD

015508         PERFORM  2210-GET-CLIENT-NAME
015508             THRU 2210-GET-CLIENT-NAME-X
           ELSE
              SET  WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF  L5600-CNFD-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF  L5600-RETRN-CLI-NOT-FOUND
               MOVE SPACES            TO MIR-DV-OWN-CLI-NM
013578         MOVE SPACES            TO MIR-DV-OWN-CLI-NM-2
           END-IF.

      * VALIDATE BANK ACCOUNT TYPE

           IF  MIR-CLI-BNK-ACCT-NUM > SPACES
016395*        MOVE MIR-CLI-BNK-ACCT-NUM TO WS-BANK-NUM
016395         MOVE MIR-CLI-BNK-ACCT-NUM TO WS-ACCT-NUM

016395*        IF  NOT WS-CLI-VALID-BANK-NUM
016395         IF  NOT WS-CLI-VALID-ACCT-NUM
                   SET  WGLOB-RETURN-ERROR
                                      TO TRUE
016395*MSG: 'VALID BANK ACCOUNT TYPES ARE 1 TO 9 INCLUSIVE, RE-ENTER'
016395*MSG: 'VALID ACCOUNT TYPES ARE 1 TO 9 INCLUSIVE, RE-ENTER'
                   MOVE 'CS50500011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

           END-IF.

016395* VALIDATE CREDIT CARD ACCOUNT NUM
016395
016395     IF  MIR-CLI-CRC-NUM > SPACES
016395         MOVE MIR-CLI-CRC-NUM TO WS-ACCT-NUM
016395
016395         IF  NOT WS-CLI-VALID-ACCT-NUM
016395             SET  WGLOB-RETURN-ERROR
016395                                TO TRUE
016395*MSG: 'VALID ACCOUNT TYPES ARE 1 TO 9 INCLUSIVE, RE-ENTER'
016395             MOVE 'CS50500011'  TO WGLOB-MSG-REF-INFO
016395             PERFORM  0260-1000-GENERATE-MESSAGE
016395                 THRU 0260-1000-GENERATE-MESSAGE-X
016395         END-IF
016395
016395     END-IF.
016395
       2200-CHECK-KEY-FIELDS-X.
           EXIT.
      /
015508*----------------------
015508 2210-GET-CLIENT-NAME.
015508*----------------------
015508
015508     INITIALIZE RCLNC-REC-INFO.
020478*    INITIALIZE RCLNM-REC-INFO.
013578
013578     MOVE RCLI-CLI-ID           TO WCLNC-CLI-ID.
020478*    MOVE RCLI-CLI-ID           TO WCLNM-CLI-ID.
013578
013578     IF  WGLOB-COUNTRY-JAPAN
013578         SET WCLNC-CLI-CO-GR-KANJI
013578                                TO TRUE
020478*        SET WCLNM-CLI-INDV-GR-KANJI
020478*                               TO TRUE
013578     ELSE
013578         SET WCLNC-CLI-CO-GR-ALPHA
013578                                TO TRUE
020478*        SET WCLNM-CLI-INDV-GR-ALPHA
020478*                               TO TRUE
013578     END-IF.
013578
013578     PERFORM  2215-GET-AND-FORMAT-NAME
013578         THRU 2215-GET-AND-FORMAT-NAME-X.
           MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM

013578     IF  WGLOB-COUNTRY-JAPAN
015508         INITIALIZE RCLNC-REC-INFO
020478*        INITIALIZE RCLNM-REC-INFO
013578         MOVE RCLI-CLI-ID       TO WCLNC-CLI-ID
020478*        MOVE RCLI-CLI-ID       TO WCLNM-CLI-ID
013578         SET WCLNC-CLI-CO-GR-KATAKANA
013578                                TO TRUE
020478*        SET WCLNM-CLI-INDV-GR-KATAKANA
020478*                               TO TRUE
020478         IF RCLI-CLI-SEX-COMPANY
013578            PERFORM  2215-GET-AND-FORMAT-NAME
013578                THRU 2215-GET-AND-FORMAT-NAME-X
                  MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM-2
020478         ELSE
020478            IF NOT L2435-CLI-NM-GR-ALPHA
020478               MOVE L2435-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
020478               MOVE L2435-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
020478               MOVE L2435-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
020478               MOVE L2435-CLI-SFX-NM TO L0620-CLI-SFX-NM
020478               PERFORM  0620-1000-FORMAT-SCREEN-NAME
020478                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
020478               MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM-2
020478            END-IF
020478         END-IF
013578     END-IF.
013578
018732     IF L0620-SCREEN-NAME = SPACE
020478     AND RCLI-CLI-SEX-COMPANY
018732        PERFORM  2216-RETRY-CLIENT-NAME
018732            THRU 2216-RETRY-CLIENT-NAME-X
018732     END-IF.
015508 2210-GET-CLIENT-NAME-X.
013578     EXIT.
013578
013578*-------------------------
015508 2215-GET-AND-FORMAT-NAME.
013578*-------------------------
015508
015508     IF  RCLI-CLI-SEX-COMPANY
015508         SET WCLNC-CLI-CO-NM-TYP-CLI
015508                                TO TRUE
015508
015508         PERFORM  CLNC-1000-READ
015508             THRU CLNC-1000-READ-X
020478         MOVE RCLNC-CLI-CO-ENTR-NM  TO L0620-CLI-CO-NM
020478         PERFORM  0620-1000-FORMAT-SCREEN-NAME
020478             THRU 0620-1000-FORMAT-SCREEN-NAME-X
           ELSE
020478         PERFORM  2435-1000-BUILD-PARM-INFO
020478             THRU 2435-1000-BUILD-PARM-INFO-X
020478         MOVE RCLI-CLI-ID       TO L2435-CLI-ID
020478         PERFORM  2435-2000-CRNT-CLI-NAME
020478             THRU 2435-2000-CRNT-CLI-NAME-X
020478         IF  WGLOB-COUNTRY-JAPAN
020478         AND NOT L2435-CLI-NM-GR-ALPHA
020478             MOVE L2435-CLI-KJ-ENTR-GIV-NM TO L0620-CLI-GIV-NM
020478             MOVE L2435-CLI-KJ-ENTR-SUR-NM TO L0620-CLI-SUR-NM
020478            MOVE L2435-CLI-KJ-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
020478             MOVE L2435-CLI-KJ-SFX-NM TO L0620-CLI-SFX-NM
020478         ELSE
020478             MOVE L2435-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
020478             MOVE L2435-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
020478             MOVE L2435-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
020478             MOVE L2435-CLI-SFX-NM TO L0620-CLI-SFX-NM
020478         END-IF
020478*        SET WCLNM-CLI-INDV-NM-TYP-CRNT
020478*                               TO TRUE
020478*        MOVE +1                TO WCLNM-CLI-INDV-SEQ-NUM
020478*
020478*        PERFORM  CLNM-1000-READ
020478*            THRU CLNM-1000-READ-X
015508     END-IF.
013578
020478*    MOVE RCLNM-ENTR-GIV-NM     TO L0620-CLI-GIV-NM.
020478*    MOVE RCLNM-ENTR-SUR-NM     TO L0620-CLI-SUR-NM.
020478*    MOVE RCLNM-CLI-INDV-MID-NM TO L0620-CLI-MID-INIT-NM.
020478*    MOVE RCLNM-CLI-INDV-SFX-NM TO L0620-CLI-SFX-NM.
020478*    MOVE RCLNC-CLI-CO-ENTR-NM  TO L0620-CLI-CO-NM.
013578     PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578         THRU 0620-1000-FORMAT-SCREEN-NAME-X.
013578
015508 2215-GET-AND-FORMAT-NAME-X.
015508     EXIT.
      /
018732*----------------------
018732 2216-RETRY-CLIENT-NAME.
018732*----------------------
018732
018732
018732     MOVE RCLI-CLI-ID           TO WCLNC-CLI-ID.
020478*    MOVE RCLI-CLI-ID           TO WCLNM-CLI-ID.
018732
018732     IF  WGLOB-COUNTRY-JAPAN
018732         SET WCLNC-CLI-CO-GR-ALPHA
018732                                TO TRUE
020478*        SET WCLNM-CLI-INDV-GR-ALPHA
020478*                               TO TRUE
018732     ELSE
018732         SET WCLNC-CLI-CO-GR-KATAKANA
018732                                TO TRUE
020478*        SET WCLNM-CLI-INDV-GR-KATAKANA
020478*                               TO TRUE
018732     END-IF.
018732
018732     PERFORM  2215-GET-AND-FORMAT-NAME
018732         THRU 2215-GET-AND-FORMAT-NAME-X.
018732     MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM

018732     IF  NOT WGLOB-COUNTRY-JAPAN
018732         INITIALIZE RCLNC-REC-INFO
020478*        INITIALIZE RCLNM-REC-INFO
018732         MOVE RCLI-CLI-ID       TO WCLNC-CLI-ID
020478*        MOVE RCLI-CLI-ID       TO WCLNM-CLI-ID
018732         SET WCLNC-CLI-CO-GR-KATAKANA
018732                                TO TRUE
020478*        SET WCLNM-CLI-INDV-GR-KATAKANA
020478*                               TO TRUE
018732         PERFORM  2215-GET-AND-FORMAT-NAME
018732             THRU 2215-GET-AND-FORMAT-NAME-X
018732         MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM-2
018732     END-IF.
018732
018732 2216-RETRY-CLIENT-NAME-X.
018732     EXIT.
018732
      *--------------------
       3000-PROCESS-DETAIL.
      *--------------------

      * SETUP CLIENT INFORMATION (IF ANY) ON SCREEN
      * ALSO SET WS-MAX-DISPLAY-LINES WHICH DEPENDS ON SCREEN TYPE

           PERFORM  3100-CLIENT-INFO
               THRU 3100-CLIENT-INFO-X.

           PERFORM  3200-FIRST-DETAIL-REC
               THRU 3200-FIRST-DETAIL-REC-X.

           IF  WS-FIRST-REC-NOT-FOUND
      *        MSG: NO RELATIONSHIPS FOUND FOR  THIS CLIENT
               MOVE 'CS50500001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-DETAIL-X
           END-IF.

557660     IF WS-LISTBILL-DISPLAY
557660        MOVE SPACES             TO MIR-POL-ID-BASE-G
557660        MOVE SPACES             TO MIR-POL-ID-SFX-G
557660     END-IF.
           MOVE +1                    TO WS-SUB.
           PERFORM  3300-POLICY-LOOP
               THRU 3300-POLICY-LOOP-X
               UNTIL WS-SUB > WS-MAX-DISPLAY-LINES
               OR  WRL-IO-EOF.

           PERFORM  3400-SAVE-KEY-VALUES
               THRU 3400-SAVE-KEY-VALUES-X.

       3000-PROCESS-DETAIL-X.
           EXIT.

      /
      *-----------------
       3100-CLIENT-INFO.
      *-----------------

           EVALUATE TRUE

               WHEN WS-GENERAL-DISPLAY
013578*            MOVE +6            TO WS-MAX-DISPLAY-LINES
013578             MOVE +12           TO WS-MAX-DISPLAY-LINES
                   PERFORM  4100-GENERAL-CLIENT-INFO
                       THRU 4100-GENERAL-CLIENT-INFO-X

               WHEN WS-INSURED-DISPLAY
013578*            MOVE +3            TO WS-MAX-DISPLAY-LINES
013578             MOVE +6            TO WS-MAX-DISPLAY-LINES

               WHEN WS-OWNER-DISPLAY
013578*            MOVE +3            TO WS-MAX-DISPLAY-LINES
013578*            MOVE +6            TO WS-MAX-DISPLAY-LINES
016053             MOVE +10           TO WS-MAX-DISPLAY-LINES
                   PERFORM  4300-OWNER-CLIENT-INFO
                       THRU 4300-OWNER-CLIENT-INFO-X

016395*        WHEN WS-PAC-PAYOR-DISPLAY
016395         WHEN WS-PAYOR-DISPLAY
013578*            MOVE +2            TO WS-MAX-DISPLAY-LINES
013578             MOVE +6            TO WS-MAX-DISPLAY-LINES
016395             IF  WS-BUS-FCN-CRCDTL
016395                 PERFORM  4600-CRC-PAYOR-CLIENT-INFO
016395                     THRU 4600-CRC-PAYOR-CLIENT-INFO-X
016395             ELSE
020467*                PERFORM  4400-PAC-PAYOR-CLIENT-INFO
020467*                    THRU 4400-PAC-PAYOR-CLIENT-INFO-X
020467                 PERFORM  4400-PMT-PAYOR-CLIENT-INFO
020467                     THRU 4400-PMT-PAYOR-CLIENT-INFO-X
016395             END-IF

               WHEN WS-LISTBILL-DISPLAY
                   MOVE +12           TO WS-MAX-DISPLAY-LINES
557660*            MOVE SPACES           TO MIR-POL-ID-G
                   PERFORM  4500-LISTBILL-CLIENT-INFO
                       THRU 4500-LISTBILL-CLIENT-INFO-X

               WHEN WS-CAN-TAXN-DISPLAY
013578*            MOVE +5            TO WS-MAX-DISPLAY-LINES
013578             MOVE +6            TO WS-MAX-DISPLAY-LINES

               WHEN WS-CAN-TAXR-DISPLAY
013578*            MOVE +3            TO WS-MAX-DISPLAY-LINES
013578             MOVE +6            TO WS-MAX-DISPLAY-LINES

               WHEN WS-US-TAX-DISPLAY
013578*            MOVE +5            TO WS-MAX-DISPLAY-LINES
013578             MOVE +6            TO WS-MAX-DISPLAY-LINES

           END-EVALUATE.

       3100-CLIENT-INFO-X.
           EXIT.


      *----------------------
       3200-FIRST-DETAIL-REC.
      *----------------------

013578     MOVE LOW-VALUES            TO WRL-KEY.
           MOVE MIR-CLI-ID            TO WRL-CLI-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.

018633*    IF  WS-5050-RL-KEY-FIELDS NOT = SPACE
018633*        MOVE WS-5050-RL-KEY-SYS-ID
018633     IF  LCOMM-RL-KEY-FIELDS NOT = SPACE
018633         MOVE LCOMM-RL-KEY-SYS-ID
013578                                TO WRL-REL-SYS-ID
018633*        MOVE WS-5050-RL-KEY-POL-ID
018633         MOVE LCOMM-RL-KEY-POL-ID
013578                                TO WRL-REL-SYS-REF-POL-ID
018633*        MOVE WS-5050-RL-KEY-CVG-NUM
018633         MOVE LCOMM-RL-KEY-CVG-NUM
013578                                TO WRL-REL-SYS-REF-CVG-NUM
018633*        MOVE WS-5050-RL-KEY-TYP-CD
018633         MOVE LCOMM-RL-KEY-TYP-CD
013578                                TO WRL-REL-TYP-CD
013578     END-IF.
013578
013578     MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
013578     MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
013578     PERFORM  3210-FORWARD-BROWSE
013578         THRU 3210-FORWARD-BROWSE-X.
013578
       3200-FIRST-DETAIL-REC-X.
           EXIT.

      /
      *--------------------
       3210-FORWARD-BROWSE.
      *--------------------

           SET WS-FIRST-REC-NOT-FOUND TO TRUE.
           PERFORM  RL-1000-BROWSE
               THRU RL-1000-BROWSE-X.

           IF  NOT WRL-IO-OK
               GO TO 3210-FORWARD-BROWSE-X
           END-IF.

           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

           IF  NOT WRL-IO-OK
               PERFORM  RL-3000-END-BROWSE
                   THRU RL-3000-END-BROWSE-X
               GO TO 3210-FORWARD-BROWSE-X
           END-IF.

           SET WS-FIRST-REC-FOUND     TO TRUE.

       3210-FORWARD-BROWSE-X.
           EXIT.

      *-----------------
       3300-POLICY-LOOP.
      *-----------------

           SET WS-RL-RQST-NOT-FOUND   TO TRUE.

           PERFORM  3310-RL-CHECK-LOOP
               THRU 3310-RL-CHECK-LOOP-X
               UNTIL NOT WRL-IO-OK
               OR    WS-RL-RQST-FOUND.

           IF  WS-RL-RQST-FOUND
               PERFORM  3320-PROCESS-RL-REC
                   THRU 3320-PROCESS-RL-REC-X
               PERFORM  3315-READ-RL-RECORD
                   THRU 3315-READ-RL-RECORD-X
           END-IF.

       3300-POLICY-LOOP-X.
           EXIT.


      *-------------------
       3310-RL-CHECK-LOOP.
      *-------------------

016051*    IF  RRL-REL-SYS-ID NOT = 'ADMIN'
016051*    AND RRL-REL-SYS-ID NOT = 'NEWBUS'
016440*    IF  (RRL-REL-SYS-ID = 'ADMIN'
016440*    OR   RRL-REL-SYS-ID = 'NEWBUS')
016440     IF  RRL-REL-SYS-ID = WGLOB-SYS-CTL-ID
009798     AND (RRL-REL-SYS-REF-CVG-NUM NUMERIC)
009798         CONTINUE
009798     ELSE
               PERFORM  3315-READ-RL-RECORD
                   THRU 3315-READ-RL-RECORD-X
               GO TO 3310-RL-CHECK-LOOP-X
           END-IF.

           IF  WS-DISPLAY-CODE NOT = RRL-REL-TYP-CD

016395*        IF  WS-PAC-PAYOR-DISPLAY
016395         IF  WS-PAYOR-DISPLAY
               OR  WS-LISTBILL-DISPLAY
               OR  WS-INSURED-DISPLAY
               OR  WS-OWNER-DISPLAY
                   PERFORM  3315-READ-RL-RECORD
                       THRU 3315-READ-RL-RECORD-X
                   GO TO 3310-RL-CHECK-LOOP-X
               END-IF

           END-IF.

           IF  WS-CAN-TAXN-DISPLAY

               IF  RRL-REL-TYP-CD NOT = 'O'
                   PERFORM  3315-READ-RL-RECORD
                       THRU 3315-READ-RL-RECORD-X
                   GO TO 3310-RL-CHECK-LOOP-X
               END-IF

           END-IF.

           IF  WS-CAN-TAXR-DISPLAY

               IF (RRL-REL-TYP-CD NOT = 'O'
               AND RRL-REL-TYP-CD NOT = 'S')
                   PERFORM  3315-READ-RL-RECORD
                       THRU 3315-READ-RL-RECORD-X
                   GO TO 3310-RL-CHECK-LOOP-X
               END-IF

           END-IF.

           IF  WS-US-TAX-DISPLAY

               IF  RRL-REL-TYP-CD NOT = 'O'
                   PERFORM  3315-READ-RL-RECORD
                       THRU 3315-READ-RL-RECORD-X
                   GO TO 3310-RL-CHECK-LOOP-X
               END-IF

           END-IF.

010904*    IF THIS IS IS ANY SCREEN OTHER THAN THE GENERAL-SREEN AND
010904*    THE CURRENT RELATION TYPE IS "OWNER" CHECK CLI-REL-SUB-CODE.
010904*    IF CLI-REL-SUB-CODE IS = 'C-CONTINGENT" IGNORE THIS
010904*    RELATIONSHIP RECORD.
010904*
010904     IF  RRL-REL-TYP-OWNER
010904     AND NOT WS-GENERAL-DISPLAY
010904         MOVE RRL-CLI-ID        TO WPOLC-CLI-ID
010904         MOVE RRL-REL-SYS-REF-POL-ID
010904                                TO WPOLC-POL-ID
010904         MOVE RRL-REL-TYP-CD    TO WPOLC-POL-CLI-REL-TYP-CD
010904
010904         PERFORM  POLC-1000-READ
010904             THRU POLC-1000-READ-X
010904
010904         IF  NOT WPOLC-IO-OK
010904             MOVE WPOLC-KEY     TO WGLOB-MSG-PARM(1)
010904             MOVE 'XS00000001'  TO WGLOB-MSG-REF-INFO
010904             PERFORM  0260-1000-GENERATE-MESSAGE
010904                 THRU 0260-1000-GENERATE-MESSAGE-X
010904             PERFORM  3315-READ-RL-RECORD
010904                 THRU 3315-READ-RL-RECORD-X
010904             GO TO 3310-RL-CHECK-LOOP-X
010904         END-IF
010904
010904         IF  RPOLC-POL-CLI-REL-SUB-CD = 'C'
010904             PERFORM  3315-READ-RL-RECORD
010904                 THRU 3315-READ-RL-RECORD-X
010904             GO TO 3310-RL-CHECK-LOOP-X
010904         END-IF
010904     END-IF.

           PERFORM  7000-RETRIEVE-POLICY-INFO
               THRU 7000-RETRIEVE-POLICY-INFO-X.

           IF  L5051-RETRN-OK
           AND L5051-RL-FOUND
               SET WS-RL-RQST-FOUND   TO TRUE
           ELSE
               PERFORM  3315-READ-RL-RECORD
                   THRU 3315-READ-RL-RECORD-X
           END-IF.

       3310-RL-CHECK-LOOP-X.
           EXIT.


      *--------------------
       3315-READ-RL-RECORD.
      *--------------------

013578     PERFORM  RL-2000-READ-NEXT
013578         THRU RL-2000-READ-NEXT-X.
013578
       3315-READ-RL-RECORD-X.
           EXIT.


      *--------------------
       3320-PROCESS-RL-REC.
      *--------------------

           EVALUATE TRUE

               WHEN WS-GENERAL-DISPLAY
                   PERFORM  5100-GENERAL-POLICY-INFO
                       THRU 5100-GENERAL-POLICY-INFO-X

               WHEN WS-INSURED-DISPLAY
                   PERFORM  5200-INSURED-POLICY-INFO
                       THRU 5200-INSURED-POLICY-INFO-X

               WHEN WS-OWNER-DISPLAY
                   PERFORM  5300-OWNER-POLICY-INFO
                       THRU 5300-OWNER-POLICY-INFO-X

016395*        WHEN WS-PAC-PAYOR-DISPLAY
016395*            PERFORM  5400-PAC-PAYOR-POLICY-INFO
016395*                THRU 5400-PAC-PAYOR-POLICY-INFO-X
016395         WHEN WS-PAYOR-DISPLAY
016395             PERFORM  5400-PAYOR-POLICY-INFO
016395                 THRU 5400-PAYOR-POLICY-INFO-X

               WHEN WS-LISTBILL-DISPLAY
                   PERFORM  5500-LISTBILL-POLICY-INFO
                       THRU 5500-LISTBILL-POLICY-INFO-X

               WHEN WS-CAN-TAXN-DISPLAY
                   PERFORM  5600-CAN-TAXN-POLICY-INFO
                       THRU 5600-CAN-TAXN-POLICY-INFO-X

               WHEN WS-CAN-TAXR-DISPLAY
                   PERFORM  5700-CAN-TAXR-POLICY-INFO
                       THRU 5700-CAN-TAXR-POLICY-INFO-X

               WHEN WS-US-TAX-DISPLAY
                   PERFORM  5800-US-TAX-POLICY-INFO
                       THRU 5800-US-TAX-POLICY-INFO-X

           END-EVALUATE.

       3320-PROCESS-RL-REC-X.
           EXIT.


      *---------------------
       3400-SAVE-KEY-VALUES.
      *---------------------

           IF  WRL-IO-EOF
               IF  WS-SUB > 1
      *MSG: END OF POLICY DISPLAY REACHED
                   MOVE 'CS50500022'  TO WGLOB-MSG-REF-INFO
               ELSE
      *MSG: NO POLICIES FOUND TO DISPLAY
                   MOVE 'CS50500010'  TO WGLOB-MSG-REF-INFO
               END-IF
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  3420-BROWSE-CHECK
                   THRU 3420-BROWSE-CHECK-X
           END-IF.

013578     PERFORM  RL-3000-END-BROWSE
013578         THRU RL-3000-END-BROWSE-X.
013578
       3400-SAVE-KEY-VALUES-X.
           EXIT.
      /
      *------------------
       3420-BROWSE-CHECK.
      *------------------

           MOVE RRL-REL-SYS-ID        TO WS-TEMP-SYS-ID.
           MOVE RRL-REL-SYS-REF-POL-ID
                                      TO WS-TEMP-POL-ID.
           MOVE RRL-REL-SYS-REF-CVG-NUM
                                      TO WS-TEMP-CVG-NUM.
           MOVE RRL-REL-TYP-CD        TO WS-TEMP-TYP-CD.

           SET WS-RL-RQST-NOT-FOUND   TO TRUE.

           PERFORM  3310-RL-CHECK-LOOP
               THRU 3310-RL-CHECK-LOOP-X
               UNTIL WRL-IO-EOF
                  OR  WS-RL-RQST-FOUND.

           IF  WS-RL-RQST-FOUND
018633*        MOVE WS-TEMP-SYS-ID         TO WS-5050-RL-KEY-SYS-ID
018633*        MOVE WS-TEMP-POL-ID         TO WS-5050-RL-KEY-POL-ID
018633*        MOVE WS-TEMP-CVG-NUM        TO WS-5050-RL-KEY-CVG-NUM
018633*        MOVE WS-TEMP-TYP-CD         TO WS-5050-RL-KEY-TYP-CD
018633         MOVE WS-TEMP-SYS-ID         TO LCOMM-RL-KEY-SYS-ID
018633         MOVE WS-TEMP-POL-ID         TO LCOMM-RL-KEY-POL-ID
018633         MOVE WS-TEMP-CVG-NUM        TO LCOMM-RL-KEY-CVG-NUM
018633         MOVE WS-TEMP-TYP-CD         TO LCOMM-RL-KEY-TYP-CD
013578
               SET WGLOB-MORE-DATA-EXISTS
                                      TO TRUE
025517         MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
020467* MORE RECORDS EXIST - UNABLE TO DISPLAY - CONTACT SYSTEMS
025517* TO VIEW MORE DATA - SELECT MORE
025517*         MOVE 'XS00000367'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
013578         MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3420-BROWSE-CHECK-X.
           EXIT.
      /
      *-------------------------
       4100-GENERAL-CLIENT-INFO.
      *-------------------------

013578     IF  WGLOB-COUNTRY-JAPAN
019154*        SET L2440-CLI-ADDR-GR-KATAKANA
019154         SET L2440-CLI-ADDR-GR-KANJI
                                      TO TRUE
013578         PERFORM  4110-PR-ADDR-1
013578             THRU 4110-PR-ADDR-1-X

019154*        SET L2440-CLI-ADDR-GR-KANJI
019154         SET L2440-CLI-ADDR-GR-KATAKANA
                                      TO TRUE
013578         PERFORM  4120-PR-ADDR-2
013578             THRU 4120-PR-ADDR-2-X
013578     ELSE
               SET L2440-CLI-ADDR-GR-ALPHA
                                      TO TRUE
013578         PERFORM  4110-PR-ADDR-1
013578             THRU 4110-PR-ADDR-1-X
013578     END-IF.

008455*    MOVE RCLI-CLI-SUSP-AMT             TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2                TO MIR-CLI-SUSP-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RCLI-CLI-SUSP-AMT * 100.
020874     MOVE RCLI-CLI-SUSP-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-SUSP-AMT
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CLI-SUSP-AMT.

           MOVE RCLI-CLI-LANG-CD      TO MIR-CLI-LANG-CD.
           MOVE RCLI-CLI-SEX-CD       TO MIR-CLI-SEX-CD.
           MOVE RCLI-CLI-BTH-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-BTH-DT.

           MOVE RCLI-CLI-AGE-PROOF-IND
                                      TO MIR-CLI-AGE-PROOF-IND.
           MOVE RCLI-CLI-SMKR-CD      TO MIR-CLI-SMKR-CD.
557695*    MOVE RCLI-CLI-SIN-ID               TO MIR-CLI-TAX-ID.
557695     MOVE RCLI-CLI-TAX-ID       TO MIR-CLI-TAX-ID.
           MOVE RCLI-CLI-TXEMP-CD     TO MIR-CLI-TXEMP-CD.
557667*    MOVE RCLI-CLI-BUS-PHON-NUM         TO MIR-CLI-CNTCT-ID-TXT-2.
557667*    MOVE RCLI-CLI-RES-PHON-NUM         TO MIR-CLI-CNTCT-ID-TXT-1.
557667     MOVE RCLI-CLI-ID           TO L2433-CLI-ID.
557667     PERFORM 2433-2000-GET-PHON-NUM
557667        THRU 2433-2000-GET-PHON-NUM-X.
557667     MOVE L2433-HOM-PHON-NUM    TO MIR-CLI-CNTCT-ID-TXT.
557667     MOVE L2433-BUS-PHON-NUM    TO MIR-CLI-CNTCT-ID-TXT-2.
557667     IF L2433-HOM-PHON-NUM NOT = SPACE
557667        MOVE 'HO'               TO WEDIT-ETBL-VALU-ID
557667        MOVE SPACE              TO REDIT-ETBL-DESC-TXT
557667        PERFORM CNTP-2000-DESC
557667           THRU CNTP-2000-DESC-X
557667     END-IF.
557667     IF L2433-BUS-PHON-NUM NOT = SPACE
557667        MOVE 'BU'               TO WEDIT-ETBL-VALU-ID
557667        MOVE SPACE              TO REDIT-ETBL-DESC-TXT
557667        PERFORM CNTP-2000-DESC
557667           THRU CNTP-2000-DESC-X
557667     END-IF.

           MOVE RCLI-CLI-STMT-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-STMT-DT.
           MOVE RCLI-CLI-CLAS-CD      TO MIR-CLI-CLAS-CD.
019155*    MOVE L2440-ADDR-STAT-CD    TO MIR-CLI-ADDR-STAT-CD.
           MOVE RCLI-OCCP-ID          TO MIR-OCCP-ID.
           MOVE RCLI-CLI-OCCP-CLAS-CD TO MIR-CLI-OCCP-CLAS-CD.
023437     MOVE RCLI-CLI-CTZN-CTRY-CD TO MIR-CLI-CTZN-CTRY-CD.

       4100-GENERAL-CLIENT-INFO-X.
           EXIT.

      *-------------------
013578 4110-PR-ADDR-1.
      *-------------------

           MOVE MIR-CLI-ID            TO L2440-CLI-ID.
           MOVE 'PR'                  TO L2440-CLI-ADDR-TYP-CD.
           PERFORM  2440-1000-PRIMARY-ADDRESS
               THRU 2440-1000-PRIMARY-ADDRESS-X.

           IF  L2440-ADDR-STAT-ERROR
      *MSG: WARNING... ADDRESS STATUS CODE IS ERROR
               MOVE 'CS50500014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L2440-ADDR-STAT-INCOMPLETE
               MOVE 'XS00000212'      TO WGLOB-MSG-REF-INFO
               MOVE L2440-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L2440-ADDR-STAT-INCOMPLETE
           AND L2440-CLI-ADDR-LN-1-TXT    = SPACES
           AND L2440-CLI-CITY-NM-TXT      = SPACES
           AND L2440-CLI-CRNT-LOC-CD      = SPACES
           AND L2440-CLI-PSTL-CD          = SPACES
           AND L2440-CLI-CTRY-CD          = SPACES
               MOVE SPACES            TO WCLIA-KEY
               PERFORM  CLIA-1000-CREATE
                   THRU CLIA-1000-CREATE-X
               MOVE RCLIA-CLI-ADDR-INFO
                                      TO L2440-CLI-ADDR-INFO
               MOVE RCLIA-CLI-ADDR-CHNG-DT
                                      TO L2440-ADDR-CHNG-DT
           END-IF.

           MOVE L2440-CLI-ADDR-INFO   TO L0951-CLI-ADDR-INFO.
023434     MOVE L2440-CLI-CTRY-CD     TO L0951-FORMAT-CTRY.
           PERFORM  0951-1000-FORMAT-ADDRESS
               THRU 0951-1000-FORMAT-ADDRESS-X.

           MOVE L0951-CLIENT-ADDRESS-LINE (1)
                                      TO MIR-CLI-ADDR-LN-1-TXT.
           MOVE L0951-CLIENT-ADDRESS-LINE (2)
                                      TO MIR-CLI-ADDR-LN-2-TXT.
           MOVE L0951-CLIENT-ADDRESS-LINE (3)
                                      TO MIR-CLI-ADDR-LN-3-TXT.
           MOVE L0951-CLIENT-ADDRESS-LINE (4)
                                      TO MIR-DV-CLI-ADDR-LN-4-TXT.
           MOVE L0951-CLIENT-ADDRESS-LINE (5)
                                      TO MIR-DV-CLI-ADDR-LN-5-TXT.
019144     MOVE L0951-CLIENT-ADDRESS-LINE (6)
019144                                TO MIR-DV-CLI-ADDR-LN-6-TXT.
019144     MOVE L0951-CLIENT-ADDRESS-LINE-ADDL
019144                                TO MIR-CLI-ADDR-ADDL-TXT.
018763*    MOVE L2440-CLI-JP-ADDR-CD  TO MIR-CLI-JP-ADDR-CD.
018763     MOVE L2440-CLI-ALT-ADDR-CD TO MIR-CLI-ALT-ADDR-CD.

019143     MOVE L2440-CLI-ADDR-CNTCT-TXT  TO  MIR-CLI-ADDR-CNTCT-TXT.
019155     MOVE L2440-ADDR-STAT-CD    TO MIR-CLI-ADDR-STAT-CD.

       4110-PR-ADDR-1-X.
           EXIT.

      *-------------------
013578 4120-PR-ADDR-2.
      *-------------------

           MOVE MIR-CLI-ID            TO L2440-CLI-ID.
           MOVE 'PR'                  TO L2440-CLI-ADDR-TYP-CD.
           PERFORM  2440-1000-PRIMARY-ADDRESS
               THRU 2440-1000-PRIMARY-ADDRESS-X.

           IF  L2440-ADDR-STAT-ERROR
      *MSG: WARNING... ADDRESS STATUS CODE IS ERROR
               MOVE 'CS50500014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L2440-ADDR-STAT-INCOMPLETE
               MOVE 'XS00000212'      TO WGLOB-MSG-REF-INFO
               MOVE L2440-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L2440-ADDR-STAT-INCOMPLETE
           AND L2440-CLI-ADDR-LN-1-TXT    = SPACES
           AND L2440-CLI-CITY-NM-TXT      = SPACES
           AND L2440-CLI-CRNT-LOC-CD      = SPACES
           AND L2440-CLI-PSTL-CD          = SPACES
           AND L2440-CLI-CTRY-CD          = SPACES
               MOVE SPACES            TO WCLIA-KEY
               PERFORM  CLIA-1000-CREATE
                   THRU CLIA-1000-CREATE-X
               MOVE RCLIA-CLI-ADDR-INFO
                                      TO L2440-CLI-ADDR-INFO
               MOVE RCLIA-CLI-ADDR-CHNG-DT
                                      TO L2440-ADDR-CHNG-DT
           END-IF.

           MOVE L2440-CLI-ADDR-INFO   TO L0951-CLI-ADDR-INFO.
023434     MOVE L2440-CLI-CTRY-CD     TO L0951-FORMAT-CTRY.
           PERFORM  0951-1000-FORMAT-ADDRESS
               THRU 0951-1000-FORMAT-ADDRESS-X.

           MOVE L0951-CLIENT-ADDRESS-LINE (1)
                                      TO MIR-CLI-ADDR-LN-1-TXT-2.
           MOVE L0951-CLIENT-ADDRESS-LINE (2)
                                      TO MIR-CLI-ADDR-LN-2-TXT-2.
           MOVE L0951-CLIENT-ADDRESS-LINE (3)
                                      TO MIR-CLI-ADDR-LN-3-TXT-2.
           MOVE L0951-CLIENT-ADDRESS-LINE (4)
                                      TO MIR-DV-CLI-ADDR-LN-4-TXT-2.
           MOVE L0951-CLIENT-ADDRESS-LINE (5)
                                      TO MIR-DV-CLI-ADDR-LN-5-TXT-2.
019144     MOVE L0951-CLIENT-ADDRESS-LINE (6)
019144                                TO MIR-DV-CLI-ADDR-LN-6-TXT-2.
019144     MOVE L0951-CLIENT-ADDRESS-LINE-ADDL
019144                                TO MIR-CLI-ADDR-ADDL-TXT-2.
018763*    MOVE L2440-CLI-JP-ADDR-CD  TO MIR-CLI-JP-ADDR-CD-2.
018763     MOVE L2440-CLI-ALT-ADDR-CD TO MIR-CLI-ALT-ADDR-CD-2.
019155     MOVE L2440-ADDR-STAT-CD    TO MIR-CLI-ADDR-STAT-CD-2.

       4120-PR-ADDR-2-X.
           EXIT.

      *-----------------------
       4300-OWNER-CLIENT-INFO.
      *-----------------------

008455*    MOVE RCLI-CLI-SUSP-AMT         TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2            TO MIR-CLI-SUSP-AMT.
008455*    MOVE WS-PIC-NEG-7-2            TO MIR-CLI-SUSP-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RCLI-CLI-SUSP-AMT * 100.
020874     MOVE RCLI-CLI-SUSP-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-SUSP-AMT TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CLI-SUSP-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RCLI-CLI-SUSP-AMT * 100.
020874     MOVE RCLI-CLI-SUSP-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-SUSP-AMT TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CLI-SUSP-AMT.

       4300-OWNER-CLIENT-INFO-X.
           EXIT.


      *---------------------------
020467*4400-PAC-PAYOR-CLIENT-INFO.
020467 4400-PMT-PAYOR-CLIENT-INFO.
      *---------------------------

           IF  MIR-CLI-BNK-ACCT-NUM NOT = SPACES
           AND MIR-CLI-BNK-ACCT-NUM NOT = ZERO
               PERFORM  4420-READ-BANK-INFO
                   THRU 4420-READ-BANK-INFO-X
           ELSE
               PERFORM  4440-CHECK-BANK-INFO
                   THRU 4440-CHECK-BANK-INFO-X
           END-IF.

020467*4400-PAC-PAYOR-CLIENT-INFO-X.
020467 4400-PMT-PAYOR-CLIENT-INFO-X.
           EXIT.


      *--------------------
       4420-READ-BANK-INFO.
      *--------------------

020478*    MOVE MIR-CLI-ID            TO WCLIN-CLI-ID.
020478*    MOVE MIR-CLI-BNK-ACCT-NUM  TO WS-PIC-9.
020478*    MOVE WS-PIC-9              TO WCLIN-CLI-BNK-ACCT-NUM.
020478*    PERFORM  CLIN-1000-READ
020478*        THRU CLIN-1000-READ-X.
020478     PERFORM  5020-1000-BUILD-PARM-INFO
020478         THRU 5020-1000-BUILD-PARM-INFO-X.
020478     MOVE MIR-CLI-ID            TO L5020-CLI-ID.
020478     MOVE MIR-CLI-BNK-ACCT-NUM  TO WS-PIC-9.
020478     MOVE WS-PIC-9              TO L5020-PAC-NUM.
020478     SET L5020-INFO-TYP-BANK-ACCT TO TRUE.
020478     PERFORM  5020-2000-GET-SPECIFIC-BANK
020478         THRU 5020-2000-GET-SPECIFIC-BANK-X.
020478*    IF  NOT WCLIN-IO-OK
020478     IF  NOT L5020-RETRN-OK
      * MSG: BANK RECORD DOES NOT EXIST FOR  THE BANK ACCT # CODED.
               MOVE 'CS50500008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4420-READ-BANK-INFO-X
           END-IF.

020478*    MOVE RCLIB-BNK-ID          TO WBNKA-BNK-ID.
020478*    MOVE RCLIB-BNK-BR-ID       TO WBNKA-BNK-BR-ID.
020478*    MOVE RCLIB-BNK-ACCT-ID     TO WBNKA-BNK-ACCT-ID.
020478*    PERFORM  BNKA-1000-READ
020478*        THRU BNKA-1000-READ-X.
020478*
020478*    IF  NOT WBNKA-IO-OK
020478* MSG: BNKA RECORD NOT FOUND FOR  CLIB RECORD KEY (@1)
020478*        MOVE RCLIB-KEY         TO WGLOB-MSG-PARM (1)
020478*        MOVE 'CS50500009'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        GO TO 4420-READ-BANK-INFO-X
020478*    END-IF.
020478*
020478*    MOVE RCLIB-BNK-BR-ID       TO MIR-BNK-BR-ID.
020478*    MOVE RCLIB-BNK-ID          TO MIR-BNK-ID.
020478*    MOVE RCLIB-BNK-ACCT-ID     TO MIR-BNK-ACCT-ID.
020478*
020478*    MOVE RBNKA-BNK-ACCT-TYP-CD TO MIR-BNK-ACCT-TYP-CD.
020478*    MOVE RBNKA-BNK-ACCT-MICR-IND
020478*                               TO MIR-BNK-ACCT-MICR-IND.
020478*    MOVE RBNKA-BNK-ACCT-HLDR-NM
020478*                               TO MIR-DV-OWN-CLI-NM.
020478     MOVE L5020-BNK-BR-ID (1)   TO MIR-BNK-BR-ID.
020478     MOVE L5020-BNK-ID (1)      TO MIR-BNK-ID.
020478     MOVE L5020-BNK-ACCT-ID (1) TO MIR-BNK-ACCT-ID.
020478
020478     MOVE L5020-BNK-ACCT-TYP-CD (1)
020478                                TO MIR-BNK-ACCT-TYP-CD.
020478     MOVE L5020-BNK-ACCT-MICR-IND (1)
020478                                TO MIR-BNK-ACCT-MICR-IND.
020478     MOVE L5020-BNK-ACCT-HLDR-NM (1)
020478                                TO MIR-DV-OWN-CLI-NM.

       4420-READ-BANK-INFO-X.
           EXIT.


      *---------------------
       4440-CHECK-BANK-INFO.
      *---------------------

020478*    MOVE MIR-CLI-ID            TO WCLIN-CLI-ID.
020478*    MOVE ZEROES                TO WCLIN-CLI-BNK-ACCT-NUM.
020478*    MOVE WCLIN-KEY             TO WCLIN-ENDBR-KEY.
020478*    MOVE 999                   TO WCLIN-ENDBR-CLI-BNK-ACCT-NUM.
020478*    PERFORM  CLIN-1000-BROWSE
020478*        THRU CLIN-1000-BROWSE-X.
020478*
020478*    IF  WCLIN-IO-OK
020478*        PERFORM  CLIN-2000-READ-NEXT
020478*            THRU CLIN-2000-READ-NEXT-X
020478*
020478*        IF  WCLIN-IO-OK
020478*            PERFORM  CLIN-3000-END-BROWSE
020478*                THRU CLIN-3000-END-BROWSE-X
020478*            GO TO 4440-CHECK-BANK-INFO-X
020478*        END-IF
020478*
020478*        PERFORM  CLIN-3000-END-BROWSE
020478*            THRU CLIN-3000-END-BROWSE-X
020478*    END-IF.
020478*
020478*    MSG: PAYOR  CLIENT HAS NO BANK RECORD
020478*    MOVE 'CS50500012'          TO WGLOB-MSG-REF-INFO.
020478*    PERFORM  0260-1000-GENERATE-MESSAGE
020478*        THRU 0260-1000-GENERATE-MESSAGE-X.

020478     PERFORM  5020-1000-BUILD-PARM-INFO
020478         THRU 5020-1000-BUILD-PARM-INFO-X.
020478     MOVE MIR-CLI-ID            TO L5020-CLI-ID.
020478     MOVE 1                     TO L5020-BANK-QTY
020478     PERFORM  5020-1000-GET-BANK-INFO
020478         THRU 5020-1000-GET-BANK-INFO-X.
020478     IF  L5020-RETRN-BNK-INFO-NOT-FND
020478*MSG: PAYOR  CLIENT HAS NO BANK RECORD
020478         MOVE 'CS50500012'      TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478     END-IF.

       4440-CHECK-BANK-INFO-X.
           EXIT.


      *--------------------------
       4500-LISTBILL-CLIENT-INFO.
      *--------------------------

           PERFORM  5052-1000-BUILD-PARM-INFO
               THRU 5052-1000-BUILD-PARM-INFO-X.
           MOVE ZERO                  TO L5052-LBILL-REC-TYP-CD.
           MOVE MIR-CLI-ID            TO L5052-LBILL-CLI-ID.
           PERFORM  5052-1000-LISTBILL-INFO
               THRU 5052-1000-LISTBILL-INFO-X.

           IF  L5052-RETRN-OK
               MOVE L5052-LBILL-STAT-CD
                                      TO MIR-LBILL-STAT-CD
           END-IF.

       4500-LISTBILL-CLIENT-INFO-X.
           EXIT.


016395*---------------------------
016395 4600-CRC-PAYOR-CLIENT-INFO.
016395*---------------------------
016395
016395     IF  MIR-CLI-CRC-NUM NOT = SPACES
016395     AND MIR-CLI-CRC-NUM NOT = ZERO
016395         PERFORM  4620-READ-CRC-INFO
016395             THRU 4620-READ-CRC-INFO-X
016395     ELSE
016395         PERFORM  4640-CHECK-CRC-INFO
016395             THRU 4640-CHECK-CRC-INFO-X
016395     END-IF.
016395
016395 4600-CRC-PAYOR-CLIENT-INFO-X.
016395     EXIT.
016395
016395*-------------------
016395 4620-READ-CRC-INFO.
016395*-------------------
016395
016395     MOVE MIR-CLI-ID            TO WCLCN-CLI-ID.
016395     MOVE MIR-CLI-CRC-NUM       TO WS-PIC-9.
016395     MOVE WS-PIC-9              TO WCLCN-CLI-CRC-NUM.
016395     PERFORM  CLCN-1000-READ
016395         THRU CLCN-1000-READ-X.
016395
016395     IF  NOT WCLCN-IO-OK
016395* MSG: CREDIT CARD RECORD DOES NOT EXIST FOR THE ACCT # CODED.
016395         MOVE 'CS50500025'      TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395         GO TO 4620-READ-CRC-INFO-X
016395     END-IF.
016395
016395     MOVE RCLCR-CRC-TYP-CD      TO WCRCD-CRC-TYP-CD.
016395     MOVE RCLCR-CRC-ID          TO WCRCD-CRC-ID.
016395     PERFORM  CRCD-1000-READ
016395         THRU CRCD-1000-READ-X.
016395
016395     IF  NOT WCRCD-IO-OK
016395* MSG: CRCD RECORD NOT FOUND FOR  CLCR RECORD KEY (@1)
016395         MOVE RCLCR-KEY         TO WGLOB-MSG-PARM (1)
016395         MOVE 'CS50500026'      TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395         GO TO 4620-READ-CRC-INFO-X
016395     END-IF.
016395
016395     MOVE RCLCR-CRC-TYP-CD      TO MIR-CRC-TYP-CD.
016395     MOVE RCLCR-CRC-ID          TO MIR-CRC-ID.
020874*    MOVE RCRCD-CRC-XPRY-MO     TO L0290-INPUT-NUMBER.
020874     MOVE RCRCD-CRC-XPRY-MO     TO L0290-INPUT-V00.
016395     SET L0290-SIGN-SUPPRESS    TO TRUE.
016395     SET L0290-SIGN-FLOAT       TO TRUE.
016395     MOVE 0                     TO L0290-PRECISION.
016395     MOVE LENGTH OF MIR-CRC-XPRY-MO TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016395     MOVE L0290-OUTPUT-DATA   TO MIR-CRC-XPRY-MO.
016395
020874*    MOVE RCRCD-CRC-XPRY-YR     TO L0290-INPUT-NUMBER.
020874     MOVE RCRCD-CRC-XPRY-YR     TO L0290-INPUT-V00.
016395     SET L0290-SIGN-SUPPRESS    TO TRUE.
016395     SET L0290-SIGN-FLOAT       TO TRUE.
016395     MOVE 0                     TO L0290-PRECISION.
016395     MOVE LENGTH OF MIR-CRC-XPRY-YR TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016395     MOVE L0290-OUTPUT-DATA     TO MIR-CRC-XPRY-YR.
016395     MOVE RCRCD-CRC-HLDR-NM     TO MIR-DV-OWN-CLI-NM.
016395
016395 4620-READ-CRC-INFO-X.
016395     EXIT.
016395
016395*--------------------
016395 4640-CHECK-CRC-INFO.
016395*--------------------
016395
016395     MOVE MIR-CLI-ID            TO WCLCN-CLI-ID.
016395     MOVE ZEROES                TO WCLCN-CLI-CRC-NUM.
016395     MOVE WCLCN-KEY             TO WCLCN-ENDBR-KEY.
016395     MOVE 999                   TO WCLCN-ENDBR-CLI-CRC-NUM.
016395     PERFORM  CLCN-1000-BROWSE
016395         THRU CLCN-1000-BROWSE-X.
016395
016395     IF  WCLCN-IO-OK
016395         PERFORM  CLCN-2000-READ-NEXT
016395             THRU CLCN-2000-READ-NEXT-X
016395
016395         IF  WCLCN-IO-OK
016395             PERFORM  CLCN-3000-END-BROWSE
016395                 THRU CLCN-3000-END-BROWSE-X
016395             GO TO 4640-CHECK-CRC-INFO-X
016395         END-IF
016395
016395         PERFORM  CLCN-3000-END-BROWSE
016395             THRU CLCN-3000-END-BROWSE-X
016395     END-IF.
016395
016395*    MSG: PAYOR CLIENT HAS NO CREDIT CARD RECORD
016395     MOVE 'CS50500027'          TO WGLOB-MSG-REF-INFO.
016395     PERFORM  0260-1000-GENERATE-MESSAGE
016395         THRU 0260-1000-GENERATE-MESSAGE-X.
016395
016395 4640-CHECK-CRC-INFO-X.
016395     EXIT.
016395
      *-------------------------
       5100-GENERAL-POLICY-INFO.
      *-------------------------

           SET WS-RL-FOUND            TO TRUE.
           MOVE RRL-REL-SYS-REF-ID    TO WS-POL-CVG-ID.
           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX-T (WS-SUB).
           MOVE WS-CVG-NUM            TO MIR-CVG-NUM-T (WS-SUB).
010418     MOVE L5051-POL-SBSDRY-CO-ID
010418                                TO MIR-SBSDRY-CO-ID-T (WS-SUB).

           IF  MIR-CVG-NUM-T (WS-SUB) = '00'
               MOVE SPACES            TO MIR-CVG-NUM-T (WS-SUB)
               MOVE L5051-POL-ISS-EFF-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-ISS-EFF-DT-T (WS-SUB)
               MOVE L5051-POL-CSTAT-CD
                                      TO MIR-CVG-CSTAT-CD-T (WS-SUB)
               MOVE L5051-POL-SPND-IND
                                      TO MIR-POL-SPND-IND-T (WS-SUB)
               MOVE L5051-POL-CLI-REL-SUB-CD
                                  TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
           ELSE
               MOVE L5051-CVG-CSTAT-CD
                                      TO MIR-CVG-CSTAT-CD-T (WS-SUB)
               MOVE L5051-CVG-SPND-CSTAT-CD
                                  TO MIR-CVG-SPND-CSTAT-CD-T (WS-SUB)
               MOVE L5051-CVG-ISS-EFF-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-ISS-EFF-DT-T (WS-SUB)
           END-IF.

           IF  RRL-REL-DESC-TXT = SPACES
               MOVE RRL-REL-TYP-CD    TO WEDIT-ETBL-VALU-ID
               PERFORM  RELA-2000-DESC
                   THRU RELA-2000-DESC-X
               IF  WEDIT-IO-OK
                   MOVE REDIT-ETBL-DESC-TXT
                                  TO MIR-REL-DESC-TXT-T (WS-SUB)
               ELSE
                   MOVE 'XS00000223'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-2000-GET-MESSAGE
                       THRU 0260-2000-GET-MESSAGE-X
                   MOVE WGLOB-MSG-TXT
                                  TO MIR-REL-DESC-TXT-T (WS-SUB)
               END-IF

           ELSE
               MOVE RRL-REL-DESC-TXT
                                  TO MIR-REL-DESC-TXT-T (WS-SUB)
           END-IF.

           IF  RRL-REL-TYP-CD = 'I'
               MOVE SPACES            TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
           ELSE
               IF  RRL-REL-TYP-CD = 'B'
                   PERFORM  5150-GET-BENE-ADRT
                       THRU 5150-GET-BENE-ADRT-X
                   MOVE RBENE-BNFY-TYP-CD
                                  TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
               ELSE
                   MOVE L5051-CLI-ADDR-TYP-CD
                                      TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
               END-IF

           END-IF.

           ADD 1                      TO WS-SUB.

       5100-GENERAL-POLICY-INFO-X.
           EXIT.


      *-------------------
       5150-GET-BENE-ADRT.
      *-------------------

           INITIALIZE RBENE-REC-INFO.

           IF  WS-CVG-NUM = '00'

               MOVE LOW-VALUES        TO WBENE-KEY
               MOVE WS-POL-ID         TO WBENE-POL-ID
               MOVE ZEROES            TO WBENE-BNFY-SEQ-NUM

               MOVE WBENE-KEY         TO WBENE-ENDBR-KEY
               MOVE +999              TO WBENE-ENDBR-BNFY-SEQ-NUM

               PERFORM  BENE-1000-BROWSE
                   THRU BENE-1000-BROWSE-X

               IF  WBENE-IO-EOF
                   MOVE SPACES        TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
                   GO TO 5150-GET-BENE-ADRT-X
               END-IF

               PERFORM  BENE-2000-READ-NEXT
                   THRU BENE-2000-READ-NEXT-X
                   UNTIL WBENE-IO-EOF
                   OR  ( RBENE-CLI-ID      = RCLI-CLI-ID
                         AND RBENE-CVG-NUM = WS-CVG-NUM )

               IF  WBENE-IO-EOF
                   MOVE SPACES        TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
                   PERFORM  BENE-3000-END-BROWSE
                       THRU BENE-3000-END-BROWSE-X
                   GO TO 5150-GET-BENE-ADRT-X
               END-IF

               PERFORM  BENE-3000-END-BROWSE
                   THRU BENE-3000-END-BROWSE-X

           ELSE

               MOVE LOW-VALUES        TO WBENC-KEY
               MOVE WS-POL-ID         TO WBENC-POL-ID
               MOVE WS-CVG-NUM        TO WBENC-CVG-NUM
               MOVE ZEROES            TO WBENC-BNFY-SEQ-NUM

               MOVE WBENC-KEY         TO WBENC-ENDBR-KEY
               MOVE +999              TO WBENC-ENDBR-BNFY-SEQ-NUM

               PERFORM  BENC-1000-BROWSE
                   THRU BENC-1000-BROWSE-X

               IF  WBENC-IO-EOF
                   MOVE SPACES        TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
                   GO TO 5150-GET-BENE-ADRT-X
               END-IF

               PERFORM  BENC-2000-READ-NEXT
                   THRU BENC-2000-READ-NEXT-X
                   UNTIL WBENC-IO-EOF
                   OR   RBENE-CLI-ID   = RCLI-CLI-ID

               IF  WBENC-IO-EOF
                   MOVE SPACES        TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
                   PERFORM  BENC-3000-END-BROWSE
                       THRU BENC-3000-END-BROWSE-X
                   GO TO 5150-GET-BENE-ADRT-X
               END-IF

               PERFORM  BENC-3000-END-BROWSE
                   THRU BENC-3000-END-BROWSE-X

           END-IF.

           MOVE RBENE-CLI-ADDR-TYP-CD TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB).

       5150-GET-BENE-ADRT-X.
           EXIT.

      /
      *---------------------------
       5200-INSURED-POLICY-INFO.
      *---------------------------

           MOVE RRL-REL-SYS-REF-ID    TO WS-POL-CVG-ID.
           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX-T (WS-SUB).
           MOVE WS-CVG-NUM            TO MIR-CVG-NUM-T (WS-SUB).

           MOVE L5051-CVG-ISS-EFF-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CVG-ISS-EFF-DT-T (WS-SUB).
010418     MOVE L5051-POL-SBSDRY-CO-ID
010418                                TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE L5051-CVG-CSTAT-CD    TO MIR-CVG-CSTAT-CD-T (WS-SUB).
           MOVE L5051-CVG-SPND-CSTAT-CD
                                  TO MIR-CVG-SPND-CSTAT-CD-T (WS-SUB).
           MOVE L5051-POL-BILL-TYP-CD TO MIR-POL-BILL-TYP-CD-T (WS-SUB).
           MOVE L5051-POL-BILL-MODE-CD
                                  TO MIR-POL-BILL-MODE-CD-T (WS-SUB).
008455*    MOVE L5051-CVG-MPREM-AMT        TO WS-PIC-Z-7-2.
008455*    MOVE WS-PIC-Z-7-2      TO MIR-CVG-MPREM-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-CVG-MPREM-AMT * 100.
020874     MOVE L5051-CVG-MPREM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-MPREM-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-MPREM-AMT-T (WS-SUB).

           MOVE L5051-POL-PD-TO-DT-NUM
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                  TO MIR-POL-PD-TO-DT-NUM-T (WS-SUB).
020874*    MOVE L5051-CVG-ME-FCT      TO WS-PIC-NEG-1-2.
020874*    MOVE WS-PIC-NEG-1-2        TO MIR-CVG-ME-FCT-T (WS-SUB).
020874     MOVE L5051-CVG-ME-FCT      TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-ME-FCT-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN.
020874     SET L0290-SIGN-DISPLAY     TO TRUE.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-ME-FCT-T (WS-SUB).
557671     MOVE L5051-CVG-ME-RAT-CD   TO MIR-CVG-ME-RAT-CD-T (WS-SUB).
           MOVE L5051-CVG-ME-REASN-CD TO MIR-CVG-ME-REASN-CD-T (WS-SUB).
008455*    MOVE L5051-CVG-FE-PREM-AMT      TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2             TO MIR-CVG-FE-PREM-AMT-T (WS-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                             L5051-CVG-FE-PREM-AMT  * 100.
020874     MOVE L5051-CVG-FE-PREM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FE-PREM-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FE-PREM-AMT-T (WS-SUB).

           MOVE L5051-CVG-FE-REASN-CD
                                      TO MIR-CVG-FE-REASN-CD-T (WS-SUB).

013578     MOVE L5051-CVG-PLAN-ID     TO MIR-PLAN-ID-T (WS-SUB).
           MOVE L5051-CVG-RT-AGE      TO MIR-CVG-RT-AGE-T (WS-SUB).

008455*    MOVE L5051-CVG-SUM-INS-AMT      TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-CVG-SUM-INS-AMT-T (WS-
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-CVG-SUM-INS-AMT * 100.
020874     MOVE L5051-CVG-SUM-INS-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-SUM-INS-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-SUM-INS-AMT-T (WS-SUB).

008455*    MOVE L5051-CVG-FACE-AMT         TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-CVG-FACE-AMT-T (WS-SUB
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-CVG-FACE-AMT * 100.
020874     MOVE L5051-CVG-FACE-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FACE-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FACE-AMT-T (WS-SUB).

008455*    MOVE L5051-REIN-AMOUNT          TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-DV-REINS-TOT-AMT-T (WS
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-REIN-AMOUNT * 100.
020874     MOVE L5051-REIN-AMOUNT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-REINS-TOT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-REINS-TOT-AMT-T (WS-SUB).

020874*    MOVE L5051-CVG-WP-MULT-FCT TO WS-PIC-NEG-1-2.
020874*    MOVE WS-PIC-NEG-1-2        TO MIR-CVG-WP-MULT-FCT-T (WS-SUB).
020874     MOVE L5051-CVG-WP-MULT-FCT TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-WP-MULT-FCT-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN.
020874     SET L0290-SIGN-DISPLAY     TO TRUE.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA    TO MIR-CVG-WP-MULT-FCT-T (WS-SUB).
008455*    MOVE L5051-CVG-AD-FACE-AMT      TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-CVG-AD-FACE-AMT-T (WS-
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-CVG-AD-FACE-AMT * 100.
020874     MOVE L5051-CVG-AD-FACE-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-AD-FACE-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-AD-FACE-AMT-T (WS-SUB).

020874*    MOVE L5051-CVG-AD-MULT-FCT TO WS-PIC-9-1-2.
020874*    MOVE WS-PIC-9-1-2          TO MIR-CVG-AD-MULT-FCT-T (WS-SUB).
020874     MOVE L5051-CVG-AD-MULT-FCT TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-AD-MULT-FCT-T (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-AD-MULT-FCT-T (WS-SUB).
008455*    MOVE L5051-AD-AMOUNT            TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-CSN-AD-FACE-AMT-T (WS-
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-AD-AMOUNT * 100.
020874     MOVE L5051-AD-AMOUNT       TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-AD-FACE-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-AD-FACE-AMT-T (WS-SUB).

           MOVE L5051-AGENT           TO MIR-AGT-ID-T (WS-SUB).

           MOVE WS-POL-ID             TO L2430-POL-ID.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           MOVE L2430-CLI-ID          TO MIR-CLI-ID-T (WS-SUB).

025388*    MOVE L5051-CVG-LIVES-INSRD-CD
025388*                           TO MIR-CVG-LIVES-INSRD-CD-T (WS-SUB).
025388     MOVE L5051-CVG-LIVES-INSRD-QTY
025388                            TO MIR-LIVES-INSRD-QTY-T (WS-SUB).

           ADD 1                      TO WS-SUB.

       5200-INSURED-POLICY-INFO-X.
           EXIT.
      /
      *-----------------------
       5300-OWNER-POLICY-INFO.
      *-----------------------

           MOVE RRL-REL-SYS-REF-ID    TO WS-POL-CVG-ID.
           SET WS-RL-FOUND            TO TRUE.

           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX-T (WS-SUB).

           MOVE L5051-POL-ISS-EFF-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-POL-ISS-EFF-DT-T (WS-SUB).
010418     MOVE L5051-POL-SBSDRY-CO-ID
010418                                TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE L5051-POL-CSTAT-CD    TO MIR-POL-CSTAT-CD-T (WS-SUB).
           MOVE L5051-POL-SPND-IND    TO MIR-POL-SPND-IND-T (WS-SUB).
           MOVE L5051-POL-BILL-TYP-CD TO MIR-POL-BILL-TYP-CD-T (WS-SUB).
           MOVE L5051-POL-BILL-MODE-CD
                                  TO MIR-POL-BILL-MODE-CD-T (WS-SUB).
008455*    MOVE L5051-POL-MPREM-AMT        TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2             TO MIR-POL-MPREM-AMT-T (WS-SU
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-MPREM-AMT * 100.
020874     MOVE L5051-POL-MPREM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-MPREM-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-MPREM-AMT-T (WS-SUB).

008455*    MOVE L5051-POL-GRS-APREM-AMT    TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-POL-GRS-APREM-AMT-T (W
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-GRS-APREM-AMT * 100
020874     MOVE L5051-POL-GRS-APREM-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-GRS-APREM-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-POL-GRS-APREM-AMT-T (WS-SUB).

020874*    MOVE L5051-POL-PREM-DSCNT-PCT
020874*                               TO WS-PIC-9-2-3.
020874*    MOVE WS-PIC-9-2-3      TO MIR-POL-PREM-DSCNT-PCT-T (WS-SUB).
020874     MOVE L5051-POL-PREM-DSCNT-PCT TO L0290-INPUT-V03.
020874     MOVE 3                        TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-PREM-DSCNT-PCT-T (WS-SUB)
020874                                   TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-POL-PREM-DSCNT-PCT-T (WS-SUB).

           MOVE WS-POL-ID             TO L2430-POL-ID.
           MOVE L5051-POL-BASE-CVG-NUM
                                      TO L2430-CVG.
           PERFORM  2430-3100-GET-PRIM-INSRD
               THRU 2430-3100-GET-PRIM-INSRD-X.
           MOVE L2430-CLI-ID          TO MIR-INSRD-CLI-ID-T (WS-SUB).

           MOVE L5051-POL-PD-TO-DT-NUM
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                  TO MIR-POL-PD-TO-DT-NUM-T (WS-SUB).
           MOVE L5051-POL-BILL-TO-DT-NUM
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                  TO MIR-POL-BILL-TO-DT-NUM-T (WS-SUB).

008455*    MOVE L5051-POL-PREM-SUSP-AMT    TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2             TO MIR-POL-PREM-SUSP-AMT-T (W
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-PREM-SUSP-AMT * 100
020874     MOVE L5051-POL-PREM-SUSP-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-POL-PREM-SUSP-AMT-T (WS-SUB).

008455*    MOVE L5051-POL-MISC-SUSP-AMT    TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2             TO MIR-POL-MISC-SUSP-AMT-T (W
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-MISC-SUSP-AMT * 100
020874     MOVE L5051-POL-MISC-SUSP-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-POL-MISC-SUSP-AMT-T (WS-SUB).

008455*    MOVE L5051-POL-OS-DISB-AMT      TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-POL-OS-DISB-AMT-T (WS-
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-OS-DISB-AMT * 100.
020874     MOVE L5051-POL-OS-DISB-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-OS-DISB-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-OS-DISB-AMT-T (WS-SUB).

008455*    MOVE L5051-LOAN-AMT-1           TO WS-PIC-Z-7-2.
008455*    MOVE WS-PIC-Z-7-2               TO MIR-DV-LOAN-REPAY-AMT-T (W
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-LOAN-AMT-1 * 100.
020874     MOVE L5051-LOAN-AMT-1      TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LOAN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-LOAN-AMT-T (WS-SUB).

008455*    MOVE L5051-LOAN-AMT-3           TO WS-PIC-Z-7-2.
008455*    MOVE WS-PIC-Z-7-2               TO MIR-DV-LOAN-REPAY-AMT-T (W
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-LOAN-AMT-3 * 100.
020874     MOVE L5051-LOAN-AMT-3      TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-APL-LOAN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-APL-LOAN-AMT-T (WS-SUB).

           MOVE L5051-POL-TOT-LOAN-AMT
                                      TO WS-LOAN-HOLD.

008455*    MOVE WS-LOAN-HOLD               TO WS-PIC-Z-8-2.
008455*    MOVE WS-PIC-Z-8-2               TO MIR-LOAN-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER = WS-LOAN-HOLD * 100.
020874     MOVE WS-LOAN-HOLD          TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-LOAN-REPAY-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-LOAN-REPAY-AMT-T (WS-SUB).

008455*    MOVE L5051-POL-CSV-AMT          TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-DV-POL-CSV-AMT-T (WS-S
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-CSV-AMT * 100.
020874     MOVE L5051-POL-CSV-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-POL-CSV-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-CSV-AMT-T (WS-SUB).

008455*    MOVE L5051-LOAN-CSV-AMT         TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-DV-LOAN-DSCNT-AMT-T (W
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-LOAN-CSV-AMT * 100.
020874     MOVE L5051-LOAN-CSV-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-LOAN-DSCNT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-LOAN-DSCNT-AMT-T (WS-SUB)

008455*    MOVE L5051-POL-ACUM-VALU-AMT    TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-DV-CFN-APROX-AMT-T (WS
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-ACUM-VALU-AMT * 100
020874     MOVE L5051-POL-ACUM-VALU-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CFN-APROX-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-SIDFND-AFV-AMT * 100
020874     MOVE L5051-POL-SIDFND-AFV-AMT TO L0290-INPUT-V02.
018846     MOVE 2                     TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-POL-SIDFND-AFV-AMT-T (WS-SUB)
018846                                TO L0290-MAX-OUT-LEN.
018846     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA
018846       TO MIR-DV-POL-SIDFND-AFV-AMT-T (WS-SUB).
018846
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-SIDFND-NET-CV-AMT * 100
020874     MOVE L5051-SIDFND-NET-CV-AMT TO L0290-INPUT-V02.
018846     MOVE 2                     TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-SIDFND-NET-CV-AMT-T (WS-SUB)
018846                                TO L0290-MAX-OUT-LEN.
018846     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA
018846       TO MIR-DV-SIDFND-NET-CV-AMT-T (WS-SUB).
018846
           PERFORM  2430-1000-BUILD-POL-REL-INFO
               THRU 2430-1000-BUILD-POL-REL-INFO-X.
           IF  L2430-OWNER-CTR > 1
               MOVE 'Y'           TO MIR-DV-POL-JNT-OWN-IND-T (WS-SUB)
           ELSE
               MOVE 'N'           TO MIR-DV-POL-JNT-OWN-IND-T (WS-SUB)
           END-IF.

016053     INITIALIZE RPOL-REC-INFO.

           MOVE WS-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
      *        SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'POLICY RECORD NOT FOUND (@1)'
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

016053     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016053         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

016053     PERFORM  6981-1000-BUILD-PARM-INFO
016053         THRU 6981-1000-BUILD-PARM-INFO-X.
016053
016053     MOVE WS-CVG-NUM            TO L6981-CVG.
016053     MOVE WGLOB-PROCESS-DATE    TO L6981-SCREEN-DATE.
016053     MOVE WGLOB-PROCESS-DATE    TO L1640-EXTERNAL-DATE.
016053     MOVE WGLOB-PROCESS-DATE    TO L6981-EFF-DT.
016053
016053     PERFORM  6981-1000-INQUIRE
016053         THRU 6981-1000-INQUIRE-X.
016053
020464*    ADD L6981-DV-POL-ACUM-AMT  TO
020464*        WS-DV-POL-ACUM-AMT.
020464* DO NOT INCLUDE PENDING ACTIVITY AMOUNT
020464      COMPUTE  WS-DV-POL-ACUM-AMT
020464             = WS-DV-POL-ACUM-AMT
020464             + L6981-DV-POL-ACUM-AMT
020464             - L6981-DV-POL-PEND-IN-AMT
020464             + L6981-DV-POL-PEND-OUT-AMT.
020464
020464* DETERMINE PENDING DEPOSIT ACTIVITY AMOUNT
020464     COMPUTE  WS-DV-TOT-POL-PEND-AMT
020464            = WS-DV-TOT-POL-PEND-AMT
020464            + L6981-DV-POL-PEND-IN-AMT
020464            + L6981-DV-POL-PEND-OUT-AMT.
020464
020464     COMPUTE L0290-INPUT-V02
020464            = WS-DV-TOT-POL-PEND-AMT.
020464     MOVE 2                     TO L0290-PRECISION.
020464     MOVE LENGTH OF MIR-DV-POL-PEND-ACTV-AMT
020464                                TO L0290-MAX-OUT-LEN.
020464     SET L0290-SIGN-DISPLAY     TO TRUE.
020464     PERFORM 0290-2000-FORMAT-FOR-MIR
020464        THRU 0290-2000-FORMAT-FOR-MIR-X.
020464     MOVE L0290-OUTPUT-DATA TO
020464          MIR-DV-POL-PEND-ACTV-AMT.
020464
020464* DETERMINE NET DEFERRED ACTIVITY
020464     COMPUTE  WS-DV-TOT-POL-DEFR-AMT
020464            = WS-DV-TOT-POL-DEFR-AMT
020464            + L6981-DV-POL-DEFR-IN-AMT
020464            + L6981-DV-POL-DEFR-OUT-AMT.
020464
020464     COMPUTE L0290-INPUT-V02
020464            = WS-DV-TOT-POL-DEFR-AMT.
020464     MOVE 2                     TO L0290-PRECISION.
020464     MOVE LENGTH OF MIR-DV-POL-DEFR-ACTV-AMT
020464                                TO L0290-MAX-OUT-LEN.
020464     SET L0290-SIGN-DISPLAY     TO TRUE.
020464     PERFORM 0290-2000-FORMAT-FOR-MIR
020464        THRU 0290-2000-FORMAT-FOR-MIR-X.
020464     MOVE L0290-OUTPUT-DATA TO
020464          MIR-DV-POL-DEFR-ACTV-AMT.
020464
020464     COMPUTE L6981-DV-POL-SURR-AMT
020464           = L6981-DV-POL-SURR-AMT
020464           + L6981-DV-POL-DEFR-IN-AMT
020464           + L6981-DV-POL-DEFR-OUT-AMT.
020464
016053     ADD L6981-DV-POL-SURR-AMT      TO
016053         WS-DV-TOT-POL-SURR-AMT.
016053     ADD L6981-MAXLN                TO
016053         WS-DV-TOT-LOAN-MAX-AMT.
016053
018846     ADD L6981-DV-POL-SIDFND-AFV-AMT  TO
018846         WS-DV-POL-SIDFND-AFV-AMT.
018846     ADD L6981-DV-SIDFND-NET-CV-AMT  TO
018846         WS-DV-SIDFND-NET-CV-AMT.
018846
020874*    COMPUTE L0290-INPUT-NUMBER = WS-DV-POL-ACUM-AMT * 100.
020874     MOVE WS-DV-POL-ACUM-AMT TO L0290-INPUT-V02.
016053     MOVE 2                     TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-TOT-POL-ACUM-AMT
016053                                TO L0290-MAX-OUT-LEN.
016053     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA TO
016053          MIR-DV-TOT-POL-ACUM-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = WS-DV-POL-SIDFND-AFV-AMT * 100.
020874     MOVE WS-DV-POL-SIDFND-AFV-AMT TO L0290-INPUT-V02.
018846     MOVE 2                     TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-POL-SIDFND-AFV-AMT
018846                                TO L0290-MAX-OUT-LEN.
018846     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA TO
018846          MIR-DV-POL-SIDFND-AFV-AMT.
018846
020874*    COMPUTE L0290-INPUT-NUMBER = WS-DV-SIDFND-NET-CV-AMT * 100.
020874     MOVE WS-DV-SIDFND-NET-CV-AMT TO L0290-INPUT-V02.
018846     MOVE 2                     TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-SIDFND-NET-CV-AMT
018846                                TO L0290-MAX-OUT-LEN.
018846     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA TO
018846          MIR-DV-SIDFND-NET-CV-AMT.
018846
020874*    COMPUTE L0290-INPUT-NUMBER = WS-DV-TOT-POL-SURR-AMT * 100
020874     MOVE WS-DV-TOT-POL-SURR-AMT TO L0290-INPUT-V02.
016053     MOVE 2                     TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-TOT-POL-SURR-AMT
016053                                TO L0290-MAX-OUT-LEN.
016053     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA TO
016053          MIR-DV-TOT-POL-SURR-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = WS-DV-TOT-LOAN-MAX-AMT * 100
020874     MOVE WS-DV-TOT-LOAN-MAX-AMT TO L0290-INPUT-V02.
016053     MOVE 2                     TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-TOT-MAX-LOAN-AMT
016053                                TO L0290-MAX-OUT-LEN.
016053     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA TO
016053          MIR-DV-TOT-MAX-LOAN-AMT.
016053
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-POL-ACUM-AMT * 100
020874     MOVE L6981-DV-POL-ACUM-AMT TO L0290-INPUT-V02.
016053     MOVE 2                     TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-POL-ACUM-AMT-T (WS-SUB)
016053                                TO L0290-MAX-OUT-LEN.
016053     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA TO
016053          MIR-DV-POL-ACUM-AMT-T (WS-SUB).
016053
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-POL-SIDFND-AFV-AMT
020874*                               * 100.
020874     MOVE L6981-DV-POL-SIDFND-AFV-AMT  TO L0290-INPUT-V02.
018846     MOVE 2                     TO L0290-PRECISION.
018846     MOVE LENGTH OF MIR-DV-POL-SIDFND-AFV-AMT-T (WS-SUB)
018846                                TO L0290-MAX-OUT-LEN.
018846     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018846     MOVE L0290-OUTPUT-DATA TO
018846          MIR-DV-POL-SIDFND-AFV-AMT-T (WS-SUB).
018846
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-DV-POL-SURR-AMT * 100
020874     MOVE L6981-DV-POL-SURR-AMT TO L0290-INPUT-V02.
016053     MOVE 2                     TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-POL-SURR-AMT-T (WS-SUB)
016053                                TO L0290-MAX-OUT-LEN.
016053     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA TO
016053           MIR-DV-POL-SURR-AMT-T (WS-SUB).
016053
020874*    COMPUTE L0290-INPUT-NUMBER = L6981-MAXLN * 100
020874     MOVE L6981-MAXLN TO L0290-INPUT-V02.
016053     MOVE 2                     TO L0290-PRECISION.
016053     MOVE LENGTH OF MIR-DV-MAX-LOAN-AMT-T (WS-SUB)
016053                                TO L0290-MAX-OUT-LEN.
016053     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016053     MOVE L0290-OUTPUT-DATA TO
016053          MIR-DV-MAX-LOAN-AMT-T (WS-SUB).

           ADD 1                      TO WS-SUB.

       5300-OWNER-POLICY-INFO-X.
           EXIT.
      /
      *-----------------------
016395*5400-PAC-PAYOR-POLICY-INFO.
016395 5400-PAYOR-POLICY-INFO.
      *-----------------------

020467     IF  MIR-POL-BILL-TYP-CD-T (WS-SUB) NOT = SPACES
020467     AND MIR-POL-BILL-TYP-CD-T (WS-SUB)
020467                           NOT = L5051-POL-BILL-TYP-CD
020467        GO TO 5400-PAYOR-POLICY-INFO-X
020467     END-IF.
020467
           SET WS-RL-FOUND            TO TRUE.
           MOVE RRL-REL-SYS-REF-ID    TO WS-POL-CVG-ID.
           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX-T (WS-SUB).

           MOVE L5051-POL-ISS-EFF-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-POL-ISS-EFF-DT-T (WS-SUB).
010418     MOVE L5051-POL-SBSDRY-CO-ID
010418                                TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE L5051-POL-CSTAT-CD    TO MIR-POL-CSTAT-CD-T (WS-SUB).
           MOVE L5051-POL-SPND-IND    TO MIR-POL-SPND-IND-T (WS-SUB).
           MOVE L5051-POL-PD-TO-DT-NUM
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                  TO MIR-POL-PD-TO-DT-NUM-T (WS-SUB).
           MOVE L5051-POL-BILL-TO-DT-NUM
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                  TO MIR-POL-BILL-TO-DT-NUM-T (WS-SUB).
           MOVE L5051-POL-BILL-MODE-CD
                                  TO MIR-POL-BILL-MODE-CD-T (WS-SUB).
557659*    MOVE L5051-POL-PAC-DRW-DY-CD    TO MIR-POL-PAC-DRW-DY-T (WS-S
016395*    MOVE L5051-POL-PAC-DRW-DY-CD-N
016395*                               TO MIR-POL-PAC-DRW-DY-T (WS-SUB).
016395     MOVE L5051-POL-PMT-DRW-DY-CD-N
016395                                TO MIR-POL-PMT-DRW-DY-T (WS-SUB).

008455*    MOVE L5051-POL-MPREM-AMT        TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2             TO MIR-POL-MPREM-AMT-T (WS-SU
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-MPREM-AMT * 100.
020874     MOVE L5051-POL-MPREM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-MPREM-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-MPREM-AMT-T (WS-SUB).

008455*    MOVE L5051-POL-SNDRY-AMT        TO WS-PIC-Z-7-2.
008455*    MOVE WS-PIC-Z-7-2               TO MIR-POL-SNDRY-AMT-T (WS-SU
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-SNDRY-AMT * 100.
020874     MOVE L5051-POL-SNDRY-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-SNDRY-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-SNDRY-AMT-T (WS-SUB).

008455*    MOVE L5051-POL-LOAN-REPAY-AMT   TO WS-PIC-NEG-5-2.
008455*    MOVE WS-PIC-NEG-5-2             TO MIR-POL-LOAN-REPAY-AMT-T (
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-LOAN-REPAY-AMT * 100.
020874     MOVE L5051-POL-LOAN-REPAY-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-LOAN-REPAY-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-POL-LOAN-REPAY-AMT-T (WS-SUB).

008455*    MOVE L5051-POL-PREM-SUSP-AMT    TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2             TO MIR-POL-PREM-SUSP-AMT-T (W
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-PREM-SUSP-AMT * 100.
020874     MOVE L5051-POL-PREM-SUSP-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-POL-PREM-SUSP-AMT-T (WS-SUB).

008455*    MOVE L5051-POL-MISC-SUSP-AMT    TO WS-PIC-NEG-7-2.
008455*    MOVE WS-PIC-NEG-7-2             TO MIR-POL-MISC-SUSP-AMT-T (W
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-POL-MISC-SUSP-AMT * 100.
020874     MOVE L5051-POL-MISC-SUSP-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-MISC-SUSP-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-POL-MISC-SUSP-AMT-T (WS-SUB).

           MOVE L5051-BILL-RMND-REASN-CD
                                  TO MIR-BILL-RMND-REASN-CD-T (WS-SUB).
           MOVE L5051-POL-RBILL-CD    TO MIR-POL-RBILL-CD-T (WS-SUB).
           MOVE L5051-POL-RBILL-DEPT-ID
                                      TO MIR-RBILL-DEPT-ID-T (WS-SUB).
           MOVE L5051-POL-RBILL-USER-ID
                                      TO MIR-RBILL-USER-ID-T (WS-SUB).
557659*    MOVE L5051-MISC-RESTR-1-IND     TO MIR-RBILL-MISC-1-CD-T (WS-
557659*    MOVE L5051-MISC-RESTR-2-IND     TO MIR-RBILL-MISC-2-CD-T (WS-
557659     MOVE L5051-MISC-RESTR-1-CD TO MIR-RBILL-MISC-1-CD-T (WS-SUB).
557659     MOVE L5051-MISC-RESTR-2-CD TO MIR-RBILL-MISC-2-CD-T (WS-SUB).

           MOVE L5051-POL-RBILL-EFF-DT
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-RBILL-EFF-DT-T (WS-SUB).
           MOVE L5051-POL-RBILL-END-DT
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-RBILL-END-DT-T (WS-SUB).
016395*    MOVE L5051-POL-PAC-RETRN-1-DT
016395     MOVE L5051-POL-PMT-RETRN-1-DT
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
016395*                           TO MIR-POL-PAC-RETRN-1-DT-T (WS-SUB).
016395                            TO MIR-POL-PMT-RETRN-1-DT-T (WS-SUB).
016395*    MOVE L5051-POL-PAC-RETRN-1-CD
016395*                           TO MIR-POL-PAC-RETRN-1-CD-T (WS-SUB).
016395     MOVE L5051-POL-PMT-RETRN-1-CD
016395                            TO MIR-POL-PMT-RETRN-1-CD-T (WS-SUB).
016395*    MOVE L5051-POL-PAC-RETRN-2-DT
016395     MOVE L5051-POL-PMT-RETRN-2-DT
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
016395*                           TO MIR-POL-PAC-RETRN-2-DT-T (WS-SUB).
016395                            TO MIR-POL-PMT-RETRN-2-DT-T (WS-SUB).
016395*    MOVE L5051-POL-PAC-RETRN-2-CD
016395*                           TO MIR-POL-PAC-RETRN-2-CD-T (WS-SUB).
016395     MOVE L5051-POL-PMT-RETRN-2-CD
016395                            TO MIR-POL-PMT-RETRN-2-CD-T (WS-SUB).
016395*    MOVE L5051-PAC-REDRW-OPT-CD
016395*                           TO MIR-PAC-REDRW-OPT-CD-T (WS-SUB).
016395     MOVE L5051-PMT-REDRW-OPT-CD
016395                            TO MIR-PMT-REDRW-OPT-CD-T (WS-SUB).
016395*    MOVE L5051-POL-PAC-REDRW-DT
016395     MOVE L5051-POL-PMT-REDRW-DT
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
016395*                           TO MIR-POL-PAC-REDRW-DT-T (WS-SUB).
016395                            TO MIR-POL-PMT-REDRW-DT-T (WS-SUB).
020467     MOVE L5051-POL-BILL-TYP-CD
020467                            TO MIR-POL-BILL-TYP-CD-T (WS-SUB ).

           ADD 1                      TO WS-SUB.

016395*5400-PAC-PAYOR-POLICY-INFO-X.
016395 5400-PAYOR-POLICY-INFO-X.
           EXIT.
      /
      *--------------------------
       5500-LISTBILL-POLICY-INFO.
      *--------------------------

           SET WS-RL-FOUND            TO TRUE.
           MOVE RRL-REL-SYS-REF-ID    TO WS-POL-CVG-ID.
           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX-T (WS-SUB).

           MOVE WS-POL-ID             TO L2430-POL-ID.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RELATIONSHIP-FOUND
               MOVE L2430-CLI-SUR-NM  TO MIR-DV-OWN-CLI-NM-T (WS-SUB)
           ELSE
               MOVE SPACES            TO MIR-DV-OWN-CLI-NM-T (WS-SUB)
           END-IF.

010418     MOVE L5051-POL-SBSDRY-CO-ID
010418                                TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE L5051-POL-CSTAT-CD    TO MIR-POL-CSTAT-CD-T (WS-SUB).
           MOVE L5051-POL-SPND-IND    TO MIR-POL-SPND-IND-T (WS-SUB).

008455*    MOVE L5051-SUM-INSURED          TO WS-PIC-Z-9-2.
008455*    MOVE WS-PIC-Z-9-2               TO MIR-DV-POL-SUM-INS-AMT-T (
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-SUM-INSURED * 100.
020874     MOVE L5051-SUM-INSURED     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-POL-SUM-INS-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-SUM-INS-AMT-T (WS-SUB).

           MOVE L5051-POL-BILL-MODE-CD
                                  TO MIR-POL-BILL-MODE-CD-T (WS-SUB).

           MOVE L5051-POL-PD-TO-DT-NUM
                                      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                  TO MIR-POL-PD-TO-DT-NUM-T (WS-SUB).

008455*    MOVE L5051-BILLING-AMOUNT       TO WS-PIC-Z-7-2.
008455*    MOVE WS-PIC-Z-7-2               TO MIR-DV-TOT-BILL-AMT-T (WS-
020874*    COMPUTE L0290-INPUT-NUMBER = L5051-BILLING-AMOUNT * 100.
020874     MOVE L5051-BILLING-AMOUNT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-TOT-BILL-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TOT-BILL-AMT-T (WS-SUB).

           ADD 1                      TO WS-SUB.

       5500-LISTBILL-POLICY-INFO-X.
           EXIT.
      /
      *--------------------------
       5600-CAN-TAXN-POLICY-INFO.
      *--------------------------

           SET WS-RL-FOUND            TO TRUE.
           MOVE RRL-REL-SYS-REF-ID    TO WS-POL-CVG-ID.
           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX-T (WS-SUB).

           MOVE L5051-POL-ISS-EFF-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-POL-ISS-EFF-DT-T (WS-SUB).
010418     MOVE L5051-POL-SBSDRY-CO-ID
010418                                TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE L5051-POL-CSTAT-CD    TO MIR-POL-CSTAT-CD-T (WS-SUB).
           MOVE L5051-POL-SPND-IND    TO MIR-POL-SPND-IND-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = L5051-TAX-ACB * 100.
020874     MOVE L5051-TAX-ACB         TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-ACB-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CDN-TAX-ACB-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = L5051-TAX-ANNV-ACB-AMT * 100.
020874     MOVE L5051-TAX-ANNV-ACB-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TAX-ANNV-ACB-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-TAX-ANNV-ACB-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = L5051-TAX-GAIN-AMT * 100.
020874     MOVE L5051-TAX-GAIN-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TAX-GAIN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-TAX-GAIN-AMT-T (WS-SUB).

           COMPUTE WS-TSYRB-HOLD =
031036*       (L5051-PREV-XEMP-TST-DUR-N - 1) + L5051-POL-ISS-EFF-DT-YR.
031036        (L5051-NXT-XEMP-TST-DUR-N - 1) + L5051-POL-ISS-EFF-DT-YR.
           MOVE WS-TSYRB-HOLD     TO MIR-DV-TXEMP-PYR-QTY-T (WS-SUB).
           MOVE L5051-POL-TXEMP-CD    TO MIR-POL-TXEMP-CD-T (WS-SUB).
           MOVE L5051-POL-TAX-TYP-CD  TO MIR-POL-TAX-TYP-CD-T (WS-SUB).
           MOVE L5051-TAX-RPT-FREQ-CD TO MIR-TAX-RPT-FREQ-CD-T (WS-SUB).
           MOVE L5051-GAIN-RPT-TIME-CD
                                  TO MIR-GAIN-RPT-TIME-CD-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = L5051-FED-TAXWH-YTD-AMT * 100.
020874     MOVE L5051-FED-TAXWH-YTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-FED-TAXWH-YTD-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-FED-TAXWH-YTD-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = L5051-PROV-TAXWH-YTD-AMT * 100.
020874     MOVE L5051-PROV-TAXWH-YTD-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PROV-TAXWH-YTD-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-PROV-TAXWH-YTD-AMT-T (WS-SUB).

           ADD 1                      TO WS-SUB.

       5600-CAN-TAXN-POLICY-INFO-X.
           EXIT.

      *--------------------------
       5700-CAN-TAXR-POLICY-INFO.
      *--------------------------

           SET WS-RL-FOUND            TO TRUE.
           MOVE RRL-REL-SYS-REF-ID    TO WS-POL-CVG-ID.
           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX-T (WS-SUB).

           MOVE L5051-POL-ISS-EFF-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-POL-ISS-EFF-DT-T (WS-SUB).
010418     MOVE L5051-POL-SBSDRY-CO-ID
010418                                TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE L5051-POL-CSTAT-CD    TO MIR-POL-CSTAT-CD-T (WS-SUB).
           MOVE L5051-POL-SPND-IND    TO MIR-POL-SPND-IND-T (WS-SUB).
           MOVE RRL-REL-TYP-CD        TO MIR-REL-TYP-CD-T (WS-SUB).

           IF  RRL-REL-TYP-CD = 'S'
008455*        MOVE ZEROES                 TO WS-PIC-NEG-9-2
008455*        MOVE WS-PIC-NEG-9-2         TO MIR-TAX-GAIN-AMT-T (WS-SUB
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-TAX-GAIN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-TAX-GAIN-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-FED-TAXWH-YTD-AMT-T (W
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-FED-TAXWH-YTD-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-FED-TAXWH-YTD-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-PROV-TAXWH-YTD-AMT-T (
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PROV-TAXWH-YTD-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-PROV-TAXWH-YTD-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-REG-CNTRB-1-AMT-T (WS-
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-1-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-REG-CNTRB-2-AMT-T (WS-
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-2-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-REG-RECPT-1-AMT-T (WS-
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-1-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-REG-RECPT-2-AMT-T (WS-
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-2-AMT-T (WS-SUB)

           ELSE

008455*        MOVE L5051-TAX-GAIN-AMT     TO WS-PIC-NEG-9-2
008455*        MOVE WS-PIC-NEG-9-2         TO MIR-TAX-GAIN-AMT-T (WS-SUB
020874*        COMPUTE L0290-INPUT-NUMBER = L5051-TAX-GAIN-AMT  * 100
020874         MOVE L5051-TAX-GAIN-AMT     TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-TAX-GAIN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-TAX-GAIN-AMT-T (WS-SUB)

008455*        MOVE L5051-FED-TAXWH-YTD-AMT   TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-FED-TAXWH-YTD-AMT-T (W
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                             L5051-FED-TAXWH-YTD-AMT * 100
020874         MOVE L5051-FED-TAXWH-YTD-AMT   TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-FED-TAXWH-YTD-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-FED-TAXWH-YTD-AMT-T (WS-SUB)

008455*        MOVE L5051-PROV-TAXWH-YTD-AMT  TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-PROV-TAXWH-YTD-AMT-T (
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                            L5051-PROV-TAXWH-YTD-AMT * 100
020874         MOVE L5051-PROV-TAXWH-YTD-AMT  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PROV-TAXWH-YTD-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-PROV-TAXWH-YTD-AMT-T (WS-SUB)

008455*        MOVE L5051-POL-REG-2-AMT    TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-REG-CNTRB-1-AMT-T (WS-
020874*        COMPUTE L0290-INPUT-NUMBER = L5051-POL-REG-2-AMT * 100
020874         MOVE L5051-POL-REG-2-AMT    TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-1-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-1-AMT-T (WS-SUB)

008455*        MOVE L5051-POL-REG-1-AMT    TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-REG-CNTRB-2-AMT-T (WS-
020874*        COMPUTE L0290-INPUT-NUMBER = L5051-POL-REG-1-AMT * 100
020874         MOVE L5051-POL-REG-1-AMT    TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-CNTRB-2-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-CNTRB-2-AMT-T (WS-SUB)

008455*        MOVE L5051-REG-RECPT-2-AMT  TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-REG-RECPT-1-AMT-T (WS-
020874*        COMPUTE L0290-INPUT-NUMBER = L5051-REG-RECPT-2-AMT * 100
020874         MOVE L5051-REG-RECPT-2-AMT  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-1-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-1-AMT-T (WS-SUB)

008455*        MOVE L5051-REG-RECPT-1-AMT  TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-REG-RECPT-2-AMT-T (WS-
020874*        COMPUTE L0290-INPUT-NUMBER = L5051-REG-RECPT-1-AMT * 100
020874         MOVE L5051-REG-RECPT-1-AMT  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-REG-RECPT-2-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-REG-RECPT-2-AMT-T (WS-SUB)

           END-IF.

           IF  RRL-REL-TYP-CD = 'O'
008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-DV-SPOUS-CNTRB-1-AMT-T
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-SPOUS-CNTRB-1-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-DV-SPOUS-CNTRB-1-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-DV-SPOUS-CNTRB-2-AMT-T
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-SPOUS-CNTRB-2-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-DV-SPOUS-CNTRB-2-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-DV-SPOUS-RECPT-1-AMT-T
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-SPOUS-RECPT-1-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-DV-SPOUS-RECPT-1-AMT-T (WS-SUB)

008455*        MOVE ZEROES                 TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-DV-SPOUS-RECPT-2-AMT-T
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-SPOUS-RECPT-2-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-DV-SPOUS-RECPT-2-AMT-T (WS-SUB)
           ELSE
008455*        MOVE L5051-POL-REGSP-2-AMT  TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-DV-SPOUS-CNTRB-1-AMT-T
020874*        COMPUTE L0290-INPUT-NUMBER = L5051-POL-REGSP-2-AMT * 100
020874         MOVE L5051-POL-REGSP-2-AMT  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-SPOUS-CNTRB-1-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-DV-SPOUS-CNTRB-1-AMT-T (WS-SUB)

008455*        MOVE L5051-POL-REGSP-1-AMT  TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-DV-SPOUS-CNTRB-2-AMT-T
020874*        COMPUTE L0290-INPUT-NUMBER = L5051-POL-REGSP-1-AMT * 100
020874         MOVE L5051-POL-REGSP-1-AMT  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-SPOUS-CNTRB-2-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-DV-SPOUS-CNTRB-2-AMT-T (WS-SUB)

008455*        MOVE L5051-REGSP-RECPT-2-AMT TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-DV-SPOUS-RECPT-1-AMT-T
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L5051-REGSP-RECPT-2-AMT * 100
020874         MOVE L5051-REGSP-RECPT-2-AMT TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-SPOUS-RECPT-1-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-DV-SPOUS-RECPT-1-AMT-T (WS-SUB)

008455*        MOVE L5051-REGSP-RECPT-1-AMT TO WS-PIC-NEG-7-2
008455*        MOVE WS-PIC-NEG-7-2         TO MIR-DV-SPOUS-RECPT-2-AMT-T
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L5051-REGSP-RECPT-1-AMT * 100
020874         MOVE L5051-REGSP-RECPT-1-AMT TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-SPOUS-RECPT-2-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
008455                            TO MIR-DV-SPOUS-RECPT-2-AMT-T (WS-SUB)
           END-IF.

           ADD 1                      TO WS-SUB.

       5700-CAN-TAXR-POLICY-INFO-X.
           EXIT.
      /
      *------------------------
       5800-US-TAX-POLICY-INFO.
      *------------------------

           SET WS-RL-FOUND            TO TRUE.
           MOVE RRL-REL-SYS-REF-ID    TO WS-POL-CVG-ID.
           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX-T (WS-SUB).

           MOVE L5051-POL-ISS-EFF-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-POL-ISS-EFF-DT-T (WS-SUB).
010418     MOVE L5051-POL-SBSDRY-CO-ID
010418                                TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE L5051-POL-CSTAT-CD    TO MIR-POL-CSTAT-CD-T (WS-SUB).
           MOVE L5051-POL-SPND-IND    TO MIR-POL-SPND-IND-T (WS-SUB).
           MOVE L5051-POL-PNSN-QUALF-CD
                                  TO MIR-POL-PNSN-QUALF-CD-T (WS-SUB).
008455*    MOVE L5051-GRS-DSTRB-TOT     TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2     TO MIR-DV-DSTRB-YTD-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5051-GRS-DSTRB-TOT * 100.
020874     MOVE L5051-GRS-DSTRB-TOT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-DSTRB-YTD-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-DSTRB-YTD-AMT-T (WS-SUB).

008455*    MOVE L5051-INT-TOT              TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2       TO MIR-DV-CLI-INT-YTD-AMT-T (
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5051-INT-TOT * 100.
020874     MOVE L5051-INT-TOT         TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-INT-YTD-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CLI-INT-YTD-AMT-T (WS-SUB).

008455*    MOVE L5051-TAXBL-TOT            TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2            TO MIR-DV-TAXBL-DSTRB-AMT-T (
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5051-TAXBL-TOT * 100.
020874     MOVE L5051-TAXBL-TOT       TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-TAXBL-DSTRB-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-TAXBL-DSTRB-AMT-T (WS-SUB).

008455*    MOVE L5051-FED-TAXWH-TOT        TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2             TO MIR-DV-US-TAXWH-AMT-T (WS-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5051-FED-TAXWH-TOT * 100.
020874     MOVE L5051-FED-TAXWH-TOT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-US-TAXWH-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-US-TAXWH-AMT-T (WS-SUB).

008455*    MOVE L5051-CURR-YR-TOT-AMT      TO WS-PIC-Z-13-2.
008455*    MOVE WS-PIC-Z-13-2              TO MIR-DV-POL-CRNT-YR-AMT-T (
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5051-CURR-YR-TOT-AMT * 100.
020874     MOVE L5051-CURR-YR-TOT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-POL-CRNT-YR-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-CRNT-YR-AMT-T (WS-SUB).

008455*    MOVE L5051-PREV-YR-TOT-AMT      TO WS-PIC-Z-13-2.
008455*    MOVE WS-PIC-Z-13-2              TO MIR-DV-POL-PREV-YR-AMT-T (
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5051-PREV-YR-TOT-AMT * 100.
020874     MOVE L5051-PREV-YR-TOT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-POL-PREV-YR-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-PREV-YR-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5051-LTAXWH-TOT-AMT * 100.
020874     MOVE L5051-LTAXWH-TOT-AMT  TO L0290-INPUT-V02.
013693     MOVE 2                     TO L0290-PRECISION.
013693     MOVE LENGTH OF
013693             MIR-DV-USTX-LTAXWH-YTD-AMT-T (WS-SUB)
013693                                TO L0290-MAX-OUT-LEN.
013693     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
013693     MOVE L0290-OUTPUT-DATA TO
013693                MIR-DV-USTX-LTAXWH-YTD-AMT-T (WS-SUB).

           ADD 1                      TO WS-SUB.

       5800-US-TAX-POLICY-INFO-X.
           EXIT.
      /
      *---------------------
       6000-PROCESS-SUMMARY.
      *---------------------

           EVALUATE TRUE

               WHEN WS-INSURED-DISPLAY
                   MOVE +7            TO WS-MAX-DISPLAY-LINES
                   PERFORM  6200-INSURED-SUMMARY
                       THRU 6200-INSURED-SUMMARY-X

               WHEN WS-OWNER-DISPLAY
018846*            MOVE +6            TO WS-MAX-DISPLAY-LINES
018846             MOVE +8            TO WS-MAX-DISPLAY-LINES
                   PERFORM  6300-OWNER-SUMMARY
                       THRU 6300-OWNER-SUMMARY-X

016395*        WHEN WS-PAC-PAYOR-DISPLAY
016395         WHEN WS-PAYOR-DISPLAY
                   MOVE +7            TO WS-MAX-DISPLAY-LINES
016395             IF  WS-BUS-FCN-CRCSUM
016395                 PERFORM  6900-CRC-PAYOR-SUMMARY
016395                     THRU 6900-CRC-PAYOR-SUMMARY-X
016395             ELSE
020467                 PERFORM  6400-PMT-PAYOR-SUMMARY
020467                     THRU 6400-PMT-PAYOR-SUMMARY-X
020467*                PERFORM  6400-PAC-PAYOR-SUMMARY
020467*                    THRU 6400-PAC-PAYOR-SUMMARY-X
016395             END-IF

               WHEN WS-LISTBILL-DISPLAY
                   MOVE +5            TO WS-MAX-DISPLAY-LINES
                   PERFORM  6500-LISTBILL-SUMMARY
                       THRU 6500-LISTBILL-SUMMARY-X

               WHEN WS-CAN-TAXN-DISPLAY
                   MOVE +4            TO WS-MAX-DISPLAY-LINES
                   PERFORM  6600-CAN-TAXN-SUMMARY
                       THRU 6600-CAN-TAXN-SUMMARY-X

               WHEN WS-CAN-TAXR-DISPLAY
                   MOVE +11           TO WS-MAX-DISPLAY-LINES
                   PERFORM  6700-CAN-TAXR-SUMMARY
                       THRU 6700-CAN-TAXR-SUMMARY-X

               WHEN WS-US-TAX-DISPLAY
557691*            MOVE +4               TO WS-MAX-DISPLAY-LINES
013693*            MOVE +6            TO WS-MAX-DISPLAY-LINES
013693             MOVE +7            TO WS-MAX-DISPLAY-LINES
                   PERFORM  6800-US-TAX-SUMMARY
                       THRU 6800-US-TAX-SUMMARY-X

           END-EVALUATE.

       6000-PROCESS-SUMMARY-X.
           EXIT.
      /
      *---------------------
       6200-INSURED-SUMMARY.
      *---------------------

           PERFORM  5053-1000-BUILD-PARM-INFO
               THRU 5053-1000-BUILD-PARM-INFO-X.
           SET L5053-INFO-TYP-INSRD   TO TRUE.
           MOVE MIR-CLI-ID            TO L5053-CLI-ID.

           PERFORM  5053-1000-POL-TOT-INFO
               THRU 5053-1000-POL-TOT-INFO-X.

           IF  L5053-REL-NOT-FOUND
      *        MSG: NO INSURED RELATIONSHIPS FOUND FOR  THIS CLIENT
               MOVE 'CS50500015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6200-INSURED-SUMMARY-X
           END-IF.

           PERFORM  6250-LOAD-INSURED-SUMMARY
               THRU 6250-LOAD-INSURED-SUMMARY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-DISPLAY-LINES.

       6200-INSURED-SUMMARY-X.
           EXIT.

      *--------------------------
       6250-LOAD-INSURED-SUMMARY.
      *--------------------------

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-INFORCE-AMT (WS-SUB) * 100.
020874     MOVE L5053-INFORCE-AMT (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-INSRD-INFC-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CLI-INSRD-INFC-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-PENDING-AMT (WS-SUB) * 100.
020874     MOVE L5053-PENDING-AMT (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-INSRD-PEND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CLI-INSRD-PEND-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-SUSPENDED-AMT (WS-SUB) * 100.
020874     MOVE L5053-SUSPENDED-AMT (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-INSRD-SPND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CLI-INSRD-SPND-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-TOTAL-AMT     (WS-SUB) * 100.
020874     MOVE L5053-TOTAL-AMT     (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-INSRD-TOT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CLI-INSRD-TOT-AMT-T (WS-SUB).

       6250-LOAD-INSURED-SUMMARY-X.
           EXIT.
      /
      *-------------------
       6300-OWNER-SUMMARY.
      *-------------------

           PERFORM  5053-1000-BUILD-PARM-INFO
               THRU 5053-1000-BUILD-PARM-INFO-X.
           SET L5053-INFO-TYP-OWNER   TO TRUE.
           MOVE MIR-CLI-ID            TO L5053-CLI-ID.

           PERFORM  5053-1000-POL-TOT-INFO
               THRU 5053-1000-POL-TOT-INFO-X.

           IF  L5053-REL-NOT-FOUND
      *        MSG: NO OWNER RELATIONSHIPS FOUND FOR  THIS CLIENT
               MOVE 'CS50500016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6300-OWNER-SUMMARY-X
           END-IF.

           PERFORM  6350-LOAD-OWNER-SUMMARY
               THRU 6350-LOAD-OWNER-SUMMARY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-DISPLAY-LINES.

020874*    COMPUTE L0290-INPUT-NUMBER = RCLI-CLI-SUSP-AMT * 100.
020874     MOVE RCLI-CLI-SUSP-AMT     TO L0290-INPUT-V02.
013578     MOVE 2                     TO L0290-PRECISION.
013578     MOVE LENGTH OF MIR-CLI-SUSP-AMT
013578                                TO L0290-MAX-OUT-LEN.
013578     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
013578     MOVE L0290-OUTPUT-DATA     TO MIR-CLI-SUSP-AMT.

       6300-OWNER-SUMMARY-X.
           EXIT.

      *------------------------
       6350-LOAD-OWNER-SUMMARY.
      *------------------------

008455*    MOVE L5053-INFORCE-AMT (WS-SUB)   TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-CLI-OWN-INFC-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-INFORCE-AMT (WS-SUB) * 100.
020874     MOVE L5053-INFORCE-AMT (WS-SUB)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-OWN-INFC-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CLI-OWN-INFC-AMT-T (WS-SUB).

008455*    MOVE L5053-PENDING-AMT (WS-SUB)   TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-CLI-OWN-PEND-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-PENDING-AMT (WS-SUB) * 100.
020874     MOVE L5053-PENDING-AMT (WS-SUB)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-OWN-PEND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CLI-OWN-PEND-AMT-T (WS-SUB).

008455*    MOVE L5053-SUSPENDED-AMT (WS-SUB) TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-CLI-OWN-SPND-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-SUSPENDED-AMT (WS-SUB) * 100.
020874     MOVE L5053-SUSPENDED-AMT (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-OWN-SPND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CLI-OWN-SPND-AMT-T (WS-SUB).

008455*    MOVE L5053-TOTAL-AMT     (WS-SUB) TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-CLI-OWN-TOT-AMT-T
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-TOTAL-AMT     (WS-SUB) * 100.
020874     MOVE L5053-TOTAL-AMT     (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-OWN-TOT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CLI-OWN-TOT-AMT-T (WS-SUB).

       6350-LOAD-OWNER-SUMMARY-X.
           EXIT.
      /
      *-----------------------
020467*6400-PAC-PAYOR-SUMMARY.
020467 6400-PMT-PAYOR-SUMMARY.
      *-----------------------

      *
      *  CHECK BANK RECORDS
      *
020467*    PERFORM  4400-PAC-PAYOR-CLIENT-INFO
020467*        THRU 4400-PAC-PAYOR-CLIENT-INFO-X.
020467     PERFORM  4400-PMT-PAYOR-CLIENT-INFO
020467         THRU 4400-PMT-PAYOR-CLIENT-INFO-X.

           PERFORM  5053-1000-BUILD-PARM-INFO
               THRU 5053-1000-BUILD-PARM-INFO-X.

016395*    SET L5053-INFO-TYP-PAC-PAYOR
016395*                               TO TRUE.
016395     SET L5053-INFO-TYP-PAYOR   TO TRUE.
020467     MOVE MIR-POL-BILL-TYP-CD   TO L5053-POL-BILL-TYP-CD.
020467     SET L5053-INQ-TYP-PMT      TO TRUE.
020467*    SET L5053-INQ-TYP-PAC      TO TRUE.
           MOVE MIR-CLI-ID            TO L5053-CLI-ID.
016395*    MOVE MIR-CLI-BNK-ACCT-NUM  TO L5053-BNK-ACCT-NUM.
016395     MOVE MIR-CLI-BNK-ACCT-NUM  TO L5053-ACCT-NUM.
020467     IF MIR-POL-BILL-TYP-CD = SPACES
020467        MOVE '4' TO L5053-POL-BILL-TYP-CD
020467        SET WS-AUTOPAY-TOTALS-REQD TO TRUE
020467     ELSE
020467        SET WS-AUTOPAY-TOTALS-NOT-REQD TO TRUE
020467     END-IF.


           PERFORM  5053-1000-POL-TOT-INFO
               THRU 5053-1000-POL-TOT-INFO-X.

           IF  L5053-REL-NOT-FOUND

               IF  MIR-CLI-BNK-ACCT-NUM = SPACES
      *            MSG: NO PAC PAYOR  RELATIONSHIPS FOUND FOR CLIENT
                   MOVE 'CS50500003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *            MSG: NO POLICIES FOUND FOR  CLIENT AND BANK ACCT #
                   MOVE 'CS50500004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

           ELSE
016395*        PERFORM  6450-LOAD-PAC-PAYOR-SUMMARY
016395*            THRU 6450-LOAD-PAC-PAYOR-SUMMARY-X
020467         IF WS-AUTOPAY-TOTALS-REQD
020467            MOVE L5053-TPOTAL-INFO-AREA TO WS-PAC-TOTALS-AREA
020467            INITIALIZE L5053-TPOTAL-INFO-AREA
020467            MOVE 'D' TO L5053-POL-BILL-TYP-CD
020467            PERFORM  5053-1000-POL-TOT-INFO
020467                THRU 5053-1000-POL-TOT-INFO-X
020467         END-IF

016395         PERFORM  6450-LOAD-PAYOR-SUMMARY
016395             THRU 6450-LOAD-PAYOR-SUMMARY-X
           END-IF.

020467*6400-PAC-PAYOR-SUMMARY-X.
020467 6400-PMT-PAYOR-SUMMARY-X.
           EXIT.

      *----------------------------
016395*6450-LOAD-PAC-PAYOR-SUMMARY.
016395 6450-LOAD-PAYOR-SUMMARY.
      *----------------------------

           MOVE 1                     TO WS-SUB.
           MOVE 1                     TO WS-SUB2.

013578     PERFORM  6451-ARRAY-BROWSE
013578         THRU 6451-ARRAY-BROWSE-X
013578         VARYING WS-SUB FROM WS-SUB BY +1
013578         UNTIL WS-SUB  > 31
013578         OR    WS-SUB2 > WS-MAX-DISPLAY-LINES.
013578
           IF  WS-SUB2 > WS-MAX-DISPLAY-LINES
               PERFORM  6453-ARRAY-CHECKING
                   THRU 6453-ARRAY-CHECKING-X
           ELSE
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

016395*6450-LOAD-PAC-PAYOR-SUMMARY-X.
016395 6450-LOAD-PAYOR-SUMMARY-X.
           EXIT.
      /
      *------------------
       6451-ARRAY-BROWSE.
      *------------------

           IF  L5053-INFORCE-AMT (WS-SUB)     > ZERO
           OR  L5053-PENDING-AMT (WS-SUB)     > ZERO
           OR  L5053-SUSPENDED-AMT (WS-SUB)   > ZERO
           OR  L5053-TOTAL-AMT     (WS-SUB)   > ZERO
020874*        MOVE WS-SUB            TO WS-PIC-99
016395*        MOVE WS-PIC-99         TO MIR-POL-PAC-DRW-DY-T (WS-SUB2)
020874*        MOVE WS-PIC-99         TO MIR-POL-PMT-DRW-DY-T (WS-SUB2)
020874         MOVE WS-SUB                TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-PMT-DRW-DY-T (WS-SUB2)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-POL-PMT-DRW-DY-T (WS-SUB2)
008455*        MOVE L5053-INFORCE-AMT (WS-SUB) TO WS-PIC-NEG-9-2
008455*        MOVE WS-PIC-NEG-9-2    TO MIR-DV-PAC-PREM-AMT-T (WS-SUB2)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L5053-INFORCE-AMT (WS-SUB) * 100
020874         MOVE L5053-INFORCE-AMT (WS-SUB) TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455*        MOVE LENGTH OF MIR-DV-PAC-PREM-AMT-T (WS-SUB)
016395         MOVE LENGTH OF MIR-DV-PMT-PREM-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016395*        MOVE L0290-OUTPUT-DATA TO MIR-DV-PAC-PREM-AMT-T (WS-SUB2)
016395         MOVE L0290-OUTPUT-DATA TO MIR-DV-PMT-PREM-AMT-T (WS-SUB2)

008455*        MOVE L5053-PENDING-AMT (WS-SUB)  TO WS-PIC-NEG-9-2
008455*        MOVE WS-PIC-NEG-9-2    TO MIR-DV-PAC-PEND-AMT-T (WS-SUB2)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L5053-PENDING-AMT (WS-SUB)  * 100
020874         MOVE L5053-PENDING-AMT (WS-SUB)  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455*        MOVE LENGTH OF MIR-DV-PAC-PEND-AMT-T (WS-SUB)
016395         MOVE LENGTH OF MIR-DV-PMT-PEND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455*        MOVE L0290-OUTPUT-DATA TO MIR-DV-PAC-PEND-AMT-T (WS-SUB2)
016395         MOVE L0290-OUTPUT-DATA TO MIR-DV-PMT-PEND-AMT-T (WS-SUB2)

008455*        MOVE L5053-SUSPENDED-AMT (WS-SUB) TO WS-PIC-NEG-9-2
008455*        MOVE WS-PIC-NEG-9-2    TO MIR-DV-PAC-SPND-AMT-T (WS-SUB2)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L5053-SUSPENDED-AMT (WS-SUB)   * 100
020874         MOVE L5053-SUSPENDED-AMT (WS-SUB) TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455*        MOVE LENGTH OF MIR-DV-PAC-SPND-AMT-T (WS-SUB)
016395         MOVE LENGTH OF MIR-DV-PMT-SPND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455*        MOVE L0290-OUTPUT-DATA TO MIR-DV-PAC-SPND-AMT-T (WS-SUB2)
016395         MOVE L0290-OUTPUT-DATA TO MIR-DV-PMT-SPND-AMT-T (WS-SUB2)


008455*        MOVE L5053-TOTAL-AMT    (WS-SUB) TO WS-PIC-NEG-9-2
008455*        MOVE WS-PIC-NEG-9-2              TO MIR-DV-TOT-PAC-AMT-T
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             L5053-TOTAL-AMT    (WS-SUB) * 100
020874         MOVE L5053-TOTAL-AMT    (WS-SUB) TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
016395*        MOVE LENGTH OF MIR-DV-TOT-PAC-AMT-T (WS-SUB)
016395         MOVE LENGTH OF MIR-DV-TOT-PMT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016395*        MOVE L0290-OUTPUT-DATA TO MIR-DV-TOT-PAC-AMT-T (WS-SUB2)
016395         MOVE L0290-OUTPUT-DATA TO MIR-DV-TOT-PMT-AMT-T (WS-SUB2)
020467         MOVE L5053-BILL-TYP-CD (WS-SUB)
020467                                TO MIR-POL-BILL-TYP-CD-T (WS-SUB2)

               ADD 1                  TO WS-SUB2
           END-IF.
020467
020467     IF WS-AUTOPAY-TOTALS-REQD
020467        IF  WS-PAC-INFORCE-AMT (WS-SUB)     > ZERO
020467        OR  WS-PAC-PENDING-AMT (WS-SUB)     > ZERO
020467        OR  WS-PAC-SUSPENDED-AMT (WS-SUB)   > ZERO
020467        OR  WS-PAC-TOTAL-AMT     (WS-SUB)   > ZERO
020467            MOVE WS-SUB       TO L0290-INPUT-V00
020467            MOVE 0            TO L0290-PRECISION
020467            MOVE LENGTH OF MIR-POL-PMT-DRW-DY-T (WS-SUB2)
020467                              TO L0290-MAX-OUT-LEN
020467            PERFORM 0290-2000-FORMAT-FOR-MIR
020467               THRU 0290-2000-FORMAT-FOR-MIR-X
020467            MOVE L0290-OUTPUT-DATA
020467                              TO MIR-POL-PMT-DRW-DY-T (WS-SUB2)
020467
020467            MOVE WS-PAC-INFORCE-AMT (WS-SUB) TO L0290-INPUT-V02
020467            MOVE 2            TO L0290-PRECISION
020467            MOVE LENGTH OF MIR-DV-PMT-PREM-AMT-T (WS-SUB)
020467                              TO L0290-MAX-OUT-LEN
020467            SET L0290-SIGN-DISPLAY TO TRUE
020467            PERFORM 0290-2000-FORMAT-FOR-MIR
020467               THRU 0290-2000-FORMAT-FOR-MIR-X
020467            MOVE L0290-OUTPUT-DATA
020467                              TO MIR-DV-PMT-PREM-AMT-T (WS-SUB2)
020467
020467            MOVE WS-PAC-PENDING-AMT (WS-SUB)  TO L0290-INPUT-V02
020467            MOVE 2            TO L0290-PRECISION
020467            MOVE LENGTH OF MIR-DV-PMT-PEND-AMT-T (WS-SUB)
020467                              TO L0290-MAX-OUT-LEN
020467            SET L0290-SIGN-DISPLAY TO TRUE
020467            PERFORM 0290-2000-FORMAT-FOR-MIR
020467               THRU 0290-2000-FORMAT-FOR-MIR-X
020467            MOVE L0290-OUTPUT-DATA
020467                              TO MIR-DV-PMT-PEND-AMT-T (WS-SUB2)
020467
020467            MOVE WS-PAC-SUSPENDED-AMT (WS-SUB) TO L0290-INPUT-V02
020467            MOVE 2            TO L0290-PRECISION
020467            MOVE LENGTH OF MIR-DV-PMT-SPND-AMT-T (WS-SUB)
020467                              TO L0290-MAX-OUT-LEN
020467            SET L0290-SIGN-DISPLAY TO TRUE
020467            PERFORM 0290-2000-FORMAT-FOR-MIR
020467               THRU 0290-2000-FORMAT-FOR-MIR-X
020467            MOVE L0290-OUTPUT-DATA
020467                              TO MIR-DV-PMT-SPND-AMT-T (WS-SUB2)
020467
020467            MOVE WS-PAC-TOTAL-AMT    (WS-SUB) TO L0290-INPUT-V02
020467            MOVE 2            TO L0290-PRECISION
020467            MOVE LENGTH OF MIR-DV-TOT-PMT-AMT-T (WS-SUB)
020467                              TO L0290-MAX-OUT-LEN
020467            SET L0290-SIGN-DISPLAY TO TRUE
020467            PERFORM 0290-2000-FORMAT-FOR-MIR
020467               THRU 0290-2000-FORMAT-FOR-MIR-X
020467            MOVE L0290-OUTPUT-DATA
020467                              TO MIR-DV-TOT-PMT-AMT-T (WS-SUB2)
020467
020467            MOVE WS-PAC-BILL-TYP-CD (WS-SUB)
020467                              TO MIR-POL-BILL-TYP-CD-T (WS-SUB2)
020467
020467            ADD 1             TO WS-SUB2
020467        END-IF
020467     END-IF.

       6451-ARRAY-BROWSE-X.
           EXIT.

      *--------------------
       6453-ARRAY-CHECKING.
      *--------------------

           MOVE WS-SUB                TO WS-SUB2.

020467     IF WS-AUTOPAY-TOTALS-REQD
020467        PERFORM
020467            UNTIL WS-SUB2 > 31
020467            OR  L5053-INFORCE-AMT (WS-SUB2)     > ZERO
020467            OR  L5053-PENDING-AMT (WS-SUB2)     > ZERO
020467            OR  L5053-SUSPENDED-AMT (WS-SUB2)   > ZERO
020467            OR  L5053-TOTAL-AMT     (WS-SUB2) > ZERO
020467            OR  WS-PAC-INFORCE-AMT (WS-SUB2)     > ZERO
020467            OR  WS-PAC-PENDING-AMT (WS-SUB2)     > ZERO
020467            OR  WS-PAC-SUSPENDED-AMT (WS-SUB2)   > ZERO
020467            OR  WS-PAC-TOTAL-AMT     (WS-SUB2) > ZERO
020467                ADD +1         TO WS-SUB2
020467        END-PERFORM
020467     ELSE
020467        PERFORM
020467            UNTIL WS-SUB2 > 31
020467            OR  L5053-INFORCE-AMT (WS-SUB2)     > ZERO
020467            OR  L5053-PENDING-AMT (WS-SUB2)     > ZERO
020467            OR  L5053-SUSPENDED-AMT (WS-SUB2)   > ZERO
020467            OR  L5053-TOTAL-AMT     (WS-SUB2) > ZERO
020467                ADD +1         TO WS-SUB2
020467        END-PERFORM
020467     END-IF.
020467
020467*    PERFORM
020467*        UNTIL WS-SUB2 > 31
020467*        OR  L5053-INFORCE-AMT (WS-SUB2)     > ZERO
020467*        OR  L5053-PENDING-AMT (WS-SUB2)     > ZERO
020467*        OR  L5053-SUSPENDED-AMT (WS-SUB2)   > ZERO
020467*        OR  L5053-TOTAL-AMT     (WS-SUB2) > ZERO
020467*            ADD +1         TO WS-SUB2
020467*    END-PERFORM.

           IF  WS-SUB2 > 0
           AND WS-SUB2 < 32
               SET WGLOB-MORE-DATA-EXISTS
                                      TO TRUE
020467*        MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
020467* MORE RECORDS EXIST - UNABLE TO DISPLAY - CONTACT SYSTEMS
020467         MOVE 'XS00000367'      TO WGLOB-MSG-REF-INFO

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6453-ARRAY-CHECKING-X.
           EXIT.
      /
      *----------------------
       6500-LISTBILL-SUMMARY.
      *----------------------

           PERFORM  5053-1000-BUILD-PARM-INFO
               THRU 5053-1000-BUILD-PARM-INFO-X.
           SET L5053-INFO-TYP-LISTBILL
                                      TO TRUE.
           MOVE MIR-CLI-ID            TO L5053-CLI-ID.

           PERFORM  5053-1000-POL-TOT-INFO
               THRU 5053-1000-POL-TOT-INFO-X.

           IF  L5053-REL-NOT-FOUND
      *        MSG: NO LISTBILL RELATIONSHIPS FOUND FOR  THIS CLIENT
               MOVE 'CS50500002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  6550-LOAD-LISTBILL-SUMMARY
                   THRU 6550-LOAD-LISTBILL-SUMMARY-X
                   VARYING WS-SUB FROM 1 BY 1
                   UNTIL WS-SUB > WS-MAX-DISPLAY-LINES
           END-IF.

       6500-LISTBILL-SUMMARY-X.
           EXIT.
      /
      *---------------------------
       6550-LOAD-LISTBILL-SUMMARY.
      *---------------------------

008455*    MOVE L5053-INFORCE-AMT (WS-SUB)   TO WS-PIC-Z-9-2.
008455*    MOVE WS-PIC-Z-9-2                 TO MIR-DV-CLI-LBILL-INFC-AM
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-INFORCE-AMT (WS-SUB)   * 100.
020874     MOVE L5053-INFORCE-AMT (WS-SUB)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-LBILL-INFC-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CLI-LBILL-INFC-AMT-T (WS-SUB).

008455*    MOVE L5053-PENDING-AMT (WS-SUB)   TO WS-PIC-Z-9-2.
008455*    MOVE WS-PIC-Z-9-2                 TO MIR-DV-CLI-LBILL-PEND-AM
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-PENDING-AMT (WS-SUB)   * 100.
020874     MOVE L5053-PENDING-AMT (WS-SUB)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-LBILL-PEND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CLI-LBILL-PEND-AMT-T (WS-SUB).

008455*    MOVE L5053-SUSPENDED-AMT (WS-SUB) TO WS-PIC-Z-9-2.
008455*    MOVE WS-PIC-Z-9-2                 TO MIR-DV-CLI-LBILL-SPND-AM
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-SUSPENDED-AMT (WS-SUB) * 100.
020874     MOVE L5053-SUSPENDED-AMT (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-LBILL-SPND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CLI-LBILL-SPND-AMT-T (WS-SUB).

008455*    MOVE L5053-TOTAL-AMT     (WS-SUB) TO WS-PIC-Z-9-2.
008455*    MOVE WS-PIC-Z-9-2                 TO MIR-DV-CLI-LBILL-TOT-AMT
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-TOTAL-AMT     (WS-SUB) * 100.
020874     MOVE L5053-TOTAL-AMT     (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-LBILL-TOT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CLI-LBILL-TOT-AMT-T (WS-SUB).

       6550-LOAD-LISTBILL-SUMMARY-X.
           EXIT.

      /
      *----------------------
       6600-CAN-TAXN-SUMMARY.
      *----------------------

           PERFORM  5053-1000-BUILD-PARM-INFO
               THRU 5053-1000-BUILD-PARM-INFO-X.
           SET L5053-INFO-TYP-CDN-NON-REG
                                      TO TRUE.
           MOVE MIR-CLI-ID            TO L5053-CLI-ID.

           PERFORM  5053-1000-POL-TOT-INFO
               THRU 5053-1000-POL-TOT-INFO-X.

           IF  L5053-REL-CDN-NREG-FOUND
               PERFORM  6670-LOAD-CAN-TAXN-SUMMARY
                   THRU 6670-LOAD-CAN-TAXN-SUMMARY-X
013578             VARYING WS-SUB FROM 1 BY 1
                   UNTIL   WS-SUB > WS-MAX-DISPLAY-LINES
               GO TO 6600-CAN-TAXN-SUMMARY-X
           END-IF.

           IF  L5053-REL-NOT-FOUND
      *        MSG: NO OWNER RELATIONSHIPS FOUND FOR  THIS CLIENT
               MOVE 'CS50500016'      TO WGLOB-MSG-REF-INFO
           ELSE

               IF  L5053-REL-CDN-NOT-FOUND
      *            MSG: NO CANADIAN POLICIES FOUND FOR  THIS CLIENT
                   MOVE 'CS50500018'  TO WGLOB-MSG-REF-INFO
               ELSE
      *            MSG: NO CANADIAN NON-REG POLICIES FOUND FOR CLIENT
                   MOVE 'CS50500020'  TO WGLOB-MSG-REF-INFO
               END-IF

           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6600-CAN-TAXN-SUMMARY-X.
           EXIT.

      *---------------------------
       6650-LOAD-CAN-TAXC-SUMMARY.
      *---------------------------

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-INFORCE-AMT (WS-SUB)   * 100.
020874     MOVE L5053-INFORCE-AMT (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-INFC-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CDN-TAX-INFC-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-PENDING-AMT (WS-SUB)   * 100.
020874     MOVE L5053-PENDING-AMT (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-PEND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CDN-TAX-PEND-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-SUSPENDED-AMT (WS-SUB) * 100.
020874     MOVE L5053-SUSPENDED-AMT (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-SPND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CDN-TAX-SPND-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-TOTAL-AMT     (WS-SUB) * 100.
020874     MOVE L5053-TOTAL-AMT     (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-TOT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CDN-TAX-TOT-AMT-T (WS-SUB).

       6650-LOAD-CAN-TAXC-SUMMARY-X.
           EXIT.
      /
      *---------------------------
       6670-LOAD-CAN-TAXN-SUMMARY.
      *---------------------------

013578     COMPUTE WS-SUB2 = WS-SUB.
013578
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-INFORCE-AMT (WS-SUB)   * 100.
020874     MOVE L5053-INFORCE-AMT (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-INFC-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CDN-TAX-INFC-AMT-T (WS-SUB2).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-PENDING-AMT (WS-SUB)   * 100.
020874     MOVE L5053-PENDING-AMT (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-PEND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CDN-TAX-PEND-AMT-T (WS-SUB2).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-SUSPENDED-AMT (WS-SUB) * 100.
020874     MOVE L5053-SUSPENDED-AMT (WS-SUB)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-SPND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CDN-TAX-SPND-AMT-T (WS-SUB2).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-TOTAL-AMT     (WS-SUB) * 100.
020874     MOVE L5053-TOTAL-AMT     (WS-SUB) TO L0290-INPUT-V02
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-TOT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CDN-TAX-TOT-AMT-T (WS-SUB2).

       6670-LOAD-CAN-TAXN-SUMMARY-X.
           EXIT.
      /
      *----------------------
       6700-CAN-TAXR-SUMMARY.
      *----------------------

           PERFORM  5053-1000-BUILD-PARM-INFO
               THRU 5053-1000-BUILD-PARM-INFO-X.
           SET L5053-INFO-TYP-CDN-REG TO TRUE.
           MOVE MIR-CLI-ID            TO L5053-CLI-ID.

           PERFORM  5053-1000-POL-TOT-INFO
               THRU 5053-1000-POL-TOT-INFO-X.

           IF  L5053-REL-CDN-REG-FOUND
               PERFORM  6750-LOAD-CAN-TAXR-SUMMARY
                   THRU 6750-LOAD-CAN-TAXR-SUMMARY-X
013578             VARYING WS-SUB FROM 1 BY 1
                   UNTIL   WS-SUB > WS-MAX-DISPLAY-LINES
               GO TO 6700-CAN-TAXR-SUMMARY-X
           END-IF.

           IF  L5053-REL-NOT-FOUND
      *        MSG: NO OWNER OR SPOUSAL RELATIONSHIPS FOUND
               MOVE 'CS50500024'      TO WGLOB-MSG-REF-INFO
           ELSE

               IF  L5053-REL-CDN-NOT-FOUND
      *            MSG: NO CANADIAN POLICIES FOUND FOR  THIS CLIENT
                   MOVE 'CS50500018'  TO WGLOB-MSG-REF-INFO
               ELSE
      *            MSG: NO CANADIAN REGISTERED POLICIES FOUND
                   MOVE 'CS50500021'  TO WGLOB-MSG-REF-INFO
               END-IF

           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6700-CAN-TAXR-SUMMARY-X.
           EXIT.


      *---------------------------
       6720-LOAD-CAN-TAXE-SUMMARY.
      *---------------------------

008455*    MOVE L5053-INFORCE-AMT (1)        TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-CDN-TAX-INFC-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-INFORCE-AMT (1)   * 100.
020874     MOVE L5053-INFORCE-AMT (1) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-INFC-AMT-T (1)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CDN-TAX-INFC-AMT-T (1).

008455*    MOVE L5053-PENDING-AMT (1)        TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-CDN-TAX-PEND-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-PENDING-AMT (1)   *  100.
020874     MOVE L5053-PENDING-AMT (1) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-PEND-AMT-T (1)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CDN-TAX-PEND-AMT-T (1).

008455*    MOVE L5053-SUSPENDED-AMT (1)      TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-CDN-TAX-SPND-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-SUSPENDED-AMT (1)  *  100.
020874     MOVE L5053-SUSPENDED-AMT (1)  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-SPND-AMT-T (1)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CDN-TAX-SPND-AMT-T (1).

008455*    MOVE L5053-TOTAL-AMT     (1)      TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-CDN-TAX-TOT-AMT-T
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-TOTAL-AMT (1) * 100.
020874     MOVE L5053-TOTAL-AMT (1)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-TOT-AMT-T (1)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CDN-TAX-TOT-AMT-T (1).

       6720-LOAD-CAN-TAXE-SUMMARY-X.
           EXIT.


      *---------------------------
       6750-LOAD-CAN-TAXR-SUMMARY.
      *---------------------------

013578     COMPUTE WS-SUB2 = WS-SUB.

008455*    MOVE L5053-INFORCE-AMT (WS-SUB)   TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2               TO MIR-DV-CDN-TAX-INFC-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-INFORCE-AMT (WS-SUB)   * 100.
020874     MOVE L5053-INFORCE-AMT (WS-SUB)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-INFC-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CDN-TAX-INFC-AMT-T (WS-SUB2).

008455*    MOVE L5053-PENDING-AMT (WS-SUB)   TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2               TO MIR-DV-CDN-TAX-PEND-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-PENDING-AMT (WS-SUB)   * 100.
020874     MOVE L5053-PENDING-AMT (WS-SUB)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-PEND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CDN-TAX-PEND-AMT-T (WS-SUB2).

008455*    MOVE L5053-SUSPENDED-AMT (WS-SUB) TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2               TO MIR-DV-CDN-TAX-SPND-AMT-
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-SUSPENDED-AMT (WS-SUB) * 100.
020874     MOVE L5053-SUSPENDED-AMT (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-SPND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
008455                        TO MIR-DV-CDN-TAX-SPND-AMT-T (WS-SUB2).

008455*    MOVE L5053-TOTAL-AMT     (WS-SUB) TO WS-PIC-NEG-9-2.
008455*    MOVE WS-PIC-NEG-9-2               TO MIR-DV-CDN-TAX-TOT-AMT-T
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-TOTAL-AMT     (WS-SUB) * 100.
020874     MOVE L5053-TOTAL-AMT     (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CDN-TAX-TOT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-CDN-TAX-TOT-AMT-T (WS-SUB2).

       6750-LOAD-CAN-TAXR-SUMMARY-X.
           EXIT.

      /
      *--------------------
       6800-US-TAX-SUMMARY.
      *--------------------

           PERFORM  5053-1000-BUILD-PARM-INFO
               THRU 5053-1000-BUILD-PARM-INFO-X.

           SET L5053-INFO-TYP-US-TAX  TO TRUE.
           MOVE MIR-CLI-ID            TO L5053-CLI-ID.
557695*    MOVE RCLI-CLI-SIN-ID               TO L5053-CLI-SIN-ID.
557695     MOVE RCLI-CLI-TAX-ID       TO L5053-CLI-SIN-ID.

           PERFORM  5053-1000-POL-TOT-INFO
               THRU 5053-1000-POL-TOT-INFO-X.

           IF  L5053-REL-US-FOUND
               PERFORM  6850-LOAD-US-TAX-SUMMARY
                   THRU 6850-LOAD-US-TAX-SUMMARY-X
                   VARYING WS-SUB FROM 1 BY 1
                     UNTIL WS-SUB > WS-MAX-DISPLAY-LINES
           ELSE

               IF  L5053-REL-NOT-FOUND
      *            MSG: NO OWNER RELATIONSHIPS FOUND FOR  THIS CLIENT
                   MOVE 'CS50500016'  TO WGLOB-MSG-REF-INFO
               ELSE
      *            MSG: NO US POLICIES FOUND FOR  THIS CLIENT
                   MOVE 'CS50500019'  TO WGLOB-MSG-REF-INFO
               END-IF

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6800-US-TAX-SUMMARY-X.
           EXIT.
      /
      *-------------------------
       6850-LOAD-US-TAX-SUMMARY.
      *-------------------------

008455*    MOVE L5053-INFORCE-AMT (WS-SUB)   TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-US-TAX-INFC-AMT-T
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-INFORCE-AMT (WS-SUB)   *  100.
020874     MOVE L5053-INFORCE-AMT (WS-SUB)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-US-TAX-INFC-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-US-TAX-INFC-AMT-T (WS-SUB).

008455*    MOVE L5053-PENDING-AMT (WS-SUB)   TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-US-TAX-PEND-AMT-T
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-PENDING-AMT (WS-SUB)   *  100.
020874     MOVE L5053-PENDING-AMT (WS-SUB)   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-US-TAX-PEND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-US-TAX-PEND-AMT-T (WS-SUB).

008455*    MOVE L5053-SUSPENDED-AMT (WS-SUB) TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-US-TAX-SPND-AMT-T
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-SUSPENDED-AMT (WS-SUB) * 100.
020874     MOVE L5053-SUSPENDED-AMT (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-US-TAX-SPND-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-US-TAX-SPND-AMT-T (WS-SUB).

008455*    MOVE L5053-TOTAL-AMT     (WS-SUB) TO WS-PIC-NEG-11-2.
008455*    MOVE WS-PIC-NEG-11-2              TO MIR-DV-US-TAX-TOT-AMT-T
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         L5053-TOTAL-AMT     (WS-SUB) * 100.
020874     MOVE L5053-TOTAL-AMT     (WS-SUB) TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-US-TAX-TOT-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DV-US-TAX-TOT-AMT-T (WS-SUB).

       6850-LOAD-US-TAX-SUMMARY-X.
           EXIT.
      /
      *-----------------------
016395 6900-CRC-PAYOR-SUMMARY.
016395*-----------------------
016395
016395*
016395*  CHECK CREDIT CARD RECORD
016395*
016395     PERFORM  4600-CRC-PAYOR-CLIENT-INFO
016395         THRU 4600-CRC-PAYOR-CLIENT-INFO-X.
016395
016395     PERFORM  5053-1000-BUILD-PARM-INFO
016395         THRU 5053-1000-BUILD-PARM-INFO-X.
016395
016395     SET L5053-INFO-TYP-PAYOR   TO TRUE.
016395     SET L5053-INQ-TYP-CRC      TO TRUE.
016395     MOVE MIR-CLI-ID            TO L5053-CLI-ID.
016395     MOVE MIR-CLI-CRC-NUM       TO L5053-ACCT-NUM.
016395
016395     PERFORM  5053-1000-POL-TOT-INFO
016395         THRU 5053-1000-POL-TOT-INFO-X.
016395
016395     IF  L5053-REL-NOT-FOUND
016395
016395       IF  MIR-CLI-CRC-NUM = SPACES
016395*      MSG: NO CRC PAYOR  RELATIONSHIPS FOUND FOR CLIENT
016395           MOVE 'CS50500028'  TO WGLOB-MSG-REF-INFO
016395           PERFORM  0260-1000-GENERATE-MESSAGE
016395               THRU 0260-1000-GENERATE-MESSAGE-X
016395       ELSE
016395*      MSG: NO POLICIES FOUND FOR  CLIENT AND CREDIT CARD ACCT #
016395           MOVE 'CS50500029'  TO WGLOB-MSG-REF-INFO
016395           PERFORM  0260-1000-GENERATE-MESSAGE
016395               THRU 0260-1000-GENERATE-MESSAGE-X
016395       END-IF
016395
016395     ELSE
016395        PERFORM  6450-LOAD-PAYOR-SUMMARY
016395            THRU 6450-LOAD-PAYOR-SUMMARY-X
016395     END-IF.
016395
016395 6900-CRC-PAYOR-SUMMARY-X.
016395     EXIT.

      *--------------------------
       7000-RETRIEVE-POLICY-INFO.
      *--------------------------

           PERFORM  5051-1000-BUILD-PARM-INFO
               THRU 5051-1000-BUILD-PARM-INFO-X.

           EVALUATE TRUE

               WHEN WS-GENERAL-DISPLAY
                   PERFORM  5051-1000-GENERAL-INFO
                       THRU 5051-1000-GENERAL-INFO-X

               WHEN WS-INSURED-DISPLAY
                   PERFORM  5051-1100-INSURED-INFO
                       THRU 5051-1100-INSURED-INFO-X

               WHEN WS-OWNER-DISPLAY
                   PERFORM  5051-1200-OWNER-INFO
                       THRU 5051-1200-OWNER-INFO-X

016395*        WHEN WS-PAC-PAYOR-DISPLAY
016395         WHEN WS-PAYOR-DISPLAY
016395             IF  WS-BUS-FCN-CRCDTL
016395                 MOVE MIR-CLI-CRC-NUM TO L5051-ACCT-NUM
016395                 PERFORM  5051-1800-CRC-PAYOR-INFO
016395                     THRU 5051-1800-CRC-PAYOR-INFO-X
016395             ELSE
                       MOVE MIR-CLI-BNK-ACCT-NUM TO L5051-ACCT-NUM
020467                 PERFORM  5051-1300-PMT-PAYOR-INFO
020467                     THRU 5051-1300-PMT-PAYOR-INFO-X
020467*                PERFORM  5051-1300-PAC-PAYOR-INFO
020467*                    THRU 5051-1300-PAC-PAYOR-INFO-X
016395             END-IF

               WHEN WS-LISTBILL-DISPLAY
                   PERFORM  5051-1400-LISTBILL-INFO
                       THRU 5051-1400-LISTBILL-INFO-X

               WHEN WS-CAN-TAXN-DISPLAY
                   PERFORM  5051-1500-CAN-TAXN-INFO
                       THRU 5051-1500-CAN-TAXN-INFO-X

               WHEN WS-CAN-TAXR-DISPLAY
                   PERFORM  5051-1600-CAN-TAXR-INFO
                       THRU 5051-1600-CAN-TAXR-INFO-X

               WHEN WS-US-TAX-DISPLAY
                   PERFORM  5051-1700-US-TAX-INFO
                       THRU 5051-1700-US-TAX-INFO-X

           END-EVALUATE.

       7000-RETRIEVE-POLICY-INFO-X.
           EXIT.
      /
      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID            TO WGLOB-REF-CLIENT-NUMBER.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.
018633*-------------------
018633*9500-BUILD-TWRK-KEY.
018633*-------------------
018633*
018633*    MOVE MIR-BUS-FCN-ID        TO L8090-BUS-FCN-ID.
018633*    SET L8090-USAGE-COMM       TO TRUE.
018633*    MOVE ZEROS                 TO L8090-TEMP-WRK-SEQ-NUM.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9800-WRITE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*    MOVE +300                  TO L8090-AREA-LEN.
018633*    MOVE WS-5050-SPECIFIC-AREA TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*
018633*-------------------
018633*9900-DELETE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
023514*    CONTINUE.
025970*    CONTINUE.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0951-0000-INIT-PARM-INFO
025970         THRU 0951-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2433-0000-INIT-PARM-INFO
025970         THRU 2433-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5020-0000-INIT-PARM-INFO
025970         THRU 5020-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5051-0000-INIT-PARM-INFO
025970         THRU 5051-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5052-0000-INIT-PARM-INFO
025970         THRU 5052-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5053-0000-INIT-PARM-INFO
025970         THRU 5053-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5216-0000-INIT-PARM-INFO
025970         THRU 5216-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6981-0000-INIT-PARM-INFO
025970         THRU 6981-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES                     TO WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFCCK.
       COPY CCPERELA.
      /
016053 COPY NCPPCVGS.
       COPY XCPPINIT.
       COPY XCPPEXIT.
012624*COPY XCPPMEXT.
      /
025970 COPY CCPS0951.
025970 COPY CCPS2430.
025970 COPY CCPS2433.
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
      *
      /
       COPY CCPSPGA.
      /
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
       COPY CCPL0620.

018764*COPY CCCL0951.
018764 COPY CCPL0951.
      /
018764*COPY CCCL2430.
018764 COPY CCPL2430.
020478 COPY CCPS2435.
020478 COPY CCPL2435.

018764*COPY CCCL2440.
020478 COPY CCPS2440.
018764 COPY CCPL2440.
020478 COPY CCPS5020.
020478 COPY CCPL5020.
      /
       COPY CCPS5051.
018764*COPY CCCL5051.
018764 COPY CCPL5051.

       COPY CCPS5052.
018764*COPY CCCL5052.
018764 COPY CCPL5052.

       COPY CCPS5053.
018764*COPY CCCL5053.
018764 COPY CCPL5053.

       COPY CCPS5216.
018764*COPY CCCL5216.
018764 COPY CCPL5216.
      /
       COPY CCPS5600.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
557667 COPY CCPECNTP.
018764*COPY CCCL2433.
018764 COPY CCPL2433.
      /
013578*COPY XCPS2500.
013578*COPY XCCL2500.
013578
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBBENC.
       COPY CCPBBENE.

       COPY CCPNBNKA.

016395 COPY CCPBCLCN.
016395 COPY CCPNCLCN.
016395
       COPY CCPNCLI.

020478*COPY CCPNCLNM.
015508/
015508 COPY CCPNCLNC.
015508/
016053 COPY CCPNCVG.
      /
       COPY CCPCCLIA.

020478*COPY CCPBCLIN.
020478*COPY CCPNCLIN.

016395 COPY CCPNCRCD.
016395
       COPY CCPNEDIT.

016053 COPY CCPNPOL.
010904 COPY CCPNPOLC.

       COPY CCPBRL.
016537*COPY CCPVRL.
016053*
018764*COPY CCCL6981.
018764 COPY CCPL6981.
016053 COPY CCPS6981.
016053*
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM5050                     **
      *****************************************************************
