      *************************
       IDENTIFICATION DIVISION.
      *************************

018764*PROGRAM-ID. XSLU1611.
       PROGRAM-ID. XSDU1611.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSDU1611                                         **
      **  REMARKS:  RETRIEVE LAST 100 MSIN RECORDS IN SEVERITY       **
      **            ORDER FOR THE LAST TASK EXECUTED, PERFORM A      **
      **            ROLLBACK, AND RE-INSERT THE RECORDS THAT WERE    **
      **            EXTRACTED.                                       **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016312**  6.1       MORE MESSAGE INDICATOR SETUP                     **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018763**  6.3       CODE CLEANUP - DEVENV/PROD ENVIRONMENT TAGS      **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020913**  6.4       ELIMINATION OF PROCESSING COPYBOOKS              **
021351**  6.4       RENAME SYNCPOINT TO ROLLBACK                     **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
026070**  6.6       ERROR HANDLER                                    **
031585**  7.0       MSIN RECORD WITH BLANK USER ID                   **
031971**  7.0       USER MESSAGE SEQUENCE NUMBER EXPANSION           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
036900**  7.1       REMOVE DEVENV AND PROD TAGS                      **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

018764*COPY XCWWPGWS REPLACING '$VAR1' BY 'XSLU1611'.
       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSDU1611'.

       COPY SQLCA.
016537*COPY XCWLPTR.

      *  BUFFER AREA FOR RETRIEVING MSIN RECORDS PRIOR TO ISSUING
      *  A ROLLBACK.

014590*COPY XCWL0030.
CVMF71 COPY XCWL0035.

      *****************************************************************
      * CALLED MODULE PARAMETER INFORMATION                           *
      *****************************************************************

020913*COPY XCWW1611.

031971 COPY XCWWCNST.
031971
       01  WS-WORK-AREA.
016548*    05  W1611-SUB                            PIC S9(04) COMP.
016548     05  WS-SUB                               PIC S9(04) BINARY.
016548*    05  W1611-SUB2                           PIC S9(04) COMP.
016548     05  WS-SUB2                              PIC S9(04) BINARY.
           05  WS-DUPS-IND                          PIC X(01).
               88  WS-DUPS-FOUND                    VALUE 'Y'.
               88  WS-DUPS-NOT-FOUND                VALUE 'N'.

       COPY XCFRMSIN.
       COPY XCFWMSIN.
       COPY XCFWMSIS.
      /
      *****************
       LINKAGE SECTION.
      *****************

018764 COPY XCWWDFH.
018764*01   DFHCOMMAREA.
018764*  02  WGLOB-GLOBAL-AREA.
018764 01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWL1611.

      ********************
018764*PROCEDURE DIVISION.
018764 PROCEDURE DIVISION USING DFHEIBLK
018764                          DFHCOMMAREA
018764                          WGLOB-GLOBAL-AREA
018764                          L1611-PARM-INFO.
      ********************

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
026070*
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
018764
018764*    SET ADDRESS OF L1611-PARM-INFO    TO WGLOB-PARM-ADDR-PTR (1).
           SET L1611-RETRN-OK                TO TRUE.

           INITIALIZE L1611-OUTPUT-PARM-INFO.

           EVALUATE TRUE

               WHEN L1611-RQST-ROLLBACK-SAVE-MSIN
                   PERFORM  1000-ROLLBACK-AND-SAVE-MSIN
                       THRU 1000-ROLLBACK-AND-SAVE-MSIN-X

               WHEN L1611-RQST-RETRIEVE-MSIN
                   PERFORM  2000-RETRIEVE-MSIN
                       THRU 2000-RETRIEVE-MSIN-X


               WHEN OTHER
                   SET  L1611-RETRN-INVALID-REQUEST  TO  TRUE

           END-EVALUATE.


           GOBACK.

       0000-MAINLINE-X.
           EXIT.


      *---------------------------
       1000-ROLLBACK-AND-SAVE-MSIN.
      *---------------------------
      *****************************************************************
      ** THIS PARAGRAPH WILL OBTAIN UP TO 100 OF THE LAST MSIN       **
      ** GENERATED, STORE THEM IN A BUFFER, PERFORM A ROLLBACK       **
      ** AND REWRITE THE RECORDS                                     **
      *****************************************************************

           PERFORM  9100-READ-MSIN-INTO-BUFFER
               THRU 9100-READ-MSIN-INTO-BUFFER-X.

           PERFORM  9200-ROLLBACK
               THRU 9200-ROLLBACK-X.

           PERFORM  9300-REWRITE-LAST-100-MSIN
               THRU 9300-REWRITE-LAST-100-MSIN-X.

       1000-ROLLBACK-AND-SAVE-MSIN-X.
           EXIT.
      /
      *------------------
       2000-RETRIEVE-MSIN.
      *------------------

           PERFORM  9100-READ-MSIN-INTO-BUFFER
               THRU 9100-READ-MSIN-INTO-BUFFER-X.

       2000-RETRIEVE-MSIN-X.
           EXIT.

      /
      *---------------------------
       9100-READ-MSIN-INTO-BUFFER.
      *---------------------------

           INITIALIZE L1611-MSIN-BUFFER-AREA.

      * SETUP FOR END-BROWSE KEY

           MOVE WGLOB-USER-ID           TO WMSIS-USER-ID.
           MOVE WGLOB-SYSTEM-DATE-INT   TO WMSIS-USER-MSG-DT.
           MOVE WGLOB-SYSTEM-TIME       TO WMSIS-USER-MSG-TIME.
           MOVE WGLOB-TASK-ID           TO WMSIS-USER-MSG-TASK-ID.
           SET  WMSIS-MSG-SEVRTY-INFO   TO TRUE.
           MOVE +001                    TO WMSIS-USER-MSG-SEQ-NUM.

           MOVE WMSIS-KEY               TO WMSIS-ENDBR-KEY.

      * SETUP FOR START BROWSE KEY

           SET  WMSIS-MSG-SEVRTY-SYSTEM TO TRUE.
031971*    MOVE +999                    TO WMSIS-USER-MSG-SEQ-NUM.
031971     MOVE WCNST-MAX-USER-MSG-SEQ-NUM-N
031971                                  TO WMSIS-USER-MSG-SEQ-NUM.

           PERFORM  MSIS-1000-BROWSE-PREV
               THRU MSIS-1000-BROWSE-PREV-X.

           PERFORM  MSIS-2000-READ-PREV
               THRU MSIS-2000-READ-PREV-X.

           MOVE ZERO                    TO L1611-MSIN-REC-CTR.
           MOVE +1                      TO WS-SUB.
           PERFORM  9110-UPDATE-MSIN-BUFFER
               THRU 9110-UPDATE-MSIN-BUFFER-X
              UNTIL WS-SUB > L1611-MAX-BUFFER-CTR
                 OR WMSIS-IO-EOF.

           IF  WMSIS-IO-OK
           AND L1611-RQST-RETRIEVE-MSIN
016312*        PERFORM  MSIS-2000-READ-PREV
016312*            THRU MSIS-2000-READ-PREV-X
016312*        IF WMSIS-IO-OK
                   SET L1611-MSIN-MORE-MESSAGES  TO TRUE
016312*        END-IF
           END-IF.

           PERFORM  MSIS-3000-END-BROWSE-PREV
               THRU MSIS-3000-END-BROWSE-PREV-X.

       9100-READ-MSIN-INTO-BUFFER-X.
           EXIT.

      *-----------------------
       9110-UPDATE-MSIN-BUFFER.
      *-----------------------

           SET  WS-DUPS-NOT-FOUND     TO TRUE.

           PERFORM  9111-SCAN-FOR-DUPS
               THRU 9111-SCAN-FOR-DUPS-X
            VARYING WS-SUB2 FROM 1 BY 1
              UNTIL WS-SUB2 > WS-SUB
                 OR WS-DUPS-FOUND.

           IF WS-DUPS-NOT-FOUND
               IF L1611-RQST-RETRIEVE-MSIN
               AND RMSIN-USER-MSG-GUI-NO
034802*            NEXT SENTENCE
034802             CONTINUE
034802*        END-IF
034802         ELSE
034802*        MOVE RMSIN-REC-INFO    TO L1611-MSIN-REC-INFO (WS-SUB)
034802*        ADD  +1                TO L1611-MSIN-REC-CTR
034802*        ADD  +1                TO WS-SUB
034802             MOVE RMSIN-REC-INFO  TO L1611-MSIN-REC-INFO (WS-SUB)
034802             ADD  +1              TO L1611-MSIN-REC-CTR
034802             ADD  +1              TO WS-SUB
034802         END-IF
           END-IF.

           PERFORM  MSIS-2000-READ-PREV
               THRU MSIS-2000-READ-PREV-X.

       9110-UPDATE-MSIN-BUFFER-X.
           EXIT.
      /

      *------------------
       9111-SCAN-FOR-DUPS.
      *------------------

           IF RMSIN-USER-MSG-TXT = L1611-MSIN-USER-MSG-TXT (WS-SUB2)
               SET  WS-DUPS-FOUND       TO TRUE
           END-IF.

       9111-SCAN-FOR-DUPS-X.
           EXIT.

      *-------------
       9200-ROLLBACK.
      *-------------

018764*    EXEC CICS
018764*         SYNCPOINT ROLLBACK
018764*    END-EXEC.
018764*
021351*    PERFORM  ABND-6000-SYNCPOINT
021351*        THRU ABND-6000-SYNCPOINT-X.

026070*    PERFORM  ABND-6000-ROLLBACK
026070*        THRU ABND-6000-ROLLBACK-X.
           PERFORM  ERR-2000-ROLLBACK
               THRU ERR-2000-ROLLBACK-X.

CVMQ71     PERFORM  QERR-2000-ROLLBACK
CVMQ71         THRU QERR-2000-ROLLBACK-X.

       9200-ROLLBACK-X.
           EXIT.
      /
      *--------------------------
       9300-REWRITE-LAST-100-MSIN.
      *--------------------------

031585     IF  WGLOB-USER-ID = SPACE
031585         GO TO 9300-REWRITE-LAST-100-MSIN-X
031585     END-IF.

           MOVE +1                      TO WS-SUB.
           PERFORM  9310-REWRITE-ONE-MSIN
               THRU 9310-REWRITE-ONE-MSIN-X
              UNTIL WS-SUB > L1611-MSIN-REC-CTR.

       9300-REWRITE-LAST-100-MSIN-X.
           EXIT.

      *---------------------
       9310-REWRITE-ONE-MSIN.
      *---------------------

           MOVE L1611-MSIN-REC-INFO (WS-SUB)    TO RMSIN-REC-INFO.

           MOVE RMSIN-KEY               TO WMSIN-KEY.

           PERFORM  MSIN-1000-WRITE
               THRU MSIN-1000-WRITE-X.

           ADD  +1                      TO WS-SUB.

       9310-REWRITE-ONE-MSIN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
023514
023514     CONTINUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      **                   PROCESSING COPYBOOKS                      **
      *****************************************************************

       COPY XCPVMSIS.
       COPY XCPAMSIN.
       COPY XCCP0030.
018764
026070*COPY XCCPABND.
026070 COPY XCCPERR.
CVMQ71 COPY XCCPQERR.
CVMQ71 COPY XCPL0035.

      *****************************************************************
      **                 END OF PROGRAM XSDU1611                     **
      *****************************************************************
