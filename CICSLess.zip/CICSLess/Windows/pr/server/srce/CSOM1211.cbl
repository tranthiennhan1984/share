      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1211.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1211                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE RT TABLE                                 **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
012624**  6.0       DESCRIPTION                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016483**  6.2       MESSAGE CLEANUP                                  **
016537**  6.2       CODE CLEAN UP                                    **
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1211'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      *
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-CREATE            VALUE '1211'.
025970*    05  WS-TWRK-KEY                      PIC X(04)
025970*                                         VALUE '1210'.
014221     05  WS-SAVE-RT-KEY                   PIC X(100).
           05  WS-EDIT-KEY-FIELDS.
               10  WS-RTBL-SMKR-CD              PIC X(01).
                   88  WS-RTBL-SMKR-CD-VALID    VALUE SPACE
                                                      'S' 'N' 'C' 'U'.
               10  WS-RTBL-PAR-CD               PIC X(01).
                   88  WS-RTBL-PAR-CD-VALID     VALUE SPACE 'N' 'P'.
               10  WS-RTBL-SEX-CD               PIC X(01).
                   88  WS-RTBL-SEX-CD-VALID     VALUE SPACE 'M' 'F' 'J'.
               10  WS-RTBL-DB-OPT-CD            PIC X(01).
                   88  WS-RTBL-DB-OPT-CD-VALID  VALUE SPACE '1' '2' 'A'
                                                      'B' 'I' 'L'.
               10  WS-RTBL-PNSN-QUALF-CD        PIC X(01).
                   88  WS-RTBL-PNSN-QUALF-CD-VALID VALUE SPACE 'C' 'D'
                                                      'I' 'F' 'K' 'N'
013697*                                               'O' 'S' 'T'.
013697                                                'O' 'S' 'T'
013697                                                'R' 'E' 'M'.
               10  WS-RTBL-JNT-LIFE-CD          PIC X(01).
                   88  WS-RTBL-JNT-LIFE-CD-VALID VALUE SPACE 'L' 'F' 'S'
                                                      'J'.
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '1210'.

      *
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      *
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      *
       COPY CCFWRT.
       COPY CCFRRT.
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
014221 COPY XCWL8090.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1211.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.
 
       0000-MAINLINE-X.
           GOBACK.

      *
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID                   TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID          TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1211'              TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'            TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'            TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST    TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *
      *------------
       2000-CREATE.
      *------------
      *
      *  THE RECORD SHOULD NOT EXIST ON A CREATE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  MIR-RETRN-EDIT-ERROR
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  RT-1000-BROWSE
               THRU RT-1000-BROWSE-X.
           PERFORM  RT-2000-READ-NEXT
               THRU RT-2000-READ-NEXT-X.

           IF  WRT-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE WRT-KEY                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  RT-3000-END-BROWSE
                   THRU RT-3000-END-BROWSE-X
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  RT-3000-END-BROWSE
               THRU RT-3000-END-BROWSE-X.
014221     MOVE WRT-KEY                     TO WS-SAVE-RT-KEY.
           PERFORM
             UNTIL WRT-RTBL-AGE-DUR > WRT-ENDBR-RTBL-AGE-DUR
               PERFORM  RT-1000-CREATE
                   THRU RT-1000-CREATE-X
               PERFORM  RT-1000-WRITE
                   THRU RT-1000-WRITE-X
               ADD +1                       TO WRT-RTBL-AGE-DUR
           END-PERFORM.

014221     MOVE WS-SAVE-RT-KEY              TO WRT-KEY.
014221     PERFORM RT-1000-READ-TWRK-TS
014221        THRU RT-1000-READ-TWRK-TS-X
014221     IF  WRT-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WRT-KEY           TO WGLOB-MSG-PARM (1)
014221         MOVE 'RT'           TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221     END-IF.

       2000-CREATE-X.
           EXIT.
      *

      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           PERFORM  4110-EDIT-RTBL-SMKR-CD
               THRU 4110-EDIT-RTBL-SMKR-CD-X.

           PERFORM  4120-EDIT-RTBL-PAR-CD
               THRU 4120-EDIT-RTBL-PAR-CD-X.

           PERFORM  4130-EDIT-RTBL-SEX-CD
               THRU 4130-EDIT-RTBL-SEX-CD-X.

           PERFORM  4140-EDIT-RTBL-STBL-1-CD
               THRU 4140-EDIT-RTBL-STBL-1-CD-X.

           PERFORM  4150-EDIT-RTBL-STBL-2-CD
               THRU 4150-EDIT-RTBL-STBL-2-CD-X.

           PERFORM  4160-EDIT-RTBL-STBL-3-CD
               THRU 4160-EDIT-RTBL-STBL-3-CD-X.

           PERFORM  4170-EDIT-RTBL-STBL-4-CD
               THRU 4170-EDIT-RTBL-STBL-4-CD-X.

           PERFORM  4180-EDIT-RTBL-LOC-GR-ID
               THRU 4180-EDIT-RTBL-LOC-GR-ID-X.

           PERFORM  4190-EDIT-RTBL-DB-OPT-CD
               THRU 4190-EDIT-RTBL-DB-OPT-CD-X.

           PERFORM  4200-EDIT-RTBL-PNSN-QUALF-CD
               THRU 4200-EDIT-RTBL-PNSN-QUALF-CD-X.

           PERFORM  4210-EDIT-RTBL-JNT-LIFE-CD
               THRU 4210-EDIT-RTBL-JNT-LIFE-CD-X.

           PERFORM  4220-EDIT-RTBL-RT-TYP-CD
               THRU 4220-EDIT-RTBL-RT-TYP-CD-X.

012525     PERFORM  4230-EDIT-RTBL-MAT-XPRY-DUR
012525         THRU 4230-EDIT-RTBL-MAT-XPRY-DUR-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      *
      ************************
       4110-EDIT-RTBL-SMKR-CD.
      ************************
      *
      *************************************************************
      * VALIDATE THE SMOKER VALUE
      *************************************************************
           MOVE WRT-RTBL-SMKR-CD      TO WS-RTBL-SMKR-CD.
      *
           IF WS-RTBL-SMKR-CD-VALID
               CONTINUE
           ELSE
               MOVE 'CS12110003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4110-EDIT-RTBL-SMKR-CD-X.
           EXIT.
      *
      ***********************
       4120-EDIT-RTBL-PAR-CD.
      ***********************
      *
      *************************************************************
      * VALIDATE THE PAR VALUE
      *************************************************************
      *
           MOVE WRT-RTBL-PAR-CD        TO WS-RTBL-PAR-CD.
      *
           IF WS-RTBL-PAR-CD-VALID
               CONTINUE
           ELSE
               MOVE 'CS12110004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4120-EDIT-RTBL-PAR-CD-X.
           EXIT.
      *
      ***********************
       4130-EDIT-RTBL-SEX-CD.
      ***********************
      *
      *************************************************************
      * VALIDATE THE SEX VALUE
      *************************************************************
      *
           MOVE WRT-RTBL-SEX-CD        TO WS-RTBL-SEX-CD.
      *
           IF WS-RTBL-SEX-CD-VALID
               CONTINUE
           ELSE
               MOVE 'CS12110005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4130-EDIT-RTBL-SEX-CD-X.
           EXIT.
      *
      **************************
       4140-EDIT-RTBL-STBL-1-CD.
      **************************
      *
      ***************************************************************
      *  SUB TABLE 1 MUST BE IN ETAB/STBL1
      ***************************************************************
      *
           IF WRT-RTBL-STBL-1-CD NOT = SPACES
               MOVE WRT-RTBL-STBL-1-CD     TO WEDIT-ETBL-VALU-ID
               PERFORM  STB1-1000-EDIT-SUB-TABLE-1
                   THRU STB1-1000-EDIT-SUB-TABLE-1-X
               IF WEDIT-IO-OK
                   CONTINUE
               ELSE
                   MOVE 'CS12110006'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
       4140-EDIT-RTBL-STBL-1-CD-X.
           EXIT.
      *
      **************************
       4150-EDIT-RTBL-STBL-2-CD.
      **************************
      *
      ***************************************************************
      *  SUB TABLE 2 MUST BE IN ETAB/STBL2
      ***************************************************************
      *
           IF WRT-RTBL-STBL-2-CD NOT = SPACES
               MOVE WRT-RTBL-STBL-2-CD             TO WEDIT-ETBL-VALU-ID
               PERFORM  STB2-1000-EDIT-SUB-TABLE-2
                   THRU STB2-1000-EDIT-SUB-TABLE-2-X
               IF  WEDIT-IO-OK
                   CONTINUE
               ELSE
                   MOVE 'CS12110007'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
       4150-EDIT-RTBL-STBL-2-CD-X.
           EXIT.
      *
      **************************
       4160-EDIT-RTBL-STBL-3-CD.
      **************************
      *
      ***************************************************************
      *  SUB TABLE 3 MUST BE IN ETAB/STB3
      ***************************************************************
      *
           IF WRT-RTBL-STBL-3-CD NOT = SPACES
               MOVE WRT-RTBL-STBL-3-CD             TO WEDIT-ETBL-VALU-ID
               PERFORM  STB3-1000-EDIT-SUB-TABLE-3
                   THRU STB3-1000-EDIT-SUB-TABLE-3-X
               IF  WEDIT-IO-OK
                   CONTINUE
               ELSE
                   MOVE 'CS12110008'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
       4160-EDIT-RTBL-STBL-3-CD-X.
           EXIT.
      *
      **************************
       4170-EDIT-RTBL-STBL-4-CD.
      **************************
      *
      ***************************************************************
      *  SUB TABLE 4 MUST BE IN ETAB/STB4
      ***************************************************************
      *
           IF WRT-RTBL-STBL-4-CD NOT = SPACES
               MOVE WRT-RTBL-STBL-4-CD             TO WEDIT-ETBL-VALU-ID
               PERFORM  STB4-1000-EDIT-SUB-TABLE-4
                   THRU STB4-1000-EDIT-SUB-TABLE-4-X
               IF  WEDIT-IO-OK
                   CONTINUE
               ELSE
                   MOVE 'CS12110009'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
       4170-EDIT-RTBL-STBL-4-CD-X.
           EXIT.
      *
      **************************
       4180-EDIT-RTBL-LOC-GR-ID.
      **************************
      *
      ***************************************************************
      *  CURRENT LOCATION MUST BE IN ETAB/CLOC
      ***************************************************************
      *
           IF WRT-LOC-GR-ID NOT = SPACES
               MOVE WRT-LOC-GR-ID     TO WEDIT-ETBL-VALU-ID
               PERFORM  LGAS-1000-EDIT-LGAS-LOCATION
                   THRU LGAS-1000-EDIT-LGAS-LOCATION-X
               IF  WEDIT-IO-OK
                   CONTINUE
               ELSE
      * MSG: LOC MUST BE FOUND ON EDIT/LOCGP. CHECK AND RE-ENTER
                   MOVE 'CS12110010'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *
       4180-EDIT-RTBL-LOC-GR-ID-X.
           EXIT.
      *
      **************************
       4190-EDIT-RTBL-DB-OPT-CD.
      **************************
      *
      *************************************************************
      * VALIDATE THE DBO VALUE
      *************************************************************
      *
           MOVE WRT-RTBL-DB-OPT-CD     TO WS-RTBL-DB-OPT-CD.
      *
           IF WS-RTBL-DB-OPT-CD-VALID
               CONTINUE
           ELSE
               MOVE 'CS12110011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4190-EDIT-RTBL-DB-OPT-CD-X.
           EXIT.
      *
      ******************************
       4200-EDIT-RTBL-PNSN-QUALF-CD.
      ******************************
      *
      *************************************************************
      * VALIDATE THE PENSION QUALIFIED CODE
      *************************************************************
      *
           MOVE WRT-RTBL-PNSN-QUALF-CD TO WS-RTBL-PNSN-QUALF-CD.
      *
           IF WS-RTBL-PNSN-QUALF-CD-VALID
               CONTINUE
           ELSE
               MOVE 'CS12110012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4200-EDIT-RTBL-PNSN-QUALF-CD-X.
           EXIT.
      *
      ****************************
       4210-EDIT-RTBL-JNT-LIFE-CD.
      ****************************
      *
      *************************************************************
      * VALIDATE THE JOINT LIFE AGE CODE
      *************************************************************
      *
           MOVE WRT-RTBL-JNT-LIFE-CD   TO WS-RTBL-JNT-LIFE-CD.
      *
           IF WS-RTBL-JNT-LIFE-CD-VALID
               CONTINUE
           ELSE
               MOVE 'CS12110013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4210-EDIT-RTBL-JNT-LIFE-CD-X.
           EXIT.
      *
      **************************
       4220-EDIT-RTBL-RT-TYP-CD.
      **************************
      *
      *************************************************************
      * VALIDATE THE RATE TYPE CODE
      *************************************************************
      *
           MOVE WRT-RTBL-RT-TYP-CD             TO WEDIT-ETBL-VALU-ID.
           PERFORM  RTTP-1000-EDIT
               THRU RTTP-1000-EDIT-X.

           IF WEDIT-IO-OK
               CONTINUE
           ELSE
               MOVE 'CS12110014'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
       4220-EDIT-RTBL-RT-TYP-CD-X.
           EXIT.
      *
012525**************************
012525 4230-EDIT-RTBL-MAT-XPRY-DUR.
012525**************************
012525*
012525*************************************************************
012525* VALIDATE THE COVERAGE TERM
012525*************************************************************
012525*
012525     IF MIR-RTBL-MAT-XPRY-DUR NOT NUMERIC
012525        MOVE 'CS12110016'  TO WGLOB-MSG-REF-INFO
012525         PERFORM  0260-1000-GENERATE-MESSAGE
012525             THRU 0260-1000-GENERATE-MESSAGE-X
012525     END-IF.
012525*
012525 4230-EDIT-RTBL-MAT-XPRY-DUR-X.
012525     EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.
           MOVE LOW-VALUES             TO WRT-KEY.
           MOVE MIR-RTBL-DB-OPT-CD     TO WRT-RTBL-DB-OPT-CD.
           MOVE MIR-RTBL-JNT-LIFE-CD   TO WRT-RTBL-JNT-LIFE-CD.
           MOVE MIR-LOC-GR-ID          TO WRT-LOC-GR-ID.
           MOVE MIR-RTBL-PAR-CD        TO WRT-RTBL-PAR-CD.
           MOVE MIR-RTBL-PNSN-QUALF-CD TO WRT-RTBL-PNSN-QUALF-CD.
           MOVE MIR-RTBL-RT-TYP-CD     TO WRT-RTBL-RT-TYP-CD.
           MOVE MIR-RTBL-ID            TO WRT-RTBL-ID.
           MOVE MIR-RTBL-SEX-CD        TO WRT-RTBL-SEX-CD.
           MOVE MIR-RTBL-SMKR-CD       TO WRT-RTBL-SMKR-CD.
           MOVE MIR-RTBL-STBL-1-CD     TO WRT-RTBL-STBL-1-CD.
           MOVE MIR-RTBL-STBL-2-CD     TO WRT-RTBL-STBL-2-CD.
           MOVE MIR-RTBL-STBL-3-CD     TO WRT-RTBL-STBL-3-CD.
           MOVE MIR-RTBL-STBL-4-CD     TO WRT-RTBL-STBL-4-CD.

012525     MOVE MIR-RTBL-MAT-XPRY-DUR  TO L0280-INPUT-DATA.
012525     MOVE LENGTH OF MIR-RTBL-MAT-XPRY-DUR TO L0280-INPUT-SIZE.
012525     MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
012525     MOVE ZERO                   TO L0280-PRECISION.
012525     PERFORM 0280-1000-NUMERIC-EDIT
012525        THRU 0280-1000-NUMERIC-EDIT-X.
020874*    MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
020874     MOVE L0280-OUTPUT           TO L0290-INPUT-V00.
012525     MOVE LENGTH MIR-RTBL-MAT-XPRY-DUR TO L0290-MAX-OUT-LEN.
012525     MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
012525     MOVE L0290-OUTPUT-DATA      TO WRT-RTBL-MAT-XPRY-DUR.

           MOVE MIR-DPOS-TRM-DY-DUR    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
020874*    MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
020874     MOVE L0280-OUTPUT           TO L0290-INPUT-V00.
015543*    MOVE LENGTH MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN.
015543     MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN.
           MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO WRT-DPOS-TRM-DY-DUR.
           MOVE MIR-DPOS-TRM-MO-DUR    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
020874*    MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
020874     MOVE L0280-OUTPUT           TO L0290-INPUT-V00.
015543*    MOVE LENGTH MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN.
015543     MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN.
           MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO WRT-DPOS-TRM-MO-DUR.
      *
           IF MIR-RTBL-AGE = SPACE
               MOVE SPACE              TO WRT-RTBL-AGE
           ELSE
               MOVE MIR-RTBL-AGE       TO L0280-INPUT-DATA
               MOVE LENGTH OF MIR-RTBL-AGE TO L0280-INPUT-SIZE
               MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
               MOVE ZERO               TO L0280-PRECISION
               PERFORM 0280-1000-NUMERIC-EDIT
                  THRU 0280-1000-NUMERIC-EDIT-X
               MOVE L0280-OUTPUT       TO WRT-RTBL-AGE-N
           END-IF.
      *
           MOVE MIR-RTBL-IDT-NUM       TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT                                    
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.                                 
020462     PERFORM 1640-7000-MIR-TO-INT                                         
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE TO WRT-RTBL-IDT-NUM-N
           ELSE
               MOVE 'CS12110001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           MOVE MIR-RTBL-AGE-DUR       TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-AGE-DUR TO L0280-INPUT-SIZE.
           MOVE ZERO                   TO L0280-PRECISION.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT       TO WRT-RTBL-AGE-DUR
           ELSE
               MOVE 'CS12110002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           MOVE WRT-KEY                TO WRT-ENDBR-KEY.
      *
           MOVE MIR-DV-END-RTBL-AGE-DUR TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DV-END-RTBL-AGE-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT       TO WRT-ENDBR-RTBL-AGE-DUR
               IF WRT-ENDBR-RTBL-AGE-DUR < WRT-RTBL-AGE-DUR
016483*MSG: INVALID AGE RANGE
                   MOVE 'CS12110015'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
               END-IF
           ELSE
               MOVE 'CS12110002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.


      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT  TO TRUE.
025970     MOVE MIR-BUS-FCN-ID      TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK        TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPELGAS.
       COPY CCPERTTP.
       COPY CCPESTB1.
       COPY CCPESTB2.
       COPY CCPESTB3.
       COPY CCPESTB4.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY RT
014221                         '$VAR2' BY 'RT'.
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
      *
       COPY CCPART.
       COPY CCPBRT.
       COPY CCPCRT.
014221*
014221 COPY CCPNRT.
014221 COPY CCPURT.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM1211                     **
      *****************************************************************
