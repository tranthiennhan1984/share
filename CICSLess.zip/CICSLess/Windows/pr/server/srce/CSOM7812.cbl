      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7812.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7812                                         **
      **  REMARKS:  FINANCIAL ACTIVITY BUSINESS FUNCTION             **
      **            THIS MODULE PERFORMS THE POLICY INQUIRY FOR THE  **
      **            TOTAL DEPOSIT                                    **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018839**  6.3       FINANCIAL BALANCES FLOW                          **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
021657**  6.6       CORRECT FIELD NAMES IN MIR COPYBOOKS             **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
025999**  6.6       MESSAGE CORRECTION                               **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
033899**  7.0       M&E TRANSFER MISSING FROM POLICY ACTIVITY LIST   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7812'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
021930*COPY XCWWCVGM.

025970*01  WS-PGM-WORK-AREA.
025970 01  WS-CONSTANTS.
           05  WS-MAX-LINE                      PIC 999 VALUE 50.
025970         88 WS-MAX-LINE-DEFAULT           VALUE 50.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-RETRIEVE          VALUE '7812'.
           05  WS-CVG                           PIC 99.
           05  WS-SEQ                           PIC X(20).
           05  FILLER                REDEFINES  WS-SEQ.
               10  WS-SEQ-NUM                   PIC 999.
               10  FILLER                       PIC X(17).
           05  WS-FA-SEQ-NUM                    PIC 999.
           05  WS-SUB                           PIC 999.
           05  WS-CDSD-COUNT                    PIC S99.
           05  WS-ACTIVITY-TYPE-ID              PIC X(4).
               88  WS-ACTIVITY-TYPE-DEP   VALUE '4009' '4012' '4013'
031036*                                         '5000'.
031036                                          '5000' '7061' '7062'.
               88  WS-ACTIVITY-TYPE-REVRS VALUE '4001' '4002' '4003'
                                                '4006' '4007' '4008'
                                                '4011' '4012' '4013'
                                                '4014' '4015' '4017'
                                                '4018' '5002' '5003'
                                                '5004' '5005' '5006'
033899*                                         '5007' '5010' '5100'
033899                                          '5007' '5011' '5100'
031036*                                         '5022'.
031036                                          '5022' '7061' '7062'
031036                                          '7063' '7064'.
           05  WS-WEALTH-ACCUM-IND              PIC X VALUE 'N'.
               88  WS-WEALTH-ACCUM-YES          VALUE 'Y'.
               88  WS-WEALTH-ACCUM-NO           VALUE 'N'.
030054*    05  WS-SAVE-PHST-DATA.
030054*        10  WS-SAVE-PCHST-EFF-IDT-NUM    PIC X(007).
030054*        10  WS-SAVE-PCHST-SEQ-NUM        PIC 9(003).
030054*        10  WS-SAVE-PCHST-STAT-CD        PIC X(001).
030054*        10  WS-SAVE-POL-ACTV-TYP-ID      PIC X(004).
030054*        10  WS-SAVE-PCHST-EFF-DT         PIC X(010).
           05  WS-TRXN-TYP-ID                   PIC X(003).
               88  WS-TRXN-TYP-SDP              VALUE 'SDP'.
               88  WS-TRXN-TYP-DEP              VALUE 'DEP'.
               88  WS-TRXN-TYP-IPD              VALUE 'IPD'.
           05  WS-DEP-PHST-FOUND-NO-IND         PIC X(001).
               88  WS-DEP-PHST-FOUND-NO         VALUE 'N'.
               88  WS-DEP-PHST-FOUND-YES        VALUE 'Y'.
           05  WS-CDSA-REC-FOUND-IND            PIC X(01).
               88  WS-CDSA-REC-FOUND            VALUE 'Y'.
               88  WS-CDSA-REC-NOT-FOUND        VALUE 'N'.
           05  WS-SAVE-CDSA-KEY.
               10  WS-CDSA-CO-ID                PIC X(02).
               10  WS-CDSA-POL-ID               PIC X(10).
023437*        10  WS-CDSA-TYP-CD               PIC X(01).
023437         10  WS-CDSA-TYP-CD               PIC X(02).
               10  WS-CDSA-POL-PAYO-NUM         PIC S9(05)  COMP-3.
               10  WS-CDSA-CDA-EFF-IDT-NUM      PIC X(07).
               10  WS-CDSA-CDA-EFF-IDT-NUM-N    REDEFINES
                   WS-CDSA-CDA-EFF-IDT-NUM      PIC 9(07).
               10  WS-CDSA-CDA-SEQ-NUM          PIC S9(03)  COMP-3.
           05  WS-TRXN-EFF-DT                   PIC X(010).
           05  WS-CLI-TRXN-AMT                  PIC S9(13)V9(02).
           05  WS-TRXN-GRS-AMT                  PIC S9(13)V99.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
       COPY CCWWINDX.
030054 COPY XCWWCNST.
       COPY CCWWLOCK.
      /
      *****************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                            *
      *****************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFRCDSA.
       COPY CCFWCDSA.
021930*COPY CCFWCDSD.
021930*COPY CCFRCDSD.
       COPY CCFWPHST.
       COPY CCFRPHST.
030054 COPY CCFHPHST.
       COPY SCFWFA.
       COPY SCFRFA.
       COPY SCFWFD.
       COPY SCFRFD.
       COPY CCFWCFLW.
       COPY CCFRCFLW.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      *
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7812.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    INITIALIZE                   WS-WORK-AREA.
025970*    MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK         TO TRUE.
025970*    MOVE SPACES               TO MIR-OUTPUT-AREA.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7812'       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------

           MOVE MIR-POL-ID             TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WPOL-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'POL'            TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           SET WS-WEALTH-ACCUM-NO TO TRUE.

           PERFORM  2010-INS-TYPE-CHECK
               THRU 2010-INS-TYPE-CHECK-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > RPOL-POL-CVG-REC-CTR-N
                  OR WS-WEALTH-ACCUM-YES.

           IF WS-WEALTH-ACCUM-NO
      * MSG: FINANCIAL ACTIVITY IS NOT AVAILABLE FOR THIS TYPE OF POLICY
               MOVE 'CS78120002'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-RETRIEVE-X
           END-IF.


021657*    MOVE MIR-DV-START-DT           TO L1640-EXTERNAL-DATE.
021657     MOVE MIR-DV-STRT-DT            TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
026057     IF  L1640-NOT-VALID
026057*MSG:    'DATE @1 INVALID'
026057         MOVE 'CS78120003'      TO WGLOB-MSG-REF-INFO
026057         MOVE MIR-DV-STRT-DT    TO WGLOB-MSG-PARM (1)
026057         PERFORM  0260-1000-GENERATE-MESSAGE
026057             THRU 0260-1000-GENERATE-MESSAGE-X
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 2000-RETRIEVE-X
026057     END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE L1640-INTERNAL-DATE   TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 2000-RETRIEVE-X
026057     END-IF.

           MOVE L1640-INTERNAL-DATE       TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE       TO WPHST-PCHST-EFF-IDT-NUM.

021657*    MOVE MIR-DV-START-SEQ-NUM      TO L0280-INPUT-DATA.
021657     MOVE MIR-DV-STRT-SEQ-NUM       TO L0280-INPUT-DATA.
021657*    MOVE LENGTH OF MIR-DV-START-SEQ-NUM  TO L0280-INPUT-SIZE.
021657     MOVE LENGTH OF MIR-DV-STRT-SEQ-NUM  TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE          TO L0280-LENGTH.
           MOVE ZERO                      TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT              TO WPHST-PCHST-SEQ-NUM.


           PERFORM  3000-POL-ACTIVITY-LIST
               THRU 3000-POL-ACTIVITY-LIST-X.


       2000-RETRIEVE-X.
           EXIT.

      *--------------------
       2010-INS-TYPE-CHECK.
      *--------------------

           IF WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-SUB)
           OR WCVGS-CVG-INS-TYP-SEG-FUND    (WS-SUB)
           OR WCVGS-CVG-INS-TYP-FPA         (WS-SUB)
               SET WS-WEALTH-ACCUM-YES TO TRUE
           END-IF.

       2010-INS-TYPE-CHECK-X.
           EXIT.

      /
      *-----------------------
       3000-POL-ACTIVITY-LIST.
      *-----------------------
      *
           MOVE RPOL-POL-ID         TO WPHST-POL-ID.
           MOVE WPHST-KEY           TO WPHST-ENDBR-KEY.
           MOVE HIGH-VALUES         TO WPHST-ENDBR-PCHST-EFF-IDT-NUM.
030054*    MOVE +999                TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                              TO WPHST-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-BROWSE
               THRU PHST-1000-BROWSE-X.

           SET WS-DEP-PHST-FOUND-NO TO TRUE.
           PERFORM  3010-READ-DEP-PHST
               THRU 3010-READ-DEP-PHST-X
               UNTIL WS-DEP-PHST-FOUND-YES
                  OR WPHST-IO-EOF.

           IF WPHST-IO-EOF
      *MSG: NO DEPOSIT ACTIVITY TO DISPLAY
               MOVE 'CS78120001'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PHST-3000-END-BROWSE
                   THRU PHST-3000-END-BROWSE-X
               GO TO 3000-POL-ACTIVITY-LIST-X
           END-IF.

           MOVE 1                 TO WS-SUB.
           PERFORM  3100-DEP-PHST-LOOP
               THRU 3100-DEP-PHST-LOOP-X
               UNTIL   WS-SUB > WS-MAX-LINE
               OR      WPHST-IO-EOF.


           IF WPHST-IO-EOF
      * MSG: ** END OF LIST **
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
           ELSE
      * MSG: INQUIRE COMPLETE - CONTINUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE

      * SET KEY FOR NEXT SCREEN
030054*        MOVE WS-SAVE-PCHST-EFF-DT  TO  L1640-INTERNAL-DATE
030054         MOVE HPHST-PCHST-EFF-DT    TO  L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
021657*        MOVE L1640-EXTERNAL-DATE   TO  MIR-DV-START-DT
021657         MOVE L1640-EXTERNAL-DATE   TO  MIR-DV-STRT-DT

020874*        MOVE WS-SAVE-PCHST-SEQ-NUM TO L0290-INPUT-NUMBER
030054*        MOVE WS-SAVE-PCHST-SEQ-NUM TO L0290-INPUT-V00
030054         MOVE HPHST-PCHST-SEQ-NUM   TO L0290-INPUT-V00
               MOVE 0                     TO L0290-PRECISION
021657*        MOVE LENGTH OF MIR-DV-START-SEQ-NUM
021657         MOVE LENGTH OF MIR-DV-STRT-SEQ-NUM
                                         TO L0290-MAX-OUT-LEN
020874*        SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
               SET L0290-SIGN-SUPPRESS       TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
021657*        MOVE L0290-OUTPUT-DATA    TO  MIR-DV-START-SEQ-NUM
021657         MOVE L0290-OUTPUT-DATA    TO  MIR-DV-STRT-SEQ-NUM
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  PHST-3000-END-BROWSE
               THRU PHST-3000-END-BROWSE-X.

       3000-POL-ACTIVITY-LIST-X.
           EXIT.


      *------------------
       3010-READ-DEP-PHST.
      *------------------

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.

           IF WPHST-IO-EOF
              GO TO 3010-READ-DEP-PHST-X
           END-IF.

           IF RPHST-PCHST-STAT-ACTIVE
           OR RPHST-PCHST-STAT-REVERSED
               CONTINUE
           ELSE
               GO TO 3010-READ-DEP-PHST-X
           END-IF.

           MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTIVITY-TYPE-ID.
           IF NOT WS-ACTIVITY-TYPE-DEP
               GO TO 3010-READ-DEP-PHST-X
           END-IF.

           SET WS-DEP-PHST-FOUND-YES    TO TRUE.
030054*    MOVE RPHST-PCHST-EFF-IDT-NUM TO WS-SAVE-PCHST-EFF-IDT-NUM.
030054*    MOVE RPHST-PCHST-SEQ-NUM     TO WS-SAVE-PCHST-SEQ-NUM.
030054*    MOVE RPHST-PCHST-EFF-DT      TO WS-SAVE-PCHST-EFF-DT.
030054*    MOVE RPHST-PCHST-STAT-CD     TO WS-SAVE-PCHST-STAT-CD.
030054*    MOVE RPHST-POL-ACTV-TYP-ID   TO WS-SAVE-POL-ACTV-TYP-ID.
030054     MOVE RPHST-PCHST-EFF-IDT-NUM TO HPHST-PCHST-EFF-IDT-NUM.
030054     MOVE RPHST-PCHST-SEQ-NUM     TO HPHST-PCHST-SEQ-NUM.
030054     MOVE RPHST-PCHST-EFF-DT      TO HPHST-PCHST-EFF-DT.
030054     MOVE RPHST-PCHST-STAT-CD     TO HPHST-PCHST-STAT-CD.
030054     MOVE RPHST-POL-ACTV-TYP-ID   TO HPHST-POL-ACTV-TYP-ID.

       3010-READ-DEP-PHST-X.
           EXIT.

      *
      *-------------------
       3100-DEP-PHST-LOOP.
      *-------------------

           PERFORM  3200-PROCESS-DEPOSITS
               THRU 3200-PROCESS-DEPOSITS-X

           SET WS-DEP-PHST-FOUND-NO TO TRUE.
           PERFORM  3010-READ-DEP-PHST
               THRU 3010-READ-DEP-PHST-X
               UNTIL WS-DEP-PHST-FOUND-YES
                  OR WPHST-IO-EOF.

       3100-DEP-PHST-LOOP-X.
           EXIT.

      *
      *----------------------
       3200-PROCESS-DEPOSITS.
      *----------------------

           MOVE RPHST-CVG-NUM                TO WS-CVG.
           SET WS-CDSA-REC-NOT-FOUND         TO TRUE.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  3300-DEPOSITS-FA
                        THRU 3300-DEPOSITS-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  3400-DEPOSITS-CFLW
                        THRU 3400-DEPOSITS-CFLW-X

           END-EVALUATE.

           IF  WS-CDSA-REC-NOT-FOUND
               GO TO 3200-PROCESS-DEPOSITS-X
           END-IF.

           IF  RCDSA-KEY NOT = WS-SAVE-CDSA-KEY
               MOVE RCDSA-CDA-EFF-DT         TO WS-TRXN-EFF-DT
               MOVE RCDSA-CDA-TOT-TRXN-AMT   TO WS-TRXN-GRS-AMT
               PERFORM  3600-DEPOSITS-TO-MIR
                   THRU 3600-DEPOSITS-TO-MIR-X
               MOVE RCDSA-KEY                TO WS-SAVE-CDSA-KEY
           END-IF.

       3200-PROCESS-DEPOSITS-X.
           EXIT.
      *
      *
      *-----------------
       3300-DEPOSITS-FA.
      *-----------------

           MOVE RPHST-POL-ID             TO WFA-POL-ID.
           MOVE RPHST-CVG-NUM            TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.
           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF  NOT WFA-IO-OK
               GO TO 3300-DEPOSITS-FA-X
           END-IF.

           MOVE RPHST-POL-ID            TO WCDSA-POL-ID.

           IF  WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
               SET WCDSA-CDA-TYP-SIDFND TO TRUE
           ELSE
               SET WCDSA-CDA-TYP-DPOS   TO TRUE
           END-IF.

           MOVE RFA-POL-PAYO-NUM        TO WCDSA-POL-PAYO-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE RFA-CDA-SEQ-NUM         TO WCDSA-CDA-SEQ-NUM.

           IF  WCDSA-KEY = WS-SAVE-CDSA-KEY
               SET WS-CDSA-REC-FOUND    TO TRUE
               GO TO 3300-DEPOSITS-FA-X
           END-IF.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.

           IF  NOT WCDSA-IO-OK
               PERFORM  3310-FA-TO-MIR
                   THRU 3310-FA-TO-MIR-X
               GO TO 3300-DEPOSITS-FA-X
           END-IF.

           SET WS-CDSA-REC-FOUND        TO TRUE.

       3300-DEPOSITS-FA-X.
           EXIT.

       3310-FA-TO-MIR.

           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE RFA-FRST-FIA-FND-ID    TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           MOVE ZERO                   TO WS-CLI-TRXN-AMT.

           PERFORM  3315-READ-FD
               THRU 3315-READ-FD-X
               UNTIL WFD-FND-ID = SPACE.

           MOVE RFA-CIA-EFF-DT         TO WS-TRXN-EFF-DT.
           MOVE WS-CLI-TRXN-AMT        TO WS-TRXN-GRS-AMT.

           PERFORM  3600-DEPOSITS-TO-MIR
               THRU 3600-DEPOSITS-TO-MIR-X.

       3310-FA-TO-MIR-X.
           EXIT.

       3315-READ-FD.

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF  NOT WFD-IO-OK
               MOVE SPACES             TO WFD-FND-ID
               GO TO 3315-READ-FD-X
           END-IF.

           COMPUTE WS-CLI-TRXN-AMT = WS-CLI-TRXN-AMT
020469*                            + RFD-FIA-FND-TRXN-AMT
020469*                            + RFD-FIA-LOAD-AMT.
020469                             + RFD-FIA-ORIG-TRXN-AMT
020469                             + RFD-FIA-ORIG-LOAD-AMT.

           MOVE RFD-NXT-FIA-FND-ID     TO WFD-FND-ID.

       3315-READ-FD-X.
           EXIT.
      *
      *------------------
       3400-DEPOSITS-CFLW.
      *------------------

           MOVE RPHST-POL-ID                 TO WCFLW-POL-ID.
           MOVE RPHST-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT TO WS-SEQ
           END-IF.

           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF  NOT WCFLW-IO-OK
               GO TO 3400-DEPOSITS-CFLW-X
           END-IF.

           MOVE RPHST-POL-ID             TO WCDSA-POL-ID.

           IF  WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
               SET WCDSA-CDA-TYP-SIDFND TO TRUE
           ELSE
               SET WCDSA-CDA-TYP-DPOS   TO TRUE
           END-IF.

           MOVE RCFLW-SRC-POL-PAYO-NUM   TO WCDSA-POL-PAYO-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE RCFLW-SRC-CDA-SEQ-NUM    TO WCDSA-CDA-SEQ-NUM.

           IF  WCDSA-KEY = WS-SAVE-CDSA-KEY
               SET WS-CDSA-REC-FOUND     TO TRUE
               GO TO 3400-DEPOSITS-CFLW-X
           END-IF.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.

           IF  NOT WCDSA-IO-OK
               PERFORM  3410-CFLW-TO-MIR
                   THRU 3410-CFLW-TO-MIR-X
               GO TO 3400-DEPOSITS-CFLW-X
           END-IF.

           SET WS-CDSA-REC-FOUND         TO TRUE.

       3400-DEPOSITS-CFLW-X.
           EXIT.

       3410-CFLW-TO-MIR.

           IF  RCFLW-CF-REVRS-PRCES-DT = WWKDT-ZERO-DT
               MOVE RCFLW-CF-CLI-TRXN-AMT TO WS-CLI-TRXN-AMT
           ELSE
               COMPUTE WS-CLI-TRXN-AMT = RCFLW-CF-CLI-TRXN-AMT
                                       * -1
           END-IF.

           MOVE RCFLW-CF-EFF-DT          TO WS-TRXN-EFF-DT.
           MOVE WS-CLI-TRXN-AMT          TO WS-TRXN-GRS-AMT.

           PERFORM  3600-DEPOSITS-TO-MIR
               THRU 3600-DEPOSITS-TO-MIR-X.

       3410-CFLW-TO-MIR-X.
           EXIT.

      *---------------------
       3600-DEPOSITS-TO-MIR.
      *---------------------

           MOVE WS-TRXN-EFF-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                TO MIR-DV-FIN-TRXN-EFF-DT-T (WS-SUB).


           EVALUATE TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4009'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5000'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4009'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5000'
                    IF WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
                       SET WS-TRXN-TYP-SDP    TO TRUE
                    ELSE
                       SET WS-TRXN-TYP-DEP    TO TRUE
                    END-IF

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4012'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4013'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4012'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4013'
                    SET WS-TRXN-TYP-IPD       TO TRUE

           END-EVALUATE.

           MOVE WS-TRXN-TYP-ID  TO MIR-DV-FIN-TRXN-TYP-CD-T (WS-SUB).


020874*    COMPUTE L0290-INPUT-NUMBER = WS-TRXN-GRS-AMT * 100.
020874     MOVE WS-TRXN-GRS-AMT          TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                                TO MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB).


030054*    MOVE WS-SAVE-PCHST-STAT-CD
030054     MOVE HPHST-PCHST-STAT-CD
                                TO MIR-DV-FIN-TRXN-STAT-CD-T (WS-SUB).


020874*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO L0290-INPUT-NUMBER.
030054*    MOVE WS-SAVE-PCHST-SEQ-NUM    TO L0290-INPUT-V00.
030054     MOVE HPHST-PCHST-SEQ-NUM      TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
021657*    MOVE LENGTH OF MIR-DV-FIRST-SEQ-NUM-T (WS-SUB)
021657     MOVE LENGTH OF MIR-DV-FIN-TRXN-SEQ-NUM-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
021657*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-FIRST-SEQ-NUM-T (WS-SUB).
021657     MOVE L0290-OUTPUT-DATA TO MIR-DV-FIN-TRXN-SEQ-NUM-T (WS-SUB).

           ADD +1                    TO WS-SUB.

       3600-DEPOSITS-TO-MIR-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-WEALTH-ACCUM-NO    TO TRUE.
025970     SET WS-MAX-LINE-DEFAULT   TO TRUE.
025970
025970     MOVE SPACES               TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970     MOVE SPACES               TO MIR-OUTPUT-AREA.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      *
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      *
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNCVG.
       COPY CCPBPHST.
       COPY SCPNFA.
       COPY SCPNFD.
       COPY CCPNCFLW.
       COPY CCPNCDSA.
021930*COPY CCPBCDSD.
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM7712                        **
      *****************************************************************
