      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM2291.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM2291                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE DOCS TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
025244**  6.6       ADDED STANDARD MESSAGE                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM2291'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-CREATE            VALUE '2291'.
           05  WS-DOCSTC-GR-ID                  PIC X(99).
           05  WS-DBSRL-PARNT-TBL-ID            PIC X(04).
           05  WS-DBSRL-CHILD-TBL-ID            PIC X(04).
       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT         VALUE '2291'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
       COPY XCWL2299.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY XCFWDOCS.
       COPY XCFRDOCS.
       
       COPY XCFWDBRL.
       COPY XCFRDBRL.
       
       COPY XCFRXTAB.
       COPY XCFWXTAB.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM2291.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2291'      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'    TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                         TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------
      
      *
      *  CHECK DOCUMENT STRUCTURE ID EXISTS ON XTAB
      *

           MOVE MIR-DOCSTC-ID            TO WXTAB-ETBL-VALU-ID.

           PERFORM  DSID-1000-EDIT-DOCS-ST-ID
               THRU DSID-1000-EDIT-DOCS-ST-ID-X.

           IF WXTAB-IO-OK
               CONTINUE
           ELSE
      *MSG: INVALID STRUCTURE ID (@1).  CHECK SECURITY EDIT TYPE
      *     'DSID'.
               MOVE 'XS22910001'         TO WGLOB-MSG-REF-INFO
               MOVE WXTAB-ETBL-VALU-ID   TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CREATE-X
           END-IF.

      *
      *  CHECK CHILD ID ID EXISTS ON XTAB AND DBRL
      *

           MOVE MIR-DBSRL-ID             TO WXTAB-ETBL-VALU-ID.

           PERFORM  DBRI-1000-EDIT-DBSRL-ID
               THRU DBRI-1000-EDIT-DBSRL-ID-X.

           IF WXTAB-IO-OK
               CONTINUE
           ELSE
      *MSG: INVALID DATABASE RELATIONSHIP ID (@1).  CHECK SECURITY EDIT
      *     TYPE 'DBRID'.
               MOVE 'XS22910002'         TO WGLOB-MSG-REF-INFO
               MOVE WXTAB-ETBL-VALU-ID   TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CREATE-X
           END-IF.
           
           MOVE MIR-DBSRL-ID             TO WDBRL-DBSRL-ID.
           
           PERFORM  DBRL-1000-READ
               THRU DBRL-1000-READ-X.
               
           IF WDBRL-IO-OK
               MOVE RDBRL-DBSRL-PARNT-TBL-ID
                                         TO WS-DBSRL-PARNT-TBL-ID
           ELSE
      *MSG: @2 RECORD (@1) NOT FOUND
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               MOVE WDBRL-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'DBRL'               TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CREATE-X
           END-IF.

      *
      *  CHECK PARENT ID EXISTS ON XTAB AND DBRL
      *
           IF MIR-PARNT-DBSRL-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES TO MIR-PARNT-DBSRL-ID
           END-IF.

           IF  MIR-PARNT-DBSRL-ID = SPACES
               CONTINUE
           ELSE
               MOVE MIR-PARNT-DBSRL-ID   TO WXTAB-ETBL-VALU-ID

               PERFORM  DBRI-1000-EDIT-DBSRL-ID
                   THRU DBRI-1000-EDIT-DBSRL-ID-X

               IF  WXTAB-IO-OK
                   CONTINUE
               ELSE
      *MSG: INVALID PARENT DATABASE RELATIONSHIP ID (@1).  CHECK
      *     SECURITY EDIT TYPE 'DBRID'.
                   MOVE 'XS22910003'     TO WGLOB-MSG-REF-INFO
                   MOVE WXTAB-ETBL-VALU-ID 
                                         TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-CREATE-X
               END-IF
               
               MOVE MIR-PARNT-DBSRL-ID   TO WDBRL-DBSRL-ID
           
               PERFORM  DBRL-1000-READ
                   THRU DBRL-1000-READ-X
               
               IF WDBRL-IO-OK
                   MOVE RDBRL-DBSRL-CHILD-TBL-ID
                                         TO WS-DBSRL-CHILD-TBL-ID
               ELSE
      *MSG: @2 RECORD (@1) NOT FOUND
                   MOVE 'XS00000001'     TO WGLOB-MSG-REF-INFO
                   MOVE WDBRL-KEY        TO WGLOB-MSG-PARM (1)
                   MOVE 'DBRL'           TO WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-CREATE-X
               END-IF
           END-IF.
           
      *
      *  THE PARENT RECORD SHOULD EXIST ON A CREATE
      *
      
           IF  MIR-PARNT-DBSRL-ID = SPACES
               MOVE ZEROES               TO WS-DOCSTC-GR-ID
           ELSE
               MOVE LOW-VALUES           TO WDOCS-KEY
               MOVE MIR-DOCSTC-ID        TO WDOCS-DOCSTC-ID
               MOVE MIR-PARNT-DBSRL-ID   TO WDOCS-DBSRL-ID

               PERFORM  DOCS-1000-READ
                   THRU DOCS-1000-READ-X

               IF  WDOCS-IO-OK
                   CONTINUE
               ELSE
      *MSG: PARENT DATABASE RELATIONSHIP ID (@1) DOES NOT EXIST ON
      *     DOCUMENT STRUCTURE TABLE.
                   MOVE WDOCS-KEY        TO WGLOB-MSG-PARM (1)
                   MOVE 'XS22910005'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-CREATE-X
               END-IF
               MOVE RDOCS-DOCSTC-GR-ID   TO WS-DOCSTC-GR-ID
           END-IF.
           
      *
      *  THE CHILD TABLE BELONGING TO THE PARENT RELATIONSHIP MUST BE
      *  THE SAME AS THE PARENT TABLE OF THE NEW, CHILD RELATIONSHIP
      *
      
           IF WS-DBSRL-PARNT-TBL-ID = WS-DBSRL-CHILD-TBL-ID
               CONTINUE
           ELSE
      *MSG: CHILD TABLE OF THE PARENT RELATIONSHIP (@1) MUST BE THE 
      *     SAME AS THE PARENT TABLE OF THE CHILD RELATIONSHIP (@2).
               MOVE 'XS22910006'         TO WGLOB-MSG-REF-INFO
               MOVE WS-DBSRL-CHILD-TBL-ID
                                         TO WGLOB-MSG-PARM (1)
               MOVE WS-DBSRL-PARNT-TBL-ID
                                         TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CREATE-X
           END-IF.
           
      *
      *  THE CHILD RECORD SHOULD NOT EXIST ON A CREATE
      *
      
           MOVE LOW-VALUES               TO WDOCS-KEY.
           MOVE MIR-DOCSTC-ID            TO WDOCS-DOCSTC-ID.
           MOVE MIR-DBSRL-ID             TO WDOCS-DBSRL-ID.

           PERFORM  DOCS-1000-READ
               THRU DOCS-1000-READ-X.

           IF  WDOCS-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE WDOCS-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CREATE-X
           END-IF.
           
      *
      *  CALL MODULE TO CALCULATE THE GROUP-ID AND SEQUENCE NUMBER
      *

           MOVE MIR-DOCSTC-ID            TO L2299-DOCSTC-ID.
           MOVE MIR-PARNT-DBSRL-ID       TO L2299-PARNT-DBSRL-ID.
           MOVE WS-DOCSTC-GR-ID          TO L2299-DOCSTC-GR-ID.  

           PERFORM  2299-1000-GEN-GRP-ID
               THRU 2299-1000-GEN-GRP-ID-X.
               
           IF  L2299-RETRN-OK
               CONTINUE
           ELSE
      *MSG: 'AN ERROR OCCURRED CALCULATING THE GROUP ID AND SEQUENCE
      *      NUMBER'
               MOVE 'XS22910004'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
      *  LOAD UP AND WRITE OUT NEW RECORD TO DOCS TABLE
      *
           MOVE MIR-DOCSTC-ID            TO WDOCS-DOCSTC-ID.
           MOVE MIR-DBSRL-ID             TO WDOCS-DBSRL-ID.
           
           PERFORM  DOCS-1000-CREATE
               THRU DOCS-1000-CREATE-X.
               
           MOVE MIR-PARNT-DBSRL-ID       TO RDOCS-PARNT-DBSRL-ID.
           MOVE L2299-DOCSTC-SEQ-NUM     TO RDOCS-DOCSTC-SEQ-NUM.
           MOVE L2299-DOCSTC-GR-ID       TO RDOCS-DOCSTC-GR-ID.

           PERFORM  DOCS-1000-WRITE
               THRU DOCS-1000-WRITE-X.

      *  UPDATE THE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  DOCS-1000-READ-TWRK-TS
               THRU DOCS-1000-READ-TWRK-TS-X.

025244*MSG: 'RECORD CREATED - CONTINUE'
025244     MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
025244     PERFORM  0260-1000-GENERATE-MESSAGE
025244         THRU 0260-1000-GENERATE-MESSAGE-X.
025244               
           MOVE L2299-DOCSTC-SEQ-NUM     TO MIR-DOCSTC-SEQ-NUM.
           MOVE L2299-DOCSTC-GR-ID       TO MIR-DOCSTC-GR-ID.

       2000-CREATE-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
025970     PERFORM  2299-0000-INIT-PARM-INFO
025970         THRU 2299-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE MIR-OUTPUT-AREA.

           MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
025970     SET  WS-TWRK-KEY-DEFAULT      TO TRUE.
           
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPEDSID.
       COPY XCPEDBRI.
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  DOCS
                                '$VAR2'   BY 'DOCS'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
       COPY XCPL2299.
025970 COPY XCPS8090.
       COPY XCPS2299.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY XCPADOCS.
       COPY XCPCDOCS.
       COPY XCPNDOCS.
       COPY XCPUDOCS.
      
       COPY XCPNDBRL.
       
       COPY XCPNXTAB. 
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM 'XSOM2291'                   **
      *****************************************************************
