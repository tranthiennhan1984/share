      ********************************************************
      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. SSOM1734.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1734                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE FS TABLE                                 **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016679**  6.2       NEW PROCESS DRIVER                               **
015944**  6.3       REDUCE FUNDS PER COVERAGE TO 25 (DEFAULT MAX)    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019440**  6.3       FIX FUND INQUIRY FOR MISSING VALUES              **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020618**  6.4       INITIALIZATION                                   **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
021239**  6.4       FUND UNIT VALUE                                  **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023339**  6.5       WORKING STORAGE INITIALIZATION                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024526**  6.5       INCORRECT FUND ALLOCATION BEING DISPLAYED        **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034302**  7.1       FUND INQUIRY ACTIVITY PAGES NOT DISPLAY 98 FUND  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1734'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.

      /
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES         PIC S9(03) BINARY.
034302*        88  WS-MAX-LIST-LINES-DEFAULT   VALUE 25.
034302         88  WS-MAX-LIST-LINES-DEFAULT   VALUE 98.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID             PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '1734'.
           05  WS-SUB                    PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES         PIC S9(03) BINARY
025970*                                              VALUE 25.
015944*                                              VALUE 129.
           05  WS-FA-SW                  PIC X(01).
               88 WS-DONE-FA                VALUE 'Y'.

       01  WS-WORK-AREAS.
           05  EDIT-ZZ9-9999             PIC ZZ9.9999.
           05  EDIT-SZZ9-999999          PIC ---9.9(06).
           05  EDIT-999                  PIC 999.
           05  WS-POL-ID.
               10  WS-POL-ID-BASE        PIC X(09).
               10  WS-POL-ID-SFX         PIC X(01).
           05  WS-HOLD-TRN               PIC X(03).
           05  HOLD-EFFDT                PIC X(10).
           05  EFFDT-I                   PIC X(10).
           05  WS-HOLD-IDT-NUM           PIC X(07).
           05  WS-HOLD-IDT-NUM-N         REDEFINES
               WS-HOLD-IDT-NUM           PIC 9(07).
           05  HOLD-SEQ                  PIC 9(03).
           05  HOLD-SEQ-X  REDEFINES  HOLD-SEQ  PIC X(3).

       01  SAVE-POLICY-NUMBER-AREAS.
           05  POLICY-HOLD.
               10  POLICY-BASE.
                   15  POLICY-FIRST   PIC X(01).
                   15  POLICY-MID     PIC X(08).
               10  POLICY-LAST        PIC X(01).
           05  HOLD-COV               PIC 9(02).
           05  HOLD-COV-A REDEFINES HOLD-COV        PIC X(02).

       01  KEY-WORK-AREAS.
           05  WK-SEQ                    PIC 9(4)   BINARY.
           05  WK-NEXT-FUND              PIC X(5).
           05  WK-FS-HIGH-KEY.
               10  FILLER                PIC X(14).
               10  WK-FS-HIGH-FUND       PIC X(05).
           05  WK-FA-HIGH-KEY.
               10  FILLER                PIC X(14).
               10  WK-FA-HIGH-EFF-DT     PIC X(7).
               10  WK-FA-HIGH-SEQ-NUM    PIC S9(4)  BINARY.
           05  WK-FD-HIGH-KEY.
               10  FILLER                PIC X(14).
               10  WK-FD-HIGH-FUND       PIC X(5).
               10  WK-FD-HIGH-DATE       PIC 9(7).
               10  WK-FD-HIGH-SEQ        PIC 9(4)    BINARY.
           05  CARRY-OVER-SW             PIC 9.
               88  CARRY-OVER                        VALUE 1.
           05  WS-SIGN6-G.
               10  WS-SIGN6-T         OCCURS  139
                                      PIC X(01).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************

026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY SCFWFC.
       COPY SCFRFC.
       COPY SCFWFD.
       COPY SCFRFD.
       COPY SCFWFS.
       COPY SCFRFS.
       COPY SCFWFA.
       COPY SCFRFA.
       COPY CCFWPOL.
       COPY CCFRPOL.
021930*COPY CCFRPOLC.
021930*COPY CCFREDIT.
021930*COPY CCFWEDIT.
021930*COPY XCFRXTAB.
021930*COPY XCFWXTAB.
021930*COPY XCFRCRCY.
021930*COPY XCFWCRCY.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************

028298 COPY CCWL2626.
       COPY CCWL5400.
       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL0280.
021930*COPY CCWL2440.
021930*COPY CCWL0620.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
020469 COPY XCWL8640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1734.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

020618     MOVE SPACE                TO WS-FA-SW.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  2200-MOVE-DATA-TO-TWA
               THRU 2200-MOVE-DATA-TO-TWA-X.

           MOVE MIR-CIA-SEQ-NUM      TO HOLD-SEQ-X.
           MOVE MIR-CIA-TYP-CD       TO WS-HOLD-TRN.
           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
      *
      *  VALIDATE / CHECK POLICY ACCESS
      *
           PERFORM  2100-VALIDATE-POLICY
               THRU 2100-VALIDATE-POLICY-X.


           IF  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE EFFDT-I               TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WGLOB-RETURN-ERROR     TO TRUE
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 1000-PROCESS-REQUEST-X
026057     END-IF.

           PERFORM  2500-NOW-GET-FUND
               THRU 2500-NOW-GET-FUND-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2600-NEXT-TEST-TRANS
               THRU 2600-NEXT-TEST-TRANS-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM1734'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'SS17340003'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------


           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           COMPUTE WK-SEQ = 1000 - HOLD-SEQ.
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  FA-1000-BROWSE
               THRU FA-1000-BROWSE-X.

           IF WFD-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE     TO WFD-CO-ID
           ELSE
               MOVE SPACES                 TO WFD-CO-ID
           END-IF.

           PERFORM  4000-SETUP-READS
               THRU 4000-SETUP-READS-X.

           IF WGLOB-RETURN-ERROR
               PERFORM  FA-3000-END-BROWSE
                   THRU FA-3000-END-BROWSE-X
               GO TO 2000-LIST-X
           END-IF.

           MOVE 1                          TO WS-SUB.
           IF WFS-IO-OK
               PERFORM  4100-PROCESS-TRAN
                   THRU 4100-PROCESS-TRAN-X
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
024526*        OR      WFS-IO-EOF
024526         OR     (WFS-IO-EOF AND
024526                 WK-NEXT-FUND = SPACES)
               OR      WFD-IO-EOF
           END-IF.

034302*    IF  WFS-IO-EOF
034302*    AND WK-NEXT-FUND = SPACES
034302*MSG:    MESSAGE "** END OF LIST **"
034302*        MOVE 'XS00000015'
034302*          TO WGLOB-MSG-REF-INFO
034302*        PERFORM 0260-1000-GENERATE-MESSAGE
034302*           THRU 0260-1000-GENERATE-MESSAGE-X
034302*    ELSE
034302*        SET WGLOB-MORE-DATA-EXISTS
034302*          TO TRUE
034302*MSG:    MESSAGE "** TO VIEW MORE DATA PRESS ENTER **"
034302*        MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
034302*        PERFORM  0260-1000-GENERATE-MESSAGE
034302*            THRU 0260-1000-GENERATE-MESSAGE-X
034302*        MOVE RFD-CVG-NUM           TO MIR-CVG-NUM
034302*        MOVE RFD-POL-ID            TO WS-POL-ID
034302*        MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE
034302*        MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX
034302*    END-IF.

           COMPUTE HOLD-SEQ = 1000 - RFA-CIA-SEQ-NUM.
           MOVE HOLD-SEQ-X                TO MIR-CIA-SEQ-NUM.

           PERFORM  FS-3000-END-BROWSE
               THRU FS-3000-END-BROWSE-X.
           PERFORM  FA-3000-END-BROWSE
               THRU FA-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.

      /
      *---------------------
       2100-VALIDATE-POLICY.
      *---------------------

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2100-VALIDATE-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET  L5400-STAT-MSG-NOT-REQD TO TRUE.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  NOT L5400-RETRN-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       2100-VALIDATE-POLICY-X.
           EXIT.
      /
      *----------------------
       2200-MOVE-DATA-TO-TWA.
      *----------------------

           MOVE MIR-POL-ID-BASE       TO POLICY-BASE.
           MOVE MIR-POL-ID-SFX        TO POLICY-LAST.
           MOVE POLICY-HOLD           TO WFC-POL-ID.
           MOVE ZERO                  TO WFC-IO-STATUS.
023339     SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
023339     SET L0280-SPACES-PERMITTED     TO TRUE.
023339     MOVE ZERO                      TO L0280-PRECISION.
023339     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-LENGTH.
023339     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-INPUT-SIZE.
023339     MOVE MIR-CVG-NUM               TO L0280-INPUT-DATA.
023339
023339     PERFORM  0280-1000-NUMERIC-EDIT
023339         THRU 0280-1000-NUMERIC-EDIT-X.
023339
023339     IF  L0280-OK
023339         AND L0280-OUTPUT-V00 NOT = ZERO
023339         MOVE L0280-OUTPUT-V00      TO WFC-CVG-NUM-N
023339     ELSE
023339         MOVE '01'                  TO WFC-CVG-NUM
023339     END-IF.
023339
023339*    MOVE MIR-CVG-NUM           TO HOLD-COV-A.
023339*    SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
023339*    MOVE '2'                   TO L0280-LENGTH.
023339*    MOVE '0'                   TO L0280-PRECISION.
023339*    MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.
023339*    PERFORM  0280-1000-NUMERIC-EDIT
023339*        THRU 0280-1000-NUMERIC-EDIT-X.
023339*
023339*    IF L0280-OK
023339*        MOVE L0280-OUTPUT      TO HOLD-COV
023339*    END-IF.
023339*
023339*    IF (HOLD-COV-A NOT NUMERIC)
023339*    OR (HOLD-COV-A = '00')
023339*        MOVE '01'              TO HOLD-COV-A
023339*    END-IF.
023339*
023339*    MOVE HOLD-COV-A            TO WFC-CVG-NUM-N.
           MOVE MIR-CIA-EFF-DT        TO HOLD-EFFDT.
           MOVE MIR-CIA-TYP-CD        TO WS-HOLD-TRN.
           MOVE MIR-CIA-SEQ-NUM       TO HOLD-SEQ-X.
           MOVE HIGH-VALUES           TO WFC-ENDBR-KEY.
           IF  (HOLD-SEQ-X NOT NUMERIC)
           OR  (HOLD-SEQ-X = ZEROES)
               MOVE '999'             TO HOLD-SEQ-X
           END-IF.

           MOVE HOLD-EFFDT            TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO EFFDT-I
           ELSE
               MOVE WWKDT-ZERO-DT     TO EFFDT-I
           END-IF.

       2200-MOVE-DATA-TO-TWA-X.
           EXIT.

      *------------------
       2500-NOW-GET-FUND.
      *------------------

           PERFORM  FC-1000-READ
               THRU FC-1000-READ-X.

           IF NOT WFC-IO-OK
               MOVE 'SS17340007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2500-NOW-GET-FUND-X.
           EXIT.

      *---------------------
       2600-NEXT-TEST-TRANS.
      *---------------------

           MOVE RFC-INV-CVG-STAT-CD   TO MIR-CFN-STAT-CD.


           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '0'                   TO L0280-PRECISION.
024526     MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE HOLD-SEQ-X            TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO HOLD-SEQ
           END-IF.

           IF (HOLD-SEQ NOT NUMERIC)
           OR (HOLD-SEQ = 0)
               MOVE 999               TO HOLD-SEQ
           END-IF.

       2600-NEXT-TEST-TRANS-X.
           EXIT.
      /
       4000-SETUP-READS.

           PERFORM  4520-FIND-NEXT-FA-RECORD
               THRU 4520-FIND-NEXT-FA-RECORD-X
               UNTIL WS-DONE-FA
               OR WFA-IO-EOF.

           IF  WFA-IO-EOF
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-SETUP-READS-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4000-SETUP-READS-X
           END-IF.

      ***** SET UP FS/FD KEY AND HIGH KEY AS MUCH AS POSSIBLE *****

           MOVE LOW-VALUES            TO WFD-KEY.
           MOVE RFA-POL-ID            TO WFS-POL-ID.
           MOVE RFA-POL-ID            TO WFD-POL-ID.
           MOVE RFA-CVG-NUM-N         TO WFS-CVG-NUM-N.
           MOVE RFA-CVG-NUM-N         TO WFD-CVG-NUM-N.
           MOVE RFA-CIA-IDT-NUM       TO WFD-FIA-IDT-NUM.
           MOVE HIGH-VALUES           TO WFS-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WFD-ENDBR-KEY.
           MOVE RFA-CIA-IDT-NUM       TO WFD-ENDBR-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM       TO WFD-ENDBR-FIA-SEQ-NUM.
           MOVE RFA-CVG-NUM           TO WFS-ENDBR-CVG-NUM.

           IF WFS-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE TO WFS-CO-ID
           ELSE
               MOVE SPACES            TO WFS-CO-ID
           END-IF.

           IF WFD-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE TO WFD-CO-ID
           ELSE
               MOVE SPACES            TO WFD-CO-ID
           END-IF.

           MOVE LOW-VALUES            TO WFD-FND-ID.

           MOVE RFA-FRST-FIA-FND-ID   TO WK-NEXT-FUND.
           MOVE LOW-VALUES            TO WFS-FND-ID.

           MOVE WFS-KEY               TO WK-FS-HIGH-KEY.
           MOVE HIGH-VALUES           TO WK-FS-HIGH-FUND.
           MOVE WK-FS-HIGH-KEY        TO WFS-ENDBR-KEY.

           MOVE WFD-KEY               TO WK-FD-HIGH-KEY.
           MOVE +9999999              TO WK-FD-HIGH-DATE.
           MOVE +999                  TO WK-FD-HIGH-SEQ.

           PERFORM  FS-1000-BROWSE
               THRU FS-1000-BROWSE-X.

       4000-SETUP-READS-X.
           EXIT.

       4100-PROCESS-TRAN.


024526*    PERFORM  FS-2000-READ-NEXT
024526*        THRU FS-2000-READ-NEXT-X.

024526     IF  WFS-IO-EOF
024526         MOVE WK-NEXT-FUND      TO RFS-FND-ID
024526     ELSE
024526         PERFORM  FS-2000-READ-NEXT
024526             THRU FS-2000-READ-NEXT-X
024526     END-IF.

           IF WFS-IO-EOF
024526     AND WK-NEXT-FUND = SPACES
               GO TO 4100-PROCESS-TRAN-X
           END-IF.

           MOVE RFA-CIA-IDT-NUM-N     TO WFD-FIA-IDT-NUM-N.
           MOVE RFA-CIA-SEQ-NUM       TO WFD-FIA-SEQ-NUM.

           IF (RFS-FND-ID   < WK-NEXT-FUND)
             OR (WK-NEXT-FUND = SPACES)
               MOVE RFS-FND-ID        TO WFD-FND-ID
               MOVE RFS-FND-ID        TO WK-FD-HIGH-FUND
               PERFORM  4530-FIND-MOST-RECENT-FD
                   THRU 4530-FIND-MOST-RECENT-FD-X
               SET RFD-FIA-UNIT-STAT-NOT-STRT TO TRUE
021239*        MOVE 0                 TO RFD-FIA-INTG-AUNIT-QTY
021239*        MOVE 0                 TO RFD-FIA-DCML-AUNIT-QTY
021239*        MOVE 0                 TO RFD-FIA-INTG-IUNIT-QTY
021239*        MOVE 0                 TO RFD-FIA-DCML-IUNIT-QTY
               GO TO 4100-PROCESS-TRAN-X
           ELSE
               MOVE WK-NEXT-FUND      TO WFD-FND-ID
               PERFORM  4540-FIND-EXACT-FD
                   THRU 4540-FIND-EXACT-FD-X
               MOVE ZERO              TO CARRY-OVER-SW
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4100-PROCESS-TRAN-X
           END-IF.

           IF  (RFD-FIA-IDT-NUM = WS-HOLD-IDT-NUM
           AND (RFD-FIA-SEQ-NUM = HOLD-SEQ
           OR RFD-FIA-SEQ-NUM = RFA-CIA-SEQ-NUM))
               CONTINUE
           ELSE
               GO TO 4100-PROCESS-TRAN-X
           END-IF.

           IF CARRY-OVER
               MOVE ZERO          TO EDIT-ZZ9-9999
020874*        MOVE 0             TO L0290-INPUT-NUMBER
020874         MOVE ZERO          TO L0290-INPUT-V02
               MOVE 2             TO L0290-PRECISION
               MOVE LENGTH OF MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
020874*        MOVE 0             TO L0290-INPUT-NUMBER
020874         MOVE ZERO          TO L0290-INPUT-V02
               MOVE 2             TO L0290-PRECISION
               MOVE LENGTH OF MIR-DV-TOT-FIA-FND-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-DV-TOT-FIA-FND-AMT-T (WS-SUB)
020874*        MOVE 0             TO L0290-INPUT-NUMBER
020874         MOVE ZERO          TO L0290-INPUT-V02
               MOVE 2             TO L0290-PRECISION
               MOVE LENGTH OF MIR-FIA-PEND-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY   TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA   TO MIR-FIA-PEND-AMT-T (WS-SUB)
020874*        MOVE 0             TO L0290-INPUT-NUMBER
020874         MOVE ZERO          TO L0290-INPUT-V02
               MOVE 2             TO L0290-PRECISION
               MOVE LENGTH OF MIR-PEND-DPOS-INT-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY   TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-PEND-DPOS-INT-AMT-T (WS-SUB)
           ELSE
               MOVE 0             TO L0290-INPUT-NUMBER
020874*        COMPUTE L0290-INPUT-NUMBER = RFD-FIA-FND-TRXN-AMT * 100
020874         MOVE RFD-FIA-FND-TRXN-AMT TO L0290-INPUT-V02
               MOVE 2             TO L0290-PRECISION
               MOVE LENGTH OF MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-FIA-FND-TRXN-AMT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RFD-PEND-DPOS-INT-AMT * 100
020874         MOVE RFD-PEND-DPOS-INT-AMT TO L0290-INPUT-V02
               MOVE 2             TO L0290-PRECISION
               MOVE LENGTH OF MIR-PEND-DPOS-INT-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-PEND-DPOS-INT-AMT-T (WS-SUB)
               COMPUTE RFD-FIA-FND-TRXN-AMT
                       = RFD-FIA-FND-TRXN-AMT + RFD-PEND-DPOS-INT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFD-FIA-FND-TRXN-AMT * 100
020874         MOVE RFD-FIA-FND-TRXN-AMT TO L0290-INPUT-V02
               MOVE 2             TO L0290-PRECISION
               MOVE LENGTH OF MIR-DV-TOT-FIA-FND-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-DV-TOT-FIA-FND-AMT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = RFD-FIA-PEND-AMT * 100
020874         MOVE RFD-FIA-PEND-AMT      TO L0290-INPUT-V02
               MOVE 2             TO L0290-PRECISION
               MOVE LENGTH OF MIR-FIA-PEND-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA   TO MIR-FIA-PEND-AMT-T (WS-SUB)
           END-IF.

           MOVE RFD-FND-ID        TO MIR-FND-ID-T (WS-SUB).

020469     PERFORM  8640-1000-BUILD-PARM-INFO
020469         THRU 8640-1000-BUILD-PARM-INFO-X.
020469
020469     MOVE RFD-FND-ID        TO L8640-FND-ID.
020469
020469     PERFORM  8640-1000-GET-FND-CRCY-CD
020469         THRU 8640-1000-GET-FND-CRCY-CD-X.
020469
020469     IF  NOT L8640-RETRN-OK
020469*MSG: CURRENCY CODE NOT FOUND FOR FUND @1
020469         MOVE 'SS17340001'      TO WGLOB-MSG-REF-INFO
020469         MOVE L8640-FND-ID      TO WGLOB-MSG-PARM (1)
020469         PERFORM  0260-1000-GENERATE-MESSAGE
020469             THRU 0260-1000-GENERATE-MESSAGE-X
020469     ELSE
020469         MOVE L8640-FND-CRCY-CD TO MIR-FIA-CRCY-CD-T (WS-SUB)
020469     END-IF.
020469
           ADD 1                  TO WS-SUB.

       4100-PROCESS-TRAN-X.
           EXIT.
      /

      *-------------------------
       4520-FIND-NEXT-FA-RECORD.
      *-------------------------


           PERFORM  FA-2000-READ-NEXT
               THRU FA-2000-READ-NEXT-X.

019440     IF MIR-CIA-TYP-CD = SPACE
019440        MOVE RFA-CIA-TYP-CD TO MIR-CIA-TYP-CD
019440     END-IF.
019440
019440     MOVE RFC-INV-CVG-STAT-CD TO MIR-CFN-STAT-CD.
019440
           IF NOT WFA-IO-OK
               MOVE 'SS17340004'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               SET WS-DONE-FA   TO TRUE
               GO TO 4520-FIND-NEXT-FA-RECORD-X
           END-IF.

           IF (HOLD-SEQ-X NOT NUMERIC)
               IF (HOLD-SEQ-X NOT = LOW-VALUES
                                AND SPACES)
                   MOVE 'SS17340006'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-DONE-FA     TO TRUE
                   GO TO 4520-FIND-NEXT-FA-RECORD-X
               END-IF
           END-IF.


           IF WS-HOLD-TRN = SPACES
                      OR LOW-VALUES
               SET WS-DONE-FA    TO TRUE
               GO TO 4520-FIND-NEXT-FA-RECORD-X
           END-IF.

           IF WS-HOLD-TRN = RFA-CIA-TYP-CD
               SET WS-DONE-FA    TO TRUE
               GO TO 4520-FIND-NEXT-FA-RECORD-X
           END-IF.

       4520-FIND-NEXT-FA-RECORD-X.
           EXIT.
      /
      *-------------------------
       4530-FIND-MOST-RECENT-FD.
      *-------------------------

           PERFORM  FD-1000-BROWSE
               THRU FD-1000-BROWSE-X.

           IF WFD-IO-EOF
               PERFORM  4535-FIND-MOST-RCNT-FD-CONT
                   THRU 4535-FIND-MOST-RCNT-FD-CONT-X
               GO TO 4530-FIND-MOST-RECENT-FD-X
           END-IF.

           PERFORM  FD-2000-READ-NEXT
               THRU FD-2000-READ-NEXT-X.

           IF NOT WFD-IO-OK
               PERFORM  4535-FIND-MOST-RCNT-FD-CONT
                   THRU 4535-FIND-MOST-RCNT-FD-CONT-X
           END-IF.

           PERFORM  FD-3000-END-BROWSE
               THRU FD-3000-END-BROWSE-X.


       4530-FIND-MOST-RECENT-FD-X.
           EXIT.
      /
      *----------------------------
       4535-FIND-MOST-RCNT-FD-CONT.
      *----------------------------

           MOVE RFS-FND-ID            TO RFD-FND-ID.
021239*    MOVE 0                     TO RFD-CFN-INTG-AUNIT-QTY.
021239*    MOVE 0                     TO RFD-CFN-DCML-AUNIT-QTY.
021239*    MOVE 0                     TO RFD-FIA-AUNIT-PRIC-AMT.
021239*    MOVE 0                     TO RFD-CFN-INTG-IUNIT-QTY.
021239*    MOVE 0                     TO RFD-CFN-DCML-IUNIT-QTY.
021239*    MOVE 0                     TO RFD-FIA-IUNIT-PRIC-AMT.
           MOVE 0                     TO RFD-CFN-TRXN-LTD-AMT.
           MOVE 0                     TO RFD-CFN-LOAD-LTD-AMT.
           MOVE 0                     TO RFD-CFN-INT-LTD-AMT.
           MOVE 0                     TO RFD-CFN-PEND-LTD-AMT.

       4535-FIND-MOST-RCNT-FD-CONT-X.
           EXIT.

      *-------------------
       4540-FIND-EXACT-FD.
      *-------------------

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF NOT WFD-IO-OK
               MOVE 'SS17340005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4540-FIND-EXACT-FD-X
           END-IF.

           MOVE RFD-NXT-FIA-FND-ID    TO WK-NEXT-FUND
           IF NOT RFA-CIA-UNIT-STAT-NOT-STRT
               IF ((RFA-CIA-TYP-CD = 'SUR'
                                  OR 'ADM')
                     AND
                     RFA-CIA-REVRS-STAT-NOT-STRT)
                 OR (RFA-CIA-TYP-CD = 'DEP'
                     AND
                     NOT RFA-CIA-REVRS-STAT-NOT-STRT)
                 OR (RFA-CIA-TYP-CD = 'TRS'
                     AND
                     (RFD-FIA-FND-TRXN-AMT < 0
                        OR RFD-FIA-VALU-SURR-PCT NOT = 0)
                     AND
                     RFA-CIA-REVRS-STAT-NOT-STRT)
                 OR (RFA-CIA-TYP-CD = 'TRS'
                     AND
                     (RFD-FIA-FND-TRXN-AMT > 0
                        OR RFD-FIA-IN-ALLOC-PCT NOT = 0)
                     AND
                     NOT RFA-CIA-REVRS-STAT-NOT-STRT)
                   MOVE '-'           TO WS-SIGN6-T (WS-SUB)
               END-IF
           END-IF.

       4540-FIND-EXACT-FD-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
           MOVE LOW-VALUES             TO WFA-KEY.

           MOVE EFFDT-I                TO L1660-INTERNAL-DATE.
           PERFORM 1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WFA-CIA-IDT-NUM-N.
           MOVE L1660-INVERTED-DATE    TO WS-HOLD-IDT-NUM-N.
           MOVE MIR-POL-ID-BASE        TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WS-POL-ID-SFX.
           MOVE WS-POL-ID              TO WFA-POL-ID.
023339*    MOVE MIR-CVG-NUM            TO WFA-CVG-NUM.
023339     MOVE WFC-CVG-NUM            TO WFA-CVG-NUM.
           MOVE WK-SEQ                 TO WFA-CIA-SEQ-NUM.
           MOVE WFA-KEY                TO WK-FA-HIGH-KEY.
           MOVE +999                   TO WK-FA-HIGH-SEQ-NUM.
           MOVE WK-FA-HIGH-KEY         TO WFA-ENDBR-KEY.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------


           MOVE SPACES                 TO MIR-CFN-STAT-CD.
           MOVE SPACES                 TO MIR-DV-TOT-FIA-FND-AMT-G.
           MOVE SPACES                 TO MIR-FND-ID-G.
           MOVE SPACES                 TO MIR-FIA-FND-TRXN-AMT-G.
           MOVE SPACES                 TO MIR-FIA-PEND-AMT-G.
           MOVE SPACES                 TO MIR-PEND-DPOS-INT-AMT-G.
020469     MOVE SPACES                 TO MIR-FIA-CRCY-CD-G.


       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           SET  WGLOB-REF-POLICY       TO TRUE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                    TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE        TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX         TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8640-0000-INIT-PARM-INFO
025970         THRU 8640-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WS-WORK-AREAS.
025970     INITIALIZE SAVE-POLICY-NUMBER-AREAS.
025970     INITIALIZE KEY-WORK-AREAS.
025970     MOVE SPACE                      TO WWKDT-WORK-FIELDS.
025970
025970     SET WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************

025970 COPY XCPS1670.
       COPY CCPS5400.
018764*COPY CCCL5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL5400.
021930*COPY CCPL0620.
       COPY XCPL0290.
       COPY XCPS0290.
018764*COPY CCCL2440.
021930*COPY CCPL2440.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
020469 COPY XCPL8640.
020469 COPY XCPS8640.
020469
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************

021930*COPY CCPNEDIT.
       COPY CCPNPOL.
021930*COPY XCPNCRCY.
021930*COPY XCPNXTAB.
       COPY SCPBFD.
       COPY SCPNFD.
       COPY SCPBFS.
       COPY SCPNFC.
       COPY SCPBFA.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM SSOM1734
      *****************************************************************
