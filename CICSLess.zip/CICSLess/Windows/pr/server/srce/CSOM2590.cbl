      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2590.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2590                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE POLP AND CDSI TABLES                     **
      **            DISPLAY DETAILED INFORMATION PERTAINING TO A     **
      **            DEFERRED ACTIVITY                                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2590'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC  X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '2590'.
           05  WS-CDI-ALLOC-CD               PIC  X(01).
               88  WS-CDI-ALLOC-AMT          VALUE 'A'.
               88  WS-CDI-ALLOC-PCT          VALUE 'P'.
               88  WS-CDI-ALLOC-UNIT         VALUE 'U'.
023437*    05  WS-CDI-TYP-CD                 PIC  X(01).
023437     05  WS-CDI-TYP-CD                 PIC  X(02).
               88  WS-CDI-TYP-TRMN            VALUE
023437*            'B' 'D' 'E' 'G' 'H' 'J' 'K' 'N'.
023437             'B ' 'D ' 'E ' 'G ' 'H ' 'J ' 'K ' 'N '.

               88  WS-CDI-TYP-SURR            VALUE
                   'B', 'D', 'E', 'G', 'H', 'J',
                   'K', 'L', 'N', 'T', 'W'.

               88  WS-CDI-TYP-NON-SURR        VALUE
                                            'M'.

           05  I                             PIC S9(04)
                                             BINARY.
           05  WS-SUB                        PIC S9(04)
                                             BINARY.
           05  WS-MAX-LIST-LINES             PIC S9(04)
                                             BINARY.
           05  WS-POL-PAYO-NUM               PIC S9(05)
                                             COMP-3.
           05  WS-AMOUNT                     PIC S9(13)V9(02)
                                             COMP-3.
           05  WS-DEFR-IN-AMT                PIC S9(13)V9(02)
                                             COMP-3.
           05  WS-DEFR-OUT-AMT               PIC S9(13)V9(02)
                                             COMP-3.
           05  WS-DEFR-IN-UNIT-QTY           PIC S9(09)V9(09)
                                             COMP-3.
           05  WS-DEFR-OUT-UNIT-QTY          PIC S9(09)V9(09)
                                             COMP-3.
           05  WS-POLP-ERR-KEY.
               10  WS-POLP-ERR-POL-ID        PIC  X(10).
               10  FILLER                    PIC  X(01) VALUE SPACES.
               10  WS-POLP-ERR-POL-PAYO-NUM  PIC  9(05).
           05  WS-BNK-ACCT-NUM               PIC  9(01).
       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                   PIC  X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '2590'.
025970*                                      VALUE '2590'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCWWCVGS.
      /
       COPY CCFWPOLP.
       COPY CCFRPOLP.
      /
       COPY CCFWCDSI.
       COPY CCFRCDSI.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL5400.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
       COPY XCWL1640.
      /
       COPY XCWL1660.
      /
       COPY XCWL8960.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2590.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2590'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-RETRIEVE.
      *--------------
      *
           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  8000-EDIT-KEY-FIELDS
               THRU 8000-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED      TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  7000-BUILD-POLP-KEYS
               THRU 7000-BUILD-POLP-KEYS-X.

           PERFORM  POLP-1000-READ
               THRU POLP-1000-READ-X.

           IF  WPOLP-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOLP-POL-ID            TO WS-POLP-ERR-POL-ID
               MOVE MIR-POL-PAYO-NUM        TO WS-POLP-ERR-POL-PAYO-NUM
               MOVE WS-POLP-ERR-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  8020-XEDIT-FIELDS
               THRU 8020-XEDIT-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED      TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.

      /
      *---------------------------
       7000-BUILD-POLP-KEYS.
      *---------------------------

           MOVE MIR-POL-ID                  TO WPOLP-POL-ID.
           MOVE WS-POL-PAYO-NUM             TO WPOLP-POL-PAYO-NUM.

       7000-BUILD-POLP-KEYS-X.
           EXIT.

      *---------------------------
       7100-BUILD-CDSI-KEYS.
      *---------------------------

           MOVE RPOLP-POL-ID              TO WCDSI-POL-ID.
           MOVE RPOLP-POL-PAYO-EFF-DT     TO L1660-INTERNAL-DATE.

           PERFORM 1660-2000-CONVERT-INT-TO-INV
              THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE       TO WCDSI-CDI-EFF-IDT-NUM.
           MOVE RPOLP-POL-PAYO-TYP-CD     TO WCDSI-CDI-TYP-CD.
           MOVE RPOLP-POL-PAYO-NUM        TO WCDSI-POL-PAYO-NUM.
023112     MOVE +001                      TO WCDSI-CDI-SEQ-NUM.
           MOVE ZERO                      TO WCDSI-CDI-ALLOC-NUM.
           MOVE WCDSI-KEY                 TO WCDSI-ENDBR-KEY.
           MOVE +999                      TO WCDSI-ENDBR-CDI-ALLOC-NUM.

       7100-BUILD-CDSI-KEYS-X.
           EXIT.

      /
      *---------------------------
       8000-EDIT-KEY-FIELDS.
      *---------------------------

           PERFORM  8011-EDIT-POL-ID
               THRU 8011-EDIT-POL-ID-X.

           PERFORM  8012-EDIT-POL-PAYO-NUM
               THRU 8012-EDIT-POL-PAYO-NUM-X.

       8000-EDIT-KEY-FIELDS-X.
           EXIT.

      *---------------------------
       8011-EDIT-POL-ID.
      *---------------------------
      *
      * CHECK POLICY EXISTS
      *
           IF  MIR-POL-ID-BASE  = SPACES
           AND MIR-POL-ID-SFX   = SPACES
      *MSG: POLICY NUMBER IS REQUIRED
               MOVE 'CS25900001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

           MOVE MIR-POL-ID               TO WPOL-POL-ID.

      *  UPDATE GROUP LEVEL TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD NOT FOUND
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

      *
      * CHECK POLICY CONFIDENTIAL AND SECURITY ARE SATISFIED
      *

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
            END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

       8011-EDIT-POL-ID-X.
           EXIT.

      *---------------------------
       8012-EDIT-POL-PAYO-NUM.
      *---------------------------
      *
      *  CHECK PAYOUT NUMBER
      *

           IF  MIR-POL-PAYO-NUM = SPACES
           OR  MIR-POL-PAYO-NUM = '00000'
      *MSG: PAYOUT NUMBER IS REQUIRED
               MOVE 'CS25900002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8012-EDIT-POL-PAYO-NUM-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 0                    TO L0280-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-NUM
                                     TO L0280-INPUT-SIZE.

           COMPUTE  L0280-LENGTH
                 =  L0280-INPUT-SIZE.

           MOVE MIR-POL-PAYO-NUM     TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: INVALID PAYOUT NUMBER
               MOVE 'CS25900003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8012-EDIT-POL-PAYO-NUM-X
           END-IF.

           COMPUTE  WS-POL-PAYO-NUM
                 =  100000
                 -  L0280-OUTPUT-V00.

       8012-EDIT-POL-PAYO-NUM-X.
           EXIT.

      /
      *---------------------------
       8020-XEDIT-FIELDS.
      *---------------------------

           PERFORM  8021-XEDIT-POL-PAYO-NUM
               THRU 8021-XEDIT-POL-PAYO-NUM-X.

       8020-XEDIT-FIELDS-X.
           EXIT.

      /
      *---------------------------
       8021-XEDIT-POL-PAYO-NUM.
      *---------------------------
      *
      *  CHECK IT IS A DEFER ACTIVTY TRANSACTION USING SUBSET VALUE
      *

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X

           MOVE 'POL-PAYO-TYP-CD'        TO L8960-AV-TBL-CD.
           MOVE RPOLP-POL-PAYO-TYP-CD    TO L8960-AV-CD.
           MOVE 'DEF'                    TO L8960-AV-SUBSET-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X

           IF  NOT L8960-RETRN-OK
      *MSG: NOT A DEFERRED ACTIVITY, USE AUTOMATIC PAYOUT LIST
               MOVE 'CS25900004'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-PAYO-TYP-CD  TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
            END-IF.

       8021-XEDIT-POL-PAYO-NUM-X.
           EXIT.

      /
      *---------------------------
       9000-BLANK-DATA-FIELDS.
      *---------------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.


      /
      *---------------------------
       9200-MOVE-RECORD-TO-MIR.
      *---------------------------

           MOVE RPOLP-POL-PAYO-EFF-DT     TO L1640-INTERNAL-DATE.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE       TO MIR-POL-PAYO-EFF-DT.
           MOVE RPOLP-POL-PAYO-TYP-CD     TO MIR-POL-PAYO-TYP-CD
           MOVE RPOLP-POL-PAYO-STAT-CD    TO MIR-POL-PAYO-STAT-CD
           MOVE RPOLP-TRXN-FEE-OVRID-IND  TO MIR-TRXN-FEE-OVRID-IND
           MOVE RPOLP-TRXN-FEE-AMT        TO WS-AMOUNT.

           IF  RPOLP-POL-PAYO-TYP-LPAY
           OR  RPOLP-POL-PAYO-TYP-LOAN
               MOVE ZERO                  TO WS-AMOUNT
           END-IF.

           PERFORM  9500-FORMAT-AMT-FOR-MIR
               THRU 9500-FORMAT-AMT-FOR-MIR-X

           MOVE L0290-OUTPUT-DATA         TO MIR-TRXN-FEE-AMT.

           MOVE RPOLP-SURR-TAX-OVRID-CD   TO MIR-SURR-TAX-OVRID-CD
           MOVE RPOLP-OVRID-ALLOC-TYP-CD  TO MIR-OVRID-ALLOC-TYP-CD

           MOVE RPOLP-ANNV-VALU-IND       TO MIR-ANNV-VALU-IND.
           MOVE RPOLP-POL-PAYO-MAV-IND    TO MIR-POL-PAYO-MAV-IND.
           MOVE RPOLP-POL-PAYO-ROLU-IND   TO MIR-POL-PAYO-ROLU-IND.

           PERFORM  7100-BUILD-CDSI-KEYS
               THRU 7100-BUILD-CDSI-KEYS-X.

           PERFORM  CDSI-1000-BROWSE
               THRU CDSI-1000-BROWSE-X.

           PERFORM  CDSI-2000-READ-NEXT
               THRU CDSI-2000-READ-NEXT-X.

           PERFORM  9210-BUILD-LIST-SCREEN
               THRU 9210-BUILD-LIST-SCREEN-X
              UNTIL NOT WCDSI-IO-OK.

            PERFORM  CDSI-3000-END-BROWSE
                THRU CDSI-3000-END-BROWSE-X.

      *
      * TOTAL POLICY PAYOUT AMOUNT
      *

           COMPUTE  L0290-INPUT-V02
                 =  WS-DEFR-IN-AMT
                 +  WS-DEFR-OUT-AMT.

           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-PAYO-TOT-AMT
                                        TO L0290-MAX-OUT-LEN.

           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA         TO MIR-DV-POL-PAYO-TOT-AMT.

      *
      * TOTAL POLICY PAYOUT UNIT QUANTITY
      *

           COMPUTE  L0290-INPUT-V09
                 =  WS-DEFR-IN-UNIT-QTY
                 +  WS-DEFR-OUT-UNIT-QTY.

           MOVE 9                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-PAYO-UNIT-QTY
                                          TO L0290-MAX-OUT-LEN.

           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA         TO MIR-DV-POL-PAYO-UNIT-QTY.

023437* DISPLAY THE FEDERAL TAX WITHHOLDING REQUEST DATA
023437
029060*    MOVE RPOLP-FED-TAXWH-CALC-CD   TO MIR-FED-TAXWH-CALC-CD.
029060*    MOVE RPOLP-FED-TAXWH-RQST-AMT  TO WS-AMOUNT.
029060     MOVE RPOLP-FTAXWH-RQST-CD      TO MIR-FTAXWH-RQST-CD.
029060     MOVE RPOLP-FTAXWH-RQST-AMT     TO WS-AMOUNT.
023437
023437     PERFORM  9500-FORMAT-AMT-FOR-MIR
023437         THRU 9500-FORMAT-AMT-FOR-MIR-X
023437
029060*    MOVE L0290-OUTPUT-DATA         TO MIR-FED-TAXWH-RQST-AMT.
023437
029060*    MOVE RPOLP-FED-TAXWH-RQST-PCT  TO L0290-INPUT-V02.
029060     MOVE L0290-OUTPUT-DATA         TO MIR-FTAXWH-RQST-AMT.
029060     MOVE RPOLP-FTAXWH-RQST-PCT     TO L0290-INPUT-V02.
023437
023437     MOVE 2                         TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                   TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                    TO L0290-MAX-OUT-LEN.
023437     PERFORM 0290-2000-FORMAT-FOR-MIR
023437        THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA         TO MIR-FED-TAXWH-RQST-PCT.
029060     MOVE L0290-OUTPUT-DATA         TO MIR-FTAXWH-RQST-PCT.
023437
023437* DISPLAY THE LOCATON TAX WITHHOLDING DATA
023437
029060*    MOVE RPOLP-LTAXWH-CALC-CD     TO MIR-LTAXWH-CALC-CD.
029060*    MOVE RPOLP-LTAXWH-FLAT-AMT    TO WS-AMOUNT.
029060     MOVE RPOLP-LTAXWH-RQST-CD     TO MIR-LTAXWH-RQST-CD.
029060     MOVE RPOLP-LTAXWH-RQST-AMT    TO WS-AMOUNT.
023437
023437     PERFORM  9500-FORMAT-AMT-FOR-MIR
023437         THRU 9500-FORMAT-AMT-FOR-MIR-X
023437
029060*    MOVE L0290-OUTPUT-DATA         TO MIR-LTAXWH-FLAT-AMT.
023437
029060*    MOVE RPOLP-LTAXWH-PCT          TO WS-AMOUNT.
029060     MOVE L0290-OUTPUT-DATA         TO MIR-LTAXWH-RQST-AMT.
029060     MOVE RPOLP-LTAXWH-RQST-PCT     TO WS-AMOUNT.
023437
023437     PERFORM  9500-FORMAT-AMT-FOR-MIR
023437         THRU 9500-FORMAT-AMT-FOR-MIR-X
023437
029060*    MOVE L0290-OUTPUT-DATA         TO MIR-LTAXWH-PCT.
029060     MOVE L0290-OUTPUT-DATA         TO MIR-LTAXWH-RQST-PCT.
023437
       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.

      *---------------------------
       9210-BUILD-LIST-SCREEN.
      *---------------------------

           MOVE RCDSI-CDI-TYP-CD           TO WS-CDI-TYP-CD.

           PERFORM  9220-ACCUM-TOT
               THRU 9220-ACCUM-TOT-X.

           PERFORM  9225-GET-PAYO-DEST
               THRU 9225-GET-PAYO-DEST-X.

           IF  RCDSI-CLI-ID NOT = SPACES
               MOVE RCDSI-CLI-ID           TO MIR-CLI-ID
           END-IF.

           IF  RCDSI-CLI-BNK-ACCT-NUM  NOT = ZEROES
               MOVE RCDSI-CLI-BNK-ACCT-NUM TO WS-BNK-ACCT-NUM
               MOVE WS-BNK-ACCT-NUM        TO MIR-CLI-BNK-ACCT-NUM
           END-IF.

      *
      * DESTINATION INSTRUCTION LIST WILL NOT INCLUDE THE PAYOUT METHOD
      *
           IF  RCDSI-CDI-PAYO-MTHD-CD = SPACES
               CONTINUE
           ELSE
               IF  WS-CDI-TYP-TRMN
                   CONTINUE
               ELSE
                   PERFORM  CDSI-2000-READ-NEXT
                       THRU CDSI-2000-READ-NEXT-X
                   GO TO 9210-BUILD-LIST-SCREEN-X
               END-IF
           END-IF.

           ADD +1 TO WS-SUB.

           IF  WS-SUB > WS-MAX-LIST-LINES
      *MSG LIST MAXIMUM REACHED (@1), CONTACT SYSTEMS
               MOVE WS-MAX-LIST-LINES      TO WGLOB-MSG-PARM (1)
               MOVE 'CS25900005'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  0030-5000-LOGIC-ERROR
                   THRU 0030-5000-LOGIC-ERROR-X
           END-IF.

           MOVE RCDSI-CDI-ALLOC-CD       TO WS-CDI-ALLOC-CD.
           MOVE RCDSI-CDI-ALLOC-CD       TO MIR-CDI-ALLOC-CD-T (WS-SUB).

           PERFORM  9230-GET-DESC-TXT
               THRU 9230-GET-DESC-TXT-X.

           PERFORM  9240-GET-ALLOC-DESGNT
               THRU 9240-GET-ALLOC-DESGNT-X.

           PERFORM CDSI-2000-READ-NEXT
              THRU CDSI-2000-READ-NEXT-X.

       9210-BUILD-LIST-SCREEN-X.
           EXIT.


      *---------------------------
       9220-ACCUM-TOT.
      *---------------------------
      *
      * ACCUMULATE THE SET OF INSTRUCTIONS (CDSI), CHECK THE TYPE OF
      * ALLOCATION INSTRUCTION TO DETERMINE CDSI TO INCLUDE IN TOTALS
      * AS IT ENSURES A NET RESULT OF ZERO IS NOT PRODUCED
      *
            IF  RCDSI-DEST-CVG-NUM   = SPACES
                GO TO 9220-ACCUM-TOT-X
            END-IF.

            IF  RCDSI-DEST-CVG-NUM-N > ZEROES
            AND WCVGS-CVG-COLFND (RCDSI-DEST-CVG-NUM-N)
                GO TO 9220-ACCUM-TOT-X
            END-IF.

           EVALUATE TRUE

              WHEN WS-CDI-TYP-SURR
      *
      * MONEY COMING OUT OF THE POLICY
      *
                    IF  RCDSI-CDI-ALLOC-AMT < ZERO
                        ADD RCDSI-CDI-ALLOC-AMT TO WS-DEFR-OUT-AMT
                        ADD RCDSI-CDI-ALLOC-UNIT-QTY
                                                TO WS-DEFR-OUT-UNIT-QTY
                    END-IF

              WHEN WS-CDI-TYP-NON-SURR
      *
      * MONEY GOING INTO THE POLICY
      *
                    IF  RCDSI-DEST-CVG-NUM-N = ZEROES
                        GO TO 9220-ACCUM-TOT-X
                    END-IF

                    IF  RCDSI-CDI-ALLOC-AMT > ZERO
                        ADD RCDSI-CDI-ALLOC-AMT TO WS-DEFR-IN-AMT
                        ADD RCDSI-CDI-ALLOC-UNIT-QTY
                                                TO WS-DEFR-IN-UNIT-QTY
                    END-IF

           END-EVALUATE.

       9220-ACCUM-TOT-X.
           EXIT.


      /
      *---------------------------
       9225-GET-PAYO-DEST.
      *---------------------------
      *
      * DETERMINE THE TOTAL INSTRUCTION AMOUNT
      *
           EVALUATE TRUE

                WHEN  RCDSI-CDI-PAYO-CHQ
                      MOVE RCDSI-CDI-ALLOC-AMT
                                          TO WS-AMOUNT
                      PERFORM  9500-FORMAT-AMT-FOR-MIR
                          THRU 9500-FORMAT-AMT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                          TO MIR-DV-POL-PAYO-CHQ-AMT

                WHEN  RCDSI-CDI-PAYO-OS-DISB
                      MOVE RCDSI-CDI-ALLOC-AMT
                                          TO WS-AMOUNT
                      PERFORM  9500-FORMAT-AMT-FOR-MIR
                          THRU 9500-FORMAT-AMT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                          TO MIR-DV-POL-PAYO-DISB-AMT

                WHEN  RCDSI-CDI-PAYO-EFT
                      MOVE RCDSI-CDI-ALLOC-AMT
                                          TO WS-AMOUNT
                      PERFORM  9500-FORMAT-AMT-FOR-MIR
                          THRU 9500-FORMAT-AMT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                          TO MIR-DV-POL-PAYO-EFT-AMT

                WHEN  RCDSI-CDI-PAYO-MISC-SUSP
                      MOVE RCDSI-CDI-ALLOC-AMT
                                          TO WS-AMOUNT
                      PERFORM  9500-FORMAT-AMT-FOR-MIR
                          THRU 9500-FORMAT-AMT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                          TO MIR-DV-POL-PAYO-MISC-AMT

                WHEN  RCDSI-CDI-PAYO-PREM-SUSP
                      MOVE RCDSI-CDI-ALLOC-AMT
                                          TO WS-AMOUNT
                      PERFORM  9500-FORMAT-AMT-FOR-MIR
                          THRU 9500-FORMAT-AMT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                          TO MIR-DV-POL-PAYO-PREM-AMT

           END-EVALUATE.


       9225-GET-PAYO-DEST-X.
           EXIT.


      *---------------------------
       9230-GET-DESC-TXT.
      *---------------------------
      *
      *  GET FUND OR PLAN DESCRIPTION ON THIS INSTRUCTION
      *
           EVALUATE TRUE

                WHEN RCDSI-CDI-PAYO-MTHD-CD = SPACES

                    IF  RCDSI-DEST-FND-ID      = SPACES
                    AND RCDSI-DEST-CVG-NUM NOT = SPACES
                    AND RCDSI-DEST-CVG-NUM-N   > ZEROES
                        MOVE WCVGS-PLAN-ID (RCDSI-DEST-CVG-NUM-N)
                             TO WEDIT-ETBL-VALU-ID
                        PERFORM  PLAN-2000-DESC
                            THRU PLAN-2000-DESC-X
                        MOVE REDIT-ETBL-DESC-TXT
                             TO MIR-DV-FND-DESC-TXT-T (WS-SUB)
                    ELSE
                        IF  RCDSI-DEST-FND-ID NOT = SPACES
                            MOVE RCDSI-DEST-FND-ID
                              TO WEDIT-ETBL-VALU-ID
                            PERFORM  SGFD-2000-DESC
                                THRU SGFD-2000-DESC-X
                            MOVE REDIT-ETBL-DESC-TXT
                              TO MIR-DV-FND-DESC-TXT-T (WS-SUB)
                        END-IF
                    END-IF

           END-EVALUATE.

       9230-GET-DESC-TXT-X.
           EXIT.


      *---------------------------
       9240-GET-ALLOC-DESGNT.
      *---------------------------
      *
      * DETERMINE DOLLAR AMOUNT, PERCENT AND/OR UNIT AS PER INSTRUCTION
      *
           EVALUATE TRUE

                WHEN  WS-CDI-ALLOC-PCT
      *
      * DISPLAY THE PERCENT THAT IS ALLOCATED TO THIS INSTRUCTION
      *
                      MOVE RCDSI-CDI-ALLOC-PCT      TO L0290-INPUT-V04
                      MOVE 4                        TO L0290-PRECISION
                      MOVE LENGTH OF MIR-CDI-ALLOC-PCT-T (WS-SUB)
                                                    TO L0290-MAX-OUT-LEN

                      PERFORM  0290-2000-FORMAT-FOR-MIR
                          THRU 0290-2000-FORMAT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                   TO MIR-CDI-ALLOC-PCT-T (WS-SUB)

                      MOVE RCDSI-CDI-ALLOC-AMT      TO WS-AMOUNT
                      PERFORM  9500-FORMAT-AMT-FOR-MIR
                          THRU 9500-FORMAT-AMT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                   TO MIR-CDI-ALLOC-AMT-T (WS-SUB)

                WHEN  WS-CDI-ALLOC-UNIT
      *
      * DISPLAY THE NUMBER OF UNITS ALLOCATED TO THIS INSTRUCTION
      *
                      MOVE RCDSI-CDI-ALLOC-UNIT-QTY TO L0290-INPUT-V09
                      MOVE 9                        TO L0290-PRECISION
                      MOVE LENGTH OF MIR-CDI-ALLOC-UNIT-QTY-T (WS-SUB)
                                                    TO L0290-MAX-OUT-LEN
                      PERFORM  0290-2000-FORMAT-FOR-MIR
                          THRU 0290-2000-FORMAT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                   TO MIR-CDI-ALLOC-UNIT-QTY-T (WS-SUB)

                WHEN  OTHER
      *
      * DISPLAY THE DOLLAR AMOUNT THAT IS ALLOCATED TO THIS INSTRUCTION
      *
                      MOVE RCDSI-CDI-ALLOC-AMT      TO WS-AMOUNT
                      PERFORM  9500-FORMAT-AMT-FOR-MIR
                          THRU 9500-FORMAT-AMT-FOR-MIR-X
                      MOVE L0290-OUTPUT-DATA
                                   TO MIR-CDI-ALLOC-AMT-T (WS-SUB)


           END-EVALUATE.

       9240-GET-ALLOC-DESGNT-X.
           EXIT.


      /
      *---------------------------
       9300-SETUP-MSIN-REFERENCE.
      *---------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.

           SET  WGLOB-REF-POLICY         TO TRUE.
           MOVE MIR-POL-ID               TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.


      /
      *---------------------------
       9500-FORMAT-AMT-FOR-MIR.
      *---------------------------

           MOVE WS-AMOUNT               TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TRXN-FEE-AMT
                                        TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.

       9500-FORMAT-AMT-FOR-MIR-X.
           EXIT.


      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.

      *
      *  SET THE NUMBER OF LIST LINES USING MIR FIELD OCCURENCES
      *

           COMPUTE WS-MAX-LIST-LINES
                 = LENGTH OF MIR-CDI-ALLOC-CD-G
                 / LENGTH OF MIR-CDI-ALLOC-CD-T (1).

           MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK         TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPEPLAN.
      /
       COPY CCPESGFD.
      /
       COPY NCPPCVGS.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POL
                                '$VAR2'   BY 'POL'.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS8090.
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
       COPY XCPS8960.
       COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY CCPNCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNPOLP.
      /
       COPY CCPBCDSI.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **              END OF PROGRAM CSOM2590                        **
      *****************************************************************
