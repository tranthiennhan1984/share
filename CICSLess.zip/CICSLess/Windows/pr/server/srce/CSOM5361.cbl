      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5361.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5361                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE LTWR TABLE                               **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013693**  6.2       LOCATION TAX                                     **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018770**  6.3       PCR - ALLOWABLE VALUE EDIT                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5361'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                   PIC X(04) VALUE '5360'.
025970         88  WS-TWRK-KEY-DEFAULT                 VALUE '5360'.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-CREATE            VALUE '5361'.
025970*    05  WS-TWRK-KEY                      PIC X(04) VALUE '5360'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
021930*COPY XCWWWKDT.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWLTWR.
       COPY CCFRLTWR.
      /
018770*COPY XCFWDMAD.
018770*COPY XCFRDMAD.
018770*
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
021930*COPY XCWLDTLK.
021930*COPY XCWL0280.
021930*COPY XCWL1640.
       COPY XCWL8090.
018770 COPY XCWL8960.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5361.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5361'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-CREATE.
      *------------
      *
      *  THE RECORD SHOULD NOT EXIST ON A CREATE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  LTWR-1000-READ
               THRU LTWR-1000-READ-X.

           IF  WLTWR-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE WLTWR-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CREATE-X
           END-IF.
      *
      *  CREATE THE NEW RECORD
      *
           PERFORM  LTWR-1000-CREATE
               THRU LTWR-1000-CREATE-X.

           PERFORM  LTWR-1000-WRITE
               THRU LTWR-1000-WRITE-X.

           PERFORM  LTWR-1000-READ-TWRK-TS
               THRU LTWR-1000-READ-TWRK-TS-X.

       2000-CREATE-X.
           EXIT.
      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           PERFORM  4110-EDIT-LOC-GR-ID
               THRU 4110-EDIT-LOC-GR-ID-X.

           PERFORM  4120-EDIT-LTAXWH-DISB-CD
               THRU 4120-EDIT-LTAXWH-DISB-CD-X.

           PERFORM  4130-EDIT-LTAXWH-FILE-CD
               THRU 4130-EDIT-LTAXWH-FILE-CD-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *--------------------
       4110-EDIT-LOC-GR-ID.
      *--------------------
      *
      ***************************************************************
      *  CURRENT LOCATION MUST BE IN ETAB/CLOC
      ***************************************************************
      *
           IF WLTWR-LOC-GR-ID NOT = SPACES
               MOVE WLTWR-LOC-GR-ID     TO WEDIT-ETBL-VALU-ID
               PERFORM  LGAS-1000-EDIT-LGAS-LOCATION
                   THRU LGAS-1000-EDIT-LGAS-LOCATION-X
               IF  WEDIT-IO-OK
                   CONTINUE
               ELSE
      * MSG: LOC MUST BE FOUND ON EDIT/LOCGP. CHECK AND RE-ENTER
                   MOVE 'CS53610001'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       4110-EDIT-LOC-GR-ID-X.
           EXIT.
      /
      *-------------------------
       4120-EDIT-LTAXWH-DISB-CD.
      *-------------------------

           IF  MIR-LTAXWH-DISB-CD = SPACES
      *MSG: LOCATION TAX DISBRIBUTION CODE CAN NOT BE SPACES
               MOVE 'CS53610002'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4120-EDIT-LTAXWH-DISB-CD-X
           END-IF.

018770*    MOVE LOW-VALUES            TO WDMAD-KEY.
018770*    MOVE MIR-LTAXWH-DISB-CD    TO WDMAD-DM-AV-CD.
018770*    MOVE "LTAXWH-DISB-CD"      TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE WGLOB-USER-LANG       TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    MOVE HIGH-VALUES           TO WDMAD-ENDBR-KEY.
018770*    MOVE WDMAD-DM-AV-CD        TO WDMAD-ENDBR-DM-AV-CD.
018770*    MOVE WDMAD-DM-AV-TBL-CD    TO WDMAD-ENDBR-DM-AV-TBL-CD.
018770*    MOVE WDMAD-DM-AV-DESC-LANG-CD
018770*                             TO WDMAD-ENDBR-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM DMAD-1000-BROWSE
018770*       THRU DMAD-1000-BROWSE-X.
018770*
018770*    PERFORM DMAD-2000-READ-NEXT
018770*       THRU DMAD-2000-READ-NEXT-X
018770*
018770*    IF WDMAD-IO-OK
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770     MOVE 'LTAXWH-DISB-CD'      TO L8960-AV-TBL-CD.
018770     MOVE MIR-LTAXWH-DISB-CD    TO L8960-AV-CD.
018770
018770     PERFORM  8960-1000-VALIDATE-CODE
018770         THRU 8960-1000-VALIDATE-CODE-X.
018770
018770     IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      * MSG:   LOCATION TAX DISBTIBUIOTN CODE NOT FOUND ON DMAD.
      *        CHECK AND RE-ENTER.
               MOVE 'CS53610003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

018770*    PERFORM DMAD-3000-END-BROWSE
018770*       THRU DMAD-3000-END-BROWSE-X.
018770*
       4120-EDIT-LTAXWH-DISB-CD-X.
           EXIT.
      /
      *-------------------------
       4130-EDIT-LTAXWH-FILE-CD.
      *-------------------------
      *
      ***************************************************************
      *  CURRENT LOCATION MUST BE IN ETAB
      ***************************************************************
      *
           IF  MIR-LTAXWH-FILE-CD = SPACES
      *MSG: FILING STATUS MUST BE ENTERED
               MOVE 'CS53610004'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4130-EDIT-LTAXWH-FILE-CD-X
           END-IF.

           MOVE MIR-LTAXWH-FILE-CD
             TO WEDIT-ETBL-VALU-ID.

           PERFORM  FILE-1000-EDIT
               THRU FILE-1000-EDIT-X.

           IF  NOT WEDIT-IO-OK
      *MSG: FILING STATUS NOT VALID
               MOVE 'CS53610005'             TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4130-EDIT-LTAXWH-FILE-CD-X
           END-IF.

           MOVE MIR-LTAXWH-FILE-CD           TO WLTWR-LTAXWH-FILE-CD.

       4130-EDIT-LTAXWH-FILE-CD-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES               TO WLTWR-KEY.

           MOVE MIR-LOC-GR-ID            TO WLTWR-LOC-GR-ID.
           MOVE MIR-LTAXWH-DISB-CD       TO WLTWR-LTAXWH-DISB-CD.
           MOVE MIR-LTAXWH-FILE-CD       TO WLTWR-LTAXWH-FILE-CD.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-TWRK-KEY-DEFAULT       TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPELGAS.
       COPY CCPEFILE.
       COPY CCPNEDIT.
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY LTWR
                               '$VAR2' BY 'LTWR'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
021930*COPY XCPL0280.
021930*COPY XCPL1640.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS8090.
018770 COPY XCPS8960.
018770 COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPALTWR.
       COPY CCPCLTWR.
       COPY CCPNLTWR.
       COPY CCPULTWR.
      /
018770*COPY XCPBDMAD.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM9999                     **
      *****************************************************************
