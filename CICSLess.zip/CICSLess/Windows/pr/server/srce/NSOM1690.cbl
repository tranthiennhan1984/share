      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM1690.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM1690                                         **
      **  REMARKS:  LABU - UNMATCHED LAB RESULTS                     **
      **            THIS MODULE ALLOWS THE USER TO MATCH LAB RESULTS **
      **            THAT WERE TRANSMITTED TO THE COMPANY             **
      **            ELECTRONICALLY WITHOUT A VALID CLIENT NUMBER, TO **
      **            A CLIENT THAT RESIDES ON BIOP (BIOGRAPHIC        **
      **            PROFILE).                                        **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       LABU CONTROL PROCESSING FIXES                    **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557695**  5.5       TAXATION ID ENHANCEMENTS                         **
557708**  5.5       ABEND HANDLING                                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010310**  5.6       REMOVE VSAM ALTX FIELDS                          **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGES SUPPORT CHANGES                         **
015508**  6.0       CLIENT ENHANCEMENT FOR JAPAN                     **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018645**  6.4       REDEFINE LAB RESULTS                             **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM1690'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           05  WS-INPUT-VALID-SW            PIC X(1)   VALUE SPACES.
               88  WS-VALID-INPUT           VALUE 'Y'.
               88  WS-INVALID-INPUT         VALUE 'N'.
013578     05  WS-END-LIST-SW               PIC X(1)   VALUE SPACES.
013578         88  WS-END-LIST-REQUIRED     VALUE 'Y'.
           05  WS-ATTACH-VERIFIED-SW        PIC X(1)   VALUE SPACES.
               88  WS-ATTACH-VERIFIED       VALUE 'Y'.
           05  WS-ATTACH-COMPLETED-SW       PIC X(1)   VALUE SPACES.
               88  WS-ATTACH-COMPLETED      VALUE 'Y'.
           05  WS-ATTACH-CNT-X.
               10  WS-ATTACH-CNT            PIC 9(04) VALUE ZERO.
           05  WS-VERIFY-REQD-SW            PIC X(1)   VALUE SPACES.
               88  WS-VERIFY-REQD           VALUE 'Y'.
           05  WS-DISPLAY-REC-SW            PIC X(1)   VALUE SPACES.
               88  WS-DISPLAY-REC-FOUND     VALUE 'Y'.
               88  WS-DISPLAY-REC-NOT-FOUND VALUE 'N'.
015508     05  WS-GOT-CLIENT-NAME-SW        PIC X(1)   VALUE SPACES.
015508         88  WS-GOT-CLIENT-NAME       VALUE 'Y'.
015508         88  WS-GOT-CLIENT-NAME-NO    VALUE 'N'.
013578*    05  WS-SCREEN-CODE               PIC X(1)   VALUE SPACES.
013578*        88  WS-BROWSE-SCREEN         VALUE 'B'.
013578*        88  WS-ATTACH-SCREEN         VALUE 'A'.
013578*        88  WS-DELETE-SCREEN         VALUE 'D'.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-ATTACH        VALUES '1690'.
013578         88  WS-BUS-FCN-DELETE        VALUES '1693'.
013578         88  WS-BUS-FCN-LIST          VALUES '1694'.
016548*    05  WS-FIRST-MOVE-LINE           PIC S9(4)  COMP.
016548     05  WS-FIRST-MOVE-LINE           PIC S9(4)  BINARY.
016548*    05  WS-LINES-TO-MOVE             PIC S9(4)  COMP.
016548     05  WS-LINES-TO-MOVE             PIC S9(4)  BINARY.
016548*    05  WS-OFFSET                    PIC S9(4)  COMP.
016548     05  WS-OFFSET                    PIC S9(4)  BINARY.
016548*    05  WS-REMAINING-LINES           PIC S9(4)  COMP.
016548     05  WS-REMAINING-LINES           PIC S9(4)  BINARY.
016548*    05  WS-MAX-LIST-SCREEN-LINES     PIC S9(4)  COMP
025970*    05  WS-MAX-LIST-SCREEN-LINES     PIC S9(4)  BINARY
016548*                                                VALUE +13.
025970*                                                VALUE +40.
016548*    05  WS-MAX-ATTACH-SCREEN-LINES   PIC S9(4)  COMP
025970*    05  WS-MAX-ATTACH-SCREEN-LINES   PIC S9(4)  BINARY
013578*                                                VALUE +4.
025970*                                                VALUE +40.
016548*    05  I                            PIC S9(4)  COMP.
016548     05  I                            PIC S9(4)  BINARY.
016548*    05  WS-LINE                      PIC S9(4)  COMP.
016548     05  WS-LINE                      PIC S9(4)  BINARY.
020478     05  WS-LINE-CHANGE               PIC S9(4)  BINARY.
020478     05  WS-LAST-LINE                 PIC S9(4)  BINARY.
           05  WS-SAVE-FIRST-NAME           PIC X(25).
           05  WS-SAVE-INITIAL              PIC X(01).
           05  WS-SAVE-DATE-OF-BIRTH        PIC X(10).
           05  WS-SAVE-SEX                  PIC X(01).
           05  WS-SAVE-SIN-NUMBER           PIC X(09).
           05  WS-SAVE-CODE                 PIC X(03).
           05  WS-SEQNUM                    PIC X(03).

           05  RPOL-POL-ID                  PIC X(10)  VALUE SPACES.
           05  RPOL-POL-BASE-CVG-NUM        PIC 9(02)  VALUE ZERO.
025970*    05  HOLD-RUN-ID                  PIC X(01)  VALUE '0'.
025970     05  HOLD-RUN-ID                  PIC X(01).
025970         88  WS-DEFAULT-HOLD-RUN-ID              VALUE '0'.
      *
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-SCREEN-LINES     PIC S9(4)  BINARY.
025970         88  WS-DEFAULT-MAX-LIST-LINES           VALUE +40.
025970     05  WS-MAX-ATTACH-SCREEN-LINES   PIC S9(4)  BINARY.
025970         88  WS-DEFAULT-MAX-ATTACH-LINES         VALUE +40.
      *
016537*COPY XCWWWKDT.
020478 COPY XCWWWKDT.
      *
016537*COPY XCWEBLCH.
      *

      *
      * FILE AREA
      *
015508*COPY CCFWCLIE.
       COPY CCFWCLI.
       COPY CCFRCLI.
      *
015508 COPY CCFWCLNN.
015508 COPY CCFWCLNM.
015508 COPY CCFRCLNM.
      *
       COPY NCFWLABR.
       COPY NCFRLABR.
      *
       COPY NCFWLABU.
       COPY NCFRLABU.
      *
      *
      * PARAMETER AREA
      *
020478 COPY CCWL2435.
028298 COPY CCWL2626.
       COPY CCWL5120.
      *
       COPY NCWL1030.
      *
       COPY NCWL7180.
      *
016537*COPY XCWL0270.
      *
016537*COPY XCWL0280.
      *
       COPY XCWL1640.
      *
016537*COPY XCWL1670.
      *
016537*COPY XCWL1680.
      *
       COPY XCWLDTLK.
      *
      * COMM AREA
      *
014588*COPY CCWCCOMM.
014588*COPY NCWC1690.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM1690.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
      * NORMAL PROCESSING:
      * DISTRIBUTE CONTROL TO APPROPRIATE PROCESSING ROUTINE
      *
      * INITIALIZE VARIABLES NEEDED FOR THIS TRANSACTION
      *
           PERFORM  2050-INITIALIZE
               THRU 2050-INITIALIZE-X.

           IF  MIR-DV-PRCES-STATE-CD = '3'
               MOVE 'Y'           TO WS-ATTACH-VERIFIED-SW
           END-IF.

           EVALUATE TRUE
               WHEN WS-BUS-FCN-LIST
                    PERFORM  3000-PROCESS-LIST
                        THRU 3000-PROCESS-LIST-X
               WHEN WS-BUS-FCN-ATTACH
                    PERFORM  4000-PROCESS-ATTACH
                        THRU 4000-PROCESS-ATTACH-X
               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *----------------
       2050-INITIALIZE.
      *----------------
      *
      * INITIALIZE: INITIALIZE MISCELLANEOUS VARIABLES NEEDED FOR
      * PROCESSING IN THIS TRANSACTION.
      *
      * INITIALIZE WORK VARIABLES
      *
           MOVE '0'                   TO WGLOB-RETURN-CODE.
           MOVE '001'                 TO WS-SEQNUM.
           MOVE 'N'                   TO WS-ATTACH-VERIFIED-SW.

      *
      * SET UP MESSAGE VARIABLES
      *
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

       2050-INITIALIZE-X.
           EXIT.

      *------------------
       3000-PROCESS-LIST.
      *------------------
      *
      * PROCESS BROWSE
      *

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  8000-BUILD-LABU-KEY
               THRU 8000-BUILD-LABU-KEY-X.

           PERFORM  3100-NEXT-PAGE
               THRU 3100-NEXT-PAGE-X.

       3000-PROCESS-LIST-X.
           EXIT.

      *---------------
       3100-NEXT-PAGE.
      *---------------
      *
      * SETUP BROWSE KEYS, BEGIN BROWSE, AND LOAD DATA ARRAY UNTIL
      * END-OF-FILE OR SCREEN IS FULL.
      *

           MOVE HIGH-VALUES           TO WLABU-ENDBR-KEY.

      *
      * DISPLAY NEXT PAGE
      *
           MOVE 1                     TO WS-LINE.

           PERFORM  3200-DISPLAY-NEXT-PAGE
               THRU 3200-DISPLAY-NEXT-PAGE-X.

       3100-NEXT-PAGE-X.
           EXIT.

      *-----------------------
       3200-DISPLAY-NEXT-PAGE.
      *-----------------------
      *
      * BROWSE FORWARDS FROM THE CURRENT BROWSE KEY, LOADING RECORDS
      * THE SCREEN LINE BEGINNING WITH WS-LINE, UNTIL FULL OR END-OF-
      *

           PERFORM  LABU-1000-BROWSE
               THRU LABU-1000-BROWSE-X.

           PERFORM  LABU-2000-READ-NEXT
               THRU LABU-2000-READ-NEXT-X.

           IF  NOT WLABU-IO-OK
               IF  WS-LINE > 1
      *MSG: END OF FILE REACHED
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3200-DISPLAY-NEXT-PAGE-X
               ELSE
      *MSG: NO RECORDS FOUND TO DISPLAY
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3200-DISPLAY-NEXT-PAGE-X
               END-IF
           END-IF.

           IF  WS-LINE = 1
               IF  WLABU-IO-OK
                   MOVE RLABU-CLI-LTST-SUR-NM
                                      TO MIR-CLI-LTST-SUR-NM
                   MOVE RLABU-CLI-LTST-SEQ-NUM
                                      TO MIR-CLI-LTST-SEQ-NUM
                   MOVE RLABU-CLI-LTST-SEQ-NUM
                                      TO WS-SEQNUM
               END-IF
           END-IF.

      *
      * LOAD SCREEN DATA ARRAY
      *
020478     MOVE 1                 TO WS-LINE-CHANGE.
           PERFORM  3210-DISPLAY-RECORD-NEXT
               THRU 3210-DISPLAY-RECORD-NEXT-X
020478*     VARYING WS-LINE FROM WS-LINE BY 1
              UNTIL (NOT WLABU-IO-OK)
                 OR (WS-LINE > WS-MAX-LIST-SCREEN-LINES).

      *
      * COMPLETION MESSAGE
      *
           IF  WLABU-IO-OK
      *MSG: ** TO VIEW MORE DATA PRESS ENTER **
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9250-UPDATE-SCREEN-KEYS
                   THRU 9250-UPDATE-SCREEN-KEYS-X
           ELSE
               IF  WS-LINE > 1
      *MSG: END OF FILE REACHED
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORDS FOUND TO DISPLAY
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  LABU-3000-END-BROWSE
               THRU LABU-3000-END-BROWSE-X.

       3200-DISPLAY-NEXT-PAGE-X.
           EXIT.

      *-------------------------
       3210-DISPLAY-RECORD-NEXT.
      *-------------------------
      *
      * DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE GIVEN BY
      * WS-LINE AND RETRIEVE THE NEXT RECORD.
      *

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'N'                  TO WS-DISPLAY-REC-SW.

           PERFORM  3215-READ-LABU
               THRU 3215-READ-LABU-X
              UNTIL WS-DISPLAY-REC-FOUND
                 OR WLABU-IO-EOF.

       3210-DISPLAY-RECORD-NEXT-X.
           EXIT.

      *---------------
       3215-READ-LABU.
      *---------------

           PERFORM  LABU-2000-READ-NEXT
               THRU LABU-2000-READ-NEXT-X.

           IF  WLABU-IO-EOF
               GO TO 3215-READ-LABU-X
           END-IF.

           MOVE RLABU-CLI-BTH-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

020478     IF WS-LINE > 1
020478        COMPUTE WS-LAST-LINE = WS-LINE - 1
020478     END-IF.

020478*    IF  L1640-EXTERNAL-DATE      NOT = MIR-CLI-BTH-DT-T (WS-LINE)
020478     IF  L1640-EXTERNAL-DATE      NOT =
020478                              MIR-CLI-BTH-DT-T (WS-LAST-LINE)
           OR  RLABU-CLI-LTST-SUR-NM    NOT =
020478*                                 MIR-CLI-LTST-SUR-NM-T (WS-LINE)
020478                              MIR-CLI-LTST-SUR-NM-T (WS-LAST-LINE)
015904*    OR  RLABU-CLI-GIV-NM         NOT = MIR-CLI-GIV-NM-T (WS-LINE)
015904     OR  RLABU-CLI-GIV-NM         NOT = MIR-CLI-INDV-GIV-NM-T
020478*          (WS-LINE)
020478                                       (WS-LAST-LINE)
           OR  RLABU-CLI-MID-INIT-NM    NOT =
015904*                                  MIR-CLI-MID-INIT-NM-T (WS-LINE)
015904                                   MIR-CLI-INDV-MID-NM-T
020478*                                         (WS-LINE)
020478                                        (WS-LAST-LINE)
020478*    OR  RLABU-CLI-SEX-CD         NOT = MIR-CLI-SEX-CD-T (WS-LINE)
020478     OR  RLABU-CLI-SEX-CD         NOT =
020478                              MIR-CLI-SEX-CD-T (WS-LAST-LINE)
557695*    OR  RLABU-CLI-SIN-ID         NOT = MIR-CLI-TAX-ID-T (WS-LINE)
020478*    OR  RLABU-CLI-TAX-ID         NOT = MIR-CLI-TAX-ID-T (WS-LINE)
020478     OR  RLABU-CLI-TAX-ID         NOT =
020478                              MIR-CLI-TAX-ID-T (WS-LAST-LINE)
020478*    OR  RLABU-LAB-ID             NOT = MIR-LAB-ID-T (WS-LINE)
020478     OR  RLABU-LAB-ID             NOT =
020478                              MIR-LAB-ID-T (WS-LAST-LINE)
               MOVE 'Y'               TO WS-DISPLAY-REC-SW
           END-IF.

       3215-READ-LABU-X.
           EXIT.

      *--------------------
       4000-PROCESS-ATTACH.
      *--------------------
      *
      * PROCESS ATTACH SCREEN: ATTACH CLIENT TO TEST OR DISPLAY CLIENT
      *

015508     SET WS-GOT-CLIENT-NAME-NO TO TRUE.

           PERFORM  4800-PROCESS-ATTACHMENT
               THRU 4800-PROCESS-ATTACHMENT-X.

           IF  WS-ATTACH-COMPLETED
               GO TO 4000-PROCESS-ATTACH-X
           END-IF.

      *
      * LOOK FOR LABU TEST RECORD
      *
           PERFORM  8000-BUILD-LABU-KEY
               THRU 8000-BUILD-LABU-KEY-X.

           PERFORM  LABU-1000-READ
               THRU LABU-1000-READ-X.

           IF  NOT WLABU-IO-OK
      *MSG: UNMATCHED TEST NOT FOUND - (@1)
               MOVE 'NS16900013'      TO WGLOB-MSG-REF-INFO
               MOVE WLABU-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-ATTACH-X
           END-IF.

      *
      * LOAD LABU INFORMATION
      *
           MOVE RLABU-CLI-LTST-SEQ-NUM TO MIR-CLI-LTST-SEQ-NUM.
           MOVE RLABU-CLI-LTST-SUR-NM TO MIR-CLI-LTST-SUR-NM.
015904*    MOVE RLABU-CLI-GIV-NM      TO MIR-CLI-GIV-NM.
015904     MOVE RLABU-CLI-GIV-NM      TO MIR-CLI-INDV-GIV-NM.
015904*    MOVE RLABU-CLI-MID-INIT-NM TO MIR-CLI-MID-INIT-NM.
015904     MOVE RLABU-CLI-MID-INIT-NM TO MIR-CLI-INDV-MID-NM.
           MOVE RLABU-CLI-SEX-CD      TO MIR-CLI-SEX-CD.

           MOVE RLABU-CLI-BTH-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-BTH-DT.

557695*    MOVE RLABU-CLI-SIN-ID      TO MIR-CLI-TAX-ID.
557695     MOVE RLABU-CLI-TAX-ID      TO MIR-CLI-TAX-ID.
           MOVE RLABU-LAB-GEN-REF-ID  TO MIR-LAB-GEN-REF-ID.

      *
      * DISPLAY AL INFORMATION
      *

           PERFORM  4010-SET-PAGE-KEY
               THRU 4010-SET-PAGE-KEY-X.

           IF  MIR-DV-BCKWRD-SCROLL-IND = 'Y'
               PERFORM  4500-PREV-PAGE
                   THRU 4500-PREV-PAGE-X
           ELSE
               MOVE 1 TO WS-LINE
               PERFORM  4100-NEXT-PAGE
                   THRU 4100-NEXT-PAGE-X
           END-IF.

       4000-PROCESS-ATTACH-X.
           EXIT.

      *------------------
       4010-SET-PAGE-KEY.
      *------------------
      *
      * SET PAGE KEY: SET KEY FOR START OF ATTACH SCREEN BROWSE
      *


           IF  MIR-DV-PRCES-STATE-CD = '1'
           AND MIR-CLI-ID            = SPACES
           AND MIR-DV-BCKWRD-SCROLL-IND NOT = 'Y'
015508         PERFORM  8200-INIT-CLNN-KEY
015508             THRU 8200-INIT-CLNN-KEY-X
015508         MOVE RLABU-CLI-LTST-SUR-NM    TO WCLNN-CLI-INDV-SUR-NM
015508         MOVE RLABU-CLI-GIV-NM         TO WCLNN-CLI-INDV-GIV-NM
015508         GO TO 4010-SET-PAGE-KEY-X
           END-IF.

           IF  MIR-CLI-ID        NOT = SPACES
020478         PERFORM  8200-INIT-CLNN-KEY
020478             THRU 8200-INIT-CLNN-KEY-X
015508         IF  WS-GOT-CLIENT-NAME-NO
015508             PERFORM  8300-GET-CLIENT-NAME
015508                 THRU 8300-GET-CLIENT-NAME-X
020478*        END-IF
020478*        IF  NOT WCLNM-IO-OK
020478             IF  NOT L2435-RETRN-OK
015508                 GO TO 4010-SET-PAGE-KEY-X
020478             END-IF
020478         END-IF
020478*        ELSE
020478*            PERFORM  8200-INIT-CLNN-KEY
020478*                THRU 8200-INIT-CLNN-KEY-X
020478*            MOVE RCLNM-CLI-INDV-SUR-NM TO WCLNN-CLI-INDV-SUR-NM
020478*            MOVE RCLNM-CLI-INDV-GIV-NM TO WCLNN-CLI-INDV-GIV-NM
020478         MOVE L2435-CLI-SUR-NM TO WCLNN-CLI-INDV-SUR-NM
020478         MOVE L2435-CLI-GIV-NM TO WCLNN-CLI-INDV-GIV-NM
020478*        END-IF
           END-IF.

       4010-SET-PAGE-KEY-X.
           EXIT.

      *---------------
       4100-NEXT-PAGE.
      *---------------
      *
      * DISPLAY NEXT PAGE
      *

015508*    MOVE HIGH-VALUES           TO WCLIE-ENDBR-KEY.
015508*    MOVE WWKDT-HIGH-DT         TO WCLIE-ENDBR-CLI-BTH-DT.
020478     MOVE WWKDT-LOW-DT          TO WCLNN-CLI-INDV-EFF-DT.
015508     MOVE WCLNN-KEY             TO WCLNN-ENDBR-KEY.
015508     MOVE HIGH-VALUES           TO WCLNN-ENDBR-CLI-INDV-SUR-NM.
015508     MOVE HIGH-VALUES           TO WCLNN-ENDBR-CLI-INDV-GIV-NM.
015508     MOVE HIGH-VALUES           TO WCLNN-ENDBR-CLI-ID.
020478     MOVE WWKDT-HIGH-DT         TO WCLNN-ENDBR-CLI-INDV-EFF-DT.

           PERFORM  4200-DISPLAY-NEXT-PAGE
               THRU 4200-DISPLAY-NEXT-PAGE-X.

       4100-NEXT-PAGE-X.
           EXIT.

      *-----------------------
       4200-DISPLAY-NEXT-PAGE.
      *-----------------------
      *
      * BROWSE FORWARD FROM THE CURRENT BROWSE KEY, LOADING RECORDS
      * THE SCREEN LINE BEGINNING WITH WS-LINE, UNTIL FULL OR
      * END-OF-FILE
      *

           PERFORM  CLNN-1000-BROWSE
               THRU CLNN-1000-BROWSE-X.

           PERFORM  CLNN-2000-READ-NEXT
               THRU CLNN-2000-READ-NEXT-X.

           IF  NOT WCLNN-IO-OK
               PERFORM  CLNN-3000-END-BROWSE
                   THRU CLNN-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 4200-DISPLAY-NEXT-PAGE-X
           END-IF.

      *
      * LOAD SCREEN DATA ARRAY
      *
020478     MOVE 1             TO WS-LINE-CHANGE.
           PERFORM  4210-DISPLAY-RECORD-NEXT
               THRU 4210-DISPLAY-RECORD-NEXT-X
020478*     VARYING WS-LINE FROM WS-LINE BY 1
              UNTIL WS-LINE > WS-MAX-ATTACH-SCREEN-LINES
                 OR NOT WCLNN-IO-OK.

           IF  WCLNN-IO-OK
               MOVE RCLNM-CLI-ID TO WCLI-CLI-ID
               PERFORM  CLI-1000-READ
                   THRU CLI-1000-READ-X
               IF  NOT WCLI-IO-OK
                   PERFORM  CLNN-3000-END-BROWSE
                       THRU CLNN-3000-END-BROWSE-X
                   GO TO 4200-DISPLAY-NEXT-PAGE-X
               END-IF
               PERFORM  9250-UPDATE-SCREEN-KEYS
                   THRU 9250-UPDATE-SCREEN-KEYS-X
           END-IF.

      *
      * COMPLETION MESSAGE
      *
           IF  WCLNN-IO-OK
               IF  MIR-DV-PRCES-STATE-CD = '1'
      *MSG: ** TO VIEW MORE DATA PRESS ENTER **
                   MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
                   SET WGLOB-MORE-DATA-EXISTS     TO TRUE
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               IF  WS-LINE > 1
      *MSG: END OF FILE REACHED
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORDS FOUND TO DISPLAY
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  CLNN-3000-END-BROWSE
               THRU CLNN-3000-END-BROWSE-X.

       4200-DISPLAY-NEXT-PAGE-X.
           EXIT.

      *-------------------------
       4210-DISPLAY-RECORD-NEXT.
      *-------------------------
      *
      * DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE GIVEN BY
      * WS-LINE AND RETRIEVE THE NEXT RECORD.
      *

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  CLNN-2000-READ-NEXT
               THRU CLNN-2000-READ-NEXT-X.

       4210-DISPLAY-RECORD-NEXT-X.
           EXIT.

      *---------------
       4500-PREV-PAGE.
      *---------------
      *
      * DISPLAY PREVIOUS PAGE
      *
           MOVE WS-MAX-ATTACH-SCREEN-LINES TO WS-LINE.
015508*    MOVE LOW-VALUES            TO WCLIE-ENDBR-KEY.
015508*    MOVE WWKDT-LOW-DT          TO WCLIE-ENDBR-CLI-BTH-DT.
020478     MOVE WWKDT-LOW-DT          TO WCLNN-CLI-INDV-EFF-DT.
015508     MOVE WCLNN-KEY             TO WCLNN-ENDBR-KEY.
015508     MOVE LOW-VALUES            TO WCLNN-ENDBR-CLI-INDV-SUR-NM.
015508     MOVE LOW-VALUES            TO WCLNN-ENDBR-CLI-INDV-GIV-NM.
015508     MOVE LOW-VALUES            TO WCLNN-ENDBR-CLI-ID.
020478     MOVE WWKDT-HIGH-DT         TO WCLNN-ENDBR-CLI-INDV-EFF-DT.

           PERFORM  4600-DISPLAY-PREV-PAGE
               THRU 4600-DISPLAY-PREV-PAGE-X.

       4500-PREV-PAGE-X.
           EXIT.

      *-----------------------
       4600-DISPLAY-PREV-PAGE.
      *-----------------------
      *
      * BROWSE BACKWARDS FROM THE CURRENT BROWSE KEY, LOADING RECORDS
      * THE SCREEN, BEGINNING WITH WS-LINE AND REDUCING, UNTIL SCREEN
      * OR END-OF-FILE.
      *

           PERFORM  CLNN-1000-BROWSE-PREV
               THRU CLNN-1000-BROWSE-PREV-X.

           PERFORM  CLNN-2000-READ-PREV
               THRU CLNN-2000-READ-PREV-X.

           IF  NOT WCLNN-IO-OK
               PERFORM  CLNN-3000-END-BROWSE-PREV
                   THRU CLNN-3000-END-BROWSE-PREV-X
      *MSG: 'CANNOT SCROLL BACKWARD'
               MOVE 'XS00000241' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-TOP-OF-PAGE TO TRUE
               GO TO 4600-DISPLAY-PREV-PAGE-X
           END-IF.

      *
      * LOAD SCREEN DATA ARRAY
      *
020478     MOVE -1            TO WS-LINE-CHANGE.
           PERFORM  4610-DISPLAY-RECORD-PREV
               THRU 4610-DISPLAY-RECORD-PREV-X
020478*     VARYING WS-LINE FROM WS-LINE BY -1
              UNTIL WS-LINE < 1
                 OR NOT WCLNN-IO-OK.

           IF  WCLNN-IO-EOF
      *
      * MSG: BEGINNING OF FILE ENCOUNTERED
      *
               MOVE 'XS00000098' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WS-LINE < 1
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *
      * NEED TO MOVE DATA UP THE PAGE
      *
                   MOVE WS-LINE TO WS-REMAINING-LINES
                   COMPUTE WS-LINES-TO-MOVE =
                           WS-MAX-ATTACH-SCREEN-LINES
                         - WS-REMAINING-LINES
                   COMPUTE WS-FIRST-MOVE-LINE =
                           WS-LINE
                         + 1
                   PERFORM  4700-REFORMAT-PREV
                       THRU 4700-REFORMAT-PREV-X
                    VARYING WS-LINE FROM WS-FIRST-MOVE-LINE BY 1
                      UNTIL WS-LINE > WS-MAX-ATTACH-SCREEN-LINES
015508             PERFORM  8300-GET-CLIENT-NAME
015508                 THRU 8300-GET-CLIENT-NAME-X
015508             PERFORM  8200-INIT-CLNN-KEY
015508                 THRU 8200-INIT-CLNN-KEY-X
020478*            MOVE RCLNM-CLI-INDV-SUR-NM TO WCLNN-CLI-INDV-SUR-NM
020478*            MOVE RCLNM-CLI-INDV-GIV-NM TO WCLNN-CLI-INDV-GIV-NM
020478             MOVE L2435-CLI-SUR-NM TO WCLNN-CLI-INDV-SUR-NM
020478             MOVE L2435-CLI-GIV-NM TO WCLNN-CLI-INDV-GIV-NM
                   COMPUTE WS-LINE =
                           WS-LINES-TO-MOVE
                         + 1
                   PERFORM  4100-NEXT-PAGE
                       THRU 4100-NEXT-PAGE-X
               END-IF
           ELSE
               IF  WCLNN-IO-OK
               AND MIR-DV-PRCES-STATE-CD = '1'
      *MSG: ** TO VIEW MORE DATA PRESS ENTER **
                   MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
                   SET WGLOB-MORE-DATA-EXISTS     TO TRUE
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *
      * FINISH BROWSE
      *
           PERFORM  CLNN-3000-END-BROWSE-PREV
               THRU CLNN-3000-END-BROWSE-PREV-X.

       4600-DISPLAY-PREV-PAGE-X.
           EXIT.

      *-------------------------
       4610-DISPLAY-RECORD-PREV.
      *-------------------------
      *
      * DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE GIVEN BY
      * WS-LINE AND RETRIEVE THE PREVIOUS RECORD.
      *

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  CLNN-2000-READ-PREV
               THRU CLNN-2000-READ-PREV-X.

       4610-DISPLAY-RECORD-PREV-X.
           EXIT.

      *-------------------
       4700-REFORMAT-PREV.
      *-------------------
      *
      * HIT BEGINNING OF FILE BEFORE FULL PAGE. NEED TO MOVE UP DATA
      *
           COMPUTE WS-OFFSET = WS-LINE - WS-REMAINING-LINES.
           MOVE MIR-DV-INSRD-CLI-NM-T (WS-LINE)
             TO MIR-DV-INSRD-CLI-NM-T (WS-OFFSET).

           MOVE MIR-CLI-ID-T (WS-LINE)
             TO MIR-CLI-ID-T (WS-OFFSET).

           MOVE MIR-CLI-BTH-DT-T (WS-LINE)
             TO MIR-CLI-BTH-DT-T (WS-OFFSET).

           MOVE MIR-CLI-TAX-ID-T (WS-LINE)
             TO MIR-CLI-TAX-ID-T (WS-OFFSET).

           MOVE MIR-CLI-SEX-CD-T (WS-LINE)
             TO MIR-CLI-SEX-CD-T (WS-OFFSET).

       4700-REFORMAT-PREV-X.
           EXIT.

      *------------------------
       4800-PROCESS-ATTACHMENT.
      *------------------------
      *
      * PROCESS ATTACHMENT: MOVE UNMATCHED LAB RESULTS TO MATCHED LAB
      * AND DELETE UNMATCHED LAB RESULTS
      *

           IF  MIR-DV-PRCES-STATE-CD = '1'
               GO TO 4800-PROCESS-ATTACHMENT-X
           END-IF.

      *
      * GET LABU RECORD
      *
           PERFORM  8000-BUILD-LABU-KEY
               THRU 8000-BUILD-LABU-KEY-X.

           PERFORM  LABU-1000-READ
               THRU LABU-1000-READ-X.

           IF  NOT WLABU-IO-OK
      *MSG: RECORD LOST - (@1) - CALL SYSTEMS
               MOVE 'XS00000116'      TO WGLOB-MSG-REF-INFO
               MOVE WLABU-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4800-PROCESS-ATTACHMENT-X
           END-IF.

           IF  WS-ATTACH-VERIFIED
               PERFORM  4802-PROCESS-ATTACHMENT-2
                   THRU 4802-PROCESS-ATTACHMENT-2-X
               GO TO 4800-PROCESS-ATTACHMENT-X
           END-IF.

      *
      * CHECK CLIENT VALUES AGAINST LAB VALUES
      *
           MOVE 'N'                   TO WS-VERIFY-REQD-SW.
           MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

           PERFORM  CLI-1000-READ
               THRU CLI-1000-READ-X.

           IF  NOT WCLI-IO-OK
      *MSG: LOST CLIENT (@1) - CALL SYSTEMS
               MOVE 'XS00000090'      TO WGLOB-MSG-REF-INFO
               MOVE WCLI-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4800-PROCESS-ATTACHMENT-X
           END-IF.

015508     PERFORM  8300-GET-CLIENT-NAME
015508         THRU 8300-GET-CLIENT-NAME-X.
020478*    IF  NOT WCLNM-IO-OK
020478     IF  NOT L2435-RETRN-OK
015508         GO TO 4800-PROCESS-ATTACHMENT-X
015508     ELSE
015508         SET WS-GOT-CLIENT-NAME TO TRUE
015508     END-IF.

      *
      * CHECK LAST NAME
      *
020478*    IF  RCLNM-CLI-INDV-SUR-NM NOT = RLABU-CLI-LTST-SUR-NM
020478     IF  L2435-CLI-SUR-NM NOT = RLABU-CLI-LTST-SUR-NM
      *MSG: CLIENT LAST NAME DOES NOT MATCH LAB LAST
               MOVE 'NS16900006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VERIFY-REQD-SW
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 4800-PROCESS-ATTACHMENT-X
               END-IF
           END-IF.

      *
      * CHECK DATE OF BIRTH
      *
           IF  RCLI-CLI-BTH-DT  NOT = RLABU-CLI-BTH-DT
      *MSG: CLIENT BIRTH DATE DOES NOT MATCH LAB
      *     BIRTH DATE
               MOVE 'NS16900007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VERIFY-REQD-SW
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 4800-PROCESS-ATTACHMENT-X
               END-IF
           END-IF.

      *
      * CHECK SEX
      *
           IF  RCLI-CLI-SEX-CD NOT = RLABU-CLI-SEX-CD
      *MSG: CLIENT SEX DOES NOT MATCH LAB SEX
               MOVE 'NS16900008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VERIFY-REQD-SW
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 4800-PROCESS-ATTACHMENT-X
               END-IF
           END-IF.

      *
      * CHECK SIN
      *
557695*    IF  RCLI-CLI-SIN-ID NOT = RLABU-CLI-SIN-ID
557695     IF  RCLI-CLI-TAX-ID NOT = RLABU-CLI-TAX-ID
      *MSG: CLIENT SIN DOES NOT MATCH LAB SIN
               MOVE 'NS16900018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VERIFY-REQD-SW
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 4800-PROCESS-ATTACHMENT-X
               END-IF
           END-IF.

      *
      * CHECK FIRST NAME
      *
020478*    IF  RCLNM-CLI-INDV-GIV-NM NOT = RLABU-CLI-GIV-NM
020478     IF  L2435-CLI-GIV-NM NOT = RLABU-CLI-GIV-NM
      *MSG: CLIENT FIRST NAME DOES NOT MATCH LAB
      *     FIRST NAME
               MOVE 'NS16900009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VERIFY-REQD-SW
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 4800-PROCESS-ATTACHMENT-X
               END-IF
           END-IF.

      *
      * CHECK MIDDLE INITIAL
      *
020478*    IF  RCLNM-CLI-INDV-MID-NM NOT = RLABU-CLI-MID-INIT-NM
020478     IF  L2435-CLI-MID-INIT-NM NOT = RLABU-CLI-MID-INIT-NM
      *MSG: CLIENT INITIAL DOES NOT MATCH LAB INITIA
               MOVE 'NS16900010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VERIFY-REQD-SW
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 4800-PROCESS-ATTACHMENT-X
               END-IF
           END-IF.

      *
      * IF ANYTHING DID NOT MATCH, A VERIFY WILL BE REQUIRED.
      *
           IF  WS-VERIFY-REQD
           AND MIR-DV-PRCES-STATE-CD NOT = '3'
               SET MIR-RETRN-VERIF-REQIR TO TRUE
               MOVE 'NS16900004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
      * FORCE FIELD SHOULD BE 3
               GO TO 4800-PROCESS-ATTACHMENT-X
           END-IF.

           PERFORM  4802-PROCESS-ATTACHMENT-2
               THRU 4802-PROCESS-ATTACHMENT-2-X.

       4800-PROCESS-ATTACHMENT-X.
           EXIT.

      *--------------------------
       4802-PROCESS-ATTACHMENT-2.
      *--------------------------
      *
      * ALL CHECKS PASSED, CONTINUE
      *
           PERFORM  4850-ATTACH-BLOCK
               THRU 4850-ATTACH-BLOCK-X.

      *
      * THIS NEW LAB RESULT MAY AFFECT THE STATUS OF A REQUIREMENT FOR
      * THE CLIENT SO REQUIREMENT RESOLUTION PROCESSING IS PERFORMED.
      *
           PERFORM  7180-1000-BUILD-PARM-INFO
               THRU 7180-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L7180-CLI-ID.
           MOVE RLABR-CLI-LTST-LAB-ID TO L7180-LAB-CD.
           MOVE SPACES                TO L7180-REQIR-CD.
           MOVE SPACES                TO L7180-SEQ-NUM.

           PERFORM  7180-1000-RESOLVE-REQT
               THRU 7180-1000-RESOLVE-REQT-X.

           IF  L7180-CLI-DECISION-RQST
               PERFORM  1030-1000-BUILD-PARM-INFO
                   THRU 1030-1000-BUILD-PARM-INFO-X
               MOVE MIR-CLI-ID        TO L1030-CLIENT-ID
               PERFORM  1030-1000-CLIENT-DECISION
                   THRU 1030-1000-CLIENT-DECISION-X
           END-IF.

           MOVE 'Y'                   TO WS-ATTACH-COMPLETED-SW.

       4802-PROCESS-ATTACHMENT-2-X.
           EXIT.

      *------------------
       4850-ATTACH-BLOCK.
      *------------------
      *
      * ATTACHMENT WILL NOW BE BY ENTIRE BLOCK OF LABU RECORDS,
      * NOT JUST SINGLE LABU RECORDS.  LOGIC SIMILAR TO THE
      * BLOCK DELETE WILL BE USED.
      *
      *  STORE FIRST-NAME, INITIAL, SEX, DOB, SIN, LAB SINCE
      *  THE KEY FOR THIS FILE DOES NOT UNIQUELY IDENTIFY AN
      *  INDIVIDUAL
      *
           MOVE RLABU-CLI-GIV-NM      TO WS-SAVE-FIRST-NAME.
           MOVE RLABU-CLI-MID-INIT-NM TO WS-SAVE-INITIAL.
           MOVE RLABU-CLI-BTH-DT      TO WS-SAVE-DATE-OF-BIRTH.
           MOVE RLABU-CLI-SEX-CD      TO WS-SAVE-SEX.
557695*    MOVE RLABU-CLI-SIN-ID         TO WS-SAVE-SIN-NUMBER.
557695     MOVE RLABU-CLI-TAX-ID      TO WS-SAVE-SIN-NUMBER.
           MOVE RLABU-LAB-ID          TO WS-SAVE-CODE.
      *
      *  AT THIS POINT WE HAVE TO BACK UP TO GET THE FIRST RECORD
      *  OF THE BLOCK TO BE ATTACHED, IN CASE THE USER ENTERED THE
      *  ATTACH CODE AT SOME RECORD PAST THE FIRST ONE.
      *
           MOVE RLABU-CLI-LTST-SUR-NM TO WLABU-CLI-LTST-SUR-NM.
           MOVE ZEROS                 TO WLABU-CLI-LTST-SEQ-NUM-N.
           MOVE WLABU-KEY             TO WLABU-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WLABU-ENDBR-CLI-LTST-SEQ-NUM.
           MOVE SPACES                TO RLABU-REC-INFO.
      *
      *  POSITION AT THE FIRST RECORD OF THE BLOCK TO BE ATTACHED.
      *
           PERFORM  6220-LOCATE-FIRST-REC
               THRU 6220-LOCATE-FIRST-REC-X.

           MOVE RLABU-CLI-LTST-SEQ-NUM TO WLABU-CLI-LTST-SEQ-NUM.
           MOVE +0                    TO WS-ATTACH-CNT.

           PERFORM  4880-GET-NEXT-LABU
               THRU 4880-GET-NEXT-LABU-X.

           PERFORM  4870-ATTACH-DELETE-LABU
               THRU 4870-ATTACH-DELETE-LABU-X
              UNTIL NOT WLABU-IO-OK.

      *MSG: (@1) LABU RECORDS ATTACHED -- CONTINUE
           MOVE 'NS16900014'          TO WGLOB-MSG-REF-INFO
           MOVE WS-ATTACH-CNT-X       TO WGLOB-MSG-PARM (1)
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4850-ATTACH-BLOCK-X.
           EXIT.

      *------------------------
       4870-ATTACH-DELETE-LABU.
      *------------------------
      *
      * CREATE MATCHED TEST RECORD
      *
           MOVE MIR-CLI-ID            TO WLABR-CLI-ID.
           MOVE RLABU-CLI-LTST-DT     TO WLABR-CLI-LTST-DT.
           MOVE RLABU-LTST-ID         TO WLABR-LTST-ID.
           MOVE HIGH-VALUES           TO WLABR-CLI-LTST-SEQ-NUM.

           MOVE WLABR-KEY             TO WLABR-ENDBR-KEY.
           MOVE LOW-VALUES            TO WLABR-ENDBR-CLI-LTST-SEQ-NUM.

           PERFORM  LABR-1000-BROWSE-PREV
               THRU LABR-1000-BROWSE-PREV-X.

           MOVE 'N'                   TO WS-END-LIST-SW.
           IF  WLABR-IO-OK
               MOVE 'Y'               TO WS-END-LIST-SW
               PERFORM  LABR-2000-READ-PREV
                   THRU LABR-2000-READ-PREV-X
           END-IF.

           IF  WLABR-IO-OK
               IF RLABR-CLI-LTST-SEQ-NUM-N NOT < WLABR-MAX-SEQUENCE-NO
      *MSG: CANNOT CREATE ANY MORE TESTS FOR (@1)
                   MOVE 'NS16900005'  TO WGLOB-MSG-REF-INFO
                   MOVE WLABR-KEY     TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  LABR-3000-END-BROWSE-PREV
                       THRU LABR-3000-END-BROWSE-PREV-X
                   MOVE RLABU-KEY     TO WLABU-KEY
                   PERFORM  4880-GET-NEXT-LABU
                       THRU 4880-GET-NEXT-LABU-X
                   GO TO 4870-ATTACH-DELETE-LABU-X
               ELSE
                   ADD +1             TO RLABR-CLI-LTST-SEQ-NUM-N
                   MOVE RLABR-CLI-LTST-SEQ-NUM-N
                                      TO WLABR-CLI-LTST-SEQ-NUM-N
               END-IF
           ELSE
               MOVE MIR-CLI-ID        TO WLABR-CLI-ID
               MOVE RLABU-CLI-LTST-DT TO WLABR-CLI-LTST-DT
               MOVE RLABU-LTST-ID     TO WLABR-LTST-ID
               MOVE +1                TO WLABR-CLI-LTST-SEQ-NUM-N
               MOVE WLABR-KEY         TO RLABR-KEY
           END-IF.

           IF  WS-END-LIST-REQUIRED
               PERFORM  LABR-3000-END-BROWSE-PREV
                   THRU LABR-3000-END-BROWSE-PREV-X
           END-IF.

           PERFORM  LABR-1000-CREATE
               THRU LABR-1000-CREATE-X.

      *
      * LOAD LABR RECORD
      *
           MOVE 'A'                   TO RLABR-RSLT-REC-CREAT-CD.
           MOVE RLABU-LAB-ID          TO RLABR-CLI-LTST-LAB-ID.
018645*    MOVE RLABU-CLI-LTST-RSLT-TXT
018645     MOVE RLABU-CLI-LTST-RSLT-CD
                                      TO RLABR-CLI-LTST-RSLT-CD.
018645     MOVE RLABU-RSLT-QTY-TXT    TO RLABR-RSLT-QTY-TXT.
           MOVE RLABU-SERUM-DESC-TXT  TO RLABR-SERUM-DESC-TXT.
           MOVE RLABU-URIN-DESC-TXT   TO RLABR-URIN-DESC-TXT.
           MOVE RLABU-PREV-MEAL-DT    TO RLABR-PREV-MEAL-DT.
           MOVE RLABU-PREV-MEAL-TIME  TO RLABR-PREV-MEAL-TIME.
           MOVE RLABU-BLOOD-DRW-DT    TO RLABR-BLOOD-DRW-DT.
           MOVE RLABU-BLOOD-DRW-TIME  TO RLABR-BLOOD-DRW-TIME.
           MOVE RLABU-SAMPL-VOID-DT   TO RLABR-SAMPL-VOID-DT.
           MOVE RLABU-LAB-RMRK-NUM    TO RLABR-LAB-RMRK-NUM.
           MOVE RLABU-CLI-LTST-RMRK-TXT
                                      TO RLABR-CLI-LTST-RMRK-TXT.
           MOVE RLABU-CLI-LTST-STAT-CD TO RLABR-CLI-LTST-STAT-CD.
           MOVE RLABU-RSLT-PRECSN-QTY TO RLABR-RSLT-PRECSN-QTY.
018645     MOVE RLABU-TST-RSLT-TYP-CD TO RLABR-TST-RSLT-TYP-CD.
           MOVE RLABU-LAB-MIN-NRNG-QTY TO RLABR-LAB-MIN-NRNG-QTY.
           MOVE RLABU-LAB-MAX-NRNG-QTY TO RLABR-LAB-MAX-NRNG-QTY.
           MOVE RLABU-CO-MIN-NRNG-QTY TO RLABR-CO-MIN-NRNG-QTY.
           MOVE RLABU-CO-MAX-NRNG-QTY TO RLABR-CO-MAX-NRNG-QTY.
           MOVE RLABU-ALPHA-RESP-CD   TO RLABR-ALPHA-RESP-CD.
           MOVE RLABU-UNIT-MESUR-TXT  TO RLABR-UNIT-MESUR-TXT.

           IF  RLABU-CLI-LTST-STAT-CD = SPACES
           AND RLABU-LTST-ID     NOT = 'XXXX'
           AND RLABU-LTST-ID     NOT = 'YYYY'
               MOVE 'Y'               TO RLABR-BAD-LAB-INFO-IND
           END-IF.

           PERFORM  LABR-1000-WRITE
               THRU LABR-1000-WRITE-X.
           ADD  +1                    TO WS-ATTACH-CNT.

           MOVE RLABU-KEY             TO WLABU-KEY.

           PERFORM  LABU-2000-DELETE-WITH-KEY
               THRU LABU-2000-DELETE-WITH-KEY-X.

           PERFORM  4880-GET-NEXT-LABU
               THRU 4880-GET-NEXT-LABU-X.

       4870-ATTACH-DELETE-LABU-X.
           EXIT.

      *-------------------
       4880-GET-NEXT-LABU.
      *-------------------

           PERFORM  LABU-1000-BROWSE
               THRU LABU-1000-BROWSE-X.

           IF  NOT WLABU-IO-OK
               GO TO 4880-GET-NEXT-LABU-X
           END-IF.

           PERFORM  LABU-2000-READ-NEXT
               THRU LABU-2000-READ-NEXT-X.

           IF  NOT WLABU-IO-OK
               PERFORM  LABU-3000-END-BROWSE
                   THRU LABU-3000-END-BROWSE-X
               MOVE 7                 TO WLABU-IO-STATUS
           ELSE
               IF  RLABU-CLI-GIV-NM        NOT = WS-SAVE-FIRST-NAME
               OR  RLABU-CLI-MID-INIT-NM   NOT = WS-SAVE-INITIAL
               OR  RLABU-CLI-BTH-DT        NOT = WS-SAVE-DATE-OF-BIRTH
               OR  RLABU-CLI-SEX-CD        NOT = WS-SAVE-SEX
557695*        OR  RLABU-CLI-SIN-ID        NOT = WS-SAVE-SIN-NUMBER
557695         OR  RLABU-CLI-TAX-ID        NOT = WS-SAVE-SIN-NUMBER
               OR  RLABU-LAB-ID            NOT = WS-SAVE-CODE
                   PERFORM  LABU-3000-END-BROWSE
                       THRU LABU-3000-END-BROWSE-X
                   MOVE 7             TO WLABU-IO-STATUS
               ELSE
                   PERFORM  LABU-3000-END-BROWSE
                       THRU LABU-3000-END-BROWSE-X
               END-IF
           END-IF.

       4880-GET-NEXT-LABU-X.
           EXIT.

      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

            PERFORM  6200-PROCESS-DELETE
                THRU 6200-PROCESS-DELETE-X.

       6000-PROCESS-DELETE-X.
           EXIT.

      *--------------------
       6200-PROCESS-DELETE.
      *--------------------
      *
      * DELETE THE RECORD.
      *

           MOVE MIR-CLI-LTST-SUR-NM   TO WLABU-CLI-LTST-SUR-NM.
           MOVE MIR-CLI-LTST-SEQ-NUM  TO WLABU-CLI-LTST-SEQ-NUM.
           MOVE WLABU-KEY             TO WLABU-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WLABU-ENDBR-CLI-LTST-SEQ-NUM.

           PERFORM  LABU-1000-READ
               THRU LABU-1000-READ-X.

           IF  NOT WLABU-IO-OK
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WLABU-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6200-PROCESS-DELETE-X
           END-IF.

      *
      * STORE FIRST-NAME, INITIAL, SEX, DOB, SIN, LAB SINCE
      * THE KEY FOR THIS FILE DOES NOT UNIQUELY IDENTIFY AN
      * INDIVIDUAL
      *

           MOVE RLABU-CLI-GIV-NM      TO WS-SAVE-FIRST-NAME.
           MOVE RLABU-CLI-MID-INIT-NM TO WS-SAVE-INITIAL.
           MOVE RLABU-CLI-BTH-DT      TO WS-SAVE-DATE-OF-BIRTH.
           MOVE RLABU-CLI-SEX-CD      TO WS-SAVE-SEX.
557695*    MOVE RLABU-CLI-SIN-ID         TO WS-SAVE-SIN-NUMBER.
557695     MOVE RLABU-CLI-TAX-ID      TO WS-SAVE-SIN-NUMBER.
           MOVE RLABU-LAB-ID          TO WS-SAVE-CODE.

      *
      * AT THIS POINT WE HAVE TO BACK UP TO GET THE FIRST RECORD
      * OF THE BLOCK TO BE DELETED, IN CASE THE USER ENTERED THE
      * DELETE CODE AT SOME RECORD PAST THE FIRST ONE.
      *

           MOVE MIR-CLI-LTST-SUR-NM   TO WLABU-CLI-LTST-SUR-NM.
           MOVE ZEROS                 TO WLABU-CLI-LTST-SEQ-NUM.
           MOVE WLABU-KEY             TO WLABU-ENDBR-KEY.
           MOVE HIGH-VALUES           TO
                WLABU-ENDBR-CLI-LTST-SEQ-NUM.
           MOVE SPACES                TO RLABU-REC-INFO.

      *
      * POSITION AT THE FIRST RECORD OF THE BLOCK TO BE DELETED.
      *

           PERFORM  6220-LOCATE-FIRST-REC
               THRU 6220-LOCATE-FIRST-REC-X.

           MOVE RLABU-CLI-LTST-SEQ-NUM TO WLABU-CLI-LTST-SEQ-NUM.

           PERFORM  LABU-1000-BROWSE
               THRU LABU-1000-BROWSE-X.

           PERFORM  LABU-2000-READ-NEXT
               THRU LABU-2000-READ-NEXT-X.

           IF  WLABU-IO-OK
               PERFORM  6210-DELETE-LABU
                   THRU 6210-DELETE-LABU-X
                  UNTIL NOT WLABU-IO-OK
               PERFORM  LABU-3000-END-BROWSE
                   THRU LABU-3000-END-BROWSE-X
           END-IF.

      *MSG: DELETE COMPLETED - CONTINUE
           MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6200-PROCESS-DELETE-X.
           EXIT.

      *-----------------
       6210-DELETE-LABU.
      *-----------------
      *
      * DELETE LABU BLOCK, STARTING AT THE RECORD SELECTED
      * AND CONTINUE UNTIL THE CLIENT INFORMATION CHANGES.
      *

           MOVE RLABU-KEY TO WLABU-KEY.

           PERFORM  LABU-3000-END-BROWSE
               THRU LABU-3000-END-BROWSE-X.

           PERFORM  LABU-2000-DELETE-WITH-KEY
               THRU LABU-2000-DELETE-WITH-KEY-X.

           PERFORM  LABU-1000-BROWSE
               THRU LABU-1000-BROWSE-X.

           IF  WLABU-IO-EOF
               GO TO 6210-DELETE-LABU-X
           END-IF.

           PERFORM  LABU-2000-READ-NEXT
               THRU LABU-2000-READ-NEXT-X.

           IF  RLABU-CLI-GIV-NM      NOT =  WS-SAVE-FIRST-NAME
           OR  RLABU-CLI-MID-INIT-NM NOT =  WS-SAVE-INITIAL
           OR  RLABU-CLI-BTH-DT      NOT =  WS-SAVE-DATE-OF-BIRTH
           OR  RLABU-CLI-SEX-CD      NOT =  WS-SAVE-SEX
557695*    OR  RLABU-CLI-SIN-ID      NOT =  WS-SAVE-SIN-NUMBER
557695     OR  RLABU-CLI-TAX-ID      NOT =  WS-SAVE-SIN-NUMBER
           OR  RLABU-LAB-ID          NOT =  WS-SAVE-CODE
               MOVE 7                 TO WLABU-IO-STATUS
           END-IF.

       6210-DELETE-LABU-X.
           EXIT.

      *----------------------
       6220-LOCATE-FIRST-REC.
      *----------------------

           PERFORM  LABU-1000-BROWSE
               THRU LABU-1000-BROWSE-X.

           IF  NOT WLABU-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6220-LOCATE-FIRST-REC-X
           END-IF.

           PERFORM  LABU-2000-READ-NEXT
               THRU LABU-2000-READ-NEXT-X
              UNTIL (RLABU-CLI-GIV-NM          = WS-SAVE-FIRST-NAME
                AND  RLABU-CLI-MID-INIT-NM     = WS-SAVE-INITIAL
                AND  RLABU-CLI-BTH-DT          = WS-SAVE-DATE-OF-BIRTH
                AND  RLABU-CLI-SEX-CD          = WS-SAVE-SEX
557695*         AND  RLABU-CLI-SIN-ID          = WS-SAVE-SIN-NUMBER
557695          AND  RLABU-CLI-TAX-ID          = WS-SAVE-SIN-NUMBER
                AND  RLABU-LAB-ID              = WS-SAVE-CODE)
                OR   NOT WLABU-IO-OK.

           PERFORM  LABU-3000-END-BROWSE
               THRU LABU-3000-END-BROWSE-X.

       6220-LOCATE-FIRST-REC-X.
           EXIT.

      *--------------------
       8000-BUILD-LABU-KEY.
      *--------------------
      *
      * BUILD LABU READ KEY
      *
           MOVE MIR-CLI-LTST-SUR-NM   TO WLABU-CLI-LTST-SUR-NM.
           IF  MIR-CLI-LTST-SEQ-NUM = SPACES
               MOVE WS-SEQNUM         TO WLABU-CLI-LTST-SEQ-NUM
           ELSE
               MOVE MIR-CLI-LTST-SEQ-NUM
                 TO WLABU-CLI-LTST-SEQ-NUM
           END-IF.

       8000-BUILD-LABU-KEY-X.
           EXIT.

      *-------------------
020478*8100-INIT-CLNM-KEY.
020478*-------------------
020478*
020478*    MOVE ZEROS                    TO WCLNM-KEY.
020478*
020478*    EVALUATE TRUE
020478*
020478*        WHEN WGLOB-COUNTRY-JAPAN
020478*             SET  WCLNM-CLI-INDV-GR-KATAKANA
020478*               TO TRUE
020478*
020478*        WHEN OTHER
020478*             SET  WCLNM-CLI-INDV-GR-ALPHA
020478*               TO TRUE
020478*
020478*    END-EVALUATE.
020478*
020478*    SET  WCLNM-CLI-INDV-NM-TYP-CRNT  TO TRUE.
020478*    MOVE +1 TO WCLNM-CLI-INDV-SEQ-NUM.
020478*
020478*8100-INIT-CLNM-KEY-X.
020478*    EXIT.

      *-------------------
       8200-INIT-CLNN-KEY.
      *-------------------

           MOVE LOW-VALUES               TO WCLNN-KEY.

           EVALUATE TRUE

               WHEN WGLOB-COUNTRY-JAPAN
                    SET  WCLNN-CLI-INDV-GR-KATAKANA
                      TO TRUE

               WHEN OTHER
                    SET  WCLNN-CLI-INDV-GR-ALPHA
                      TO TRUE

           END-EVALUATE.

020478*    SET  WCLNN-CLI-INDV-NM-TYP-CRNT  TO TRUE.

       8200-INIT-CLNN-KEY-X.
           EXIT.

015508*---------------------
015508 8300-GET-CLIENT-NAME.
015508*---------------------
015508
020478*    PERFORM  8100-INIT-CLNM-KEY
020478*        THRU 8100-INIT-CLNM-KEY-X.
020478*    MOVE MIR-CLI-ID               TO WCLNM-CLI-ID.
020478*    PERFORM  CLNM-1000-READ
020478*        THRU CLNM-1000-READ-X.

020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478     MOVE MIR-CLI-ID               TO L2435-CLI-ID.
020478     PERFORM  2435-2000-CRNT-CLI-NAME
020478         THRU 2435-2000-CRNT-CLI-NAME-X.

020478*    IF  NOT WCLNM-IO-OK
020478     IF  NOT L2435-RETRN-OK
015508*MSG: LOST CLIENT (@1) - CALL SYSTEMS
015508         MOVE 'XS00000090'         TO WGLOB-MSG-REF-INFO
020478*        MOVE WCLNM-KEY            TO WGLOB-MSG-PARM (1)
020478         MOVE MIR-CLI-ID           TO WGLOB-MSG-PARM (1)
015508         PERFORM  0260-1000-GENERATE-MESSAGE
015508             THRU 0260-1000-GENERATE-MESSAGE-X
015508         PERFORM  9100-BLANK-DATA-FIELDS
015508             THRU 9100-BLANK-DATA-FIELDS-X
015508     END-IF.
015508
015508 8300-GET-CLIENT-NAME-X.
015508     EXIT.

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      *
      * BLANK DATA FIELDS: SET EACH DATA (NON-KEY AND NON-CONTROL)
      * FIELD ON THE SCREEN TO SPACES.
      *

           IF  WS-BUS-FCN-LIST
               PERFORM  9110-BLANK-BROWSE-SCREEN
                   THRU 9110-BLANK-BROWSE-SCREEN-X
           ELSE
               PERFORM  9120-BLANK-ATTACH-SCREEN
                   THRU 9120-BLANK-ATTACH-SCREEN-X
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *-------------------------
       9110-BLANK-BROWSE-SCREEN.
      *-------------------------
      *
      * BLANK DATA FIELDS: SET EACH DATA (NON-KEY AND NON-CONTROL)
      * FIELD ON THE SCREEN TO SPACES.
      *

           PERFORM  9112-BLANK-BROWSE-LINES
               THRU 9112-BLANK-BROWSE-LINES-X
            VARYING WS-LINE FROM 1 BY 1
              UNTIL (WS-LINE > WS-MAX-LIST-SCREEN-LINES).

       9110-BLANK-BROWSE-SCREEN-X.
           EXIT.

      *------------------------
       9112-BLANK-BROWSE-LINES.
      *------------------------
      *
      *  SET EACH DISPLAY LINE TO BLANKS
      *

           MOVE SPACES        TO MIR-CLI-LTST-SEQ-NUM-T (WS-LINE).
           MOVE SPACES        TO MIR-CLI-LTST-SUR-NM-T (WS-LINE).
015904*    MOVE SPACES        TO MIR-CLI-GIV-NM-T (WS-LINE).
015904     MOVE SPACES        TO MIR-CLI-INDV-GIV-NM-T (WS-LINE).
015904*    MOVE SPACES        TO MIR-CLI-MID-INIT-NM-T (WS-LINE).
015904     MOVE SPACES        TO MIR-CLI-INDV-MID-NM-T (WS-LINE).
           MOVE SPACES        TO MIR-CLI-SEX-CD-T (WS-LINE).
           MOVE SPACES        TO MIR-CLI-BTH-DT-T (WS-LINE).
           MOVE SPACES        TO MIR-CLI-TAX-ID-T (WS-LINE).
           MOVE SPACES        TO MIR-LAB-ID-T (WS-LINE).

       9112-BLANK-BROWSE-LINES-X.
           EXIT.

      *-------------------------
       9120-BLANK-ATTACH-SCREEN.
      *-------------------------
      *
      * BLANK DATA FIELDS: SET EACH DATA (NON-KEY AND NON-CONTROL)
      * FIELD ON THE SCREEN TO SPACES.
      *

015904*    MOVE SPACES        TO MIR-CLI-GIV-NM.
015904     MOVE SPACES        TO MIR-CLI-INDV-GIV-NM.
015904*    MOVE SPACES        TO MIR-CLI-MID-INIT-NM.
015904     MOVE SPACES        TO MIR-CLI-INDV-MID-NM.
           MOVE SPACES        TO MIR-CLI-SEX-CD.
           MOVE SPACES        TO MIR-CLI-BTH-DT.
           MOVE SPACES        TO MIR-CLI-TAX-ID.
           MOVE SPACES        TO MIR-LAB-GEN-REF-ID.

           PERFORM  9122-BLANK-ATTACH-LINES
               THRU 9122-BLANK-ATTACH-LINES-X
            VARYING WS-LINE FROM 1 BY 1
              UNTIL (WS-LINE > WS-MAX-ATTACH-SCREEN-LINES).

       9120-BLANK-ATTACH-SCREEN-X.
           EXIT.

      *------------------------
       9122-BLANK-ATTACH-LINES.
      *------------------------
      *
      * SET EACH DISPLAY LINE TO BLANKS
      *

           MOVE SPACES        TO MIR-DV-INSRD-CLI-NM-T (WS-LINE).
           MOVE SPACES        TO MIR-CLI-SEX-CD-T (WS-LINE).
           MOVE SPACES        TO MIR-CLI-BTH-DT-T (WS-LINE).
           MOVE SPACES        TO MIR-CLI-TAX-ID-T (WS-LINE).
           MOVE SPACES        TO MIR-CLI-ID-T (WS-LINE).

       9122-BLANK-ATTACH-LINES-X.
           EXIT.

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *
      * RECORD TO SCREEN:
      *

           IF  WS-BUS-FCN-LIST
               PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
                   THRU 9210-MOVE-RECORD-TO-SCREEN-1-X
           ELSE
               PERFORM  9220-MOVE-RECORD-TO-SCREEN-2
                   THRU 9220-MOVE-RECORD-TO-SCREEN-2-X
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *-----------------------------
       9210-MOVE-RECORD-TO-SCREEN-1.
      *-----------------------------
      *
      * LOAD SCREEN LINE
      *
           MOVE RLABU-CLI-LTST-SEQ-NUM
                                  TO MIR-CLI-LTST-SEQ-NUM-T (WS-LINE).
           MOVE RLABU-CLI-LTST-SUR-NM
                                   TO MIR-CLI-LTST-SUR-NM-T (WS-LINE).
015904*    MOVE RLABU-CLI-GIV-NM        TO MIR-CLI-GIV-NM-T (WS-LINE).
015904     MOVE RLABU-CLI-GIV-NM        TO MIR-CLI-INDV-GIV-NM-T
015904            (WS-LINE).
           MOVE RLABU-CLI-MID-INIT-NM
015904*                            TO MIR-CLI-MID-INIT-NM-T (WS-LINE).
015904                             TO MIR-CLI-INDV-MID-NM-T (WS-LINE).
           MOVE RLABU-CLI-BTH-DT        TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE     TO MIR-CLI-BTH-DT-T (WS-LINE).
           MOVE RLABU-CLI-SEX-CD      TO MIR-CLI-SEX-CD-T (WS-LINE).
557695*    MOVE RLABU-CLI-SIN-ID      TO MIR-CLI-TAX-ID-T (WS-LINE).
557695     MOVE RLABU-CLI-TAX-ID      TO MIR-CLI-TAX-ID-T (WS-LINE).
           MOVE RLABU-LAB-ID          TO MIR-LAB-ID-T (WS-LINE).
020478     ADD  WS-LINE-CHANGE        TO WS-LINE.

       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.

      *-----------------------------
       9220-MOVE-RECORD-TO-SCREEN-2.
      *-----------------------------
      *
      * SHIFT DATA FROM RECORD BUFFER TO THE SCREEN DISPLAY LINE
      * GIVEN BY THE INPUT ITEM WS-LINE.
      *

      * LOAD SCREEN LINE

020478* CHECK IF IT IS A CURRENT NAME
020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478
020478     MOVE RCLNM-CLI-ID        TO L2435-CLI-ID.
020478
020478     PERFORM  2435-2000-CRNT-CLI-NAME
020478         THRU 2435-2000-CRNT-CLI-NAME-X.
020478
020478     IF  L2435-CLI-INDV-EFF-DT NOT = RCLNM-CLI-INDV-EFF-DT
020478         GO TO 9220-MOVE-RECORD-TO-SCREEN-2-X
020478     END-IF.

           MOVE RCLNM-CLI-ID          TO WCLI-CLI-ID.

           PERFORM  CLI-1000-READ
               THRU CLI-1000-READ-X.

           IF  NOT WCLI-IO-OK
               GO TO 9220-MOVE-RECORD-TO-SCREEN-2-X
           END-IF.

           MOVE RCLI-CLI-ID           TO L5120-CLI-ID.
           PERFORM  5120-1000-CLI-NAME-UPDATE
               THRU 5120-1000-CLI-NAME-UPDATE-X.

           MOVE L5120-CLI-NAME TO MIR-DV-INSRD-CLI-NM-T (WS-LINE).

           MOVE L5120-CLI-ID          TO MIR-CLI-ID-T (WS-LINE).

           IF  WGLOB-SECUR-CNFD-ACCS-CD = 'B'
           OR  WGLOB-SECUR-CNFD-ACCS-CD = 'C'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               IF  RCLI-CLI-CONFIDENTIAL
020478         ADD WS-LINE-CHANGE        TO WS-LINE
                   GO TO 9220-MOVE-RECORD-TO-SCREEN-2-X
               END-IF
           END-IF.

           MOVE RCLI-CLI-BTH-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-BTH-DT-T (WS-LINE).

557695*    MOVE RCLI-CLI-SIN-ID       TO MIR-CLI-TAX-ID-T (WS-LINE).
557695     MOVE RCLI-CLI-TAX-ID       TO MIR-CLI-TAX-ID-T (WS-LINE).
           MOVE RCLI-CLI-SEX-CD       TO MIR-CLI-SEX-CD-T (WS-LINE).
020478     ADD WS-LINE-CHANGE         TO WS-LINE.

       9220-MOVE-RECORD-TO-SCREEN-2-X.
           EXIT.

      *------------------------
       9250-UPDATE-SCREEN-KEYS.
      *------------------------
      *
      * UPDATE THE SCREEN KEYS FROM THE RECORD BUFFER
      *

           IF  WS-BUS-FCN-LIST
               MOVE RLABU-CLI-LTST-SUR-NM
                                      TO MIR-CLI-LTST-SUR-NM
               MOVE RLABU-CLI-LTST-SEQ-NUM
                                      TO MIR-CLI-LTST-SEQ-NUM
           ELSE
               IF  MIR-DV-BCKWRD-SCROLL-IND NOT = 'Y'
                   MOVE RCLI-CLI-ID TO MIR-CLI-ID
               END-IF
           END-IF.

       9250-UPDATE-SCREEN-KEYS-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *
      * SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS
      * WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1030-0000-INIT-PARM-INFO
025970         THRU 1030-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5120-0000-INIT-PARM-INFO
025970         THRU 5120-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7180-0000-INIT-PARM-INFO
025970         THRU 7180-0000-INIT-PARM-INFO-X.
025970
023514     INITIALIZE                         WS-PGM-WORK-AREA.
023514
025970      SET WS-DEFAULT-HOLD-RUN-ID        TO TRUE.
025970      SET WS-DEFAULT-MAX-LIST-LINES     TO TRUE.
025970      SET WS-DEFAULT-MAX-ATTACH-LINES   TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      ****************************************************************
      * TRANSACTION PROCESSING COPYMEMBERS                           *
      ****************************************************************
      *
      ****************************************************************
      * LINK PROCESSING COPYBOOKS                                    *
      ****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPSPGA.
      *
020478 COPY CCPS2435.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
020478 COPY CCPL2435.
018764*COPY CCCL5120.
025970 COPY CCPS5120.
018764 COPY CCPL5120.
      *
       COPY NCPS1030.
018764*COPY NCCL1030.
018764 COPY NCPL1030.
      *
       COPY NCPS7180.
018764*COPY NCCL7180.
018764 COPY NCPL7180.
      *
016537*COPY XCPL0270.
      *
016537*COPY XCPL0280.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
016537*COPY XCPL1680.
      *
      * MESSAGE PROCESSING

       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY NCPALABR.
      *
       COPY NCPVLABR.
      *
       COPY NCPCLABR.
      *
       COPY NCPBLABU.
      *
       COPY NCPGLABU.
      *
       COPY NCPNLABU.
      *
016537*COPY NCPVLABU.
      *
013578*COPY XCCPTSQP.
      *
      *
015508*COPY CCPBCLIE.
015508*COPY CCPVCLIE.
015508 COPY CCPBCLNN.
015508 COPY CCPVCLNN.
015508 COPY CCPNCLNM.
       COPY CCPNCLI.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
      *
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM1690                     **
      *****************************************************************
