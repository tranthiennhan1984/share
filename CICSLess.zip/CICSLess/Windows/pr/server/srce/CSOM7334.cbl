      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7334.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7334                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE DBGA TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
025999**  6.6       MESSAGE CORRECTION                               **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7334'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       COPY XCWWWKDT.

      /
       01  WS-WORKING-STORAGE.
           05  WS-CONSTANT-FIELDS.
025970*        10  WS-MAX-LIST-LINES           PIC 9(3) VALUE 100.
025970         10  WS-MAX-LIST-LINES              PIC 9(3).
025970             88  WS-MAX-LIST-LINES-DEFAULT  VALUE 100.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID               PIC X(04).
                   88  WS-BUS-FCN-LIST         VALUE '7334'.
               10  WS-SUB                      PIC 9(3).

               10  WS-MIR-FIELDS.
                   15  WS-MIR-DBGA-EFF-DT      PIC X(10).
                   15  WS-MIR-DBGA-SEQ-NUM     PIC 9(03).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0620.
       COPY CCWL2430.
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFWDBGA.
       COPY CCFRDBGA.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7334.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.


           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

025970*    MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7334'        TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'      TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  DBGA-1000-BROWSE
               THRU DBGA-1000-BROWSE-X.

           PERFORM  DBGA-2000-READ-NEXT
               THRU DBGA-2000-READ-NEXT-X.

           IF  WDBGA-IO-EOF
               PERFORM  DBGA-3000-END-BROWSE
                   THRU DBGA-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                       TO WS-SUB.
           PERFORM  2010-BROWSE-DBGA
               THRU 2010-BROWSE-DBGA-X
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WDBGA-IO-EOF.

           IF  WDBGA-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
               MOVE RDBGA-DBGA-EFF-DT      TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE    TO MIR-DBGA-EFF-DT
               MOVE RDBGA-DBGA-SEQ-NUM     TO L0290-INPUT-V00
               MOVE 0                      TO L0290-PRECISION
               MOVE LENGTH OF MIR-DBGA-SEQ-NUM
                                           TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA      TO MIR-DBGA-SEQ-NUM
           END-IF.

           PERFORM  DBGA-3000-END-BROWSE
               THRU DBGA-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-DBGA.
      *-----------------

           ADD 1                    TO WS-SUB.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  DBGA-2000-READ-NEXT
               THRU DBGA-2000-READ-NEXT-X.

       2010-BROWSE-DBGA-X.
           EXIT.

      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  4110-EDIT-POL-ID
               THRU 4110-EDIT-POL-ID-X.

           PERFORM  4120-EDIT-EFF-DT
               THRU 4120-EDIT-EFF-DT-X.

           PERFORM  4130-EDIT-SEQ-NUM
               THRU 4130-EDIT-SEQ-NUM-X.

026057     IF  WGLOB-MSG-ERROR-SW > ZERO
026057         GO TO 2100-VALIDATE-KEYS-X
026057     END-IF.
026057
026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-MIR-DBGA-EFF-DT       TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        MOVE 1                    TO WGLOB-MSG-ERROR-SW
026057     END-IF.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------
       4110-EDIT-POL-ID.
      *-----------------

           MOVE MIR-POL-ID           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
      *MSG: RECORD (@1) NOT FOUND
              MOVE WPOL-POL-ID        TO WGLOB-MSG-PARM (1)
              MOVE 'POL'              TO WGLOB-MSG-PARM (2)
              MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              MOVE 1                    TO WGLOB-MSG-ERROR-SW
              GO TO 4110-EDIT-POL-ID-X
           END-IF.

           MOVE ZERO                       TO I.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE L0620-INPUT-PARM-INFO
               IF  L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM
                                           TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                           TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                           TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                           TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM   TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD       TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME      TO MIR-DV-OWN-CLI-NM
           END-IF.

       4110-EDIT-POL-ID-X.
           EXIT.

      *-----------------
       4120-EDIT-EFF-DT.
      *-----------------

           IF  MIR-DBGA-EFF-DT = SPACE
               MOVE WWKDT-LOW-DT         TO WS-MIR-DBGA-EFF-DT
               GO TO 4120-EDIT-EFF-DT-X
           END-IF.

           MOVE MIR-DBGA-EFF-DT          TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE  TO WS-MIR-DBGA-EFF-DT
           ELSE
      *MSG: INVALID EFFECTIVE DATE
               MOVE 'CS73340001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
           END-IF.

       4120-EDIT-EFF-DT-X.
           EXIT.

      *------------------
       4130-EDIT-SEQ-NUM.
      *------------------

           IF  MIR-DBGA-SEQ-NUM = SPACE
               MOVE ZERO                    TO WS-MIR-DBGA-SEQ-NUM
               GO TO 4130-EDIT-SEQ-NUM-X
           END-IF.

           MOVE MIR-DBGA-SEQ-NUM            TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DBGA-SEQ-NUM  TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-MIR-DBGA-SEQ-NUM
           ELSE
      *MSG: INVALID SEQUENCE NUMBER
               MOVE 'CS73340002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       4130-EDIT-SEQ-NUM-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES            TO WDBGA-KEY.
           MOVE HIGH-VALUES           TO WDBGA-ENDBR-KEY.

           MOVE MIR-POL-ID            TO WDBGA-POL-ID.
           MOVE MIR-POL-ID            TO WDBGA-ENDBR-POL-ID.
           MOVE WS-MIR-DBGA-EFF-DT    TO WDBGA-DBGA-EFF-DT.
           MOVE WWKDT-HIGH-DT         TO WDBGA-ENDBR-DBGA-EFF-DT.
           MOVE ZERO                  TO WDBGA-DBGA-SEQ-NUM.
           MOVE 999                   TO WDBGA-ENDBR-DBGA-SEQ-NUM.

           IF WS-MIR-DBGA-EFF-DT NOT = WWKDT-LOW-DT
              MOVE WS-MIR-DBGA-SEQ-NUM  TO WDBGA-DBGA-SEQ-NUM
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           INITIALIZE  MIR-OUTPUT-AREA.
           INITIALIZE  WS-MIR-FIELDS.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  WS-SUB > WS-MAX-LIST-LINES
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.


           MOVE RDBGA-DBGA-TYP-CD
             TO MIR-DBGA-TYP-CD-T (WS-SUB).

           MOVE RDBGA-DBGA-STAT-CD
             TO MIR-DBGA-STAT-CD-T (WS-SUB).


           MOVE RDBGA-DBGA-EFF-DT      TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-DBGA-EFF-DT-T (WS-SUB).


           MOVE RDBGA-DBGA-SEQ-NUM     TO L0290-INPUT-V00.
           MOVE 0                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-SEQ-NUM-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-DBGA-SEQ-NUM-T (WS-SUB).


           SET L0290-SIGN-DISPLAY     TO TRUE.
           MOVE RDBGA-DBGA-TRXN-AMT    TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-TRXN-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-DBGA-TRXN-AMT-T (WS-SUB).


           SET L0290-SIGN-DISPLAY     TO TRUE.
           MOVE RDBGA-DBGA-DPOS-LTD-AMT TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-DPOS-LTD-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-DBGA-DPOS-LTD-AMT-T (WS-SUB).


           SET L0290-SIGN-DISPLAY     TO TRUE.
           MOVE RDBGA-DBGA-WTHDR-LTD-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-WTHDR-LTD-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-DBGA-WTHDR-LTD-AMT-T (WS-SUB).


           SET L0290-SIGN-DISPLAY     TO TRUE.
           MOVE RDBGA-DBGA-PRORATE-AMT  TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-PRORATE-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-DBGA-PRORATE-AMT-T (WS-SUB).


           SET L0290-SIGN-DISPLAY     TO TRUE.
           MOVE RDBGA-DBGA-RESET-AMT    TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-RESET-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-DBGA-RESET-AMT-T (WS-SUB).


           SET L0290-SIGN-DISPLAY     TO TRUE.
           MOVE RDBGA-DBGA-MAV-AMT      TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-MAV-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-DBGA-MAV-AMT-T (WS-SUB).


           SET L0290-SIGN-DISPLAY     TO TRUE.
           MOVE RDBGA-DBGA-NET-PREM-AMT TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DBGA-NET-PREM-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-DBGA-NET-PREM-AMT-T (WS-SUB).


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *-------------------------
       9990-INIT-WORKING-STORAGE.
      *-------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           INITIALIZE WS-WORK-FIELDS.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.
025970
025970     MOVE SPACES            TO WWKDT-WORK-FIELDS.           
025970      
025970     MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS1670.
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
       COPY CCPL2430.
       COPY CCPS2430.
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBDBGA.
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM7334
      *****************************************************************
