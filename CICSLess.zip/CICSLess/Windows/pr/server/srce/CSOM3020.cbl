      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3020.

      *COPY XCWLPTR.
       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3020                                         **
      **  REMARKS:  PROCESS DRIVER FOR PDIV TRANSACTION              **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010648**  5.6       INITIAL CREATION                                 **
013994**  5.6A      BONUS AND DIVIDEND VESTING                       **
014723**  5.6A      FIX LOGIC ABEND                                  **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016548**  6.2       CHANGE COMP TO BINARY                            **
016757**  6.2       DELETING TWRK RECORD BEFORE RETRIEVE             **
017343**  6.2       FIX ABEND                                        **
016983**  6.3       CODE CLEANUP                                     **
017322**  6.3       DELETE TWRK ON RETRIEVE STEP                     **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      *
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3020'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
013578 COPY XCWL8090.
      *
014590*COPY XCWL0030.
      *

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 WS-SUB-DEFAULT              VALUE ZERO.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
025970         88 I-DEFAULT                   VALUE ZERO.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
016548     05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
016548                                      BINARY.
025970         88 WS-MAX-BROWSE-LINES-DEFAULT          VALUE +12.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-VALID                    VALUES ARE
                   '0790', '0791', '0792', '0793', '0794'.
               88  WS-BUS-FCN-RETRIEVE                 VALUE '0790'.
               88  WS-BUS-FCN-CREATE                   VALUE '0791'.
               88  WS-BUS-FCN-UPDATE                   VALUE '0792'.
               88  WS-BUS-FCN-DELETE                   VALUE '0793'.
               88  WS-BUS-FCN-LIST                     VALUE '0794'.
014221     05  WS-TWRK-KEY                  PIC X(04)  VALUE '0790'.
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '0790'.
023436*    05  WS-DIV-OPT-CD                PIC X(01)  VALUE SPACES.
023436*        88  WS-DIV-OPT-CD-VALID                 VALUES ARE
023436*            '0', '1', '2', '3', '4', '5', '6', '9',
023436*            'A', 'B', 'C', 'D'.
023436*013994  88  WS-DIV-OPT-REALOC-VALID             VALUE '0' '1'
023436*013994                                                '2' '5'
023436*013994                                                '6' '9'
023436*013994                                                'A' 'B'
023436*013994                                                'C' 'D'.
023436*013994  88  WS-DIV-OPT-REALOC-NOT-VALID         VALUE '3' '4'.
023436*
023436     05  WS-DO-EDO-CD.
023436         10  WS-DIV-OPT-CD            PIC X(01). 
023436             88  WS-DIV-OPT-REALOC-VALID         VALUE '0' '1'
023436                                                       '2' '5'
023436                                                       '6' '9'.
023436             88  WS-DIV-OPT-REALOC-NOT-VALID     VALUE '3' '4'.
023436         10  WS-DIV-XCES-CD           PIC X(01).
023436
023436     05  WS-DIV-CD-XCES-CD            PIC X(02).
023436         88 WS-DIV-CD-XCES-CD-VALID   VALUE '00' '10' '21' '22'  
023436                                            '23' '24' '30' '40'  
023436                                            '51' '52' '53' '54'  
023436                                            '61' '63' '64' '90'.  
023436*
013994     05  WS-REOPT                     PIC X(01).
013994         88  WS-VALID-REOPT           VALUE 'N' 'D' 'P'.
013994         88  WS-SELECT-REOPT          VALUE 'D' 'P'.
013994         88  WS-DEFAULT-REOPT         VALUE 'N'.
017343*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0790'.
017343*    05  WS-WORK-AREA.
017343*        10 WS-PLAN-DIV-DFLT-IND      PIC X(01).
017343
017343 COPY XCWLCOMM REPLACING '$VAR1' BY '0790'.
017343         15  LCOMM-PLAN-DIV-DFLT-IND      PIC X(01).
017343

023436 COPY XCWL8960.

      ***************************************************************
      * COMM AREA
      ***************************************************************
014588*COPY XCWCCOMM.
      *
       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      *
      ***************************************************************
      * EDIT TABLE WORK AREA
      ***************************************************************
       COPY CCFREDIT.
       COPY CCFWEDIT.
      *
013994 COPY CCFRPLRT.
013994 COPY CCFWPLRT.
      *
      ***************************************************************
      * DIVIDEND OPTION WORK AREA
      ***************************************************************
       COPY CCFRPDIV.
014723 COPY CCFHPDIV.
       COPY CCFWPDIV.
      *
      ***************************************************************
      * PLAN HEADER WORK AREA
      ***************************************************************
       COPY CCFRPH.
       COPY CCFWPH.
      *
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3020.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.
      *
      **********************
       2000-PROCESS-REQUEST.
      **********************

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3020'   TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      ***********************
       3000-PROCESS-RETRIEVE.
      ***********************

018763*    PERFORM 9700-RETRIEVE-TWRK
018763*       THRU 9700-RETRIEVE-TWRK-X.
018763*
018763*    IF L8090-RETRN-OK
018763*        PERFORM 9900-DELETE-TWRK
018763*           THRU 9900-DELETE-TWRK-X
018763*    END-IF.

           MOVE MIR-PLAN-ID             TO WPDIV-PLAN-ID.
           MOVE MIR-LOC-GR-ID           TO WPDIV-LOC-GR-ID.
           MOVE MIR-PLAN-DIV-OPT-CD     TO WPDIV-PLAN-DIV-OPT-CD.
023436     MOVE MIR-PLAN-DIV-XCES-CD    TO WPDIV-PLAN-DIV-XCES-CD.

014221     MOVE MIR-PLAN-ID             TO WPH-PLAN-ID.
014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.
014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID    TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'           TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 3000-PROCESS-RETRIEVE-X
014221     END-IF.

           PERFORM  8100-READ-PDIV-INFO
               THRU 8100-READ-PDIV-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

017343*    MOVE MIR-PLAN-DIV-DFLT-IND TO WS-PLAN-DIV-DFLT-IND.
017343*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.
017343*
017343*    PERFORM 9800-WRITE-TWRK
017343*       THRU 9800-WRITE-TWRK-X.
017343
017343     PERFORM  COMM-3000-DELETE-TWRK
017343         THRU COMM-3000-DELETE-TWRK-X.
017343
017343     MOVE MIR-PLAN-DIV-DFLT-IND TO LCOMM-PLAN-DIV-DFLT-IND.
017343     PERFORM  COMM-2000-WRITE-TWRK
017343         THRU COMM-2000-WRITE-TWRK-X.
017343
      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *******************
       3500-PROCESS-LIST.
      *******************

           MOVE SPACES                TO MIR-LOC-GR-ID-G.
           MOVE SPACES                TO MIR-PLAN-DIV-OPT-CD-G.
023436     MOVE SPACES                TO MIR-PLAN-DIV-XCES-CD-G.
           MOVE SPACES                TO MIR-PLAN-DIV-DFLT-IND-G.
      *    MOVE SPACES                TO MIR-RHDR-TABLE.


           MOVE LOW-VALUES            TO WPDIV-KEY.
           MOVE HIGH-VALUES           TO WPDIV-ENDBR-KEY.

           IF  MIR-PLAN-ID = SPACES
      *MSG:    PLAN ID IS REQUIRED
               MOVE 'CS30200001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 3500-PROCESS-LIST-X
               END-IF
           END-IF.


           MOVE MIR-PLAN-ID           TO WPDIV-PLAN-ID.
           MOVE MIR-PLAN-ID           TO WPDIV-ENDBR-PLAN-ID.

           IF  MIR-LOC-GR-ID = SPACES
               CONTINUE
           ELSE
               MOVE MIR-LOC-GR-ID     TO WPDIV-LOC-GR-ID
           END-IF.

           IF  MIR-PLAN-DIV-OPT-CD = SPACES
               CONTINUE
           ELSE
               MOVE MIR-PLAN-DIV-OPT-CD
                                      TO WPDIV-PLAN-DIV-OPT-CD
           END-IF.

023436     IF  MIR-PLAN-DIV-XCES-CD = SPACES
023436         CONTINUE
023436     ELSE
023436         MOVE MIR-PLAN-DIV-XCES-CD
023436                                TO WPDIV-PLAN-DIV-XCES-CD
023436     END-IF.

           PERFORM  PDIV-1000-BROWSE
               THRU PDIV-1000-BROWSE-X

           PERFORM  PDIV-2000-READ-NEXT
               THRU PDIV-2000-READ-NEXT-X.

           IF  NOT WPDIV-IO-OK
           OR  WPDIV-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PDIV-3000-END-BROWSE
                   THRU PDIV-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF  WPDIV-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDIV-3000-END-BROWSE
               THRU PDIV-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      *
      *********************
       4000-PROCESS-CREATE.
      *********************

           IF  MIR-PLAN-ID = SPACES
      *MSG:    PLAN ID IS REQUIRED
               MOVE 'CS30200001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 4000-PROCESS-CREATE-X
               END-IF
           END-IF.

023436     IF  MIR-PLAN-DIV-OPT-CD = SPACES
023436*MSG:    DIVIDEND OPTION IS REQUIRED
023436         MOVE 'CS30200013'      TO WGLOB-MSG-REF-INFO
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436         IF  WGLOB-MSG-SEVRTY-FATAL
023436             GO TO 4000-PROCESS-CREATE-X
023436         END-IF
023436     END-IF.
023436
023436     IF  MIR-PLAN-DIV-XCES-CD = SPACES
023436*MSG:    EXCESS DIVIDEND OPTION IS REQUIRED
023436         MOVE 'CS30200014'      TO WGLOB-MSG-REF-INFO
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436         IF  WGLOB-MSG-SEVRTY-FATAL
023436             GO TO 4000-PROCESS-CREATE-X
023436         END-IF
023436     END-IF.

      *
      ***  DIVIDEND OPTIONS KEY FIELD EDITS.
      *
023436     PERFORM  4100-EDIT-PDIV-KEY-FIELDS
023436         THRU 4100-EDIT-PDIV-KEY-FIELDS-X.
023436
023436     IF  WGLOB-MSG-ERROR-SW = 0
023436         CONTINUE
023436     ELSE
023436         GO TO 4000-PROCESS-CREATE-X
023436     END-IF.

           MOVE MIR-PLAN-ID             TO WPDIV-PLAN-ID.
           MOVE MIR-LOC-GR-ID           TO WPDIV-LOC-GR-ID.
           MOVE MIR-PLAN-DIV-OPT-CD     TO WPDIV-PLAN-DIV-OPT-CD.
023436     MOVE MIR-PLAN-DIV-XCES-CD    TO WPDIV-PLAN-DIV-XCES-CD.

           PERFORM PDIV-1000-READ
              THRU PDIV-1000-READ-X.

           IF  WPDIV-IO-OK
               MOVE WPDIV-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   GO TO 4000-PROCESS-CREATE-X
               END-IF
           END-IF.

      *
      ***  DIVIDEND OPTIONS KEY FIELD EDITS.
      *
023436*    PERFORM  4100-EDIT-PDIV-KEY-FIELDS
023436*        THRU 4100-EDIT-PDIV-KEY-FIELDS-X.
023436*
023436*    IF  WGLOB-MSG-ERROR-SW = 0
023436*        CONTINUE
023436*    ELSE
023436*        GO TO 4000-PROCESS-CREATE-X
023436*    END-IF.


      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM  PDIV-1000-CREATE
               THRU PDIV-1000-CREATE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  PDIV-1000-WRITE
               THRU PDIV-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PDIV-1000-CALL-AUDIT
                  THRU PDIV-1000-CALL-AUDIT-X
           END-IF.

014221     MOVE MIR-PLAN-ID             TO WPH-PLAN-ID.
014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID    TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'           TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4000-PROCESS-CREATE-X
014221     END-IF.

      *    PERFORM  9200-MOVE-RECORD-TO-SCREEN
      *        THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE RPDIV-PLAN-DIV-DFLT-IND
                                      TO MIR-PLAN-DIV-DFLT-IND.
013994     MOVE RPDIV-PLAN-DIV-ALLOC-CD
                                      TO MIR-PLAN-DIV-ALLOC-CD.


       4000-PROCESS-CREATE-X.
           EXIT.
      *
      ****************************
       4100-EDIT-PDIV-KEY-FIELDS.
      ****************************

           MOVE MIR-PLAN-ID            TO WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  WPH-IO-OK
               CONTINUE
           ELSE
      *MSG:    'INVALID PLAN/RS'
               MOVE 'CS30200005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET MIR-RETRN-RQST-FAILED TO TRUE
               END-IF
           END-IF.

           MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.

           PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
               THRU LCGP-1000-EDIT-LCGP-LOCATION-X.

           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *MSG:    'INVALID LOCATION GROUP.  MUST BE IN EDIT, TYPE = LOCGP'
               MOVE 'CS30200006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET MIR-RETRN-RQST-FAILED TO TRUE
               END-IF
           END-IF.


           MOVE MIR-PLAN-DIV-OPT-CD      TO WS-DIV-OPT-CD.
023436     MOVE MIR-PLAN-DIV-XCES-CD     TO WS-DIV-XCES-CD.

023436
023436     PERFORM  8960-1000-BUILD-PARM-INFO
023436         THRU 8960-1000-BUILD-PARM-INFO-X.
023436     MOVE 'PLAN-DIV-OPT-CD'        TO L8960-AV-TBL-CD.
023436     MOVE MIR-PLAN-DIV-OPT-CD      TO L8960-AV-CD.
023436
023436     PERFORM  8960-1000-VALIDATE-CODE
023436         THRU 8960-1000-VALIDATE-CODE-X.
023436
023436*     IF  WS-DIV-OPT-CD-VALID
023436*         CONTINUE
023436*     ELSE
023436*
023436     IF  NOT L8960-RETRN-OK
      *MSG: 'INVALID DIVIDEND OPTION'
               MOVE MIR-PLAN-DIV-OPT-CD TO WGLOB-MSG-PARM (1)
               MOVE 'CS30200007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET MIR-RETRN-RQST-FAILED TO TRUE
               END-IF
           END-IF.

023436     PERFORM  8960-1000-BUILD-PARM-INFO
023436         THRU 8960-1000-BUILD-PARM-INFO-X.
023436     MOVE 'PLAN-DIV-XCES-CD'    TO L8960-AV-TBL-CD.
023436     MOVE MIR-PLAN-DIV-XCES-CD  TO L8960-AV-CD.
023436
023436     PERFORM  8960-1000-VALIDATE-CODE
023436         THRU 8960-1000-VALIDATE-CODE-X.
023436
023436     IF  NOT L8960-RETRN-OK
023436*MSG:    'INVALID EXCESS DIVIDEND OPTION'
023436         MOVE MIR-PLAN-DIV-OPT-CD TO WGLOB-MSG-PARM (1)
023436         MOVE 'CS30200015'        TO WGLOB-MSG-REF-INFO
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436         IF  WGLOB-MSG-SEVRTY-FATAL
023436             SET MIR-RETRN-RQST-FAILED TO TRUE
023436         END-IF
023436     END-IF.
023436*
023436*  DO CROSS EDIT FOR DIV-OPT-CD AND DIV-XCES-CD COMBINATION
023436*
023436     MOVE WS-DO-EDO-CD             TO WS-DIV-CD-XCES-CD.
023436
023436     IF  WS-DIV-CD-XCES-CD-VALID
023436         CONTINUE
023436     ELSE
023436*MSG:'PLAN DIVIDEND OPTION/EXCESS DIVIDEND OPTION 
023436*     INVALID COMBINATION'
023436         MOVE 'CS30200016'      TO WGLOB-MSG-REF-INFO
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436         IF  WGLOB-MSG-SEVRTY-FATAL
023436             SET MIR-RETRN-RQST-FAILED TO TRUE
023436         END-IF
023436     END-IF.

       4100-EDIT-PDIV-KEY-FIELDS-X.
           EXIT.
      *
      *********************
       5000-PROCESS-UPDATE.
      *********************


017343*    PERFORM 9700-RETRIEVE-TWRK
017343*       THRU 9700-RETRIEVE-TWRK-X.
017343*
017343*    IF L8090-RETRN-OK
017343*       MOVE L8090-AREA-INFO-TEXT TO WS-WORK-AREA
018763*        PERFORM 9900-DELETE-TWRK
018763*           THRU 9900-DELETE-TWRK-X
017343*    END-IF
017343*
017343*    PERFORM 9900-DELETE-TWRK
017343*       THRU 9900-DELETE-TWRK-X.
017343
017343     PERFORM  COMM-1000-RETRIEVE-TWRK
017343         THRU COMM-1000-RETRIEVE-TWRK-X.
017343
017343     IF  NOT LCOMM-RETRN-OK
017343*MSG: TWRK ERROR - CALL SYSTEMS
017343         MOVE 'XS00000243'      TO WGLOB-MSG-REF-INFO
017343         PERFORM  0260-1000-GENERATE-MESSAGE
017343             THRU 0260-1000-GENERATE-MESSAGE-X
017343         GO TO 5000-PROCESS-UPDATE-X
017343     END-IF.
017343
017343     PERFORM  COMM-3000-DELETE-TWRK
017343         THRU COMM-3000-DELETE-TWRK-X.
017343
      *****************************************************************
      *   CHECK PDIV:
      *   ENSURE THAT THE PLAN DIVIDEND ROW EXISTS.
      *****************************************************************

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           MOVE MIR-PLAN-ID             TO WPDIV-PLAN-ID.
           MOVE MIR-LOC-GR-ID           TO WPDIV-LOC-GR-ID.
           MOVE MIR-PLAN-DIV-OPT-CD     TO WPDIV-PLAN-DIV-OPT-CD.
023436     MOVE MIR-PLAN-DIV-XCES-CD    TO WPDIV-PLAN-DIV-XCES-CD.

           PERFORM  PDIV-1000-READ-FOR-UPDATE
               THRU PDIV-1000-READ-FOR-UPDATE-X.

           IF  WPDIV-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PDIV-1000-CALL-AUDIT
                      THRU PDIV-1000-CALL-AUDIT-X
               END-IF
           ELSE
               MOVE WPDIV-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   PERFORM  9100-BLANK-DATA-FIELDS
                       THRU 9100-BLANK-DATA-FIELDS-X
014221             PERFORM  PH-3000-UNLOCK
014221                 THRU PH-3000-UNLOCK-X
                   GO TO 5000-PROCESS-UPDATE-X
               END-IF
           END-IF.


013994     PERFORM  5220-EDIT-REOPT
013994         THRU 5220-EDIT-REOPT-X.


           PERFORM  5210-EDIT-PDIV-DATA-FIELDS
               THRU 5210-EDIT-PDIV-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW = 0
               PERFORM  PDIV-2000-REWRITE
                   THRU PDIV-2000-REWRITE-X
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PDIV-1000-CALL-AUDIT
                      THRU PDIV-1000-CALL-AUDIT-X
               END-IF
014221         PERFORM  PH-2000-REWRITE
014221             THRU PH-2000-REWRITE-X
014221         PERFORM  PH-1000-READ-TWRK-TS
014221             THRU PH-1000-READ-TWRK-TS-X
014221     ELSE
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW = 0
      *MSG:    MAINTENANCE COMPLETE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

018763*    MOVE MIR-PLAN-DIV-DFLT-IND TO WS-PLAN-DIV-DFLT-IND.
018763*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT.

018763*    PERFORM 9800-WRITE-TWRK
018763*       THRU 9800-WRITE-TWRK-X.
018763     MOVE MIR-PLAN-DIV-DFLT-IND TO LCOMM-PLAN-DIV-DFLT-IND.
018763     PERFORM  COMM-2000-WRITE-TWRK
018763         THRU COMM-2000-WRITE-TWRK-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      *
      ***************************
       5210-EDIT-PDIV-DATA-FIELDS.
      ***************************

           IF  MIR-PLAN-DIV-DFLT-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-DIV-DFLT-IND
           ELSE
               IF  MIR-PLAN-DIV-DFLT-IND = SPACES
017343*        OR  MIR-PLAN-DIV-DFLT-IND = WS-PLAN-DIV-DFLT-IND
017343         OR  MIR-PLAN-DIV-DFLT-IND = LCOMM-PLAN-DIV-DFLT-IND
013994             MOVE RPDIV-PLAN-DIV-DFLT-IND
                                      TO MIR-PLAN-DIV-DFLT-IND
                   GO TO 5210-EDIT-PDIV-DATA-FIELDS-X
               END-IF
           END-IF.


      **************************************************************
      **   IF THE DEFAULT IND IS SET TO YES CHECK TO SEE IF THERE **
      **   IS ANOTHER DEFAULT UNDER THIS LOCATION GROUP, AND IF   **
      **   SO PRINT AN APPROPRIATE MESSAGE.                       **
      **                                                          **
      **   IF THE DEFAULT IS SET TO NO ACCEPT IT, OTHERWISE       **
      **   DISPLAY AN 'INVALID DATA' MESSAGE.                     **
      **                                                          **
      **************************************************************

014723     MOVE RPDIV-REC-INFO        TO HPDIV-REC-INFO.

           EVALUATE MIR-PLAN-DIV-DFLT-IND
               WHEN 'N'
                    MOVE MIR-PLAN-DIV-DFLT-IND
                                      TO RPDIV-PLAN-DIV-DFLT-IND

               WHEN 'Y'
                    PERFORM  5320-CHECK-FOR-OTHER-DEFAULT
                        THRU 5320-CHECK-FOR-OTHER-DEFAULT-X

                    IF  RPDIV-PLAN-DIV-DFLT-IND = 'Y'
      *MSG:    'ONLY ONE DEFAULT OPTION ALLOWED FOR LOCATION GROUP'
                        MOVE 'CS30200008'
                                      TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
      *                  IF  WGLOB-MSG-SEVRTY-FATAL
                    ELSE
014723                  MOVE HPDIV-REC-INFO
                                      TO RPDIV-REC-INFO
014723                  PERFORM  8050-BUILD-PDIV-KEY
014723                      THRU 8050-BUILD-PDIV-KEY-X
                        MOVE MIR-PLAN-DIV-DFLT-IND
                                      TO RPDIV-PLAN-DIV-DFLT-IND
                    END-IF



               WHEN OTHER
      *MSG:    'DEFAULT INDICATOR MUST BE Y OR N
                    MOVE 'CS30200009' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    IF  WGLOB-MSG-SEVRTY-FATAL
                        GO TO 5210-EDIT-PDIV-DATA-FIELDS-X
                    END-IF

           END-EVALUATE.

       5210-EDIT-PDIV-DATA-FIELDS-X.
           EXIT.


013994*****************
013994 5220-EDIT-REOPT.
013994*****************
013994
013994     IF MIR-PLAN-DIV-ALLOC-CD = EBLCH-BLANK-FIELD-CHAR
013994         MOVE 'N'               TO MIR-PLAN-DIV-ALLOC-CD
013994     ELSE
013994         IF  MIR-PLAN-DIV-ALLOC-CD = SPACES
013994             MOVE RPDIV-PLAN-DIV-ALLOC-CD
                                      TO MIR-PLAN-DIV-ALLOC-CD
013994         END-IF
013994     END-IF.
013994
013994     MOVE MIR-PLAN-DIV-ALLOC-CD
                                      TO WS-REOPT.
013994
013994     IF NOT WS-VALID-REOPT
013994*MSG:   'INVALID DIVIDEND REALLOCATION OPTION'
013994        MOVE 'CS30200010'       TO WGLOB-MSG-REF-INFO
013994        PERFORM  0260-1000-GENERATE-MESSAGE
013994            THRU 0260-1000-GENERATE-MESSAGE-X
013994        GO TO 5220-EDIT-REOPT-X
013994     END-IF.
013994
013994     MOVE RPDIV-PLAN-DIV-OPT-CD TO  WS-DIV-OPT-CD.

013994     IF WS-DIV-OPT-REALOC-NOT-VALID
013994        IF WS-SELECT-REOPT
013994*MSG: RE-ALLOCATE OPTION MIUST BE 'N' FOR DIVIDEND OPTION
013994           MOVE 'CS30200011'    TO WGLOB-MSG-REF-INFO
013994           PERFORM  0260-1000-GENERATE-MESSAGE
013994               THRU 0260-1000-GENERATE-MESSAGE-X
013994           GO TO 5220-EDIT-REOPT-X
013994        END-IF
013994     END-IF.
013994
013994     MOVE MIR-PLAN-ID               TO  WPLRT-PLAN-ID.
013994     SET WPLRT-PLAN-RT-TYP-VSTDV    TO  TRUE.
013994
013994     PERFORM  PLRT-1000-READ
013994         THRU PLRT-1000-READ-X.

013994     IF WPLRT-IO-OK
013994        IF WS-DEFAULT-REOPT
013994        AND WS-DIV-OPT-REALOC-VALID
013994*MSG: WARNING - VESTING APPLIES RE-ALLOCATION OPTION
013994*               SHOULD BE 'D' OR 'P'
013994           MOVE 'CS30200012'    TO  WGLOB-MSG-REF-INFO
013994           PERFORM  0260-1000-GENERATE-MESSAGE
013994               THRU 0260-1000-GENERATE-MESSAGE-X
013994        END-IF
013994     END-IF.

013994     MOVE MIR-PLAN-DIV-ALLOC-CD
                                      TO RPDIV-PLAN-DIV-ALLOC-CD.

013994 5220-EDIT-REOPT-X.
013994     EXIT.
      *
      *-----------------------------
       5320-CHECK-FOR-OTHER-DEFAULT.
      *-----------------------------
      *****************************************************************
      *   CHECK FOR OTHER DEFAULT:                                    *
      *       ONLY ONE DEFAULT VALUE (OF 'Y') IS ALLOWED PER LOCATION *
      *       GROUP.  CHECK TO MAKE SURE THAT NO OTHERS EXIST.        *
      *****************************************************************

           MOVE LOW-VALUES            TO WPDIV-KEY.
           MOVE HIGH-VALUES           TO WPDIV-ENDBR-KEY.

           MOVE MIR-PLAN-ID           TO WPDIV-PLAN-ID.
           MOVE MIR-PLAN-ID           TO WPDIV-ENDBR-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPDIV-LOC-GR-ID.
           MOVE MIR-LOC-GR-ID         TO WPDIV-ENDBR-LOC-GR-ID.

           PERFORM  PDIV-1000-BROWSE
               THRU PDIV-1000-BROWSE-X.

           PERFORM
               UNTIL NOT WPDIV-IO-OK
               OR    RPDIV-PLAN-DIV-DFLT-IND  = 'Y'
               PERFORM  PDIV-2000-READ-NEXT
                   THRU PDIV-2000-READ-NEXT-X
           END-PERFORM.

           PERFORM  PDIV-3000-END-BROWSE
               THRU PDIV-3000-END-BROWSE-X.

       5320-CHECK-FOR-OTHER-DEFAULT-X.
           EXIT.
      /
      *********************
       6000-PROCESS-DELETE.
      *********************

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  8050-BUILD-PDIV-KEY
               THRU 8050-BUILD-PDIV-KEY-X.

           PERFORM  PDIV-1000-READ-FOR-UPDATE
               THRU PDIV-1000-READ-FOR-UPDATE-X

           IF  WPDIV-IO-OK
               PERFORM 6210-PROCESS-PROCESS-DELETE
                  THRU 6210-PROCESS-PROCESS-DELETE-X
           ELSE
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WPDIV-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      *
      ****************************
       6210-PROCESS-PROCESS-DELETE.
      ****************************

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PDIV-1000-CALL-AUDIT
                  THRU PDIV-1000-CALL-AUDIT-X
           END-IF.

           PERFORM PDIV-1000-DELETE
              THRU PDIV-1000-DELETE-X.

           IF  WPDIV-IO-OK
      *MSG:    DELETE COMPLETED MESSAGE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PDIV-1000-CALL-AUDIT
                      THRU PDIV-1000-CALL-AUDIT-X
               END-IF
           ELSE
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WPDIV-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

       6210-PROCESS-PROCESS-DELETE-X.
           EXIT.
      *
      *********************
       8050-BUILD-PDIV-KEY.
      *********************

           MOVE MIR-PLAN-ID           TO WPDIV-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPDIV-LOC-GR-ID.
           MOVE MIR-PLAN-DIV-OPT-CD   TO WPDIV-PLAN-DIV-OPT-CD.
023436     MOVE MIR-PLAN-DIV-XCES-CD  TO WPDIV-PLAN-DIV-XCES-CD.

       8050-BUILD-PDIV-KEY-X.
           EXIT.
      *
      **********************
       8100-READ-PDIV-INFO.
      **********************

           IF  RPDIV-PLAN-ID          = WPDIV-PLAN-ID
           AND RPDIV-LOC-GR-ID        = WPDIV-LOC-GR-ID
           AND RPDIV-PLAN-DIV-OPT-CD  = WPDIV-PLAN-DIV-OPT-CD
023436     AND RPDIV-PLAN-DIV-XCES-CD = WPDIV-PLAN-DIV-XCES-CD
               GO TO 8100-READ-PDIV-INFO-X
           END-IF.

           PERFORM  PDIV-1000-READ
               THRU PDIV-1000-READ-X.

           IF  WPDIV-IO-NOT-FOUND
      *MSG:    "RECORD NOT FOUND"
               MOVE WPDIV-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8100-READ-PDIV-INFO-X.
           EXIT.
      *
      ************************
       9100-BLANK-DATA-FIELDS.
      ************************
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************

           IF  WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-LOC-GR-ID-G
               MOVE SPACES            TO MIR-PLAN-DIV-OPT-CD-G
023436         MOVE SPACES            TO MIR-PLAN-DIV-XCES-CD-G
               MOVE SPACES            TO MIR-PLAN-DIV-DFLT-IND-G
           ELSE
               MOVE SPACES            TO MIR-PLAN-DIV-DFLT-IND
013994         MOVE SPACES            TO MIR-PLAN-DIV-ALLOC-CD
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************

           IF  WS-BUS-FCN-LIST
               PERFORM  9210-MOVE-PDIV-TO-SCRN-1
                   THRU 9210-MOVE-PDIV-TO-SCRN-1-X
                   VARYING I FROM 1 BY 1
                   UNTIL   I > WS-MAX-BROWSE-LINES
                   OR      WPDIV-IO-EOF

               IF  NOT WPDIV-IO-EOF
                   MOVE RPDIV-PLAN-ID TO MIR-PLAN-ID
                   MOVE RPDIV-LOC-GR-ID
                                      TO MIR-LOC-GR-ID
                   MOVE RPDIV-PLAN-DIV-OPT-CD
                                      TO MIR-PLAN-DIV-OPT-CD
023436             MOVE RPDIV-PLAN-DIV-XCES-CD
023436                                TO MIR-PLAN-DIV-XCES-CD
               END-IF
           ELSE
               MOVE RPDIV-PLAN-DIV-DFLT-IND
                                      TO MIR-PLAN-DIV-DFLT-IND
013994         MOVE RPDIV-PLAN-DIV-ALLOC-CD
                                      TO MIR-PLAN-DIV-ALLOC-CD
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      **************************
       9210-MOVE-PDIV-TO-SCRN-1.
      **************************

           MOVE RPDIV-LOC-GR-ID       TO MIR-LOC-GR-ID-T (I).
           MOVE RPDIV-PLAN-DIV-OPT-CD TO MIR-PLAN-DIV-OPT-CD-T (I).
023436     MOVE RPDIV-PLAN-DIV-XCES-CD 
023436                                TO MIR-PLAN-DIV-XCES-CD-T (I).
           MOVE RPDIV-PLAN-DIV-DFLT-IND
                                      TO MIR-PLAN-DIV-DFLT-IND-T (I).

           PERFORM  PDIV-2000-READ-NEXT
               THRU PDIV-2000-READ-NEXT-X.

       9210-MOVE-PDIV-TO-SCRN-1-X.
           EXIT.
      *
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-SUB-DEFAULT TO TRUE.
025970     SET I-DEFAULT TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
017343***************************
017343*9500-BUILD-TWRK-KEY.
017343***************************
017343*
017343*    MOVE WS-TWRK-KEY           TO L8090-BUS-FCN-ID.
017343*    MOVE ZEROS                 TO L8090-TEMP-WRK-SEQ-NUM.
017343*    SET  L8090-USAGE-COMM      TO TRUE.
017343*
017343*9500-BUILD-TWRK-KEY-X.
017343*    EXIT.
017343*
017343***************************
017343*9700-RETRIEVE-TWRK.
017343***************************
017343*
017343*    PERFORM 9500-BUILD-TWRK-KEY
017343*       THRU 9500-BUILD-TWRK-KEY-X.
017343*
017343*    PERFORM 8090-2000-RETRIEVE-TWRK
017343*       THRU 8090-2000-RETRIEVE-TWRK-X.
017343*
017343*
017343*9700-RETRIEVE-TWRK-X.
017343*    EXIT.
017343*
017343***************************
017343*9800-WRITE-TWRK.
017343***************************
017343*
017343*    PERFORM 9500-BUILD-TWRK-KEY
017343*       THRU 9500-BUILD-TWRK-KEY-X.
017343*
017343*    MOVE LENGTH OF WS-WORK-AREA
017343*                TO L8090-AREA-LEN.
017343*
017343*    PERFORM 8090-1000-WRITE-TWRK
017343*       THRU 8090-1000-WRITE-TWRK-X.
017343*
017343*
017343*9800-WRITE-TWRK-X.
017343*    EXIT.
017343*
017343***************************
017343*9900-DELETE-TWRK.
017343***************************
017343*
017343*    PERFORM 9500-BUILD-TWRK-KEY
017343*       THRU 9500-BUILD-TWRK-KEY-X.
017343*
017343*
017343*    PERFORM 8090-3000-DELETE-TWRK
017343*       THRU 8090-3000-DELETE-TWRK-X.
017343*
017343*
017343*9900-DELETE-TWRK-X.
017343*    EXIT.
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.

021930*COPY XCPSCOMM.
017343 COPY XCPPCOMM.
      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY CCCLPDIV.
018764 COPY CCPLPDIV.
018764*COPY XCCL0260.
018764 COPY XCPL0260.

017343 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
023436 COPY XCPS8960.
023436 COPY XCPL8960.
      /
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY CCPNPH.
014221 COPY CCPUPH.
      *
       COPY CCPAPDIV.
       COPY CCPNPDIV.
       COPY CCPBPDIV.
       COPY CCPCPDIV.
       COPY CCPUPDIV.
       COPY CCPXPDIV.
      *
013994 COPY CCPNPLRT.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY CCPNEDIT.
       COPY CCPELCGP.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM CSOM3020                       *
      ******************************************************************
