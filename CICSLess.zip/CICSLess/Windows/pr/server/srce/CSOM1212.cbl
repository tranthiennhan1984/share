      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1212.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1212                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE RT TABLE                                 **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
012624**  6.0       DESCRIPTION                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017163**  6.2       SIGN NOTATION                                    **
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024110**  6.5       RATE RESAON CODE EDIT                            **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1212'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      *
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '1212'.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1210'.
014221     05  WS-SAVE-RT-KEY                PIC X(100).
016548*    05  WS-MAX-SUB                    PIC S9(04) COMP VALUE +121.
025970*    05  WS-MAX-SUB                    PIC S9(04)
025970*                                      BINARY VALUE +121.
016548*    05  WS-SUB                        PIC S9(04) COMP.
016548     05  WS-SUB                        PIC S9(04) BINARY.
016548*    05  WS-MAX-DUR                    PIC S9(04) COMP.
016548     05  WS-MAX-DUR                    PIC S9(04) BINARY.
           05  WS-MISSING-RATE-IND           PIC X(01).
               88  WS-MISSING-RATE           VALUE 'Y'.
               88  WS-MISSING-RATE-NO        VALUE 'N'.
           05  WS-RTBL-REASN-CD              PIC X(01).
018763     05  WS-MSG-FLG-IND                PIC X(01).
018763         88  WS-MSG-FLG                VALUE 'Y'.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1210'.
025970     05  WS-MAX-SUB                    PIC S9(04) BINARY.
025970         88  WS-MAX-SUB-DEFAULT        VALUE +121.
      *
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
024110 COPY XCWEBLCH.
      *
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      *
       COPY CCFWRT.
       COPY CCFRRT.
      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL0005.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
014221 COPY XCWL8090.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1212.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1212'            TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'          TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      *
      *-----------
       2000-UPDATE.
      *-----------
      *
      *  ALL RECORDS MUST EXIST ON A MAINTAIN
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF MIR-RETRN-EDIT-ERROR
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  RT-1000-BROWSE
               THRU RT-1000-BROWSE-X.
           PERFORM  RT-2000-READ-NEXT
               THRU RT-2000-READ-NEXT-X.

           IF  WRT-IO-EOF
               SET WS-MISSING-RATE         TO TRUE
           ELSE
               SET WS-MISSING-RATE-NO      TO TRUE
           END-IF.

014221     MOVE WRT-KEY                    TO WS-SAVE-RT-KEY.
014221     PERFORM RT-2000-UPDATE-TWRK-TS
014221        THRU RT-2000-UPDATE-TWRK-TS-X.

014221     IF  WRT-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WRT-KEY            TO WGLOB-MSG-PARM (1)
014221         MOVE 'RT'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2000-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'RT'               TO WGLOB-MSG-PARM (01)
014221         MOVE WRT-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2000-UPDATE-X
014221     END-IF.

           PERFORM
             VARYING WS-SUB FROM WRT-RTBL-AGE-DUR BY 1
               UNTIL WS-SUB > WRT-ENDBR-RTBL-AGE-DUR
                  OR WRT-IO-EOF
               IF RRT-RTBL-AGE-DUR NOT = WS-SUB
                   SET WS-MISSING-RATE     TO TRUE
               END-IF
               PERFORM RT-2000-READ-NEXT
                  THRU RT-2000-READ-NEXT-X
           END-PERFORM.

           PERFORM RT-3000-END-BROWSE
              THRU RT-3000-END-BROWSE-X.

           IF WS-MISSING-RATE
           OR RRT-RTBL-AGE-DUR NOT = WRT-ENDBR-RTBL-AGE-DUR
      * THERE WAS A MISSING RATE, OR WE HIT EOF BEFORE THE LAST ONE
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE 'XS00000006'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
014221         MOVE WS-SAVE-RT-KEY         TO WRT-KEY
014221         PERFORM  RT-3000-UNLOCK
014221             THRU RT-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X
               VARYING WS-SUB FROM 1 BY 1
                 UNTIL WS-SUB > WS-MAX-DUR.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               CONTINUE
           ELSE
               SET MIR-RETRN-EDIT-ERROR    TO TRUE
014221         MOVE WS-SAVE-RT-KEY         TO WRT-KEY
018763         IF NOT WS-MSG-FLG
014221            PERFORM  RT-3000-UNLOCK
014221                THRU RT-3000-UNLOCK-X
018763         END-IF
014221         GO TO 2000-UPDATE-X
           END-IF.

014221     MOVE WS-SAVE-RT-KEY             TO WRT-KEY
014221     PERFORM  RT-1000-READ-TWRK-TS
014221         THRU RT-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.
      *
      *----------------
       7000-BUILD-KEYS.
      *----------------

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.
           MOVE LOW-VALUES             TO WRT-KEY.
           MOVE MIR-RTBL-DB-OPT-CD     TO WRT-RTBL-DB-OPT-CD.
           MOVE MIR-RTBL-JNT-LIFE-CD   TO WRT-RTBL-JNT-LIFE-CD.
           MOVE MIR-LOC-GR-ID          TO WRT-LOC-GR-ID.
           MOVE MIR-RTBL-PAR-CD        TO WRT-RTBL-PAR-CD.
           MOVE MIR-RTBL-PNSN-QUALF-CD TO WRT-RTBL-PNSN-QUALF-CD.
           MOVE MIR-RTBL-RT-TYP-CD     TO WRT-RTBL-RT-TYP-CD.
           MOVE MIR-RTBL-ID            TO WRT-RTBL-ID.
           MOVE MIR-RTBL-SEX-CD        TO WRT-RTBL-SEX-CD.
           MOVE MIR-RTBL-SMKR-CD       TO WRT-RTBL-SMKR-CD.
           MOVE MIR-RTBL-STBL-1-CD     TO WRT-RTBL-STBL-1-CD.
           MOVE MIR-RTBL-STBL-2-CD     TO WRT-RTBL-STBL-2-CD.
           MOVE MIR-RTBL-STBL-3-CD     TO WRT-RTBL-STBL-3-CD.
           MOVE MIR-RTBL-STBL-4-CD     TO WRT-RTBL-STBL-4-CD.

012525     MOVE MIR-RTBL-MAT-XPRY-DUR  TO L0280-INPUT-DATA.
012525     MOVE LENGTH OF MIR-RTBL-MAT-XPRY-DUR TO L0280-INPUT-SIZE.
012525     MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
012525     MOVE ZERO                   TO L0280-PRECISION.
012525     PERFORM 0280-1000-NUMERIC-EDIT
012525        THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
012525     MOVE LENGTH MIR-RTBL-MAT-XPRY-DUR TO L0290-MAX-OUT-LEN.
012525     MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
012525     MOVE L0290-OUTPUT-DATA      TO WRT-RTBL-MAT-XPRY-DUR.

           MOVE MIR-DPOS-TRM-DY-DUR    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.
           MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
           MOVE LENGTH MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN.
           MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO WRT-DPOS-TRM-DY-DUR.
           MOVE MIR-DPOS-TRM-MO-DUR    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
           MOVE LENGTH MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN.
           MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO WRT-DPOS-TRM-MO-DUR.
      *
           IF MIR-RTBL-AGE = SPACE
               MOVE SPACE              TO WRT-RTBL-AGE
           ELSE
               MOVE MIR-RTBL-AGE       TO L0280-INPUT-DATA
               MOVE LENGTH OF MIR-RTBL-AGE TO L0280-INPUT-SIZE
               MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
               MOVE ZERO               TO L0280-PRECISION
               PERFORM 0280-1000-NUMERIC-EDIT
                  THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT   TO WRT-RTBL-AGE-N
               ELSE
                   MOVE 'CS12120002'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
               END-IF
           END-IF.
      *
           MOVE MIR-RTBL-IDT-NUM       TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT                                    
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.                                 
020462     PERFORM 1640-7000-MIR-TO-INT                                         
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE TO WRT-RTBL-IDT-NUM-N
           ELSE
               MOVE 'CS12120001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           MOVE MIR-RTBL-AGE-DUR-T (1) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-AGE-DUR-T (1) TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT       TO WRT-RTBL-AGE-DUR
           ELSE
               MOVE 'CS12120002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           MOVE WRT-KEY                TO WRT-ENDBR-KEY.
           PERFORM
               VARYING WS-MAX-DUR FROM WS-MAX-SUB BY -1
                 UNTIL WS-MAX-DUR < 1
                    OR MIR-RTBL-AGE-DUR-T (WS-MAX-DUR) > SPACE
015543         CONTINUE
           END-PERFORM.
      *
           MOVE MIR-RTBL-AGE-DUR-T (WS-MAX-DUR) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-AGE-DUR-T (1) TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT       TO WRT-ENDBR-RTBL-AGE-DUR
           ELSE
               MOVE 'CS12120002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.
      *
      *--------------------
       8000-EDITS.
      *--------------------
      *
      * VALIDATE AGE/DUR
           MOVE MIR-RTBL-AGE-DUR-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-AGE-DUR-T (1) TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE         TO L0280-LENGTH.
           MOVE ZERO                     TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120003'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-AGE-DUR-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-EDITS-X
           END-IF.
      *
           MOVE L0280-OUTPUT             TO WRT-RTBL-AGE-DUR.
014221*    PERFORM RT-1000-READ-FOR-UPDATE
014221*       THRU RT-1000-READ-FOR-UPDATE-X.

014221     IF WRT-KEY = WS-SAVE-RT-KEY
014221        CONTINUE
014221     ELSE
014221        PERFORM  RT-1000-READ-FOR-UPDATE
014221            THRU RT-1000-READ-FOR-UPDATE-X
      *
              IF WRT-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
                  MOVE MIR-RTBL-AGE-DUR-T (WS-SUB) TO WGLOB-MSG-PARM (1)
                  MOVE 'XS00000006'         TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                  SET MIR-RETRN-RQST-FAILED TO TRUE
                  GO TO 8000-EDITS-X
014221         END-IF
           END-IF.
      *
020874*    MOVE L0280-OUTPUT             TO L0290-INPUT-NUMBER.
020874     MOVE L0280-OUTPUT             TO L0290-INPUT-V00.
           MOVE LENGTH MIR-RTBL-AGE-DUR-T (1) TO L0290-MAX-OUT-LEN.
           MOVE ZERO                     TO L0290-PRECISION.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-RTBL-AGE-DUR-T (WS-SUB).
      *
      * EDIT REASON CODE

024110     IF  MIR-RTBL-REASN-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
024110         MOVE SPACE                TO MIR-RTBL-REASN-CD-T
024110                                      (WS-SUB)
024110     END-IF.
           PERFORM  0005-1000-BUILD-PARM-INFO
               THRU 0005-1000-BUILD-PARM-INFO-X.
           MOVE MIR-RTBL-REASN-CD-T (WS-SUB) TO L0005-INPUT-STRING.
           PERFORM  0005-2000-CONVERT-NO-ACCENTS
               THRU 0005-2000-CONVERT-NO-ACCENTS-X.
      *
           IF L0005-RETRN-OK
              MOVE L0005-OUTPUT-STRING   TO WS-RTBL-REASN-CD
           ELSE
              MOVE RRT-RTBL-REASN-CD     TO WS-RTBL-REASN-CD
           END-IF.

           IF WS-RTBL-REASN-CD NUMERIC
           OR WS-RTBL-REASN-CD ALPHABETIC
               MOVE WS-RTBL-REASN-CD     TO MIR-RTBL-REASN-CD-T (WS-SUB)
               MOVE WS-RTBL-REASN-CD     TO RRT-RTBL-REASN-CD
           ELSE
               MOVE 'CS12120004'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-REASN-CD-T (WS-SUB) TO WGLOB-MSG-PARM (1)
018763         SET WS-MSG-FLG            TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
      * EDIT EACH RATE
           MOVE MIR-RTBL-1-RT-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-1-RT-T (1) TO L0280-INPUT-SIZE.
           MOVE +5                       TO L0280-PRECISION.
017163     SET L0280-SIGN-PERMITTED      TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-1-RT-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V05     TO RRT-RTBL-1-RT
               MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
               MOVE LENGTH MIR-RTBL-1-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE +5                   TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-1-RT-T (WS-SUB)
           END-IF.
      *
           MOVE MIR-RTBL-2-RT-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-2-RT-T (1) TO L0280-INPUT-SIZE.
           MOVE +5                       TO L0280-PRECISION.
017163     SET L0280-SIGN-PERMITTED      TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-2-RT-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V05     TO RRT-RTBL-2-RT
               MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER 
               MOVE LENGTH MIR-RTBL-2-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE +5                   TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-2-RT-T (WS-SUB)
           END-IF.
      *
           MOVE MIR-RTBL-3-RT-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-3-RT-T (1) TO L0280-INPUT-SIZE.
           MOVE +5                       TO L0280-PRECISION.
017163     SET L0280-SIGN-PERMITTED      TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-3-RT-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V05     TO RRT-RTBL-3-RT
               MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
               MOVE LENGTH MIR-RTBL-3-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE +5                   TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-3-RT-T (WS-SUB)
           END-IF.
      *
           MOVE MIR-RTBL-4-RT-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-4-RT-T (1) TO L0280-INPUT-SIZE.
           MOVE +5                       TO L0280-PRECISION.
017163     SET L0280-SIGN-PERMITTED      TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-4-RT-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V05     TO RRT-RTBL-4-RT
               MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER 
               MOVE LENGTH MIR-RTBL-4-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE +5                   TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-4-RT-T (WS-SUB)
           END-IF.
      *
           MOVE MIR-RTBL-5-RT-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-5-RT-T (1) TO L0280-INPUT-SIZE.
           MOVE +5                       TO L0280-PRECISION.
017163     SET L0280-SIGN-PERMITTED      TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-5-RT-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V05     TO RRT-RTBL-5-RT
               MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER 
               MOVE LENGTH MIR-RTBL-5-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE +5                   TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-5-RT-T (WS-SUB)
           END-IF.
      *
           MOVE MIR-RTBL-6-RT-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-6-RT-T (1) TO L0280-INPUT-SIZE.
           MOVE +5                       TO L0280-PRECISION.
017163     SET L0280-SIGN-PERMITTED      TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-6-RT-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V05     TO RRT-RTBL-6-RT
               MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
               MOVE LENGTH MIR-RTBL-6-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE +5                   TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-6-RT-T (WS-SUB)
           END-IF.
      *
           MOVE MIR-RTBL-7-RT-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-7-RT-T (1) TO L0280-INPUT-SIZE.
           MOVE +5                       TO L0280-PRECISION.
017163     SET L0280-SIGN-PERMITTED      TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-7-RT-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V05     TO RRT-RTBL-7-RT
               MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
               MOVE LENGTH MIR-RTBL-7-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE +5                   TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-7-RT-T (WS-SUB)
           END-IF.
      *
           MOVE MIR-RTBL-8-RT-T (WS-SUB) TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-8-RT-T (1) TO L0280-INPUT-SIZE.
           MOVE +5                       TO L0280-PRECISION.
017163     SET L0280-SIGN-PERMITTED      TO TRUE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF NOT L0280-OK
               MOVE 'CS12120005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-RTBL-8-RT-T (WS-SUB) TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V05     TO RRT-RTBL-8-RT
               MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER 
               MOVE LENGTH MIR-RTBL-8-RT-T (1) TO L0290-MAX-OUT-LEN
               MOVE +5                   TO L0290-PRECISION
017163         SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-8-RT-T (WS-SUB)
           END-IF.
      *
           PERFORM RT-2000-REWRITE
               THRU RT-2000-REWRITE-X.
      *
       8000-EDITS-X.
           EXIT.
      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0005-0000-INIT-PARM-INFO
025970         THRU 0005-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT  TO TRUE.
025970     SET WS-MAX-SUB-DEFAULT   TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY RT
014221                         '$VAR2' BY 'RT'.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      *
025970 COPY XCPS8090.
       COPY XCPS0005.
       COPY XCPL0005.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBRT.
       COPY CCPURT.

014221 COPY CCPNRT.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM1212                     **
      *****************************************************************
