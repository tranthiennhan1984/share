      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM6985.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6985                                         **
      **  REMARKS:  POLI (VF) - CASH FLOW HISTORY                    **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       NEW                                              **
013578**  6.0       ELIMINATE SUPPORT FOR THE CHARACTER INTERFACE    **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016686**  6.2       PROCESSING DATE CHANGE FOR CONCURRENCY           **
016983**  6.3       CODE CLEANUP                                     **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020157**  6.3       CHECK COVERAGE NUMBER IS NUMERIC                 **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021239**  6.4       FUND UNIT VALUE                                  **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
022730**  6.5       MOVE UNIT VALUES TO RATE HEADER/RATE LOAD        **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
026200**  6.7       BROWSE PROBLEM ON POLICY INQUIRY FUND VALUES     **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6985'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
       COPY XCWWCVGM.
013578 COPY XCWL8090.

025970 01  WS-CONSTANTS.
025970    05  WS-6985-TBL-SIZE                    PIC S9(04) BINARY.
025970        88  WS-6985-TBL-SIZE-DEFAULT        VALUE +50.

       01  WS-PGM-WORK-AREA.
016548*    05  WS-START-CVGNO                     PIC S9(4)  COMP.
016548     05  WS-START-CVGNO                     PIC S9(4)  BINARY.
016548*    05  WS-END-CVGNO                       PIC S9(4)  COMP.
016548     05  WS-END-CVGNO                       PIC S9(4)  BINARY.
           05  WS-FOUND-PRIMARY-SW                PIC X(01).
               88  WS-FOUND-PRIMARY               VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS           VALUE 'N'.

016548*    05  WS-SUB                             PIC S9(04)    COMP.
016548     05  WS-SUB                             PIC S9(04)    BINARY.

       01  WS-EDIT-PROCESS-CHECKS.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID              VALUE '6985'.
           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.

           05  WS-POLICY.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-CVG-NUM              PIC X(02).
               88  WS-CVG-NUM-BLANK    VALUE SPACES ZEROS.
           05  WS-CVG-NUM-R            REDEFINES
               WS-CVG-NUM              PIC 9(02).
           05  WS-CURR-DATE.
               10  WS-CURR-YEAR             PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-CURR-MONTH            PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-CURR-DAY              PIC 9(02).
016686*    05  WS-APPL-CTL-PRCES-DT         PIC X(10).
016686     05  WS-DV-EFF-DT                 PIC X(10).
           05  WS-CO-ID                     PIC X(02).
016548*    05  WS-6985-TBL-SIZE             PIC S9(04) COMP
025970*    05  WS-6985-TBL-SIZE        PIC S9(04) BINARY VALUE +50.
018633*    05  WS-CFLW-KEY                  PIC X(28).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '6985'.
018633     15  LCOMM-CFLW-KEY               PIC X(28).
026200     15  LCOMM-CFLW-KEY-R             REDEFINES
026200         LCOMM-CFLW-KEY.
026200         20  LCOMM-CO-ID              PIC X(02).
026200         20  LCOMM-POL-ID             PIC X(10).
026200         20  LCOMM-CVG-NUM            PIC X(02).
026200         20  LCOMM-CVG-NUM-N          REDEFINES
026200             LCOMM-CVG-NUM            PIC 9(02).
026200         20  LCOMM-CF-TYP-CD          PIC X(01).
026200         20  LCOMM-CF-EFF-DT          PIC X(10).
026200         20  LCOMM-CF-SEQ-NUM         PIC X(03).
026200         20  LCOMM-CF-SEQ-NUM-N       REDEFINES
026200             LCOMM-CF-SEQ-NUM         PIC 9(03).

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
      *
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
026057 COPY XCWWWKDT.

      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
       COPY CCFWPOLC.
       COPY CCFRPOLC.
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************
020478 COPY CCWL2626.
       COPY XCWL0290.
      *
       COPY CCWL0620.
       COPY CCWL2430.
      *
       COPY CCWL5400.
      *
       COPY CCWL6985.
      *
       COPY XCWLDTLK.
016537*COPY XCWL0225.
       COPY XCWL0280.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM6985.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           INITIALIZE L2430-OUTPUT-PARM-INFO.
           INITIALIZE RPOL-REC-INFO.

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  0100-SET-MIR-VALUES
               THRU 0100-SET-MIR-VALUES-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------
       0100-SET-MIR-VALUES.
      *--------------------

           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX.
           MOVE WS-CO-ID              TO MIR-CO-ID.
           MOVE WS-CVG-NUM            TO MIR-CVG-NUM.
016686*    MOVE WS-APPL-CTL-PRCES-DT  TO MIR-APPL-CTL-PRCES-DT.
016686     MOVE WS-DV-EFF-DT          TO MIR-DV-EFF-DT.

       0100-SET-MIR-VALUES-X.
           EXIT.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST
                                      TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

018633*    PERFORM  9700-RETRIEVE-TWRK
018633*        THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           MOVE WGLOB-PROCESS-DATE    TO WS-CURR-DATE.

           PERFORM  2050-SET-WS-FROM-MIR
               THRU 2050-SET-WS-FROM-MIR-X.

           SET WS-NO-ERRORS-FOUND      TO TRUE.

           PERFORM  2200-MORE-INITIAL-EDITS
               THRU 2200-MORE-INITIAL-EDITS-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.

           PERFORM  3000-DISPLAY-SCREEN
               THRU 3000-DISPLAY-SCREEN-X.

018633*    IF  WS-CFLW-KEY NOT = SPACE
018633     IF  LCOMM-CFLW-KEY NOT = SPACE
018633*        PERFORM  9800-WRITE-TWRK
018633*            THRU 9800-WRITE-TWRK-X
018633         PERFORM  COMM-2000-WRITE-TWRK
018633             THRU COMM-2000-WRITE-TWRK-X
013578     END-IF.
013578
       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *---------------------
       2050-SET-WS-FROM-MIR.
      *---------------------

016686*    MOVE MIR-APPL-CTL-PRCES-DT TO WS-APPL-CTL-PRCES-DT.
016686     MOVE MIR-DV-EFF-DT         TO WS-DV-EFF-DT.
           MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SFX.

           IF  MIR-CVG-NUM = SPACES
           OR  MIR-CVG-NUM = ZEROES
020157     OR  MIR-CVG-NUM NOT NUMERIC
               MOVE '01'              TO WS-CVG-NUM
           ELSE
               MOVE MIR-CVG-NUM       TO WS-CVG-NUM
           END-IF.

016686*    IF  MIR-APPL-CTL-PRCES-DT = SPACES
016686     IF  MIR-DV-EFF-DT         = SPACES
               MOVE WGLOB-PROCESS-DATE  TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
016686*                               TO WS-APPL-CTL-PRCES-DT
016686                                TO WS-DV-EFF-DT
           ELSE
016686*        MOVE MIR-APPL-CTL-PRCES-DT
016686*                               TO WS-APPL-CTL-PRCES-DT
016686         MOVE MIR-DV-EFF-DT     TO WS-DV-EFF-DT
           END-IF.

           IF  MIR-CO-ID = SPACES
               MOVE WGLOB-COMPANY-CODE   TO MIR-CO-ID
               MOVE WGLOB-COMPANY-CODE   TO WS-CO-ID
           ELSE
               MOVE MIR-CO-ID         TO WS-CO-ID
           END-IF.

026200*    CHECK FOR CHANGE IN POL-ID OR CVG-ID AND RESET KEY
026200
026200     IF  LCOMM-CFLW-KEY NOT = SPACES
026200         IF  LCOMM-CO-ID = WS-CO-ID
026200         AND LCOMM-POL-ID = WS-POLICY
026200         AND LCOMM-CVG-NUM = WS-CVG-NUM
026200             CONTINUE
026200         ELSE
026200             MOVE SPACES            TO LCOMM-CFLW-KEY
026200         END-IF
026200     END-IF.

       2050-SET-WS-FROM-MIR-X.
           EXIT.
      *
      *------------------------
       2200-MORE-INITIAL-EDITS.
      *------------------------

           MOVE WS-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    POLICY RECORD NOT FOUND (@1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE WS-CVG-NUM            TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WS-CVG-NUM-R
               IF  WS-CVG-NUM > WCVGM-MAX-WCVGS-NUM
                   SET WS-ERROR-FOUND      TO TRUE
      *MSG:        COVERAGE MUST BE NUMERIC
                   MOVE 'XS00000079'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-CVG-NUM    TO WGLOB-MSG-PARM (1)
                   MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    COVERAGE MUST BE NUMERIC
               MOVE 'XS00000079'      TO WGLOB-MSG-REF-INFO
               MOVE WS-CVG-NUM        TO WGLOB-MSG-PARM (1)
               MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

016686*    MOVE WS-APPL-CTL-PRCES-DT  TO L1640-EXTERNAL-DATE.
016686     MOVE WS-DV-EFF-DT          TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'DATE @1 INVALID'
               MOVE 'CS69850001'      TO WGLOB-MSG-REF-INFO
016686*        MOVE WS-APPL-CTL-PRCES-DT TO WGLOB-MSG-PARM (1)
016686         MOVE WS-DV-EFF-DT         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-DV-EFF-DT          TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WS-ERROR-FOUND      TO TRUE
026057        GO TO 2200-MORE-INITIAL-EDITS-X
026057     END-IF.

      *
      * PERFORM CONFIDENTIAL POLICY AND BRANCH LEVEL SECURITY CHECKS
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
               SET WS-ERROR-FOUND      TO TRUE
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

           IF  RPOL-POL-CVG-REC-CTR-N = ZEROS
      *MSG:    NO COVERAGES TO DISPLAY
               SET WS-ERROR-FOUND     TO TRUE
               MOVE 'XS00000095'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  WS-CVG-NUM-R > RPOL-POL-CVG-REC-CTR-N
                   SET WS-ERROR-FOUND TO TRUE
      *MSG:        'COVERAGE (@1) DOES NOT EXIST'
                   MOVE 'XS00000080'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-CVG-NUM    TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  2210-READ-ALL-CVG
               THRU 2210-READ-ALL-CVG-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > RPOL-POL-CVG-REC-CTR-N
               OR      WS-ERROR-FOUND.

           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

       2200-MORE-INITIAL-EDITS-X.
           EXIT.
      *
      *------------------
       2210-READ-ALL-CVG.
      *------------------

           MOVE WS-POL-ID-BASE        TO WCVG-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WCVG-POL-ID-SFX.
           MOVE WS-SUB                TO WCVG-CVG-NUM-N.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  WCVG-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'POLICY & COVERAGE (@1) OUT OF SYNC ...'
               MOVE 'XS00000084'      TO WGLOB-MSG-REF-INFO
               MOVE WS-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2210-READ-ALL-CVG-X
           END-IF.

           MOVE RCVG-CVG-INFO         TO WCVGS-CVG-INFO (WS-SUB).
           MOVE WS-SUB                TO WCVGS-CVG-SEQ-NUM-N (WS-SUB).

       2210-READ-ALL-CVG-X.
           EXIT.
      *
      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------

           IF  WS-CVG-NUM-BLANK
               MOVE +1                TO WS-START-CVGNO
           ELSE
               MOVE WS-CVG-NUM-R      TO WS-START-CVGNO
           END-IF.

           MOVE WS-START-CVGNO        TO WS-END-CVGNO.

           IF  WS-END-CVGNO > RPOL-POL-CVG-REC-CTR-N
               MOVE RPOL-POL-CVG-REC-CTR-N
                                      TO WS-END-CVGNO
           END-IF.

      *
      * READ AND FORMAT OWNERS NAME
      *
           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM  TO L0620-CLI-SFX-NM
           END-IF.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
           MOVE RPOL-POL-CVG-REC-CTR  TO MIR-POL-CVG-REC-CTR.
           MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

       2300-COMMON-LINE-SET-X.
           EXIT.
      *
      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  WS-POLICY         = SPACES
               GO TO 2320-GET-OWNER-X
           END-IF.

           IF  L2430-CLI-ID = SPACES
               PERFORM  2400-CHECK-FOR-OWNER-CLI
                   THRU 2400-CHECK-FOR-OWNER-CLI-X
           ELSE
               IF  L2430-CLI-NM-COMPRESSED = SPACES
      *MSG:        OWNER CLIENT NAME = SPACES
                   MOVE 'CS69850006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2320-GET-OWNER-X.
           EXIT.
      *
      *-------------------------
       2400-CHECK-FOR-OWNER-CLI.
      *-------------------------

      *
      * BUILD START/END BROWSE KEY
      *
           MOVE LOW-VALUES            TO  WPOLC-KEY.
           MOVE RPOL-POL-ID           TO  WPOLC-POL-ID.
           MOVE 'O'                   TO  WPOLC-POL-CLI-REL-TYP-CD.

           MOVE WPOLC-KEY             TO  WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO  WPOLC-ENDBR-CLI-ID.

      *
      *  POSITION AT THE FIRST RECORD FOR THE GIVEN RELATIONSHIP
      *
           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

           IF  WPOLC-IO-OK
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

           IF  WPOLC-IO-EOF
               MOVE 'CS69850007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           SET  WS-NO-PRIMARY-EXISTS TO TRUE.
           PERFORM  2500-DETERMINE-IF-PRIMARY
               THRU 2500-DETERMINE-IF-PRIMARY-X
               UNTIL WPOLC-IO-EOF
               OR    WS-FOUND-PRIMARY.

           IF  WS-NO-PRIMARY-EXISTS
               MOVE 'CS69850007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           PERFORM  2600-FIND-OWNERS-LOOP
               THRU 2600-FIND-OWNERS-LOOP-X
               UNTIL WPOLC-IO-EOF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.


       2400-CHECK-FOR-OWNER-CLI-X.
           EXIT.

      *--------------------------
       2500-DETERMINE-IF-PRIMARY.
      *--------------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD = 'P'
               SET WS-FOUND-PRIMARY TO TRUE
               GO TO 2500-DETERMINE-IF-PRIMARY-X
           END-IF.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2500-DETERMINE-IF-PRIMARY-X.
           EXIT.

      *----------------------
       2600-FIND-OWNERS-LOOP.
      *----------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD NOT = 'P'
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
               GO TO 2600-FIND-OWNERS-LOOP-X
           END-IF.

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

      *
      * WE HAVE FOUND THE REQUIRED RECORD, READ THE CLIENT FILE
      *
           MOVE  RPOLC-CLI-ID         TO  L2430-CLI-ID.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

       2600-FIND-OWNERS-LOOP-X.
           EXIT.
      *
      *--------------------
       3000-DISPLAY-SCREEN.
      *--------------------

           EVALUATE TRUE

               WHEN WCVGS-CVG-CF-TYP-ALLOW (WS-CVG-NUM-R)
                    CONTINUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG-NUM-R)
                    CONTINUE

               WHEN OTHER
      *MSG:        COVERAGE CASHFLOW TYPE NOT VALID FOR THIS SCREEN
                   MOVE 'CS69850008'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3000-DISPLAY-SCREEN-X

           END-EVALUATE.

           PERFORM  4000-BUILD-6985-PARM-INFO
               THRU 4000-BUILD-6985-PARM-INFO-X.

           MOVE WS-CVG-NUM-R          TO L6985-CVG-NUM.
           MOVE 'VF'                  TO L6985-FUNCTION-CODE.
           MOVE WS-POLICY             TO L6985-POLICY.
016686*    MOVE WS-APPL-CTL-PRCES-DT  TO L6985-SCREEN-DATE.
016686     MOVE WS-DV-EFF-DT          TO L6985-SCREEN-DATE.
016686*    MOVE WS-APPL-CTL-PRCES-DT  TO L1640-EXTERNAL-DATE.
016686     MOVE WS-DV-EFF-DT          TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO L6985-EFF-DT.

           PERFORM  6985-1000-INQUIRE
               THRU 6985-1000-INQUIRE-X

           PERFORM  4010-RETRN-8985-PARM-INFO
               THRU 4010-RETRN-8985-PARM-INFO-X.


       3000-DISPLAY-SCREEN-X.
           EXIT.
      /
      *--------------------------
       4000-BUILD-6985-PARM-INFO.
      *--------------------------

           PERFORM  6985-1000-BUILD-PARM-INFO
               THRU 6985-1000-BUILD-PARM-INFO-X.

      *
      * DETERMINE CF PLAN TYPE TO DETERMINE WHAT SCREEN VIEW TO DISPLAY
      *
           EVALUATE WCVGS-CVG-CF-TYP-CD (WS-CVG-NUM-R)

               WHEN 'A'
               WHEN 'I'
                    MOVE 'G'          TO L6985-CF-SCREEN-TYPE

               WHEN 'D'
               WHEN 'M'
                    MOVE 'D'          TO L6985-CF-SCREEN-TYPE

               WHEN 'E'
               WHEN 'P'
                    MOVE 'E'          TO L6985-CF-SCREEN-TYPE

           END-EVALUATE.
      *
      * BUILD INPUT PARAMETERS
      *
           MOVE WS-CVG-NUM            TO L6985-CVG-NUM.
           MOVE WS-START-CVGNO        TO L6985-START-CVGNO.
018633*    MOVE WS-CFLW-KEY           TO L6985-CASH-FLOW-KEY.
018633     MOVE LCOMM-CFLW-KEY        TO L6985-CASH-FLOW-KEY.

       4000-BUILD-6985-PARM-INFO-X.
           EXIT.

      *--------------------------
       4010-RETRN-8985-PARM-INFO.
      *--------------------------
      *
      * BUILD OUTPUT PARAMETERS
      *
020874*    COMPUTE L0290-INPUT-NUMBER = L6985-ACCUM * 100.
020464*    MOVE L6985-ACCUM           TO L0290-INPUT-V02.
020464     COMPUTE L0290-INPUT-V02
020464            = L6985-ACCUM
020464            - (L6985-POL-PEND-IN-AMT
020464            + L6985-POL-PEND-OUT-AMT).
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-BASE-CV-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-BASE-CV-AMT.

020464     COMPUTE L0290-INPUT-V02
020464            = (L6985-POL-PEND-IN-AMT
020464            + L6985-POL-PEND-OUT-AMT).
020464     MOVE +2                    TO L0290-PRECISION.
020464     MOVE LENGTH OF MIR-DV-POL-PEND-ACTV-AMT
020464                                TO L0290-MAX-OUT-LEN.
020464     SET L0290-SIGN-DISPLAY     TO TRUE.
020464     PERFORM 0290-1000-NUMERIC-FORMAT
020464        THRU 0290-1000-NUMERIC-FORMAT-X.
020464     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-PEND-ACTV-AMT.
020464
020464
020464     COMPUTE L0290-INPUT-V02
020464            = (L6985-POL-DEFR-IN-AMT
020464            +  L6985-POL-DEFR-OUT-AMT).
020464     MOVE +2                    TO L0290-PRECISION.
020464     MOVE LENGTH OF MIR-DV-POL-DEFR-ACTV-AMT
020464                                TO L0290-MAX-OUT-LEN.
020464     SET L0290-SIGN-DISPLAY     TO TRUE.
020464     PERFORM 0290-1000-NUMERIC-FORMAT
020464        THRU 0290-1000-NUMERIC-FORMAT-X.
020464     MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-DEFR-ACTV-AMT.
020464
020874*    COMPUTE L0290-INPUT-NUMBER = L6985-LOANS * 100.
020874     MOVE L6985-LOANS           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LOAN-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6985-MKTAJ * 100.
020874     MOVE L6985-MKTAJ           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-MKTVAL-ADJ-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CF-MKTVAL-ADJ-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6985-MTVAJ * 100.
020874     MOVE L6985-MTVAJ           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-MTHV-ADJ-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-MTHV-ADJ-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6985-MXAVL * 100.
020464*    MOVE L6985-MXAVL           TO L0290-INPUT-V02.
020464     COMPUTE L0290-INPUT-V02
020464            = L6985-MXAVL
020464            + L6985-POL-DEFR-IN-AMT
020464            + L6985-POL-DEFR-OUT-AMT.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-CSV-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-POL-CSV-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6985-SCHRG * 100.
020874     MOVE L6985-SCHRG           TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-SURR-CHRG-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-SURR-CHRG-AMT.

013578     MOVE L6985-WO              TO MIR-CVG-WTHDR-ORDR-CD.
013578*    MOVE L6985-WO              TO MIR-DISP-WTHDR-ORDR-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = L6985-TOTEUA
020874*                                 * 100000.
020874     MOVE L6985-TOTEUA          TO L0290-INPUT-V05.
           MOVE 5                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CVG-UNIT-QTY
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-CVG-UNIT-QTY.

020874*    COMPUTE L0290-INPUT-NUMBER = L6985-UVALUA
020874*                                 * 10000.
020874     MOVE L6985-UVALUA          TO L0290-INPUT-V04.
           MOVE 4                     TO L0290-PRECISION.
022730*    MOVE LENGTH OF MIR-DV-UVAL-RT
022730     MOVE LENGTH OF MIR-DV-INT-RT-INIT-DPOS-RT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
022730     MOVE L0290-OUTPUT-DATA     TO MIR-DV-INT-RT-INIT-DPOS-RT.
022730*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-UVAL-RT.

014591*    MOVE L6985-PLNCD           TO MIR-PLAN-ID.
014591     MOVE L6985-PLAN-ID         TO MIR-PLAN-ID.

020874*    COMPUTE L0290-INPUT-NUMBER = L6985-MCVVAL * 100.
020874     MOVE L6985-MCVVAL          TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-MCV-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-MCV-ACUM-AMT.

           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-6985-TBL-SIZE
                  OR   L6985-CFSQ-T (WS-SUB) = SPACE

               MOVE L6985-CFSQ-T (WS-SUB)
                                      TO MIR-CF-SEQ-NUM-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-CAMT-T (WS-SUB) * 100
020874         MOVE L6985-CAMT-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-CLI-TRXN-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-CF-CLI-TRXN-AMT-T (WS-SUB)

               MOVE L6985-CFDT-T (WS-SUB)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CF-EFF-DT-T (WS-SUB)
               ELSE
                   MOVE SPACE         TO MIR-CF-EFF-DT-T (WS-SUB)
               END-IF

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-CNET-T (WS-SUB) * 100
020874         MOVE L6985-CNET-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-FND-TRXN-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-CF-FND-TRXN-AMT-T (WS-SUB)

               MOVE L6985-CRSN-T (WS-SUB)
                                      TO MIR-CF-REASN-CD-T (WS-SUB)
               MOVE L6985-CSTA-T (WS-SUB)
                                      TO MIR-CF-STAT-CD-T (WS-SUB)
               MOVE L6985-CTYP-T (WS-SUB)
                                      TO MIR-CF-TRXN-CD-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER = L6985-FBAL-T (WS-SUB) * 100
020874         MOVE L6985-FBAL-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-FND-BAL-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-CF-FND-BAL-AMT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-INRT-T (WS-SUB)
020874*                                 * 10000
020874         MOVE L6985-INRT-T (WS-SUB) TO L0290-INPUT-V04
               MOVE 4                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-INT-PCT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
016983*        SET L0290-SIGN-DISPLAY TO TRUE
016983         SET L0290-SIGN-SUPPRESS    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-CF-INT-PCT-T (WS-SUB)

               MOVE L6985-NXDT-T (WS-SUB)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-NXT-CF-DT-T (WS-SUB)
               ELSE
                   MOVE SPACE         TO MIR-NXT-CF-DT-T (WS-SUB)
               END-IF

               MOVE L6985-RLDT-T (WS-SUB)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-ROLOVR-CF-DT-T (WS-SUB)
               ELSE
                   MOVE SPACE         TO MIR-ROLOVR-CF-DT-T (WS-SUB)
               END-IF

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-NUNTA-T (WS-SUB)
020874*                                 * 100000
020874         MOVE L6985-NUNTA-T (WS-SUB) TO L0290-INPUT-V05
               MOVE 5                      TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-UNIT-QTY-T (WS-SUB)
                                           TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-CF-UNIT-QTY-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-UVALA-T (WS-SUB)
020874*                                 * 10000
020874         MOVE L6985-UVALA-T (WS-SUB) TO L0290-INPUT-V04
               MOVE 4                      TO L0290-PRECISION
022730*        MOVE LENGTH OF MIR-DV-UVAL-RT-T (WS-SUB)
022730         MOVE LENGTH OF MIR-DV-INT-RT-INIT-DPOS-RT-T (WS-SUB)
                                           TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
022730         MOVE L0290-OUTPUT-DATA
022730           TO MIR-DV-INT-RT-INIT-DPOS-RT-T (WS-SUB)
022730*        MOVE L0290-OUTPUT-DATA TO MIR-DV-UVAL-RT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-MCVN-T (WS-SUB) * 100
020874         MOVE L6985-MCVN-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-MCV-TRXN-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-CF-MCV-TRXN-AMT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-MCVA-T (WS-SUB) * 100
020874         MOVE L6985-MCVA-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-MCV-FND-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-CF-MCV-FND-AMT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-MCVI-T (WS-SUB)
020874*                                 * 100000
020874         MOVE L6985-MCVI-T (WS-SUB)TO L0290-INPUT-V05
               MOVE 5                    TO L0290-PRECISION
               MOVE LENGTH OF MIR-MCV-GUAR-INT-PCT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-MCV-GUAR-INT-PCT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-MVIA-T (WS-SUB) * 100
020874         MOVE L6985-MVIA-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-MCV-ACUM-INT-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-MCV-ACUM-INT-AMT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-MVIN-T (WS-SUB) * 100
020874         MOVE L6985-MVIN-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-MCV-INT-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-CF-MCV-INT-AMT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-LTDI-T (WS-SUB) * 100
020874         MOVE L6985-LTDI-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-ACUM-INT-LTD-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-ACUM-INT-LTD-AMT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6985-LTDM-T (WS-SUB) * 100
020874         MOVE L6985-LTDM-T (WS-SUB) TO L0290-INPUT-V02
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-MCV-INT-LTD-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                  TO MIR-CF-MCV-INT-LTD-AMT-T (WS-SUB)

021239         MOVE L6985-CF-UNIT-TYP-CD-T (WS-SUB)
021239           TO MIR-CF-UNIT-TYP-CD-T (WS-SUB)
021239
           END-PERFORM.

018633*    MOVE L6985-CASH-FLOW-KEY   TO WS-CFLW-KEY.
018633     MOVE L6985-CASH-FLOW-KEY   TO LCOMM-CFLW-KEY.
013578     MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG-NUM-R)
013578                                TO MIR-CVG-CF-TYP-CD.

       4010-RETRN-8985-PARM-INFO-X.
           EXIT.

      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.
           MOVE MIR-CVG-NUM           TO WGLOB-REF-COVERAGE-NUMBER.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.
      *
018633*-------------------
018633*9500-BUILD-TWRK-KEY.
018633*-------------------
018633*
018633*    MOVE MIR-BUS-FCN-ID        TO L8090-BUS-FCN-ID.
018633*    SET L8090-USAGE-COMM       TO TRUE.
018633*    MOVE ZEROS                 TO L8090-TEMP-WRK-SEQ-NUM.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*    IF  L8090-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT
018633*                               TO WS-CFLW-KEY
018633*    ELSE
018633*        MOVE SPACE             TO WS-CFLW-KEY
018633*    END-IF.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9800-WRITE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*    MOVE +300                  TO L8090-AREA-LEN.
018633*    MOVE WS-CFLW-KEY           TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9900-DELETE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
018633*
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6985-0000-INIT-PARM-INFO
025970         THRU 6985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-PROCESS-CHECKS.
025970     SET WS-6985-TBL-SIZE-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
025970 COPY XCPS1670.
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
      *
       COPY CCPSPGA.
      *
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
       COPY CCPL0620.
      *
       COPY XCPS0290.
       COPY XCPL0290.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
       COPY CCPS6985.
018764*COPY CCCL6985.
018764 COPY CCPL6985.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
      *
016537*COPY XCCL0225.
      *
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNCVG.
      *
       COPY CCPNPOL.
      *
       COPY CCPBPOLC.
      *
      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6985                     **
      *****************************************************************


