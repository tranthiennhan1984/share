      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM3360.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM3360                                         **
      **  REMARKS:  PROCESS DRIVER FOR SUB-COMPANY PROFILE           **
      **            MAINTENANCE TRANSACTION:     PSUB                **
      **                                                             **
      **            THERE ARE FOUR SCREENS TO THIS TRANSACTION       **
      **            ONE FILE RECORD PER SUB-COMPANY                  **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010418**  5.6       MULTI-COMPANY                                    **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPORT - REMOVAL OF XCPPMEXT             **
014221**  6.2       LOGICAL LOCKING                                  **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016395**  6.2       CREDIT CARD BILLING                              **
016440**  6.2       NB/AD CONSOLIDATION                              **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017308**  6.2       DISPLAY UWG-CHNG-DY-DUR                          **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018384**  6.4       CHANGE ROLLOVER PERCENTAGE FROM 2 TO 3 BYTES     **
020463**  6.4       INVESTOR PROFILES                                **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023901**  6.5       INCREASE LENGTH OF MIR-TCR-INFC-MO-DUR           **
023443**  6.5       DIRECT LOAN RECOGNITION FOR DIVIDENDS            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM3360'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-COUNTERS.
016548*    05  WS-SUB                      PIC S9(04) COMP.
016548     05  WS-SUB                      PIC S9(04) BINARY.
016548*    05  WS-SUB-2                    PIC S9(04) COMP.
016548     05  WS-SUB-2                    PIC S9(04) BINARY.

       01  WS-WORKING-STORAGE.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'PSUB'.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK                    VALUE '0'.
023443         88  WS-DATA-EDITS-FAILED                VALUE '1'.
           05  WS-VALIDATE-CONTROL          PIC X(01).
               88  WS-INVALID-CONTROL                  VALUE '1'.
           05  WS-VALIDATE-HWMNR            PIC X(01).
               88  WS-VALID-HWMNR                      VALUE '0'.
           05  WS-VALIDATE-HWMXR            PIC X(01).
               88  WS-VALID-HWMXR                      VALUE '0'.
           05  WS-VALIDATE-ISSDF            PIC X(01).
               88  WS-VALID-ISSDF                      VALUE '0'.
           05  WS-VALIDATE-ISSDL            PIC X(01).
               88  WS-VALID-ISSDL                      VALUE '0'.
           05  WS-VALIDATE-DEPDF            PIC X(01).
               88  WS-VALID-DEPDF                      VALUE '0'.
           05  WS-VALIDATE-DEPDL            PIC X(01).
               88  WS-VALID-DEPDL                      VALUE '0'.
016395     05  WS-VALIDATE-CRCDEPDF         PIC X(01).
016395         88  WS-VALID-CRCDEPDF                   VALUE '0'.
016395     05  WS-VALIDATE-CRCDEPDL         PIC X(01).
016395         88  WS-VALID-CRCDEPDL                   VALUE '0'.
           05  WS-VALIDATE-DRAW             PIC X(01).
               88  WS-VALID-DRAW                       VALUE 'Y' 'N'.
           05  WS-VALIDATE-REDRAW           PIC X(01).
               88  WS-VALID-REDRAW                     VALUE 'Y' 'N'.
           05  WS-YES-NO-TEST               PIC X(01).
               88  WS-YES-NO-VALID                     VALUE 'Y' 'N'.
               88  WS-YES                              VALUE 'Y'.
           05  WS-VALIDATE-ADRPU            PIC X(01).
               88  WS-VALID-ADRPU                      VALUE '3' '4'.
           05  WS-VALIDATE-PACRO            PIC X(01).
               88  WS-VALID-PACRO                      VALUE '1' '3'.
           05  WS-RDDTE.
               10  WS-RDDTE-MM              PIC 9(02).
               10  WS-RDDTE-DD              PIC 9(02).
               10  WS-RDDTE-FILLER          PIC X(05).
016440*    05  WS-AASI-COMPANY-IND          PIC X(01).
016440*        88  WS-AGCOP-IND-VALID                VALUE 'A' 'C' 'G'.
           05  WS-AASI-BASE-DT              PIC X(01).
               88  WS-BASE-DT-VALID                    VALUE 'A' 'P'.
           05  WS-CURRENT-RISK-ADB          PIC X(01).
               88  WS-CURRENT-ADB-VALID                VALUE 'Y' 'N'.
           05  WS-PENDING-PREM-TOLR-TYPE    PIC X(01).
               88  WS-PENDING-PREM-TYPE-VALID        VALUE 'A' 'M' 'P'.
           05  WS-INFC-PREM-TOL-TYPE        PIC X(01).
               88  WS-INFC-PREM-TYPE-VALID           VALUE 'A' 'M' 'P'.
           05  WS-LOAN-REPAY-TOL-TYPE       PIC X(01).
               88  WS-LOAN-REPAY-TYPE-VALID          VALUE 'A' 'M' 'P'.
           05  WS-COMTMT-TOLR-TYPE          PIC X(01).
               88  WS-COMTMT-TOLR-TYPE-VALID    VALUE 'E' 'S' 'B' 'N'.
           05  WS-INT-RATE-IND              PIC X(01).
               88  WS-INT-RATE-IND-VALID        VALUE 'H' 'G' 'N'.
           05  WS-COMTMT-START-IND          PIC X(01).
               88  WS-COMTMT-START-IND-VALID    VALUE 'R' 'S' 'N'.
           05  WS-COMTMT-TOLR-IND           PIC X(01).
               88  WS-COMTMT-TOLR-IND-VALID     VALUE 'A' 'P' 'N'.
016395     05  WS-CRC-REDRW-OPT-CD           PIC X(01).
016395         88  WS-CRC-REDRW-OPT-CD-VALID    VALUE '1' '3'.
           05  WS-HOURS-WORKED-MODE1         PIC X(01).
               88  WS-HOURS-WORKED-MODE1-OK  VALUE 'H' 'D' 'M'.
           05  WS-HOURS-WORKED-MODE2         PIC X(01).
               88  WS-HOURS-WORKED-MODE2-OK  VALUE 'D' 'W' 'M' 'Y'.
           05  WS-DUP-FOUND-SW               PIC X(01).
               88  WS-DUP-FOUND              VALUE 'Y'.
           05  WS-ANOTHER-DFLT-SUBCO-FOUND-SW
                                             PIC X(01).
               88  WS-ANOTHER-DFLT-SUBCO-FOUND
                                             VALUE 'Y'.
               88  WS-ANOTHER-DFLT-SUBCO-FOUND-NO
                                             VALUE 'N'.
016395     05  WS-CRC-REDRW-DUR.
016395         10  WS-CRC-REDRW-DUR-MO      PIC X(02).
016395         10  WS-CRC-REDRW-DUR-DY      PIC X(02).
016395     05  WS-CRC-DPOS-DY-RANGE         PIC S9(03).
016395         88  WS-CRC-FRST-DPOS-DY-VALID    VALUE +1 THRU +31.
016395         88  WS-CRC-FINAL-DPOS-DY-VALID   VALUE +1 THRU +31.
           05  WS-SAVE-HWMNR                PIC S9(03) COMP-3.
           05  WS-SAVE-HWMXR                PIC S9(03) COMP-3.
           05  WS-SAVE-ISSDF                PIC S9(03) COMP-3.
           05  WS-SAVE-ISSDL                PIC S9(03) COMP-3.
           05  WS-SAVE-DEPDF                PIC S9(03) COMP-3.
           05  WS-SAVE-DEPDL                PIC S9(03) COMP-3.
016395     05  WS-SAVE-CRCDEPDF             PIC S9(03) COMP-3.
016395     05  WS-SAVE-CRCDEPDL             PIC S9(03) COMP-3.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1680' '1681'
                                                  '1682' '1683'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1680'.
               88  WS-BUS-FCN-CREATE        VALUE '1681'.
               88  WS-BUS-FCN-UPDATE        VALUE '1682'.
               88  WS-BUS-FCN-DELETE        VALUE '1683'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1680'.
           05  WS-N-9                       PIC 9.
           05  WS-N-99                      PIC 99.
           05  WS-N-999                     PIC 999.
           05  WS-N-9999                    PIC 9999.
           05  WS-N-99-99-R REDEFINES WS-N-9999.
               10  WS-N-99-1                PIC 99.
               10  WS-N-99-2                PIC 99.
           05  WS-N-999V9                   PIC 999.9.
           05  WS-PIC-Z9                    PIC Z9.
           05  WS-PIC-ZZ9                   PIC ZZ9.
           05  WS-PIC-ZZZ9                  PIC ZZZ9.
           05  WS-PIC-POL9                  PIC 9(9).
           05  WS-N-9999999                 PIC 9(7).
           05  WS-PIC-PCNT                  PIC ZZ9.999.
           05  WS-N-999-999                 PIC 999.999.
           05  WS-N-9999999-99              PIC 9(7).99.
           05  WS-N-99999                   PIC 9(05).
           05  WS-TEST-RANGE                PIC S9(18) COMP-3.
023901*        88  WS-AGMTH-VALID           VALUE +1 THRU +99.
023901         88  WS-AGMTH-VALID           VALUE +1 THRU +999.
               88  WS-HWMNR-VALID           VALUE +0 THRU +999.
               88  WS-HWMXR-VALID           VALUE +0 THRU +999.
               88  WS-MIR-PEND-PREM-TOL-PCT-VALID  VALUE +0 THRU +100.
               88  WS-MIR-INFC-PREM-TOL-PCT-VALID VALUE +0 THRU +100.
               88  WS-MIR-LOAN-RPAY-TOL-PCT-VALID VALUE +0 THRU +100.
020463         88  WS-PRFL-REBAL-TOL-PCT-VALID VALUE +0 THRU +100.
               88  WS-MCHAG-VALID           VALUE +1 THRU +99.
               88  WS-FDSDY-VALID           VALUE +1 THRU +999.
               88  WS-FDWDY-VALID           VALUE +1 THRU +999.
               88  WS-YRCAL-VALID           VALUE +0 THRU +99.
               88  WS-ISSDF-VALID           VALUE +1 THRU +31.
               88  WS-ISSDL-VALID           VALUE +1 THRU +31.
               88  WS-DEPDF-VALID           VALUE +1 THRU +31.
               88  WS-DEPDL-VALID           VALUE +1 THRU +31.
016395         88  WS-CRCDEPDF-VALID        VALUE +1 THRU +31.
016395         88  WS-CRCDEPDL-VALID        VALUE +1 THRU +31.
               88  WS-MXBDT-VALID           VALUE +0 THRU +999.
               88  WS-MXPDT-VALID           VALUE +0 THRU +999.
               88  WS-MXMOS-VALID           VALUE +0 THRU +999.
016503         88  WS-BILL-LEAD-DY-VALID    VALUE +0 THRU +999.
016503         88  WS-PAC-LEAD-DY-VALID     VALUE +0 THRU +999.
016503         88  WS-ANOAYO-LEAD-DY-VALID  VALUE +0 THRU +999.
016503         88  WS-CLM-LEAD-DY-VALID     VALUE +0 THRU +999.
016503         88  WS-OTHR-LEAD-DY-VALID    VALUE +0 THRU +999.
016503         88  WS-REQIR-LEAD-DY-VALID   VALUE +0 THRU +999.
016395         88  WS-CRC-LEAD-DY-VALID     VALUE +0 THRU +999.
020467
020467         88  WS-DD2-DEPDF-VALID       VALUE +1 THRU +31.
020467         88  WS-DD2-DEPDL-VALID       VALUE +1 THRU +31.
020467
020467     05  WS-VALIDATE-DD2-DEPDF        PIC X(01).
020467         88  WS-VALID-DD2-DEPDF                  VALUE '0'.
020467     05  WS-VALIDATE-DD2-DEPDL        PIC X(01).
020467         88  WS-VALID-DD2-DEPDL                  VALUE '0'.
020467     05  WS-VALIDATE-DD2RO            PIC X(01).
020467         88  WS-VALID-DD2RO                      VALUE '1' '2'.
020467     05  WS-VALIDATE-DD2-DRAW         PIC X(01).
020467         88  WS-VALID-DD2-DRAW                   VALUE 'Y' 'N'.
020467     05  WS-VALIDATE-DD2-REDRAW       PIC X(01).
020467         88  WS-VALID-DD2-REDRAW                 VALUE 'Y' 'N'.
020467     05  WS-DD2-RDDTE.
020467         10  WS-DD2-RDDTE-MM          PIC 9(02).
020467         10  WS-DD2-RDDTE-DD          PIC 9(02).
020467         10  WS-DD2-RDDTE-FILLER      PIC X(05).
020467     05  WS-SAVE-DD2-DEPDF            PIC S9(03) COMP-3.
020467     05  WS-SAVE-DD2-DEPDL            PIC S9(03) COMP-3.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'PSUB'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '1680'.
      /
016537*COPY XCWWWKDT.
      /
       COPY XCWEBLCH.
      /
       COPY NCWEHWMD.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
014221 COPY XCWL8090.
      /
021930*COPY XCWLDTLK.
015904*COPY XCWL1640.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
014221 COPY CCWWLOCK.
      /
       COPY CCFWSCOM.
       COPY CCFRSCOM.
       COPY CCFHSCOM.
      /

       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

      /
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY NCWM3360.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

            SET MIR-RETRN-OK                  TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           MOVE '0'                TO WS-DATA-EDITS.
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *      PROCESS USER REQUEST
      *****************************************************************
      *********************
       2000-PROCESS-REQUEST.
      **********************

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  7000-VALIDATE-CTL-FIELDS
               THRU 7000-VALIDATE-CTL-FIELDS-X.
           IF WS-INVALID-CONTROL
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
      *    PROCESS SCREEN FUNCTIONS
      *

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

           WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'         TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID       TO  WGLOB-MSG-PARM (1)
                   MOVE 'NSOM3360'           TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST     TO  TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY PROCESSING: RETRIEVE RECORD AND DISPLAY
      *****************************************************************
       3000-PROCESS-RETRIEVE.

014221*    PERFORM  SCOM-1000-READ
014221*        THRU SCOM-1000-READ-X.

014221     PERFORM  SCOM-1000-READ-TWRK-TS
014221         THRU SCOM-1000-READ-TWRK-TS-X.

           IF WSCOM-IO-NOT-FOUND
               MOVE 'NS33600050'      TO WGLOB-MSG-REF-INFO
               MOVE WSCOM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *****************************************************************
      *  CREATE PROCESSING: TWO PASSES REQUIRED
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      *      ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING
      *****************************************************************
       4000-PROCESS-CREATE.

           PERFORM  SCOM-1000-READ
               THRU SCOM-1000-READ-X.

           IF WSCOM-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WSCOM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               MOVE 'XS00000004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  SCOM-1000-CREATE
                   THRU SCOM-1000-CREATE-X
               PERFORM  SCOM-1000-WRITE
                   THRU SCOM-1000-WRITE-X
014221         PERFORM  SCOM-1000-READ-TWRK-TS
014221             THRU SCOM-1000-READ-TWRK-TS-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *****************************************************************
      *  MAINTAIN PROCESSING:
      *      FORCE = 1:  USER HAS ENTERED KEY DETAILS
      *      FORCE = 2:  USER HAS MODIFIED DATA FIELDS
      *****************************************************************
       5000-PROCESS-UPDATE.

           MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WSCOM-ENDBR-SBSDRY-CO-ID.

014221*    PERFORM  SCOM-1000-READ-FOR-UPDATE
014221*        THRU SCOM-1000-READ-FOR-UPDATE-X.

014221     PERFORM  SCOM-2000-UPDATE-TWRK-TS
014221         THRU SCOM-2000-UPDATE-TWRK-TS-X.

           IF WSCOM-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WSCOM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'SCOM'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WSCOM-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.

           PERFORM  SCOM-2000-REWRITE
               THRU SCOM-2000-REWRITE-X.

014221     PERFORM  SCOM-1000-READ-TWRK-TS
014221         THRU SCOM-1000-READ-TWRK-TS-X.

015904*    MOVE RSCOM-PREV-UPDT-DT    TO L1640-INTERNAL-DATE.
015904*    PERFORM  1640-2000-INTERNAL-TO-EXT
015904*        THRU 1640-2000-INTERNAL-TO-EXT-X.
015904*    MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-UPDATE-DT.

           IF WS-DATA-EDITS-OK
           AND WGLOB-MSG-ERROR-SW = 0
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
           ELSE
               IF WGLOB-MSG-ERROR-SW > 0
               AND WS-DATA-EDITS-OK
                   MOVE 'XS00000008'  TO WGLOB-MSG-REF-INFO
               ELSE
                   MOVE 'XS00000008'  TO WGLOB-MSG-REF-INFO
               END-IF
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *****************************************************************
      *  DELETE PROCESSING:
      *      FORCE = 1:  USER HAS ENTERED KEY DETAILS
      *      FORCE = 9:  USER HAS VERIFIED DELETE REQUEST
      *****************************************************************
       6000-PROCESS-DELETE.

           MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WSCOM-ENDBR-SBSDRY-CO-ID.

014221*    PERFORM  SCOM-1000-READ-FOR-UPDATE
014221*        THRU SCOM-1000-READ-FOR-UPDATE-X.

014221     PERFORM  SCOM-2000-UPDATE-TWRK-TS
014221         THRU SCOM-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'SCOM'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WSCOM-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WSCOM-IO-OK
               PERFORM  SCOM-1000-DELETE
                   THRU SCOM-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WSCOM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.

      /
      *****************************************************************
      *  VALIDATE CONTROL FIELDS:
      *      CHECK CONTROL FIELDS NOT INCLUDING THE ENTER CODE
      *****************************************************************
       7000-VALIDATE-CTL-FIELDS.

           MOVE '0'                   TO WS-VALIDATE-CONTROL.

           MOVE MIR-SBSDRY-CO-ID      TO WEDIT-ETBL-VALU-ID.
           MOVE 'SUBCO'               TO  WEDIT-ETBL-TYP-ID.
           MOVE WGLOB-EDIT-LANG       TO  WEDIT-ETBL-LANG-CD.
           PERFORM  EDIT-1000-READ
               THRU EDIT-1000-READ-X.

           IF WEDIT-IO-OK
               MOVE MIR-SBSDRY-CO-ID  TO RSCOM-SBSDRY-CO-ID
               MOVE MIR-SBSDRY-CO-ID  TO WSCOM-SBSDRY-CO-ID
           ELSE
      *MSG:    SUB COMPANY MUST BE IN EDIT - TYPE SBCO
               MOVE 'NS33600001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-VALIDATE-CONTROL
           END-IF.

           IF WS-INVALID-CONTROL
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           END-IF.

       7000-VALIDATE-CTL-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       7500-EDIT-DATA-FIELDS.

           MOVE '0'                   TO WS-DATA-EDITS.

           PERFORM  7510-EDIT-SCREEN-1
               THRU 7510-EDIT-SCREEN-1-X.

           PERFORM  7520-EDIT-SCREEN-2
               THRU 7520-EDIT-SCREEN-2-X.

           PERFORM  7530-EDIT-SCREEN-3
               THRU 7530-EDIT-SCREEN-3-X.

           PERFORM  7540-EDIT-SCREEN-4
               THRU 7540-EDIT-SCREEN-4-X.

       7500-EDIT-DATA-FIELDS-X.
           EXIT.
      /
       7510-EDIT-SCREEN-1.

           PERFORM  7600-EDIT-MXBDT
               THRU 7600-EDIT-MXBDT-X.

           PERFORM  7610-EDIT-FDSDY
               THRU 7610-EDIT-FDSDY-X.

           PERFORM  7620-EDIT-MXPDT
               THRU 7620-EDIT-MXPDT-X.

           PERFORM  7630-EDIT-FDWDY
               THRU 7630-EDIT-FDWDY-X.

           PERFORM  7640-EDIT-MXMOS
               THRU 7640-EDIT-MXMOS-X.

           PERFORM  7650-EDIT-ISSDF
               THRU 7650-EDIT-ISSDF-X.

           PERFORM  7660-EDIT-ISSDL
               THRU 7660-EDIT-ISSDL-X.

           IF  WS-VALID-ISSDF
           AND WS-VALID-ISSDL
               PERFORM  7670-ISSUE-CROSS-EDIT
                   THRU 7670-ISSUE-CROSS-EDIT-X
           END-IF.

           PERFORM  7680-EDIT-ADRPU
               THRU 7680-EDIT-ADRPU-X.

           PERFORM  7690-EDIT-EXPYP
               THRU 7690-EDIT-EXPYP-X.

           PERFORM  7700-EDIT-BZAMT
               THRU 7700-EDIT-BZAMT-X.

023443     PERFORM  7705-EDIT-DLR-RECALC-IND
023443         THRU 7705-EDIT-DLR-RECALC-IND-X.
023443
029060     PERFORM  7706-EDIT-2YR-LKBACK-IND
029060         THRU 7706-EDIT-2YR-LKBACK-IND-X.
029060
           PERFORM  7710-EDIT-DFTSC
               THRU 7710-EDIT-DFTSC-X.

           PERFORM  7720-EDIT-DFTLN
               THRU 7720-EDIT-DFTLN-X.

           PERFORM  7730-EDIT-PRTLT
               THRU 7730-EDIT-PRTLT-X.

           PERFORM  7740-EDIT-PRTLP
               THRU 7740-EDIT-PRTLP-X.

           PERFORM  7750-EDIT-PRTLA
               THRU 7750-EDIT-PRTLA-X.

           PERFORM  7760-EDIT-PRTLTI
               THRU 7760-EDIT-PRTLTI-X.

           PERFORM  7770-EDIT-PRTLPI
               THRU 7770-EDIT-PRTLPI-X.

           PERFORM  7780-EDIT-PRTLAI
               THRU 7780-EDIT-PRTLAI-X.

           PERFORM  7790-EDIT-LNTLT
               THRU 7790-EDIT-LNTLT-X.

           PERFORM  7800-EDIT-LNTLP
               THRU 7800-EDIT-LNTLP-X.

           PERFORM  7810-EDIT-LNTLA
               THRU 7810-EDIT-LNTLA-X.

016503     PERFORM  7820-EDIT-BILL-LEAD-DY-DUR
016503         THRU 7820-EDIT-BILL-LEAD-DY-DUR-X.

016503     PERFORM  7830-EDIT-PAC-LEAD-DY-DUR
016503         THRU 7830-EDIT-PAC-LEAD-DY-DUR-X.

016503     PERFORM  7840-EDIT-ANPAYO-LEAD-DY-DUR
016503         THRU 7840-EDIT-ANPAYO-LEAD-DY-DUR-X.

016503     PERFORM  7850-EDIT-CLM-LEAD-DY-DUR
016503         THRU 7850-EDIT-CLM-LEAD-DY-DUR-X.

016503     PERFORM  7860-EDIT-OTHR-LEAD-DY-DUR
016503         THRU 7860-EDIT-OTHR-LEAD-DY-DUR-X.

016503     PERFORM  7870-EDIT-REQIR-LEAD-DY-DUR
016503         THRU 7870-EDIT-REQIR-LEAD-DY-DUR-X.

016395     PERFORM  7880-EDIT-CRC-LEAD-DY-DUR
016395         THRU 7880-EDIT-CRC-LEAD-DY-DUR-X.

020467     PERFORM  8700-EDIT-DD2-LEAD-DY-DUR
020467         THRU 8700-EDIT-DD2-LEAD-DY-DUR-X.

       7510-EDIT-SCREEN-1-X.
           EXIT.
      /
       7520-EDIT-SCREEN-2.

           PERFORM  7980-EDIT-COMPD
               THRU 7980-EDIT-COMPD-X.

           PERFORM  8050-EDIT-RNDYS
               THRU 8050-EDIT-RNDYS-X.

           PERFORM  7900-EDIT-DEPDF
               THRU 7900-EDIT-DEPDF-X.

           PERFORM  7910-EDIT-DEPDL
               THRU 7910-EDIT-DEPDL-X.

           PERFORM  7990-EDIT-COMTT
               THRU 7990-EDIT-COMTT-X.

           PERFORM  8060-EDIT-RTOLT
               THRU 8060-EDIT-RTOLT-X.

           PERFORM  7940-EDIT-DRAW-IND
               THRU 7940-EDIT-DRAW-IND-X.

           PERFORM  8020-EDIT-COMTI
               THRU 8020-EDIT-COMTI-X.

           PERFORM  8090-EDIT-RTOLO
               THRU 8090-EDIT-RTOLO-X.

           PERFORM  7950-EDIT-REDRAW-IND
               THRU 7950-EDIT-REDRAW-IND-X.

           PERFORM  8030-EDIT-COMTA
               THRU 8030-EDIT-COMTA-X.

           PERFORM  8100-EDIT-RTOLF
               THRU 8100-EDIT-RTOLF-X.

           PERFORM  7930-EDIT-PACRO
               THRU 7930-EDIT-PACRO-X.

           PERFORM  8000-EDIT-COMTP
               THRU 8000-EDIT-COMTP-X.

           PERFORM  8070-EDIT-RTOLP
               THRU 8070-EDIT-RTOLP-X.

           PERFORM  7960-EDIT-MDRED
               THRU 7960-EDIT-MDRED-X.

           PERFORM  8040-EDIT-CMIRI
               THRU 8040-EDIT-CMIRI-X.

           PERFORM  8080-EDIT-RIRTI
               THRU 8080-EDIT-RIRTI-X.

           PERFORM  8010-EDIT-COMSI
               THRU 8010-EDIT-COMSI-X.

016395     PERFORM  8120-EDIT-CRC-REDRW-OPT-CD
016395         THRU 8120-EDIT-CRC-REDRW-OPT-CD-X.

016395     PERFORM  8130-EDIT-CRC-REDRW-DUR
016395         THRU 8130-EDIT-CRC-REDRW-DUR-X.

016395     PERFORM  8140-CROSS-EDIT-CRC-REDRW
016395         THRU 8140-CROSS-EDIT-CRC-REDRW-X.

016395     PERFORM  8150-EDIT-CRC-FRST-DPOS-DY
016395         THRU 8150-EDIT-CRC-FRST-DPOS-DY-X.

016395     PERFORM  8160-EDIT-CRC-FINAL-DPOS-DY
016395         THRU 8160-EDIT-CRC-FINAL-DPOS-DY-X.

016395     IF  WS-VALID-CRCDEPDF
016395     AND WS-VALID-CRCDEPDL
016395     PERFORM  8170-CROSS-EDIT-CRC-DPOS
016395         THRU 8170-CROSS-EDIT-CRC-DPOS-X
016395     END-IF.

           IF  WS-VALID-DEPDF
           AND WS-VALID-DEPDL
               PERFORM  7920-PAC-CROSS-EDIT
                   THRU 7920-PAC-CROSS-EDIT-X
           END-IF.

           PERFORM  7970-PACRO-CROSS-EDIT
               THRU 7970-PACRO-CROSS-EDIT-X.

           IF WS-COMTMT-TOLR-TYPE-VALID
           AND WS-VALID-DEPDL
               PERFORM  7920-PAC-CROSS-EDIT
                   THRU 7920-PAC-CROSS-EDIT-X
           END-IF.

           PERFORM  8190-SCREEN2-CROSS-EDITS
               THRU 8190-SCREEN2-CROSS-EDITS-X.

020467     PERFORM  8710-EDIT-DD2-DEPDF
020467         THRU 8710-EDIT-DD2-DEPDF-X.
020467
020467     PERFORM  8720-EDIT-DD2-DEPDL
020467         THRU 8720-EDIT-DD2-DEPDL-X.
020467
020467     PERFORM  8730-EDIT-DD2RO
020467         THRU 8730-EDIT-DD2RO-X.
020467
020467     PERFORM  8740-EDIT-DD2-DRAW-IND
020467         THRU 8740-EDIT-DD2-DRAW-IND-X.
020467
020467     PERFORM  8750-EDIT-DD2-REDRAW-IND
020467         THRU 8750-EDIT-DD2-REDRAW-IND-X.
020467
020467     PERFORM  8760-EDIT-DD2-MDRED
020467         THRU 8760-EDIT-DD2-MDRED-X.
020467
020467     PERFORM  8770-DD2RO-CROSS-EDIT
020467         THRU 8770-DD2RO-CROSS-EDIT-X.
020467
020467     IF  WS-VALID-DD2-DEPDF
020467     AND WS-VALID-DD2-DEPDL
020467         PERFORM  8780-DD2-CROSS-EDIT
020467             THRU 8780-DD2-CROSS-EDIT-X
020467     END-IF.
020467
020467     IF WS-COMTMT-TOLR-TYPE-VALID
020467     AND WS-VALID-DD2-DEPDL
020467         PERFORM  8780-DD2-CROSS-EDIT
020467             THRU 8780-DD2-CROSS-EDIT-X
020467     END-IF.
020467
020467     PERFORM  8785-EDIT-2AMLI
020467         THRU 8785-EDIT-2AMLI-X.
020467
020463     PERFORM  8790-EDIT-ARTOLP
020463         THRU 8790-EDIT-ARTOLP-X.

       7520-EDIT-SCREEN-2-X.
           EXIT.
      /
       7530-EDIT-SCREEN-3.

           PERFORM  8200-EDIT-MXADB
               THRU 8200-EDIT-MXADB-X.

           PERFORM  8210-EDIT-CRADB
               THRU 8210-EDIT-CRADB-X.

           PERFORM  8220-EDIT-MXWPA
               THRU 8220-EDIT-MXWPA-X.

           PERFORM  8230-EDIT-MDISC
               THRU 8230-EDIT-MDISC-X.

           PERFORM  8240-EDIT-MXWPP
               THRU 8240-EDIT-MXWPP-X.

           PERFORM  8250-EDIT-MAXCH
               THRU 8250-EDIT-MAXCH-X.

           PERFORM  8260-EDIT-MAXUW
               THRU 8260-EDIT-MAXUW-X.

           PERFORM  8270-EDIT-MAXAL
               THRU 8270-EDIT-MAXAL-X.

           PERFORM  8300-EDIT-MCHAG
               THRU 8300-EDIT-MCHAG-X.

           PERFORM  8310-EDIT-YRCAL
               THRU 8310-EDIT-YRCAL-X.

           PERFORM  8590-EDIT-IMMON
               THRU 8590-EDIT-IMMON-X.

           PERFORM  8280-EDIT-MIBCS
               THRU 8280-EDIT-MIBCS-X.

           PERFORM  8290-EDIT-MIBDC
               THRU 8290-EDIT-MIBDC-X.

016440*    PERFORM  8320-EDIT-AGCOP
016440*        THRU 8320-EDIT-AGCOP-X.

           PERFORM  8330-EDIT-AGMTH
               THRU 8330-EDIT-AGMTH-X.

           PERFORM  8340-EDIT-AGSUM
               THRU 8340-EDIT-AGSUM-X.

           PERFORM  8350-EDIT-HWMNR
               THRU 8350-EDIT-HWMNR-X.

           PERFORM  8360-EDIT-HWMXR
               THRU 8360-EDIT-HWMXR-X.

           IF  WS-VALID-HWMNR
           AND WS-VALID-HWMXR
               PERFORM  8370-RATING-CROSS-EDIT
                   THRU 8370-RATING-CROSS-EDIT-X
           END-IF.

       7530-EDIT-SCREEN-3-X.
           EXIT.
      /
       7540-EDIT-SCREEN-4.

016440*    PERFORM  8500-EDIT-HCOMP
016440*        THRU 8500-EDIT-HCOMP-X.

           PERFORM  8510-BLANK-OOE-GROUP
               THRU 8510-BLANK-OOE-GROUP-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-OOE-ENTRIES.

           PERFORM  8520-EDIT-OOEOC
               THRU 8520-EDIT-OOEOC-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-OOE-ENTRIES.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.

           PERFORM  8530-EDIT-OOEMX
               THRU 8530-EDIT-OOEMX-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-OOE-ENTRIES.

           PERFORM  8540-EDIT-OOECC
               THRU 8540-EDIT-OOECC-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-OOE-ENTRIES.

           PERFORM  8550-XEDIT-OOE-ENTRY
               THRU 8550-XEDIT-OOE-ENTRY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-OOE-ENTRIES.

           MOVE 'N'                   TO WS-DUP-FOUND-SW.

           PERFORM  8560-CHECK-FOR-DUPLICATE
               THRU 8560-CHECK-FOR-DUPLICATE-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-OOE-ENTRIES.

           IF WS-DUP-FOUND
      *MSG:    THERE ARE DUPLICATE OCC CLASSES-FIRST WILL BE USED
               MOVE 'NS33600090'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

           PERFORM  8570-EDIT-MXADD
               THRU 8570-EDIT-MXADD-X.

           PERFORM  8580-EDIT-UERAT
               THRU 8580-EDIT-UERAT-X.

           PERFORM  8600-EDIT-HMDIS
               THRU 8600-EDIT-HMDIS-X.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 1                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +5                    TO L0280-INPUT-SIZE.

           PERFORM  8610-EDIT-HOURS-ENTRY
               THRU 8610-EDIT-HOURS-ENTRY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-HOURS-ENTRIES.

           PERFORM  8670-XEDIT-HOURS-ENTRY
               THRU 8670-XEDIT-HOURS-ENTRY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-HOURS-ENTRIES.

       7540-EDIT-SCREEN-4-X.
           EXIT.
      /
      *****************************************************************
      *  ASYS-MAX-POL-BACK-DT : MUST BE NUMERIC IN RANGE 0 TO 999
      *****************************************************************

       7600-EDIT-MXBDT.

           IF  MIR-MAX-BCKDT-MO-DUR   =  SPACES
020874*        MOVE RSCOM-MAX-BCKDT-MO-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-MAX-BCKDT-MO-DUR
020874         MOVE RSCOM-MAX-BCKDT-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-BCKDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-BCKDT-MO-DUR
               GO TO 7600-EDIT-MXBDT-X
           END-IF.

           IF  MIR-MAX-BCKDT-MO-DUR   =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-MAX-BCKDT-MO-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-BCKDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-BCKDT-MO-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-BCKDT-MO-DUR  TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
                                         WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-MAX-BCKDT-MO-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-BCKDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-BCKDT-MO-DUR
               IF  WS-MXBDT-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-MAX-BCKDT-MO-DUR
               ELSE
                   MOVE 'NS33600109'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600110'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7600-EDIT-MXBDT-X.
           EXIT.


      *****************************************************************
      *  DISPO-DAYS: MUST BE NUMERIC IN RANGE 1 TO 999
      *****************************************************************
       7610-EDIT-FDSDY.

           IF  MIR-FINAL-DISP-DY-DUR = SPACES
020874*        MOVE RSCOM-FINAL-DISP-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-FINAL-DISP-DY-DUR
020874         MOVE RSCOM-FINAL-DISP-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DISP-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DISP-DY-DUR
               GO TO 7610-EDIT-FDSDY-X
           END-IF.

           IF  MIR-FINAL-DISP-DY-DUR = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-FINAL-DISP-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DISP-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DISP-DY-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-FINAL-DISP-DY-DUR TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-ZZ9
020874         MOVE L0280-OUTPUT      TO
                                        WS-TEST-RANGE
020874*        MOVE WS-PIC-ZZ9        TO MIR-FINAL-DISP-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DISP-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DISP-DY-DUR
               IF  WS-FDSDY-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-FINAL-DISP-DY-DUR
               ELSE
                   MOVE 'NS33600021'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600045'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7610-EDIT-FDSDY-X.
           EXIT.


      *****************************************************************
      *  ASYS-MAX-POL-POST-DT : MUST BE NUMERIC IN RANGE 0 TO 999
      *****************************************************************

       7620-EDIT-MXPDT.

           IF  MIR-MAX-PSTDT-MO-DUR                    =  SPACES
020874*        MOVE RSCOM-MAX-PSTDT-MO-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-MAX-PSTDT-MO-DUR
020874         MOVE RSCOM-MAX-PSTDT-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-PSTDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-PSTDT-MO-DUR
               GO TO 7620-EDIT-MXPDT-X
           END-IF.

           IF  MIR-MAX-PSTDT-MO-DUR  =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-MAX-PSTDT-MO-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-PSTDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-PSTDT-MO-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-PSTDT-MO-DUR  TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
                                               WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-MAX-PSTDT-MO-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-PSTDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-PSTDT-MO-DUR
               IF  WS-MXPDT-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-MAX-PSTDT-MO-DUR
               ELSE
                   MOVE 'NS33600111'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600112'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7620-EDIT-MXPDT-X.
           EXIT.

      *****************************************************************
      *  DISPO-WARNING: MUST BE NUMERIC IN RANGE 1 TO 999
      *****************************************************************
       7630-EDIT-FDWDY.

           IF  MIR-DISP-WARN-DY-DUR = SPACES
020874*        MOVE RSCOM-DISP-WARN-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-DISP-WARN-DY-DUR
020874         MOVE RSCOM-DISP-WARN-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DISP-WARN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DISP-WARN-DY-DUR
               GO TO 7630-EDIT-FDWDY-X
           END-IF.

           IF  MIR-DISP-WARN-DY-DUR = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-DISP-WARN-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DISP-WARN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DISP-WARN-DY-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-DISP-WARN-DY-DUR  TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-ZZ9
020874         MOVE L0280-OUTPUT      TO
                                        WS-TEST-RANGE
020874*        MOVE WS-PIC-ZZ9        TO MIR-DISP-WARN-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DISP-WARN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DISP-WARN-DY-DUR
               IF  WS-FDWDY-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-DISP-WARN-DY-DUR
               ELSE
                   MOVE 'NS33600022'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600046'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7630-EDIT-FDWDY-X.
           EXIT.


       7640-EDIT-MXMOS.
           IF MIR-MAX-UNDO-MO-DUR                     = SPACES
020874*        MOVE RSCOM-MAX-UNDO-MO-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-MAX-UNDO-MO-DUR
020874         MOVE RSCOM-MAX-UNDO-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-UNDO-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-UNDO-MO-DUR
               GO TO 7640-EDIT-MXMOS-X
           END-IF.

           IF MIR-MAX-UNDO-MO-DUR  = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-MAX-UNDO-MO-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-UNDO-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-UNDO-MO-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-UNDO-MO-DUR   TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
                                               WS-TEST-RANGE
020874*        MOVE WS-N-999          TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-MAX-UNDO-MO-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-UNDO-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-UNDO-MO-DUR
               IF WS-MXMOS-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-MAX-UNDO-MO-DUR
               ELSE
      *MSG:        MAX MTHS FOR UNDO/REDO MUST BE  0 - 999
                   MOVE 'NS33600127'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
      *MSG:    MAX # MOS MUST BE NUMERIC
               MOVE 'NS33600118'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7640-EDIT-MXMOS-X.
           EXIT.

      *****************************************************************
      *  ASYS-ISS-FIRST: MUST BE NUMERIC IN RANGE 1 TO 31
      *****************************************************************

       7650-EDIT-ISSDF.

           MOVE '0'                   TO WS-VALIDATE-ISSDF.

           IF  MIR-FRST-ISS-DY                    =  SPACES
               MOVE RSCOM-FRST-ISS-DY TO WS-SAVE-ISSDF
020874*        MOVE RSCOM-FRST-ISS-DY TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-FRST-ISS-DY
020874         MOVE RSCOM-FRST-ISS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-ISS-DY
               GO TO 7650-EDIT-ISSDF-X
           END-IF.

           IF  MIR-FRST-ISS-DY  =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-99
               MOVE +0                TO WS-SAVE-ISSDF
020874*        MOVE WS-N-99           TO MIR-FRST-ISS-DY
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-ISS-DY
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-FRST-ISS-DY       TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-99
020874         MOVE L0280-OUTPUT      TO
                                               WS-TEST-RANGE
020874*        MOVE WS-N-99           TO MIR-FRST-ISS-DY
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-ISS-DY
               IF  WS-ISSDF-VALID
                   MOVE L0280-OUTPUT  TO WS-SAVE-ISSDF
               ELSE
                   MOVE 'NS33600105'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
                                        WS-VALIDATE-ISSDF
               END-IF
           ELSE
               MOVE 'NS33600106'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
                                         WS-VALIDATE-ISSDF
           END-IF.

       7650-EDIT-ISSDF-X.
           EXIT.


      *****************************************************************
      *  ASYS-ISS-LAST : MUST BE NUMERIC IN RANGE 1 TO 31
      *****************************************************************

       7660-EDIT-ISSDL.

           MOVE '0'                   TO WS-VALIDATE-ISSDL.

           IF  MIR-FINAL-ISS-DY                    =  SPACES
               MOVE RSCOM-FINAL-ISS-DY                  TO WS-SAVE-ISSDL
020874*        MOVE RSCOM-FINAL-ISS-DY                        TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-FINAL-ISS-DY
020874         MOVE RSCOM-FINAL-ISS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-ISS-DY
               GO TO 7660-EDIT-ISSDL-X
           END-IF.

           IF  MIR-FINAL-ISS-DY  =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-99
               MOVE +0                TO WS-SAVE-ISSDL
020874*        MOVE WS-N-99           TO MIR-FINAL-ISS-DY
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-ISS-DY
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-FINAL-ISS-DY      TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-99
020874         MOVE L0280-OUTPUT      TO
                                               WS-TEST-RANGE
020874*        MOVE WS-N-99           TO MIR-FINAL-ISS-DY
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-ISS-DY
               IF  WS-ISSDL-VALID
                   MOVE L0280-OUTPUT  TO WS-SAVE-ISSDL
               ELSE
                   MOVE 'NS33600105'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
                                         WS-VALIDATE-ISSDL
                   GO TO 7660-EDIT-ISSDL-X
               END-IF
           ELSE
               MOVE 'NS33600107'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
                                         WS-VALIDATE-ISSDL
           END-IF.

       7660-EDIT-ISSDL-X.
           EXIT.


       7670-ISSUE-CROSS-EDIT.

           IF (WS-SAVE-ISSDF LESS THAN WS-SAVE-ISSDL)
               MOVE WS-SAVE-ISSDF     TO RSCOM-FRST-ISS-DY
               MOVE WS-SAVE-ISSDL     TO RSCOM-FINAL-ISS-DY
           ELSE
               MOVE 'NS33600108'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7670-ISSUE-CROSS-EDIT-X.
           EXIT.


       7680-EDIT-ADRPU.

           IF  MIR-RPU-DR-CD  =  SPACES
               MOVE RSCOM-RPU-DR-CD   TO MIR-RPU-DR-CD
               GO TO 7680-EDIT-ADRPU-X
           END-IF.

           IF  MIR-RPU-DR-CD =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-RPU-DR-CD
           END-IF.

           MOVE MIR-RPU-DR-CD         TO WS-VALIDATE-ADRPU.

           IF  WS-VALID-ADRPU
               MOVE MIR-RPU-DR-CD     TO RSCOM-RPU-DR-CD
           ELSE
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS33600100'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7680-EDIT-ADRPU-X
           END-IF.

       7680-EDIT-ADRPU-X.
           EXIT.


       7690-EDIT-EXPYP.

           IF  MIR-XTRNL-PMT-IND                    = SPACES
               MOVE RSCOM-XTRNL-PMT-IND
                                      TO MIR-XTRNL-PMT-IND
               GO TO 7690-EDIT-EXPYP-X
           END-IF.

           IF  MIR-XTRNL-PMT-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-XTRNL-PMT-IND
           END-IF.

           MOVE MIR-XTRNL-PMT-IND     TO WS-YES-NO-TEST.

           IF  WS-YES-NO-VALID
               MOVE MIR-XTRNL-PMT-IND TO RSCOM-XTRNL-PMT-IND
           ELSE
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS33600129'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7690-EDIT-EXPYP-X.
           EXIT.


       7700-EDIT-BZAMT.

           IF  MIR-BILL-ZERO-AMT-IND =  SPACES
               MOVE RSCOM-BILL-ZERO-AMT-IND
                                      TO MIR-BILL-ZERO-AMT-IND
               GO TO 7700-EDIT-BZAMT-X
           END-IF.

           IF  MIR-BILL-ZERO-AMT-IND =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-BILL-ZERO-AMT-IND
           END-IF.

           MOVE MIR-BILL-ZERO-AMT-IND TO WS-YES-NO-TEST.

           IF  WS-YES-NO-VALID
               MOVE MIR-BILL-ZERO-AMT-IND
                                      TO RSCOM-BILL-ZERO-AMT-IND
           ELSE
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS33600101'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7700-EDIT-BZAMT-X
           END-IF.

       7700-EDIT-BZAMT-X.
           EXIT.

023443
023443*-------------------------
023443 7705-EDIT-DLR-RECALC-IND.
023443*-------------------------
023443
023443     IF  MIR-DLR-DIV-RECALC-IND =  SPACES
023443         MOVE RSCOM-DLR-DIV-RECALC-IND
023443                                  TO MIR-DLR-DIV-RECALC-IND
023443         GO TO 7705-EDIT-DLR-RECALC-IND-X
023443     END-IF.
023443
023443     IF  MIR-DLR-DIV-RECALC-IND =  EBLCH-BLANK-FIELD-CHAR
023443         MOVE SPACES              TO MIR-DLR-DIV-RECALC-IND
023443     END-IF.
023443
023443     MOVE MIR-DLR-DIV-RECALC-IND  TO WS-YES-NO-TEST.
023443
023443     IF  WS-YES-NO-VALID
023443         MOVE MIR-DLR-DIV-RECALC-IND
023443                                  TO RSCOM-DLR-DIV-RECALC-IND
023443     ELSE
023443         SET WS-DATA-EDITS-FAILED TO TRUE
023443         MOVE 'NS33600161'        TO WGLOB-MSG-REF-INFO
023443         PERFORM  0260-1000-GENERATE-MESSAGE
023443             THRU 0260-1000-GENERATE-MESSAGE-X
023443         GO TO 7705-EDIT-DLR-RECALC-IND-X
023443     END-IF.
023443
023443 7705-EDIT-DLR-RECALC-IND-X.
023443     EXIT.
029060
029060*------------------------
029060 7706-EDIT-2YR-LKBACK-IND.
029060*------------------------
029060
029060     IF  MIR-MEC-2YR-ADJ-IND  =  SPACES
029060         MOVE RSCOM-MEC-2YR-ADJ-IND TO MIR-MEC-2YR-ADJ-IND
029060         GO TO 7706-EDIT-2YR-LKBACK-IND-X
029060     END-IF.
029060
029060     IF  MIR-MEC-2YR-ADJ-IND  =  EBLCH-BLANK-FIELD-CHAR
029060         MOVE SPACES                TO MIR-MEC-2YR-ADJ-IND
029060     END-IF.
029060
029060     MOVE MIR-MEC-2YR-ADJ-IND       TO WS-YES-NO-TEST.
029060
029060     IF  WS-YES-NO-VALID
029060         MOVE MIR-MEC-2YR-ADJ-IND   TO RSCOM-MEC-2YR-ADJ-IND
029060     ELSE
029060         SET WS-DATA-EDITS-FAILED   TO TRUE
029060*MSG INVALID MEC 2 YEAR LOOK BACK INDICATOR, MUST BE Y OR N.
029060         MOVE 'NS33600163'          TO WGLOB-MSG-REF-INFO
029060         PERFORM  0260-1000-GENERATE-MESSAGE
029060             THRU 0260-1000-GENERATE-MESSAGE-X
029060         GO TO 7706-EDIT-2YR-LKBACK-IND-X
029060     END-IF.
029060
029060 7706-EDIT-2YR-LKBACK-IND-X.
029060     EXIT.

      *****************************************************************
      *  SBSDRY-CO-DFLT-IND:             MUST BE Y OR N
      *****************************************************************
       7710-EDIT-DFTSC.

           IF  MIR-SBSDRY-CO-DFLT-IND  =  SPACES
               MOVE RSCOM-SBSDRY-CO-DFLT-IND
                                      TO MIR-SBSDRY-CO-DFLT-IND
               GO TO 7710-EDIT-DFTSC-X
           END-IF.

           IF  MIR-SBSDRY-CO-DFLT-IND =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-SBSDRY-CO-DFLT-IND
           END-IF.

           MOVE MIR-SBSDRY-CO-DFLT-IND  TO WS-YES-NO-TEST.

           IF  WS-YES-NO-VALID
               CONTINUE
           ELSE
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS33600012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7710-EDIT-DFTSC-X
           END-IF.

      *  ONLY ONE SUB-COMPANY CAN HAVE DEFAULT INDICATOR SET TO YES

           IF  WS-YES
               PERFORM  7715-LOOK-FOR-DFLT-SUBCO
                   THRU 7715-LOOK-FOR-DFLT-SUBCO-X
               IF  WS-ANOTHER-DFLT-SUBCO-FOUND
                   MOVE '1'           TO WS-DATA-EDITS
                   MOVE 'NS33600019'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 7710-EDIT-DFTSC-X
               END-IF
           END-IF.

           MOVE MIR-SBSDRY-CO-DFLT-IND   TO RSCOM-SBSDRY-CO-DFLT-IND.

       7710-EDIT-DFTSC-X.
           EXIT.

       7715-LOOK-FOR-DFLT-SUBCO.

           MOVE RSCOM-REC-INFO        TO HSCOM-REC-INFO.
           SET  WS-ANOTHER-DFLT-SUBCO-FOUND-NO TO TRUE.

           MOVE LOW-VALUES            TO WSCOM-KEY.
           MOVE HIGH-VALUES           TO WSCOM-ENDBR-KEY.

           PERFORM  SCOM-1000-BROWSE
               THRU SCOM-1000-BROWSE-X.

           PERFORM  SCOM-2000-READ-NEXT
               THRU SCOM-2000-READ-NEXT-X.

           PERFORM
               UNTIL (NOT WSCOM-IO-OK)
                  OR WS-ANOTHER-DFLT-SUBCO-FOUND

               IF  RSCOM-SBSDRY-CO-DFLT
               AND RSCOM-SBSDRY-CO-ID NOT = HSCOM-SBSDRY-CO-ID
                   SET WS-ANOTHER-DFLT-SUBCO-FOUND TO TRUE
               ELSE
                   PERFORM  SCOM-2000-READ-NEXT
                       THRU SCOM-2000-READ-NEXT-X
               END-IF
           END-PERFORM.

           PERFORM  SCOM-3000-END-BROWSE
               THRU SCOM-3000-END-BROWSE-X.

           MOVE HSCOM-REC-INFO        TO RSCOM-REC-INFO.

       7715-LOOK-FOR-DFLT-SUBCO-X.
           EXIT.

      *****************************************************************
      *  DFLT-LANG-CD:            MUST BE IN EDIT - TYPE LANG
      *****************************************************************
       7720-EDIT-DFTLN.

           IF MIR-DFLT-LANG-CD = SPACES
               MOVE RSCOM-DFLT-LANG-CD     TO MIR-DFLT-LANG-CD
               GO TO 7720-EDIT-DFTLN-X
           END-IF.

           IF MIR-DFLT-LANG-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-DFLT-LANG-CD
               MOVE SPACES            TO RSCOM-DFLT-LANG-CD
               GO TO 7720-EDIT-DFTLN-X
           END-IF.

           MOVE MIR-DFLT-LANG-CD      TO WEDIT-ETBL-VALU-ID.
           PERFORM  LANG-1000-EDIT
               THRU LANG-1000-EDIT-X.
           IF NOT WEDIT-IO-OK
      *MSG:    DEFAULT LANGUAGE MUST BE IN EDIT - TYPE LANG
               MOVE 'NS33600002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
               GO TO 7720-EDIT-DFTLN-X
           END-IF.

           MOVE MIR-DFLT-LANG-CD      TO RSCOM-DFLT-LANG-CD.

       7720-EDIT-DFTLN-X.
           EXIT.


      *****************************************************************
      *  PREM-TOLR-TYPE (PENDING):       MUST BE A  M OR P
      *****************************************************************
       7730-EDIT-PRTLT.

           IF MIR-PEND-PREM-TOL-CD = SPACES
               MOVE RSCOM-PEND-PREM-TOL-CD
                                      TO MIR-PEND-PREM-TOL-CD
               GO TO 7730-EDIT-PRTLT-X
           END-IF.


           MOVE MIR-PEND-PREM-TOL-CD  TO WS-PENDING-PREM-TOLR-TYPE.
           IF WS-PENDING-PREM-TYPE-VALID
               MOVE MIR-PEND-PREM-TOL-CD
                                      TO RSCOM-PEND-PREM-TOL-CD
           ELSE
               MOVE 'NS33600010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7730-EDIT-PRTLT-X.
           EXIT.

      *****************************************************************
      *  PREM-TOLR-PCNT: MUST BE NUMERIC IN RANGE 0 TO 100
      *****************************************************************
       7740-EDIT-PRTLP.

           IF MIR-PEND-PREM-TOL-PCT = SPACES
020874*        MOVE RSCOM-PEND-PREM-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-PEND-PREM-TOL-PCT
020874         MOVE RSCOM-PEND-PREM-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PEND-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PEND-PREM-TOL-PCT
               GO TO 7740-EDIT-PRTLP-X
           END-IF.

           IF MIR-PEND-PREM-TOL-PCT = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-PEND-PREM-TOL-PCT
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PEND-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PEND-PREM-TOL-PCT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-PEND-PREM-TOL-PCT TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-TEST-RANGE
               IF WS-MIR-PEND-PREM-TOL-PCT-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-PEND-PREM-TOL-PCT
020874*            MOVE RSCOM-PEND-PREM-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*            MOVE WS-PIC-ZZ9    TO MIR-PEND-PREM-TOL-PCT
020874             MOVE RSCOM-PEND-PREM-TOL-PCT TO L0290-INPUT-V00
020874             MOVE 0             TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-PEND-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA TO MIR-PEND-PREM-TOL-PCT
               ELSE
                   MOVE 'NS33600011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7740-EDIT-PRTLP-X.
           EXIT.

      *****************************************************************
      *  PREM-TOLR-AMT: MUST BE NUMERIC
      *****************************************************************
       7750-EDIT-PRTLA.

           IF MIR-PEND-PREM-TOL-AMT = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-PEND-PREM-TOL-AMT
020874*                                     * 100
020874         MOVE RSCOM-PEND-PREM-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7752-FORMAT-PRTLA
                   THRU 7752-FORMAT-PRTLA-X
               GO TO 7750-EDIT-PRTLA-X
           END-IF.

           IF MIR-PEND-PREM-TOL-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-PEND-PREM-TOL-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-PEND-PREM-TOL-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
                                  - 1.
           MOVE MIR-PEND-PREM-TOL-AMT TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
               PERFORM  7752-FORMAT-PRTLA
                   THRU 7752-FORMAT-PRTLA-X
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RSCOM-PEND-PREM-TOL-AMT
           ELSE
               MOVE 'NS33600035'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7750-EDIT-PRTLA-X.
           EXIT.


      *****************************************************************
      *  PREM-TOLR-AMT: OUTPUT FORMAT Z(6)9.99
      *****************************************************************
       7752-FORMAT-PRTLA.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PEND-PREM-TOL-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-PEND-PREM-TOL-AMT.
       7752-FORMAT-PRTLA-X.
           EXIT.

      *****************************************************************
      *  PREM-TOLR-TYPE (INFORCE):       MUST BE A  M OR P
      *****************************************************************
       7760-EDIT-PRTLTI.

           IF MIR-INFC-PREM-TOL-CD = SPACES
               MOVE RSCOM-INFC-PREM-TOL-CD
                                      TO MIR-INFC-PREM-TOL-CD
               GO TO 7760-EDIT-PRTLTI-X
           END-IF.

           MOVE MIR-INFC-PREM-TOL-CD  TO WS-INFC-PREM-TOL-TYPE.
           IF WS-INFC-PREM-TYPE-VALID
               MOVE MIR-INFC-PREM-TOL-CD
                                      TO RSCOM-INFC-PREM-TOL-CD
           ELSE
               MOVE 'NS33600010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7760-EDIT-PRTLTI-X.
           EXIT.

      *****************************************************************
      *  PREM-TOLR-PCNT: MUST BE NUMERIC IN RANGE 0 TO 100
      *****************************************************************
       7770-EDIT-PRTLPI.

           IF MIR-INFC-PREM-TOL-PCT = SPACES
020874*        MOVE RSCOM-INFC-PREM-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-INFC-PREM-TOL-PCT
020874         MOVE RSCOM-INFC-PREM-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-INFC-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-INFC-PREM-TOL-PCT
               GO TO 7770-EDIT-PRTLPI-X
           END-IF.

           IF MIR-INFC-PREM-TOL-PCT = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-INFC-PREM-TOL-PCT
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-INFC-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-INFC-PREM-TOL-PCT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-INFC-PREM-TOL-PCT TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-TEST-RANGE
020874*        MOVE WS-PIC-ZZ9        TO MIR-INFC-PREM-TOL-PCT
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-INFC-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-INFC-PREM-TOL-PCT
               IF WS-MIR-INFC-PREM-TOL-PCT-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-INFC-PREM-TOL-PCT
020874*            MOVE RSCOM-INFC-PREM-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*            MOVE WS-PIC-ZZ9    TO MIR-INFC-PREM-TOL-PCT
020874             MOVE RSCOM-INFC-PREM-TOL-PCT TO L0290-INPUT-V00
020874             MOVE 0             TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-INFC-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA TO MIR-INFC-PREM-TOL-PCT
               ELSE
                   MOVE 'NS33600011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7770-EDIT-PRTLPI-X.
           EXIT.

      *****************************************************************
      *  PREM-TOLR-INFORCE-AMT: MUST BE NUMERIC
      *****************************************************************
       7780-EDIT-PRTLAI.

           IF MIR-INFC-PREM-TOL-AMT = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-INFC-PREM-TOL-AMT
020874*                                     * 100
020874         MOVE RSCOM-INFC-PREM-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7782-FORMAT-PRTLAI
                   THRU 7782-FORMAT-PRTLAI-X
               GO TO 7780-EDIT-PRTLAI-X
           END-IF.

           IF MIR-INFC-PREM-TOL-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-INFC-PREM-TOL-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-INFC-PREM-TOL-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
                                  - 1.
           MOVE MIR-INFC-PREM-TOL-AMT TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
               PERFORM  7782-FORMAT-PRTLAI
                   THRU 7782-FORMAT-PRTLAI-X
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RSCOM-INFC-PREM-TOL-AMT
           ELSE
               MOVE 'NS33600035'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7780-EDIT-PRTLAI-X.
           EXIT.

      *****************************************************************
      *  PREM-TOLR-INFORCE-AMT: OUTPUT FORMAT Z(6)9.99
      *****************************************************************
       7782-FORMAT-PRTLAI.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-INFC-PREM-TOL-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-INFC-PREM-TOL-AMT.
       7782-FORMAT-PRTLAI-X.
           EXIT.

      *****************************************************************
      *  LOAN-TOLR-TYPE:       MUST BE A  M OR P
      *****************************************************************
       7790-EDIT-LNTLT.

           IF MIR-LOAN-REPAY-TOL-CD = SPACES
               MOVE RSCOM-LOAN-REPAY-TOL-CD
                                      TO MIR-LOAN-REPAY-TOL-CD
               GO TO 7790-EDIT-LNTLT-X
           END-IF.

           MOVE MIR-LOAN-REPAY-TOL-CD TO WS-LOAN-REPAY-TOL-TYPE.
           IF WS-LOAN-REPAY-TYPE-VALID
               MOVE MIR-LOAN-REPAY-TOL-CD
                                      TO RSCOM-LOAN-REPAY-TOL-CD
           ELSE
               MOVE 'NS33600010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7790-EDIT-LNTLT-X.
           EXIT.

      *****************************************************************
      *  LOAN-TOLR-PCNT: MUST BE NUMERIC IN RANGE 0 TO 100
      *****************************************************************
       7800-EDIT-LNTLP.

           IF MIR-LOAN-REPAY-TOL-PCT = SPACES
020874*        MOVE RSCOM-LOAN-REPAY-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-LOAN-REPAY-TOL-PCT
020874         MOVE RSCOM-LOAN-REPAY-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-LOAN-REPAY-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-REPAY-TOL-PCT
               GO TO 7800-EDIT-LNTLP-X
           END-IF.

           IF MIR-LOAN-REPAY-TOL-PCT = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-LOAN-REPAY-TOL-PCT
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-LOAN-REPAY-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-REPAY-TOL-PCT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-LOAN-REPAY-TOL-PCT              TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-TEST-RANGE
020874*        MOVE WS-PIC-ZZ9        TO MIR-LOAN-REPAY-TOL-PCT
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-LOAN-REPAY-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-REPAY-TOL-PCT
               IF WS-MIR-LOAN-RPAY-TOL-PCT-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-LOAN-REPAY-TOL-PCT
020874*            MOVE RSCOM-LOAN-REPAY-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*            MOVE WS-PIC-ZZ9    TO MIR-LOAN-REPAY-TOL-PCT
020874             MOVE RSCOM-LOAN-REPAY-TOL-PCT TO L0290-INPUT-V00
020874             MOVE 0                 TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-LOAN-REPAY-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA TO MIR-LOAN-REPAY-TOL-PCT
               ELSE
                   MOVE 'NS33600011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7800-EDIT-LNTLP-X.
           EXIT.
      *****************************************************************
      *  LOAN-TOLR-AMT: MUST BE NUMERIC
      *****************************************************************
       7810-EDIT-LNTLA.

           IF MIR-LOAN-REPAY-TOL-AMT = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-LOAN-REPAY-TOL-AMT
020874*                                     * 100
020874         MOVE RSCOM-LOAN-REPAY-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7812-FORMAT-LNTLA
                   THRU 7812-FORMAT-LNTLA-X
               GO TO 7810-EDIT-LNTLA-X
           END-IF.

           IF MIR-LOAN-REPAY-TOL-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-LOAN-REPAY-TOL-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-LOAN-REPAY-TOL-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
                                  - 1.
           MOVE MIR-LOAN-REPAY-TOL-AMT              TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
               PERFORM  7812-FORMAT-LNTLA
                   THRU 7812-FORMAT-LNTLA-X
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RSCOM-LOAN-REPAY-TOL-AMT
           ELSE
               MOVE 'NS33600035'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7810-EDIT-LNTLA-X.
           EXIT.

      *****************************************************************
      *  LOAN-TOLR-AMT: OUTPUT FORMAT Z(6)9.99
      *****************************************************************
       7812-FORMAT-LNTLA.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LOAN-REPAY-TOL-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-LOAN-REPAY-TOL-AMT.
       7812-FORMAT-LNTLA-X.
           EXIT.

      *****************************************************************
      *  BILL-LEAD-DY-DUR: MUST BE NUMERIC 0 - 999
      *****************************************************************
016503 7820-EDIT-BILL-LEAD-DY-DUR.

016503     IF  MIR-BILL-LEAD-DY-DUR   =  SPACES
020874*        MOVE RSCOM-BILL-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-BILL-LEAD-DY-DUR
020874         MOVE RSCOM-BILL-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BILL-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-BILL-LEAD-DY-DUR
016503         GO TO 7820-EDIT-BILL-LEAD-DY-DUR-X
016503     END-IF.

016503     IF  MIR-BILL-LEAD-DY-DUR   =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-BILL-LEAD-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BILL-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-BILL-LEAD-DY-DUR
016503     END-IF.

016503     MOVE 'N'                   TO L0280-SIGN-IND.
016503     MOVE 0                     TO L0280-PRECISION.
016503     MOVE 3                     TO L0280-LENGTH.
016503     MOVE +3                    TO L0280-INPUT-SIZE.
016503     MOVE MIR-BILL-LEAD-DY-DUR  TO L0280-INPUT-DATA.

016503     PERFORM  8800-NUMERIC-EDIT
016503         THRU 8800-NUMERIC-EDIT-X.

016503     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016503                                   WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-BILL-LEAD-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BILL-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-BILL-LEAD-DY-DUR
016503         IF  WS-BILL-LEAD-DY-VALID
016503             MOVE L0280-OUTPUT  TO RSCOM-BILL-LEAD-DY-DUR
016503         ELSE
016503*MSG: BILL LEAD TIME DAYS DUR MUST BE POSITIVE NUMERIC (000-999)
016503             MOVE 'NS33600131'  TO WGLOB-MSG-REF-INFO
016503             PERFORM  0260-1000-GENERATE-MESSAGE
016503                 THRU 0260-1000-GENERATE-MESSAGE-X
016503             MOVE '1'           TO WS-DATA-EDITS
016503         END-IF
016503     ELSE
016503*MSG: BILL LEAD TIME DAYS DUR MUST BE POSITIVE NUMERIC (000-999)
016503         MOVE 'NS33600131'      TO WGLOB-MSG-REF-INFO
016503         PERFORM  0260-1000-GENERATE-MESSAGE
016503             THRU 0260-1000-GENERATE-MESSAGE-X
016503         MOVE '1'               TO WS-DATA-EDITS
016503     END-IF.

016503 7820-EDIT-BILL-LEAD-DY-DUR-X.
016503     EXIT.

      *****************************************************************
      *  PAC-LEAD-DY-DUR: MUST BE NUMERIC 0 - 999
      *****************************************************************
016503 7830-EDIT-PAC-LEAD-DY-DUR.

016503     IF  MIR-PAC-LEAD-DY-DUR    =  SPACES
020874*        MOVE RSCOM-PAC-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-PAC-LEAD-DY-DUR
020874         MOVE RSCOM-PAC-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PAC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PAC-LEAD-DY-DUR
016503         GO TO 7830-EDIT-PAC-LEAD-DY-DUR-X
016503     END-IF.

016503     IF  MIR-PAC-LEAD-DY-DUR    =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-PAC-LEAD-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PAC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PAC-LEAD-DY-DUR
016503     END-IF.

016503     MOVE 'N'                   TO L0280-SIGN-IND.
016503     MOVE 0                     TO L0280-PRECISION.
016503     MOVE 3                     TO L0280-LENGTH.
016503     MOVE +3                    TO L0280-INPUT-SIZE.
016503     MOVE MIR-PAC-LEAD-DY-DUR   TO L0280-INPUT-DATA.

016503     PERFORM  8800-NUMERIC-EDIT
016503         THRU 8800-NUMERIC-EDIT-X.

016503     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016503                                   WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-PAC-LEAD-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PAC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PAC-LEAD-DY-DUR
016503         IF  WS-BILL-LEAD-DY-VALID
016503             MOVE L0280-OUTPUT  TO RSCOM-PAC-LEAD-DY-DUR
016503         ELSE
016503*MSG: PAC LEAD TIME DAYS MUST BE POSITIVE NUMERIC (000-999)
016503             MOVE 'NS33600132'  TO WGLOB-MSG-REF-INFO
016503             PERFORM  0260-1000-GENERATE-MESSAGE
016503                 THRU 0260-1000-GENERATE-MESSAGE-X
016503             MOVE '1'           TO WS-DATA-EDITS
016503         END-IF
016503     ELSE
016503*MSG: PAC LEAD TIME DAYS MUST BE POSITIVE NUMERIC (000-999)
016503         MOVE 'NS33600132'      TO WGLOB-MSG-REF-INFO
016503         PERFORM  0260-1000-GENERATE-MESSAGE
016503             THRU 0260-1000-GENERATE-MESSAGE-X
016503         MOVE '1'               TO WS-DATA-EDITS
016503     END-IF.

016503 7830-EDIT-PAC-LEAD-DY-DUR-X.
016503     EXIT.


      *****************************************************************
      *  ANPAYO-LEAD-DY-DUR: MUST BE NUMERIC 0 - 999
      *****************************************************************
016503 7840-EDIT-ANPAYO-LEAD-DY-DUR.

016503     IF  MIR-ANPAYO-LEAD-DY-DUR =  SPACES
020874*        MOVE RSCOM-ANPAYO-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-ANPAYO-LEAD-DY-DUR
020874         MOVE RSCOM-ANPAYO-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ANPAYO-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ANPAYO-LEAD-DY-DUR
016503         GO TO 7840-EDIT-ANPAYO-LEAD-DY-DUR-X
016503     END-IF.

016503     IF  MIR-ANPAYO-LEAD-DY-DUR =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-ANPAYO-LEAD-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ANPAYO-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ANPAYO-LEAD-DY-DUR
016503     END-IF.

016503     MOVE 'N'                   TO L0280-SIGN-IND.
016503     MOVE 0                     TO L0280-PRECISION.
016503     MOVE 3                     TO L0280-LENGTH.
016503     MOVE +3                    TO L0280-INPUT-SIZE.
016503     MOVE MIR-ANPAYO-LEAD-DY-DUR TO L0280-INPUT-DATA.

016503     PERFORM  8800-NUMERIC-EDIT
016503         THRU 8800-NUMERIC-EDIT-X.

016503     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016503                                   WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-ANPAYO-LEAD-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ANPAYO-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ANPAYO-LEAD-DY-DUR
016503         IF  WS-BILL-LEAD-DY-VALID
016503             MOVE L0280-OUTPUT  TO RSCOM-ANPAYO-LEAD-DY-DUR
016503         ELSE
016503*MSG: ANNUITY PAYOUT LEAD TIME DAYS MUST BE POSITIVE NUMERIC
016503*     (000-999)
016503             MOVE 'NS33600133'  TO WGLOB-MSG-REF-INFO
016503             PERFORM  0260-1000-GENERATE-MESSAGE
016503                 THRU 0260-1000-GENERATE-MESSAGE-X
016503             MOVE '1'           TO WS-DATA-EDITS
016503         END-IF
016503     ELSE
016503*MSG: ANNUITY PAYOUT LEAD TIME DAYS MUST BE POSITIVE NUMERIC
016503*     (000-999)
016503         MOVE 'NS33600133'      TO WGLOB-MSG-REF-INFO
016503         PERFORM  0260-1000-GENERATE-MESSAGE
016503             THRU 0260-1000-GENERATE-MESSAGE-X
016503         MOVE '1'               TO WS-DATA-EDITS
016503     END-IF.

016503 7840-EDIT-ANPAYO-LEAD-DY-DUR-X.
016503     EXIT.

      *****************************************************************
      *  CLM-LEAD-DY-DUR: MUST BE NUMERIC 0 - 999
      *****************************************************************
016503 7850-EDIT-CLM-LEAD-DY-DUR.

016503     IF  MIR-CLM-LEAD-DY-DUR =     SPACES
020874*        MOVE RSCOM-CLM-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CLM-LEAD-DY-DUR
020874         MOVE RSCOM-CLM-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLM-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLM-LEAD-DY-DUR
016503         GO TO 7850-EDIT-CLM-LEAD-DY-DUR-X
016503     END-IF.

016503     IF  MIR-CLM-LEAD-DY-DUR =     EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CLM-LEAD-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLM-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLM-LEAD-DY-DUR
016503     END-IF.

016503     MOVE 'N'                   TO L0280-SIGN-IND.
016503     MOVE 0                     TO L0280-PRECISION.
016503     MOVE 3                     TO L0280-LENGTH.
016503     MOVE +3                    TO L0280-INPUT-SIZE.
016503     MOVE MIR-CLM-LEAD-DY-DUR TO L0280-INPUT-DATA.

016503     PERFORM  8800-NUMERIC-EDIT
016503         THRU 8800-NUMERIC-EDIT-X.

016503     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016503                                   WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-CLM-LEAD-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLM-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLM-LEAD-DY-DUR
016503         IF  WS-BILL-LEAD-DY-VALID
016503             MOVE L0280-OUTPUT  TO RSCOM-CLM-LEAD-DY-DUR
016503         ELSE
016503*MSG: CLAIM PAYOUT LEAD TIME DAYS MUST BE POSITIVE NUMERIC
016503*     (000-999)
016503             MOVE 'NS33600134'  TO WGLOB-MSG-REF-INFO
016503             PERFORM  0260-1000-GENERATE-MESSAGE
016503                 THRU 0260-1000-GENERATE-MESSAGE-X
016503             MOVE '1'           TO WS-DATA-EDITS
016503         END-IF
016503     ELSE
016503*MSG: CLAIM PAYOUT LEAD TIME DAYS MUST BE POSITIVE NUMEERIC
016503*     (000-999)
016503         MOVE 'NS33600134'      TO WGLOB-MSG-REF-INFO
016503         PERFORM  0260-1000-GENERATE-MESSAGE
016503             THRU 0260-1000-GENERATE-MESSAGE-X
016503         MOVE '1'               TO WS-DATA-EDITS
016503     END-IF.

016503 7850-EDIT-CLM-LEAD-DY-DUR-X.
016503     EXIT.

      *****************************************************************
      *  OTHR-LEAD-DY-DUR: MUST BE NUMERIC 0 - 999
      *****************************************************************
016503 7860-EDIT-OTHR-LEAD-DY-DUR.

016503     IF  MIR-OTHR-LEAD-DY-DUR =    SPACES
020874*        MOVE RSCOM-OTHR-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-OTHR-LEAD-DY-DUR
020874         MOVE RSCOM-OTHR-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-OTHR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-OTHR-LEAD-DY-DUR
016503         GO TO 7860-EDIT-OTHR-LEAD-DY-DUR-X
016503     END-IF.

016503     IF  MIR-OTHR-LEAD-DY-DUR =    EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-OTHR-LEAD-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-OTHR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-OTHR-LEAD-DY-DUR
016503     END-IF.

016503     MOVE 'N'                   TO L0280-SIGN-IND.
016503     MOVE 0                     TO L0280-PRECISION.
016503     MOVE 3                     TO L0280-LENGTH.
016503     MOVE +3                    TO L0280-INPUT-SIZE.
016503     MOVE MIR-OTHR-LEAD-DY-DUR TO L0280-INPUT-DATA.

016503     PERFORM  8800-NUMERIC-EDIT
016503         THRU 8800-NUMERIC-EDIT-X.

016503     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016503                                   WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-OTHR-LEAD-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-OTHR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-OTHR-LEAD-DY-DUR
016503         IF  WS-BILL-LEAD-DY-VALID
016503             MOVE L0280-OUTPUT  TO RSCOM-OTHR-LEAD-DY-DUR
016503         ELSE
016503*MSG: OTHER PAYOUT LEAD TIME DAYS DUR MUST BE POSITIVE NUMERIC
016503*     (000-999)
016503             MOVE 'NS33600135'  TO WGLOB-MSG-REF-INFO
016503             PERFORM  0260-1000-GENERATE-MESSAGE
016503                 THRU 0260-1000-GENERATE-MESSAGE-X
016503             MOVE '1'           TO WS-DATA-EDITS
016503         END-IF
016503     ELSE
016503*MSG: OTHER PAYOUT LEAD TIME DAYS DUR MUST BE POSITIVE NUMERIC
016503*     (000-999)
016503         MOVE 'NS33600135'      TO WGLOB-MSG-REF-INFO
016503         PERFORM  0260-1000-GENERATE-MESSAGE
016503             THRU 0260-1000-GENERATE-MESSAGE-X
016503         MOVE '1'               TO WS-DATA-EDITS
016503     END-IF.

016503 7860-EDIT-OTHR-LEAD-DY-DUR-X.
016503     EXIT.

      *****************************************************************
      *  REQIR-LEAD-DY-DUR: MUST BE NUMERIC 0 - 999
      *****************************************************************
016503 7870-EDIT-REQIR-LEAD-DY-DUR.

016503     IF  MIR-REQIR-LEAD-DY-DUR =   SPACES
020874*        MOVE RSCOM-REQIR-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-REQIR-LEAD-DY-DUR
020874         MOVE RSCOM-REQIR-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-REQIR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-REQIR-LEAD-DY-DUR
016503         GO TO 7870-EDIT-REQIR-LEAD-DY-DUR-X
016503     END-IF.

016503     IF  MIR-REQIR-LEAD-DY-DUR =   EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-REQIR-LEAD-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-REQIR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-REQIR-LEAD-DY-DUR
016503     END-IF.

016503     MOVE 'N'                   TO L0280-SIGN-IND.
016503     MOVE 0                     TO L0280-PRECISION.
016503     MOVE 3                     TO L0280-LENGTH.
016503     MOVE +3                    TO L0280-INPUT-SIZE.
016503     MOVE MIR-REQIR-LEAD-DY-DUR TO L0280-INPUT-DATA.

016503     PERFORM  8800-NUMERIC-EDIT
016503         THRU 8800-NUMERIC-EDIT-X.

016503     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016503                                   WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-REQIR-LEAD-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-REQIR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-REQIR-LEAD-DY-DUR
016503         IF  WS-BILL-LEAD-DY-VALID
016503             MOVE L0280-OUTPUT  TO RSCOM-REQIR-LEAD-DY-DUR
016503         ELSE
016503*MSG: REQUIREMENTS FOLLOW UP LEAD TIME DAYS MUST BE POSITIVE
016503*     NUMERIC (000-999)
016503             MOVE 'NS33600136'  TO WGLOB-MSG-REF-INFO
016503             PERFORM  0260-1000-GENERATE-MESSAGE
016503                 THRU 0260-1000-GENERATE-MESSAGE-X
016503             MOVE '1'           TO WS-DATA-EDITS
016503         END-IF
016503     ELSE
016503*MSG: REQUIREMENTS FOLLOW UP LEAD TIME DAYS MUST BE POSITIVE
016503*     NUMERIC (000-999)
016503         MOVE 'NS33600136'      TO WGLOB-MSG-REF-INFO
016503         PERFORM  0260-1000-GENERATE-MESSAGE
016503             THRU 0260-1000-GENERATE-MESSAGE-X
016503         MOVE '1'               TO WS-DATA-EDITS
016503     END-IF.

016503 7870-EDIT-REQIR-LEAD-DY-DUR-X.
016503     EXIT.

      *****************************************************************
      *  CRC-LEAD-DY-DUR: MUST BE NUMERIC 0 - 999
      *****************************************************************
016503 7880-EDIT-CRC-LEAD-DY-DUR.

016503     IF  MIR-CRC-LEAD-DY-DUR =     SPACES
020874*        MOVE RSCOM-CRC-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-LEAD-DY-DUR
020874         MOVE RSCOM-CRC-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-LEAD-DY-DUR
016503         GO TO 7880-EDIT-CRC-LEAD-DY-DUR-X
016503     END-IF.

016503     IF  MIR-CRC-LEAD-DY-DUR =     EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-LEAD-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-LEAD-DY-DUR
016503     END-IF.

016503     MOVE 'N'                   TO L0280-SIGN-IND.
016503     MOVE 0                     TO L0280-PRECISION.
016503     MOVE 3                     TO L0280-LENGTH.
016503     MOVE +3                    TO L0280-INPUT-SIZE.
016503     MOVE MIR-CRC-LEAD-DY-DUR TO L0280-INPUT-DATA.

016503     PERFORM  8800-NUMERIC-EDIT
016503         THRU 8800-NUMERIC-EDIT-X.

016503     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016503                                   WS-TEST-RANGE
020874*        MOVE WS-N-999          TO MIR-CRC-LEAD-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-LEAD-DY-DUR
016503         IF  WS-BILL-LEAD-DY-VALID
016503             MOVE L0280-OUTPUT  TO RSCOM-CRC-LEAD-DY-DUR
016503         ELSE
016503*MSG: CREDIT CARD LEAD TIME DAYS MUST BE POSITIVE NUMERIC
016503*     (000-999)
016503             MOVE 'NS33600137'  TO WGLOB-MSG-REF-INFO
016503             PERFORM  0260-1000-GENERATE-MESSAGE
016503                 THRU 0260-1000-GENERATE-MESSAGE-X
016503             MOVE '1'           TO WS-DATA-EDITS
016503         END-IF
016503     ELSE
016503*MSG: CREDIT CARD LEAD TIME DAYS MUST BE POSITIVE NUMERIC
016503*     (000-999)
016503         MOVE 'NS33600137'      TO WGLOB-MSG-REF-INFO
016503         PERFORM  0260-1000-GENERATE-MESSAGE
016503             THRU 0260-1000-GENERATE-MESSAGE-X
016503         MOVE '1'               TO WS-DATA-EDITS
016503     END-IF.

016503 7880-EDIT-CRC-LEAD-DY-DUR-X.
016503     EXIT.

      *****************************************************************
      *  ASYS-DEP-FIRST: MUST BE NUMERIC IN RANGE 1 TO 31
      *****************************************************************

       7900-EDIT-DEPDF.

           MOVE '0'                   TO WS-VALIDATE-DEPDF.

           IF  MIR-FRST-DPOS-DY   =  SPACES
               MOVE RSCOM-FRST-DPOS-DY   TO WS-SAVE-DEPDF
020874*        MOVE RSCOM-FRST-DPOS-DY   TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-FRST-DPOS-DY
020874         MOVE RSCOM-FRST-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-DPOS-DY
               GO TO 7900-EDIT-DEPDF-X
           END-IF.

           IF  MIR-FRST-DPOS-DY   =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-99
020874         MOVE 0                 TO
                                         WS-SAVE-DEPDF
020874*        MOVE WS-N-99           TO MIR-FRST-DPOS-DY
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-DPOS-DY
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-FRST-DPOS-DY      TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-99
020874         MOVE L0280-OUTPUT      TO
                                               WS-TEST-RANGE
020874*        MOVE WS-N-99           TO MIR-FRST-DPOS-DY
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-DPOS-DY
               IF  WS-DEPDF-VALID
                   MOVE L0280-OUTPUT  TO WS-SAVE-DEPDF
               ELSE
                   MOVE 'NS33600113'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
                                         WS-VALIDATE-DEPDF
                   GO TO 7900-EDIT-DEPDF-X
               END-IF
           ELSE
               MOVE 'NS33600114'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
                                         WS-VALIDATE-DEPDF
           END-IF.

       7900-EDIT-DEPDF-X.
           EXIT.


      *****************************************************************
      *  ASYS-DEP-LAST : MUST BE NUMERIC IN RANGE 1 TO 31
      *****************************************************************

       7910-EDIT-DEPDL.

           MOVE '0'                   TO WS-VALIDATE-DEPDL.

           IF  MIR-FINAL-DPOS-DY    =  SPACES
               MOVE RSCOM-FINAL-DPOS-DY
                                      TO WS-SAVE-DEPDL
020874*        MOVE RSCOM-FINAL-DPOS-DY
020874*                               TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-FINAL-DPOS-DY
020874         MOVE RSCOM-FINAL-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DPOS-DY
               GO TO 7910-EDIT-DEPDL-X
           END-IF.

           IF  MIR-FINAL-DPOS-DY   =  EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-99
020874         MOVE 0                 TO
                                         WS-SAVE-DEPDL
020874*        MOVE WS-N-99           TO MIR-FINAL-DPOS-DY
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DPOS-DY
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-FINAL-DPOS-DY     TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-99
020874         MOVE L0280-OUTPUT      TO
                                         WS-TEST-RANGE
020874*        MOVE WS-N-99           TO MIR-FINAL-DPOS-DY
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DPOS-DY
               IF  WS-DEPDL-VALID
                   MOVE L0280-OUTPUT  TO WS-SAVE-DEPDL
               ELSE
                   MOVE 'NS33600113'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
                                         WS-VALIDATE-DEPDL
                   GO TO 7910-EDIT-DEPDL-X
               END-IF
           ELSE
               MOVE 'NS33600115'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
                                         WS-VALIDATE-DEPDL
           END-IF.

       7910-EDIT-DEPDL-X.
           EXIT.


       7920-PAC-CROSS-EDIT.

           IF (WS-SAVE-DEPDF < WS-SAVE-DEPDL)
               MOVE WS-SAVE-DEPDF     TO RSCOM-FRST-DPOS-DY
               MOVE WS-SAVE-DEPDL     TO RSCOM-FINAL-DPOS-DY
           ELSE
               MOVE 'NS33600116'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7920-PAC-CROSS-EDIT-X.
           EXIT.


       7930-EDIT-PACRO.

           IF  MIR-PAC-REDRW-OPT-CD                    =  SPACES
               MOVE RSCOM-PAC-REDRW-OPT-CD
                                      TO MIR-PAC-REDRW-OPT-CD
               GO TO 7930-EDIT-PACRO-X
           END-IF.

           IF  MIR-PAC-REDRW-OPT-CD  =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PAC-REDRW-OPT-CD
           END-IF.

           MOVE MIR-PAC-REDRW-OPT-CD  TO WS-VALIDATE-PACRO.

           IF  WS-VALID-PACRO
               MOVE MIR-PAC-REDRW-OPT-CD
                                      TO RSCOM-PAC-REDRW-OPT-CD
           ELSE
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS33600102'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7930-EDIT-PACRO-X.
           EXIT.

       7940-EDIT-DRAW-IND.

           IF MIR-INIT-PAC-DRW-IND   = SPACES
               MOVE RSCOM-INIT-PAC-DRW-IND
                                      TO MIR-INIT-PAC-DRW-IND
               GO TO 7940-EDIT-DRAW-IND-X
           END-IF.

           MOVE MIR-INIT-PAC-DRW-IND  TO WS-VALIDATE-DRAW.

           IF WS-VALID-DRAW
               MOVE MIR-INIT-PAC-DRW-IND
                                      TO RSCOM-INIT-PAC-DRW-IND
           ELSE
               MOVE '1'               TO WS-DATA-EDITS
      *MSG:    INVALID DRAW INDICATOR - MUST BE Y OR N
               MOVE 'NS33600120'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7940-EDIT-DRAW-IND-X.
           EXIT.

       7950-EDIT-REDRAW-IND.

           IF MIR-INIT-PAC-REDRW-IND   = SPACES
               MOVE RSCOM-INIT-PAC-REDRW-IND
                                      TO MIR-INIT-PAC-REDRW-IND
               GO TO 7950-EDIT-REDRAW-IND-X
           END-IF.

           MOVE MIR-INIT-PAC-REDRW-IND  TO WS-VALIDATE-REDRAW.

           IF WS-VALID-REDRAW
               MOVE MIR-INIT-PAC-REDRW-IND
                                      TO RSCOM-INIT-PAC-REDRW-IND
           ELSE
               MOVE '1'               TO WS-DATA-EDITS
      *MSG:    INVALID REDRAW INDICATOR - MUST BE Y OR N
               MOVE 'NS33600121'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7950-EDIT-REDRAW-IND-X.
           EXIT.


       7960-EDIT-MDRED.

           IF  MIR-PAC-REDRW-DUR   =  SPACES
               MOVE RSCOM-PAC-REDRW-DUR
                                      TO MIR-PAC-REDRW-DUR
               GO TO 7960-EDIT-MDRED-X
           END-IF.

           IF  MIR-PAC-REDRW-DUR   =  EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-PAC-REDRW-DUR
           END-IF.

           MOVE MIR-PAC-REDRW-DUR     TO WS-RDDTE.

           IF  WS-RDDTE-MM NUMERIC
           AND WS-RDDTE-DD NUMERIC
           AND WS-RDDTE-FILLER  =  SPACES
               MOVE MIR-PAC-REDRW-DUR TO RSCOM-PAC-REDRW-DUR
           ELSE
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS33600104'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7960-EDIT-MDRED-X.
           EXIT.


       7970-PACRO-CROSS-EDIT.

           IF  RSCOM-PAC-REDRW-OPT-CD       =  '3'
           AND RSCOM-PAC-REDRW-DUR          =  ZEROS
               MOVE RSCOM-PAC-REDRW-OPT-CD
                                      TO WGLOB-MSG-PARM (1)
               MOVE '1'               TO WS-DATA-EDITS
               MOVE 'NS33600103'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7970-PACRO-CROSS-EDIT-X.
           EXIT.

      *****************************************************************
      *  COMTMT-PER: MUST BE NUMERIC
      *****************************************************************
       7980-EDIT-COMPD.

           IF MIR-COMIT-PERI-DY-DUR = SPACES
020874*        MOVE RSCOM-COMIT-PERI-DY-DUR-N
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-COMIT-PERI-DY-DUR
020874         MOVE RSCOM-COMIT-PERI-DY-DUR-N TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-PERI-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-PERI-DY-DUR
               GO TO 7980-EDIT-COMPD-X
           END-IF.

           IF MIR-COMIT-PERI-DY-DUR = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-COMIT-PERI-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-PERI-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-PERI-DY-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-COMIT-PERI-DY-DUR TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-COMIT-PERI-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-PERI-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-PERI-DY-DUR
               MOVE L0280-OUTPUT      TO RSCOM-COMIT-PERI-DY-DUR-N
           ELSE
               MOVE 'NS33600054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7980-EDIT-COMPD-X.
           EXIT.
      *****************************************************************
      *  COMTMT-TOLR-TYPE: MUST BE E, S, B, OR N (NONE)
      *****************************************************************
       7990-EDIT-COMTT.

           IF MIR-COMIT-TOL-CALC-CD = SPACES
               MOVE RSCOM-COMIT-TOL-CALC-CD
                                      TO MIR-COMIT-TOL-CALC-CD
               GO TO 7990-EDIT-COMTT-X
           END-IF.

           IF MIR-COMIT-TOL-CALC-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-COMIT-TOL-CALC-CD
           END-IF.

           MOVE MIR-COMIT-TOL-CALC-CD TO WS-COMTMT-TOLR-TYPE.

           IF WS-COMTMT-TOLR-TYPE-VALID
               MOVE MIR-COMIT-TOL-CALC-CD
                                      TO RSCOM-COMIT-TOL-CALC-CD
           ELSE
               MOVE 'NS33600055'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       7990-EDIT-COMTT-X.
           EXIT.

      *****************************************************************
      *  COMTMT-TOLR-PCNT: MUST BE NUMERIC
      *****************************************************************
       8000-EDIT-COMTP.

           IF MIR-COMIT-TOL-PCT = SPACES
020874*        MOVE RSCOM-COMIT-TOL-PCT-N
020874*                               TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-COMIT-TOL-PCT
020874         MOVE RSCOM-COMIT-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-TOL-PCT
               GO TO 8000-EDIT-COMTP-X
           END-IF.

           IF MIR-COMIT-TOL-PCT = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-COMIT-TOL-PCT
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-TOL-PCT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
018384*    MOVE 2                     TO L0280-LENGTH.
018384     MOVE 3                     TO L0280-LENGTH.
018384*    MOVE +2                    TO L0280-INPUT-SIZE.
018384     MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-COMIT-TOL-PCT     TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-COMIT-TOL-PCT
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-TOL-PCT
               MOVE L0280-OUTPUT      TO RSCOM-COMIT-TOL-PCT
           ELSE
               MOVE 'NS33600056'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8000-EDIT-COMTP-X.
           EXIT.
      *****************************************************************
      *  COMTMT-START-IND: MUST BE R, S, OR N (NONE)
      *****************************************************************
       8010-EDIT-COMSI.

           IF MIR-COMIT-STRT-CD = SPACES
               MOVE RSCOM-COMIT-STRT-CD
                                      TO MIR-COMIT-STRT-CD
               GO TO 8010-EDIT-COMSI-X
           END-IF.

           IF MIR-COMIT-STRT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-COMIT-STRT-CD
           END-IF.

           MOVE MIR-COMIT-STRT-CD     TO WS-COMTMT-START-IND.

           IF WS-COMTMT-START-IND-VALID
               MOVE MIR-COMIT-STRT-CD TO RSCOM-COMIT-STRT-CD
           ELSE
               MOVE 'NS33600057'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8010-EDIT-COMSI-X.
           EXIT.

      *****************************************************************
      *  COMTMT-TOLR-IND: MUST BE A, P, OR N (NONE)
      *****************************************************************
       8020-EDIT-COMTI.

           IF MIR-COMIT-TOL-CD = SPACES
               MOVE RSCOM-COMIT-TOL-CD               TO MIR-COMIT-TOL-CD
               GO TO 8020-EDIT-COMTI-X
           END-IF.

           IF MIR-COMIT-TOL-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-COMIT-TOL-CD
           END-IF.

           MOVE MIR-COMIT-TOL-CD      TO WS-COMTMT-TOLR-IND.

           IF WS-COMTMT-TOLR-IND-VALID
               MOVE MIR-COMIT-TOL-CD  TO RSCOM-COMIT-TOL-CD
           ELSE
               MOVE 'NS33600058'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8020-EDIT-COMTI-X.
           EXIT.

      *****************************************************************
      *  COMTMT-TOLR-AMT: MUST BE NUMERIC
      *****************************************************************
       8030-EDIT-COMTA.

           IF MIR-COMIT-TOL-AMT = SPACES
               MOVE RSCOM-COMIT-TOL-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8032-FORMAT-COMTA
                   THRU 8032-FORMAT-COMTA-X
               GO TO 8030-EDIT-COMTA-X
           END-IF.

           IF MIR-COMIT-TOL-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-COMIT-TOL-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-COMIT-TOL-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-COMIT-TOL-AMT     TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
               PERFORM  8032-FORMAT-COMTA
                   THRU 8032-FORMAT-COMTA-X
               MOVE L0280-OUTPUT      TO RSCOM-COMIT-TOL-AMT
           ELSE
               MOVE 'NS33600059'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8030-EDIT-COMTA-X.
           EXIT.

      *****************************************************************
      *  COMTMT-TOLR-AMT: OUTPUT FORMAT Z(6)9.
      *****************************************************************
       8032-FORMAT-COMTA.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-COMIT-TOL-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-COMIT-TOL-AMT.
       8032-FORMAT-COMTA-X.
           EXIT.

      *****************************************************************
      *  INT-RATE-IND: MUST BE H, G, OR N (NONE)
      *****************************************************************
       8040-EDIT-CMIRI.

           IF MIR-COMIT-INT-RT-CD = SPACES
               MOVE RSCOM-COMIT-INT-RT-CD
                                      TO MIR-COMIT-INT-RT-CD
               GO TO 8040-EDIT-CMIRI-X
           END-IF.

           IF MIR-COMIT-INT-RT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-COMIT-INT-RT-CD
           END-IF.

           MOVE MIR-COMIT-INT-RT-CD   TO WS-INT-RATE-IND.

           IF WS-INT-RATE-IND-VALID
               MOVE MIR-COMIT-INT-RT-CD
                                      TO RSCOM-COMIT-INT-RT-CD
           ELSE
               MOVE 'NS33600060'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8040-EDIT-CMIRI-X.
           EXIT.

      ****************************************************************
      *  # DAYS TO ROLLOVER: MUST BE NUMERIC
      ****************************************************************
       8050-EDIT-RNDYS.

           IF MIR-ROLOVR-DY-DUR = SPACES
020874*        MOVE RSCOM-ROLOVR-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-ROLOVR-DY-DUR
020874         MOVE RSCOM-ROLOVR-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-DY-DUR
               GO TO 8050-EDIT-RNDYS-X
           END-IF.

           IF MIR-ROLOVR-DY-DUR = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-ROLOVR-DY-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-DY-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-ROLOVR-DY-DUR     TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874*        MOVE WS-N-999          TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-ROLOVR-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-DY-DUR
               MOVE L0280-OUTPUT      TO RSCOM-ROLOVR-DY-DUR
           ELSE
      *MSG:    # OF DAYS TO ROLL MUST BE NUMERIC
               MOVE 'NS33600119'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8050-EDIT-RNDYS-X.
           EXIT.

      *****************************************************************
      *  ROLLOVER TOLERANCE TYPE IND: MUST BE E, S, B, OR N (NONE)
      *****************************************************************
       8060-EDIT-RTOLT.

           IF MIR-ROLOVR-TOL-CALC-CD = SPACES
               MOVE RSCOM-ROLOVR-TOL-CALC-CD
                                      TO MIR-ROLOVR-TOL-CALC-CD
               GO TO 8060-EDIT-RTOLT-X
           END-IF.
      *
      * USE COMMITMENT TOLERANCE TYPE AS THEY HAVE THE SAME VALID VALUES
      *
           MOVE MIR-ROLOVR-TOL-CALC-CD   TO WS-COMTMT-TOLR-TYPE.
           IF WS-COMTMT-TOLR-TYPE-VALID
               MOVE MIR-ROLOVR-TOL-CALC-CD
                                      TO RSCOM-ROLOVR-TOL-CALC-CD
           ELSE
               MOVE 'NS33600055'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8060-EDIT-RTOLT-X.
           EXIT.

      *****************************************************************
      *  ROLLOVER TOLERANCE PCNT: MUST BE NUMERIC
      *****************************************************************
       8070-EDIT-RTOLP.

           IF MIR-ROLOVR-TOL-PCT = SPACES
020874*        MOVE RSCOM-ROLOVR-TOL-PCT
020874*                               TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-ROLOVR-TOL-PCT
020874         MOVE RSCOM-ROLOVR-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-TOL-PCT
               GO TO 8070-EDIT-RTOLP-X
           END-IF.

           IF MIR-ROLOVR-TOL-PCT = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-N-99
020874*        MOVE WS-N-99           TO WS-PIC-Z9
020874*        MOVE WS-PIC-ZZ9        TO MIR-ROLOVR-TOL-PCT
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-TOL-PCT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
018384*    MOVE 2                     TO L0280-LENGTH.
018384     MOVE 3                     TO L0280-LENGTH.
018384*    MOVE +2                    TO L0280-INPUT-SIZE.
018384     MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-ROLOVR-TOL-PCT    TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-99
020874*        MOVE WS-N-99           TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-ROLOVR-TOL-PCT
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-TOL-PCT
               MOVE L0280-OUTPUT      TO RSCOM-ROLOVR-TOL-PCT
           ELSE
      *MSG:    MUST BE NUMERIC
               MOVE 'NS33600056'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8070-EDIT-RTOLP-X.
           EXIT.

      *****************************************************************
      *  ROLLOVER INTEREST RATE INDICATOR: MUST BE H, G, OR N (NONE)
      *****************************************************************
       8080-EDIT-RIRTI.

           IF MIR-ROLOVR-INT-RT-CD = SPACES
               MOVE RSCOM-ROLOVR-INT-RT-CD
                                      TO MIR-ROLOVR-INT-RT-CD
               GO TO 8080-EDIT-RIRTI-X
           END-IF.

           IF MIR-ROLOVR-INT-RT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-ROLOVR-INT-RT-CD
           END-IF.
      *
      *  USE COMMITMENT INTEREST RATE INDICATOR AS THEY HAVE THE SAME
      *  VALID VALUES
      *
           MOVE MIR-ROLOVR-INT-RT-CD  TO WS-INT-RATE-IND.
           IF WS-INT-RATE-IND-VALID
               MOVE MIR-ROLOVR-INT-RT-CD
                                      TO RSCOM-ROLOVR-INT-RT-CD
           ELSE
               MOVE 'NS33600060'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8080-EDIT-RIRTI-X.
           EXIT.

      *****************************************************************
      *  ROLLOVER TOLERANCE ORDER: MIST BE A, P, OR N (NONE)
      *****************************************************************
       8090-EDIT-RTOLO.

           IF MIR-ROLOVR-TOL-CD = SPACES
               MOVE RSCOM-ROLOVR-TOL-CD
                                      TO MIR-ROLOVR-TOL-CD
               GO TO 8090-EDIT-RTOLO-X
           END-IF.
      *
      *  USE COMMITTMENT LETTER VALUES AS THEY ARE THE SAME
      *
           MOVE MIR-ROLOVR-TOL-CD     TO WS-COMTMT-TOLR-IND.

           IF WS-COMTMT-TOLR-IND-VALID
               MOVE MIR-ROLOVR-TOL-CD TO RSCOM-ROLOVR-TOL-CD
           ELSE
               MOVE 'NS33600058'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8090-EDIT-RTOLO-X.
           EXIT.

      *****************************************************************
      *  ROLLOVER TOLERANCE FLAT AMT: MUST BE NUMERIC
      *****************************************************************
       8100-EDIT-RTOLF.

           IF MIR-ROLOVR-TOL-AMT = SPACES
               MOVE RSCOM-ROLOVR-TOL-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8102-FORMAT-RTOLF
                   THRU 8102-FORMAT-RTOLF-X
               GO TO 8100-EDIT-RTOLF-X
           END-IF.

           IF MIR-ROLOVR-TOL-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-ROLOVR-TOL-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-ROLOVR-TOL-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-ROLOVR-TOL-AMT    TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
               PERFORM  8102-FORMAT-RTOLF
                   THRU 8102-FORMAT-RTOLF-X
               MOVE L0280-OUTPUT      TO RSCOM-ROLOVR-TOL-AMT
           ELSE
               MOVE 'NS33600059'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8100-EDIT-RTOLF-X.
           EXIT.

      *****************************************************************
      *  COMTMT-TOLR-AMT: OUTPUT FORMAT Z(6)9.
      *****************************************************************
       8102-FORMAT-RTOLF.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-ROLOVR-TOL-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-ROLOVR-TOL-AMT.
       8102-FORMAT-RTOLF-X.
           EXIT.

016395*****************************************************************
016395*  CREDIT CARD REDRAW OPTION CODE - VALID CODE IS '1' '3'
016395*****************************************************************
016395 8120-EDIT-CRC-REDRW-OPT-CD.
016395
016395     IF  MIR-CRC-REDRW-OPT-CD                    =  SPACES
016395         MOVE RSCOM-CRC-REDRW-OPT-CD
016395                                TO MIR-CRC-REDRW-OPT-CD
016395         GO TO 8120-EDIT-CRC-REDRW-OPT-CD-X
016395     END-IF.
016395
016395     IF  MIR-CRC-REDRW-OPT-CD  =  EBLCH-BLANK-FIELD-CHAR
016395         MOVE SPACES            TO MIR-CRC-REDRW-OPT-CD
016395     END-IF.
016395
016395     MOVE MIR-CRC-REDRW-OPT-CD  TO WS-CRC-REDRW-OPT-CD.
016395
016395     IF  WS-CRC-REDRW-OPT-CD-VALID
016395         MOVE MIR-CRC-REDRW-OPT-CD
016395                                TO RSCOM-CRC-REDRW-OPT-CD
016395     ELSE
016395         MOVE '1'               TO WS-DATA-EDITS
016395*MSG: CREDIT CARD REDRAW OPTION CODE MUST BE '1' OR '3'
016395         MOVE 'NS33600139'      TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395     END-IF.
016395
016395 8120-EDIT-CRC-REDRW-OPT-CD-X.
016395     EXIT.

016395*****************************************************************
016395*  CREDIT CARD REDRAW DUR MONTHS/DAYS
016395*****************************************************************
016395 8130-EDIT-CRC-REDRW-DUR.
016395
016395     IF  MIR-CRC-REDRW-DUR   =  SPACES
016395         MOVE RSCOM-CRC-REDRW-DUR
016395                                TO MIR-CRC-REDRW-DUR
016395         GO TO 8130-EDIT-CRC-REDRW-DUR-X
016395     END-IF.
016395
016395     IF  MIR-CRC-REDRW-DUR   =  EBLCH-BLANK-FIELD-CHAR
016395         MOVE ZEROS             TO MIR-CRC-REDRW-DUR
016395     END-IF.
016395
016395     MOVE MIR-CRC-REDRW-DUR     TO WS-CRC-REDRW-DUR
016395
016395     IF  WS-CRC-REDRW-DUR-MO NUMERIC
016395     AND WS-CRC-REDRW-DUR-DY NUMERIC
016395         MOVE MIR-CRC-REDRW-DUR TO RSCOM-CRC-REDRW-DUR
016395     ELSE
016395         MOVE '1'               TO WS-DATA-EDITS
016395*MSG: CREDIT CARD REDRAW DUR MUST BE NUMERIC
016395         MOVE 'NS33600140'      TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395     END-IF.
016395
016395 8130-EDIT-CRC-REDRW-DUR-X.
016395     EXIT.

016395*****************************************************************
016395*  CROSS EDIT CREDIT CARD REDRAW
016395*****************************************************************
016395 8140-CROSS-EDIT-CRC-REDRW.
016395
016395     IF  RSCOM-CRC-REDRW-OPT-CD       =  '3'
016395     AND RSCOM-CRC-REDRW-DUR          =  ZEROS
016395*MSG: FOR CREDIT CARD REDRAW OPTION 3, #MONTHS/DAYS TO REDRAW
016395*     MUST > 0000
016395         MOVE RSCOM-CRC-REDRW-OPT-CD
016395                                TO WGLOB-MSG-PARM (1)
016395         MOVE '1'               TO WS-DATA-EDITS
016395*MSG: FOR CREDIT CARD REDRAW OPTION (3), NUMBER OF MONTHS/DAYS
016395*     TO REDRAW MUST BE > 0000
016395         MOVE 'NS33600141'      TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395     END-IF.
016395
016395 8140-CROSS-EDIT-CRC-REDRW-X.
016395     EXIT.

016395*****************************************************************
016395*  CRC-FRST-DPOS-DY - MUST BE NUMERIC WITH RANGE +1 TO + 31
016395*****************************************************************
016395 8150-EDIT-CRC-FRST-DPOS-DY.
016395
016395     MOVE '0'                   TO WS-VALIDATE-CRCDEPDF.
016395
016395     IF  MIR-CRC-FRST-DPOS-DY =    SPACES
016395         MOVE RSCOM-CRC-FRST-DPOS-DY
016395                                TO WS-SAVE-CRCDEPDF
020874*        MOVE RSCOM-CRC-FRST-DPOS-DY
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-FRST-DPOS-DY
020874         MOVE RSCOM-CRC-FRST-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FRST-DPOS-DY
016395         GO TO 8150-EDIT-CRC-FRST-DPOS-DY-X
016395     END-IF.
016395
016395     IF  MIR-CRC-FRST-DPOS-DY =    EBLCH-BLANK-FIELD-CHAR
016395         MOVE 0                 TO WS-SAVE-CRCDEPDF
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-FRST-DPOS-DY
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FRST-DPOS-DY
016395     END-IF.
016395
016395     MOVE 'N'                   TO L0280-SIGN-IND.
016395     MOVE 0                     TO L0280-PRECISION.
016395     MOVE 3                     TO L0280-LENGTH.
016395     MOVE +3                    TO L0280-INPUT-SIZE.
016395     MOVE MIR-CRC-FRST-DPOS-DY  TO L0280-INPUT-DATA.
016395
016395     PERFORM  8800-NUMERIC-EDIT
016395         THRU 8800-NUMERIC-EDIT-X.
016395
016395     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016395                                   WS-CRC-DPOS-DY-RANGE
020874*        MOVE WS-N-999          TO MIR-CRC-FRST-DPOS-DY
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FRST-DPOS-DY
016395         IF  WS-CRC-FRST-DPOS-DY-VALID
016395             MOVE L0280-OUTPUT  TO WS-SAVE-CRCDEPDF
016395         ELSE
016395*MSG: FIRST CREDIT CARD DEPOSIT DAY MUST BE IN RANGE 1 -31
016395             MOVE 'NS33600142'  TO WGLOB-MSG-REF-INFO
016395             PERFORM  0260-1000-GENERATE-MESSAGE
016395                 THRU 0260-1000-GENERATE-MESSAGE-X
016395             MOVE '1'           TO WS-DATA-EDITS
016395             MOVE '1'           TO WS-VALIDATE-CRCDEPDF
016395         END-IF
016395     ELSE
016395*MSG: FIRST CREDIT CARD DEPOSIT DAY MUST BE IN RANGE 1 -31
016395         MOVE 'NS33600142'      TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395         MOVE '1'               TO WS-DATA-EDITS
016395         MOVE '1'               TO WS-VALIDATE-CRCDEPDF
016395     END-IF.
016395
016395 8150-EDIT-CRC-FRST-DPOS-DY-X.
016395     EXIT.

016395*****************************************************************
016395*  CRC-FINAL-DPOS-DY - MUST BE NUMERIC WITH RANGE +1 TO + 31
016395*****************************************************************
016395 8160-EDIT-CRC-FINAL-DPOS-DY.
016395
016395     MOVE '0'                   TO WS-VALIDATE-CRCDEPDL.
016395
016395     IF  MIR-CRC-FINAL-DPOS-DY =   SPACES
016395         MOVE RSCOM-CRC-FINAL-DPOS-DY
016395                                TO WS-SAVE-CRCDEPDL
020874*        MOVE RSCOM-CRC-FINAL-DPOS-DY
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-FINAL-DPOS-DY
020874         MOVE RSCOM-CRC-FINAL-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FINAL-DPOS-DY
016395         GO TO 8160-EDIT-CRC-FINAL-DPOS-DY-X
016395     END-IF.
016395
016395     IF  MIR-CRC-FINAL-DPOS-DY =   EBLCH-BLANK-FIELD-CHAR
016395         MOVE 0                 TO WS-SAVE-CRCDEPDL
020874*        MOVE 0                 TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-FINAL-DPOS-DY
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FINAL-DPOS-DY
016395     END-IF.
016395
016395     MOVE 'N'                   TO L0280-SIGN-IND.
016395     MOVE 0                     TO L0280-PRECISION.
016395     MOVE 3                     TO L0280-LENGTH.
016395     MOVE +3                    TO L0280-INPUT-SIZE.
016395     MOVE MIR-CRC-FINAL-DPOS-DY TO L0280-INPUT-DATA.
016395
016395     PERFORM  8800-NUMERIC-EDIT
016395         THRU 8800-NUMERIC-EDIT-X.
016395
016395     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-999
020874         MOVE L0280-OUTPUT      TO
016395                                   WS-CRC-DPOS-DY-RANGE
020874*        MOVE WS-N-999          TO MIR-CRC-FINAL-DPOS-DY
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FINAL-DPOS-DY
016395         IF  WS-CRC-FINAL-DPOS-DY-VALID
016395             MOVE L0280-OUTPUT  TO WS-SAVE-CRCDEPDL
016395         ELSE
016395*MSG: LAST DAY OF CREDIT CARD DEPOSIT DAY MUST BE IN RANGE 1 -31
016395             MOVE 'NS33600143'  TO WGLOB-MSG-REF-INFO
016395             PERFORM  0260-1000-GENERATE-MESSAGE
016395                 THRU 0260-1000-GENERATE-MESSAGE-X
016395             MOVE '1'           TO WS-DATA-EDITS
016395             MOVE '1'           TO WS-VALIDATE-CRCDEPDL
016395         END-IF
016395     ELSE
016395*MSG: LAST DAY OF CREDIT CARD DEPOSIT DAY MUST BE IN RANGE 1 -31
016395         MOVE 'NS33600143'      TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395         MOVE '1'               TO WS-DATA-EDITS
016395         MOVE '1'               TO WS-VALIDATE-CRCDEPDL
016395     END-IF.
016395
016395 8160-EDIT-CRC-FINAL-DPOS-DY-X.
016395     EXIT.

016395 8170-CROSS-EDIT-CRC-DPOS.
016395
016395     IF (WS-SAVE-CRCDEPDF < WS-SAVE-CRCDEPDL)
016395         MOVE WS-SAVE-CRCDEPDF     TO RSCOM-CRC-FRST-DPOS-DY
016395         MOVE WS-SAVE-CRCDEPDL     TO RSCOM-CRC-FINAL-DPOS-DY
016395     ELSE
016395         MOVE 'NS33600144'      TO WGLOB-MSG-REF-INFO
016395         PERFORM  0260-1000-GENERATE-MESSAGE
016395             THRU 0260-1000-GENERATE-MESSAGE-X
016395         MOVE '1'               TO WS-DATA-EDITS
016395     END-IF.
016395
016395 8170-CROSS-EDIT-CRC-DPOS-X.
016395     EXIT.

      ******************************************************************
      *  IF TYPE IS 'P', MAXIMUM AMOUNT SHOULD BE ZERO                 *
      *                        AND MAXIMUM PERCENT SHOULD BE NON-ZERO  *
      *  IF TYPE IS 'A', MAXIMUM PERCENT SHOULD BE ZERO                *
      *                        AND MAXIMUM AMOUNT SHOULD BE NON-ZERO   *
      ******************************************************************
       8190-SCREEN2-CROSS-EDITS.

           IF (RSCOM-PEND-PREM-TOL-CD = 'P'
           AND RSCOM-PEND-PREM-TOL-PCT   = 0)
           OR (RSCOM-PEND-PREM-TOL-CD = 'A'
           AND RSCOM-PEND-PREM-TOL-PCT   > 0)
               MOVE 'NS33600069'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF (RSCOM-INFC-PREM-TOL-CD = 'P'
           AND RSCOM-INFC-PREM-TOL-PCT   = 0)
           OR (RSCOM-INFC-PREM-TOL-CD = 'A'
           AND RSCOM-INFC-PREM-TOL-PCT  > 0)
               MOVE 'NS33600123'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF (RSCOM-LOAN-REPAY-TOL-CD = 'P'
           AND RSCOM-LOAN-REPAY-TOL-PCT   = 0)
           OR (RSCOM-LOAN-REPAY-TOL-CD = 'A'
           AND RSCOM-LOAN-REPAY-TOL-PCT   > 0)
               MOVE 'NS33600124'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF (RSCOM-PEND-PREM-TOL-CD = 'A'
           AND RSCOM-PEND-PREM-TOL-AMT  = 0)
           OR (RSCOM-PEND-PREM-TOL-CD = 'P'
           AND RSCOM-PEND-PREM-TOL-AMT  > 0)
               MOVE 'NS33600070'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF (RSCOM-INFC-PREM-TOL-CD = 'A'
           AND RSCOM-INFC-PREM-TOL-AMT   = 0)
           OR (RSCOM-INFC-PREM-TOL-CD = 'P'
           AND RSCOM-INFC-PREM-TOL-AMT   > 0)
               MOVE 'NS33600125'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF (RSCOM-LOAN-REPAY-TOL-CD = 'A'
           AND RSCOM-LOAN-REPAY-TOL-AMT   = 0)
           OR (RSCOM-LOAN-REPAY-TOL-CD = 'P'
           AND RSCOM-LOAN-REPAY-TOL-AMT   > 0)
               MOVE 'NS33600126'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *
      ***  IF TOLERANCE ORDER IS 'N' AND TYPE IS NOT, PRODUCE MESSAGE
      *
           IF  RSCOM-COMIT-TOL-NONE
           AND NOT RSCOM-COMIT-TOL-CALC-NONE
               MOVE RSCOM-COMIT-TOL-CALC-CD
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS33600065'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
      ***  IF TOLERANCE ORDER IS 'N' AND TYPE IS NOT, PRODUCE MESSAGE
      *
           IF  RSCOM-ROLOVR-TOL-NONE
           AND NOT RSCOM-ROLOVR-TOL-CALC-NONE
               MOVE RSCOM-ROLOVR-TOL-CALC-CD
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS33600066'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8190-SCREEN2-CROSS-EDITS-X.
           EXIT.
      /
      *****************************************************************
      *  MAX-ADB-AMT: MUST BE NUMERIC
      *****************************************************************
       8200-EDIT-MXADB.

           IF MIR-CLI-MAX-AD-AMT = SPACES
               MOVE RSCOM-CLI-MAX-AD-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8202-FORMAT-MXADB
                   THRU 8202-FORMAT-MXADB-X
               GO TO 8200-EDIT-MXADB-X
           END-IF.

           IF MIR-CLI-MAX-AD-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-CLI-MAX-AD-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-CLI-MAX-AD-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-CLI-MAX-AD-AMT    TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
               PERFORM  8202-FORMAT-MXADB
                   THRU 8202-FORMAT-MXADB-X
               MOVE L0280-OUTPUT      TO RSCOM-CLI-MAX-AD-AMT
           ELSE
               MOVE 'NS33600038'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8200-EDIT-MXADB-X.
           EXIT.
      *****************************************************************
      *  MAX-ADB-AMT: OUTPUT FORMAT Z(8)9
      *****************************************************************
       8202-FORMAT-MXADB.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CLI-MAX-AD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CLI-MAX-AD-AMT.
       8202-FORMAT-MXADB-X.
           EXIT.

      *****************************************************************
      *  CURRENT-RISK-ADB: MUST BE Y OR N
      *****************************************************************
       8210-EDIT-CRADB.

           IF MIR-TCR-INCL-AD-IND = SPACES
               MOVE RSCOM-TCR-INCL-AD-IND
                                      TO MIR-TCR-INCL-AD-IND
               GO TO 8210-EDIT-CRADB-X
           END-IF.

           IF MIR-TCR-INCL-AD-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TCR-INCL-AD-IND
           END-IF.

           MOVE MIR-TCR-INCL-AD-IND   TO WS-CURRENT-RISK-ADB

           IF WS-CURRENT-ADB-VALID
               MOVE MIR-TCR-INCL-AD-IND
                                      TO RSCOM-TCR-INCL-AD-IND
           ELSE
               MOVE 'NS33600018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8210-EDIT-CRADB-X.
           EXIT.
      *****************************************************************
      *  MAX-WP-AMT: MUST BE NUMERIC
      *****************************************************************
       8220-EDIT-MXWPA.

           IF MIR-CLI-MAXWP-AMT = SPACES
               MOVE RSCOM-CLI-MAXWP-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8222-FORMAT-MXWPA
                   THRU 8222-FORMAT-MXWPA-X
               GO TO 8220-EDIT-MXWPA-X
           END-IF.

           IF MIR-CLI-MAXWP-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-CLI-MAXWP-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-CLI-MAXWP-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-CLI-MAXWP-AMT     TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
               PERFORM  8222-FORMAT-MXWPA
                   THRU 8222-FORMAT-MXWPA-X
               MOVE L0280-OUTPUT      TO RSCOM-CLI-MAXWP-AMT
           ELSE
               MOVE 'NS33600039'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8220-EDIT-MXWPA-X.
           EXIT.

      *****************************************************************
      *  MAX-WP-AMT: OUTPUT FORMAT Z(8)9
      *****************************************************************
       8222-FORMAT-MXWPA.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CLI-MAXWP-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CLI-MAXWP-AMT.
       8222-FORMAT-MXWPA-X.
           EXIT.

      *****************************************************************
      *  MAX-SUM-INS-DISC: MUST BE NUMERIC
      *****************************************************************
       8230-EDIT-MDISC.

           IF MIR-TOT-INS-DSCREP-AMT = SPACES
               MOVE RSCOM-TOT-INS-DSCREP-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8232-FORMAT-MDISC
                   THRU 8232-FORMAT-MDISC-X
               GO TO 8230-EDIT-MDISC-X
           END-IF.

           IF MIR-TOT-INS-DSCREP-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-TOT-INS-DSCREP-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-TOT-INS-DSCREP-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-TOT-INS-DSCREP-AMT              TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
               PERFORM  8232-FORMAT-MDISC
                   THRU 8232-FORMAT-MDISC-X
               MOVE L0280-OUTPUT      TO RSCOM-TOT-INS-DSCREP-AMT
           ELSE
               MOVE 'NS33600047'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8230-EDIT-MDISC-X.
           EXIT.

      *****************************************************************
      *  TOT-INS-DSCREP-AMT : OUTPUT FORMAT Z(8)9
      *****************************************************************
       8232-FORMAT-MDISC.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TOT-INS-DSCREP-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-TOT-INS-DSCREP-AMT.
       8232-FORMAT-MDISC-X.
           EXIT.

      *****************************************************************
      *  MAX-WP-PREM: MUST BE NUMERIC
      *****************************************************************
       8240-EDIT-MXWPP.

           IF MIR-CLI-MAXWP-PREM-AMT = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-CLI-MAXWP-PREM-AMT
020874*                                     * 100
020874         MOVE RSCOM-CLI-MAXWP-PREM-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  8242-FORMAT-MXWPP
                   THRU 8242-FORMAT-MXWPP-X
               GO TO 8240-EDIT-MXWPP-X
           END-IF.

           IF MIR-CLI-MAXWP-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-CLI-MAXWP-PREM-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-CLI-MAXWP-PREM-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
                                  - 1.
           MOVE MIR-CLI-MAXWP-PREM-AMT              TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
               PERFORM  8242-FORMAT-MXWPP
                   THRU 8242-FORMAT-MXWPP-X
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RSCOM-CLI-MAXWP-PREM-AMT
           ELSE
               MOVE 'NS33600040'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8240-EDIT-MXWPP-X.
           EXIT.

      *****************************************************************
      *  MAX-WP-PREM: OUTPUT FORMAT Z(6)9.99
      *****************************************************************
       8242-FORMAT-MXWPP.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CLI-MAXWP-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CLI-MAXWP-PREM-AMT.
       8242-FORMAT-MXWPP-X.
           EXIT.

      /
      *****************************************************************
      *  MAX MONTHS AND DAYS FOR CHANGE
      *****************************************************************
       8250-EDIT-MAXCH.

           IF MIR-UWG-CHNG-MO-DUR = SPACES
               MOVE RSCOM-UWG-CHNG-MO-DUR
                                      TO MIR-UWG-CHNG-MO-DUR
           END-IF.

           IF MIR-UWG-CHNG-DY-DUR = SPACES
               MOVE RSCOM-UWG-CHNG-DY-DUR
                                      TO MIR-UWG-CHNG-DY-DUR
           END-IF.

           IF MIR-UWG-CHNG-MO-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE '00'              TO MIR-UWG-CHNG-MO-DUR
           END-IF.

           IF MIR-UWG-CHNG-DY-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE '00'              TO MIR-UWG-CHNG-DY-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-UWG-CHNG-MO-DUR   TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-N-99-1
020874*        MOVE WS-N-99-1         TO MIR-UWG-CHNG-MO-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-UWG-CHNG-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-UWG-CHNG-MO-DUR
               MOVE WS-N-99-1         TO RSCOM-UWG-CHNG-MO-DUR
           ELSE
               MOVE 'NS33600093'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-UWG-CHNG-DY-DUR   TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-N-99-1
020874*        MOVE WS-N-99-1         TO MIR-UWG-CHNG-DY-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-UWG-CHNG-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-UWG-CHNG-DY-DUR
               MOVE WS-N-99-1         TO RSCOM-UWG-CHNG-DY-DUR
           ELSE
               MOVE 'NS33600093'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8250-EDIT-MAXCH-X.
           EXIT.
      *****************************************************************
      *  MAX-UW-AMT: MUST BE NUMERIC
      *****************************************************************
       8260-EDIT-MAXUW.

           IF MIR-MAX-UWG-AMT = SPACES
020874*        MOVE RSCOM-MAX-UWG-AMT TO L0290-INPUT-NUMBER
020874         MOVE RSCOM-MAX-UWG-AMT TO L0290-INPUT-V00
               PERFORM  8262-FORMAT-MAXUW
                   THRU 8262-FORMAT-MAXUW-X
               GO TO 8260-EDIT-MAXUW-X
           END-IF.

           IF MIR-MAX-UWG-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-MAX-UWG-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-MAX-UWG-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-MAX-UWG-AMT       TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
               PERFORM  8262-FORMAT-MAXUW
                   THRU 8262-FORMAT-MAXUW-X
               MOVE L0280-OUTPUT      TO RSCOM-MAX-UWG-AMT
           ELSE
               MOVE 'NS33600061'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8260-EDIT-MAXUW-X.
           EXIT.

      *****************************************************************
      *  MAX-UW-AMT: OUTPUT FORMAT Z(8)9
      *****************************************************************
       8262-FORMAT-MAXUW.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-MAX-UWG-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-MAX-UWG-AMT.
       8262-FORMAT-MAXUW-X.
           EXIT.

      *****************************************************************
      *  MAX ALCOHOL CONSUMPTION MUST BE VALID NUMERIC
      *****************************************************************
       8270-EDIT-MAXAL.

           IF MIR-MAX-ALCHL-QTY = SPACES
               MOVE RSCOM-MAX-ALCHL-QTY
                                      TO WS-PIC-ZZZ9
               MOVE WS-PIC-ZZZ9       TO MIR-MAX-ALCHL-QTY
               GO TO 8270-EDIT-MAXAL-X
           END-IF.

           IF MIR-MAX-ALCHL-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE 0                 TO WS-PIC-ZZZ9
               MOVE WS-PIC-ZZZ9       TO MIR-MAX-ALCHL-QTY
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-LENGTH.
           MOVE +4                    TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-ALCHL-QTY     TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-PIC-ZZZ9
               MOVE WS-PIC-ZZZ9       TO MIR-MAX-ALCHL-QTY
               MOVE L0280-OUTPUT      TO RSCOM-MAX-ALCHL-QTY
           ELSE
               MOVE 'NS33600064'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8270-EDIT-MAXAL-X.
           EXIT.
      *****************************************************************
      *  MIB-COMPANY-SYMBOL
      *****************************************************************
       8280-EDIT-MIBCS.

           IF MIR-MIB-CO-SYMBL-CD = SPACES
               MOVE RSCOM-MIB-CO-SYMBL-CD
                                      TO MIR-MIB-CO-SYMBL-CD
               GO TO 8280-EDIT-MIBCS-X
           END-IF.

           IF MIR-MIB-CO-SYMBL-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-MIB-CO-SYMBL-CD
           END-IF.

           MOVE MIR-MIB-CO-SYMBL-CD   TO RSCOM-MIB-CO-SYMBL-CD.

       8280-EDIT-MIBCS-X.
           EXIT.
      *****************************************************************
      *  MIB-DESTINATION-CODE
      *****************************************************************
       8290-EDIT-MIBDC.

           IF MIR-MIB-CO-DEST-CD = SPACES
               MOVE RSCOM-MIB-CO-DEST-CD
                                      TO MIR-MIB-CO-DEST-CD
               GO TO 8290-EDIT-MIBDC-X
           END-IF.

           IF MIR-MIB-CO-DEST-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-MIB-CO-DEST-CD
           END-IF.

           MOVE MIR-MIB-CO-DEST-CD    TO RSCOM-MIB-CO-DEST-CD.

       8290-EDIT-MIBDC-X.
           EXIT.

      *****************************************************************
      *  MAX-CHILD-AGE: MUST BE NUMERIC IN RANGE 1 TO 99
      *****************************************************************
       8300-EDIT-MCHAG.

           IF MIR-MAX-CHILD-AGE = SPACES
               MOVE RSCOM-MAX-CHILD-AGE
                                      TO WS-PIC-Z9
               MOVE WS-PIC-Z9         TO MIR-MAX-CHILD-AGE
               GO TO 8300-EDIT-MCHAG-X
           END-IF.

           IF MIR-MAX-CHILD-AGE = EBLCH-BLANK-FIELD-CHAR
               MOVE 0                 TO WS-PIC-Z9
               MOVE WS-PIC-Z9         TO MIR-MAX-CHILD-AGE
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-CHILD-AGE     TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-PIC-Z9
                                        WS-TEST-RANGE
               MOVE WS-PIC-Z9         TO MIR-MAX-CHILD-AGE
               IF WS-MCHAG-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-MAX-CHILD-AGE
               ELSE
                   MOVE 'NS33600006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600048'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8300-EDIT-MCHAG-X.
           EXIT.
      *****************************************************************
      *  YEARS-CURR-ADDR: MUST BE NUMERIC IN RANGE 0 TO 99
      *****************************************************************
       8310-EDIT-YRCAL.

           IF MIR-CRNT-ADDR-YR-DUR = SPACES
020874*        MOVE RSCOM-CRNT-ADDR-YR-DUR
020874*                               TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-CRNT-ADDR-YR-DUR
020874         MOVE RSCOM-CRNT-ADDR-YR-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRNT-ADDR-YR-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRNT-ADDR-YR-DUR
               GO TO 8310-EDIT-YRCAL-X
           END-IF.

           IF MIR-CRNT-ADDR-YR-DUR = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-CRNT-ADDR-YR-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRNT-ADDR-YR-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRNT-ADDR-YR-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-CRNT-ADDR-YR-DUR  TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-Z9
020874         MOVE L0280-OUTPUT      TO
                                        WS-TEST-RANGE
020874*        MOVE WS-PIC-Z9         TO MIR-CRNT-ADDR-YR-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRNT-ADDR-YR-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRNT-ADDR-YR-DUR
               IF WS-YRCAL-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-CRNT-ADDR-YR-DUR
               ELSE
                   MOVE 'NS33600024'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600049'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8310-EDIT-YRCAL-X.
           EXIT.
      *****************************************************************
      *  AASI-COMPANY-IND:    MUST BE A OR C OR G
      *****************************************************************
016440*8320-EDIT-AGCOP.

016440*    IF MIR-TCR-CALC-MTHD-CD = SPACES
016440*        MOVE RSCOM-TCR-CALC-MTHD-CD
016440*                               TO MIR-TCR-CALC-MTHD-CD
016440*        GO TO 8320-EDIT-AGCOP-X
016440*    END-IF.

016440*    IF MIR-TCR-CALC-MTHD-CD = EBLCH-BLANK-FIELD-CHAR
016440*        MOVE SPACES            TO MIR-TCR-CALC-MTHD-CD
016440*    END-IF.

016440*    MOVE MIR-TCR-CALC-MTHD-CD  TO WS-AASI-COMPANY-IND.
016440*    IF WS-AGCOP-IND-VALID
016440*        MOVE MIR-TCR-CALC-MTHD-CD
016440*                               TO RSCOM-TCR-CALC-MTHD-CD
016440*    ELSE
016440*        MOVE 'NS33600003'      TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        MOVE '1'               TO WS-DATA-EDITS
016440*    END-IF.

016440*8320-EDIT-AGCOP-X.
016440*    EXIT.

      *****************************************************************
      *  AASI-WITHIN-MTH: MUST BE NUMERIC IN RANGE 1 TO 99
      *****************************************************************
       8330-EDIT-AGMTH.

           IF MIR-TCR-INFC-MO-DUR = SPACES
020874*        MOVE RSCOM-TCR-INFC-MO-DUR
020874*                               TO WS-N-99
020874*        MOVE WS-N-99           TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-TCR-INFC-MO-DUR
020874         MOVE RSCOM-TCR-INFC-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-TCR-INFC-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-TCR-INFC-MO-DUR
               GO TO 8330-EDIT-AGMTH-X
           END-IF.

           IF MIR-TCR-INFC-MO-DUR = EBLCH-BLANK-FIELD-CHAR
020874*        MOVE 0                 TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-TCR-INFC-MO-DUR
020874         MOVE ZERO              TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-TCR-INFC-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-TCR-INFC-MO-DUR
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
023901*    MOVE 2                     TO L0280-LENGTH.
023901*    MOVE +2                    TO L0280-INPUT-SIZE.
023901     MOVE 3                     TO L0280-LENGTH.
023901     MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-TCR-INFC-MO-DUR   TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-N-99
020874         MOVE L0280-OUTPUT      TO
                                        WS-TEST-RANGE
020874*        MOVE WS-N-99           TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-TCR-INFC-MO-DUR
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-TCR-INFC-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-TCR-INFC-MO-DUR
               IF WS-AGMTH-VALID
                   MOVE L0280-OUTPUT  TO RSCOM-TCR-INFC-MO-DUR
               ELSE
                   MOVE 'NS33600004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           ELSE
               MOVE 'NS33600030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8330-EDIT-AGMTH-X.
           EXIT.

      *****************************************************************
      *  AASI-BASE-DT:     MUST BE A OR P
      *****************************************************************
       8340-EDIT-AGSUM.

           IF MIR-TCR-BASE-DT-CD = SPACES
               MOVE RSCOM-TCR-BASE-DT-CD
                                      TO MIR-TCR-BASE-DT-CD
               GO TO 8340-EDIT-AGSUM-X
           END-IF.

           IF MIR-TCR-BASE-DT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-TCR-BASE-DT-CD
           END-IF.

           MOVE MIR-TCR-BASE-DT-CD    TO WS-AASI-BASE-DT.
           IF WS-BASE-DT-VALID
               MOVE MIR-TCR-BASE-DT-CD           TO RSCOM-TCR-BASE-DT-CD
           ELSE
               MOVE 'NS33600005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8340-EDIT-AGSUM-X.
           EXIT.

      *****************************************************************
      *  HW-MIN-RATING: MUST BE NUMERIC IN RANGE 0 TO 999
      *  HW-MAX-RATING: MUST BE NUMERIC IN RANGE 0 TO 999
      *****************************************************************
       8350-EDIT-HWMNR.

           MOVE '0'                   TO WS-VALIDATE-HWMNR.
           IF MIR-HWTB-MIN-RAT-QTY = SPACES
               MOVE RSCOM-HWTB-MIN-RAT-QTY
                                      TO WS-PIC-ZZ9
                                                WS-SAVE-HWMNR
               MOVE WS-PIC-ZZ9        TO MIR-HWTB-MIN-RAT-QTY
               GO TO 8350-EDIT-HWMNR-X
           END-IF.

           IF MIR-HWTB-MIN-RAT-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE 0                 TO WS-PIC-ZZ9
               MOVE +0                TO WS-SAVE-HWMNR
               MOVE WS-PIC-ZZ9        TO MIR-HWTB-MIN-RAT-QTY
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-HWTB-MIN-RAT-QTY  TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-N-999
                                        WS-TEST-RANGE
               MOVE WS-N-999          TO WS-PIC-ZZ9
               MOVE WS-PIC-ZZ9        TO MIR-HWTB-MIN-RAT-QTY
               IF WS-HWMNR-VALID
                   MOVE L0280-OUTPUT  TO WS-SAVE-HWMNR
               ELSE
                   MOVE 'NS33600007'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
                                   WS-VALIDATE-HWMNR
               END-IF
           ELSE
               MOVE 'NS33600032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
                                        WS-VALIDATE-HWMNR
           END-IF.

       8350-EDIT-HWMNR-X.
           EXIT.

       8360-EDIT-HWMXR.

           MOVE '0'                   TO WS-VALIDATE-HWMXR.
           IF MIR-HWTB-MAX-RAT-QTY = SPACES
               MOVE RSCOM-HWTB-MAX-RAT-QTY
                                      TO WS-PIC-ZZ9
                                           WS-SAVE-HWMXR
               MOVE WS-PIC-ZZ9        TO MIR-HWTB-MAX-RAT-QTY
               GO TO 8360-EDIT-HWMXR-X
           END-IF.

           IF MIR-HWTB-MAX-RAT-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE 0                 TO WS-PIC-ZZ9
               MOVE +0                TO WS-SAVE-HWMXR
               MOVE WS-PIC-ZZ9        TO MIR-HWTB-MAX-RAT-QTY
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-HWTB-MAX-RAT-QTY  TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-N-999
                                        WS-TEST-RANGE
               MOVE WS-N-999          TO WS-PIC-ZZ9
               MOVE WS-PIC-ZZ9        TO MIR-HWTB-MAX-RAT-QTY
               IF WS-HWMXR-VALID
                   MOVE L0280-OUTPUT  TO WS-SAVE-HWMXR
               ELSE
                   MOVE 'NS33600008'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE '1'       TO WS-DATA-EDITS
                                       WS-VALIDATE-HWMXR
               END-IF
           ELSE
               MOVE 'NS33600033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
                                         WS-VALIDATE-HWMXR
           END-IF.

       8360-EDIT-HWMXR-X.
           EXIT.

       8370-RATING-CROSS-EDIT.

           IF (WS-SAVE-HWMNR GREATER WS-SAVE-HWMXR)
               MOVE 'NS33600009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           ELSE
               MOVE WS-SAVE-HWMNR     TO RSCOM-HWTB-MIN-RAT-QTY
               MOVE WS-SAVE-HWMXR     TO RSCOM-HWTB-MAX-RAT-QTY
           END-IF.

       8370-RATING-CROSS-EDIT-X.
           EXIT.
      /
016440*8500-EDIT-HCOMP.

016440*    IF MIR-DI-CCAS-INCL-CD = SPACES
016440*        MOVE RSCOM-DI-CCAS-INCL-CD
016440*                               TO MIR-DI-CCAS-INCL-CD
016440*        GO TO 8500-EDIT-HCOMP-X
016440*    END-IF.

016440*    IF MIR-DI-CCAS-INCL-CD = EBLCH-BLANK-FIELD-CHAR
016440*        MOVE 'A'               TO RSCOM-DI-CCAS-INCL-CD
016440*        MOVE RSCOM-DI-CCAS-INCL-CD
016440*                               TO MIR-DI-CCAS-INCL-CD
016440*        GO TO 8500-EDIT-HCOMP-X
016440*    END-IF.

016440*    MOVE MIR-DI-CCAS-INCL-CD   TO WS-AASI-COMPANY-IND.
016440*    IF NOT WS-AGCOP-IND-VALID
016440*MSG:     HEALTH INCLUDE COMPANIES IND MUST BE A, G OR C
016440*         MOVE 'NS33600073'     TO WGLOB-MSG-REF-INFO
016440*         PERFORM  0260-1000-GENERATE-MESSAGE
016440*             THRU 0260-1000-GENERATE-MESSAGE-X
016440*         MOVE '1'              TO WS-DATA-EDITS
016440*         GO TO 8500-EDIT-HCOMP-X
016440*     END-IF.

016440*    MOVE MIR-DI-CCAS-INCL-CD   TO RSCOM-DI-CCAS-INCL-CD.

016440*8500-EDIT-HCOMP-X.
016440*    EXIT.


       8510-BLANK-OOE-GROUP.

           IF MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB)
                                      = EBLCH-BLANK-FIELD-GROUP
               MOVE EBLCH-BLANK-FIELD-CHAR
                                    TO MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB)
               MOVE EBLCH-BLANK-FIELD-CHAR
                                      TO MIR-OOE-3-MAX-AMT-T (WS-SUB)
               MOVE EBLCH-BLANK-FIELD-CHAR
                                    TO MIR-OOE-3-MAX-CCAS-AMT-T (WS-SUB)
           END-IF.

       8510-BLANK-OOE-GROUP-X.
           EXIT.


       8520-EDIT-OOEOC.

           IF MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB) = SPACES
               MOVE RSCOM-OOE-OCCP-CLAS-CD (WS-SUB)
                                    TO MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB)
               GO TO 8520-EDIT-OOEOC-X
           END-IF.

           IF MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES          TO MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB)
               MOVE SPACES            TO RSCOM-OOE-OCCP-CLAS-CD (WS-SUB)
               GO TO 8520-EDIT-OOEOC-X
           END-IF.

           MOVE MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB)
                                      TO WEDIT-ETBL-VALU-ID.
           PERFORM  STB4-1000-EDIT-SUB-TABLE-4
               THRU STB4-1000-EDIT-SUB-TABLE-4-X.
           IF NOT WEDIT-IO-OK
      *MSG:    OCC CLASS MUST BE IN EDIT - TYPE STB4
               MOVE 'NS33600074'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
               GO TO 8520-EDIT-OOEOC-X
           END-IF.

           MOVE MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB)
                                     TO RSCOM-OOE-OCCP-CLAS-CD (WS-SUB).

       8520-EDIT-OOEOC-X.
           EXIT.


       8530-EDIT-OOEMX.

           IF MIR-OOE-3-MAX-AMT-T (WS-SUB) = SPACES
               MOVE RSCOM-OOE-MAX-AMT (WS-SUB)
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8532-FORMAT-OOEMX
                   THRU 8532-FORMAT-OOEMX-X
               GO TO 8530-EDIT-OOEMX-X
           END-IF.

           IF MIR-OOE-3-MAX-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO RSCOM-OOE-MAX-AMT (WS-SUB)
               MOVE ZERO              TO MIR-OOE-3-MAX-AMT-T (WS-SUB)
               GO TO 8530-EDIT-OOEMX-X
           END-IF.

           MOVE MIR-OOE-3-MAX-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-OOE-3-MAX-AMT-T (WS-SUB)
                                      TO L0280-INPUT-SIZE
                                                  L0280-LENGTH.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
               PERFORM  8532-FORMAT-OOEMX
                   THRU 8532-FORMAT-OOEMX-X
               MOVE L0280-OUTPUT      TO RSCOM-OOE-MAX-AMT (WS-SUB)
           ELSE
      *MSG:    OOE MAX MUST BE NUMERIC IN FORMAT 99999
               MOVE 'NS33600075'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8530-EDIT-OOEMX-X.
           EXIT.

      *****************************************************************
      *  OOE-MAX-AMT: OUTPUT FORMAT 99999
      *****************************************************************
       8532-FORMAT-OOEMX.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-OOE-3-MAX-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-OOE-3-MAX-AMT-T (WS-SUB).
       8532-FORMAT-OOEMX-X.
           EXIT.

       8540-EDIT-OOECC.

           IF MIR-OOE-3-MAX-CCAS-AMT-T (WS-SUB) = SPACES
               MOVE RSCOM-OOE-MAX-CCAS-AMT (WS-SUB)
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8542-FORMAT-OOECC
                   THRU 8542-FORMAT-OOECC-X
               GO TO 8540-EDIT-OOECC-X
           END-IF.

           IF MIR-OOE-3-MAX-CCAS-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO RSCOM-OOE-MAX-CCAS-AMT (WS-SUB)
               MOVE ZERO            TO MIR-OOE-3-MAX-CCAS-AMT-T (WS-SUB)
               GO TO 8540-EDIT-OOECC-X
           END-IF.

           MOVE MIR-OOE-3-MAX-CCAS-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-OOE-3-MAX-CCAS-AMT-T (WS-SUB)
                                      TO L0280-INPUT-SIZE
                                                  L0280-LENGTH.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
               PERFORM  8542-FORMAT-OOECC
                   THRU 8542-FORMAT-OOECC-X
               MOVE L0280-OUTPUT      TO RSCOM-OOE-MAX-CCAS-AMT (WS-SUB)
           ELSE
      *MSG:    OOE CC MAX MUST BE NUMERIC IN FORMAT 99999
               MOVE 'NS33600076'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8540-EDIT-OOECC-X.
           EXIT.

      *****************************************************************
      *  OOE-MAX-CCAS-AMT: OUTPUT FORMAT 99999
      *****************************************************************
       8542-FORMAT-OOECC.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-OOE-3-MAX-CCAS-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA  TO MIR-OOE-3-MAX-CCAS-AMT-T (WS-SUB).
       8542-FORMAT-OOECC-X.
           EXIT.

       8550-XEDIT-OOE-ENTRY.

           IF RSCOM-OOE-OCCP-CLAS-CD (WS-SUB) = SPACES
               IF RSCOM-OOE-MAX-AMT (WS-SUB) NOT = ZEROS
               OR RSCOM-OOE-MAX-CCAS-AMT (WS-SUB) NOT = ZEROS
      *MSG:        OOE OCC CLASS IS BLANK, AMOUNTS SHOULD BE ZERO
                   MOVE 'NS33600077'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               IF RSCOM-OOE-MAX-AMT (WS-SUB) = ZEROS
               OR RSCOM-OOE-MAX-CCAS-AMT (WS-SUB) = ZEROS
      *MSG:        OOE OCC CLASS IS NON-BLANK, AMTS SHOULD NOT BE ZERO
                   MOVE 'NS33600078'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-DATA-EDITS
               END-IF
           END-IF.

           IF RSCOM-OOE-MAX-AMT (WS-SUB) <
              RSCOM-OOE-MAX-CCAS-AMT (WS-SUB)
      *MSG:    (I) ISSUE LIMIT SHOULD NOT BE LESS THAN CC MAX AMOUNT
               MOVE 'NS33600091'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8550-XEDIT-OOE-ENTRY-X.
           EXIT.


       8560-CHECK-FOR-DUPLICATE.

           IF RSCOM-OOE-OCCP-CLAS-CD (WS-SUB) = SPACE
               GO TO 8560-CHECK-FOR-DUPLICATE-X
           END-IF.

           ADD +1, WS-SUB GIVING WS-SUB-2.

           PERFORM  8565-CHECK-REST-FOR-DUP
               THRU 8565-CHECK-REST-FOR-DUP-X
               VARYING WS-SUB-2 FROM WS-SUB-2 BY 1
               UNTIL   WS-SUB-2 > WSCOM-MAX-OOE-ENTRIES.

       8560-CHECK-FOR-DUPLICATE-X.
           EXIT.


       8565-CHECK-REST-FOR-DUP.

           IF RSCOM-OOE-OCCP-CLAS-CD (WS-SUB) =
               RSCOM-OOE-OCCP-CLAS-CD (WS-SUB-2)
               MOVE 'Y'               TO WS-DUP-FOUND-SW
           END-IF.

       8565-CHECK-REST-FOR-DUP-X.
           EXIT.


       8570-EDIT-MXADD.

           IF MIR-MAX-ADND-AMT = SPACES
020874*        MOVE RSCOM-MAX-ADND-AMT             TO L0290-INPUT-NUMBER
020874         MOVE RSCOM-MAX-ADND-AMT             TO L0290-INPUT-V00
               PERFORM  8572-FORMAT-MXADD
                   THRU 8572-FORMAT-MXADD-X
               GO TO 8570-EDIT-MXADD-X
           END-IF.

           IF MIR-MAX-ADND-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO MIR-MAX-ADND-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-MAX-ADND-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-MAX-ADND-AMT      TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
               PERFORM  8572-FORMAT-MXADD
                   THRU 8572-FORMAT-MXADD-X
               MOVE L0280-OUTPUT      TO RSCOM-MAX-ADND-AMT
           ELSE
      *MSG:    MAX ADD AMOUNT MUST BE NUMERIC - FORMAT 999999999
               MOVE 'NS33600079'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8570-EDIT-MXADD-X.
           EXIT.

      *****************************************************************
      *  MAX-ADND-AMT: OUTPUT FORMAT 999999999
      *****************************************************************
       8572-FORMAT-MXADD.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-MAX-ADND-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-MAX-ADND-AMT.
       8572-FORMAT-MXADD-X.
           EXIT.


       8580-EDIT-UERAT.

           IF MIR-MAX-INCM-RATIO-PCT = SPACES
020874*        MOVE RSCOM-MAX-INCM-RATIO-PCT
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-MAX-INCM-RATIO-PCT
020874         MOVE RSCOM-MAX-INCM-RATIO-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-INCM-RATIO-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-INCM-RATIO-PCT
               GO TO 8580-EDIT-UERAT-X
           END-IF.

           IF MIR-MAX-INCM-RATIO-PCT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO RSCOM-MAX-INCM-RATIO-PCT
               MOVE ZERO              TO MIR-MAX-INCM-RATIO-PCT
               GO TO 8580-EDIT-UERAT-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-MAX-INCM-RATIO-PCT              TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     (S) UNEARNED/EARNED RATIO MUST BE NUMERIC FORMAT 999
                MOVE 'NS33600081'     TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                GO TO 8580-EDIT-UERAT-X
            END-IF.

           MOVE L0280-OUTPUT          TO RSCOM-MAX-INCM-RATIO-PCT.
020874*    MOVE L0280-OUTPUT          TO WS-N-999.
020874*    MOVE WS-N-999              TO MIR-MAX-INCM-RATIO-PCT.
020874     MOVE L0280-OUTPUT          TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MAX-INCM-RATIO-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-INCM-RATIO-PCT.

       8580-EDIT-UERAT-X.
           EXIT.

       8590-EDIT-IMMON.

           IF MIR-CLI-INCM-MO-DUR = SPACES
020874*        MOVE RSCOM-CLI-INCM-MO-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CLI-INCM-MO-DUR
020874         MOVE RSCOM-CLI-INCM-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-INCM-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-INCM-MO-DUR
               GO TO 8590-EDIT-IMMON-X
           END-IF.

           IF MIR-CLI-INCM-MO-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO RSCOM-CLI-INCM-MO-DUR
               MOVE ZERO              TO MIR-CLI-INCM-MO-DUR
               GO TO 8590-EDIT-IMMON-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-INCM-MO-DUR   TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     (S) INCOME MAX MONTH RANGE MUST BE NUMERIC FORMAT 999
                MOVE 'NS33600130'     TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                GO TO 8590-EDIT-IMMON-X
            END-IF.

           MOVE L0280-OUTPUT          TO RSCOM-CLI-INCM-MO-DUR.
020874*    MOVE L0280-OUTPUT          TO WS-N-999.
020874*    MOVE WS-N-999              TO MIR-CLI-INCM-MO-DUR.
020874     MOVE L0280-OUTPUT          TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLI-INCM-MO-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CLI-INCM-MO-DUR.

       8590-EDIT-IMMON-X.
           EXIT.

       8600-EDIT-HMDIS.

           IF MIR-SUM-INS-DSCREP-AMT = SPACES
               MOVE RSCOM-SUM-INS-DSCREP-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8602-FORMAT-HMDIS
                   THRU 8602-FORMAT-HMDIS-X
               GO TO 8600-EDIT-HMDIS-X
           END-IF.

           IF MIR-SUM-INS-DSCREP-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO RSCOM-SUM-INS-DSCREP-AMT
               MOVE ZERO              TO MIR-SUM-INS-DSCREP-AMT
               GO TO 8600-EDIT-HMDIS-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE LENGTH OF MIR-SUM-INS-DSCREP-AMT
                                      TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-SUM-INS-DSCREP-AMT   TO L0280-INPUT-DATA.

           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     (S) MAX UW DISCRENCY (HEALTH) MUST BE NUMERIC - 99999
                MOVE 'NS33600080'     TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                GO TO 8600-EDIT-HMDIS-X
            END-IF.

           MOVE L0280-OUTPUT          TO RSCOM-SUM-INS-DSCREP-AMT.
020874*    MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER.
020874     MOVE L0280-OUTPUT      TO L0290-INPUT-V00.
           PERFORM  8602-FORMAT-HMDIS
               THRU 8602-FORMAT-HMDIS-X.

       8600-EDIT-HMDIS-X.
           EXIT.

      *****************************************************************
      *  SUM-INS-DSCREP-AMT : OUTPUT FORMAT 99999
      *****************************************************************
       8602-FORMAT-HMDIS.
           MOVE 0                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-SUM-INS-DSCREP-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-SUM-INS-DSCREP-AMT.
       8602-FORMAT-HMDIS-X.
           EXIT.


       8610-EDIT-HOURS-ENTRY.

           PERFORM  8620-BLANK-HOURS-GROUP
               THRU 8620-BLANK-HOURS-GROUP-X.

           PERFORM  8630-EDIT-MINHR
               THRU 8630-EDIT-MINHR-X.

           PERFORM  8640-EDIT-MAXHR
               THRU 8640-EDIT-MAXHR-X.

           PERFORM  8650-EDIT-HWMD1
               THRU 8650-EDIT-HWMD1-X.

           PERFORM  8660-EDIT-HWMD2
               THRU 8660-EDIT-HWMD2-X.

       8610-EDIT-HOURS-ENTRY-X.
           EXIT.


       8620-BLANK-HOURS-GROUP.

           IF MIR-MIN-WRK-3-QTY-T (WS-SUB) = EBLCH-BLANK-FIELD-GROUP
               MOVE EBLCH-BLANK-FIELD-CHAR
                                      TO MIR-MIN-WRK-3-QTY-T (WS-SUB)
               MOVE EBLCH-BLANK-FIELD-CHAR
                                      TO MIR-MAX-WRK-3-QTY-T (WS-SUB)
               MOVE EBLCH-BLANK-FIELD-CHAR
                                    TO MIR-SBSDRY-CO-WRK-3-CD-T (WS-SUB)
               MOVE EBLCH-BLANK-FIELD-CHAR
                                      TO MIR-WRK-DUR-3-CD-T (WS-SUB)
           END-IF.

       8620-BLANK-HOURS-GROUP-X.
           EXIT.


       8630-EDIT-MINHR.

           IF MIR-MIN-WRK-3-QTY-T (WS-SUB) = SPACES
               MOVE RSCOM-MIN-WRK-QTY (WS-SUB)
                                      TO WS-N-999V9
               MOVE WS-N-999V9        TO MIR-MIN-WRK-3-QTY-T (WS-SUB)
               GO TO 8630-EDIT-MINHR-X
           END-IF.

           IF MIR-MIN-WRK-3-QTY-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO RSCOM-MIN-WRK-QTY (WS-SUB)
               MOVE ZERO              TO WS-N-999V9
               MOVE WS-N-999V9        TO MIR-MIN-WRK-3-QTY-T (WS-SUB)
               GO TO 8630-EDIT-MINHR-X
           END-IF.

           MOVE MIR-MIN-WRK-3-QTY-T (WS-SUB)
                                      TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-V01  TO WS-N-999V9
               MOVE WS-N-999V9        TO MIR-MIN-WRK-3-QTY-T (WS-SUB)
               MOVE L0280-OUTPUT-V01  TO RSCOM-MIN-WRK-QTY (WS-SUB)
           ELSE
      *MSG:    (S) MIN HOURS WORKED MUST BE NUMERIC-FORMAT 999.9
               MOVE 'NS33600082'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8630-EDIT-MINHR-X.
           EXIT.


       8640-EDIT-MAXHR.

           IF MIR-MAX-WRK-3-QTY-T (WS-SUB) = SPACES
               MOVE RSCOM-MAX-WRK-QTY (WS-SUB)
                                      TO WS-N-999V9
               MOVE WS-N-999V9        TO MIR-MAX-WRK-3-QTY-T (WS-SUB)
               GO TO 8640-EDIT-MAXHR-X
           END-IF.

           IF MIR-MAX-WRK-3-QTY-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO RSCOM-MAX-WRK-QTY (WS-SUB)
               MOVE ZERO              TO WS-N-999V9
               MOVE WS-N-999V9        TO MIR-MAX-WRK-3-QTY-T (WS-SUB)
               GO TO 8640-EDIT-MAXHR-X
           END-IF.

           MOVE MIR-MAX-WRK-3-QTY-T (WS-SUB)
                                      TO L0280-INPUT-DATA.
           PERFORM  8800-NUMERIC-EDIT
               THRU 8800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-V01  TO WS-N-999V9
               MOVE WS-N-999V9        TO MIR-MAX-WRK-3-QTY-T (WS-SUB)
               MOVE L0280-OUTPUT-V01  TO RSCOM-MAX-WRK-QTY (WS-SUB)
           ELSE
      *MSG:    (S) MAX HOURS WORKED MUST BE NUMERIC-FORMAT 999.9
               MOVE 'NS33600083'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8640-EDIT-MAXHR-X.
           EXIT.


       8650-EDIT-HWMD1.

           IF MIR-SBSDRY-CO-WRK-3-CD-T (WS-SUB) = SPACES
               MOVE RSCOM-SBSDRY-CO-WRK-CD   (WS-SUB)
                                      TO
                   MIR-SBSDRY-CO-WRK-3-CD-T (WS-SUB)
               GO TO 8650-EDIT-HWMD1-X
           END-IF.

           IF MIR-SBSDRY-CO-WRK-3-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE           TO MIR-SBSDRY-CO-WRK-3-CD-T (WS-SUB)
               MOVE SPACE           TO RSCOM-SBSDRY-CO-WRK-CD   (WS-SUB)
               GO TO 8650-EDIT-HWMD1-X
           END-IF.

            MOVE MIR-SBSDRY-CO-WRK-3-CD-T (WS-SUB)
                                      TO WS-HOURS-WORKED-MODE1.
            IF NOT WS-HOURS-WORKED-MODE1-OK
      *MSG:     (S) HOURS WORKED MODE 1 MUST BE H, D OR M
                MOVE 'NS33600084'     TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                MOVE '1'              TO WS-DATA-EDITS
                GO TO 8650-EDIT-HWMD1-X
            END-IF.

           MOVE MIR-SBSDRY-CO-WRK-3-CD-T (WS-SUB)
                                      TO
               RSCOM-SBSDRY-CO-WRK-CD   (WS-SUB).

       8650-EDIT-HWMD1-X.
           EXIT.


       8660-EDIT-HWMD2.

           IF MIR-WRK-DUR-3-CD-T (WS-SUB) = SPACES
               MOVE RSCOM-WRK-DUR-CD (WS-SUB)
                                      TO
                   MIR-WRK-DUR-3-CD-T (WS-SUB)
               GO TO 8660-EDIT-HWMD2-X
           END-IF.

           IF MIR-WRK-DUR-3-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-WRK-DUR-3-CD-T (WS-SUB)
               MOVE SPACE             TO RSCOM-WRK-DUR-CD (WS-SUB)
               GO TO 8660-EDIT-HWMD2-X
           END-IF.

            MOVE MIR-WRK-DUR-3-CD-T (WS-SUB)
                                      TO WS-HOURS-WORKED-MODE2.
            IF NOT WS-HOURS-WORKED-MODE2-OK
      *MSG:     (S) HOURS WORKED MODE 2 MUST BE D, W, M OR Y
                MOVE 'NS33600085'     TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                MOVE '1'              TO WS-DATA-EDITS
                GO TO 8660-EDIT-HWMD2-X
            END-IF.

           MOVE MIR-WRK-DUR-3-CD-T (WS-SUB)
                                      TO
               RSCOM-WRK-DUR-CD (WS-SUB).

       8660-EDIT-HWMD2-X.
           EXIT.


       8670-XEDIT-HOURS-ENTRY.

           IF RSCOM-MIN-WRK-QTY (WS-SUB) >
                                         RSCOM-MAX-WRK-QTY (WS-SUB)
      *MSG:     (S) MIN HOURS (@1) SHOULD NOT EXCEED MAX HOURS (@2)
                MOVE 'NS33600086'     TO WGLOB-MSG-REF-INFO
                MOVE RSCOM-MIN-WRK-QTY (WS-SUB)
                                      TO WS-N-999V9
                MOVE WS-N-999V9       TO WGLOB-MSG-PARM (1)
                MOVE RSCOM-MAX-WRK-QTY (WS-SUB)
                                      TO WS-N-999V9
                MOVE WS-N-999V9       TO WGLOB-MSG-PARM (2)
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

           IF RSCOM-MIN-WRK-QTY (WS-SUB) > ZERO
           OR RSCOM-MAX-WRK-QTY (WS-SUB) > ZERO
               IF RSCOM-WRK-MODE-INFO  (WS-SUB) = SPACES
      *MSG:     (S) HOURS NON-ZERO, MODE SHOULD BE ENTERED - LINE (@1)
                MOVE 'NS33600092'     TO WGLOB-MSG-REF-INFO
                MOVE WS-SUB           TO WS-N-9
                MOVE WS-N-9           TO WGLOB-MSG-PARM (1)
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-EDITS
               END-IF
           END-IF.

           MOVE RSCOM-WRK-MODE-INFO  (WS-SUB)
                                      TO EHWMD-MODE.
           PERFORM  HWMD-1000-EDIT-MODE
               THRU HWMD-1000-EDIT-MODE-X.
           IF NOT EHWMD-DATA-VALID
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

           MOVE RSCOM-MIN-WRK-QTY (WS-SUB)
                                      TO EHWMD-HOURS.
           PERFORM  HWMD-2000-EDIT-HOURS
               THRU HWMD-2000-EDIT-HOURS-X.
           IF NOT EHWMD-DATA-VALID
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

           MOVE RSCOM-MAX-WRK-QTY (WS-SUB)
                                      TO EHWMD-HOURS.
           PERFORM  HWMD-2000-EDIT-HOURS
               THRU HWMD-2000-EDIT-HOURS-X.
           IF NOT EHWMD-DATA-VALID
               MOVE '1'               TO WS-DATA-EDITS
           END-IF.

       8670-XEDIT-HOURS-ENTRY-X.
           EXIT.

      /

020467*****************************************************************
020467*  DD2-LEAD-DY-DUR: MUST BE NUMERIC 0 - 999
020467*****************************************************************
020467 8700-EDIT-DD2-LEAD-DY-DUR.

020467     IF  MIR-DD2-LEAD-DY-DUR    =  SPACES
020467         MOVE RSCOM-DD2-LEAD-DY-DUR TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-LEAD-DY-DUR
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-LEAD-DY-DUR
020467         GO TO 8700-EDIT-DD2-LEAD-DY-DUR-X
020467     END-IF.

020467     IF  MIR-DD2-LEAD-DY-DUR    =  EBLCH-BLANK-FIELD-CHAR
020467         MOVE ZERO              TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-LEAD-DY-DUR
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-LEAD-DY-DUR
020467     END-IF.

020467     MOVE 'N'                   TO L0280-SIGN-IND.
020467     MOVE 0                     TO L0280-PRECISION.
020467     MOVE 3                     TO L0280-LENGTH.
020467     MOVE +3                    TO L0280-INPUT-SIZE.
020467     MOVE MIR-DD2-LEAD-DY-DUR   TO L0280-INPUT-DATA.

020467     PERFORM  8800-NUMERIC-EDIT
020467         THRU 8800-NUMERIC-EDIT-X.

020467     IF  L0280-OK
020467         MOVE L0280-OUTPUT      TO
020467                                   WS-TEST-RANGE
020467         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-LEAD-DY-DUR
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-LEAD-DY-DUR
020467         IF  WS-BILL-LEAD-DY-VALID
020467             MOVE L0280-OUTPUT  TO RSCOM-DD2-LEAD-DY-DUR
020467         ELSE
020467*MSG: AUTOPAY LEAD TIME DAYS MUST BE POSITIVE NUMERIC (000-999)
020467             MOVE 'NS33600149'  TO WGLOB-MSG-REF-INFO
020467             PERFORM  0260-1000-GENERATE-MESSAGE
020467                 THRU 0260-1000-GENERATE-MESSAGE-X
020467             MOVE '1'           TO WS-DATA-EDITS
020467         END-IF
020467     ELSE
020467*MSG: AUTOPAY LEAD TIME DAYS MUST BE POSITIVE NUMERIC (000-999)
020467         MOVE 'NS33600150'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467         MOVE '1'               TO WS-DATA-EDITS
020467     END-IF.

020467 8700-EDIT-DD2-LEAD-DY-DUR-X.
020467     EXIT.
020467/
020467*****************************************************************
020467*  DD2-DEP-FIRST: MUST BE NUMERIC IN RANGE 1 TO 31
020467*****************************************************************
020467 8710-EDIT-DD2-DEPDF.
020467
020467     MOVE '0'                   TO WS-VALIDATE-DD2-DEPDF.
020467
020467     IF  MIR-DD2-FRST-DPOS-DY   =  SPACES
020467         MOVE RSCOM-DD2-FRST-DPOS-DY   TO WS-SAVE-DD2-DEPDF
020467         MOVE RSCOM-DD2-FRST-DPOS-DY   TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FRST-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FRST-DPOS-DY
020467         GO TO 8710-EDIT-DD2-DEPDF-X
020467     END-IF.
020467
020467     IF  MIR-DD2-FRST-DPOS-DY   =  EBLCH-BLANK-FIELD-CHAR
020467         MOVE 0                 TO WS-SAVE-DD2-DEPDF
020467         MOVE ZERO              TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FRST-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FRST-DPOS-DY
020467     END-IF.
020467
020467     MOVE 'N'                   TO L0280-SIGN-IND.
020467     MOVE 0                     TO L0280-PRECISION.
020467     MOVE 2                     TO L0280-LENGTH.
020467     MOVE +2                    TO L0280-INPUT-SIZE.
020467     MOVE MIR-DD2-FRST-DPOS-DY  TO L0280-INPUT-DATA.
020467
020467     PERFORM  8800-NUMERIC-EDIT
020467         THRU 8800-NUMERIC-EDIT-X.
020467
020467     IF  L0280-OK
020467         MOVE L0280-OUTPUT      TO WS-TEST-RANGE
020467         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FRST-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FRST-DPOS-DY
020467         IF  WS-DD2-DEPDF-VALID
020467             MOVE L0280-OUTPUT  TO WS-SAVE-DD2-DEPDF
020467         ELSE
020467*MSG: AUTOPAY DEPOSIT DAYS MUST BE IN RANGE 1-31
020467             MOVE 'NS33600151'  TO WGLOB-MSG-REF-INFO
020467             PERFORM  0260-1000-GENERATE-MESSAGE
020467                 THRU 0260-1000-GENERATE-MESSAGE-X
020467             MOVE '1'           TO WS-DATA-EDITS
020467                                   WS-VALIDATE-DD2-DEPDF
020467             GO TO 8710-EDIT-DD2-DEPDF-X
020467         END-IF
020467     ELSE
020467*MSG:  MINIMUM AUTOPAY DAY MUST BE NUMERIC
020467         MOVE 'NS33600152'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467         MOVE '1'               TO WS-DATA-EDITS
020467                                   WS-VALIDATE-DD2-DEPDF
020467     END-IF.
020467
020467 8710-EDIT-DD2-DEPDF-X.
020467     EXIT.
020467/
020467*****************************************************************
020467*  DD2-DEP-LAST : MUST BE NUMERIC IN RANGE 1 TO 31
020467*****************************************************************
020467
020467 8720-EDIT-DD2-DEPDL.
020467
020467     MOVE '0'                   TO WS-VALIDATE-DD2-DEPDL.
020467
020467     IF  MIR-DD2-FINAL-DPOS-DY    =  SPACES
020467         MOVE RSCOM-DD2-FINAL-DPOS-DY TO WS-SAVE-DD2-DEPDL
020467         MOVE RSCOM-DD2-FINAL-DPOS-DY TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FINAL-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FINAL-DPOS-DY
020467         GO TO 8720-EDIT-DD2-DEPDL-X
020467     END-IF.
020467
020467     IF  MIR-DD2-FINAL-DPOS-DY   =  EBLCH-BLANK-FIELD-CHAR
020467         MOVE 0                 TO WS-SAVE-DD2-DEPDL
020467         MOVE ZERO              TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FINAL-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FINAL-DPOS-DY
020467     END-IF.
020467
020467     MOVE 'N'                   TO L0280-SIGN-IND.
020467     MOVE 0                     TO L0280-PRECISION.
020467     MOVE 2                     TO L0280-LENGTH.
020467     MOVE +2                    TO L0280-INPUT-SIZE.
020467     MOVE MIR-DD2-FINAL-DPOS-DY     TO L0280-INPUT-DATA.
020467
020467     PERFORM  8800-NUMERIC-EDIT
020467         THRU 8800-NUMERIC-EDIT-X.
020467
020467     IF  L0280-OK
020467         MOVE L0280-OUTPUT      TO WS-TEST-RANGE
020467         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FINAL-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FINAL-DPOS-DY
020467         IF  WS-DD2-DEPDL-VALID
020467             MOVE L0280-OUTPUT  TO WS-SAVE-DD2-DEPDL
020467         ELSE
020467*MSG: AUTOPAY DEPOSIT DAYS MUST BE IN RANGE 1-31
020467             MOVE 'NS33600151'  TO WGLOB-MSG-REF-INFO
020467             PERFORM  0260-1000-GENERATE-MESSAGE
020467                 THRU 0260-1000-GENERATE-MESSAGE-X
020467             MOVE '1'           TO WS-DATA-EDITS
020467                                   WS-VALIDATE-DD2-DEPDL
020467             GO TO 8720-EDIT-DD2-DEPDL-X
020467         END-IF
020467     ELSE
020467*MSG: MAXIMUM AUTOPAY DAY MUST BE NUMERIC
020467         MOVE 'NS33600153'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467         MOVE '1'               TO WS-DATA-EDITS
020467                                   WS-VALIDATE-DD2-DEPDL
020467     END-IF.
020467
020467 8720-EDIT-DD2-DEPDL-X.
020467     EXIT.
020467/
020467 8730-EDIT-DD2RO.
020467
020467     IF  MIR-DD2-REDRW-OPT-CD      =  SPACES
020467         MOVE RSCOM-DD2-REDRW-OPT-CD  TO MIR-DD2-REDRW-OPT-CD
020467         GO TO 8730-EDIT-DD2RO-X
020467     END-IF.
020467
020467     IF  MIR-DD2-REDRW-OPT-CD  =  EBLCH-BLANK-FIELD-CHAR
020467         MOVE SPACES            TO MIR-DD2-REDRW-OPT-CD
020467     END-IF.
020467
020467     MOVE MIR-DD2-REDRW-OPT-CD  TO WS-VALIDATE-DD2RO.
020467
020467     IF  WS-VALID-DD2RO
020467         MOVE MIR-DD2-REDRW-OPT-CD
020467                                TO RSCOM-DD2-REDRW-OPT-CD
020467     ELSE
020467         MOVE '1'               TO WS-DATA-EDITS
020467*MSG: AUTOPAY REDRAW OPTION CODE IS INVALID. RE-ENTER
020467         MOVE 'NS33600155'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467     END-IF.
020467
020467 8730-EDIT-DD2RO-X.
020467     EXIT.
020467/
020467 8740-EDIT-DD2-DRAW-IND.
020467
020467     IF MIR-INIT-DD2-DRW-IND   = SPACES
020467         MOVE RSCOM-INIT-DD2-DRW-IND
020467                                TO MIR-INIT-DD2-DRW-IND
020467         GO TO 8740-EDIT-DD2-DRAW-IND-X
020467     END-IF.
020467
020467     MOVE MIR-INIT-DD2-DRW-IND  TO WS-VALIDATE-DD2-DRAW.
020467
020467     IF WS-VALID-DD2-DRAW
020467         MOVE MIR-INIT-DD2-DRW-IND
020467                                TO RSCOM-INIT-DD2-DRW-IND
020467     ELSE
020467         MOVE '1'               TO WS-DATA-EDITS
020467*MSG:    INVALID DRAW INDICATOR FOR AUTOPAY - MUST BE Y OR N
020467         MOVE 'NS33600156'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467     END-IF.
020467
020467 8740-EDIT-DD2-DRAW-IND-X.
020467     EXIT.
020467/
020467 8750-EDIT-DD2-REDRAW-IND.
020467
020467     IF MIR-INIT-DD2-REDRW-IND   = SPACES
020467         MOVE RSCOM-INIT-DD2-REDRW-IND
020467                                TO MIR-INIT-DD2-REDRW-IND
020467         GO TO 8750-EDIT-DD2-REDRAW-IND-X
020467     END-IF.
020467
020467     MOVE MIR-INIT-DD2-REDRW-IND  TO WS-VALIDATE-DD2-REDRAW.
020467
020467     IF WS-VALID-DD2-REDRAW
020467         MOVE MIR-INIT-DD2-REDRW-IND
020467                                TO RSCOM-INIT-DD2-REDRW-IND
020467     ELSE
020467         MOVE '1'               TO WS-DATA-EDITS
020467*MSG:    INVALID REDRAW INDICATOR FOR AUTOPAY - MUST BE Y OR N
020467         MOVE 'NS33600157'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467     END-IF.
020467
020467 8750-EDIT-DD2-REDRAW-IND-X.
020467     EXIT.
020467/
020467 8760-EDIT-DD2-MDRED.
020467
020467     IF  MIR-DD2-REDRW-DUR   =  SPACES
020467         MOVE RSCOM-DD2-REDRW-DUR
020467                                TO MIR-DD2-REDRW-DUR
020467         GO TO 8760-EDIT-DD2-MDRED-X
020467     END-IF.
020467
020467     IF  MIR-DD2-REDRW-DUR   =  EBLCH-BLANK-FIELD-CHAR
020467         MOVE ZEROS             TO MIR-DD2-REDRW-DUR
020467     END-IF.
020467
020467     MOVE MIR-DD2-REDRW-DUR     TO WS-DD2-RDDTE.
020467
020467     IF  WS-DD2-RDDTE-MM NUMERIC
020467     AND WS-DD2-RDDTE-DD NUMERIC
020467     AND WS-DD2-RDDTE-FILLER  =  SPACES
020467         MOVE MIR-DD2-REDRW-DUR TO RSCOM-DD2-REDRW-DUR
020467     ELSE
020467         MOVE '1'               TO WS-DATA-EDITS
020467*MSG: #MTHS/DAYS TO REDRAW FOR AUTOPAY MUST BE A 4-DIGIT NUMBER
020467         MOVE 'NS33600158'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467     END-IF.
020467
020467 8760-EDIT-DD2-MDRED-X.
020467     EXIT.
020467/
020467 8770-DD2RO-CROSS-EDIT.
020467
020467     IF  RSCOM-DD2-REDRW-OPT-CD       =  '3'
020467     AND RSCOM-DD2-REDRW-DUR          =  ZEROS
020467         MOVE RSCOM-DD2-REDRW-OPT-CD
020467                                TO WGLOB-MSG-PARM (1)
020467         MOVE '1'               TO WS-DATA-EDITS
020467*MSG: FOR AUTOPAY REDRAW OPTION (3), #MTHS/DAYS TO REDRAW MUST
020467*     BE > 0000
020467         MOVE 'NS33600159'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467     END-IF.
020467
020467 8770-DD2RO-CROSS-EDIT-X.
020467     EXIT.
020467/
020467 8780-DD2-CROSS-EDIT.
020467
020467     IF (WS-SAVE-DD2-DEPDF < WS-SAVE-DD2-DEPDL)
020467         MOVE WS-SAVE-DD2-DEPDF TO RSCOM-DD2-FRST-DPOS-DY
020467         MOVE WS-SAVE-DD2-DEPDL TO RSCOM-DD2-FINAL-DPOS-DY
020467     ELSE
020467*MSG: MINIMUM AUTOPAY DAY MUST BE LESS THAN MAXIMUM AUTOPAY DAY
020467         MOVE 'NS33600154'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467         MOVE '1'               TO WS-DATA-EDITS
020467     END-IF.
020467
020467 8780-DD2-CROSS-EDIT-X.
020467     EXIT.
020467/
020467 8785-EDIT-2AMLI.
020467
020467     IF  MIR-DD2-DRW-MRG-IND = SPACES
020467         MOVE RSCOM-DD2-DRW-MRG-IND
020467                                TO MIR-DD2-DRW-MRG-IND
020467         GO TO 8785-EDIT-2AMLI-X
020467     END-IF.
020467
020467     IF  MIR-DD2-DRW-MRG-IND = EBLCH-BLANK-FIELD-CHAR
020467         MOVE SPACES            TO MIR-DD2-DRW-MRG-IND
020467     END-IF.
020467
020467     MOVE MIR-DD2-DRW-MRG-IND     TO WS-YES-NO-TEST.
020467
020467     IF  WS-YES-NO-VALID
020467         MOVE MIR-DD2-DRW-MRG-IND TO RSCOM-DD2-DRW-MRG-IND
020467     ELSE
020467* MSG: AUTOPAY AMALGAMATE INDICATOR MUST BE Y OR N
020467         MOVE '1'               TO WS-DATA-EDITS
020467         MOVE 'NS33600160'      TO WGLOB-MSG-REF-INFO
020467         PERFORM  0260-1000-GENERATE-MESSAGE
020467             THRU 0260-1000-GENERATE-MESSAGE-X
020467     END-IF.
020467
020467 8785-EDIT-2AMLI-X.
020467     EXIT.
020467/
020463
020463*****************************************************************
020463*  ASSET-REBAL-TOL-PCT: MUST BE NUMERIC
020463*****************************************************************
020463 8790-EDIT-ARTOLP.

020463     IF MIR-PRFL-REBAL-TOL-PCT = SPACES
020463         MOVE RSCOM-PRFL-REBAL-TOL-PCT TO L0290-INPUT-V02
020463         MOVE 2                        TO L0290-PRECISION
020463         MOVE LENGTH OF MIR-PRFL-REBAL-TOL-PCT
020463                                       TO L0290-MAX-OUT-LEN
020463         PERFORM 0290-2000-FORMAT-FOR-MIR
020463            THRU 0290-2000-FORMAT-FOR-MIR-X
020463         MOVE L0290-OUTPUT-DATA        TO MIR-PRFL-REBAL-TOL-PCT
020463         GO TO 8790-EDIT-ARTOLP-X
020463     END-IF.

020463     IF MIR-PRFL-REBAL-TOL-PCT = EBLCH-BLANK-FIELD-CHAR
020463         MOVE 0                        TO L0290-INPUT-V02
020463         MOVE 2                        TO L0290-PRECISION
020463         MOVE LENGTH OF MIR-PRFL-REBAL-TOL-PCT
020463                                       TO L0290-MAX-OUT-LEN
020463         PERFORM 0290-2000-FORMAT-FOR-MIR
020463            THRU 0290-2000-FORMAT-FOR-MIR-X
020463         MOVE L0290-OUTPUT-DATA        TO MIR-PRFL-REBAL-TOL-PCT
020463     END-IF.

020463     MOVE 'N'                          TO L0280-SIGN-IND.
020463     MOVE 2                            TO L0280-PRECISION.
020463     MOVE 3                            TO L0280-LENGTH.
020463     MOVE +6                           TO L0280-INPUT-SIZE.
020463     MOVE MIR-PRFL-REBAL-TOL-PCT       TO L0280-INPUT-DATA.
020463     PERFORM  8800-NUMERIC-EDIT
020463         THRU 8800-NUMERIC-EDIT-X.

020463     IF L0280-OK
020463         MOVE L0280-OUTPUT-V02      TO L0290-INPUT-V02
020463         MOVE 2                     TO L0290-PRECISION
020463         MOVE LENGTH OF MIR-PRFL-REBAL-TOL-PCT
020463                                    TO L0290-MAX-OUT-LEN
020463         PERFORM 0290-2000-FORMAT-FOR-MIR
020463            THRU 0290-2000-FORMAT-FOR-MIR-X
020463         MOVE L0290-OUTPUT-DATA     TO MIR-PRFL-REBAL-TOL-PCT
020463         MOVE L0280-OUTPUT-V02      TO WS-TEST-RANGE
020463         IF  WS-PRFL-REBAL-TOL-PCT-VALID
020463             MOVE L0280-OUTPUT-V02  TO RSCOM-PRFL-REBAL-TOL-PCT
020463             MOVE RSCOM-PRFL-REBAL-TOL-PCT
020463                                    TO L0290-INPUT-V02
020463             MOVE 2                 TO L0290-PRECISION
020463             MOVE LENGTH OF MIR-PRFL-REBAL-TOL-PCT
020463                                    TO L0290-MAX-OUT-LEN
020463             PERFORM 0290-2000-FORMAT-FOR-MIR
020463                THRU 0290-2000-FORMAT-FOR-MIR-X
020463             MOVE L0290-OUTPUT-DATA TO MIR-PRFL-REBAL-TOL-PCT
020463         ELSE
020463*MSG: ASSET REBALANCE TOLERANCE PERCENT OUT OF RANGE
020463             MOVE 'NS33600145'      TO WGLOB-MSG-REF-INFO
020463             PERFORM  0260-1000-GENERATE-MESSAGE
020463                 THRU 0260-1000-GENERATE-MESSAGE-X
020463             MOVE '1'               TO WS-DATA-EDITS
020463         END-IF
020463     ELSE
020463*MSG..ASSET REBALANCING TOLERANCE PERCENTAGE
020463*     MUST BE A VALID NUMERIC VALUE.
023118*        MOVE 'NS336000162'            TO WGLOB-MSG-REF-INFO
023118         MOVE 'NS33600162'             TO WGLOB-MSG-REF-INFO
020463         PERFORM  0260-1000-GENERATE-MESSAGE
020463             THRU 0260-1000-GENERATE-MESSAGE-X
020463         MOVE '1'                      TO WS-DATA-EDITS
020463     END-IF.

020463 8790-EDIT-ARTOLP-X.
020463     EXIT.

       8800-NUMERIC-EDIT.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               GO TO 8800-NUMERIC-EDIT-X
           END-IF.

           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE '1'                   TO WS-DATA-EDITS.

       8800-NUMERIC-EDIT-X.
           EXIT.
      /


      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************

       9100-BLANK-DATA-FIELDS.

015904*    MOVE SPACES                TO MIR-PREV-UPDATE-DT.
           MOVE SPACES                TO MIR-MAX-BCKDT-MO-DUR.
           MOVE SPACES                TO MIR-FINAL-DISP-DY-DUR.
           MOVE SPACES                TO MIR-MAX-PSTDT-MO-DUR.
           MOVE SPACES                TO MIR-DISP-WARN-DY-DUR.
           MOVE SPACES                TO MIR-MAX-UNDO-MO-DUR.
           MOVE SPACES                TO MIR-FRST-ISS-DY.
023443     MOVE SPACES                TO MIR-DLR-DIV-RECALC-IND.
029060     MOVE SPACES                TO MIR-MEC-2YR-ADJ-IND.
           MOVE SPACES                TO MIR-FINAL-ISS-DY.
           MOVE SPACES                TO MIR-RPU-DR-CD.
           MOVE SPACES                TO MIR-XTRNL-PMT-IND.
           MOVE SPACES                TO MIR-BILL-ZERO-AMT-IND.
           MOVE SPACES                TO MIR-SBSDRY-CO-DFLT-IND.
           MOVE SPACES                TO MIR-DFLT-LANG-CD.
           MOVE SPACES                TO MIR-PEND-PREM-TOL-CD.
           MOVE SPACES                TO MIR-PEND-PREM-TOL-PCT.
           MOVE SPACES                TO MIR-PEND-PREM-TOL-AMT.
           MOVE SPACES                TO MIR-INFC-PREM-TOL-CD.
           MOVE SPACES                TO MIR-INFC-PREM-TOL-PCT.
           MOVE SPACES                TO MIR-INFC-PREM-TOL-AMT.
           MOVE SPACES                TO MIR-LOAN-REPAY-TOL-CD.
           MOVE SPACES                TO MIR-LOAN-REPAY-TOL-PCT.
           MOVE SPACES                TO MIR-LOAN-REPAY-TOL-AMT.
016395     MOVE SPACES                TO MIR-CRC-LEAD-DY-DUR.
016503     MOVE SPACES                TO MIR-BILL-LEAD-DY-DUR.
016503     MOVE SPACES                TO MIR-PAC-LEAD-DY-DUR.
016503     MOVE SPACES                TO MIR-ANPAYO-LEAD-DY-DUR.
016503     MOVE SPACES                TO MIR-CLM-LEAD-DY-DUR.
016503     MOVE SPACES                TO MIR-OTHR-LEAD-DY-DUR.
016503     MOVE SPACES                TO MIR-REQIR-LEAD-DY-DUR.

015904*    MOVE SPACES                TO MIR-PREV-UPDATE-DT.
           MOVE SPACES                TO MIR-COMIT-PERI-DY-DUR.
           MOVE SPACES                TO MIR-ROLOVR-DY-DUR.
           MOVE SPACES                TO MIR-FRST-DPOS-DY.
           MOVE SPACES                TO MIR-FINAL-DPOS-DY.
           MOVE SPACES                TO MIR-COMIT-TOL-CALC-CD.
           MOVE SPACES                TO MIR-ROLOVR-TOL-CALC-CD.
           MOVE SPACES                TO MIR-INIT-PAC-DRW-IND.
           MOVE SPACES                TO MIR-COMIT-TOL-CD.
           MOVE SPACES                TO MIR-ROLOVR-TOL-CD.
           MOVE SPACES                TO MIR-INIT-PAC-REDRW-IND.
           MOVE SPACES                TO MIR-COMIT-TOL-AMT.
           MOVE SPACES                TO MIR-ROLOVR-TOL-AMT.
           MOVE SPACES                TO MIR-PAC-REDRW-OPT-CD.
           MOVE SPACES                TO MIR-COMIT-TOL-PCT.
           MOVE SPACES                TO MIR-ROLOVR-TOL-PCT.
           MOVE SPACES                TO MIR-PAC-REDRW-DUR.
           MOVE SPACES                TO MIR-COMIT-INT-RT-CD.
           MOVE SPACES                TO MIR-ROLOVR-INT-RT-CD.
           MOVE SPACES                TO MIR-COMIT-STRT-CD.
016395     MOVE SPACES                TO MIR-CRC-REDRW-DUR.
016395     MOVE SPACES                TO MIR-CRC-REDRW-OPT-CD.
016395     MOVE SPACES                TO MIR-CRC-FRST-DPOS-DY.
016395     MOVE SPACES                TO MIR-CRC-FINAL-DPOS-DY.

015904*    MOVE SPACES                TO MIR-PREV-UPDATE-DT.
           MOVE SPACES                TO MIR-CLI-MAX-AD-AMT.
           MOVE SPACES                TO MIR-TCR-INCL-AD-IND.
           MOVE SPACES                TO MIR-CLI-MAXWP-AMT.
           MOVE SPACES                TO MIR-TOT-INS-DSCREP-AMT.
           MOVE SPACES                TO MIR-CLI-MAXWP-PREM-AMT.
           MOVE SPACES                TO MIR-UWG-CHNG-MO-DUR.
           MOVE SPACES                TO MIR-MAX-UWG-AMT.
           MOVE SPACES                TO MIR-MAX-ALCHL-QTY.
           MOVE SPACES                TO MIR-MAX-CHILD-AGE.
           MOVE SPACES                TO MIR-CRNT-ADDR-YR-DUR.
           MOVE SPACES                TO MIR-CLI-INCM-MO-DUR.
           MOVE SPACES                TO MIR-MIB-CO-SYMBL-CD.
           MOVE SPACES                TO MIR-MIB-CO-DEST-CD.
016440*    MOVE SPACES                TO MIR-TCR-CALC-MTHD-CD.
           MOVE SPACES                TO MIR-TCR-INFC-MO-DUR.
           MOVE SPACES                TO MIR-TCR-BASE-DT-CD.
           MOVE SPACES                TO MIR-HWTB-MIN-RAT-QTY.
           MOVE SPACES                TO MIR-HWTB-MAX-RAT-QTY.

020467     MOVE SPACES                TO MIR-INIT-DD2-DRW-IND.
020467     MOVE SPACES                TO MIR-INIT-DD2-REDRW-IND.
020467     MOVE SPACES                TO MIR-DD2-REDRW-OPT-CD.
020467     MOVE SPACES                TO MIR-DD2-REDRW-DUR.
020467     MOVE SPACES                TO MIR-DD2-LEAD-DY-DUR.
020467     MOVE SPACES                TO MIR-DD2-FRST-DPOS-DY.
020467     MOVE SPACES                TO MIR-DD2-FINAL-DPOS-DY.
020467     MOVE SPACES                TO MIR-DD2-DRW-MRG-IND.
020463     MOVE SPACES                TO MIR-PRFL-REBAL-TOL-PCT.

015904*    MOVE SPACES                TO MIR-PREV-UPDATE-DT.
016440*    MOVE SPACES                TO MIR-DI-CCAS-INCL-CD.
           MOVE SPACES                TO MIR-OOE-3-OCCP-CLAS-CD-G.
           MOVE SPACES                TO MIR-OOE-3-MAX-AMT-G.
           MOVE SPACES                TO MIR-OOE-3-MAX-CCAS-AMT-G.
           MOVE SPACES                TO MIR-MAX-ADND-AMT.
           MOVE SPACES                TO MIR-MAX-INCM-RATIO-PCT.
           MOVE SPACES                TO MIR-SUM-INS-DSCREP-AMT.
           MOVE SPACES                TO MIR-MIN-WRK-3-QTY-G.
           MOVE SPACES                TO MIR-MAX-WRK-3-QTY-G.
           MOVE SPACES                TO MIR-SBSDRY-CO-WRK-3-CD-G.
           MOVE SPACES                TO MIR-WRK-DUR-3-CD-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /

      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *  CALL DATE ROUTINE M0993BAT TO PERFORM DATE CONVERSION
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.

      *
      *** SCREEN 1 DATA
      *
           MOVE RSCOM-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID.
015904*    MOVE RSCOM-PREV-UPDT-DT    TO L1640-INTERNAL-DATE.
015904*    PERFORM  1640-2000-INTERNAL-TO-EXT
015904*        THRU 1640-2000-INTERNAL-TO-EXT-X.
015904*    MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-UPDATE-DT.
           MOVE RSCOM-RPU-DR-CD       TO MIR-RPU-DR-CD.
           MOVE RSCOM-XTRNL-PMT-IND   TO MIR-XTRNL-PMT-IND.
           MOVE RSCOM-BILL-ZERO-AMT-IND
                                      TO MIR-BILL-ZERO-AMT-IND.
           MOVE RSCOM-SBSDRY-CO-DFLT-IND
                                      TO MIR-SBSDRY-CO-DFLT-IND.
           MOVE RSCOM-DFLT-LANG-CD    TO MIR-DFLT-LANG-CD.
           MOVE RSCOM-PEND-PREM-TOL-CD    TO MIR-PEND-PREM-TOL-CD.
           MOVE RSCOM-INFC-PREM-TOL-CD    TO MIR-INFC-PREM-TOL-CD.
           MOVE RSCOM-LOAN-REPAY-TOL-CD
                                      TO MIR-LOAN-REPAY-TOL-CD.
           IF  WS-BUS-FCN-UPDATE
020874*        MOVE RSCOM-MAX-BCKDT-MO-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-MAX-BCKDT-MO-DUR
020874         MOVE RSCOM-MAX-BCKDT-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-BCKDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-BCKDT-MO-DUR
020874*        MOVE RSCOM-FINAL-DISP-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-FINAL-DISP-DY-DUR
020874         MOVE RSCOM-FINAL-DISP-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DISP-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DISP-DY-DUR
020874*        MOVE RSCOM-MAX-PSTDT-MO-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-MAX-PSTDT-MO-DUR
020874         MOVE RSCOM-MAX-PSTDT-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-PSTDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-PSTDT-MO-DUR
020874*        MOVE RSCOM-DISP-WARN-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-DISP-WARN-DY-DUR
020874         MOVE RSCOM-DISP-WARN-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DISP-WARN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DISP-WARN-DY-DUR
020874*        MOVE RSCOM-MAX-UNDO-MO-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-MAX-UNDO-MO-DUR
020874         MOVE RSCOM-MAX-UNDO-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-UNDO-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-UNDO-MO-DUR
020874*        MOVE RSCOM-CRC-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-LEAD-DY-DUR
020874         MOVE RSCOM-CRC-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-LEAD-DY-DUR
020874*        MOVE RSCOM-BILL-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-BILL-LEAD-DY-DUR
020874         MOVE RSCOM-BILL-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BILL-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-BILL-LEAD-DY-DUR
020874*        MOVE RSCOM-PAC-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-PAC-LEAD-DY-DUR
020874         MOVE RSCOM-PAC-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PAC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PAC-LEAD-DY-DUR
020874*        MOVE RSCOM-ANPAYO-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-ANPAYO-LEAD-DY-DUR
020874         MOVE RSCOM-ANPAYO-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ANPAYO-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ANPAYO-LEAD-DY-DUR
020874*        MOVE RSCOM-CLM-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CLM-LEAD-DY-DUR
020874         MOVE RSCOM-CLM-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLM-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLM-LEAD-DY-DUR
020874*        MOVE RSCOM-OTHR-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-OTHR-LEAD-DY-DUR
020874         MOVE RSCOM-OTHR-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-OTHR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-OTHR-LEAD-DY-DUR
020874*        MOVE RSCOM-REQIR-LEAD-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-REQIR-LEAD-DY-DUR
020874         MOVE RSCOM-REQIR-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-REQIR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-REQIR-LEAD-DY-DUR
020874*        MOVE RSCOM-FRST-ISS-DY TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-FRST-ISS-DY
020874         MOVE RSCOM-FRST-ISS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-ISS-DY
020874*        MOVE RSCOM-FINAL-ISS-DY   TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-FINAL-ISS-DY
020874         MOVE RSCOM-FINAL-ISS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-ISS-DY
020874*        MOVE RSCOM-PEND-PREM-TOL-PCT
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-PEND-PREM-TOL-PCT
020874         MOVE RSCOM-PEND-PREM-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PEND-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PEND-PREM-TOL-PCT
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-PEND-PREM-TOL-AMT
020874*                                     * 100
020874         MOVE RSCOM-PEND-PREM-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7752-FORMAT-PRTLA
                   THRU 7752-FORMAT-PRTLA-X

020874*        MOVE RSCOM-INFC-PREM-TOL-PCT
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-INFC-PREM-TOL-PCT
020874         MOVE RSCOM-INFC-PREM-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-INFC-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-INFC-PREM-TOL-PCT
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-INFC-PREM-TOL-AMT
020874*                                     * 100
020874         MOVE RSCOM-INFC-PREM-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7782-FORMAT-PRTLAI
                   THRU 7782-FORMAT-PRTLAI-X

020874*        MOVE RSCOM-LOAN-REPAY-TOL-PCT
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-LOAN-REPAY-TOL-PCT
020874         MOVE RSCOM-LOAN-REPAY-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-LOAN-REPAY-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-REPAY-TOL-PCT
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-LOAN-REPAY-TOL-AMT
020874*                                     * 100
020874         MOVE RSCOM-LOAN-REPAY-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7812-FORMAT-LNTLA
                   THRU 7812-FORMAT-LNTLA-X

020467         MOVE RSCOM-DD2-LEAD-DY-DUR TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-LEAD-DY-DUR
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-LEAD-DY-DUR
020467
020463         MOVE RSCOM-PRFL-REBAL-TOL-PCT TO L0290-INPUT-V02
020463         MOVE 2                        TO L0290-PRECISION
020463         MOVE LENGTH OF MIR-PRFL-REBAL-TOL-PCT
020463                                       TO L0290-MAX-OUT-LEN
020463         PERFORM 0290-2000-FORMAT-FOR-MIR
020463            THRU 0290-2000-FORMAT-FOR-MIR-X
020463         MOVE L0290-OUTPUT-DATA        TO MIR-PRFL-REBAL-TOL-PCT

           ELSE
020874*        MOVE RSCOM-MAX-BCKDT-MO-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-MAX-BCKDT-MO-DUR
020874         MOVE RSCOM-MAX-BCKDT-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-BCKDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-BCKDT-MO-DUR
020874*        MOVE RSCOM-FINAL-DISP-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-FINAL-DISP-DY-DUR
020874         MOVE RSCOM-FINAL-DISP-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DISP-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DISP-DY-DUR
020874*        MOVE RSCOM-MAX-PSTDT-MO-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-MAX-PSTDT-MO-DUR
020874         MOVE RSCOM-MAX-PSTDT-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-PSTDT-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-PSTDT-MO-DUR
020874*        MOVE RSCOM-DISP-WARN-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-DISP-WARN-DY-DUR
020874         MOVE RSCOM-DISP-WARN-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DISP-WARN-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-DISP-WARN-DY-DUR
020874*        MOVE RSCOM-MAX-UNDO-MO-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-MAX-UNDO-MO-DUR
020874         MOVE RSCOM-MAX-UNDO-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-UNDO-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-MAX-UNDO-MO-DUR
020874*        MOVE RSCOM-CRC-LEAD-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-CRC-LEAD-DY-DUR
020874         MOVE RSCOM-CRC-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-LEAD-DY-DUR
020874*        MOVE RSCOM-BILL-LEAD-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-BILL-LEAD-DY-DUR
020874         MOVE RSCOM-BILL-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BILL-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-BILL-LEAD-DY-DUR
020874*        MOVE RSCOM-PAC-LEAD-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-PAC-LEAD-DY-DUR
020874         MOVE RSCOM-PAC-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PAC-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PAC-LEAD-DY-DUR
020874*        MOVE RSCOM-ANPAYO-LEAD-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-ANPAYO-LEAD-DY-DUR
020874         MOVE RSCOM-ANPAYO-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ANPAYO-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ANPAYO-LEAD-DY-DUR
020874*        MOVE RSCOM-CLM-LEAD-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-CLM-LEAD-DY-DUR
020874         MOVE RSCOM-CLM-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLM-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLM-LEAD-DY-DUR
020874*        MOVE RSCOM-OTHR-LEAD-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-OTHR-LEAD-DY-DUR
020874         MOVE RSCOM-OTHR-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-OTHR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-OTHR-LEAD-DY-DUR
020874*        MOVE RSCOM-REQIR-LEAD-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-REQIR-LEAD-DY-DUR
020874         MOVE RSCOM-REQIR-LEAD-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-REQIR-LEAD-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-REQIR-LEAD-DY-DUR
020874*        MOVE RSCOM-FRST-ISS-DY TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FRST-ISS-DY
020874         MOVE RSCOM-FRST-ISS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-ISS-DY
020874*        MOVE RSCOM-FINAL-ISS-DY   TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FINAL-ISS-DY
020874         MOVE RSCOM-FINAL-ISS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-ISS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-ISS-DY
020874*        MOVE RSCOM-PEND-PREM-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-PEND-PREM-TOL-PCT
020874         MOVE RSCOM-PEND-PREM-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-PEND-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-PEND-PREM-TOL-PCT
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-PEND-PREM-TOL-AMT
020874*                                     * 100
020874         MOVE RSCOM-PEND-PREM-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7752-FORMAT-PRTLA
                   THRU 7752-FORMAT-PRTLA-X

020874*        MOVE RSCOM-INFC-PREM-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-INFC-PREM-TOL-PCT
020874         MOVE RSCOM-INFC-PREM-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-INFC-PREM-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-INFC-PREM-TOL-PCT
020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-INFC-PREM-TOL-AMT
020874*                                     * 100
020874         MOVE RSCOM-INFC-PREM-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7782-FORMAT-PRTLAI
                   THRU 7782-FORMAT-PRTLAI-X

020874*        MOVE RSCOM-LOAN-REPAY-TOL-PCT
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-LOAN-REPAY-TOL-PCT
020874         MOVE RSCOM-LOAN-REPAY-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-LOAN-REPAY-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-LOAN-REPAY-TOL-PCT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                RSCOM-LOAN-REPAY-TOL-AMT * 100
020874         MOVE RSCOM-LOAN-REPAY-TOL-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  7812-FORMAT-LNTLA
                   THRU 7812-FORMAT-LNTLA-X

020467         MOVE RSCOM-DD2-LEAD-DY-DUR TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-LEAD-DY-DUR
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-LEAD-DY-DUR
020467
020463         MOVE RSCOM-PRFL-REBAL-TOL-PCT TO L0290-INPUT-V02
020463         MOVE 2                        TO L0290-PRECISION
020463         MOVE LENGTH OF MIR-PRFL-REBAL-TOL-PCT
020463                                       TO L0290-MAX-OUT-LEN
020463         PERFORM 0290-2000-FORMAT-FOR-MIR
020463            THRU 0290-2000-FORMAT-FOR-MIR-X
020463         MOVE L0290-OUTPUT-DATA        TO MIR-PRFL-REBAL-TOL-PCT

           END-IF.

      *
      ***SCREEN 2 DATA
      *
           MOVE RSCOM-COMIT-TOL-CALC-CD
                                      TO MIR-COMIT-TOL-CALC-CD.
           MOVE RSCOM-ROLOVR-TOL-CALC-CD
                                      TO MIR-ROLOVR-TOL-CALC-CD.
           MOVE RSCOM-INIT-PAC-DRW-IND   TO MIR-INIT-PAC-DRW-IND.
           MOVE RSCOM-COMIT-TOL-CD    TO MIR-COMIT-TOL-CD.
           MOVE RSCOM-ROLOVR-TOL-CD   TO MIR-ROLOVR-TOL-CD.
           MOVE RSCOM-INIT-PAC-REDRW-IND
                                      TO MIR-INIT-PAC-REDRW-IND.
           MOVE RSCOM-PAC-REDRW-OPT-CD   TO MIR-PAC-REDRW-OPT-CD.
           MOVE RSCOM-PAC-REDRW-DUR   TO MIR-PAC-REDRW-DUR.
           MOVE RSCOM-COMIT-INT-RT-CD TO MIR-COMIT-INT-RT-CD.
           MOVE RSCOM-ROLOVR-INT-RT-CD   TO MIR-ROLOVR-INT-RT-CD.
           MOVE RSCOM-COMIT-STRT-CD   TO MIR-COMIT-STRT-CD.
016395     MOVE RSCOM-CRC-REDRW-OPT-CD  TO MIR-CRC-REDRW-OPT-CD.
016395     MOVE RSCOM-CRC-REDRW-DUR   TO MIR-CRC-REDRW-DUR.
020467
020467     MOVE RSCOM-DD2-DRW-MRG-IND       TO MIR-DD2-DRW-MRG-IND.
020467
020467     MOVE RSCOM-INIT-DD2-DRW-IND   TO MIR-INIT-DD2-DRW-IND.
020467     MOVE RSCOM-INIT-DD2-REDRW-IND
020467                                   TO MIR-INIT-DD2-REDRW-IND.
020467     MOVE RSCOM-DD2-REDRW-OPT-CD   TO MIR-DD2-REDRW-OPT-CD.
020467     MOVE RSCOM-DD2-REDRW-DUR      TO MIR-DD2-REDRW-DUR.
023443     MOVE RSCOM-DLR-DIV-RECALC-IND TO MIR-DLR-DIV-RECALC-IND.
029060     MOVE RSCOM-MEC-2YR-ADJ-IND    TO MIR-MEC-2YR-ADJ-IND.

           IF  WS-BUS-FCN-UPDATE
020874*        MOVE RSCOM-COMIT-PERI-DY-DUR-N
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-COMIT-PERI-DY-DUR
020874         MOVE RSCOM-COMIT-PERI-DY-DUR-N TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-PERI-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-PERI-DY-DUR
020874*        MOVE RSCOM-ROLOVR-DY-DUR
020874*                               TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-ROLOVR-DY-DUR
020874         MOVE RSCOM-ROLOVR-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-DY-DUR
020874*        MOVE RSCOM-FRST-DPOS-DY   TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-FRST-DPOS-DY
020874         MOVE RSCOM-FRST-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-DPOS-DY
020874*        MOVE RSCOM-FINAL-DPOS-DY
020874*                               TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-FINAL-DPOS-DY
020874         MOVE RSCOM-FINAL-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DPOS-DY
020874*        MOVE RSCOM-CRC-FRST-DPOS-DY  TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-FRST-DPOS-DY
020874         MOVE RSCOM-CRC-FRST-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FRST-DPOS-DY
020874*        MOVE RSCOM-CRC-FINAL-DPOS-DY TO WS-N-999
020874*        MOVE WS-N-999          TO MIR-CRC-FINAL-DPOS-DY
020874         MOVE RSCOM-CRC-FINAL-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FINAL-DPOS-DY
               MOVE RSCOM-COMIT-TOL-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8032-FORMAT-COMTA
                   THRU 8032-FORMAT-COMTA-X
               MOVE RSCOM-ROLOVR-TOL-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8102-FORMAT-RTOLF
                   THRU 8102-FORMAT-RTOLF-X

020874*        MOVE RSCOM-COMIT-TOL-PCT-N
020874*                               TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-COMIT-TOL-PCT
020874         MOVE RSCOM-COMIT-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-TOL-PCT
020874*        MOVE RSCOM-ROLOVR-TOL-PCT
020874*                               TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-ROLOVR-TOL-PCT
020874         MOVE RSCOM-ROLOVR-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-TOL-PCT

020467         MOVE RSCOM-DD2-FRST-DPOS-DY TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FRST-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FRST-DPOS-DY
020467
020467         MOVE RSCOM-DD2-FINAL-DPOS-DY TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FINAL-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FINAL-DPOS-DY
           ELSE
020874*        MOVE RSCOM-COMIT-PERI-DY-DUR-N
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-COMIT-PERI-DY-DUR
020874         MOVE RSCOM-COMIT-PERI-DY-DUR-N TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-PERI-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-PERI-DY-DUR
020874*        MOVE RSCOM-ROLOVR-DY-DUR
020874*                               TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-ROLOVR-DY-DUR
020874         MOVE RSCOM-ROLOVR-DY-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-DY-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-DY-DUR
020874*        MOVE RSCOM-FRST-DPOS-DY   TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FRST-DPOS-DY
020874         MOVE RSCOM-FRST-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FRST-DPOS-DY
020874*        MOVE RSCOM-FINAL-DPOS-DY
020874*                               TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-FINAL-DPOS-DY
020874         MOVE RSCOM-FINAL-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-FINAL-DPOS-DY
020874*        MOVE RSCOM-CRC-FRST-DPOS-DY TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-CRC-FRST-DPOS-DY
020874         MOVE RSCOM-CRC-FRST-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FRST-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FRST-DPOS-DY
020874*        MOVE RSCOM-CRC-FINAL-DPOS-DY TO WS-PIC-ZZ9
020874*        MOVE WS-PIC-ZZ9        TO MIR-CRC-FINAL-DPOS-DY
020874         MOVE RSCOM-CRC-FINAL-DPOS-DY TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRC-FINAL-DPOS-DY
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRC-FINAL-DPOS-DY

               MOVE RSCOM-COMIT-TOL-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8032-FORMAT-COMTA
                   THRU 8032-FORMAT-COMTA-X
               MOVE RSCOM-ROLOVR-TOL-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8102-FORMAT-RTOLF
                   THRU 8102-FORMAT-RTOLF-X
020874*        MOVE RSCOM-COMIT-TOL-PCT-N
020874*                               TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-COMIT-TOL-PCT
020874         MOVE RSCOM-COMIT-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-COMIT-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-COMIT-TOL-PCT
020874*        MOVE RSCOM-ROLOVR-TOL-PCT
020874*                               TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-ROLOVR-TOL-PCT
020874         MOVE RSCOM-ROLOVR-TOL-PCT TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ROLOVR-TOL-PCT
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-ROLOVR-TOL-PCT

020467         MOVE RSCOM-DD2-FRST-DPOS-DY TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FRST-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FRST-DPOS-DY
020467
020467         MOVE RSCOM-DD2-FINAL-DPOS-DY TO L0290-INPUT-V00
020467         MOVE 0                 TO L0290-PRECISION
020467         MOVE LENGTH OF MIR-DD2-FINAL-DPOS-DY
020467                                TO L0290-MAX-OUT-LEN
020467         PERFORM 0290-2000-FORMAT-FOR-MIR
020467            THRU 0290-2000-FORMAT-FOR-MIR-X
020467         MOVE L0290-OUTPUT-DATA TO MIR-DD2-FINAL-DPOS-DY
           END-IF.

      *
      ***SCREEN 3 DATA
      *
           MOVE RSCOM-TCR-INCL-AD-IND TO MIR-TCR-INCL-AD-IND.
020874*    MOVE RSCOM-UWG-CHNG-MO-DUR TO WS-N-99-1.
020874*    MOVE RSCOM-UWG-CHNG-DY-DUR TO WS-N-99-2.
017308*    MOVE WS-N-9999             TO MIR-UWG-CHNG-MO-DUR.
020874*    MOVE WS-N-99-1             TO MIR-UWG-CHNG-MO-DUR.
020874     MOVE RSCOM-UWG-CHNG-MO-DUR TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-UWG-CHNG-MO-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-UWG-CHNG-MO-DUR.
020874*    MOVE WS-N-99-2             TO MIR-UWG-CHNG-DY-DUR.
020874     MOVE RSCOM-UWG-CHNG-DY-DUR TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-UWG-CHNG-DY-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-UWG-CHNG-DY-DUR.
           MOVE RSCOM-MAX-ALCHL-QTY   TO WS-PIC-ZZZ9.
           MOVE WS-PIC-ZZZ9           TO MIR-MAX-ALCHL-QTY.
020874*    MOVE RSCOM-CLI-INCM-MO-DUR TO WS-N-999.
020874*    MOVE WS-N-999              TO MIR-CLI-INCM-MO-DUR.
020874     MOVE RSCOM-CLI-INCM-MO-DUR TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLI-INCM-MO-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CLI-INCM-MO-DUR.
           MOVE RSCOM-MIB-CO-SYMBL-CD TO MIR-MIB-CO-SYMBL-CD.
           MOVE RSCOM-MIB-CO-DEST-CD  TO MIR-MIB-CO-DEST-CD.
016440*    MOVE RSCOM-TCR-CALC-MTHD-CD   TO MIR-TCR-CALC-MTHD-CD.
           MOVE RSCOM-TCR-BASE-DT-CD  TO MIR-TCR-BASE-DT-CD.
           IF  WS-BUS-FCN-UPDATE
               MOVE RSCOM-CLI-MAX-AD-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8202-FORMAT-MXADB
                   THRU 8202-FORMAT-MXADB-X

               MOVE RSCOM-CLI-MAXWP-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8222-FORMAT-MXWPA
                   THRU 8222-FORMAT-MXWPA-X

               MOVE RSCOM-TOT-INS-DSCREP-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8232-FORMAT-MDISC
                   THRU 8232-FORMAT-MDISC-X

020874*        COMPUTE L0290-INPUT-NUMBER = RSCOM-CLI-MAXWP-PREM-AMT
020874*                                     * 100
020874         MOVE RSCOM-CLI-MAXWP-PREM-AMT
020874                                TO L0290-INPUT-V02
               PERFORM  8242-FORMAT-MXWPP
                   THRU 8242-FORMAT-MXWPP-X

020874*        MOVE RSCOM-MAX-UWG-AMT TO L0290-INPUT-NUMBER
020874         MOVE RSCOM-MAX-UWG-AMT TO L0290-INPUT-V00
               PERFORM  8262-FORMAT-MAXUW
                   THRU 8262-FORMAT-MAXUW-X

               MOVE RSCOM-MAX-CHILD-AGE
                                      TO WS-N-99
               MOVE WS-N-99           TO MIR-MAX-CHILD-AGE
020874*        MOVE RSCOM-CRNT-ADDR-YR-DUR
020874*                               TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-CRNT-ADDR-YR-DUR
020874         MOVE RSCOM-CRNT-ADDR-YR-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRNT-ADDR-YR-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRNT-ADDR-YR-DUR
020874*        MOVE RSCOM-TCR-INFC-MO-DUR
020874*                               TO WS-N-99
020874*        MOVE WS-N-99           TO MIR-TCR-INFC-MO-DUR
020874         MOVE RSCOM-TCR-INFC-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-TCR-INFC-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-TCR-INFC-MO-DUR
               MOVE RSCOM-HWTB-MIN-RAT-QTY
                                      TO WS-N-999
               MOVE WS-N-999          TO MIR-HWTB-MIN-RAT-QTY
               MOVE RSCOM-HWTB-MAX-RAT-QTY
                                      TO WS-N-999
               MOVE WS-N-999          TO MIR-HWTB-MAX-RAT-QTY
           ELSE
               MOVE RSCOM-CLI-MAX-AD-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8202-FORMAT-MXADB
                   THRU 8202-FORMAT-MXADB-X

               MOVE RSCOM-CLI-MAXWP-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8222-FORMAT-MXWPA
                   THRU 8222-FORMAT-MXWPA-X

               MOVE RSCOM-TOT-INS-DSCREP-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
               PERFORM  8232-FORMAT-MDISC
                   THRU 8232-FORMAT-MDISC-X

020874*        COMPUTE L0290-INPUT-NUMBER
020874*                                  = RSCOM-CLI-MAXWP-PREM-AMT
020874*                                   * 100
               PERFORM  8242-FORMAT-MXWPP
                   THRU 8242-FORMAT-MXWPP-X

020874*        MOVE RSCOM-MAX-UWG-AMT TO L0290-INPUT-NUMBER
020874         MOVE RSCOM-MAX-UWG-AMT TO L0290-INPUT-V00
               PERFORM  8262-FORMAT-MAXUW
                   THRU 8262-FORMAT-MAXUW-X

               MOVE RSCOM-MAX-CHILD-AGE
                                      TO WS-PIC-Z9
               MOVE WS-PIC-Z9         TO MIR-MAX-CHILD-AGE
020874*        MOVE RSCOM-CRNT-ADDR-YR-DUR
020874*                               TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-CRNT-ADDR-YR-DUR
020874         MOVE RSCOM-CRNT-ADDR-YR-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CRNT-ADDR-YR-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CRNT-ADDR-YR-DUR
020874*        MOVE RSCOM-TCR-INFC-MO-DUR
020874*                               TO WS-PIC-Z9
020874*        MOVE WS-PIC-Z9         TO MIR-TCR-INFC-MO-DUR
020874         MOVE RSCOM-TCR-INFC-MO-DUR TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-TCR-INFC-MO-DUR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-TCR-INFC-MO-DUR
               MOVE RSCOM-HWTB-MIN-RAT-QTY
                                      TO WS-PIC-ZZ9
               MOVE WS-PIC-ZZ9        TO MIR-HWTB-MIN-RAT-QTY
               MOVE RSCOM-HWTB-MAX-RAT-QTY
                                      TO WS-PIC-ZZ9
               MOVE WS-PIC-ZZ9        TO MIR-HWTB-MAX-RAT-QTY
           END-IF.


      *
      ***SCREEN 4 DATA
      *
016440*    MOVE RSCOM-DI-CCAS-INCL-CD TO MIR-DI-CCAS-INCL-CD.
020874*    MOVE RSCOM-MAX-ADND-AMT    TO L0290-INPUT-NUMBER.
020874     MOVE RSCOM-MAX-ADND-AMT    TO L0290-INPUT-V00.
           PERFORM  8572-FORMAT-MXADD
               THRU 8572-FORMAT-MXADD-X.
020874*    MOVE RSCOM-MAX-INCM-RATIO-PCT
020874*                               TO WS-N-999.
020874*    MOVE WS-N-999              TO MIR-MAX-INCM-RATIO-PCT.
020874     MOVE RSCOM-MAX-INCM-RATIO-PCT TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MAX-INCM-RATIO-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-INCM-RATIO-PCT.
           MOVE RSCOM-SUM-INS-DSCREP-AMT
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
           PERFORM  8602-FORMAT-HMDIS
               THRU 8602-FORMAT-HMDIS-X.
           PERFORM  9220-MOVE-OOE-ENTRY
               THRU 9220-MOVE-OOE-ENTRY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-HOURS-ENTRIES.
           PERFORM  9230-MOVE-HOURS-ENTRY
               THRU 9230-MOVE-HOURS-ENTRY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WSCOM-MAX-HOURS-ENTRIES.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
       9220-MOVE-OOE-ENTRY.

           MOVE RSCOM-OOE-OCCP-CLAS-CD (WS-SUB)
                                   TO MIR-OOE-3-OCCP-CLAS-CD-T (WS-SUB).
           MOVE RSCOM-OOE-MAX-AMT (WS-SUB)
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
           PERFORM  8532-FORMAT-OOEMX
               THRU 8532-FORMAT-OOEMX-X.
           MOVE RSCOM-OOE-MAX-CCAS-AMT (WS-SUB)
020874*                               TO L0290-INPUT-NUMBER.
020874                                TO L0290-INPUT-V00.
           PERFORM  8542-FORMAT-OOECC
               THRU 8542-FORMAT-OOECC-X.

       9220-MOVE-OOE-ENTRY-X.
           EXIT.


       9230-MOVE-HOURS-ENTRY.

           MOVE RSCOM-MIN-WRK-QTY (WS-SUB)
                                      TO WS-N-999V9.
           MOVE WS-N-999V9            TO MIR-MIN-WRK-3-QTY-T (WS-SUB).
           MOVE RSCOM-MAX-WRK-QTY (WS-SUB)
                                      TO WS-N-999V9.
           MOVE WS-N-999V9            TO MIR-MAX-WRK-3-QTY-T (WS-SUB).
           MOVE RSCOM-SBSDRY-CO-WRK-CD (WS-SUB)
                                   TO MIR-SBSDRY-CO-WRK-3-CD-T (WS-SUB).
           MOVE RSCOM-WRK-DUR-CD  (WS-SUB)
                                      TO MIR-WRK-DUR-3-CD-T (WS-SUB).

       9230-MOVE-HOURS-ENTRY-X.
           EXIT.

      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                        WS-WORKING-STORAGE.
025970     INITIALIZE                        WS-COUNTERS.
025970     INITIALIZE                        EHWMD-EDIT-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME         TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY           TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /

      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPELANG.
      /
       COPY CCPESTB4.
      /
       COPY NCPEHWMD.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY SCOM
014221                         '$VAR2' BY 'SCOM'.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /

      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
015904*COPY XCPL1640.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS
      ****************************************************************
014660*COPY XCPPMEXT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY CCPASCOM.
       COPY CCPBSCOM.
       COPY CCPNSCOM.
       COPY CCPUSCOM.
       COPY CCPXSCOM.
       COPY CCPCSCOM.

      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
016537*COPY XCCPHNDL.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM3360                     **
      *****************************************************************
