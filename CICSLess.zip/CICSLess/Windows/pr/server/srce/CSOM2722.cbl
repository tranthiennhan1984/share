      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2722.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2722                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE IPRO TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2722'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '2722'.

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '2722'.      
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWEBLCH.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRIPRD.
       COPY CCFWIPRE.
       COPY CCFRIPRO.
       COPY CCFWIPRO.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2722.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2722'     TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------
      *
      *  THE RECORD MUST EXIST ON A MAINTAIN
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  IPRO-2000-UPDATE-TWRK-TS
               THRU IPRO-2000-UPDATE-TWRK-TS-X.

           IF  WIPRO-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WIPRO-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           IF MIR-RETRN-TS-MISMATCH
      * MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS 
      *       HAS UPDATED - TABLE (@1), KEY @2'
              MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
              MOVE 'IPRO'           TO WGLOB-MSG-PARM (1)
              MOVE RIPRO-KEY        TO WGLOB-MSG-PARM (2)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-UPDATE-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               SET MIR-RETRN-EDIT-ERROR       TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  IPRO-2000-REWRITE
               THRU IPRO-2000-REWRITE-X.

      *  UPDATE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  IPRO-1000-READ-TWRK-TS
               THRU IPRO-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.
      /
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WIPRO-KEY.

           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.


       7000-BUILD-KEYS-X.
           EXIT.
      /
      *--------------------
       8000-EDITS.
      *--------------------

      *THE PROFILE EXPIRY DATE SHOULD BE A VALID DATE

           PERFORM  8100-EDIT-PRFL-XPRY-DT
               THRU 8100-EDIT-PRFL-XPRY-DT-X.

      *THE PROFILE EXPIRY DATE SHOULD BE GREATER THAN OR EQUAL 
      *TO THE INVESTOR PROFILE EFFECTIVE DATE (ON INVESTOR PROFILE
      *DETAIL IPRD TABLE).

      *BROWSE THE IPRD TO FIND THE ACTIVE RECORD
           MOVE LOW-VALUES             TO WIPRE-KEY.
           MOVE MIR-PRFL-ID            TO WIPRE-PRFL-ID.
           SET WIPRE-PRFLD-STAT-ACTV   TO TRUE.

           MOVE WIPRE-KEY              TO WIPRE-ENDBR-KEY.

           PERFORM  IPRE-1000-BROWSE
               THRU IPRE-1000-BROWSE-X.

           PERFORM  IPRE-2000-READ-NEXT
               THRU IPRE-2000-READ-NEXT-X.

      *ONLY IF AN ACTIVE RECORD IS FOUND THEN COMPARE EFFECTIVE AND 
      *EXPIRY DATES
           IF WIPRE-IO-OK
              IF  RIPRD-PRFLD-STAT-ACTV
              AND RIPRO-PRFL-XPRY-DT NOT = WWKDT-ZERO-DT
                 IF RIPRO-PRFL-XPRY-DT < RIPRD-PRFLD-EFF-DT
      *MSG: PROFILE EXPIRY DATE CANNOT BE (@1) <  PROFILE EFF DATE (@2)
                   MOVE 'CS27220002'         TO WGLOB-MSG-REF-INFO
                   MOVE RIPRO-PRFL-XPRY-DT   TO WGLOB-MSG-PARM (1)
                   MOVE RIPRD-PRFLD-EFF-DT   TO WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR    TO TRUE
                 END-IF
              END-IF
           END-IF.

           PERFORM  IPRE-3000-END-BROWSE
               THRU IPRE-3000-END-BROWSE-X.

       8000-EDITS-X.
           EXIT.
      /
      *----------------------------
       8100-EDIT-PRFL-XPRY-DT.
      *----------------------------

           IF  MIR-PRFL-XPRY-DT = SPACE
           OR  MIR-PRFL-XPRY-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE WWKDT-ZERO-DT        TO RIPRO-PRFL-XPRY-DT
               GO TO 8100-EDIT-PRFL-XPRY-DT-X
           END-IF.

           MOVE MIR-PRFL-XPRY-DT         TO L1640-EXTERNAL-DATE.
           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      *MSG: PROFILE EXPIRY DATE MUST BE VALID
               MOVE 'CS27220001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE  TO RIPRO-PRFL-XPRY-DT
           END-IF.

       8100-EDIT-PRFL-XPRY-DT-X.
           EXIT.

      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           MOVE SPACES TO MIR-PRFL-XPRY-DT.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

      * MOVE PROFILE EXPIRY DATE TO MIR FIELD

           IF RIPRO-PRFL-XPRY-DT NOT = SPACES
              MOVE RIPRO-PRFL-XPRY-DT      TO L1640-INTERNAL-DATE
              PERFORM  1640-8000-INTERNAL-TO-MIR
                  THRU 1640-8000-INTERNAL-TO-MIR-X
              MOVE L1640-EXTERNAL-DATE     TO MIR-PRFL-XPRY-DT
           END-IF.
           
       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE          WS-WORKING-STORAGE.
025970     SET  WS-TWRK-KEY-DEFAULT            TO TRUE.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.


       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  IPRO
                                '$VAR2'   BY 'IPRO'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBIPRE.
       COPY CCPNIPRO.
       COPY CCPUIPRO.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM 'CSOM2722'                   **
      *****************************************************************
